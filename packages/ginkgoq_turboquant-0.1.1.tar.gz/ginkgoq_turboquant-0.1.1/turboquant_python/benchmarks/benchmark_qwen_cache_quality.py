"""Real Qwen cache-quality benchmark on Wikitext-2.

This benchmark scores next-token negative log likelihood with an explicit cache
loop so the selected KV cache implementation is exercised during evaluation.
It is intentionally small by default because Hugging Face eager cache adapters
are slow; increase --documents and --tokens-per-doc for stronger evidence.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import torch
import torch.nn.functional as F
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache

from torbuquant.llm import TurboQuantDynamicCache


@dataclass(frozen=True)
class CacheMode:
    name: str
    key_method: str
    key_bits: int
    value_bits: int
    recent_tokens: int
    dense: bool = False


def _cache_modes(recent_tokens: int) -> list[CacheMode]:
    return [
        CacheMode("dense_sdpa", "mse", 16, 16, 0, dense=True),
        CacheMode("tq_mse_k4v8", "mse", 4, 8, recent_tokens),
        CacheMode("tq_prod_k4v8", "prod", 4, 8, recent_tokens),
        CacheMode("tq_prod_k4v4", "prod", 4, 4, recent_tokens),
    ]


def _load_token_sequences(tokenizer, *, documents: int, tokens_per_doc: int) -> list[torch.Tensor]:
    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
    sequences = []
    for row in dataset:
        text = " ".join(row["text"].split())
        if len(text) < 200:
            continue
        ids = tokenizer(text, return_tensors="pt", truncation=True, max_length=tokens_per_doc + 1).input_ids[0]
        if ids.numel() >= tokens_per_doc + 1:
            sequences.append(ids[: tokens_per_doc + 1])
        if len(sequences) >= documents:
            return sequences
    raise RuntimeError("not enough Wikitext-2 rows with the requested token length")


def _make_cache(mode: CacheMode, model, *, device: torch.device) -> DynamicCache | TurboQuantDynamicCache:
    if mode.dense:
        return DynamicCache(num_hidden_layers=model.config.num_hidden_layers)

    head_dim = model.config.hidden_size // model.config.num_attention_heads
    return TurboQuantDynamicCache(
        num_hidden_layers=model.config.num_hidden_layers,
        head_dim=head_dim,
        key_bits=mode.key_bits,
        value_bits=mode.value_bits,
        recent_tokens=mode.recent_tokens,
        device=device,
        dtype=torch.float32,
        seed=0,
        cache_dequant=False,
        key_method=mode.key_method,
    )


@torch.inference_mode()
def _score_sequence(model, ids: torch.Tensor, cache, *, device: torch.device) -> tuple[float, int]:
    ids = ids.to(device)
    total_nll = 0.0
    count = 0
    attention_mask = torch.ones(1, 1, device=device, dtype=torch.long)

    for pos in range(ids.numel() - 1):
        token = ids[pos].view(1, 1)
        target = ids[pos + 1].view(1)
        if pos > 0:
            attention_mask = torch.ones(1, pos + 1, device=device, dtype=torch.long)
        outputs = model(
            input_ids=token,
            attention_mask=attention_mask,
            past_key_values=cache,
            use_cache=True,
        )
        loss = F.cross_entropy(outputs.logits[:, -1, :].float(), target)
        total_nll += float(loss.detach().cpu())
        count += 1

    return total_nll, count


def _cache_stats(cache) -> dict[str, float | None]:
    if not isinstance(cache, TurboQuantDynamicCache):
        return {
            "compressed_kv_mib": None,
            "dense_equivalent_mib": None,
            "compression_ratio": 1.0,
            "gpu_kv_mib": None,
        }
    return {
        "compressed_kv_mib": cache.compressed_memory_bytes() / 1024**2,
        "dense_equivalent_mib": cache.dense_memory_bytes() / 1024**2,
        "compression_ratio": cache.compression_ratio(),
        "gpu_kv_mib": cache.gpu_memory_bytes() / 1024**2,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--output-dir", default="runs/turboquant_qwen_quality")
    parser.add_argument("--documents", type=int, default=2)
    parser.add_argument("--tokens-per-doc", type=int, default=192)
    parser.add_argument("--recent-tokens", type=int, default=64)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    device = torch.device(args.device)
    dtype = torch.bfloat16 if device.type == "cuda" else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation="eager",
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()

    sequences = _load_token_sequences(tokenizer, documents=args.documents, tokens_per_doc=args.tokens_per_doc)
    rows = []
    for mode in _cache_modes(args.recent_tokens):
        start = time.perf_counter()
        total_nll = 0.0
        total_tokens = 0
        last_cache = None
        for ids in sequences:
            cache = _make_cache(mode, model, device=device)
            nll, count = _score_sequence(model, ids, cache, device=device)
            total_nll += nll
            total_tokens += count
            last_cache = cache
            del cache
            if device.type == "cuda":
                torch.cuda.empty_cache()
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        seconds = time.perf_counter() - start
        avg_nll = total_nll / total_tokens
        row = {
            **asdict(mode),
            "documents": args.documents,
            "tokens_per_doc": args.tokens_per_doc,
            "scored_tokens": total_tokens,
            "avg_nll": avg_nll,
            "perplexity": math.exp(avg_nll),
            "seconds": seconds,
            **_cache_stats(last_cache),
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

    jsonl_path = output_dir / "qwen_cache_quality.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as f:
        f.write(json.dumps({"metadata": vars(args)}, sort_keys=True) + "\n")
        for row in rows:
            f.write(json.dumps(row, sort_keys=True) + "\n")

    md_path = output_dir / "QWEN_CACHE_QUALITY.md"
    with md_path.open("w", encoding="utf-8") as f:
        f.write("# Qwen Cache Quality Benchmark\n\n")
        f.write(f"- model: `{args.model}`\n")
        f.write(f"- dataset: `wikitext-2-raw-v1` validation\n")
        f.write(f"- documents: `{args.documents}`\n")
        f.write(f"- tokens per document: `{args.tokens_per_doc}`\n")
        f.write(f"- recent dense window: `{args.recent_tokens}`\n\n")
        f.write("| Mode | Key Method | K/V Bits | PPL | Avg NLL | Compression | Seconds |\n")
        f.write("|------|------------|----------|----:|--------:|------------:|--------:|\n")
        for row in rows:
            bits = "dense" if row["dense"] else f"K{row['key_bits']}V{row['value_bits']}"
            f.write(
                f"| {row['name']} | {row['key_method']} | {bits} | "
                f"{row['perplexity']:.3f} | {row['avg_nll']:.4f} | "
                f"{row['compression_ratio']:.2f}x | {row['seconds']:.3f} |\n"
            )

    print(f"wrote {jsonl_path}")
    print(f"wrote {md_path}")


if __name__ == "__main__":
    main()
