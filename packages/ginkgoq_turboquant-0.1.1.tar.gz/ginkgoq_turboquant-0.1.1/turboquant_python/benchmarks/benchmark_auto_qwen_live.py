"""Live Qwen auto-mode smoke benchmark.

This loads Qwen once, selects cache policy with auto mode for several serving
scenarios, runs a short deterministic decode, and writes measured results.

It is intentionally a smoke test, not a production throughput benchmark. The
Qwen integration currently uses Hugging Face eager execution; production
throughput still requires paged KV / serving integration.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache

from torbuquant import AutoPolicyInput, choose_auto_kv_policy
from torbuquant.llm import TurboQuantDynamicCache


@dataclass(frozen=True)
class LiveScenario:
    name: str
    batch_size: int
    expected_context_tokens: int
    kv_budget_mb: float | None
    prefer_low_latency: bool = False
    key_method: str = "mse"


def _select_next(logits: torch.Tensor) -> torch.Tensor:
    return torch.argmax(logits[:, -1, :], dim=-1, keepdim=True)


def _load_prompt(tokenizer, *, min_tokens: int) -> str:
    try:
        from datasets import load_dataset

        dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
        parts: list[str] = []
        for row in dataset:
            text = " ".join(row["text"].split())
            if len(text) < 80:
                continue
            parts.append(text)
            prompt = "\n".join(parts)
            if len(tokenizer(prompt).input_ids) >= min_tokens:
                return prompt
    except Exception as exc:
        print(f"warning: could not load Wikitext-2 prompt; using fallback prompt: {exc}")

    return (
        "TurboQuant compresses the key-value cache used by transformer decoders. "
        "The benchmark should preserve model behavior while reducing memory and "
        "improving serving throughput under memory pressure. "
    ) * 32


@torch.inference_mode()
def _generate(model, tokenizer, prompt: str, cache, *, max_new_tokens: int) -> tuple[str, float]:
    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    input_ids = inputs.input_ids
    attention_mask = inputs.attention_mask

    if device.type == "cuda":
        torch.cuda.synchronize(device)
    start = time.perf_counter()

    outputs = model(input_ids=input_ids, attention_mask=attention_mask, past_key_values=cache, use_cache=True)
    next_token = _select_next(outputs.logits)
    generated = [next_token]

    for _ in range(max_new_tokens - 1):
        attention_mask = torch.cat([attention_mask, torch.ones_like(next_token)], dim=-1)
        outputs = model(input_ids=next_token, attention_mask=attention_mask, past_key_values=cache, use_cache=True)
        next_token = _select_next(outputs.logits)
        generated.append(next_token)

    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - start

    return tokenizer.decode(torch.cat(generated, dim=-1)[0], skip_special_tokens=True), elapsed


def _scenarios() -> list[LiveScenario]:
    return [
        LiveScenario(
            name="dense_low_latency",
            batch_size=1,
            expected_context_tokens=4096,
            kv_budget_mb=2048,
            prefer_low_latency=True,
        ),
        LiveScenario(
            name="k4v8_mse_throughput_policy",
            batch_size=8,
            expected_context_tokens=4096,
            kv_budget_mb=512,
            key_method="mse",
        ),
        LiveScenario(
            name="k4v8_prod_paper_faithful_keys",
            batch_size=8,
            expected_context_tokens=4096,
            kv_budget_mb=512,
            key_method="prod",
        ),
        LiveScenario(
            name="k4v4_prod_memory_pressure_policy",
            batch_size=8,
            expected_context_tokens=8192,
            kv_budget_mb=512,
            key_method="prod",
        ),
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--output-dir", default="runs/turboquant_auto_policy")
    parser.add_argument("--prompt-min-tokens", type=int, default=192)
    parser.add_argument("--max-new-tokens", type=int, default=2)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    device = torch.device(args.device)
    dtype = torch.bfloat16 if device.type == "cuda" else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation="eager",
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()

    prompt = _load_prompt(tokenizer, min_tokens=args.prompt_min_tokens)
    prompt_tokens = len(tokenizer(prompt).input_ids)
    config = model.config
    head_dim = config.hidden_size // config.num_attention_heads
    kv_heads = getattr(config, "num_key_value_heads", config.num_attention_heads)
    dtype_bytes = torch.empty((), dtype=dtype).element_size()

    rows = []
    for scenario in _scenarios():
        budget = None if scenario.kv_budget_mb is None else int(scenario.kv_budget_mb * 1024**2)
        policy = choose_auto_kv_policy(
            AutoPolicyInput(
                batch_size=scenario.batch_size,
                num_layers=config.num_hidden_layers,
                num_kv_heads=kv_heads,
                head_dim=head_dim,
                context_tokens=scenario.expected_context_tokens,
                dtype_bytes=dtype_bytes,
                available_kv_memory_bytes=budget,
                prefer_low_latency=scenario.prefer_low_latency,
            )
        )

        if policy.backend == "sdpa_fp16":
            cache = DynamicCache(num_hidden_layers=config.num_hidden_layers)
        else:
            cache = TurboQuantDynamicCache(
                num_hidden_layers=config.num_hidden_layers,
                head_dim=head_dim,
                key_bits=policy.k_bits,
                value_bits=policy.v_bits,
                key_method=scenario.key_method,
                recent_tokens=policy.recent_window,
                device=device,
                dtype=torch.float32,
                seed=0,
            )

        text, seconds = _generate(model, tokenizer, prompt, cache, max_new_tokens=args.max_new_tokens)

        compressed_bytes = None
        dense_bytes = policy.estimated_dense_kv_bytes
        actual_dense_bytes = None
        actual_compression = None
        if isinstance(cache, TurboQuantDynamicCache):
            compressed_bytes = cache.compressed_memory_bytes()
            actual_dense_bytes = cache.dense_memory_bytes()
            actual_compression = cache.compression_ratio()

        selected = policy.backend if policy.backend == "sdpa_fp16" else f"K{policy.k_bits}V{policy.v_bits}"
        row = {
            **asdict(scenario),
            "selected": selected,
            "key_method": scenario.key_method,
            "policy": asdict(policy),
            "prompt_tokens": prompt_tokens,
            "generated_text": text,
            "seconds": seconds,
            "actual_compressed_kv_mib": None if compressed_bytes is None else compressed_bytes / 1024**2,
            "actual_dense_equivalent_mib": None if actual_dense_bytes is None else actual_dense_bytes / 1024**2,
            "actual_compression": actual_compression,
            "estimated_dense_kv_mib": None if dense_bytes is None else dense_bytes / 1024**2,
            "estimated_selected_kv_mib": (
                None if policy.estimated_compressed_kv_bytes is None else policy.estimated_compressed_kv_bytes / 1024**2
            ),
        }
        rows.append(row)
        print(
            f"{scenario.name:32s} selected={selected:<10s} key_method={scenario.key_method:<4s} seconds={seconds:.3f} "
            f"actual_comp={actual_compression if actual_compression is not None else 1.0:.2f}x "
            f"text={text!r}"
        )

        del cache
        if device.type == "cuda":
            torch.cuda.empty_cache()

    jsonl_path = output_dir / "auto_qwen_live_results.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as f:
        f.write(
            json.dumps(
                {
                    "metadata": {
                        "model": args.model,
                        "prompt_tokens": prompt_tokens,
                        "max_new_tokens": args.max_new_tokens,
                        "dtype": str(dtype),
                        "device": str(device),
                    }
                },
                sort_keys=True,
            )
            + "\n"
        )
        for row in rows:
            f.write(json.dumps(row, sort_keys=True) + "\n")

    md_path = output_dir / "AUTO_QWEN_LIVE_RESULTS.md"
    with md_path.open("w", encoding="utf-8") as f:
        f.write("# Qwen2.5 Auto Mode Live Results\n\n")
        f.write(f"- model: `{args.model}`\n")
        f.write(f"- prompt tokens: `{prompt_tokens}`\n")
        f.write(f"- generated tokens per scenario: `{args.max_new_tokens}`\n")
        f.write(f"- execution: Hugging Face eager attention smoke test\n\n")
        f.write("| Scenario | Selected | Key Method | Seconds | Actual KV MiB | Dense Eq. MiB | Actual Compression | Generated |\n")
        f.write("|----------|----------|------------|--------:|--------------:|--------------:|-------------------:|-----------|\n")
        for row in rows:
            actual = "" if row["actual_compressed_kv_mib"] is None else f"{row['actual_compressed_kv_mib']:.2f}"
            dense_eq = "" if row["actual_dense_equivalent_mib"] is None else f"{row['actual_dense_equivalent_mib']:.2f}"
            comp = "1.00" if row["actual_compression"] is None else f"{row['actual_compression']:.2f}"
            generated = row["generated_text"].replace("|", "\\|")
            f.write(
                f"| {row['name']} | {row['selected']} | {row['key_method']} | {row['seconds']:.3f} | "
                f"{actual} | {dense_eq} | {comp}x | `{generated}` |\n"
            )
        f.write("\n")
        f.write("This is an execution smoke test. Use `benchmark_fixed_memory_throughput.py` for throughput claims.\n")

    print(f"\nwrote {jsonl_path}")
    print(f"wrote {md_path}")


if __name__ == "__main__":
    main()
