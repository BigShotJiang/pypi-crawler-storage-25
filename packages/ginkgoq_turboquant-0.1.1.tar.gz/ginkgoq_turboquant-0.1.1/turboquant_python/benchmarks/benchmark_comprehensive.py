"""Comprehensive isolated benchmark of all TurboQuant modes.

Tests all combinations across various token lengths with proper isolation
to ensure no test affects another.
"""

import gc
import time
import torch
import subprocess
import sys
from dataclasses import dataclass
from typing import List, Dict, Any


def reset_gpu():
    """Completely reset GPU state between tests."""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        # Small sleep to let GPU fully settle
        time.sleep(0.1)


def get_gpu_memory_mb():
    """Get current GPU memory usage in MB."""
    if torch.cuda.is_available():
        return torch.cuda.max_memory_allocated() / (1024 * 1024)
    return 0


@dataclass
class BenchmarkResult:
    """Single benchmark result."""
    mode: str
    rotation: str
    seq_len: int
    time_ms: float
    peak_memory_mb: float
    quantized_size_mb: float


def run_isolated_benchmark(
    mode: str,
    rotation: str,
    seq_len: int,
    dim: int = 128,
    bits: int = 3,
    batch_heads: int = 32,
    num_iters: int = 30,
    warmup_iters: int = 5,
) -> BenchmarkResult:
    """Run a single isolated benchmark."""

    # Fresh imports to avoid any cached state
    from torbuquant.quantizers import TurboQuantMSE

    reset_gpu()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Create quantizer
    quantizer = TurboQuantMSE(dim, bits, device=device, rotation_type=rotation)

    # Create test data
    keys = torch.randn(batch_heads, seq_len, dim, device=device)
    query = torch.randn(batch_heads, dim, device=device)

    # Quantize
    quantized = quantizer.quantize(keys)

    # Calculate quantized size
    quantized_size_mb = (
        quantized.indices.nelement() * quantized.indices.element_size() +
        quantized.norms.nelement() * quantized.norms.element_size()
    ) / (1024 * 1024)

    # Pre-rotate query if using direct score
    if mode in ("direct_pt", "direct_triton"):
        query_rotated = quantizer.rotate_query(query)

    # Warmup
    for _ in range(warmup_iters):
        if mode == "dequant_matmul":
            keys_full = quantizer.dequantize(quantized)
            _ = torch.matmul(query.unsqueeze(1), keys_full.transpose(-2, -1)).squeeze(1)
        elif mode == "direct_pt":
            _ = quantizer.direct_score(query_rotated.unsqueeze(1), quantized).squeeze(1)
        elif mode == "direct_triton":
            _ = quantizer.direct_score_triton(query_rotated.unsqueeze(1), quantized).squeeze(1)

        if device.type == "cuda":
            torch.cuda.synchronize()

    # Reset memory tracking after warmup
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    # Benchmark
    if device.type == "cuda":
        torch.cuda.synchronize()

    start = time.perf_counter()
    for _ in range(num_iters):
        if mode == "dequant_matmul":
            keys_full = quantizer.dequantize(quantized)
            scores = torch.matmul(query.unsqueeze(1), keys_full.transpose(-2, -1)).squeeze(1)
        elif mode == "direct_pt":
            scores = quantizer.direct_score(query_rotated.unsqueeze(1), quantized).squeeze(1)
        elif mode == "direct_triton":
            scores = quantizer.direct_score_triton(query_rotated.unsqueeze(1), quantized).squeeze(1)

        if device.type == "cuda":
            torch.cuda.synchronize()

    elapsed = time.perf_counter() - start
    time_ms = (elapsed / num_iters) * 1000
    peak_memory_mb = get_gpu_memory_mb()

    # Cleanup
    del keys, query, quantized, quantizer, scores
    if mode in ("direct_pt", "direct_triton"):
        del query_rotated
    reset_gpu()

    return BenchmarkResult(
        mode=mode,
        rotation=rotation,
        seq_len=seq_len,
        time_ms=time_ms,
        peak_memory_mb=peak_memory_mb,
        quantized_size_mb=quantized_size_mb,
    )


def run_all_benchmarks() -> List[BenchmarkResult]:
    """Run all benchmark combinations."""
    from torbuquant.quantizers import HAS_TRITON

    results = []

    # Configuration
    dim = 128
    bits = 3
    batch_heads = 32
    seq_lens = [256, 512, 1024, 2048, 4096, 8192]
    rotations = ["dense", "rht"]
    modes = ["dequant_matmul", "direct_pt"]
    if HAS_TRITON:
        modes.append("direct_triton")

    total_tests = len(seq_lens) * len(rotations) * len(modes)
    current_test = 0

    print(f"Running {total_tests} benchmark configurations...")
    print(f"Config: dim={dim}, bits={bits}, batch_heads={batch_heads}")
    print()

    for seq_len in seq_lens:
        for rotation in rotations:
            for mode in modes:
                current_test += 1
                print(f"[{current_test}/{total_tests}] seq_len={seq_len}, rotation={rotation}, mode={mode}...", end=" ", flush=True)

                try:
                    result = run_isolated_benchmark(
                        mode=mode,
                        rotation=rotation,
                        seq_len=seq_len,
                        dim=dim,
                        bits=bits,
                        batch_heads=batch_heads,
                    )
                    results.append(result)
                    print(f"{result.time_ms:.3f}ms, {result.peak_memory_mb:.1f}MB")
                except Exception as e:
                    print(f"FAILED: {e}")

                # Extra cleanup between tests
                reset_gpu()

    return results


def generate_markdown_report(results: List[BenchmarkResult], output_path: str):
    """Generate markdown report from results."""
    from torbuquant.quantizers import HAS_TRITON

    # Group results by seq_len
    by_seq_len: Dict[int, List[BenchmarkResult]] = {}
    for r in results:
        if r.seq_len not in by_seq_len:
            by_seq_len[r.seq_len] = []
        by_seq_len[r.seq_len].append(r)

    # Find baseline for speedup calculations
    def get_baseline(seq_len: int) -> float:
        for r in by_seq_len[seq_len]:
            if r.mode == "dequant_matmul" and r.rotation == "dense":
                return r.time_ms
        return 1.0

    md = []
    md.append("# TurboQuant Comprehensive Benchmark Results")
    md.append("")
    md.append("## Configuration")
    md.append("")
    md.append("| Parameter | Value |")
    md.append("|-----------|-------|")
    md.append("| Dimension | 128 |")
    md.append("| Bits | 3 |")
    md.append("| Batch × Heads | 32 |")
    md.append(f"| Triton Available | {HAS_TRITON} |")
    md.append(f"| Device | {'CUDA' if torch.cuda.is_available() else 'CPU'} |")
    if torch.cuda.is_available():
        md.append(f"| GPU | {torch.cuda.get_device_name(0)} |")
    md.append("")

    md.append("## Mode Descriptions")
    md.append("")
    md.append("| Mode | Description | Pros | Cons |")
    md.append("|------|-------------|------|------|")
    md.append("| `dequant_matmul` | Dequantize keys → cuBLAS matmul | Simple, uses optimized cuBLAS | Must materialize full K tensor |")
    md.append("| `direct_pt` | PyTorch direct score computation | No full K tensor needed | Still uses tensor ops |")
    md.append("| `direct_triton` | Triton fused kernel | Fused ops, best for long seq | Kernel launch overhead for short seq |")
    md.append("")

    md.append("| Rotation | Description | Memory | Speed |")
    md.append("|----------|-------------|--------|-------|")
    md.append("| `dense` | O(d²) Gaussian QR matrix | d×d float32 | cuBLAS optimized |")
    md.append("| `rht` | O(d log d) Hadamard + signs | 2×d float32 | PyTorch overhead |")
    md.append("")

    md.append("## Detailed Results by Sequence Length")
    md.append("")

    for seq_len in sorted(by_seq_len.keys()):
        baseline_time = get_baseline(seq_len)
        md.append(f"### Sequence Length: {seq_len}")
        md.append("")
        md.append("| Rotation | Mode | Time (ms) | Speedup | Peak Memory (MB) |")
        md.append("|----------|------|-----------|---------|------------------|")

        for r in sorted(by_seq_len[seq_len], key=lambda x: (x.rotation, x.mode)):
            speedup = baseline_time / r.time_ms if r.time_ms > 0 else 0
            speedup_str = f"{speedup:.2f}x" if speedup != 1.0 else "baseline"
            md.append(f"| {r.rotation} | {r.mode} | {r.time_ms:.3f} | {speedup_str} | {r.peak_memory_mb:.1f} |")

        md.append("")

    md.append("## Summary Tables")
    md.append("")

    # Speed comparison table
    md.append("### Speed Comparison (ms)")
    md.append("")
    header = "| Seq Len |"
    sep = "|---------|"
    modes_rotations = []
    for rotation in ["dense", "rht"]:
        for mode in ["dequant_matmul", "direct_pt", "direct_triton"]:
            col_name = f"{rotation[:1].upper()}-{mode.split('_')[0][:3]}"
            header += f" {col_name} |"
            sep += "--------|"
            modes_rotations.append((rotation, mode))
    md.append(header)
    md.append(sep)

    for seq_len in sorted(by_seq_len.keys()):
        row = f"| {seq_len} |"
        for rotation, mode in modes_rotations:
            found = False
            for r in by_seq_len[seq_len]:
                if r.rotation == rotation and r.mode == mode:
                    row += f" {r.time_ms:.2f} |"
                    found = True
                    break
            if not found:
                row += " N/A |"
        md.append(row)

    md.append("")

    # Key findings
    md.append("## Key Findings")
    md.append("")

    # Calculate averages for findings
    dense_dequant_times = [r.time_ms for r in results if r.rotation == "dense" and r.mode == "dequant_matmul"]
    rht_dequant_times = [r.time_ms for r in results if r.rotation == "rht" and r.mode == "dequant_matmul"]
    dense_direct_times = [r.time_ms for r in results if r.rotation == "dense" and r.mode == "direct_pt"]
    rht_direct_times = [r.time_ms for r in results if r.rotation == "rht" and r.mode == "direct_pt"]

    if dense_dequant_times and rht_dequant_times:
        avg_dequant_ratio = sum(rht_dequant_times) / sum(dense_dequant_times)
        md.append(f"1. **Dequant+matmul**: RHT is {avg_dequant_ratio:.2f}x vs Dense (RHT slower due to PyTorch Hadamard overhead)")

    if dense_direct_times and rht_direct_times:
        avg_direct_ratio = sum(rht_direct_times) / sum(dense_direct_times)
        md.append(f"2. **Direct score**: RHT is {avg_direct_ratio:.2f}x vs Dense (nearly equal - rotation is pre-computed!)")

    md.append(f"3. **Memory**: RHT saves 98.4% rotation matrix storage (2×d vs d×d)")
    md.append("")

    md.append("## Recommendations")
    md.append("")
    md.append("| Use Case | Recommended Config |")
    md.append("|----------|-------------------|")
    md.append("| Maximum speed | `rotation=dense` + `direct_pt` or `direct_triton` |")
    md.append("| Maximum memory savings | `rotation=rht` + `direct_pt` |")
    md.append("| Short sequences (<1024) | `rotation=dense` + `dequant_matmul` (cuBLAS optimized) |")
    md.append("| Long sequences (>4096) | `rotation=dense` + `direct_triton` |")
    md.append("")

    md.append("## Memory Analysis")
    md.append("")
    md.append("### Per-quantizer Memory (dim=128)")
    md.append("")
    md.append("| Component | Dense | RHT | Savings |")
    md.append("|-----------|-------|-----|---------|")
    md.append("| Rotation matrix | 64 KB | 1 KB | 98.4% |")
    md.append("| Centroids | 1 KB | 1 KB | 0% |")
    md.append("| Boundaries | 1 KB | 1 KB | 0% |")
    md.append("| **Total** | **66 KB** | **3 KB** | **95.5%** |")
    md.append("")

    md.append("### Quantized KV Storage (per token)")
    md.append("")
    md.append("| Format | Bytes/token/head |")
    md.append("|--------|------------------|")
    md.append("| FP16 dense | 256 |")
    md.append("| 3-bit quantized | ~48 + 4 (norms) |")
    md.append("| **Compression** | **~4.9x** |")
    md.append("")

    # Write file
    with open(output_path, "w") as f:
        f.write("\n".join(md))

    print(f"\nMarkdown report written to: {output_path}")


def main():
    print("=" * 80)
    print("TurboQuant Comprehensive Isolated Benchmark")
    print("=" * 80)
    print()

    # Check if CUDA available
    if not torch.cuda.is_available():
        print("WARNING: CUDA not available, running on CPU")
    else:
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    print()

    # Run benchmarks
    results = run_all_benchmarks()

    # Generate report
    output_path = "/home/arman/project/turboquant_python/BENCHMARK_RESULTS.md"
    generate_markdown_report(results, output_path)

    print()
    print("=" * 80)
    print("Benchmark complete!")
    print("=" * 80)


if __name__ == "__main__":
    main()
