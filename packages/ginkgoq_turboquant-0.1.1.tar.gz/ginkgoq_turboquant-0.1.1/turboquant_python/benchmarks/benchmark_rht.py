"""Benchmark: Dense rotation O(d²) vs RHT O(d log d)."""

import time
import torch
from torbuquant.quantizers import TurboQuantMSE


def benchmark_rotation_types():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print()

    # Test configurations
    dims = [64, 128, 256, 512]  # Power of 2 for RHT compatibility
    batch_heads = 32
    seq_len = 2048
    bits = 3
    num_iters = 50

    print(f"{'dim':<8} {'Quantize Dense':<18} {'Quantize RHT':<18} {'Dequant Dense':<18} {'Dequant RHT':<18} {'RHT Speedup':<12}")
    print("-" * 100)

    for dim in dims:
        # Create quantizers
        q_dense = TurboQuantMSE(dim, bits, device=device, rotation_type="dense")
        q_rht = TurboQuantMSE(dim, bits, device=device, rotation_type="rht")

        # Test data
        x = torch.randn(batch_heads, seq_len, dim, device=device)

        # Warmup
        for _ in range(5):
            _ = q_dense.quantize(x)
            _ = q_rht.quantize(x)
            torch.cuda.synchronize() if device.type == "cuda" else None

        # Benchmark quantize - Dense
        torch.cuda.synchronize() if device.type == "cuda" else None
        start = time.perf_counter()
        for _ in range(num_iters):
            quantized_dense = q_dense.quantize(x)
            torch.cuda.synchronize() if device.type == "cuda" else None
        quant_dense_ms = (time.perf_counter() - start) / num_iters * 1000

        # Benchmark quantize - RHT
        torch.cuda.synchronize() if device.type == "cuda" else None
        start = time.perf_counter()
        for _ in range(num_iters):
            quantized_rht = q_rht.quantize(x)
            torch.cuda.synchronize() if device.type == "cuda" else None
        quant_rht_ms = (time.perf_counter() - start) / num_iters * 1000

        # Benchmark dequantize - Dense
        torch.cuda.synchronize() if device.type == "cuda" else None
        start = time.perf_counter()
        for _ in range(num_iters):
            _ = q_dense.dequantize(quantized_dense)
            torch.cuda.synchronize() if device.type == "cuda" else None
        dequant_dense_ms = (time.perf_counter() - start) / num_iters * 1000

        # Benchmark dequantize - RHT
        torch.cuda.synchronize() if device.type == "cuda" else None
        start = time.perf_counter()
        for _ in range(num_iters):
            _ = q_rht.dequantize(quantized_rht)
            torch.cuda.synchronize() if device.type == "cuda" else None
        dequant_rht_ms = (time.perf_counter() - start) / num_iters * 1000

        # Calculate speedup
        total_dense = quant_dense_ms + dequant_dense_ms
        total_rht = quant_rht_ms + dequant_rht_ms
        speedup = total_dense / total_rht if total_rht > 0 else 0

        print(f"{dim:<8} {quant_dense_ms:<18.3f} {quant_rht_ms:<18.3f} {dequant_dense_ms:<18.3f} {dequant_rht_ms:<18.3f} {speedup:<12.2f}x")

        # Verify correctness
        reconstructed_dense = q_dense.dequantize(quantized_dense)
        reconstructed_rht = q_rht.dequantize(quantized_rht)
        # Both should give similar reconstruction error (not identical due to different rotations)
        error_dense = (x - reconstructed_dense).abs().mean().item()
        error_rht = (x - reconstructed_rht).abs().mean().item()
        print(f"         Reconstruction error - Dense: {error_dense:.6f}, RHT: {error_rht:.6f}")
        print()


def benchmark_direct_score_with_rht():
    """Benchmark direct score computation with both rotation types."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("\n" + "=" * 70)
    print("Direct Score Computation: Dense vs RHT")
    print("=" * 70)

    dim = 128
    bits = 3
    batch_heads = 32
    seq_len = 4096
    num_iters = 50

    # Create quantizers
    q_dense = TurboQuantMSE(dim, bits, device=device, rotation_type="dense")
    q_rht = TurboQuantMSE(dim, bits, device=device, rotation_type="rht")

    # Test data
    keys = torch.randn(batch_heads, seq_len, dim, device=device)
    query = torch.randn(batch_heads, dim, device=device)

    # Quantize
    quantized_dense = q_dense.quantize(keys)
    quantized_rht = q_rht.quantize(keys)

    # Warmup
    for _ in range(5):
        q_rot_dense = q_dense.rotate_query(query)
        q_rot_rht = q_rht.rotate_query(query)
        _ = q_dense.direct_score(q_rot_dense.unsqueeze(1), quantized_dense)
        _ = q_rht.direct_score(q_rot_rht.unsqueeze(1), quantized_rht)
        torch.cuda.synchronize() if device.type == "cuda" else None

    # Benchmark dequant + matmul (baseline) - Dense
    torch.cuda.synchronize() if device.type == "cuda" else None
    start = time.perf_counter()
    for _ in range(num_iters):
        keys_full = q_dense.dequantize(quantized_dense)
        scores = torch.matmul(query.unsqueeze(1), keys_full.transpose(-2, -1)).squeeze(1)
        torch.cuda.synchronize() if device.type == "cuda" else None
    dequant_dense_ms = (time.perf_counter() - start) / num_iters * 1000

    # Benchmark dequant + matmul - RHT
    torch.cuda.synchronize() if device.type == "cuda" else None
    start = time.perf_counter()
    for _ in range(num_iters):
        keys_full = q_rht.dequantize(quantized_rht)
        scores = torch.matmul(query.unsqueeze(1), keys_full.transpose(-2, -1)).squeeze(1)
        torch.cuda.synchronize() if device.type == "cuda" else None
    dequant_rht_ms = (time.perf_counter() - start) / num_iters * 1000

    # Benchmark direct_score - Dense
    q_rot_dense = q_dense.rotate_query(query)
    torch.cuda.synchronize() if device.type == "cuda" else None
    start = time.perf_counter()
    for _ in range(num_iters):
        scores = q_dense.direct_score(q_rot_dense.unsqueeze(1), quantized_dense).squeeze(1)
        torch.cuda.synchronize() if device.type == "cuda" else None
    direct_dense_ms = (time.perf_counter() - start) / num_iters * 1000

    # Benchmark direct_score - RHT
    q_rot_rht = q_rht.rotate_query(query)
    torch.cuda.synchronize() if device.type == "cuda" else None
    start = time.perf_counter()
    for _ in range(num_iters):
        scores = q_rht.direct_score(q_rot_rht.unsqueeze(1), quantized_rht).squeeze(1)
        torch.cuda.synchronize() if device.type == "cuda" else None
    direct_rht_ms = (time.perf_counter() - start) / num_iters * 1000

    print(f"Config: dim={dim}, seq_len={seq_len}, batch_heads={batch_heads}")
    print()
    print(f"{'Method':<30} {'Dense (ms)':<15} {'RHT (ms)':<15} {'RHT Speedup':<12}")
    print("-" * 72)
    print(f"{'Dequant + matmul':<30} {dequant_dense_ms:<15.3f} {dequant_rht_ms:<15.3f} {dequant_dense_ms/dequant_rht_ms:<12.2f}x")
    print(f"{'Direct score':<30} {direct_dense_ms:<15.3f} {direct_rht_ms:<15.3f} {direct_dense_ms/direct_rht_ms:<12.2f}x")
    print()
    print("Overall:")
    print(f"  Dense: Dequant={dequant_dense_ms:.3f}ms, Direct={direct_dense_ms:.3f}ms, Direct speedup={dequant_dense_ms/direct_dense_ms:.2f}x")
    print(f"  RHT:   Dequant={dequant_rht_ms:.3f}ms, Direct={direct_rht_ms:.3f}ms, Direct speedup={dequant_rht_ms/direct_rht_ms:.2f}x")


if __name__ == "__main__":
    benchmark_rotation_types()
    benchmark_direct_score_with_rht()
