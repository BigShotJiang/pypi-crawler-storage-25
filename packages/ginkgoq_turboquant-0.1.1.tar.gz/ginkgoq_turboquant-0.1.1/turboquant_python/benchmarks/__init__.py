"""TorbuQuant benchmarks.

Run individual benchmarks:
    python -m benchmarks.benchmark_k4v4_fused
    python -m benchmarks.benchmark_fixed_memory_throughput

Or use pytest:
    pytest benchmarks/ -v
"""
