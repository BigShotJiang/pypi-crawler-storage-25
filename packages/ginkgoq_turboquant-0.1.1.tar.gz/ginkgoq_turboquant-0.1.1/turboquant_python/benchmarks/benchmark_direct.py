"""Direct comparison: dequantize+matmul vs Triton direct_score."""

import time
import torch
from torbuquant.quantizers import TurboQuantMSE, HAS_TRITON


def benchmark():
    device = torch.device("cuda")
    torch.cuda.synchronize()

    # Test multiple sequence lengths to find crossover point
    dim = 128
    bits = 3
    batch_heads = 32  # Simulate 4 batch * 8 heads
    num_iters = 50

    print(f"Config: dim={dim}, batch_heads={batch_heads}")
    print(f"{'seq_len':<10} {'Dequant+MM':<15} {'Direct PT':<15} {'Direct Tri':<15} {'PT speedup':<12} {'Tri speedup':<12}")
    print("-" * 85)

    for seq_len in [512, 1024, 2048, 4096, 8192, 16384]:
        quantizer = TurboQuantMSE(dim, bits, device=device, dtype=torch.float32)

        # Quantize some keys
        try:
            keys = torch.randn(batch_heads, seq_len, dim, device=device)
            quantized = quantizer.quantize(keys)
        except RuntimeError as e:
            print(f"{seq_len:<10} OOM")
            break

        # Query
        query = torch.randn(batch_heads, dim, device=device)

        # Warmup
        for _ in range(5):
            _ = quantizer.dequantize(quantized)
            torch.cuda.synchronize()

        # Method 1: Dequantize + matmul
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(num_iters):
            keys_full = quantizer.dequantize(quantized)
            scores = torch.matmul(query.unsqueeze(1), keys_full.transpose(-2, -1)).squeeze(1)
            torch.cuda.synchronize()
        time1 = (time.perf_counter() - start) / num_iters * 1000

        # Method 2: Direct score (PyTorch, no Triton)
        query_rotated = quantizer.rotate_query(query)
        torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(num_iters):
            scores2 = quantizer.direct_score(query_rotated.unsqueeze(1), quantized, scale=1.0).squeeze(1)
            torch.cuda.synchronize()
        time2 = (time.perf_counter() - start) / num_iters * 1000

        # Method 3: Triton kernel (if available)
        if HAS_TRITON:
            torch.cuda.synchronize()
            start = time.perf_counter()
            for _ in range(num_iters):
                scores3 = quantizer.direct_score_triton(query_rotated.unsqueeze(1), quantized, scale=1.0).squeeze(1)
                torch.cuda.synchronize()
            time3 = (time.perf_counter() - start) / num_iters * 1000
        else:
            time3 = float('nan')

        speedup_pt = time1 / time2 if time2 > 0 else 0
        speedup_tri = time1 / time3 if time3 > 0 else 0

        print(f"{seq_len:<10} {time1:<15.3f} {time2:<15.3f} {time3:<15.3f} {speedup_pt:<12.2f}x {speedup_tri:<12.2f}x")

        # Cleanup
        del keys, quantized, query, query_rotated
        torch.cuda.empty_cache()


if __name__ == "__main__":
    benchmark()
