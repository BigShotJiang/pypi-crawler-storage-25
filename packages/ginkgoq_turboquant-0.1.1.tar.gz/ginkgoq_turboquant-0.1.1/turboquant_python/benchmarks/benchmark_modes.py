"""Benchmark all three TurboQuant cache modes.

This script compares:
- MODE 1: cache_dequant=True (fast, no GPU savings)
- MODE 2: cache_dequant=False (slow, real GPU savings)
- MODE 3: compute_key_scores() (direct quantized-key scoring; may or may not be
  faster depending on sequence length/head dim/kernel overhead)
"""

import time
import torch
import gc

from torbuquant.llm.hf_cache import TurboQuantDynamicCache, HAS_TRITON


def benchmark_mode(
    mode_name: str,
    cache: TurboQuantDynamicCache,
    use_direct_scores: bool,
    seq_len: int = 512,
    num_iterations: int = 50,
):
    """Benchmark a single mode."""
    batch_size = 1
    num_heads = 8
    head_dim = 64
    num_layers = 1

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dtype = torch.float16 if device.type == "cuda" else torch.float32

    # Warm up - fill cache with initial sequence
    k = torch.randn(batch_size, num_heads, seq_len, head_dim, device=device, dtype=dtype)
    v = torch.randn(batch_size, num_heads, seq_len, head_dim, device=device, dtype=dtype)

    # Update cache (triggers quantization)
    keys_full, values_full = cache.update(k, v, layer_idx=0)

    if device.type == "cuda":
        torch.cuda.synchronize()

    # Benchmark: simulate autoregressive decoding
    times = []
    scale = 1.0 / (head_dim ** 0.5)

    for _ in range(num_iterations):
        # New query token
        q = torch.randn(batch_size, num_heads, 1, head_dim, device=device, dtype=dtype)

        if device.type == "cuda":
            torch.cuda.synchronize()

        start = time.perf_counter()

        if use_direct_scores:
            # MODE 3: Direct score computation (Triton-accelerated)
            scores = cache.compute_key_scores(q, layer_idx=0, scale=scale)
            # For fair comparison, also get values
            _, values = cache._layers[0]._get_full_cache(dtype=dtype)
        else:
            # MODE 1 or 2: Standard attention (get full K/V, then matmul)
            keys, values = cache._layers[0]._get_full_cache(dtype=dtype)
            scores = torch.matmul(q, keys.transpose(-2, -1)) * scale

        # Compute attention output (same for all modes)
        # Ensure consistent dtypes
        scores = scores.float()
        attn_weights = torch.softmax(scores, dim=-1).to(values.dtype)
        output = torch.matmul(attn_weights, values)

        if device.type == "cuda":
            torch.cuda.synchronize()

        times.append(time.perf_counter() - start)

    avg_time_ms = sum(times) / len(times) * 1000
    gpu_mb = cache.gpu_memory_bytes() / (1024 * 1024)
    dense_mb = cache.dense_memory_bytes() / (1024 * 1024)
    compression = cache.compression_ratio()

    return {
        "mode": mode_name,
        "avg_time_ms": avg_time_ms,
        "gpu_memory_mb": gpu_mb,
        "dense_equivalent_mb": dense_mb,
        "compression_ratio": compression,
        "has_triton": HAS_TRITON,
    }


def main():
    print("=" * 70)
    print("TurboQuant Cache Modes Benchmark")
    print("=" * 70)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print(f"Triton available: {HAS_TRITON}")
    print()

    head_dim = 64
    num_layers = 1

    # Test multiple sequence lengths to see scaling
    for seq_len in [512, 2048, 4096]:
        print(f"\n{'='*70}")
        print(f"SEQUENCE LENGTH: {seq_len}")
        print("="*70)

        results = []

        # MODE 1: Speed Priority (cache_dequant=True)
        print("Testing MODE 1: Speed Priority (cache_dequant=True)...")
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()

        cache1 = TurboQuantDynamicCache(
            num_hidden_layers=num_layers,
            head_dim=head_dim,
            key_bits=3,
            value_bits=3,
            recent_tokens=64,
            device=device,
            cache_dequant=True,
            offload_to_cpu=False,
        )
        results.append(benchmark_mode("MODE 1: Speed", cache1, use_direct_scores=False, seq_len=seq_len))
        del cache1

        # MODE 2: Memory Priority (cache_dequant=False) - same device for fair comparison
        print("Testing MODE 2: Memory Priority (cache_dequant=False)...")
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()

        cache2 = TurboQuantDynamicCache(
            num_hidden_layers=num_layers,
            head_dim=head_dim,
            key_bits=3,
            value_bits=3,
            recent_tokens=64,
            device=device,
            cache_dequant=False,
            offload_to_cpu=False,  # Keep on GPU for fair timing comparison
        )
        results.append(benchmark_mode("MODE 2: Memory", cache2, use_direct_scores=False, seq_len=seq_len))
        del cache2

        # MODE 3: Direct quantized-key scoring with Triton
        if HAS_TRITON:
            print("Testing MODE 3: Direct key scoring (compute_key_scores with Triton)...")
            gc.collect()
            if device.type == "cuda":
                torch.cuda.empty_cache()

            cache3 = TurboQuantDynamicCache(
                num_hidden_layers=num_layers,
                head_dim=head_dim,
                key_bits=3,
                value_bits=3,
                recent_tokens=64,
                device=device,
                cache_dequant=False,  # Don't cache dequantized (memory savings)
                offload_to_cpu=False,  # Keep quantized on GPU for Triton
            )
            results.append(benchmark_mode("MODE 3: Direct", cache3, use_direct_scores=True, seq_len=seq_len))
            del cache3
        else:
            print("Skipping MODE 3: Triton not available")

        # Print results
        print()
        print(f"{'Mode':<25} {'Time (ms)':<12} {'GPU (MB)':<12} {'Savings':<12}")
        print("-" * 70)

        baseline_time = results[0]["avg_time_ms"]
        baseline_gpu = results[0]["gpu_memory_mb"]

        for r in results:
            speedup = baseline_time / r["avg_time_ms"] if r["avg_time_ms"] > 0 else 0
            mem_savings = (1 - r["gpu_memory_mb"] / baseline_gpu) * 100 if baseline_gpu > 0 else 0
            print(f"{r['mode']:<25} {r['avg_time_ms']:<12.3f} {r['gpu_memory_mb']:<12.2f} {mem_savings:>6.1f}% GPU")

    print()
    print("\nSummary:")
    print("  MODE 1: Fast attention, but no GPU memory savings")
    print("  MODE 2: Real GPU savings, but slower (dequantize on every step)")
    if HAS_TRITON:
        print("  MODE 3: Direct quantized-key scoring; inspect measured time before claiming speed")


if __name__ == "__main__":
    main()
