"""Fixed-KV-memory throughput benchmark for TurboQuant.

Single-request latency is the wrong win condition for compressed KV. This
benchmark asks the production question:

    Given the same KV-memory budget and context length, how many concurrent
    decode streams can each backend serve, and what is aggregate tok/s?

It measures real CUDA latency for SDPA, K4V8, and K4V4 at the maximum batch
that fits in the requested KV budget.
"""

from __future__ import annotations

import argparse
import gc
import math
import time
from dataclasses import dataclass

import torch

from torbuquant.fused_attention import FusedTurboQuantAttention
from torbuquant.fused_attention import CompressedKV


@dataclass
class Result:
    backend: str
    context: int
    batch: int
    kv_mb: float
    latency_ms: float
    tok_s: float
    compression: float


def _bench(fn, *, warmup: int, iters: int) -> float:
    for _ in range(warmup):
        fn()
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(iters):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - start) * 1000.0 / iters


def _reset_cuda() -> None:
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()


def _dense_kv_bytes(batch: int, heads: int, context: int, dim: int, dtype: torch.dtype) -> int:
    element_size = torch.empty((), dtype=dtype).element_size()
    return batch * heads * context * dim * 2 * element_size


def _measure_compressed_bytes(
    *,
    batch: int,
    heads: int,
    context: int,
    dim: int,
    v_bits: int,
    device: torch.device,
    dtype: torch.dtype,
    batch_chunk: int = 8,
) -> tuple[int, FusedTurboQuantAttention, object, torch.Tensor]:
    attention = FusedTurboQuantAttention(dim, k_bits=4, v_bits=v_bits, device=device, dtype=torch.float32)

    chunks = []
    for start in range(0, batch, batch_chunk):
        chunk = min(batch_chunk, batch - start)
        keys = torch.randn(chunk, heads, context, dim, device=device, dtype=dtype)
        values = torch.randn(chunk, heads, context, dim, device=device, dtype=dtype)
        chunks.append(attention.quantize_kv(keys, values))
        del keys, values
        _reset_cuda()

    compressed = CompressedKV(
        k_indices=torch.cat([chunk.k_indices for chunk in chunks], dim=0),
        k_norms=torch.cat([chunk.k_norms for chunk in chunks], dim=0),
        k_bits=chunks[0].k_bits,
        k_dim=chunks[0].k_dim,
        v_quantized=torch.cat([chunk.v_quantized for chunk in chunks], dim=0),
        v_scales=torch.cat([chunk.v_scales for chunk in chunks], dim=0),
        v_zeros=torch.cat([chunk.v_zeros for chunk in chunks], dim=0),
        v_bits=chunks[0].v_bits,
        v_group_size=chunks[0].v_group_size,
        v_dim=chunks[0].v_dim,
        seq_len=context,
    )
    bytes_used = compressed.memory_bytes()["total"]
    query = torch.randn(batch, heads, 1, dim, device=device, dtype=dtype)
    return bytes_used, attention, compressed, query


def _compressed_unit_bytes(
    *,
    heads: int,
    context: int,
    dim: int,
    v_bits: int,
    device: torch.device,
    dtype: torch.dtype,
    batch_chunk: int,
) -> int:
    bytes_used, attention, compressed, query = _measure_compressed_bytes(
        batch=1,
        heads=heads,
        context=context,
        dim=dim,
        v_bits=v_bits,
        device=device,
        dtype=dtype,
        batch_chunk=batch_chunk,
    )
    del attention, compressed, query
    _reset_cuda()
    return bytes_used


def _max_batch_from_unit(unit_bytes: int, budget_bytes: int) -> int:
    return max(1, budget_bytes // max(1, unit_bytes))


def _run_sdpa(
    *,
    batch: int,
    heads: int,
    context: int,
    dim: int,
    device: torch.device,
    dtype: torch.dtype,
    warmup: int,
    iters: int,
) -> Result:
    _reset_cuda()
    query = torch.randn(batch, heads, 1, dim, device=device, dtype=dtype)
    keys = torch.randn(batch, heads, context, dim, device=device, dtype=dtype)
    values = torch.randn(batch, heads, context, dim, device=device, dtype=dtype)
    latency_ms = _bench(
        lambda: torch.nn.functional.scaled_dot_product_attention(query, keys, values, is_causal=False),
        warmup=warmup,
        iters=iters,
    )
    kv_bytes = _dense_kv_bytes(batch, heads, context, dim, dtype)
    result = Result("SDPA-FP16", context, batch, kv_bytes / 1024**2, latency_ms, batch / (latency_ms / 1000.0), 1.0)
    del query, keys, values
    _reset_cuda()
    return result


def _run_tq(
    *,
    backend: str,
    v_bits: int,
    batch: int,
    heads: int,
    context: int,
    dim: int,
    device: torch.device,
    dtype: torch.dtype,
    warmup: int,
    iters: int,
    batch_chunk: int,
) -> Result:
    _reset_cuda()
    compressed_bytes, attention, compressed, query = _measure_compressed_bytes(
        batch=batch,
        heads=heads,
        context=context,
        dim=dim,
        v_bits=v_bits,
        device=device,
        dtype=dtype,
        batch_chunk=batch_chunk,
    )
    scale = 1.0 / math.sqrt(dim)
    latency_ms = _bench(lambda: attention(query, compressed, scale=scale), warmup=warmup, iters=iters)
    dense_bytes = _dense_kv_bytes(batch, heads, context, dim, dtype)
    result = Result(
        backend,
        context,
        batch,
        compressed_bytes / 1024**2,
        latency_ms,
        batch / (latency_ms / 1000.0),
        dense_bytes / compressed_bytes,
    )
    del attention, compressed, query
    _reset_cuda()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contexts", type=int, nargs="+", default=[2048, 4096, 8192])
    parser.add_argument("--kv-budget-mb", type=float, default=512.0)
    parser.add_argument("--heads", type=int, default=32)
    parser.add_argument("--dim", type=int, default=128)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--iters", type=int, default=50)
    parser.add_argument("--max-batch", type=int, default=512)
    parser.add_argument("--quantize-batch-chunk", type=int, default=8)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")

    device = torch.device("cuda")
    dtype = torch.float16
    budget_bytes = int(args.kv_budget_mb * 1024**2)

    print(f"GPU: {torch.cuda.get_device_name(0)}")
    print(f"KV budget: {args.kv_budget_mb:.1f} MiB, H={args.heads}, D={args.dim}")
    print(
        f"{'ctx':>7} {'backend':>10} {'batch':>7} {'kv MiB':>10} "
        f"{'lat ms':>10} {'tok/s':>12} {'comp':>8}"
    )

    all_results: list[Result] = []
    for context in args.contexts:
        dense_unit = _dense_kv_bytes(1, args.heads, context, args.dim, dtype)
        sdpa_batch = min(args.max_batch, _max_batch_from_unit(dense_unit, budget_bytes))
        all_results.append(
            _run_sdpa(
                batch=sdpa_batch,
                heads=args.heads,
                context=context,
                dim=args.dim,
                device=device,
                dtype=dtype,
                warmup=args.warmup,
                iters=args.iters,
            )
        )

        for backend, v_bits in [("K4V8", 8), ("K4V4", 4)]:
            unit_bytes = _compressed_unit_bytes(
                heads=args.heads,
                context=context,
                dim=args.dim,
                v_bits=v_bits,
                device=device,
                dtype=dtype,
                batch_chunk=args.quantize_batch_chunk,
            )
            batch = min(args.max_batch, _max_batch_from_unit(unit_bytes, budget_bytes))
            all_results.append(
                _run_tq(
                    backend=backend,
                    v_bits=v_bits,
                    batch=batch,
                    heads=args.heads,
                    context=context,
                    dim=args.dim,
                    device=device,
                    dtype=dtype,
                    warmup=args.warmup,
                    iters=args.iters,
                    batch_chunk=args.quantize_batch_chunk,
                )
            )

        for result in all_results[-3:]:
            print(
                f"{result.context:7d} {result.backend:>10} {result.batch:7d} "
                f"{result.kv_mb:10.1f} {result.latency_ms:10.3f} "
                f"{result.tok_s:12.1f} {result.compression:8.2f}x"
            )

        baseline = all_results[-3]
        for result in all_results[-2:]:
            print(
                f"        throughput_vs_sdpa {result.backend}: "
                f"{result.tok_s / baseline.tok_s:.2f}x at same KV budget"
            )


if __name__ == "__main__":
    main()
