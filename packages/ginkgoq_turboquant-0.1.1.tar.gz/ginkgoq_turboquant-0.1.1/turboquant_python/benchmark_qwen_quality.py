"""Reference-vs-TurboQuant quality gate for Qwen decode.

This is a deterministic, real-model check. It compares dense KV against the
patched compressed KV path on the same prompt and teacher-forces the baseline
greedy token at every step so logits are compared on identical token histories.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache

from torbuquant.llm import TurboQuantQwenCache, install_qwen_turboquant_attention


def dtype_from_name(name: str) -> torch.dtype:
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    if name == "fp32":
        return torch.float32
    raise ValueError(f"unknown dtype: {name}")


def load_wikitext_prompt(tokenizer, *, target_tokens: int) -> str:
    from datasets import load_dataset

    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
    parts: list[str] = []
    for row in dataset:
        text = " ".join(row["text"].split())
        if len(text) < 80:
            continue
        parts.append(text)
        prompt = "\n".join(parts)
        ids = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=target_tokens).input_ids[0]
        if ids.numel() >= target_tokens:
            return tokenizer.decode(ids, skip_special_tokens=True)
    raise RuntimeError(f"could not build a Wikitext prompt with {target_tokens} tokens")


def distribution_metrics(reference_logits: torch.Tensor, test_logits: torch.Tensor) -> dict[str, float | int | bool]:
    ref = reference_logits.float()
    tst = test_logits.float()
    ref_logp = torch.log_softmax(ref, dim=-1)
    tst_logp = torch.log_softmax(tst, dim=-1)
    ref_p = torch.softmax(ref, dim=-1)
    kl = torch.sum(ref_p * (ref_logp - tst_logp), dim=-1)
    ref_argmax = torch.argmax(ref, dim=-1)
    tst_argmax = torch.argmax(tst, dim=-1)
    prob_delta = torch.abs(ref_p - torch.softmax(tst, dim=-1))
    return {
        "kl": float(kl.item()),
        "score_exp_neg_kl": float(100.0 * math.exp(-float(kl.item()))),
        "argmax_match": bool(torch.equal(ref_argmax, tst_argmax)),
        "reference_argmax": int(ref_argmax.item()),
        "test_argmax": int(tst_argmax.item()),
        "max_probability_delta": float(prob_delta.max().item()),
        "mean_probability_delta": float(prob_delta.mean().item()),
    }


@torch.inference_mode()
def run_quality_gate(model, tokenizer, prompt: str, args: argparse.Namespace) -> dict:
    device = torch.device(args.device)
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=args.context_tokens).to(device)
    head_dim = model.config.hidden_size // model.config.num_attention_heads
    num_key_value_heads = getattr(model.config, "num_key_value_heads", model.config.num_attention_heads)

    dense_cache = DynamicCache()
    tq_cache = TurboQuantQwenCache(
        num_hidden_layers=model.config.num_hidden_layers,
        head_dim=head_dim,
        num_attention_heads=model.config.num_attention_heads,
        num_key_value_heads=num_key_value_heads,
        key_bits=args.key_bits,
        value_bits=args.value_bits,
        boundary_value_bits=args.boundary_value_bits,
        boundary_layers=args.boundary_layers,
        recent_tokens=args.recent_tokens,
        sparse_v_threshold=args.sparse_v_threshold,
        require_fused_attention=not args.allow_dense_fallback,
        rotation_type="rht",
        device=device,
        dtype=torch.float32,
        seed=args.seed,
    )

    attention_mask = inputs.attention_mask
    current_ids = inputs.input_ids
    step_metrics = []
    generated_ids = []
    start = time.perf_counter()

    for step in range(args.steps):
        dense_out = model(
            input_ids=current_ids,
            attention_mask=attention_mask,
            past_key_values=dense_cache,
            use_cache=True,
        )
        tq_out = model(
            input_ids=current_ids,
            attention_mask=attention_mask,
            past_key_values=tq_cache,
            use_cache=True,
        )

        dense_logits = dense_out.logits[:, -1, :]
        tq_logits = tq_out.logits[:, -1, :]
        metrics = distribution_metrics(dense_logits, tq_logits)
        metrics["step"] = step
        step_metrics.append(metrics)

        next_token = torch.tensor([[metrics["reference_argmax"]]], device=device, dtype=torch.long)
        generated_ids.append(next_token)
        current_ids = next_token
        attention_mask = torch.cat([attention_mask, torch.ones_like(next_token)], dim=-1)

    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - start

    kl_values = [float(m["kl"]) for m in step_metrics]
    argmax_matches = [bool(m["argmax_match"]) for m in step_metrics]
    generated = torch.cat(generated_ids, dim=-1) if generated_ids else torch.empty(1, 0, dtype=torch.long)
    return {
        "model": args.model,
        "prompt_tokens": int(inputs.input_ids.shape[1]),
        "steps": args.steps,
        "dtype": str(next(model.parameters()).dtype),
        "turboquant": {
            "key_bits": args.key_bits,
            "value_bits": args.value_bits,
            "recent_tokens": args.recent_tokens,
            "boundary_value_bits": args.boundary_value_bits or 0,
            "boundary_layers": args.boundary_layers,
            "sparse_v_threshold": args.sparse_v_threshold,
            "compressed_kv_mib": tq_cache.compressed_memory_bytes() / 1024**2,
            "dense_kv_equivalent_mib": tq_cache.dense_memory_bytes() / 1024**2,
            "compression_ratio": tq_cache.compression_ratio(),
            "stats": tq_cache.stats(),
        },
        "quality": {
            "mean_kl": sum(kl_values) / len(kl_values) if kl_values else 0.0,
            "max_kl": max(kl_values) if kl_values else 0.0,
            "mean_score_exp_neg_kl": sum(100.0 * math.exp(-v) for v in kl_values) / len(kl_values)
            if kl_values
            else 100.0,
            "argmax_match_rate": sum(argmax_matches) / len(argmax_matches) if argmax_matches else 1.0,
            "all_argmax_match": all(argmax_matches),
        },
        "timing": {
            "wall_seconds": elapsed,
            "steps_per_second": args.steps / elapsed if elapsed > 0 else 0.0,
        },
        "teacher_forced_reference_text": tokenizer.decode(generated[0], skip_special_tokens=True),
        "steps_detail": step_metrics,
    }


def write_outputs(output_dir: Path, result: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "qwen_quality_result.json"
    md_path = output_dir / "QWEN_QUALITY_RESULT.md"
    json_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    md_path.write_text(
        "\n".join(
            [
                "# Qwen TurboQuant Quality Gate",
                "",
                f"- model: `{result['model']}`",
                f"- prompt tokens: `{result['prompt_tokens']}`",
                f"- steps: `{result['steps']}`",
                f"- K/V bits: `K{result['turboquant']['key_bits']}V{result['turboquant']['value_bits']}`",
                f"- boundary V: `{result['turboquant']['boundary_layers']}` layers at V`{result['turboquant']['boundary_value_bits']}`",
                "",
                "| Metric | Value |",
                "|--------|------:|",
                f"| mean KL | {result['quality']['mean_kl']:.8f} |",
                f"| max KL | {result['quality']['max_kl']:.8f} |",
                f"| mean exp(-KL) score | {result['quality']['mean_score_exp_neg_kl']:.4f} |",
                f"| argmax match rate | {100.0 * result['quality']['argmax_match_rate']:.2f}% |",
                f"| fused calls | {result['turboquant']['stats']['fused_attention_calls']} |",
                f"| fused single-pass calls | {result['turboquant']['stats']['fused_single_pass_calls']} |",
                f"| fused two-stage calls | {result['turboquant']['stats']['fused_two_stage_calls']} |",
                f"| dense fallback calls | {result['turboquant']['stats']['dense_fallback_calls']} |",
                f"| compressed KV MiB | {result['turboquant']['compressed_kv_mib']:.2f} |",
                f"| dense KV equivalent MiB | {result['turboquant']['dense_kv_equivalent_mib']:.2f} |",
                f"| compression ratio | {result['turboquant']['compression_ratio']:.4f}x |",
                "",
                "## Teacher-Forced Reference Text",
                "",
                "```text",
                result["teacher_forced_reference_text"],
                "```",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(f"wrote {json_path}")
    print(f"wrote {md_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--output-dir", default="runs/qwen_quality/turboquant")
    parser.add_argument("--prompt-file")
    parser.add_argument("--context-tokens", type=int, default=512)
    parser.add_argument("--steps", type=int, default=8)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--key-bits", type=int, default=16)
    parser.add_argument("--value-bits", type=int, default=4)
    parser.add_argument("--recent-tokens", type=int, default=128)
    parser.add_argument("--boundary-value-bits", type=int, choices=[2, 4, 8], default=8)
    parser.add_argument("--boundary-layers", type=int, default=2)
    parser.add_argument("--sparse-v-threshold", type=float, default=0.0)
    parser.add_argument("--allow-dense-fallback", action="store_true")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    dtype = dtype_from_name(args.dtype) if device.type == "cuda" else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    if args.prompt_file:
        prompt = Path(args.prompt_file).read_text(encoding="utf-8")
    else:
        prompt = load_wikitext_prompt(tokenizer, target_tokens=args.context_tokens)

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation="sdpa",
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()
    install_qwen_turboquant_attention(model)

    result = run_quality_gate(model, tokenizer, prompt, args)
    write_outputs(Path(args.output_dir), result)


if __name__ == "__main__":
    main()
