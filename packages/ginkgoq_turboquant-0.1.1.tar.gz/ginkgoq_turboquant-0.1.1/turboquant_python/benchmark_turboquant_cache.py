"""Benchmark Qwen generation with TurboQuant KV compression.

Default backend is the patched Qwen fused path, which consumes compressed KV
directly during decode. The old HF DynamicCache adapter remains available for
diagnosis with ``--backend hf-adapter``.
"""

from __future__ import annotations

import argparse
import json
import os
import resource
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from torbuquant.llm import (
    TurboQuantDynamicCache,
    TurboQuantQwenCache,
    install_qwen_turboquant_attention,
)
from torbuquant.policy import AutoPolicyInput, choose_auto_kv_policy, estimate_dense_kv_bytes


def gpu_memory_mib() -> dict[str, float]:
    if not torch.cuda.is_available():
        return {"allocated": 0.0, "reserved": 0.0, "max_allocated": 0.0, "max_reserved": 0.0}
    return {
        "allocated": torch.cuda.memory_allocated() / 1024**2,
        "reserved": torch.cuda.memory_reserved() / 1024**2,
        "max_allocated": torch.cuda.max_memory_allocated() / 1024**2,
        "max_reserved": torch.cuda.max_memory_reserved() / 1024**2,
    }


def cpu_rss_mib() -> float:
    # ru_maxrss is KiB on Linux.
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024


def reset_memory_stats() -> None:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()


def load_wikitext_prompt(tokenizer, *, target_tokens: int) -> str:
    from datasets import load_dataset

    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
    parts: list[str] = []
    for row in dataset:
        text = " ".join(row["text"].split())
        if len(text) < 80:
            continue
        parts.append(text)
        prompt = "\n".join(parts)
        ids = tokenizer(prompt, return_tensors="pt",
                        truncation=True, max_length=target_tokens).input_ids[0]
        if ids.numel() >= target_tokens:
            return tokenizer.decode(ids, skip_special_tokens=True)
    raise RuntimeError(
        f"could not build a Wikitext prompt with {target_tokens} tokens")


def load_prompt(tokenizer, args: argparse.Namespace) -> tuple[str, int, str]:
    if args.prompt_file:
        text = Path(args.prompt_file).read_text(encoding="utf-8")
        source = f"file:{args.prompt_file}"
    else:
        text = load_wikitext_prompt(
            tokenizer, target_tokens=args.context_tokens)
        source = "wikitext-2-raw-v1/validation"

    encoded = tokenizer(text, return_tensors="pt",
                        truncation=True, max_length=args.context_tokens)
    prompt = tokenizer.decode(encoded.input_ids[0], skip_special_tokens=True)
    return prompt, int(encoded.input_ids.shape[1]), source


def dtype_from_name(name: str) -> torch.dtype:
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    if name == "fp32":
        return torch.float32
    raise ValueError(f"unknown dtype: {name}")


def write_outputs(output_dir: Path, result: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "turboquant_cache_result.json"
    md_path = output_dir / "TURBOQUANT_CACHE_RESULT.md"
    json_path.write_text(json.dumps(
        result, indent=2, sort_keys=True), encoding="utf-8")

    md_path.write_text(
        "\n".join(
            [
                "# TurboQuant Cache Benchmark",
                "",
                f"- model: `{result['model']}`",
                f"- prompt source: `{result['prompt_source']}`",
                f"- prompt tokens: `{result['prompt_tokens']}`",
                f"- generated tokens: `{result['generated_tokens']}`",
                f"- key method: `{result['turboquant']['key_method']}`",
                f"- K/V bits: `K{result['turboquant']['key_bits']}V{result['turboquant']['value_bits']}`",
                f"- recent tokens: `{result['turboquant']['recent_tokens']}`",
                f"- sparse V threshold: `{result['turboquant']['sparse_v_threshold']}`",
                f"- boundary V: `{result['turboquant']['boundary_layers']}` layers at V`{result['turboquant']['boundary_value_bits']}`",
                "",
                "| Metric | Value |",
                "|--------|------:|",
                f"| wall seconds | {result['timing']['wall_seconds']:.4f} |",
                f"| tokens/sec | {result['timing']['tokens_per_second']:.4f} |",
                f"| GPU peak allocated MiB | {result['gpu_memory_mib_after']['max_allocated']:.2f} |",
                f"| GPU peak reserved MiB | {result['gpu_memory_mib_after']['max_reserved']:.2f} |",
                f"| CPU max RSS MiB | {result['cpu_max_rss_mib']:.2f} |",
                f"| compressed/stored KV MiB | {result['turboquant']['compressed_kv_mib']:.2f} |",
                f"| dense KV equivalent MiB | {result['turboquant']['dense_kv_equivalent_mib']:.2f} |",
                f"| dense KV / peak allocated | {100.0 * result['diagnosis']['dense_kv_fraction_of_peak']:.2f}% |",
                f"| storage compression | {result['turboquant']['compression_ratio']:.4f}x |",
                "",
                "## Diagnosis",
                "",
                f"Backend: `{result['turboquant']['backend']}`",
                result["diagnosis"]["summary"],
                "",
                f"- adapter returns dense K/V: `{result['diagnosis']['adapter_returns_dense_kv']}`",
                f"- fused compressed attention used: `{result['diagnosis']['fused_compressed_attention_used']}`",
                f"- fused attention calls: `{result['diagnosis']['fused_attention_calls']}`",
                f"- fused single-pass calls: `{result['diagnosis']['fused_single_pass_calls']}`",
                f"- fused two-stage calls: `{result['diagnosis']['fused_two_stage_calls']}`",
                f"- dense fallback calls: `{result['diagnosis']['dense_fallback_calls']}`",
                f"- expected speedup from this benchmark: `{result['diagnosis']['expected_speedup']}`",
                "",
                "## Generated Text",
                "",
                "```text",
                result["generated_text"],
                "```",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(f"wrote {json_path}")
    print(f"wrote {md_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument(
        "--output-dir", default="runs/cache_benchmarks/turboquant")
    parser.add_argument("--prompt-file")
    parser.add_argument("--context-tokens", type=int, default=4096)
    parser.add_argument("--max-new-tokens", type=int, default=32)
    parser.add_argument(
        "--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--key-bits", type=int, default=4)
    parser.add_argument("--value-bits", type=int, default=8)
    parser.add_argument("--key-method", choices=["mse", "prod"], default="mse")
    parser.add_argument("--recent-tokens", type=int, default=128)
    parser.add_argument("--sparse-v-threshold", type=float, default=0.0)
    parser.add_argument("--boundary-value-bits", type=int, choices=[4, 8])
    parser.add_argument("--boundary-layers", type=int, default=0)
    parser.add_argument(
        "--allow-dense-fallback",
        action="store_true",
        help="Diagnostic only: allow patched Qwen path to fall back to dense/dequantized attention.",
    )
    parser.add_argument("--cache-dequant", action="store_true")
    parser.add_argument(
        "--backend",
        choices=["qwen-fused", "hf-adapter"],
        default="qwen-fused",
        help="qwen-fused consumes compressed KV directly; hf-adapter is the old compatibility path.",
    )
    parser.add_argument("--auto", action="store_true", help="Choose SDPA or TurboQuant once before inference.")
    parser.add_argument("--kv-budget-mb", type=float, help="KV budget for auto mode.")
    parser.add_argument("--prefer-low-latency", action="store_true", help="Auto mode should prefer SDPA when dense KV fits.")
    parser.add_argument("--policy-batch-size", type=int, default=1, help="Expected batch/concurrency for auto mode.")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    dtype = dtype_from_name(
        args.dtype) if device.type == "cuda" else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(
        args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    prompt, prompt_tokens, prompt_source = load_prompt(tokenizer, args)

    attn_impl = "eager" if args.backend == "hf-adapter" else "sdpa"
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation=attn_impl,
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()

    head_dim = model.config.hidden_size // model.config.num_attention_heads
    num_key_value_heads = getattr(model.config, "num_key_value_heads", model.config.num_attention_heads)
    effective_backend = args.backend
    policy = None
    if args.auto:
        budget = int(args.kv_budget_mb * 1024**2) if args.kv_budget_mb is not None else None
        policy = choose_auto_kv_policy(
            AutoPolicyInput(
                batch_size=args.policy_batch_size,
                num_layers=model.config.num_hidden_layers,
                num_kv_heads=num_key_value_heads,
                num_attention_heads=model.config.num_attention_heads,
                head_dim=head_dim,
                context_tokens=prompt_tokens + args.max_new_tokens,
                dtype_bytes=2 if dtype in (torch.float16, torch.bfloat16) else 4,
                available_kv_memory_bytes=budget,
                model_name=args.model,
                prefer_quality=True,
                prefer_low_latency=args.prefer_low_latency or args.policy_batch_size <= 1,
                allow_quantization=True,
            )
        )
        if policy.backend == "sdpa_fp16":
            effective_backend = "sdpa"
        else:
            effective_backend = "qwen-fused"
            args.key_bits = policy.k_bits
            args.value_bits = policy.v_bits
            args.recent_tokens = policy.recent_window
            args.sparse_v_threshold = policy.sparse_v_threshold
            args.boundary_value_bits = policy.boundary_value_bits
            args.boundary_layers = policy.boundary_layers

    patched_layers = 0
    if effective_backend == "qwen-fused":
        patched_layers = install_qwen_turboquant_attention(model)
        cache = TurboQuantQwenCache(
            num_hidden_layers=model.config.num_hidden_layers,
            head_dim=head_dim,
            num_attention_heads=model.config.num_attention_heads,
            num_key_value_heads=num_key_value_heads,
            key_bits=args.key_bits,
            value_bits=args.value_bits,
            boundary_value_bits=args.boundary_value_bits,
            boundary_layers=args.boundary_layers,
            recent_tokens=args.recent_tokens,
            sparse_v_threshold=args.sparse_v_threshold,
            require_fused_attention=not args.allow_dense_fallback,
            rotation_type="rht",
            device=device,
            dtype=torch.float32,
            seed=args.seed,
        )
    elif effective_backend == "hf-adapter":
        cache = TurboQuantDynamicCache(
            num_hidden_layers=model.config.num_hidden_layers,
            head_dim=head_dim,
            key_bits=args.key_bits,
            value_bits=args.value_bits,
            key_method=args.key_method,
            recent_tokens=args.recent_tokens,
            device=device,
            dtype=torch.float32,
            seed=args.seed,
            cache_dequant=args.cache_dequant,
        )
    elif effective_backend == "sdpa":
        cache = None
    else:
        raise ValueError(f"unknown backend: {effective_backend}")

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True,
                       max_length=args.context_tokens).to(device)
    reset_memory_stats()
    mem_before = gpu_memory_mib()
    start = time.perf_counter()
    with torch.inference_mode():
        generate_kwargs = dict(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            use_cache=True,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
        )
        if cache is not None:
            generate_kwargs["past_key_values"] = cache
        outputs = model.generate(**generate_kwargs)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    wall_seconds = time.perf_counter() - start
    mem_after = gpu_memory_mib()

    generated_tokens = int(outputs.shape[1] - inputs.input_ids.shape[1])
    generated_text = tokenizer.decode(
        outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
    if cache is not None:
        compressed_kv_mib = cache.compressed_memory_bytes() / 1024**2
        dense_kv_mib = cache.dense_memory_bytes() / 1024**2
        gpu_kv_mib = cache.gpu_memory_bytes() / 1024**2
        compression_ratio = cache.compression_ratio()
        cache_stats = cache.stats() if hasattr(cache, "stats") else {}
    else:
        total_cache_tokens = int(inputs.input_ids.shape[1] + generated_tokens)
        dense_bytes = estimate_dense_kv_bytes(
            batch_size=1,
            num_layers=model.config.num_hidden_layers,
            num_kv_heads=num_key_value_heads,
            head_dim=head_dim,
            context_tokens=total_cache_tokens,
            dtype_bytes=2 if dtype in (torch.float16, torch.bfloat16) else 4,
        )
        compressed_kv_mib = dense_bytes / 1024**2
        dense_kv_mib = dense_bytes / 1024**2
        gpu_kv_mib = dense_bytes / 1024**2
        compression_ratio = 1.0
        cache_stats = {}
    peak_allocated_mib = mem_after["max_allocated"]

    result = {
        "benchmark": "turboquant_cache",
        "model": args.model,
        "device": str(device),
        "dtype": str(dtype),
        "prompt_source": prompt_source,
        "prompt_tokens": prompt_tokens,
        "generated_tokens": generated_tokens,
        "timing": {
            "wall_seconds": wall_seconds,
            "tokens_per_second": generated_tokens / wall_seconds if wall_seconds > 0 else 0.0,
        },
        "gpu_memory_mib_before": mem_before,
        "gpu_memory_mib_after": mem_after,
        "cpu_max_rss_mib": cpu_rss_mib(),
        "turboquant": {
            "key_bits": 16 if effective_backend == "sdpa" else args.key_bits,
            "value_bits": 16 if effective_backend == "sdpa" else args.value_bits,
            "backend": effective_backend,
            "requested_backend": args.backend,
            "auto_policy": policy.reason if policy is not None else None,
            "patched_qwen_layers": patched_layers,
            "key_method": args.key_method,
            "recent_tokens": 0 if effective_backend == "sdpa" else args.recent_tokens,
            "sparse_v_threshold": 0.0 if effective_backend == "sdpa" else args.sparse_v_threshold,
            "boundary_value_bits": 0 if effective_backend == "sdpa" else (args.boundary_value_bits or 0),
            "boundary_layers": 0 if effective_backend == "sdpa" else args.boundary_layers,
            "cache_dequant": args.cache_dequant,
            "cache_stats": cache_stats,
            "compressed_kv_mib": compressed_kv_mib,
            "dense_kv_equivalent_mib": dense_kv_mib,
            "gpu_kv_mib": gpu_kv_mib,
            "compression_ratio": compression_ratio,
        },
        "diagnosis": {
            "adapter_returns_dense_kv": effective_backend == "hf-adapter",
            "fused_compressed_attention_used": effective_backend == "qwen-fused",
            "fused_attention_calls": int(cache_stats.get("fused_attention_calls", 0)),
            "fused_single_pass_calls": int(cache_stats.get("fused_single_pass_calls", 0)),
            "fused_two_stage_calls": int(cache_stats.get("fused_two_stage_calls", 0)),
            "dense_fallback_calls": int(cache_stats.get("dense_fallback_calls", 0)),
            "expected_speedup": "lowest_latency" if effective_backend == "sdpa" else ("possible_under_memory_pressure" if effective_backend == "qwen-fused" else "no"),
            "summary": (
                "Patched Qwen attention consumes TurboQuant-compressed KV directly during decode. "
                "Prefill remains exact SDPA and then compresses the resulting K/V."
                if effective_backend == "qwen-fused"
                else "Auto policy selected dense SDPA because it is the correct low-latency path for this workload."
                if effective_backend == "sdpa"
                else "HF DynamicCache adapter stores compressed history but returns dequantized dense K/V "
                "for compatibility, so it should not be used as the production speed path."
            ),
            "dense_kv_fraction_of_peak": dense_kv_mib / peak_allocated_mib if peak_allocated_mib else 0.0,
        },
        "generated_text": generated_text,
    }
    write_outputs(Path(args.output_dir), result)


if __name__ == "__main__":
    main()
