"""Run Qwen2.5-3B with a TurboQuant-compressed KV cache.

Example:
    python examples/qwen25_turboquant_generate.py \
      --model Qwen/Qwen2.5-3B \
      --prompt "Explain TurboQuant in one paragraph." \
      --max-new-tokens 32 \
      --compare-baseline
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from torbuquant import AutoPolicyInput, choose_auto_kv_policy
from torbuquant.llm import TurboQuantDynamicCache


def _select_next(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    logits = logits[:, -1, :]
    if temperature <= 0:
        return torch.argmax(logits, dim=-1, keepdim=True)
    probs = torch.softmax(logits / temperature, dim=-1)
    return torch.multinomial(probs, num_samples=1)


@torch.inference_mode()
def generate_with_cache(
    model,
    tokenizer,
    prompt: str,
    cache,
    *,
    max_new_tokens: int,
    temperature: float,
) -> tuple[str, float]:
    device = next(model.parameters()).device
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    input_ids = inputs.input_ids
    attention_mask = inputs.attention_mask

    start = time.perf_counter()
    outputs = model(
        input_ids=input_ids,
        attention_mask=attention_mask,
        past_key_values=cache,
        use_cache=True,
    )
    next_token = _select_next(outputs.logits, temperature)
    generated = [next_token]

    for _ in range(max_new_tokens - 1):
        attention_mask = torch.cat([attention_mask, torch.ones_like(next_token)], dim=-1)
        outputs = model(
            input_ids=next_token,
            attention_mask=attention_mask,
            past_key_values=cache,
            use_cache=True,
        )
        next_token = _select_next(outputs.logits, temperature)
        generated.append(next_token)
        if tokenizer.eos_token_id is not None and int(next_token.item()) == tokenizer.eos_token_id:
            break

    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - start
    new_ids = torch.cat(generated, dim=-1)
    return tokenizer.decode(new_ids[0], skip_special_tokens=True), elapsed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--prompt", default="Explain TurboQuant in one concise paragraph.")
    parser.add_argument("--max-new-tokens", type=int, default=32)
    parser.add_argument("--key-bits", type=int, default=3)
    parser.add_argument("--value-bits", type=int, default=3)
    parser.add_argument("--key-method", choices=["mse", "prod"], default="mse")
    parser.add_argument("--recent-tokens", type=int, default=128)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--compare-baseline", action="store_true")
    parser.add_argument("--keep-sliding-window", action="store_true")
    parser.add_argument("--auto", action="store_true", help="Choose SDPA/K4V8/K4V4 once from estimated KV pressure.")
    parser.add_argument("--batch-size", type=int, default=1, help="Expected serving batch/concurrency for auto mode.")
    parser.add_argument(
        "--expected-context-tokens",
        type=int,
        help="Expected total context for auto mode; defaults to prompt tokens + max new tokens.",
    )
    parser.add_argument("--kv-budget-mb", type=float, help="KV-cache memory budget for auto mode.")
    parser.add_argument("--prefer-low-latency", action="store_true", help="Auto mode favors dense SDPA when memory allows.")
    args = parser.parse_args()

    device = torch.device(args.device)
    dtype = torch.bfloat16 if device.type == "cuda" else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation="eager",
        trust_remote_code=True,
    )
    if not args.keep_sliding_window and hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()

    config = model.config
    head_dim = config.hidden_size // config.num_attention_heads
    prompt_tokens = tokenizer(args.prompt, return_tensors="pt").input_ids.shape[1]
    expected_context = args.expected_context_tokens or (prompt_tokens + args.max_new_tokens)
    kv_heads = getattr(config, "num_key_value_heads", config.num_attention_heads)

    use_turboquant = True
    if args.auto:
        budget = int(args.kv_budget_mb * 1024**2) if args.kv_budget_mb is not None else None
        policy = choose_auto_kv_policy(
            AutoPolicyInput(
                batch_size=args.batch_size,
                num_layers=config.num_hidden_layers,
                num_kv_heads=kv_heads,
                head_dim=head_dim,
                context_tokens=expected_context,
                dtype_bytes=torch.empty((), dtype=dtype).element_size(),
                available_kv_memory_bytes=budget,
                prefer_low_latency=args.prefer_low_latency,
            )
        )
        print("=== Auto KV Policy ===")
        print(policy)
        use_turboquant = policy.backend == "turboquant"
        if use_turboquant:
            args.key_bits = policy.k_bits
            args.value_bits = policy.v_bits
            args.recent_tokens = policy.recent_window

    if not use_turboquant:
        baseline_cache = DynamicCache(num_hidden_layers=config.num_hidden_layers)
        base_text, base_seconds = generate_with_cache(
            model,
            tokenizer,
            args.prompt,
            baseline_cache,
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
        )
        print("=== Auto Selected Dense SDPA KV ===")
        print(base_text)
        print(f"seconds={base_seconds:.3f}")
        return

    tq_cache = TurboQuantDynamicCache(
        num_hidden_layers=config.num_hidden_layers,
        head_dim=head_dim,
        key_bits=args.key_bits,
        value_bits=args.value_bits,
        key_method=args.key_method,
        recent_tokens=args.recent_tokens,
        device=device,
        dtype=torch.float32,
        seed=0,
    )
    tq_text, tq_seconds = generate_with_cache(
        model,
        tokenizer,
        args.prompt,
        tq_cache,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
    )

    print("=== TurboQuant KV ===")
    print(tq_text)
    print(f"seconds={tq_seconds:.3f}")
    print(f"compressed_kv_mb={tq_cache.compressed_memory_bytes() / 1024**2:.2f}")
    print(f"dense_kv_equivalent_mb={tq_cache.dense_memory_bytes() / 1024**2:.2f}")
    print(f"estimated_storage_compression={tq_cache.compression_ratio():.2f}x")

    if args.compare_baseline:
        baseline_cache = DynamicCache(num_hidden_layers=config.num_hidden_layers)
        base_text, base_seconds = generate_with_cache(
            model,
            tokenizer,
            args.prompt,
            baseline_cache,
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
        )
        print("\n=== Baseline KV ===")
        print(base_text)
        print(f"seconds={base_seconds:.3f}")


if __name__ == "__main__":
    main()
