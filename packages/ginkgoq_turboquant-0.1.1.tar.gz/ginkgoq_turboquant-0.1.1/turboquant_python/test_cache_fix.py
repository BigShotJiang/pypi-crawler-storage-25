"""Test that TurboQuantDynamicCache works with transformers."""

import torch
from torbuquant.llm import TurboQuantDynamicCache

def test_cache_initialization():
    """Test cache can be created without errors."""
    cache = TurboQuantDynamicCache(
        num_hidden_layers=36,
        head_dim=128,
        key_bits=4,
        value_bits=8,
        key_method="mse",
        recent_tokens=128,
        device="cpu",
    )

    # Check required attributes from DynamicCache parent
    assert hasattr(cache, '_seen_tokens')
    assert hasattr(cache, 'key_cache')
    assert hasattr(cache, 'value_cache')
    assert cache._seen_tokens == 0
    print("✓ Cache initialization works")


def test_cache_update():
    """Test cache update mechanism."""
    cache = TurboQuantDynamicCache(
        num_hidden_layers=2,
        head_dim=64,
        key_bits=4,
        value_bits=8,
        device="cpu",
    )

    # Simulate forward pass
    keys = torch.randn(1, 4, 10, 64)  # (B, H, N, D)
    values = torch.randn(1, 4, 10, 64)

    # Layer 0
    k_out, v_out = cache.update(keys, values, layer_idx=0)
    assert cache._seen_tokens == 10
    assert k_out.shape == keys.shape

    # Layer 1 (same tokens)
    k_out, v_out = cache.update(keys, values, layer_idx=1)
    assert cache._seen_tokens == 10  # Only updated on layer 0

    # More tokens on layer 0
    keys2 = torch.randn(1, 4, 5, 64)
    values2 = torch.randn(1, 4, 5, 64)
    k_out, v_out = cache.update(keys2, values2, layer_idx=0)
    assert cache._seen_tokens == 15

    print("✓ Cache update works")


if __name__ == "__main__":
    test_cache_initialization()
    test_cache_update()
    print("\n✓ All tests passed!")
