"""Test full cache workflow including simulated generation."""

import torch
from torbuquant.llm import TurboQuantDynamicCache


def test_full_workflow():
    """Test complete cache workflow as used during generation."""

    # Create cache
    cache = TurboQuantDynamicCache(
        num_hidden_layers=4,
        head_dim=64,
        key_bits=4,
        value_bits=8,
        key_method="mse",
        recent_tokens=32,
        device="cpu",
    )

    print("Initial state:")
    print(f"  _seen_tokens: {cache._seen_tokens}")
    print(f"  key_cache: {cache.key_cache}")
    print(f"  value_cache: {cache.value_cache}")
    print()

    # Simulate prefill phase (all 4 layers, 20 tokens)
    print("Prefill phase (20 tokens):")
    prefill_keys = torch.randn(1, 8, 20, 64)  # (B, H, N, D)
    prefill_values = torch.randn(1, 8, 20, 64)

    for layer_idx in range(4):
        k_out, v_out = cache.update(prefill_keys, prefill_values, layer_idx)
        print(f"  Layer {layer_idx}: seq_len={cache.get_seq_length(layer_idx)}")

    print(f"  _seen_tokens after prefill: {cache._seen_tokens}")
    print(f"  key_cache length: {len(cache.key_cache)}")
    print()

    # Simulate decode phase (1 token at a time)
    print("Decode phase:")
    for step in range(3):
        decode_keys = torch.randn(1, 8, 1, 64)
        decode_values = torch.randn(1, 8, 1, 64)

        for layer_idx in range(4):
            k_out, v_out = cache.update(decode_keys, decode_values, layer_idx)

        print(f"  Step {step+1}: _seen_tokens={cache._seen_tokens}, layer_0_seq={cache.get_seq_length(0)}")

    print()
    print(f"Final state:")
    print(f"  Total tokens: {cache._seen_tokens}")
    print(f"  Layers filled: {len([l for l in cache._layers if l is not None])}")
    print(f"  key_cache entries: {len(cache.key_cache)}")
    print(f"  Compression ratio: {cache.compression_ratio():.2f}x")
    print()
    print("✓ Full workflow test passed")


if __name__ == "__main__":
    test_full_workflow()
