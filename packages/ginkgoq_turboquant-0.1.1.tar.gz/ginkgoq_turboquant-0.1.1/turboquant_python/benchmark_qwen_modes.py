"""Compare dense Qwen KV against fused TurboQuant KV modes in one process."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, DynamicCache

from torbuquant.llm import TurboQuantQwenCache, install_qwen_turboquant_attention
from torbuquant.policy import estimate_dense_kv_bytes


def dtype_from_name(name: str) -> torch.dtype:
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    if name == "fp32":
        return torch.float32
    raise ValueError(f"unknown dtype: {name}")


def load_wikitext_prompt(tokenizer, *, target_tokens: int) -> str:
    from datasets import load_dataset

    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
    parts: list[str] = []
    for row in dataset:
        text = " ".join(row["text"].split())
        if len(text) < 80:
            continue
        parts.append(text)
        prompt = "\n".join(parts)
        ids = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=target_tokens).input_ids[0]
        if ids.numel() >= target_tokens:
            return tokenizer.decode(ids, skip_special_tokens=True)
    raise RuntimeError(f"could not build prompt with {target_tokens} tokens")


def gpu_memory_mib() -> dict[str, float]:
    if not torch.cuda.is_available():
        return {"allocated": 0.0, "reserved": 0.0, "max_allocated": 0.0, "max_reserved": 0.0}
    return {
        "allocated": torch.cuda.memory_allocated() / 1024**2,
        "reserved": torch.cuda.memory_reserved() / 1024**2,
        "max_allocated": torch.cuda.max_memory_allocated() / 1024**2,
        "max_reserved": torch.cuda.max_memory_reserved() / 1024**2,
    }


def reset_memory_stats() -> None:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()


def make_tq_cache(model, *, mode: str, device: torch.device, seed: int, recent_tokens: int) -> TurboQuantQwenCache:
    head_dim = model.config.hidden_size // model.config.num_attention_heads
    num_key_value_heads = getattr(model.config, "num_key_value_heads", model.config.num_attention_heads)
    if mode == "k16v4":
        key_bits, value_bits = 16, 4
    elif mode == "k16v2":
        key_bits, value_bits = 16, 2
    elif mode == "k8v4":
        key_bits, value_bits = 8, 4
    elif mode == "k8v2":
        key_bits, value_bits = 8, 2
    elif mode == "k8v8":
        key_bits, value_bits = 8, 8
    elif mode == "k4v4":
        key_bits, value_bits = 4, 4
    elif mode == "k4v2":
        key_bits, value_bits = 4, 2
    elif mode == "k4v8":
        key_bits, value_bits = 4, 8
    elif mode == "k2v2":
        key_bits, value_bits = 2, 2
    elif mode == "k2v4":
        key_bits, value_bits = 2, 4
    else:
        raise ValueError(f"unknown TurboQuant mode: {mode}")
    return TurboQuantQwenCache(
        num_hidden_layers=model.config.num_hidden_layers,
        head_dim=head_dim,
        num_attention_heads=model.config.num_attention_heads,
        num_key_value_heads=num_key_value_heads,
        key_bits=key_bits,
        value_bits=value_bits,
        boundary_value_bits=8 if value_bits < 8 else None,
        boundary_layers=2 if value_bits < 8 else 0,
        recent_tokens=recent_tokens,
        require_fused_attention=True,
        rotation_type="rht",
        device=device,
        dtype=torch.float32,
        seed=seed,
    )


def _select_greedy(logits: torch.Tensor) -> torch.Tensor:
    return torch.argmax(logits[:, -1, :], dim=-1, keepdim=True)


@torch.inference_mode()
def run_prefill_decode(
    model,
    tokenizer,
    inputs,
    *,
    cache,
    max_new_tokens: int,
) -> tuple[torch.Tensor, dict[str, float]]:
    device = inputs.input_ids.device
    attention_mask = inputs.attention_mask

    prefill_start = time.perf_counter()
    outputs = model(
        input_ids=inputs.input_ids,
        attention_mask=attention_mask,
        past_key_values=cache,
        use_cache=True,
    )
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    prefill_seconds = time.perf_counter() - prefill_start

    next_token = _select_greedy(outputs.logits)
    generated = [next_token]

    decode_start = time.perf_counter()
    for _ in range(max_new_tokens - 1):
        attention_mask = torch.cat([attention_mask, torch.ones_like(next_token)], dim=-1)
        outputs = model(
            input_ids=next_token,
            attention_mask=attention_mask,
            past_key_values=cache,
            use_cache=True,
        )
        next_token = _select_greedy(outputs.logits)
        generated.append(next_token)
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    decode_seconds = time.perf_counter() - decode_start

    generated_ids = torch.cat(generated, dim=-1)
    return generated_ids, {
        "prefill_seconds": prefill_seconds,
        "decode_seconds": decode_seconds,
        "total_seconds": prefill_seconds + decode_seconds,
    }


def run_mode(model, tokenizer, inputs, args, *, mode: str, device: torch.device) -> dict:
    if mode == "dense":
        cache = DynamicCache()
    else:
        cache = make_tq_cache(model, mode=mode, device=device, seed=args.seed, recent_tokens=args.recent_tokens)

    # Warmup compiles kernels and exercises model code outside measured timing.
    if args.warmup_tokens > 0:
        warm_cache = DynamicCache() if mode == "dense" else make_tq_cache(
            model, mode=mode, device=device, seed=args.seed, recent_tokens=args.recent_tokens
        )
        run_prefill_decode(model, tokenizer, inputs, cache=warm_cache, max_new_tokens=args.warmup_tokens)

    reset_memory_stats()
    generated_ids, timing = run_prefill_decode(
        model,
        tokenizer,
        inputs,
        cache=cache,
        max_new_tokens=args.max_new_tokens,
    )
    generated_tokens = int(generated_ids.shape[1])

    head_dim = model.config.hidden_size // model.config.num_attention_heads
    num_key_value_heads = getattr(model.config, "num_key_value_heads", model.config.num_attention_heads)
    dense_bytes = estimate_dense_kv_bytes(
        batch_size=inputs.input_ids.shape[0],
        num_layers=model.config.num_hidden_layers,
        num_kv_heads=num_key_value_heads,
        head_dim=head_dim,
        context_tokens=int(inputs.input_ids.shape[1] + generated_tokens),
        dtype_bytes=2,
    )
    if mode == "dense":
        compressed_mib = dense_bytes / 1024**2
        dense_mib = dense_bytes / 1024**2
        compression = 1.0
        stats = {}
    else:
        compressed_mib = cache.compressed_memory_bytes() / 1024**2
        dense_mib = cache.dense_memory_bytes() / 1024**2
        compression = cache.compression_ratio()
        stats = cache.stats()

    return {
        "mode": mode,
        "wall_seconds": timing["total_seconds"],
        "prefill_seconds": timing["prefill_seconds"],
        "decode_seconds": timing["decode_seconds"],
        "decode_tokens_per_second": (generated_tokens - 1) / timing["decode_seconds"]
        if generated_tokens > 1 and timing["decode_seconds"] > 0
        else 0.0,
        "end_to_end_tokens_per_second": generated_tokens / timing["total_seconds"] if timing["total_seconds"] > 0 else 0.0,
        "generated_tokens": generated_tokens,
        "gpu_memory_mib": gpu_memory_mib(),
        "compressed_kv_mib": compressed_mib,
        "dense_kv_equivalent_mib": dense_mib,
        "compression_ratio": compression,
        "stats": stats,
        "generated_text": tokenizer.decode(generated_ids[0], skip_special_tokens=True),
    }


def write_outputs(output_dir: Path, result: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "qwen_modes_result.json"
    md_path = output_dir / "QWEN_MODES_RESULT.md"
    json_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")

    lines = [
        "# Qwen KV Mode Benchmark",
        "",
        f"- model: `{result['model']}`",
        f"- prompt tokens: `{result['prompt_tokens']}`",
        f"- max new tokens: `{result['max_new_tokens']}`",
        f"- warmup tokens: `{result['warmup_tokens']}`",
        "",
        "| Mode | decode tok/s | e2e tok/s | prefill s | decode s | peak MiB | KV MiB | KV compression | fused attn | fused V | fallback |",
        "|------|-------------:|----------:|----------:|---------:|---------:|-------:|---------------:|-----------:|--------:|---------:|",
    ]
    for item in result["results"]:
        stats = item["stats"]
        lines.append(
            f"| {item['mode']} | "
            f"{item['decode_tokens_per_second']:.4f} | "
            f"{item['end_to_end_tokens_per_second']:.4f} | "
            f"{item['prefill_seconds']:.4f} | "
            f"{item['decode_seconds']:.4f} | "
            f"{item['gpu_memory_mib']['max_allocated']:.2f} | "
            f"{item['compressed_kv_mib']:.2f} | "
            f"{item['compression_ratio']:.4f}x | "
            f"{stats.get('fused_attention_calls', 0)} | "
            f"{stats.get('fused_weighted_v_calls', 0)} | "
            f"{stats.get('dense_fallback_calls', 0)} |"
        )
    lines.extend(["", "## Generated Text", ""])
    for item in result["results"]:
        lines.extend([f"### {item['mode']}", "", "```text", item["generated_text"], "```", ""])
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"wrote {json_path}")
    print(f"wrote {md_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument("--output-dir", default="runs/qwen_modes")
    parser.add_argument("--context-tokens", type=int, default=512)
    parser.add_argument("--max-new-tokens", type=int, default=16)
    parser.add_argument("--warmup-tokens", type=int, default=1)
    parser.add_argument("--recent-tokens", type=int, default=128)
    parser.add_argument("--modes", nargs="+", default=["dense", "k16v4", "k8v4"])
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    dtype = dtype_from_name(args.dtype) if device.type == "cuda" else torch.float32
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    prompt = load_wikitext_prompt(tokenizer, target_tokens=args.context_tokens)
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=args.context_tokens).to(device)

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation="sdpa",
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()
    install_qwen_turboquant_attention(model)

    results = [run_mode(model, tokenizer, inputs, args, mode=mode, device=device) for mode in args.modes]
    write_outputs(
        Path(args.output_dir),
        {
            "model": args.model,
            "prompt_tokens": int(inputs.input_ids.shape[1]),
            "max_new_tokens": args.max_new_tokens,
            "warmup_tokens": args.warmup_tokens,
            "results": results,
        },
    )


if __name__ == "__main__":
    main()
