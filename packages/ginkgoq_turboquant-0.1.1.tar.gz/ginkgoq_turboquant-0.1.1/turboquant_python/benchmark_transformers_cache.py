"""Benchmark Qwen generation with the standard Transformers KV cache.

This script is intentionally standalone. It only benchmarks the regular
Transformers cache path and writes resource/result files under --output-dir.
"""

from __future__ import annotations

import argparse
import json
import resource
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def gpu_memory_mib() -> dict[str, float]:
    if not torch.cuda.is_available():
        return {"allocated": 0.0, "reserved": 0.0, "max_allocated": 0.0, "max_reserved": 0.0}
    return {
        "allocated": torch.cuda.memory_allocated() / 1024**2,
        "reserved": torch.cuda.memory_reserved() / 1024**2,
        "max_allocated": torch.cuda.max_memory_allocated() / 1024**2,
        "max_reserved": torch.cuda.max_memory_reserved() / 1024**2,
    }


def cpu_rss_mib() -> float:
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024


def reset_memory_stats() -> None:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()


def load_wikitext_prompt(tokenizer, *, target_tokens: int) -> str:
    from datasets import load_dataset

    dataset = load_dataset("wikitext", "wikitext-2-raw-v1", split="validation")
    parts: list[str] = []
    for row in dataset:
        text = " ".join(row["text"].split())
        if len(text) < 80:
            continue
        parts.append(text)
        prompt = "\n".join(parts)
        ids = tokenizer(prompt, return_tensors="pt",
                        truncation=True, max_length=target_tokens).input_ids[0]
        if ids.numel() >= target_tokens:
            return tokenizer.decode(ids, skip_special_tokens=True)
    raise RuntimeError(
        f"could not build a Wikitext prompt with {target_tokens} tokens")


def load_prompt(tokenizer, args: argparse.Namespace) -> tuple[str, int, str]:
    if args.prompt_file:
        text = Path(args.prompt_file).read_text(encoding="utf-8")
        source = f"file:{args.prompt_file}"
    else:
        text = load_wikitext_prompt(
            tokenizer, target_tokens=args.context_tokens)
        source = "wikitext-2-raw-v1/validation"

    encoded = tokenizer(text, return_tensors="pt",
                        truncation=True, max_length=args.context_tokens)
    prompt = tokenizer.decode(encoded.input_ids[0], skip_special_tokens=True)
    return prompt, int(encoded.input_ids.shape[1]), source


def dtype_from_name(name: str) -> torch.dtype:
    if name == "bf16":
        return torch.bfloat16
    if name == "fp16":
        return torch.float16
    if name == "fp32":
        return torch.float32
    raise ValueError(f"unknown dtype: {name}")


def estimate_dense_kv_mib(model, *, batch_size: int, tokens: int, dtype: torch.dtype) -> float:
    kv_heads = getattr(model.config, "num_key_value_heads",
                       model.config.num_attention_heads)
    head_dim = model.config.hidden_size // model.config.num_attention_heads
    element_size = torch.empty((), dtype=dtype).element_size()
    bytes_used = batch_size * model.config.num_hidden_layers * \
        kv_heads * tokens * head_dim * 2 * element_size
    return bytes_used / 1024**2


def write_outputs(output_dir: Path, result: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "transformers_cache_result.json"
    md_path = output_dir / "TRANSFORMERS_CACHE_RESULT.md"
    json_path.write_text(json.dumps(
        result, indent=2, sort_keys=True), encoding="utf-8")

    md_path.write_text(
        "\n".join(
            [
                "# Transformers Cache Benchmark",
                "",
                f"- model: `{result['model']}`",
                f"- prompt source: `{result['prompt_source']}`",
                f"- prompt tokens: `{result['prompt_tokens']}`",
                f"- generated tokens: `{result['generated_tokens']}`",
                "",
                "| Metric | Value |",
                "|--------|------:|",
                f"| wall seconds | {result['timing']['wall_seconds']:.4f} |",
                f"| tokens/sec | {result['timing']['tokens_per_second']:.4f} |",
                f"| GPU peak allocated MiB | {result['gpu_memory_mib_after']['max_allocated']:.2f} |",
                f"| GPU peak reserved MiB | {result['gpu_memory_mib_after']['max_reserved']:.2f} |",
                f"| CPU max RSS MiB | {result['cpu_max_rss_mib']:.2f} |",
                f"| estimated dense KV MiB | {result['transformers']['estimated_dense_kv_mib']:.2f} |",
                "",
                "## Generated Text",
                "",
                "```text",
                result["generated_text"],
                "```",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(f"wrote {json_path}")
    print(f"wrote {md_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B")
    parser.add_argument(
        "--output-dir", default="runs/cache_benchmarks/transformers")
    parser.add_argument("--prompt-file")
    parser.add_argument("--context-tokens", type=int, default=4096)
    parser.add_argument("--max-new-tokens", type=int, default=32)
    parser.add_argument(
        "--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument(
        "--dtype", choices=["bf16", "fp16", "fp32"], default="bf16")
    parser.add_argument("--attn-implementation", default="eager")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    dtype = dtype_from_name(
        args.dtype) if device.type == "cuda" else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(
        args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    prompt, prompt_tokens, prompt_source = load_prompt(tokenizer, args)

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=dtype,
        device_map={"": str(device)},
        attn_implementation=args.attn_implementation,
        trust_remote_code=True,
    )
    if hasattr(model.config, "use_sliding_window"):
        model.config.use_sliding_window = False
    model.eval()

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True,
                       max_length=args.context_tokens).to(device)
    reset_memory_stats()
    mem_before = gpu_memory_mib()
    start = time.perf_counter()
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            use_cache=True,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
        )
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    wall_seconds = time.perf_counter() - start
    mem_after = gpu_memory_mib()

    generated_tokens = int(outputs.shape[1] - inputs.input_ids.shape[1])
    generated_text = tokenizer.decode(
        outputs[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
    total_cache_tokens = int(inputs.input_ids.shape[1] + generated_tokens)

    result = {
        "benchmark": "transformers_cache",
        "model": args.model,
        "device": str(device),
        "dtype": str(dtype),
        "attn_implementation": args.attn_implementation,
        "prompt_source": prompt_source,
        "prompt_tokens": prompt_tokens,
        "generated_tokens": generated_tokens,
        "timing": {
            "wall_seconds": wall_seconds,
            "tokens_per_second": generated_tokens / wall_seconds if wall_seconds > 0 else 0.0,
        },
        "gpu_memory_mib_before": mem_before,
        "gpu_memory_mib_after": mem_after,
        "cpu_max_rss_mib": cpu_rss_mib(),
        "transformers": {
            "cache": "DynamicCache/default",
            "estimated_dense_kv_mib": estimate_dense_kv_mib(
                model,
                batch_size=int(inputs.input_ids.shape[0]),
                tokens=total_cache_tokens,
                dtype=dtype,
            ),
        },
        "generated_text": generated_text,
    }
    write_outputs(Path(args.output_dir), result)


if __name__ == "__main__":
    main()
