import pytest
import torch

from torbuquant.llm.qwen_fused import TurboQuantQwenCache


def test_qwen_cache_boundary_v_selects_boundary_and_middle_bits():
    cache = TurboQuantQwenCache(
        num_hidden_layers=4,
        head_dim=32,
        num_attention_heads=4,
        num_key_value_heads=1,
        key_bits=8,
        value_bits=4,
        boundary_value_bits=8,
        boundary_layers=1,
        recent_tokens=0,
        require_fused_attention=False,
        device="cpu",
        dtype=torch.float32,
    )

    assert [cache._value_bits_for_layer(i) for i in range(4)] == [8, 4, 4, 8]


def test_qwen_cache_accepts_dense_key_compressed_value_mode():
    cache = TurboQuantQwenCache(
        num_hidden_layers=1,
        head_dim=32,
        num_attention_heads=4,
        num_key_value_heads=1,
        key_bits=16,
        value_bits=4,
        recent_tokens=0,
        require_fused_attention=False,
        device="cpu",
        dtype=torch.float32,
    )

    keys = torch.randn(1, 1, 4, 32)
    values = torch.randn(1, 1, 4, 32)
    cache.append(keys, values, 0)
    layer = cache.layers[0]
    assert layer.compressed.k_bits == 16
    assert layer.compressed.k_indices.shape == keys.shape
    assert layer.compressed.v_bits == 4
    assert layer.compressed.v_quantized.shape[-1] == values.shape[-1] // 2


def test_qwen_cache_accepts_dense_key_v2_mode():
    cache = TurboQuantQwenCache(
        num_hidden_layers=1,
        head_dim=32,
        num_attention_heads=4,
        num_key_value_heads=1,
        key_bits=16,
        value_bits=2,
        recent_tokens=0,
        require_fused_attention=False,
        device="cpu",
        dtype=torch.float32,
    )

    keys = torch.randn(1, 1, 4, 32)
    values = torch.randn(1, 1, 4, 32)
    cache.append(keys, values, 0)
    layer = cache.layers[0]
    assert layer.compressed.k_bits == 16
    assert layer.compressed.v_bits == 2
    assert layer.compressed.v_quantized.shape[-1] == values.shape[-1] // 4


def test_qwen_cache_accepts_aggressive_k2v2_mode():
    cache = TurboQuantQwenCache(
        num_hidden_layers=1,
        head_dim=32,
        num_attention_heads=4,
        num_key_value_heads=1,
        key_bits=2,
        value_bits=2,
        recent_tokens=0,
        require_fused_attention=False,
        device="cpu",
        dtype=torch.float32,
    )

    keys = torch.randn(1, 1, 4, 32)
    values = torch.randn(1, 1, 4, 32)
    cache.append(keys, values, 0)
    layer = cache.layers[0]
    assert layer.compressed.k_bits == 2
    assert layer.compressed.v_bits == 2
    assert layer.compressed.v_quantized.shape[-1] == values.shape[-1] // 4


def test_qwen_cache_rejects_sparse_v_until_global_softmax_skip_exists():
    with pytest.raises(ValueError, match="sparse_v_threshold"):
        TurboQuantQwenCache(
            num_hidden_layers=1,
            head_dim=32,
            num_attention_heads=4,
            num_key_value_heads=1,
            key_bits=8,
            value_bits=4,
            sparse_v_threshold=1e-6,
            device="cpu",
            dtype=torch.float32,
        )
