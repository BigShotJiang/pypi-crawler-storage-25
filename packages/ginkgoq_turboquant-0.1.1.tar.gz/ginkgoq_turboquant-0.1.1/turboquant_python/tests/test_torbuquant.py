import math

import pytest
import torch

from torbuquant.codebook import compute_lloyd_max_codebook
from torbuquant.packing import pack_unsigned, unpack_unsigned
from torbuquant.quantizers import TurboQuantMSE, TurboQuantProd
from torbuquant.rotation import generate_rotation_matrix


def _device() -> torch.device:
    return torch.device(f"cuda:{torch.cuda.current_device()}" if torch.cuda.is_available() else "cpu")


def test_bit_packing_roundtrip_all_supported_widths():
    generator = torch.Generator()
    generator.manual_seed(1)
    for bits in range(1, 9):
        values = torch.randint(0, 1 << bits, (4, 31), generator=generator)
        packed = pack_unsigned(values, bits)
        unpacked = unpack_unsigned(packed, bits, values.shape[-1])
        assert torch.equal(unpacked.cpu(), values)


def test_rotation_is_orthogonal_on_target_device():
    device = _device()
    rotation = generate_rotation_matrix(16, device=device, seed=3)
    eye = torch.eye(16, device=device)
    assert torch.allclose(rotation.T @ rotation, eye, atol=2e-5, rtol=2e-5)


def test_lloyd_max_matches_paper_small_bit_mse():
    codebook = compute_lloyd_max_codebook(128, 1)
    assert codebook.total_mse == pytest.approx(0.36, abs=0.01)
    assert codebook.centroids[0] == pytest.approx(-math.sqrt(2.0 / (math.pi * 128)), abs=0.002)
    assert codebook.centroids[1] == pytest.approx(math.sqrt(2.0 / (math.pi * 128)), abs=0.002)


def test_mse_quantizer_reconstructs_on_same_device():
    device = _device()
    generator = torch.Generator(device=device)
    generator.manual_seed(5)
    x = torch.randn(32, 32, device=device, generator=generator)
    quantizer = TurboQuantMSE(32, 3, device=device, seed=11)
    quantized = quantizer.quantize(x)
    x_hat = quantizer.dequantize(quantized)

    assert quantized.indices.device == device
    assert x_hat.device == device
    assert x_hat.shape == x.shape
    assert torch.isfinite(x_hat).all()
    assert torch.mean(torch.sum((x - x_hat) ** 2, dim=-1)) < torch.mean(torch.sum(x**2, dim=-1))


def test_product_inner_product_api_matches_dequantized_scores():
    device = _device()
    generator = torch.Generator(device=device)
    generator.manual_seed(9)
    x = torch.randn(17, 32, device=device, generator=generator)
    query = torch.randn(5, 32, device=device, generator=generator)
    quantizer = TurboQuantProd(32, 3, device=device, seed=13)

    quantized = quantizer.quantize(x)
    scores = quantizer.inner_product(query, quantized)
    dequantized_scores = query @ quantizer.dequantize(quantized).T

    assert scores.device == device
    assert scores.shape == (5, 17)
    assert torch.allclose(scores, dequantized_scores, atol=2e-4, rtol=2e-4)
