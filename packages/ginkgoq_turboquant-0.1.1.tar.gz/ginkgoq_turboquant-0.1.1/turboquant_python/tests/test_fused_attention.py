import math

import pytest
import torch

from torbuquant.fused_attention import (
    FusedTurboQuantAttention,
    dequantize_values_uniform,
    HAS_TRITON,
)
from torbuquant.quantizers import MSEQuantized


pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")


def test_k4v4_fused_matches_direct_reference():
    if not HAS_TRITON:
        pytest.skip("Triton is not available")

    device = torch.device("cuda")
    generator = torch.Generator(device=device)
    generator.manual_seed(123)

    batch, heads, seq_len, dim = 1, 2, 64, 128
    query = torch.randn(batch, heads, 1, dim, device=device, dtype=torch.float16, generator=generator)
    keys = torch.randn(batch, heads, seq_len, dim, device=device, dtype=torch.float16, generator=generator)
    values = torch.randn(batch, heads, seq_len, dim, device=device, dtype=torch.float16, generator=generator)
    scale = 1.0 / math.sqrt(dim)

    attention = FusedTurboQuantAttention(dim, k_bits=4, v_bits=4, device=device, dtype=torch.float32)
    compressed = attention.quantize_kv(keys, values)
    fused = attention(query, compressed, scale=scale).float()

    q_rot = attention.k_quantizer.rotate_query(query.squeeze(2).reshape(-1, dim)).reshape(batch, heads, dim)
    k_quantized = MSEQuantized(
        indices=compressed.k_indices,
        norms=compressed.k_norms,
        bits=compressed.k_bits,
        dim=compressed.k_dim,
    )
    scores = attention.k_quantizer.direct_score(q_rot.unsqueeze(2), k_quantized, scale=scale).squeeze(2)
    weights = torch.softmax(scores, dim=-1)
    values_dequant = dequantize_values_uniform(
        compressed.v_quantized,
        compressed.v_scales,
        compressed.v_zeros,
        compressed.v_group_size,
        bits=4,
        original_D=dim,
    ).to(weights.dtype)
    reference = torch.einsum("bhn,bhnd->bhd", weights, values_dequant).unsqueeze(2).float()

    assert torch.max(torch.abs(fused - reference)).item() < 1e-3
    assert torch.mean(torch.abs(fused - reference)).item() < 1e-4


def test_k4v4_uses_packed_v_storage():
    device = torch.device("cuda")
    values = torch.randn(1, 2, 16, 128, device=device, dtype=torch.float16)
    keys = torch.randn_like(values)

    attention = FusedTurboQuantAttention(128, k_bits=4, v_bits=4, device=device, dtype=torch.float32)
    compressed = attention.quantize_kv(keys, values)

    assert compressed.v_quantized.dtype == torch.uint8
    assert compressed.v_quantized.shape[-1] == values.shape[-1] // 2
