from torbuquant import AutoPolicyInput, choose_auto_kv_policy, estimate_dense_kv_bytes


def test_auto_policy_prefers_dense_when_low_latency_and_memory_fits():
    dense = estimate_dense_kv_bytes(
        batch_size=1,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=1024,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=1,
            num_layers=36,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=1024,
            available_kv_memory_bytes=dense * 2,
            prefer_low_latency=True,
        )
    )
    assert policy.backend == "sdpa_fp16"
    assert policy.estimated_compression == 1.0


def test_auto_policy_selects_k4v8_for_throughput_under_pressure():
    dense = estimate_dense_kv_bytes(
        batch_size=8,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=8192,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=8,
            num_layers=36,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            available_kv_memory_bytes=int(dense / 1.6),
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "turboquant"
    assert (policy.k_bits, policy.v_bits) == (4, 8)


def test_auto_policy_selects_k4v4_when_k4v8_does_not_fit():
    dense = estimate_dense_kv_bytes(
        batch_size=16,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=8192,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=16,
            num_layers=36,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            available_kv_memory_bytes=int(dense / 3.0),
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "turboquant"
    assert (policy.k_bits, policy.v_bits) == (4, 4)


def test_auto_policy_selects_asymmetric_mode_for_qwen_gqa():
    dense = estimate_dense_kv_bytes(
        batch_size=4,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=8192,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=4,
            num_layers=36,
            num_attention_heads=16,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            available_kv_memory_bytes=int(dense / 1.6),
            model_name="Qwen/Qwen2.5-3B",
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "turboquant"
    assert (policy.k_bits, policy.v_bits) == (8, 4)
    assert policy.sparse_v_threshold == 0.0
    assert policy.require_fused_attention is True
    assert policy.boundary_value_bits == 8
    assert policy.boundary_layers == 2


def test_auto_policy_selects_k16v4_for_qwen_when_budget_allows():
    dense = estimate_dense_kv_bytes(
        batch_size=4,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=8192,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=4,
            num_layers=36,
            num_attention_heads=16,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            available_kv_memory_bytes=int(dense / 1.2),
            model_name="Qwen/Qwen2.5-3B",
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "turboquant"
    assert (policy.k_bits, policy.v_bits) == (16, 4)
    assert policy.boundary_value_bits == 8


def test_auto_policy_uses_dense_without_memory_budget_even_for_batch():
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=8,
            num_layers=36,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "sdpa_fp16"
    assert policy.estimated_compression == 1.0


def test_auto_policy_uses_dense_when_budget_fits():
    dense = estimate_dense_kv_bytes(
        batch_size=8,
        num_layers=36,
        num_kv_heads=2,
        head_dim=128,
        context_tokens=8192,
    )
    policy = choose_auto_kv_policy(
        AutoPolicyInput(
            batch_size=8,
            num_layers=36,
            num_kv_heads=2,
            head_dim=128,
            context_tokens=8192,
            available_kv_memory_bytes=dense * 2,
            prefer_low_latency=False,
        )
    )
    assert policy.backend == "sdpa_fp16"
