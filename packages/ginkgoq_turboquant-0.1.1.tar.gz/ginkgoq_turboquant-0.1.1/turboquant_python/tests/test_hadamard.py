"""Debug Hadamard transform implementation."""

import torch
from torbuquant.rotation import hadamard_transform, RHTRotation


def test_hadamard():
    print("Testing Hadamard Transform")
    print("=" * 50)

    # Test: H @ H = d * I (before normalization)
    # After normalization: (H/sqrt(d)) @ (H/sqrt(d)) = I
    d = 8
    x = torch.eye(d)  # Identity to extract columns of H

    # Apply H to each column
    Hx = hadamard_transform(x)  # This is H / sqrt(d)
    print(f"H (normalized):\n{Hx}")

    # H_norm @ H_norm should be I
    HH = Hx @ Hx.T
    print(f"\nH_norm @ H_norm.T (should be I):\n{HH}")

    # Test round-trip
    y = torch.randn(d)
    y_transformed = hadamard_transform(y)
    y_back = hadamard_transform(y_transformed)  # H^-1 = H for normalized Hadamard
    print(f"\nRound-trip test:")
    print(f"  Original: {y}")
    print(f"  After H: {y_transformed}")
    print(f"  After H again: {y_back}")
    print(f"  Max error: {(y - y_back).abs().max().item():.6f}")


def test_rht():
    print("\n\nTesting RHT Rotation")
    print("=" * 50)

    d = 8
    device = torch.device("cpu")

    rht = RHTRotation(d, device, seed=42)

    # Test round-trip
    x = torch.randn(d)
    x_forward = rht.forward(x)
    x_back = rht.backward(x_forward)

    print(f"Original x: {x}")
    print(f"After forward: {x_forward}")
    print(f"After backward: {x_back}")
    print(f"Max error (should be ~0): {(x - x_back).abs().max().item():.6f}")

    # Test orthogonality: ||Rx|| = ||x||
    norm_x = x.norm().item()
    norm_forward = x_forward.norm().item()
    print(f"\nNorm preservation (should be equal):")
    print(f"  ||x|| = {norm_x:.6f}")
    print(f"  ||Rx|| = {norm_forward:.6f}")
    print(f"  Ratio: {norm_forward/norm_x:.6f}")

    # Test with batch
    print("\nBatch test:")
    batch = torch.randn(4, d)
    batch_forward = rht.forward(batch)
    batch_back = rht.backward(batch_forward)
    print(f"Batch error: {(batch - batch_back).abs().max().item():.6f}")


def test_quantizer_roundtrip():
    """Test quantizer with RHT."""
    print("\n\nTesting Quantizer with RHT")
    print("=" * 50)

    from torbuquant.quantizers import TurboQuantMSE

    d = 64
    bits = 3
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    q_dense = TurboQuantMSE(d, bits, device=device, rotation_type="dense", seed=0)
    q_rht = TurboQuantMSE(d, bits, device=device, rotation_type="rht", seed=0)

    x = torch.randn(10, d, device=device)

    # Test rotation round-trip directly
    print("Testing rotation round-trip:")
    x_rot_dense = q_dense._rotate_forward(x)
    x_back_dense = q_dense._rotate_backward(x_rot_dense)
    print(f"  Dense rotation error: {(x - x_back_dense).abs().max().item():.6f}")

    x_rot_rht = q_rht._rotate_forward(x)
    x_back_rht = q_rht._rotate_backward(x_rot_rht)
    print(f"  RHT rotation error: {(x - x_back_rht).abs().max().item():.6f}")

    # Test full quantize-dequantize
    print("\nTesting quantize-dequantize:")
    x_quant_dense = q_dense.quantize(x)
    x_recon_dense = q_dense.dequantize(x_quant_dense)
    error_dense = (x - x_recon_dense).abs().mean().item()
    print(f"  Dense reconstruction error: {error_dense:.6f}")

    x_quant_rht = q_rht.quantize(x)
    x_recon_rht = q_rht.dequantize(x_quant_rht)
    error_rht = (x - x_recon_rht).abs().mean().item()
    print(f"  RHT reconstruction error: {error_rht:.6f}")


if __name__ == "__main__":
    test_hadamard()
    test_rht()
    test_quantizer_roundtrip()
