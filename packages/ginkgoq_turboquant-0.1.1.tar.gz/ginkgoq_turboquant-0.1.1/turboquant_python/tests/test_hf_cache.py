import torch

from torbuquant.llm import TurboQuantDynamicCache


def _device() -> torch.device:
    return torch.device(f"cuda:{torch.cuda.current_device()}" if torch.cuda.is_available() else "cpu")


def test_dynamic_cache_supports_paper_faithful_prod_keys():
    device = _device()
    generator = torch.Generator(device=device)
    generator.manual_seed(123)

    cache = TurboQuantDynamicCache(
        num_hidden_layers=1,
        head_dim=32,
        key_bits=3,
        value_bits=3,
        recent_tokens=16,
        device=device,
        dtype=torch.float32,
        key_method="prod",
        cache_dequant=False,
    )

    keys = torch.randn(1, 2, 96, 32, device=device, generator=generator)
    values = torch.randn(1, 2, 96, 32, device=device, generator=generator)
    key_full, value_full = cache.update(keys, values, layer_idx=0)

    assert key_full.shape == keys.shape
    assert value_full.shape == values.shape
    assert key_full.device == device
    assert value_full.device == device
    assert cache.get_seq_length(0) == 96
    assert cache.compressed_memory_bytes() > 0
    assert cache.dense_memory_bytes() > 0
    assert cache.compression_ratio() > 1.0
