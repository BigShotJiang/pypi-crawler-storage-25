"""Run TurboQuant on real embedding datasets.

Default dataset follows the DBpedia/OpenAI3 embedding dataset cited in the
paper.  The script intentionally keeps the sample small by default so it is a
validation entry point, not a full paper-scale benchmark runner.
"""

from __future__ import annotations

import argparse
from collections.abc import Iterable

import torch

from .metrics import pairwise_inner_products, recall_at_k, reconstruction_mse
from .quantizers import TurboQuantMSE, TurboQuantProd


DEFAULT_DATASET = "Qdrant/dbpedia-entities-openai3-text-embedding-3-large-1536-1M"


def _find_embedding_column(row: dict) -> str:
    for key, value in row.items():
        if isinstance(value, list) and value and isinstance(value[0], (float, int)):
            return key
    raise ValueError("could not find a numeric embedding column in the dataset row")


def _load_embeddings(dataset_name: str, count: int, split: str) -> torch.Tensor:
    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise RuntimeError("install the optional dependency with `pip install -e .[real-data]`") from exc

    dataset = load_dataset(dataset_name, split=split, streaming=True)
    iterator: Iterable[dict] = iter(dataset)
    first = next(iterator)
    column = _find_embedding_column(first)
    vectors = [torch.tensor(first[column], dtype=torch.float32)]

    for row in iterator:
        vectors.append(torch.tensor(row[column], dtype=torch.float32))
        if len(vectors) >= count:
            break
    if len(vectors) < count:
        raise ValueError(f"dataset yielded only {len(vectors)} vectors, requested {count}")
    return torch.stack(vectors, dim=0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default=DEFAULT_DATASET)
    parser.add_argument("--split", default="train")
    parser.add_argument("--database-size", type=int, default=2048)
    parser.add_argument("--queries", type=int, default=128)
    parser.add_argument("--bits", type=int, default=3)
    parser.add_argument("--top-k", type=int, default=10)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    needed = args.database_size + args.queries
    data = _load_embeddings(args.dataset, needed, args.split)
    data = torch.nn.functional.normalize(data, dim=-1)
    database = data[: args.database_size].to(args.device)
    queries = data[args.database_size :].to(args.device)
    dim = database.shape[-1]

    mse_quantizer = TurboQuantMSE(dim, args.bits, device=args.device, seed=17)
    database_hat = mse_quantizer.dequantize(mse_quantizer.quantize(database))
    mse = reconstruction_mse(database, database_hat).item()

    prod_quantizer = TurboQuantProd(dim, args.bits, device=args.device, seed=17)
    prod_codes = prod_quantizer.quantize(database)
    exact_scores = pairwise_inner_products(queries, database)
    approx_scores = prod_quantizer.inner_product(queries, prod_codes)
    recall = recall_at_k(exact_scores, approx_scores, args.top_k)
    rmse = torch.sqrt(torch.mean((approx_scores - exact_scores) ** 2)).item()

    print(f"dataset={args.dataset}")
    print(f"device={args.device}")
    print(f"dim={dim} database={args.database_size} queries={args.queries} bits={args.bits}")
    print(f"mse_quantizer_mse={mse:.6f}")
    print(f"prod_inner_product_rmse={rmse:.6f}")
    print(f"recall_1_at_{args.top_k}={recall:.4f}")


if __name__ == "__main__":
    main()
