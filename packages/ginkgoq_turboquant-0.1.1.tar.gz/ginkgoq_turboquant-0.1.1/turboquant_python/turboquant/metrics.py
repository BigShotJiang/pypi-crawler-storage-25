"""Validation metrics for TurboQuant experiments."""

from __future__ import annotations

import torch


def reconstruction_mse(x: torch.Tensor, x_hat: torch.Tensor) -> torch.Tensor:
    """Mean squared L2 reconstruction error per vector."""

    return torch.mean(torch.sum((x - x_hat) ** 2, dim=-1))


def pairwise_inner_products(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Pairwise inner products for tensors shaped ``(n, d)`` and ``(m, d)``."""

    return x @ y.T


def recall_at_k(exact_scores: torch.Tensor, approx_scores: torch.Tensor, k: int) -> float:
    """1@k recall: true top-1 appears in approximate top-k."""

    true_nn = torch.argmax(exact_scores, dim=-1, keepdim=True)
    approx_topk = torch.topk(approx_scores, k=k, dim=-1).indices
    return torch.any(approx_topk == true_nn, dim=-1).float().mean().item()
