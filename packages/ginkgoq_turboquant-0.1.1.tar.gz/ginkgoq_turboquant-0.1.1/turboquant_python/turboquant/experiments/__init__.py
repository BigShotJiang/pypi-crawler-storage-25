"""Paper-reproduction experiment helpers."""

