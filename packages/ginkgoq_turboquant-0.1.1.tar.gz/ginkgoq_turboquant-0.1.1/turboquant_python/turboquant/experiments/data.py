"""Dataset loading helpers for paper reproduction."""

from __future__ import annotations

from collections.abc import Iterable

import torch


DBPEDIA_1536 = "Qdrant/dbpedia-entities-openai3-text-embedding-3-large-1536-1M"
DBPEDIA_3072 = "Qdrant/dbpedia-entities-openai3-text-embedding-3-large-3072-1M"
GLOVE_200 = "open-vdb/glove-200-angular"


def find_vector_column(row: dict, preferred: str | None = None) -> str:
    if preferred is not None:
        if preferred not in row:
            raise ValueError(f"requested vector column {preferred!r} is not present")
        return preferred
    for key, value in row.items():
        if isinstance(value, list) and value and isinstance(value[0], (float, int)):
            return key
    raise ValueError(f"could not infer vector column from keys: {sorted(row)}")


def load_hf_vectors(
    dataset_name: str,
    *,
    count: int,
    config: str | None = None,
    split: str = "train",
    vector_column: str | None = None,
    seed: int = 0,
    streaming: bool = True,
    shuffle: bool = True,
    shuffle_buffer: int = 100_000,
) -> torch.Tensor:
    """Load real vectors from Hugging Face datasets as ``float32`` tensors."""

    try:
        from datasets import load_dataset
    except ImportError as exc:
        raise RuntimeError("install `datasets` or use `pip install -e .[real-data]`") from exc

    ds = load_dataset(dataset_name, config, split=split, streaming=streaming)
    if shuffle:
        ds = ds.shuffle(seed=seed, buffer_size=shuffle_buffer) if streaming else ds.shuffle(seed=seed)

    iterator: Iterable[dict] = iter(ds)
    first = next(iterator)
    column = find_vector_column(first, vector_column)
    vectors = [torch.as_tensor(first[column], dtype=torch.float32)]

    for row in iterator:
        vectors.append(torch.as_tensor(row[column], dtype=torch.float32))
        if len(vectors) >= count:
            break
    if len(vectors) < count:
        raise ValueError(f"loaded {len(vectors)} vectors but requested {count}")
    return torch.stack(vectors, dim=0)


def split_database_queries(vectors: torch.Tensor, database_size: int, query_size: int) -> tuple[torch.Tensor, torch.Tensor]:
    needed = database_size + query_size
    if vectors.shape[0] < needed:
        raise ValueError(f"need {needed} vectors, got {vectors.shape[0]}")
    return vectors[:database_size], vectors[database_size:needed]
