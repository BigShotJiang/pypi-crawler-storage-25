"""Reproduce TurboQuant paper experiments from the manuscript protocol.

This covers the experiments that can be reproduced directly from the paper text:

* empirical MSE and inner-product distortion on DBpedia/OpenAI3 embeddings
* nearest-neighbor 1@k recall on DBpedia/OpenAI3 and GloVe-style datasets

The paper does not publish the exact random row IDs/seeds, so this runner records
its seed and sampled protocol in the output metadata.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import time
from pathlib import Path

import torch

from ..codebook import compute_lloyd_max_codebook
from ..metrics import reconstruction_mse
from ..quantizers import TurboQuantMSE, TurboQuantProd
from .data import DBPEDIA_1536, DBPEDIA_3072, GLOVE_200, load_hf_vectors, split_database_queries


def _normalize(x: torch.Tensor) -> torch.Tensor:
    return torch.nn.functional.normalize(x.float(), dim=-1)


def _as_device(x: torch.Tensor, device: torch.device) -> torch.Tensor:
    return x.to(device=device, dtype=torch.float32, non_blocking=True)


def _sync(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def _write_rows(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))


def _serializable_args(args: argparse.Namespace) -> dict:
    return {key: value for key, value in vars(args).items() if key != "func"}


def _chunked_inner_stats(
    queries: torch.Tensor,
    database: torch.Tensor,
    approx_database: torch.Tensor,
    *,
    chunk_size: int,
) -> dict[str, float]:
    errors = []
    exact_values = []
    for start in range(0, database.shape[0], chunk_size):
        stop = min(start + chunk_size, database.shape[0])
        exact = queries @ database[start:stop].T
        approx = queries @ approx_database[start:stop].T
        err = approx - exact
        errors.append(err.detach().flatten().cpu())
        exact_values.append(exact.detach().flatten().cpu())
    all_errors = torch.cat(errors)
    all_exact = torch.cat(exact_values)
    return {
        "ip_error_mean": float(all_errors.mean()),
        "ip_error_abs_mean": float(all_errors.abs().mean()),
        "ip_error_var": float(all_errors.var(unbiased=False)),
        "ip_error_mse": float(torch.mean(all_errors**2)),
        "ip_error_rmse": float(torch.sqrt(torch.mean(all_errors**2))),
        "exact_ip_mean": float(all_exact.mean()),
        "exact_ip_std": float(all_exact.std(unbiased=False)),
    }


def _topk_scores(
    queries: torch.Tensor,
    database: torch.Tensor,
    *,
    top_k: int,
    chunk_size: int,
) -> torch.Tensor:
    top_scores = []
    top_indices = []
    for start in range(0, database.shape[0], chunk_size):
        stop = min(start + chunk_size, database.shape[0])
        scores = queries @ database[start:stop].T
        scores, indices = torch.topk(scores, k=min(top_k, scores.shape[-1]), dim=-1)
        top_scores.append(scores)
        top_indices.append(indices + start)

    merged_scores = torch.cat(top_scores, dim=-1)
    merged_indices = torch.cat(top_indices, dim=-1)
    keep_scores, keep_pos = torch.topk(merged_scores, k=top_k, dim=-1)
    return torch.gather(merged_indices, dim=-1, index=keep_pos), keep_scores


def _recall_1_at_k(
    queries: torch.Tensor,
    database: torch.Tensor,
    approx_database: torch.Tensor,
    *,
    top_k: int,
    chunk_size: int,
) -> float:
    exact_idx, _ = _topk_scores(queries, database, top_k=1, chunk_size=chunk_size)
    approx_idx, _ = _topk_scores(queries, approx_database, top_k=top_k, chunk_size=chunk_size)
    return float(torch.any(approx_idx == exact_idx, dim=-1).float().mean().detach().cpu())


def run_empirical(args: argparse.Namespace) -> None:
    out = Path(args.output_dir)
    device = torch.device(args.device)
    vectors = load_hf_vectors(
        args.dataset,
        count=args.database_size + args.queries,
        config=args.config,
        split=args.split,
        vector_column=args.vector_column,
        seed=args.seed,
        streaming=not args.no_streaming,
        shuffle=not args.no_shuffle,
        shuffle_buffer=args.shuffle_buffer,
    )
    database_cpu, queries_cpu = split_database_queries(_normalize(vectors), args.database_size, args.queries)
    database = _as_device(database_cpu, device)
    queries = _as_device(queries_cpu, device)
    dim = database.shape[-1]

    rows: list[dict] = []
    for bits in args.bits:
        for method in ["mse", "prod"]:
            _sync(device)
            start = time.perf_counter()
            if method == "mse":
                quantizer = TurboQuantMSE(dim, bits, device=device, seed=args.seed)
            else:
                quantizer = TurboQuantProd(dim, bits, device=device, seed=args.seed)
            codes = quantizer.quantize(database)
            approx = quantizer.dequantize(codes)
            _sync(device)
            quant_seconds = time.perf_counter() - start

            row = {
                "dataset": args.dataset,
                "dim": dim,
                "database_size": args.database_size,
                "queries": args.queries,
                "seed": args.seed,
                "method": method,
                "bits": bits,
                "quantize_dequantize_seconds": quant_seconds,
                "mse": float(reconstruction_mse(database, approx)),
            }
            row.update(_chunked_inner_stats(queries, database, approx, chunk_size=args.score_chunk_size))

            avg_query_norm_sq = float(torch.mean(torch.sum(queries**2, dim=-1)).detach().cpu())
            row["mse_lower_bound"] = 4.0 ** (-bits)
            row["mse_upper_bound_paper"] = (math.sqrt(3.0) * math.pi / 2.0) * (4.0 ** (-bits))
            row["prod_lower_bound"] = (avg_query_norm_sq / dim) * (4.0 ** (-bits))
            row["prod_upper_bound_paper"] = (math.sqrt(3.0) * math.pi * math.pi * avg_query_norm_sq / dim) * (4.0 ** (-bits))
            rows.append(row)
            print(json.dumps(row, sort_keys=True))

    _write_rows(out / "empirical_validation.csv", rows)
    _write_json(
        out / "metadata.json",
        {
            "mode": "empirical",
            "paper_protocol": "DBpedia/OpenAI3 embeddings, 100000 database vectors, 1000 queries, bits 1-4",
            "note": "The paper does not publish exact random row IDs; this run records the seed and sampling settings.",
            "args": _serializable_args(args),
        },
    )


def _faiss_pq_reconstruct(database: torch.Tensor, bits_per_coordinate: int) -> tuple[torch.Tensor, float]:
    import faiss
    import numpy as np

    if 8 % bits_per_coordinate != 0:
        raise ValueError("paper-style FAISS PQ baseline here supports bits that divide 8")
    x = np.ascontiguousarray(database.detach().cpu().numpy().astype("float32"))
    dim = x.shape[1]
    subvector_dim = 8 // bits_per_coordinate
    if dim % subvector_dim != 0:
        raise ValueError(f"dim={dim} is not divisible by subvector_dim={subvector_dim}")
    m = dim // subvector_dim
    index = faiss.IndexPQ(dim, m, 8)
    start = time.perf_counter()
    index.train(x)
    codes = index.sa_encode(x)
    reconstructed = index.sa_decode(codes)
    elapsed = time.perf_counter() - start
    return torch.from_numpy(reconstructed).to(database.device), elapsed


def run_nearest_neighbor(args: argparse.Namespace) -> None:
    out = Path(args.output_dir)
    device = torch.device(args.device)
    if args.query_dataset:
        database_cpu = load_hf_vectors(
            args.dataset,
            count=args.database_size,
            config=args.config,
            split=args.split,
            vector_column=args.vector_column,
            seed=args.seed,
            streaming=not args.no_streaming,
            shuffle=not args.no_shuffle,
            shuffle_buffer=args.shuffle_buffer,
        )
        queries_cpu = load_hf_vectors(
            args.query_dataset,
            count=args.queries,
            config=args.query_config,
            split=args.query_split,
            vector_column=args.query_vector_column or args.vector_column,
            seed=args.seed + 1,
            streaming=not args.no_streaming,
            shuffle=not args.no_shuffle,
            shuffle_buffer=args.shuffle_buffer,
        )
        database_cpu = _normalize(database_cpu)
        queries_cpu = _normalize(queries_cpu)
    else:
        vectors = load_hf_vectors(
            args.dataset,
            count=args.database_size + args.queries,
            config=args.config,
            split=args.split,
            vector_column=args.vector_column,
            seed=args.seed,
            streaming=not args.no_streaming,
            shuffle=not args.no_shuffle,
            shuffle_buffer=args.shuffle_buffer,
        )
        database_cpu, queries_cpu = split_database_queries(_normalize(vectors), args.database_size, args.queries)
    database = _as_device(database_cpu, device)
    queries = _as_device(queries_cpu, device)
    dim = database.shape[-1]

    rows: list[dict] = []
    for bits in args.bits:
        _sync(device)
        start = time.perf_counter()
        quantizer = TurboQuantProd(dim, bits, device=device, seed=args.seed)
        approx = quantizer.dequantize(quantizer.quantize(database))
        _sync(device)
        tq_seconds = time.perf_counter() - start
        row = {
            "dataset": args.dataset,
            "dim": dim,
            "database_size": args.database_size,
            "queries": args.queries,
            "seed": args.seed,
            "method": "TurboQuant",
            "bits": bits,
            "quantization_seconds": tq_seconds,
            f"recall_1_at_{args.top_k}": _recall_1_at_k(
                queries,
                database,
                approx,
                top_k=args.top_k,
                chunk_size=args.score_chunk_size,
            ),
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True))

        if args.include_pq and bits in [1, 2, 4, 8]:
            pq_approx, pq_seconds = _faiss_pq_reconstruct(database, bits)
            pq_row = dict(row)
            pq_row["method"] = "FAISS-IndexPQ"
            pq_row["quantization_seconds"] = pq_seconds
            pq_row[f"recall_1_at_{args.top_k}"] = _recall_1_at_k(
                queries,
                database,
                pq_approx,
                top_k=args.top_k,
                chunk_size=args.score_chunk_size,
            )
            rows.append(pq_row)
            print(json.dumps(pq_row, sort_keys=True))

    _write_rows(out / "nearest_neighbor.csv", rows)
    _write_json(
        out / "metadata.json",
        {
            "mode": "nearest-neighbor",
            "paper_protocol": "100000 database vectors, query set, recall 1@k; DBpedia 1536/3072 and GloVe 200 in the paper.",
            "note": "RabitQ is not bundled here; FAISS PQ is optional with --include-pq.",
            "args": _serializable_args(args),
        },
    )


def run_codebooks(args: argparse.Namespace) -> None:
    rows = []
    for dim in args.dims:
        for bits in args.bits:
            cb = compute_lloyd_max_codebook(dim, bits)
            row = {
                "dim": dim,
                "bits": bits,
                "mse_total": cb.total_mse,
                "paper_small_bit_mse": {1: 0.36, 2: 0.117, 3: 0.03, 4: 0.009}.get(bits),
                "lower_bound": 4.0 ** (-bits),
                "upper_bound_paper": (math.sqrt(3.0) * math.pi / 2.0) * (4.0 ** (-bits)),
            }
            rows.append(row)
            print(json.dumps(row, sort_keys=True))
    _write_rows(Path(args.output_dir) / "codebooks.csv", rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--output-dir", default="runs/turboquant_reproduction")
    common.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    common.add_argument("--seed", type=int, default=0)
    common.add_argument("--bits", type=int, nargs="+", default=[1, 2, 3, 4])

    data = argparse.ArgumentParser(add_help=False)
    data.add_argument("--dataset", default=DBPEDIA_1536)
    data.add_argument("--config")
    data.add_argument("--split", default="train")
    data.add_argument("--vector-column")
    data.add_argument("--database-size", type=int, default=100_000)
    data.add_argument("--queries", type=int, default=1_000)
    data.add_argument("--shuffle-buffer", type=int, default=100_000)
    data.add_argument("--score-chunk-size", type=int, default=8192)
    data.add_argument("--no-streaming", action="store_true")
    data.add_argument("--no-shuffle", action="store_true")

    empirical = sub.add_parser("empirical", parents=[common, data])
    empirical.set_defaults(func=run_empirical)

    nn = sub.add_parser("nn", parents=[common, data])
    nn.add_argument("--top-k", type=int, default=10)
    nn.add_argument("--include-pq", action="store_true")
    nn.add_argument("--query-dataset")
    nn.add_argument("--query-config")
    nn.add_argument("--query-split", default="test")
    nn.add_argument("--query-vector-column")
    nn.set_defaults(func=run_nearest_neighbor)

    codebooks = sub.add_parser("codebooks", parents=[common])
    codebooks.add_argument("--dims", type=int, nargs="+", default=[128, 1536, 3072])
    codebooks.set_defaults(func=run_codebooks)

    presets = sub.add_parser("paper-presets")
    presets.set_defaults(func=lambda _args: print(json.dumps({
        "empirical_dbpedia_1536": DBPEDIA_1536,
        "nn_dbpedia_1536": DBPEDIA_1536,
        "nn_dbpedia_3072": DBPEDIA_3072,
        "nn_glove_200": GLOVE_200,
    }, indent=2)))
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
