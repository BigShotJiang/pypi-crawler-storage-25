"""Small executable validation using real tensor math on CPU or GPU."""

from __future__ import annotations

import argparse

import torch

from .metrics import reconstruction_mse
from .quantizers import TurboQuantMSE, TurboQuantProd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dim", type=int, default=128)
    parser.add_argument("--bits", type=int, default=3)
    parser.add_argument("--vectors", type=int, default=512)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)
    generator = torch.Generator(device=device)
    generator.manual_seed(123)
    x = torch.randn(args.vectors, args.dim, device=device, generator=generator)
    y = torch.randn(args.vectors, args.dim, device=device, generator=generator)

    mse = TurboQuantMSE(args.dim, args.bits, device=device, seed=7)
    x_hat = mse(x)
    print(f"device={device}")
    print(f"mse_total={reconstruction_mse(x, x_hat).item():.6f}")

    prod = TurboQuantProd(args.dim, args.bits, device=device, seed=7)
    q = prod.quantize(x)
    approx = prod.inner_product(y[:16], q)
    exact = y[:16] @ x.T
    print(f"inner_product_rmse={torch.sqrt(torch.mean((approx - exact) ** 2)).item():.6f}")


if __name__ == "__main__":
    main()
