"""Bit packing helpers for TurboQuant indices and QJL signs."""

from __future__ import annotations

import torch


def pack_unsigned(values: torch.Tensor, bits: int) -> torch.Tensor:
    """Pack unsigned integer values from the last dimension into uint8 bytes."""

    if bits < 1 or bits > 8:
        raise ValueError(f"bits must be in [1, 8], got {bits}")
    if values.shape[-1] < 1:
        raise ValueError("cannot pack an empty last dimension")

    if bits == 4:
        values8 = values.to(torch.uint8)
        if torch.any(values8 >= 16):
            raise ValueError("values contain entries outside the requested bit-width")
        if values8.shape[-1] % 2 != 0:
            values8 = torch.nn.functional.pad(values8, (0, 1))
        paired = values8.reshape(*values8.shape[:-1], -1, 2)
        return (paired[..., 0] | (paired[..., 1] << 4)).contiguous()

    if bits == 8:
        values8 = values.to(torch.uint8)
        if torch.any(values.to(torch.int64) < 0) or torch.any(values.to(torch.int64) >= 256):
            raise ValueError("values contain entries outside the requested bit-width")
        return values8.contiguous()

    values64 = values.to(torch.int64)
    if torch.any(values64 < 0) or torch.any(values64 >= (1 << bits)):
        raise ValueError("values contain entries outside the requested bit-width")

    dim = values64.shape[-1]
    rows = values64.reshape(-1, dim)
    total_bits = dim * bits
    packed = torch.zeros(rows.shape[0], (total_bits + 7) // 8, device=values.device, dtype=torch.uint8)

    coord_offsets = torch.arange(dim, device=values.device, dtype=torch.int64) * bits
    for bit in range(bits):
        positions = coord_offsets + bit
        byte_idx = positions // 8
        bit_idx = positions % 8
        payload = (((rows >> bit) & 1).to(torch.uint8) << bit_idx.to(torch.uint8)).contiguous()
        packed.scatter_add_(1, byte_idx.expand(rows.shape[0], -1), payload)

    return packed.reshape(*values.shape[:-1], packed.shape[-1])


def unpack_unsigned(packed: torch.Tensor, bits: int, dim: int) -> torch.Tensor:
    """Unpack ``uint8`` bytes into unsigned integer values along the last dim."""

    if bits < 1 or bits > 8:
        raise ValueError(f"bits must be in [1, 8], got {bits}")
    if dim < 1:
        raise ValueError(f"dim must be positive, got {dim}")

    if bits == 4:
        low = packed & 0x0F
        high = (packed >> 4) & 0x0F
        values = torch.stack([low, high], dim=-1).reshape(*packed.shape[:-1], -1)
        return values[..., :dim].to(torch.int64)

    if bits == 8:
        return packed[..., :dim].to(torch.int64)

    rows = packed.reshape(-1, packed.shape[-1])
    values = torch.zeros(rows.shape[0], dim, device=packed.device, dtype=torch.int64)
    coord_offsets = torch.arange(dim, device=packed.device, dtype=torch.int64) * bits

    for bit in range(bits):
        positions = coord_offsets + bit
        byte_idx = positions // 8
        bit_idx = positions % 8
        bit_values = ((rows[:, byte_idx] >> bit_idx) & 1).to(torch.int64)
        values |= bit_values << bit

    return values.reshape(*packed.shape[:-1], dim)


def pack_signs(signs: torch.Tensor) -> torch.Tensor:
    """Pack boolean or ``{-1, +1}`` signs from the last dimension."""

    if signs.dtype == torch.bool:
        bits = signs
    else:
        bits = signs >= 0
    return pack_unsigned(bits.to(torch.uint8), 1)


def unpack_signs(packed: torch.Tensor, dim: int, *, dtype: torch.dtype = torch.float32) -> torch.Tensor:
    """Unpack QJL signs as ``{-1, +1}`` floats."""

    bits = unpack_unsigned(packed, 1, dim).to(dtype=dtype)
    return bits.mul(2.0).sub(1.0)
