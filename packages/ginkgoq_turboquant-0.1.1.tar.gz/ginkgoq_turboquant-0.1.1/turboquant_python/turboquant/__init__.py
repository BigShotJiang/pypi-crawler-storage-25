"""TurboQuant: Near-optimal KV cache quantization for LLM inference.

This package implements the TurboQuant paper algorithms for compressing
key-value caches in transformer-based language models. It achieves near-optimal
distortion rates (within ~2.7x of information-theoretic lower bounds) across
all bit-widths and dimensions.

Core Algorithms:
    - ``TurboQuantMSE``: Algorithm 1, optimized for reconstruction MSE.
      Best for KV cache where quality preservation matters.
    - ``TurboQuantProd``: Algorithm 2, MSE quantization plus residual QJL
      for unbiased inner-product estimation. Best for vector search.

Key Features:
    - 2.5-4.7x memory compression with quality preservation
    - Data-oblivious (no calibration needed)
    - Fused Triton kernels for decode attention
    - Auto policy for SDPA vs TurboQuant selection
    - HuggingFace Transformers integration

Quick Start:
    >>> from torbuquant import TurboQuantMSE
    >>> quantizer = TurboQuantMSE(dim=128, bits=4, device="cuda")
    >>> compressed = quantizer.quantize(keys)
    >>> reconstructed = quantizer.dequantize(compressed)

For LLM integration:
    >>> from torbuquant.llm import TurboQuantDynamicCache
    >>> cache = TurboQuantDynamicCache(
    ...     num_hidden_layers=32,
    ...     head_dim=128,
    ...     key_bits=4,
    ...     value_bits=8,
    ... )

Paper Reference:
    TurboQuant: Online Vector Quantization with Near-optimal Distortion Rate
    Zandieh et al., ICLR 2026
    https://arxiv.org/abs/2504.19874
"""

__version__ = "0.1.0"
__author__ = "Arman Asgharpoor"

from .codebook import LloydMaxCodebook, beta_coordinate_pdf, compute_lloyd_max_codebook
from .fused_attention import CompressedKV, FusedTurboQuantAttention
from .policy import (
    AutoPolicyInput,
    TurboQuantKVPolicy,
    choose_auto_kv_policy,
    choose_kv_policy,
    estimate_dense_kv_bytes,
    estimate_turboquant_kv_bytes,
)
from .quantizers import MSEQuantized, ProdQuantized, TurboQuantMSE, TurboQuantProd
from .rotation import generate_qjl_matrix, generate_rotation_matrix

__all__ = [
    # Version
    "__version__",
    # Quantizers (core)
    "TurboQuantMSE",
    "TurboQuantProd",
    "MSEQuantized",
    "ProdQuantized",
    # Codebook
    "LloydMaxCodebook",
    "beta_coordinate_pdf",
    "compute_lloyd_max_codebook",
    # Rotation
    "generate_qjl_matrix",
    "generate_rotation_matrix",
    # Fused Attention
    "FusedTurboQuantAttention",
    "CompressedKV",
    # Policy
    "TurboQuantKVPolicy",
    "AutoPolicyInput",
    "choose_auto_kv_policy",
    "choose_kv_policy",
    "estimate_dense_kv_bytes",
    "estimate_turboquant_kv_bytes",
]
