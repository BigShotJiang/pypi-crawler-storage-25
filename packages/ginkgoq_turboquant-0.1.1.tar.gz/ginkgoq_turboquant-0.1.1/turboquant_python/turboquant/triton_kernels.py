"""Triton kernels for TurboQuant - fused score computation.

These kernels compute attention scores directly from quantized keys,
avoiding the need to materialize full dequantized tensors.

Key optimization: Instead of dequantize(K) -> Q @ K.T, we compute:
    score[n] = norm[n] * Σⱼ q_rot[j] * centroid[idx[n,j]]

This fuses: unpack indices + centroid lookup + scaling + dot product
into a single kernel pass, dramatically reducing memory bandwidth.
"""

from __future__ import annotations

import torch

try:
    import triton
    import triton.language as tl
    HAS_TRITON = True
except ImportError:
    HAS_TRITON = False


if HAS_TRITON:
    @triton.jit
    def _turboquant_mse_score_kernel(
        # Pointers
        Q_ROT_ptr,      # (BH, D) rotated query: q @ Pi.T
        INDICES_ptr,    # (BH, N) unpacked indices (int64)
        NORMS_ptr,      # (BH, N) original norms
        CENTROIDS_ptr,  # (n_clusters,) centroid values
        OUT_ptr,        # (BH, N) output scores
        # Strides
        stride_q_bh, stride_q_d,
        stride_i_bh, stride_i_n, stride_i_d,
        stride_n_bh, stride_n_n,
        stride_o_bh, stride_o_n,
        # Dimensions
        N,
        D: tl.constexpr,
        # Block sizes
        BLOCK_N: tl.constexpr,
        BLOCK_D: tl.constexpr,
    ):
        """Compute TurboQuant MSE attention scores.

        For each (query, quantized_key) pair, compute:
            score = norm * Σⱼ q_rot[j] * centroid[idx[j]]
        """
        pid_bh = tl.program_id(0)  # batch*head index
        pid_n = tl.program_id(1)   # token block index

        # Token range for this block
        n_start = pid_n * BLOCK_N
        n_offs = n_start + tl.arange(0, BLOCK_N)
        n_mask = n_offs < N

        # Accumulate score for each token
        scores = tl.zeros([BLOCK_N], dtype=tl.float32)

        # Process dimension in blocks
        for d_start in range(0, D, BLOCK_D):
            d_offs = d_start + tl.arange(0, BLOCK_D)
            d_mask = d_offs < D

            # Load rotated query values for this dimension block: (BLOCK_D,)
            q_vals = tl.load(
                Q_ROT_ptr + pid_bh * stride_q_bh + d_offs * stride_q_d,
                mask=d_mask, other=0.0
            ).to(tl.float32)

            # Load indices for this dimension block: (BLOCK_N, BLOCK_D)
            # indices[b, n, d] -> INDICES_ptr + b*stride_i_bh + n*stride_i_n + d*stride_i_d
            idx_ptrs = (
                INDICES_ptr
                + pid_bh * stride_i_bh
                + n_offs[:, None] * stride_i_n
                + d_offs[None, :] * stride_i_d
            )
            indices = tl.load(idx_ptrs, mask=n_mask[:, None] & d_mask[None, :], other=0)

            # Lookup centroids: (BLOCK_N, BLOCK_D)
            centroid_vals = tl.load(CENTROIDS_ptr + indices)

            # Dot product contribution: sum over D
            # scores += (q_vals[None, :] * centroid_vals).sum(axis=1)
            contribution = tl.sum(q_vals[None, :] * centroid_vals, axis=1)
            scores += contribution

        # Scale by norms
        norms = tl.load(
            NORMS_ptr + pid_bh * stride_n_bh + n_offs * stride_n_n,
            mask=n_mask, other=0.0
        ).to(tl.float32)
        scores = scores * norms

        # Store results
        tl.store(
            OUT_ptr + pid_bh * stride_o_bh + n_offs * stride_o_n,
            scores, mask=n_mask
        )


def triton_mse_score(
    query_rotated: torch.Tensor,  # (BH, D) or (B, H, D)
    indices: torch.Tensor,        # (BH, N, D) unpacked indices
    norms: torch.Tensor,          # (BH, N)
    centroids: torch.Tensor,      # (n_clusters,)
) -> torch.Tensor:
    """Compute MSE attention scores using Triton kernel.

    Args:
        query_rotated: Pre-rotated query (q @ Pi.T)
        indices: Unpacked quantization indices
        norms: Original vector norms
        centroids: Codebook centroids

    Returns:
        Attention scores (BH, N)
    """
    if not HAS_TRITON:
        raise RuntimeError("Triton not available. Install with: pip install triton")

    # Flatten to (BH, ...)
    if query_rotated.dim() == 3:
        B, H, D = query_rotated.shape
        query_rotated = query_rotated.reshape(B * H, D)
    else:
        D = query_rotated.shape[-1]

    if indices.dim() == 4:
        B, H, N, D = indices.shape
        indices = indices.reshape(B * H, N, D)
        norms = norms.reshape(B * H, N)
    else:
        N = indices.shape[-2]

    BH = query_rotated.shape[0]

    # Ensure contiguous and correct types
    query_rotated = query_rotated.contiguous().float()
    indices = indices.contiguous().long()
    norms = norms.contiguous().float()
    centroids = centroids.contiguous().float()

    # Output
    out = torch.empty(BH, N, device=query_rotated.device, dtype=torch.float32)

    # Block sizes
    BLOCK_N = min(64, triton.next_power_of_2(N))
    BLOCK_D = min(64, triton.next_power_of_2(D))

    # Grid
    grid = (BH, triton.cdiv(N, BLOCK_N))

    _turboquant_mse_score_kernel[grid](
        query_rotated, indices, norms, centroids, out,
        # Strides
        query_rotated.stride(0), query_rotated.stride(1),
        indices.stride(0), indices.stride(1), indices.stride(2),
        norms.stride(0), norms.stride(1),
        out.stride(0), out.stride(1),
        # Dims
        N=N, D=D,
        # Blocks
        BLOCK_N=BLOCK_N, BLOCK_D=BLOCK_D,
    )

    return out


def check_triton_available() -> bool:
    """Check if Triton is available and functional."""
    return HAS_TRITON
