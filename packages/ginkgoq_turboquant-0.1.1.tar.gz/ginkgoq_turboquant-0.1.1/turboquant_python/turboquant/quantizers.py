"""Paper-faithful PyTorch TurboQuant quantizers."""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch

from .codebook import codebook_tensors
from .packing import pack_signs, pack_unsigned, unpack_signs, unpack_unsigned
from .rotation import (
    generate_qjl_matrix,
    generate_rotation_matrix,
    generate_rht_rotation,
    rotate_backward,
    rotate_forward,
    RHTRotation,
    hadamard_transform,
)

# Try to import Triton kernels
try:
    from .triton_kernels import triton_mse_score, HAS_TRITON
except ImportError:
    HAS_TRITON = False
    triton_mse_score = None


@dataclass(frozen=True)
class MSEQuantized:
    """Compressed output of ``TurboQuantMSE.quantize``."""

    indices: torch.Tensor
    norms: torch.Tensor
    bits: int
    dim: int


@dataclass(frozen=True)
class ProdQuantized:
    """Compressed output of ``TurboQuantProd.quantize``."""

    mse_indices: torch.Tensor
    qjl_signs: torch.Tensor
    residual_norms: torch.Tensor
    norms: torch.Tensor
    mse_bits: int
    dim: int


class TurboQuantMSE(torch.nn.Module):
    """Algorithm 1 from the TurboQuant paper, optimized for MSE.

    Supports two rotation modes:
    - "dense": Standard O(d²) Gaussian QR rotation (default, works with any dim)
    - "rht": Randomized Hadamard Transform O(d log d) (requires power-of-2 dim)

    RHT mode is significantly faster for large dimensions but requires dim to be
    a power of 2. Use rotation_type="rht" when dim is 64, 128, 256, etc.
    """

    def __init__(
        self,
        dim: int,
        bits: int,
        *,
        device: torch.device | str | None = None,
        dtype: torch.dtype = torch.float32,
        seed: int | None = 0,
        normalize: bool = True,
        rotation_type: str = "dense",  # "dense" or "rht"
    ) -> None:
        super().__init__()
        if dim < 3:
            raise ValueError(f"dim must be >= 3, got {dim}")
        if bits < 1 or bits > 8:
            raise ValueError(f"bits must be in [1, 8], got {bits}")
        if rotation_type not in ("dense", "rht"):
            raise ValueError(f"rotation_type must be 'dense' or 'rht', got {rotation_type}")
        if rotation_type == "rht" and (dim & (dim - 1)) != 0:
            raise ValueError(f"RHT requires power-of-2 dimension, got {dim}")

        self.dim = dim
        self.bits = bits
        self.normalize = normalize
        self.rotation_type = rotation_type
        device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))

        # Initialize rotation based on type
        if rotation_type == "dense":
            rotation = generate_rotation_matrix(dim, device=device, dtype=dtype, seed=seed)
            self.register_buffer("rotation", rotation)
            self._rht = None
        else:  # rht
            self._rht = generate_rht_rotation(dim, device=device, dtype=dtype, seed=seed)
            # Register sign vectors as buffers for state_dict compatibility
            self.register_buffer("_rht_signs1", self._rht.signs1)
            self.register_buffer("_rht_signs2", self._rht.signs2)
            self.register_buffer("rotation", torch.empty(0))  # Placeholder for device property

        centroids, boundaries = codebook_tensors(dim, bits, device=device, dtype=dtype)
        self.register_buffer("centroids", centroids)
        self.register_buffer("decision_boundaries", boundaries)

    @property
    def device(self) -> torch.device:
        return self.centroids.device

    def _check_input(self, x: torch.Tensor) -> None:
        if x.shape[-1] != self.dim:
            raise ValueError(f"expected last dimension {self.dim}, got {x.shape[-1]}")
        if x.device != self.device:
            raise ValueError(f"input is on {x.device}, but quantizer is on {self.device}")

    def _rotate_forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply forward rotation (dense or RHT)."""
        if self.rotation_type == "rht":
            return self._rht.forward(x)
        return rotate_forward(x, self.rotation)

    def _rotate_backward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply backward rotation (dense or RHT)."""
        if self.rotation_type == "rht":
            return self._rht.backward(x)
        return rotate_backward(x, self.rotation)

    def quantize(self, x: torch.Tensor) -> MSEQuantized:
        """Quantize vectors of shape ``(..., dim)`` into packed codebook indices."""

        self._check_input(x)
        work = x.to(dtype=self.centroids.dtype)
        if self.normalize:
            norms = torch.linalg.vector_norm(work, dim=-1)
            unit = work / norms.clamp_min(torch.finfo(work.dtype).tiny).unsqueeze(-1)
        else:
            norms = torch.ones(work.shape[:-1], device=work.device, dtype=work.dtype)
            unit = work

        rotated = self._rotate_forward(unit)
        indices = torch.searchsorted(self.decision_boundaries, rotated.contiguous())
        packed = pack_unsigned(indices, self.bits)
        return MSEQuantized(indices=packed, norms=norms, bits=self.bits, dim=self.dim)

    def dequantize(self, quantized: MSEQuantized) -> torch.Tensor:
        """Reconstruct vectors from packed TurboQuant MSE codes."""

        if quantized.dim != self.dim or quantized.bits != self.bits:
            raise ValueError("quantized metadata does not match this quantizer")
        indices = unpack_unsigned(quantized.indices.to(self.device), self.bits, self.dim)
        rotated_hat = self.centroids[indices]
        unit_hat = self._rotate_backward(rotated_hat)
        return unit_hat * quantized.norms.to(self.device, dtype=unit_hat.dtype).unsqueeze(-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dequantize(self.quantize(x))

    def rotate_query(self, query: torch.Tensor) -> torch.Tensor:
        """Pre-rotate query for use with direct_score().

        Call this ONCE per decode step, then use direct_score() for all layers.

        Args:
            query: (..., dim) query vectors

        Returns:
            (..., dim) rotated query: q @ Pi.T (or RHT forward transform)
        """
        self._check_input(query)
        return self._rotate_forward(query.to(dtype=self.centroids.dtype))

    def direct_score(
        self,
        query_rotated: torch.Tensor,
        quantized: MSEQuantized,
        scale: float = 1.0,
    ) -> torch.Tensor:
        """Compute attention scores directly from quantized keys WITHOUT dequantizing.

        This is the KEY optimization from the paper - instead of:
            dequant_K = dequantize(quantized)  # O(N × D × D) rotation
            scores = Q @ dequant_K.T           # O(N × D)

        We compute:
            scores = norms * Σⱼ q_rot[j] * centroid[idx[j]]  # O(N × D) total

        This avoids the expensive O(D × D) rotation for EACH of N tokens!

        Args:
            query_rotated: (..., Q, D) pre-rotated query (from rotate_query())
            quantized: MSEQuantized with packed indices of shape (..., N, packed_d)
            scale: attention scale factor (typically 1/sqrt(d))

        Returns:
            (..., Q, N) attention scores
        """
        # Unpack indices: (..., N, D)
        indices = unpack_unsigned(quantized.indices.to(self.device), self.bits, self.dim)

        # Look up centroids for all positions: (..., N, D)
        centroids_lookup = self.centroids[indices]  # shape: (..., N, D)

        # Scale by norms: centroids_lookup * norms[..., :, None]
        norms = quantized.norms.to(self.device, dtype=centroids_lookup.dtype)
        scaled_centroids = centroids_lookup * norms.unsqueeze(-1)  # (..., N, D)

        # Compute scores: q_rot @ scaled_centroids.T
        # query_rotated: (..., Q, D), scaled_centroids: (..., N, D)
        # Result: (..., Q, N)
        q_rot = query_rotated.to(dtype=scaled_centroids.dtype)
        scores = torch.matmul(q_rot, scaled_centroids.transpose(-2, -1))

        return scores * scale

    def direct_score_fused(
        self,
        query: torch.Tensor,
        quantized: MSEQuantized,
        scale: float = 1.0,
    ) -> torch.Tensor:
        """Fused version: rotate query and compute scores in one call.

        Use this when you need scores for a single layer.
        Use rotate_query() + direct_score() when reusing across layers.
        """
        q_rot = self.rotate_query(query)
        return self.direct_score(q_rot, quantized, scale)

    def direct_score_triton(
        self,
        query_rotated: torch.Tensor,
        quantized: MSEQuantized,
        scale: float = 1.0,
    ) -> torch.Tensor:
        """Compute attention scores using Triton kernel (31x faster than dequantize+matmul).

        This uses a fused Triton kernel that computes:
            score[n] = norm[n] * Σⱼ q_rot[j] * centroid[idx[n,j]]

        Falls back to PyTorch if Triton is not available.

        Args:
            query_rotated: (..., Q, D) pre-rotated query (from rotate_query())
            quantized: MSEQuantized with packed indices
            scale: attention scale factor (typically 1/sqrt(d))

        Returns:
            (..., Q, N) attention scores
        """
        if not HAS_TRITON or triton_mse_score is None:
            return self.direct_score(query_rotated, quantized, scale)

        # Unpack indices
        indices = unpack_unsigned(quantized.indices.to(self.device), self.bits, self.dim)
        norms = quantized.norms.to(self.device)

        # Handle batch dimensions - Triton kernel expects (BH, ...) format
        orig_shape = indices.shape  # (..., N, D)
        batch_dims = orig_shape[:-2]
        N = orig_shape[-2]
        Q_len = query_rotated.shape[-2]

        # Flatten batch dims
        if len(batch_dims) > 0:
            BH = int(torch.tensor(batch_dims).prod().item())
            indices_flat = indices.reshape(BH, N, self.dim)
            norms_flat = norms.reshape(BH, N)
            q_flat = query_rotated.reshape(BH, Q_len, self.dim)
        else:
            indices_flat = indices.unsqueeze(0)
            norms_flat = norms.unsqueeze(0)
            q_flat = query_rotated.unsqueeze(0)
            BH = 1

        # Call Triton kernel for each query position
        # The kernel expects (BH, D) query, so we loop over Q positions
        scores_list = []
        for q_idx in range(Q_len):
            q_single = q_flat[:, q_idx, :]  # (BH, D)
            scores_single = triton_mse_score(q_single, indices_flat, norms_flat, self.centroids)
            scores_list.append(scores_single)

        scores_flat = torch.stack(scores_list, dim=1)  # (BH, Q, N)

        # Reshape back to original batch dims
        if len(batch_dims) > 0:
            scores = scores_flat.reshape(*batch_dims, Q_len, N)
        else:
            scores = scores_flat.squeeze(0)

        return scores * scale

    def direct_score_memory_efficient(
        self,
        query_rotated: torch.Tensor,
        quantized: MSEQuantized,
        scale: float = 1.0,
        chunk_size: int = 64,
    ) -> torch.Tensor:
        """Memory-efficient direct score: process in chunks to avoid large intermediate tensors.

        This version uses less GPU memory by processing tokens in chunks,
        trading some speed for memory efficiency.

        Args:
            query_rotated: (..., Q, D) pre-rotated query
            quantized: MSEQuantized with packed indices
            scale: attention scale factor
            chunk_size: number of tokens to process at once

        Returns:
            (..., Q, N) attention scores
        """
        # Unpack indices: (..., N, D)
        indices = unpack_unsigned(quantized.indices.to(self.device), self.bits, self.dim)
        norms = quantized.norms.to(self.device, dtype=self.centroids.dtype)

        # Get shapes
        batch_shape = indices.shape[:-2]
        N = indices.shape[-2]
        Q_len = query_rotated.shape[-2]

        # Flatten batch dims for processing
        indices_flat = indices.reshape(-1, N, self.dim)
        norms_flat = norms.reshape(-1, N)
        q_flat = query_rotated.to(dtype=self.centroids.dtype).reshape(-1, Q_len, self.dim)

        B = indices_flat.shape[0]
        scores_flat = torch.empty(B, Q_len, N, device=self.device, dtype=self.centroids.dtype)

        # Process in chunks to save memory
        for start in range(0, N, chunk_size):
            end = min(start + chunk_size, N)
            idx_chunk = indices_flat[:, start:end, :]  # (B, chunk, D)
            norm_chunk = norms_flat[:, start:end]       # (B, chunk)

            # Centroid lookup for this chunk only
            centroids_chunk = self.centroids[idx_chunk]  # (B, chunk, D)
            scaled_chunk = centroids_chunk * norm_chunk.unsqueeze(-1)

            # Score for this chunk
            scores_flat[:, :, start:end] = torch.matmul(q_flat, scaled_chunk.transpose(-2, -1))

        # Reshape back
        scores = scores_flat.reshape(*batch_shape, Q_len, N)
        return scores * scale


class TurboQuantProd(torch.nn.Module):
    """Algorithm 2: MSE code plus residual QJL for unbiased inner products."""

    def __init__(
        self,
        dim: int,
        bits: int,
        *,
        device: torch.device | str | None = None,
        dtype: torch.dtype = torch.float32,
        seed: int | None = 0,
    ) -> None:
        super().__init__()
        if bits < 1:
            raise ValueError(f"bits must be >= 1, got {bits}")
        self.dim = dim
        self.bits = bits
        device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.mse_quantizer = TurboQuantMSE(
            dim,
            max(bits - 1, 1),
            device=device,
            dtype=dtype,
            seed=seed,
            normalize=True,
        )
        self.uses_mse_stage = bits > 1
        qjl = generate_qjl_matrix(dim, device=device, dtype=dtype, seed=None if seed is None else seed + 1)
        self.register_buffer("qjl_matrix", qjl)
        self.qjl_scale = math.sqrt(math.pi / 2.0) / dim

    @property
    def device(self) -> torch.device:
        return self.qjl_matrix.device

    def _check_input(self, x: torch.Tensor) -> None:
        if x.shape[-1] != self.dim:
            raise ValueError(f"expected last dimension {self.dim}, got {x.shape[-1]}")
        if x.device != self.device:
            raise ValueError(f"input is on {x.device}, but quantizer is on {self.device}")

    def quantize(self, x: torch.Tensor) -> ProdQuantized:
        """Quantize vectors into MSE indices, residual sign sketch, and residual norm."""

        self._check_input(x)
        work = x.to(dtype=self.qjl_matrix.dtype)
        if self.uses_mse_stage:
            mse_q = self.mse_quantizer.quantize(work)
            mse_hat = self.mse_quantizer.dequantize(mse_q)
            mse_indices = mse_q.indices
            norms = mse_q.norms
            mse_bits = mse_q.bits
        else:
            mse_hat = torch.zeros_like(work)
            mse_indices = torch.empty(*work.shape[:-1], 0, device=work.device, dtype=torch.uint8)
            norms = torch.linalg.vector_norm(work, dim=-1)
            mse_bits = 0

        residual = work - mse_hat
        residual_norms = torch.linalg.vector_norm(residual, dim=-1)
        residual_unit = residual / residual_norms.clamp_min(torch.finfo(work.dtype).tiny).unsqueeze(-1)
        signs = residual_unit @ self.qjl_matrix.T
        return ProdQuantized(
            mse_indices=mse_indices,
            qjl_signs=pack_signs(signs),
            residual_norms=residual_norms,
            norms=norms,
            mse_bits=mse_bits,
            dim=self.dim,
        )

    def dequantize(self, quantized: ProdQuantized) -> torch.Tensor:
        """Return the vector whose dot product implements the paper's estimator."""

        if quantized.dim != self.dim:
            raise ValueError("quantized dimension does not match this quantizer")
        if self.uses_mse_stage:
            mse_q = MSEQuantized(
                indices=quantized.mse_indices,
                norms=quantized.norms,
                bits=quantized.mse_bits,
                dim=self.dim,
            )
            mse_hat = self.mse_quantizer.dequantize(mse_q)
        else:
            shape = (*quantized.qjl_signs.shape[:-1], self.dim)
            mse_hat = torch.zeros(shape, device=self.device, dtype=self.qjl_matrix.dtype)

        signs = unpack_signs(quantized.qjl_signs.to(self.device), self.dim, dtype=self.qjl_matrix.dtype)
        qjl_hat = signs @ self.qjl_matrix
        scale = self.qjl_scale * quantized.residual_norms.to(self.device, dtype=qjl_hat.dtype).unsqueeze(-1)
        return mse_hat + qjl_hat * scale

    def inner_product(self, query: torch.Tensor, quantized: ProdQuantized) -> torch.Tensor:
        """Estimate all ``<query_i, x_j>`` without explicitly materializing all vectors."""

        self._check_input(query)
        q = query.to(dtype=self.qjl_matrix.dtype)
        if self.uses_mse_stage:
            mse_q = MSEQuantized(
                indices=quantized.mse_indices,
                norms=quantized.norms,
                bits=quantized.mse_bits,
                dim=self.dim,
            )
            mse_hat = self.mse_quantizer.dequantize(mse_q)
            mse_score = q @ mse_hat.transpose(-2, -1)
        else:
            mse_score = 0.0

        q_sketch = q @ self.qjl_matrix.T
        signs = unpack_signs(quantized.qjl_signs.to(self.device), self.dim, dtype=q.dtype)
        qjl_score = q_sketch @ signs.transpose(-2, -1)
        qjl_score = qjl_score * (
            self.qjl_scale
            * quantized.residual_norms.to(self.device, dtype=q.dtype).unsqueeze(-2)
        )
        return mse_score + qjl_score

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dequantize(self.quantize(x))
