#!/usr/bin/env python3
"""Demo script for TurboQuant with Qwen2.5-3B.

This script demonstrates the real-world usage of TurboQuant KV-cache
quantization with the Qwen2.5-3B language model.

Usage:
    python -m torbuquant.llm.demo_qwen --prompt "Explain quantum computing"
    python -m torbuquant.llm.demo_qwen --key-bits 2 --value-bits 2 --max-tokens 200
    python -m torbuquant.llm.demo_qwen --compare --prompt "Write a story about AI"
"""

from __future__ import annotations

import argparse
import sys
import time

import torch


def main():
    parser = argparse.ArgumentParser(
        description="TurboQuant demo with Qwen2.5-3B",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--model",
        type=str,
        default="Qwen/Qwen2.5-3B",
        help="HuggingFace model name (default: Qwen/Qwen2.5-3B)",
    )
    parser.add_argument(
        "--prompt",
        type=str,
        default="Explain the theory of relativity in simple terms:",
        help="Input prompt for generation",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=100,
        help="Maximum new tokens to generate (default: 100)",
    )
    parser.add_argument(
        "--key-bits",
        type=int,
        default=3,
        help="Bits for key quantization (default: 3)",
    )
    parser.add_argument(
        "--value-bits",
        type=int,
        default=3,
        help="Bits for value quantization (default: 3)",
    )
    parser.add_argument(
        "--recent-tokens",
        type=int,
        default=128,
        help="Recent tokens to keep uncompressed (default: 128)",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="Sampling temperature (default: 0.7)",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=0.9,
        help="Nucleus sampling top-p (default: 0.9)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed (default: 42)",
    )
    parser.add_argument(
        "--compare",
        action="store_true",
        help="Compare TurboQuant with standard cache",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda" if torch.cuda.is_available() else "cpu",
        help="Device (default: cuda if available)",
    )
    parser.add_argument(
        "--dtype",
        type=str,
        default="float16",
        choices=["float16", "bfloat16", "float32"],
        help="Model dtype (default: float16)",
    )
    parser.add_argument(
        "--long-context",
        action="store_true",
        help="Test with a longer context to show compression benefits",
    )
    parser.add_argument(
        "--memory-mode",
        action="store_true",
        help="Use memory-efficient mode (slower but real GPU savings)",
    )

    args = parser.parse_args()

    dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }

    print("=" * 70)
    print("TurboQuant LLM Demo with Qwen2.5-3B")
    print("=" * 70)
    print()

    if args.long_context:
        args.prompt = """Below is a comprehensive overview of machine learning concepts.

Machine learning is a subset of artificial intelligence that focuses on the development of algorithms and statistical models that enable computer systems to improve their performance on a specific task through experience. The field has seen tremendous growth in recent years, with applications ranging from image recognition to natural language processing.

Supervised learning is one of the main paradigms in machine learning. In this approach, the algorithm learns from labeled training data, inferring a function that can be used to map new inputs to outputs. Common supervised learning algorithms include linear regression, logistic regression, support vector machines, decision trees, and neural networks.

Unsupervised learning, on the other hand, deals with unlabeled data. The goal is to discover hidden patterns or structures in the data. Clustering algorithms like K-means and hierarchical clustering, as well as dimensionality reduction techniques like PCA and t-SNE, are popular unsupervised learning methods.

Reinforcement learning is another important paradigm where an agent learns to make decisions by taking actions in an environment to maximize some notion of cumulative reward. This approach has been particularly successful in game playing and robotics applications.

Deep learning, a subset of machine learning based on artificial neural networks with multiple layers, has revolutionized the field. Convolutional neural networks (CNNs) excel at image processing tasks, while recurrent neural networks (RNNs) and transformers are well-suited for sequential data like text.

The transformer architecture, introduced in the paper "Attention is All You Need," has become the foundation for modern large language models. These models use self-attention mechanisms to process input sequences in parallel, enabling them to capture long-range dependencies effectively.

Now, please continue this explanation by discussing:
"""
        args.max_tokens = 200

    cache_dequant = not args.memory_mode
    mode_str = "SPEED MODE" if cache_dequant else "MEMORY MODE"

    print(f"Model: {args.model}")
    print(f"Device: {args.device}")
    print(f"Dtype: {args.dtype}")
    print(f"Key bits: {args.key_bits}, Value bits: {args.value_bits}")
    print(f"Recent tokens (uncompressed): {args.recent_tokens}")
    print(f"Mode: {mode_str} (cache_dequant={cache_dequant})")
    if args.memory_mode:
        print("  -> REAL GPU memory savings, but slower inference")
    else:
        print("  -> Fast inference, but no GPU memory savings")
    print()

    print("Loading model and tokenizer...")
    load_start = time.perf_counter()

    from .qwen import (
        compare_generation,
        generate_with_turboquant,
        load_qwen_model,
    )

    model, tokenizer = load_qwen_model(
        model_name=args.model,
        device=args.device,
        dtype=dtype_map[args.dtype],
    )

    load_time = time.perf_counter() - load_start
    print(f"Model loaded in {load_time:.1f}s")
    print()

    if args.compare:
        print("Running comparison (TurboQuant vs Standard)...")
        print("-" * 70)
        compare_generation(
            model,
            tokenizer,
            args.prompt,
            max_new_tokens=args.max_tokens,
            key_bits=args.key_bits,
            value_bits=args.value_bits,
            recent_tokens=args.recent_tokens,
            temperature=args.temperature,
            top_p=args.top_p,
            seed=args.seed,
            verbose=True,
            cache_dequant=cache_dequant,
        )
    else:
        print(f"Prompt: {args.prompt[:100]}..." if len(args.prompt) > 100 else f"Prompt: {args.prompt}")
        print("-" * 70)

        result = generate_with_turboquant(
            model,
            tokenizer,
            args.prompt,
            max_new_tokens=args.max_tokens,
            key_bits=args.key_bits,
            value_bits=args.value_bits,
            recent_tokens=args.recent_tokens,
            temperature=args.temperature,
            top_p=args.top_p,
            seed=args.seed,
            cache_dequant=cache_dequant,
        )

        print()
        print("Generated text:")
        print("-" * 70)
        print(result.generated_text)
        print("-" * 70)
        print()
        print("Statistics:")
        print(f"  Input tokens: {result.input_tokens}")
        print(f"  Output tokens: {result.output_tokens}")
        print(f"  Generation time: {result.generation_time_seconds:.2f}s")
        print(f"  Speed: {result.tokens_per_second:.1f} tokens/second")
        print(f"  Storage compression: {result.compression_ratio:.2f}x")
        print(f"  Compressed storage: {result.compressed_memory_bytes / 1024 / 1024:.2f} MB")
        print(f"  Dense equivalent: {result.dense_memory_bytes / 1024 / 1024:.2f} MB")
        if result.gpu_memory_bytes:
            gpu_ratio = result.gpu_memory_bytes / result.dense_memory_bytes if result.dense_memory_bytes else 1.0
            print(f"  GPU memory: {result.gpu_memory_bytes / 1024 / 1024:.2f} MB ({gpu_ratio:.2f}x of dense)")
            if gpu_ratio < 1.0:
                print(f"  GPU savings: {(1-gpu_ratio)*100:.1f}%")

    print()
    print("=" * 70)
    print("Demo complete!")


if __name__ == "__main__":
    main()
