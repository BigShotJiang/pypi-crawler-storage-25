"""TurboQuant LLM integration module.

Provides KV-cache quantization for real LLM inference using the paper's
Algorithm 1 (MSE) and Algorithm 2 (inner product) quantizers.

Usage with HuggingFace Transformers:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from torbuquant.llm import TurboQuantDynamicCache

    model = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-3B")
    tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-3B")

    cache = TurboQuantDynamicCache(
        num_hidden_layers=model.config.num_hidden_layers,
        head_dim=model.config.hidden_size // model.config.num_attention_heads,
        key_bits=3,
        value_bits=3,
        device="cuda",
    )

    output = model.generate(
        input_ids,
        past_key_values=cache,
        max_new_tokens=100,
    )
"""

from .hf_cache import TurboQuantDynamicCache
from .qwen_fused import TurboQuantQwenCache, install_qwen_turboquant_attention

__all__ = [
    "TurboQuantDynamicCache",
    "TurboQuantQwenCache",
    "install_qwen_turboquant_attention",
]
