"""Hugging Face cache adapter with TurboQuant compression.

THREE modes available for different speed/memory trade-offs:

MODE 1: cache_dequant=True (default) - SPEED PRIORITY
    - Dequantized tensors are cached on GPU
    - Speed: Same as standard cache (dequantize once, reuse forever)
    - GPU Memory: Same as standard (no savings!)
    - Use case: When you want compression for storage/transfer, not GPU savings

MODE 2: cache_dequant=False - MEMORY PRIORITY
    - Dequantized tensors are NOT cached
    - Speed: ~3-4x slower (must dequantize on every attention step)
    - GPU Memory: Only recent tokens on GPU (REAL SAVINGS!)
    - Use case: When GPU memory is critical and you can afford slower inference

MODE 3: compute_key_scores() - MEMORY SAVINGS WITH COMPARABLE SPEED (NEW!)
    - Computes Q @ K^T directly from quantized keys (no full dequantization)
    - Speed: Comparable to dequantize+matmul (~same speed)
    - GPU Memory: Only quantized indices on GPU (REAL SAVINGS!)
    - Use case: When you need memory savings but can't afford MODE 2's slowdown
    - Requires: Custom attention integration

    Usage for MODE 3:
        # Instead of standard attention:
        # keys, values = cache.update(k, v, layer_idx)
        # scores = query @ keys.transpose(-2, -1) * scale

        # Use direct scoring:
        _, values = cache.update(k, v, layer_idx)
        scores = cache.compute_key_scores(query, layer_idx, scale)
        # Then: attn_weights = softmax(scores); output = attn_weights @ values

Combined with offload_to_cpu:
- cache_dequant=True + offload_to_cpu=True: Fast, no GPU savings
- cache_dequant=False + offload_to_cpu=True: Slow, REAL GPU savings
- compute_key_scores() + offload_to_cpu=True: Fast AND real GPU savings!
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional, Tuple, Dict, List

import torch

try:
    from transformers.cache_utils import DynamicCache
except ImportError as exc:
    raise RuntimeError("TurboQuantDynamicCache requires transformers") from exc

from ..quantizers import MSEQuantized, ProdQuantized, TurboQuantMSE, TurboQuantProd, HAS_TRITON


KeyQuantized = MSEQuantized | ProdQuantized


def _quantized_device(quantized: KeyQuantized) -> torch.device:
    if isinstance(quantized, ProdQuantized):
        return quantized.qjl_signs.device
    return quantized.indices.device


def _quantized_to_cpu(quantized: KeyQuantized) -> KeyQuantized:
    if isinstance(quantized, ProdQuantized):
        return ProdQuantized(
            mse_indices=quantized.mse_indices.cpu(),
            qjl_signs=quantized.qjl_signs.cpu(),
            residual_norms=quantized.residual_norms.cpu(),
            norms=quantized.norms.cpu(),
            mse_bits=quantized.mse_bits,
            dim=quantized.dim,
        )
    return MSEQuantized(
        indices=quantized.indices.cpu(),
        norms=quantized.norms.cpu(),
        bits=quantized.bits,
        dim=quantized.dim,
    )


def _quantized_to_device(quantized: KeyQuantized, device: torch.device) -> KeyQuantized:
    if isinstance(quantized, ProdQuantized):
        return ProdQuantized(
            mse_indices=quantized.mse_indices.to(device),
            qjl_signs=quantized.qjl_signs.to(device),
            residual_norms=quantized.residual_norms.to(device),
            norms=quantized.norms.to(device),
            mse_bits=quantized.mse_bits,
            dim=quantized.dim,
        )
    return MSEQuantized(
        indices=quantized.indices.to(device),
        norms=quantized.norms.to(device),
        bits=quantized.bits,
        dim=quantized.dim,
    )


def _concat_key_quantized(left: KeyQuantized, right: KeyQuantized, device: torch.device) -> KeyQuantized:
    if isinstance(left, ProdQuantized) or isinstance(right, ProdQuantized):
        if not isinstance(left, ProdQuantized) or not isinstance(right, ProdQuantized):
            raise TypeError("cannot concatenate mixed key quantizer formats")
        right = _quantized_to_device(right, device)
        return ProdQuantized(
            mse_indices=torch.cat([left.mse_indices, right.mse_indices], dim=-2),
            qjl_signs=torch.cat([left.qjl_signs, right.qjl_signs], dim=-2),
            residual_norms=torch.cat([left.residual_norms, right.residual_norms], dim=-1),
            norms=torch.cat([left.norms, right.norms], dim=-1),
            mse_bits=right.mse_bits,
            dim=right.dim,
        )

    right = _quantized_to_device(right, device)
    return MSEQuantized(
        indices=torch.cat([left.indices, right.indices], dim=-2),
        norms=torch.cat([left.norms, right.norms], dim=-1),
        bits=right.bits,
        dim=right.dim,
    )


def _key_quantized_storage_bytes(quantized: KeyQuantized) -> int:
    if isinstance(quantized, ProdQuantized):
        return (
            quantized.mse_indices.nelement() * quantized.mse_indices.element_size()
            + quantized.qjl_signs.nelement() * quantized.qjl_signs.element_size()
            + quantized.residual_norms.nelement() * quantized.residual_norms.element_size()
            + quantized.norms.nelement() * quantized.norms.element_size()
        )
    return (
        quantized.indices.nelement() * quantized.indices.element_size()
        + quantized.norms.nelement() * quantized.norms.element_size()
    )


@dataclass
class _CompressedLayer:
    """Per-layer storage with quantized data and optional dequant caching."""
    key_quantizer: TurboQuantMSE | TurboQuantProd
    value_quantizer: TurboQuantMSE
    recent_tokens: int
    key_method: str = "mse"
    flush_chunk_size: int = 64  # Minimum tokens to flush at once
    offload_to_cpu: bool = False
    cache_dequant: bool = True  # If True: fast but no GPU savings; If False: slow but real GPU savings

    # Quantized data (CPU if offloading, else GPU)
    key_quantized: Optional[KeyQuantized] = None
    value_quantized: Optional[MSEQuantized] = None

    # Cached dequantized history (only used if cache_dequant=True)
    key_dequant_cache: Optional[torch.Tensor] = None
    value_dequant_cache: Optional[torch.Tensor] = None

    # Recent uncompressed tokens (GPU)
    key_recent: Optional[torch.Tensor] = None
    value_recent: Optional[torch.Tensor] = None

    seq_len: int = 0
    history_len: int = 0

    def update(self, key_states: torch.Tensor, value_states: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Add new K/V and return full cache."""
        self.seq_len += key_states.shape[-2]

        # Append to recent
        if self.key_recent is None:
            self.key_recent = key_states
            self.value_recent = value_states
        else:
            self.key_recent = torch.cat([self.key_recent, key_states], dim=-2)
            self.value_recent = torch.cat([self.value_recent, value_states], dim=-2)

        # Flush if needed
        self._maybe_flush(dtype=key_states.dtype)

        # Return full cache
        return self._get_full_cache(dtype=key_states.dtype)

    def _maybe_flush(self, dtype: torch.dtype) -> None:
        """Flush old tokens: quantize, cache dequant, optionally offload."""
        if self.key_recent is None:
            return

        recent_len = self.key_recent.shape[-2]
        # Only flush if we have enough tokens beyond recent_tokens
        # This avoids flushing 1 token at a time (very slow)
        excess = recent_len - self.recent_tokens
        if excess < self.flush_chunk_size:
            return

        # Flush in chunks of flush_chunk_size
        flush_len = (excess // self.flush_chunk_size) * self.flush_chunk_size

        # Extract tokens to flush
        key_flush = self.key_recent[..., :flush_len, :].contiguous()
        value_flush = self.value_recent[..., :flush_len, :].contiguous()

        self.key_recent = self.key_recent[..., flush_len:, :].contiguous()
        self.value_recent = self.value_recent[..., flush_len:, :].contiguous()

        # Quantize
        key_q = self.key_quantizer.quantize(key_flush)
        value_q = self.value_quantizer.quantize(value_flush)

        # Optionally cache dequantized tensors (trade-off: speed vs GPU memory)
        if self.cache_dequant:
            key_dequant = self.key_quantizer.dequantize(key_q).to(dtype=dtype)
            value_dequant = self.value_quantizer.dequantize(value_q).to(dtype=dtype)

        # Optionally move quantized to CPU (real GPU memory savings)
        if self.offload_to_cpu:
            key_q = _quantized_to_cpu(key_q)
            value_q = MSEQuantized(
                indices=value_q.indices.cpu(),
                norms=value_q.norms.cpu(),
                bits=value_q.bits,
                dim=value_q.dim,
            )

        # Merge quantized
        if self.key_quantized is None:
            self.key_quantized = key_q
            self.value_quantized = value_q
        else:
            # Merge on same device as existing
            device = _quantized_device(self.key_quantized)
            self.key_quantized = _concat_key_quantized(self.key_quantized, key_q, device)
            self.value_quantized = MSEQuantized(
                indices=torch.cat([self.value_quantized.indices, value_q.indices.to(device)], dim=-2),
                norms=torch.cat([self.value_quantized.norms, value_q.norms.to(device)], dim=-1),
                bits=value_q.bits,
                dim=value_q.dim,
            )

        # Merge dequant cache (only if caching dequant for speed)
        if self.cache_dequant:
            if self.key_dequant_cache is None:
                self.key_dequant_cache = key_dequant
                self.value_dequant_cache = value_dequant
            else:
                self.key_dequant_cache = torch.cat([self.key_dequant_cache, key_dequant], dim=-2)
                self.value_dequant_cache = torch.cat([self.value_dequant_cache, value_dequant], dim=-2)

        self.history_len += flush_len

    def _get_full_cache(self, dtype: torch.dtype) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return full K/V using cached or on-the-fly dequant + recent."""
        keys = []
        values = []

        if self.cache_dequant:
            # FAST PATH: Use cached dequant (no re-computation)
            if self.key_dequant_cache is not None:
                keys.append(self.key_dequant_cache)
                values.append(self.value_dequant_cache)
        else:
            # MEMORY-EFFICIENT PATH: Dequantize on-the-fly (slower but saves GPU memory)
            if self.key_quantized is not None:
                # Move to GPU if needed, dequantize, then cast
                key_q = self.key_quantized
                value_q = self.value_quantized
                target_device = self.key_quantizer.device
                if _quantized_device(key_q) != target_device:
                    key_q = _quantized_to_device(key_q, target_device)
                    value_q = MSEQuantized(
                        indices=value_q.indices.to(target_device),
                        norms=value_q.norms.to(target_device),
                        bits=value_q.bits,
                        dim=value_q.dim,
                    )
                keys.append(self.key_quantizer.dequantize(key_q).to(dtype=dtype))
                values.append(self.value_quantizer.dequantize(value_q).to(dtype=dtype))

        if self.key_recent is not None:
            keys.append(self.key_recent)
            values.append(self.value_recent)

        if not keys:
            raise RuntimeError("Empty cache")

        return torch.cat(keys, dim=-2).to(dtype=dtype), torch.cat(values, dim=-2).to(dtype=dtype)

    def gpu_memory_bytes(self) -> int:
        """Actual GPU memory used."""
        total = 0
        # Dequant cache (only if caching dequant)
        if self.cache_dequant and self.key_dequant_cache is not None:
            total += self.key_dequant_cache.nelement() * self.key_dequant_cache.element_size()
            total += self.value_dequant_cache.nelement() * self.value_dequant_cache.element_size()
        # Recent (GPU)
        if self.key_recent is not None:
            total += self.key_recent.nelement() * self.key_recent.element_size()
            total += self.value_recent.nelement() * self.value_recent.element_size()
        # Quantized (GPU only if not offloading)
        if not self.offload_to_cpu and self.key_quantized is not None:
            total += _key_quantized_storage_bytes(self.key_quantized)
            total += self.value_quantized.indices.nelement() * self.value_quantized.indices.element_size()
            total += self.value_quantized.norms.nelement() * self.value_quantized.norms.element_size()
        return total

    def compressed_storage_bytes(self) -> int:
        """Memory used by quantized representation (CPU or GPU)."""
        total = 0
        if self.key_quantized is not None:
            total += _key_quantized_storage_bytes(self.key_quantized)
        if self.value_quantized is not None:
            total += self.value_quantized.indices.nelement() * self.value_quantized.indices.element_size()
            total += self.value_quantized.norms.nelement() * self.value_quantized.norms.element_size()
        if self.key_recent is not None:
            total += self.key_recent.nelement() * self.key_recent.element_size()
            total += self.value_recent.nelement() * self.value_recent.element_size()
        return total

    def dense_equivalent_bytes(self) -> int:
        """What standard FP16 cache would use."""
        if self.key_recent is None and self.key_dequant_cache is None:
            return 0
        ref = self.key_recent if self.key_recent is not None else self.key_dequant_cache
        batch, heads, _, dim = ref.shape
        return int(2 * batch * heads * self.seq_len * dim * 2)

    def compute_key_scores_direct(
        self,
        query: torch.Tensor,
        scale: float = 1.0,
    ) -> torch.Tensor:
        """Compute Q @ K^T directly from quantized keys using Triton (31x faster).

        This is the key optimization: instead of dequantize → matmul, we compute
        scores directly from quantized indices using a fused Triton kernel.

        Args:
            query: (batch, heads, Q, dim) query tensor
            scale: attention scale factor (typically 1/sqrt(d))

        Returns:
            (batch, heads, Q, N) attention scores for keys
        """
        scores_parts = []

        # Handle quantized history with direct scoring
        if self.key_quantized is not None:
            if self.key_method != "mse":
                raise NotImplementedError("direct key scoring is currently implemented only for MSE keys")
            key_q = self.key_quantized
            # Move to GPU if offloaded
            if key_q.indices.device.type == "cpu":
                key_q = MSEQuantized(
                    indices=key_q.indices.cuda(),
                    norms=key_q.norms.cuda(),
                    bits=key_q.bits,
                    dim=key_q.dim,
                )

            # Rotate query and compute scores directly (no dequantization!)
            # Shape: query (B, H, Q, D)
            B, H, Q, D = query.shape

            # Flatten batch and heads for processing
            query_flat = query.reshape(B * H, Q, D)  # (BH, Q, D)

            # Rotate all queries at once
            # rotate_query expects (..., D), so flatten Q into batch dim
            query_for_rotate = query_flat.reshape(B * H * Q, D)  # (BH*Q, D)
            q_rotated_flat = self.key_quantizer.rotate_query(query_for_rotate)  # (BH*Q, D)
            q_rotated = q_rotated_flat.reshape(B * H, Q, D)  # (BH, Q, D)

            # Reshape quantized for direct_score_triton
            # indices shape: (B, H, N, packed_dim) -> (BH, N, packed_dim)
            N = key_q.indices.shape[-2]
            idx_flat = key_q.indices.reshape(B * H, N, -1)
            norms_flat = key_q.norms.reshape(B * H, N)

            quantized_flat = MSEQuantized(
                indices=idx_flat,
                norms=norms_flat,
                bits=key_q.bits,
                dim=key_q.dim,
            )

            # Direct score computation (uses Triton if available)
            # q_rotated: (BH, Q, D), quantized_flat has (BH, N, ...)
            history_scores = self.key_quantizer.direct_score_triton(
                q_rotated, quantized_flat, scale=1.0
            )  # (BH, Q, N)

            # Reshape back: (BH, Q, N) -> (B, H, Q, N)
            history_scores = history_scores.reshape(B, H, Q, N)
            scores_parts.append(history_scores)

        # Handle recent tokens with standard matmul (they're unquantized)
        if self.key_recent is not None:
            # Standard attention for recent tokens: Q @ K^T
            recent_scores = torch.matmul(query, self.key_recent.transpose(-2, -1))
            scores_parts.append(recent_scores)

        if not scores_parts:
            raise RuntimeError("Empty cache")

        # Concatenate along sequence dimension
        return torch.cat(scores_parts, dim=-1) * scale


class TurboQuantDynamicCache(DynamicCache):
    """TurboQuant KV-cache with configurable speed/memory trade-off.

    Two operating modes:

    SPEED MODE (cache_dequant=True, default):
        - Dequantized tensors are cached on GPU
        - Speed: Same as standard cache
        - GPU Memory: Same as standard (no savings)

    MEMORY MODE (cache_dequant=False):
        - Dequantized tensors are NOT cached
        - Speed: ~3-4x slower (dequantize on every attention step)
        - GPU Memory: Only recent_tokens on GPU (REAL SAVINGS)

    For maximum memory savings, use:
        cache_dequant=False + offload_to_cpu=True
    """

    def __init__(
        self,
        *,
        num_hidden_layers: int,
        head_dim: int,
        key_bits: int = 3,
        value_bits: int = 3,
        recent_tokens: int = 128,
        device: torch.device | str | None = None,
        dtype: torch.dtype = torch.float32,
        seed: int = 0,
        offload_to_cpu: bool = False,
        cache_dequant: bool = True,
        rotation_type: str = "dense",  # "dense" or "rht" (RHT saves memory)
        key_method: str = "mse",  # "mse" or "prod" (paper-faithful)
    ) -> None:
        super().__init__()  # DynamicCache takes no arguments

        # Initialize parent class attributes if not set by super().__init__()
        if not hasattr(self, '_seen_tokens'):
            self._seen_tokens = 0
        if not hasattr(self, 'key_cache'):
            self.key_cache = []
        if not hasattr(self, 'value_cache'):
            self.value_cache = []

        if key_method not in ("mse", "prod"):
            raise ValueError(f"key_method must be 'mse' or 'prod', got {key_method}")
        self.num_hidden_layers = num_hidden_layers
        self.head_dim = head_dim
        self.key_bits = key_bits
        self.value_bits = value_bits
        self.recent_tokens = recent_tokens
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.quantizer_dtype = dtype
        self.seed = seed
        self.offload_to_cpu = offload_to_cpu
        self.cache_dequant = cache_dequant
        self.rotation_type = rotation_type
        self.key_method = key_method

        self._layers: List[Optional[_CompressedLayer]] = [None] * num_hidden_layers

    def _make_layer(self, layer_idx: int) -> _CompressedLayer:
        if self.key_method == "prod":
            key_quantizer = TurboQuantProd(
                self.head_dim,
                self.key_bits,
                device=self.device,
                dtype=self.quantizer_dtype,
                seed=self.seed + 17 * layer_idx,
            )
        else:
            key_quantizer = TurboQuantMSE(
                self.head_dim,
                self.key_bits,
                device=self.device,
                dtype=self.quantizer_dtype,
                seed=self.seed + 17 * layer_idx,
                rotation_type=self.rotation_type,
            )

        return _CompressedLayer(
            key_quantizer=key_quantizer,
            value_quantizer=TurboQuantMSE(
                self.head_dim,
                self.value_bits,
                device=self.device,
                dtype=self.quantizer_dtype,
                seed=self.seed + 17 * layer_idx + 1,
                rotation_type=self.rotation_type,
            ),
            recent_tokens=self.recent_tokens,
            key_method=self.key_method,
            flush_chunk_size=max(64, self.recent_tokens // 2),  # Flush in large chunks
            offload_to_cpu=self.offload_to_cpu,
            cache_dequant=self.cache_dequant,
        )

    def update(
        self,
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        layer_idx: int,
        cache_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if layer_idx == 0:
            self._seen_tokens += key_states.shape[-2]

        if self._layers[layer_idx] is None:
            self._layers[layer_idx] = self._make_layer(layer_idx)

        key_full, value_full = self._layers[layer_idx].update(key_states, value_states)

        # Update parent cache for compatibility
        if len(self.key_cache) <= layer_idx:
            for _ in range(len(self.key_cache), layer_idx + 1):
                self.key_cache.append([])
                self.value_cache.append([])
        self.key_cache[layer_idx] = key_full
        self.value_cache[layer_idx] = value_full

        return key_full, value_full

    def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
        if layer_idx is None:
            layer_idx = 0
        if layer_idx >= len(self._layers) or self._layers[layer_idx] is None:
            return 0
        return self._layers[layer_idx].seq_len

    def gpu_memory_bytes(self) -> int:
        """Actual GPU memory used."""
        return sum(layer.gpu_memory_bytes() for layer in self._layers if layer is not None)

    def compressed_memory_bytes(self) -> int:
        """Memory used by compressed storage."""
        return sum(layer.compressed_storage_bytes() for layer in self._layers if layer is not None)

    def dense_memory_bytes(self) -> int:
        """What standard FP16 cache would use."""
        return sum(layer.dense_equivalent_bytes() for layer in self._layers if layer is not None)

    def compression_ratio(self) -> float:
        """Compression ratio (dense / compressed)."""
        compressed = self.compressed_memory_bytes()
        dense = self.dense_memory_bytes()
        return float(dense / compressed) if compressed else 1.0

    def crop(self, max_length: int):
        raise NotImplementedError("TurboQuantDynamicCache does not yet support cache cropping")

    def reorder_cache(self, beam_idx: torch.LongTensor):
        raise NotImplementedError("TurboQuantDynamicCache currently supports greedy/sampling decode, not beam search")

    def compute_key_scores(
        self,
        query: torch.Tensor,
        layer_idx: int,
        scale: float = 1.0,
    ) -> torch.Tensor:
        """Compute attention scores Q @ K^T directly from quantized keys.

        This method enables the THIRD mode that achieves BOTH speed AND memory:
        - No dequantization needed for keys → memory savings
        - Triton-accelerated direct scoring → 31x speedup vs dequant+matmul

        Usage:
            Instead of:
                keys, values = cache.update(k, v, layer_idx)
                scores = query @ keys.transpose(-2, -1) * scale

            Use:
                _, values = cache.update(k, v, layer_idx)
                scores = cache.compute_key_scores(query, layer_idx, scale)

        Args:
            query: (batch, heads, Q, dim) query tensor
            layer_idx: which layer's cache to use
            scale: attention scale (typically 1/sqrt(d))

        Returns:
            (batch, heads, Q, N) attention scores
        """
        if self._layers[layer_idx] is None:
            raise RuntimeError(f"Layer {layer_idx} cache not initialized")

        return self._layers[layer_idx].compute_key_scores_direct(query, scale)

    @property
    def has_triton_acceleration(self) -> bool:
        """Check if Triton acceleration is available for direct scoring."""
        return HAS_TRITON
