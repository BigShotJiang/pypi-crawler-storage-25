"""Qwen2 attention patch that consumes TurboQuant-compressed KV directly.

This is intentionally separate from ``TurboQuantDynamicCache``. The HF cache
adapter must return dense tensors for compatibility, so it cannot deliver the
real TurboQuant memory path. This module patches Qwen2 attention so decode
attention reads compressed KV instead.
"""

from __future__ import annotations

import types
from dataclasses import dataclass
from typing import Literal, Optional
import os

import torch
from transformers.cache_utils import Cache

from ..fused_attention import (
    CompressedKV,
    FusedTurboQuantAttention,
    dequantize_values_uniform,
)
from ..quantizers import MSEQuantized

try:
    import triton
    import triton.language as tl
    HAS_TRITON = True
except ImportError:  # pragma: no cover - optional dependency
    HAS_TRITON = False
    triton = None
    tl = None


if HAS_TRITON:
    @triton.jit
    def _qwen_gqa_weighted_v_kernel(
        W_PTR,
        VQ_PTR, VS_PTR, VZ_PTR,
        OUT_PTR,
        QH: tl.constexpr, KVH: tl.constexpr, GROUPS: tl.constexpr,
        N: tl.constexpr, D: tl.constexpr,
        V_PACKED_D: tl.constexpr, V_BITS: tl.constexpr,
        BLOCK_N: tl.constexpr,
    ):
        pid_h = tl.program_id(0)
        b = pid_h // QH
        qh = pid_h - b * QH
        kvh = qh // GROUPS
        g = qh - kvh * GROUPS
        d = tl.arange(0, D)
        acc = tl.zeros([D], dtype=tl.float32)

        for block_start in range(0, N, BLOCK_N):
            n = block_start + tl.arange(0, BLOCK_N)
            n_mask = n < N
            w = tl.load(
                W_PTR + (((b * KVH + kvh) * GROUPS + g) * N + n),
                mask=n_mask,
                other=0.0,
            ).to(tl.float32)

            if V_BITS == 4:
                vd = d // 2
                packed_v = tl.load(
                    VQ_PTR
                    + ((b * KVH + kvh) * N + n[:, None]) * V_PACKED_D
                    + vd[None, :],
                    mask=n_mask[:, None] & ((vd < V_PACKED_D)[None, :]),
                    other=0,
                )
                v_uint = tl.where((d % 2)[None, :] == 1, (packed_v >> 4) & 0xF, packed_v & 0xF)
            elif V_BITS == 2:
                vd = d // 4
                packed_v = tl.load(
                    VQ_PTR
                    + ((b * KVH + kvh) * N + n[:, None]) * V_PACKED_D
                    + vd[None, :],
                    mask=n_mask[:, None] & ((vd < V_PACKED_D)[None, :]),
                    other=0,
                )
                shift = (d % 4) * 2
                v_uint = (packed_v >> shift[None, :]) & 0x3
            else:
                v_uint = tl.load(
                    VQ_PTR
                    + ((b * KVH + kvh) * N + n[:, None]) * V_PACKED_D
                    + d[None, :],
                    mask=n_mask[:, None],
                    other=0,
                )

            vs = tl.load(VS_PTR + (b * KVH + kvh) * N + n, mask=n_mask, other=1.0).to(tl.float32)
            vz = tl.load(VZ_PTR + (b * KVH + kvh) * N + n, mask=n_mask, other=0.0).to(tl.float32)
            v = v_uint.to(tl.float32) * vs[:, None] + vz[:, None]
            acc += tl.sum(w[:, None] * v, axis=0)

        tl.store(OUT_PTR + pid_h * D + d, acc)


def _try_weighted_v_hybrid(
    weights: torch.Tensor,
    compressed: CompressedKV,
    *,
    num_attention_heads: int,
    num_key_value_heads: int,
) -> Optional[torch.Tensor]:
    """Apply attention weights to packed compressed V without dense V materialization.

    Args:
        weights: (B, KVH, G, N) normalized attention weights for compressed history.
        compressed: compressed historical KV cache.

    Returns:
        (B, QH, 1, D) output contribution for compressed history, or None when
        the fused packed-V path is unavailable.
    """

    if not HAS_TRITON or weights.device.type != "cuda":
        return None
    if compressed.v_bits not in (2, 4, 8):
        return None
    try:
        B, KVH, G, N = weights.shape
        D = compressed.v_dim
        QH = num_attention_heads
        if KVH != num_key_value_heads or QH != KVH * G:
            return None
        w = weights.contiguous()
        vq = compressed.v_quantized.contiguous()
        vs = compressed.v_scales[..., 0].contiguous()
        vz = compressed.v_zeros[..., 0].contiguous()
        if compressed.v_bits == 8:
            v_packed_d = D
        elif compressed.v_bits == 4:
            v_packed_d = (D + 1) // 2
        else:
            v_packed_d = (D + 3) // 4
        out = torch.empty(B * QH, D, device=weights.device, dtype=torch.float16)
        _qwen_gqa_weighted_v_kernel[(B * QH,)](
            w, vq, vs, vz, out,
            QH=QH, KVH=KVH, GROUPS=G,
            N=N, D=D,
            V_PACKED_D=v_packed_d,
            V_BITS=compressed.v_bits,
            BLOCK_N=64,
        )
        return out.reshape(B, QH, 1, D)
    except RuntimeError:
        return None


if HAS_TRITON:
    @triton.jit
    def _qwen_gqa_grouped_k4_stage1_kernel(
        Q_PTR, QROT_PTR,
        KIDX_PTR, KNORM_PTR, CENT_PTR,
        VQ_PTR, VS_PTR, VZ_PTR,
        RK_PTR, RV_PTR,
        M_PTR, L_PTR, ACC_PTR,
        QH: tl.constexpr, KVH: tl.constexpr, GROUPS: tl.constexpr,
        N: tl.constexpr, R: tl.constexpr, D: tl.constexpr,
        PACKED_D: tl.constexpr, V_PACKED_D: tl.constexpr,
        K_BITS: tl.constexpr, V_BITS: tl.constexpr, SCALE: tl.constexpr,
        SPARSE_V_THRESHOLD: tl.constexpr,
        BLOCK_G: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_D_SCORE: tl.constexpr,
        NUM_BLOCKS: tl.constexpr, NUM_G_BLOCKS: tl.constexpr,
    ):
        pid_bkv = tl.program_id(0)
        pid_gblk = tl.program_id(1)
        pid_blk = tl.program_id(2)

        b = pid_bkv // KVH
        kvh = pid_bkv - b * KVH
        g = pid_gblk * BLOCK_G + tl.arange(0, BLOCK_G)
        g_mask = g < GROUPS
        qh = kvh * GROUPS + g
        pid_h = b * QH + qh

        start = pid_blk * BLOCK_N
        total = N + R
        offs = start + tl.arange(0, BLOCK_N)
        valid = offs < total
        is_hist = offs < N
        hist_n = offs
        recent_n = offs - N

        scores = tl.zeros([BLOCK_G, BLOCK_N], dtype=tl.float32)
        d = tl.arange(0, D)

        for d_start in range(0, D, BLOCK_D_SCORE):
            ds = d_start + tl.arange(0, BLOCK_D_SCORE)
            d_mask = ds < D
            if K_BITS == 16:
                q_hist = tl.load(
                    Q_PTR + pid_h[:, None] * D + ds[None, :],
                    mask=g_mask[:, None] & d_mask[None, :],
                    other=0.0,
                ).to(tl.float32)
                k_dense = tl.load(
                    KIDX_PTR
                    + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                    + ds[None, :],
                    mask=valid[:, None] & is_hist[:, None] & d_mask[None, :],
                    other=0.0,
                ).to(tl.float32)
                hist_scores = tl.sum(q_hist[:, None, :] * k_dense[None, :, :], axis=2)
            else:
                qrot = tl.load(
                    QROT_PTR + pid_h[:, None] * D + ds[None, :],
                    mask=g_mask[:, None] & d_mask[None, :],
                    other=0.0,
                ).to(tl.float32)
                if K_BITS == 4:
                    packed_d = ds // 2
                    packed = tl.load(
                        KIDX_PTR
                        + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                        + packed_d[None, :],
                        mask=valid[:, None] & is_hist[:, None] & ((packed_d < PACKED_D)[None, :]),
                        other=0,
                    )
                    idx = tl.where((ds % 2)[None, :] == 1, (packed >> 4) & 0xF, packed & 0xF)
                else:
                    idx = tl.load(
                        KIDX_PTR
                        + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                        + ds[None, :],
                        mask=valid[:, None] & is_hist[:, None] & d_mask[None, :],
                        other=0,
                    )
                cent = tl.load(CENT_PTR + idx)
                hist_scores = tl.sum(qrot[:, None, :] * cent[None, :, :], axis=2)

            qraw = tl.load(
                Q_PTR + pid_h[:, None] * D + ds[None, :],
                mask=g_mask[:, None] & d_mask[None, :],
                other=0.0,
            ).to(tl.float32)
            rk = tl.load(
                RK_PTR
                + ((b * KVH + kvh) * R + recent_n[:, None]) * D
                + ds[None, :],
                mask=valid[:, None] & (~is_hist)[:, None] & d_mask[None, :],
                other=0.0,
            ).to(tl.float32)
            recent_scores = tl.sum(qraw[:, None, :] * rk[None, :, :], axis=2)
            scores += tl.where(is_hist[None, :], hist_scores, recent_scores)

        norms = tl.load(
            KNORM_PTR + (b * KVH + kvh) * N + hist_n,
            mask=valid & is_hist,
            other=1.0,
        ).to(tl.float32)
        scores = tl.where(is_hist[None, :] & (K_BITS != 16), scores * norms[None, :], scores)
        scores = tl.where(valid[None, :] & g_mask[:, None], scores * SCALE, float("-inf"))

        m = tl.max(scores, axis=1)
        p = tl.exp(scores - m[:, None])
        l = tl.sum(p, axis=1)
        p_acc = tl.where(p >= SPARSE_V_THRESHOLD, p, 0.0)
        active_v = tl.max(p_acc, axis=0) > 0.0

        if V_BITS == 4:
            vd = d // 2
            packed_v = tl.load(
                VQ_PTR
                + ((b * KVH + kvh) * N + hist_n[:, None]) * V_PACKED_D
                + vd[None, :],
                mask=valid[:, None] & is_hist[:, None] & active_v[:, None] & ((vd < V_PACKED_D)[None, :]),
                other=0,
            )
            hist_v_uint = tl.where((d % 2)[None, :] == 1, (packed_v >> 4) & 0xF, packed_v & 0xF)
        else:
            hist_v_uint = tl.load(
                VQ_PTR
                + ((b * KVH + kvh) * N + hist_n[:, None]) * V_PACKED_D
                + d[None, :],
                mask=valid[:, None] & is_hist[:, None] & active_v[:, None],
                other=0,
            )
        vs = tl.load(VS_PTR + (b * KVH + kvh) * N + hist_n, mask=valid & is_hist, other=1.0).to(tl.float32)
        vz = tl.load(VZ_PTR + (b * KVH + kvh) * N + hist_n, mask=valid & is_hist, other=0.0).to(tl.float32)
        hist_v = hist_v_uint.to(tl.float32) * vs[:, None] + vz[:, None]
        recent_v = tl.load(
            RV_PTR
            + ((b * KVH + kvh) * R + recent_n[:, None]) * D
            + d[None, :],
            mask=valid[:, None] & (~is_hist)[:, None] & active_v[:, None],
            other=0.0,
        ).to(tl.float32)
        v = tl.where(is_hist[:, None], hist_v, recent_v)
        acc = tl.sum(p_acc[:, :, None] * v[None, :, :], axis=1)

        tl.store(M_PTR + pid_h * NUM_BLOCKS + pid_blk, m, mask=g_mask)
        tl.store(L_PTR + pid_h * NUM_BLOCKS + pid_blk, l, mask=g_mask)
        tl.store(
            ACC_PTR + (pid_h[:, None] * NUM_BLOCKS + pid_blk) * D + d[None, :],
            acc,
            mask=g_mask[:, None],
        )


    @triton.jit
    def _qwen_gqa_hybrid_k4_stage1_kernel(
        Q_PTR, QROT_PTR,
        KIDX_PTR, KNORM_PTR, CENT_PTR,
        VQ_PTR, VS_PTR, VZ_PTR,
        RK_PTR, RV_PTR,
        M_PTR, L_PTR, ACC_PTR,
        QH: tl.constexpr, KVH: tl.constexpr, GROUPS: tl.constexpr,
        N: tl.constexpr, R: tl.constexpr, D: tl.constexpr,
        PACKED_D: tl.constexpr, V_PACKED_D: tl.constexpr,
        K_BITS: tl.constexpr, V_BITS: tl.constexpr, SCALE: tl.constexpr,
        SPARSE_V_THRESHOLD: tl.constexpr,
        BLOCK_N: tl.constexpr, BLOCK_D_SCORE: tl.constexpr,
        NUM_BLOCKS: tl.constexpr,
    ):
        pid_h = tl.program_id(0)
        pid_blk = tl.program_id(1)
        b = pid_h // QH
        qh = pid_h - b * QH
        kvh = qh // GROUPS

        start = pid_blk * BLOCK_N
        total = N + R
        offs = start + tl.arange(0, BLOCK_N)
        valid = offs < total
        is_hist = offs < N
        hist_n = offs
        recent_n = offs - N

        scores = tl.zeros([BLOCK_N], dtype=tl.float32)
        d = tl.arange(0, D)

        for d_start in range(0, D, BLOCK_D_SCORE):
            ds = d_start + tl.arange(0, BLOCK_D_SCORE)
            d_mask = ds < D
            if K_BITS == 16:
                q = tl.load(
                    Q_PTR + (b * QH + qh) * D + ds,
                    mask=d_mask,
                    other=0.0,
                ).to(tl.float32)
                k_dense = tl.load(
                    KIDX_PTR
                    + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                    + ds[None, :],
                    mask=valid[:, None] & is_hist[:, None] & d_mask[None, :],
                    other=0.0,
                ).to(tl.float32)
                hist_scores = tl.sum(q[None, :] * k_dense, axis=1)
            else:
                q = tl.load(
                    QROT_PTR + (b * QH + qh) * D + ds,
                    mask=d_mask,
                    other=0.0,
                ).to(tl.float32)
                if K_BITS == 4:
                    packed_d = ds // 2
                    packed = tl.load(
                        KIDX_PTR
                        + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                        + packed_d[None, :],
                        mask=valid[:, None] & is_hist[:, None] & ((packed_d < PACKED_D)[None, :]),
                        other=0,
                    )
                    idx = tl.where((ds % 2)[None, :] == 1, (packed >> 4) & 0xF, packed & 0xF)
                else:
                    idx = tl.load(
                        KIDX_PTR
                        + ((b * KVH + kvh) * N + hist_n[:, None]) * PACKED_D
                        + ds[None, :],
                        mask=valid[:, None] & is_hist[:, None] & d_mask[None, :],
                        other=0,
                    )
                cent = tl.load(CENT_PTR + idx)
                hist_scores = tl.sum(q[None, :] * cent, axis=1)

            q_raw = tl.load(
                Q_PTR + (b * QH + qh) * D + ds,
                mask=d_mask,
                other=0.0,
            ).to(tl.float32)
            rk = tl.load(
                RK_PTR
                + ((b * KVH + kvh) * R + recent_n[:, None]) * D
                + ds[None, :],
                mask=valid[:, None] & (~is_hist)[:, None] & d_mask[None, :],
                other=0.0,
            ).to(tl.float32)
            recent_scores = tl.sum(q_raw[None, :] * rk, axis=1)
            scores += tl.where(is_hist, hist_scores, recent_scores)

        norms = tl.load(
            KNORM_PTR + (b * KVH + kvh) * N + hist_n,
            mask=valid & is_hist,
            other=1.0,
        ).to(tl.float32)
        scores = tl.where(is_hist & (K_BITS != 16), scores * norms, scores)
        scores = tl.where(valid, scores * SCALE, float("-inf"))

        m = tl.max(scores, axis=0)
        p = tl.exp(scores - m)
        l = tl.sum(p, axis=0)
        p_acc = tl.where(p >= SPARSE_V_THRESHOLD, p, 0.0)
        active_v = p_acc > 0.0

        if V_BITS == 4:
            vd = d // 2
            packed_v = tl.load(
                VQ_PTR
                + ((b * KVH + kvh) * N + hist_n[:, None]) * V_PACKED_D
                + vd[None, :],
                mask=valid[:, None] & is_hist[:, None] & active_v[:, None] & ((vd < V_PACKED_D)[None, :]),
                other=0,
            )
            hist_v_uint = tl.where((d % 2)[None, :] == 1, (packed_v >> 4) & 0xF, packed_v & 0xF)
        else:
            hist_v_uint = tl.load(
                VQ_PTR
                + ((b * KVH + kvh) * N + hist_n[:, None]) * V_PACKED_D
                + d[None, :],
                mask=valid[:, None] & is_hist[:, None] & active_v[:, None],
                other=0,
            )
        vs = tl.load(VS_PTR + (b * KVH + kvh) * N + hist_n, mask=valid & is_hist, other=1.0).to(tl.float32)
        vz = tl.load(VZ_PTR + (b * KVH + kvh) * N + hist_n, mask=valid & is_hist, other=0.0).to(tl.float32)
        hist_v = hist_v_uint.to(tl.float32) * vs[:, None] + vz[:, None]

        recent_v = tl.load(
            RV_PTR
            + ((b * KVH + kvh) * R + recent_n[:, None]) * D
            + d[None, :],
            mask=valid[:, None] & (~is_hist)[:, None] & active_v[:, None],
            other=0.0,
        ).to(tl.float32)
        v = tl.where(is_hist[:, None], hist_v, recent_v)
        acc = tl.sum(p_acc[:, None] * v, axis=0)

        tl.store(M_PTR + pid_h * NUM_BLOCKS + pid_blk, m)
        tl.store(L_PTR + pid_h * NUM_BLOCKS + pid_blk, l)
        tl.store(ACC_PTR + (pid_h * NUM_BLOCKS + pid_blk) * D + d, acc)


    @triton.jit
    def _qwen_gqa_hybrid_k4_stage2_kernel(
        M_PTR, L_PTR, ACC_PTR, OUT_PTR,
        D: tl.constexpr, NUM_BLOCKS: tl.constexpr, BLOCK_B: tl.constexpr,
    ):
        pid_h = tl.program_id(0)
        d = tl.arange(0, D)
        b = tl.arange(0, BLOCK_B)
        m = tl.full([1], float("-inf"), dtype=tl.float32)
        for block_start in range(0, NUM_BLOCKS, BLOCK_B):
            bb = block_start + b
            bb_mask = bb < NUM_BLOCKS
            mb = tl.load(M_PTR + pid_h * NUM_BLOCKS + bb, mask=bb_mask, other=float("-inf")).to(tl.float32)
            m = tl.maximum(m, tl.max(mb, axis=0))

        l = tl.zeros([1], dtype=tl.float32)
        acc = tl.zeros([D], dtype=tl.float32)
        for block_start in range(0, NUM_BLOCKS, BLOCK_B):
            bb = block_start + b
            bb_mask = bb < NUM_BLOCKS
            mb = tl.load(M_PTR + pid_h * NUM_BLOCKS + bb, mask=bb_mask, other=float("-inf")).to(tl.float32)
            lb = tl.load(L_PTR + pid_h * NUM_BLOCKS + bb, mask=bb_mask, other=0.0).to(tl.float32)
            alpha = tl.exp(mb - m)
            l += tl.sum(alpha * lb, axis=0)
            part = tl.load(
                ACC_PTR + (pid_h * NUM_BLOCKS + bb[:, None]) * D + d[None, :],
                mask=bb_mask[:, None],
                other=0.0,
            ).to(tl.float32)
            acc += tl.sum(alpha[:, None] * part, axis=0)

        out = acc / tl.maximum(l, 1e-9)
        tl.store(OUT_PTR + pid_h * D + d, out)


    @triton.jit
    def _qwen_gqa_hybrid_k4_kernel(
        Q_PTR, QROT_PTR,
        KIDX_PTR, KNORM_PTR, CENT_PTR,
        VQ_PTR, VS_PTR, VZ_PTR,
        RK_PTR, RV_PTR,
        OUT_PTR,
        QH: tl.constexpr, KVH: tl.constexpr, GROUPS: tl.constexpr,
        N: tl.constexpr, R: tl.constexpr, D: tl.constexpr,
        PACKED_D: tl.constexpr, V_PACKED_D: tl.constexpr,
        K_BITS: tl.constexpr, V_BITS: tl.constexpr, SCALE: tl.constexpr,
        SPARSE_V_THRESHOLD: tl.constexpr,
        BLOCK_N: tl.constexpr, BLOCK_D_SCORE: tl.constexpr,
    ):
        pid = tl.program_id(0)
        b = pid // QH
        qh = pid - b * QH
        kvh = qh // GROUPS

        d = tl.arange(0, D)
        acc = tl.zeros([D], dtype=tl.float32)
        m = tl.full([1], float("-inf"), dtype=tl.float32)
        l = tl.zeros([1], dtype=tl.float32)

        for block_start in range(0, N, BLOCK_N):
            n = block_start + tl.arange(0, BLOCK_N)
            n_mask = n < N
            scores = tl.zeros([BLOCK_N], dtype=tl.float32)

            norms = tl.load(
                KNORM_PTR + (b * KVH + kvh) * N + n,
                mask=n_mask,
                other=0.0,
            ).to(tl.float32)

            for d_start in range(0, D, BLOCK_D_SCORE):
                ds = d_start + tl.arange(0, BLOCK_D_SCORE)
                d_mask = ds < D
                if K_BITS == 16:
                    q = tl.load(
                        Q_PTR + (b * QH + qh) * D + ds,
                        mask=d_mask,
                        other=0.0,
                    ).to(tl.float32)
                    k_dense = tl.load(
                        KIDX_PTR
                        + ((b * KVH + kvh) * N + n[:, None]) * PACKED_D
                        + ds[None, :],
                        mask=n_mask[:, None] & d_mask[None, :],
                        other=0.0,
                    ).to(tl.float32)
                    scores += tl.sum(q[None, :] * k_dense, axis=1)
                else:
                    q = tl.load(
                        QROT_PTR + (b * QH + qh) * D + ds,
                        mask=d_mask,
                        other=0.0,
                    ).to(tl.float32)
                    if K_BITS == 4:
                        packed_d = ds // 2
                        packed = tl.load(
                            KIDX_PTR
                            + ((b * KVH + kvh) * N + n[:, None]) * PACKED_D
                            + packed_d[None, :],
                            mask=n_mask[:, None] & ((packed_d < PACKED_D)[None, :]),
                            other=0,
                        )
                        idx = tl.where((ds % 2)[None, :] == 1, (packed >> 4) & 0xF, packed & 0xF)
                    else:
                        idx = tl.load(
                            KIDX_PTR
                            + ((b * KVH + kvh) * N + n[:, None]) * PACKED_D
                            + ds[None, :],
                            mask=n_mask[:, None] & d_mask[None, :],
                            other=0,
                        )
                    cent = tl.load(CENT_PTR + idx)
                    scores += tl.sum(q[None, :] * cent, axis=1)

            scores = tl.where(K_BITS == 16, scores * SCALE, scores * norms * SCALE)

            if V_BITS == 4:
                vd = d // 2
                packed_v = tl.load(
                    VQ_PTR
                    + ((b * KVH + kvh) * N + n[:, None]) * V_PACKED_D
                    + vd[None, :],
                    mask=n_mask[:, None] & ((vd < V_PACKED_D)[None, :]),
                    other=0,
                )
                v_uint = tl.where((d % 2)[None, :] == 1, (packed_v >> 4) & 0xF, packed_v & 0xF)
            else:
                v_uint = tl.load(
                    VQ_PTR
                    + ((b * KVH + kvh) * N + n[:, None]) * V_PACKED_D
                    + d[None, :],
                    mask=n_mask[:, None],
                    other=0,
                )
            vs = tl.load(VS_PTR + (b * KVH + kvh) * N + n, mask=n_mask, other=1.0).to(tl.float32)
            vz = tl.load(VZ_PTR + (b * KVH + kvh) * N + n, mask=n_mask, other=0.0).to(tl.float32)
            v = v_uint.to(tl.float32) * vs[:, None] + vz[:, None]

            block_max = tl.max(scores, axis=0)
            m_new = tl.maximum(m, block_max)
            alpha = tl.exp(m - m_new)
            beta = tl.exp(scores - m_new)
            l = alpha * l + tl.sum(beta, axis=0)
            beta_acc = tl.where(beta >= SPARSE_V_THRESHOLD, beta, 0.0)
            acc = alpha * acc + tl.sum(beta_acc[:, None] * v, axis=0)
            m = m_new

        for block_start in range(0, R, BLOCK_N):
            n = block_start + tl.arange(0, BLOCK_N)
            n_mask = n < R
            scores = tl.zeros([BLOCK_N], dtype=tl.float32)

            for d_start in range(0, D, BLOCK_D_SCORE):
                ds = d_start + tl.arange(0, BLOCK_D_SCORE)
                d_mask = ds < D
                q = tl.load(Q_PTR + (b * QH + qh) * D + ds, mask=d_mask, other=0.0).to(tl.float32)
                k = tl.load(
                    RK_PTR
                    + ((b * KVH + kvh) * R + n[:, None]) * D
                    + ds[None, :],
                    mask=n_mask[:, None] & d_mask[None, :],
                    other=0.0,
                ).to(tl.float32)
                scores += tl.sum(q[None, :] * k, axis=1)

            scores = scores * SCALE
            v = tl.load(
                RV_PTR
                + ((b * KVH + kvh) * R + n[:, None]) * D
                + d[None, :],
                mask=n_mask[:, None],
                other=0.0,
            ).to(tl.float32)

            block_max = tl.max(scores, axis=0)
            m_new = tl.maximum(m, block_max)
            alpha = tl.exp(m - m_new)
            beta = tl.exp(scores - m_new)
            l = alpha * l + tl.sum(beta, axis=0)
            beta_acc = tl.where(beta >= SPARSE_V_THRESHOLD, beta, 0.0)
            acc = alpha * acc + tl.sum(beta_acc[:, None] * v, axis=0)
            m = m_new

        out = acc / tl.maximum(l, 1e-9)
        tl.store(OUT_PTR + (b * QH + qh) * D + d, out)


def _try_fused_gqa_hybrid(
    query_states: torch.Tensor,
    query_rotated: torch.Tensor,
    compressed: CompressedKV,
    recent_k: torch.Tensor,
    recent_v: torch.Tensor,
    centroids: torch.Tensor,
    *,
    num_attention_heads: int,
    num_key_value_heads: int,
    groups: int,
    scale: float,
    sparse_v_threshold: float,
) -> Optional[tuple[torch.Tensor, Literal["single_pass", "two_stage"]]]:
    if not HAS_TRITON or query_states.device.type != "cuda":
        return None
    B, QH, _, D = query_states.shape
    if compressed.k_bits not in (4, 8, 16) or compressed.v_bits not in (4, 8):
        return None
    try:
        q = query_states.squeeze(2).contiguous()
        qrot = query_rotated.reshape(B, QH, D).contiguous()
        kidx = compressed.k_indices.contiguous()
        knorm = compressed.k_norms.contiguous()
        vq = compressed.v_quantized.contiguous()
        vs = compressed.v_scales[..., 0].contiguous()
        vz = compressed.v_zeros[..., 0].contiguous()
        rk = recent_k.contiguous()
        rv = recent_v.contiguous()
        N = kidx.shape[-2]
        R = rk.shape[-2]
        block_n = 64
        num_blocks = triton.cdiv(N + R, block_n)
        out = torch.empty(B, QH, D, device=query_states.device, dtype=query_states.dtype)
        v_packed_d = D if compressed.v_bits == 8 else (D + 1) // 2
        single_pass_limit = int(os.environ.get("TORBUQUANT_GQA_SINGLE_PASS_MAX_TOKENS", "4096"))
        use_single_pass = (
            os.environ.get("TORBUQUANT_GQA_FORCE_TWO_STAGE") != "1"
            and os.environ.get("TORBUQUANT_EXPERIMENTAL_GQA_GROUPED") != "1"
            and N + R <= single_pass_limit
        )
        if use_single_pass:
            _qwen_gqa_hybrid_k4_kernel[(B * QH,)](
                q, qrot,
                kidx, knorm, centroids,
                vq, vs, vz,
                rk, rv,
                out,
                QH=num_attention_heads, KVH=num_key_value_heads, GROUPS=groups,
                N=N, R=R, D=D,
                PACKED_D=kidx.shape[-1], V_PACKED_D=v_packed_d,
                K_BITS=compressed.k_bits,
                V_BITS=compressed.v_bits,
                SCALE=scale,
                SPARSE_V_THRESHOLD=sparse_v_threshold,
                BLOCK_N=block_n,
                BLOCK_D_SCORE=min(64, D),
            )
            return out.unsqueeze(2), "single_pass"

        scratch_m = torch.empty(B * QH, num_blocks, device=query_states.device, dtype=torch.float32)
        scratch_l = torch.empty(B * QH, num_blocks, device=query_states.device, dtype=torch.float32)
        scratch_acc = torch.empty(B * QH, num_blocks, D, device=query_states.device, dtype=torch.float32)
        if os.environ.get("TORBUQUANT_EXPERIMENTAL_GQA_GROUPED") == "1":
            block_g = 2
            num_g_blocks = triton.cdiv(groups, block_g)
            _qwen_gqa_grouped_k4_stage1_kernel[(B * num_key_value_heads, num_g_blocks, num_blocks)](
                q, qrot,
                kidx, knorm, centroids,
                vq, vs, vz,
                rk, rv,
                scratch_m, scratch_l, scratch_acc,
                QH=num_attention_heads, KVH=num_key_value_heads, GROUPS=groups,
                N=N, R=R, D=D,
                PACKED_D=kidx.shape[-1], V_PACKED_D=v_packed_d,
                K_BITS=compressed.k_bits,
                V_BITS=compressed.v_bits,
                SCALE=scale,
                SPARSE_V_THRESHOLD=sparse_v_threshold,
                BLOCK_G=block_g,
                BLOCK_N=block_n,
                BLOCK_D_SCORE=min(64, D),
                NUM_BLOCKS=num_blocks,
                NUM_G_BLOCKS=num_g_blocks,
            )
        else:
            _qwen_gqa_hybrid_k4_stage1_kernel[(B * QH, num_blocks)](
                q, qrot,
                kidx, knorm, centroids,
                vq, vs, vz,
                rk, rv,
                scratch_m, scratch_l, scratch_acc,
                QH=num_attention_heads, KVH=num_key_value_heads, GROUPS=groups,
                N=N, R=R, D=D,
                PACKED_D=kidx.shape[-1], V_PACKED_D=v_packed_d,
                K_BITS=compressed.k_bits,
                V_BITS=compressed.v_bits,
                SCALE=scale,
                SPARSE_V_THRESHOLD=sparse_v_threshold,
                BLOCK_N=block_n,
                BLOCK_D_SCORE=min(64, D),
                NUM_BLOCKS=num_blocks,
            )
        _qwen_gqa_hybrid_k4_stage2_kernel[(B * QH,)](
            scratch_m, scratch_l, scratch_acc, out,
            D=D, NUM_BLOCKS=num_blocks,
            BLOCK_B=min(128, triton.next_power_of_2(num_blocks)),
        )
        return out.unsqueeze(2), "two_stage"
    except RuntimeError:
        return None


@dataclass
class _LayerState:
    attention: FusedTurboQuantAttention
    key_bits: int
    value_bits: int
    compressed: Optional[CompressedKV] = None
    recent_k: Optional[torch.Tensor] = None
    recent_v: Optional[torch.Tensor] = None
    seq_len: int = 0


def _concat_compressed(left: CompressedKV, right: CompressedKV) -> CompressedKV:
    if left.k_bits != right.k_bits or left.v_bits != right.v_bits:
        raise ValueError("cannot concatenate compressed KV with different bit widths")
    if left.k_dim != right.k_dim or left.v_dim != right.v_dim:
        raise ValueError("cannot concatenate compressed KV with different dimensions")
    return CompressedKV(
        k_indices=torch.cat([left.k_indices, right.k_indices], dim=-2),
        k_norms=torch.cat([left.k_norms, right.k_norms], dim=-1),
        k_bits=left.k_bits,
        k_dim=left.k_dim,
        v_quantized=torch.cat([left.v_quantized, right.v_quantized], dim=-2),
        v_scales=torch.cat([left.v_scales, right.v_scales], dim=-2),
        v_zeros=torch.cat([left.v_zeros, right.v_zeros], dim=-2),
        v_bits=left.v_bits,
        v_group_size=left.v_group_size,
        v_dim=left.v_dim,
        seq_len=left.seq_len + right.seq_len,
    )


def _repeat_compressed_for_gqa(compressed: CompressedKV, repeats: int) -> CompressedKV:
    if repeats == 1:
        return compressed
    return CompressedKV(
        k_indices=compressed.k_indices.repeat_interleave(repeats, dim=1),
        k_norms=compressed.k_norms.repeat_interleave(repeats, dim=1),
        k_bits=compressed.k_bits,
        k_dim=compressed.k_dim,
        v_quantized=compressed.v_quantized.repeat_interleave(repeats, dim=1),
        v_scales=compressed.v_scales.repeat_interleave(repeats, dim=1),
        v_zeros=compressed.v_zeros.repeat_interleave(repeats, dim=1),
        v_bits=compressed.v_bits,
        v_group_size=compressed.v_group_size,
        v_dim=compressed.v_dim,
        seq_len=compressed.seq_len,
    )


class TurboQuantQwenCache(Cache):
    """Compressed KV cache for patched Qwen2 attention.

    The cache never returns dense K/V tensors during the patched path. Prefill is
    computed exactly by Qwen attention, then K/V are compressed. Decode appends
    the current token in compressed form and calls fused TurboQuant attention.
    """

    def __init__(
        self,
        *,
        num_hidden_layers: int,
        head_dim: int,
        num_attention_heads: int,
        num_key_value_heads: int,
        key_bits: int = 4,
        value_bits: int = 4,
        boundary_value_bits: int | None = None,
        boundary_layers: int = 0,
        recent_tokens: int = 128,
        sparse_v_threshold: float = 0.0,
        require_fused_attention: bool = True,
        rotation_type: str = "rht",
        device: torch.device | str | None = None,
        dtype: torch.dtype = torch.float32,
        seed: int = 0,
    ) -> None:
        super().__init__()
        if key_bits not in (2, 4, 8, 16):
            raise ValueError("patched Qwen fused path currently supports key_bits=2, 4, 8, or 16")
        if value_bits not in (2, 4, 8):
            raise ValueError("patched Qwen fused path currently supports value_bits=2, 4, or 8")
        if boundary_value_bits is not None and boundary_value_bits not in (2, 4, 8):
            raise ValueError("boundary_value_bits must be 2, 4, 8, or None")
        if boundary_layers < 0:
            raise ValueError("boundary_layers must be >= 0")
        if sparse_v_threshold != 0.0:
            raise ValueError(
                "sparse_v_threshold is not production-enabled yet; "
                "the current kernels must first implement globally normalized sparse V skipping."
            )
        self.num_hidden_layers = num_hidden_layers
        self.head_dim = head_dim
        self.num_attention_heads = num_attention_heads
        self.num_key_value_heads = num_key_value_heads
        self.num_key_value_groups = num_attention_heads // num_key_value_heads
        self.key_bits = key_bits
        self.value_bits = value_bits
        self.boundary_value_bits = boundary_value_bits
        self.boundary_layers = boundary_layers
        self.recent_tokens = recent_tokens
        self.sparse_v_threshold = float(sparse_v_threshold)
        self.require_fused_attention = require_fused_attention
        self.flush_chunk_size = max(64, recent_tokens // 2) if recent_tokens > 0 else 1
        self.rotation_type = rotation_type
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.dtype = dtype
        self.seed = seed
        self._seen_tokens = 0
        self.layers: list[Optional[_LayerState]] = [None] * num_hidden_layers
        self.fused_attention_calls = 0
        self.fused_weighted_v_calls = 0
        self.fused_single_pass_calls = 0
        self.fused_two_stage_calls = 0
        self.dense_fallback_calls = 0

    def _value_bits_for_layer(self, layer_idx: int) -> int:
        if self.boundary_value_bits is None or self.boundary_layers <= 0:
            return self.value_bits
        if layer_idx < self.boundary_layers:
            return self.boundary_value_bits
        if layer_idx >= self.num_hidden_layers - self.boundary_layers:
            return self.boundary_value_bits
        return self.value_bits

    def _make_layer(self, layer_idx: int) -> _LayerState:
        value_bits = self._value_bits_for_layer(layer_idx)
        return _LayerState(
            attention=FusedTurboQuantAttention(
                self.head_dim,
                k_bits=self.key_bits,
                v_bits=value_bits,
                rotation_type=self.rotation_type,
                device=self.device,
                dtype=self.dtype,
                metadata_dtype=torch.float16,
                seed=self.seed + 17 * layer_idx,
            ),
            key_bits=self.key_bits,
            value_bits=value_bits,
        )

    def _layer(self, layer_idx: int) -> _LayerState:
        layer = self.layers[layer_idx]
        if layer is None:
            layer = self._make_layer(layer_idx)
            self.layers[layer_idx] = layer
        return layer

    def append(self, key_states: torch.Tensor, value_states: torch.Tensor, layer_idx: int) -> None:
        layer = self._layer(layer_idx)
        if self.recent_tokens <= 0:
            chunk = layer.attention.quantize_kv(key_states.contiguous(), value_states.contiguous())
            layer.compressed = chunk if layer.compressed is None else _concat_compressed(layer.compressed, chunk)
        else:
            if layer.recent_k is None:
                layer.recent_k = key_states.contiguous()
                layer.recent_v = value_states.contiguous()
            else:
                layer.recent_k = torch.cat([layer.recent_k, key_states], dim=-2).contiguous()
                layer.recent_v = torch.cat([layer.recent_v, value_states], dim=-2).contiguous()

            excess = layer.recent_k.shape[-2] - self.recent_tokens
            if excess >= self.flush_chunk_size:
                flush_len = (excess // self.flush_chunk_size) * self.flush_chunk_size
                key_flush = layer.recent_k[..., :flush_len, :].contiguous()
                value_flush = layer.recent_v[..., :flush_len, :].contiguous()
                layer.recent_k = layer.recent_k[..., flush_len:, :].contiguous()
                layer.recent_v = layer.recent_v[..., flush_len:, :].contiguous()
                chunk = layer.attention.quantize_kv(key_flush, value_flush)
                layer.compressed = chunk if layer.compressed is None else _concat_compressed(layer.compressed, chunk)
        layer.seq_len += key_states.shape[-2]
        if layer_idx == 0:
            self._seen_tokens += key_states.shape[-2]

    def attend(self, query_states: torch.Tensor, layer_idx: int, scale: float) -> torch.Tensor:
        layer = self._layer(layer_idx)
        if layer.compressed is None and layer.recent_k is None:
            raise RuntimeError(f"layer {layer_idx} has no KV")
        if layer.compressed is not None and layer.compressed.k_bits == 16:
            return self._attend_hybrid(query_states, layer, scale)
        if layer.recent_k is None:
            compressed = _repeat_compressed_for_gqa(layer.compressed, self.num_key_value_groups)
            return layer.attention(query_states, compressed, scale=scale)
        return self._attend_hybrid(query_states, layer, scale)

    def _attend_hybrid(self, query_states: torch.Tensor, layer: _LayerState, scale: float) -> torch.Tensor:
        B, QH, Q, D = query_states.shape
        if Q != 1:
            raise ValueError("TurboQuantQwenCache hybrid attention only supports decode Q=1")
        KVH = self.num_key_value_heads
        G = self.num_key_value_groups
        q_group = query_states.squeeze(2).reshape(B, KVH, G, D)

        score_parts = []
        value_parts = []
        recent_k = layer.recent_k
        recent_v = layer.recent_v
        if recent_k is None:
            recent_k = torch.empty(B, KVH, 0, D, device=query_states.device, dtype=query_states.dtype)
            recent_v = torch.empty(B, KVH, 0, D, device=query_states.device, dtype=query_states.dtype)

        if layer.compressed is not None:
            compressed = layer.compressed
            if compressed.k_bits == 16:
                q_rot = q_group
                centroids = torch.empty(0, device=query_states.device, dtype=torch.float32)
                if os.environ.get("TORBUQUANT_DISABLE_WEIGHTED_V_KERNEL") != "1":
                    hist_scores = torch.einsum("bkgd,bknd->bkgn", q_group, compressed.k_indices) * scale
                    if recent_k.shape[-2] > 0:
                        recent_scores = torch.einsum("bkgd,bknd->bkgn", q_group, recent_k) * scale
                        all_scores = torch.cat([hist_scores, recent_scores], dim=-1)
                    else:
                        all_scores = hist_scores
                    weights = torch.softmax(all_scores, dim=-1, dtype=torch.float32).to(query_states.dtype)
                    hist_weights = weights[..., : compressed.seq_len]
                    hist_out = _try_weighted_v_hybrid(
                        hist_weights,
                        compressed,
                        num_attention_heads=self.num_attention_heads,
                        num_key_value_heads=self.num_key_value_heads,
                    )
                    if hist_out is not None:
                        if recent_k.shape[-2] > 0:
                            recent_weights = weights[..., compressed.seq_len :]
                            recent_out = torch.einsum("bkgn,bknd->bkgd", recent_weights, recent_v)
                            hist_out = hist_out + recent_out.reshape(B, QH, 1, D)
                        self.fused_weighted_v_calls += 1
                        return hist_out.to(dtype=query_states.dtype)
            else:
                q_rot = layer.attention.k_quantizer.rotate_query(q_group.reshape(-1, D)).reshape(B, KVH, G, D)
                centroids = layer.attention.k_quantizer.centroids
                if os.environ.get("TORBUQUANT_DISABLE_WEIGHTED_V_KERNEL") != "1":
                    key_q = MSEQuantized(
                        indices=compressed.k_indices,
                        norms=compressed.k_norms,
                        bits=compressed.k_bits,
                        dim=compressed.k_dim,
                    )
                    try:
                        hist_scores = layer.attention.k_quantizer.direct_score_triton(q_rot, key_q, scale=scale)
                    except RuntimeError:
                        hist_scores = layer.attention.k_quantizer.direct_score(q_rot, key_q, scale=scale)
                    if recent_k.shape[-2] > 0:
                        recent_scores = torch.einsum("bkgd,bknd->bkgn", q_group, recent_k) * scale
                        all_scores = torch.cat([hist_scores, recent_scores], dim=-1)
                    else:
                        all_scores = hist_scores
                    weights = torch.softmax(all_scores, dim=-1, dtype=torch.float32).to(query_states.dtype)
                    hist_weights = weights[..., : compressed.seq_len]
                    hist_out = _try_weighted_v_hybrid(
                        hist_weights,
                        compressed,
                        num_attention_heads=self.num_attention_heads,
                        num_key_value_heads=self.num_key_value_heads,
                    )
                    if hist_out is not None:
                        if recent_k.shape[-2] > 0:
                            recent_weights = weights[..., compressed.seq_len :]
                            recent_out = torch.einsum("bkgn,bknd->bkgd", recent_weights, recent_v)
                            hist_out = hist_out + recent_out.reshape(B, QH, 1, D)
                        self.fused_weighted_v_calls += 1
                        return hist_out.to(dtype=query_states.dtype)
            if os.environ.get("TORBUQUANT_DISABLE_GQA_KERNEL") != "1":
                fused = _try_fused_gqa_hybrid(
                    query_states,
                    q_rot.reshape(B, QH, D),
                    compressed,
                    recent_k,
                    recent_v,
                    centroids,
                    num_attention_heads=self.num_attention_heads,
                    num_key_value_heads=self.num_key_value_heads,
                    groups=self.num_key_value_groups,
                    scale=scale,
                    sparse_v_threshold=self.sparse_v_threshold,
                )
                if fused is not None:
                    fused_out, kernel_mode = fused
                    self.fused_attention_calls += 1
                    if kernel_mode == "single_pass":
                        self.fused_single_pass_calls += 1
                    else:
                        self.fused_two_stage_calls += 1
                    return fused_out
            if self.require_fused_attention:
                raise RuntimeError(
                    "No fused compressed Qwen attention kernel was used. "
                    "Use CUDA with supported K/V bits, keep TORBUQUANT_DISABLE_GQA_KERNEL unset, "
                    "or construct TurboQuantQwenCache(require_fused_attention=False) for diagnostic fallback."
                )
            self.dense_fallback_calls += 1
            if compressed.k_bits == 16:
                scores = torch.einsum("bkgd,bknd->bkgn", q_group, compressed.k_indices) * scale
                values = dequantize_values_uniform(
                    compressed.v_quantized,
                    compressed.v_scales,
                    compressed.v_zeros,
                    compressed.v_group_size,
                    bits=compressed.v_bits,
                    original_D=compressed.v_dim,
                ).to(dtype=query_states.dtype)
                score_parts.append(scores)
                value_parts.append(values)
                return self._attend_dense_parts(score_parts, value_parts, recent_k, recent_v, q_group, query_states, scale)
            key_q = MSEQuantized(
                indices=compressed.k_indices,
                norms=compressed.k_norms,
                bits=compressed.k_bits,
                dim=compressed.k_dim,
            )
            try:
                scores = layer.attention.k_quantizer.direct_score_triton(q_rot, key_q, scale=scale)
            except RuntimeError:
                scores = layer.attention.k_quantizer.direct_score(q_rot, key_q, scale=scale)
            values = dequantize_values_uniform(
                compressed.v_quantized,
                compressed.v_scales,
                compressed.v_zeros,
                compressed.v_group_size,
                bits=compressed.v_bits,
                original_D=compressed.v_dim,
            ).to(dtype=query_states.dtype)
            score_parts.append(scores)
            value_parts.append(values)

        if recent_k.shape[-2] > 0:
            recent_scores = torch.einsum("bkgd,bknd->bkgn", q_group, recent_k) * scale
            score_parts.append(recent_scores)
            value_parts.append(recent_v)

        all_scores = torch.cat(score_parts, dim=-1)
        all_values = torch.cat(value_parts, dim=-2)
        weights = torch.softmax(all_scores, dim=-1, dtype=torch.float32).to(query_states.dtype)
        out = torch.einsum("bkgn,bknd->bkgd", weights, all_values)
        return out.reshape(B, QH, 1, D)

    def _attend_dense_parts(
        self,
        score_parts: list[torch.Tensor],
        value_parts: list[torch.Tensor],
        recent_k: torch.Tensor,
        recent_v: torch.Tensor,
        q_group: torch.Tensor,
        query_states: torch.Tensor,
        scale: float,
    ) -> torch.Tensor:
        B, QH, _, D = query_states.shape
        if recent_k.shape[-2] > 0:
            recent_scores = torch.einsum("bkgd,bknd->bkgn", q_group, recent_k) * scale
            score_parts.append(recent_scores)
            value_parts.append(recent_v)
        all_scores = torch.cat(score_parts, dim=-1)
        all_values = torch.cat(value_parts, dim=-2)
        weights = torch.softmax(all_scores, dim=-1, dtype=torch.float32).to(query_states.dtype)
        out = torch.einsum("bkgn,bknd->bkgd", weights, all_values)
        return out.reshape(B, QH, 1, D)

    def update(self, key_states, value_states, layer_idx, cache_kwargs=None):
        raise RuntimeError(
            "TurboQuantQwenCache must be used with install_qwen_turboquant_attention(); "
            "it does not expose dense K/V through Cache.update()."
        )

    def get_seq_length(self, layer_idx: Optional[int] = 0) -> int:
        if layer_idx is None:
            layer_idx = 0
        if layer_idx >= len(self.layers) or self.layers[layer_idx] is None:
            return 0
        return self.layers[layer_idx].seq_len

    def get_max_cache_shape(self) -> Optional[int]:
        return None

    def reorder_cache(self, beam_idx: torch.LongTensor):
        raise NotImplementedError("TurboQuantQwenCache currently supports greedy/sampling decode, not beam search")

    def compressed_memory_bytes(self) -> int:
        total = 0
        for layer in self.layers:
            if layer is not None and layer.compressed is not None:
                total += layer.compressed.memory_bytes()["total"]
            if layer is not None and layer.recent_k is not None:
                total += layer.recent_k.nelement() * layer.recent_k.element_size()
                total += layer.recent_v.nelement() * layer.recent_v.element_size()
        return total

    def gpu_memory_bytes(self) -> int:
        return self.compressed_memory_bytes()

    def dense_memory_bytes(self) -> int:
        total = 0
        for layer in self.layers:
            if layer is not None:
                total += (
                    2
                    * self.num_key_value_heads
                    * layer.seq_len
                    * self.head_dim
                    * 2
                )
        return total

    def compression_ratio(self) -> float:
        compressed = self.compressed_memory_bytes()
        return self.dense_memory_bytes() / compressed if compressed else 1.0

    def stats(self) -> dict[str, int | float]:
        return {
            "fused_attention_calls": self.fused_attention_calls,
            "fused_weighted_v_calls": self.fused_weighted_v_calls,
            "fused_single_pass_calls": self.fused_single_pass_calls,
            "fused_two_stage_calls": self.fused_two_stage_calls,
            "dense_fallback_calls": self.dense_fallback_calls,
            "sparse_v_threshold": self.sparse_v_threshold,
            "boundary_layers": self.boundary_layers,
            "boundary_value_bits": self.boundary_value_bits or 0,
        }


def install_qwen_turboquant_attention(model) -> int:
    """Patch Qwen2 attention modules to use ``TurboQuantQwenCache`` in decode.

    Returns the number of patched attention modules.
    """

    try:
        from transformers.models.qwen2.modeling_qwen2 import (
            ALL_ATTENTION_FUNCTIONS,
            apply_rotary_pos_emb,
            eager_attention_forward,
            logger,
        )
    except Exception as exc:  # pragma: no cover - depends on transformers build
        raise RuntimeError("Qwen2 TurboQuant patch requires transformers Qwen2") from exc

    patched = 0

    for module in model.modules():
        if module.__class__.__name__ != "Qwen2Attention":
            continue
        if getattr(module, "_turboquant_patched", False):
            continue

        original_forward = module.forward

        def make_forward(orig_forward):
            def turbo_forward(
                self,
                hidden_states: torch.Tensor,
                position_embeddings,
                attention_mask: Optional[torch.Tensor],
                past_key_value: Optional[Cache] = None,
                cache_position: Optional[torch.LongTensor] = None,
                **kwargs,
            ):
                if not isinstance(past_key_value, TurboQuantQwenCache):
                    return orig_forward(
                        hidden_states,
                        position_embeddings,
                        attention_mask,
                        past_key_value=past_key_value,
                        cache_position=cache_position,
                        **kwargs,
                    )

                input_shape = hidden_states.shape[:-1]
                hidden_shape = (*input_shape, -1, self.head_dim)

                query_states = self.q_proj(hidden_states).view(hidden_shape).transpose(1, 2)
                key_states = self.k_proj(hidden_states).view(hidden_shape).transpose(1, 2)
                value_states = self.v_proj(hidden_states).view(hidden_shape).transpose(1, 2)

                cos, sin = position_embeddings
                query_states, key_states = apply_rotary_pos_emb(query_states, key_states, cos, sin)

                q_len = query_states.shape[-2]

                if q_len > 1:
                    past_key_value.append(key_states, value_states, self.layer_idx)

                    sliding_window = None
                    if (
                        self.config.use_sliding_window
                        and getattr(self.config, "sliding_window", None) is not None
                        and self.layer_idx >= self.config.max_window_layers
                    ):
                        sliding_window = self.config.sliding_window

                    attention_interface = eager_attention_forward
                    if self.config._attn_implementation != "eager":
                        if self.config._attn_implementation == "sdpa" and kwargs.get("output_attentions", False):
                            logger.warning_once(
                                "`torch.nn.functional.scaled_dot_product_attention` does not support "
                                "`output_attentions=True`. Falling back to eager attention."
                            )
                        else:
                            attention_interface = ALL_ATTENTION_FUNCTIONS[self.config._attn_implementation]

                    attn_output, attn_weights = attention_interface(
                        self,
                        query_states,
                        key_states,
                        value_states,
                        attention_mask,
                        dropout=0.0 if not self.training else self.attention_dropout,
                        scaling=self.scaling,
                        sliding_window=sliding_window,
                        **kwargs,
                    )
                else:
                    past_key_value.append(key_states, value_states, self.layer_idx)
                    attn_output = past_key_value.attend(query_states, self.layer_idx, self.scaling)
                    attn_output = attn_output.transpose(1, 2).contiguous()
                    attn_weights = None

                attn_output = attn_output.reshape(*input_shape, -1).contiguous()
                attn_output = self.o_proj(attn_output)
                return attn_output, attn_weights

            return turbo_forward

        module._turboquant_original_forward = original_forward
        module.forward = types.MethodType(make_forward(original_forward), module)
        module._turboquant_patched = True
        patched += 1

    return patched
