"""Qwen model integration utilities for TurboQuant.

This module provides helper functions for running Qwen models with
TurboQuant KV-cache quantization.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import torch

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
    from transformers.cache_utils import DynamicCache
except ImportError as exc:
    raise RuntimeError("Qwen integration requires transformers") from exc

from .hf_cache import TurboQuantDynamicCache


@dataclass
class GenerationResult:
    """Result of text generation with statistics."""

    generated_text: str
    input_tokens: int
    output_tokens: int
    generation_time_seconds: float
    cache_type: str
    compressed_memory_bytes: Optional[int] = None
    dense_memory_bytes: Optional[int] = None
    compression_ratio: Optional[float] = None
    gpu_memory_bytes: Optional[int] = None  # Actual GPU memory used

    @property
    def tokens_per_second(self) -> float:
        if self.generation_time_seconds > 0:
            return self.output_tokens / self.generation_time_seconds
        return 0.0


def load_qwen_model(
    model_name: str = "Qwen/Qwen2.5-3B",
    device: str = "cuda",
    dtype: torch.dtype = torch.float16,
    trust_remote_code: bool = True,
) -> tuple:
    """Load Qwen model and tokenizer.

    Args:
        model_name: HuggingFace model identifier
        device: Device to load model on
        dtype: Model dtype (float16 recommended for efficiency)
        trust_remote_code: Whether to trust remote code (required for Qwen)

    Returns:
        (model, tokenizer) tuple
    """
    tokenizer = AutoTokenizer.from_pretrained(
        model_name,
        trust_remote_code=trust_remote_code,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=dtype,
        device_map=device,
        trust_remote_code=trust_remote_code,
    )
    model.eval()

    return model, tokenizer


def create_turboquant_cache(
    model,
    key_bits: int = 3,
    value_bits: int = 3,
    recent_tokens: int = 128,
    device: Optional[str] = None,
    seed: int = 0,
    offload_to_cpu: bool = False,
    cache_dequant: bool = True,
) -> TurboQuantDynamicCache:
    """Create a TurboQuantDynamicCache configured for the given model.

    Args:
        model: HuggingFace model
        key_bits: Bits for key quantization
        value_bits: Bits for value quantization
        recent_tokens: Number of recent tokens to keep uncompressed
        device: Device for quantizer matrices
        seed: Random seed for rotation matrices
        offload_to_cpu: Whether to offload quantized data to CPU
        cache_dequant: Speed vs memory trade-off:
            - True (default): Cache dequantized tensors. FAST but NO GPU savings.
            - False: Dequantize on-the-fly. SLOWER but REAL GPU memory savings.

    Returns:
        Configured TurboQuantDynamicCache instance
    """
    config = model.config
    head_dim = config.hidden_size // config.num_attention_heads

    if device is None:
        device = next(model.parameters()).device

    return TurboQuantDynamicCache(
        num_hidden_layers=config.num_hidden_layers,
        head_dim=head_dim,
        key_bits=key_bits,
        value_bits=value_bits,
        recent_tokens=recent_tokens,
        device=device,
        dtype=torch.float32,
        seed=seed,
        offload_to_cpu=offload_to_cpu,
        cache_dequant=cache_dequant,
    )


def generate_with_turboquant(
    model,
    tokenizer,
    prompt: str,
    max_new_tokens: int = 100,
    key_bits: int = 3,
    value_bits: int = 3,
    recent_tokens: int = 128,
    temperature: float = 0.7,
    top_p: float = 0.9,
    do_sample: bool = True,
    seed: int = 0,
    cache_dequant: bool = True,
) -> GenerationResult:
    """Generate text using TurboQuant KV-cache quantization.

    Args:
        model: HuggingFace model
        tokenizer: HuggingFace tokenizer
        prompt: Input prompt text
        max_new_tokens: Maximum tokens to generate
        key_bits: Bits for key quantization
        value_bits: Bits for value quantization
        recent_tokens: Uncompressed recent token window
        temperature: Sampling temperature
        top_p: Nucleus sampling parameter
        do_sample: Whether to use sampling
        seed: Random seed
        cache_dequant: Speed vs memory trade-off:
            - True (default): FAST, no GPU savings
            - False: SLOWER (~3-4x), REAL GPU savings (~60-70%)

    Returns:
        GenerationResult with text and statistics
    """
    device = next(model.parameters()).device

    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    input_len = inputs.input_ids.shape[1]

    cache = create_turboquant_cache(
        model,
        key_bits=key_bits,
        value_bits=value_bits,
        recent_tokens=recent_tokens,
        seed=seed,
        offload_to_cpu=True,  # Always offload quantized to CPU (no need on GPU)
        cache_dequant=cache_dequant,
    )

    if seed is not None:
        torch.manual_seed(seed)

    torch.cuda.synchronize() if device.type == "cuda" else None
    start_time = time.perf_counter()

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            past_key_values=cache,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=do_sample,
            pad_token_id=tokenizer.pad_token_id,
            use_cache=True,
        )

    torch.cuda.synchronize() if device.type == "cuda" else None
    end_time = time.perf_counter()

    generated_ids = outputs[0][input_len:]
    generated_text = tokenizer.decode(generated_ids, skip_special_tokens=True)

    return GenerationResult(
        generated_text=generated_text,
        input_tokens=input_len,
        output_tokens=len(generated_ids),
        generation_time_seconds=end_time - start_time,
        cache_type=f"TurboQuant(k={key_bits}b, v={value_bits}b, cache_dequant={cache_dequant})",
        compressed_memory_bytes=cache.compressed_memory_bytes(),
        dense_memory_bytes=cache.dense_memory_bytes(),
        compression_ratio=cache.compression_ratio(),
        gpu_memory_bytes=cache.gpu_memory_bytes(),
    )


def generate_with_standard_cache(
    model,
    tokenizer,
    prompt: str,
    max_new_tokens: int = 100,
    temperature: float = 0.7,
    top_p: float = 0.9,
    do_sample: bool = True,
    seed: int = 0,
) -> GenerationResult:
    """Generate text using standard (uncompressed) KV-cache.

    Args:
        model: HuggingFace model
        tokenizer: HuggingFace tokenizer
        prompt: Input prompt text
        max_new_tokens: Maximum tokens to generate
        temperature: Sampling temperature
        top_p: Nucleus sampling parameter
        do_sample: Whether to use sampling
        seed: Random seed

    Returns:
        GenerationResult with text and statistics
    """
    device = next(model.parameters()).device

    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    input_len = inputs.input_ids.shape[1]

    if seed is not None:
        torch.manual_seed(seed)

    torch.cuda.synchronize() if device.type == "cuda" else None
    start_time = time.perf_counter()

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p,
            do_sample=do_sample,
            pad_token_id=tokenizer.pad_token_id,
            use_cache=True,
        )

    torch.cuda.synchronize() if device.type == "cuda" else None
    end_time = time.perf_counter()

    generated_ids = outputs[0][input_len:]
    generated_text = tokenizer.decode(generated_ids, skip_special_tokens=True)

    return GenerationResult(
        generated_text=generated_text,
        input_tokens=input_len,
        output_tokens=len(generated_ids),
        generation_time_seconds=end_time - start_time,
        cache_type="Standard (FP16)",
    )


def compare_generation(
    model,
    tokenizer,
    prompt: str,
    max_new_tokens: int = 100,
    key_bits: int = 3,
    value_bits: int = 3,
    recent_tokens: int = 128,
    temperature: float = 0.7,
    top_p: float = 0.9,
    do_sample: bool = True,
    seed: int = 42,
    verbose: bool = True,
    cache_dequant: bool = True,
) -> tuple[GenerationResult, GenerationResult]:
    """Compare generation with TurboQuant vs standard cache.

    Args:
        model: HuggingFace model
        tokenizer: HuggingFace tokenizer
        prompt: Input prompt text
        max_new_tokens: Maximum tokens to generate
        key_bits: Bits for key quantization
        value_bits: Bits for value quantization
        recent_tokens: Uncompressed recent token window
        temperature: Sampling temperature
        top_p: Nucleus sampling parameter
        do_sample: Whether to use sampling
        seed: Random seed (same for both to enable comparison)
        verbose: Whether to print comparison
        cache_dequant: Speed vs memory trade-off:
            - True: FAST, no GPU savings
            - False: SLOWER, REAL GPU savings

    Returns:
        (turboquant_result, standard_result) tuple
    """
    mode_str = "SPEED MODE" if cache_dequant else "MEMORY MODE"
    if verbose:
        print(f"TurboQuant {mode_str} (cache_dequant={cache_dequant})")
        print(f"Prompt ({len(prompt)} chars): {prompt[:100]}...")
        print("-" * 60)

    standard_result = generate_with_standard_cache(
        model,
        tokenizer,
        prompt,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
        top_p=top_p,
        do_sample=do_sample,
        seed=seed,
    )

    turboquant_result = generate_with_turboquant(
        model,
        tokenizer,
        prompt,
        max_new_tokens=max_new_tokens,
        key_bits=key_bits,
        value_bits=value_bits,
        recent_tokens=recent_tokens,
        temperature=temperature,
        top_p=top_p,
        do_sample=do_sample,
        seed=seed,
        cache_dequant=cache_dequant,
    )

    if verbose:
        print(f"Standard Cache:")
        print(f"  Output: {standard_result.generated_text[:200]}...")
        print(f"  Tokens: {standard_result.output_tokens}, Time: {standard_result.generation_time_seconds:.2f}s")
        print(f"  Speed: {standard_result.tokens_per_second:.1f} tok/s")
        print()
        print(f"TurboQuant Cache (k={key_bits}b, v={value_bits}b, {mode_str}):")
        print(f"  Output: {turboquant_result.generated_text[:200]}...")
        print(f"  Tokens: {turboquant_result.output_tokens}, Time: {turboquant_result.generation_time_seconds:.2f}s")
        print(f"  Speed: {turboquant_result.tokens_per_second:.1f} tok/s")
        print(f"  Speed ratio: {turboquant_result.tokens_per_second / standard_result.tokens_per_second:.2f}x")
        print(f"  Storage compression: {turboquant_result.compression_ratio:.2f}x")
        print(f"  GPU memory: {turboquant_result.gpu_memory_bytes / 1024 / 1024:.2f} MB")
        print(f"  Dense equivalent: {turboquant_result.dense_memory_bytes / 1024 / 1024:.2f} MB")
        gpu_ratio = turboquant_result.gpu_memory_bytes / turboquant_result.dense_memory_bytes if turboquant_result.dense_memory_bytes else 1.0
        print(f"  GPU memory ratio: {gpu_ratio:.2f}x (savings: {(1-gpu_ratio)*100:.1f}%)")

    return turboquant_result, standard_result
