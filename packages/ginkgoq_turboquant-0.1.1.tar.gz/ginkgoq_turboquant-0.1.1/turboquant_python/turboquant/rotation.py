"""Random transforms used by TurboQuant."""

from __future__ import annotations

import torch


def _generator(device: torch.device, seed: int | None) -> torch.Generator | None:
    if seed is None:
        return None
    gen_device = "cuda" if device.type == "cuda" else "cpu"
    generator = torch.Generator(device=gen_device)
    generator.manual_seed(seed)
    return generator


def generate_rotation_matrix(
    dim: int,
    *,
    device: torch.device | str,
    dtype: torch.dtype = torch.float32,
    seed: int | None = None,
) -> torch.Tensor:
    """Generate the paper's random orthogonal matrix via Gaussian QR."""

    if dim < 1:
        raise ValueError(f"dim must be positive, got {dim}")
    device = torch.device(device)
    gaussian = torch.randn(
        dim,
        dim,
        device=device,
        dtype=torch.float32,
        generator=_generator(device, seed),
    )
    q, r = torch.linalg.qr(gaussian, mode="reduced")
    signs = torch.sign(torch.diagonal(r))
    signs = torch.where(signs == 0, torch.ones_like(signs), signs)
    q = q * signs.unsqueeze(0)
    return q.to(dtype=dtype)


def generate_qjl_matrix(
    dim: int,
    *,
    device: torch.device | str,
    dtype: torch.dtype = torch.float32,
    seed: int | None = None,
) -> torch.Tensor:
    """Generate the QJL Gaussian matrix ``S`` with i.i.d. ``N(0, 1)`` entries."""

    if dim < 1:
        raise ValueError(f"dim must be positive, got {dim}")
    device = torch.device(device)
    return torch.randn(
        dim,
        dim,
        device=device,
        dtype=torch.float32,
        generator=_generator(device, seed),
    ).to(dtype=dtype)


def rotate_forward(x: torch.Tensor, rotation: torch.Tensor) -> torch.Tensor:
    """Apply ``Pi x`` to row-major vectors stored as ``(..., dim)``."""

    return x @ rotation.T


def rotate_backward(y: torch.Tensor, rotation: torch.Tensor) -> torch.Tensor:
    """Apply ``Pi^T y`` to row-major vectors stored as ``(..., dim)``."""

    return y @ rotation


# =============================================================================
# Randomized Hadamard Transform (RHT) - O(d log d) complexity
# =============================================================================

def hadamard_transform(x: torch.Tensor) -> torch.Tensor:
    """Fast Walsh-Hadamard Transform - O(d log d).

    Vectorized implementation using the butterfly algorithm.
    The transform is self-inverse up to scaling: H @ H = d * I
    We normalize by 1/sqrt(d) so (H/sqrt(d)) @ (H/sqrt(d)) = I

    Args:
        x: (..., d) tensor where d must be a power of 2

    Returns:
        (..., d) transformed tensor (normalized by 1/sqrt(d))
    """
    d = x.shape[-1]
    if d & (d - 1) != 0:
        raise ValueError(f"Dimension must be power of 2, got {d}")

    # Work with float for precision, clone to avoid modifying input
    result = x.float().clone()
    original_shape = result.shape

    # Flatten all batch dimensions
    result = result.reshape(-1, d).contiguous()
    batch_size = result.shape[0]

    # Butterfly algorithm for WHT
    h = 1
    while h < d:
        # Reshape to group pairs: (batch, d/(2h), 2, h)
        result = result.reshape(batch_size, -1, 2, h)

        # Butterfly: top = a + b, bottom = a - b
        # Clone to avoid in-place modification issues
        a = result[:, :, 0, :].clone()
        b = result[:, :, 1, :].clone()

        result[:, :, 0, :] = a + b
        result[:, :, 1, :] = a - b

        # Reshape back
        result = result.reshape(batch_size, d)

        h *= 2

    # Normalize and restore shape
    result = result / (d ** 0.5)
    result = result.reshape(original_shape)

    return result.to(x.dtype)


def hadamard_transform_inverse(x: torch.Tensor) -> torch.Tensor:
    """Inverse Fast Walsh-Hadamard Transform.

    Since H_norm @ H_norm = I (for our normalized version), the inverse is the same.
    """
    return hadamard_transform(x)


class RHTRotation:
    """Randomized Hadamard Transform rotation - O(d log d) complexity.

    Implements: R(x) = D1 @ H @ D2 @ x
    Where:
        - D1, D2 are diagonal matrices with random ±1 entries
        - H is the Walsh-Hadamard transform

    This gives a random rotation-like transform with:
        - O(d log d) compute instead of O(d²)
        - O(d) storage (just sign vectors) instead of O(d²)
        - Good randomization properties for quantization
    """

    def __init__(
        self,
        dim: int,
        device: torch.device,
        dtype: torch.dtype = torch.float32,
        seed: int | None = None,
    ):
        if dim & (dim - 1) != 0:
            raise ValueError(f"RHT requires power-of-2 dimension, got {dim}")

        self.dim = dim
        self.device = device
        self.dtype = dtype

        # Generate random sign vectors
        gen = _generator(device, seed)
        # D1 and D2 are ±1 diagonal matrices, stored as vectors
        self.signs1 = (torch.randint(0, 2, (dim,), device=device, generator=gen) * 2 - 1).to(dtype)
        self.signs2 = (torch.randint(0, 2, (dim,), device=device, generator=gen) * 2 - 1).to(dtype)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply RHT: D1 @ H @ D2 @ x"""
        # D2 @ x (element-wise multiply)
        result = x * self.signs2
        # H @ (D2 @ x)
        result = hadamard_transform(result)
        # D1 @ H @ D2 @ x
        result = result * self.signs1
        return result

    def backward(self, y: torch.Tensor) -> torch.Tensor:
        """Apply inverse RHT: D2 @ H @ D1 @ y (since H^T = H and D^T = D)"""
        # D1 @ y
        result = y * self.signs1
        # H @ D1 @ y
        result = hadamard_transform(result)
        # D2 @ H @ D1 @ y
        result = result * self.signs2
        return result

    def to(self, device: torch.device) -> "RHTRotation":
        """Move to device."""
        self.signs1 = self.signs1.to(device)
        self.signs2 = self.signs2.to(device)
        self.device = device
        return self


def generate_rht_rotation(
    dim: int,
    *,
    device: torch.device | str,
    dtype: torch.dtype = torch.float32,
    seed: int | None = None,
) -> RHTRotation:
    """Generate RHT rotation transform.

    Args:
        dim: Dimension (must be power of 2)
        device: Target device
        dtype: Data type for sign vectors
        seed: Random seed for reproducibility

    Returns:
        RHTRotation object with forward() and backward() methods
    """
    device = torch.device(device)
    return RHTRotation(dim, device, dtype, seed)
