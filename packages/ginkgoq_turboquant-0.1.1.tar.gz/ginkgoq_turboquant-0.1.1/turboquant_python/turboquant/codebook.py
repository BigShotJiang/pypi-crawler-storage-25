"""Lloyd-Max scalar codebooks for TurboQuant.

After a random rotation, every coordinate of a unit vector distributed on
``S^{d-1}`` has density

    Gamma(d/2) / (sqrt(pi) Gamma((d-1)/2)) * (1 - x^2)^((d-3)/2)

on ``[-1, 1]``.  TurboQuant solves the continuous one-dimensional k-means
problem for this density and applies the resulting scalar quantizer to every
rotated coordinate.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import torch
from scipy import integrate, special


@dataclass(frozen=True)
class LloydMaxCodebook:
    """Continuous Lloyd-Max codebook for the sphere-coordinate density."""

    dim: int
    bits: int
    centroids: np.ndarray
    boundaries: np.ndarray
    mse_per_coordinate: float

    @property
    def total_mse(self) -> float:
        return float(self.dim * self.mse_per_coordinate)


def beta_coordinate_pdf(x: np.ndarray | float, dim: int) -> np.ndarray:
    """PDF of one coordinate of a uniform random point on ``S^{dim-1}``."""

    if dim < 3:
        raise ValueError("the continuous Beta-coordinate density requires dim >= 3")
    values = np.asarray(x, dtype=np.float64)
    clipped = np.clip(values, -1.0 + 1e-15, 1.0 - 1e-15)
    log_const = (
        special.gammaln(dim / 2.0)
        - 0.5 * np.log(np.pi)
        - special.gammaln((dim - 1) / 2.0)
    )
    log_pdf = log_const + ((dim - 3.0) / 2.0) * np.log1p(-(clipped * clipped))
    return np.exp(log_pdf)


def _moment(lo: float, hi: float, dim: int, power: int) -> float:
    value, _ = integrate.quad(
        lambda t: (t**power) * float(beta_coordinate_pdf(t, dim)),
        lo,
        hi,
        epsabs=1e-13,
        epsrel=1e-13,
        limit=200,
    )
    return float(value)


def _initial_centroids(dim: int, levels: int) -> np.ndarray:
    grid = np.linspace(-1.0 + 1e-10, 1.0 - 1e-10, 20001, dtype=np.float64)
    pdf = beta_coordinate_pdf(grid, dim)
    cdf = np.cumsum(pdf)
    cdf /= cdf[-1]
    mids = (np.arange(levels, dtype=np.float64) + 0.5) / levels
    return np.interp(mids, cdf, grid)


@lru_cache(maxsize=128)
def compute_lloyd_max_codebook(
    dim: int,
    bits: int,
    max_iter: int = 200,
    tol: float = 1e-12,
) -> LloydMaxCodebook:
    """Compute the paper's scalar codebook for a given dimension and bit-width."""

    if dim < 3:
        raise ValueError(f"dim must be >= 3, got {dim}")
    if bits < 1:
        raise ValueError(f"bits must be >= 1, got {bits}")
    if bits > 8:
        raise ValueError("bits > 8 is supported mathematically but impractical here")

    levels = 1 << bits
    centroids = _initial_centroids(dim, levels)
    previous = np.inf
    mse = np.inf

    for _ in range(max_iter):
        boundaries = np.empty(levels + 1, dtype=np.float64)
        boundaries[0] = -1.0
        boundaries[-1] = 1.0
        boundaries[1:-1] = 0.5 * (centroids[:-1] + centroids[1:])

        updated = np.empty_like(centroids)
        for idx in range(levels):
            lo = float(boundaries[idx])
            hi = float(boundaries[idx + 1])
            mass = _moment(lo, hi, dim, 0)
            updated[idx] = _moment(lo, hi, dim, 1) / mass if mass > 0.0 else 0.5 * (lo + hi)

        mse = 0.0
        for idx, center in enumerate(updated):
            lo = float(boundaries[idx])
            hi = float(boundaries[idx + 1])
            m0 = _moment(lo, hi, dim, 0)
            m1 = _moment(lo, hi, dim, 1)
            m2 = _moment(lo, hi, dim, 2)
            mse += m2 - 2.0 * float(center) * m1 + float(center * center) * m0

        centroids = updated
        if abs(previous - mse) <= tol:
            break
        previous = mse

    boundaries = np.empty(levels + 1, dtype=np.float64)
    boundaries[0] = -1.0
    boundaries[-1] = 1.0
    boundaries[1:-1] = 0.5 * (centroids[:-1] + centroids[1:])
    return LloydMaxCodebook(dim, bits, centroids, boundaries, float(mse))


def codebook_tensors(
    dim: int,
    bits: int,
    *,
    device: torch.device | str,
    dtype: torch.dtype = torch.float32,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return centroids and decision boundaries as tensors on ``device``."""

    codebook = compute_lloyd_max_codebook(dim, bits)
    centroids = torch.as_tensor(codebook.centroids, device=device, dtype=dtype)
    decision_boundaries = torch.as_tensor(codebook.boundaries[1:-1], device=device, dtype=dtype)
    return centroids, decision_boundaries
