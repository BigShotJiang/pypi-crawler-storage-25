"""Production mode selection for TurboQuant KV cache.

The policy is intentionally conservative and follows measured behavior:

* Dense SDPA is the current low-latency path.
* K16V4 is the safest Qwen/GQA memory-pressure path: exact K, packed V.
* K8V4 is the stronger-compression Qwen/GQA memory-pressure path.
* K4V4 is a memory-survival mode, not a default quality/speed mode.
* K4V2 is experimental until model-quality gates pass.

Auto mode is a one-time planning decision. It must not run inside the decode
loop. The decision is based on model/cache shape, expected context length,
batch/concurrency, and available KV-memory budget.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


Objective = Literal["throughput", "balanced", "max_memory", "experimental"]
Backend = Literal["sdpa_fp16", "turboquant"]


@dataclass(frozen=True)
class TurboQuantKVPolicy:
    backend: Backend
    k_bits: int
    v_bits: int
    recent_window: int
    fused_decode: bool
    reason: str
    sparse_v_threshold: float = 0.0
    require_fused_attention: bool = True
    boundary_value_bits: int | None = None
    boundary_layers: int = 0
    estimated_dense_kv_bytes: int | None = None
    estimated_compressed_kv_bytes: int | None = None
    estimated_compression: float | None = None


@dataclass(frozen=True)
class AutoPolicyInput:
    """Inputs for a zero-overhead one-time KV policy decision."""

    batch_size: int
    num_layers: int
    num_kv_heads: int
    head_dim: int
    context_tokens: int
    dtype_bytes: int = 2
    available_kv_memory_bytes: int | None = None
    model_name: str | None = None
    num_attention_heads: int | None = None
    base_weight_bits: int | None = None
    prefer_quality: bool = True
    prefer_low_latency: bool = False
    allow_quantization: bool = True


def estimate_dense_kv_bytes(
    *,
    batch_size: int,
    num_layers: int,
    num_kv_heads: int,
    head_dim: int,
    context_tokens: int,
    dtype_bytes: int = 2,
) -> int:
    """Estimate dense K+V cache bytes for decoder-only attention."""

    return int(batch_size * num_layers * num_kv_heads * context_tokens * head_dim * 2 * dtype_bytes)


def estimate_turboquant_kv_bytes(
    dense_bytes: int,
    *,
    k_bits: int = 4,
    v_bits: int,
) -> int:
    """Estimate compressed KV bytes from measured compression ratios.

    These ratios include key indices/norms and value payload/scale metadata for
    the current fused-attention storage format. They are intentionally
    conservative and should be replaced by live allocation measurements in a
    serving backend.
    """

    if k_bits == 16 and v_bits == 4:
        ratio = 1.30
    elif k_bits == 16 and v_bits == 8:
        ratio = 1.15
    elif k_bits == 8 and v_bits == 8:
        ratio = 1.55
    elif k_bits == 8 and v_bits == 4:
        ratio = 1.70
    elif k_bits == 4 and v_bits == 8:
        ratio = 2.56
    elif k_bits == 4 and v_bits == 4:
        ratio = 3.76
    elif k_bits == 4 and v_bits == 2:
        ratio = 4.7
    else:
        raise ValueError(f"unsupported K/V bits for estimate: K{k_bits}V{v_bits}")
    return int(dense_bytes / ratio)


def choose_kv_policy(objective: Objective = "throughput", *, context_length: int = 4096) -> TurboQuantKVPolicy:
    """Choose a measured-safe TurboQuant KV configuration.

    Args:
        objective: Production goal.
        context_length: Used only to scale the dense recent window.

    Returns:
        Conservative K/V bit-width and recent-window recommendation.
    """

    recent = 128 if context_length >= 2048 else 64

    if objective == "throughput":
        return TurboQuantKVPolicy(
            backend="sdpa_fp16",
            k_bits=16,
            v_bits=16,
            recent_window=0,
            fused_decode=False,
            require_fused_attention=False,
            reason="Dense SDPA is the measured low-latency path for single-request inference.",
        )
    if objective == "balanced":
        return TurboQuantKVPolicy(
            backend="turboquant",
            k_bits=4,
            v_bits=8,
            recent_window=max(recent, 128),
            fused_decode=True,
            reason="Use K4V8 only when KV memory pressure matters and quality must be preserved.",
        )
    if objective == "max_memory":
        return TurboQuantKVPolicy(
            backend="turboquant",
            k_bits=4,
            v_bits=4,
            recent_window=max(recent, 128),
            fused_decode=True,
            reason="K4V4 gives stronger compression, but current kernels are throughput-negative versus SDPA.",
        )
    if objective == "experimental":
        return TurboQuantKVPolicy(
            backend="turboquant",
            k_bits=4,
            v_bits=2,
            recent_window=max(recent, 256),
            fused_decode=False,
            reason="K4V2 is experimental; use only with real model quality gates.",
        )
    raise ValueError(f"unknown objective: {objective}")


def choose_auto_kv_policy(inputs: AutoPolicyInput) -> TurboQuantKVPolicy:
    """Choose the cache backend once, before inference starts.

    Rules:
    - If no KV budget is provided, use dense SDPA/FP16. TurboQuant is not the
      single-request speed path.
    - If dense KV fits the budget, use dense SDPA/FP16.
    - If dense KV does not fit, use TurboQuant memory-pressure modes.
    - Use safer asymmetric K8/V4 for Qwen-like or low-bit-weight models.
    - Use K4V8 for less sensitive models when speed/quality is preferred.
    - Use K4V4 only when safer modes do not fit.
    - Never choose K4V2 unless a caller explicitly asks for experimental mode.
    """

    dense = estimate_dense_kv_bytes(
        batch_size=inputs.batch_size,
        num_layers=inputs.num_layers,
        num_kv_heads=inputs.num_kv_heads,
        head_dim=inputs.head_dim,
        context_tokens=inputs.context_tokens,
        dtype_bytes=inputs.dtype_bytes,
    )

    budget = inputs.available_kv_memory_bytes
    recent = 256 if inputs.context_tokens >= 2048 else 128
    model_name = (inputs.model_name or "").lower()
    gqa_ratio = (
        inputs.num_attention_heads / inputs.num_kv_heads
        if inputs.num_attention_heads and inputs.num_kv_heads
        else 1.0
    )
    qwen_like = "qwen" in model_name
    low_bit_weights = inputs.base_weight_bits is not None and inputs.base_weight_bits <= 4
    sensitive_k = qwen_like or low_bit_weights or gqa_ratio >= 4.0
    sparse_threshold = 0.0

    if not inputs.allow_quantization:
        return TurboQuantKVPolicy(
            backend="sdpa_fp16",
            k_bits=16,
            v_bits=16,
            recent_window=0,
            fused_decode=False,
            reason="Quantization disabled by caller.",
            require_fused_attention=False,
            estimated_dense_kv_bytes=dense,
            estimated_compressed_kv_bytes=dense,
            estimated_compression=1.0,
        )

    if budget is None:
        return TurboQuantKVPolicy(
            backend="sdpa_fp16",
            k_bits=16,
            v_bits=16,
            recent_window=0,
            fused_decode=False,
            reason="No KV memory budget was provided; dense SDPA is the correct speed path.",
            require_fused_attention=False,
            estimated_dense_kv_bytes=dense,
            estimated_compressed_kv_bytes=dense,
            estimated_compression=1.0,
        )

    pressure = dense / max(1, budget)
    if dense <= int(0.90 * budget):
        return TurboQuantKVPolicy(
            backend="sdpa_fp16",
            k_bits=16,
            v_bits=16,
            recent_window=0,
            fused_decode=False,
            reason=f"Dense KV fits the budget ({pressure:.2f}x); SDPA remains the speed path.",
            require_fused_attention=False,
            estimated_dense_kv_bytes=dense,
            estimated_compressed_kv_bytes=dense,
            estimated_compression=1.0,
        )

    if sensitive_k:
        k16v4 = estimate_turboquant_kv_bytes(dense, k_bits=16, v_bits=4)
        if k16v4 <= budget:
            return TurboQuantKVPolicy(
                backend="turboquant",
                k_bits=16,
                v_bits=4,
                recent_window=recent,
                fused_decode=True,
                sparse_v_threshold=sparse_threshold,
                boundary_value_bits=8,
                boundary_layers=2,
                reason=(
                    "Selected K16V4: this model/workload is K-sensitive, so key routing stays exact "
                    "while values carry the memory reduction."
                ),
                estimated_dense_kv_bytes=dense,
                estimated_compressed_kv_bytes=k16v4,
                estimated_compression=dense / max(1, k16v4),
            )
        k8v4 = estimate_turboquant_kv_bytes(dense, k_bits=8, v_bits=4)
        if k8v4 <= budget:
            return TurboQuantKVPolicy(
                backend="turboquant",
                k_bits=8,
                v_bits=4,
                recent_window=recent,
                fused_decode=True,
                sparse_v_threshold=sparse_threshold,
                boundary_value_bits=8,
                boundary_layers=2,
                reason=(
                    "Selected asymmetric K8V4: this model/workload is K-sensitive, so keys stay high precision "
                    "while values carry most of the compression."
                ),
                estimated_dense_kv_bytes=dense,
                estimated_compressed_kv_bytes=k8v4,
                estimated_compression=dense / max(1, k8v4),
            )

    if inputs.prefer_quality:
        k8v8 = estimate_turboquant_kv_bytes(dense, k_bits=8, v_bits=8)
        if k8v8 <= budget:
            return TurboQuantKVPolicy(
                backend="turboquant",
                k_bits=8,
                v_bits=8,
                recent_window=recent,
                fused_decode=True,
                sparse_v_threshold=sparse_threshold,
                reason="K8V8 fits the KV budget and is selected as the safest quality-preserving compressed mode.",
                estimated_dense_kv_bytes=dense,
                estimated_compressed_kv_bytes=k8v8,
                estimated_compression=dense / max(1, k8v8),
            )

    k4v8 = estimate_turboquant_kv_bytes(dense, k_bits=4, v_bits=8)
    if k4v8 <= budget:
        return TurboQuantKVPolicy(
            backend="turboquant",
            k_bits=4,
            v_bits=8,
            recent_window=recent,
            fused_decode=True,
            sparse_v_threshold=sparse_threshold,
            reason="K4V8 fits the KV budget with the safest current quality profile.",
            estimated_dense_kv_bytes=dense,
            estimated_compressed_kv_bytes=k4v8,
            estimated_compression=dense / max(1, k4v8),
        )

    k4v4 = estimate_turboquant_kv_bytes(dense, k_bits=4, v_bits=4)
    if k4v4 <= budget:
        return TurboQuantKVPolicy(
            backend="turboquant",
            k_bits=4,
            v_bits=4,
            recent_window=max(recent, 128),
            fused_decode=True,
            sparse_v_threshold=sparse_threshold,
            reason="K4V8 does not fit the KV budget; K4V4 is selected for memory survival.",
            estimated_dense_kv_bytes=dense,
            estimated_compressed_kv_bytes=k4v4,
            estimated_compression=dense / max(1, k4v4),
        )

    return TurboQuantKVPolicy(
        backend="turboquant",
        k_bits=4,
        v_bits=4,
        recent_window=max(recent, 256),
        fused_decode=True,
        sparse_v_threshold=sparse_threshold,
        reason="Even K4V4 exceeds the estimated KV budget; select max safe compression and reduce batch/context.",
        estimated_dense_kv_bytes=dense,
        estimated_compressed_kv_bytes=k4v4,
        estimated_compression=dense / max(1, k4v4),
    )
