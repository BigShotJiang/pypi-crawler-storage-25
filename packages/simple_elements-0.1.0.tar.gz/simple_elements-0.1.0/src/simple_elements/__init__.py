from .sentinels import UnsetType, UNSET

__all__ = [
    # Sentinel
    "UnsetType",
    "UNSET",
]


_DESIGN_NOTES = """
# simple_elements

## Public API
| Name                           | Description                                                       |
|--------------------------------|-------------------------------------------------------------------|
| `UNSET`                        | Sentinel for an unset value                                       |
| `UnsetType`                    | Sentinel type — for type annotations                              |
"""