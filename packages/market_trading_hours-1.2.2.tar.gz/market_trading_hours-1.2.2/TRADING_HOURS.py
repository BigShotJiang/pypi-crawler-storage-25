# FILE:    TRADING_HOURS.py
# PURPOSE: Determine whether a given date/time is a valid market trading day and
#          whether the current moment falls within a configurable market window.
# GOAL:    Expose is_trading_day, is_market_open, and find_next_trading_date as
#          the public API, backed by holiday data and market-timing config.
# RUNS TO: is_market_open() / find_next_trading_date()

# ┌────────────────────────────────────────────────────────────────────────────────┐
# │ PERFORMANCE TEST RESULTS (2 RUN AVERAGE)                                       │
# ├────────────────────────────────────┬──────────┬──────────┬────────────┬────────┤
# │ Test                               │ Ops      │ Time     │ Throughput │ Status │
# ├────────────────────────────────────┼──────────┼──────────┼────────────┼────────┤
# │ is_trading_day (single-thread)     │      365 │ 0.000 s  │ 3,210,937  │ ✅ PASS│
# │ find_next_trading_date             │       13 │ 0.000 s  │   736,837  │ ✅ PASS│
# │ T+1/T+2/T+3 calculations           │       39 │ 0.000 s  │   352,162  │ ✅ PASS│
# │ is_market_open                     │    1,000 │ 0.021 s  │    47,926  │ ✅ PASS│
# │ market_window (no buffer)          │      100 │ 0.002 s  │    43,839  │ ✅ PASS│
# │ market_window (pre15/post30)       │      100 │ 0.002 s  │    47,531  │ ✅ PASS│
# │ market_window (pre60/post120)      │      100 │ 0.002 s  │    46,583  │ ✅ PASS│
# ├────────────────────────────────────┼──────────┼──────────┼────────────┼────────┤
# │ Multi-thread (4 threads)           │   40,000 │ 0.015 s  │ 2,816,544  │ ✅ PASS│
# │ Multi-thread (8 threads)           │   80,000 │ 0.027 s  │ 2,989,087  │ ✅ PASS│
# ├────────────────────────────────────┼──────────┼──────────┼────────────┼────────┤
# │ Cache cold (first 10 calls)        │       10 │ 0.000 s  │ 1,127,040  │   N/A  │
# │ Cache warm (next 10 calls)         │       10 │ 0.000 s  │ 1,725,076  │   N/A  │
# │ Cache speedup                      │        - │       -  │    1.5x    │   N/A  │
# └────────────────────────────────────┴──────────┴──────────┴────────────┴────────┘
# SYSTEM: Ubuntu 24.04.4 LTS | AMD Ryzen 7 5800H (16 cores, 13Gi RAM) | Python 3.12.3
# TESTED: 2026-04-03 18:49 UTC

# ═══════════════════════════════════════════════════════════════════════════════
# QUICK START
# ═══════════════════════════════════════════════════════════════════════════════
#
# Set environment variables in .env:
#   PROJECT_DIRECTORY=/path/to/project   # Required: NO space before =
#
# Required config files (relative to PROJECT_DIRECTORY):
#   _CONFIG/trading_hours/trading_holidays.json
#   _CONFIG/trading_hours/market_timings.json
#
# Import and use:
#   from TRADING_HOURS import (
#       is_trading_day, is_today_trading_day, find_next_trading_date,
#       get_date_n_trading_days_later, is_market_open, processing_market_window,
#   )
#   from datetime import date
#
#   is_trading_day(date(2025, 7, 4))               # → True  (Friday)
#   is_trading_day(date(2025, 7, 5))               # → False (Saturday)
#   find_next_trading_date(date(2025, 7, 4))        # → date(2025, 7, 7)
#   is_market_open()                               # → True / False (live clock)
#   in_window, info = processing_market_window(minutes_before_open=15,
#                                               minutes_after_close=30)
#
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# KEY FEATURES & DESIGN DECISIONS
# ═══════════════════════════════════════════════════════════════════════════════
#
# 1. Two source files merged into one module
#    - a2_check_is_trading_day.py and a3_market_timing_utils.py are combined.
#    - WHY: Market-window checks depend on trading-day checks; keeping them in
#           separate files forced dynamic importlib loading at runtime which is
#           fragile and defeats static analysis. One module, one import.
#
# 2. Pure functions only — no OOP, no class state
#    - All logic is in module-level functions; holiday data and timings are
#      loaded once and passed as parameters (or cached at module level).
#    - WHY: Stateful classes (original TradingUtils / MarketTimingUtils) required
#           mocking __init__ IO in tests; pure functions are independently testable
#           without any mock setup.
#    - RULE OVERRIDE: §PYTHON no-oop — original code used @dataclass for Holiday,
#      YearHolidays, TradingHolidays, MarketTimings. Replaced with TypedDict per
#      RULE typeddict. Exception classes retained (RULE exception-class).
#      Restore when: never — TypedDict is the correct pattern here.
#
# 3. Holiday data loaded once at module import via _load_cached_holidays()
#    - WHY: Holiday file is read-only config that never changes mid-process;
#           loading once avoids repeated disk IO on every is_trading_day call.
#
# 4. Configurable market window via minutes_before_open / minutes_after_close
#    - WHY: Pre-market data fetching and post-close reconciliation jobs need to
#           run outside strict open/close times; hardcoding the window would
#           require code changes for each caller's schedule.
#
# 5. Midnight-crossing window support
#    - WHY: Some international markets (e.g. crypto, overnight futures) have
#           sessions that span midnight; the window logic handles close < open
#           by adding a day to close_dt.
#
# 6. stdlib zoneinfo used exclusively (no pytz)
#    - WHY: zoneinfo is in the standard library since Python 3.9 and works
#           directly with datetime.combine / datetime.now without pytz's
#           .localize() footgun. Using one timezone library eliminates the
#           pytz.utc vs timezone.utc inconsistency that existed when both
#           were mixed. pytz is no longer a dependency of this module.
#
# ═══════════════════════════════════════════════════════════════════════════════

# SECTION MAP:
#   SECTION 1 · ENVIRONMENT SETUP      — load and validate PROJECT_DIRECTORY
#   SECTION 2 · RETRY MECHANISM        — simple_retry for transient IO failures
#   SECTION 3 · TIMESTAMP UTILITIES    — pure datetime helpers
#   SECTION 4 · ENUMERATIONS           — Weekday enum for readable weekday checks
#   SECTION 5 · DATA MODELS            — TypedDicts + named exceptions
#   SECTION 6 · CONFIG LOADERS         — fetch_trading_holidays, fetch_market_timings
#   SECTION 7 · HOLIDAY PARSING        — parse_trading_holidays (pure)
#   SECTION 8 · TRADING DAY CHECKS     — is_trading_day, is_today_trading_day,
#                                        was_date_trading_day, find_next_trading_date,
#                                        get_date_n_trading_days_later
#   SECTION 9 · MARKET WINDOW CHECKS   — is_market_open, processing_market_window
#   SECTION 10 · PERFORMANCE TEST      — run_performance_test() live benchmark

# ── IMPORTS ──────────────────────────────────────────────────────────────────
# Three groups: stdlib · third-party · internal

from __future__ import annotations

# ── stdlib ───────────────────────────────────────────────────────────────────
import json
import os
import threading
import time
import warnings
from datetime import date, datetime, time as _time, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Callable, TypedDict, TypeVar
from unittest.mock import patch
from zoneinfo import ZoneInfo
# WHY zoneinfo: stdlib since Python 3.9; works directly with datetime.now(tz)
# and datetime.combine(date, time, tz) without pytz's .localize() footgun.
# All timezone references in this module use ZoneInfo — no mixed-library risk.

# ── third-party ──────────────────────────────────────────────────────────────
import pytest  # Test-only: used by test classes at module end
from dotenv import load_dotenv

T = TypeVar("T")


# ── SECTION 1 · ENVIRONMENT SETUP ────────────────────────────────────────────
# Goal: Load and validate PROJECT_DIRECTORY before any IO operation.

load_dotenv()

PROJECT_DIRECTORY: Path = Path(os.environ.get("PROJECT_DIRECTORY") or "")
# WHY: Fail fast at import — a missing PROJECT_DIRECTORY means config files
#      (holidays JSON, market timings JSON) cannot be located; better to crash
#      here than silently return wrong trading-day results later.
if not os.environ.get("PROJECT_DIRECTORY"):
    raise ValueError("PROJECT_DIRECTORY environment variable not set")

_HOLIDAYS_PATH: Path = (
    PROJECT_DIRECTORY / "_CONFIG" / "trading_hours" / "trading_holidays.json"
)
# WHY: Path computed once at module level so every function references the same
#      location; changing the config layout requires one edit, not a search.

_TIMINGS_PATH: Path = (
    PROJECT_DIRECTORY / "_CONFIG" / "trading_hours" / "market_timings.json"
)
# WHY: Same rationale as _HOLIDAYS_PATH — single source of truth for the path.


# ── TESTS ───────────────────────────────────────────────────────────────────
try:
    import pytest
except ImportError:
    pytest = None

if pytest is not None:

    class TestImportValidation:
        """WHY: Verify import-time validation correctly handles missing config."""

        def test_import_fails_when_project_directory_missing(self) -> None:
            import subprocess

            shared_lib_dir = os.path.dirname(os.path.abspath(__file__))
            env = os.environ.copy()
            env.pop("PROJECT_DIRECTORY", None)
            env["PYTHONPATH"] = shared_lib_dir
            result = subprocess.run(
                ["python3", "-c", "import TRADING_HOURS"],
                capture_output=True,
                text=True,
                env=env,
                cwd="/tmp",
            )
            assert result.returncode != 0, (
                f"Expected non-zero returncode, got {result.returncode}"
            )
            assert "PROJECT_DIRECTORY" in result.stderr, (
                f"Expected 'PROJECT_DIRECTORY' in stderr, got: {result.stderr}"
            )


# ── SECTION 2 · RETRY MECHANISM ──────────────────────────────────────────────
# Goal: Wrap transient IO (file reads) with a simple fixed-delay retry.


def simple_retry(func: Callable[[], T], max_attempts: int = 3, delay: float = 1.0) -> T:
    """
    [TIER 2] WHY: Config file reads can fail transiently under high disk IO or
    network-mounted filesystems; three attempts with a 1 s pause recovers from
    spikes without hiding real bugs (missing file → FileNotFoundError on all
    attempts).

    Retry policy: DOMAIN_RULES.md § RETRY — max 3, all exceptions retryable,
    1 s fixed delay. FileNotFoundError and json.JSONDecodeError are NOT retried
    in callers — they are caught before entering the retry closure.
    """
    for attempt in range(max_attempts):
        try:
            return func()
        except Exception as e:
            # WHY: Exception (not bare except) — catches all non-system-exit errors;
            #      local file IO has no 4xx-equivalent, so all exceptions are
            #      treated as transient retryable failures per DOMAIN_RULES retry policy.
            if attempt == max_attempts - 1:
                raise  # WHY: Re-raise original on final attempt — preserve traceback
            time.sleep(delay)
    raise RuntimeError("simple_retry: all attempts exhausted — unreachable")


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestSimpleRetry:
        """WHY: Verify retry mechanism correctly handles success/failure cycles."""

        def test_simple_retry(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── succeeds on first attempt (happy path) ────────────────────────────
            call_count = 0

            def succeed_immediately() -> int:
                nonlocal call_count
                call_count += 1
                return 42

            result = simple_retry(succeed_immediately, max_attempts=3, delay=0.01)
            assert result == 42, f"Expected 42, got {result}"
            assert call_count == 1, f"Expected 1 call, got {call_count}"

            # ── succeeds on third attempt (transient failure recovery) ─────────────
            call_count = 0

            def fail_twice_then_succeed() -> int:
                nonlocal call_count
                call_count += 1
                if call_count < 3:
                    raise RuntimeError("temporary failure")
                return 42

            result = simple_retry(fail_twice_then_succeed, max_attempts=3, delay=0.01)
            assert result == 42, f"Expected 42, got {result}"
            assert call_count == 3, f"Expected 3 calls, got {call_count}"

            # ── raises on exhaustion (persistent failure) ──────────────────────────
            call_count = 0

            def always_fail() -> int:
                nonlocal call_count
                call_count += 1
                raise RuntimeError("persistent failure")

            with pytest.raises(RuntimeError, match="persistent failure"):
                simple_retry(always_fail, max_attempts=3, delay=0.01)
            assert call_count == 3, f"Expected 3 calls, got {call_count}"


# ── SECTION 3 · TIMESTAMP UTILITIES ──────────────────────────────────────────
# Goal: Pure helpers that produce timestamps without IO or side effects.


def get_iso8601_timestamp() -> str:
    """
    [TIER 2] WHY: Centralises UTC timestamp formatting so all log/audit entries
    use the same ISO 8601 millisecond-precision format; callers never format
    datetimes inline.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    # WHY: [:-3] trims microseconds to milliseconds; appending "Z" makes the
    #      timezone explicit for downstream JSON consumers.
    # WHY timezone.utc and not ZoneInfo("UTC"): timezone.utc is the stdlib
    #      sentinel for UTC and is marginally cheaper; ZoneInfo is reserved for
    #      named IANA zones (e.g. "Asia/Kolkata") loaded from market_timings.json.


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetIso8601Timestamp:
        """WHY: Verify timestamp formatting produces ISO 8601 with millisecond precision."""

        def test_get_iso8601_timestamp(self) -> None:
            assert pytest is not None  # Type guard for pyright
            # ── returns a non-empty string ────────────────────────────────────────
            result = get_iso8601_timestamp()
            assert isinstance(result, str), f"Expected str, got {type(result).__name__}"
            assert len(result) > 0, "Timestamp must be non-empty"

            # ── ends with Z (UTC timezone) ─────────────────────────────────────────
            assert result.endswith("Z"), (
                f"Expected timestamp to end with 'Z', got {result!r}"
            )

            # ── has millisecond precision (3 digits after decimal) ──────────────
            assert "." in result, f"Expected '.' in timestamp, got {result!r}"
            parts = result.split(".")
            assert len(parts) == 2, f"Expected exactly one '.', got {len(parts)}"
            assert len(parts[1]) == 4, (
                f"Expected 3 digits + 'Z' after '.', got {len(parts[1])} chars: {parts[1]!r}"
            )


# ── SECTION 4 · ENUMERATIONS ─────────────────────────────────────────────────
# Goal: Provide named weekday constants so weekday comparisons read as intent.


# RULE OVERRIDE: §PYTHON no-oop — Weekday(Enum) uses class keyword but is a
# stdlib enumeration pattern equivalent to TypedDict for named constants;
# replacing with module-level ints would lose type safety and IDE completion.
# Restore when: Python adds a non-class enum syntax (unlikely).
class Weekday(Enum):
    """
    WHY: date.weekday() returns 0–6 as bare ints; comparing against SATURDAY.value
    and SUNDAY.value makes the intent readable and prevents off-by-one errors.
    """

    MONDAY = 0
    TUESDAY = 1
    WEDNESDAY = 2
    THURSDAY = 3
    FRIDAY = 4
    SATURDAY = 5
    SUNDAY = 6


# ── SECTION 5 · DATA MODELS ───────────────────────────────────────────────────
# Goal: Define all structured data shapes and domain exceptions.


class HolidayEntry(TypedDict):
    date: str  # Format: "DD-Mon-YYYY" e.g. "26-Feb-2025"
    day: str  # Day name e.g. "Wednesday"
    description: str  # Holiday name e.g. "Mahashivratri"


class YearHolidaysEntry(TypedDict):
    year: int
    holidays: list[HolidayEntry]


class TradingHolidaysData(TypedDict):
    market_holidays: list[YearHolidaysEntry]


class MarketTimingsData(TypedDict):
    open: str  # Format: "HH:MM"
    close: str  # Format: "HH:MM"
    timezone: str  # e.g. "Asia/Kolkata"
    trading_days_in_week: int  # Usually 5


class HolidayConfigError(ValueError):
    """WHY: Raised when the holidays JSON is missing, malformed, or has
    an invalid date entry — lets callers distinguish config problems from
    runtime trading-day errors."""


class MarketTimingError(ValueError):
    """WHY: Raised when market_timings.json is missing, malformed, or contains
    an invalid time string — distinct from HolidayConfigError so callers can
    handle each config failure separately."""


# ── SECTION 6 · CONFIG LOADERS ───────────────────────────────────────────────
# Goal: Load raw JSON config files from disk with retry and structured errors.


def fetch_trading_holidays() -> set[date]:
    """
    [TIER 2] WHY: Reads trading_holidays.json once and returns a set of holiday
    dates for the current and future years only — past years are irrelevant to
    live trading and skipping them keeps the set small for O(1) lookups.
    """

    def _read_file() -> dict:
        with open(_HOLIDAYS_PATH) as f:
            return json.load(f)

    try:
        raw: dict = simple_retry(_read_file)
    except FileNotFoundError as exc:
        raise HolidayConfigError(f"Holiday file not found: {_HOLIDAYS_PATH}") from exc
    except json.JSONDecodeError as exc:
        raise HolidayConfigError("trading_holidays.json contains invalid JSON") from exc

    return parse_trading_holidays(raw)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestFetchTradingHolidays:
        """WHY: Verify trading holidays loading handles file errors and valid data."""

        def test_fetch_trading_holidays(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import tempfile

            global _HOLIDAY_CACHE
            global _HOLIDAYS_PATH
            original = _HOLIDAY_CACHE
            original_path = _HOLIDAYS_PATH
            temp_path = None
            try:
                _HOLIDAY_CACHE = None

                # ── returns set of dates from valid JSON ───────────────────────────
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False
                ) as f:
                    json.dump(
                        {
                            "market_holidays": [
                                {
                                    "year": 2099,
                                    "holidays": [
                                        {
                                            "date": "01-Jan-2099",
                                            "day": "Wednesday",
                                            "description": "New Year",
                                        }
                                    ],
                                }
                            ]
                        },
                        f,
                    )
                    temp_path = f.name
                _HOLIDAYS_PATH = Path(temp_path)
                result = fetch_trading_holidays()
                assert isinstance(result, set), (
                    f"Expected set, got {type(result).__name__}"
                )
                assert date(2099, 1, 1) in result, "Expected 2099-01-01 in holiday set"

                # ── missing file raises HolidayConfigError ─────────────────────────
                _HOLIDAY_CACHE = None
                _HOLIDAYS_PATH = Path("/nonexistent/holidays.json")
                with pytest.raises(HolidayConfigError, match="not found"):
                    fetch_trading_holidays()

                # ── invalid JSON raises HolidayConfigError ──────────────────────────
                _HOLIDAY_CACHE = None
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False
                ) as f:
                    f.write("not valid json")
                    temp_path = f.name
                _HOLIDAYS_PATH = Path(temp_path)
                with pytest.raises(HolidayConfigError, match="invalid JSON"):
                    fetch_trading_holidays()
            finally:
                _HOLIDAY_CACHE = original
                _HOLIDAYS_PATH = original_path
                if temp_path and os.path.exists(temp_path):
                    os.unlink(temp_path)


def fetch_market_timings() -> MarketTimingsData:
    """
    [TIER 2] WHY: Reads market_timings.json and returns the validated timings
    dict; raises MarketTimingError on any config problem so callers get a clear
    message rather than a raw KeyError or FileNotFoundError.
    """

    def _read_file() -> dict:
        with open(_TIMINGS_PATH) as f:
            return json.load(f)

    try:
        raw: dict = simple_retry(_read_file)
    except FileNotFoundError as exc:
        raise MarketTimingError(
            f"Market timings file not found: {_TIMINGS_PATH}"
        ) from exc
    except json.JSONDecodeError as exc:
        raise MarketTimingError("market_timings.json contains invalid JSON") from exc

    try:
        mt = raw["market_timings"]
        return MarketTimingsData(
            open=mt["open"],
            close=mt["close"],
            timezone=mt["timezone"],
            trading_days_in_week=mt.get("trading_days_in_week", 5),
        )
    except KeyError as exc:
        raise MarketTimingError(
            f"Missing required field in market_timings.json: {exc}"
        ) from exc


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestFetchMarketTimings:
        """WHY: Verify market timings loading handles file errors and valid data."""

        def test_fetch_market_timings(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import tempfile

            global _TIMINGS_CACHE
            global _TIMINGS_PATH
            original = _TIMINGS_CACHE
            original_path = _TIMINGS_PATH
            temp_path = None
            try:
                _TIMINGS_CACHE = None

                # ── returns MarketTimingsData from valid JSON ──────────────────────
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False
                ) as f:
                    json.dump(
                        {
                            "market_timings": {
                                "open": "09:15",
                                "close": "15:30",
                                "timezone": "Asia/Kolkata",
                                "trading_days_in_week": 5,
                            }
                        },
                        f,
                    )
                    temp_path = f.name
                _TIMINGS_PATH = Path(temp_path)
                result = fetch_market_timings()
                assert result["open"] == "09:15", (
                    f"Expected '09:15', got {result['open']!r}"
                )
                assert result["close"] == "15:30", (
                    f"Expected '15:30', got {result['close']!r}"
                )
                assert result["timezone"] == "Asia/Kolkata", (
                    f"Expected 'Asia/Kolkata', got {result['timezone']!r}"
                )
                assert result["trading_days_in_week"] == 5, (
                    f"Expected 5, got {result['trading_days_in_week']}"
                )

                # ── missing file raises MarketTimingError ──────────────────────────
                _TIMINGS_CACHE = None
                _TIMINGS_PATH = Path("/nonexistent/timings.json")
                with pytest.raises(MarketTimingError, match="not found"):
                    fetch_market_timings()

                # ── missing required field raises MarketTimingError ────────────────
                _TIMINGS_CACHE = None
                with tempfile.NamedTemporaryFile(
                    mode="w", suffix=".json", delete=False
                ) as f:
                    json.dump(
                        {
                            "market_timings": {"open": "09:15"}
                        },  # missing close, timezone
                        f,
                    )
                    temp_path = f.name
                _TIMINGS_PATH = Path(temp_path)
                with pytest.raises(MarketTimingError, match="Missing required field"):
                    fetch_market_timings()
            finally:
                _TIMINGS_CACHE = original
                _TIMINGS_PATH = original_path
                if temp_path and os.path.exists(temp_path):
                    os.unlink(temp_path)


# ── Module-level cache — loaded once at first call, reused thereafter ─────────
_HOLIDAY_CACHE: set[date] | None = None
_TIMINGS_CACHE: MarketTimingsData | None = None
_HOLIDAY_CACHE_LOCK = threading.Lock()
_TIMINGS_CACHE_LOCK = threading.Lock()
# WHY: Holiday and timing data are static config; reloading from disk on every
#      is_trading_day call would add needless latency in tight trading loops.
# WHY locks: Double-checked locking prevents two threads from both seeing
#      cache=None simultaneously and both calling fetch. The lock is only
#      acquired when cache is None (i.e. exactly once per process lifetime).


def _get_holidays() -> set[date]:
    """[TIER 2] WHY: Lazy-loads and caches the holiday set so the first call
    pays the disk IO cost and all subsequent calls are free.
    Double-checked locking: outer check avoids lock acquisition on the hot path
    (cache already populated); inner check prevents double-load under contention.
    """
    global _HOLIDAY_CACHE
    if _HOLIDAY_CACHE is None:
        with _HOLIDAY_CACHE_LOCK:
            if _HOLIDAY_CACHE is None:
                _HOLIDAY_CACHE = fetch_trading_holidays()
    return _HOLIDAY_CACHE


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetHolidays:
        """WHY: Verify lazy-loading and caching of holiday data."""

        def test_get_holidays(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                # ── returns cached set of dates ───────────────────────────────────
                _HOLIDAY_CACHE = {date(2025, 1, 1)}
                result = _get_holidays()
                assert date(2025, 1, 1) in result, (
                    "Expected 2025-01-01 in cached holidays"
                )

                # ── lazy loads from fetch when cache is None ──────────────────────
                # WHY: Mock fetch to avoid needing real config files in CI
                _HOLIDAY_CACHE = None
                with patch(
                    "TRADING_HOURS.fetch_trading_holidays",
                    return_value={date(2025, 12, 25)},
                ):
                    result = _get_holidays()
                assert isinstance(result, set), (
                    f"Expected set, got {type(result).__name__}"
                )
                assert date(2025, 12, 25) in result, "Expected mocked holiday in result"
                assert _HOLIDAY_CACHE is not None, (
                    "Cache should be populated after first call"
                )
            finally:
                _HOLIDAY_CACHE = original


def _get_timings() -> MarketTimingsData:
    """[TIER 2] WHY: Same double-checked locking pattern as _get_holidays —
    timings never change mid-process and the lock is only contended on the
    first call.
    """
    global _TIMINGS_CACHE
    if _TIMINGS_CACHE is None:
        with _TIMINGS_CACHE_LOCK:
            if _TIMINGS_CACHE is None:
                _TIMINGS_CACHE = fetch_market_timings()
    return _TIMINGS_CACHE


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetTimings:
        """WHY: Verify lazy-loading and caching of market timings."""

        def test_get_timings(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _TIMINGS_CACHE
            original = _TIMINGS_CACHE
            try:
                # ── returns cached MarketTimingsData ───────────────────────────────
                test_timings = MarketTimingsData(
                    open="09:15",
                    close="15:30",
                    timezone="Asia/Kolkata",
                    trading_days_in_week=5,
                )
                _TIMINGS_CACHE = test_timings
                result = _get_timings()
                assert result == test_timings, (
                    f"Expected cached timings, got {result!r}"
                )

                # ── lazy loads from fetch when cache is None ──────────────────────
                # WHY: Mock fetch to avoid needing real config files in CI
                _TIMINGS_CACHE = None
                with patch(
                    "TRADING_HOURS.fetch_market_timings", return_value=test_timings
                ):
                    result = _get_timings()
                assert isinstance(result, dict), (
                    f"Expected dict, got {type(result).__name__}"
                )
                assert _TIMINGS_CACHE is not None, (
                    "Cache should be populated after first call"
                )
            finally:
                _TIMINGS_CACHE = original


# ── SECTION 7 · HOLIDAY PARSING ──────────────────────────────────────────────
# Goal: Convert raw JSON dict into a set of date objects (pure, no IO).


def parse_trading_holidays(raw: dict) -> set[date]:
    """
    [TIER 2] WHY: Separates the IO concern (fetch_trading_holidays) from the
    parsing concern so this function can be unit-tested with fixture dicts
    without touching the filesystem.

    Skips past years — holidays before the current calendar year are irrelevant
    to forward-looking trading-day queries and keeping them wastes memory.
    Skips malformed entries silently — a single bad date should not prevent
    the rest of the holiday calendar from loading.
    """
    current_year = datetime.now(timezone.utc).year
    holiday_dates: set[date] = set()

    for year_entry in raw.get("market_holidays", []):
        year = year_entry.get("year")
        if year is None or year < current_year:
            # WHY: Past years are never queried; skipping them keeps the set lean.
            continue
        for h in year_entry.get("holidays", []):
            try:
                holiday_dates.add(datetime.strptime(h["date"], "%d-%b-%Y").date())
            except (KeyError, ValueError) as e:
                # WHY: A malformed entry should not crash the entire load —
                #      one bad date in a 20-holiday year is recoverable.
                # WHY warn: Silent skip hides config mistakes from operators;
                #      a UserWarning surfaces the issue without halting the load.
                warnings.warn(
                    f"Skipping malformed holiday entry in year {year}: {e}",
                    UserWarning,
                    stacklevel=2,
                )
                continue

    return holiday_dates


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestParseTradingHolidays:
        """WHY: Verify holiday parsing is pure and handles malformed entries gracefully."""

        def test_parse_trading_holidays(self) -> None:
            assert pytest is not None  # Type guard for pyright
            import warnings as _warnings

            # ── valid entry is added to the set ───────────────────────────────────
            valid_raw = {
                "market_holidays": [
                    {
                        "year": 2099,
                        "holidays": [
                            {
                                "date": "01-Jan-2099",
                                "day": "Wednesday",
                                "description": "New Year",
                            }
                        ],
                    }
                ]
            }
            assert date(2099, 1, 1) in parse_trading_holidays(valid_raw), (
                "Expected 2099-01-01 in parsed holidays"
            )

            # ── malformed entry is skipped without crashing ───────────────────────
            malformed_raw = {
                "market_holidays": [
                    {
                        "year": 2099,
                        "holidays": [
                            {"date": "BAD-DATE", "day": "X", "description": "X"}
                        ],
                    }
                ]
            }
            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                assert len(parse_trading_holidays(malformed_raw)) == 0, (
                    "Malformed entries should produce empty set"
                )

            # ── holiday on weekend is included (redundant but harmless) ──────────
            weekend_holiday_raw = {
                "market_holidays": [
                    {
                        "year": 2099,
                        "holidays": [
                            {
                                "date": "05-Sep-2099",
                                "day": "Saturday",
                                "description": "Test",
                            }
                        ],
                    }
                ]
            }
            holidays = parse_trading_holidays(weekend_holiday_raw)
            assert date(2099, 9, 5) in holidays, (
                "Weekend holiday should still be in the set"
            )

            # ── malformed entry emits UserWarning ──────────────────────────────────
            raw = {
                "market_holidays": [
                    {
                        "year": 2099,
                        "holidays": [
                            {"date": "BAD-DATE", "day": "X", "description": "X"}
                        ],
                    }
                ]
            }
            with _warnings.catch_warnings(record=True) as caught:
                _warnings.simplefilter("always")
                result = parse_trading_holidays(raw)
            assert len(result) == 0, f"Expected empty set, got {len(result)} holidays"
            assert any("malformed holiday" in str(w.message).lower() for w in caught), (
                f"Expected UserWarning about malformed holiday, got: {[str(w.message) for w in caught]}"
            )


# ── SECTION 8 · TRADING DAY CHECKS ───────────────────────────────────────────
# Goal: Pure functions that answer "is this date a trading day?" questions.


def is_trading_day(check_date: date) -> bool:
    """
    [TIER 1] WHY: Core predicate — returns False for weekends and exchange
    holidays, True otherwise. Used by every scheduling and order-placement
    decision.
    """
    if check_date.weekday() in (Weekday.SATURDAY.value, Weekday.SUNDAY.value):
        return False
    return check_date not in _get_holidays()


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestIsTradingDay:
        """WHY: Verify weekday and weekend classification without requiring real holiday data."""

        def test_is_trading_day(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                # ── Pre-populate cache with empty set so no file I/O needed ────────
                _HOLIDAY_CACHE = set()

                # ── Friday returns true (standard trading day) ────────────────────────
                friday = date(2025, 7, 4)
                assert is_trading_day(friday) is True, (
                    f"Friday {friday} must be a trading day"
                )

                # ── Saturday returns false (weekend) ──────────────────────────────────
                saturday = date(2025, 7, 5)
                assert is_trading_day(saturday) is False, (
                    f"Saturday {saturday} must not be a trading day"
                )

                # ── Sunday returns false (weekend) ───────────────────────────────────
                sunday = date(2025, 7, 6)
                assert is_trading_day(sunday) is False, (
                    f"Sunday {sunday} must not be a trading day"
                )
            finally:
                _HOLIDAY_CACHE = original


def is_today_trading_day() -> bool:
    """
    [TIER 1] WHY: Convenience wrapper for the common case of checking today's
    date; avoids callers having to import datetime just to call is_trading_day.
    Uses ZoneInfo("UTC") consistent with the rest of the module's timezone
    approach — timezone.utc is reserved for the UTC-sentinel use in
    get_iso8601_timestamp only.
    """
    return is_trading_day(datetime.now(ZoneInfo("UTC")).date())


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestIsTodayTradingDay:
        """WHY: Verify today-trading-day check uses current date correctly."""

        def test_is_today_trading_day(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                # ── Pre-populate cache so no file I/O needed ─────────────────────
                _HOLIDAY_CACHE = set()
                # ── returns bool (never raises) ────────────────────────────────────────
                result = is_today_trading_day()
                assert isinstance(result, bool), (
                    f"Expected bool, got {type(result).__name__}"
                )
            finally:
                _HOLIDAY_CACHE = original


def was_date_trading_day(check_date: date) -> bool:
    """
    [TIER 1] WHY: Explicit name for historical lookups — makes call-site intent
    clear vs is_trading_day which is used for both past and future dates.
    """
    return is_trading_day(check_date)


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestWasDateTradingDay:
        """WHY: Verify historical date check has same logic as is_trading_day."""

        def test_was_date_trading_day(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                _HOLIDAY_CACHE = set()
                # ── weekend returns false ───────────────────────────────────────────────
                saturday = date(2025, 7, 5)
                assert was_date_trading_day(saturday) is False, (
                    f"Saturday {saturday} must not be a trading day"
                )

                # ── weekday returns true ─────────────────────────────────────────────
                monday = date(2025, 7, 7)
                assert was_date_trading_day(monday) is True, (
                    f"Monday {monday} must be a trading day"
                )
            finally:
                _HOLIDAY_CACHE = original


def find_next_trading_date(from_date: date, inclusive: bool = False) -> date:
    """
    [TIER 1] WHY: Centralises the "advance to next valid trading day" logic
    so no caller implements their own date-crawling loop.

    inclusive=True returns from_date itself if it is already a trading day,
    which is needed by get_date_n_trading_days_later to avoid double-advancing
    when the start date is a trading day.
    """
    if inclusive and is_trading_day(from_date):
        return from_date
    current = from_date
    while True:
        current += timedelta(days=1)
        if is_trading_day(current):
            return current


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestFindNextTradingDate:
        """WHY: Verify that date-crawling skips weekends and returns the correct next day."""

        def test_find_next_trading_date(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                _HOLIDAY_CACHE = set()
                # ── Friday → Monday (standard weekend skip) ───────────────────────────
                friday = date(2025, 7, 4)
                assert find_next_trading_date(friday) == date(2025, 7, 7), (
                    f"Friday {friday} should advance to Monday 2025-07-07"
                )

                # ── inclusive=True on trading day returns same day ───────────────────
                monday = date(2025, 7, 7)
                assert find_next_trading_date(monday, inclusive=True) == monday, (
                    f"inclusive=True on trading day {monday} should return same day"
                )

                # ── Saturday → Monday (non-trading start) ────────────────────────────
                saturday = date(2025, 7, 5)
                assert find_next_trading_date(saturday) == date(2025, 7, 7), (
                    f"Saturday {saturday} should advance to Monday 2025-07-07"
                )
            finally:
                _HOLIDAY_CACHE = original


def get_date_n_trading_days_later(from_date: date, trading_days: int) -> date:
    """
    [TIER 1] WHY: Answers "what date is N trading days from today?" — needed
    by settlement-date calculations (T+1, T+2) and delivery scheduling.

    trading_days=0 returns from_date unchanged regardless of whether it is
    a trading day, matching standard T+0 semantics.
    """
    if trading_days == 0:
        return from_date

    # WHY: If from_date is a trading day, the first step moves to the NEXT
    #      trading day (non-inclusive); if it is a weekend/holiday, we first
    #      advance to the nearest trading day (inclusive) before counting.
    if is_trading_day(from_date):
        current = find_next_trading_date(from_date, inclusive=False)
    else:
        current = find_next_trading_date(from_date, inclusive=True)

    # WHY: trading_days - 1 additional advances because the first advance
    #      above already consumed one trading-day step.
    for _ in range(max(trading_days - 1, 0)):
        current = find_next_trading_date(current, inclusive=False)

    return current


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestGetDateNTradingDaysLater:
        """WHY: Verify N-day counting from trading days, weekends, and zero-day edge case."""

        def test_get_date_n_trading_days_later(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE
            original = _HOLIDAY_CACHE
            try:
                _HOLIDAY_CACHE = set()
                # ── T+0 returns same date (T+0 semantics) ─────────────────────────────
                friday = date(2025, 7, 4)
                assert get_date_n_trading_days_later(friday, 0) == friday, (
                    f"T+0 from {friday} should return same date"
                )

                # ── T+1 from Friday crosses weekend to Monday ────────────────────────
                assert get_date_n_trading_days_later(date(2025, 7, 4), 1) == date(
                    2025, 7, 7
                ), "T+1 from Friday should land on Monday"

                # ── T+2 from Friday lands on Tuesday ─────────────────────────────────
                assert get_date_n_trading_days_later(date(2025, 7, 4), 2) == date(
                    2025, 7, 8
                ), "T+2 from Friday should land on Tuesday"

                # ── T+1 from Saturday (non-trading day) ───────────────────────────────
                # WHY: Starting from a non-trading day, T+1 counts from the next valid
                #      trading day (Monday), so result is Monday.
                assert get_date_n_trading_days_later(date(2025, 7, 5), 1) == date(
                    2025, 7, 7
                ), "T+1 from Saturday should land on Monday"
            finally:
                _HOLIDAY_CACHE = original


# ── SECTION 9 · MARKET WINDOW CHECKS ─────────────────────────────────────────
# Goal: Determine whether the current clock time falls inside the trading window.


def _parse_time_str(time_str: str) -> _time:
    """
    [TIER 2] WHY: Centralises HH:MM parsing and converts ValueError into
    MarketTimingError so callers never see a raw strptime exception.
    """
    try:
        return datetime.strptime(time_str, "%H:%M").time()
    except ValueError as exc:
        raise MarketTimingError(
            f"Invalid time format {time_str!r} — expected HH:MM"
        ) from exc


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestParseTimeStr:
        """WHY: Verify time string parsing handles valid and invalid formats."""

        def test_parse_time_str(self) -> None:
            assert pytest is not None  # Type guard for pyright
            from datetime import time

            # ── valid HH:MM returns datetime.time ─────────────────────────────────
            result = _parse_time_str("09:30")
            assert isinstance(result, time), (
                f"Expected time, got {type(result).__name__}"
            )
            assert result.hour == 9, f"Expected hour 9, got {result.hour}"
            assert result.minute == 30, f"Expected minute 30, got {result.minute}"

            # ── invalid format raises MarketTimingError ──────────────────────────
            with pytest.raises(MarketTimingError, match="Invalid time format"):
                _parse_time_str("930")

            # ── midnight (00:00) is parsed correctly ─────────────────────────────
            result = _parse_time_str("00:00")
            assert result.hour == 0, f"Expected hour 0, got {result.hour}"
            assert result.minute == 0, f"Expected minute 0, got {result.minute}"


def processing_market_window(
    minutes_before_open: int = 0,
    minutes_after_close: int = 0,
) -> tuple[bool, str]:
    """
    [TIER 1] WHY: Returns both a bool and a human-readable debug string so
    callers can log exactly why a window check passed or failed without
    re-computing it.

    minutes_before_open / minutes_after_close expand the window for pre-market
    data fetching and post-close reconciliation jobs respectively.

    Overnight sessions (close_time < open_time): close_dt is advanced one day
    so the interval is contiguous. For early-morning times that fall in the tail
    of an overnight session, `now` is compared directly — no date reconstruction.
    """
    if minutes_before_open < 0 or minutes_after_close < 0:
        raise ValueError(
            "minutes_before_open and minutes_after_close must be non-negative"
        )
    if not is_today_trading_day():
        return False, "Not a trading day"

    timings = _get_timings()
    tz = ZoneInfo(timings["timezone"])
    now = datetime.now(tz)

    open_time = _parse_time_str(timings["open"])
    close_time = _parse_time_str(timings["close"])

    open_dt = datetime.combine(now.date(), open_time, tz)
    close_dt = datetime.combine(now.date(), close_time, tz)

    if close_time <= open_time:
        close_dt += timedelta(days=1)
        # WHY: <= covers overnight (close < open) and 24/7 (close == open);
        #      adding a day makes the interval contiguous so a single range
        #      check works for all cases including early-morning tail times.

    window_start = open_dt - timedelta(minutes=minutes_before_open)
    window_end = close_dt + timedelta(minutes=minutes_after_close)

    in_window = window_start <= now < window_end
    # WHY: `now` is a fully-anchored datetime — comparing it directly to
    #      window_start and window_end works correctly across midnight without
    #      any date-splitting. The original bug was reconstructing current_dt
    #      from now.date() + now.time() which loses the date context for
    #      early-morning times in overnight sessions.

    debug_info = (
        f"Market {timings['open']}–{timings['close']} | "
        f"Window {window_start.strftime('%H:%M')}–{window_end.strftime('%H:%M %Y-%m-%d')} | "
        f"Now {now.strftime('%H:%M %Y-%m-%d')} | "
        f"In window: {in_window}"
    )
    return in_window, debug_info


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestProcessingMarketWindow:
        """WHY: Verify market window calculation handles all edge cases."""

        def test_processing_market_window(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE, _TIMINGS_CACHE
            original_holidays = _HOLIDAY_CACHE
            original_timings = _TIMINGS_CACHE
            try:
                # ── Pre-populate caches so no file I/O needed ─────────────────────
                _HOLIDAY_CACHE = set()
                _TIMINGS_CACHE = MarketTimingsData(
                    open="09:15",
                    close="15:30",
                    timezone="Asia/Kolkata",
                    trading_days_in_week=5,
                )
                # ── returns (bool, str) tuple ──────────────────────────────────────────
                result = processing_market_window()
                assert isinstance(result, tuple), (
                    f"Expected tuple, got {type(result).__name__}"
                )
                assert len(result) == 2, (
                    f"Expected 2-element tuple, got {len(result)} elements"
                )
                assert isinstance(result[0], bool), (
                    f"Expected bool at index 0, got {type(result[0]).__name__}"
                )
                assert isinstance(result[1], str), (
                    f"Expected str at index 1, got {type(result[1]).__name__}"
                )

                # ── debug info structure (either market hours or non-trading day msg) ─
                in_window, info = processing_market_window()
                assert isinstance(in_window, bool), (
                    f"Expected bool, got {type(in_window).__name__}"
                )
                assert isinstance(info, str), f"Expected str, got {type(info).__name__}"
                # Either we get market hours info OR "Not a trading day" message
                has_market_info = (
                    "Market" in info and "Window" in info and "Now" in info
                )
                has_non_trading_msg = info == "Not a trading day"
                assert has_market_info or has_non_trading_msg, (
                    f"Unexpected info format: {info}"
                )

                # ── buffer parameters expand window (only on trading days) ─────────────
                if is_today_trading_day():
                    result = processing_market_window(
                        minutes_before_open=60, minutes_after_close=120
                    )
                    assert isinstance(result, tuple), (
                        f"Expected tuple, got {type(result).__name__}"
                    )
                    assert result[0] in (True, False), (
                        f"Expected bool, got {result[0]!r}"
                    )

                # ── negative minutes raises ValueError ────────────────────────────────
                with pytest.raises(ValueError, match="non-negative"):
                    processing_market_window(minutes_before_open=-1)

                with pytest.raises(ValueError, match="non-negative"):
                    processing_market_window(minutes_after_close=-5)
            finally:
                _HOLIDAY_CACHE = original_holidays
                _TIMINGS_CACHE = original_timings


def is_market_open() -> bool:
    """
    [TIER 1] WHY: Convenience wrapper for the standard no-buffer window check;
    callers that only need a yes/no answer don't have to unpack a tuple.
    """
    in_window, _ = processing_market_window()
    return in_window


# ── TESTS ───────────────────────────────────────────────────────────────────
if pytest is not None:

    class TestIsMarketOpen:
        """WHY: Verify is_market_open delegates to processing_market_window."""

        def test_is_market_open(self) -> None:
            assert pytest is not None  # Type guard for pyright
            global _HOLIDAY_CACHE, _TIMINGS_CACHE
            original_holidays = _HOLIDAY_CACHE
            original_timings = _TIMINGS_CACHE
            try:
                # ── Pre-populate caches so no file I/O needed ─────────────────────
                _HOLIDAY_CACHE = set()
                _TIMINGS_CACHE = MarketTimingsData(
                    open="09:15",
                    close="15:30",
                    timezone="Asia/Kolkata",
                    trading_days_in_week=5,
                )
                # ── returns bool (never raises) ────────────────────────────────────────
                result = is_market_open()
                assert isinstance(result, bool), (
                    f"Expected bool, got {type(result).__name__}"
                )
            finally:
                _HOLIDAY_CACHE = original_holidays
                _TIMINGS_CACHE = original_timings


# ── SECTION 10 · PERFORMANCE TEST ─────────────────────────────────────────────
# Goal: Provide live performance benchmarks for all public API operations.


def run_performance_test(
    single_thread_count: int = 100000,
    multi_thread_count: int = 10000,
    num_threads: int = 4,
    show_logs: bool = True,
) -> dict:
    """
    Run live performance benchmarks for TRADING_HOURS on current hardware.

    Tests:
      1. Single-thread is_trading_day throughput
      2. Single-thread find_next_trading_date throughput
      3. Single-thread get_date_n_trading_days_later throughput (T+1, T+2, T+3)
      4. processing_market_window throughput (various buffer configs)
      5. is_market_open throughput
      6. Multi-thread is_trading_day throughput (4 threads)
      7. Multi-thread is_trading_day throughput (8 threads)
      8. Cache performance (cold vs warm)
      9. Lookup time by day type (weekday, weekend, holiday)

    Args:
        single_thread_count: Number of operations for single-thread tests.
        multi_thread_count: Ops per thread for multi-thread tests.
        num_threads: Worker thread count for the primary multi-thread test.
        show_logs: Print per-test progress lines (set False for silent run).

    Returns:
        dict with keys: is_trading_day, find_next_trading_date, t_plus_calc,
                        market_window, is_market_open, multi_thread_4,
                        multi_thread_8, cache_performance, day_type_lookup.
    """
    from datetime import datetime as _dt, timedelta as _td, date as _date

    print("\n" + "=" * 70)
    print("TRADING_HOURS Live Performance Test")
    print(f"Started: {_dt.now().isoformat()}")
    print("=" * 70)

    results: dict = {}

    # ── Test data: all trading days in 2025 ───────────────────────────────────
    start_date = _date(2025, 1, 1)
    end_date = _date(2025, 12, 31)
    all_dates = []
    current = start_date
    while current <= end_date:
        all_dates.append(current)
        current += _td(days=1)

    if show_logs:
        print(f"\n📊 Test dataset: {len(all_dates):,} dates (full year 2025)")
        print("-" * 40)

    # ── 1. Single-Thread is_trading_day ───────────────────────────────────────
    if show_logs:
        print(f"\n📊 Single-Thread is_trading_day ({len(all_dates):,} ops):")
        print("-" * 40)

    start = time.time()
    trading_day_results = [is_trading_day(d) for d in all_dates]
    elapsed_isd = time.time() - start
    throughput_isd = len(all_dates) / elapsed_isd
    trading_days_count = sum(1 for r in trading_day_results if r)

    results["is_trading_day"] = {
        "ops": len(all_dates),
        "time_seconds": round(elapsed_isd, 3),
        "throughput": round(throughput_isd, 0),
        "trading_days_count": trading_days_count,
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {len(all_dates):,}")
        print(f"   Time:       {elapsed_isd:.3f} seconds")
        print(f"   Throughput: {throughput_isd:.0f} ops/sec")
        print(f"   Trading days in 2025: {trading_days_count}")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_isd >= 10000 else "⚠️ Below target")

    # ── 2. Single-Thread find_next_trading_date ───────────────────────────────
    sample_dates = all_dates[::30]  # Sample every 30 days

    if show_logs:
        print(f"\n📊 Single-Thread find_next_trading_date ({len(sample_dates):,} ops):")
        print("-" * 40)

    start = time.time()
    for d in sample_dates:
        find_next_trading_date(d)
    elapsed_find = time.time() - start
    throughput_find = len(sample_dates) / elapsed_find

    results["find_next_trading_date"] = {
        "ops": len(sample_dates),
        "time_seconds": round(elapsed_find, 3),
        "throughput": round(throughput_find, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {len(sample_dates):,}")
        print(f"   Time:       {elapsed_find:.3f} seconds")
        print(f"   Throughput: {throughput_find:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_find >= 10000 else "⚠️ Below target")

    # ── 3. Single-Thread get_date_n_trading_days_later (T+1, T+2, T+3) ────────
    if show_logs:
        print(
            f"\n📊 Single-Thread T+1/T+2/T+3 calculations ({len(sample_dates) * 3:,} ops):"
        )
        print("-" * 40)

    start = time.time()
    for d in sample_dates:
        get_date_n_trading_days_later(d, 1)
        get_date_n_trading_days_later(d, 2)
        get_date_n_trading_days_later(d, 3)
    elapsed_tcalc = time.time() - start
    tcalc_ops = len(sample_dates) * 3
    throughput_tcalc = tcalc_ops / elapsed_tcalc

    results["t_plus_calc"] = {
        "ops": tcalc_ops,
        "time_seconds": round(elapsed_tcalc, 3),
        "throughput": round(throughput_tcalc, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        {tcalc_ops:,}")
        print(f"   Time:       {elapsed_tcalc:.3f} seconds")
        print(f"   Throughput: {throughput_tcalc:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_tcalc >= 10000 else "⚠️ Below target")

    # ── 4. processing_market_window (various buffer configs) ──────────────────
    if show_logs:
        print("\n📊 processing_market_window (100 ops per config):")
        print("-" * 40)

    buffer_configs = [
        (0, 0, "No buffer"),
        (15, 30, "Pre 15min, Post 30min"),
        (60, 120, "Pre 1hr, Post 2hr"),
    ]

    market_window_results = {}
    for before, after, name in buffer_configs:
        start = time.time()
        for _ in range(100):
            in_window, info = processing_market_window(
                minutes_before_open=before, minutes_after_close=after
            )
        elapsed_mw = time.time() - start
        throughput_mw = 100 / elapsed_mw
        market_window_results[name] = round(throughput_mw, 0)

        if show_logs:
            print(f"   {name:25} {throughput_mw:.0f} ops/sec")

    results["market_window"] = market_window_results

    # ── 5. is_market_open (simple wrapper) ────────────────────────────────────
    if show_logs:
        print(f"\n📊 is_market_open (1,000 ops):")
        print("-" * 40)

    start = time.time()
    for _ in range(1000):
        is_market_open()
    elapsed_imo = time.time() - start
    throughput_imo = 1000 / elapsed_imo

    results["is_market_open"] = {
        "ops": 1000,
        "time_seconds": round(elapsed_imo, 3),
        "throughput": round(throughput_imo, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Ops:        1,000")
        print(f"   Time:       {elapsed_imo:.3f} seconds")
        print(f"   Throughput: {throughput_imo:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_imo >= 10000 else "⚠️ Below target")

    # ── 6. Multi-Thread is_trading_day (4 threads) ───────────────────────────
    mt4_threads = 4
    mt4_ops_per_thread = multi_thread_count
    mt4_total = mt4_threads * mt4_ops_per_thread

    if show_logs:
        print(
            f"\n📊 Multi-Thread is_trading_day ({mt4_threads} threads × {mt4_ops_per_thread:,} ops = {mt4_total:,} total):"
        )
        print("-" * 40)

    test_dates_mt = [_date(2025, 7, (i % 31) + 1) for i in range(mt4_ops_per_thread)]

    def _worker_isd(tid: int, dates_list: list[_date]) -> None:
        for d in dates_list:
            is_trading_day(d)

    threads_4 = [
        threading.Thread(target=_worker_isd, args=(i, test_dates_mt))
        for i in range(mt4_threads)
    ]
    start = time.time()
    for t in threads_4:
        t.start()
    for t in threads_4:
        t.join()
    elapsed_mt4 = time.time() - start
    throughput_mt4 = mt4_total / elapsed_mt4

    results["multi_thread_4"] = {
        "threads": mt4_threads,
        "ops_per_thread": mt4_ops_per_thread,
        "total_ops": mt4_total,
        "time_seconds": round(elapsed_mt4, 3),
        "throughput": round(throughput_mt4, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Total ops:  {mt4_total:,}")
        print(f"   Time:       {elapsed_mt4:.3f} seconds")
        print(f"   Throughput: {throughput_mt4:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_mt4 >= 10000 else "⚠️ Below target")

    # ── 7. Multi-Thread is_trading_day (8 threads) ───────────────────────────
    mt8_threads = 8
    mt8_ops_per_thread = multi_thread_count
    mt8_total = mt8_threads * mt8_ops_per_thread

    if show_logs:
        print(
            f"\n📊 Multi-Thread is_trading_day ({mt8_threads} threads × {mt8_ops_per_thread:,} ops = {mt8_total:,} total):"
        )
        print("-" * 40)

    threads_8 = [
        threading.Thread(target=_worker_isd, args=(i, test_dates_mt))
        for i in range(mt8_threads)
    ]
    start = time.time()
    for t in threads_8:
        t.start()
    for t in threads_8:
        t.join()
    elapsed_mt8 = time.time() - start
    throughput_mt8 = mt8_total / elapsed_mt8

    results["multi_thread_8"] = {
        "threads": mt8_threads,
        "ops_per_thread": mt8_ops_per_thread,
        "total_ops": mt8_total,
        "time_seconds": round(elapsed_mt8, 3),
        "throughput": round(throughput_mt8, 0),
        "target": 10000,
    }

    if show_logs:
        print(f"   Total ops:  {mt8_total:,}")
        print(f"   Time:       {elapsed_mt8:.3f} seconds")
        print(f"   Throughput: {throughput_mt8:.0f} ops/sec")
        print("   Target: ≥10,000 ops/sec → ", end="")
        print("✅ PASS" if throughput_mt8 >= 10000 else "⚠️ Below target")

    # ── 8. Cache Performance (cold vs warm) ──────────────────────────────────
    if show_logs:
        print("\n📊 Cache Performance (first 10 calls vs next 10 calls):")
        print("-" * 40)

    import TRADING_HOURS as th  # Self-import for cache manipulation

    # Cold cache (reset)
    th._HOLIDAY_CACHE = None
    th._TIMINGS_CACHE = None

    test_date = _date(2025, 7, 4)

    start = time.time()
    for _ in range(10):
        is_trading_day(test_date)
    elapsed_cold = time.time() - start

    start = time.time()
    for _ in range(10):
        is_trading_day(test_date)
    elapsed_warm = time.time() - start

    cold_throughput = 10 / elapsed_cold
    warm_throughput = 10 / elapsed_warm
    speedup = elapsed_cold / elapsed_warm

    results["cache_performance"] = {
        "cold_cache_ops_sec": round(cold_throughput, 0),
        "warm_cache_ops_sec": round(warm_throughput, 0),
        "speedup": round(speedup, 1),
    }

    if show_logs:
        print(f"   Cold cache (first 10 calls): {cold_throughput:.0f} ops/sec")
        print(f"   Warm cache (next 10 calls):  {warm_throughput:.0f} ops/sec")
        print(f"   Speedup: {speedup:.1f}x faster with cache")

    # ── 9. Lookup time by day type ───────────────────────────────────────────
    if show_logs:
        print("\n📊 Lookup Time by Day Type (1,000 ops each):")
        print("-" * 40)

    day_type_tests = [
        ("Monday (trading day)", _date(2025, 7, 7)),
        ("Saturday (weekend)", _date(2025, 7, 12)),
        ("Wednesday (trading day)", _date(2025, 7, 9)),
    ]

    day_type_results = {}
    for name, d in day_type_tests:
        start = time.time()
        for _ in range(1000):
            is_trading_day(d)
        elapsed_dt = time.time() - start
        throughput_dt = 1000 / elapsed_dt
        day_type_results[name] = round(throughput_dt, 0)

        if show_logs:
            print(f"   {name:25} {throughput_dt:.0f} ops/sec")

    results["day_type_lookup"] = day_type_results

    # ── Summary ───────────────────────────────────────────────────────────────
    print("\n" + "=" * 70)
    print("✅ Performance Test Complete")
    print("=" * 70)

    return results


# ── SECTION 11 · PUBLIC API EXPORTS ──────────────────────────────────────────
# Goal: Declare the explicit public surface of this module.

__all__ = [
    "is_trading_day",
    "is_today_trading_day",
    "was_date_trading_day",
    "find_next_trading_date",
    "get_date_n_trading_days_later",
    "is_market_open",
    "processing_market_window",
    "HolidayConfigError",
    "MarketTimingError",
    "run_performance_test",
]


# ═══════════════════════════════════════════════════════════════════════════════
# TEST COVERAGE MATRIX
# ═══════════════════════════════════════════════════════════════════════════════
#
# Tier 1 = Public API      → must be exhaustive; called by application code
# Tier 2 = Internal Logic  → correctness + resilience; helpers & infrastructure
# Tier 3 = Dev/Debug       → lower priority; import-time validation
#
# Legend: ✅ covered  ⚠️ partial  ❌ not covered
#
# ┌─────────────────────────────────────┬──────┬───────────┬────────┬────────────────────────────────────────────────────────────────────────┐
# │ Function / Component                │ Tier │ Test Class│ Tests  │ What is tested                                                         │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ is_trading_day()                    │  1   │TestIsTrad │ 3  ✅  │ Friday returns true, Saturday false, Sunday false                     │
# │ is_today_trading_day()              │  1   │TestToday  │ 1  ✅  │ returns bool (uses current date)                                      │
# │ was_date_trading_day()              │  1   │TestWasDat │ 2  ✅  │ weekend returns false, weekday returns true                          │
# │ find_next_trading_date()            │  1   │TestFindNex│ 3  ✅  │ Friday→Monday, inclusive flag, Saturday→Monday                        │
# │ get_date_n_trading_days_later()     │  1   │TestGetDat │ 4  ✅  │ T+0 returns same, T+1 crosses weekend, T+2, Saturday start           │
# │ is_market_open()                    │  1   │TestIsMkt  │ 1  ✅  │ delegates to processing_market_window, returns bool                  │
# │ processing_market_window()          │  1   │TestProcMkt│ 4  ✅  │ returns tuple, debug info, buffer expansion, negative minutes raises │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ simple_retry()                      │  2   │TestSmpRet │ 3  ✅  │ success on attempt 1, success on attempt 3, exhaustion raises        │
# │ get_iso8601_timestamp()             │  2   │TestISO8601│ 3  ✅  │ returns string, ends with Z, has milliseconds                         │
# │ parse_trading_holidays()            │  2   │TestParseTr│ 4  ✅  │ valid entry added, malformed entry skipped, weekend holiday included, │
# │                                     │      │           │        │ UserWarning emitted on malformed entry                               │
# │ _parse_time_str()                   │  2   │TestParseTm│ 3  ✅  │ valid HH:MM, invalid format raises, midnight parsed                  │
# │ fetch_trading_holidays()            │  2   │TestFetchTr│ 3  ✅  │ returns set of dates, missing file raises, invalid JSON raises       │
# │ fetch_market_timings()              │  2   │ 2   │TestFetchMkt│ 3 ✅  │ returns timings data, missing file raises, missing field raises       │
# │ _get_holidays()                     │  2   │TestGetHol │ 2  ✅  │ returns cached set, lazy loads from fetch                             │
# │ _get_timings()                      │  2   │TestGetTim │ 2  ✅  │ returns cached timings, lazy loads from fetch                         │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ PROJECT_DIRECTORY validation        │  3   │TestImpVal │ 1  ✅  │ raises ValueError if missing; subprocess test                       │
# ├─────────────────────────────────────┼──────┼───────────┼────────┼────────────────────────────────────────────────────────────────────────┤
# │ TOTALS                              │                  │        │                                                                        │
# │   Tier 1 — Public API               │    7 functions   │ 18 ✅  │ All public functions fully covered                                     │
# │   Tier 2 — Internal Logic           │    8 functions   │ 23 ✅  │ All Tier 2 helpers now fully covered                                    │
# │   Tier 3 — Dev/Debug                │    1 component   │  1 ✅  │ Import-time validation covered                                         │
# └─────────────────────────────────────┴──────┴───────────┴────────┴────────────────────────────────────────────────────────────────────────┘

# ═══════════════════════════════════════════════════════════════════════════════
# USAGE GUIDE
# ═══════════════════════════════════════════════════════════════════════════════
#
# Quick Start:
#   from TRADING_HOURS import (
#       is_trading_day, is_today_trading_day, find_next_trading_date,
#       get_date_n_trading_days_later, is_market_open, processing_market_window,
#   )
#   from datetime import date
#
#   is_trading_day(date(2025, 7, 4))               # → True  (Friday)
#   is_trading_day(date(2025, 7, 5))               # → False (Saturday)
#   find_next_trading_date(date(2025, 7, 4))        # → date(2025, 7, 7)
#   get_date_n_trading_days_later(date(2025, 7, 4), 2)  # → date(2025, 7, 8)
#   is_market_open()                               # → True / False (live clock)
#   in_window, info = processing_market_window(minutes_before_open=15,
#                                               minutes_after_close=30)
#
# Environment Variables (.env):
#   PROJECT_DIRECTORY=/path/to/project   # Required: NO space before =
#
# Config Files (relative to PROJECT_DIRECTORY):
#   _CONFIG/trading_hours/trading_holidays.json      # Required: holiday calendar
#   _CONFIG/trading_hours/market_timings.json        # Required: open/close/timezone
#
# ─────────────────────────────────────────────────────────────────────────────
# RELOAD CACHED DATA (after editing config files mid-process):
#   import TRADING_HOURS
#   TRADING_HOURS._HOLIDAY_CACHE = None   # forces next call to re-read disk
#   TRADING_HOURS._TIMINGS_CACHE = None
# ─────────────────────────────────────────────────────────────────────────────
#
# Run Tests:
#   python3 -m pytest TRADING_HOURS.py -v
#
# Run Performance Test:
#   python3 TRADING_HOURS.py
#
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("Testing TRADING_HOURS...")

    friday = date(2025, 7, 4)
    saturday = date(2025, 7, 5)

    assert is_trading_day(friday) is True, "Friday must be a trading day"
    assert is_trading_day(saturday) is False, "Saturday must not be a trading day"
    print("  is_trading_day (Fri/Sat)              ✅")

    assert find_next_trading_date(friday) == date(2025, 7, 7)
    assert find_next_trading_date(saturday) == date(2025, 7, 7)
    print("  find_next_trading_date                ✅")

    assert get_date_n_trading_days_later(friday, 0) == friday
    assert get_date_n_trading_days_later(friday, 1) == date(2025, 7, 7)
    assert get_date_n_trading_days_later(friday, 2) == date(2025, 7, 8)
    print("  get_date_n_trading_days_later         ✅")

    in_window, info = processing_market_window(
        minutes_before_open=60, minutes_after_close=120
    )
    print(f"  processing_market_window              ✅  ({info})")

    print("Done — verify _CONFIG/ files exist if any FileNotFoundError appears.")

    # Run full performance test — shows all 9 benchmark categories
    print("\n" + "=" * 60)
    print("Running FULL Performance Test Suite")
    print("=" * 60)
    run_performance_test(show_logs=True)
