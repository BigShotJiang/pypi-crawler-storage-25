# Gentiq Backend Framework (Python)

**The core Python engine for building high-performance, agentic AI backends.**

`gentiq-python` is a modular, [FastAPI](https://fastapi.tiangolo.com/)-based framework built on top of [PydanticAI](https://ai.pydantic.dev/). It handles all the infrastructure—persistence, security, and streaming—allowing you to focus entirely on defining your agents and tools.

---

## 🚀 Key Features

- **`GentiqApp` Factory**: Rapidly initialize a production-ready FastAPI application with just an agent.
- **Deep PydanticAI Integration**: Fully supports PydanticAI's type-safe agent system.
- **Dependency Injection**: Automatic injection of `AgentDeps` containing `UserStore`, `ChatStore`, and the current `User`.
- **Atomic Balance Tracking**: Integrated per-user token and request balance management with automatic deduction.
- **Pluggable Persistence**: Switch between SQLite/MongoDB and FileSystem/MinIO with simple configuration.
- **Advanced Admin Management**: Secure API endpoints for user analytics, chat history auditing, and permission-based administration.

---

## 📦 Installation

Since Gentiq is typically used as a core framework, you can install it via pip:

```bash
pip install gentiq
```

*For monorepo development, it is recommended to install it in editable mode:*

```bash
# In your app's pyproject.toml
[tool.uv.sources]
gentiq = { path = "../../../packages/gentiq-python", editable = true }
```

---

## 💡 Quick Start

```python
from gentiq import GentiqApp, AgentDeps
from pydantic_ai import Agent

# Define your agent
agent = Agent[AgentDeps[dict]]('openai:gpt-4o')

# Initialize GentiqApp
app = GentiqApp(agent, app_name="MyAI")

# GentiqApp.api is a regular FastAPI instance
# Run with: uvicorn main:app.api --reload
```

---

## 📂 Core Modules

- **`gentiq.app`**: The main application orchestrator (`GentiqApp`).
- **`gentiq.stores`**: High-level stores for users, chat history, and administration.
- **`gentiq.engines`**: Pluggable persistence backends (SQLite, MongoDB, S3, FileSystem).
- **`gentiq.auth`**: Pluggable JWT-based authentication adapters.
- **`gentiq.api.dependencies`**: Reusable FastAPI dependencies like `get_user_store`, `get_chat_store`, and `get_current_user`.

---

## 🛠️ Local Development

To contribute or test the package locally:

1. **Install uv**: Ensure you have `uv` installed.
2. **Sync Dependencies**:
   ```bash
   uv sync
   ```
3. **Run Tests** (if applicable):
   ```bash
   uv run pytest
   ```
