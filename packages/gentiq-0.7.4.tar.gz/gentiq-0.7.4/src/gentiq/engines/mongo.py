from typing import Any

from .base import DBEngine


class MongoEngine(DBEngine):
    """
    MongoDB implementation of the Gentiq database engine.
    """

    def __init__(
        self,
        uri: str,
        db_name: str,
        username: str | None = None,
        password: str | None = None,
        **kwargs: Any,
    ):
        try:
            from pymongo import MongoClient
        except ImportError as err:
            raise ImportError("Please install `pymongo` to use the MongoDB engine!") from err

        self.client = MongoClient(uri, username=username, password=password, tz_aware=True)
        self.db = self.client[db_name]

    def find_one(
        self, collection: str, filter: dict[str, Any], projection: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        return self.db[collection].find_one(filter, projection)

    def find_many(
        self,
        collection: str,
        filter: dict[str, Any],
        projection: dict[str, Any] | None = None,
        sort: list[tuple[str, int]] | None = None,
        skip: int = 0,
        limit: int = 0,
    ) -> list[dict[str, Any]]:
        cursor = self.db[collection].find(filter, projection)
        if sort:
            cursor = cursor.sort(sort)
        if skip:
            cursor = cursor.skip(skip)
        if limit:
            cursor = cursor.limit(limit)
        return list(cursor)

    def insert_one(self, collection: str, document: dict[str, Any]) -> Any:
        return self.db[collection].insert_one(document)

    def update_one(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        push_fields: dict[str, Any] | None = None,
        set_on_insert: dict[str, Any] | None = None,
        upsert: bool = False,
    ) -> Any:
        update_doc: dict[str, Any] = {}
        if set_fields:
            update_doc["$set"] = set_fields
        if inc_fields:
            update_doc["$inc"] = inc_fields
        if push_fields:
            update_doc["$push"] = push_fields
        if set_on_insert:
            update_doc["$setOnInsert"] = set_on_insert

        # If there are no modifiers but we are upserting or just setting fields,
        # ensure we don't pass an empty update unless it's a direct replace.
        # This implementation expects modifier operations.
        if not update_doc and set_fields is not None:
            update_doc = set_fields

        return self.db[collection].update_one(filter, update_doc, upsert=upsert)

    def delete_one(self, collection: str, filter: dict[str, Any]) -> bool:
        result = self.db[collection].delete_one(filter)
        return result.deleted_count > 0

    def delete_many(self, collection: str, filter: dict[str, Any]) -> int:
        result = self.db[collection].delete_many(filter)
        return result.deleted_count

    def count_documents(self, collection: str, filter: dict[str, Any]) -> int:
        return self.db[collection].count_documents(filter)

    def update_and_return(
        self,
        collection: str,
        filter: dict[str, Any],
        set_fields: dict[str, Any] | None = None,
        inc_fields: dict[str, Any] | None = None,
        return_after: bool = True,
    ) -> dict[str, Any] | None:
        try:
            from pymongo import ReturnDocument as MongoReturnDocument
        except ImportError as err:
            raise ImportError("Please install `pymongo` to use the MongoDB engine!") from err

        mongo_rd = MongoReturnDocument.AFTER if return_after else MongoReturnDocument.BEFORE
        update_doc: dict[str, Any] = {}
        if set_fields:
            update_doc["$set"] = set_fields
        if inc_fields:
            update_doc["$inc"] = inc_fields

        if not update_doc:
            return self.db[collection].find_one(filter)

        return self.db[collection].find_one_and_update(filter, update_doc, return_document=mongo_rd)

    def create_index(self, collection: str, keys: list[tuple[str, int]], unique: bool = False) -> None:
        self.db[collection].create_index(keys, unique=unique)

    def distinct(self, collection: str, field: str, filter: dict[str, Any] | None = None) -> list[Any]:
        return self.db[collection].distinct(field, filter)

    def aggregate(self, collection: str, pipeline: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return list(self.db[collection].aggregate(pipeline))
