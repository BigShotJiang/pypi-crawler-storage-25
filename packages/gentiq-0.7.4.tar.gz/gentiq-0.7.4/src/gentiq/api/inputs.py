from pydantic import BaseModel

from .enums import AdminPermission


__all__ = [
    "AdminLoginInput",
    "AdminRegisterInput",
    "AdminUpdateInput",
    "LoginInput",
    "MessageFeedbackInput",
    "RegisterUserInput",
    "ThreadUpdateInput",
    "UserBalanceUpdateInput",
    "UserCreateInput",
    "UserUpdateInput",
]


# ------------------------------ #
# -------- User Inputs --------- #
# ------------------------------ #
class RegisterUserInput(BaseModel):
    phone: str
    password: str
    name: str
    surname: str


class LoginInput(BaseModel):
    phone: str
    password: str


class MessageFeedbackInput(BaseModel):
    thread_id: str
    message_id: str
    sentiment: str | None  # 'like' or 'dislike' or null to retract


class ThreadUpdateInput(BaseModel):
    title: str | None = None
    pinned: bool | None = None


# ------------------------------ #
# -------- Admin Inputs -------- #
# ------------------------------ #
class AdminRegisterInput(BaseModel):
    username: str
    password: str
    name: str
    permissions: list[AdminPermission]


class AdminUpdateInput(BaseModel):
    name: str | None = None
    password: str | None = None
    permissions: list[AdminPermission] | None = None


class AdminLoginInput(BaseModel):
    username: str
    password: str


class UserCreateInput(BaseModel):
    phone: str
    name: str
    surname: str
    balance: dict | None = None


class UserUpdateInput(BaseModel):
    phone: str | None = None
    name: str | None = None
    surname: str | None = None
    password: str | None = None


class UserBalanceUpdateInput(BaseModel):
    tokens: int
    requests: int
    token_limit: int | None = None
    request_limit: int | None = None
