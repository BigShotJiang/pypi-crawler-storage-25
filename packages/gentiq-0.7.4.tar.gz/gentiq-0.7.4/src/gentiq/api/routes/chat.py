import logging
import mimetypes
from http import HTTPStatus
from json import dumps, loads
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse
from pydantic import ValidationError
from pydantic_ai.ui import SSE_CONTENT_TYPE
from pydantic_ai.ui.vercel_ai import VercelAIAdapter

from ...errors import ErrorCode, GentiqError
from ...schemas import User
from ...stores import ChatStore, UserStore
from ..chat_service import ChatService
from ..dependencies import get_chat_service, get_chat_store, get_current_user, get_user_store
from ..inputs import MessageFeedbackInput, ThreadUpdateInput


# --- Configuration & Setup ---

router = APIRouter()
logger = logging.getLogger(__name__)


# --- Message Parsing Helpers ---


# --- Endpoints: Chat Core ---


@router.post("/chat/feedback", tags=["Chat"])
async def save_feedback(
    data: MessageFeedbackInput,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Saves user feedback (sentiment) for a specific assistant message."""
    try:
        chat_store.save_feedback(
            thread_id=data.thread_id,
            item_ids=[data.message_id],
            sentiment=data.sentiment,
            user_id=user.id,
        )
        return JSONResponse({"status": "success"}, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error("Error saving feedback: %s", e)
        raise GentiqError(
            ErrorCode.FEEDBACK_SAVE_FAILED, message=f"Failed to save feedback: {e!s}", status_code=500
        ) from e


@router.post("/chat", tags=["Chat"])
async def chat(
    request: Request,
    user: Annotated[User, Depends(get_current_user)],
    user_store: Annotated[UserStore, Depends(get_user_store)],
    chat_service: Annotated[ChatService, Depends(get_chat_service)],
) -> Response:
    """Core chat endpoint that streams AI responses back to the client."""
    accept_header = request.headers.get("accept", SSE_CONTENT_TYPE)

    try:
        raw_body = await request.body()
        try:
            body_dict = loads(raw_body)
            processed_body = chat_service.preprocess_chat_request(body_dict)
        except Exception as preprocess_err:
            logger.warning("Failed to preprocess chat body: %s", preprocess_err)
            processed_body = raw_body

        run_input = VercelAIAdapter.build_run_input(processed_body)
    except ValidationError as e:
        return Response(
            content=dumps(e.json()),
            media_type="application/json",
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
        )

    if not user_store.check_user_balance(user.id):
        raise GentiqError(ErrorCode.INSUFFICIENT_BALANCE, status_code=HTTPStatus.PAYMENT_REQUIRED)

    adapter = VercelAIAdapter(agent=chat_service.agent, run_input=run_input, accept=accept_header)
    thread_id = request.headers.get("X-Thread-Id")

    if thread_id:
        chat_service.handle_pre_stream_user_message(
            run_input=run_input,
            thread_id=thread_id,
            user_id=user.id,
        )

    response_gen = chat_service.stream_chat(
        user=user,
        run_input=run_input,
        adapter=adapter,
        thread_id=thread_id,
    )

    sse_stream = adapter.encode_stream(response_gen)
    return StreamingResponse(sse_stream, media_type=accept_header)


# --- Endpoints: Threads & Attachments ---


@router.get("/chat/threads", tags=["Chat"])
async def list_threads(
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
) -> Response:
    """Lists recent chat threads for the authenticated user."""
    try:
        threads = chat_store.list_user_threads(user_id=user.id, skip=skip, limit=limit)
        total_count = chat_store.count_user_threads(user_id=user.id)
        return JSONResponse(
            {
                "threads": threads,
                "skip": skip,
                "limit": limit,
                "count": len(threads),
                "total_count": total_count,
            },
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Failed to list threads: %s", e)
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch threads: {e!s}", status_code=500)


@router.get("/chat/threads/{thread_id}", tags=["Chat"])
async def get_thread_messages(
    thread_id: str,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Retrieves all message history for a specific chat thread."""
    try:
        items = chat_store.get_thread_items(user_id=user.id, thread_id=thread_id)
        if items is None:
            return JSONResponse({"items": []}, status_code=HTTPStatus.OK)
        return JSONResponse({"items": items}, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error("Failed to fetch thread messages: %s", e)
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch thread messages: {e!s}", status_code=500)


@router.patch("/chat/threads/{thread_id}", tags=["Chat"])
async def update_thread(
    thread_id: str,
    data: ThreadUpdateInput,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Updates thread metadata (e.g., title) for the authenticated user."""
    try:
        thread = chat_store.fetch_thread(thread_id)
        if not thread or thread.get("user_id") != user.id:
            raise GentiqError(ErrorCode.THREAD_NOT_FOUND, status_code=HTTPStatus.NOT_FOUND)

        chat_store.update_thread_info(thread_id, title=data.title, pinned=data.pinned, user_id=user.id)
        return JSONResponse(
            {"status": "success", "message": "Thread updated successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Error updating thread: %s", e)
        raise GentiqError(ErrorCode.THREAD_UPDATE_FAILED, message=f"Failed to update thread: {e!s}", status_code=500)


@router.delete("/chat/threads/{thread_id}", tags=["Chat"])
async def delete_thread(
    thread_id: str,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Deletes a chat thread and its associated message history."""
    try:
        success = chat_store.delete_user_thread(user_id=user.id, thread_id=thread_id)
        if not success:
            raise GentiqError(ErrorCode.THREAD_NOT_FOUND, status_code=HTTPStatus.NOT_FOUND)
        return JSONResponse(
            {"status": "success", "message": "Thread deleted successfully"},
            status_code=HTTPStatus.OK,
        )
    except Exception as e:
        logger.error("Failed to delete thread: %s", e)
        raise GentiqError(ErrorCode.THREAD_DELETE_FAILED, message=f"Failed to delete thread: {e!s}", status_code=500)


@router.get("/chat/attachments/{object_name:path}", tags=["Chat"])
async def get_attachment(
    object_name: str,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Proxies a secure attachment from storage to the authenticated user."""
    try:
        content = chat_store.download_attachment(object_name)
        media_type, _ = mimetypes.guess_type(object_name)
        if not media_type:
            media_type = "application/octet-stream"
        return Response(content=content, media_type=media_type)
    except Exception as e:
        logger.error("Failed to serve attachment %s: %s", object_name, e)
        raise GentiqError(ErrorCode.ATTACHMENT_NOT_FOUND, status_code=HTTPStatus.NOT_FOUND)


@router.post("/chat/threads/{thread_id}/share", tags=["Chat"])
async def share_thread(
    thread_id: str,
    user: Annotated[User, Depends(get_current_user)],
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Generates a public readonly snapshot of a chat thread."""
    try:
        share_id = chat_store.create_shared_thread(thread_id, user.id)
        return JSONResponse(
            {"status": "success", "share_id": share_id, "url": f"/shared/{share_id}"},
            status_code=HTTPStatus.OK,
        )
    except ValueError as e:
        raise GentiqError(ErrorCode.THREAD_NOT_FOUND, message=str(e), status_code=HTTPStatus.NOT_FOUND)
    except Exception as e:
        logger.error("Failed to share thread: %s", e)
        raise GentiqError(ErrorCode.THREAD_SHARE_FAILED, message=f"Failed to share thread: {e!s}", status_code=500)


@router.get("/public/shared/{share_id}", tags=["Chat"])
async def get_shared_thread(
    share_id: str,
    chat_store: Annotated[ChatStore, Depends(get_chat_store)],
) -> Response:
    """Retrieves a public readonly snapshot of a chat thread."""
    try:
        shared = chat_store.get_shared_thread(share_id)
        if not shared:
            raise GentiqError(ErrorCode.THREAD_NOT_FOUND, status_code=HTTPStatus.NOT_FOUND)
        return JSONResponse(shared, status_code=HTTPStatus.OK)
    except Exception as e:
        logger.error("Failed to get shared thread: %s", e)
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to get shared thread: {e!s}", status_code=500)
