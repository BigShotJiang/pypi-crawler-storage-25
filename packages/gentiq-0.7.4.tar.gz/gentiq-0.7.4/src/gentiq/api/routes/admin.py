import mimetypes
import uuid
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, Response

from ...env import FEEDBACKS, THREAD_ITEMS, THREADS, TRANSACTIONS, USERS
from ...errors import ErrorCode, GentiqError
from ...stores import AdminStore, ChatStore, UserStore
from ..dependencies import get_current_admin, get_current_admin_optional, require_permission
from ..enums import AdminPermission
from ..inputs import (
    AdminLoginInput,
    AdminRegisterInput,
    AdminUpdateInput,
    UserBalanceUpdateInput,
    UserCreateInput,
    UserUpdateInput,
)
from ..security import hash_password, verify_password


router = APIRouter(prefix="/admin", tags=["Admin"])
AuthenticatedAdmin = Annotated[dict | None, Depends(get_current_admin)]
OptionalAdmin = Annotated[dict | None, Depends(get_current_admin_optional)]


# ------------------------------ #
# -------- Setup Status -------- #
# ------------------------------ #


@router.get("/setup-status")
async def get_setup_status(request: Request) -> Response:
    """Check if the system needs initial admin setup (no admins exist)."""
    admin_store: AdminStore = request.app.state.admin_store
    admins = admin_store.list_admins()
    return JSONResponse({"needs_setup": len(admins) == 0})


# ------------------------------ #
# ----- Admin Management ------- #
# ------------------------------ #


@router.post("/admins")
async def register_admin(
    request: Request,
    data: AdminRegisterInput,
    admin: Annotated[dict | None, Depends(get_current_admin_optional)],
) -> Response:
    """Endpoint to register a new admin."""
    admin_store: AdminStore = request.app.state.admin_store
    # Allow registration if no admins exist (initial setup) or if requester has ADMIN_MANAGEMENT permission
    admins = admin_store.list_admins()
    if len(admins) > 0:
        require_permission(AdminPermission.ADMIN_MANAGEMENT)

    # Check if admin with username already exists
    existing_admin = admin_store.get_admin_by_username(data.username)
    if existing_admin:
        raise GentiqError(ErrorCode.ADMIN_ALREADY_EXISTS, status_code=400)

    # Generate admin ID and hash password
    admin_id = f"admin_{uuid.uuid4().hex}"
    password_hash = hash_password(data.password)

    # Create admin in database
    try:
        admin_doc = admin_store.create_admin(
            admin_id=admin_id,
            username=data.username,
            password_hash=password_hash,
            name=data.name,
            permissions=[p.value for p in data.permissions],
        )

        return JSONResponse(
            {
                "admin_id": admin_doc.id,
                "username": admin_doc.username,
                "name": admin_doc.name,
                "permissions": admin_doc.permissions,
                "created_at": admin_doc.created_at.isoformat() if admin_doc.created_at else None,
            },
            status_code=201,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to create admin: {e!s}", status_code=500)


@router.post("/login")
async def login_admin(request: Request, data: AdminLoginInput) -> Response:
    """Endpoint for admin login. Returns a JWT token on success."""
    admin_store: AdminStore = request.app.state.admin_store
    admin = admin_store.get_admin_by_username(data.username)
    if not admin:
        raise GentiqError(ErrorCode.INVALID_CREDENTIALS, status_code=401)

    if not verify_password(data.password, admin.password_hash):
        raise GentiqError(ErrorCode.INVALID_CREDENTIALS, status_code=401)
    token = request.app.state.auth.create_admin_token(admin.id)

    permissions = admin.permissions
    if permissions and len(permissions) > 0 and not isinstance(permissions[0], str):
        permissions = [p.value if hasattr(p, "value") else str(p) for p in permissions]

    return JSONResponse(
        {
            "token": token,
            "admin_id": admin.id,
            "username": admin.username,
            "name": admin.name,
            "permissions": permissions,
        },
        status_code=200,
    )


@router.get("/admins")
async def list_admins(
    request: Request,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT))],
) -> Response:
    """Endpoint to list all admins."""
    admin_store: AdminStore = request.app.state.admin_store
    try:
        admins = admin_store.list_admins()
        return JSONResponse(
            {
                "admins": [
                    {
                        "id": a.id,
                        "username": a.username,
                        "name": a.name,
                        "permissions": a.permissions,
                    }
                    for a in admins
                ]
            },
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch admins: {e!s}", status_code=500)


@router.patch("/admins/{admin_id}")
async def update_admin(
    request: Request,
    admin_id: str,
    data: AdminUpdateInput,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT))],
) -> Response:
    """Endpoint to update an admin's information or permissions."""
    admin_store: AdminStore = request.app.state.admin_store
    try:
        update_data = {}
        if data.name is not None:
            update_data["name"] = data.name
        if data.password is not None:
            update_data["password_hash"] = hash_password(data.password)
        if data.permissions is not None:
            update_data["permissions"] = [p.value for p in data.permissions]

        if not update_data:
            raise GentiqError(ErrorCode.ADMIN_UPDATE_FAILED, message="No update data provided", status_code=400)

        success = admin_store.update_admin(admin_id, update_data)
        if not success:
            raise GentiqError(ErrorCode.ADMIN_NOT_FOUND, status_code=404)

        return JSONResponse(
            {"status": "success", "message": "Admin updated successfully"},
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.ADMIN_UPDATE_FAILED, message=f"Failed to update admin: {e!s}", status_code=500)


@router.delete("/admins/{admin_id}")
async def delete_admin(
    request: Request,
    admin_id: str,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT))],
) -> Response:
    """Endpoint to delete an admin."""
    admin_store: AdminStore = request.app.state.admin_store
    if admin and admin_id == admin.get("admin_id"):
        raise GentiqError(ErrorCode.CANNOT_DELETE_SELF, status_code=400)

    try:
        success = admin_store.delete_admin(admin_id)
        if not success:
            raise GentiqError(ErrorCode.ADMIN_NOT_FOUND, status_code=404)
        return JSONResponse(
            {"status": "success", "message": "Admin deleted successfully"},
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to delete admin: {e!s}", status_code=500)


@router.get("/permissions")
async def list_permissions(
    request: Request,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT))],
) -> Response:
    """Endpoint to list all available permissions."""
    return JSONResponse(
        {"permissions": AdminPermission.list_all()},
        status_code=200,
    )


# ------------------------------ #
# ----- Chat History ----------- #
# ------------------------------ #


@router.get("/chat-history/threads")
async def list_all_threads(
    request: Request,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.CHAT_HISTORY))],
    skip: int = 0,
    limit: int = 50,
    query: str | None = None,
    feedback: str | None = None,
) -> Response:
    """Endpoint to list all chat threads or search for threads."""
    chat_store: ChatStore = request.app.state.chat_store
    try:
        if query:
            threads = chat_store.search_threads(query=query, skip=skip, limit=limit, feedback_filter=feedback)
        else:
            threads = chat_store.list_all_threads(skip=skip, limit=limit, feedback_filter=feedback)

        return JSONResponse(
            jsonable_encoder(
                {
                    "threads": threads,
                    "skip": skip,
                    "limit": limit,
                    "count": len(threads),
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch threads: {e!s}", status_code=500)


@router.get("/chat-history/threads/{thread_id}/items")
async def get_thread_items(
    request: Request,
    thread_id: str,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.CHAT_HISTORY))],
) -> Response:
    """Endpoint to get all items (messages) in a specific thread."""
    chat_store: ChatStore = request.app.state.chat_store
    try:
        items = chat_store.get_thread_items_for_admin(thread_id)
        thread = chat_store.fetch_thread(thread_id)

        if not thread:
            raise GentiqError(ErrorCode.THREAD_NOT_FOUND, status_code=404)

        thread.pop("_id", None)

        return JSONResponse(
            jsonable_encoder(
                {
                    "thread_id": thread_id,
                    "thread": thread,
                    "items": items,
                    "count": len(items),
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch thread items: {e!s}", status_code=500)


@router.get("/chat-history/attachments/{object_name:path}")
async def get_attachment_for_admin(
    request: Request,
    object_name: str,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.CHAT_HISTORY))],
) -> Response:
    """Securely proxy a storage attachment to the authenticated admin."""
    chat_store: ChatStore = request.app.state.chat_store
    try:
        content = chat_store.download_attachment(object_name)
        media_type, _ = mimetypes.guess_type(object_name)
        if not media_type:
            media_type = "application/octet-stream"
        return Response(content=content, media_type=media_type)
    except Exception:
        raise GentiqError(ErrorCode.ATTACHMENT_NOT_FOUND, status_code=404)


# ------------------------------ #
# ----- User Management -------- #
# ------------------------------ #


@router.get("/users")
async def list_users(
    request: Request,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
    skip: int = 0,
    limit: int = 100,
    query: str | None = None,
) -> Response:
    """Endpoint to list all users."""
    user_store: UserStore = request.app.state.user_store
    try:
        users = user_store.list_users(skip=skip, limit=limit, query=query)
        count = user_store.count_users(query=query)
        return JSONResponse(
            jsonable_encoder(
                {
                    "users": [
                        {
                            "id": u.id,
                            "phone": u.phone,
                            "name": u.name,
                            "surname": u.surname,
                            "token": u.token,
                            "balance": u.balance,
                        }
                        for u in users
                    ],
                    "count": count,
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch users: {e!s}", status_code=500)


@router.post("/users")
async def create_user(
    request: Request,
    data: UserCreateInput,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
) -> Response:
    """Endpoint to create a new user."""
    user_store: UserStore = request.app.state.user_store
    try:
        existing_user = user_store.get_user_by_phone(data.phone)
        if existing_user:
            raise GentiqError(ErrorCode.PHONE_ALREADY_EXISTS, status_code=400)

        user_id = f"user_{uuid.uuid4().hex}"
        auth_adapter = request.app.state.auth
        token = auth_adapter.create_user_token(user_id)

        user = user_store.create_user(
            user_id=user_id,
            phone=data.phone,
            name=data.name,
            surname=data.surname,
            token=token,
            balance=data.balance,
        )

        return JSONResponse(
            jsonable_encoder(
                {
                    "status": "success",
                    "user": {
                        "id": user.id,
                        "phone": user.phone,
                        "name": user.name,
                        "surname": user.surname,
                        "token": user.token,
                        "created_at": user.created_at,
                    },
                }
            ),
            status_code=201,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to create user: {e!s}", status_code=500)


@router.patch("/users/{user_id}")
async def update_user(
    request: Request,
    user_id: str,
    data: UserUpdateInput,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
) -> Response:
    """Endpoint to update a user's information."""
    user_store: UserStore = request.app.state.user_store
    try:
        existing_user = user_store.get_user(user_id)
        if not existing_user:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)

        if data.phone and data.phone != existing_user.phone:
            phone_user = user_store.get_user_by_phone(data.phone)
            if phone_user:
                raise GentiqError(ErrorCode.PHONE_ALREADY_EXISTS, status_code=400)
            user_store.update_user_phone(user_id, data.phone)

        user_store.update_user_info(
            user_id=user_id,
            name=data.name,
            surname=data.surname,
        )

        updated_user = user_store.get_user(user_id)
        if not updated_user:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)

        return JSONResponse(
            jsonable_encoder(
                {
                    "status": "success",
                    "user": {
                        "id": updated_user.id,
                        "phone": updated_user.phone,
                        "name": updated_user.name,
                        "surname": updated_user.surname,
                        "token": updated_user.token,
                        "balance": updated_user.balance,
                    },
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to update user: {e!s}", status_code=500) from e


@router.delete("/users/{user_id}")
async def delete_user(
    request: Request,
    user_id: str,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
) -> Response:
    """Endpoint to delete a user."""
    user_store: UserStore = request.app.state.user_store
    try:
        success = user_store.delete_user(user_id)
        if not success:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)
        return JSONResponse(
            {"status": "success", "message": "User deleted successfully"},
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to delete user: {e!s}", status_code=500)


@router.post("/users/{user_id}/balance")
async def update_user_balance(
    request: Request,
    user_id: str,
    data: UserBalanceUpdateInput,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
) -> Response:
    """Endpoint to update a user's balance to specific values."""
    user_store: UserStore = request.app.state.user_store
    try:
        new_balance = user_store.update_user_balance(
            user_id=user_id,
            tokens=data.tokens,
            requests=data.requests,
            token_limit=data.token_limit,
            request_limit=data.request_limit,
        )

        return JSONResponse(
            jsonable_encoder(
                {
                    "status": "success",
                    "message": "User balance updated successfully",
                    "balance": new_balance,
                }
            ),
            status_code=200,
        )
    except ValueError as e:
        raise GentiqError(ErrorCode.USER_NOT_FOUND, message=str(e), status_code=404)
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to update user balance: {e!s}", status_code=500)


@router.post("/users/{user_id}/refresh-token")
async def refresh_user_token(
    request: Request,
    user_id: str,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.USER_MANAGEMENT))],
) -> Response:
    """Endpoint to refresh a user's JWT token."""
    user_store: UserStore = request.app.state.user_store
    try:
        user = user_store.get_user(user_id)
        if not user:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)

        new_token = request.app.state.auth.create_user_token(user_id)
        user_store.update_user_token(user_id, new_token)

        updated_user = user_store.get_user(user_id)
        if not updated_user:
            raise GentiqError(ErrorCode.USER_NOT_FOUND, status_code=404)

        return JSONResponse(
            jsonable_encoder(
                {
                    "status": "success",
                    "message": "Token refreshed successfully",
                    "user": {
                        "id": updated_user.id,
                        "phone": updated_user.phone,
                        "name": updated_user.name,
                        "surname": updated_user.surname,
                        "token": updated_user.token,
                        "balance": updated_user.balance,
                    },
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to refresh token: {e!s}", status_code=500)


# ------------------------------ #
# ----- Analytics -------------- #
# ------------------------------ #


@router.get("/analytics")
async def get_analytics(
    request: Request,
    admin: Annotated[dict | None, Depends(require_permission(AdminPermission.ANALYTICS))],
    days: int = 30,
) -> Response:
    """Endpoint to get analytics data for the admin panel."""
    admin_store: AdminStore = request.app.state.admin_store
    user_store: UserStore = request.app.state.user_store
    try:
        now = datetime.now(UTC)
        end_date = now + timedelta(days=1)
        start_date = now - timedelta(days=days)

        date_match = {"created_at": {"$gte": start_date, "$lte": end_date}}

        # Get user registration trends over time
        user_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get thread creation trends
        thread_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get message trends
        message_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get token usage trends
        transaction_pipeline = [
            {
                "$match": {
                    "created_at": {"$gte": start_date, "$lte": end_date},
                    "type": "usage",
                }
            },
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "total_tokens": {"$sum": {"$abs": "$change.tokens"}},
                    "total_requests": {"$sum": {"$abs": "$change.requests"}},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get most active users (by thread count)
        active_users_pipeline = [
            {"$match": date_match},
            {"$group": {"_id": "$user_id", "thread_count": {"$sum": 1}}},
            {"$sort": {"thread_count": -1}},
            {"$limit": 10},
        ]

        # Get recent feedbacks sentiment distribution
        feedback_pipeline = [
            {"$match": date_match},
            {"$sort": {"created_at": -1}},
            {
                "$group": {
                    "_id": {"thread_id": "$thread_id", "item_ids": "$item_ids"},
                    "sentiment": {"$first": "$sentiment"},
                }
            },
            {"$group": {"_id": "$sentiment", "count": {"$sum": 1}}},
        ]

        # Execute pipelines
        try:
            user_trends = admin_store.engine.aggregate(USERS, user_pipeline)
        except Exception:
            user_trends = []

        try:
            thread_trends = admin_store.engine.aggregate(THREADS, thread_pipeline)
        except Exception:
            thread_trends = []

        try:
            message_trends = admin_store.engine.aggregate(THREAD_ITEMS, message_pipeline)
        except Exception:
            message_trends = []

        try:
            token_usage = admin_store.engine.aggregate(TRANSACTIONS, transaction_pipeline)
        except Exception:
            token_usage = []

        try:
            active_users_data = admin_store.engine.aggregate(THREADS, active_users_pipeline)
        except Exception:
            active_users_data = []

        try:
            feedback_distribution = admin_store.engine.aggregate(FEEDBACKS, feedback_pipeline)
        except Exception:
            feedback_distribution = []

        # Enrich with user info
        active_users = []
        for item in active_users_data:
            user_id = item.get("_id")
            if user_id:
                user = user_store.get_user(user_id)
                if user:
                    active_users.append(
                        {
                            "user_id": user_id,
                            "name": f"{user.name} {user.surname}",
                            "thread_count": item["thread_count"],
                        }
                    )

        return JSONResponse(
            jsonable_encoder(
                {
                    "overview": {
                        "total_users": sum(t["count"] for t in user_trends),
                        "total_threads": sum(t["count"] for t in thread_trends),
                        "total_messages": sum(m["count"] for m in message_trends),
                        "total_token_usage": sum(t.get("total_tokens", 0) for t in token_usage),
                    },
                    "trends": {
                        "users": [{"date": item["_id"], "count": item["count"]} for item in user_trends],
                        "threads": [{"date": item["_id"], "count": item["count"]} for item in thread_trends],
                        "messages": [{"date": item["_id"], "count": item["count"]} for item in message_trends],
                        "token_usage": [
                            {
                                "date": item["_id"],
                                "tokens": item.get("total_tokens", 0),
                                "requests": item.get("total_requests", 0),
                            }
                            for item in token_usage
                        ],
                    },
                    "distributions": {
                        "feedback_sentiment": [
                            {
                                "sentiment": "positive"
                                if item["_id"] == "like"
                                else ("negative" if item["_id"] == "dislike" else item["_id"]),
                                "count": item["count"],
                            }
                            for item in feedback_distribution
                        ],
                    },
                    "active_users": active_users,
                }
            ),
            status_code=200,
        )
    except Exception as e:
        raise GentiqError(ErrorCode.INTERNAL_ERROR, message=f"Failed to fetch analytics: {e!s}", status_code=500)
