from datetime import UTC, datetime

from ..engines.base import DBEngine, StorageEngine
from ..env import ATTACHMENTS, FEEDBACKS, SHARED_THREADS, THREAD_ITEMS, THREADS, USERS
from ..schemas import Feedback
from .user_store import UserStore


class ChatStore:
    """Store for managing conversation threads, messages, and associated metadata.

    The ChatStore handles the persistence of chat history, file attachments,
    user feedback, and usage metrics per thread. It coordinates between the
    database engine and storage engine to provide a seamless conversational API.

    Args:
        engine: The database engine instance for structured data (threads, messages).
        user_store: The UserStore instance for linking threads to users.
        files_store: The StorageEngine instance for binary file management.
    """

    def __init__(self, engine: DBEngine, user_store: UserStore, files_store: StorageEngine):
        self.engine = engine
        self.user_store = user_store
        self.files_store = files_store
        self.threads = THREADS
        self.thread_items = THREAD_ITEMS
        self.attachments = ATTACHMENTS
        self.feedbacks = FEEDBACKS
        self.users = USERS
        self.shared_threads = SHARED_THREADS

        self.engine.create_index(self.thread_items, [("thread_id", 1), ("id", 1)], unique=True)
        self.engine.create_index(self.thread_items, [("thread_id", 1), ("created_at", 1)])

    def download_attachment(self, object_name: str) -> bytes:
        """Download a file attachment from the storage engine."""
        response = self.files_store.download(container=self.attachments, object_name=object_name)
        try:
            return response.read()
        finally:
            if hasattr(response, "close"):
                response.close()
            if hasattr(response, "release_conn"):
                response.release_conn()

    def get_attachment_url(self, object_name: str) -> str:
        return f"/api/chat/attachments/{object_name}"

    def list_user_threads(self, user_id: str, skip: int = 0, limit: int = 50) -> list[dict]:
        threads = self.engine.find_many(
            self.threads,
            {"user_id": user_id, "is_deleted": {"$ne": True}},
            sort=[("pinned", -1), ("created_at", -1)],
            skip=skip,
            limit=limit,
        )
        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()
            user = self.user_store.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def fetch_thread(self, thread_id: str) -> dict | None:
        return self.engine.find_one(self.threads, {"id": thread_id})

    def fetch_thread_item(self, thread_id: str, item_id: str) -> dict | None:
        return self.engine.find_one(self.thread_items, {"thread_id": thread_id, "id": item_id})

    def count_user_threads(self, user_id: str) -> int:
        return self.engine.count_documents(self.threads, {"user_id": user_id, "is_deleted": {"$ne": True}})

    def delete_user_thread(self, user_id: str, thread_id: str) -> bool:
        self.engine.update_one(
            self.threads,
            {"id": thread_id, "user_id": user_id},
            set_fields={"is_deleted": True, "updated_at": datetime.now(UTC)},
        )
        return True

    def get_thread_items(self, user_id: str, thread_id: str) -> list[dict] | None:
        thread = self.engine.find_one(self.threads, {"id": thread_id, "user_id": user_id, "is_deleted": {"$ne": True}})
        if not thread:
            return None

        items = self.engine.find_many(self.thread_items, {"thread_id": thread_id}, sort=[("created_at", 1)])
        feedbacks = self.engine.find_many(self.feedbacks, {"thread_id": thread_id})
        feedback_map = {}
        for fb in feedbacks:
            item_ids = fb.get("item_ids")
            if isinstance(item_ids, list):
                for item_id in item_ids:
                    feedback_map[item_id] = fb.get("sentiment")

        for item in items:
            item.pop("_id", None)
            m_id = item.get("id")
            if m_id in feedback_map:
                item["feedback"] = feedback_map[m_id]

            if "created_at" in item and hasattr(item["created_at"], "isoformat"):
                item["created_at"] = item["created_at"].isoformat()
            if "updated_at" in item and hasattr(item["updated_at"], "isoformat"):
                item["updated_at"] = item["updated_at"].isoformat()
        return items

    def save_thread_item(self, thread_id: str, item: dict) -> None:
        if "_id" in item:
            item.pop("_id")
        item["thread_id"] = thread_id
        if "created_at" not in item:
            item["created_at"] = datetime.now(UTC)

        m_id = item.get("id")
        if m_id:
            self.engine.update_one(
                self.thread_items, {"thread_id": thread_id, "id": m_id}, set_fields=item, upsert=True
            )
        else:
            self.engine.insert_one(self.thread_items, item)

    def clear_thread_items_after(self, thread_id: str, timestamp: datetime) -> int:
        return self.engine.delete_many(self.thread_items, {"thread_id": thread_id, "created_at": {"$gt": timestamp}})

    def save_attachment(
        self, attachment_id: str, thread_id: str, user_id: str, media_type: str, filename: str | None = None
    ) -> None:
        doc = {
            "id": attachment_id,
            "thread_id": thread_id,
            "user_id": user_id,
            "media_type": media_type,
        }
        if filename:
            doc["filename"] = filename

        self.engine.update_one(
            self.attachments,
            {"id": attachment_id},
            set_fields=doc,
            set_on_insert={"created_at": datetime.now(UTC)},
            upsert=True,
        )

    def save_feedback(self, thread_id: str, item_ids: list[str], sentiment: str | None, user_id: str) -> None:
        # Always clear existing feedbacks for these specific items by this user to avoid duplicates
        self.engine.delete_many(self.feedbacks, {"thread_id": thread_id, "item_ids": item_ids, "user_id": user_id})

        if sentiment is not None:
            feedback_doc = Feedback(
                thread_id=thread_id,
                item_ids=item_ids,
                sentiment=sentiment,
                user_id=user_id,
                created_at=datetime.now(UTC),
            )
            self.engine.insert_one(self.feedbacks, feedback_doc.model_dump())

    def update_usage(self, user_id: str, thread_id: str, usage) -> None:
        def get_metric(obj, key, default=0):
            if isinstance(obj, dict):
                return obj.get(key, default)
            val = getattr(obj, key, default)
            return val if val is not None else default

        details = get_metric(usage, "details", {})
        if not isinstance(details, dict):
            details = {}

        input_t = get_metric(usage, "input_tokens", 0) or get_metric(usage, "request_tokens", 0) or 0
        output_t = get_metric(usage, "output_tokens", 0) or get_metric(usage, "response_tokens", 0) or 0
        total_t = get_metric(usage, "total_tokens", 0) or 0

        if total_t == 0 and (input_t > 0 or output_t > 0):
            total_t = input_t + output_t

        usage_info = {
            "requests": get_metric(usage, "requests", 1) or 1,
            "request_tokens": input_t,
            "response_tokens": output_t,
            "input_tokens": input_t,
            "output_tokens": output_t,
            "total_tokens": total_t,
            "cache_read_tokens": get_metric(usage, "cache_read_tokens", 0) or 0,
            "cache_write_tokens": get_metric(usage, "cache_write_tokens", 0) or 0,
            "cache_audio_read_tokens": get_metric(usage, "cache_audio_read_tokens", 0) or 0,
            "input_audio_tokens": get_metric(usage, "input_audio_tokens", 0) or 0,
            "output_audio_tokens": get_metric(usage, "output_audio_tokens", 0) or 0,
            "tool_calls": get_metric(usage, "tool_calls", 0) or 0,
            "details": details,
        }

        inc_data = {}
        set_data = {}

        snapshot_fields = [
            "request_tokens",
            "input_tokens",
            "cache_read_tokens",
            "cache_audio_read_tokens",
            "input_audio_tokens",
        ]

        additive_fields = [
            "requests",
            "response_tokens",
            "output_tokens",
            "cache_write_tokens",
            "output_audio_tokens",
            "tool_calls",
        ]

        for k, v in usage_info.items():
            if k == "details" and isinstance(v, dict):
                for dk, dv in v.items():
                    inc_data[f"metadata.usage.details.{dk}"] = dv or 0
            elif k in snapshot_fields:
                set_data[f"metadata.usage.{k}"] = v or 0
                inc_data[f"metadata.usage.cumulative_{k}"] = v or 0
            elif k in additive_fields:
                inc_data[f"metadata.usage.{k}"] = v or 0

        inc_data["metadata.usage.cumulative_total_tokens"] = usage_info["total_tokens"]

        set_data["user_id"] = user_id
        set_data["updated_at"] = datetime.now(UTC)

        set_on_insert = {"created_at": datetime.now(UTC), "id": thread_id, "_id": thread_id}

        self.engine.update_one(
            self.threads,
            {"id": thread_id},
            set_fields=set_data if set_data else None,
            inc_fields=inc_data if inc_data else None,
            set_on_insert=set_on_insert,
            upsert=True,
        )

        tokens_to_deduct = usage_info["total_tokens"]
        requests_to_deduct = usage_info["requests"]
        self.user_store.usage_deduct_and_log(user_id, thread_id, tokens_to_deduct, requests_to_deduct, usage_info)

    def update_thread_info(
        self, thread_id: str, title: str | None = None, user_id: str | None = None, **kwargs
    ) -> None:
        update_doc = {}
        if title:
            update_doc["title"] = title
        if user_id:
            update_doc["user_id"] = user_id

        update_doc.update(kwargs)

        if update_doc:
            update_doc["updated_at"] = datetime.now(UTC)
            self.engine.update_one(
                self.threads,
                {"id": thread_id},
                set_fields=update_doc,
                set_on_insert={"created_at": datetime.now(UTC)},
                upsert=True,
            )

    def search_threads(
        self, query: str, skip: int = 0, limit: int = 50, feedback_filter: str | None = None
    ) -> list[dict]:
        user_query = {
            "$or": [
                {"name": {"$regex": query, "$options": "i"}},
                {"surname": {"$regex": query, "$options": "i"}},
                {"phone": {"$regex": query, "$options": "i"}},
                {"id": query},
            ]
        }
        matching_users = self.engine.find_many(self.users, user_query)
        user_ids = [u["id"] for u in matching_users]

        item_query = {
            "$or": [
                {"content": {"$regex": query, "$options": "i"}},
                {"content.text": {"$regex": query, "$options": "i"}},
                {"content.parts.text": {"$regex": query, "$options": "i"}},
            ]
        }
        item_thread_ids = self.engine.distinct(self.thread_items, "thread_id", item_query)

        thread_query = {
            "$or": [
                {"user_id": {"$in": user_ids}},
                {"title": {"$regex": query, "$options": "i"}},
                {"id": query},
                {"id": {"$in": item_thread_ids}},
            ]
        }

        if feedback_filter:
            fb_query = {}
            if feedback_filter == "liked":
                fb_query = {"sentiment": "like"}
            elif feedback_filter == "disliked":
                fb_query = {"sentiment": "dislike"}

            fb_thread_ids = self.engine.distinct(self.feedbacks, "thread_id", fb_query)
            thread_query = {"$and": [thread_query, {"id": {"$in": fb_thread_ids}}]}

        threads = self.engine.find_many(self.threads, thread_query, sort=[("created_at", -1)], skip=skip, limit=limit)

        thread_ids = [t["id"] for t in threads]
        feedbacks = self.engine.find_many(self.feedbacks, {"thread_id": {"$in": thread_ids}})
        feedback_counts = {}

        # Track items already counted to ensure each message's feedback is counted only once
        # Map: tid -> { item_id -> sentiment }
        tid_message_feedbacks = {}

        for fb in feedbacks:
            tid = fb["thread_id"]
            if tid not in tid_message_feedbacks:
                tid_message_feedbacks[tid] = {}

            items = fb.get("item_ids", [])
            sentiment = fb.get("sentiment")
            if isinstance(items, list) and sentiment:
                for mid in items:
                    tid_message_feedbacks[tid][mid] = sentiment

        # Now aggregate the unique message sentiments into counts
        for tid, message_map in tid_message_feedbacks.items():
            counts = {"like": 0, "dislike": 0}
            for sentiment in message_map.values():
                if sentiment in counts:
                    counts[sentiment] += 1
            feedback_counts[tid] = counts

        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()

            thread["feedback_info"] = feedback_counts.get(thread["id"], {"like": 0, "dislike": 0})

            user = self.user_store.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def list_all_threads(self, skip: int = 0, limit: int = 50, feedback_filter: str | None = None) -> list[dict]:
        filter_doc = {}
        if feedback_filter:
            fb_query = {}
            if feedback_filter == "liked":
                fb_query = {"sentiment": "like"}
            elif feedback_filter == "disliked":
                fb_query = {"sentiment": "dislike"}

            thread_ids = self.engine.distinct(self.feedbacks, "thread_id", fb_query)
            filter_doc["id"] = {"$in": thread_ids}

        threads = self.engine.find_many(self.threads, filter_doc, sort=[("created_at", -1)], skip=skip, limit=limit)

        thread_ids = [t["id"] for t in threads]
        feedbacks = self.engine.find_many(self.feedbacks, {"thread_id": {"$in": thread_ids}})
        feedback_counts = {}

        # Track items already counted to ensure each message's feedback is counted only once
        # Map: tid -> { item_id -> sentiment }
        tid_message_feedbacks = {}

        for fb in feedbacks:
            tid = fb["thread_id"]
            if tid not in tid_message_feedbacks:
                tid_message_feedbacks[tid] = {}

            items = fb.get("item_ids", [])
            sentiment = fb.get("sentiment")
            if isinstance(items, list) and sentiment:
                for mid in items:
                    tid_message_feedbacks[tid][mid] = sentiment

        # Now aggregate the unique message sentiments into counts
        for tid, message_map in tid_message_feedbacks.items():
            counts = {"like": 0, "dislike": 0}
            for sentiment in message_map.values():
                if sentiment in counts:
                    counts[sentiment] += 1
            feedback_counts[tid] = counts

        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()

            thread["feedback_info"] = feedback_counts.get(thread["id"], {"like": 0, "dislike": 0})

            user = self.user_store.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def get_thread_items_for_admin(self, thread_id: str) -> list[dict]:
        items = self.engine.find_many(self.thread_items, {"thread_id": thread_id}, sort=[("created_at", 1)])

        feedbacks = self.engine.find_many(self.feedbacks, {"thread_id": thread_id})
        feedback_map = {}
        for fb in feedbacks:
            item_ids = fb.get("item_ids")
            if isinstance(item_ids, list):
                for item_id in item_ids:
                    feedback_map[item_id] = fb.get("sentiment")

        for item in items:
            item.pop("_id", None)
            m_id = item.get("id")
            if m_id in feedback_map:
                item["feedback"] = feedback_map[m_id]

            if "created_at" in item and hasattr(item["created_at"], "isoformat"):
                item["created_at"] = item["created_at"].isoformat()
            if "updated_at" in item and hasattr(item["updated_at"], "isoformat"):
                item["updated_at"] = item["updated_at"].isoformat()
        return items

    def create_shared_thread(self, thread_id: str, user_id: str) -> str:
        """Creates a public readonly snapshot of a thread."""
        import uuid

        thread = self.engine.find_one(self.threads, {"id": thread_id, "user_id": user_id, "is_deleted": {"$ne": True}})
        if not thread:
            raise ValueError("Thread not found or access denied")

        items = self.get_thread_items(user_id=user_id, thread_id=thread_id)

        share_id = f"share_{uuid.uuid4().hex}"
        shared_doc = {
            "id": share_id,
            "thread_id": thread_id,
            "title": thread.get("title", "Shared Chat"),
            "items": items,
            "created_at": datetime.now(UTC),
        }

        self.engine.insert_one(self.shared_threads, shared_doc)
        return share_id

    def get_shared_thread(self, share_id: str) -> dict | None:
        """Retrieves a public readonly snapshot of a thread."""
        shared = self.engine.find_one(self.shared_threads, {"id": share_id})
        if not shared:
            return None

        shared.pop("_id", None)
        if "created_at" in shared and hasattr(shared["created_at"], "isoformat"):
            shared["created_at"] = shared["created_at"].isoformat()

        return shared
