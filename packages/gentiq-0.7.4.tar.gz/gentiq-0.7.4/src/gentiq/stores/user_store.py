from datetime import UTC, datetime

from ..engines.base import DBEngine
from ..env import INITIAL_BALANCE_REQUESTS, INITIAL_BALANCE_TOKENS, TRANSACTIONS, USERS
from ..schemas import Balance, Transaction, TransactionChange, User


class UserStore:
    """Store for managing user profiles, authentication data, and usage balances.

    The UserStore provides a high-level API for interacting with the user collection,
    handling everything from basic CRUD operations to complex atomic balance updates
    and transaction logging.

    Args:
        engine: The database engine instance used for persistence.
        collection: The name of the collection/table for user documents.
        transactions_collection: The name of the collection/table for transaction logs.
    """

    def __init__(self, engine: DBEngine, collection: str = USERS, transactions_collection: str = TRANSACTIONS):
        self.engine = engine
        self.collection = collection
        self.transactions_collection = transactions_collection

    def get_user(self, user_id: str) -> User | None:
        """Retrieve a user by their unique ID."""
        doc = self.engine.find_one(self.collection, {"id": user_id})
        if not doc:
            return None
        doc.pop("_id", None)
        return User.model_validate(doc)

    def get_user_by_phone(self, phone: str) -> User | None:
        """Retrieve a user by their phone number."""
        doc = self.engine.find_one(self.collection, {"phone": phone})
        if doc:
            doc.pop("_id", None)
            return User.model_validate(doc)
        return None

    def create_user(
        self,
        user_id: str,
        phone: str,
        name: str,
        surname: str,
        token: str,
        balance: Balance | dict | None = None,
        password_hash: str | None = None,
    ) -> User:
        if balance is None:
            balance = Balance(
                tokens=INITIAL_BALANCE_TOKENS,
                requests=INITIAL_BALANCE_REQUESTS,
                token_limit=INITIAL_BALANCE_TOKENS,
                request_limit=INITIAL_BALANCE_REQUESTS,
                updated_at=datetime.now(UTC),
            )
        elif isinstance(balance, dict):
            balance = Balance.model_validate(balance)

        if balance and balance.tokens > balance.token_limit:
            raise ValueError(f"Initial tokens ({balance.tokens}) cannot exceed token limit ({balance.token_limit})")
        if balance and balance.requests > balance.request_limit:
            raise ValueError(
                f"Initial requests ({balance.requests}) cannot exceed request limit ({balance.request_limit})"
            )

        user = User(
            id=user_id,
            phone=phone,
            password_hash=password_hash,
            name=name,
            surname=surname,
            token=token,
            balance=balance,
            created_at=datetime.now(UTC),
        )
        self.engine.insert_one(self.collection, user.model_dump())
        return user

    def update_user_token(self, user_id: str, token: str) -> None:
        self.engine.update_one(self.collection, {"id": user_id}, set_fields={"token": token})

    def update_user_password(self, user_id: str, password_hash: str) -> None:
        self.engine.update_one(self.collection, {"id": user_id}, set_fields={"password_hash": password_hash})

    def update_user_phone(self, user_id: str, phone: str) -> None:
        self.engine.update_one(self.collection, {"id": user_id}, set_fields={"phone": phone})

    def update_user_info(
        self,
        user_id: str,
        name: str | None = None,
        surname: str | None = None,
    ) -> None:
        set_fields = {}
        if name is not None:
            set_fields["name"] = name
        if surname is not None:
            set_fields["surname"] = surname
        if set_fields:
            self.engine.update_one(self.collection, {"id": user_id}, set_fields=set_fields)

    def list_users(self, skip: int = 0, limit: int = 100, query: str | None = None) -> list[User]:
        filter_doc = {}
        if query:
            filter_doc = {
                "$or": [
                    {"name": {"$regex": query, "$options": "i"}},
                    {"surname": {"$regex": query, "$options": "i"}},
                    {"phone": {"$regex": query, "$options": "i"}},
                ]
            }
        docs = self.engine.find_many(self.collection, filter_doc, sort=[("name", 1)], skip=skip, limit=limit)
        return [User.model_validate({k: v for k, v in doc.items() if k != "_id"}) for doc in docs]

    def count_users(self, query: str | None = None) -> int:
        filter_doc = {}
        if query:
            filter_doc = {
                "$or": [
                    {"name": {"$regex": query, "$options": "i"}},
                    {"surname": {"$regex": query, "$options": "i"}},
                    {"phone": {"$regex": query, "$options": "i"}},
                ]
            }
        return self.engine.count_documents(self.collection, filter_doc)

    def delete_user(self, user_id: str) -> bool:
        return self.engine.delete_one(self.collection, {"id": user_id})

    def get_user_balance(self, user_id: str) -> Balance:
        user = self.get_user(user_id)
        if not user:
            raise ValueError("User not found")
        return user.balance or Balance(
            tokens=0, requests=0, token_limit=0, request_limit=0, updated_at=datetime.now(UTC)
        )

    def check_user_balance(self, user_id: str) -> bool:
        balance = self.get_user_balance(user_id)
        return balance.tokens > 0 and balance.requests > 0

    def update_user_balance(
        self, user_id: str, tokens: int, requests: int, token_limit: int | None = None, request_limit: int | None = None
    ) -> dict:
        user = self.get_user(user_id)
        if not user:
            raise ValueError("User not found")

        current_balance = user.balance or Balance(
            tokens=0, requests=0, token_limit=0, request_limit=0, updated_at=datetime.now(UTC)
        )

        target_token_limit = token_limit if token_limit is not None else current_balance.token_limit
        target_request_limit = request_limit if request_limit is not None else current_balance.request_limit

        if tokens > target_token_limit:
            raise ValueError(f"Tokens ({tokens}) cannot exceed token limit ({target_token_limit})")
        if requests > target_request_limit:
            raise ValueError(f"Requests ({requests}) cannot exceed request limit ({target_request_limit})")

        token_change = tokens - current_balance.tokens
        request_change = requests - current_balance.requests

        new_balance = Balance(
            tokens=tokens,
            requests=requests,
            token_limit=token_limit if token_limit is not None else current_balance.token_limit,
            request_limit=request_limit if request_limit is not None else current_balance.request_limit,
            updated_at=datetime.now(UTC),
        )
        self.engine.update_one(self.collection, {"id": user_id}, set_fields={"balance": new_balance.model_dump()})

        transaction = Transaction(
            user_id=user_id,
            type="balance_update",
            change=TransactionChange(tokens=token_change, requests=request_change),
            balance_after=TransactionChange(tokens=tokens, requests=requests),
            created_at=datetime.now(UTC),
        )
        self.engine.insert_one(self.transactions_collection, transaction.model_dump(by_alias=True))
        return new_balance.model_dump()

    def recharge_user(self, user_id: str, add_tokens: int, add_requests: int) -> dict:
        updated_user = self.engine.update_and_return(
            self.collection,
            {"id": user_id},
            set_fields={"balance.updated_at": datetime.now(UTC)},
            inc_fields={
                "balance.tokens": add_tokens,
                "balance.requests": add_requests,
                "balance.token_limit": add_tokens,
                "balance.request_limit": add_requests,
            },
            return_after=True,
        )

        if not updated_user:
            raise ValueError("User not found")

        new_balance_dict = updated_user.get("balance", {"tokens": 0, "requests": 0, "updated_at": datetime.now(UTC)})
        new_balance = Balance.model_validate(new_balance_dict)

        transaction = Transaction(
            user_id=user_id,
            type="recharge",
            change=TransactionChange(tokens=add_tokens, requests=add_requests),
            balance_after=TransactionChange(tokens=new_balance.tokens, requests=new_balance.requests),
            created_at=datetime.now(UTC),
        )
        self.engine.insert_one(self.transactions_collection, transaction.model_dump(by_alias=True))
        return new_balance.model_dump()

    def usage_deduct_and_log(
        self, user_id: str, thread_id: str, tokens_to_deduct: int, requests_to_deduct: int, usage_info: dict
    ) -> None:
        updated_user = self.engine.update_and_return(
            self.collection,
            {"id": user_id},
            set_fields={"balance.updated_at": datetime.now(UTC)},
            inc_fields={"balance.tokens": -tokens_to_deduct, "balance.requests": -requests_to_deduct},
            return_after=True,
        )
        if not updated_user:
            return

        new_balance_dict = updated_user.get("balance", {"tokens": 0, "requests": 0, "updated_at": datetime.now(UTC)})
        new_balance = Balance.model_validate(new_balance_dict)

        transaction = Transaction(
            user_id=user_id,
            type="usage",
            thread_id=thread_id,
            change=TransactionChange(tokens=-tokens_to_deduct, requests=-requests_to_deduct),
            balance_after=TransactionChange(tokens=new_balance.tokens, requests=new_balance.requests),
            created_at=datetime.now(UTC),
            details=usage_info,
        )
        self.engine.insert_one(self.transactions_collection, transaction.model_dump(by_alias=True))
