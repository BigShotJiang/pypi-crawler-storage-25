from typing import Any

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field


class Balance(BaseModel):
    """Represents a user's balance for different resources."""

    tokens: int
    requests: int
    updated_at: AwareDatetime
    token_limit: int
    request_limit: int


class User(BaseModel):
    """Represents a Gentiq user profile and their current balance."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    phone: str
    name: str
    surname: str
    token: str
    balance: Balance | None
    created_at: AwareDatetime
    password_hash: str | None


class Feedback(BaseModel):
    """Represents user feedback (sentiment) on one or more chat items."""

    thread_id: str
    item_ids: list[str]
    sentiment: str
    user_id: str
    created_at: AwareDatetime | None = None


class Admin(BaseModel):
    """Represents an administrative user with specific permissions."""

    id: str
    username: str
    password_hash: str
    name: str
    permissions: list[str]
    created_at: AwareDatetime | None = None


class TransactionChange(BaseModel):
    """Represents the change in balance for a transaction."""

    tokens: int
    requests: int


class Transaction(BaseModel):
    """Represents a balance change (recharge or usage) for a user."""

    model_config = ConfigDict(populate_by_name=True)

    user_id: str
    type_: str = Field(alias="type")
    change: TransactionChange
    balance_after: TransactionChange
    created_at: AwareDatetime
    thread_id: str | None = None
    details: dict[str, Any] | None = None


class SharedConversation(BaseModel):
    """Represents a readonly snapshot of a conversation for public sharing."""

    id: str
    title: str
    items: list[dict]
    created_at: AwareDatetime
