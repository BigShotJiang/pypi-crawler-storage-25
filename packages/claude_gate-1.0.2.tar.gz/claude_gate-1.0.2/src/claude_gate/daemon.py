#!/usr/bin/env python3
"""
daemon.py — Listens for Slack DMs and runs Claude Code tasks remotely.

Start via: cg up

Slack commands:
    !start-session — Open an interactive Claude session
    !end-session   — Close the interactive session
    !status        — Show what's running and for how long
    !stop          — Kill the running task
    !output [N]    — Dump last N lines of output
    !revoke        — Revoke "Allow All Session" flag
"""

import sys
import os
import re
import json
import pty
import select
import signal
import subprocess
import threading
import time

ANSI_ESCAPE = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

from claude_gate.env import load_env

from slack_sdk import WebClient
from slack_sdk.socket_mode import SocketModeClient
from slack_sdk.socket_mode.response import SocketModeResponse

SESSION_FLAG       = '/tmp/claude-hook-allow-all'
OUTPUT_DUMP_LINES  = 50   # how many lines !output returns
LOG_DIR            = '/tmp/claude-daemon-logs'
SILENCE_WARN_SECS  = 180  # warn on Slack after 3 min of no output

# ── Task state (shared across threads) ──────────────────────────────────────
task_running      = [False]
task_process      = [None]
task_name         = [None]   # what task is running
task_start        = [None]   # when it started (time.time())
task_output_lines = [[]]     # output lines for current task (reset per task)
task_lines_lock   = [None]   # lock for task_output_lines
task_last_output  = [None]   # time.time() of last line received
task_log_path     = [None]   # path to current task's log file
pending_task      = [None]

itask_active  = [False]  # session is open
itask_session = [None]   # claude session_id for --resume (None = not yet started)
itask_busy    = [False]  # currently processing a message
itask_process = [None]   # subprocess ref so !stop can kill it


def elapsed(start):
    """Return human-readable elapsed time string."""
    secs = int(time.time() - start)
    if secs < 60:
        return f"{secs}s"
    elif secs < 3600:
        return f"{secs // 60}m {secs % 60}s"
    else:
        return f"{secs // 3600}h {(secs % 3600) // 60}m"


_WHISPER_FORMATS = {'flac', 'm4a', 'mp3', 'mp4', 'mpeg', 'mpga', 'oga', 'ogg', 'wav', 'webm'}
_MIME_TO_EXT = {
    'audio/mp4':   'm4a',
    'audio/x-m4a': 'm4a',
    'audio/mpeg':  'mp3',
    'audio/ogg':   'ogg',
    'audio/webm':  'webm',
    'audio/flac':  'flac',
    'audio/wav':   'wav',
    'audio/wave':  'wav',
}

def _whisper_ext(file_meta):
    """Return a Whisper-compatible extension for a Slack file metadata dict."""
    name = file_meta.get('name', '')
    if name and '.' in name:
        ext = name.rsplit('.', 1)[-1].lower()
        if ext in _WHISPER_FORMATS:
            return ext
    return _MIME_TO_EXT.get(file_meta.get('mimetype', ''), 'm4a')


def transcribe_and_interpret(audio_bytes, ext, openai_api_key):
    """Transcribe audio with Whisper then convert spoken words to a task via GPT-4o-mini."""
    import openai
    oa = openai.OpenAI(api_key=openai_api_key)

    # Pass bytes as a named tuple so the SDK sends the correct filename + MIME type
    transcript = oa.audio.transcriptions.create(
        model='whisper-1',
        file=(f'audio.{ext}', audio_bytes, f'audio/{ext}'),
    )
    spoken = transcript.text.strip()

    resp = oa.chat.completions.create(
        model='gpt-4o-mini',
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a task interpreter for a software coding assistant called Claude Code. "
                    "The user sent a voice message which may be in any language. "
                    "Convert their spoken words into a single, clear, concise task description that "
                    "Claude Code can execute directly. "
                    "Always respond in English regardless of the language of the voice message. "
                    "Return only the task description — no preamble, no punctuation wrapping."
                )
            },
            {"role": "user", "content": spoken}
        ]
    )
    task = resp.choices[0].message.content.strip()
    return spoken, task


def _slack_download(url, bot_token):
    """Download a Slack private file, following CDN redirects without auth."""
    import httpx

    with httpx.Client(follow_redirects=False) as client:
        r = client.get(url, headers={'Authorization': f'Bearer {bot_token}'})
        if r.status_code in (301, 302, 303, 307, 308):
            r = client.get(r.headers['location'], follow_redirects=True)
        return r.content


def handle_voice_message(slack_client, channel, event, config):
    """Detect an audio file in a Slack message, transcribe it, and show an approval card.

    Returns True if the event contained an audio file (caller should skip text parsing).
    """
    files = event.get('files', [])
    audio = next((f for f in files if f.get('mimetype', '').startswith('audio/')), None)
    if not audio:
        return False

    openai_key = config.get('OPENAI_API_KEY')
    if not openai_key:
        slack_client.chat_postMessage(
            channel=channel,
            text=(
                '⚠️ Voice messages require `OPENAI_API_KEY` in `.env`.\n'
                'Add it and restart the daemon to enable transcription.'
            )
        )
        return True

    def process():
        try:
            slack_client.chat_postMessage(channel=channel, text='🎙️ Transcribing voice message…')

            url = audio.get('url_private_download') or audio.get('url_private')
            audio_bytes = _slack_download(url, config['SLACK_BOT_TOKEN'])

            ext = _whisper_ext(audio)
            spoken, task = transcribe_and_interpret(audio_bytes, ext, openai_key)

            pending_task[0] = task
            slack_client.chat_postMessage(
                channel=channel,
                text=f'🎙️ Voice: {spoken}\n🤖 Task: {task}',
                blocks=[
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": (
                                f"🎙️ *Voice transcript:*\n_{spoken}_\n\n"
                                f"🤖 *Interpreted task:*\n_{task}_"
                            )
                        }
                    },
                    {
                        "type": "actions",
                        "elements": [
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "✅  Run Task"},
                                "style": "primary",
                                "action_id": "run_task",
                                "value": task
                            },
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "❌  Cancel"},
                                "style": "danger",
                                "action_id": "cancel_task",
                                "value": "cancel"
                            }
                        ]
                    }
                ]
            )
        except Exception as e:
            slack_client.chat_postMessage(channel=channel, text=f'❌ Voice processing failed: {e}')

    threading.Thread(target=process, daemon=True).start()
    return True


def run_task(client, channel, task, project_dir):
    """Run `claude --print <task>`, stream live output to Slack, post result."""
    task_running[0]      = True
    task_name[0]         = task
    task_start[0]        = time.time()
    task_last_output[0]  = None

    output_lines = []  # all lines collected so far
    lines_lock   = threading.Lock()

    # expose to handle_event so !output can read them
    task_output_lines[0] = output_lines
    task_lines_lock[0]   = lines_lock

    os.makedirs(LOG_DIR, exist_ok=True)
    log_file = os.path.join(LOG_DIR, f"task_{int(task_start[0])}.log")
    task_log_path[0] = log_file
    log_fh = open(log_file, 'w', buffering=1)
    log_fh.write(f"Task: {task}\nStarted: {time.strftime('%Y-%m-%d %H:%M:%S')}\n{'='*60}\n")

    # Auto-approve all tool actions while daemon task is running
    # (user already approved at the task level)
    open(SESSION_FLAG, 'w').close()

    try:
        client.chat_postMessage(
            channel=channel,
            blocks=[{
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": (
                        f"🔄 *Working on it...*\n\n_{task}_\n\n"
                        f"_Live tool-by-tool updates via hooks_"
                    )
                }
            }],
            text=f"🔄 Working on: {task}"
        )

        # Use a pty so claude thinks it's writing to a real terminal
        # This prevents output buffering and gives us real-time lines
        master_fd, slave_fd = pty.openpty()

        daemon_settings = os.path.join(project_dir, '.claude/settings.daemon.json')
        process = subprocess.Popen(
            ['claude',
             '--setting-sources', 'user',
             '--settings', daemon_settings,
             '--print', task],
            stdin=subprocess.DEVNULL,
            stdout=slave_fd,
            stderr=slave_fd,
            cwd=project_dir,
            close_fds=True,
            preexec_fn=os.setsid   # own process group so !stop kills children too
        )
        os.close(slave_fd)
        task_process[0] = process

        # ── Thread: read Claude's output from pty master ─────────────────────
        def read_output():
            buf = ''
            while True:
                try:
                    r, _, _ = select.select([master_fd], [], [], 0.5)
                    if r:
                        data = os.read(master_fd, 4096).decode('utf-8', errors='replace')
                        buf += data
                        lines = buf.split('\n')
                        buf = lines[-1]  # keep incomplete line
                        for line in lines[:-1]:
                            clean = ANSI_ESCAPE.sub('', line).rstrip('\r')
                            if clean.strip():
                                with lines_lock:
                                    output_lines.append(clean)
                                log_fh.write(clean + '\n')
                                task_last_output[0] = time.time()
                    elif process.poll() is not None:
                        break
                except OSError:
                    break
            try:
                os.close(master_fd)
            except OSError:
                pass

        reader = threading.Thread(target=read_output, daemon=True)
        reader.start()

        # ── Thread: warn on Slack if no output for SILENCE_WARN_SECS ─────────
        def monitor_silence():
            warned_at = [0]
            while task_running[0] and process.poll() is None:
                time.sleep(15)
                if task_last_output[0] is None:
                    continue
                silent_secs = int(time.time() - task_last_output[0])
                if silent_secs >= SILENCE_WARN_SECS and time.time() - warned_at[0] > SILENCE_WARN_SECS:
                    warned_at[0] = time.time()
                    client.chat_postMessage(
                        channel=channel,
                        text=(
                            f"⚠️ *Possibly stuck* — no output for {silent_secs // 60}m "
                            f"({elapsed(task_start[0])} elapsed)\n"
                            f"Send `!stop` to kill it, or wait if it's expected."
                        )
                    )

        threading.Thread(target=monitor_silence, daemon=True).start()

        process.wait()
        reader.join(timeout=5)

        with lines_lock:
            full_output = '\n'.join(output_lines).strip() or '(no output)'

        # Split into 2800-char chunks (Slack block limit)
        chunks = [full_output[i:i+2800] for i in range(0, len(full_output), 2800)]

        client.chat_postMessage(
            channel=channel,
            text=f'✅ Task complete! ({elapsed(task_start[0])})',
            blocks=[{
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"✅ *Task complete!* _{elapsed(task_start[0])} elapsed_"
                }
            }]
        )
        for i, chunk in enumerate(chunks):
            label = f"_(part {i+1}/{len(chunks)})_\n" if len(chunks) > 1 else ""
            client.chat_postMessage(
                channel=channel,
                text=chunk,
                blocks=[{
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": f"{label}```\n{chunk}\n```"}
                }]
            )

    except Exception as e:
        client.chat_postMessage(channel=channel, text=f'❌ Error running task: {str(e)}')

    finally:
        task_running[0] = False
        task_process[0] = None
        try:
            log_fh.write(f"\n{'='*60}\nFinished: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            log_fh.close()
        except Exception:
            pass
        # Clear session flag when task finishes
        if os.path.exists(SESSION_FLAG):
            os.remove(SESSION_FLAG)


def run_interactive_message(client, channel, message, project_dir):
    """Run a single message exchange inside an active interactive session."""
    itask_busy[0] = True
    try:
        client.chat_postMessage(channel=channel, text='🔄 Working on it...')

        daemon_settings = os.path.join(project_dir, '.claude/settings.daemon.json')
        cmd = ['claude',
               '--setting-sources', 'user',
               '--settings', daemon_settings,
               '--print', '--output-format', 'json', message]
        if itask_session[0]:
            cmd = ['claude',
                   '--setting-sources', 'user',
                   '--settings', daemon_settings,
                   '--resume', itask_session[0],
                   '--print', '--output-format', 'json', message]

        open(SESSION_FLAG, 'w').close()

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=project_dir,
            preexec_fn=os.setsid
        )
        itask_process[0] = proc
        stdout, _ = proc.communicate()
        itask_process[0] = None

        raw = stdout.decode('utf-8', errors='replace')
        try:
            data = json.loads(raw)
            itask_session[0] = data.get('session_id', itask_session[0])
            response = data.get('result', raw)
        except (json.JSONDecodeError, ValueError):
            response = raw

        response = ANSI_ESCAPE.sub('', response).strip() or '(no output)'

        chunks = [response[i:i+2800] for i in range(0, len(response), 2800)]
        for i, chunk in enumerate(chunks):
            label = f"_(part {i+1}/{len(chunks)})_\n" if len(chunks) > 1 else ""
            client.chat_postMessage(
                channel=channel,
                text=chunk,
                blocks=[{
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": f"{label}```\n{chunk}\n```"}
                }]
            )

        if itask_active[0]:
            client.chat_postMessage(
                channel=channel,
                text='💬 Send your next message or end the session.',
                blocks=[
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "💬 Send your next message or end the session."
                        }
                    },
                    {
                        "type": "actions",
                        "elements": [
                            {
                                "type": "button",
                                "text": {"type": "plain_text", "text": "🔚  End Session"},
                                "style": "danger",
                                "action_id": "end_session",
                                "value": "end_session"
                            }
                        ]
                    }
                ]
            )
    except Exception as e:
        client.chat_postMessage(channel=channel, text=f'❌ Error: {e}')
    finally:
        itask_busy[0] = False
        itask_process[0] = None
        if os.path.exists(SESSION_FLAG):
            os.remove(SESSION_FLAG)


def main():
    config       = load_env()
    bot_token    = config['SLACK_BOT_TOKEN']
    app_token    = config['SLACK_APP_TOKEN']
    user_id      = config['SLACK_USER_ID']
    project_dir  = config['PROJECT_DIR']
    project_name = config.get('PROJECT_NAME', 'project')

    client = WebClient(token=bot_token)

    result  = client.conversations_open(users=user_id)
    channel = result['channel']['id']

    client.chat_postMessage(
        channel=channel,
        text='🟢 Claude daemon started!',
        blocks=[
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": (
                        f"🟢 *Claude daemon started!*\n"
                        f"Project: *{project_name}*\n"
                        f"Directory: `{project_dir}`\n\n"
                        f"Inside a session, send text or 🎙️ *voice messages* to run tasks.\n"
                        f"While running: `!output` for full output, `!status`, `!stop`."
                    )
                }
            },
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "💬  Start Session"},
                        "style": "primary",
                        "action_id": "start_session"
                    }
                ]
            }
        ]
    )

    sm_client = SocketModeClient(app_token=app_token, web_client=client)

    # ── SIGTERM handler so `cg down` can shut us down cleanly ──────────────
    _sm_ref = [sm_client]
    def _sigterm_handler(signum, frame):
        try:
            client.chat_postMessage(channel=channel, text=f'🔴 Claude daemon stopped for *{project_name}*.')
        except Exception:
            pass
        try:
            _sm_ref[0].close()
        except Exception:
            pass
        sys.exit(0)
    import signal as _signal
    _signal.signal(_signal.SIGTERM, _sigterm_handler)

    def handle_event(sm, req):
        sm.send_socket_mode_response(SocketModeResponse(envelope_id=req.envelope_id))

        # ── Button clicks ─────────────────────────────────────────────────────
        if req.type == 'interactive':
            payload = req.payload
            if isinstance(payload, str):
                payload = json.loads(payload)

            for action in payload.get('actions', []):
                action_id = action.get('action_id')

                if action_id == 'run_task':
                    task = pending_task[0]
                    if not task:
                        return
                    pending_task[0] = None

                    if itask_active[0]:
                        if itask_busy[0]:
                            client.chat_postMessage(channel=channel, text='⏳ Still processing, please wait.')
                            return
                        threading.Thread(
                            target=run_interactive_message,
                            args=(client, channel, task, project_dir),
                            daemon=True
                        ).start()
                    else:
                        if task_running[0]:
                            client.chat_postMessage(
                                channel=channel,
                                text=f'⚠️ Already running: _{task_name[0]}_ ({elapsed(task_start[0])} elapsed)\nSend `!stop` to cancel it first.'
                            )
                            return
                        threading.Thread(
                            target=run_task,
                            args=(client, channel, task, project_dir),
                            daemon=True
                        ).start()

                elif action_id == 'cancel_task':
                    pending_task[0] = None
                    client.chat_postMessage(channel=channel, text='❌ Task cancelled.')

                elif action_id == 'start_session':
                    if task_running[0]:
                        client.chat_postMessage(channel=channel, text='⚠️ A task is already running. Send `!stop` first.')
                    elif itask_active[0]:
                        client.chat_postMessage(channel=channel, text='⚠️ Already in a session. Send `!end-session` first.')
                    else:
                        itask_active[0] = True
                        itask_session[0] = None
                        client.chat_postMessage(channel=channel, text='💬 Session started. What do you want me to do?')

                elif action_id == 'end_session':
                    itask_active[0] = False
                    itask_session[0] = None
                    client.chat_postMessage(channel=channel, text='✅ Interactive session ended.')

        # ── Incoming DM messages ──────────────────────────────────────────────
        elif req.type == 'events_api':
            event = req.payload.get('event', {})

            if event.get('type') != 'message' or event.get('bot_id'):
                return
            if event.get('user') != user_id:
                return

            # ── Voice messages (audio file attachments) ──────────────────────
            if event.get('files') and any(f.get('mimetype', '').startswith('audio/') for f in event.get('files', [])):
                if not itask_active[0]:
                    client.chat_postMessage(
                        channel=channel,
                        text='⚠️ No session is active. Start a session first.',
                        blocks=[
                            {
                                "type": "section",
                                "text": {"type": "mrkdwn", "text": "⚠️ No session is active. Start a session to send voice messages."}
                            },
                            {
                                "type": "actions",
                                "elements": [
                                    {
                                        "type": "button",
                                        "text": {"type": "plain_text", "text": "💬  Start Session"},
                                        "style": "primary",
                                        "action_id": "start_session"
                                    }
                                ]
                            }
                        ]
                    )
                    return
                if handle_voice_message(client, channel, event, config):
                    return

            text = event.get('text', '').strip()

            # ── !start-session ──────────────────────────────────────────────────
            if text.lower() == '!start-session':
                if task_running[0]:
                    client.chat_postMessage(channel=channel, text='⚠️ A task is already running. Send `!stop` first.')
                    return
                if itask_active[0]:
                    client.chat_postMessage(channel=channel, text='⚠️ Already in a session. Send `!end-session` first.')
                    return
                itask_active[0] = True
                itask_session[0] = None
                client.chat_postMessage(channel=channel, text='💬 What do you want me to do?')

            # ── !end-session ─────────────────────────────────────────────────────
            elif text.lower() == '!end-session':
                if not itask_active[0]:
                    client.chat_postMessage(channel=channel, text='⚠️ No interactive session is active.')
                    return
                itask_active[0] = False
                itask_session[0] = None
                client.chat_postMessage(channel=channel, text='✅ Interactive session ended.')

            # ── Non-! text with no active session ────────────────────────────
            elif not itask_active[0] and not text.startswith('!'):
                client.chat_postMessage(
                    channel=channel,
                    text='⚠️ No session is active. Start a session first.',
                    blocks=[
                        {
                            "type": "section",
                            "text": {"type": "mrkdwn", "text": "⚠️ No session is active. Start a session to perform a task."}
                        },
                        {
                            "type": "actions",
                            "elements": [
                                {
                                    "type": "button",
                                    "text": {"type": "plain_text", "text": "💬  Start Session"},
                                    "style": "primary",
                                    "action_id": "start_session"
                                }
                            ]
                        }
                    ]
                )

            # ── Messages during active session (non-! text) ───────────────────
            elif itask_active[0] and not text.startswith('!'):
                if itask_busy[0]:
                    client.chat_postMessage(channel=channel, text='⏳ Still working on previous message. Please wait.')
                    return
                if itask_session[0] is None:
                    # First message — show confirmation card
                    pending_task[0] = text
                    client.chat_postMessage(
                        channel=channel,
                        text=f"🤖 Here's what I'll do:\n\"{text}\"",
                        blocks=[
                            {
                                "type": "section",
                                "text": {
                                    "type": "mrkdwn",
                                    "text": f"🤖 *Here's what I'll do:*\n\n_{text}_"
                                }
                            },
                            {
                                "type": "actions",
                                "elements": [
                                    {
                                        "type": "button",
                                        "text": {"type": "plain_text", "text": "✅  Run Task"},
                                        "style": "primary",
                                        "action_id": "run_task",
                                        "value": text
                                    },
                                    {
                                        "type": "button",
                                        "text": {"type": "plain_text", "text": "❌  Cancel"},
                                        "style": "danger",
                                        "action_id": "cancel_task",
                                        "value": "cancel"
                                    }
                                ]
                            }
                        ]
                    )
                else:
                    # Follow-up message — run directly, no confirmation
                    threading.Thread(
                        target=run_interactive_message,
                        args=(client, channel, text, project_dir),
                        daemon=True
                    ).start()

            # ── !run <task> — disabled; use !start-session instead ───────────
            # elif text.lower().startswith('!run '):
            #     task = text[5:].strip()
            #     if not task:
            #         client.chat_postMessage(
            #             channel=channel,
            #             text='⚠️ Please provide a task description.\nExample: `!run fix the login bug`'
            #         )
            #         return
            #
            #     pending_task[0] = task
            #     client.chat_postMessage(
            #         channel=channel,
            #         text=f"🤖 Here's what I'll do:\n\"{task}\"",
            #         blocks=[
            #             {
            #                 "type": "section",
            #                 "text": {
            #                     "type": "mrkdwn",
            #                     "text": f"🤖 *Here's what I'll do:*\n\n_{task}_"
            #                 }
            #             },
            #             {
            #                 "type": "actions",
            #                 "elements": [
            #                     {
            #                         "type": "button",
            #                         "text": {"type": "plain_text", "text": "✅  Run Task"},
            #                         "style": "primary",
            #                         "action_id": "run_task",
            #                         "value": task
            #                     },
            #                     {
            #                         "type": "button",
            #                         "text": {"type": "plain_text", "text": "❌  Cancel"},
            #                         "style": "danger",
            #                         "action_id": "cancel_task",
            #                         "value": "cancel"
            #                     }
            #                 ]
            #             }
            #         ]
            #     )

            # ── !status ──────────────────────────────────────────────────────
            elif text.lower() == '!status':
                if task_running[0]:
                    silence_note = ''
                    if task_last_output[0] is not None:
                        silent_secs = int(time.time() - task_last_output[0])
                        if silent_secs >= 10:
                            silence_note = f'\n_Silent for {silent_secs}s_'
                    with task_lines_lock[0] if task_lines_lock[0] else threading.Lock():
                        line_count = len(task_output_lines[0])
                    client.chat_postMessage(
                        channel=channel,
                        text=(
                            f"🔄 *Task running* ({elapsed(task_start[0])} elapsed)\n"
                            f"Task: _{task_name[0]}_\n"
                            f"{line_count} lines captured{silence_note}"
                        )
                    )
                else:
                    client.chat_postMessage(
                        channel=channel,
                        text='✅ No task running. Send `!start-session` to begin.'
                    )

            # ── !stop ────────────────────────────────────────────────────────
            elif text.lower() == '!stop':
                if itask_busy[0] and itask_process[0]:
                    try:
                        os.killpg(os.getpgid(itask_process[0].pid), signal.SIGTERM)
                    except Exception:
                        itask_process[0].terminate()
                    itask_busy[0] = False
                    itask_process[0] = None
                    client.chat_postMessage(channel=channel, text='🛑 Interactive message interrupted.')
                elif task_process[0] and task_running[0]:
                    try:
                        os.killpg(os.getpgid(task_process[0].pid), signal.SIGTERM)
                    except Exception:
                        task_process[0].terminate()
                    client.chat_postMessage(
                        channel=channel,
                        text=f'🛑 Stopped: _{task_name[0]}_ (ran for {elapsed(task_start[0])})'
                    )
                else:
                    client.chat_postMessage(channel=channel, text='⚠️ No task is currently running.')

            # ── !revoke ──────────────────────────────────────────────────────
            elif text.lower() == '!revoke':
                if os.path.exists(SESSION_FLAG):
                    os.remove(SESSION_FLAG)
                    client.chat_postMessage(channel=channel, text='🔒 "Allow All Session" revoked. Approvals are active again.')
                else:
                    client.chat_postMessage(channel=channel, text='ℹ️ No active session to revoke.')

            # ── !output ──────────────────────────────────────────────────────
            elif text.lower().startswith('!output'):
                parts = text.split()
                try:
                    n = int(parts[1]) if len(parts) > 1 else OUTPUT_DUMP_LINES
                except ValueError:
                    n = OUTPUT_DUMP_LINES

                lock = task_lines_lock[0]
                lines = task_output_lines[0]
                if lock is None or not lines:
                    client.chat_postMessage(channel=channel, text='⚠️ No output available yet.')
                else:
                    with lock:
                        snapshot = list(lines[-n:])
                        total    = len(lines)
                    preview = '\n'.join(snapshot)
                    if len(preview) > 2800:
                        preview = '...\n' + preview[-2800:]
                    silence_note = ''
                    if task_last_output[0] is not None:
                        silent_secs = int(time.time() - task_last_output[0])
                        if silent_secs >= 5:
                            silence_note = f'\n_Silent for {silent_secs}s_'
                    client.chat_postMessage(
                        channel=channel,
                        text=f'📋 Last {len(snapshot)} of {total} lines',
                        blocks=[{
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": (
                                    f"📋 *Last {len(snapshot)} of {total} lines* "
                                    f"({elapsed(task_start[0])} elapsed){silence_note}\n\n"
                                    f"```\n{preview}\n```"
                                )
                            }
                        }]
                    )

            # ── !log ─────────────────────────────────────────────────────────
            elif text.lower() == '!log':
                log = task_log_path[0]
                if not log or not os.path.exists(log):
                    client.chat_postMessage(channel=channel, text='⚠️ No log file available.')
                else:
                    client.chat_postMessage(
                        channel=channel,
                        text=f'📄 Log file: `{log}`\nUse `!output` to see the last lines, or read the file directly on the server.'
                    )

            # ── unknown command ──────────────────────────────────────────────
            elif text.startswith('!'):
                client.chat_postMessage(
                    channel=channel,
                    text=(
                        "❓ Unknown command. Available commands:\n"
                        "• `!start-session` — open an interactive Claude session\n"
                        "• `!end-session`   — close the interactive session\n"
                        "• `!status` — show what's running and elapsed time\n"
                        "• `!stop` — stop the current task\n"
                        "• `!output [N]` — dump last N lines of output (default 50)\n"
                        "• `!log` — show path to the full log file\n"
                        "• `!revoke` — revoke Allow All Session"
                    )
                )

    sm_client.socket_mode_request_listeners.append(handle_event)
    sm_client.connect()

    print(f'✅ Claude daemon running for {project_name}')
    print(f'   Directory : {project_dir}')
    print(f'   Listening for Slack messages...')
    print(f'   Press Ctrl+C to stop.\n')

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        client.chat_postMessage(
            channel=channel,
            text=f'🔴 Claude daemon stopped for *{project_name}*.'
        )
        sm_client.close()
        print('\nDaemon stopped.')


if __name__ == '__main__':
    main()
