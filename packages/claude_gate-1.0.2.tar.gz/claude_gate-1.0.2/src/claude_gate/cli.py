"""
cli.py — cg command-line interface for claude-gate.

Commands:
  cg setup-slack
  cg init [--adopt] [--force] [--env-file PATH]
  cg up [-d/--detach]
  cg down
  cg status
  cg logs [-f/--follow]
  cg doctor
  cg upgrade-hooks
"""

import argparse
import os
import shutil
import sys
import signal
import subprocess
import time
import importlib.resources as pkg_resources


# ── Helpers ──────────────────────────────────────────────────────────────────

def _data_dir():
    """Return the path to the package's data/ directory."""
    try:
        # Python 3.9+
        ref = pkg_resources.files('claude_gate') / 'data'
        return str(ref)
    except AttributeError:
        import pkg_resources as pr
        return pr.resource_filename('claude_gate', 'data')


def _dot_claude(project_dir=None):
    """Return .claude/ path for the given (or current) project dir."""
    base = project_dir or os.getcwd()
    return os.path.join(base, '.claude')


def _pid_file(project_dir=None):
    return os.path.join(_dot_claude(project_dir), 'daemon.pid')


def _daemon_log():
    return '/tmp/claude-daemon.log'


def _activity_log():
    return '/tmp/claude-activity.log'


def _read_pid(project_dir=None):
    """Read PID from daemon.pid. Returns int or None."""
    pid_path = _pid_file(project_dir)
    if not os.path.exists(pid_path):
        return None
    try:
        with open(pid_path) as f:
            return int(f.read().strip())
    except (ValueError, OSError):
        return None


def _pid_alive(pid):
    """Return True if a process with this PID is running."""
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


def _is_project_root(path):
    """Heuristic: does this look like a project root?"""
    for marker in ('.git', 'pyproject.toml', 'package.json', 'setup.py', 'Makefile'):
        if os.path.exists(os.path.join(path, marker)):
            return True
    return False


def _gate_files_present(dot_claude, data_dir):
    """Return True if any claude-gate owned files exist in dot_claude."""
    hooks_dir = os.path.join(dot_claude, 'hooks')
    if os.path.isdir(hooks_dir):
        src_hooks = os.path.join(data_dir, 'hooks')
        for fname in os.listdir(src_hooks):
            if os.path.exists(os.path.join(hooks_dir, fname)):
                return True
    for fname in ('settings.daemon.json', 'env.example', '.env', 'daemon.pid'):
        if os.path.exists(os.path.join(dot_claude, fname)):
            return True
    return False


def _copy_hooks(data_dir, hooks_dir):
    """Copy all hook files from package data/hooks/ to hooks_dir."""
    src_hooks = os.path.join(data_dir, 'hooks')
    os.makedirs(hooks_dir, exist_ok=True)
    for fname in os.listdir(src_hooks):
        src = os.path.join(src_hooks, fname)
        if not os.path.isfile(src):
            continue
        dst = os.path.join(hooks_dir, fname)
        shutil.copy2(src, dst)
        if fname.endswith('.py'):
            os.chmod(dst, 0o755)


def _prompt(label, default='', secret=False):
    """Prompt the user for input, optionally masking it."""
    prompt_str = f"  {label}"
    if default:
        prompt_str += f" [{default}]"
    prompt_str += ": "
    if secret:
        import getpass
        val = getpass.getpass(prompt_str)
    else:
        val = input(prompt_str)
    return val.strip() or default


def _append_gitignore(project_dir, line):
    """Append line to .gitignore if not already present."""
    gitignore = os.path.join(project_dir, '.gitignore')
    if os.path.exists(gitignore):
        with open(gitignore) as f:
            content = f.read()
        if line in content.splitlines():
            return  # already present
        with open(gitignore, 'a') as f:
            if not content.endswith('\n'):
                f.write('\n')
            f.write(line + '\n')
    else:
        with open(gitignore, 'w') as f:
            f.write(line + '\n')


# ── Commands ──────────────────────────────────────────────────────────────────

def _lookup_user_id(bot_token):
    """Try to resolve Slack User ID from email; fall back to manual entry."""
    if not bot_token:
        return _prompt("SLACK_USER_ID (U...)")

    email = input("  Your Slack email (to auto-detect User ID, or press Enter to type ID manually): ").strip()
    if not email:
        return _prompt("SLACK_USER_ID (U...)")

    try:
        from slack_sdk import WebClient
        client = WebClient(token=bot_token)
        resp = client.users_lookupByEmail(email=email)
        user = resp['user']
        uid  = user['id']
        name = user.get('real_name') or user.get('name', '')
        print(f"  Found: {name} ({uid})")
        confirm = input("  Use this account? [Y/n] ").strip().lower()
        if confirm in ('', 'y', 'yes'):
            return uid
    except Exception as e:
        print(f"  Could not look up email: {e}")

    return _prompt("SLACK_USER_ID (U...)")


def cmd_setup_slack(args):
    """Print the Slack app manifest and guide the user through setup."""
    manifest_path = os.path.join(_data_dir(), 'slack-manifest.yaml')
    with open(manifest_path) as f:
        manifest = f.read()

    BOLD  = '\033[1m'
    DIM   = '\033[2m'
    GREEN = '\033[32m'
    CYAN  = '\033[36m'
    RESET = '\033[0m'

    def step(n, text):
        print(f"\n{BOLD}{GREEN}Step {n}.{RESET} {text}")

    print(f"\n{BOLD}Claude Gate — Slack App Setup{RESET}")
    print(f"{DIM}This takes about 3 minutes.{RESET}")

    step(1, f"Open the Slack app creation page:\n\n"
            f"  {CYAN}https://api.slack.com/apps?new_app=1{RESET}\n\n"
            f"  Select {BOLD}\"From an app manifest\"{RESET}, then choose your workspace.")

    step(2, f"Paste the manifest below into the YAML tab and click {BOLD}Next → Create{RESET}.\n\n"
            f"  {DIM}Tip: feel free to change {BOLD}name{RESET}{DIM} and {BOLD}display_name{RESET}"
            f"{DIM} to your project name or any name you like.{RESET}\n")
    print("─" * 60)
    print(manifest.rstrip())
    print("─" * 60)

    step(3, f"Install the app:\n\n"
            f"  In the left sidebar click {BOLD}\"Install App\"{RESET} → "
            f"{BOLD}\"Install to Workspace\"{RESET} → Allow.\n\n"
            f"  Copy the {BOLD}Bot User OAuth Token{RESET} (starts with {CYAN}xoxb-{RESET}) "
            f"— you'll need it in a moment.")

    step(4, f"Create an App-Level Token (for Socket Mode):\n\n"
            f"  Settings → {BOLD}Basic Information{RESET} → scroll to "
            f"{BOLD}\"App-Level Tokens\"{RESET} → {BOLD}Generate Token and Scopes{RESET}.\n"
            f"  Name it anything (e.g. {CYAN}claude-gate-socket{RESET}), "
            f"add scope {BOLD}connections:write{RESET}, click Generate.\n\n"
            f"  Copy the token (starts with {CYAN}xapp-{RESET}).")

    step(5, f"Run {BOLD}cg init{RESET} — it will ask for your tokens and "
            f"auto-detect your Slack User ID from your email:\n\n"
            f"  {CYAN}cg init{RESET}\n\n"
            f"  Then start the daemon:\n\n"
            f"  {CYAN}cg up -d{RESET}")

    print(f"\n{DIM}Tip: run {BOLD}cg doctor{RESET}{DIM} any time to verify your tokens are working.{RESET}\n")


def cmd_init(args):
    """Scaffold .claude/ in the current directory."""
    project_dir = os.getcwd()
    dot_claude  = _dot_claude(project_dir)
    hooks_dir   = os.path.join(dot_claude, 'hooks')
    data_dir    = _data_dir()

    # 1. Project root heuristic
    if not _is_project_root(project_dir):
        print("Warning: this directory doesn't look like a project root (no .git, pyproject.toml, package.json, etc.).")
        ans = input("Continue anyway? [y/N] ").strip().lower()
        if ans not in ('y', 'yes'):
            print("Aborted.")
            sys.exit(1)

    # 2. Check .claude/ existence — only block if claude-gate files are already present
    if os.path.isdir(dot_claude) and _gate_files_present(dot_claude, data_dir) and not args.force and not args.adopt:
        print(f"Error: {dot_claude} already contains claude-gate files.")
        print("Use --force to overwrite, or --adopt if you already have a working setup.")
        sys.exit(1)

    # 3. Collect credentials first (before writing any files)
    env_file = os.path.join(dot_claude, '.env')
    if args.env_file:
        env_content = None  # will copy file directly later
    else:
        default_project = os.path.basename(project_dir)
        print("\nConfigure your Slack credentials (press Enter to skip optional fields).")
        print("Don't have tokens yet? Run 'cg setup-slack' first for a guided 3-minute setup.\n")
        project_name = _prompt("PROJECT_NAME", default_project)
        bot_token    = _prompt("SLACK_BOT_TOKEN (xoxb-...)", secret=True)
        app_token    = _prompt("SLACK_APP_TOKEN (xapp-...)", secret=True)
        user_id      = _lookup_user_id(bot_token)
        openai_key   = _prompt("OPENAI_API_KEY (optional, for voice messages)", secret=True)

        lines = [
            "# ─── Slack ───────────────────────────────────────────",
            f"SLACK_BOT_TOKEN={bot_token}",
            f"SLACK_APP_TOKEN={app_token}",
            f"SLACK_USER_ID={user_id}",
            "",
            "# ─── Project ─────────────────────────────────────────",
            f"PROJECT_NAME={project_name}",
            f"PROJECT_DIR={project_dir}",
        ]
        if openai_key:
            lines += [
                "",
                "# ─── OpenAI (voice messages) ─────────────────────────",
                f"OPENAI_API_KEY={openai_key}",
            ]
        env_content = '\n'.join(lines) + '\n'

    # 4. All input collected — now write files
    if not args.adopt:
        os.makedirs(dot_claude, exist_ok=True)
        _copy_hooks(data_dir, hooks_dir)

        for fname in ('settings.daemon.json',):
            src = os.path.join(data_dir, fname)
            dst = os.path.join(dot_claude, fname)
            if args.force or not os.path.exists(dst):
                shutil.copy2(src, dst)

        src_env_example = os.path.join(data_dir, 'env.example')
        dst_env_example = os.path.join(dot_claude, 'env.example')
        if args.force or not os.path.exists(dst_env_example):
            shutil.copy2(src_env_example, dst_env_example)

        print(f"Copied hook files to {hooks_dir}")

    # 5. Write .env
    if args.env_file:
        shutil.copy2(args.env_file, env_file)
        os.chmod(env_file, 0o600)
        print(f"Copied {args.env_file} to {env_file}")
    else:
        with open(env_file, 'w') as f:
            f.write(env_content)
        os.chmod(env_file, 0o600)
        print(f"\nWrote {env_file} (chmod 600)")

    # 7. Append to .gitignore
    _append_gitignore(project_dir, '.claude/.env')
    print("Added .claude/.env to .gitignore")

    # 8. Next steps
    print("\nDone! Next steps:")
    print("  cg doctor    # verify your tokens work")
    print("  cg up -d     # start the daemon in the background")


def cmd_up(args):
    """Start the daemon (foreground or detached)."""
    project_dir = os.getcwd()
    pid_path    = _pid_file(project_dir)
    log_path    = _daemon_log()

    # Check for stale PID file
    existing_pid = _read_pid(project_dir)
    if existing_pid is not None:
        if _pid_alive(existing_pid):
            print(f"Error: daemon already running (PID {existing_pid}).")
            print("Use 'cg down' to stop it first.")
            sys.exit(1)
        else:
            print(f"Removing stale PID file (PID {existing_pid} is dead).")
            os.remove(pid_path)

    if not args.detach:
        # Foreground: just call daemon.main() directly
        from claude_gate import daemon
        daemon.main()
    else:
        # Detached: double-fork
        pid = os.fork()
        if pid > 0:
            # Parent: wait briefly for child to write PID, then confirm
            time.sleep(0.3)
            child_pid = _read_pid(project_dir)
            if child_pid:
                print(f"Daemon started (PID {child_pid})")
                print(f"Logs: {log_path}")
            else:
                print(f"Daemon started (child PID {pid})")
            sys.exit(0)

        # Child: become session leader, redirect I/O
        os.setsid()

        # Second fork to prevent acquiring a tty
        pid2 = os.fork()
        if pid2 > 0:
            sys.exit(0)

        # Grandchild: the actual daemon process
        sys.stdin  = open(os.devnull, 'r')
        sys.stdout = open(log_path, 'a', buffering=1)
        sys.stderr = sys.stdout

        with open(pid_path, 'w') as f:
            f.write(str(os.getpid()))

        from claude_gate import daemon
        daemon.main()


def cmd_down(args):
    """Stop the detached daemon."""
    project_dir = os.getcwd()
    pid_path    = _pid_file(project_dir)
    pid         = _read_pid(project_dir)

    if pid is None:
        print("No daemon PID file found. Is the daemon running?")
        sys.exit(1)

    if not _pid_alive(pid):
        print(f"PID {pid} is not running. Removing stale PID file.")
        os.remove(pid_path)
        sys.exit(0)

    print(f"Sending SIGTERM to PID {pid}...")
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except ProcessLookupError:
        pass

    # Wait up to 10s for process to die
    for _ in range(20):
        time.sleep(0.5)
        if not _pid_alive(pid):
            break
    else:
        print(f"Process {pid} did not die after 10s. Sending SIGKILL...")
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        time.sleep(1)

    if os.path.exists(pid_path):
        os.remove(pid_path)
    print("Daemon stopped.")


def cmd_status(args):
    """Show daemon status."""
    project_dir = os.getcwd()
    pid         = _read_pid(project_dir)
    log_path    = _daemon_log()

    if pid is None:
        print("Daemon: not running (no PID file)")
    elif _pid_alive(pid):
        print(f"Daemon: running (PID {pid})")
        print(f"Log:    {log_path}")
    else:
        print(f"Daemon: not running (stale PID {pid})")

    # Show last 5 lines of daemon log
    if os.path.exists(log_path):
        print(f"\n-- Last 5 lines of {log_path} --")
        try:
            result = subprocess.run(
                ['tail', '-n', '5', log_path],
                capture_output=True, text=True
            )
            print(result.stdout.rstrip())
        except Exception as e:
            print(f"  (could not read log: {e})")
    else:
        print(f"\nNo log file at {log_path}")


def cmd_logs(args):
    """Tail activity and daemon logs."""
    activity_log = _activity_log()
    daemon_log   = _daemon_log()

    logs_to_tail = [f for f in [activity_log, daemon_log] if os.path.exists(f)]

    if not logs_to_tail:
        print("No log files found yet.")
        sys.exit(0)

    if args.follow:
        cmd = ['tail', '-f'] + logs_to_tail
        subprocess.run(cmd)
    else:
        for log in logs_to_tail:
            print(f"── {log} ──")
            subprocess.run(['tail', '-n', '30', log])
            print()


def cmd_doctor(args):
    """Verify tokens, dependencies, and hook drift."""
    project_dir = os.getcwd()
    dot_claude  = _dot_claude(project_dir)
    hooks_dir   = os.path.join(dot_claude, 'hooks')
    data_dir    = _data_dir()
    ok = True

    # Load env
    try:
        from claude_gate.env import load_env
        config = load_env(project_dir)
        print("  .env loaded")
    except FileNotFoundError as e:
        print(f"  ERROR: {e}")
        sys.exit(1)

    # Verify Slack bot token
    print("\nChecking Slack bot token...")
    try:
        from slack_sdk import WebClient
        client = WebClient(token=config['SLACK_BOT_TOKEN'])
        auth = client.auth_test()
        print(f"  OK — connected as @{auth['user']} on {auth['team']}")
    except Exception as e:
        print(f"  ERROR: {e}")
        ok = False

    # Verify OpenAI key (optional)
    openai_key = config.get('OPENAI_API_KEY')
    if openai_key:
        print("\nChecking OpenAI API key...")
        try:
            import openai
            oa = openai.OpenAI(api_key=openai_key)
            oa.models.list()
            print("  OK — OpenAI key works")
        except Exception as e:
            print(f"  ERROR: {e}")
            ok = False
    else:
        print("\nOpenAI API key not set (voice messages disabled)")

    # Check notify-send
    print("\nChecking notify-send...")
    if shutil.which('notify-send'):
        print("  OK — notify-send found")
    else:
        print("  WARNING: notify-send not found. Desktop notifications won't work.")
        print("           Install: sudo apt install libnotify-bin")

    # Check hook drift
    print("\nChecking hook files for drift...")
    if not os.path.isdir(hooks_dir):
        print(f"  WARNING: {hooks_dir} not found. Run 'cg init' first.")
    else:
        src_hooks = os.path.join(data_dir, 'hooks')
        drifted = []
        for fname in os.listdir(src_hooks):
            src = os.path.join(src_hooks, fname)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(hooks_dir, fname)
            if not os.path.exists(dst):
                print(f"  MISSING: {fname}")
                drifted.append(fname)
            elif open(src, 'rb').read() != open(dst, 'rb').read():
                print(f"  MODIFIED: {fname} (differs from package version)")
                drifted.append(fname)
            else:
                print(f"  OK: {fname}")
        if drifted:
            print(f"\n  Run 'cg upgrade-hooks' to update {len(drifted)} file(s).")

    # Check for legacy slack-daemon.py
    legacy = os.path.join(hooks_dir, 'slack-daemon.py')
    if os.path.exists(legacy):
        print(f"\n  NOTE: {legacy} is no longer used.")
        print("         The daemon now runs via 'cg up'. It is safe to delete this file.")

    print()
    if ok:
        print("All checks passed.")
    else:
        print("Some checks failed. See above.")
        sys.exit(1)


def cmd_remove(args):
    """Remove claude-gate files from the current project (leaves other .claude/ contents intact)."""
    project_dir = os.getcwd()
    dot_claude  = _dot_claude(project_dir)
    data_dir    = _data_dir()

    if not os.path.isdir(dot_claude):
        print(f"Nothing to remove: {dot_claude} does not exist.")
        sys.exit(0)

    # Stop daemon if running
    pid = _read_pid(project_dir)
    if pid is not None and _pid_alive(pid):
        if not args.yes:
            ans = input(f"Daemon is running (PID {pid}). Stop it? [y/N] ").strip().lower()
            if ans not in ('y', 'yes'):
                print("Aborted.")
                sys.exit(1)
        print(f"Stopping daemon (PID {pid})...")
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
        except ProcessLookupError:
            pass
        for _ in range(20):
            time.sleep(0.5)
            if not _pid_alive(pid):
                break

    # Build list of files/dirs installed by cg init
    hooks_dir = os.path.join(dot_claude, 'hooks')
    hook_files = [
        os.path.join(hooks_dir, fname)
        for fname in os.listdir(os.path.join(data_dir, 'hooks'))
    ]
    targets = hook_files + [
        os.path.join(dot_claude, 'settings.daemon.json'),
        os.path.join(dot_claude, 'env.example'),
        os.path.join(dot_claude, '.env'),
        os.path.join(dot_claude, 'daemon.pid'),
    ]
    existing = [t for t in targets if os.path.exists(t)]

    if not existing and not os.path.isdir(hooks_dir):
        print("No claude-gate files found in this project.")
        sys.exit(0)

    if not args.yes:
        print(f"\nThe following will be removed from {dot_claude}/:")
        for t in existing:
            print(f"  {os.path.relpath(t, dot_claude)}")
        if os.path.isdir(hooks_dir):
            print(f"  hooks/  (directory)")
        ans = input("\nContinue? [y/N] ").strip().lower()
        if ans not in ('y', 'yes'):
            print("Aborted.")
            sys.exit(1)

    # Remove hook files then hooks dir if empty
    for f in hook_files:
        if os.path.exists(f):
            os.remove(f)
            print(f"  Removed hooks/{os.path.basename(f)}")
    if os.path.isdir(hooks_dir) and not os.listdir(hooks_dir):
        os.rmdir(hooks_dir)
        print("  Removed hooks/")
    elif os.path.isdir(hooks_dir):
        print(f"  Kept hooks/ (contains other files)")

    # Remove top-level files
    for fname in ('settings.daemon.json', 'env.example', '.env', 'daemon.pid'):
        path = os.path.join(dot_claude, fname)
        if os.path.exists(path):
            os.remove(path)
            print(f"  Removed {fname}")

    # Remove .claude/.env from .gitignore
    gitignore = os.path.join(project_dir, '.gitignore')
    if os.path.exists(gitignore):
        with open(gitignore) as f:
            lines = f.readlines()
        new_lines = [l for l in lines if l.rstrip('\n') != '.claude/.env']
        if len(new_lines) != len(lines):
            with open(gitignore, 'w') as f:
                f.writelines(new_lines)
            print("  Removed .claude/.env from .gitignore")

    print("\nDone. claude-gate removed from this project.")


def cmd_upgrade_hooks(args):
    """Re-copy hook files from package data, with backup."""
    project_dir = os.getcwd()
    dot_claude  = _dot_claude(project_dir)
    hooks_dir   = os.path.join(dot_claude, 'hooks')
    data_dir    = _data_dir()
    src_hooks   = os.path.join(data_dir, 'hooks')
    bak_dir     = os.path.join(hooks_dir, '.bak')

    if not os.path.isdir(hooks_dir):
        print(f"Error: {hooks_dir} not found. Run 'cg init' first.")
        sys.exit(1)

    ts = time.strftime('%Y%m%d_%H%M%S')
    updated = 0

    for fname in os.listdir(src_hooks):
        src = os.path.join(src_hooks, fname)
        if not os.path.isfile(src):
            continue
        dst = os.path.join(hooks_dir, fname)

        src_content = open(src, 'rb').read()

        if not os.path.exists(dst):
            shutil.copy2(src, dst)
            if fname.endswith('.py'):
                os.chmod(dst, 0o755)
            print(f"  Installed new: {fname}")
            updated += 1
            continue

        dst_content = open(dst, 'rb').read()
        if src_content == dst_content:
            print(f"  Up to date:    {fname}")
            continue

        # Files differ — ask (unless --force)
        if not args.force:
            ans = input(f"  {fname} differs from package version. Update? [y/N] ").strip().lower()
            if ans not in ('y', 'yes'):
                print(f"  Skipped:       {fname}")
                continue

        # Back up existing file
        os.makedirs(bak_dir, exist_ok=True)
        bak = os.path.join(bak_dir, f"{fname}.{ts}")
        shutil.copy2(dst, bak)
        print(f"  Backed up to:  {bak}")

        shutil.copy2(src, dst)
        if fname.endswith('.py'):
            os.chmod(dst, 0o755)
        print(f"  Updated:       {fname}")
        updated += 1

    # Warn about legacy slack-daemon.py
    legacy = os.path.join(hooks_dir, 'slack-daemon.py')
    if os.path.exists(legacy):
        print(f"\n  NOTE: {legacy} is no longer used by 'cg up'.")
        print("         It is safe to delete it.")

    print(f"\n{updated} file(s) updated.")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog='cg',
        description='claude-gate: Gate Claude Code tool use behind Slack approvals.',
    )
    sub = parser.add_subparsers(dest='command', metavar='<command>')

    # setup-slack
    sub.add_parser('setup-slack', help='Print Slack app manifest and setup guide (start here)')

    # init
    p_init = sub.add_parser('init', help='Scaffold .claude/ in the current directory')
    p_init.add_argument('--adopt', action='store_true',
                        help='For existing .claude/ setups: skip file copy, just write .env')
    p_init.add_argument('--force', action='store_true',
                        help='Overwrite existing files')
    p_init.add_argument('--env-file', metavar='PATH',
                        help='Use this file as .claude/.env instead of prompting')

    # up
    p_up = sub.add_parser('up', help='Start the Slack daemon')
    p_up.add_argument('-d', '--detach', action='store_true',
                      help='Run detached in background, write PID to .claude/daemon.pid')

    # down
    sub.add_parser('down', help='Stop the detached daemon')

    # status
    sub.add_parser('status', help='Show daemon status and recent log lines')

    # logs
    p_logs = sub.add_parser('logs', help='Tail activity and daemon logs')
    p_logs.add_argument('-f', '--follow', action='store_true',
                        help='Follow logs (like tail -f)')

    # doctor
    sub.add_parser('doctor', help='Verify tokens, deps, and hook file integrity')

    # upgrade-hooks
    p_upgrade = sub.add_parser('upgrade-hooks', help='Re-copy hook files from package data')
    p_upgrade.add_argument('--force', action='store_true',
                           help='Update all files without prompting')

    # remove
    p_remove = sub.add_parser('remove', help='Remove claude-gate from the current project')
    p_remove.add_argument('-y', '--yes', action='store_true',
                          help='Skip confirmation prompts')

    args = parser.parse_args()

    dispatch = {
        'setup-slack':   cmd_setup_slack,
        'init':          cmd_init,
        'up':            cmd_up,
        'down':          cmd_down,
        'status':        cmd_status,
        'logs':          cmd_logs,
        'doctor':        cmd_doctor,
        'upgrade-hooks': cmd_upgrade_hooks,
        'remove':        cmd_remove,
    }

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    try:
        dispatch[args.command](args)
    except KeyboardInterrupt:
        print('\nAborted.')
        sys.exit(0)


if __name__ == '__main__':
    main()
