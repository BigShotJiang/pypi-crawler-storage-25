#!/usr/bin/env python3
# claude-gate v0.1.0
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from env_loader import load_env

from slack_sdk import WebClient

def main():
    config    = load_env()
    bot_token = config['SLACK_BOT_TOKEN']
    user_id   = config['SLACK_USER_ID']
    project   = config.get('PROJECT_NAME', 'your project')

    client  = WebClient(token=bot_token)
    result  = client.conversations_open(users=user_id)
    channel = result['channel']['id']

    client.chat_postMessage(
        channel=channel,
        text=f'✅ Claude has finished the task in *{project}*!',
        blocks=[
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": (
                        f"✅ *Claude has finished the task!*\n"
                        f"Project: *{project}*\n"
                        f"Head back to your laptop to review the results."
                    )
                }
            }
        ]
    )

if __name__ == '__main__':
    main()
