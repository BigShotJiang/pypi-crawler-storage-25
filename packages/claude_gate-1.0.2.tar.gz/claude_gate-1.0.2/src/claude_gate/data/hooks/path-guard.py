#!/usr/bin/env python3
# claude-gate v0.1.0
"""
PreToolUse hook: blocks any tool that accesses paths outside the project's
working directory. Covers Write/Edit/Read/MultiEdit/Glob/Grep (file_path or
path param) and Bash (absolute path tokens + ../ traversals in the command).
"""
import json
import os
import re
import sys


def real(path):
    try:
        return os.path.realpath(path)
    except Exception:
        return path


def within_cwd(path, cwd_real):
    r = real(path)
    return r == cwd_real or r.startswith(cwd_real + os.sep)


def check_file_path(path, cwd, cwd_real):
    if not path:
        return None
    abs_path = path if os.path.isabs(path) else os.path.join(cwd, path)
    return path if not within_cwd(abs_path, cwd_real) else None


def bash_violations(command, cwd, cwd_real):
    violations = []

    # Absolute path tokens
    for match in re.finditer(r'(?<![:\w])/([^\s\'";\|&<>\\]+)', command):
        p = '/' + match.group(1)
        if not within_cwd(p, cwd_real):
            violations.append(p)

    # Relative traversal paths that escape cwd (e.g. ../../etc/passwd)
    for match in re.finditer(r'(?:^|[\s=\'"(])(\.\./[^\s\'";\|&<>]*)', command):
        p = match.group(1)
        if not within_cwd(real(os.path.join(cwd, p)), cwd_real):
            violations.append(p)

    return violations


def main():
    raw = sys.stdin.read()
    try:
        hook_input = json.loads(raw) if raw.strip() else {}
    except Exception:
        sys.exit(0)

    tool_name  = hook_input.get('tool_name', '')
    tool_input = hook_input.get('tool_input', {})
    cwd        = hook_input.get('cwd') or os.getcwd()
    cwd_real   = real(cwd)
    violations = []

    if tool_name in ('Write', 'Edit', 'Read', 'MultiEdit', 'Glob', 'Grep'):
        path = tool_input.get('file_path') or tool_input.get('path', '')
        v = check_file_path(path, cwd, cwd_real)
        if v:
            violations.append(v)

    elif tool_name == 'Bash':
        violations = bash_violations(tool_input.get('command', ''), cwd, cwd_real)

    if not violations:
        sys.exit(0)

    reason = (
        f"Access denied: path(s) outside working directory "
        f"({cwd}): {', '.join(set(violations))}"
    )
    print(json.dumps({"decision": "block", "reason": reason}))
    try:
        with open('/dev/tty', 'w') as tty:
            tty.write(f"\n\033[1;91m[path-guard] {reason}\033[0m\n")
    except Exception:
        pass
    sys.exit(1)


if __name__ == '__main__':
    main()
