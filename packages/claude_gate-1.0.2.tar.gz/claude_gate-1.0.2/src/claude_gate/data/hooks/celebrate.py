#!/usr/bin/env python3
# claude-gate v0.1.0
import random
import time
import os
import sys
import fcntl
import termios
import struct

def get_terminal_size(tty):
    try:
        result = fcntl.ioctl(tty.fileno(), termios.TIOCGWINSZ, b'\x00' * 8)
        rows, cols = struct.unpack('HHHH', result)[:2]
        return cols or 80, rows or 24
    except Exception:
        return 80, 24

def main():
    tty = open('/dev/tty', 'w')
    cols, rows = get_terminal_size(tty)

    confetti_chars = ['*', '+', 'o', '•', '✦', '✧', '❋', '❊']
    colors = [
        '\033[91m', '\033[92m', '\033[93m', '\033[94m', '\033[95m', '\033[96m',
        '\033[1;91m', '\033[1;92m', '\033[1;93m', '\033[1;95m', '\033[1;96m',
    ]
    reset  = '\033[0m'
    bold_yellow = '\033[1;93m'

    height = rows - 4  # leave room for message at bottom

    num_particles = 50
    particles = []
    for _ in range(num_particles):
        particles.append({
            'x':     random.uniform(0, cols - 1),
            'y':     random.uniform(0, height - 1),
            'dy':    random.uniform(0, 0.5),
            'dx':    random.uniform(-0.3, 0.3),
            'char':  random.choice(confetti_chars),
            'color': random.choice(colors),
            'speed': random.uniform(0.4, 1.2),
        })

    try:
        # Switch to alternate screen (clean slate, no Claude UI visible)
        tty.write('\033[?1049h')
        # Hide cursor
        tty.write('\033[?25l')
        # Clear the alternate screen
        tty.write('\033[2J')
        tty.flush()

        for frame in range(35):
            canvas = [[' '] * cols for _ in range(height)]

            for p in particles:
                p['dy'] += 0.15 * p['speed']
                p['y']  += p['dy'] * 0.12
                p['x']  += p['dx']

                if p['y'] >= height:
                    p['y']    = 0
                    p['dy']   = random.uniform(0, 0.3)
                    p['x']    = random.uniform(0, cols - 1)
                    p['char'] = random.choice(confetti_chars)
                    p['color']= random.choice(colors)

                p['x'] = p['x'] % cols

                ix, iy = int(p['x']), int(p['y'])
                if 0 <= ix < cols - 1 and 0 <= iy < height:
                    canvas[iy][ix] = p['color'] + p['char'] + reset

            # Move cursor to top-left each frame
            output = '\033[H'
            for row in canvas:
                output += ''.join(row) + '\n'

            # Celebration message centered at the bottom
            msg = '  🎉  Task Complete!  🎉  '
            pad = max(0, (cols - len(msg)) // 2)
            output += '\n' + bold_yellow + ' ' * pad + msg + reset + '\n'

            tty.write(output)
            tty.flush()
            time.sleep(0.07)

        # Pause briefly so user can enjoy it
        time.sleep(0.4)

    finally:
        # Restore cursor and switch back to normal screen (Claude UI returns)
        tty.write('\033[?25h')
        tty.write('\033[?1049l')
        tty.flush()
        tty.close()

if __name__ == '__main__':
    main()
