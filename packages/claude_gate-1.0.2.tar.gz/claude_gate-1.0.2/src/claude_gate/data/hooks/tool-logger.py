#!/usr/bin/env python3
# claude-gate v0.1.0
"""
tool-logger.py — PreToolUse hook that posts live tool activity to Slack
when a daemon task is running, and always logs to /tmp/claude-activity.log.
Always exits 0 — never blocks tool use.
"""

import json
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from env_loader import load_env

SESSION_FLAG        = '/tmp/claude-hook-allow-all'
SESSION_EXPIRY_SECS = 15 * 60
ACTIVITY_LOG        = '/tmp/claude-activity.log'

ICONS = {
    'Bash':       '💻',
    'Write':      '📝',
    'Edit':       '✏️',
    'Read':       '📖',
    'Glob':       '🔎',
    'Grep':       '🔍',
    'WebSearch':  '🌐',
    'WebFetch':   '🌐',
    'TodoWrite':  '📋',
    'TodoRead':   '📋',
}


def format_message(tool_name, tool_input):
    icon = ICONS.get(tool_name, '🔧')

    if tool_name == 'Bash':
        cmd = tool_input.get('command', '').strip()
        first_line = cmd.split('\n')[0][:120]
        return f"{icon} *Bash:* `{first_line}`"

    elif tool_name == 'Edit':
        path = tool_input.get('file_path', '')
        return f"{icon} *Edit:* `{path}`"

    elif tool_name == 'Write':
        path = tool_input.get('file_path', '')
        return f"{icon} *Write:* `{path}`"

    elif tool_name == 'Read':
        path = tool_input.get('file_path', '')
        return f"{icon} *Read:* `{path}`"

    elif tool_name in ('Glob',):
        pattern = tool_input.get('pattern', '')
        return f"{icon} *Glob:* `{pattern}`"

    elif tool_name == 'Grep':
        pattern = tool_input.get('pattern', '')[:80]
        return f"{icon} *Grep:* `{pattern}`"

    elif tool_name == 'WebSearch':
        query = tool_input.get('query', '')[:100]
        return f"{icon} *WebSearch:* `{query}`"

    elif tool_name == 'WebFetch':
        url = tool_input.get('url', '')[:100]
        return f"{icon} *WebFetch:* `{url}`"

    else:
        return f"{icon} *{tool_name}*"


def session_active():
    if not os.path.exists(SESSION_FLAG):
        return False
    return (time.time() - os.path.getmtime(SESSION_FLAG)) < SESSION_EXPIRY_SECS


def main():
    try:
        raw        = sys.stdin.read()
        hook_input = json.loads(raw) if raw.strip() else {}
        tool_name  = hook_input.get('tool_name', 'unknown')
        tool_input = hook_input.get('tool_input', {})
    except Exception:
        sys.exit(0)

    ts  = time.strftime('%H:%M:%S')
    msg = format_message(tool_name, tool_input)

    # Always write to activity log
    try:
        with open(ACTIVITY_LOG, 'a') as f:
            f.write(f"[{ts}] {msg}\n")
    except Exception:
        pass

    # Post to Slack only when a daemon task is running
    if not session_active():
        sys.exit(0)

    try:
        from slack_sdk import WebClient
        config  = load_env()
        client  = WebClient(token=config['SLACK_BOT_TOKEN'])
        result  = client.conversations_open(users=config['SLACK_USER_ID'])
        channel = result['channel']['id']
        client.chat_postMessage(
            channel=channel,
            text=msg,
            blocks=[{
                "type": "section",
                "text": {"type": "mrkdwn", "text": f"`{ts}` {msg}"}
            }]
        )
    except Exception:
        pass

    sys.exit(0)


if __name__ == '__main__':
    main()
