# claude-gate v0.1.0
"""
Shared utility — loads .env from the .claude/ folder of whichever
project this plugin lives in.

Usage in any hook script:
    from env_loader import load_env
    config = load_env()
    token  = config['SLACK_BOT_TOKEN']
"""
import os

def load_env() -> dict:
    # __file__ is .claude/hooks/env_loader.py
    # so .env is one level up: .claude/.env
    script_dir = os.path.dirname(os.path.abspath(__file__))
    env_path   = os.path.join(script_dir, '..', '.env')
    env_path   = os.path.normpath(env_path)

    if not os.path.exists(env_path):
        raise FileNotFoundError(
            f"No .env found at {env_path}\n"
            "Copy .env.example to .env and fill in your values."
        )

    config = {}
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, val = line.split('=', 1)
                config[key.strip()] = val.strip()
    return config
