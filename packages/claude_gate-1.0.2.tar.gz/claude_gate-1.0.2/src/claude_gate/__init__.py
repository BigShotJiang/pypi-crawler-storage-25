"""claude-gate — Gate Claude Code tool use behind approvals."""

__version__ = "0.1.0"
