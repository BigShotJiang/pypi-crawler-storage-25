"""
Package-level env loader.

Loads .claude/.env from a project directory (defaults to cwd).
Used by daemon.py inside the package.
"""
import os


def load_env(project_dir=None):
    if project_dir is None:
        project_dir = os.getcwd()
    env_path = os.path.normpath(os.path.join(project_dir, '.claude', '.env'))
    if not os.path.exists(env_path):
        raise FileNotFoundError(
            f"No .env found at {env_path}\n"
            "Run 'cg init' to set up the project."
        )
    config = {}
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, val = line.split('=', 1)
                config[key.strip()] = val.strip()
    return config
