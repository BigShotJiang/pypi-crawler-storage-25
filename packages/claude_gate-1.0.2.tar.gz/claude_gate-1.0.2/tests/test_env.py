"""Tests for claude_gate.env.load_env()."""
import os
import pytest

from claude_gate.env import load_env


class TestLoadEnvFileNotFound:
    def test_raises_when_no_env_file(self, tmp_path):
        """load_env raises FileNotFoundError when .claude/.env is missing."""
        # tmp_path has no .claude/ at all
        with pytest.raises(FileNotFoundError) as exc_info:
            load_env(str(tmp_path))
        assert '.env' in str(exc_info.value)
        assert 'cg init' in str(exc_info.value)

    def test_raises_when_dot_claude_exists_but_no_env(self, tmp_path):
        """load_env raises if .claude/ exists but .env is absent."""
        (tmp_path / '.claude').mkdir()
        with pytest.raises(FileNotFoundError):
            load_env(str(tmp_path))


class TestLoadEnvParsing:
    def test_basic_key_value(self, tmp_project, env_file):
        """load_env correctly parses key=value pairs."""
        config = load_env(str(tmp_project))
        assert config['SLACK_BOT_TOKEN'] == 'xoxb-test'
        assert config['SLACK_APP_TOKEN'] == 'xapp-test'
        assert config['SLACK_USER_ID'] == 'U123'
        assert config['PROJECT_NAME'] == 'test-project'
        assert config['PROJECT_DIR'] == '/tmp/test-project'

    def test_strips_whitespace_from_keys_and_values(self, tmp_project, env_file):
        """load_env strips surrounding whitespace from keys and values."""
        config = load_env(str(tmp_project))
        # '  OPENAI_API_KEY = sk-test  ' should parse cleanly
        assert config['OPENAI_API_KEY'] == 'sk-test'

    def test_ignores_comments(self, tmp_project, env_file):
        """load_env ignores lines starting with #."""
        config = load_env(str(tmp_project))
        # The comment line '# this is a comment' must not appear as a key
        for key in config:
            assert not key.startswith('#')

    def test_ignores_blank_lines(self, tmp_project, env_file):
        """load_env ignores empty lines."""
        config = load_env(str(tmp_project))
        assert '' not in config

    def test_value_with_equals_sign(self, tmp_project):
        """load_env uses split('=', 1) so values may contain '='."""
        env_path = tmp_project / '.claude' / '.env'
        env_path.write_text("MY_URL=https://example.com/path?foo=bar\n")
        config = load_env(str(tmp_project))
        assert config['MY_URL'] == 'https://example.com/path?foo=bar'

    def test_returns_dict(self, tmp_project, env_file):
        """load_env returns a plain dict."""
        config = load_env(str(tmp_project))
        assert isinstance(config, dict)

    def test_defaults_to_cwd(self, tmp_project, env_file, monkeypatch):
        """load_env defaults project_dir to os.getcwd() when called with no args."""
        monkeypatch.chdir(str(tmp_project))
        config = load_env()
        assert config['SLACK_BOT_TOKEN'] == 'xoxb-test'
