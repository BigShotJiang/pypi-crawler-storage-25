"""Browser-open hint for missing-license errors.

When :func:`solve` raises a "No license key found" ``RuntimeError``, we offer
to open the license portal. Silent in non-interactive contexts (CI, headless
servers, non-TTY scripts). Controllable via env vars:

- ``MOREAU_NO_BROWSER=1``  -> never open a browser
- ``MOREAU_OPEN_BROWSER=1`` -> always attempt to open a browser
"""
import os
import sys
import webbrowser

LICENSE_URL = "https://license.moreau.so"

_NOT_FOUND_MARKER = "No license key found"


def _should_open_browser() -> bool:
    if os.environ.get("MOREAU_NO_BROWSER"):
        return False
    if os.environ.get("MOREAU_OPEN_BROWSER"):
        return True
    if "ipykernel" in sys.modules or "IPython" in sys.modules:
        return True
    try:
        return bool(sys.stdout.isatty())
    except Exception:
        return False


def maybe_open_license_url(exc: BaseException) -> None:
    """If ``exc`` is a missing-license error, try to open the license portal."""
    if _NOT_FOUND_MARKER not in str(exc):
        return
    if not _should_open_browser():
        return
    try:
        webbrowser.open_new_tab(LICENSE_URL)
    except Exception:
        pass
