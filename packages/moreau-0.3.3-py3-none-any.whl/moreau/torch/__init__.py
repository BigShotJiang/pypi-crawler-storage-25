"""
Moreau PyTorch integration with unified CPU/CUDA support.

Provides differentiable convex optimization for PyTorch neural networks
with automatic device selection between CPU and CUDA backends.

Example:
    >>> import torch
    >>> from moreau.torch import Solver
    >>> import moreau
    >>>
    >>> # Setup problem structure
    >>> cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)
    >>>
    >>> # Create solver (auto-selects CUDA if available)
    >>> solver = Solver(n=2, m=3, P_row_offsets=..., P_col_indices=...,
    ...                 A_row_offsets=..., A_col_indices=..., cones=cones)
    >>>
    >>> # Solve with autograd support (stateless — all data passed per call)
    >>> solution = solver.solve(P_values, A_values, q, b)
    >>> print(solution.x, solver.info.status)
    >>>
    >>> # Backpropagate through the solution
    >>> loss = solution.x.sum()
    >>> loss.backward()
"""

import warnings

import torch
from typing import Tuple, Optional, Any

                                                 
from moreau._backend import (
    torch_available,
    default_device,
    get_device_component,
)

from moreau._types import (
    Cones, Settings, IPMSettings, SolverStatus, TuneResult,
    TorchSolveInfo, TorchSolution, TorchBatchedSolveInfo, TorchBatchedSolution,
    WarmStart, BatchedWarmStart,
    normalize_status as _normalize_status,
)
from moreau._backend import solver_methods_for_device as _solver_methods_for_device
from moreau._backend import auto_tune_candidates as _auto_tune_candidates

                                                                          
                                                                    
                                                                          
from moreau._backend import _device_registry as _dr
if 'cpu' in _dr and _dr['cpu'].get('torch_solver') is None:
    from ._cpu_impl import _TorchSolverCpu
    _dr['cpu']['torch_solver'] = _TorchSolverCpu
del _dr


def _validate_tensor_dtype(t: torch.Tensor, name: str) -> None:
    """Validate that a tensor is float64."""
    if t.dtype != torch.float64:
        raise RuntimeError(f"{name} must be float64, got {t.dtype}")


                                                                             
                                   
 
                                                                      
                                                                 
                                                                    
 
                                                                     
                                                            
                                                                 
                                                             
                                                                             

                                                                           
                                                              
import weakref
_IMPL_REGISTRY: dict[int, weakref.ref] = {}
_next_handle: int = 0


def _register_impl(impl) -> int:
    global _next_handle
    h = _next_handle
    _next_handle += 1
    _IMPL_REGISTRY[h] = weakref.ref(impl, lambda _: _IMPL_REGISTRY.pop(h, None))
    return h


def _get_impl(handle: int):
    ref = _IMPL_REGISTRY.get(handle)
    if ref is None:
        raise RuntimeError("Solver impl not found in registry")
    impl = ref()
    if impl is None:
        raise RuntimeError("Solver has been garbage collected")
    return impl


@torch.library.custom_op("moreau::solve_backward", mutates_args=())
def _solve_backward_op(
    dx: torch.Tensor,
    dz: torch.Tensor,
    ds: torch.Tensor,
    impl_handle: torch.Tensor,
    solve_mode: torch.Tensor,
    state_rinv: torch.Tensor,
    state_rinv_diag: torch.Tensor,
    state_use_rinv_diag: torch.Tensor,
    state_n_active: torch.Tensor,
    state_ws: torch.Tensor,
    state_sense: torch.Tensor,
    state_lam_star: torch.Tensor,
    P_values: torch.Tensor,
    A_values: torch.Tensor,
    q: torch.Tensor,
    b: torch.Tensor,
    x: torch.Tensor,
    z: torch.Tensor,
    s: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Backward pass: compute gradients via implicit differentiation."""
    impl = _get_impl(impl_handle.item())
    mode_str = 'single' if solve_mode.item() == 0 else 'batch'
    dP, dq, dA, db = impl.backward_with_mode(
        dx, dz, ds, mode_str, P_values, A_values, q, b, x, z, s,
        state_rinv, state_rinv_diag, state_use_rinv_diag,
        state_n_active, state_ws, state_sense, state_lam_star,
    )
    return dP, dq, dA, db


@_solve_backward_op.register_fake
def _solve_backward_op_fake(dx, dz, ds, impl_handle, solve_mode,
                            state_rinv, state_rinv_diag, state_use_rinv_diag,
                            state_n_active, state_ws, state_sense, state_lam_star,
                            P_values, A_values, q, b, x, z, s):
    return (
        torch.empty_like(P_values),
        torch.empty_like(q),
        torch.empty_like(A_values),
        torch.empty_like(b),
    )


@_solve_backward_op.register_vmap
def _solve_backward_op_vmap(info, in_dims, dx, dz, ds, impl_handle, solve_mode,
                            state_rinv, state_rinv_diag, state_use_rinv_diag,
                            state_n_active, state_ws, state_sense, state_lam_star,
                            P_values, A_values, q, b, x, z, s):
    (dx_bd, dz_bd, ds_bd, h_bd, m_bd, state_rinv_bd, state_rinv_diag_bd,
     state_use_rinv_diag_bd, state_n_active_bd, state_ws_bd, state_sense_bd,
     state_lam_star_bd, P_bd, A_bd, q_bd, b_bd, x_bd, z_bd, s_bd) = in_dims
    N = info.batch_size

                                                                         
    def _expand(t, bd):
        if bd is not None:
            return t.movedim(bd, 0)
        return t.unsqueeze(0).expand(N, *t.shape).contiguous()

    dx = _expand(dx, dx_bd)
    dz = _expand(dz, dz_bd)
    ds = _expand(ds, ds_bd)
    state_rinv = _expand(state_rinv, state_rinv_bd)
    state_rinv_diag = _expand(state_rinv_diag, state_rinv_diag_bd)
    state_use_rinv_diag = _expand(state_use_rinv_diag, state_use_rinv_diag_bd)
    state_n_active = _expand(state_n_active, state_n_active_bd)
    state_ws = _expand(state_ws, state_ws_bd)
    state_sense = _expand(state_sense, state_sense_bd)
    state_lam_star = _expand(state_lam_star, state_lam_star_bd)
    P_values = _expand(P_values, P_bd)
    A_values = _expand(A_values, A_bd)
    q = _expand(q, q_bd)
    b = _expand(b, b_bd)
    x = _expand(x, x_bd)
    z = _expand(z, z_bd)
    s = _expand(s, s_bd)

                                                                         
                                                                          
    batch_mode = torch.tensor(1, dtype=torch.int64)
    dP, dq_out, dA, db_out = _solve_backward_op._backend_fns[None](
        dx, dz, ds, impl_handle, batch_mode,
        state_rinv, state_rinv_diag, state_use_rinv_diag,
        state_n_active, state_ws, state_sense, state_lam_star,
        P_values, A_values, q, b, x, z, s,
    )

                                      
    return (dP, dq_out, dA, db_out), (0, 0, 0, 0)


                                                                             
                                      
 
                                                                   
                                                                   
                                                                 
                   
 
                                                                        
                                                                 
                                                                             

class _SolveFunction(torch.autograd.Function):
    @staticmethod
    def forward(solver, q, b, P_values, A_values):
        warm_kwargs = getattr(solver, '_pending_warm_kwargs', {})
        with torch.no_grad():
            result = solver._impl.solve(q, b, **warm_kwargs)
        solver._last_result = result
        return result['x'], result['z'], result['s']

    @staticmethod
    def setup_context(ctx, inputs, output):
        solver, q, b, P_values, A_values = inputs
        x, z, s = output
        mode = 0 if solver._impl._last_solve_mode == 'single' else 1
        cached = getattr(solver, '_last_result', {}) or {}
        backward_state = cached.get('_backward_state')
        device = q.device
        if backward_state is None:
            state_rinv = torch.empty(0, dtype=torch.float64, device=device)
            state_rinv_diag = torch.empty(0, dtype=torch.float64, device=device)
            state_use_rinv_diag = torch.empty(0, dtype=torch.int64, device=device)
            state_n_active = torch.empty(0, dtype=torch.int64, device=device)
            state_ws = torch.empty(0, dtype=torch.int64, device=device)
            state_sense = torch.empty(0, dtype=torch.int64, device=device)
            state_lam_star = torch.empty(0, dtype=torch.float64, device=device)
        else:
            flat_state = backward_state._to_flat_dict()
            state_rinv = torch.as_tensor(flat_state['rinv'], dtype=torch.float64, device=device)
            state_rinv_diag = torch.as_tensor(flat_state['rinv_diag'], dtype=torch.float64, device=device)
            state_use_rinv_diag = torch.as_tensor(flat_state['use_rinv_diag'], dtype=torch.int64, device=device)
            state_n_active = torch.as_tensor(flat_state['n_active'], dtype=torch.int64, device=device)
            state_ws = torch.as_tensor(flat_state['ws'], dtype=torch.int64, device=device)
            state_sense = torch.as_tensor(flat_state['sense'], dtype=torch.int64, device=device)
            state_lam_star = torch.as_tensor(flat_state['lam_star'], dtype=torch.float64, device=device)
        ctx.solver = solver
        ctx.save_for_backward(torch.tensor(solver._impl_handle, dtype=torch.int64),
                              torch.tensor(mode, dtype=torch.int64),
                              state_rinv, state_rinv_diag, state_use_rinv_diag,
                              state_n_active, state_ws, state_sense, state_lam_star,
                              P_values, A_values, q, b, x, z, s)

    @staticmethod
    def backward(ctx, dx, dz, ds):
        (impl_handle, solve_mode, state_rinv, state_rinv_diag, state_use_rinv_diag,
         state_n_active, state_ws, state_sense, state_lam_star,
         P_values, A_values, q, b, x, z, s) = ctx.saved_tensors

        if dx is None:
            dx = torch.zeros_like(x)
        if dz is None:
            dz = torch.zeros_like(z)
        if ds is None:
            ds = torch.zeros_like(s)

        dP, dq, dA, db = _solve_backward_op(
            dx, dz, ds, impl_handle, solve_mode,
            state_rinv, state_rinv_diag, state_use_rinv_diag,
            state_n_active, state_ws, state_sense, state_lam_star,
            P_values, A_values, q, b, x, z, s,
        )

                                                                                    
        if hasattr(ctx.solver, '_last_result'):
            ctx.solver._last_result = None

                                                                             
        return None, dq, db, dP, dA


class Solver:
    """Unified PyTorch solver with automatic device selection and autograd support.

    Thread Safety:
        Solver instances are NOT thread-safe. Each thread should use its own
        Solver instance, or external synchronization must be used. Calling
        solve() concurrently from multiple threads on the same Solver instance
        will cause data races and undefined behavior.

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P matrix (torch.Tensor, CPU).
            P must be full symmetric (both upper and lower triangles).
        P_col_indices: CSR column indices for P matrix (torch.Tensor, CPU)
        A_row_offsets: CSR row pointers for A matrix (torch.Tensor, CPU)
        A_col_indices: CSR column indices for A matrix (torch.Tensor, CPU)
        cones: Cone specification (moreau.Cones object)
        settings: Optional solver settings (moreau.Settings object).
                  Contains device, batch_size, enable_grad and solver tolerances.
                  Note: enable_grad defaults to True for torch.Solver if not specified.

    Example:
        >>> import torch
        >>> from moreau.torch import Solver
        >>> import moreau
        >>>
        >>> cones = moreau.Cones(num_nonneg_cones=2)
        >>> settings = moreau.Settings(device='cuda', batch_size=64)
        >>>
        >>> solver = Solver(
        ...     n=2, m=2,
        ...     P_row_offsets=torch.tensor([0, 1, 2]),
        ...     P_col_indices=torch.tensor([0, 1]),
        ...     A_row_offsets=torch.tensor([0, 1, 2]),
        ...     A_col_indices=torch.tensor([0, 1]),
        ...     cones=cones,
        ...     settings=settings,
        ... )
        >>>
        >>> solution = solver.solve(P_values, A_values, q, b)
        >>> print(solver.info.status, solver.info.obj_val)
    """

    def __init__(
        self,
        n: int,
        m: int,
        P_row_offsets: torch.Tensor,
        P_col_indices: torch.Tensor,
        A_row_offsets: torch.Tensor,
        A_col_indices: torch.Tensor,
        cones: Any,
        settings: Optional[Any] = None,
    ):
                                            
        from moreau import _warn_cvxpy_soc_if_needed
        _warn_cvxpy_soc_if_needed(cones)

                                                                               
                                                                               
        if settings is None:
            settings = Settings(enable_grad=True)
        elif not settings.enable_grad:
                                                                     
                                                             
            settings = settings.model_copy(update={'enable_grad': True})

                                                               
        device = settings.device
        batch_size = settings.batch_size
        enable_grad = settings.enable_grad

                                                                 
                                                                    
        if device == 'auto':
            device = 'cpu'
            for dev in [default_device()]:
                if dev != 'cpu' and torch_available(dev):
                    device = dev
                    break

                                                                
        from moreau._types import SolverType
        from moreau import _resolve_solver_type
        nnz_P = len(P_col_indices)
        settings, device = _resolve_solver_type(settings, n, m, cones, device, nnz_P=nnz_P)

        self._device = device
        self._n = n
        self._m = m
        self._settings = settings
        self._cones = cones
        self._batch_size = batch_size

                                                                     
                                                                              
        target = torch.device('cpu' if device == 'cpu' else device)
        P_row_offsets = P_row_offsets.to(target) if isinstance(P_row_offsets, torch.Tensor) else P_row_offsets
        P_col_indices = P_col_indices.to(target) if isinstance(P_col_indices, torch.Tensor) else P_col_indices
        A_row_offsets = A_row_offsets.to(target) if isinstance(A_row_offsets, torch.Tensor) else A_row_offsets
        A_col_indices = A_col_indices.to(target) if isinstance(A_col_indices, torch.Tensor) else A_col_indices

        self._P_row_offsets = P_row_offsets
        self._P_col_indices = P_col_indices
        self._A_row_offsets = A_row_offsets
        self._A_col_indices = A_col_indices

                                              
        TorchSolverClass = get_device_component(device, 'torch_solver')

        if TorchSolverClass is None:
            raise ImportError(
                f"PyTorch extension for device '{device}' not available. "
                f"Use device='cpu' or install the appropriate backend."
            )
        self._TorchSolverClass = TorchSolverClass

                                 
        import time
        construction_start = time.perf_counter()

                                                                                 
                                                                 
                                                                        
                                                                            
        self._impl = TorchSolverClass(
            n, m,
            P_row_offsets, P_col_indices,
            A_row_offsets, A_col_indices,
            cones, settings,
            batch_size=batch_size,
            enable_grad=enable_grad,
        )

                                                                               
        if enable_grad:
            self._impl.setup_grad(batch_size)

        self._construction_time = time.perf_counter() - construction_start
        self._setup_time = 0.0

                                                                  
                                                                             
                                                                          
                                                                                  
                                                         
        self._original_device = settings.device
        ipm = settings.ipm_settings
        self._original_method = ipm.direct_solve_method if ipm else 'auto'
        if self._original_method == 'auto' and settings.device != 'auto':
            from moreau._backend import _rank_method
            ranked = _rank_method(self._device, self._n, self._m,
                                  len(A_col_indices), batch_size)
            initial_method = ranked[0] if ranked else 'auto'
            if ipm:
                ipm.direct_solve_method = initial_method

                         
        self._auto_tuned = False
        self._tune_result = None

                                                   
        self._info = None

                                                                       
                                              
        self._impl_handle = _register_impl(self._impl)

    def setup(
        self,
        P_values: torch.Tensor,
        A_values: torch.Tensor,
    ):
        """Set P and A matrix values.

        Must be called before solve(). Can be called multiple times to update
        values for repeated solves with the same structure.

        Args:
            P_values: P matrix values, shape (batch, nnzP) or (nnzP,), float64
            A_values: A matrix values, shape (batch, nnzA) or (nnzA,), float64
        """
        import time
        _validate_tensor_dtype(P_values, 'P_values')
        _validate_tensor_dtype(A_values, 'A_values')

                                                    
        if P_values.device != A_values.device:
            raise ValueError(
                f"P_values (device={P_values.device}) and A_values "
                f"(device={A_values.device}) must be on the same device"
            )
        self._input_device = P_values.device

                                                  
        target = torch.device('cpu' if self._device == 'cpu' else self._device)
        if P_values.device != target:
            P_values = P_values.to(target)
        if A_values.device != target:
            A_values = A_values.to(target)

        self._P_values = P_values
        self._A_values = A_values
        setup_start = time.perf_counter()
        self._impl.setup(P_values, A_values)
        self._setup_time = time.perf_counter() - setup_start

                                                                            
    _WARM_START_NO_RETRY = frozenset({
        SolverStatus.Solved,
        SolverStatus.AlmostSolved,
        SolverStatus.MaxIterations,
        SolverStatus.CallbackTerminated,
    })

    _AUTO_TUNE_MARGIN = 1.5

    def _needs_auto_tune(self) -> bool:
        """Check if auto-tune benchmarking should run on this solve."""
        if self._auto_tuned:
            return False
        if not self._settings.auto_tune:
            return False
                                                               
        from moreau._types import SolverType
        if self._settings.solver == SolverType.ACTIVE_SET:
            return False
                                                                              
        from moreau._backend import _default_device_override
        if self._original_device == 'auto' and _default_device_override is not None:
            return False
                                                       
        if self._original_device == 'auto':
            return True
        if self._original_method == 'auto':
            return True
        return False

    def _auto_tune(self, q: torch.Tensor, b: torch.Tensor):
        """Benchmark solver configs and lock in the fastest.

        Uses moreau.CompiledSolver internally for benchmarking (no grad
        overhead), then reconstructs this solver's backend with the winner.
        """
        warnings.warn(
            "First solve is benchmarking solver configurations "
            "(auto_tune=True). Subsequent solves will be faster. "
            "Set auto_tune=False (default) to use heuristic selection "
            "without benchmarking.",
            stacklevel=3,
        )
        import numpy as np
        import moreau

        q_np = q.detach().cpu().numpy().astype(np.float64)
        b_np = b.detach().cpu().numpy().astype(np.float64)
        P_np = self._P_values.detach().cpu().numpy().astype(np.float64)
        A_np = self._A_values.detach().cpu().numpy().astype(np.float64)
        _cpu = lambda t: t.cpu() if hasattr(t, 'cpu') else t
        P_ro = np.asarray(_cpu(self._P_row_offsets), dtype=np.int64)
        P_ci = np.asarray(_cpu(self._P_col_indices), dtype=np.int64)
        A_ro = np.asarray(_cpu(self._A_row_offsets), dtype=np.int64)
        A_ci = np.asarray(_cpu(self._A_col_indices), dtype=np.int64)

                                                                           
                                                                             
        actual_batch = q_np.shape[0] if q_np.ndim == 2 else 1

        candidates = _auto_tune_candidates(
            self._original_device, self._original_method,
            n=self._n, m=self._m,
            nnz_P=len(P_ci), nnz_A=len(A_ci),
            batch_size=actual_batch,
        )

        if not candidates:
            self._auto_tuned = True
            return

                                                      
        ipm = self._settings.ipm_settings
        current_method = ipm.direct_solve_method if ipm else 'auto'
        current_config = (self._device, current_method)
        current_key = f"{current_config[0]}:{current_config[1]}"

                                                                                
        verbose = self._settings.verbose
        results = {}
        best_time = float('inf')
        best_key = None
        construction_limit = None

        if verbose:
            _print = lambda *a, **kw: print(*a, **kw, flush=True)
            _print(f"[moreau] auto-tune: benchmarking {len(candidates)} "
                   f"candidate(s)...")
        else:
            _print = None

        for trial_device, trial_method in candidates:
            key = f"{trial_device}:{trial_method}"
            trial_settings = self._settings.model_copy(deep=True)
            trial_settings.device = trial_device
            trial_settings.verbose = False
            trial_settings.enable_grad = False
            trial_settings.batch_size = actual_batch
            if trial_settings.ipm_settings is None:
                trial_settings.ipm_settings = IPMSettings()
            trial_settings.ipm_settings.direct_solve_method = trial_method
                                                             
            if best_time < float('inf'):
                trial_settings.time_limit = min(
                    best_time * self._AUTO_TUNE_MARGIN,
                    trial_settings.time_limit,
                )

                                       
            import time as _time
            build_t0 = _time.perf_counter()
            trial = moreau.CompiledSolver(
                n=self._n, m=self._m,
                P_row_offsets=P_ro, P_col_indices=P_ci,
                A_row_offsets=A_ro, A_col_indices=A_ci,
                cones=self._cones, settings=trial_settings,
            )
            trial.setup(P_np, A_np)
            build_time = _time.perf_counter() - build_t0

                                                           
            if construction_limit is None:
                construction_limit = max(build_time * 5, 1.0)

                                                
            if build_time > construction_limit:
                results[key] = {
                    'solve_time': float('inf'),
                    'iterations': 0,
                    'status': [SolverStatus.NumericalError],
                }
                if _print:
                    _print(f"[moreau] auto-tune:   {key:<16s} "
                           f"{build_time:.3f}s build  "
                           f"skipped (build > {construction_limit:.2f}s limit)")
                continue

            trial.solve(q_np, b_np)
            info = trial.info
            results[key] = {
                'solve_time': info.solve_time,
                'iterations': info.iterations,
                'status': info.status,
            }

            _ok = (SolverStatus.Solved, SolverStatus.AlmostSolved)
            statuses = info.status if isinstance(info.status, list) else [info.status]
            is_ok = all(s in _ok for s in statuses)
            if is_ok and info.solve_time < best_time:
                best_time = info.solve_time
                best_key = key

            if _print:
                iters = info.iterations
                iters_str = str(max(iters)) if isinstance(iters, list) else str(iters)
                names = set(s.name if hasattr(s, 'name') else str(s) for s in statuses)
                status_str = names.pop() if len(names) == 1 else '/'.join(sorted(names))
                marker = " *" if key == best_key else ""
                _print(f"[moreau] auto-tune:   {key:<16s} "
                       f"{build_time:.3f}s build  "
                       f"{info.solve_time:.4f}s solve  "
                       f"{iters_str} iters  "
                       f"{status_str}{marker}")

                                                                                          
        _ok_statuses = (SolverStatus.Solved, SolverStatus.AlmostSolved)
        sorted_keys = sorted(results, key=lambda k: results[k]['solve_time'])
        winner_key = None
        for key in sorted_keys:
            r_status = results[key]['status']
            r_statuses = r_status if isinstance(r_status, list) else [r_status]
            if not all(s in _ok_statuses for s in r_statuses):
                continue
            dev = key.split(':', 1)[0]
            if get_device_component(dev, 'torch_solver') is not None:
                winner_key = key
                break

        if winner_key is None:
            winner_key = sorted_keys[0]
            best_device = self._device
            best_method = winner_key.split(':', 1)[1]
        else:
            best_device, best_method = winner_key.split(':', 1)

        best_time = results[winner_key]['solve_time']
        tuned_limit = best_time * self._AUTO_TUNE_MARGIN
        time_limit = max(tuned_limit, self._settings.time_limit)

        if _print:
            _print(f"[moreau] auto-tune: winner {best_device}:{best_method} "
                   f"({best_time:.4f}s solve)")

        self._tune_result = TuneResult(
            device=best_device,
            method=best_method,
            time_limit=time_limit,
            results=results,
        )

                                                           
        winner_config = (best_device, best_method)
        if winner_config != current_config:
            winning_settings = self._settings.model_copy(deep=True)
            winning_settings.device = best_device
            if winning_settings.ipm_settings is None:
                winning_settings.ipm_settings = IPMSettings()
            winning_settings.ipm_settings.direct_solve_method = best_method
            winning_settings.time_limit = time_limit
            self._settings = winning_settings
            self._device = best_device

            TorchSolverClass = get_device_component(best_device, 'torch_solver')
            if TorchSolverClass is not None:
                self._TorchSolverClass = TorchSolverClass

                                                           
            target = torch.device('cpu' if best_device == 'cpu' else best_device)
            self._P_row_offsets = self._P_row_offsets.to(target) if isinstance(self._P_row_offsets, torch.Tensor) else self._P_row_offsets
            self._P_col_indices = self._P_col_indices.to(target) if isinstance(self._P_col_indices, torch.Tensor) else self._P_col_indices
            self._A_row_offsets = self._A_row_offsets.to(target) if isinstance(self._A_row_offsets, torch.Tensor) else self._A_row_offsets
            self._A_col_indices = self._A_col_indices.to(target) if isinstance(self._A_col_indices, torch.Tensor) else self._A_col_indices

            self._impl = self._TorchSolverClass(
                self._n, self._m,
                self._P_row_offsets, self._P_col_indices,
                self._A_row_offsets, self._A_col_indices,
                self._cones, self._settings,
                batch_size=self._batch_size,
                enable_grad=self._settings.enable_grad,
            )
            self._impl_handle = _register_impl(self._impl)
            if self._settings.enable_grad:
                self._impl.setup_grad(self._batch_size)

                                                       
            target = 'cpu' if best_device == 'cpu' else best_device
            self._P_values = self._P_values.to(target)
            self._A_values = self._A_values.to(target)
            self._impl.setup(self._P_values, self._A_values)

        self._auto_tuned = True

    def solve(
        self,
        P_values: torch.Tensor,
        A_values: torch.Tensor,
        q: torch.Tensor,
        b: torch.Tensor,
        *,
        warm_start=None,
    ):
        """Solve the optimization problem.

        Stateless call — all problem data is passed as arguments.
        Safe for chained solves in autograd graphs (e.g. MPC rollouts).
        P/A setup is cached internally: if P and A haven't changed since
        the last call, the expensive setup step is skipped automatically.

        Args:
            P_values: P matrix values, shape (batch, nnzP) or (nnzP,), float64
            A_values: A matrix values, shape (batch, nnzA) or (nnzA,), float64
            q: Linear cost vector, shape (batch, n) or (n,)
            b: Constraint RHS, shape (batch, m) or (m,)
            warm_start: Optional WarmStart or BatchedWarmStart from a previous
                solve (e.g. ``solution.to_warm_start()``). Gradients do NOT
                flow through warm start values.

        Returns:
            Solution object:
            - For single problems: TorchSolution
            - For batched problems: TorchBatchedSolution

        Example:
            >>> solver = Solver(n, m, P_ro, P_ci, A_ro, A_ci, cones)
            >>> solution = solver.solve(P_values, A_values, q, b)
            >>> loss = solution.x.sum()
            >>> loss.backward()
        """
        self.setup(P_values, A_values)

                                                                  
        if self._needs_auto_tune():
            self._auto_tune(q, b)

                                                                                     
        if q.device != b.device:
            raise ValueError(
                f"q (device={q.device}) and b (device={b.device}) "
                f"must be on the same device"
            )
        input_device = getattr(self, '_input_device', None)
        if input_device is not None and q.device != input_device:
            raise ValueError(
                f"solve() inputs (device={q.device}) must be on the same device "
                f"as setup() inputs (device={input_device})"
            )
        input_device = q.device

                                                                        
                                                                       
        target = torch.device('cpu' if self._device == 'cpu' else self._device)
        if q.device != target:
            q = q.to(target)
        if b.device != target:
            b = b.to(target)

                                                                       
        if warm_start is not None:
            if not isinstance(warm_start, (WarmStart, BatchedWarmStart)):
                raise TypeError(
                    f"warm_start must be a WarmStart or BatchedWarmStart, "
                    f"got {type(warm_start).__name__}")

            device = q.device
            warm_x = torch.tensor(warm_start.x, dtype=torch.float64, device=device)
            warm_z = torch.tensor(warm_start.z, dtype=torch.float64, device=device)
            warm_s = torch.tensor(warm_start.s, dtype=torch.float64, device=device)

                                          
            if warm_x.dim() == 1:
                warm_x = warm_x.unsqueeze(0)
                warm_z = warm_z.unsqueeze(0)
                warm_s = warm_s.unsqueeze(0)

            self._pending_warm_kwargs = {
                'warm_x': warm_x, 'warm_z': warm_z, 'warm_s': warm_s
            }
        else:
            self._pending_warm_kwargs = {}

        x, z, s = _SolveFunction.apply(
            self, q, b, self._P_values, self._A_values
        )

                                  
        self._pending_warm_kwargs = {}

                                
        cached = self._last_result

                                                    
        is_batched = x.dim() > 1

                                                                   
        if warm_start is not None:
            ipm = self._settings.ipm_settings
            no_retry = ipm.warm_start_no_retry if (ipm and ipm.warm_start_no_retry is not None) else self._WARM_START_NO_RETRY
            if is_batched:
                status_list = [_normalize_status(int(st)) for st in cached['status']]
                need_retry = any(s not in no_retry for s in status_list)
            else:
                status_val = _normalize_status(int(cached['status']))
                need_retry = status_val not in no_retry

            if need_retry:
                warnings.warn(
                    "Warm-started solve failed, retrying without warm start.",
                    UserWarning,
                    stacklevel=2,
                )
                self._pending_warm_kwargs = {}
                x, z, s = _SolveFunction.apply(
                    self, q, b, self._P_values, self._A_values
                )
                cached = self._last_result

                                                        
        if x.device != input_device:
            x = x.to(input_device)
            z = z.to(input_device)
            s = s.to(input_device)

        if is_batched:
            status_list = [_normalize_status(int(st)) for st in cached['status']]

            solution = TorchBatchedSolution(
                x=x,
                z=z,
                s=s,
            )
            self._info = TorchBatchedSolveInfo(
                status=status_list,
                obj_val=cached['obj_val'],
                iterations=cached['iterations'],
                solve_time=cached['solve_time'],
                setup_time=self._setup_time,
                construction_time=self._construction_time,
            )
            return solution
        else:
            status = _normalize_status(int(cached['status']))

            solution = TorchSolution(
                x=x,
                z=z,
                s=s,
            )
            self._info = TorchSolveInfo(
                status=status,
                obj_val=cached['obj_val'],
                iterations=cached['iterations'],
                solve_time=cached['solve_time'],
                setup_time=self._setup_time,
                construction_time=self._construction_time,
            )
            return solution

    def backward(
        self,
        dx: torch.Tensor,
        dz: Optional[torch.Tensor] = None,
        ds: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Compute gradients via implicit differentiation."""
        return self._impl.backward(dx, dz, ds)

    def setup_grad(self, batch_size: Optional[int] = None):
        """Setup for gradient computation (backward pass).

        Pre-allocates memory and preprocessing for backward(). Optional but
        recommended when calling backward() repeatedly.

        Args:
            batch_size: Optional batch size for pre-allocation.
        """
        self._impl.setup_grad(batch_size)

    @property
    def grad_initialized(self) -> bool:
        """Whether setup_grad() has been called."""
        return self._impl.grad_initialized

    @property
    def device(self) -> str:
        """Return the active device name ('cpu' or 'cuda')."""
        return self._device

    @property
    def n(self) -> int:
        """Number of primal variables."""
        return self._n

    @property
    def m(self) -> int:
        """Number of constraints."""
        return self._m

    @property
    def batch_size(self) -> int:
        """Current batch size."""
        return self._impl.batch_size

    @property
    def is_initialized(self) -> bool:
        """Whether solver has been initialized."""
        return self._impl.is_initialized

    @property
    def nnzP(self) -> int:
        """Number of non-zeros in P matrix."""
        return self._impl.nnzP

    @property
    def nnzA(self) -> int:
        """Number of non-zeros in A matrix."""
        return self._impl.nnzA

    def reset(self):
        """Reset solver state."""
        self._impl.reset()

    def get_dimensions(self) -> dict:
        """Return problem dimensions."""
        return self._impl.get_dimensions()

    @property
    def tune_result(self):
        """Result from auto-tuning on the first solve() call.

        Returns None if auto-tune has not run yet (e.g. device and method
        were set explicitly, or solve() has not been called).
        """
        return self._tune_result

    @property
    def info(self):
        """Metadata from the last solve() call.

        Returns None if solve() has not been called yet.

        Contains:
            - status: SolverStatus enum (or list for batched)
            - obj_val: Objective value tensor
            - iterations: Number of IPM iterations
            - solve_time: Time in IPM iterations (seconds)
            - setup_time: Time setting matrix values (seconds)
            - construction_time: Time constructing solver (seconds)
        """
        return self._info


def solver(
    n: int,
    m: int,
    P_row_offsets: torch.Tensor,
    P_col_indices: torch.Tensor,
    A_row_offsets: torch.Tensor,
    A_col_indices: torch.Tensor,
    cones: Any,
    settings: Optional[Any] = None,
):
    """Create a PyTorch-compatible solve function.

    Returns a function that solves conic optimization problems with autograd support.
    The returned function has signature:

        solve(P_values, A_values, q, b) -> (Solution, Info)

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P matrix (torch.Tensor).
            P must be full symmetric (both upper and lower triangles).
        P_col_indices: CSR column indices for P matrix (torch.Tensor)
        A_row_offsets: CSR row pointers for A matrix (torch.Tensor)
        A_col_indices: CSR column indices for A matrix (torch.Tensor)
        cones: Cone specification (moreau.Cones object)
        settings: Optional solver settings (moreau.Settings object)

    Returns:
        Function: (P_values, A_values, q, b) -> (Solution, Info)

    Example:
        >>> from moreau.torch import solver
        >>> import moreau
        >>>
        >>> cones = moreau.Cones(num_nonneg_cones=2)
        >>> solve = solver(n=2, m=2, P_row_offsets=..., P_col_indices=...,
        ...                A_row_offsets=..., A_col_indices=..., cones=cones)
        >>>
        >>> solution, info = solve(P_values, A_values, q, b)
        >>> print(solution.x, info.status)
    """
                                     
    s = Solver(
        n, m,
        P_row_offsets, P_col_indices,
        A_row_offsets, A_col_indices,
        cones, settings,
    )

    def solve(
        P_values: torch.Tensor,
        A_values: torch.Tensor,
        q: torch.Tensor,
        b: torch.Tensor,
    ):
        """Solve the optimization problem.

        Args:
            P_values: P matrix values, shape (batch, nnzP) or (nnzP,)
            A_values: A matrix values, shape (batch, nnzA) or (nnzA,)
            q: Linear cost vector, shape (batch, n) or (n,)
            b: Constraint RHS, shape (batch, m) or (m,)

        Returns:
            Tuple of (solution, info):
                solution: TorchSolution or TorchBatchedSolution with x, z, s
                info: TorchSolveInfo or TorchBatchedSolveInfo with status, obj_val, etc.
        """
        solution = s.solve(P_values, A_values, q, b)
        return solution, s.info

    return solve


__all__ = [
    'Solver',
    'solver',
]
