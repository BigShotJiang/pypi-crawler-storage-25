"""Application configuration via environment variables."""

from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


_DEFAULT_DB_DIR = Path.home() / ".doorae"
_DEFAULT_DB_URL = f"sqlite+aiosqlite:///{_DEFAULT_DB_DIR / 'doorae.db'}"
_DEFAULT_ROOM_FILES_DIR = _DEFAULT_DB_DIR / "room_files"

# Bind addresses that listen on every interface aren't valid dial targets.
# When we build a URL for an agent to connect back to us, map these to a
# loopback address so a local agent can still reach the server.
_UNDIALABLE_HOSTS = frozenset({"0.0.0.0", "::", ""})


class DooraeSettings(BaseSettings):
    """Configuration loaded from ``DOORAE_*`` environment variables."""

    host: str = "127.0.0.1"
    port: int = 8000
    db_url: str = _DEFAULT_DB_URL
    jwt_secret: str = ""
    jwt_expire_hours: int = 24
    log_level: str = "INFO"
    dev: bool = False  # DOORAE_DEV=1 for development mode
    # #124 — Fernet symmetric key for encrypting MCP server credentials
    # at rest (``mcp_server_instances.env_values_encrypted``). Loaded
    # from ``DOORAE_MCP_SECRETS_KEY``. Empty string falls back to a
    # process-local ephemeral key when ``dev=True`` (with a loud
    # warning); production deployments MUST set this explicitly or the
    # MCPSecrets initializer will refuse to boot.
    mcp_secrets_key: str = ""
    # #197 — Embedded LiteLLM gateway. When enabled, doorae-server
    # supervises a ``litellm`` subprocess listening on
    # ``127.0.0.1:<llm_gateway_port>`` and exposes ``/api/v1/llm/*``
    # as a reverse proxy. See docs/design/12-llm-gateway.md.
    #
    # Off by default — the existing "agent calls upstream directly"
    # path remains canonical until Phase 5 flips per-agent wiring.
    llm_gateway_enabled: bool = False
    # Port the LiteLLM subprocess listens on (loopback only). Picked
    # above LiteLLM's default 4000 so local dev setups that already
    # have LiteLLM running don't collide with the embedded one.
    llm_gateway_port: int = 4001
    # Rendered config.yaml location. Empty string defaults to
    # ``~/.doorae/litellm.yaml`` — resolved lazily in the gateway
    # code so tests can point at a temp dir without poisoning home.
    llm_gateway_config_path: str = ""
    # #246 — Disk-backed storage for room shared files. The DB only
    # keeps metadata + sha256; the original bytes live under
    # ``<room_files_dir>/<room_id>/<file_id>``. Kept outside the
    # DB so the default SQLite ``doorae.db`` stays compact as rooms
    # accumulate attachments. Resolved lazily so tests can redirect
    # it without touching ``$HOME``.
    room_files_dir: Path = _DEFAULT_ROOM_FILES_DIR

    model_config = SettingsConfigDict(env_prefix="DOORAE_")

    def reachable_host(self) -> str:
        """A host string that a client can actually dial.

        Running with ``--host 0.0.0.0`` tells uvicorn to listen on every
        interface, but ``0.0.0.0`` is not a usable destination address.
        Falling back to ``127.0.0.1`` lets agents colocated with the
        server connect over loopback; remote machines should set
        ``DOORAE_HOST`` to the server's real hostname explicitly.
        """
        if self.host in _UNDIALABLE_HOSTS:
            return "127.0.0.1"
        return self.host
