"""
MXTQ loader — dequants TQ weights at load time for testing.
Usage: from load_mxtq_dequant import load_mxtq_model
"""
import sys, json, gc, time
import numpy as np
import mlx.core as mx
import mlx.nn as nn
from pathlib import Path

sys.path.insert(0, "/Users/eric/jang/jang-tools")
from jang_tools.turboquant.codebook import compute_codebook
from jang_tools.turboquant.rotation import generate_random_signs, hadamard_inverse
from jang_tools.turboquant.givens import generate_givens_rotations, givens_inverse
from jang_tools.turboquant.pipeline import unpack_bits


def _dequant_tq(packed, norms, bits, in_features, seed=42, rotation="hadamard"):
    """Dequant a single MXTQ/MXRQ tensor to float16. CPU-based to avoid GPU OOM."""
    import numpy as _np
    out_features = packed.shape[0]
    cb = _np.array(compute_codebook(in_features, bits), dtype=_np.float32)

    # Fully vectorized unpack — zero Python loops
    packed_np = _np.array(packed).astype(_np.uint32) if not isinstance(packed, _np.ndarray) else packed.astype(_np.uint32)
    norms_np = _np.array(norms).astype(_np.float32) if not isinstance(norms, _np.ndarray) else norms.astype(_np.float32)
    vals_per_u32 = 32 // bits
    mask = _np.uint32((1 << bits) - 1)

    # Broadcast unpack: (out, packed_cols, 1) >> shifts(1, 1, vals_per_u32) & mask
    shifts = _np.arange(0, 32, bits, dtype=_np.uint32).reshape(1, 1, -1)
    unpacked = (packed_np[:, :, None] >> shifts) & mask  # (out, packed_cols, vals_per_u32)
    all_idx = unpacked.reshape(out_features, -1)[:, :in_features].astype(_np.int32)

    w = cb[all_idx] * norms_np[:, None]

    # Inverse rotation
    if rotation == "givens":
        rot_params = generate_givens_rotations(in_features, seed=seed)
        w = givens_inverse(w, rot_params)
    else:
        signs = generate_random_signs(in_features, seed=seed)
        w_mx = mx.array(w)
        w_mx = hadamard_inverse(w_mx, mx.array(signs))
        w = _np.array(w_mx)

    return mx.array(w.astype(_np.float16))


def load_mxtq_model(model_path, skip_params_eval=False):
    """Load MXTQ2 model with TQ dequant at load time."""
    model_path = Path(model_path)
    # M125 (iter 48): context-manage reads so fds close deterministically.
    with open(model_path / "config.json") as _f:
        config = json.load(_f)

    jang_cfg_path = model_path / "jang_config.json"
    if jang_cfg_path.exists():
        with open(jang_cfg_path) as _f:
            jang_cfg = json.load(_f)
    else:
        jang_cfg = {}
    mxtq_seed = jang_cfg.get("mxtq_seed", jang_cfg.get("mxrq_seed", 42))
    mxtq_bits_map = jang_cfg.get("mxtq_bits", jang_cfg.get("mxrq_bits", {}))
    rotation_type = jang_cfg.get("rotation", "hadamard")

    print(f"Loading MXTQ2: {model_path.name}", flush=True)

    from mlx_lm.utils import load_config, load_model as _load_skeleton, load_tokenizer
    model_config = load_config(model_path)
    if "quantization" not in model_config:
        model_config["quantization"] = {"group_size": 64, "bits": 2}

    model, model_config = _load_skeleton(model_path, lazy=True, strict=False, model_config=model_config)

    weight_files = sorted(model_path.glob("model-*.safetensors"))
    if not weight_files:
        weight_files = sorted(model_path.glob("model.safetensors-*.safetensors"))

    print(f"  {len(weight_files)} shards", flush=True)

    _needs_vlm_remap = hasattr(model, "language_model") and "text_config" in model_config
    tq_count = 0

    for sf_path in weight_files:
        weights = mx.load(str(sf_path))

        if _needs_vlm_remap:
            remapped = {}
            for k, v in weights.items():
                if k.startswith("model.language_model."):
                    remapped[k.replace("model.language_model.", "language_model.model.", 1)] = v
                elif k.startswith("lm_head."):
                    remapped["language_model." + k] = v
                else:
                    remapped[k] = v
            weights = remapped

        tq_groups = {}
        regular = {}
        for k, v in weights.items():
            if k.endswith(".tq_packed") or k.endswith(".rq_packed"):
                base = k.rsplit(".", 1)[0]
                tq_groups.setdefault(base, {})["packed"] = v
            elif k.endswith(".tq_norms") or k.endswith(".rq_norms"):
                base = k.rsplit(".", 1)[0]
                tq_groups.setdefault(base, {})["norms"] = v
            elif k.endswith(".tq_bits") or k.endswith(".rq_bits"):
                base = k.rsplit(".", 1)[0]
                tq_groups.setdefault(base, {})["bits_arr"] = v
            elif k.endswith(".rq_shape") or k.endswith(".tq_shape"):
                base = k.rsplit(".", 1)[0]
                tq_groups.setdefault(base, {})["orig_shape"] = v
            else:
                regular[k] = v

        for base, parts in tq_groups.items():
            if "packed" not in parts or "norms" not in parts:
                continue
            packed = parts["packed"]
            norms = parts["norms"]

            bl = base.lower()
            if "shared_expert" in bl:
                bits = mxtq_bits_map.get("shared_expert", 3)
            elif "expert" in bl:
                bits = mxtq_bits_map.get("routed_expert", 2)
            else:
                bits = 2

            vals_per_u32 = 32 // bits
            orig_shape = parts.get("orig_shape")

            if packed.ndim == 3:
                n_exp, out_feat, packed_cols = packed.shape
                if orig_shape is not None:
                    os_np = np.array(orig_shape)
                    in_features = int(os_np[-1])
                else:
                    in_features = packed_cols * vals_per_u32
                expert_ws = []
                for e in range(n_exp):
                    w = _dequant_tq(packed[e], norms[e], bits, in_features, mxtq_seed)
                    expert_ws.append(w)
                    if e % 32 == 31:
                        mx.synchronize()
                dq = mx.stack(expert_ws)
                mx.synchronize()
                del expert_ws
            else:
                out_feat, packed_cols = packed.shape
                if orig_shape is not None:
                    os_np = np.array(orig_shape)
                    in_features = int(os_np[-1])
                else:
                    in_features = packed_cols * vals_per_u32
                dq = _dequant_tq(packed, norms, bits, in_features, mxtq_seed, rotation_type)
                mx.synchronize()

            regular[f"{base}.weight"] = dq
            tq_count += 1

        if hasattr(model, "sanitize"):
            regular = model.sanitize(regular)

        model.load_weights(list(regular.items()), strict=False)
        del regular, weights
        gc.collect()

    sys.path.insert(0, "/Users/eric/mlx/vllm-mlx")
    from vmlx_engine.utils.jang_loader import _fix_quantized_bits
    _fix_quantized_bits(model)

    tc = model_config.get("text_config", model_config)
    if tc.get("kv_lora_rank", 0) > 0 or tc.get("model_type", "") == "glm_moe_dsa":
        model.set_dtype(mx.bfloat16)
        print("  bfloat16 enabled", flush=True)

    if not skip_params_eval:
        mx.synchronize()

    tokenizer = load_tokenizer(model_path)
    print(f"  Done: {tq_count} MXTQ tensors dequanted", flush=True)
    return model, tokenizer
