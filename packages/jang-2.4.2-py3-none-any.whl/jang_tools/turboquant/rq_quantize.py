"""
MXRQ — RotorQuant-style weight quantization for JANG.
Created by Jinho Jang (eric@jangq.ai)

Uses PlanarQuant (2D Givens) rotation + Lloyd-Max codebook.
O(d) rotation vs O(d log d) Hadamard — 12x faster dequant at inference.

Credit: RotorQuant/PlanarQuant approach from scrya-com/rotorquant (2026).
"""
import numpy as np
import mlx.core as mx
from .codebook import compute_codebook
from .givens import generate_givens_rotations, givens_rotate, givens_inverse
from .pipeline import pack_bits, unpack_bits


def rq_quantize_weight(weight: np.ndarray, bits: int = 2, seed: int = 42) -> dict:
    """Quantize weight matrix using RotorQuant (Givens + codebook).

    Args:
        weight: (out_features, in_features) float32
        bits: codebook bits
        seed: rotation seed

    Returns:
        dict with packed (uint32), norms (float16), rotation params
    """
    out_feat, in_feat = weight.shape

    # Givens rotation parameters
    rot_params = generate_givens_rotations(in_feat, seed=seed)

    # Rotate
    w_rot = givens_rotate(weight, rot_params)

    # Per-row normalize
    norms = np.sqrt(np.sum(w_rot ** 2, axis=1, keepdims=True)).astype(np.float32)
    norms_safe = np.maximum(norms, 1e-10)
    w_normed = w_rot / norms_safe

    # Lloyd-Max codebook
    cb_list = compute_codebook(in_feat, bits)
    cb = np.array(cb_list, dtype=np.float32)
    boundaries = (cb[:-1] + cb[1:]) / 2.0

    # Quantize to codebook indices
    indices = np.zeros(w_normed.shape, dtype=np.uint8)
    for b in boundaries:
        indices += (w_normed > b).astype(np.uint8)

    # Pack per-row
    packed_rows = []
    for r in range(out_feat):
        row_packed = np.array(pack_bits(mx.array(indices[r]), bits))
        packed_rows.append(row_packed)
    packed = np.stack(packed_rows)

    return {
        "packed": packed,
        "norms": norms.squeeze(-1).astype(np.float16),
    }


def rq_dequant_weight(packed, norms, bits, in_features, seed=42):
    """Dequant MXRQ weight back to float. Used at load time.

    Args:
        packed: (out_features, packed_cols) uint32
        norms: (out_features,) float16
        bits: int
        in_features: int
        seed: int

    Returns:
        mx.array (out_features, in_features) float16
    """
    out_feat = packed.shape[0]
    cb = mx.array(compute_codebook(in_features, bits))
    rot_params = generate_givens_rotations(in_features, seed=seed)

    # Unpack per-row + codebook lookup
    rows = []
    for r in range(out_feat):
        idx = unpack_bits(packed[r] if isinstance(packed[r], mx.array) else mx.array(packed[r]),
                          bits, in_features)
        row = mx.take(cb, idx.astype(mx.uint32))
        rows.append(row)
    w = mx.stack(rows)

    # Scale by norms
    norms_mx = mx.array(norms) if not isinstance(norms, mx.array) else norms
    w = w * norms_mx[:, None].astype(w.dtype)

    # Inverse Givens rotation (O(d), fast)
    w_np = np.array(w)
    w_restored = givens_inverse(w_np, rot_params)

    return mx.array(w_restored.astype(np.float16))
