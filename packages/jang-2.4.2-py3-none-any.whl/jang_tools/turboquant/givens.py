"""
Givens (Planar) Rotation for JANG Weight Quantization.
Created by Jinho Jang (eric@jangq.ai)

Block-diagonal 2D rotations for weight decorrelation before quantization.
Inspired by RotorQuant/PlanarQuant (scrya-com/rotorquant) which showed that
small block rotations (2D Givens) outperform full Walsh-Hadamard transforms
for quantization decorrelation — "real vectors live on low-rank manifolds,
and block-diagonal rotation preserves directional structure more effectively
than global WHT scrambling."

Key advantages over Hadamard (from RotorQuant research):
  - O(d) complexity vs O(d log d) for WHT
  - Preserves local structure (2D pairs vs full d-dim scramble)
  - 128 parameters vs 16384 for d=128 (44x reduction)
  - Better PPL at 3-bit KV cache (6.91 vs 7.07 on Llama 3.1 8B)

Applied to weights: rotate row vectors before quantization, inverse-rotate
at inference after dequantization. The rotation is orthogonal so the
matmul result is identical: y = x @ (R^T Q(R W))^T = x @ W^T + quant_error.

References:
  - RotorQuant (scrya-com/rotorquant, 2026) — block-diagonal rotation KV cache
  - PlanarQuant — 2D Givens subset achieving best speed/quality tradeoff
"""

import numpy as np
from typing import Optional


def generate_givens_rotations(
    dim: int,
    seed: int = 42,
) -> np.ndarray:
    """Generate random 2D Givens rotation parameters.

    Args:
        dim: vector dimension (must be even or will be padded)
        seed: random seed for reproducibility

    Returns:
        (n_pairs, 2) array of [cos θ, sin θ] per pair
    """
    n_pairs = (dim + 1) // 2
    rng = np.random.RandomState(seed)
    angles = rng.uniform(0, 2 * np.pi, n_pairs)
    return np.stack([np.cos(angles), np.sin(angles)], axis=-1).astype(np.float32)


def givens_rotate(
    weights: np.ndarray,
    rotations: np.ndarray,
) -> np.ndarray:
    """Apply block-diagonal 2D Givens rotation to weight rows.

    Args:
        weights: (out_features, in_features) float32
        rotations: (n_pairs, 2) as [cos θ, sin θ]

    Returns:
        Rotated weights, same shape
    """
    out_feat, in_feat = weights.shape
    n_pairs = rotations.shape[0]
    d_padded = n_pairs * 2

    # Pad if odd dimension
    if in_feat % 2 != 0:
        weights = np.pad(weights, ((0, 0), (0, 1)))

    # Reshape to pairs: (out_feat, n_pairs, 2)
    pairs = weights[:, :d_padded].reshape(out_feat, n_pairs, 2)

    # Apply rotation: [c*v0 - s*v1, s*v0 + c*v1]
    c = rotations[:, 0]  # (n_pairs,)
    s = rotations[:, 1]  # (n_pairs,)
    v0 = pairs[:, :, 0]  # (out_feat, n_pairs)
    v1 = pairs[:, :, 1]

    rotated = np.stack([
        c * v0 - s * v1,
        s * v0 + c * v1,
    ], axis=-1)  # (out_feat, n_pairs, 2)

    result = rotated.reshape(out_feat, d_padded)
    return result[:, :in_feat]


def givens_inverse(
    weights: np.ndarray,
    rotations: np.ndarray,
) -> np.ndarray:
    """Apply inverse Givens rotation (transpose = negate sin).

    Args:
        weights: (out_features, in_features) rotated weights
        rotations: (n_pairs, 2) as [cos θ, sin θ]

    Returns:
        Un-rotated weights, same shape
    """
    # Inverse = same rotation with sin negated
    inv_rot = rotations.copy()
    inv_rot[:, 1] = -inv_rot[:, 1]
    return givens_rotate(weights, inv_rot)
