"""
GLM-5.1-JANG-MXTQ2 Conversion
Created by Jinho Jang (eric@jangq.ai)

Mixed-precision TurboQuant: MXTQ 2-bit experts, MXTQ 3-bit shared, affine 8-bit attention.
"""
import sys, json, gc, time, shutil
import numpy as np
import mlx.core as mx
from pathlib import Path
from tqdm import tqdm
from safetensors import safe_open
from safetensors.numpy import save_file

sys.path.insert(0, "/opt/homebrew/lib/python3.14/site-packages")
from jang_tools.fp8 import load_fp8_tensor
from jang_tools.calibrate import _load_bf16_tensor
from jang_tools.turboquant.linear import tq_quantize_weight

SRC = Path("/Volumes/EricsLLMDrive/GLM-5.1-FP8")
OUT = Path("/Users/eric/models/GLM-5.1-JANG-MXTQ2")
OUT.mkdir(exist_ok=True)

with open(SRC / "config.json") as _f:
    config = json.load(_f)
tc = config.get("text_config", config)
n_layers = tc["num_hidden_layers"]
first_dense = tc.get("first_k_dense_replace", 0)
n_experts = tc.get("n_routed_experts", 256)
SEED = 42

# Bit assignment per tensor type
def get_bits_and_method(tensor_name):
    """Returns (bits, method) where method is 'mxtq' or 'affine'."""
    name = tensor_name.lower()
    # Norms, biases — passthrough fp16
    if "norm" in name or tensor_name.endswith(".bias"):
        return (16, "passthrough")
    # Gate/router — passthrough fp16
    if ".gate." in name and "gate_proj" not in name:
        return (16, "passthrough")
    # Embeddings, lm_head — affine 8-bit
    if "embed_tokens" in name or "lm_head" in name:
        return (8, "affine")
    # Attention (MLA) — affine 8-bit
    if "self_attn" in name:
        return (8, "affine")
    # Shared expert — MXTQ 3-bit
    if "shared_expert" in name:
        return (3, "mxtq")
    # Routed expert — MXTQ 2-bit
    if "experts" in name or "switch_mlp" in name:
        return (2, "mxtq")
    # Fallback
    return (8, "affine")


print("=" * 60)
print("  GLM-5.1-JANG-MXTQ2 Conversion")
print("  Created by Jinho Jang (eric@jangq.ai)")
print("=" * 60)
print(f"  Source: {SRC}")
print(f"  Output: {OUT}")
print(f"  Layers: {n_layers} ({first_dense} dense, {n_layers - first_dense} MoE)")
print(f"  Experts: {n_experts}")
print(f"  Profile: MXTQ2 (attn=affine-8, shared=mxtq-3, expert=mxtq-2)")
print(flush=True)

# Collect all tensors
print("\n  Scanning source model...", flush=True)
all_tensors = []
for sf in sorted(SRC.glob("model-*.safetensors")):
    with safe_open(str(sf), framework="numpy") as f:
        for k in f.keys():
            if k.endswith("_scale_inv"):
                continue
            shape = list(f.get_slice(k).get_shape())
            all_tensors.append((k, shape, sf))
print(f"  Found {len(all_tensors)} tensors", flush=True)

# Process tensors
shard_idx = 0
shard_tensors = {}
shard_bytes = 0
MAX_SHARD = 1_000_000_000  # 1 GB shards
total_mxtq = 0
total_affine = 0
total_passthrough = 0
shard_map = {}  # tensor_name -> shard filename

def flush_shard():
    global shard_idx, shard_tensors, shard_bytes, shard_map
    if not shard_tensors:
        return
    shard_idx += 1
    fname = f"model-{shard_idx:05d}-of-XXXXX.safetensors"
    save_file(shard_tensors, str(OUT / fname))
    for k in shard_tensors:
        shard_map[k] = fname
    print(f"    Shard {shard_idx}: {len(shard_tensors)} tensors, {shard_bytes/1e9:.1f} GB", flush=True)
    shard_tensors = {}
    shard_bytes = 0

def add_tensor(name, arr):
    global shard_tensors, shard_bytes
    shard_tensors[name] = arr
    shard_bytes += arr.nbytes
    if shard_bytes >= MAX_SHARD:
        flush_shard()

print("\n  Converting...", flush=True)
for tensor_name, shape, sf_path in tqdm(all_tensors, desc="  Processing"):
    bits, method = get_bits_and_method(tensor_name)

    # Load tensor
    with safe_open(str(sf_path), framework="numpy") as f:
        scale_key = tensor_name + "_scale_inv"
        try:
            scale = f.get_tensor(scale_key)
        except Exception:
            scale = None
        try:
            tensor = load_fp8_tensor(sf_path, tensor_name, shape, scale)
        except Exception:
            try:
                tensor = f.get_tensor(tensor_name)
                if not isinstance(tensor, np.ndarray):
                    tensor = np.array(tensor)
            except (TypeError, Exception):
                tensor = _load_bf16_tensor(sf_path, tensor_name, shape)

    tensor = tensor.astype(np.float32) if tensor.dtype != np.float32 else tensor

    if method == "passthrough":
        # Store as float16
        t16 = tensor.astype(np.float16) if tensor.dtype != np.float16 else tensor
        add_tensor(tensor_name, t16)
        total_passthrough += 1

    elif method == "affine":
        # Standard mx.quantize
        w = mx.array(tensor.astype(np.float16))
        qw, qs, qb = mx.quantize(w, group_size=64, bits=bits)
        base = tensor_name.replace(".weight", "") if tensor_name.endswith(".weight") else tensor_name
        add_tensor(f"{base}.weight", np.array(qw))
        add_tensor(f"{base}.scales", np.array(qs).astype(np.float16))
        add_tensor(f"{base}.biases", np.array(qb).astype(np.float16))
        total_affine += 1

    elif method == "mxtq":
        # TurboQuant: rotation + codebook
        result = tq_quantize_weight(tensor, bits=bits, seed=SEED)
        base = tensor_name.replace(".weight", "") if tensor_name.endswith(".weight") else tensor_name
        add_tensor(f"{base}.tq_packed", result["packed"])
        add_tensor(f"{base}.tq_norms", result["norms"])
        add_tensor(f"{base}.tq_bits", np.array([bits], dtype=np.uint8))
        total_mxtq += 1

    del tensor
    if total_mxtq % 100 == 0 and total_mxtq > 0:
        gc.collect()

# Flush remaining
flush_shard()

# Write index
print(f"\n  Writing index ({shard_idx} shards)...", flush=True)
index = {"metadata": {"total_size": sum(v.nbytes for v in shard_tensors.values())},
         "weight_map": shard_map}
# M125 (iter 48): context-manage the write so the buffer flushes + fd closes
# promptly. The final rename-and-rewrite below then replaces this file with
# the corrected-name variant.
with open(OUT / "model.safetensors.index.json", "w") as _f:
    json.dump(index, _f, indent=2)

# Rename shards with correct total
for i in range(1, shard_idx + 1):
    old = OUT / f"model-{i:05d}-of-XXXXX.safetensors"
    new = OUT / f"model-{i:05d}-of-{shard_idx:05d}.safetensors"
    if old.exists():
        old.rename(new)
        shard_map = {k: v.replace("XXXXX", f"{shard_idx:05d}") for k, v in shard_map.items()}

# Update and write index with correct names
index["weight_map"] = shard_map
with open(OUT / "model.safetensors.index.json", "w") as _f:
    json.dump(index, _f, indent=2)

# Write config
config.pop("quantization_config", None)
config["quantization"] = {"group_size": 64, "bits": 2}  # default for affine fallback
jang_config = {
    "weight_format": "mxtq",
    "profile": "MXTQ2",
    "mxtq_seed": SEED,
    "mxtq_bits": {"attention": 8, "shared_expert": 3, "routed_expert": 2},
    "method": "affine+mxtq",
}

# Stamp Tier-1 capabilities into the nested jang block. This converter
# inlines jang_config under config["jang"] (legacy path); vmlx's
# CapabilityDetector also looks for capabilities here.
from jang_tools.capabilities import build_capabilities
caps = build_capabilities(jang_config, config, OUT)
if caps is not None:
    jang_config["capabilities"] = caps
    print(f"  capabilities: family={caps['family']} reasoning={caps['reasoning_parser']} "
          f"tool={caps['tool_parser']} cache={caps['cache_type']} modality={caps['modality']}",
          flush=True)
else:
    print("  WARNING: could not resolve capabilities — vmlx will fall back to "
          "silver/bronze. Add the family to jang_tools/capabilities.py::FAMILY_MAP.",
          flush=True)

config["jang"] = jang_config
with open(OUT / "config.json", "w") as _f:
    json.dump(config, _f, indent=2)

# Validate the inlined jang block — catch schema drift / typos / missing keys.
from jang_tools.capabilities import verify_directory
_ok, _msg = verify_directory(OUT)
print(f"  verify: {_msg}")
if not _ok:
    raise SystemExit(f"capabilities verify failed: {_msg}")

# Copy tokenizer / chat-template / VL preprocessor / custom .py files.
# VL preprocessor configs are required by mlx-vlm / transformers for image or
# video inference — always include them when present upstream so downstream
# consumers don't have to patch them in.
for f in ["tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
          "generation_config.json", "chat_template.jinja",
          "chat_template.json", "merges.txt", "vocab.json",
          "preprocessor_config.json", "video_preprocessor_config.json",
          "configuration.json"]:
    src_f = SRC / f
    if src_f.exists():
        shutil.copy2(str(src_f), str(OUT / f))

# Copy custom .py files
for f in SRC.glob("*.py"):
    shutil.copy2(str(f), str(OUT / f.name))

# --- Osaurus / swift-transformers compatibility fix ---------------------------
# Remap tokenizer_class: "TokenizersBackend" → a concrete class that
# swift-transformers (Osaurus, vmlx-swift-lm) can parse. GLM ships its own
# ChatGLMTokenizer upstream, so map to that as the stable fallback.
_tok_cfg = OUT / "tokenizer_config.json"
if _tok_cfg.exists():
    try:
        with open(_tok_cfg) as _f:
            _tc = json.load(_f)
        if _tc.get("tokenizer_class") == "TokenizersBackend":
            _tc["tokenizer_class"] = "ChatGLMTokenizer"
            with open(_tok_cfg, "w") as _f:
                json.dump(_tc, _f, indent=2)
            print("  [osaurus-fix] tokenizer_class: TokenizersBackend → ChatGLMTokenizer", flush=True)
    except Exception as _e:
        print(f"  [osaurus-fix] skipped: {_e}", flush=True)

# Build Swift runtime sidecar so Swift runtimes (vmlx-swift-lm, vmlxctl,
# Osaurus) can load without fatalError. Python loader doesn't need it, but
# uploading without it is a footgun — see research/JANGTQ-REFERENCE.md.
print(f"\n  Building jangtq_runtime.safetensors sidecar...")
try:
    from jang_tools.build_jangtq_sidecar import main as _build_sidecar
    _saved_argv = sys.argv
    sys.argv = ["build_jangtq_sidecar", str(OUT)]
    try:
        _build_sidecar()
    finally:
        sys.argv = _saved_argv
except (Exception, SystemExit) as _e:
    print(f"  [sidecar] FAILED: {_e} — run `python3 -m jang_tools.build_jangtq_sidecar {OUT}` manually before upload", flush=True)

print(f"\n{'='*60}")
print(f"  DONE — GLM-5.1-JANG-MXTQ2")
print(f"  Output: {OUT}")
print(f"  Affine tensors: {total_affine}")
print(f"  MXTQ tensors:   {total_mxtq}")
print(f"  Passthrough:    {total_passthrough}")
du_result = sum(f.stat().st_size for f in OUT.glob("*") if f.is_file())
print(f"  Total size: {du_result/1e9:.1f} GB")
print(f"{'='*60}")
