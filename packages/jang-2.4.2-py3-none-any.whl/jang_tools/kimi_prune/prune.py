"""Execute a prune plan on Kimi K2.6: drop + absorb-merge experts, rewrite shards.

Kimi K2.6 on-disk format (confirmed from shard headers):
  experts.{E}.{proj}.weight_packed   I32, packed INT4 (8 int4s per int32)
  experts.{E}.{proj}.weight_scale    BF16, group-wise scales (group_size=32)
  experts.{E}.{proj}.weight_shape    I32[2], target dequant shape

Router:
  model.layers.{L}.mlp.gate.weight                    BF16 (E, hidden)
  model.layers.{L}.mlp.gate.e_score_correction_bias   F32 (E,)

Shared expert stays untouched.

Strategy:
  1. Walk plan per layer. For each dropped expert with an absorb-merge target:
     a. dequantize the dropped weights (INT4 → BF16) using weight_scale
     b. dequantize the kept target weights
     c. convex blend into the kept target (damping applied to dropped)
     d. requantize the merged tensor to INT4 with fresh group-wise scale
  2. Pack new shards:
     a. drop all tensor keys for dropped expert indices
     b. renumber kept experts to consecutive indices 0..n_keep-1
     c. rewrite router: keep only rows for kept experts, in new order
     d. rewrite config.json: set text_config.n_routed_experts = n_keep
        (and drop expert index consistency is maintained by the renumber)

RAM economy: we only materialize one layer's experts in BF16 at a time.
A single MoE layer has 384 experts × 3 projs × ~15 MB BF16 each ≈ 17 GB.
Blending takes <1s. Fits comfortably on 256 GB Mac Studio.

This module reads and writes .safetensors files. No actual torch/mlx tensor
math is performed — we use numpy + custom INT4 pack/unpack, so no FP8
runtime is required. Writing via `safetensors.numpy.save_file`.

Usage:
  python -m jang_tools.kimi_prune.prune \\
      --src /Volumes/EricsLLMDrive/sources/Kimi-K2.6-FP8 \\
      --plan /Volumes/EricsLLMDrive/kimi_calib/prune_plan.json \\
      --dst /Volumes/EricsLLMDrive/sources/Kimi-K2.6-pruned-30 \\
      [--no-absorb-merge]  [--absorb-damping 0.5]
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass
class PruneConfig:
    src: Path
    dst: Path
    plan_path: Path
    absorb_merge: bool = True
    absorb_damping: float = 0.5


# Regex patterns to match Kimi K2.6 tensor names.
EXPERT_TENSOR_RE = re.compile(
    r"^(?P<prefix>(?:language_model\.)?model\.layers\.)"
    r"(?P<layer>\d+)"
    r"\.mlp\.experts\."
    r"(?P<expert>\d+)"
    r"\.(?P<proj>gate_proj|up_proj|down_proj)"
    r"\.(?P<kind>weight_packed|weight_scale|weight_shape)$"
)
ROUTER_W_RE = re.compile(
    r"^(?P<prefix>(?:language_model\.)?model\.layers\.)"
    r"(?P<layer>\d+)"
    r"\.mlp\.gate\.(?P<kind>weight|e_score_correction_bias)$"
)


# ---------- INT4 unpack / pack ---------------------------------------------


def unpack_int4(packed_i32, scale_bf16, target_shape, group_size: int = 32):
    """Unpack I32-packed INT4 (8 per int32) + BF16 group scales → float32.

    Layout assumption (verified against shard30):
      packed.shape = (out, in // 8)    where values are 8 signed int4
                                       packed lsb-first per int32 word
      scale.shape  = (out, in // group_size)
      target_shape = (out, in)

    Returns numpy float32 array of shape target_shape.
    """
    import numpy as np
    out_dim, in_dim = int(target_shape[0]), int(target_shape[1])
    packed = np.asarray(packed_i32, dtype=np.int32)
    # Unpack 8 signed 4-bit values per int32.
    # Treat each int32 as uint32, shift and mask; reinterpret nibbles as
    # signed int4 via sign-extension trick.
    u = packed.view(np.uint32)
    nibbles = np.zeros((u.shape[0], u.shape[1], 8), dtype=np.int8)
    for j in range(8):
        n = ((u >> (4 * j)) & 0xF).astype(np.int8)
        # Sign-extend: values 8..15 become -8..-1.
        n = np.where(n >= 8, n - 16, n)
        nibbles[..., j] = n
    unpacked = nibbles.reshape(out_dim, -1)  # (out, in)
    assert unpacked.shape == (out_dim, in_dim), \
        f"unpack mismatch: got {unpacked.shape}, expected {(out_dim, in_dim)}"

    scale = np.asarray(scale_bf16, dtype=np.float32)  # promoted
    # Broadcast scale: (out, in/group_size) → (out, in) via repeat.
    sc = np.repeat(scale, group_size, axis=-1)[..., :in_dim]
    return unpacked.astype(np.float32) * sc


def pack_int4(w_f32, group_size: int = 32):
    """Quantize float32 → INT4 packed (I32) + BF16 group scales.

    Returns (packed_i32[out, in//8], scale_bf16[out, in//group_size],
             shape_i32[2]).
    """
    import numpy as np
    out_dim, in_dim = w_f32.shape
    assert in_dim % group_size == 0, f"in_dim {in_dim} not multiple of {group_size}"
    n_groups = in_dim // group_size
    groups = w_f32.reshape(out_dim, n_groups, group_size)
    amax = np.abs(groups).max(axis=-1, keepdims=True)  # (out, g, 1)
    scale = amax / 7.0  # int4 signed: max absolute = 7
    scale = np.where(scale > 0, scale, 1.0)
    q = np.round(groups / scale).clip(-8, 7).astype(np.int8)
    q_flat = q.reshape(out_dim, in_dim)
    # Pack 8 int4s per int32, lsb-first.
    assert in_dim % 8 == 0, f"in_dim {in_dim} not multiple of 8"
    q_u4 = (q_flat.astype(np.int32) & 0xF).astype(np.uint32)  # (out, in)
    q_grouped = q_u4.reshape(out_dim, in_dim // 8, 8)
    packed = np.zeros((out_dim, in_dim // 8), dtype=np.uint32)
    for j in range(8):
        packed |= (q_grouped[..., j] << (4 * j))
    packed_i32 = packed.view(np.int32)
    scale_bf16 = scale.squeeze(-1).astype(np.float32)  # numpy has no native bf16
    shape_i32 = np.array([out_dim, in_dim], dtype=np.int32)
    return packed_i32, scale_bf16, shape_i32


# ---------- plan-driven rewrite --------------------------------------------


def _index_shards(src: Path):
    """Return: {tensor_key: (shard_idx, shard_path)}, [shard_path_list]."""
    from safetensors import safe_open
    shards = sorted(src.glob("model-*.safetensors"))
    idx: dict[str, tuple[int, Path]] = {}
    for i, sp in enumerate(shards):
        with safe_open(sp, framework="numpy") as f:
            for k in f.keys():
                idx[k] = (i, sp)
    return idx, shards


def _layer_experts(key_index, layer: int):
    """Return per-expert tensor keys for a layer: {expert: {proj: {kind: key}}}."""
    experts: dict[int, dict[str, dict[str, str]]] = {}
    for k in key_index:
        m = EXPERT_TENSOR_RE.match(k)
        if not m or int(m.group("layer")) != layer:
            continue
        e = int(m.group("expert"))
        experts.setdefault(e, {}).setdefault(m.group("proj"), {})[m.group("kind")] = k
    return experts


def _load_expert_weights(src: Path, keys_by_shard: dict, key_names: dict):
    """Load one expert's (packed, scale, shape) for all 3 projs via safetensors."""
    from safetensors import safe_open
    out = {}
    # Group keys by shard for fewer opens.
    shard_to_keys = {}
    for proj, kinds in key_names.items():
        for kind, k in kinds.items():
            shard = keys_by_shard[k]
            shard_to_keys.setdefault(shard, []).append((proj, kind, k))
    for shard, items in shard_to_keys.items():
        with safe_open(shard, framework="numpy") as f:
            for proj, kind, k in items:
                out.setdefault(proj, {})[kind] = f.get_tensor(k)
    return out


def execute(cfg: PruneConfig):
    import numpy as np
    from safetensors.numpy import save_file

    plan = json.loads(cfg.plan_path.read_text())
    per_layer = {l["layer"]: l for l in plan["per_layer"]}

    cfg.dst.mkdir(parents=True, exist_ok=True)

    print(f"[prune] indexing source shards in {cfg.src}", flush=True)
    key_index, shards = _index_shards(cfg.src)
    key_to_shard = {k: p for k, (_, p) in key_index.items()}
    print(f"[prune] {len(key_index)} tensor keys, {len(shards)} shards",
          flush=True)

    # Precompute merged expert weights per (layer, kept_expert_slot).
    # merged[(L, new_slot)] = {proj: {packed/scale/shape}}
    merged: dict[tuple[int, int], dict[str, dict]] = {}
    # renumber[L][old_expert_idx] = new_slot (or -1 if dropped and not merged-into)
    renumber: dict[int, dict[int, int]] = {}

    # Collect all layers we need to process.
    all_layers_with_experts = sorted({
        int(EXPERT_TENSOR_RE.match(k).group("layer"))
        for k in key_index if EXPERT_TENSOR_RE.match(k)
    })
    print(f"[prune] MoE layers present: {len(all_layers_with_experts)}  "
          f"first={all_layers_with_experts[0]} last={all_layers_with_experts[-1]}",
          flush=True)

    for L in all_layers_with_experts:
        if L not in per_layer:
            # Layer missing from plan — keep all experts (no-op).
            exps = _layer_experts(key_index, L)
            renumber[L] = {e: e for e in sorted(exps.keys())}
            continue

        lp = per_layer[L]
        keep_ids = lp["keep"]
        drop_ids = lp["drop"]
        absorb = {int(k): int(v) for k, v in lp["absorb_plan"].items()}
        keep_slot = {old: new for new, old in enumerate(sorted(keep_ids))}
        renumber[L] = {}
        for old in keep_ids:
            renumber[L][old] = keep_slot[old]
        for old in drop_ids:
            renumber[L][old] = -1  # marker: do not emit

        if cfg.absorb_merge and drop_ids:
            exps = _layer_experts(key_index, L)
            # Load kept experts in BF16 (dequantized) space, lazily per-merge.
            kept_bf = {}   # kept_old -> {proj: f32 weight}
            kept_w_freq = {}  # prime with freq from profile (approx — we don't have it here)
            # We proxy freq-weight from the plan's implicit info: absorb_plan
            # targets already reflect coact. For the blend we use equal weights
            # unless the plan provides per-expert weights (future extension).
            for drop_e, keep_e in absorb.items():
                if keep_e not in kept_bf:
                    kept_bf[keep_e] = {}
                    for proj, kinds in exps[keep_e].items():
                        w = _load_expert_weights(
                            cfg.src, key_to_shard,
                            {proj: kinds}
                        )[proj]
                        kept_bf[keep_e][proj] = unpack_int4(
                            w["weight_packed"], w["weight_scale"],
                            w["weight_shape"])
                drop_w = _load_expert_weights(
                    cfg.src, key_to_shard, exps[drop_e])
                for proj in ("gate_proj", "up_proj", "down_proj"):
                    d_bf = unpack_int4(
                        drop_w[proj]["weight_packed"],
                        drop_w[proj]["weight_scale"],
                        drop_w[proj]["weight_shape"])
                    # Damped convex blend. damping < 1 biases toward kept.
                    w_keep = 1.0 / (1.0 + cfg.absorb_damping)
                    w_drop = cfg.absorb_damping / (1.0 + cfg.absorb_damping)
                    kept_bf[keep_e][proj] = (
                        w_keep * kept_bf[keep_e][proj] + w_drop * d_bf
                    )
            # Re-quantize merged kept experts and stash under their new slot.
            for keep_old, projs in kept_bf.items():
                new_slot = keep_slot[keep_old]
                merged[(L, new_slot)] = {}
                for proj, w in projs.items():
                    p, s, shp = pack_int4(w)
                    merged[(L, new_slot)][proj] = {
                        "weight_packed": p,
                        "weight_scale": s,
                        "weight_shape": shp,
                    }
        if L % 10 == 0:
            print(f"  layer {L}: kept {len(keep_ids)}, dropped {len(drop_ids)}, "
                  f"merged-into {len(set(absorb.values()))}", flush=True)

    # Rewrite shards: for each source shard, walk keys and emit mapped ones.
    n_dropped_keys = 0
    n_merged_keys = 0
    n_passthrough = 0
    for shard_idx, sp in enumerate(shards):
        from safetensors import safe_open
        out_tensors = {}
        with safe_open(sp, framework="numpy") as f:
            for k in f.keys():
                m = EXPERT_TENSOR_RE.match(k)
                if m:
                    L = int(m.group("layer"))
                    e = int(m.group("expert"))
                    proj = m.group("proj")
                    kind = m.group("kind")
                    new_slot = renumber.get(L, {}).get(e, e)
                    if new_slot == -1:
                        n_dropped_keys += 1
                        continue
                    new_key = (f"{m.group('prefix')}{L}.mlp.experts."
                               f"{new_slot}.{proj}.{kind}")
                    if (L, new_slot) in merged and proj in merged[(L, new_slot)]:
                        # Use merged tensor for this kind.
                        out_tensors[new_key] = merged[(L, new_slot)][proj][kind]
                        n_merged_keys += 1
                    else:
                        out_tensors[new_key] = f.get_tensor(k)
                    continue
                m = ROUTER_W_RE.match(k)
                if m:
                    L = int(m.group("layer"))
                    kind = m.group("kind")
                    if L not in per_layer:
                        out_tensors[k] = f.get_tensor(k)
                        continue
                    keep_ids = sorted(per_layer[L]["keep"])
                    arr = f.get_tensor(k)
                    import numpy as np
                    if kind == "weight":
                        new_arr = np.asarray(arr)[keep_ids, :]
                    else:
                        new_arr = np.asarray(arr)[keep_ids]
                    out_tensors[k] = new_arr
                    continue
                # Passthrough for all other tensors (attention, norms, embed,
                # shared_expert, first dense layer, etc.)
                out_tensors[k] = f.get_tensor(k)
                n_passthrough += 1

        dst_shard = cfg.dst / sp.name
        save_file(out_tensors, str(dst_shard))
        print(f"  shard {shard_idx + 1}/{len(shards)}  -> {dst_shard.name}  "
              f"({len(out_tensors)} tensors)", flush=True)

    # Patch config.json for the new expert count.
    cfg_src = json.loads((cfg.src / "config.json").read_text())
    text_cfg = cfg_src.get("text_config", cfg_src)
    # Use uniform n_routed_experts across layers (assumes adaptive plan still
    # uses the same per-layer target for simplicity; if mixed, we write the
    # max and include a side file per-layer).
    per_layer_keep = {l["layer"]: l["n_keep"] for l in plan["per_layer"]}
    unique = sorted(set(per_layer_keep.values()))
    if len(unique) == 1:
        text_cfg["n_routed_experts"] = unique[0]
    else:
        # Non-uniform — keep max and write sidecar.
        text_cfg["n_routed_experts"] = max(unique)
        text_cfg["n_routed_experts_per_layer"] = per_layer_keep
    if "text_config" in cfg_src:
        cfg_src["text_config"] = text_cfg
    else:
        cfg_src = text_cfg
    with (cfg.dst / "config.json").open("w") as f:
        json.dump(cfg_src, f, indent=2)

    # Copy tokenizer/processor/other non-weight files.
    for p in cfg.src.iterdir():
        if p.is_file() and not p.name.endswith(".safetensors") \
                and p.name != "config.json":
            shutil.copy2(p, cfg.dst / p.name)

    print(f"[prune] done. passthrough={n_passthrough} dropped={n_dropped_keys} "
          f"merged={n_merged_keys}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, type=Path)
    ap.add_argument("--dst", required=True, type=Path)
    ap.add_argument("--plan", required=True, type=Path)
    ap.add_argument("--no-absorb-merge", action="store_true")
    ap.add_argument("--absorb-damping", type=float, default=0.5)
    args = ap.parse_args()
    execute(PruneConfig(
        src=args.src, dst=args.dst, plan_path=args.plan,
        absorb_merge=not args.no_absorb_merge,
        absorb_damping=args.absorb_damping,
    ))


if __name__ == "__main__":
    main()
