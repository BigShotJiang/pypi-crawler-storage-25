"""
Qwen3.5-35B-A3B-JANG-MXRQ2 Conversion
Created by Jinho Jang (eric@jangq.ai)

Mixed-precision RotorQuant: Givens rotation + Lloyd-Max codebook.
Per-layer bit allocation JANG-style.

Credit: RotorQuant/PlanarQuant rotation from scrya-com/rotorquant (2026).
"""
import sys, json, gc, time, shutil, re
import numpy as np
import mlx.core as mx
from pathlib import Path
from tqdm import tqdm
from safetensors import safe_open
from safetensors.numpy import save_file

sys.path.insert(0, "/Users/eric/jang/jang-tools")
from jang_tools.fp8 import load_fp8_tensor
from jang_tools.calibrate import _load_bf16_tensor
from jang_tools.turboquant.rq_quantize import rq_quantize_weight

SRC = Path("/Users/eric/models/Qwen3.5-35B-A3B-FP8")
OUT = Path("/Users/eric/models/Qwen3.5-35B-A3B-JANG-MXRQ2")
OUT.mkdir(exist_ok=True)
SEED = 42

with open(SRC / "config.json") as _f:
    config = json.load(_f)
tc = config.get("text_config", config)
layer_types = tc.get("layer_types", [])


def get_bits_and_method(name):
    """JANG-style per-tensor bit allocation for MXRQ2."""
    n = name.lower()

    # === PASSTHROUGH fp16 (tiny or critical-exact tensors) ===
    if "norm" in n or name.endswith(".bias"):
        return 16, "pass"
    if "visual" in n or "patch_embed" in n or "merger" in n or "pos_embed" in n:
        return 16, "pass"
    if "mtp." in n:  # multi-token prediction head
        return 16, "pass"
    if "conv1d" in n:  # SSM causal conv (tiny, critical)
        return 16, "pass"
    if "a_log" in n or "dt_bias" in n:  # SSM state params
        return 16, "pass"
    # Router gates — fp16 passthrough (precision critical for expert selection)
    if ".gate." in n and "gate_proj" not in n:
        return 16, "pass"
    if "shared_expert_gate" in n:
        return 16, "pass"

    # === AFFINE 8-bit (embeddings, lm_head) ===
    if "embed_tokens" in n or "lm_head" in n:
        return 8, "affine"

    # === MXRQ 4-bit (full attention — 10 layers, most critical) ===
    if "self_attn" in n:
        return 4, "mxrq"

    # === MXRQ 3-bit (linear attention SSM projections + shared expert) ===
    if "linear_attn" in n:
        return 3, "mxrq"
    if "shared_expert" in n and "gate" not in n:
        return 3, "mxrq"

    # === MXRQ 2-bit (routed experts — 94% of model) ===
    if "experts" in n:
        return 2, "mxrq"

    # === Fallback ===
    return 4, "affine"


print("=" * 60)
print("  Qwen3.5-35B-A3B-JANG-MXRQ2")
print("  Created by Jinho Jang (eric@jangq.ai)")
print("  RotorQuant rotation credit: scrya-com/rotorquant")
print("=" * 60)
print(f"  Source: {SRC}")
print(f"  Output: {OUT}")
print(f"  Profile: MXRQ2")
print(f"    full_attn:   mxrq-4 (10 layers)")
print(f"    linear_attn: mxrq-3 (30 layers)")
print(f"    shared_exp:  mxrq-3")
print(f"    routed_exp:  mxrq-2 (256 experts)")
print(f"    embed/head:  affine-8")
print(f"    vision/ssm:  fp16 passthrough")
print(flush=True)

# Scan tensors
all_tensors = []
for sf in sorted(SRC.glob("model.safetensors-*-of-*.safetensors")):
    with safe_open(str(sf), framework="numpy") as f:
        for k in f.keys():
            if k.endswith("_scale_inv"):
                continue
            shape = list(f.get_slice(k).get_shape())
            all_tensors.append((k, shape, sf))
print(f"  Tensors: {len(all_tensors)}", flush=True)

# Count per method
method_counts = {"pass": 0, "affine": 0, "mxrq": 0}
bit_counts = {}
for k, shape, _ in all_tensors:
    bits, method = get_bits_and_method(k)
    method_counts[method] += 1
    bk = f"{method}-{bits}"
    bit_counts[bk] = bit_counts.get(bk, 0) + 1

print("  Allocation:")
for bk, cnt in sorted(bit_counts.items()):
    print(f"    {bk}: {cnt} tensors")
print(flush=True)

# Convert
shard_idx = 0
shard_tensors = {}
shard_bytes = 0
MAX_SHARD = 1_000_000_000
shard_map = {}


def flush_shard():
    global shard_idx, shard_tensors, shard_bytes, shard_map
    if not shard_tensors:
        return
    shard_idx += 1
    fname = f"model-{shard_idx:05d}-of-XXXXX.safetensors"
    save_file(shard_tensors, str(OUT / fname))
    for k in shard_tensors:
        shard_map[k] = fname
    shard_tensors = {}
    shard_bytes = 0


def add_tensor(name, arr):
    global shard_tensors, shard_bytes
    shard_tensors[name] = arr
    shard_bytes += arr.nbytes
    if shard_bytes >= MAX_SHARD:
        flush_shard()


print("\n  Converting...", flush=True)
for tensor_name, shape, sf_path in tqdm(all_tensors, desc="  Processing"):
    bits, method = get_bits_and_method(tensor_name)

    # Load tensor from FP8 source
    with safe_open(str(sf_path), framework="numpy") as f:
        scale_key = tensor_name + "_scale_inv"
        try:
            scale = f.get_tensor(scale_key)
        except Exception:
            scale = None
        try:
            tensor = load_fp8_tensor(sf_path, tensor_name, shape, scale)
        except Exception:
            try:
                tensor = f.get_tensor(tensor_name)
                if not isinstance(tensor, np.ndarray):
                    tensor = np.array(tensor)
            except (TypeError, Exception):
                tensor = _load_bf16_tensor(sf_path, tensor_name, shape)

    if tensor.dtype != np.float32:
        tensor = tensor.astype(np.float32)

    base = tensor_name.replace(".weight", "") if tensor_name.endswith(".weight") else tensor_name

    if method == "pass":
        add_tensor(tensor_name, tensor.astype(np.float16))

    elif method == "affine":
        w = mx.array(tensor.astype(np.float16))
        qw, qs, qb = mx.quantize(w, group_size=64, bits=bits)
        add_tensor(f"{base}.weight", np.array(qw))
        add_tensor(f"{base}.scales", np.array(qs).astype(np.float16))
        add_tensor(f"{base}.biases", np.array(qb).astype(np.float16))

    elif method == "mxrq":
        if tensor.ndim >= 3:
            # Per-expert for stacked 3D tensors
            n_exp = tensor.shape[0]
            all_packed, all_norms = [], []
            for e in range(n_exp):
                r = rq_quantize_weight(tensor[e], bits=bits, seed=SEED)
                all_packed.append(r["packed"])
                all_norms.append(r["norms"])
                if e % 64 == 63:
                    gc.collect()
                    mx.clear_cache()
            add_tensor(f"{base}.rq_packed", np.stack(all_packed))
            add_tensor(f"{base}.rq_norms", np.stack(all_norms))
        else:
            r = rq_quantize_weight(tensor, bits=bits, seed=SEED)
            add_tensor(f"{base}.rq_packed", r["packed"])
            add_tensor(f"{base}.rq_norms", r["norms"])
        add_tensor(f"{base}.rq_bits", np.array([bits], dtype=np.uint8))
        # Store original shape for non-power-of-2 bit widths (3-bit padding issue)
        if tensor.ndim >= 3:
            add_tensor(f"{base}.rq_shape", np.array(tensor.shape[1:], dtype=np.int32))
        else:
            add_tensor(f"{base}.rq_shape", np.array(tensor.shape, dtype=np.int32))

    del tensor
    if method_counts["mxrq"] > 0 and shard_idx % 5 == 0:
        gc.collect()

flush_shard()

# Fix shard names
total_size = 0
for i in range(1, shard_idx + 1):
    old = OUT / f"model-{i:05d}-of-XXXXX.safetensors"
    new = OUT / f"model-{i:05d}-of-{shard_idx:05d}.safetensors"
    if old.exists():
        total_size += old.stat().st_size
        old.rename(new)
shard_map = {k: v.replace("XXXXX", f"{shard_idx:05d}") for k, v in shard_map.items()}

# Write index
index = {"metadata": {"total_size": total_size}, "weight_map": shard_map}
# M125 (iter 48): context-manage writes so the buffer flushes + fd closes.
with open(OUT / "model.safetensors.index.json", "w") as _f:
    json.dump(index, _f, indent=2)

# Config
config.pop("quantization_config", None)
config["quantization"] = {"group_size": 64, "bits": 2}
with open(OUT / "config.json", "w") as _f:
    json.dump(config, _f, indent=2)

# JANG config
jang_cfg = {
    "format_version": "2.0",
    "weight_format": "mxrq",
    "profile": "MXRQ2",
    "rotation": "givens",
    "rotation_credit": "scrya-com/rotorquant (PlanarQuant)",
    "mxrq_seed": SEED,
    "mxrq_bits": {
        "full_attention": 4,
        "linear_attention": 3,
        "shared_expert": 3,
        "routed_expert": 2,
        "embeddings": 8,
        "vision": 16,
        "ssm_params": 16,
    },
}
# Stamp Tier-1 capabilities for vmlx CapabilityDetector. Idempotent.
from jang_tools.capabilities import build_capabilities
_caps = build_capabilities(jang_cfg, config, OUT)
if _caps is not None:
    jang_cfg["capabilities"] = _caps
    print(f"  capabilities: family={_caps['family']} reasoning={_caps['reasoning_parser']} "
          f"tool={_caps['tool_parser']} cache={_caps['cache_type']} modality={_caps['modality']}",
          flush=True)
else:
    print("  WARNING: could not resolve capabilities — vmlx will fall back to "
          "silver/bronze. Add the family to jang_tools/capabilities.py::FAMILY_MAP.",
          flush=True)

with open(OUT / "jang_config.json", "w") as _f:
    json.dump(jang_cfg, _f, indent=2)

# Validate the final jang_config — catch schema drift / typos / missing keys.
from jang_tools.capabilities import verify_directory
_ok, _msg = verify_directory(OUT)
print(f"  verify: {_msg}")
if not _ok:
    raise SystemExit(f"capabilities verify failed: {_msg}")

# Copy tokenizer + support files
for f in ["tokenizer.json", "tokenizer_config.json", "special_tokens_map.json",
          "generation_config.json", "chat_template.jinja"]:
    s = SRC / f
    if s.exists():
        shutil.copy2(str(s), str(OUT / f))
# Tokenizer from separate dir if exists
tok_src = Path("/Users/eric/models/Qwen3.5-35B-A3B-FP8-tokenizer")
if tok_src.exists():
    for f in tok_src.glob("*"):
        if f.is_file() and not (OUT / f.name).exists():
            shutil.copy2(str(f), str(OUT / f.name))
for f in SRC.glob("*.py"):
    shutil.copy2(str(f), str(OUT / f.name))

print(f"\n{'='*60}")
print(f"  DONE: Qwen3.5-35B-A3B-JANG-MXRQ2")
print(f"  Shards: {shard_idx}, Size: {total_size/1e9:.1f} GB")
for bk, cnt in sorted(bit_counts.items()):
    print(f"    {bk}: {cnt}")
print(f"{'='*60}")
