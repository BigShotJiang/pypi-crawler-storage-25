"""
JANG FP8 Sequential Calibration + GPTQ Conversion.
Created by Jinho Jang (eric@jangq.ai)

Layer-by-layer: load FP8 weights → forward pass → capture Hessian → GPTQ quantize.
Avoids loading the full 744B model. Memory: ~3-5 GB per layer.
"""

import json
import gc
import time
import numpy as np
from pathlib import Path
from typing import Optional

from .fp8 import load_fp8_tensor
from .calibrate import _load_bf16_tensor
from safetensors import safe_open


def _load_layer_weights(model_path: Path, layer_idx: int) -> dict:
    """Load all weights for a single layer from FP8 safetensors."""
    prefix = f"model.layers.{layer_idx}."
    weights = {}
    for sf_path in sorted(model_path.glob("model-*.safetensors")):
        with safe_open(str(sf_path), framework="numpy") as f:
            for key in f.keys():
                if not key.startswith(prefix) or key.endswith("_scale_inv"):
                    continue
                shape = list(f.get_slice(key).get_shape())
                scale_key = key + "_scale_inv"
                try:
                    scale = f.get_tensor(scale_key)
                except Exception:
                    scale = None
                try:
                    tensor = load_fp8_tensor(sf_path, key, shape, scale)
                except Exception:
                    try:
                        tensor = f.get_tensor(key)
                        if hasattr(tensor, 'astype'):
                            tensor = tensor.astype(np.float32)
                    except (TypeError, Exception):
                        tensor = _load_bf16_tensor(sf_path, key, shape)
                local_key = key[len(prefix):]
                weights[local_key] = tensor.astype(np.float32)
    return weights


def _load_embeddings(model_path: Path) -> np.ndarray:
    """Load embed_tokens from FP8 model."""
    for sf_path in sorted(model_path.glob("model-*.safetensors")):
        with safe_open(str(sf_path), framework="numpy") as f:
            for key in f.keys():
                if "embed_tokens" in key and "scale_inv" not in key:
                    shape = list(f.get_slice(key).get_shape())
                    scale_key = key + "_scale_inv"
                    try:
                        scale = f.get_tensor(scale_key)
                    except Exception:
                        scale = None
                    try:
                        return load_fp8_tensor(sf_path, key, shape, scale).astype(np.float32)
                    except Exception:
                        return _load_bf16_tensor(sf_path, key, shape).astype(np.float32)
    raise RuntimeError("embed_tokens not found")


def _rmsnorm(x, weight, eps=1e-5):
    var = np.mean(x ** 2, axis=-1, keepdims=True)
    return x / np.sqrt(var + eps) * weight


def _silu(x):
    return x * (1.0 / (1.0 + np.exp(-np.clip(x, -20, 20))))


def calibrate_and_collect_hessians(
    model_path: str | Path,
    n_samples: int = 8,
    seq_len: int = 64,
    max_layers: Optional[int] = None,
) -> dict:
    """
    Sequential FP8 calibration: forward pass layer-by-layer, compute Hessians.

    Returns dict: {layer_idx: {"mlp_input_H": ndarray, "mlp_inter_H": ndarray}}
    - mlp_input_H: Hessian for gate_proj/up_proj input (hidden_size x hidden_size)
    - mlp_inter_H: Hessian for down_proj input (intermediate_size x intermediate_size)
    """
    model_path = Path(model_path)
    config = json.loads((model_path / "config.json").read_text())
    tc = config.get("text_config", config)

    hidden_size = tc["hidden_size"]
    n_layers = tc["num_hidden_layers"]
    vocab_size = tc["vocab_size"]
    first_dense = tc.get("first_k_dense_replace", 0)
    intermediate = tc.get("intermediate_size", hidden_size * 4)
    moe_intermediate = tc.get("moe_intermediate_size", intermediate)

    if max_layers:
        n_layers = min(n_layers, max_layers)

    print(f"FP8 Sequential Calibration")
    print(f"  Model: {model_path.name}")
    print(f"  Hidden: {hidden_size}, Layers: {n_layers}, Dense: {first_dense}")
    print(f"  Samples: {n_samples}, Seq len: {seq_len}")

    # Random calibration tokens
    np.random.seed(42)
    tokens = np.random.randint(0, vocab_size, (n_samples, seq_len), dtype=np.int32)

    # Embed
    print("  Loading embeddings...", flush=True)
    embed = _load_embeddings(model_path)
    hidden = embed[tokens]  # (n_samples, seq_len, hidden_size)
    del embed
    gc.collect()
    print(f"  Hidden: {hidden.shape}", flush=True)

    all_hessians = {}

    for li in range(n_layers):
        t0 = time.time()
        lw = _load_layer_weights(model_path, li)

        # RMSNorm before MLP
        norm_key = "post_attention_layernorm.weight"
        if norm_key not in lw:
            norm_key = "input_layernorm.weight"
        if norm_key in lw:
            h_normed = _rmsnorm(hidden, lw[norm_key])
        else:
            h_normed = hidden.copy()

        # Compute MLP input Hessian (for gate_proj / up_proj)
        X = h_normed.reshape(-1, hidden_size).astype(np.float64)
        n_tokens = X.shape[0]
        H_mlp_input = (X.T @ X) / n_tokens

        # Simple MLP forward (shared expert only) to propagate hidden states
        gw = lw.get("mlp.shared_expert.gate_proj.weight",
                     lw.get("mlp.gate_proj.weight"))
        uw = lw.get("mlp.shared_expert.up_proj.weight",
                     lw.get("mlp.up_proj.weight"))
        dw = lw.get("mlp.shared_expert.down_proj.weight",
                     lw.get("mlp.down_proj.weight"))

        H_mlp_inter = None
        if gw is not None and uw is not None and dw is not None:
            gate_out = _silu(h_normed @ gw.T)
            up_out = h_normed @ uw.T
            inter = gate_out * up_out  # intermediate activations

            # Compute intermediate Hessian (for down_proj)
            X_inter = inter.reshape(-1, inter.shape[-1]).astype(np.float64)
            H_mlp_inter = (X_inter.T @ X_inter) / n_tokens

            mlp_out = inter @ dw.T
            hidden = hidden + mlp_out.astype(np.float32)

        if li >= first_dense:
            all_hessians[li] = {
                "mlp_input_H": H_mlp_input.astype(np.float32),
            }
            if H_mlp_inter is not None:
                all_hessians[li]["mlp_inter_H"] = H_mlp_inter.astype(np.float32)

        elapsed = time.time() - t0
        print(f"  Layer {li:2d}: {elapsed:.1f}s  hidden=[{hidden.min():.3f},{hidden.max():.3f}]", flush=True)

        del lw
        gc.collect()

    return all_hessians
