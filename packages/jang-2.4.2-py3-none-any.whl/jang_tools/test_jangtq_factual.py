"""
JANGTQ factual battery test.
Created by Jinho Jang (eric@jangq.ai)

Runs a fixed 10-question factual probe on a JANGTQ model and reports
pass/fail.  Comparable across JANGTQ_1L / JANGTQ_2L so quality changes
are visible.

Usage:
    python3 -m jang_tools.test_jangtq_factual <model_path>
"""
import sys, re, time
from pathlib import Path

import mlx.core as mx


# 10-question factual battery.  Same set used in iter 133 tests on
# JANGTQ_1L (baseline 7/10 post hadamard-shmem fix).
PROMPTS = [
    ("capital_france",  "What is the capital of France? Answer in one word.",
        [r"paris"]),
    ("math_2_plus_2",   "What is 2+2? Answer with just the number.",
        [r"\b4\b"]),
    ("sky_color",       "What color is the sky on a clear sunny day? Answer with one word.",
        [r"blue"]),
    ("tallest_mountain", "What is the world's tallest mountain? One word.",
        [r"everest"]),
    ("water_formula",   "What is the chemical formula for water? Just the formula.",
        [r"h2o|h_{?2}?o|h₂o"]),
    ("earth_orbits",    "What does the Earth orbit? One word.",
        [r"sun"]),
    ("hamlet_author",   "Who wrote Hamlet? Just the name.",
        [r"shakespeare"]),
    ("us_independence", "In what year did the US declare independence? Just the year.",
        [r"1776"]),
    ("color_of_gold",   "What color is gold? One word.",
        [r"gold|yellow"]),
    ("continents",      "How many continents are there? Just the number.",
        [r"\b7\b|seven"]),
]


def run_factual(model_path: str, max_tokens: int = 40, verbose: bool = True):
    from jang_tools.load_jangtq import load_jangtq_model
    from mlx_lm.sample_utils import make_sampler
    from mlx_lm.generate import generate_step

    t0 = time.time()
    model, tok = load_jangtq_model(model_path)
    print(f"  model loaded in {time.time()-t0:.1f}s", flush=True)

    sampler = make_sampler(temp=0.0)
    EOS = list(tok.eos_token_ids) if hasattr(tok, "eos_token_ids") else [tok.eos_token_id]
    if isinstance(EOS, int):
        EOS = [EOS]
    print(f"  EOS={EOS}", flush=True)

    passed = 0
    for name, q, accepts in PROMPTS:
        prompt = tok.apply_chat_template(
            [{"role": "user", "content": q}],
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        tokens = tok.encode(prompt)
        gen = []
        for t, _logits in generate_step(
            prompt=mx.array(tokens), model=model,
            max_tokens=max_tokens, sampler=sampler,
        ):
            ti = int(t)
            gen.append(ti)
            if ti in EOS:
                break
        resp = tok.decode(gen).strip()
        matched = any(re.search(p, resp.lower()) for p in accepts)
        mark = "PASS" if matched else "FAIL"
        if matched:
            passed += 1
        if verbose:
            print(f"  {mark} [{name:18s}] resp={resp[:80]!r}", flush=True)

    print(f"\n  RESULT: {passed}/{len(PROMPTS)} passed", flush=True)
    return passed


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python3 -m jang_tools.test_jangtq_factual <model_path>",
              file=sys.stderr)
        sys.exit(1)
    run_factual(sys.argv[1])
