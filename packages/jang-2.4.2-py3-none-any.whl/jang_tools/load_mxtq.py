"""
MXTQ loader — dequants TQ weights at load time, re-quantizes to affine for QuantizedLinear.
Usage: from load_mxtq import load_mxtq_model
"""
import sys, json, gc, time
import numpy as np
import mlx.core as mx
import mlx.nn as nn
from pathlib import Path

from jang_tools.turboquant.codebook import compute_codebook
from jang_tools.turboquant.rotation import generate_random_signs, hadamard_inverse
from jang_tools.turboquant.pipeline import unpack_bits

AFFINE_GROUP_SIZE = 64


def _dequant_tq(packed, norms, bits, in_features, seed=42):
    """Dequant a single MXTQ tensor to float16. Vectorized — no per-row loop."""
    out_features = packed.shape[0]
    cb = mx.array(compute_codebook(in_features, bits))
    signs = mx.array(generate_random_signs(in_features, seed=seed))

    n_total = out_features * in_features
    idx_flat = unpack_bits(packed.reshape(-1), bits, n_total)
    w = mx.take(cb, idx_flat.astype(mx.uint32)).reshape(out_features, in_features)
    w = w * norms[:, None].astype(w.dtype)
    w = hadamard_inverse(w, signs)
    return w.astype(mx.float16)


def load_mxtq_model(model_path, skip_params_eval=False):
    """Load MXTQ2 model with TQ dequant at load time."""
    model_path = Path(model_path)
    # M125 (iter 48): context-manage reads so fds close deterministically.
    with open(model_path / "config.json") as _f:
        config = json.load(_f)

    jang_cfg_path = model_path / "jang_config.json"
    if jang_cfg_path.exists():
        with open(jang_cfg_path) as _f:
            jang_cfg = json.load(_f)
    else:
        jang_cfg = {}
    mxtq_seed = jang_cfg.get("mxtq_seed", 42)
    mxtq_bits_map = jang_cfg.get("mxtq_bits", {})

    print(f"Loading MXTQ2: {model_path.name}", flush=True)

    from mlx_lm.utils import load_config, load_model as _load_skeleton, load_tokenizer
    model_config = load_config(model_path)
    if "quantization" not in model_config:
        model_config["quantization"] = {"group_size": 64, "bits": 2}

    model, model_config = _load_skeleton(model_path, lazy=True, strict=False, model_config=model_config)

    weight_files = sorted(model_path.glob("model-*.safetensors"))
    if not weight_files:
        weight_files = sorted(model_path.glob("model.safetensors-*.safetensors"))

    print(f"  {len(weight_files)} shards", flush=True)

    _needs_vlm_remap = hasattr(model, "language_model") and "text_config" in model_config
    tq_count = 0
    all_weights = {}

    for shard_i, sf_path in enumerate(weight_files):
        weights = mx.load(str(sf_path))

        if _needs_vlm_remap:
            remapped = {}
            for k, v in weights.items():
                if k.startswith("model.language_model."):
                    remapped[k.replace("model.language_model.", "language_model.model.", 1)] = v
                elif k.startswith("lm_head."):
                    remapped["language_model." + k] = v
                else:
                    remapped[k] = v
            weights = remapped

        tq_groups = {}
        regular = {}
        for k, v in weights.items():
            if k.endswith(".tq_packed"):
                tq_groups.setdefault(k[:-10], {})["packed"] = v
            elif k.endswith(".tq_norms"):
                tq_groups.setdefault(k[:-9], {})["norms"] = v
            elif k.endswith(".tq_bits"):
                pass
            else:
                regular[k] = v

        for base, parts in tq_groups.items():
            if "packed" not in parts or "norms" not in parts:
                continue
            packed = parts["packed"]
            norms = parts["norms"]

            bl = base.lower()
            if "shared_expert" in bl:
                bits = mxtq_bits_map.get("shared_expert", 3)
            elif "expert" in bl:
                bits = mxtq_bits_map.get("routed_expert", 2)
            else:
                bits = 2

            vals_per_u32 = 32 // bits

            if packed.ndim == 3:
                n_exp, out_feat, packed_cols = packed.shape
                in_features = packed_cols * vals_per_u32
                expert_ws = []
                for e in range(n_exp):
                    w = _dequant_tq(packed[e], norms[e], bits, in_features, mxtq_seed)
                    expert_ws.append(w)
                    if e % 32 == 31:
                        mx.synchronize()
                dq = mx.stack(expert_ws)
                mx.synchronize()
                del expert_ws
            else:
                out_feat, packed_cols = packed.shape
                in_features = packed_cols * vals_per_u32
                dq = _dequant_tq(packed, norms, bits, in_features, mxtq_seed)
                mx.synchronize()

            qw, qs, qb = mx.quantize(dq, group_size=AFFINE_GROUP_SIZE, bits=2)
            mx.synchronize()
            del dq
            # Store as numpy to avoid Metal resource limit (499K mx.array cap)
            regular[f"{base}.weight"] = np.array(qw)
            regular[f"{base}.scales"] = np.array(qs)
            regular[f"{base}.biases"] = np.array(qb)
            del qw, qs, qb
            tq_count += 1

        # Also convert non-TQ tensors to numpy
        for k in list(regular.keys()):
            if isinstance(regular[k], mx.array):
                regular[k] = np.array(regular[k])

        all_weights.update(regular)
        del weights, regular
        gc.collect()
        if (shard_i + 1) % 10 == 0:
            print(f"  shard {shard_i + 1}/{len(weight_files)}, {tq_count} TQ tensors dequanted", flush=True)

    print(f"  All shards loaded ({len(all_weights)} keys as numpy)", flush=True)

    # Stack experts in numpy (avoids Metal resource limit from 180K mx.arrays)
    tc = config.get("text_config", config)
    n_layers = tc.get("num_hidden_layers", 78)
    n_experts = tc.get("n_routed_experts", 256)
    stacked_count = 0
    for l in range(n_layers):
        prefix = f"model.layers.{l}"
        for m_old, m_new in [("gate_proj", "gate_proj"), ("down_proj", "down_proj"), ("up_proj", "up_proj")]:
            for k in ["weight", "scales", "biases"]:
                first_key = f"{prefix}.mlp.experts.0.{m_old}.{k}"
                if first_key not in all_weights:
                    continue
                to_stack = []
                for e in range(n_experts):
                    ekey = f"{prefix}.mlp.experts.{e}.{m_old}.{k}"
                    to_stack.append(all_weights.pop(ekey))
                stacked = np.stack(to_stack)
                del to_stack
                all_weights[f"{prefix}.mlp.switch_mlp.{m_new}.{k}"] = stacked
                stacked_count += 1
        if (l + 1) % 10 == 0:
            gc.collect()
            print(f"    stacked layer {l + 1}/{n_layers}", flush=True)
    print(f"  Stacked {stacked_count} expert groups, {len(all_weights)} keys remain", flush=True)

    # Now convert to mx and load — much fewer arrays after stacking
    print(f"  Converting to mx + sanitize (non-expert keys)...", flush=True)
    for k in list(all_weights.keys()):
        if isinstance(all_weights[k], np.ndarray):
            all_weights[k] = mx.array(all_weights[k])
    mx.synchronize()

    # Run sanitize for non-expert transforms (kv_b_proj split, MTP removal, etc.)
    if hasattr(model, "sanitize"):
        all_weights = model.sanitize(all_weights)
    gc.collect()
    print(f"  Post-sanitize: {len(all_weights)} keys", flush=True)

    model.load_weights(list(all_weights.items()), strict=False)
    del all_weights
    gc.collect()

    sys.path.insert(0, "/Users/eric/mlx/vllm-mlx")
    from vmlx_engine.utils.jang_loader import _fix_quantized_bits
    _fix_quantized_bits(model)

    tc = model_config.get("text_config", model_config)
    if tc.get("kv_lora_rank", 0) > 0 or tc.get("model_type", "") == "glm_moe_dsa":
        model.set_dtype(mx.bfloat16)
        print("  bfloat16 enabled", flush=True)

    if not skip_params_eval:
        mx.synchronize()

    tokenizer = load_tokenizer(model_path)
    print(f"  Done: {tq_count} MXTQ tensors dequanted", flush=True)
    return model, tokenizer
