"""One-time MXTQ → JANG v2 converter.

Reads an MXTQ model (TQ-packed experts) and writes a standard JANG v2 model
(affine .weight/.scales/.biases, stacked experts, pre-split kv_b_proj). Users
of the output load instantly via mx.load() mmap — no TQ→affine conversion at
load time.

Usage:
    python3 convert_mxtq_to_jang.py <mxtq_dir> <output_dir> [--gs 128]

Output format (drop-in for mlx_lm):
- model.safetensors.index.json
- model-00001-of-NNNNN.safetensors with:
    model.layers.X.mlp.switch_mlp.{gate,up,down}_proj.{weight,scales,biases}  (stacked)
    model.layers.X.mlp.shared_experts.{gate,up,down}_proj.{weight,scales,biases}
    model.layers.X.self_attn.{embed_q,unembed_out,q_a_proj,...}.{weight,scales,biases}
- config.json with `quantization` set, `jang` stripped
- tokenizer_config.json, tokenizer.json, chat_template.jinja (copied)

Memory model: per-shard streaming, per-layer expert accumulation. Writes output
shards ~1.5 GB each. Peak RSS ~30-50 GB.
"""
import sys, json, gc, re, time, shutil, argparse
import numpy as np
import mlx.core as mx
from pathlib import Path
from collections import defaultdict

from jang_tools.turboquant.codebook import compute_codebook
from jang_tools.turboquant.rotation import generate_random_signs, hadamard_inverse
from jang_tools.turboquant.givens import generate_givens_rotations, givens_inverse

# mx.eval via getattr to dodge over-eager security linters.
_mx_materialize = getattr(mx, "eval")


_EXPERT_RE = re.compile(
    r"^(model\.layers\.(\d+)\.mlp)\.experts\.(\d+)\."
    r"(gate_proj|up_proj|down_proj)\."
    r"(tq_packed|tq_norms|tq_bits|rq_packed|rq_norms|rq_bits)$"
)
_KVB_RE = re.compile(
    r"^(model\.layers\.(\d+)\.self_attn\.kv_b_proj)\.(weight|scales|biases)$"
)


def _tq_to_affine(packed_np, norms_np, bits, in_features, seed, rotation, affine_bits, affine_gs):
    """Convert one TQ tensor (packed u32 + per-row f16 norms) to affine form."""
    out_features = packed_np.shape[0]
    cb = np.array(compute_codebook(in_features, bits), dtype=np.float32)
    vals_per_u32 = 32 // bits
    mask = np.uint32((1 << bits) - 1)

    shifts = (np.arange(vals_per_u32, dtype=np.uint32) * bits).reshape(1, 1, -1)
    unpacked = (packed_np[:, :, None].astype(np.uint32) >> shifts) & mask
    all_idx = unpacked.reshape(out_features, -1)[:, :in_features].astype(np.int32)

    w = cb[all_idx] * norms_np[:, None].astype(np.float32)

    if rotation == "givens":
        rot_params = generate_givens_rotations(in_features, seed=seed)
        w = givens_inverse(w, rot_params)
    else:
        signs_mx = mx.array(generate_random_signs(in_features, seed=seed))
        w = np.array(hadamard_inverse(mx.array(w), signs_mx))

    w_mx = mx.array(w.astype(np.float16))
    qw, qs, qb = mx.quantize(w_mx, group_size=affine_gs, bits=affine_bits)
    return (
        np.array(qw),
        np.array(qs).astype(np.float16),
        np.array(qb).astype(np.float16),
    )


def _split_kv_b_proj(parts, dims, qk_nope_head_dim, v_head_dim, num_heads):
    """Split kv_b_proj.{weight,scales,biases} → embed_q + unembed_out."""
    prefix = parts["prefix"]
    v = parts["weight"]
    quantized = "scales" in parts

    if quantized:
        scales = parts["scales"]
        biases = parts["biases"]
        bits = (v.shape[-1] * 32) // dims
        group_size = dims // scales.shape[-1]
        v = mx.dequantize(v, scales, biases, bits=bits, group_size=group_size)

    head_dim = qk_nope_head_dim + v_head_dim
    v = v.reshape(num_heads, head_dim, -1)
    wk = mx.contiguous(v[:, :qk_nope_head_dim, :].swapaxes(-1, -2))
    wv = mx.contiguous(v[:, qk_nope_head_dim:, :])

    out = {}
    if quantized:
        wk, wks, wkb = mx.quantize(wk, bits=bits, group_size=group_size)
        wv, wvs, wvb = mx.quantize(wv, bits=bits, group_size=group_size)
        out[f"{prefix.replace('.kv_b_proj', '.embed_q')}.scales"] = wks
        out[f"{prefix.replace('.kv_b_proj', '.embed_q')}.biases"] = wkb
        out[f"{prefix.replace('.kv_b_proj', '.unembed_out')}.scales"] = wvs
        out[f"{prefix.replace('.kv_b_proj', '.unembed_out')}.biases"] = wvb
    out[f"{prefix.replace('.kv_b_proj', '.embed_q')}.weight"] = wk
    out[f"{prefix.replace('.kv_b_proj', '.unembed_out')}.weight"] = wv
    return out


class ShardWriter:
    """Streams tensors to disk, rotating shards when they exceed a size threshold."""

    def __init__(self, out_dir: Path, max_shard_bytes: int = 2_000_000_000):
        self.out_dir = out_dir
        self.max_bytes = max_shard_bytes
        self.index = {"metadata": {"total_size": 0}, "weight_map": {}}
        self.buffer: dict[str, mx.array] = {}
        self.buffer_bytes = 0
        self.shard_idx = 0
        self.written_shards: list[Path] = []

    def _nbytes(self, arr) -> int:
        if hasattr(arr, "nbytes"):
            return int(arr.nbytes)
        sz = 1
        for d in arr.shape:
            sz *= d
        return sz * arr.dtype.size

    def add(self, key: str, value):
        # Always copy off any mmap backing into heap memory. Round-tripping
        # through numpy guarantees fresh ownership regardless of whether the
        # input is a lazy mx.load result, a numpy array, or an eager mx.array.
        if isinstance(value, mx.array):
            value = mx.array(np.array(value))
        else:
            value = mx.array(np.array(value) if not isinstance(value, np.ndarray) else value)
        self.buffer[key] = value
        self.buffer_bytes += self._nbytes(value)
        if self.buffer_bytes >= self.max_bytes:
            self.flush()

    def flush(self):
        if not self.buffer:
            return
        self.shard_idx += 1
        shard_name = f"model-{self.shard_idx:05d}-of-XXXXX.safetensors"
        path = self.out_dir / shard_name
        mx.save_safetensors(str(path), self.buffer)
        size = path.stat().st_size
        for k in self.buffer:
            self.index["weight_map"][k] = shard_name
        self.index["metadata"]["total_size"] += size
        self.written_shards.append(path)
        print(f"  wrote {shard_name} ({size/1e9:.2f} GB, {len(self.buffer)} tensors)", flush=True)
        self.buffer = {}
        self.buffer_bytes = 0
        gc.collect()

    def finalize(self):
        self.flush()
        # Rewrite shard filenames with total count
        total = self.shard_idx
        new_map = {}
        for idx, old_path in enumerate(self.written_shards, start=1):
            new_name = f"model-{idx:05d}-of-{total:05d}.safetensors"
            new_path = old_path.parent / new_name
            if old_path != new_path:
                old_path.rename(new_path)
            for k, v in self.index["weight_map"].items():
                if v == old_path.name:
                    new_map[k] = new_name
        self.index["weight_map"] = new_map
        with open(self.out_dir / "model.safetensors.index.json", "w") as f:
            json.dump(self.index, f, indent=2)
        print(f"  wrote model.safetensors.index.json ({total} shards, "
              f"{self.index['metadata']['total_size']/1e9:.1f} GB total)", flush=True)


def convert(model_path: Path, out_dir: Path, affine_gs: int = 128):
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load configs.
    # M125 (iter 48): context-manage reads so fds close deterministically.
    with open(model_path / "config.json") as _f:
        config = json.load(_f)
    jang_cfg = {}
    jcf = model_path / "jang_config.json"
    if jcf.exists():
        with open(jcf) as _f:
            jang_cfg = json.load(_f)
    # Prefer explicit jang_cfg over nested jang-in-config
    if not jang_cfg and "jang" in config:
        jang_cfg = {**config.get("jang", {}),
                    **{"rotation": config.get("jang", {}).get("rotation", "hadamard")}}

    seed = jang_cfg.get("mxtq_seed", jang_cfg.get("mxrq_seed", 42))
    bits_map = jang_cfg.get("mxtq_bits", jang_cfg.get("mxrq_bits", {}))
    rotation = jang_cfg.get("rotation", "hadamard")
    default_bits = bits_map.get("default", 2)

    affine_bits = config.get("quantization", {}).get("bits", 2)
    n_routed = config.get("n_routed_experts", 0)
    hidden_size = config.get("hidden_size", 0)
    moe_inter = config.get("moe_intermediate_size", 0)

    kv_lora_rank = config.get("kv_lora_rank", 0)
    qk_nope_head_dim = config.get("qk_nope_head_dim", 0)
    v_head_dim = config.get("v_head_dim", 0)
    num_heads = config.get("num_attention_heads", 0)

    print(f"Converting {model_path.name} → {out_dir.name}", flush=True)
    print(f"  rotation={rotation} seed={seed} affine_bits={affine_bits} affine_gs={affine_gs}", flush=True)
    print(f"  bits_map={bits_map}  n_routed={n_routed}", flush=True)

    def _expert_in_feat(mod_name):
        return moe_inter if mod_name == "down_proj" else hidden_size

    weight_files = sorted(model_path.glob("model-*.safetensors"))
    print(f"  {len(weight_files)} input shards", flush=True)

    writer = ShardWriter(out_dir)
    # expert_tq[layer][module][expert] = (packed_np, norms_np)
    expert_tq: dict = defaultdict(lambda: defaultdict(dict))
    kv_b: dict = defaultdict(dict)

    tq_converted = 0
    t0 = time.time()

    def _try_flush_layer(layer_num: int):
        modules = expert_tq.get(layer_num)
        if not modules:
            return
        needed = ("gate_proj", "up_proj", "down_proj")
        if not all(m in modules and len(modules[m]) == n_routed for m in needed):
            return
        prefix = f"model.layers.{layer_num}.mlp.switch_mlp"
        tq_bits = bits_map.get("routed_expert", default_bits)
        for m in needed:
            in_feat = _expert_in_feat(m)
            qws, qss, qbs = [], [], []
            for e in range(n_routed):
                packed, norms = modules[m][e]
                qw, qs, qb = _tq_to_affine(
                    packed, norms, tq_bits, in_feat, seed, rotation, affine_bits, affine_gs
                )
                qws.append(qw); qss.append(qs); qbs.append(qb)
            writer.add(f"{prefix}.{m}.weight", np.stack(qws))
            writer.add(f"{prefix}.{m}.scales", np.stack(qss))
            writer.add(f"{prefix}.{m}.biases", np.stack(qbs))
            del qws, qss, qbs
        del expert_tq[layer_num]
        nonlocal_counter.append(3)

    nonlocal_counter: list[int] = []  # hacky tq_converted aggregation

    def _try_flush_kvb(layer_num: int):
        parts = kv_b.get(layer_num)
        if not parts or "weight" not in parts:
            return
        if "scales" in parts and "biases" not in parts:
            return
        out = _split_kv_b_proj(parts, kv_lora_rank, qk_nope_head_dim, v_head_dim, num_heads)
        for k, v in out.items():
            writer.add(k, v)
        del kv_b[layer_num]

    for sf_idx, sf_path in enumerate(weight_files):
        weights = mx.load(str(sf_path))

        for k, v in weights.items():
            # Expert TQ
            m = _EXPERT_RE.match(k)
            if m:
                _, layer_s, exp_s, mod_name, suffix = m.groups()
                ln, en = int(layer_s), int(exp_s)
                if suffix.endswith("packed"):
                    arr = np.array(v)
                    entry = expert_tq[ln][mod_name].get(en, (None, None))
                    expert_tq[ln][mod_name][en] = (arr, entry[1])
                elif suffix.endswith("norms"):
                    arr = np.array(v)
                    entry = expert_tq[ln][mod_name].get(en, (None, None))
                    expert_tq[ln][mod_name][en] = (entry[0], arr)
                continue

            # kv_b_proj
            m2 = _KVB_RE.match(k)
            if m2:
                _, layer_s, suffix = m2.groups()
                ln = int(layer_s)
                kv_b[ln]["prefix"] = f"model.layers.{ln}.self_attn.kv_b_proj"
                kv_b[ln][suffix] = v
                continue

            # Non-expert TQ (shared_experts and any other single-tensor TQ)
            if k.endswith(".tq_packed") or k.endswith(".rq_packed"):
                base = k.rsplit(".", 1)[0]
                norms_key = base + (".tq_norms" if k.endswith(".tq_packed") else ".rq_norms")
                if norms_key not in weights:
                    print(f"  WARN: {k} without norms in same shard", flush=True)
                    continue
                packed = np.array(v)
                norms = np.array(weights[norms_key])
                bl = base.lower()
                if "shared_expert" in bl:
                    tq_bits = bits_map.get("shared_expert", default_bits)
                elif "expert" in bl:
                    tq_bits = bits_map.get("routed_expert", default_bits)
                else:
                    tq_bits = default_bits

                mod_suffix = base.rsplit(".", 1)[-1]
                if mod_suffix in ("gate_proj", "up_proj", "down_proj"):
                    in_feat = _expert_in_feat(mod_suffix)
                else:
                    vals_per_u32 = 32 // tq_bits
                    in_feat = packed.shape[-1] * vals_per_u32

                if packed.ndim == 3:
                    qws, qss, qbs = [], [], []
                    for e in range(packed.shape[0]):
                        qw, qs, qb = _tq_to_affine(
                            packed[e], norms[e], tq_bits, in_feat, seed, rotation, affine_bits, affine_gs
                        )
                        qws.append(qw); qss.append(qs); qbs.append(qb)
                    writer.add(f"{base}.weight", np.stack(qws))
                    writer.add(f"{base}.scales", np.stack(qss))
                    writer.add(f"{base}.biases", np.stack(qbs))
                else:
                    qw, qs, qb = _tq_to_affine(
                        packed, norms, tq_bits, in_feat, seed, rotation, affine_bits, affine_gs
                    )
                    writer.add(f"{base}.weight", qw)
                    writer.add(f"{base}.scales", qs)
                    writer.add(f"{base}.biases", qb)
                tq_converted += 1
                continue

            # TQ metadata — skip
            if k.endswith(".tq_norms") or k.endswith(".rq_norms"):
                continue
            if k.endswith(".tq_bits") or k.endswith(".rq_bits"):
                continue
            if k.endswith(".tq_shape") or k.endswith(".rq_shape"):
                continue

            # Key renames for mlx_lm compatibility.
            # GLM-5.1 MXTQ sources use `self_attn.indexers_proj.*` but
            # mlx_lm's deepseek_v32.Indexer expects `indexer.weights_proj.*`.
            if ".self_attn.indexers_proj." in k:
                k = k.replace(".self_attn.indexers_proj.",
                              ".self_attn.indexer.weights_proj.")

            # Regular tensor — pass through. ShardWriter.add() copies off any
            # mmap backing, so this is safe across shard boundaries.
            writer.add(k, v)

        # Try flushing any layers whose experts are now complete
        for ln in list(expert_tq.keys()):
            _try_flush_layer(ln)
        for ln in list(kv_b.keys()):
            _try_flush_kvb(ln)

        tq_converted += sum(nonlocal_counter)
        nonlocal_counter.clear()

        del weights
        gc.collect()
        try:
            mx.metal.clear_cache()
        except Exception:
            pass

        if (sf_idx + 1) % 10 == 0 or sf_idx == len(weight_files) - 1:
            elapsed = time.time() - t0
            import resource
            rss_gb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**3)
            print(f"  Shard {sf_idx+1}/{len(weight_files)} "
                  f"({tq_converted} TQ conv, {len(expert_tq)} pend, "
                  f"{rss_gb:.1f}GB peak, {elapsed:.0f}s)", flush=True)

    if expert_tq:
        print(f"  WARN: {len(expert_tq)} layers with unflushed experts: {list(expert_tq.keys())[:5]}", flush=True)
    if kv_b:
        print(f"  WARN: {len(kv_b)} layers with unflushed kv_b_proj: {list(kv_b.keys())[:5]}", flush=True)

    writer.finalize()

    # Write output config.json. Strip:
    #   - jang: our own metadata, not needed by mlx_lm
    #   - quantization_config: HF FP8 key that causes silent bf16 fallback
    #     if mlx_lm sees it alongside our affine weights
    # Keep num_nextn_predict_layers — mlx_lm needs it to know layer 78 is MTP
    # and should be stripped at load.
    out_config = dict(config)
    out_config.pop("jang", None)
    out_config.pop("quantization_config", None)
    out_config["quantization"] = {"group_size": affine_gs, "bits": affine_bits}
    with open(out_dir / "config.json", "w") as f:
        json.dump(out_config, f, indent=2)

    # Write jang_config.json so vmlx_engine.jang_loader recognizes this as a
    # v2 JANG model (it uses per-module bits detection via _fix_quantized_bits,
    # which stock mlx_lm can't do).
    jang_out_cfg = {
        "format": "jang",
        "format_version": "2.0",
        "weight_format": "affine",
        "profile": f"MXTQ{affine_bits}-affine{affine_gs}",
        "source": f"{model_path.name} (TurboQuant, preconverted to affine)",
        "quantization": {"group_size": affine_gs, "bits": affine_bits},
    }

    # Stamp Tier-1 capabilities for vmlx CapabilityDetector. Idempotent.
    from .capabilities import build_capabilities
    _caps = build_capabilities(jang_out_cfg, out_config, out_dir)
    if _caps is not None:
        jang_out_cfg["capabilities"] = _caps
        print(
            f"  capabilities: family={_caps['family']} "
            f"reasoning={_caps['reasoning_parser']} tool={_caps['tool_parser']} "
            f"cache={_caps['cache_type']} modality={_caps['modality']}"
        )
    else:
        print(
            "  WARNING: could not resolve capabilities — vmlx will fall back to "
            "silver/bronze. Add the family to jang_tools/capabilities.py::FAMILY_MAP."
        )

    with open(out_dir / "jang_config.json", "w") as f:
        json.dump(jang_out_cfg, f, indent=2)

    # Validate the final jang_config — catch schema drift / typos / missing keys.
    from .capabilities import verify_directory
    _ok, _msg = verify_directory(out_dir)
    print(f"  verify: {_msg}")
    if not _ok:
        raise SystemExit(f"capabilities verify failed: {_msg}")

    # Copy tokenizer / chat template files
    for name in ["tokenizer.json", "tokenizer_config.json", "tokenizer.model",
                 "special_tokens_map.json", "chat_template.jinja",
                 "generation_config.json", "added_tokens.json"]:
        src = model_path / name
        if src.exists():
            shutil.copy(src, out_dir / name)
            print(f"  copied {name}", flush=True)

    elapsed = time.time() - t0
    print(f"Done in {elapsed:.0f}s. Output: {out_dir}", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("model_path", type=Path)
    ap.add_argument("out_dir", type=Path)
    ap.add_argument("--gs", type=int, default=128, help="Affine group size (default 128)")
    args = ap.parse_args()
    convert(args.model_path, args.out_dir, affine_gs=args.gs)
