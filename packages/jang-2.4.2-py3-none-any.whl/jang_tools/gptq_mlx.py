"""
JANG GPTQ for MLX — Hessian-guided optimal quantization with error feedback.
Created by Jinho Jang (eric@jangq.ai)

Replaces mx.quantize RTN with GPTQ error compensation. Same output format
(uint32 + float16 scales/biases), +3.5 dB output SNR on realistic activations.

Usage in convert.py:
    from .gptq_mlx import gptq_quantize_mlx_fast
    packed, scales, biases = gptq_quantize_mlx_fast(weight, hessian, bits=2, group_size=64)
"""

import numpy as np


def gptq_quantize_mlx_fast(
    weight: np.ndarray,
    hessian: np.ndarray,
    bits: int = 2,
    group_size: int = 64,
    dampening: float = 0.01,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    GPTQ quantization producing MLX-native uint32 + float16 scales/biases.

    Args:
        weight: (out_features, in_features) float32 weight matrix
        hessian: (in_features, in_features) float32 Hessian H = X^T X / n
        bits: quantization bit width
        group_size: weights per quantization group
        dampening: Hessian diagonal regularization factor

    Returns:
        (packed_uint32, scales_float16, biases_float16) — drop-in for mx.quantize output
    """
    out_feat, in_feat = weight.shape
    n_groups = in_feat // group_size
    n_levels = (1 << bits) - 1

    W = weight.astype(np.float64).copy()
    H = hessian.astype(np.float64).copy()

    # Dampening for numerical stability
    damp = dampening * np.mean(np.diag(H))
    H[np.diag_indices_from(H)] += damp

    # Cholesky-based Hessian inverse
    try:
        L = np.linalg.cholesky(H)
        H_inv = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(in_feat, dtype=np.float64)))
    except np.linalg.LinAlgError:
        H[np.diag_indices_from(H)] += damp * 100
        L = np.linalg.cholesky(H)
        H_inv = np.linalg.solve(L.T, np.linalg.solve(L, np.eye(in_feat, dtype=np.float64)))

    Q = np.zeros((out_feat, in_feat), dtype=np.int32)
    all_scales = np.zeros((out_feat, n_groups), dtype=np.float64)
    all_zeros = np.zeros((out_feat, n_groups), dtype=np.float64)

    for g in range(n_groups):
        cs = g * group_size
        ce = cs + group_size

        # Scale/zero from current (error-adjusted) weights
        W_g = W[:, cs:ce]
        v_min = W_g.min(axis=1)
        v_max = W_g.max(axis=1)
        v_range = v_max - v_min
        v_range[v_range == 0] = 1.0
        s = v_range / n_levels
        z = np.round(-v_min / s)
        z = np.clip(z, 0, n_levels)
        all_scales[:, g] = s
        all_zeros[:, g] = z

        # Quantize group
        q_g = np.clip(np.round(W_g / s[:, None] + z[:, None]), 0, n_levels).astype(np.int32)
        dq_g = (q_g.astype(np.float64) - z[:, None]) * s[:, None]
        Q[:, cs:ce] = q_g

        # Error feedback to all remaining columns via Hessian inverse
        if ce < in_feat:
            error_g = W_g - dq_g
            H_inv_gg = H_inv[cs:ce, cs:ce]
            h_diag = np.diag(H_inv_gg)
            h_diag_safe = np.maximum(np.abs(h_diag), 1e-15)
            scaled_err = error_g / h_diag_safe[None, :]
            comp = scaled_err @ H_inv[cs:ce, ce:]
            W[:, ce:] -= comp

    # Pack to MLX uint32 format
    packed = _pack_uint32(Q, bits, in_feat)
    scales_f16 = all_scales.astype(np.float16)
    biases_f16 = (-all_scales * all_zeros).astype(np.float16)

    return packed, scales_f16, biases_f16


def gptq_quantize_fast_with_hinv(
    weight: np.ndarray,
    h_inv: np.ndarray,
    bits: int = 2,
    group_size: int = 64,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    GPTQ with precomputed H_inv — skips the expensive Cholesky inversion.

    All 256 experts in a layer share the same H_inv. Computing it once per layer
    instead of per tensor reduces total time from ~64 hours to ~32 hours.

    Args:
        weight: (out_features, in_features) float32
        h_inv: (in_features, in_features) precomputed Hessian inverse
        bits: quantization bit width
        group_size: weights per group

    Returns:
        (packed_uint32, scales_float16, biases_float16)
    """
    out_feat, in_feat = weight.shape
    n_groups = in_feat // group_size
    n_levels = (1 << bits) - 1

    W = weight.astype(np.float64).copy()
    H_inv = h_inv.astype(np.float64)

    Q = np.zeros((out_feat, in_feat), dtype=np.int32)
    all_scales = np.zeros((out_feat, n_groups), dtype=np.float64)
    all_zeros = np.zeros((out_feat, n_groups), dtype=np.float64)

    for g in range(n_groups):
        cs = g * group_size
        ce = cs + group_size

        W_g = W[:, cs:ce]
        v_min = W_g.min(axis=1)
        v_max = W_g.max(axis=1)
        v_range = v_max - v_min
        v_range[v_range == 0] = 1.0
        s = v_range / n_levels
        z = np.round(-v_min / s)
        z = np.clip(z, 0, n_levels)
        all_scales[:, g] = s
        all_zeros[:, g] = z

        q_g = np.clip(np.round(W_g / s[:, None] + z[:, None]), 0, n_levels).astype(np.int32)
        dq_g = (q_g.astype(np.float64) - z[:, None]) * s[:, None]
        Q[:, cs:ce] = q_g

        if ce < in_feat:
            error_g = W_g - dq_g
            H_inv_gg = H_inv[cs:ce, cs:ce]
            h_diag = np.diag(H_inv_gg)
            h_diag_safe = np.maximum(np.abs(h_diag), 1e-15)
            scaled_err = error_g / h_diag_safe[None, :]
            comp = scaled_err @ H_inv[cs:ce, ce:]
            W[:, ce:] -= comp

    packed = _pack_uint32(Q, bits, in_feat)
    scales_f16 = all_scales.astype(np.float16)
    biases_f16 = (-all_scales * all_zeros).astype(np.float16)
    return packed, scales_f16, biases_f16


def _pack_uint32(Q: np.ndarray, bits: int, in_feat: int) -> np.ndarray:
    """Pack quantized integers into MLX uint32 format."""
    out_feat = Q.shape[0]
    vals_per_u32 = 32 // bits
    packed_cols = (in_feat + vals_per_u32 - 1) // vals_per_u32
    packed = np.zeros((out_feat, packed_cols), dtype=np.uint32)

    for i in range(vals_per_u32):
        cols = np.arange(i, in_feat, vals_per_u32)
        if len(cols) == 0:
            break
        pack_idx = cols // vals_per_u32
        bit_offset = (cols * bits) % 32
        vals = Q[:, cols].astype(np.uint32)
        for j, (pi, bo) in enumerate(zip(pack_idx, bit_offset)):
            packed[:, pi] |= (vals[:, j] << np.uint32(bo)).astype(np.uint32)

    return packed
