"""TopicWorker — maintains state.current_topic from rolling self-buffer speech.

Listens on self_buffer for new finalized sentences. On each one, schedules a
debounced topic extraction job (max 1/5s, skipped if the rolling text hasn't
changed). Uses the user's configured AI provider (via _call_ai_for_tasks) so
cost/latency follows their existing settings.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import threading
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.buffer import SentenceBuffer

logger = logging.getLogger(__name__)


_EMPTY_TOPIC = {
    "topic": "",
    "ticket_ids": [],
    "search_query": "",
    "last_user_statement": "",
}


class TopicWorker:
    """Background topic tracker bound to a self_buffer.

    Lifecycle: instantiate, call start(), then stop() on session end.
    """

    DEBOUNCE_SECS = 5.0
    WINDOW_SENTENCES = 25  # how many recent self-sentences to consider

    def __init__(self, config: "AppConfig", self_buffer: "SentenceBuffer") -> None:
        self._config = config
        self._buffer = self_buffer
        self._stop_event = threading.Event()
        self._last_run_at: float = 0.0
        self._last_hash: str = ""
        self._timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._enabled: bool = True
        # Cache the bound listener so add/remove see the SAME object identity
        # (bound methods are re-created on each attribute access).
        self._listener = self._on_sentence

    # ---- Lifecycle ----

    def start(self) -> None:
        self._buffer.add_sentence_listener(self._listener)
        logger.info("TopicWorker started")

    def stop(self) -> None:
        self._enabled = False
        self._stop_event.set()
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        try:
            self._buffer.remove_sentence_listener(self._listener)
        except Exception:
            pass
        logger.info("TopicWorker stopped")

    # ---- Trigger ----

    def _on_sentence(self, _sentence: str) -> None:
        """Called from the transcriber thread on every new finalized sentence."""
        if not self._enabled:
            return
        now = time.monotonic()
        elapsed = now - self._last_run_at
        if elapsed >= self.DEBOUNCE_SECS:
            # Run immediately
            self._schedule_run(0.0)
        else:
            # Debounce: schedule for the remaining window if not already pending
            with self._lock:
                if self._timer is None:
                    delay = self.DEBOUNCE_SECS - elapsed
                    t = threading.Timer(delay, self._fire_via_loop)
                    t.daemon = True
                    self._timer = t
                    t.start()

    def _schedule_run(self, delay: float) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        if delay <= 0:
            self._fire_via_loop()
        else:
            t = threading.Timer(delay, self._fire_via_loop)
            t.daemon = True
            with self._lock:
                self._timer = t
            t.start()

    def _fire_via_loop(self) -> None:
        """Hand off to the asyncio loop where _run() can do async work."""
        with self._lock:
            self._timer = None
        if not self._enabled:
            return
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is None:
            return
        asyncio.run_coroutine_threadsafe(self._run(), loop)

    # ---- Async work ----

    async def _run(self) -> None:
        if not self._enabled:
            return

        sentences = self._buffer.get_last_n(self.WINDOW_SENTENCES)
        if not sentences:
            return

        # Hash-skip: if buffer text hasn't changed since last run, do nothing.
        text = "\n".join(sentences)
        h = hashlib.sha1(text.encode("utf-8")).hexdigest()
        if h == self._last_hash:
            return
        self._last_hash = h
        self._last_run_at = time.monotonic()

        topic_info = await self._extract_topic(sentences)

        from meeting_helper.state import state
        state.current_topic = topic_info

        # Pre-fetch warm cards from local-todo
        cards: list[dict] = []
        search_q = topic_info.get("search_query") or " ".join(topic_info.get("ticket_ids") or [])
        if state.local_todo is not None and search_q:
            try:
                cards = await state.local_todo.search(search_q, limit=5)
            except Exception as exc:
                logger.warning("topic_worker local-todo search failed: %s", exc)
                cards = []
        state.current_topic_cards = cards

        # Broadcast so UIs can show what the agent thinks
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "topic",
                "topic": topic_info.get("topic", ""),
                "ticket_ids": topic_info.get("ticket_ids", []),
                "last_user_statement": topic_info.get("last_user_statement", ""),
                "cards": cards,
            })
        except Exception as exc:
            logger.warning("topic broadcast failed: %s", exc)

        logger.info(
            "TopicWorker: topic=%r ticket_ids=%s warm_cards=%d",
            topic_info.get("topic", ""),
            topic_info.get("ticket_ids", []),
            len(cards),
        )

    async def _extract_topic(self, sentences: list[str]) -> dict:
        """Call the user's configured AI provider to extract topic info."""
        from meeting_helper.ai.client import _call_ai_for_tasks
        from meeting_helper.ai.prompts import (
            TOPIC_EXTRACTION_SYSTEM_PROMPT,
            build_topic_extraction_user_message,
        )

        user_msg = build_topic_extraction_user_message(sentences)
        try:
            raw = await _call_ai_for_tasks(
                self._config, TOPIC_EXTRACTION_SYSTEM_PROMPT, user_msg
            )
        except Exception as exc:
            logger.warning("topic extraction AI call failed: %s", exc)
            return dict(_EMPTY_TOPIC)

        if not raw or not raw.strip():
            return dict(_EMPTY_TOPIC)

        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return dict(_EMPTY_TOPIC)
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            return dict(_EMPTY_TOPIC)

        return {
            "topic": str(parsed.get("topic", "")).strip(),
            "ticket_ids": [str(t).strip() for t in (parsed.get("ticket_ids") or []) if str(t).strip()],
            "search_query": str(parsed.get("search_query", "")).strip(),
            "last_user_statement": str(parsed.get("last_user_statement", "")).strip(),
        }
