"""Tests for the redshift PDF estimators (nz module)."""

import numpy as np
import pytest
import jax
import jax.numpy as jnp

import sum_stat as ss
from sum_stat.nz.histogram import nz_histogram, _nz_histogram_jax
from sum_stat.nz.kde import nz_kde, _silverman_bandwidth

Z_BINS = np.linspace(0.1, 0.5, 11)
Z_GRID = np.linspace(0.05, 0.55, 100)


# ---------------------------------------------------------------------------
# Histogram estimator
# ---------------------------------------------------------------------------

class TestNzHistogram:
    def test_output_shapes(self, mock_gal):
        z_c, nz, nz_err = nz_histogram(mock_gal, Z_BINS)
        assert z_c.shape == (10,)
        assert nz.shape == (10,)
        assert nz_err.shape == (10,)

    def test_centres_are_midpoints(self, mock_gal):
        z_c, _, _ = nz_histogram(mock_gal, Z_BINS)
        expected = 0.5 * (Z_BINS[:-1] + Z_BINS[1:])
        np.testing.assert_allclose(z_c, expected)

    def test_normalisation(self, mock_gal):
        z_c, nz, _ = nz_histogram(mock_gal, Z_BINS)
        dz = np.diff(Z_BINS)
        total = np.sum(nz * dz)
        assert abs(total - 1.0) < 1e-6, f"integral n(z) dz = {total:.6f}, expected 1"

    def test_nz_nonnegative(self, mock_gal):
        _, nz, nz_err = nz_histogram(mock_gal, Z_BINS)
        assert np.all(nz >= 0)
        assert np.all(nz_err >= 0)

    def test_err_le_nz_for_populated_bins(self, mock_gal):
        _, nz, nz_err = nz_histogram(mock_gal, Z_BINS)
        populated = nz > 0
        assert np.all(nz_err[populated] <= nz[populated] * 5)

    def test_uniform_weights_equal_unweighted(self):
        rng = np.random.default_rng(0)
        z = rng.uniform(0.1, 0.5, 1000)
        cat_ones = ss.GalaxyCatalogue(ra=np.zeros(1000), dec=np.zeros(1000), redshift=z)
        cat_two = ss.GalaxyCatalogue(
            ra=np.zeros(1000), dec=np.zeros(1000), redshift=z,
            weight=np.full(1000, 2.0),
        )
        _, nz1, _ = nz_histogram(cat_ones, Z_BINS)
        _, nz2, _ = nz_histogram(cat_two, Z_BINS)
        np.testing.assert_allclose(nz1, nz2, rtol=1e-10)

    def test_jit_kernel_compilable(self, mock_gal):
        fn = jax.jit(_nz_histogram_jax)
        nz, nz_err = fn(
            jnp.array(mock_gal.redshift),
            jnp.array(mock_gal.weight),
            jnp.array(Z_BINS),
        )
        assert nz.shape == (10,)

    def test_accessible_from_top_level(self, mock_gal):
        z_c, nz, nz_err = ss.nz_histogram(mock_gal, Z_BINS)
        assert nz.shape == (10,)

    def test_empty_bins_give_zero(self):
        z = np.array([0.2, 0.21, 0.22])
        cat = ss.GalaxyCatalogue(ra=np.zeros(3), dec=np.zeros(3), redshift=z)
        bins = np.linspace(0.1, 0.5, 11)
        _, nz, nz_err = nz_histogram(cat, bins)
        # Only the bin containing [0.2, 0.22] should be nonzero
        assert nz[0] == pytest.approx(0.0)   # [0.10, 0.14] is empty
        assert nz[-1] == pytest.approx(0.0)  # [0.46, 0.50] is empty


# ---------------------------------------------------------------------------
# KDE estimator
# ---------------------------------------------------------------------------

class TestNzKde:
    def test_output_shapes(self, mock_gal):
        z_g, nz = nz_kde(mock_gal, Z_GRID)
        assert z_g.shape == Z_GRID.shape
        assert nz.shape == Z_GRID.shape

    def test_returns_input_grid(self, mock_gal):
        z_g, _ = nz_kde(mock_gal, Z_GRID)
        np.testing.assert_array_equal(z_g, Z_GRID)

    def test_nz_nonnegative(self, mock_gal):
        _, nz = nz_kde(mock_gal, Z_GRID)
        assert np.all(nz >= 0)

    def test_approximate_normalisation(self, mock_gal):
        z_g = np.linspace(0.0, 0.7, 500)
        _, nz = nz_kde(mock_gal, z_g)
        dz = z_g[1] - z_g[0]
        total = np.sum(nz) * dz
        # Grid should cover well beyond the data support [0.1, 0.5]
        assert abs(total - 1.0) < 0.05, f"integral n(z) dz = {total:.4f}, expected ~1"

    def test_explicit_bandwidth(self, mock_gal):
        z_g, nz = nz_kde(mock_gal, Z_GRID, bandwidth=0.02)
        assert nz.shape == Z_GRID.shape
        assert np.all(nz >= 0)

    def test_silverman_bandwidth_positive(self, mock_gal):
        h = _silverman_bandwidth(mock_gal.redshift, mock_gal.weight)
        assert h > 0

    def test_silverman_decreases_with_n(self):
        rng = np.random.default_rng(1)
        z_small = rng.uniform(0.1, 0.5, 100)
        z_large = rng.uniform(0.1, 0.5, 10000)
        w = np.ones_like(z_small)
        h_small = _silverman_bandwidth(z_small, w)
        h_large = _silverman_bandwidth(z_large, np.ones_like(z_large))
        assert h_large < h_small

    def test_peaks_near_data(self, mock_gal):
        z_g = np.linspace(0.0, 0.7, 300)
        _, nz = nz_kde(mock_gal, z_g)
        peak_z = z_g[np.argmax(nz)]
        assert 0.1 < peak_z < 0.5, f"KDE peak at z={peak_z:.3f}, outside data range"

    def test_accessible_from_top_level(self, mock_gal):
        z_g, nz = ss.nz_kde(mock_gal, Z_GRID)
        assert nz.shape == Z_GRID.shape

    def test_kde_smoother_than_histogram(self, mock_gal):
        z_g = np.linspace(0.1, 0.5, 50)
        _, nz_k = nz_kde(mock_gal, z_g, bandwidth=0.01)
        bins = np.linspace(0.1, 0.5, 51)
        _, nz_h, _ = nz_histogram(mock_gal, bins)
        # KDE should have smaller bin-to-bin variance (smoother)
        var_kde = np.var(np.diff(nz_k))
        var_hist = np.var(np.diff(nz_h))
        assert var_kde < var_hist, "KDE should be smoother than histogram"
