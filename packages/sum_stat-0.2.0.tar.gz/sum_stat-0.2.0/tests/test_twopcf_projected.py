"""Tests for projected two-point correlation function w_p(r_p)."""

from __future__ import annotations

import numpy as np
import pytest
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.twopcf.projected import wp

COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)
RNG = np.random.default_rng(42)

N_GAL = 500
N_RAND = 2000
RP_BINS = np.logspace(np.log10(0.5), np.log10(20.0), 8)
PI_MAX = 40.0


def _make_cat(n: int, ra_range=(0.0, 5.0), dec_range=(-2.5, 2.5), z_range=(0.15, 0.25)):
    ra = RNG.uniform(*ra_range, n)
    dec = RNG.uniform(*dec_range, n)
    z = RNG.uniform(*z_range, n)
    return ss.GalaxyCatalogue(ra=ra, dec=dec, redshift=z)


@pytest.fixture(scope="module")
def uniform_gal():
    return _make_cat(N_GAL)


@pytest.fixture(scope="module")
def uniform_rand():
    return _make_cat(N_RAND)


class TestWp:
    def test_output_shape(self, uniform_gal, uniform_rand):
        rp, wp_vals, var_wp = wp(uniform_gal, uniform_rand, RP_BINS, PI_MAX, COSMO)
        n_bins = len(RP_BINS) - 1
        assert rp.shape == (n_bins,)
        assert wp_vals.shape == (n_bins,)
        assert var_wp.shape == (n_bins,)

    def test_rp_centres_geometric_mean(self, uniform_gal, uniform_rand):
        rp, _, _ = wp(uniform_gal, uniform_rand, RP_BINS, PI_MAX, COSMO)
        expected = np.sqrt(RP_BINS[:-1] * RP_BINS[1:])
        np.testing.assert_allclose(rp, expected, rtol=1e-10)

    def test_near_zero_for_uniform(self, uniform_gal, uniform_rand):
        # Uniform random field: w_p ≈ 0 with finite-N scatter.
        # With N_GAL=500, N_RAND=2000, expect |w_p| < 10 Mpc on most bins.
        _, wp_vals, _ = wp(uniform_gal, uniform_rand, RP_BINS, PI_MAX, COSMO)
        assert np.nanmean(np.abs(wp_vals)) < 20.0

    def test_weighted_runs(self):
        # Galaxies with non-uniform weights should not raise.
        n = 300
        ra = RNG.uniform(0, 5, n)
        dec = RNG.uniform(-2.5, 2.5, n)
        z = RNG.uniform(0.15, 0.25, n)
        w = RNG.uniform(0.5, 1.5, n)
        gal = ss.GalaxyCatalogue(ra=ra, dec=dec, redshift=z, weight=w)
        rand = _make_cat(1000)
        rp, wp_vals, var_wp = wp(gal, rand, RP_BINS, PI_MAX, COSMO)
        assert rp.shape == wp_vals.shape == var_wp.shape

    def test_pi_max_rounding(self, uniform_gal, uniform_rand):
        # pi_max=40.3 should behave identically to pi_max=40
        rp_a, wp_a, _ = wp(uniform_gal, uniform_rand, RP_BINS, 40.0, COSMO)
        rp_b, wp_b, _ = wp(uniform_gal, uniform_rand, RP_BINS, 40.3, COSMO)
        np.testing.assert_array_equal(wp_a, wp_b)

    def test_exported_from_package(self):
        assert hasattr(ss, "wp")
        assert ss.wp is wp
