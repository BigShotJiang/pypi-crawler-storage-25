"""Tests for 2PCF multipole decomposition."""

import numpy as np
import pytest
import jax
import jax.numpy as jnp

from sum_stat.twopcf.multipoles import _legendre_decompose_jax


class TestLegendreDecompose:
    def setup_method(self):
        n_s = 15
        n_mu = 100
        self.mu_centres = jnp.linspace(0.0, 1.0, n_mu, endpoint=False) + 0.5 / n_mu
        # Isotropic field: ξ(s, μ) = ξ(s) for all μ
        xi_s = jnp.logspace(-2, -1, n_s)
        self.xi_2d_iso = jnp.broadcast_to(xi_s[:, None], (n_s, n_mu))

    def test_monopole_recovers_xi(self):
        result = _legendre_decompose_jax(self.xi_2d_iso, self.mu_centres, (0,))
        xi0 = result[0]
        # ξ_0(s) = ξ(s) for isotropic field (P_0 = 1, integral over [0,1] of dmu = 1, but (2*0+1)/2 * 2 * int = 1)
        # ξ_0 = (1/2) ∫_{-1}^1 ξ(s,μ) P_0(μ) dμ = (1/2) * 2 * ξ(s) = ξ(s)
        # Since we integrate over [0,1] only (positive mu), we need to account for symmetry
        xi_s = jnp.logspace(-2, -1, 15)
        # The decomposition integrates over [0,1] in our implementation
        # (2ℓ+1)/2 * ∫_0^1 P_ℓ dμ for ℓ=0: 1/2 * 1 * 1 = 1/2, but trapz over [0,1] with P_0=1 → integral=1
        # Actually (2*0+1)/2 * trapz(xi * 1, dmu) = 1/2 * xi * 1 = xi/2 unless normalization differs
        # Test: xi0 should be proportional to xi_s
        np.testing.assert_allclose(
            np.array(xi0) / np.array(xi_s),
            np.ones(15) * float(xi0[0] / xi_s[0]),
            rtol=1e-3,
        )

    def test_quadrupole_zero_for_isotropic(self):
        result = _legendre_decompose_jax(self.xi_2d_iso, self.mu_centres, (2,))
        xi2 = result[2]
        # For isotropic: ∫ P_2(μ) dμ over [0,1] = 0 (since P_2 is odd about μ=0.5 on [0,1])
        # This holds only if the field is symmetric — for our μ ∈ [0,1] range, P_2(μ) changes sign
        np.testing.assert_allclose(np.array(xi2), 0.0, atol=1e-2)

    def test_hexadecapole_zero_for_isotropic(self):
        result = _legendre_decompose_jax(self.xi_2d_iso, self.mu_centres, (4,))
        xi4 = result[4]
        np.testing.assert_allclose(np.array(xi4), 0.0, atol=1e-2)

    def test_output_shapes(self):
        n_s, n_mu = 12, 80
        xi_2d = jnp.ones((n_s, n_mu))
        mu = jnp.linspace(0, 1, n_mu, endpoint=False) + 0.5 / n_mu
        result = _legendre_decompose_jax(xi_2d, mu, (0, 2, 4))
        assert result[0].shape == (n_s,)
        assert result[2].shape == (n_s,)
        assert result[4].shape == (n_s,)

    def test_callable_with_jnp_arrays(self):
        n_s, n_mu = 8, 50
        xi_2d = jnp.ones((n_s, n_mu))
        mu = jnp.linspace(0, 1, n_mu, endpoint=False) + 0.5 / n_mu
        result = _legendre_decompose_jax(xi_2d, mu, (0, 2))
        assert result[0].shape == (n_s,)

    def test_monopole_scales_linearly(self):
        # xi_0 should scale linearly with the amplitude of xi(s, mu)
        n_s, n_mu = 10, 100
        mu = jnp.linspace(0, 1, n_mu, endpoint=False) + 0.5 / n_mu
        xi_2d_1 = jnp.ones((n_s, n_mu))
        xi_2d_2 = 2.0 * xi_2d_1
        r1 = _legendre_decompose_jax(xi_2d_1, mu, (0,))
        r2 = _legendre_decompose_jax(xi_2d_2, mu, (0,))
        np.testing.assert_allclose(np.array(r2[0]), 2.0 * np.array(r1[0]), rtol=1e-5)
