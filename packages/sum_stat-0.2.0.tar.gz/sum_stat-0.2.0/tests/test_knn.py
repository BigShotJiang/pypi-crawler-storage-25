"""Tests for sum_stat.knn: kNN-CDF, cross-kNN-CDF, volume map, Poisson reference."""

from __future__ import annotations

import numpy as np
import pytest
import h5py
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.knn import comoving_xyz, cross_knn_cdf, knn_cdf, knn_poisson_cdf, knn_volume_map
from sum_stat.knn.distances import knn_query
from sum_stat.knn.cdf import _empirical_cdf_jax
import jax.numpy as jnp

# ---------------------------------------------------------------------------
# Module-level constants and fixtures
# ---------------------------------------------------------------------------

COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111, name="Planck18_test")
RNG_SEED = 42
N_GAL = 3_000
N_RAND = 15_000
N_QUERY = 5_000   # small for test speed
K_VALUES = np.array([1, 2, 3, 4])
R_BINS = np.logspace(-1, 1.5, 21)   # 0.1 – 31.6 Mpc, 20 bins


@pytest.fixture(scope="module")
def rng():
    return np.random.default_rng(RNG_SEED)


@pytest.fixture(scope="module")
def uniform_gal(rng) -> ss.GalaxyCatalogue:
    """Uniform random galaxies in a 5×5 deg patch, z ∈ [0.1, 0.5]."""
    ra = rng.uniform(0.0, 5.0, N_GAL)
    dec = rng.uniform(-2.5, 2.5, N_GAL)
    z = rng.uniform(0.1, 0.5, N_GAL)
    return ss.GalaxyCatalogue(ra=ra, dec=dec, redshift=z)


@pytest.fixture(scope="module")
def uniform_rand(rng) -> ss.GalaxyCatalogue:
    """Matching random catalogue (5× galaxies) in the same patch."""
    ra = rng.uniform(0.0, 5.0, N_RAND)
    dec = rng.uniform(-2.5, 2.5, N_RAND)
    z = rng.uniform(0.1, 0.5, N_RAND)
    return ss.GalaxyCatalogue(ra=ra, dec=dec, redshift=z)


@pytest.fixture(scope="module")
def clustered_gal(rng) -> ss.GalaxyCatalogue:
    """Clustered catalogue: 30 cluster centres with Gaussian halos."""
    n_clusters = 30
    n_per_cluster = N_GAL // n_clusters
    centres_ra = rng.uniform(0.5, 4.5, n_clusters)
    centres_dec = rng.uniform(-2.0, 2.0, n_clusters)
    centres_z = rng.uniform(0.15, 0.45, n_clusters)
    ra_list, dec_list, z_list = [], [], []
    for cra, cdec, cz in zip(centres_ra, centres_dec, centres_z):
        ra_list.append(rng.normal(cra, 0.05, n_per_cluster))
        dec_list.append(rng.normal(cdec, 0.05, n_per_cluster))
        z_list.append(np.clip(rng.normal(cz, 0.005, n_per_cluster), 0.1, 0.5))
    return ss.GalaxyCatalogue(
        ra=np.concatenate(ra_list),
        dec=np.concatenate(dec_list),
        redshift=np.concatenate(z_list),
    )


@pytest.fixture(scope="module")
def gal_xyz(uniform_gal) -> np.ndarray:
    return comoving_xyz(uniform_gal, COSMO)


@pytest.fixture(scope="module")
def r_centres_F_k(uniform_gal, uniform_rand):
    """Pre-compute knn_cdf result for reuse."""
    return knn_cdf(
        uniform_gal, COSMO, K_VALUES, R_BINS,
        rand=uniform_rand, n_query=N_QUERY, seed=RNG_SEED,
    )


# ---------------------------------------------------------------------------
# Tests: comoving_xyz
# ---------------------------------------------------------------------------


class TestComovingXyz:
    def test_shape(self, uniform_gal):
        xyz = comoving_xyz(uniform_gal, COSMO)
        assert xyz.shape == (N_GAL, 3)

    def test_dtype(self, uniform_gal):
        xyz = comoving_xyz(uniform_gal, COSMO)
        assert xyz.dtype == np.float64

    def test_positive_distances(self, uniform_gal):
        xyz = comoving_xyz(uniform_gal, COSMO)
        r = np.linalg.norm(xyz, axis=1)
        assert np.all(r > 0)


# ---------------------------------------------------------------------------
# Tests: knn_query
# ---------------------------------------------------------------------------


class TestKnnQuery:
    def test_shape_kmax_gt_1(self, gal_xyz):
        q = gal_xyz[:20]
        d = knn_query(gal_xyz, q, k_max=3)
        assert d.shape == (20, 3)

    def test_shape_kmax_1(self, gal_xyz):
        q = gal_xyz[:20]
        d = knn_query(gal_xyz, q, k_max=1)
        assert d.shape == (20, 1)

    def test_sorted_ascending(self, gal_xyz):
        q = gal_xyz[:50]
        d = knn_query(gal_xyz, q, k_max=4)
        # each row should be sorted ascending (first NN is self at d=0)
        assert np.all(np.diff(d, axis=1) >= 0)

    def test_nonnegative(self, gal_xyz):
        q = gal_xyz[:50]
        d = knn_query(gal_xyz, q, k_max=3)
        assert np.all(d >= 0)


# ---------------------------------------------------------------------------
# Tests: _empirical_cdf_jax
# ---------------------------------------------------------------------------


class TestEmpiricalCdf:
    def test_monotone(self):
        rng = np.random.default_rng(0)
        dists = jnp.asarray(rng.uniform(0, 10, 1000))
        edges = jnp.linspace(0, 10, 11)
        F = np.array(_empirical_cdf_jax(dists, edges))
        assert np.all(np.diff(F) >= 0)

    def test_bounds(self):
        rng = np.random.default_rng(1)
        dists = jnp.asarray(rng.uniform(0, 10, 1000))
        edges = jnp.linspace(0, 10, 11)
        F = np.array(_empirical_cdf_jax(dists, edges))
        assert np.all(F >= 0) and np.all(F <= 1)

    def test_reaches_one(self):
        dists = jnp.ones(500) * 5.0
        edges = jnp.array([0.0, 3.0, 6.0, 10.0])
        F = np.array(_empirical_cdf_jax(dists, edges))
        assert F[-1] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Tests: knn_poisson_cdf
# ---------------------------------------------------------------------------


class TestKnnPoissonCdf:
    def test_bounds(self):
        edges = jnp.logspace(-1, 1.5, 21)
        F = np.array(knn_poisson_cdf(2, edges, n_bar=1e-3))
        assert np.all(F >= 0) and np.all(F <= 1)

    def test_monotone(self):
        edges = jnp.logspace(-1, 1.5, 21)
        F = np.array(knn_poisson_cdf(3, edges, n_bar=1e-3))
        assert np.all(np.diff(F) >= 0)

    def test_k1_closed_form(self):
        # For k=1: F_1(r) = 1 - exp(-n_bar * 4π/3 * r³)
        n_bar = 2e-3
        edges = jnp.logspace(-1, 1.2, 15)
        r = np.array(edges[1:])
        expected = 1.0 - np.exp(-n_bar * (4.0 * np.pi / 3.0) * r**3)
        F = np.array(knn_poisson_cdf(1, edges, n_bar=n_bar))
        np.testing.assert_allclose(F, expected, rtol=1e-6)

    def test_larger_k_less_steep(self):
        # F_1 rises faster than F_5 at small r (larger k → longer waiting)
        edges = jnp.logspace(-1, 1.5, 21)
        n_bar = 1e-3
        F1 = np.array(knn_poisson_cdf(1, edges, n_bar=n_bar))
        F5 = np.array(knn_poisson_cdf(5, edges, n_bar=n_bar))
        assert F1[5] > F5[5]


# ---------------------------------------------------------------------------
# Tests: knn_cdf
# ---------------------------------------------------------------------------


class TestKnnCdf:
    def test_output_shapes(self, r_centres_F_k):
        r_centres, F_k, F_k_poisson = r_centres_F_k
        n_r = len(R_BINS) - 1
        n_k = len(K_VALUES)
        assert r_centres.shape == (n_r,)
        assert F_k.shape == (n_k, n_r)
        assert F_k_poisson.shape == (n_k, n_r)

    def test_r_centres_geometric_mean(self, r_centres_F_k):
        r_centres, _, _ = r_centres_F_k
        expected = np.sqrt(R_BINS[:-1] * R_BINS[1:])
        np.testing.assert_allclose(r_centres, expected, rtol=1e-12)

    def test_cdf_monotone(self, r_centres_F_k):
        _, F_k, _ = r_centres_F_k
        assert np.all(np.diff(F_k, axis=1) >= -1e-12)

    def test_cdf_bounds(self, r_centres_F_k):
        _, F_k, F_k_poisson = r_centres_F_k
        assert np.all(F_k >= 0) and np.all(F_k <= 1)
        assert np.all(F_k_poisson >= 0) and np.all(F_k_poisson <= 1)

    def test_poisson_monotone(self, r_centres_F_k):
        _, _, F_k_poisson = r_centres_F_k
        assert np.all(np.diff(F_k_poisson, axis=1) >= 0)

    def test_no_rand_runs(self, uniform_gal):
        r_c, F_k, F_kp = knn_cdf(
            uniform_gal, COSMO, np.array([1, 2]), R_BINS,
            rand=None, n_query=2_000, seed=0,
        )
        assert F_k.shape == (2, len(R_BINS) - 1)

    def test_uniform_approx_poisson(self, rng):
        """Benchmark: kNN-CDF of a Poisson field ≈ Erlang reference (Banerjee & Abel 2021, §3.1).

        Uses a thin redshift shell (Δz = 0.01) so the RA/Dec/z-uniform distribution
        closely approximates a 3-D uniform (Poisson) process in comoving space.
        Galaxy and query catalogues are drawn independently to avoid self-matching.
        """
        n_gal_bench = 4_000
        n_q_bench = 6_000
        z_c, dz = 0.30, 0.01
        z_lo, z_hi = z_c - dz / 2, z_c + dz / 2
        ra_g = rng.uniform(0.0, 5.0, n_gal_bench)
        dec_g = rng.uniform(-2.5, 2.5, n_gal_bench)
        z_g = rng.uniform(z_lo, z_hi, n_gal_bench)
        gal_bench = ss.GalaxyCatalogue(ra=ra_g, dec=dec_g, redshift=z_g)

        # Independent query points — not the same objects as the galaxies.
        ra_q = rng.uniform(0.0, 5.0, n_q_bench)
        dec_q = rng.uniform(-2.5, 2.5, n_q_bench)
        z_q = rng.uniform(z_lo, z_hi, n_q_bench)
        rand_bench = ss.GalaxyCatalogue(ra=ra_q, dec=dec_q, redshift=z_q)

        # Survey volume from the thin-shell geometry (flat-sky limit).
        area_sr = (5.0 * 5.0) * (np.pi / 180.0) ** 2
        chi_c = COSMO.comoving_distance(z_c).value
        chi_lo = COSMO.comoving_distance(z_lo).value
        chi_hi = COSMO.comoving_distance(z_hi).value
        v_survey = area_sr * chi_c**2 * (chi_hi - chi_lo)
        n_bar = n_gal_bench / v_survey

        _, F_k, F_kp = knn_cdf(
            gal_bench, COSMO, np.array([1, 2, 3]), R_BINS,
            rand=rand_bench, n_query=n_q_bench, n_bar=n_bar, seed=5,
        )
        # Only compare bins where empirical CDF ∈ [0.10, 0.90] and
        # the Poisson reference is non-trivial (> 0.01).
        for ki in range(3):
            mask = (F_k[ki] > 0.10) & (F_k[ki] < 0.90) & (F_kp[ki] > 0.01)
            if mask.sum() < 3:
                continue
            np.testing.assert_allclose(F_k[ki][mask], F_kp[ki][mask], rtol=0.25)

    def test_clustering_deviates_from_poisson(self, clustered_gal, uniform_rand):
        """Clustered catalogue should deviate significantly from Erlang reference."""
        _, F_k, F_k_pois = knn_cdf(
            clustered_gal, COSMO, np.array([1]), R_BINS,
            rand=uniform_rand, n_query=N_QUERY, seed=0,
        )
        # Relative deviation must exceed 10 % somewhere in the CDF
        rel_diff = np.abs(F_k[0] - F_k_pois[0]) / (F_k_pois[0] + 1e-6)
        assert rel_diff.max() > 0.1

    def test_exported_from_package(self):
        assert callable(ss.knn_cdf)


# ---------------------------------------------------------------------------
# Tests: cross_knn_cdf
# ---------------------------------------------------------------------------


class TestCrossKnnCdf:
    def test_output_shapes(self, uniform_gal, clustered_gal, uniform_rand):
        r_c, F_a, F_b = cross_knn_cdf(
            uniform_gal, clustered_gal, COSMO, K_VALUES, R_BINS,
            rand=uniform_rand, n_query=N_QUERY, seed=0,
        )
        n_r = len(R_BINS) - 1
        n_k = len(K_VALUES)
        assert r_c.shape == (n_r,)
        assert F_a.shape == (n_k, n_r)
        assert F_b.shape == (n_k, n_r)

    def test_cdf_bounds(self, uniform_gal, clustered_gal, uniform_rand):
        _, F_a, F_b = cross_knn_cdf(
            uniform_gal, clustered_gal, COSMO, np.array([1, 2]), R_BINS,
            rand=uniform_rand, n_query=N_QUERY, seed=0,
        )
        assert np.all(F_a >= 0) and np.all(F_a <= 1)
        assert np.all(F_b >= 0) and np.all(F_b <= 1)

    def test_different_cdfs(self, uniform_gal, clustered_gal, uniform_rand):
        """Uniform and clustered populations should yield different kNN-CDFs."""
        _, F_a, F_b = cross_knn_cdf(
            uniform_gal, clustered_gal, COSMO, np.array([1]), R_BINS,
            rand=uniform_rand, n_query=N_QUERY, seed=0,
        )
        assert not np.allclose(F_a[0], F_b[0], atol=0.05)


# ---------------------------------------------------------------------------
# Tests: knn_volume_map
# ---------------------------------------------------------------------------


class TestKnnVolumeMap:
    def test_output_shape(self, uniform_gal, gal_xyz):
        k_vals = [1, 2, 3, 4]
        n_q = 200
        q_xyz = gal_xyz[:n_q]
        vols = knn_volume_map(uniform_gal, q_xyz, k_vals, COSMO)
        assert vols.shape == (n_q, len(k_vals))

    def test_all_positive(self, uniform_gal, uniform_rand):
        # Use rand catalogue xyz as query points so they don't coincide with
        # any galaxy — k=1 distance would be 0 for self-matching queries.
        rand_xyz = comoving_xyz(uniform_rand, COSMO)[:100]
        vols = knn_volume_map(uniform_gal, rand_xyz, [1, 2], COSMO)
        assert np.all(vols > 0)

    def test_volumes_non_decreasing_in_k(self, uniform_gal, gal_xyz):
        """V_k ≤ V_{k+1} since r_k ≤ r_{k+1}."""
        vols = knn_volume_map(uniform_gal, gal_xyz[:200], [1, 2, 3, 4], COSMO)
        assert np.all(np.diff(vols, axis=1) >= 0)

    def test_volume_formula(self, uniform_gal, gal_xyz):
        """V_k should equal 4π/3 * d_k³."""
        q_xyz = gal_xyz[:50]
        vols = knn_volume_map(uniform_gal, q_xyz, [1], COSMO)
        gal_xyz_arr = comoving_xyz(uniform_gal, COSMO)
        d1 = knn_query(gal_xyz_arr, q_xyz, k_max=1)[:, 0]
        expected = (4.0 * np.pi / 3.0) * d1**3
        np.testing.assert_allclose(vols[:, 0], expected, rtol=1e-10)


# ---------------------------------------------------------------------------
# Tests: write_knn round-trip
# ---------------------------------------------------------------------------


class TestWriteKnn:
    def test_roundtrip(self, tmp_path, r_centres_F_k):
        r_centres, F_k, F_k_poisson = r_centres_F_k
        k_vals = K_VALUES.astype(np.float64)
        h5_path = tmp_path / "knn_test.h5"

        meta = {
            "estimator": "knn-cdf",
            "n_query": N_QUERY,
            "n_gal": N_GAL,
            "survey": "test",
        }
        with ss.SummaryStatWriter(str(h5_path)) as w:
            w.write_knn(
                "knn/test_sample",
                r_centres, F_k, F_k_poisson, R_BINS, k_vals, COSMO, meta,
            )

        with h5py.File(h5_path, "r") as f:
            g = f["knn/test_sample"]
            np.testing.assert_allclose(g["r_centres"][()], r_centres, rtol=1e-6)
            np.testing.assert_allclose(g["F_k"][()], F_k, rtol=1e-6)
            np.testing.assert_allclose(g["F_k_poisson"][()], F_k_poisson, rtol=1e-6)
            np.testing.assert_allclose(g["k_values"][()], k_vals, rtol=1e-6)
            assert g.attrs["estimator"] == "knn-cdf"
            assert g.attrs["n_query"] == N_QUERY
            assert "cosmology" in g
