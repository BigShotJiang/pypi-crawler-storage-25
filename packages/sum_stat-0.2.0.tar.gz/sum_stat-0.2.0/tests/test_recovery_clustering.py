"""Physical recovery tests for WPRP and WTHETA (stub — not yet implemented).

These tests verify that the projected correlation w_p(r_p) and angular
correlation w(theta) estimators recover a known signal from a controlled mock.

See docs/testing.rst "Test coverage gaps" for the pass criteria.
"""

import pytest


@pytest.mark.skip(reason="not yet implemented — see docs/testing.rst coverage gaps")
def test_wprp_recovers_power_law_slope():
    """Recover the slope gamma of a power-law w_p from a Poisson-sampled mock.

    Setup: generate a mock with a known two-point xi(r) = (r/r0)^{-gamma},
    project to w_p(r_p) analytically, sample galaxy positions from the
    corresponding Poisson process, measure w_p with sum_stat.wp.

    Pass criterion: |gamma_hat - gamma_true| < 0.15 on scales 0.1–10 Mpc.
    """
    raise NotImplementedError


@pytest.mark.skip(reason="not yet implemented — see docs/testing.rst coverage gaps")
def test_wtheta_recovers_power_law_slope():
    """Recover the slope of a power-law w(theta) from a Poisson-sampled angular mock.

    Setup: project the same power-law xi(r) to w(theta) via Limber equation,
    sample angular positions, measure w(theta) with sum_stat.w_theta.

    Pass criterion: power-law slope within 0.15 of truth on scales 1–100 arcmin.
    """
    raise NotImplementedError
