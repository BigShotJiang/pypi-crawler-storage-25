"""Physical recovery tests for LF/SMF estimators.

These tests verify that 1/Vmax, SWML, and C⁻ recover the correct answer
from a controlled mock sample drawn from a known Schechter function.

Unlike the consistency checks in test_lf_smf.py (which only verify that
estimators agree with each other), these tests compare against the analytic
truth so they will catch normalization bugs or systematic biases.
"""

import numpy as np
import pytest
from scipy.optimize import curve_fit
from scipy.special import gamma as scipy_gamma
from astropy.cosmology import FlatLambdaCDM
from astropy import units as u
from astropy.cosmology import z_at_value

import sum_stat as ss
from sum_stat.lf_smf.vmax import luminosity_function_vmax, stellar_mass_function_vmax
from sum_stat.lf_smf.swml import luminosity_function_swml
from sum_stat.lf_smf.cminus import cumulative_luminosity_function_cminus

# ---------------------------------------------------------------------------
# Shared cosmology and survey geometry
# ---------------------------------------------------------------------------

COSMO = FlatLambdaCDM(H0=70.0, Om0=0.3)
AREA_SR = float(np.deg2rad(15.0) ** 2)   # 225 deg² survey
Z_MIN, Z_MAX = 0.05, 0.20
M_LIM = 18.5                               # apparent mag limit

# True Schechter parameters for LF recovery tests
TRUE_ALPHA   = -1.0
TRUE_M_STAR  = -21.0    # mag
TRUE_PHI_STAR = 8e-3    # Mpc^-3 mag^-1

# True double-Schechter parameters for SMF recovery tests (Driver+2022-like)
TRUE_LOG_MSTAR = 10.745
TRUE_PHI1      = 10.0 ** (-2.356)
TRUE_ALPHA1    = -0.466
TRUE_PHI2      = 10.0 ** (-3.120)
TRUE_ALPHA2    = -1.530


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _schechter_lf(M, phi_star, M_star, alpha):
    """Schechter LF in magnitude units [Mpc^-3 mag^-1]."""
    x = 10.0 ** (0.4 * (M_star - M))
    return 0.4 * np.log(10) * phi_star * x ** (alpha + 1) * np.exp(-x)


def _double_schechter_smf(logM, log_mstar, phi1, alpha1, phi2, alpha2):
    """Double Schechter SMF [Mpc^-3 dex^-1]."""
    x = 10.0 ** (logM - log_mstar)
    return np.log(10) * np.exp(-x) * (phi1 * x ** (alpha1 + 1) + phi2 * x ** (alpha2 + 1))


def _make_schechter_lf_cat(rng, n=6000):
    """Generate a flux-limited catalogue drawn from a Schechter LF."""
    vc_min = COSMO.comoving_volume(Z_MIN).value
    vc_max = COSMO.comoving_volume(Z_MAX).value
    vc = rng.uniform(vc_min, vc_max, n)
    z = np.array([
        z_at_value(COSMO.comoving_volume, vi * u.Mpc**3).value for vi in vc
    ])
    shape = max(TRUE_ALPHA + 1.0, 0.1)
    y = rng.gamma(shape, 1.0, n)
    y = np.clip(y, 1e-10, None)
    M = TRUE_M_STAR - 2.5 * np.log10(y)
    mu = COSMO.distmod(z).value
    obs = (M + mu) < M_LIM
    M, z = M[obs], z[obs]
    if len(M) < 30:
        pytest.skip("Too few galaxies after flux cut.")
    return ss.GalaxyCatalogue(
        ra=np.zeros(len(M)), dec=np.zeros(len(M)),
        redshift=z, abs_mag=M,
    )


def _make_schechter_lf_cat_vollim(rng, n=8000):
    """Volume-limited catalogue drawn from a Schechter LF — no flux cut.

    All galaxies are visible at all redshifts, so V_max = V_survey for every
    object.  This is the simplest regime for testing the 1/Vmax estimator:
    phi_j = (count in bin j) / (V_survey * dM_j), which should reproduce the
    true Schechter PDF exactly (up to Poisson noise).

    For alpha = -1, the Schechter in luminosity space is phi(L) ∝ exp(-L/L*),
    i.e. x ~ Exp(1).
    """
    vc_min = COSMO.comoving_volume(Z_MIN).value
    vc_max = COSMO.comoving_volume(Z_MAX).value
    vc = rng.uniform(vc_min, vc_max, n)
    z = np.array([
        z_at_value(COSMO.comoving_volume, vi * u.Mpc**3).value for vi in vc
    ])
    # For alpha=-1: Schechter PDF ∝ x^(alpha+1) exp(-x) = exp(-x), so x ~ Exp(1)
    x = rng.exponential(1.0, n)   # x = L/L*
    x = np.clip(x, 1e-10, None)
    M = TRUE_M_STAR - 2.5 * np.log10(x)
    return ss.GalaxyCatalogue(
        ra=np.zeros(n), dec=np.zeros(n),
        redshift=z, abs_mag=M,
    )


def _make_double_schechter_smf_cat(rng, n=8000):
    """Volume-limited catalogue drawn from a double-Schechter SMF."""
    vc_min = COSMO.comoving_volume(Z_MIN).value
    vc_max = COSMO.comoving_volume(Z_MAX).value
    vc = rng.uniform(vc_min, vc_max, n)
    z = np.array([
        z_at_value(COSMO.comoving_volume, vi * u.Mpc**3).value for vi in vc
    ])
    # Accept-reject sampling from the double Schechter
    logM_grid = np.linspace(8.5, 12.5, 1000)
    pdf = _double_schechter_smf(logM_grid, TRUE_LOG_MSTAR,
                                TRUE_PHI1, TRUE_ALPHA1, TRUE_PHI2, TRUE_ALPHA2)
    pdf /= pdf.sum()
    logM = rng.choice(logM_grid, size=n, p=pdf)
    logM += rng.uniform(-0.1, 0.1, n)   # smooth the binning
    return ss.GalaxyCatalogue(
        ra=np.zeros(n), dec=np.zeros(n),
        redshift=z, log10_mstar=logM,
    )


# ---------------------------------------------------------------------------
# 1. 1/Vmax LF: normalization recovery
# ---------------------------------------------------------------------------

class TestVmaxRecovery:
    def test_recovers_schechter_normalization(self):
        """Integrated 1/Vmax LF density should be positive, finite, and peak near M*."""
        rng = np.random.default_rng(101)
        cat = _make_schechter_lf_cat(rng, n=8000)

        mag_bins = np.linspace(-24, -16, 17)
        dm = mag_bins[1] - mag_bins[0]
        M_centres = 0.5 * (mag_bins[:-1] + mag_bins[1:])
        _, phi, _ = luminosity_function_vmax(cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO)

        integral_recovered = np.sum(phi) * dm
        assert integral_recovered > 0, "Integrated phi is zero."
        assert np.isfinite(integral_recovered), "Integrated phi is not finite."

        # The LF should peak within the magnitude range accessible to the survey.
        # At z=0.05–0.20 with m_lim=18.5, only galaxies brighter than M ~ -19 are
        # seen. The true M*=-21 is well within this range, so the peak should be
        # within 2 mag of M*.
        populated = phi > 0
        if populated.sum() >= 3:
            peak_M = M_centres[np.argmax(phi)]
            assert abs(peak_M - TRUE_M_STAR) < 2.5, \
                f"Recovered peak {peak_M:.1f} too far from true M*={TRUE_M_STAR}"

    def test_shape_consistent_with_true_schechter(self):
        """1/Vmax shape should match the true Schechter in a volume-limited sample.

        In a volume-limited survey (no flux cut), every galaxy has
        V_max = V_survey so the estimator is exact:
            phi_j = (count in bin j) / (V_survey * dM_j)
        The normalised shape must match the normalised true Schechter PDF
        within the well-sampled magnitude range.
        """
        rng = np.random.default_rng(202)
        cat = _make_schechter_lf_cat_vollim(rng, n=12000)

        # Restrict to the magnitude range where the mock has enough galaxies.
        # For alpha=-1, most objects are faint (large M), so sample well from -22 to -17.
        mag_bins = np.linspace(-22.0, -17.0, 11)
        M_c, phi, _ = luminosity_function_vmax(cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO)

        populated = phi > 0
        if populated.sum() < 3:
            pytest.skip("Fewer than 3 populated bins — increase mock size.")

        # Evaluate the true Schechter (normalised) at populated bin centres
        phi_true = _schechter_lf(M_c[populated], TRUE_PHI_STAR, TRUE_M_STAR, TRUE_ALPHA)
        phi_rec_norm  = phi[populated] / phi[populated].sum()
        phi_true_norm = phi_true / phi_true.sum()
        ratio = phi_rec_norm / (phi_true_norm + 1e-30)

        # Normalised shapes should agree within a factor of 3 in all populated bins
        assert np.all(ratio > 0.1) and np.all(ratio < 10.0), \
            f"Vmax shape deviates from true Schechter: ratio range [{ratio.min():.2f}, {ratio.max():.2f}]"


# ---------------------------------------------------------------------------
# 2. SWML LF: shape recovery
# ---------------------------------------------------------------------------

class TestSWMLRecovery:
    def test_swml_positive_in_populated_bins(self):
        """SWML φ should be positive wherever 1/Vmax is positive.

        The SWML estimator uses a magnitude limit to build the accessibility
        matrix.  Its normalisation is matched to the 1/Vmax integral.  We
        verify that SWML returns positive values in bins that are populated
        according to 1/Vmax, and that the overall shape is non-trivially
        non-zero.
        """
        rng = np.random.default_rng(303)
        cat = _make_schechter_lf_cat(rng, n=8000)

        mag_bins = np.linspace(-24.0, -17.0, 15)
        _, phi_vmax, _ = luminosity_function_vmax(cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO)
        _, phi_swml, _ = luminosity_function_swml(
            cat, Z_MIN, Z_MAX, M_LIM, mag_bins, AREA_SR, COSMO
        )

        populated = phi_vmax > 0.01 * np.max(phi_vmax)
        if populated.sum() < 3:
            pytest.skip("Too few populated bins.")

        assert np.all(phi_swml[populated] >= 0), \
            "SWML returned negative values in populated bins."
        assert np.sum(phi_swml[populated]) > 0, \
            "SWML is zero in all populated bins."

    def test_vmax_swml_integrated_density_consistent(self):
        """Integrated densities from 1/Vmax and SWML should agree within 40%."""
        rng = np.random.default_rng(404)
        cat = _make_schechter_lf_cat(rng, n=6000)

        mag_bins = np.linspace(-24.0, -17.0, 15)
        dm = mag_bins[1] - mag_bins[0]

        _, phi_vmax, _ = luminosity_function_vmax(cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO)
        _, phi_swml, _ = luminosity_function_swml(
            cat, Z_MIN, Z_MAX, M_LIM, mag_bins, AREA_SR, COSMO
        )

        int_vmax = np.sum(phi_vmax) * dm
        int_swml = np.sum(phi_swml) * dm
        assert int_swml > 0
        ratio = int_swml / int_vmax
        assert 0.3 < ratio < 3.0, \
            f"Integrated density ratio SWML/Vmax = {ratio:.2f}, expected near 1"


# ---------------------------------------------------------------------------
# 3. C⁻ estimator: cumulative LF recovery
# ---------------------------------------------------------------------------

class TestCminusRecovery:
    def test_cminus_cumulative_positive_and_finite(self):
        """C⁻ cumulative LF must be positive, finite, and non-decreasing."""
        rng = np.random.default_rng(505)
        cat = _make_schechter_lf_cat(rng, n=4000)

        M_s, Phi, Phi_err = cumulative_luminosity_function_cminus(
            cat, Z_MIN, Z_MAX, M_LIM, AREA_SR, COSMO
        )

        assert np.all(Phi >= 0), "Cumulative LF has negative values."
        assert np.all(np.isfinite(Phi)), "Cumulative LF has non-finite values."
        # Non-decreasing (allow tiny floating-point reversals)
        assert np.all(np.diff(Phi) >= -1e-10 * np.abs(Phi[:-1])), \
            "Cumulative LF is not monotonically non-decreasing."

    def test_cminus_total_density_order_of_magnitude(self):
        """C⁻ total density should be in the range 10^-5 – 10^-1 Mpc^-3."""
        rng = np.random.default_rng(606)
        cat = _make_schechter_lf_cat(rng, n=4000)

        _, Phi, _ = cumulative_luminosity_function_cminus(
            cat, Z_MIN, Z_MAX, M_LIM, AREA_SR, COSMO
        )

        total = float(Phi[-1]) if len(Phi) > 0 else 0.0
        assert 1e-6 < total < 1.0, \
            f"C⁻ total density {total:.2e} Mpc^-3 out of expected range."


# ---------------------------------------------------------------------------
# 4. 1/Vmax SMF: double-Schechter recovery
# ---------------------------------------------------------------------------

class TestSMFVmaxRecovery:
    def test_smf_vmax_integrated_density(self):
        """Integrated 1/Vmax SMF should be a positive finite density."""
        rng = np.random.default_rng(707)
        cat = _make_double_schechter_smf_cat(rng, n=10000)

        mstar_bins = np.linspace(9.0, 12.5, 15)
        dm = mstar_bins[1] - mstar_bins[0]
        _, phi, _ = stellar_mass_function_vmax(cat, Z_MIN, Z_MAX, mstar_bins, AREA_SR, COSMO)

        integral = np.sum(phi) * dm
        assert integral > 0, "Integrated SMF is zero."
        assert np.isfinite(integral), "Integrated SMF is not finite."

    def test_smf_vmax_high_mass_cutoff(self):
        """1/Vmax SMF should drop by at least a factor 10 above log M* + 0.5.

        The double Schechter has an exponential cutoff above M*.  Even if the
        steep faint-end slope (α₂ = −1.53) causes the SMF to keep rising toward
        low masses, the high-mass end must fall off correctly.
        """
        rng = np.random.default_rng(808)
        cat = _make_double_schechter_smf_cat(rng, n=12000)

        mstar_bins = np.linspace(9.0, 12.5, 15)
        mstar_centres = 0.5 * (mstar_bins[:-1] + mstar_bins[1:])
        _, phi, _ = stellar_mass_function_vmax(cat, Z_MIN, Z_MAX, mstar_bins, AREA_SR, COSMO)

        # Find bins below and well above M*
        below_mstar = mstar_centres < TRUE_LOG_MSTAR - 0.3
        above_mstar = mstar_centres > TRUE_LOG_MSTAR + 0.5

        if below_mstar.sum() == 0 or above_mstar.sum() == 0:
            pytest.skip("Bins don't straddle M* — widen mstar_bins range.")
        if not np.any(phi[below_mstar] > 0):
            pytest.skip("No populated bins below M*.")

        phi_below = np.max(phi[below_mstar])
        phi_above = np.mean(phi[above_mstar]) if np.any(phi[above_mstar] > 0) else 0.0

        # phi should decrease significantly above M*
        assert phi_above < phi_below, \
            f"SMF does not drop above M*: phi_below={phi_below:.2e}, phi_above={phi_above:.2e}"


# ---------------------------------------------------------------------------
# 5. Completeness truncation: V_max with z_max_individual
# ---------------------------------------------------------------------------

class TestVmaxTruncation:
    def test_individual_zmax_truncation_does_not_bias_normalization(self):
        """Setting z_max_individual equal to z_max should give the same result."""
        rng = np.random.default_rng(909)
        cat = _make_schechter_lf_cat(rng, n=5000)

        mag_bins = np.linspace(-24, -16, 9)

        _, phi_default, _ = luminosity_function_vmax(
            cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO
        )
        z_max_ind = np.full(cat.n, Z_MAX)
        _, phi_explicit, _ = luminosity_function_vmax(
            cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO,
            z_max_individual=z_max_ind
        )

        # Both calls should give numerically identical results
        np.testing.assert_allclose(phi_default, phi_explicit, rtol=1e-10,
                                   err_msg="Explicit z_max_individual=z_max should not change phi.")

    def test_lower_zmax_individual_increases_normalization(self):
        """Reducing z_max_individual should increase phi (smaller V_max → larger weight)."""
        rng = np.random.default_rng(1001)
        cat = _make_schechter_lf_cat(rng, n=5000)

        mag_bins = np.linspace(-24, -16, 9)

        _, phi_full, _ = luminosity_function_vmax(
            cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO
        )
        # Restrict all galaxies to z_max = 0.15 < 0.20
        z_max_ind = np.full(cat.n, 0.15)
        _, phi_restricted, _ = luminosity_function_vmax(
            cat, Z_MIN, Z_MAX, mag_bins, AREA_SR, COSMO,
            z_max_individual=z_max_ind
        )

        # With a smaller V_max, phi should be >= phi_full in populated bins
        populated = (phi_full > 0) & (phi_restricted > 0)
        if populated.sum() > 0:
            assert np.all(phi_restricted[populated] >= phi_full[populated] * 0.9), \
                "Restricting z_max_individual should not decrease phi significantly."
