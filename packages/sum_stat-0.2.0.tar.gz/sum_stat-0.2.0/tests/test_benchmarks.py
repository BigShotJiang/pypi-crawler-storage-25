"""Wall-clock timing benchmarks for all major functions.

Run with:
    pytest tests/test_benchmarks.py -v -s

Each benchmark:
1. Warms up JIT-compiled functions once.
2. Times n_repeat=10 calls.
3. Reports median ± std wall-clock time.
4. Soft-asserts (warns) that timing is below a threshold.

Timing targets are machine-dependent. Recorded values are for reference on
a single CPU x86-64 core (update the docstrings after running on your machine).
"""

import time
import warnings
from contextlib import contextmanager

import numpy as np
import pytest
import jax
import jax.numpy as jnp
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.twopcf.angular import _landy_szalay_jax, w_theta_from_pair_counts
from sum_stat.twopcf.multipoles import _legendre_decompose_jax
from sum_stat.cosmology import comoving_distance_jax

COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)
N_REPEAT = 10


@contextmanager
def _timer(label: str, max_s: float | None = None):
    """Context manager that prints median wall-clock time."""
    times = []
    yield times
    if not times:
        return
    median_ms = np.median(times) * 1000
    std_ms = np.std(times) * 1000
    print(f"\n  {label}: {median_ms:.2f} ± {std_ms:.2f} ms/call  (n={len(times)})")
    if max_s is not None and np.median(times) > max_s:
        warnings.warn(f"{label}: {np.median(times):.2f} s > threshold {max_s} s")


def _bench(fn, *args, n_repeat=N_REPEAT, warmup=True, **kwargs):
    """Run fn(*args, **kwargs) n_repeat times and return list of wall-clock times."""
    if warmup:
        fn(*args, **kwargs)  # JIT warm-up
    times = []
    for _ in range(n_repeat):
        t0 = time.perf_counter()
        fn(*args, **kwargs)
        times.append(time.perf_counter() - t0)
    return times


class TestTimingCosmology:
    """chi(z) via JAX Gauss-Legendre quadrature.

    Target: < 5 ms post-JIT for N=1000 redshifts.
    Measured: ~ 2 ms  (post-JIT, N=1000, CPU x86-64, 2026-04-26)
    """

    def test_comoving_distance_jax(self):
        z = jnp.linspace(0.01, 2.0, 1000)
        fn = jax.jit(comoving_distance_jax)
        with _timer("comoving_distance_jax (N=1000)", max_s=0.05) as times:
            times.extend(_bench(fn, z, 0.6736, 0.3111))


class TestTimingAngularTwopcf:
    """Angular 2PCF estimators.

    Target: Landy-Szalay JAX < 1 ms post-JIT.
    Measured: ~ 0.01 ms  (post-JIT, n_bins=20, CPU x86-64, 2026-04-26)
    """

    def test_landy_szalay_jax(self):
        n_bins = 20
        dd = jnp.ones(n_bins) * 1000.0
        dr = jnp.ones(n_bins) * 10000.0
        rr = jnp.ones(n_bins) * 100000.0
        fn = jax.jit(_landy_szalay_jax)
        with _timer("_landy_szalay_jax (n_bins=20)", max_s=0.005) as times:
            times.extend(_bench(fn, dd, dr, rr, 1000.0, 10000.0))

    def test_w_theta_from_pair_counts(self):
        n_bins = 20
        dd = np.ones(n_bins) * 1000.0
        dr = np.ones(n_bins) * 10000.0
        rr = np.ones(n_bins) * 100000.0
        with _timer("w_theta_from_pair_counts (n_bins=20)", max_s=0.01) as times:
            times.extend(_bench(w_theta_from_pair_counts, dd, dr, rr, 1000, 10000))


class TestTimingMultipoles:
    """Legendre decomposition of ξ(s, μ).

    Target: < 50 ms post-JIT.
    Measured: ~ 1 ms  (post-JIT, n_s=20, n_mu=100, CPU x86-64, 2026-04-26)
    """

    def test_legendre_decompose_jax(self):
        n_s, n_mu = 20, 100
        xi_2d = jnp.ones((n_s, n_mu)) * 0.01
        mu = jnp.linspace(0, 1, n_mu, endpoint=False) + 0.5 / n_mu
        with _timer("_legendre_decompose_jax (n_s=20, n_mu=100)", max_s=0.5) as times:
            times.extend(_bench(_legendre_decompose_jax, xi_2d, mu, (0, 2, 4), warmup=False))


class TestTimingCovariance:
    """Jackknife and bootstrap covariance wall-clock timing.

    These are dominated by the estimator cost, not the resampling overhead.
    Recorded for n_regions=10, trivial estimator.
    Measured: ~ 50 ms  (n_regions=10, N=500, n_bins=5, CPU x86-64, 2026-04-26)
    """

    def test_jackknife_regions_assignment(self):
        from sum_stat.covariance.jackknife import assign_jackknife_regions
        rng = np.random.default_rng(0)
        ra = rng.uniform(0, 10, 5000)
        dec = rng.uniform(-5, 5, 5000)
        with _timer("assign_jackknife_regions (N=5000, n=100)", max_s=2.0) as times:
            times.extend(_bench(assign_jackknife_regions, ra, dec, 100, warmup=False))

    def test_jackknife_cov_from_subsamples(self):
        from sum_stat.covariance.jackknife import jackknife_covariance_from_subsamples
        rng = np.random.default_rng(1)
        subsamples = rng.normal(0, 1, (100, 20))
        with _timer("jackknife_cov_from_subsamples (n_jack=100, n_bins=20)", max_s=0.05) as times:
            times.extend(_bench(jackknife_covariance_from_subsamples, subsamples, warmup=False))
