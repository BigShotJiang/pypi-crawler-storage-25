"""Validation tests for JAX cosmology routines.

These tests compare comoving_distance_jax and comoving_volume_jax against:
1. Analytic solutions (Einstein-de Sitter model)
2. astropy FlatLambdaCDM as an independent reference implementation

All tolerances are physically motivated:
- 0.1% for comoving distance: quadrature precision target for GL-32
- 0.5 Mpc absolute for Planck18: < 0.02% at cosmological distances
- 1% for angular diameter distance: relevant for lensing cross-checks
"""

import numpy as np
import pytest
import jax.numpy as jnp
from astropy.cosmology import FlatLambdaCDM, Planck18

from sum_stat.cosmology import (
    comoving_distance_jax,
    comoving_volume_jax,
    critical_surface_density_jax,
    astropy_to_jax_cosmo,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_C_KM_S = 299792.458   # km/s

# Redshift grids for validation
_Z_SINGLE = np.array([0.1, 0.5, 1.0, 2.0])
_Z_GRID   = np.linspace(0.05, 3.0, 20)


# ---------------------------------------------------------------------------
# 1. Einstein-de Sitter analytic solution
# ---------------------------------------------------------------------------

class TestEinsteinDeSitter:
    """Validate against the analytic comoving distance for Ω_m=1, Ω_Λ=0.

    The exact solution is:
        χ(z) = (2 c / H₀) × [1 − 1/√(1+z)]

    Reference: Hogg (1999), arXiv:astro-ph/9905116, Eq. 15
    """

    H0 = 70.0
    OM = 1.0   # EdS: matter-only
    h  = H0 / 100.0

    def _chi_analytic(self, z):
        """Analytic comoving distance for EdS cosmology [Mpc]."""
        dh = _C_KM_S / self.H0
        return 2.0 * dh * (1.0 - 1.0 / np.sqrt(1.0 + z))

    def test_comoving_distance_eds(self):
        """JAX comoving distance agrees with EdS analytic solution within 0.1%."""
        for z in _Z_SINGLE:
            chi_jax      = float(comoving_distance_jax(z, self.h, self.OM))
            chi_analytic = float(self._chi_analytic(z))
            rtol = abs(chi_jax - chi_analytic) / chi_analytic
            assert rtol < 1e-3, (
                f"z={z}: χ_JAX={chi_jax:.3f} Mpc, χ_analytic={chi_analytic:.3f} Mpc, "
                f"relative error {rtol*100:.4f}% > 0.1%"
            )

    def test_comoving_distance_array_eds(self):
        """Array input gives same result as scalar loop for EdS."""
        chi_arr = np.array(comoving_distance_jax(_Z_SINGLE, self.h, self.OM))
        chi_ref = np.array([float(comoving_distance_jax(z, self.h, self.OM))
                            for z in _Z_SINGLE])
        np.testing.assert_allclose(chi_arr, chi_ref, rtol=1e-10,
                                   err_msg="Array vs scalar mismatch.")


# ---------------------------------------------------------------------------
# 2. Planck18 cross-check against astropy
# ---------------------------------------------------------------------------

class TestPlanck18VsAstropy:
    """Compare JAX routines to astropy FlatLambdaCDM for Planck 2018 params."""

    cosmo_astropy = FlatLambdaCDM(H0=67.4, Om0=0.315, name="Planck18_val")
    h     = 67.4 / 100.0
    om    = 0.315

    def test_comoving_distance_matches_astropy(self):
        """χ(z) agrees with astropy within 0.5 Mpc at all test redshifts."""
        chi_jax    = np.array(comoving_distance_jax(_Z_GRID, self.h, self.om))
        chi_astropy = self.cosmo_astropy.comoving_distance(_Z_GRID).to("Mpc").value

        diff = np.abs(chi_jax - chi_astropy)
        assert np.all(diff < 0.5), (
            f"Max comoving distance deviation = {diff.max():.3f} Mpc "
            f"(limit 0.5 Mpc) at z = {_Z_GRID[np.argmax(diff)]:.2f}"
        )

    def test_comoving_volume_matches_astropy(self):
        """V_c(z) agrees with astropy within 0.1% at all test redshifts."""
        vc_jax    = np.array(comoving_volume_jax(_Z_GRID, self.h, self.om))
        vc_astropy = self.cosmo_astropy.comoving_volume(_Z_GRID).to("Mpc3").value

        # Avoid z~0 where volumes are tiny and ratios are noisy
        z_ok = _Z_GRID > 0.1
        rtol = np.abs(vc_jax[z_ok] - vc_astropy[z_ok]) / vc_astropy[z_ok]
        assert np.all(rtol < 1e-3), (
            f"Max comoving volume relative deviation = {rtol.max()*100:.4f}% (limit 0.1%)"
        )

    def test_angular_diameter_distance_vs_astropy(self):
        """D_A(z) = χ(z)/(1+z) agrees with astropy within 1%."""
        z_test = np.array([0.1, 0.5, 1.0, 3.0])
        chi_jax = np.array(comoving_distance_jax(z_test, self.h, self.om))
        da_jax  = chi_jax / (1.0 + z_test)
        da_astropy = self.cosmo_astropy.angular_diameter_distance(z_test).to("Mpc").value

        rtol = np.abs(da_jax - da_astropy) / da_astropy
        assert np.all(rtol < 0.01), (
            f"D_A relative error max {rtol.max()*100:.3f}% > 1%"
        )

    def test_astropy_to_jax_cosmo_extractor(self):
        """astropy_to_jax_cosmo extracts h and omega_m correctly."""
        params = astropy_to_jax_cosmo(self.cosmo_astropy)
        assert abs(params["h"]       - self.h)  < 1e-10
        assert abs(params["omega_m"] - self.om) < 1e-10


# ---------------------------------------------------------------------------
# 3. Physical properties of the comoving volume
# ---------------------------------------------------------------------------

class TestComovingVolumeProperties:
    h  = 0.7
    om = 0.3

    def test_comoving_volume_monotone(self):
        """Comoving volume must be strictly increasing from z=0.01 to z=5."""
        z = np.linspace(0.01, 5.0, 200)
        vc = np.array(comoving_volume_jax(z, self.h, self.om))
        diffs = np.diff(vc)
        assert np.all(diffs > 0), (
            f"Comoving volume is not monotone; {(diffs <= 0).sum()} non-increasing steps."
        )

    def test_comoving_volume_zero_at_zero(self):
        """V_c(z=0) should be essentially zero."""
        vc = float(comoving_volume_jax(1e-6, self.h, self.om))
        assert vc < 1e-3, f"V_c(z≈0) = {vc:.2e} Mpc³, expected ~0"

    def test_comoving_distance_positive(self):
        """χ(z) must be positive for all z > 0."""
        z = np.linspace(0.001, 5.0, 100)
        chi = np.array(comoving_distance_jax(z, self.h, self.om))
        assert np.all(chi > 0), "Comoving distance has non-positive values."


# ---------------------------------------------------------------------------
# 4. V_max formula consistency
# ---------------------------------------------------------------------------

class TestVmaxConsistency:
    """Verify that the 1/V_max sum recovers a known number density.

    For a volume-limited survey (all objects visible at all z), Σ 1/V_max
    should equal N / V_survey, which is the estimated number density.
    """

    def test_vmax_sum_equals_number_density(self):
        """Σ 1/V_max should equal N / V_survey for a volume-limited sample."""
        import sum_stat as ss

        cosmo = FlatLambdaCDM(H0=70.0, Om0=0.3)
        z_min, z_max = 0.05, 0.15
        area_sr = float(np.deg2rad(10.0) ** 2)

        vc_min = cosmo.comoving_volume(z_min).to("Mpc3").value
        vc_max = cosmo.comoving_volume(z_max).to("Mpc3").value
        v_survey = (area_sr / (4.0 * np.pi)) * (vc_max - vc_min)

        n_gal = 500
        rng = np.random.default_rng(12345)
        z = rng.uniform(z_min, z_max, n_gal)

        cat = ss.GalaxyCatalogue(
            ra=np.zeros(n_gal), dec=np.zeros(n_gal), redshift=z
        )

        # For a volume-limited sample every object has V_max = V_survey
        vmax = cat.vmax(z_min, z_max, area_sr, cosmo)
        sum_inv_vmax = np.sum(1.0 / vmax)

        n_density_from_vmax   = sum_inv_vmax
        n_density_from_volume = n_gal / v_survey

        rtol = abs(n_density_from_vmax - n_density_from_volume) / n_density_from_volume
        assert rtol < 0.01, (
            f"Σ 1/V_max = {n_density_from_vmax:.4e} Mpc^-3, "
            f"N/V = {n_density_from_volume:.4e} Mpc^-3, "
            f"relative error {rtol*100:.2f}% > 1%"
        )
