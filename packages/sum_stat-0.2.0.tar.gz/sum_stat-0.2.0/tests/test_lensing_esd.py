"""Tests for galaxy-galaxy lensing: ΔΣ, shear calibration."""

import numpy as np
import pytest
import jax
import jax.numpy as jnp
from astropy.table import Table

import sum_stat as ss
from sum_stat.lensing.esd import delta_sigma
from sum_stat.lensing.shear_calib import (
    apply_multiplicative_bias,
    apply_shear_response,
    nz_from_calibration_table,
)


class TestShearCalib:
    def test_multiplicative_bias_correction(self):
        ds = jnp.array([10.0, 20.0, 30.0])
        ds_corr = apply_multiplicative_bias(ds, 0.05)
        np.testing.assert_allclose(np.array(ds_corr), np.array(ds) / 1.05, rtol=1e-6)

    def test_multiplicative_bias_zero(self):
        ds = jnp.array([10.0, 20.0])
        ds_corr = apply_multiplicative_bias(ds, 0.0)
        np.testing.assert_allclose(np.array(ds_corr), np.array(ds), rtol=1e-6)

    def test_multiplicative_bias_grad(self):
        ds = jnp.array([10.0, 20.0])
        grad_fn = jax.grad(lambda m: jnp.sum(apply_multiplicative_bias(ds, m)))
        g = grad_fn(0.05)
        assert not jnp.isnan(g)

    def test_shear_response_correction(self):
        e1 = jnp.array([0.1, 0.2, -0.1])
        e2 = jnp.array([-0.1, 0.1, 0.2])
        R11 = jnp.full(3, 0.85)
        R22 = jnp.full(3, 0.85)
        g1, g2 = apply_shear_response(e1, e2, R11, R22)
        np.testing.assert_allclose(np.array(g1), np.array(e1) / 0.85, rtol=1e-5)
        np.testing.assert_allclose(np.array(g2), np.array(e2) / 0.85, rtol=1e-5)

    def test_nz_from_calib_normalised(self, mock_photo_z_calib):
        z_bins = np.linspace(0.2, 1.5, 14)
        z_c, n_z = nz_from_calibration_table(mock_photo_z_calib, z_bins)
        dz = z_bins[1] - z_bins[0]
        assert abs(np.sum(n_z * dz) - 1.0) < 0.1

    def test_nz_lens_cut(self, mock_photo_z_calib):
        z_bins = np.linspace(0.0, 1.5, 16)
        _, n_z_all = nz_from_calibration_table(mock_photo_z_calib, z_bins, lens_z=None)
        _, n_z_cut = nz_from_calibration_table(mock_photo_z_calib, z_bins, lens_z=0.5)
        # n_z with lens cut should have less weight at low z
        assert np.sum(n_z_cut[:5]) <= np.sum(n_z_all[:5])


# ---------------------------------------------------------------------------
# Tests for delta_sigma() — require dsigma to be installed
# ---------------------------------------------------------------------------

dsigma = pytest.importorskip("dsigma", reason="dsigma not installed")


def _make_source_table(rng: np.random.Generator, n: int = 200) -> Table:
    """Build a minimal dsigma-formatted source table from synthetic shapes."""
    from dsigma.helpers import dsigma_table

    raw = Table(
        {
            "ra": rng.uniform(0.0, 10.0, n),
            "dec": rng.uniform(-5.0, 5.0, n),
            "z": rng.uniform(0.6, 1.2, n),
            "e_1": rng.normal(0.0, 0.28, n),
            "e_2": rng.normal(0.0, 0.28, n),
            "w": rng.uniform(0.5, 1.5, n),
            "m": rng.uniform(-0.05, 0.05, n),
            "e_rms": np.full(n, 0.27),
            "R11": np.full(n, 0.85),
            "R22": np.full(n, 0.85),
        }
    )
    return dsigma_table(raw, "source")


class TestDeltaSigma:
    def test_random_subtraction_requires_rand(self, mock_gal):
        """delta_sigma raises ValueError immediately if rand is missing."""
        rng = np.random.default_rng(0)
        table_s = _make_source_table(rng)
        rp_bins = np.logspace(-1, 1, 5)
        from astropy.cosmology import FlatLambdaCDM

        cosmo = FlatLambdaCDM(H0=67.4, Om0=0.315)
        with pytest.raises(ValueError, match="rand"):
            delta_sigma(
                mock_gal, table_s, rp_bins, cosmo,
                corrections={"random_subtraction": True},
            )

    def test_output_shapes(self, mock_gal, cosmo):
        """delta_sigma returns arrays of the right length."""
        rng = np.random.default_rng(1)
        table_s = _make_source_table(rng, n=500)
        rp_bins = np.logspace(-1, 1, 6)
        n_bins = len(rp_bins) - 1

        rp_c, ds, cov = delta_sigma(mock_gal, table_s, rp_bins, cosmo)

        assert rp_c.shape == (n_bins,)
        assert ds.shape == (n_bins,)
        assert cov.shape == (n_bins, n_bins)

    def test_rp_centres_geometric_mean(self, mock_gal, cosmo):
        """Bin centres are the geometric mean of the edges."""
        rng = np.random.default_rng(2)
        table_s = _make_source_table(rng, n=500)
        rp_bins = np.logspace(-1, 1, 5)
        expected = np.sqrt(rp_bins[:-1] * rp_bins[1:])

        rp_c, _, _ = delta_sigma(mock_gal, table_s, rp_bins, cosmo)

        np.testing.assert_allclose(rp_c, expected, rtol=1e-10)
