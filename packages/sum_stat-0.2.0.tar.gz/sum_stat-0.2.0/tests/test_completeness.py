"""Tests for the Johnston-Teodoro-Hendry (2007–2012) completeness scan estimator.

Validation strategy mirrors the cross-estimator Monte Carlo approach used in
Johnston (2011) §8: synthetic catalogues with known completeness properties are
used to verify that Tc and Tv behave as expected under both the null (complete)
and alternative (incomplete) hypotheses.
"""

import numpy as np
import pytest
from astropy.cosmology import FlatLambdaCDM

from sum_stat.lf_smf.completeness_scan import completeness_scan, _tc_tv_kernel

COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)
EXPECTED_KEYS = {"m_star", "Tc", "Tv", "Tc_err", "Tv_err", "n_galaxies"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_complete_cat(rng, n=1200, alpha=0.0, M_star=-21.0,
                       z_min=0.05, z_max=0.20, m_lim=18.5,
                       cosmo=COSMO):
    """Flux-limited Schechter sample (no missing galaxies)."""
    # Draw comoving volumes uniformly → uniform in V_c
    vc_min = cosmo.comoving_volume(z_min).value
    vc_max = cosmo.comoving_volume(z_max).value
    vc = rng.uniform(vc_min, vc_max, n)
    from astropy import units as u
    from astropy.cosmology import z_at_value
    z = np.array([z_at_value(cosmo.comoving_volume, vi * u.Mpc**3).value for vi in vc])
    shape = max(alpha + 1.0, 0.1)
    y = rng.gamma(shape, 1.0, n)
    y = np.clip(y, 1e-10, None)
    M = M_star - 2.5 * np.log10(y)
    mu = cosmo.distmod(z).value
    m_app = M + mu
    sel = m_app < m_lim
    if sel.sum() < 20:
        pytest.skip("Too few galaxies after flux cut.")
    return m_app[sel], M[sel], z[sel], m_lim


def _make_incomplete_cat(rng, n=1500, alpha=0.0, M_star=-21.0,
                         z_min=0.05, z_max=0.20, m_lim=18.5,
                         m_true=18.0, frac_missing=0.40,
                         cosmo=COSMO):
    """Flux-limited Schechter sample with a known incompleteness step at m_true.

    Galaxies with m_app in [m_true, m_true + 0.5] are removed with
    probability frac_missing to simulate a population missing near the limit.
    """
    m_app, M, z, _ = _make_complete_cat(rng, n=n, alpha=alpha,
                                         M_star=M_star, z_min=z_min,
                                         z_max=z_max, m_lim=m_lim, cosmo=cosmo)
    in_gap = (m_app >= m_true) & (m_app < m_true + 0.5)
    keep = np.ones(len(m_app), dtype=bool)
    gap_idx = np.where(in_gap)[0]
    n_remove = int(frac_missing * len(gap_idx))
    if n_remove > 0:
        remove = rng.choice(gap_idx, size=n_remove, replace=False)
        keep[remove] = False
    return m_app[keep], M[keep], z[keep], m_lim, m_true


# ---------------------------------------------------------------------------
# 1. Output structure
# ---------------------------------------------------------------------------


class TestCompletenessScanOutput:
    def test_keys_present(self):
        rng = np.random.default_rng(0)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=10)
        assert set(result.keys()) == EXPECTED_KEYS

    def test_array_lengths_fixed_grid(self):
        rng = np.random.default_rng(1)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        n_test = 15
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=n_test)
        for key in EXPECTED_KEYS:
            assert len(result[key]) == n_test, f"key={key}"

    def test_m_star_range(self):
        rng = np.random.default_rng(2)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=20)
        assert result["m_star"].min() >= m_app.min() - 1e-3
        assert result["m_star"].max() <= m_lim + 1e-3

    def test_n_galaxies_monotone_fixed(self):
        """Fixed-grid: more galaxies should be included as m* increases."""
        rng = np.random.default_rng(3)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=20)
        n = result["n_galaxies"]
        populated = n > 0
        if populated.sum() >= 2:
            # n_galaxies must be non-decreasing wherever populated
            idx = np.where(populated)[0]
            assert np.all(np.diff(n[idx]) >= 0)

    def test_raises_shape_mismatch(self):
        rng = np.random.default_rng(4)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        with pytest.raises(ValueError, match="same shape"):
            completeness_scan(m_app, M[:-1], z, m_lim, COSMO)

    def test_raises_not_1d(self):
        rng = np.random.default_rng(5)
        m_app, M, z, m_lim = _make_complete_cat(rng)
        with pytest.raises(ValueError, match="1-D"):
            completeness_scan(
                m_app.reshape(-1, 1), M.reshape(-1, 1), z.reshape(-1, 1), m_lim, COSMO
            )


# ---------------------------------------------------------------------------
# 2. Null hypothesis — complete sample
# ---------------------------------------------------------------------------


class TestCompleteSampleNull:
    """For a truly complete flux-limited sample, both Tc and Tv should
    be statistically consistent with N(0,1) at all scan points."""

    def _run(self, seed, n_test=30, n_gal=800):
        rng = np.random.default_rng(seed)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=n_gal)
        return completeness_scan(m_app, M, z, m_lim, COSMO, n_test=n_test)

    def test_tc_near_zero(self):
        result = self._run(42)
        finite = np.isfinite(result["Tc"])
        assert finite.sum() >= 5, "Too few finite Tc values."
        # At least 80 % of scan points should have |Tc| < 3 (3σ of N(0,1))
        frac_ok = (np.abs(result["Tc"][finite]) < 3.0).mean()
        assert frac_ok >= 0.70, f"Tc: only {frac_ok:.1%} within ±3 for complete sample"

    def test_tv_near_zero(self):
        result = self._run(43)
        finite = np.isfinite(result["Tv"])
        assert finite.sum() >= 5
        frac_ok = (np.abs(result["Tv"][finite]) < 3.0).mean()
        assert frac_ok >= 0.70, f"Tv: only {frac_ok:.1%} within ±3 for complete sample"

    def test_err_arrays_positive(self):
        result = self._run(44)
        for key in ("Tc_err", "Tv_err"):
            finite = np.isfinite(result[key])
            if finite.sum() > 0:
                assert np.all(result[key][finite] > 0), f"{key} contains non-positive values"


# ---------------------------------------------------------------------------
# 3. Detection of incompleteness
# ---------------------------------------------------------------------------


class TestIncompleteSampleDetection:
    """A sample with a deliberate magnitude gap should produce significantly
    negative Tc or Tv at the position of the gap."""

    def test_detects_missing_faint_galaxies(self):
        rng = np.random.default_rng(99)
        m_app, M, z, m_lim, m_true = _make_incomplete_cat(
            rng, n=1500, m_lim=18.5, m_true=18.0, frac_missing=0.5
        )
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=40)
        # We expect at least one scan point at m* ≥ m_true where Tc < −2
        above_true = result["m_star"] >= m_true
        Tc_above = result["Tc"][above_true]
        finite = np.isfinite(Tc_above)
        assert finite.sum() >= 2, "Not enough scan points above m_true."
        assert np.any(Tc_above[finite] < -1.5), (
            f"Tc did not drop below -1.5 above m_true={m_true}. "
            f"Min Tc = {Tc_above[finite].min():.2f}"
        )

    def test_complete_region_not_flagged(self):
        """Scan points well below the incompleteness threshold should be OK."""
        rng = np.random.default_rng(100)
        m_app, M, z, m_lim, m_true = _make_incomplete_cat(
            rng, n=1500, m_lim=18.5, m_true=18.0, frac_missing=0.5
        )
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=40)
        # Points at m* < m_true − 0.3 should be near zero
        safe = result["m_star"] < (m_true - 0.3)
        Tc_safe = result["Tc"][safe]
        finite = np.isfinite(Tc_safe)
        if finite.sum() >= 3:
            # Majority should be within ±3σ
            frac_ok = (np.abs(Tc_safe[finite]) < 4.0).mean()
            assert frac_ok >= 0.60, f"Too many |Tc| > 4 in safe region: {frac_ok:.1%}"


# ---------------------------------------------------------------------------
# 4. Bright-limit support
# ---------------------------------------------------------------------------


class TestBrightLimitSupport:
    """Results with an explicit bright limit should be finite and differ
    from the no-bright-limit case (different associated sets)."""

    def test_finite_with_bright_limit(self):
        rng = np.random.default_rng(7)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=800)
        m_bright = float(np.percentile(m_app, 10))
        result = completeness_scan(
            m_app, M, z, m_lim, COSMO, m_lim_bright=m_bright, n_test=20
        )
        assert set(result.keys()) == EXPECTED_KEYS
        finite_Tc = np.isfinite(result["Tc"])
        assert finite_Tc.sum() >= 3, "No finite Tc values with bright limit."

    def test_differs_from_no_bright_limit(self):
        rng = np.random.default_rng(8)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=800)
        m_bright = float(np.percentile(m_app, 20))

        res_no_bright = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=20)
        res_bright = completeness_scan(
            m_app, M, z, m_lim, COSMO, m_lim_bright=m_bright, n_test=20
        )
        # At least one Tc value should differ between the two modes
        diff = res_no_bright["Tc"] - res_bright["Tc"]
        finite = np.isfinite(diff)
        assert finite.sum() >= 3
        assert np.any(np.abs(diff[finite]) > 1e-10), "Bright limit had no effect on Tc."


# ---------------------------------------------------------------------------
# 5. Adaptive S/N mode (Paper II)
# ---------------------------------------------------------------------------


class TestAdaptiveSNMode:
    def test_runs_without_error(self):
        rng = np.random.default_rng(20)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=400)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, sn_target=5.0)
        assert set(result.keys()) == EXPECTED_KEYS

    def test_output_length_proportional_to_n_target(self):
        """With N_target = sn_target², adaptive scan produces N − N_target + 1 windows."""
        rng = np.random.default_rng(21)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=400)
        sn_target = 5.0
        N_target = max(int(sn_target**2), 10)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, sn_target=sn_target)
        n_out = len(result["m_star"])
        n_gal = len(m_app)
        # Exact count may be slightly less if some windows are skipped
        assert n_out <= n_gal - N_target + 1
        assert n_out > 0, "No output windows produced."

    def test_m_star_sorted(self):
        rng = np.random.default_rng(22)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=300)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, sn_target=5.0)
        if len(result["m_star"]) > 1:
            assert np.all(np.diff(result["m_star"]) >= 0), "m_star not sorted in adaptive mode."

    def test_raises_too_small_sample(self):
        rng = np.random.default_rng(23)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=400)
        with pytest.raises(ValueError, match="N_target"):
            completeness_scan(m_app[:5], M[:5], z[:5], m_lim, COSMO, sn_target=20.0)


# ---------------------------------------------------------------------------
# 6. Kernel edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_kernel_too_few_galaxies(self):
        """_tc_tv_kernel returns nans when n_used < 3."""
        mu = np.array([1.0, 1.5])
        Tc, Tv, _, _, n_used = _tc_tv_kernel(
            np.array([-21.0, -20.0]),
            np.array([0.1, 0.12]),
            18.0, mu, None
        )
        assert np.isnan(Tc) or n_used == 0

    def test_kernel_returns_finite_for_adequate_sample(self):
        rng = np.random.default_rng(50)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=200)
        mu = COSMO.distmod(z).value
        Tc, Tv, Tc_err, Tv_err, n_used = _tc_tv_kernel(M, z, m_lim, mu, None)
        assert n_used >= 3
        assert np.isfinite(Tc)
        assert np.isfinite(Tv)
        assert Tc_err == 1.0
        assert Tv_err == 1.0

    def test_fixed_grid_handles_sparse_start(self):
        """First grid points with very few galaxies should yield NaN gracefully."""
        rng = np.random.default_rng(60)
        m_app, M, z, m_lim = _make_complete_cat(rng, n=300)
        result = completeness_scan(m_app, M, z, m_lim, COSMO, n_test=50)
        # First points may be NaN (< 3 galaxies) — that is correct behaviour
        assert all(isinstance(v, np.ndarray) for v in result.values())

    def test_public_api_accessible(self):
        import sum_stat as ss
        assert hasattr(ss, "completeness_scan")
        assert callable(ss.completeness_scan)
