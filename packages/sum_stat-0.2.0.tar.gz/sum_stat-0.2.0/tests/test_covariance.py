"""Tests for jackknife and bootstrap covariance estimators."""

import numpy as np
import pytest

from sum_stat.covariance.jackknife import (
    assign_jackknife_regions,
    jackknife_covariance_from_subsamples,
)
from sum_stat.covariance.bootstrap import bootstrap_covariance


class TestAssignJackknifeRegions:
    def test_label_count(self):
        rng = np.random.default_rng(0)
        ra = rng.uniform(0, 10, 500)
        dec = rng.uniform(-5, 5, 500)
        labels = assign_jackknife_regions(ra, dec, n_regions=20)
        assert labels.shape == (500,)
        unique = np.unique(labels)
        assert len(unique) == 20
        assert unique.min() == 0
        assert unique.max() == 19

    def test_reproducible_with_seed(self):
        rng = np.random.default_rng(1)
        ra = rng.uniform(0, 10, 200)
        dec = rng.uniform(-5, 5, 200)
        l1 = assign_jackknife_regions(ra, dec, n_regions=10, seed=42)
        l2 = assign_jackknife_regions(ra, dec, n_regions=10, seed=42)
        np.testing.assert_array_equal(l1, l2)


class TestJackknifeFromSubsamples:
    def test_shape(self):
        n_jack, n_bins = 50, 10
        rng = np.random.default_rng(0)
        subsamples = rng.normal(1.0, 0.1, (n_jack, n_bins))
        mean, cov = jackknife_covariance_from_subsamples(subsamples)
        assert mean.shape == (n_bins,)
        assert cov.shape == (n_bins, n_bins)

    def test_positive_semidefinite(self):
        rng = np.random.default_rng(1)
        subsamples = rng.normal(0, 1, (100, 8))
        _, cov = jackknife_covariance_from_subsamples(subsamples)
        eigenvalues = np.linalg.eigvalsh(cov)
        assert np.all(eigenvalues >= -1e-10)

    def test_diagonal_positive(self):
        rng = np.random.default_rng(2)
        subsamples = rng.normal(0, 1, (50, 6))
        _, cov = jackknife_covariance_from_subsamples(subsamples)
        assert np.all(np.diag(cov) >= 0)

    def test_mean_close_to_true_mean(self):
        # Mean of jackknife subsamples ≈ true mean
        true_mean = np.array([1.0, 2.0, 3.0])
        n_jack = 100
        rng = np.random.default_rng(3)
        subsamples = true_mean[None, :] + rng.normal(0, 0.1, (n_jack, 3))
        mean, _ = jackknife_covariance_from_subsamples(subsamples)
        np.testing.assert_allclose(mean, true_mean, atol=0.05)

    def test_single_jackknife_region(self):
        subsamples = np.array([[1.0, 2.0, 3.0]])
        mean, cov = jackknife_covariance_from_subsamples(subsamples)
        assert mean.shape == (3,)
        np.testing.assert_allclose(cov, np.zeros((3, 3)), atol=1e-10)


class TestBootstrapCovariance:
    def test_shape(self):
        rng = np.random.default_rng(0)
        n = 500
        ra = rng.uniform(0, 10, n)
        dec = rng.uniform(-5, 5, n)
        data = rng.normal(0, 1, n)

        def estimator(mask):
            return np.array([np.mean(data[mask]), np.std(data[mask])])

        mean, cov = bootstrap_covariance(ra, dec, estimator, n_bootstrap=50, n_patches=10)
        assert mean.shape == (2,)
        assert cov.shape == (2, 2)

    def test_covariance_positive_semidefinite(self):
        rng = np.random.default_rng(1)
        n = 300
        ra = rng.uniform(0, 10, n)
        dec = rng.uniform(-5, 5, n)
        data = rng.normal(0, 1, (n, 4))

        def estimator(mask):
            return np.mean(data[mask], axis=0)

        _, cov = bootstrap_covariance(ra, dec, estimator, n_bootstrap=100, n_patches=10)
        eigenvalues = np.linalg.eigvalsh(cov)
        assert np.all(eigenvalues >= -1e-10)
