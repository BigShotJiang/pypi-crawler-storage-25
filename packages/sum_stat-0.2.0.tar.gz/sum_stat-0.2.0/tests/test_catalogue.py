"""Tests for catalogue dataclasses."""

import numpy as np
import pytest
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss


COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)


class TestGalaxyCatalogue:
    def test_basic_construction(self):
        cat = ss.GalaxyCatalogue(
            ra=np.array([1.0, 2.0]),
            dec=np.array([0.0, 1.0]),
            redshift=np.array([0.1, 0.2]),
        )
        assert cat.n == 2
        assert cat.weight.shape == (2,)
        np.testing.assert_array_equal(cat.weight, np.ones(2))

    def test_weight_default_ones(self):
        cat = ss.GalaxyCatalogue(
            ra=np.ones(10), dec=np.zeros(10), redshift=np.full(10, 0.3)
        )
        assert np.all(cat.weight == 1.0)

    def test_shape_mismatch_raises(self):
        with pytest.raises(ValueError, match="same length"):
            ss.GalaxyCatalogue(
                ra=np.ones(5), dec=np.ones(3), redshift=np.ones(5)
            )

    def test_weight_mismatch_raises(self):
        with pytest.raises(ValueError, match="same length"):
            ss.GalaxyCatalogue(
                ra=np.ones(5), dec=np.ones(5), redshift=np.ones(5),
                weight=np.ones(3),
            )

    def test_optional_fields_stored(self):
        cat = ss.GalaxyCatalogue(
            ra=np.ones(4), dec=np.zeros(4), redshift=np.full(4, 0.2),
            log10_mstar=np.full(4, 10.5),
        )
        assert cat.log10_mstar is not None
        assert cat.log10_mstar.shape == (4,)

    def test_comoving_distance_positive(self):
        cat = ss.GalaxyCatalogue(
            ra=np.zeros(3), dec=np.zeros(3), redshift=np.array([0.1, 0.3, 0.5])
        )
        chi = cat.comoving_distance(COSMO)
        assert chi.shape == (3,)
        assert np.all(chi > 0)
        assert np.all(np.diff(chi) > 0)

    def test_vmax_positive_and_monotone(self):
        cat = ss.GalaxyCatalogue(
            ra=np.zeros(3), dec=np.zeros(3), redshift=np.array([0.1, 0.2, 0.3])
        )
        area_sr = np.deg2rad(10.0) ** 2
        vmax = cat.vmax(0.05, 0.4, area_sr, COSMO)
        assert vmax.shape == (3,)
        assert np.all(vmax > 0)

    def test_vmax_increases_with_z_max(self):
        cat = ss.GalaxyCatalogue(
            ra=np.zeros(1), dec=np.zeros(1), redshift=np.array([0.2])
        )
        area_sr = np.deg2rad(5.0) ** 2
        v1 = cat.vmax(0.05, 0.3, area_sr, COSMO)
        v2 = cat.vmax(0.05, 0.5, area_sr, COSMO)
        assert v2[0] > v1[0]


class TestShapeCatalogue:
    def test_basic_construction(self, mock_src):
        assert mock_src.n == 3000
        assert mock_src.e1.shape == (3000,)

    def test_mean_m(self, mock_src):
        m_mean = mock_src.mean_m()
        assert isinstance(m_mean, float)
        assert -0.1 < m_mean < 0.1

    def test_mean_R(self, mock_src):
        R11, R22 = mock_src.mean_R()
        assert abs(R11 - 0.85) < 0.01
        assert abs(R22 - 0.85) < 0.01


class TestPhotoZCalibTable:
    def test_basic_construction(self, mock_photo_z_calib):
        assert mock_photo_z_calib.n == 500

    def test_n_of_z_normalised(self, mock_photo_z_calib):
        z_bins = np.linspace(0.0, 1.5, 16)
        z_centres, n_z = mock_photo_z_calib.n_of_z(z_bins)
        assert z_centres.shape == (15,)
        # n_of_z divides by counts.sum() so n_z sums to 1 (not integrates to 1)
        assert abs(np.sum(n_z) - 1.0) < 0.05
