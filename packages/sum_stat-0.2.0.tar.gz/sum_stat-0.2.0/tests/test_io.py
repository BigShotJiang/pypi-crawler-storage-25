"""Tests for HDF5 writer / reader round-trips."""

import tempfile
from pathlib import Path

import numpy as np
import pytest
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.io.writer import SummaryStatWriter
from sum_stat.io.reader import SummaryStatReader


COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111, name="Planck18_test")
N = 15  # number of bins


@pytest.fixture
def tmp_h5(tmp_path):
    return tmp_path / "test.h5"


class TestWriterReader:
    def test_lf_round_trip(self, tmp_h5):
        mag_centres = np.linspace(-23, -17, N)
        bin_edges = np.linspace(-23.5, -16.5, N + 1)
        phi = np.abs(np.random.default_rng(0).normal(1e-3, 1e-4, N))
        phi_err = phi * 0.1
        cov = np.diag(phi_err ** 2)

        with SummaryStatWriter(tmp_h5) as w:
            w.write_lf(
                "lf/test_sample",
                mag_centres, phi, phi_err, cov, bin_edges,
                COSMO, {"estimator": "1/Vmax", "band": "r", "z_min": 0.1, "z_max": 0.3},
            )

        with SummaryStatReader(tmp_h5) as r:
            result = r.read_lf("lf/test_sample")

        np.testing.assert_allclose(result["M_centres"], mag_centres, rtol=1e-6)
        np.testing.assert_allclose(result["phi"], phi, rtol=1e-6)
        np.testing.assert_allclose(result["cov"], cov, rtol=1e-6)
        assert result["attrs"]["estimator"] == "1/Vmax"

    def test_twopcf_round_trip(self, tmp_h5):
        theta_centres = np.logspace(0, 2, N)
        bin_edges = np.logspace(-0.1, 2.1, N + 1)
        xi = np.abs(np.random.default_rng(1).normal(0.01, 0.005, N))
        cov = np.diag((xi * 0.1) ** 2)

        with SummaryStatWriter(tmp_h5) as w:
            w.write_twopcf(
                "angular_2pcf/test",
                theta_centres, xi, cov, bin_edges,
                "landy-szalay", COSMO, {},
                sep_unit="arcmin",
            )

        with SummaryStatReader(tmp_h5) as r:
            result = r.read_twopcf("angular_2pcf/test")

        np.testing.assert_allclose(result["xi"], xi, rtol=1e-6)
        np.testing.assert_allclose(result["sep_centres"], theta_centres, rtol=1e-6)
        assert result["attrs"]["estimator"] == "landy-szalay"

    def test_esd_round_trip(self, tmp_h5):
        rp = np.logspace(-1, 1.5, N)
        bin_edges = np.logspace(-1.1, 1.6, N + 1)
        ds = np.abs(np.random.default_rng(2).normal(10.0, 2.0, N))
        cov = np.diag((ds * 0.15) ** 2)

        with SummaryStatWriter(tmp_h5) as w:
            w.write_esd(
                "esd/test",
                rp, ds, cov, bin_edges, COSMO,
                {"lens_survey": "mock", "source_survey": "mock"},
            )

        with SummaryStatReader(tmp_h5) as r:
            result = r.read_esd("esd/test")

        np.testing.assert_allclose(result["delta_sigma"], ds, rtol=1e-6)
        np.testing.assert_allclose(result["cov"], cov, rtol=1e-6)

    def test_cosmology_round_trip(self, tmp_h5):
        data = np.ones(5)
        with SummaryStatWriter(tmp_h5) as w:
            w.write_twopcf(
                "twopcf/cosmo_test",
                data, data, np.eye(5), data, "ls", COSMO, {},
            )

        with SummaryStatReader(tmp_h5) as r:
            cosmo_out = r.cosmology("twopcf/cosmo_test")

        assert abs(cosmo_out.H0.value - 67.36) < 1e-4
        assert abs(cosmo_out.Om0 - 0.3111) < 1e-6

    def test_list_statistics(self, tmp_h5):
        with SummaryStatWriter(tmp_h5) as w:
            data = np.ones(5)
            w.write_twopcf("angular_2pcf/A", data, data, np.eye(5), data, "ls", COSMO, {})
            w.write_twopcf("angular_2pcf/B", data, data, np.eye(5), data, "ls", COSMO, {})

        with SummaryStatReader(tmp_h5) as r:
            paths = r.list_statistics()

        assert "angular_2pcf/A" in paths
        assert "angular_2pcf/B" in paths

    def test_context_manager_closes(self, tmp_h5):
        with SummaryStatWriter(tmp_h5):
            pass
        # File should be readable after context exit
        with SummaryStatReader(tmp_h5):
            pass

    def test_multipoles_round_trip(self, tmp_h5):
        s_centres = np.logspace(0.5, 2, N)
        bin_edges = np.logspace(0.4, 2.1, N + 1)
        xi0 = np.random.default_rng(3).normal(0.01, 0.003, N)
        xi2 = np.random.default_rng(4).normal(0.005, 0.001, N)
        xi4 = np.random.default_rng(5).normal(0.001, 0.0005, N)
        xi_dict = {0: xi0, 2: xi2, 4: xi4}
        cov = np.eye(3 * N) * 1e-6

        with SummaryStatWriter(tmp_h5) as w:
            w.write_multipoles("multipoles/test", s_centres, xi_dict, cov,
                               bin_edges, COSMO, {})

        with SummaryStatReader(tmp_h5) as r:
            result = r.read_multipoles("multipoles/test")

        np.testing.assert_allclose(result["xi0"], xi0, rtol=1e-6)
        np.testing.assert_allclose(result["xi2"], xi2, rtol=1e-6)
