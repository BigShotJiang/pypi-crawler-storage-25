"""Tests for angular two-point correlation function w(θ)."""

import numpy as np
import pytest
import jax
import jax.numpy as jnp

from sum_stat.twopcf.angular import _landy_szalay_jax, _davis_peebles_jax, w_theta_from_pair_counts


class TestLandySzalayJax:
    def test_output_shape(self):
        n_bins = 10
        dd = jnp.ones(n_bins) * 100.0
        dr = jnp.ones(n_bins) * 300.0
        rr = jnp.ones(n_bins) * 900.0
        w = _landy_szalay_jax(dd, dr, rr, 100, 900)
        assert w.shape == (n_bins,)

    def test_jit_compilable(self):
        fn = jax.jit(_landy_szalay_jax)
        dd = jnp.ones(5) * 50.0
        dr = jnp.ones(5) * 150.0
        rr = jnp.ones(5) * 450.0
        result = fn(dd, dr, rr, 50, 450)
        assert result.shape == (5,)

    def test_near_zero_for_poisson_field(self):
        # For a Poisson (unclustered) field, LS ≈ 0 with finite-N corrections O(1/N).
        # Use large N so the correction < 1e-3.
        n_gal, n_rand = 10000.0, 100000.0
        p = 1.0  # arbitrary density proportionality
        # Poisson expected counts: DD ∝ n_gal^2, DR ∝ n_gal*n_rand, RR ∝ n_rand^2
        rr = jnp.ones(5) * n_rand ** 2 * p
        dr = jnp.ones(5) * n_gal * n_rand * p
        dd = jnp.ones(5) * n_gal ** 2 * p
        w = _landy_szalay_jax(dd, dr, rr, n_gal, n_rand)
        np.testing.assert_allclose(np.array(w), 0.0, atol=1e-3)

    def test_positive_for_clustered(self):
        # More DD pairs than expected -> positive w
        n_gal, n_rand = 100.0, 1000.0
        alpha = n_rand / n_gal
        rr = jnp.ones(5) * 1000.0
        dr = rr / alpha
        dd = rr / alpha ** 2 * 2.0  # 2x more DD than Poisson
        w = _landy_szalay_jax(dd, dr, rr, n_gal, n_rand)
        assert float(jnp.mean(w)) > 0.0

    def test_grad_wrt_dd(self):
        grad_fn = jax.grad(lambda dd: jnp.sum(_landy_szalay_jax(dd, jnp.ones(3) * 100.0,
                                                                   jnp.ones(3) * 900.0, 50, 900)))
        dd = jnp.ones(3) * 50.0
        g = grad_fn(dd)
        assert not jnp.any(jnp.isnan(g))


class TestDavisPeeblesJax:
    def test_zero_for_unclustered(self):
        n_gal, n_rand = 100.0, 1000.0
        # DP = nr/nd * DD/DR - 1 = 0 when DD/DR = nd/nr
        dr = jnp.ones(5) * 500.0
        dd = dr * (n_gal / n_rand)
        w = _davis_peebles_jax(dd, dr, n_gal, n_rand)
        np.testing.assert_allclose(np.array(w), 0.0, atol=1e-10)

    def test_jit_compilable(self):
        fn = jax.jit(_davis_peebles_jax)
        result = fn(jnp.ones(4) * 10.0, jnp.ones(4) * 100.0, 20.0, 200.0)
        assert result.shape == (4,)


class TestWThetaFromPairCounts:
    def test_landy_szalay(self):
        n_gal, n_rand = 1000, 10000
        n_bins = 8
        dd = np.full(n_bins, 500.0)
        dr = np.full(n_bins, 5000.0)
        rr = np.full(n_bins, 50000.0)
        w = w_theta_from_pair_counts(dd, dr, rr, n_gal, n_rand, "landy-szalay")
        assert w.shape == (n_bins,)

    def test_davis_peebles(self):
        n_gal, n_rand = 1000, 10000
        n_bins = 8
        dd = np.full(n_bins, 500.0)
        dr = np.full(n_bins, 5000.0)
        w = w_theta_from_pair_counts(dd, dr, np.ones(n_bins), n_gal, n_rand, "davis-peebles")
        assert w.shape == (n_bins,)

    def test_unknown_estimator_raises(self):
        with pytest.raises(ValueError, match="Unknown estimator"):
            w_theta_from_pair_counts(np.ones(5), np.ones(5), np.ones(5), 100, 1000, "wrong")
