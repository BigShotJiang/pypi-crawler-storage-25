"""Physical recovery test for DeltaSigma (stub — not yet implemented).

This test verifies that the excess surface density estimator delta_sigma
recovers a known signal from a synthetic NFW lens-source configuration.

See docs/testing.rst "Test coverage gaps" for the pass criteria.
"""

import pytest


@pytest.mark.skip(reason="not yet implemented — see docs/testing.rst coverage gaps")
def test_delta_sigma_recovers_nfw_mass():
    """Recover M200c from a synthetic NFW convergence profile.

    Setup: place N_lens lenses at fixed z_lens with known M200c; generate
    N_source sources at z_source > z_lens with shear computed analytically
    from the NFW profile; construct a ShapeCatalogue and run sum_stat.delta_sigma.
    Fit the output ΔΣ(r_p) with an NFW model to recover M200c.

    Pass criterion: |M200c_hat - M200c_true| / M200c_true < 0.30.
    """
    raise NotImplementedError
