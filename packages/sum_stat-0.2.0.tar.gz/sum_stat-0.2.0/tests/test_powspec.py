"""Tests for power spectrum estimators (C_ℓ and P(k))."""

import numpy as np
import pytest
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.powspec.angular_cl import cl_angular
from sum_stat.powspec.pk3d import pk3d, pk_multipoles


COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)


class TestClAngular:
    def test_output_shapes(self, mock_gal):
        ell_bins = np.array([10, 20, 50, 100, 200, 500])
        ell_eff, cl, nl, cov = cl_angular(mock_gal, nside=64, ell_bins=ell_bins)
        n_bins = len(ell_bins) - 1
        assert ell_eff.shape == (n_bins,)
        assert cl.shape == (n_bins,)
        assert nl.shape == (n_bins,)
        assert cov.shape == (n_bins, n_bins)

    def test_shot_noise_positive(self, mock_gal):
        ell_bins = np.array([10, 30, 100, 300])
        _, cl, nl, _ = cl_angular(mock_gal, nside=64, ell_bins=ell_bins)
        assert np.all(nl >= 0)

    def test_covariance_diagonal_positive(self, mock_gal):
        ell_bins = np.array([10, 50, 200])
        _, _, _, cov = cl_angular(mock_gal, nside=64, ell_bins=ell_bins)
        assert np.all(np.diag(cov) >= 0)

    def test_ell_eff_in_bins(self, mock_gal):
        ell_bins = np.array([10, 30, 100])
        ell_eff, _, _, _ = cl_angular(mock_gal, nside=64, ell_bins=ell_bins)
        assert ell_eff[0] >= 10
        assert ell_eff[0] < 30
        assert ell_eff[1] >= 30
        assert ell_eff[1] < 100


class TestPk3d:
    def test_output_shapes(self, mock_gal):
        k_bins = np.logspace(-1, 0.5, 8)
        k_centres, pk, n_modes = pk3d(mock_gal, COSMO, k_bins, n_grid=32)
        n_bins = len(k_bins) - 1
        assert k_centres.shape == (n_bins,)
        assert pk.shape == (n_bins,)
        assert n_modes.shape == (n_bins,)

    def test_n_modes_positive(self, mock_gal):
        k_bins = np.logspace(-1, 0.5, 6)
        _, _, n_modes = pk3d(mock_gal, COSMO, k_bins, n_grid=32)
        assert np.all(n_modes >= 0)

    def test_k_centres_increasing(self, mock_gal):
        k_bins = np.logspace(-1, 0.5, 8)
        k_c, _, _ = pk3d(mock_gal, COSMO, k_bins, n_grid=32)
        # k_centres should be monotonically non-decreasing
        filled = k_c > 0
        if filled.sum() > 1:
            assert np.all(np.diff(k_c[filled]) >= 0)


class TestPkMultipoles:
    def test_output_shapes(self, mock_gal):
        k_bins = np.logspace(-1, 0.5, 6)
        k_c, pk_dict = pk_multipoles(mock_gal, COSMO, k_bins, n_grid=32, n_mu_bins=20)
        n_bins = len(k_bins) - 1
        assert k_c.shape == (n_bins,)
        assert 0 in pk_dict
        assert pk_dict[0].shape == (n_bins,)

    def test_multipole_keys_present(self, mock_gal):
        k_bins = np.logspace(-1, 0.5, 5)
        _, pk_dict = pk_multipoles(mock_gal, COSMO, k_bins, ells=(0, 2, 4),
                                    n_grid=32, n_mu_bins=20)
        assert set(pk_dict.keys()) == {0, 2, 4}
