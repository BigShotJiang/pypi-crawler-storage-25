"""Tests for luminosity function and stellar mass function estimators.

Monte Carlo comparison tests reproduce the spirit of the cross-estimator
comparison in Johnston (2011), arXiv:1106.2039v3, §8.
"""

import numpy as np
import pytest
import jax
import jax.numpy as jnp
from astropy.cosmology import FlatLambdaCDM

import sum_stat as ss
from sum_stat.lf_smf.vmax import luminosity_function_vmax, stellar_mass_function_vmax
from sum_stat.lf_smf.swml import luminosity_function_swml
from sum_stat.lf_smf.cminus import cumulative_luminosity_function_cminus
from sum_stat.lf_smf.independence import efron_petrosian_tau, rauzy_completeness

COSMO = FlatLambdaCDM(H0=67.36, Om0=0.3111)
AREA_SR = float(np.deg2rad(10.0) ** 2)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_schechter_cat(rng, n=800, alpha=0.0, M_star=-21.0,
                        z_min=0.05, z_max=0.20, m_lim=18.5,
                        cosmo=COSMO, area_sr=AREA_SR):
    """Generate a flux-limited catalogue drawn from a Schechter LF."""
    vc_min = cosmo.comoving_volume(z_min).value
    vc_max = cosmo.comoving_volume(z_max).value
    vc = rng.uniform(vc_min, vc_max, n)
    from astropy import units as u
    from astropy.cosmology import z_at_value
    z = np.array([
        z_at_value(cosmo.comoving_volume, vi * u.Mpc**3).value for vi in vc
    ])
    shape = max(alpha + 1.0, 0.1)
    y = rng.gamma(shape, 1.0, n)
    y = np.clip(y, 1e-10, None)
    M = M_star - 2.5 * np.log10(y)
    mu = cosmo.distmod(z).value
    obs = (M + mu) < m_lim
    M = M[obs]
    z = z[obs]
    if len(M) < 10:
        pytest.skip("Too few galaxies after flux cut — increase n.")
    return ss.GalaxyCatalogue(
        ra=np.zeros(len(M)),
        dec=np.zeros(len(M)),
        redshift=z,
        abs_mag=M,
    ), m_lim


# ---------------------------------------------------------------------------
# 1/Vmax LF
# ---------------------------------------------------------------------------

class TestVmaxLF:
    def test_output_shapes(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        M_c, phi, phi_err = luminosity_function_vmax(
            mock_gal, 0.1, 0.5, mag_bins, AREA_SR, COSMO
        )
        assert M_c.shape == (8,)
        assert phi.shape == (8,)
        assert phi_err.shape == (8,)

    def test_phi_positive(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        _, phi, _ = luminosity_function_vmax(mock_gal, 0.1, 0.5, mag_bins, AREA_SR, COSMO)
        assert np.all(phi >= 0)

    def test_phi_err_le_phi(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        _, phi, phi_err = luminosity_function_vmax(mock_gal, 0.1, 0.5, mag_bins, AREA_SR, COSMO)
        populated = phi > 0
        if populated.sum() > 0:
            assert np.all(phi_err[populated] <= phi[populated] * 2)

    def test_raises_without_abs_mag(self, mock_rand):
        mag_bins = np.linspace(-24, -16, 9)
        with pytest.raises(ValueError, match="abs_mag"):
            luminosity_function_vmax(mock_rand, 0.1, 0.5, mag_bins, AREA_SR, COSMO)


# ---------------------------------------------------------------------------
# 1/Vmax SMF
# ---------------------------------------------------------------------------

class TestVmaxSMF:
    def test_output_shapes(self, mock_gal):
        mstar_bins = np.linspace(8.5, 12.5, 9)
        M_c, phi, phi_err = stellar_mass_function_vmax(
            mock_gal, 0.1, 0.5, mstar_bins, AREA_SR, COSMO
        )
        assert M_c.shape == (8,)
        assert phi.shape == (8,)
        assert np.all(phi >= 0)

    def test_raises_without_log10_mstar(self):
        cat = ss.GalaxyCatalogue(
            ra=np.ones(10), dec=np.zeros(10), redshift=np.full(10, 0.2)
        )
        with pytest.raises(ValueError, match="log10_mstar"):
            stellar_mass_function_vmax(cat, 0.1, 0.5, np.linspace(9, 12, 5), AREA_SR, COSMO)


# ---------------------------------------------------------------------------
# SWML
# ---------------------------------------------------------------------------

class TestSWML:
    def test_output_shapes(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        M_c, phi, phi_err = luminosity_function_swml(
            mock_gal, 0.1, 0.5, 20.0, mag_bins, AREA_SR, COSMO
        )
        assert M_c.shape == (8,)
        assert phi.shape == (8,)
        assert phi_err.shape == (8,)

    def test_phi_positive(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        _, phi, _ = luminosity_function_swml(
            mock_gal, 0.1, 0.5, 20.0, mag_bins, AREA_SR, COSMO
        )
        assert np.all(phi >= 0)

    def test_raises_without_abs_mag(self, mock_rand):
        mag_bins = np.linspace(-24, -16, 9)
        with pytest.raises(ValueError, match="abs_mag"):
            luminosity_function_swml(mock_rand, 0.1, 0.5, 20.0, mag_bins, AREA_SR, COSMO)

    def test_phi_err_le_phi(self, mock_gal):
        mag_bins = np.linspace(-24, -16, 9)
        _, phi, phi_err = luminosity_function_swml(
            mock_gal, 0.1, 0.5, 20.0, mag_bins, AREA_SR, COSMO
        )
        populated = phi > 0
        if populated.sum() > 0:
            assert np.all(phi_err[populated] <= phi[populated] * 2)


# ---------------------------------------------------------------------------
# C⁻ cumulative LF
# ---------------------------------------------------------------------------

class TestCMinus:
    def test_output_shapes(self, mock_gal):
        M, Phi, Phi_err = cumulative_luminosity_function_cminus(
            mock_gal, 0.1, 0.5, 20.0, AREA_SR, COSMO
        )
        n = mock_gal.n
        assert M.shape[0] <= n
        assert Phi.shape == M.shape
        assert Phi_err.shape == M.shape

    def test_cumulative_monotone(self, mock_gal):
        M, Phi, _ = cumulative_luminosity_function_cminus(
            mock_gal, 0.1, 0.5, 20.0, AREA_SR, COSMO
        )
        assert np.all(np.diff(Phi) >= -1e-10 * Phi[:-1]), \
            "Cumulative LF should be non-decreasing."

    def test_phi_positive(self, mock_gal):
        _, Phi, _ = cumulative_luminosity_function_cminus(
            mock_gal, 0.1, 0.5, 20.0, AREA_SR, COSMO
        )
        assert np.all(Phi >= 0)

    def test_raises_without_abs_mag(self, mock_rand):
        with pytest.raises(ValueError, match="abs_mag"):
            cumulative_luminosity_function_cminus(mock_rand, 0.1, 0.5, 20.0, AREA_SR, COSMO)


# ---------------------------------------------------------------------------
# Efron-Petrosian independence test
# ---------------------------------------------------------------------------

class TestEfronPetrosian:
    def test_returns_dict_keys(self, mock_gal):
        result = efron_petrosian_tau(
            mock_gal.abs_mag, mock_gal.redshift, 20.0, COSMO
        )
        for key in ("tau", "p_value", "numerator", "denominator", "n_used"):
            assert key in result

    def test_null_distribution(self):
        """For M independent of z, |τ| should be small (|τ| < 4 with very high probability)."""
        rng = np.random.default_rng(7)
        z = rng.uniform(0.05, 0.30, 400)
        M = rng.normal(-21.0, 1.5, 400)
        mu = COSMO.distmod(z).value
        obs = (M + mu) < 20.0
        result = efron_petrosian_tau(M[obs], z[obs], 20.0, COSMO)
        assert abs(result["tau"]) < 5.0, f"Unexpected τ={result['tau']:.2f} for no-evolution sample."

    def test_tau_bounded_for_uncorrelated(self):
        """Uncorrelated sample: |τ| should not be extreme (< 5)."""
        rng = np.random.default_rng(8)
        z = rng.uniform(0.05, 0.15, 500)
        M = rng.normal(-21.5, 1.0, 500)
        mu = COSMO.distmod(z).value
        obs = (M + mu) < 19.0
        result = efron_petrosian_tau(M[obs], z[obs], 19.0, COSMO)
        assert abs(result["tau"]) < 5.0, f"τ={result['tau']:.2f} unexpectedly large for no-evolution sample."


# ---------------------------------------------------------------------------
# Rauzy completeness test
# ---------------------------------------------------------------------------

class TestRauzy:
    def test_returns_dict_keys(self, mock_gal):
        result = rauzy_completeness(
            mock_gal.abs_mag, mock_gal.redshift, 20.0, COSMO
        )
        for key in ("Tc", "Tv", "zeta_mean", "zeta_var", "n_used"):
            assert key in result

    def test_complete_sample_zeta_near_half(self):
        """For a complete flux-limited sample, mean(ζ) should be close to 0.5."""
        rng = np.random.default_rng(9)
        z = rng.uniform(0.05, 0.20, 500)
        M = rng.normal(-21.0, 1.2, 500)
        mu = COSMO.distmod(z).value
        obs = (M + mu) < 18.5
        result = rauzy_completeness(M[obs], z[obs], 18.5, COSMO)
        assert abs(result["zeta_mean"] - 0.5) < 0.15, \
            f"zeta_mean={result['zeta_mean']:.3f} far from 0.5."


# ---------------------------------------------------------------------------
# Cross-estimator Monte Carlo comparison (Johnston 2011 §8 spirit)
# ---------------------------------------------------------------------------

class TestMCComparison:
    """Compare 1/Vmax and SWML on a Schechter-distributed sample.

    Reproduces the spirit of Johnston (2011) §8 (Heyl et al. 1997, Willmer
    1997, Takeuchi et al. 2000): multiple estimators applied to the same
    simulated flux-limited catalogue should yield consistent LF shapes.
    """

    def test_vmax_swml_consistent(self):
        """1/Vmax and SWML should agree within a factor of 5 in well-sampled bins.

        Both estimators should give consistent TOTAL number density (integral of phi).
        Bin-by-bin agreement is checked only for bins with ≥ 20 weighted counts
        (Johnston 2011 §8).
        """
        rng = np.random.default_rng(42)
        cat, m_lim = _make_schechter_cat(
            rng, n=4000, alpha=0.0, M_star=-21.0,
            z_min=0.05, z_max=0.20, m_lim=18.5,
        )

        mag_bins = np.linspace(-24, -17, 9)
        dm = mag_bins[1] - mag_bins[0]

        _, phi_vmax, _ = luminosity_function_vmax(
            cat, 0.05, 0.20, mag_bins, AREA_SR, COSMO
        )
        _, phi_swml, _ = luminosity_function_swml(
            cat, 0.05, 0.20, m_lim, mag_bins, AREA_SR, COSMO
        )

        # Total density should agree within 30%
        integral_vmax = np.sum(phi_vmax) * dm
        integral_swml = np.sum(phi_swml) * dm
        assert integral_swml > 0, "SWML integral is zero."
        ratio_total = integral_swml / integral_vmax
        assert 0.5 < ratio_total < 2.0, \
            f"Integrated density ratio SWML/1Vmax = {ratio_total:.2f}, expected near 1."

        # Bin-by-bin check in the well-sampled core (one bin away from each edge)
        # Both estimators are expected to agree well away from the flux limit.
        M_centres = 0.5 * (mag_bins[:-1] + mag_bins[1:])
        core = (M_centres >= -22.5) & (M_centres <= -20.5) & (phi_vmax > 0) & (phi_swml > 0)
        if core.sum() >= 2:
            ratio = phi_swml[core] / phi_vmax[core]
            assert np.all(ratio > 0.2) and np.all(ratio < 5.0), \
                f"Core-bin 1/Vmax–SWML ratio out of range: {ratio}"

    def test_cminus_monotone_and_positive(self):
        """C⁻ cumulative LF must be positive and non-decreasing."""
        rng = np.random.default_rng(77)
        cat, m_lim = _make_schechter_cat(
            rng, n=1500, alpha=0.0, M_star=-21.0,
            z_min=0.05, z_max=0.20, m_lim=18.5,
        )
        M_s, Phi, Phi_err = cumulative_luminosity_function_cminus(
            cat, 0.05, 0.20, m_lim, AREA_SR, COSMO
        )
        assert np.all(Phi >= 0)
        assert np.all(np.diff(Phi) >= -1e-10 * np.abs(Phi[:-1]))

    def test_efron_petrosian_no_evolution(self):
        """Schechter sample with no redshift evolution should give |τ| < 4."""
        rng = np.random.default_rng(55)
        cat, m_lim = _make_schechter_cat(
            rng, n=1500, alpha=0.0, M_star=-21.0,
            z_min=0.05, z_max=0.20, m_lim=18.5,
        )
        result = efron_petrosian_tau(cat.abs_mag, cat.redshift, m_lim, COSMO)
        assert abs(result["tau"]) < 5.0, \
            f"Unexpected τ={result['tau']:.2f} for no-evolution Schechter sample."


# ---------------------------------------------------------------------------
# Zalesky et al. (2025) SMF models and digitized data
# ---------------------------------------------------------------------------

from sum_stat.lf_smf.zalesky25 import (
    schechter_mass,
    double_schechter_mass,
    eddington_kernel,
    convolve_smf_eddington,
    ZALESKY2025,
    ZALESKY2025_COLUMNS,
    ZALESKY2025_TABLE1,
    zalesky2025_smf,
)


class TestSchechterMass:
    def test_positive(self):
        m = jnp.linspace(9.0, 12.5, 50)
        phi = schechter_mass(m, -3.0, 11.0, -1.4)
        assert jnp.all(phi >= 0)

    def test_peak_near_mchar(self):
        # For α=0, φ(m) ∝ x exp(−x) peaks at x=1 i.e. m = m*
        m = jnp.linspace(9.0, 13.0, 200)
        phi = schechter_mass(m, -3.0, 11.0, 0.0)
        peak_m = float(m[jnp.argmax(phi)])
        assert abs(peak_m - 11.0) < 0.5

    def test_jit_compilable(self):
        fn = jax.jit(schechter_mass)
        m = jnp.array([10.0, 11.0])
        result = fn(m, -3.0, 11.0, -1.4)
        assert result.shape == (2,)

    def test_grad_works(self):
        grad_fn = jax.grad(
            lambda p: jnp.sum(schechter_mass(jnp.array([11.0]), p[0], p[1], p[2]))
        )
        g = grad_fn(jnp.array([-3.0, 11.0, -1.4]))
        assert g.shape == (3,)
        assert not jnp.any(jnp.isnan(g))


class TestDoubleSchechterMass:
    def test_positive(self):
        m = jnp.linspace(9.0, 12.5, 50)
        phi = double_schechter_mass(m, 11.0, -3.1, -1.4, -2.9, -0.6)
        assert jnp.all(phi >= 0)

    def test_single_limit(self):
        m = jnp.linspace(9.0, 12.5, 50)
        phi_double = double_schechter_mass(m, 11.0, -3.1, -1.4, -20.0, -0.6)
        phi_single = schechter_mass(m, -3.1, 11.0, -1.4)
        np.testing.assert_allclose(
            np.array(phi_double), np.array(phi_single), rtol=1e-4
        )

    def test_jit_compilable(self):
        fn = jax.jit(double_schechter_mass)
        m = jnp.array([10.0, 11.0])
        result = fn(m, 11.0, -3.1, -1.4, -2.9, -0.6)
        assert result.shape == (2,)

    def test_grad_works(self):
        grad_fn = jax.grad(
            lambda p: jnp.sum(
                double_schechter_mass(jnp.array([11.0]), p[0], p[1], p[2], p[3], p[4])
            )
        )
        g = grad_fn(jnp.array([11.0, -3.1, -1.4, -2.9, -0.6]))
        assert g.shape == (5,)
        assert not jnp.any(jnp.isnan(g))


class TestEddingtonKernel:
    def test_positive(self):
        dm = jnp.linspace(-3.0, 3.0, 61)
        k = eddington_kernel(dm, z=0.5)
        assert jnp.all(k >= 0)

    def test_symmetric(self):
        dm = jnp.linspace(-3.0, 3.0, 61)
        k = eddington_kernel(dm, z=0.5)
        np.testing.assert_allclose(np.array(k), np.array(k[::-1]), rtol=1e-6)

    def test_peak_at_zero(self):
        dm = jnp.linspace(-3.0, 3.0, 601)
        k = eddington_kernel(dm, z=0.5)
        assert int(jnp.argmax(k)) == 300  # centre index

    def test_tau_scales_with_z(self):
        dm = jnp.array([0.0])
        k_low = float(eddington_kernel(dm, z=0.0, tau_c=0.05)[0])
        k_high = float(eddington_kernel(dm, z=1.0, tau_c=0.05)[0])
        # At δm=0 the Lorentzian peak ∝ 1/τ_Edd; higher z → larger τ_Edd → smaller peak
        assert k_high < k_low

    def test_jit_compilable(self):
        fn = jax.jit(eddington_kernel)
        dm = jnp.array([0.0, 0.1, -0.1])
        result = fn(dm, 0.5)
        assert result.shape == (3,)


class TestConvolveSmfEddington:
    def test_output_shape(self):
        m = jnp.linspace(9.0, 12.5, 20)
        phi_obs = convolve_smf_eddington(
            lambda x: schechter_mass(x, -3.0, 11.0, -1.4), m, z=0.5
        )
        assert phi_obs.shape == (20,)

    def test_nonnegative(self):
        m = jnp.linspace(9.0, 12.5, 20)
        phi_obs = convolve_smf_eddington(
            lambda x: schechter_mass(x, -3.0, 11.0, -1.4), m, z=0.5
        )
        assert jnp.all(phi_obs >= 0)

    def test_broadens_smf(self):
        m = jnp.linspace(10.5, 12.5, 40)
        phi_true = schechter_mass(m, -3.0, 11.0, -1.4)
        phi_obs = convolve_smf_eddington(
            lambda x: schechter_mass(x, -3.0, 11.0, -1.4), m, z=0.5
        )
        # Eddington bias should boost the high-mass tail
        assert float(phi_obs[-1]) >= float(phi_true[-1])

    def test_differentiable_wrt_params(self):
        m = jnp.linspace(9.5, 12.0, 10)

        def _val(params):
            phi_fn = lambda x: schechter_mass(x, params[0], params[1], params[2])
            return jnp.sum(convolve_smf_eddington(phi_fn, m, z=0.5))

        g = jax.grad(_val)(jnp.array([-3.0, 11.0, -1.4]))
        assert g.shape == (3,)
        assert not jnp.any(jnp.isnan(g))


class TestZalesky2025Data:
    def test_table1_shape(self):
        assert ZALESKY2025_TABLE1.shape == (11, 5)

    def test_table1_volumes_positive(self):
        assert np.all(ZALESKY2025_TABLE1[:, 2] > 0)

    def test_total_shape(self):
        assert ZALESKY2025["total"].shape == (11, 22)

    def test_sf_shape(self):
        assert ZALESKY2025["star_forming"].shape == (7, 22)

    def test_quiescent_shape(self):
        assert ZALESKY2025["quiescent"].shape == (7, 22)

    def test_double_schechter_bins_total(self):
        col = ZALESKY2025_COLUMNS
        data = ZALESKY2025["total"]
        # First 5 z-bins (z ≤ 2) should have non-NaN alpha2/phi2
        for i in range(5):
            assert not np.isnan(data[i, col["alpha2_med"]])
            assert not np.isnan(data[i, col["log10_phi2_med"]])
        # Remaining z-bins are single Schechter
        for i in range(5, 11):
            assert np.isnan(data[i, col["alpha2_med"]])

    def test_quiescent_single_uses_phi2_columns(self):
        col = ZALESKY2025_COLUMNS
        data = ZALESKY2025["quiescent"]
        for i in range(2, 7):
            assert np.isnan(data[i, col["alpha1_med"]])
            assert not np.isnan(data[i, col["alpha2_med"]])


class TestZalesky2025SMF:
    def test_total_z0_returns_array(self):
        m = np.linspace(9.0, 12.5, 50)
        phi = zalesky2025_smf(m, z_bin=0, population="total")
        assert phi.shape == (50,)
        assert jnp.all(phi >= 0)

    def test_single_schechter_bin(self):
        m = np.linspace(9.0, 12.5, 50)
        phi = zalesky2025_smf(m, z_bin=5, population="total")
        assert phi.shape == (50,)
        assert jnp.all(phi >= 0)

    def test_quiescent_single(self):
        m = np.linspace(9.0, 12.5, 50)
        phi = zalesky2025_smf(m, z_bin=3, population="quiescent")
        assert phi.shape == (50,)
        assert jnp.all(phi >= 0)

    def test_map_vs_median_differ(self):
        m = np.linspace(9.0, 12.5, 20)
        phi_med = zalesky2025_smf(m, z_bin=0, population="total", use_map=False)
        phi_map = zalesky2025_smf(m, z_bin=0, population="total", use_map=True)
        assert not jnp.allclose(phi_med, phi_map)

    def test_invalid_population_raises(self):
        with pytest.raises(ValueError, match="population"):
            zalesky2025_smf(np.array([11.0]), z_bin=0, population="wrong")

    def test_invalid_zbin_raises(self):
        with pytest.raises(ValueError, match="z_bin"):
            zalesky2025_smf(np.array([11.0]), z_bin=99, population="total")


