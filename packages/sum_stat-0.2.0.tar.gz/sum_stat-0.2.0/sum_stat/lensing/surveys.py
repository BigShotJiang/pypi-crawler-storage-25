"""Survey-specific source catalogue loaders for galaxy-galaxy lensing.

Each loader reads raw survey files, applies the necessary selection cuts and
calibration steps, and returns a pair ``(table_s, table_n)`` ready to pass
directly to :func:`~sum_stat.lensing.esd.delta_sigma`.

Supported surveys
-----------------
* **DES Y3** — :func:`load_des_sources`
* **HSC**    — :func:`load_hsc_sources`
* **KiDS DR4** — :func:`load_kids_sources`

Typical workflow
----------------
::

    from sum_stat.lensing.surveys import load_des_sources
    from sum_stat import GalaxyCatalogue
    from sum_stat.lensing import delta_sigma
    from astropy.cosmology import Planck15
    import numpy as np

    table_s, table_n = load_des_sources('/path/to/des_y3.hdf5')
    lens = GalaxyCatalogue(ra=lens_ra, dec=lens_dec, redshift=lens_z)
    rand = GalaxyCatalogue(ra=rand_ra, dec=rand_dec, redshift=rand_z)
    rp_bins = 10 ** np.arange(-2.0, 1.6, 0.4)

    rp, ds, cov = delta_sigma(
        lens, table_s, rp_bins, Planck15,
        rand=rand, table_n=table_n,
        corrections={'matrix_shear_response_correction': True,
                     'random_subtraction': True},
    )
"""

from __future__ import annotations

import os

import numpy as np
from astropy.table import Table
from dsigma.helpers import dsigma_table

# ---------------------------------------------------------------------------
# DES Y3
# ---------------------------------------------------------------------------


def load_des_sources(path: str) -> tuple[Table, Table]:
    """Load and prepare the DES Y3 source catalogue for ΔΣ measurements.

    Implements the source-preparation steps from Secco et al. 2022 / Amon et
    al. 2022 as used in ``prepare_measure_DES_delta_sigma.py``:

    1. Read ``catalog`` and ``redshift`` datasets from the HDF5 file.
    2. Apply per-bin selection response ΔR_sel to ``R_11`` and ``R_22``.
    3. Filter to z_bin ≥ 0 and ``flags_select``.
    4. Assign multiplicative shear bias from the Y3 calibration.
    5. Assign the mean redshift of each tomographic bin to ``z``.

    Parameters
    ----------
    path : str
        Path to the DES Y3 HDF5 file (e.g. ``des_y3.hdf5``), containing
        ``catalog`` (source shapes) and ``redshift`` (n(z) calibration) paths.

    Returns
    -------
    table_s : Table
        dsigma-formatted source table with columns added by
        :func:`dsigma.helpers.dsigma_table` plus ``m``, ``z``, ``z_bin``.
    table_n : Table
        Photo-z calibration table read directly from the ``redshift`` HDF5
        path.  Pass to :func:`~sum_stat.lensing.esd.delta_sigma` as
        ``table_n``.

    Notes
    -----
    Recommended ``corrections`` for :func:`~sum_stat.lensing.esd.delta_sigma`::

        {'matrix_shear_response_correction': True,
         'random_subtraction': True}

    ``lens_source_cut=0.1`` is appropriate for DES.

    References
    ----------
    Secco et al. 2022, Phys.Rev.D 105, 023515.
    Amon et al. 2022, Phys.Rev.D 105, 023514.

    Examples
    --------
    >>> table_s, table_n = load_des_sources('/data/DES/des_y3.hdf5')
    >>> print(table_s.colnames)
    """
    from dsigma.surveys import des

    table_s = Table.read(path, path="catalog")
    table_s = dsigma_table(table_s, "source", survey="DES")

    # Selection response correction applied per tomographic bin
    for z_bin in range(4):
        select = table_s["z_bin"] == z_bin
        R_sel = des.selection_response(table_s[select])
        delta_R = 0.5 * np.sum(np.diag(R_sel))
        table_s["R_11"][select] += delta_R
        table_s["R_22"][select] += delta_R

    table_s = table_s[table_s["z_bin"] >= 0]
    table_s = table_s[table_s["flags_select"]]
    table_s["m"] = des.multiplicative_shear_bias(table_s["z_bin"], version="Y3")

    # Mean redshift per tomographic bin (used for lens-source pair selection)
    mean_z_per_bin = np.array([0.0, 0.358, 0.631, 0.872])
    table_s["z"] = mean_z_per_bin[table_s["z_bin"]]

    table_n = Table.read(path, path="redshift")
    return table_s, table_n


# ---------------------------------------------------------------------------
# HSC
# ---------------------------------------------------------------------------


def load_hsc_sources(path: str, nz_path: str) -> tuple[Table, Table]:
    """Load and prepare the HSC source catalogue for ΔΣ measurements.

    Implements the source-preparation steps from the HSC weak-lensing pipeline
    as used in ``prepare_measure_HSC_delta_sigma.py``:

    1. Read the HSC FITS source catalogue.
    2. Remove galaxies in regions with significant B-mode contamination.
    3. Apply dsigma HSC formatting.
    4. Compute and store the multiplicative selection bias ``m_sel``.
    5. Remove galaxies with bimodal P(z) (z_bin == 0) and re-index bins
       starting from 0.
    6. Read the n(z) table; construct the per-bin n(z) matrix.
    7. Assign each source the weighted mean redshift of its tomographic bin.

    Parameters
    ----------
    path : str
        Path to the HSC source FITS file (e.g. ``hsc.fits``).
    nz_path : str
        Path to the HSC n(z) FITS file (e.g. ``nz.fits``), expected to contain
        columns ``Z_MID`` and ``BIN1``–``BIN4``.

    Returns
    -------
    table_s : Table
        dsigma-formatted source table with columns added by
        :func:`dsigma.helpers.dsigma_table` plus ``m_sel``, ``z``, ``z_bin``.
    table_n : Table
        Photo-z calibration table with columns ``z`` and ``n`` (shape
        ``(n_z, 4)`` for four tomographic bins).

    Notes
    -----
    Recommended ``corrections`` for :func:`~sum_stat.lensing.esd.delta_sigma`::

        {'scalar_shear_response_correction': True,
         'shear_responsivity_correction': True,
         'selection_bias_correction': True,
         'boost_correction': False,
         'random_subtraction': True}

    ``lens_source_cut=0.3`` is appropriate for HSC.

    Examples
    --------
    >>> table_s, table_n = load_hsc_sources('/data/HSC/hsc.fits',
    ...                                     '/data/HSC/nz.fits')
    """
    from dsigma.surveys import hsc

    table_s = Table.read(path)
    table_s = table_s[table_s["b_mode_mask"] == 1]
    table_s = dsigma_table(table_s, "source", survey="HSC")
    table_s["m_sel"] = hsc.multiplicative_selection_bias(table_s)

    # z_bin == 0 flags bimodal P(z) galaxies; remove and re-index from 0
    table_s = table_s[table_s["z_bin"] > 0]
    table_s["z_bin"] = table_s["z_bin"] - 1

    table_n = Table.read(nz_path)
    table_n.rename_column("Z_MID", "z")
    table_n["n"] = np.column_stack([table_n[f"BIN{i + 1}"] for i in range(4)])
    table_n.keep_columns(["z", "n"])

    # Weighted mean redshift per bin, used for lens-source pair selection
    z_mean_per_bin = np.sum(table_n["z"][:, np.newaxis] * table_n["n"], axis=0)
    table_s["z"] = z_mean_per_bin[table_s["z_bin"]]

    return table_s, table_n


# ---------------------------------------------------------------------------
# KiDS DR4
# ---------------------------------------------------------------------------


def load_kids_sources(path: str, nz_dir: str) -> tuple[Table, Table]:
    """Load and prepare the KiDS DR4 source catalogue for ΔΣ measurements.

    Implements the source-preparation steps from Giblin et al. 2021 as used in
    ``prepare_measure_KIDS_delta_sigma.py``:

    1. Read the KiDS SOM gold WL catalogue.
    2. Apply quality cuts: ``MASK == 0``, ``weight > 0``, ``model_SNratio > 0``.
    3. Apply dsigma KiDS formatting.
    4. Assign tomographic redshift bins (DR4 SOM calibration).
    5. Assign multiplicative shear bias per bin (DR4).
    6. Read the five SOM n(z) ASCII files and build the calibration table.
    7. Assign each source the mean redshift of its tomographic bin.

    Parameters
    ----------
    path : str
        Path to the KiDS DR4 FITS file
        (``KiDS_DR4.1_ugriZYJHKs_SOM_gold_WL_cat.fits``).
    nz_dir : str
        Directory containing the five SOM n(z) ASCII files named::

            K1000_NS_V1.0.0A_ugriZYJHKs_photoz_SG_mask_LF_svn_309c_2Dbins_v2
            _SOMcols_Fid_blindC_TOMO{1..5}_Nz.asc

    Returns
    -------
    table_s : Table
        dsigma-formatted source table with columns added by
        :func:`dsigma.helpers.dsigma_table` plus ``m``, ``z``, ``z_bin``.
    table_n : Table
        Photo-z calibration table with columns ``z`` (bin centres) and ``n``
        (shape ``(n_z, 5)`` for five tomographic bins).

    Notes
    -----
    Recommended ``corrections`` for :func:`~sum_stat.lensing.esd.delta_sigma`::

        {'scalar_shear_response_correction': True,
         'random_subtraction': True}

    ``lens_source_cut=0.1`` is appropriate for KiDS.

    References
    ----------
    Giblin et al. 2021, A&A 645, A105.

    Examples
    --------
    >>> table_s, table_n = load_kids_sources(
    ...     '/data/KIDS/DR4/KiDS_DR4.1_ugriZYJHKs_SOM_gold_WL_cat.fits',
    ...     '/data/KIDS/DR4',
    ... )
    """
    from dsigma.surveys import kids

    table_s = Table.read(path)
    select = (table_s["MASK"] == 0) & (table_s["weight"] > 0) & (table_s["model_SNratio"] > 0)
    table_s = table_s[select]
    table_s = dsigma_table(table_s, "source", survey="KiDS")

    table_s["z_bin"] = kids.tomographic_redshift_bin(table_s["z"], version="DR4")
    table_s["m"] = kids.multiplicative_shear_bias(table_s["z_bin"], version="DR4")
    table_s = table_s[table_s["z_bin"] >= 0]

    # SOM n(z) files: one per tomographic bin, columns [z_mid, n(z)]
    nz_fname = (
        "K1000_NS_V1.0.0A_ugriZYJHKs_photoz_SG_mask_LF_svn_309c_2Dbins_v2"
        "_SOMcols_Fid_blindC_TOMO{}_Nz.asc"
    )
    table_n = Table()
    table_n["z"] = np.genfromtxt(os.path.join(nz_dir, nz_fname.format(1)))[:, 0] + 0.025
    table_n["n"] = np.vstack(
        [np.genfromtxt(os.path.join(nz_dir, nz_fname.format(i + 1)))[:, 1] for i in range(5)]
    ).T

    # Mean redshift per bin — used for lens-source pair selection only
    table_s["z"] = np.array([0.1, 0.3, 0.5, 0.7, 0.9])[table_s["z_bin"]]

    return table_s, table_n
