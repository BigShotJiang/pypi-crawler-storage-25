"""sum_stat — cosmological summary statistics from galaxy catalogues and lensing data.

Public API
----------
All estimators are accessible from the top-level namespace:

    import sum_stat as ss

    cat = ss.GalaxyCatalogue(ra=..., dec=..., redshift=...)
    theta, w, vw = ss.w_theta(cat, rand, theta_bins)
    writer = ss.SummaryStatWriter("results.h5")
    writer.write_twopcf(
        "angular_2pcf/sample_A", theta, w, cov, theta_bins, "landy-szalay", cosmo, {}
    )
"""

import jax

jax.config.update("jax_enable_x64", True)

from .catalogue import GalaxyCatalogue, PhotoZCalibTable, ShapeCatalogue
from .covariance.bootstrap import bootstrap_covariance
from .covariance.jackknife import jackknife_covariance
from .io.reader import SummaryStatReader
from .io.writer import SummaryStatWriter
from .knn import comoving_xyz, cross_knn_cdf, knn_cdf, knn_poisson_cdf, knn_volume_map
from .lensing.esd import delta_sigma
from .lf_smf.completeness_scan import completeness_scan
from .lf_smf.vmax import luminosity_function_vmax, stellar_mass_function_vmax
from .nz.histogram import nz_histogram
from .nz.kde import nz_kde
from .powspec.angular_cl import cl_angular
from .powspec.pk3d import pk3d, pk_multipoles
from .twopcf.angular import w_theta
from .twopcf.multipoles import xi_multipoles
from .twopcf.projected import wp
from .twopcf.spatial import xi_r

__version__ = "0.2.0"
__all__ = [
    # catalogues
    "GalaxyCatalogue",
    "ShapeCatalogue",
    "PhotoZCalibTable",
    # redshift distribution
    "nz_histogram",
    "nz_kde",
    # luminosity / stellar mass functions
    "luminosity_function_vmax",
    "stellar_mass_function_vmax",
    # completeness
    "completeness_scan",
    # k-nearest-neighbor statistics
    "knn_cdf",
    "cross_knn_cdf",
    "knn_volume_map",
    "knn_poisson_cdf",
    "comoving_xyz",
    # two-point correlation functions
    "w_theta",
    "xi_r",
    "wp",
    "xi_multipoles",
    # power spectra
    "cl_angular",
    "pk3d",
    "pk_multipoles",
    # galaxy-galaxy lensing
    "delta_sigma",
    # covariance
    "jackknife_covariance",
    "bootstrap_covariance",
    # I/O
    "SummaryStatWriter",
    "SummaryStatReader",
]
