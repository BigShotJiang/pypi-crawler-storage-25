# sum_stat

[![PyPI version](https://img.shields.io/pypi/v/sum-stat)](https://pypi.org/project/sum-stat/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![CI](https://github.com/JohanComparat/sum_stat/actions/workflows/ci.yml/badge.svg)](https://github.com/JohanComparat/sum_stat/actions/workflows/ci.yml)
[![Documentation](https://readthedocs.org/projects/sum-stat/badge/?version=latest)](https://sum-stat.readthedocs.io/en/latest/)

Python package for measuring cosmological summary statistics from galaxy catalogues and lensing data.

## Stable estimators

* Stellar mass function
* Angular correlation function
* Projected correlation function
* Excess surface density (galaxy-galaxy lensing)

## Installation

```bash
pip install sum-stat
```

See [pypi.org/project/sum-stat](https://pypi.org/project/sum-stat/) for details.

## Citation

If you use `sum_stat` in your research, please cite it as:

```bibtex
@software{comparat2026sumstat,
  author  = {Comparat, Johan},
  title   = {{sum\_stat}: Cosmological summary statistics from galaxy catalogues and lensing data}, 
  year    = {2026},
  version = {0.2.0},
  url     = {https://github.com/JohanComparat/sum_stat},
  license = {MIT},
}
```

A `CITATION.cff` file is also provided for automated citation tools (GitHub "Cite this repository" button).

## Contributing

Contributions are welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, coding conventions, and how to submit a pull request.

## License

MIT — see [LICENSE](LICENSE).

## Package structure

```
sum_stat/
├── sum_stat/
│   ├── catalogue.py       # GalaxyCatalogue, ShapeCatalogue, PhotoZCalibTable
│   ├── cosmology.py       # JAX-differentiable distances and Σ_crit
│   ├── covariance/        # jackknife_covariance, bootstrap_covariance
│   ├── io/                # SummaryStatWriter, SummaryStatReader
│   ├── lensing/           # delta_sigma
│   ├── lf_smf/            # 1/Vmax, SWML, C⁻, EP τ, Rauzy
│   ├── nz/                # nz_histogram, nz_kde
│   ├── powspec/           # cl_angular, pk3d, pk_multipoles  [development]
│   └── twopcf/            # w_theta, wp, xi_r, xi_multipoles
├── tests/
├── docs/
├── environment.yml
└── pyproject.toml
```
