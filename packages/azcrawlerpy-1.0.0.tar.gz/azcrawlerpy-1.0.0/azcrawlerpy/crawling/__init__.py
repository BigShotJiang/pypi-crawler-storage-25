"""
Crawling module for navigating and filling multi-step web forms.

Provides field handlers, action executors, data extraction, diagnostics,
and resilience utilities (RetryConfig, click_with_fallback, CrawlRestartError).

CrawlRestartError is a control flow signal for the restart_crawl feature: when a
step's wait_for times out and restart_crawl=True, the crawler tears down the browser
and replays the entire crawl with a fresh session, up to max_restarts times.
"""

from ..handling import BaseHandler, ValidationHandler
from .browser_utils import handle_cookie_consent
from .crawler import FormCrawler
from .data_extraction import extract_data, extract_field_value
from .discovery import ElementDiscovery
from .discovery_models import (
    DiscoveredElement,
    ElementVisibility,
    IframeDiscovery,
    PageDiscoveryReport,
    RadioButtonGroup,
)
from .exceptions import (
    CrawlerError,
    CrawlerTimeoutError,
    CrawlRestartError,
    DataExtractionError,
    FieldInteractionError,
    FieldNotFoundError,
    IframeNotFoundError,
    InvalidInstructionError,
    MissingDataError,
    NavigationError,
    UnsupportedActionTypeError,
    UnsupportedFieldTypeError,
)
from .models import (
    ActionDefinition,
    ActionType,
    BrowserType,
    ClickSelectFieldConfig,
    ComboboxFieldConfig,
    ConditionDefinition,
    ConditionType,
    ContextOptions,
    CrawlerBrowserConfig,
    CrawlResult,
    DataExtractionConfig,
    DateFieldConfig,
    DebugMode,
    DropdownFieldConfig,
    ExtractionFieldDefinition,
    FieldDefinition,
    FieldType,
    FieldTypeConfig,
    FinalPageDefinition,
    GeolocationConfig,
    HumanizeConfig,
    InMemoryCrawlResult,
    Instructions,
    ProfilerConfig,
    ProfilerSiteConfig,
    ProxyConfig,
    RetryConfig,
    StepDefinition,
    StepExtractionDefinition,
)
from .profiler import ProfilerResult, run_profiler

__all__ = [
    "ActionDefinition",
    "ActionType",
    "BaseHandler",
    "BrowserType",
    "ClickSelectFieldConfig",
    "ComboboxFieldConfig",
    "ConditionDefinition",
    "ConditionType",
    "ContextOptions",
    "CrawlRestartError",
    "CrawlResult",
    "CrawlerBrowserConfig",
    "CrawlerError",
    "CrawlerTimeoutError",
    "DataExtractionConfig",
    "DataExtractionError",
    "DateFieldConfig",
    "DebugMode",
    "DiscoveredElement",
    "DropdownFieldConfig",
    "ElementDiscovery",
    "ElementVisibility",
    "ExtractionFieldDefinition",
    "FieldDefinition",
    "FieldInteractionError",
    "FieldNotFoundError",
    "FieldType",
    "FieldTypeConfig",
    "FinalPageDefinition",
    "FormCrawler",
    "GeolocationConfig",
    "HumanizeConfig",
    "IframeDiscovery",
    "IframeNotFoundError",
    "InMemoryCrawlResult",
    "Instructions",
    "InvalidInstructionError",
    "MissingDataError",
    "NavigationError",
    "PageDiscoveryReport",
    "ProfilerConfig",
    "ProfilerResult",
    "ProfilerSiteConfig",
    "ProxyConfig",
    "RadioButtonGroup",
    "RetryConfig",
    "StepDefinition",
    "StepExtractionDefinition",
    "UnsupportedActionTypeError",
    "UnsupportedFieldTypeError",
    "ValidationHandler",
    "extract_data",
    "extract_field_value",
    "handle_cookie_consent",
    "run_profiler",
]
