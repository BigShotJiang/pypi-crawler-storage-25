from seashell.cli import main
main()
