"""HTTP client for the Seashell API.

Handles all CLI ↔ gateway communication. The two important behaviors here:

  1. **Wake-on-key**: when the user pastes their personal API key the CLI
     fires `POST /wake` immediately, then polls `/wake_status` in a
     background thread while the user is typing their password. The wake
     happens in parallel with the password prompt so the EC2's ~30s boot
     time is hidden behind the credential entry.

  2. **Session token enforcement**: every request after `/auth/login`
     includes both `X-API-Key` (institution identity) and `X-Session-Token`
     (per-researcher identity). The gateway requires both on engine
     endpoints — a leaked API key alone can't issue queries because the
     attacker also needs the password to mint a session token.
"""

import json
import sys
import threading
import time

import requests


class WakeJob(object):
    """Background-pollable wake-on-key job.

    Created by `SeashellClient.wake()`. The CLI uses `is_ready()` and
    `wait_until_ready()` to block on the wake completing. The poll runs
    in a daemon thread so it doesn't block stdin while the user is
    typing the password.
    """
    def __init__(self, client, initial_state):
        self.client = client
        self.state = initial_state.get("status", "unknown")
        self.eta = int(initial_state.get("eta", 30))
        self.error = None
        self._lock = threading.Lock()
        self._done = threading.Event()
        self._thread = None
        # If the gateway already reports running, we're done immediately.
        if self.state == "running":
            self._done.set()
        # Single-instance / dev mode — gateway returns running immediately
        # because there's nothing to wake.
        if initial_state.get("mode") == "single_instance":
            self.state = "running"
            self._done.set()

    def start_poll(self, max_seconds=120, interval=2.0):
        """Start the background polling thread. Idempotent."""
        if self._thread is not None or self._done.is_set():
            return
        self._thread = threading.Thread(
            target=self._poll, args=(max_seconds, interval), daemon=True)
        self._thread.start()

    def _poll(self, max_seconds, interval):
        deadline = time.time() + max_seconds
        # Exponential backoff capped at `interval` for stability.
        wait = 1.0
        while time.time() < deadline:
            try:
                resp = self.client.session.get(
                    self.client.server + "/wake_status", timeout=5)
                if resp.status_code == 200:
                    j = resp.json()
                    with self._lock:
                        self.state = j.get("state", self.state)
                    if j.get("state") == "running":
                        self._done.set()
                        return
                elif resp.status_code == 404:
                    # /wake_status doesn't exist on this server (engine
                    # mode or single-instance dev). Stop polling — the
                    # initial /wake response already told us we're up.
                    self._done.set()
                    return
            except requests.exceptions.RequestException as e:
                with self._lock:
                    self.error = str(e)
                # Don't fail the wake job on a single transient error;
                # the EC2 may be mid-boot and the gateway momentarily
                # unreachable. Just keep retrying until the deadline.
            time.sleep(min(wait, interval))
            wait = min(wait * 1.5, interval)
        # Deadline reached. Caller will see state still in "starting".

    def is_ready(self):
        """True if the engine is ready to accept queries."""
        return self._done.is_set()

    def wait_until_ready(self, timeout=None):
        """Block until the engine is ready or the timeout elapses.
        Returns True on ready, False on timeout."""
        if not self._done.wait(timeout=timeout):
            return False
        return True


class SeashellClient(object):
    def __init__(self, server_url, api_key):
        self.server = server_url.rstrip("/")
        self.api_key = api_key
        self.session_token = None
        self.session = requests.Session()
        self.session.headers["X-API-Key"] = api_key

    def set_session_token(self, token):
        """Attach a per-researcher session token to all subsequent
        requests. Called by the CLI after a successful /auth/login."""
        self.session_token = token
        self.session.headers["X-Session-Token"] = token

    def query(self, query_text):
        """Send a GQL query and return the result dict.

        Both X-API-Key (set in __init__) and X-Session-Token (set after
        login) are sent on every request. The gateway requires both on
        engine-execution endpoints; a missing token returns 401.
        """
        resp = self.session.post(
            self.server + "/query",
            json={"query": query_text},
            timeout=600,
        )
        if resp.status_code == 403:
            raise PermissionError(resp.json().get("detail", "Access denied"))
        if resp.status_code == 429:
            retry = resp.headers.get("Retry-After", "60")
            raise RuntimeError("Rate limited. Try again in %s seconds." % retry)
        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise RuntimeError("Query failed (%d): %s" % (resp.status_code, detail))
        return resp.json()

    def health(self):
        """Check server health. Returns dict with status, patient_count, etc."""
        try:
            resp = self.session.get(self.server + "/health", timeout=10)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None

    def wake(self):
        """Wake the institution's EC2 instance.

        Returns a `WakeJob` immediately — does NOT block. The CLI then
        starts the background poll via `job.start_poll()` and waits on
        `job.wait_until_ready()` once the user has finished typing their
        password.

        On wake failure (network, invalid key, etc.) returns a `WakeJob`
        whose state is "error" and whose `error` field contains the
        exception. The CLI surfaces this in the login flow before
        prompting for password.
        """
        try:
            resp = self.session.post(self.server + "/wake", timeout=10)
            if resp.status_code == 200:
                return WakeJob(self, resp.json())
            # Non-200 — return an error job so the CLI can show a clear
            # message instead of just hanging on the password prompt.
            detail = ""
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            job = WakeJob(self, {"status": "error", "eta": 0})
            job.error = "Wake failed (HTTP %d): %s" % (resp.status_code, detail[:200])
            return job
        except requests.exceptions.RequestException as e:
            job = WakeJob(self, {"status": "error", "eta": 0})
            job.error = "Cannot reach server at %s: %s" % (self.server, e)
            return job

    def login(self, email, password):
        """Authenticate the researcher with email + password.

        Sends both the form body AND the existing X-API-Key header so the
        gateway can cross-check that the user.institution matches the
        institution the API key is bound to (closes the privilege-
        escalation gap fixed in the gateway split).

        On success, attaches the returned session token to all subsequent
        requests via `set_session_token()`. Returns the response dict.
        """
        resp = self.session.post(
            self.server + "/auth/login",
            json={"email": email, "password": password},
            timeout=15,
        )
        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise RuntimeError("Login failed (%d): %s" % (resp.status_code, detail))
        body = resp.json()
        token = body.get("token", "")
        if not token:
            raise RuntimeError("Login response missing session token")
        self.set_session_token(token)
        return body

    def poll_job(self, endpoint, job_id, callback=None):
        """Poll an async job (export/upload) until completion.

        Args:
            endpoint: "export" or "ingest_gql"
            job_id: the job ID returned by the initial request
            callback: optional function called with job dict on each poll
        """
        url = "%s/%s/%s" % (self.server, endpoint, job_id)
        while True:
            try:
                resp = self.session.get(url, timeout=30)
                if resp.status_code != 200:
                    return {"status": "error", "detail": resp.text}
                job = resp.json()
                if callback:
                    callback(job)
                status = job.get("status", "")
                if status in ("complete", "complete_with_errors", "error", "failed"):
                    return job
            except Exception as e:
                sys.stderr.write("Poll error: %s\n" % str(e))
            time.sleep(3)
