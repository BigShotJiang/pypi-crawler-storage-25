"""Configuration management — stores credentials in ~/.seashell/config.json."""

import json
import os
import stat

CONFIG_DIR = os.path.expanduser("~/.seashell")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

DEFAULT_SERVER = "https://seashell.bio"


def load_config():
    """Load saved config, or return empty dict if none exists."""
    if not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_config(config):
    """Save config to disk with owner-only permissions (contains API key)."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
    # Set file permissions to 600 (owner read/write only)
    try:
        os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass  # Windows doesn't support chmod


def clear_config():
    """Remove saved credentials."""
    if os.path.exists(CONFIG_FILE):
        os.remove(CONFIG_FILE)
