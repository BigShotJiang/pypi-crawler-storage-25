#!/usr/bin/env bash
set -euo pipefail

# Security: All temp directories created with mktemp -d and restrictive permissions

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
dist_dir="${DIST_DIR:-${root_dir}/dist/deb}"

mkdir -p "${dist_dir}"

# Security: Use mktemp for secure temp directories
work_dir="$(mktemp -d "${dist_dir}/work.XXXXXX")"
pkg_dir="$(mktemp -d "${dist_dir}/pkg.XXXXXX")"

# Security: Set restrictive permissions on temp directories
chmod 700 "${work_dir}" "${pkg_dir}"

arch="amd64"
trap 'echo "Build failed at line ${LINENO}." >&2; rm -rf "${work_dir}" "${pkg_dir}"; exit 1' ERR
trap 'rm -rf "${work_dir}" "${pkg_dir}"' EXIT

version="${VERSION:-}"
if [[ -z "${version}" ]]; then
  version="$(python3 - <<'PY'
from pathlib import Path
import tomllib

pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
data = tomllib.loads(pyproject)
print(data["project"]["version"])
PY
)"
fi

mkdir -p "${dist_dir}"
rm -f "${dist_dir}"/fu7ur3pr00f_*.deb
# Temp directories already created with mktemp -d, no need to recreate

deb_root="${pkg_dir}/fu7ur3pr00f_${version}_${arch}"
mkdir -p "${deb_root}/DEBIAN" "${deb_root}/usr/bin" "${deb_root}/opt/fu7ur3pr00f" \
  "${deb_root}/usr/share/doc/fu7ur3pr00f"

export PIP_DISABLE_PIP_VERSION_CHECK=1
export PIP_DEFAULT_TIMEOUT="${PIP_DEFAULT_TIMEOUT:-120}"
export PIP_RETRIES="${PIP_RETRIES:-5}"

prune_path_if_exists() {
  local path
  for path in "$@"; do
    if [[ -e "${path}" ]]; then
      rm -rf "${path}"
    fi
  done
}

remove_matching_paths() {
  local base_dir="$1"
  shift
  local pattern
  local path

  shopt -s nullglob
  for pattern in "$@"; do
    for path in "${base_dir}"/${pattern}; do
      rm -rf "${path}"
    done
  done
  shopt -u nullglob
}

prune_bundled_python() {
  local python_root="$1"
  local python_lib_dir="$2"
  local site_packages_dir="${python_lib_dir}/site-packages"
  local tls_client_dir="${site_packages_dir}/tls_client/dependencies"

  echo "Pruning bundled runtime payload"

  prune_path_if_exists \
    "${python_root}/include" \
    "${python_root}/lib/pkgconfig" \
    "${python_root}/share/man" \
    "${python_root}/share/terminfo" \
    "${python_lib_dir}/ensurepip"

  remove_matching_paths "${python_root}/bin" \
    "pip" "pip3" "pip3.13" "idle3" "idle3.13" "pydoc3" "pydoc3.13" "python3.13-config"
  remove_matching_paths "${python_root}/lib" \
    "tcl*" "tk*" "itcl*" "thread*" "libtcl*" "libtk*"
  remove_matching_paths "${site_packages_dir}" \
    "pip" "pip-*.dist-info"

  if [[ -d "${site_packages_dir}" ]]; then
    find "${site_packages_dir}" -type d \( -name test -o -name tests \) -prune -exec rm -rf {} +
  fi

  find "${python_root}" -type d -name __pycache__ -prune -exec rm -rf {} +
  find "${python_root}" -type f \( -name "*.pyc" -o -name "*.pyo" \) -delete

  if [[ -d "${tls_client_dir}" ]]; then
    find "${tls_client_dir}" -maxdepth 1 -type f \
      ! -name "__init__.py" \
      ! -name "tls-client-amd64.so" \
      -delete
  fi
}

log_error_and_exit() {
  local msg="$1"
  local log_file="$2"
  echo "${msg}. Last 200 lines:" >&2
  tail -n 200 "${log_file}" >&2
  exit 1
}

build_venv="${work_dir}/build-venv"
echo "Setting up build virtualenv at ${build_venv}"
if ! python3 -m venv "${build_venv}" >/dev/null 2>&1; then
  echo "Failed to create build virtualenv. Ensure python3-venv is installed." >&2
  exit 1
fi

pip_log="${work_dir}/pip-install.log"
echo "Installing build tools"
if ! "${build_venv}/bin/pip" install --upgrade pip build hatchling getpybs >"${pip_log}" 2>&1; then
  log_error_and_exit "pip install failed" "${pip_log}"
fi

build_log="${work_dir}/build.log"
echo "Building wheel"
if ! "${build_venv}/bin/python" -m build --wheel --no-isolation -v >"${build_log}" 2>&1; then
  log_error_and_exit "Wheel build failed" "${build_log}"
fi

wheel_path="$(ls -1 "${root_dir}/dist"/fu7ur3pr00f-"${version}"-py3-none-any.whl | head -n1)"
if [[ ! -f "${wheel_path}" ]]; then
  echo "Wheel not found for version ${version}"
  exit 1
fi

# Security: Validate wheel file before installation
# Check wheel is valid ZIP archive with expected structure
if ! unzip -t "${wheel_path}" >/dev/null 2>&1; then
  echo "Wheel file is not a valid ZIP archive: ${wheel_path}"
  exit 1
fi

# Verify wheel contains expected metadata
if ! unzip -l "${wheel_path}" | grep -q "METADATA\|PKG-INFO"; then
  echo "Wheel file missing metadata: ${wheel_path}"
  exit 1
fi

# Security: Log wheel hash for audit trail
wheel_hash="$(sha256sum "${wheel_path}" | cut -d' ' -f1)"
echo "Wheel SHA256: ${wheel_hash}"

pybs_dir="${work_dir}/python-build-standalone"
mkdir -p "${pybs_dir}"
pybs_log="${work_dir}/getpybs.log"
echo "Downloading python-build-standalone"
if ! "${build_venv}/bin/getpybs" \
  --python-version 3.13 \
  --architecture x86_64-unknown-linux-gnu \
  --content-type install_only_stripped \
  --dest "${pybs_dir}" >"${pybs_log}" 2>&1; then
  log_error_and_exit "getpybs failed" "${pybs_log}"
fi

pybs_tarball="$(find "${pybs_dir}" -maxdepth 2 -type f -name "python-3.13*install_only_stripped*.tar.*" | head -n1)"
if [[ -z "${pybs_tarball}" ]]; then
  pybs_tarball="$(find "${pybs_dir}" -maxdepth 3 -type f -name "*.tar.*" | head -n1)"
fi
if [[ -z "${pybs_tarball}" ]]; then
  echo "Python build tarball not found in ${pybs_dir}"
  exit 1
fi

python_dir="${work_dir}/python"
mkdir -p "${python_dir}"
case "${pybs_tarball}" in
  *.tar.zst)
    tar --use-compress-program=unzstd -xf "${pybs_tarball}" -C "${python_dir}"
    ;;
  *.tar.gz|*.tgz)
    tar -xzf "${pybs_tarball}" -C "${python_dir}"
    ;;
  *.tar.xz)
    tar -xJf "${pybs_tarball}" -C "${python_dir}"
    ;;
  *)
    tar -xf "${pybs_tarball}" -C "${python_dir}"
    ;;
esac

python_bin="$(find "${python_dir}" -type f -regex ".*/bin/python\\(3\\(\\.[0-9]+\\)?\\)?$" | head -n1)"
if [[ -z "${python_bin}" ]]; then
  echo "Python binary not found in ${python_dir}"
  find "${python_dir}" -maxdepth 3 -type f -path "*/bin/*" | head -n 50
  exit 1
fi

python_root="$(cd "$(dirname "$(dirname "${python_bin}")")" && pwd)"
python_dest="${deb_root}/opt/fu7ur3pr00f/python"
mkdir -p "${python_dest}"
cp -a "${python_root}/." "${python_dest}/"

runtime_log="${work_dir}/runtime-install.log"
echo "Installing application into bundled Python"
if ! "${python_dest}/bin/python" -m pip --version >/dev/null 2>&1; then
  if ! "${python_dest}/bin/python" -m ensurepip --upgrade >"${runtime_log}" 2>&1; then
    log_error_and_exit "ensurepip failed" "${runtime_log}"
  fi
fi

if ! PYTHONNOUSERSITE=1 PIP_PREFER_BINARY=1 "${python_dest}/bin/python" -m pip install \
  --no-compile \
  --ignore-installed "${wheel_path}" >>"${runtime_log}" 2>&1; then
  log_error_and_exit "Bundled Python install failed" "${runtime_log}"
fi

build_python_path="${python_dest}/bin/python"
runtime_python_path="/opt/fu7ur3pr00f/python/bin/python"
while IFS= read -r -d '' script_path; do
  first_line="$(head -n1 "${script_path}")"
  if [[ "${first_line}" != "#!"* ]]; then
    continue
  fi
  if [[ "${first_line}" == "#!${build_python_path}" ]]; then
    sed -i "1s|^#!.*$|#!${runtime_python_path}|" "${script_path}"
  fi
done < <(find "${python_dest}/bin" -maxdepth 1 -type f -perm -u+x -print0)

python_lib_dir="$(find "${python_dest}/lib" -mindepth 1 -maxdepth 1 -type d -name "python3.*" | head -n1)"
if [[ -z "${python_lib_dir}" ]]; then
  echo "Bundled Python stdlib directory not found in ${python_dest}/lib"
  exit 1
fi

prune_bundled_python "${python_dest}" "${python_lib_dir}"

cat > "${deb_root}/usr/bin/fu7ur3pr00f" <<'EOF'
#!/usr/bin/env bash
export PYTHONNOUSERSITE=1
export PYTHONDONTWRITEBYTECODE=1
exec /opt/fu7ur3pr00f/python/bin/python -B -m fu7ur3pr00f.cli "$@"
EOF
chmod 755 "${deb_root}/usr/bin/fu7ur3pr00f"

github_api="https://api.github.com/repos/github/github-mcp-server/releases/latest"
github_headers=()
if [[ -n "${GITHUB_TOKEN:-}" ]]; then
  github_headers=(-H "Authorization: Bearer ${GITHUB_TOKEN}")
fi
mcp_url="$(curl -sSL "${github_headers[@]}" "${github_api}" | jq -r '.assets[] | select(.name | test("linux.*(amd64|x86_64)"; "i")) | .browser_download_url' | head -n1)"
if [[ -z "${mcp_url}" ]]; then
  echo "Failed to find github-mcp-server linux amd64 asset"
  exit 1
fi

mcp_archive="${work_dir}/github-mcp-server-asset"
if ! curl -fSL "${mcp_url}" -o "${mcp_archive}"; then
  echo "Failed to download github-mcp-server asset"
  exit 1
fi

mcp_extract_dir="${work_dir}/github-mcp-server"
mkdir -p "${mcp_extract_dir}"
case "${mcp_url}" in
  *.tar.gz|*.tgz)
    tar -xzf "${mcp_archive}" -C "${mcp_extract_dir}"
    ;;
  *.tar.xz)
    tar -xJf "${mcp_archive}" -C "${mcp_extract_dir}"
    ;;
  *.zip)
    unzip -q "${mcp_archive}" -d "${mcp_extract_dir}"
    ;;
  *)
    tar -xf "${mcp_archive}" -C "${mcp_extract_dir}"
    ;;
esac

mcp_bin="$(find "${mcp_extract_dir}" -type f -name "github-mcp-server" | head -n1)"
if [[ -z "${mcp_bin}" ]]; then
  echo "github-mcp-server binary not found in archive"
  exit 1
fi
install -m 755 "${mcp_bin}" "${deb_root}/usr/bin/github-mcp-server"

cp "${root_dir}/README.md" "${deb_root}/usr/share/doc/fu7ur3pr00f/README.md"
cp "${root_dir}/LICENSE" "${deb_root}/usr/share/doc/fu7ur3pr00f/LICENSE"

cat > "${deb_root}/DEBIAN/control" <<EOF
Package: fu7ur3pr00f
Version: ${version}
Section: utils
Priority: optional
Architecture: ${arch}
Maintainer: Juan Manuel Daza <juanmanueldaza@users.noreply.github.com>
Depends: libc6, libstdc++6, ca-certificates
Suggests: glab, poppler-utils, libpango-1.0-0, libpangoft2-1.0-0, libcairo2, libfontconfig1, libgdk-pixbuf-2.0-0
Description: FutureProof career intelligence agent
 FutureProof is a local-first career intelligence agent that gathers
 professional data, analyzes career trajectories, and generates CVs.
EOF

dpkg-deb --build "${deb_root}" "${dist_dir}/fu7ur3pr00f_${version}_${arch}.deb" >/dev/null
echo "Built ${dist_dir}/fu7ur3pr00f_${version}_${arch}.deb"
