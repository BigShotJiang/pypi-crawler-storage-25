"""Tests for gatherers."""
