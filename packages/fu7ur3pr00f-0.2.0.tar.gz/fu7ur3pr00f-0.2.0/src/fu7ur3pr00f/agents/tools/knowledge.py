"""Knowledge base (RAG) tools for the career agent."""

from langchain_core.tools import tool
from langgraph.types import interrupt

from fu7ur3pr00f.memory.knowledge import KnowledgeSource
from fu7ur3pr00f.utils.services import get_knowledge_service as _get


def _get_knowledge_service():
    """Get a KnowledgeService instance."""
    return _get()


def _parse_source(source: str):
    """Parse and validate a KnowledgeSource string.

    Returns KnowledgeSource on success, or an error string on invalid source.
    """
    try:
        return KnowledgeSource(source)
    except ValueError:
        valid = ", ".join(s.value for s in KnowledgeSource)
        return f"Invalid source {source!r}. Valid sources: {valid}"


@tool
def search_career_knowledge(
    query: str,
    sources: list[str] | None = None,
    section: str | None = None,
    limit: int = 5,
    include_social: bool = False,
) -> str:
    """Search the career knowledge base for relevant information.

    Args:
        query: What to search for (e.g., "Python projects", "leadership experience")
        sources: Optional filter by source (linkedin, portfolio, assessment)
        section: Optional filter by section name (h2 category). Examples:
                 "Profile" for headline/location, "Summary" for about text,
                 "Experience" for work history, "Skills" for skills,
                 "Education" for degrees, "Certifications" for credentials,
                 "Projects" for side projects, "Connections" for contacts,
                 "Messages" for conversations.
        limit: Maximum results to return (increase for broad searches, e.g., 20)
        include_social: Set True ONLY when searching for messages, connections,
                        or posts. Default False — focuses on career content
                        (experience, skills, education, projects, certifications).

    Use this to find specific information from the user's career history
    instead of relying on general context. More efficient than loading
    all career data. Examples:
    - "Python projects" to find Python-related work
    - "leadership" to find management or leadership experience
    - "headline summary" to find LinkedIn profile headline and summary
    - "Accenture" with section="Connections", include_social=True to find contacts
    - "relocation" with section="Conversation", include_social=True for messages
    """
    service = _get_knowledge_service()
    results = service.search(
        query,
        limit=limit,
        sources=sources,
        section=section,
        include_social=include_social,
    )

    if not results:
        return (
            f"No results found for {query!r}. "
            "Try a different query or check if career data has been indexed."
        )

    result_parts = [f"Found {len(results)} relevant results for {query!r}:"]
    result_parts.append("<search_results>")
    for i, result in enumerate(results, 1):
        source = result.get("source", "unknown")
        section = result.get("section", "")
        content = result.get("content", "")[:2000]
        result_parts.append(f"\n**{i}. [{source}] {section}**")
        result_parts.append(content)
    result_parts.append("</search_results>")

    output = "\n".join(result_parts)
    if len(output) > 8000:
        output = output[:8000] + (f"\n\n... (truncated, {len(output)} chars total)")
    return output


@tool
def get_knowledge_stats() -> str:
    """Get statistics about the career knowledge base.

    Shows what career data is indexed and available for search.
    Use this to see if the knowledge base has been populated.
    """
    service = _get_knowledge_service()
    stats = service.get_stats()

    total = stats.get("total_chunks", 0)
    if total == 0:
        return "Career knowledge base is empty. Ask me to index your career data."

    result_parts = ["Career Knowledge Base Statistics:"]
    result_parts.append(f"\nTotal chunks indexed: {total}")
    result_parts.append("\nBy source:")
    for source, count in stats.get("by_source", {}).items():
        if count > 0:
            result_parts.append(f"  - {source}: {count} chunks")

    return "\n".join(result_parts)


@tool
def index_career_knowledge(source: str = "") -> str:
    """Check indexed career data in the knowledge base.

    Args:
        source: Specific source to check (linkedin, portfolio, assessment).
                Leave empty to check all available sources.

    All sources are auto-indexed when gathered. Use this to verify indexing status.
    """
    service = _get_knowledge_service()

    results = service.index_all(verbose=False)

    if source:
        ks = _parse_source(source)
        if isinstance(ks, str):
            return ks
        count = results.get(ks.value, 0)
        if count > 0:
            return f"{source!r} has {count} chunks indexed in the knowledge base."
        return f"No data indexed for {source!r}. Gather the data first."
    else:
        total = sum(results.values())
        indexed = sum(1 for c in results.values() if c > 0)
        result_parts = [f"{total} chunks from {indexed} sources:"]
        for src, count in results.items():
            if count > 0:
                result_parts.append(f"  - {src}: {count} chunks")
        return "\n".join(result_parts)


@tool
def clear_career_knowledge(source: str = "") -> str:
    """Clear indexed data from the career knowledge base.

    Args:
        source: Specific source to clear (linkedin, portfolio, assessment).
                Leave empty to clear all indexed data.

    Use this to remove outdated indexed data before re-indexing.
    """
    target = f"{source!r}" if source else "all"
    approved = interrupt(
        {
            "question": f"Clear {target} indexed career data?",
            "details": "This will permanently remove the data from the knowledge base. "
            "You will need to re-gather to restore it.",
        }
    )
    if not approved:
        return "Knowledge base clear cancelled."

    service = _get_knowledge_service()

    if source:
        ks = _parse_source(source)
        if isinstance(ks, str):
            return ks
        deleted = service.clear_source(ks)
        return f"Cleared {deleted} chunks for {source!r} from the knowledge base."
    else:
        total_deleted = service.clear_all()
        return f"Cleared {total_deleted} chunks from the knowledge base."
