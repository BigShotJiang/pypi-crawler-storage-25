"""LangGraph checkpointer factory for persistent conversation state.

Provides SqliteSaver instances for persisting conversation state across sessions.
The checkpointer stores:
- Message history for each thread
- Agent state (current analysis, pending actions)
- Checkpoint metadata for time-travel debugging

Usage:
    from fu7ur3pr00f.memory import get_checkpointer

    checkpointer = get_checkpointer()
    agent = create_agent(..., checkpointer=checkpointer)

    # Conversations persist automatically with thread_id
    config = {"configurable": {"thread_id": "main"}}
    agent.invoke({"messages": [...]}, config)
"""

import threading
from pathlib import Path

from langgraph.checkpoint.sqlite import SqliteSaver

# Cached singleton to avoid creating new connections on every call
_checkpointer: SqliteSaver | None = None
_cp_lock = threading.Lock()
_INTERNAL_THREAD_PREFIX = "bb_"


def get_data_dir() -> Path:
    """Get or create the fu7ur3pr00f data directory."""
    from fu7ur3pr00f.utils.security import secure_mkdir

    data_dir = Path.home() / ".fu7ur3pr00f"
    secure_mkdir(data_dir)
    return data_dir


def get_checkpointer() -> SqliteSaver:
    """Get a synchronous SqliteSaver checkpointer (cached singleton).

    Returns:
        SqliteSaver instance connected to ~/.fu7ur3pr00f/memory.db

    Note:
        The SqliteSaver handles thread-safety internally with locks.
        Safe to use from multiple threads (check_same_thread=False).
    """
    global _checkpointer
    if _checkpointer is not None:
        return _checkpointer

    with _cp_lock:
        if _checkpointer is not None:
            return _checkpointer

        import sqlite3

        db_path = get_data_dir() / "memory.db"
        # Create connection with check_same_thread=False for multi-threaded use
        conn = sqlite3.connect(str(db_path), check_same_thread=False)
        db_path.chmod(0o600)
        _checkpointer = SqliteSaver(conn)
        return _checkpointer


def clear_thread_history(thread_id: str) -> None:
    """Clear conversation history for a specific thread.

    Args:
        thread_id: The thread identifier to clear

    Note:
        This is a destructive operation. Use with caution.
    """
    import sqlite3

    db_path = get_data_dir() / "memory.db"
    if not db_path.exists():
        return

    conn = sqlite3.connect(str(db_path))
    try:
        cursor = conn.cursor()
        # LangGraph stores data across both tables with thread_id
        cursor.execute("DELETE FROM checkpoints WHERE thread_id = ?", (thread_id,))
        cursor.execute("DELETE FROM writes WHERE thread_id = ?", (thread_id,))
        conn.commit()
    finally:
        conn.close()


def is_internal_thread(thread_id: str) -> bool:
    """Return True when a thread ID belongs to internal blackboard state."""
    return thread_id.startswith(_INTERNAL_THREAD_PREFIX)


def list_threads() -> list[str]:
    """List all conversation thread IDs.

    Returns:
        List of thread IDs that have stored conversations.
    """
    import sqlite3

    db_path = get_data_dir() / "memory.db"
    if not db_path.exists():
        return []

    conn = sqlite3.connect(str(db_path))
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT thread_id FROM checkpoints "
            "UNION SELECT DISTINCT thread_id FROM writes"
        )
        return [
            row[0]
            for row in cursor.fetchall()
            if row[0] and not is_internal_thread(row[0])
        ]
    except sqlite3.OperationalError:
        # Table doesn't exist yet
        return []
    finally:
        conn.close()
