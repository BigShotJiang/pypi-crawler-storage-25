"""GitHub MCP client implementation.

Uses stdio transport with the native binary to communicate
with the official GitHub MCP server.
"""

import contextlib
import logging
import shutil
from typing import Any

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

from ..config import settings
from .base import (
    MCPClient,
    MCPConnectionError,
    MCPToolError,
    MCPToolResult,
    extract_mcp_content,
)

logger = logging.getLogger(__name__)


class GitHubMCPClient(MCPClient):
    """MCP client for GitHub MCP Server.

    Uses stdio transport with the native binary.

    Environment:
        GITHUB_PERSONAL_ACCESS_TOKEN: GitHub PAT for authentication
        GITHUB_MCP_TOKEN: Alternative token setting

    Configuration:
        settings.github_mcp_command: Native binary command
    """

    def __init__(self) -> None:
        self._session: ClientSession | None = None
        self._stdio_context: Any = None
        self._read_stream: Any = None
        self._write_stream: Any = None

    def _get_server_params(self) -> StdioServerParameters:
        """Build server parameters based on configuration."""
        token = settings.github_mcp_token_resolved
        if not token:
            raise MCPConnectionError(
                "GitHub MCP token not configured. "
                "Set GITHUB_PERSONAL_ACCESS_TOKEN or "
                "GITHUB_MCP_TOKEN environment variable."
            )

        if not shutil.which(settings.github_mcp_command):
            raise MCPConnectionError(
                "github-mcp-server not found on PATH. " "Install the native binary."
            )

        return StdioServerParameters(
            command=settings.github_mcp_command,
            args=["stdio"],
            env={"GITHUB_PERSONAL_ACCESS_TOKEN": token},
        )

    async def connect(self) -> None:
        """Connect to GitHub MCP server."""
        if self._session is not None:
            return  # Already connected

        try:
            server_params = self._get_server_params()

            # Enter stdio_client context
            self._stdio_context = stdio_client(server_params)
            (
                self._read_stream,
                self._write_stream,
            ) = await self._stdio_context.__aenter__()

            # Create session
            session = ClientSession(self._read_stream, self._write_stream)
            await session.__aenter__()
            await session.initialize()
            self._session = session

            logger.info("Connected to GitHub MCP server")

        except MCPConnectionError:
            await self.disconnect()
            raise
        except Exception as e:
            await self.disconnect()
            raise MCPConnectionError(
                f"Failed to connect to GitHub MCP server: {e}"
            ) from e

    async def disconnect(self) -> None:
        """Disconnect from GitHub MCP server."""
        if self._session is not None:
            with contextlib.suppress(Exception):
                await self._session.__aexit__(None, None, None)
            self._session = None

        if self._stdio_context is not None:
            with contextlib.suppress(Exception):
                await self._stdio_context.__aexit__(None, None, None)
            self._stdio_context = None

        self._read_stream = None
        self._write_stream = None

    async def call_tool(
        self, tool_name: str, arguments: dict[str, Any]
    ) -> MCPToolResult:
        """Call an MCP tool via the session."""
        if self._session is None:
            raise MCPConnectionError("Not connected to GitHub MCP server")

        try:
            result = await self._session.call_tool(tool_name, arguments)
            content, is_error = extract_mcp_content(result)

            return MCPToolResult(
                content=content,
                raw_response=result,
                tool_name=tool_name,
                is_error=is_error,
            )

        except Exception as e:
            raise MCPToolError(f"GitHub MCP tool {tool_name!r} failed: {e}") from e

    async def list_tools(self) -> list[str]:
        """List available MCP tools."""
        if self._session is None:
            raise MCPConnectionError("Not connected to GitHub MCP server")

        tools = await self._session.list_tools()
        return [tool.name for tool in tools.tools]

    def is_connected(self) -> bool:
        """Check connection status."""
        return self._session is not None
