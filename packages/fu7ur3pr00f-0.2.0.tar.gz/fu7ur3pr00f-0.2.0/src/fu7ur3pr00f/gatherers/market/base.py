"""Base class for market intelligence gatherers.

Provides TTL-based caching to avoid hammering APIs and improve performance.
Also provides helpers to reduce code duplication when gathering from
multiple MCP sources.
"""

import hashlib
import json
import logging
import tempfile
from abc import ABC, abstractmethod
from collections.abc import Callable
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from ...config import settings
from ...mcp.factory import MCPClientFactory, MCPServerType
from ...utils.security import secure_mkdir, secure_open

logger = logging.getLogger(__name__)


class MarketGatherer(ABC):
    """Base class for market data gatherers with TTL caching.

    Subclasses should implement:
    - gather(): Collect data from MCP sources
    - _get_cache_key(): Return unique cache key
    And set:
    - cache_ttl_hours: Cache TTL in hours (class attribute)
    """

    cache_ttl_hours: int = 24

    def __init__(self) -> None:
        """Initialize gatherer with cache directory."""
        self._cache_dir = settings.market_cache_dir
        try:
            secure_mkdir(self._cache_dir)
        except OSError as exc:
            fallback_dir = Path(tempfile.gettempdir()) / "fu7ur3pr00f_market_cache"
            logger.warning(
                "Market cache dir %s is not writable (%s); using %s instead",
                self._cache_dir,
                exc,
                fallback_dir,
            )
            self._cache_dir = secure_mkdir(fallback_dir)

    @abstractmethod
    async def gather(self, **kwargs: Any) -> dict[str, Any]:
        """Gather market data from sources.

        Args:
            **kwargs: Gatherer-specific parameters

        Returns:
            Dictionary with gathered data
        """
        ...

    @abstractmethod
    def _get_cache_key(self, **kwargs: Any) -> str:
        """Generate cache key for the given parameters.

        Args:
            **kwargs: Parameters that affect cache key

        Returns:
            Unique cache key string
        """
        ...

    def _get_cache_path(self, cache_key: str) -> Path:
        """Get path to cache file for given key.

        Args:
            cache_key: Cache key

        Returns:
            Path to cache file
        """
        # Hash the key to avoid filesystem issues with special characters
        key_hash = hashlib.md5(cache_key.encode(), usedforsecurity=False).hexdigest()[
            :16
        ]
        return self._cache_dir / f"{self.__class__.__name__}_{key_hash}.json"

    def _is_cache_valid(self, cache_path: Path) -> bool:
        """Check if cache file exists and is not expired.

        Args:
            cache_path: Path to cache file

        Returns:
            True if cache is valid and can be used
        """
        if not cache_path.exists():
            return False

        try:
            with cache_path.open(encoding="utf-8") as f:
                cache_data = json.load(f)

            cached_at = datetime.fromisoformat(cache_data.get("cached_at", ""))
            ttl_hours = self.cache_ttl_hours
            expires_at = cached_at + timedelta(hours=ttl_hours)

            return datetime.now() < expires_at

        except (json.JSONDecodeError, ValueError, KeyError):
            return False

    def _read_cache(self, cache_path: Path) -> dict[str, Any] | None:
        """Read data from cache file.

        Args:
            cache_path: Path to cache file

        Returns:
            Cached data or None if invalid
        """
        try:
            with cache_path.open(encoding="utf-8") as f:
                cache_data = json.load(f)
            return cache_data.get("data")
        except (json.JSONDecodeError, OSError):
            return None

    def _write_cache(self, cache_path: Path, data: dict[str, Any]) -> None:
        """Write data to cache file.

        Args:
            cache_path: Path to cache file
            data: Data to cache
        """
        cache_data = {
            "cached_at": datetime.now().isoformat(),
            "ttl_hours": self.cache_ttl_hours,
            "data": data,
        }
        try:
            with secure_open(cache_path, mode="w", file_mode=0o600) as f:
                json.dump(cache_data, f, indent=2, default=str)
        except OSError as e:
            logger.warning("Failed to write cache: %s", e)

    async def gather_with_cache(
        self,
        refresh: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Gather data with caching support.

        Args:
            refresh: If True, bypass cache and fetch fresh data
            **kwargs: Gatherer-specific parameters

        Returns:
            Dictionary with gathered data (from cache or fresh)
        """
        cache_key = self._get_cache_key(**kwargs)
        cache_path = self._get_cache_path(cache_key)

        # Check cache unless refresh requested
        if not refresh and self._is_cache_valid(cache_path):
            cached_data = self._read_cache(cache_path)
            if cached_data is not None:
                logger.info(f"Using cached data for {self.__class__.__name__}")
                return cached_data

        # Gather fresh data
        logger.info("Gathering fresh data for %s", self.__class__.__name__)
        data = await self.gather(**kwargs)

        # Cache the results
        self._write_cache(cache_path, data)

        return data

    @staticmethod
    def _parse_mcp_content(content: Any, default: str = "{}") -> Any:
        """Parse MCP tool result content into a Python object.

        Args:
            content: Raw content from MCPToolResult (str or already parsed)
            default: Default JSON string if content is falsy

        Returns:
            Parsed Python object (dict, list, etc.)
        """
        raw = content or default
        return json.loads(raw) if isinstance(raw, str) else raw

    async def _gather_from_source(
        self,
        source_name: MCPServerType,
        tool_name: str,
        tool_args: dict[str, Any],
        results: dict[str, Any],
        extractor: Callable[[dict[str, Any]], list[dict[str, Any]]] | None = None,
        source_label: str | None = None,
    ) -> list[dict[str, Any]]:
        """Generic method to gather from any MCP source.

        This helper eliminates the repeated try/except pattern across
        multiple source gathering blocks. (DRY fix)

        Args:
            source_name: MCP source name (e.g., "jobspy", "remoteok")
            tool_name: Tool to call on the MCP client
            tool_args: Arguments to pass to the tool
            results: Results dict to update with errors
            extractor: Optional function to extract items from response.
                       Default extracts response.get("jobs", [])
            source_label: Optional human-readable label for logging

        Returns:
            List of extracted items (empty if source unavailable or errored)
        """
        label = source_label or source_name.capitalize()

        if not MCPClientFactory.is_available(source_name):
            logger.debug("%s MCP not available, skipping", label)
            return []

        try:
            logger.info("%s: Gathering data...", label)
            client = MCPClientFactory.create(source_name)
            async with client:
                result = await client.call_tool(tool_name, tool_args)

                if not result.is_error:
                    parsed = self._parse_mcp_content(result.content)

                    # Extract items using provided extractor or default
                    if extractor is not None:
                        items = extractor(parsed)
                    elif isinstance(parsed, dict):
                        items = parsed.get("jobs", [])
                    else:
                        items = parsed if isinstance(parsed, list) else []

                    logger.info("%s: Found %d items", label, len(items))
                    return items
                else:
                    logger.warning("%s: %s", label, result.error_message)
                    results["errors"].append(f"{label}: {result.error_message}")
                    return []

        except Exception as e:
            logger.exception("Error gathering from %s", label)
            results["errors"].append(f"{label} error: {e}")
            return []
