# CodeTrust Hallucination Registry

**The open database of AI code hallucinations.** 70+ phantom APIs, 25+ cross-language confusions, 15+ phantom packages that AI coding tools generate.

45% of AI-generated code contains vulnerabilities. Many are **hallucinations** — functions, methods, and packages that the AI invented but don't actually exist. Traditional security scanners (Snyk, SonarQube, Semgrep) don't detect these because they only look for known vulnerabilities in real code. Hallucinated code is a new vulnerability class.

## Install

```bash
pip install codetrust-hallucination-registry
```

**Zero dependencies. Runs offline. MIT licensed.**

## Usage

```python
from codetrust_registry import is_phantom, check, get_all_phantoms

# Quick check
is_phantom("os.get_env")        # True — doesn't exist in Python
is_phantom("os.getenv")          # False — this is real
is_phantom("json.parse")         # True — this is JavaScript, not Python
is_phantom(".push")              # True — JavaScript Array method
is_phantom(".append")            # False — Python list method

# Detailed check
result = check("os.get_env")
# {
#   "is_phantom": True,
#   "correct": "os.getenv()",
#   "cwe_id": "CT-HALL-001",
#   "description": "os.get_env() does not exist. The correct function is os.getenv().",
#   "ai_tools": "copilot,chatgpt,cursor"
# }

# Get all patterns
phantoms = get_all_phantoms(language="python")
print(f"{len(phantoms)} phantom patterns for Python")

# Filter by category
cross_lang = get_all_phantoms(category="cross_language")
phantom_apis = get_all_phantoms(category="phantom_api")
phantom_pkgs = get_all_phantoms(category="phantom_package")
```

## What It Catches

### Phantom APIs (CT-HALL-001)
Functions that AI tools invent but don't exist in the target library:
- `os.get_env()` → should be `os.getenv()`
- `json.read_file()` → should be `json.load(open(path))`
- `hashlib.encrypt()` → hashlib does hashing, not encryption
- `subprocess.execute()` → should be `subprocess.run()`

### Cross-Language Confusion (CT-HALL-003)
JavaScript/Java methods that AI puts in Python code:
- `.push()` → should be `.append()`
- `.trim()` → should be `.strip()`
- `.toUpperCase()` → should be `.upper()`
- `.contains()` → should be `'x' in string`
- `.length` → should be `len()`
- `JSON.parse()` → should be `json.loads()`
- `console.log()` → should be `print()`

### Phantom Packages (CT-HALL-002)
Packages that AI imports but don't exist on PyPI — potential supply chain attack vectors:
- `flask_secure_headers` — doesn't exist, attacker could register it
- `fastapi_helpers` — doesn't exist
- `django_utils` as a package — doesn't exist (django.utils is a module)

## Why This Matters

When AI generates `from flask_secure_headers import SecureHeaders`, that package doesn't exist. But an attacker can register `flask-secure-headers` on PyPI with malicious code. The next time someone runs `pip install`, they get owned. This is called **dependency confusion via AI hallucination** — a new attack vector that didn't exist before AI coding tools.

## API

The full registry is also available as a REST API (no auth required):

```bash
# Check a function
curl https://codetrust-api.agreeablewave-62213e7f.ukwest.azurecontainerapps.io/v1/registry/check?function=os.get_env

# List all patterns
curl https://codetrust-api.agreeablewave-62213e7f.ukwest.azurecontainerapps.io/v1/registry/phantoms

# Get stats
curl https://codetrust-api.agreeablewave-62213e7f.ukwest.azurecontainerapps.io/v1/registry/stats
```

## Contributing

Found a new hallucination pattern? Report it:

1. Open an issue on [GitHub](https://github.com/autoailabadmin/codetrust-hallucination-registry)
2. Or use the API: `POST /v1/registry/report` (requires free CodeTrust account)

## Full Scanner

This registry is the **open database**. For the full scanning engine (AST-based analysis, compliance, URL scanning, enterprise features), see [CodeTrust Enterprise](https://autoailabs.co.uk/products/codetrust).

## License

MIT — use freely in your projects, CI/CD, and tools.

Published by [AutoAI Labs](https://autoailabs.co.uk).
