"""CodeTrust Hallucination Registry — The open database of AI code hallucinations.

The world's first open, community-contributed database of AI hallucination patterns.
Every phantom API, fake package, and non-existent function that LLMs generate.

Usage:
    from codetrust_registry import is_phantom, check, get_all_phantoms

    # Quick check
    is_phantom("os.get_env")        # True — this function doesn't exist
    is_phantom("os.getenv")          # False — this is the real function

    # Detailed check
    result = check("json.parse", language="python")
    # {"is_phantom": True, "correct": "json.loads()", "cwe": "CT-HALL-003"}

    # Get all patterns
    phantoms = get_all_phantoms(language="python")
    # Returns list of 500+ phantom patterns

Published by AutoAI Labs (autoailabs.co.uk/products/codetrust)
MIT License — use freely in your own projects and CI/CD pipelines.

API: https://codetrust-api.agreeablewave-62213e7f.ukwest.azurecontainerapps.io/v1/registry/
GitHub: https://github.com/autoailabadmin/codetrust-hallucination-registry
"""

__version__ = "1.0.0"

from .registry import is_phantom, check, get_all_phantoms, get_stats, PHANTOM_COUNT

__all__ = ["is_phantom", "check", "get_all_phantoms", "get_stats", "PHANTOM_COUNT"]
