"""Core hallucination registry — the actual pattern database.

This is the open-source database that anyone can use. MIT licensed.
No API key required. No cloud dependency. Runs entirely offline.

Patterns are organized by:
  - Language (python, javascript, typescript, go)
  - Category (phantom_api, phantom_package, cross_language, deprecated_confusion)
  - Severity (critical, high, medium, low)

Each pattern includes:
  - The hallucinated function/method/package
  - The correct alternative (if one exists)
  - CWE/CodeTrust ID reference
  - Which AI tools commonly generate this hallucination

Contribute new patterns: https://github.com/autoailabadmin/codetrust-hallucination-registry
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class PhantomPattern:
    """A single AI hallucination pattern."""
    library: str
    function: str
    language: str
    category: str  # phantom_api, phantom_package, cross_language, deprecated_confusion
    severity: str  # critical, high, medium, low
    correct: str = ""  # The correct alternative
    description: str = ""
    cwe_id: str = ""  # CWE-xxx or CT-HALL-xxx
    ai_tools: str = ""  # Which AI tools commonly generate this


# ═══════════════════════════════════════════════════════════════
# PYTHON PHANTOM APIS — functions that AI invents but don't exist
# ═══════════════════════════════════════════════════════════════

PYTHON_PHANTOM_APIS: list[PhantomPattern] = [
    # os module
    PhantomPattern("os", "get_env", "python", "phantom_api", "critical", "os.getenv()", "os.get_env() does not exist. The correct function is os.getenv().", "CT-HALL-001", "copilot,chatgpt,cursor"),
    PhantomPattern("os", "set_env", "python", "phantom_api", "high", "os.environ[key] = value", "os.set_env() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "read_file", "python", "phantom_api", "high", "open(path).read()", "os.read_file() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "write_file", "python", "phantom_api", "high", "open(path, 'w').write()", "os.write_file() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "file_exists", "python", "phantom_api", "high", "os.path.exists()", "os.file_exists() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "create_dir", "python", "phantom_api", "high", "os.makedirs()", "os.create_dir() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "delete_file", "python", "phantom_api", "high", "os.remove()", "os.delete_file() does not exist.", "CT-HALL-001"),
    PhantomPattern("os", "get_cwd", "python", "phantom_api", "medium", "os.getcwd()", "os.get_cwd() does not exist. Use os.getcwd().", "CT-HALL-001"),
    # os.path module
    PhantomPattern("os.path", "get_extension", "python", "phantom_api", "high", "os.path.splitext()", "os.path.get_extension() does not exist.", "CT-HALL-001"),
    PhantomPattern("os.path", "to_absolute", "python", "phantom_api", "high", "os.path.abspath()", "os.path.to_absolute() does not exist.", "CT-HALL-001"),
    PhantomPattern("os.path", "is_valid", "python", "phantom_api", "high", "os.path.exists()", "os.path.is_valid() does not exist.", "CT-HALL-001"),
    PhantomPattern("os.path", "normalize", "python", "phantom_api", "medium", "os.path.normpath()", "os.path.normalize() does not exist.", "CT-HALL-001"),
    # json module
    PhantomPattern("json", "parse", "python", "cross_language", "critical", "json.loads()", "json.parse() is JavaScript. In Python, use json.loads().", "CT-HALL-003", "chatgpt,copilot"),
    PhantomPattern("json", "stringify", "python", "cross_language", "critical", "json.dumps()", "json.stringify() is JavaScript. In Python, use json.dumps().", "CT-HALL-003", "chatgpt,copilot"),
    PhantomPattern("json", "read_file", "python", "phantom_api", "high", "json.load(open(path))", "json.read_file() does not exist.", "CT-HALL-001"),
    PhantomPattern("json", "write_file", "python", "phantom_api", "high", "json.dump(data, open(path,'w'))", "json.write_file() does not exist.", "CT-HALL-001"),
    PhantomPattern("json", "validate", "python", "phantom_api", "medium", "json.loads() in try/except", "json.validate() does not exist.", "CT-HALL-001"),
    # pathlib.Path
    PhantomPattern("pathlib.Path", "read", "python", "phantom_api", "high", ".read_text()", "Path.read() does not exist. Use .read_text() or .read_bytes().", "CT-HALL-001"),
    PhantomPattern("pathlib.Path", "write", "python", "phantom_api", "high", ".write_text()", "Path.write() does not exist. Use .write_text() or .write_bytes().", "CT-HALL-001"),
    PhantomPattern("pathlib.Path", "copy", "python", "phantom_api", "high", "shutil.copy()", "Path.copy() does not exist. Use shutil.copy().", "CT-HALL-001"),
    PhantomPattern("pathlib.Path", "move", "python", "phantom_api", "high", "shutil.move()", "Path.move() does not exist. Use shutil.move().", "CT-HALL-001"),
    PhantomPattern("pathlib.Path", "delete", "python", "phantom_api", "high", ".unlink()", "Path.delete() does not exist. Use .unlink().", "CT-HALL-001"),
    # datetime
    PhantomPattern("datetime", "from_string", "python", "phantom_api", "high", "datetime.strptime()", "datetime.from_string() does not exist.", "CT-HALL-001"),
    PhantomPattern("datetime", "to_string", "python", "phantom_api", "high", "datetime.strftime()", "datetime.to_string() does not exist.", "CT-HALL-001"),
    PhantomPattern("datetime", "parse", "python", "phantom_api", "high", "datetime.fromisoformat() or dateutil.parser.parse()", "datetime.parse() does not exist.", "CT-HALL-001"),
    PhantomPattern("datetime", "to_timestamp", "python", "phantom_api", "medium", "datetime.timestamp()", "datetime.to_timestamp() does not exist.", "CT-HALL-001"),
    # hashlib
    PhantomPattern("hashlib", "hash", "python", "phantom_api", "high", "hashlib.sha256(data).hexdigest()", "hashlib.hash() does not exist.", "CT-HALL-001"),
    PhantomPattern("hashlib", "encrypt", "python", "phantom_api", "critical", "Use cryptography library", "hashlib.encrypt() does not exist. hashlib is for hashing, not encryption.", "CT-HALL-001"),
    PhantomPattern("hashlib", "decrypt", "python", "phantom_api", "critical", "Use cryptography library", "hashlib.decrypt() does not exist. hashlib is for hashing, not encryption.", "CT-HALL-001"),
    # requests
    PhantomPattern("requests", "fetch", "python", "cross_language", "high", "requests.get()", "requests.fetch() does not exist. fetch() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("requests", "send", "python", "phantom_api", "medium", "requests.request()", "requests.send() is a low-level Session method, not a top-level function.", "CT-HALL-001"),
    # subprocess
    PhantomPattern("subprocess", "execute", "python", "phantom_api", "high", "subprocess.run()", "subprocess.execute() does not exist. Use subprocess.run().", "CT-HALL-001"),
    PhantomPattern("subprocess", "exec", "python", "phantom_api", "high", "subprocess.run()", "subprocess.exec() does not exist. Use subprocess.run().", "CT-HALL-001"),
]

# ═══════════════════════════════════════════════════════════════
# CROSS-LANGUAGE HALLUCINATIONS — JS/Java methods in Python
# ═══════════════════════════════════════════════════════════════

CROSS_LANGUAGE_PHANTOMS: list[PhantomPattern] = [
    # String methods
    PhantomPattern("str", "contains", "python", "cross_language", "critical", "'x' in string", ".contains() is Java/JS. Use 'in' operator in Python.", "CT-HALL-003", "chatgpt,copilot,cursor"),
    PhantomPattern("str", "trim", "python", "cross_language", "critical", ".strip()", ".trim() is JavaScript. Use .strip() in Python.", "CT-HALL-003", "chatgpt,copilot"),
    PhantomPattern("str", "trimStart", "python", "cross_language", "high", ".lstrip()", ".trimStart() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "trimEnd", "python", "cross_language", "high", ".rstrip()", ".trimEnd() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "toUpperCase", "python", "cross_language", "high", ".upper()", ".toUpperCase() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "toLowerCase", "python", "cross_language", "high", ".lower()", ".toLowerCase() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "charAt", "python", "cross_language", "high", "str[index]", ".charAt() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "indexOf", "python", "cross_language", "high", ".index() or .find()", ".indexOf() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "includes", "python", "cross_language", "high", "'x' in string", ".includes() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "startsWith", "python", "cross_language", "medium", ".startswith()", ".startsWith() is JavaScript (note case).", "CT-HALL-003"),
    PhantomPattern("str", "endsWith", "python", "cross_language", "medium", ".endswith()", ".endsWith() is JavaScript (note case).", "CT-HALL-003"),
    PhantomPattern("str", "substring", "python", "cross_language", "medium", "str[start:end]", ".substring() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("str", "toString", "python", "cross_language", "high", "str()", ".toString() is JavaScript/Java.", "CT-HALL-003"),
    # Array/List methods
    PhantomPattern("list", "push", "python", "cross_language", "critical", ".append()", ".push() is JavaScript. Use .append() in Python.", "CT-HALL-003", "chatgpt,copilot,cursor"),
    PhantomPattern("list", "shift", "python", "cross_language", "high", ".pop(0)", ".shift() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("list", "unshift", "python", "cross_language", "high", ".insert(0, x)", ".unshift() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("list", "splice", "python", "cross_language", "high", "list slicing", ".splice() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("list", "forEach", "python", "cross_language", "high", "for item in list:", ".forEach() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("list", "length", "python", "cross_language", "critical", "len(list)", ".length is JavaScript/Java. Use len() in Python.", "CT-HALL-003", "chatgpt,copilot"),
    # Global functions
    PhantomPattern("global", "parseInt", "python", "cross_language", "high", "int()", "parseInt() is JavaScript global.", "CT-HALL-003"),
    PhantomPattern("global", "parseFloat", "python", "cross_language", "high", "float()", "parseFloat() is JavaScript global.", "CT-HALL-003"),
    PhantomPattern("global", "console.log", "python", "cross_language", "high", "print()", "console.log() is JavaScript.", "CT-HALL-003"),
    PhantomPattern("global", "typeof", "python", "cross_language", "high", "type()", "typeof is JavaScript.", "CT-HALL-003"),
    PhantomPattern("global", "require", "python", "cross_language", "high", "import", "require() is Node.js. Use import in Python.", "CT-HALL-003"),
]

# ═══════════════════════════════════════════════════════════════
# PHANTOM PACKAGES — AI-hallucinated packages that don't exist
# ═══════════════════════════════════════════════════════════════

PHANTOM_PACKAGES: list[PhantomPattern] = [
    PhantomPattern("", "flask_secure_headers", "python", "phantom_package", "critical", "flask-talisman or secure-headers", "flask_secure_headers does not exist on PyPI.", "CT-HALL-002", "cursor,copilot"),
    PhantomPattern("", "flask_utils", "python", "phantom_package", "high", "flask extensions", "flask_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "flask_helpers", "python", "phantom_package", "high", "", "flask_helpers does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "django_utils", "python", "phantom_package", "high", "django.utils", "django_utils as a package does not exist. Use django.utils.", "CT-HALL-002"),
    PhantomPattern("", "requests_utils", "python", "phantom_package", "high", "", "requests_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "utils", "python", "phantom_package", "medium", "", "'utils' is a generic name often hallucinated. Check if it's a local module.", "CT-HALL-002"),
    PhantomPattern("", "helpers", "python", "phantom_package", "medium", "", "'helpers' is a generic name often hallucinated.", "CT-HALL-002"),
    PhantomPattern("", "common", "python", "phantom_package", "medium", "", "'common' is a generic name often hallucinated.", "CT-HALL-002"),
    PhantomPattern("", "core_utils", "python", "phantom_package", "medium", "", "core_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "api_utils", "python", "phantom_package", "medium", "", "api_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "db_utils", "python", "phantom_package", "medium", "", "db_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "auth_utils", "python", "phantom_package", "medium", "", "auth_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "config_utils", "python", "phantom_package", "medium", "", "config_utils does not exist on PyPI.", "CT-HALL-002"),
    PhantomPattern("", "fastapi_utils", "python", "phantom_package", "high", "fastapi", "fastapi_utils may not be the package you want.", "CT-HALL-002"),
    PhantomPattern("", "fastapi_helpers", "python", "phantom_package", "high", "", "fastapi_helpers does not exist on PyPI.", "CT-HALL-002"),
]

# ═══════════════════════════════════════════════════════════════
# ALL PATTERNS COMBINED
# ═══════════════════════════════════════════════════════════════

ALL_PHANTOMS: list[PhantomPattern] = PYTHON_PHANTOM_APIS + CROSS_LANGUAGE_PHANTOMS + PHANTOM_PACKAGES
PHANTOM_COUNT = len(ALL_PHANTOMS)

# Build lookup indexes for fast querying
_FUNCTION_INDEX: dict[str, PhantomPattern] = {}
for p in ALL_PHANTOMS:
    key = f"{p.library}.{p.function}" if p.library else p.function
    _FUNCTION_INDEX[key.lower()] = p
    _FUNCTION_INDEX[p.function.lower()] = p  # Also index by function name alone
    # Index with leading dot for method-style lookup (.push, .trim, etc.)
    _FUNCTION_INDEX[f".{p.function}".lower()] = p


def is_phantom(function_name: str, language: str = "python") -> bool:
    """Check if a function/method name is a known AI hallucination.

    Args:
        function_name: Full name like "os.get_env" or just "get_env"
        language: Programming language (default: python)

    Returns:
        True if this is a known phantom pattern.

    Example:
        >>> is_phantom("os.get_env")
        True
        >>> is_phantom("os.getenv")
        False
        >>> is_phantom("json.parse")
        True  # This is JavaScript, not Python
    """
    key = function_name.lower()
    if key in _FUNCTION_INDEX:
        p = _FUNCTION_INDEX[key]
        return p.language == language
    return False


def check(function_name: str, language: str = "python") -> dict:
    """Detailed check of a function/method name.

    Returns dict with is_phantom, correct alternative, CWE ID, description.

    Example:
        >>> check("os.get_env")
        {"is_phantom": True, "correct": "os.getenv()", "cwe": "CT-HALL-001", ...}
    """
    key = function_name.lower()
    pattern = _FUNCTION_INDEX.get(key)

    if pattern and pattern.language == language:
        return {
            "is_phantom": True,
            "function": function_name,
            "language": language,
            "library": pattern.library,
            "category": pattern.category,
            "severity": pattern.severity,
            "correct": pattern.correct,
            "description": pattern.description,
            "cwe_id": pattern.cwe_id,
            "ai_tools": pattern.ai_tools,
        }

    return {
        "is_phantom": False,
        "function": function_name,
        "language": language,
    }


def get_all_phantoms(language: str = "", category: str = "") -> list[dict]:
    """Get all phantom patterns, optionally filtered by language/category.

    Args:
        language: Filter by language (e.g., "python")
        category: Filter by category (e.g., "phantom_api", "cross_language")

    Returns:
        List of pattern dictionaries.
    """
    results = []
    for p in ALL_PHANTOMS:
        if language and p.language != language:
            continue
        if category and p.category != category:
            continue
        results.append({
            "library": p.library,
            "function": p.function,
            "language": p.language,
            "category": p.category,
            "severity": p.severity,
            "correct": p.correct,
            "description": p.description,
            "cwe_id": p.cwe_id,
            "ai_tools": p.ai_tools,
        })
    return results


def get_stats() -> dict:
    """Get aggregate statistics about the registry."""
    by_category = {}
    by_severity = {}
    by_language = {}
    by_library = {}

    for p in ALL_PHANTOMS:
        by_category[p.category] = by_category.get(p.category, 0) + 1
        by_severity[p.severity] = by_severity.get(p.severity, 0) + 1
        by_language[p.language] = by_language.get(p.language, 0) + 1
        if p.library:
            by_library[p.library] = by_library.get(p.library, 0) + 1

    return {
        "total_patterns": PHANTOM_COUNT,
        "by_category": by_category,
        "by_severity": by_severity,
        "by_language": by_language,
        "top_libraries": dict(sorted(by_library.items(), key=lambda x: -x[1])[:10]),
        "version": "1.0.0",
        "source": "https://github.com/autoailabadmin/codetrust-hallucination-registry",
    }
