"""`neruva-control-install` -- the one-shot install command.

Goals (Kyle: "make sure UX is world class"):
  - User runs `pip install neruva-control && neruva-control-install`
  - We generate a token, write config, register an OS service, start
    the daemon, and print a clickable URL with the token in the
    fragment so the browser can link in one click.
  - No flags needed in the common path. `--help` documents the rare
    overrides (--no-service, --reinstall, --port).

Cross-platform service registration:
  - macOS  : ~/Library/LaunchAgents/io.neruva.control.plist + launchctl load
  - Linux  : ~/.config/systemd/user/neruva-control.service + systemctl --user
  - Windows: schtasks /Create with ONLOGON trigger + immediate start

If service registration fails (rootless containers, weird init systems),
we degrade to "you're set up, but you'll need to run `neruva-control
start` yourself in a background shell".
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import textwrap
import time
from pathlib import Path

from ._config import config_dir, gen_token, write_token, cockpit_link_url, token_path


PORT = 7331


# ---------------------------------------------------------------------------
# Cross-platform service registration
# ---------------------------------------------------------------------------

def _python_exe() -> str:
    return sys.executable or "python"


def _start_cmd() -> list[str]:
    """The command that runs the daemon foreground. Used by service
    registration on every OS."""
    return [_python_exe(), "-m", "neruva_control._cli", "start"]


def _install_macos() -> tuple[bool, str]:
    label = "io.neruva.control"
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    plist_dir.mkdir(parents=True, exist_ok=True)
    plist = plist_dir / f"{label}.plist"
    cmd_args = "".join(f"        <string>{a}</string>\n" for a in _start_cmd())
    plist.write_text(textwrap.dedent(f"""\
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
          "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
        <plist version="1.0">
        <dict>
          <key>Label</key><string>{label}</string>
          <key>ProgramArguments</key>
          <array>
{cmd_args}        </array>
          <key>RunAtLoad</key><true/>
          <key>KeepAlive</key><true/>
          <key>StandardOutPath</key>
          <string>{config_dir()}/daemon.log</string>
          <key>StandardErrorPath</key>
          <string>{config_dir()}/daemon.err</string>
        </dict>
        </plist>
    """), encoding="utf-8")
    try:
        # Unload first in case we're re-installing
        subprocess.run(["launchctl", "unload", str(plist)], capture_output=True)
        subprocess.run(["launchctl", "load", str(plist)], check=True, capture_output=True)
        return True, f"launchd: loaded {plist}"
    except Exception as e:
        return False, f"launchctl load failed: {e}"


def _install_linux() -> tuple[bool, str]:
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit = unit_dir / "neruva-control.service"
    exec_line = " ".join(_start_cmd())
    unit.write_text(textwrap.dedent(f"""\
        [Unit]
        Description=Neruva Control daemon (Cockpit local controller)
        After=network.target

        [Service]
        ExecStart={exec_line}
        Restart=always
        RestartSec=3
        Environment=PYTHONUNBUFFERED=1

        [Install]
        WantedBy=default.target
    """), encoding="utf-8")
    if not shutil.which("systemctl"):
        return False, "systemctl not found; skip auto-service. Run `neruva-control start` manually."
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=True, capture_output=True)
        subprocess.run(["systemctl", "--user", "enable", "--now", "neruva-control.service"],
                       check=True, capture_output=True)
        return True, f"systemd-user: enabled {unit}"
    except Exception as e:
        return False, f"systemctl --user enable failed: {e}"


def _install_windows() -> tuple[bool, str]:
    """Use schtasks to register an ONLOGON task. Avoids needing admin."""
    task_name = "NeruvaControl"
    cmd_str = " ".join(f'"{a}"' for a in _start_cmd())
    try:
        # Delete any prior task silently
        subprocess.run(["schtasks", "/Delete", "/TN", task_name, "/F"],
                       capture_output=True)
        # Create on-logon task that runs in current session
        subprocess.run([
            "schtasks", "/Create", "/TN", task_name,
            "/SC", "ONLOGON",
            "/TR", cmd_str,
            "/RL", "LIMITED",
            "/F",
        ], check=True, capture_output=True)
        # Run it now so user doesn't need to log out
        subprocess.run(["schtasks", "/Run", "/TN", task_name],
                       check=True, capture_output=True)
        return True, f"Task Scheduler: registered task '{task_name}'"
    except FileNotFoundError:
        return False, "schtasks not on PATH; skipping auto-service"
    except subprocess.CalledProcessError as e:
        msg = (e.stderr or b"").decode(errors="replace").strip()
        return False, f"schtasks /Create failed: {msg or e}"


def _install_service() -> tuple[bool, str]:
    if sys.platform == "darwin":
        return _install_macos()
    if sys.platform == "win32":
        return _install_windows()
    if sys.platform.startswith("linux"):
        return _install_linux()
    return False, f"unsupported platform: {sys.platform}"


def _wait_for_daemon(timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            s.connect(("127.0.0.1", PORT))
            s.close()
            return True
        except OSError:
            time.sleep(0.3)
    return False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="neruva-control-install",
        description=(
            "One-shot install for the Neruva Control daemon. "
            "Generates a token, registers a background service, and "
            "prints a one-time URL to link your browser to Cockpit."
        ),
    )
    p.add_argument("--no-service", action="store_true",
                   help="Skip OS service registration (run `neruva-control start` yourself).")
    p.add_argument("--reinstall", action="store_true",
                   help="Rotate the token even if one already exists.")
    p.add_argument("--base", default="https://app.neruva.io",
                   help="Cockpit base URL (default: https://app.neruva.io).")
    args = p.parse_args(argv)

    print()
    print("Installing Neruva Control...")
    print()

    # 1. Token
    if token_path().exists() and not args.reinstall:
        from ._config import load_token
        token = load_token()
        print(f"  [skip] Token already present at {token_path()}")
        print(f"         (re-run with --reinstall to rotate it)")
    else:
        token = gen_token()
        write_token(token)
        print(f"  [ok]   Token written to {token_path()}")

    # 2. Service registration
    if args.no_service:
        print("  [skip] Service registration (--no-service set)")
        service_msg = "skipped"
        service_ok = False
    else:
        service_ok, service_msg = _install_service()
        marker = "[ok]" if service_ok else "[warn]"
        print(f"  {marker} {service_msg}")

    # 3. Wait for daemon to come up (if we just registered + started one)
    if service_ok:
        up = _wait_for_daemon()
        if up:
            print(f"  [ok]   Daemon listening on 127.0.0.1:{PORT}")
        else:
            print(f"  [warn] Daemon didn't come up within 10s; check logs at {config_dir()}/daemon.log")
    else:
        print()
        print(f"  Auto-service didn't register. Start the daemon manually with:")
        print(f"    neruva-control start")
        print(f"  (then re-run this command, or run `neruva-control link`)")

    # 4. Print the fragment URL
    print()
    print("=" * 70)
    print()
    print("Open this URL in your browser to link this machine:")
    print()
    print(f"  {cockpit_link_url(token, args.base)}")
    print()
    print("Same machine, same browser. Token is stashed in localStorage; the")
    print("URL fragment is stripped after first load. Bookmark app.neruva.io/cockpit.")
    print()
    print("=" * 70)
    print()
    return 0 if service_ok or args.no_service else 1


if __name__ == "__main__":
    sys.exit(main())
