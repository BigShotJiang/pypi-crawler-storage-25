"""Neruva Code agent loop: file/bash/edit executor + substrate plan
caching + memory enrichment + chat-steering.

The action model itself runs server-side at api.neruva.io. The daemon
sends task + history to /v1/agent/code/step and gets back the next
action JSON. Vendor identity is fully server-side (trade-secret IP);
the daemon only knows "Neruva Code."

Flow:
  0. Pre-task: substrate /v1/agent/context for past relevant records
     (memory enrichment, prepended to first prompt).
  1. Look up cached plan via substrate plan_cache_lookup.
  2. If hit (score >= 0.85, success_rate >= 0.8) -> replay cached plan.
  3. Else: substrate /code/step -> execute action -> repeat until
     'done' or max_steps. Per-action safety check against past
     mistake_learn records.
  4. Save plan to substrate plan_cache_save for next time.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import httpx

from ._memory_enrichment import (
    enrich_task_with_memory,
    check_action_safety,
    compose_enriched_task,
)


NERUVA_BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io")

# Defaults
_DEFAULT_MAX_STEPS = 20
_DEFAULT_INTER_STEP_SLEEP_S = 0.2
_DEFAULT_STEP_TIMEOUT_S = 90.0
_DEFAULT_SUBSTRATE_TIMEOUT_S = 10.0
_DEFAULT_BASH_TIMEOUT_S = 30.0
_CACHE_SCORE_THRESHOLD = 0.85
_CACHE_SUCCESS_RATE_THRESHOLD = 0.8

# Bash safety: block obvious destructive patterns. Not exhaustive; MVP
# guard only. A determined model could still cause damage.
_BLOCKED_BASH_PATTERNS = [
    re.compile(r"\brm\s+-rf?\s+/(?!tmp|var/tmp)", re.IGNORECASE),
    re.compile(r"\bsudo\b", re.IGNORECASE),
    re.compile(r"\bmkfs\b", re.IGNORECASE),
    re.compile(r"\bdd\s+if=", re.IGNORECASE),
    re.compile(r"\bshutdown\b", re.IGNORECASE),
    re.compile(r"\breboot\b", re.IGNORECASE),
    re.compile(r":\(\)\s*\{[^}]*:\|:[^;]*;\s*\}\s*;\s*:", re.IGNORECASE),
    re.compile(r">\s*/dev/sd[a-z]", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Model call (substrate proxy)
# ---------------------------------------------------------------------------

def pick_action(
    task_text: str,
    history: list[dict],
    *,
    cwd: Optional[str] = None,
    timeout: float = _DEFAULT_STEP_TIMEOUT_S,
    neruva_api_key: Optional[str] = None,
) -> dict:
    """Ask the Neruva Code action model for ONE next action via the
    substrate proxy. Daemon needs only NERUVA_API_KEY; vendor identity
    stays server-side.

    Returns the parsed JSON action dict. Raises on transport failure
    -- caller decides whether to abort the task."""
    api_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "NERUVA_API_KEY not configured. Get one at "
            "https://app.neruva.io and put it in ~/.config/neruva/.env."
        )
    with httpx.Client(timeout=timeout) as cli:
        r = cli.post(
            f"{NERUVA_BASE_URL}/v1/agent/code/step",
            headers={"Api-Key": api_key, "Content-Type": "application/json"},
            json={
                "task_text": task_text,
                "history": history[-6:] if history else [],
                "cwd": cwd or os.getcwd(),
            },
        )
    r.raise_for_status()
    return r.json().get("action") or {}


# Back-compat alias.
devstral_pick_action = pick_action


# ---------------------------------------------------------------------------
# Action executor (unchanged - all file/bash ops happen locally)
# ---------------------------------------------------------------------------

def _pick(action: dict, key: str, default=None):
    if key in action:
        return action[key]
    args = action.get("args") or {}
    return args.get(key, default)


def _resolve_path(p: str, cwd: Optional[str]) -> Path:
    path = Path(p).expanduser()
    if not path.is_absolute() and cwd:
        path = (Path(cwd) / path).resolve()
    else:
        path = path.resolve()
    return path


def execute_code_action(action: dict, cwd: Optional[str] = None) -> dict:
    """Run one Neruva Code action. Returns {ok, ...} or {ok: False, error}."""
    a = str(action.get("action", "")).lower()
    try:
        if a == "read_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            if not p.exists():
                return {"ok": False, "error": f"file not found: {p}"}
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                return {"ok": False, "error": f"read failed: {e}"}
            return {"ok": True, "content": text[:5000],
                    "n_bytes": len(text), "path": str(p)}

        if a == "write_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            content = str(_pick(action, "content", ""))
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return {"ok": True, "wrote_bytes": len(content), "path": str(p)}

        if a == "edit_file":
            p = _resolve_path(_pick(action, "path", ""), cwd)
            if not p.exists():
                return {"ok": False, "error": f"file not found: {p}"}
            old = str(_pick(action, "old", ""))
            new = str(_pick(action, "new", ""))
            text = p.read_text(encoding="utf-8", errors="replace")
            n_occurrences = text.count(old)
            if n_occurrences == 0:
                return {"ok": False,
                        "error": f"old string not found in {p}"}
            if n_occurrences > 1:
                return {"ok": False,
                        "error": (f"old string matches {n_occurrences} "
                                  f"places in {p}; needs more context")}
            text2 = text.replace(old, new)
            p.write_text(text2, encoding="utf-8")
            return {"ok": True, "edited": str(p), "delta_bytes": len(text2) - len(text)}

        if a == "search_files":
            pattern = str(_pick(action, "pattern", ""))
            search_dir = _resolve_path(_pick(action, "dir", "."), cwd)
            if not search_dir.exists():
                return {"ok": False, "error": f"dir not found: {search_dir}"}
            rg = shutil.which("rg")
            if rg:
                cmd = [rg, "--max-count", "20", "--max-filesize", "1M",
                       "--no-heading", pattern, str(search_dir)]
            else:
                cmd = ["grep", "-r", "-n", "--max-count", "20", pattern,
                       str(search_dir)]
            try:
                proc = subprocess.run(
                    cmd, capture_output=True, text=True,
                    timeout=15, check=False,
                )
                out = (proc.stdout or "")[:3000]
                return {"ok": True, "matches": out,
                        "n_lines": out.count("\n")}
            except subprocess.TimeoutExpired:
                return {"ok": False, "error": "search timeout"}

        if a == "run_bash":
            cmd = str(_pick(action, "command", ""))
            for pat in _BLOCKED_BASH_PATTERNS:
                if pat.search(cmd):
                    return {"ok": False,
                            "error": f"blocked: matches destructive pattern {pat.pattern!r}"}
            try:
                proc = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True,
                    timeout=_DEFAULT_BASH_TIMEOUT_S, check=False,
                    cwd=cwd,
                )
                out = (proc.stdout or "")[:2000]
                err = (proc.stderr or "")[:1000]
                return {
                    "ok": proc.returncode == 0,
                    "returncode": proc.returncode,
                    "stdout": out,
                    "stderr": err,
                }
            except subprocess.TimeoutExpired:
                return {"ok": False, "error": f"bash timeout {_DEFAULT_BASH_TIMEOUT_S}s"}

        if a == "done":
            return {"ok": True, "done": True}

        if a == "say":
            text = str(_pick(action, "text", ""))
            return {"ok": True, "said": text}

        return {"ok": False, "error": f"unknown action: {a!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ---------------------------------------------------------------------------
# Substrate plan-cache helpers
# ---------------------------------------------------------------------------

def _substrate_post_retry(
    url: str, body: dict, api_key: str,
    *, max_attempts: int = 5, base_delay_s: float = 0.5,
    timeout: float = _DEFAULT_SUBSTRATE_TIMEOUT_S,
) -> Optional[httpx.Response]:
    """POST with exponential backoff on 429."""
    delay = base_delay_s
    last_r: Optional[httpx.Response] = None
    for attempt in range(max_attempts):
        try:
            with httpx.Client(timeout=timeout) as cli:
                r = cli.post(
                    url,
                    headers={"Api-Key": api_key,
                             "Content-Type": "application/json"},
                    json=body,
                )
            last_r = r
            if r.status_code != 429:
                return r
        except Exception:
            pass
        time.sleep(delay)
        delay = min(delay * 2, 8.0)
    return last_r


async def _emit(on_step: Optional[Callable[[dict], Awaitable[None]]],
                event: dict) -> None:
    if on_step is None:
        return
    try:
        await on_step(event)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Main task loop
# ---------------------------------------------------------------------------

async def run_task(
    task_text,
    namespace: str = "cockpit_code",
    *,
    cwd: Optional[str] = None,
    neruva_api_key: Optional[str] = None,
    max_steps: int = _DEFAULT_MAX_STEPS,
    on_step: Optional[Callable[[dict], Awaitable[None]]] = None,
    use_cache: bool = True,
    use_memory: bool = True,
) -> dict:
    """Run a Neruva Code task end-to-end via substrate proxy.

    `task_text` accepts a string OR a zero-arg callable returning a
    string (callable form enables chat-steering: re-read on each turn).

    Returns {ok, n_steps, duration_ms, used_cache, model_calls,
    plan_saved_to_substrate, memory_enriched, history, plan}.
    """
    nv_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not nv_key:
        return {"ok": False, "error": "NERUVA_API_KEY not configured",
                "n_steps": 0}

    if callable(task_text):
        get_task = task_text
        initial_task_str = task_text()
    else:
        initial_task_str = str(task_text)
        get_task = lambda: initial_task_str   # noqa: E731

    t0 = time.perf_counter()

    # ---- 0. Memory enrichment ----
    enrichment_preamble = ""
    if use_memory:
        enrichment_preamble = enrich_task_with_memory(
            initial_task_str, namespace, nv_key,
        )
        if enrichment_preamble:
            await _emit(on_step, {
                "event": "memory_enriched",
                "preview": enrichment_preamble[:200],
                "n_chars": len(enrichment_preamble),
            })

    # ---- 1. Plan-cache lookup ----
    plan: list[dict] = []
    history: list[dict] = []
    plan_used_from_cache = False
    success = False
    model_calls = 0

    if use_cache:
        r = _substrate_post_retry(
            f"{NERUVA_BASE_URL}/v1/agent/plan_cache_lookup",
            {"namespace": namespace, "task_text": initial_task_str,
             "top_k": 1, "min_score": _CACHE_SCORE_THRESHOLD},
            nv_key,
        )
        if r is not None and r.status_code == 200:
            hits = r.json().get("hits", [])
            if hits and hits[0]["success_rate"] >= _CACHE_SUCCESS_RATE_THRESHOLD:
                plan = hits[0]["plan"]
                plan_used_from_cache = True
                await _emit(on_step, {
                    "event": "plan_cache_hit",
                    "n_steps": len(plan),
                    "score": hits[0]["score"],
                    "record_id": hits[0]["record_id"],
                })

    # ---- 2. Execute (cached or live) ----
    if plan_used_from_cache:
        for i, step in enumerate(plan):
            await _emit(on_step, {
                "event": "step_start", "i": i, "step": step,
                "source": "cache",
            })
            res = execute_code_action(step, cwd=cwd)
            history.append({"step": step, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
        success = all(h["result"].get("ok") for h in history)
    else:
        for i in range(max_steps):
            current_task = get_task()
            full_task = compose_enriched_task(current_task,
                                              enrichment_preamble)
            try:
                action = pick_action(full_task, history, cwd=cwd,
                                     neruva_api_key=nv_key)
                model_calls += 1
            except Exception as e:
                await _emit(on_step, {
                    "event": "model_error", "i": i,
                    "error": f"{type(e).__name__}: {e}",
                })
                break
            await _emit(on_step, {
                "event": "action", "i": i, "action": action,
                "source": "neruva-code",
            })
            if str(action.get("action", "")).lower() == "done":
                success = True
                break
            action_summary = (f"{action.get('action')}: "
                              f"{json.dumps(action.get('args', {}))[:200]}")
            if use_memory:
                hit = check_action_safety(action_summary, namespace, nv_key)
                if hit:
                    await _emit(on_step, {
                        "event": "safety_warning", "i": i,
                        "action": action,
                        "past_failure": {
                            "kind": hit.get("kind"),
                            "score": hit.get("score"),
                            "text": str(hit.get("text", ""))[:200],
                        },
                    })
            res = execute_code_action(action, cwd=cwd)
            plan.append(action)
            history.append({"step": action, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)

    duration_ms = int((time.perf_counter() - t0) * 1000)

    # ---- 3. Save plan to substrate ----
    saved = False
    if not plan_used_from_cache and plan:
        r = _substrate_post_retry(
            f"{NERUVA_BASE_URL}/v1/agent/plan_cache_save",
            {"namespace": namespace, "task_text": initial_task_str,
             "plan": plan, "success": success, "duration_ms": duration_ms,
             "tags": ["neruva-code"]},
            nv_key,
        )
        saved = (r is not None and r.status_code == 200)

    final = {
        "ok": success,
        "n_steps": len(plan),
        "duration_ms": duration_ms,
        "used_cache": plan_used_from_cache,
        "model_calls": model_calls,
        "plan_saved_to_substrate": saved if not plan_used_from_cache else False,
        "memory_enriched": bool(enrichment_preamble),
        "history": history,
        "plan": plan,
    }
    await _emit(on_step, {"event": "task_complete", **final})
    return final
