"""Neruva Computer agent loop: screenshot + pyautogui executor +
substrate plan-caching + chat-steering.

The action model itself runs server-side at api.neruva.io. The daemon
sends a screenshot + task + history to /v1/agent/computer/step and
gets back the next action JSON. Vendor identity is fully server-side
(trade-secret IP); the daemon only knows "Neruva Computer."

Flow:
  1. Look up cached plan for `task_text` via substrate.
  2. If hit with score >= 0.85 and success_rate >= 0.8 -> replay
     cached plan locally (skips per-step model call, ~50% cheaper
     per the APC paper).
  3. Else: screenshot -> substrate /computer/step -> pyautogui execute
     -> repeat until 'done' or max_steps.
  4. Save plan (success or fail) to substrate as kind='plan_template'.
"""
from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import time
from typing import Any, Awaitable, Callable, Optional

import httpx

# Lazy imports for pyautogui + PIL so the daemon module loads even when
# the local environment can't import them (CI / headless). The agent
# endpoint guards on these being available at request time.
try:
    import pyautogui   # type: ignore
    _PYAUTOGUI_OK = True
except Exception as _e:
    pyautogui = None   # type: ignore
    _PYAUTOGUI_OK = False
    _PYAUTOGUI_ERR = str(_e)

try:
    from PIL import Image   # type: ignore
    _PIL_OK = True
except Exception as _e:
    Image = None   # type: ignore
    _PIL_OK = False
    _PIL_ERR = str(_e)


NERUVA_BASE_URL = os.environ.get("NERUVA_URL", "https://api.neruva.io")

# Some action models emit coords normalized to [0, 1000]; we convert
# to absolute pixels using the captured (screen_w, screen_h). Set
# NERUVA_HOLO_NORMALIZED=1 to enable; default is pass-through (most
# models emit absolute pixels matching the screenshot dims).
_NORM_BASIS = 1000

# Default safety guards on the action loop.
_DEFAULT_MAX_STEPS = 20
_DEFAULT_INTER_STEP_SLEEP_S = 0.3
_DEFAULT_STEP_TIMEOUT_S = 60.0
_DEFAULT_SUBSTRATE_TIMEOUT_S = 10.0
_CACHE_SCORE_THRESHOLD = 0.85
_CACHE_SUCCESS_RATE_THRESHOLD = 0.8


def _require_executor() -> Optional[str]:
    """Return None if pyautogui+PIL are importable; else a human error."""
    if not _PYAUTOGUI_OK:
        return f"pyautogui not installed: {_PYAUTOGUI_ERR}"
    if not _PIL_OK:
        return f"Pillow not installed: {_PIL_ERR}"
    return None


def grab_screenshot() -> tuple[bytes, int, int]:
    """Capture the current screen as PNG bytes + (width, height)."""
    img = pyautogui.screenshot()
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue(), int(img.width), int(img.height)


def pick_action(
    task_text: str,
    png_bytes: bytes,
    history: list[dict],
    *,
    timeout: float = _DEFAULT_STEP_TIMEOUT_S,
    neruva_api_key: Optional[str] = None,
) -> dict:
    """Ask the Neruva Computer action model for ONE next action via
    the substrate proxy. Daemon needs only NERUVA_API_KEY; vendor key
    + identity stay server-side.

    Returns the parsed JSON action dict. Raises on transport failure
    -- caller decides whether to abort the task."""
    api_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError(
            "NERUVA_API_KEY not configured. Get one at "
            "https://app.neruva.io and put it in ~/.config/neruva/.env."
        )
    b64 = base64.b64encode(png_bytes).decode()
    with httpx.Client(timeout=timeout) as cli:
        r = cli.post(
            f"{NERUVA_BASE_URL}/v1/agent/computer/step",
            headers={"Api-Key": api_key, "Content-Type": "application/json"},
            json={
                "task_text": task_text,
                "history": history[-6:] if history else [],
                "screenshot_b64": b64,
            },
        )
    r.raise_for_status()
    return r.json().get("action") or {}


# Back-compat alias for internal callers; will be removed in 0.5.0.
holo3_pick_action = pick_action  # noqa: F401


def _parse_action_lenient(body: str) -> dict:
    """Parse an action response, repairing common malformed shapes.
    Server-side parsing usually handles this, but keep a fallback for
    direct/legacy paths. Some models truncate mid-string, wrap in
    ``` fences, or emit text before the JSON object."""
    s = body.strip()
    # Strip code fences.
    if s.startswith("```"):
        s = s.lstrip("`")
        if s.startswith("json"):
            s = s[4:]
        s = s.strip()
    if s.endswith("```"):
        s = s[:-3].strip()
    # Try as-is.
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        pass
    # Extract first {...} object.
    import re as _re
    m = _re.search(r"\{[\s\S]*?\}", s)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    # Truncated mid-string: try repairing by closing quote + brace.
    if s.count('"') % 2 == 1:
        try:
            return json.loads(s + '"}')
        except json.JSONDecodeError:
            pass
    # Give up; treat as 'done' so the agent doesn't loop forever.
    return {"action": "done", "reasoning": f"parse failed: {s[:120]}"}


def _pick(action: dict, key: str, default=None):
    """Forgiving param lookup: model may emit args at top level (action.x)
    OR nested under args (action.args.x). Look in both places."""
    if key in action:
        return action[key]
    args = action.get("args") or {}
    return args.get(key, default)


def _maybe_normalize_coord(v: int, screen_dim: int) -> int:
    """The Neruva Computer action model emits absolute pixel coords
    matching the screenshot dimensions. We trust the model output as-is
    by default. Set NERUVA_NORM_COORDS=1 to convert from [0, 1000]
    normalized space instead."""
    if os.environ.get("NERUVA_NORM_COORDS") == "1":
        if 0 <= v <= _NORM_BASIS:
            return int(v / _NORM_BASIS * screen_dim)
    return int(v)


def execute_action(action: dict, screen_w: int, screen_h: int) -> dict:
    """Run one action via pyautogui. Returns {ok, ...} or {ok: False, error}.

    Tolerant of two shapes: {action: 'click', x:..., y:...} OR
    {action: 'click', args: {x:..., y:...}}. Some models emit the flat form;
    Anthropic Computer Use emits the nested form. Both work.
    """
    a = str(action.get("action", "")).lower()
    try:
        if a == "click":
            x_raw = int(_pick(action, "x", 0))
            y_raw = int(_pick(action, "y", 0))
            x = _maybe_normalize_coord(x_raw, screen_w)
            y = _maybe_normalize_coord(y_raw, screen_h)
            # Clamp into the visible screen with a 2px safety margin from
            # the edges (pyautogui FAILSAFE triggers on exact corners).
            # Refuse degenerate clicks at (0,0) -- the model probably
            # had nothing to click and we'd just hit the failsafe.
            x = max(2, min(x, screen_w - 2))
            y = max(2, min(y, screen_h - 2))
            if x_raw <= 0 and y_raw <= 0:
                return {"ok": False,
                        "error": "click target (0,0) -- model emitted no coords. Try keyboard win/enter/etc. instead."}
            try:
                pyautogui.click(x, y)
            except Exception as e:
                return {"ok": False,
                        "error": f"pyautogui.click({x},{y}) failed: {type(e).__name__}: {e}"}
            return {"ok": True, "px": [x, y]}
        if a == "type":
            text = str(_pick(action, "text", ""))
            # Clipboard paste is ~10x more reliable than typewrite() on
            # Windows: handles unicode + special chars, doesn't race with
            # newly-focused windows that miss the first few keystrokes.
            # Fall back to typewrite() if pyperclip is unavailable.
            try:
                import pyperclip   # type: ignore
                pyperclip.copy(text)
                pyautogui.hotkey("ctrl", "v")
                return {"ok": True, "typed_n": len(text), "via": "paste"}
            except Exception:
                pyautogui.typewrite(text, interval=0.02)
                return {"ok": True, "typed_n": len(text), "via": "typewrite"}
        if a == "key":
            keys = _pick(action, "keys", _pick(action, "key", ""))
            if isinstance(keys, list):
                pyautogui.hotkey(*[str(k).lower() for k in keys])
            else:
                pyautogui.press(str(keys).lower())
            return {"ok": True, "key": keys}
        if a == "scroll":
            amt = int(_pick(action, "amount", _pick(action, "amt", 0)))
            pyautogui.scroll(amt)
            return {"ok": True, "scrolled": amt}
        if a == "wait":
            ms = int(_pick(action, "ms", _pick(action, "duration_ms", 500)))
            time.sleep(ms / 1000.0)
            return {"ok": True, "waited_ms": ms}
        if a == "done":
            return {"ok": True, "done": True}
        if a == "say":
            text = str(_pick(action, "text", ""))
            return {"ok": True, "said": text}
        return {"ok": False, "error": f"unknown action: {a!r}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _substrate_post_retry(
    url: str, body: dict, api_key: str,
    *, max_attempts: int = 5, base_delay_s: float = 0.5,
    timeout: float = _DEFAULT_SUBSTRATE_TIMEOUT_S,
) -> Optional[httpx.Response]:
    """POST to substrate with exponential backoff on 429s.
    Returns the final Response (success or last failure) or None on
    transport failure across all attempts."""
    delay = base_delay_s
    last_r: Optional[httpx.Response] = None
    for attempt in range(max_attempts):
        try:
            with httpx.Client(timeout=timeout) as cli:
                r = cli.post(
                    url,
                    headers={"Api-Key": api_key,
                             "Content-Type": "application/json"},
                    json=body,
                )
            last_r = r
            if r.status_code != 429:
                return r
        except Exception:
            pass
        # 429 or transport error -- wait and retry.
        time.sleep(delay)
        delay = min(delay * 2, 8.0)
    return last_r


async def _emit(on_step: Optional[Callable[[dict], Awaitable[None]]],
                event: dict) -> None:
    if on_step is None:
        return
    try:
        await on_step(event)
    except Exception:
        pass   # never let UI emit break the loop


async def run_task(
    task_text,
    namespace: str = "cockpit_agent",
    *,
    neruva_api_key: Optional[str] = None,
    max_steps: int = _DEFAULT_MAX_STEPS,
    on_step: Optional[Callable[[dict], Awaitable[None]]] = None,
    use_cache: bool = True,
) -> dict:
    """Run a single Neruva Computer task end-to-end.

    `task_text` accepts either a string (static task) OR a zero-arg
    callable returning a string (dynamic task, re-read on every turn).
    The callable form is how chat-steering works: the SessionManager
    appends pending user directives to the task text on each call so
    they reach the next action-model prompt.

    Returns {ok, n_steps, duration_ms, used_cache, history, plan,
    cost_estimate_usd, model_calls}.
    """
    err = _require_executor()
    if err:
        return {"ok": False, "error": err, "n_steps": 0}

    # Normalize to callable.
    if callable(task_text):
        get_task = task_text
        initial_task_str = task_text()
    else:
        initial_task_str = str(task_text)
        get_task = lambda: initial_task_str   # noqa: E731

    nv_key = neruva_api_key or os.environ.get("NERUVA_API_KEY", "")
    t0 = time.perf_counter()
    plan_used_from_cache = False
    plan: list[dict] = []
    history: list[dict] = []
    success = False
    model_calls = 0

    # 1. Plan-cache lookup -- uses the initial task text only (mid-flight
    # directives don't change what we look up; they steer the live loop).
    if use_cache and nv_key:
        try:
            r = _substrate_post_retry(
                f"{NERUVA_BASE_URL}/v1/agent/plan_cache_lookup",
                {"namespace": namespace, "task_text": initial_task_str,
                 "top_k": 1, "min_score": _CACHE_SCORE_THRESHOLD},
                nv_key,
            )
            if r is not None and r.status_code == 200:
                hits = r.json().get("hits", [])
                if hits and hits[0]["success_rate"] >= _CACHE_SUCCESS_RATE_THRESHOLD:
                    plan = hits[0]["plan"]
                    plan_used_from_cache = True
                    await _emit(on_step, {
                        "event": "plan_cache_hit",
                        "n_steps": len(plan),
                        "score": hits[0]["score"],
                        "record_id": hits[0]["record_id"],
                    })
        except Exception:
            pass

    # 2. Execute (cached or live-derived)
    if plan_used_from_cache:
        _, sw, sh = grab_screenshot()
        for i, step in enumerate(plan):
            await _emit(on_step, {
                "event": "step_start", "i": i, "step": step, "source": "cache",
            })
            res = execute_action(step, sw, sh)
            history.append({"step": step, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)
        success = all(h["result"].get("ok") for h in history)
    else:
        for i in range(max_steps):
            png, sw, sh = grab_screenshot()
            await _emit(on_step, {
                "event": "screenshot", "i": i, "screen_wh": [sw, sh],
            })
            # Re-read task on every turn so chat-steering directives land.
            current_task = get_task()
            try:
                action = pick_action(current_task, png, history,
                                     neruva_api_key=nv_key)
                model_calls += 1
            except Exception as e:
                await _emit(on_step, {
                    "event": "model_error", "i": i,
                    "error": f"{type(e).__name__}: {e}",
                })
                break
            await _emit(on_step, {
                "event": "action", "i": i, "action": action,
                "source": "neruva-computer",
            })
            if str(action.get("action", "")).lower() == "done":
                success = True
                break
            res = execute_action(action, sw, sh)
            plan.append(action)
            history.append({"step": action, "result": res})
            await _emit(on_step, {
                "event": "step_done", "i": i, "result": res,
            })
            if not res.get("ok"):
                break
            await asyncio.sleep(_DEFAULT_INTER_STEP_SLEEP_S)

    duration_ms = int((time.perf_counter() - t0) * 1000)

    # 3. Save plan -- only if live-derived (cache hits would dupe records).
    # Retry-with-backoff guards against Cloud Run edge 429s from bursty
    # neighbor traffic. We index by the INITIAL task text so subsequent
    # runs of the same task (with no directives) hit the cache.
    saved = False
    if not plan_used_from_cache and nv_key and plan:
        r = _substrate_post_retry(
            f"{NERUVA_BASE_URL}/v1/agent/plan_cache_save",
            {"namespace": namespace, "task_text": initial_task_str,
             "plan": plan, "success": success, "duration_ms": duration_ms},
            nv_key,
        )
        saved = (r is not None and r.status_code == 200)

    final = {
        "ok": success,
        "n_steps": len(plan),
        "duration_ms": duration_ms,
        "used_cache": plan_used_from_cache,
        "model_calls": model_calls,
        "plan_saved_to_substrate": saved if not plan_used_from_cache else False,
        "history": history,
        "plan": plan,
    }
    await _emit(on_step, {"event": "task_complete", **final})
    return final
