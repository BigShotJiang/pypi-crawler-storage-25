import os

class DzongkhaTokenizer:
    def __init__(self):
        """
        Initializes the tokenizer with two options:
        1. AI-based subword tokenization (using the 32K unigram model)
        2. Rule-based Tseg tokenization
        """
        # Set the path to your 32K model
        self.model_path = os.path.join(
            os.path.dirname(__file__), "models", "dzo_unigram_32000.model"
        )
        self.sp = None

        # Attempt to load SentencePiece
        try:
            import sentencepiece as spm
            if os.path.exists(self.model_path):
                self.sp = spm.SentencePieceProcessor(model_file=self.model_path)
            else:
                print(f"Warning: Model file not found at {self.model_path}")
        except ImportError:
            print("Warning: 'sentencepiece' library not installed. subword_split() will not work.")

    def tseg_split(self, text):
        """
        METHOD 1: Traditional Tseg-based Tokenization.
        Splits text by the Dzongkha tseg (་).
        This is useful for traditional linguistic analysis.
        """
        if not text:
            return []
        # Split by tseg and filter out empty strings, keeping the tseg with the syllable
        return [syllable + "་" for syllable in text.strip().split("་") if syllable.strip()]

    def subword_split(self, text):
        """
        METHOD 2: 32K Vocab Subword Tokenization.
        Uses the SentencePiece unigram model trained on 32,000 tokens.
        This provides the best 'fertility' score for ML tasks.
        """
        if self.sp:
            return self.sp.encode_as_pieces(text)
        return "Error: SentencePiece model (dzo_unigram_32000.model) missing or library not installed."