# dargslan-toolkit

**The Complete Linux Sysadmin Toolkit** — 93 CLI tools for Linux server management in a single install. System monitoring, security auditing, network analysis, storage management, and DevOps operations.

[![PyPI version](https://img.shields.io/pypi/v/dargslan-toolkit)](https://pypi.org/project/dargslan-toolkit/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
pip install dargslan-toolkit
```

This single command installs all 93 Dargslan CLI tools covering every aspect of Linux administration.

## Tool Categories

### System Monitoring (12 tools)
| Tool | Description |
|------|-------------|
| [dargslan-sysinfo](https://pypi.org/project/dargslan-sysinfo/) | CPU, memory, disk, network overview |
| [dargslan-process-monitor](https://pypi.org/project/dargslan-process-monitor/) | Process monitoring and top-like output |
| [dargslan-proc-monitor](https://pypi.org/project/dargslan-proc-monitor/) | Process resource monitor (top CPU/memory, load) |
| [dargslan-disk-cleaner](https://pypi.org/project/dargslan-disk-cleaner/) | Disk usage analysis and cleanup |
| [dargslan-uptime-report](https://pypi.org/project/dargslan-uptime-report/) | System uptime and load tracking |
| [dargslan-memory-profiler](https://pypi.org/project/dargslan-memory-profiler/) | Memory usage deep analysis |
| [dargslan-swap-analyzer](https://pypi.org/project/dargslan-swap-analyzer/) | Swap usage and pressure analysis |
| [dargslan-swap-manager](https://pypi.org/project/dargslan-swap-manager/) | Swap space and swappiness management |
| [dargslan-inode-monitor](https://pypi.org/project/dargslan-inode-monitor/) | Inode usage monitoring |
| [dargslan-mount-monitor](https://pypi.org/project/dargslan-mount-monitor/) | Mount point and filesystem monitoring |
| [dargslan-zombie-kill](https://pypi.org/project/dargslan-zombie-kill/) | Zombie process finder and killer |
| [dargslan-process-killer](https://pypi.org/project/dargslan-process-killer/) | Process management and killer |

### Security & Hardening (16 tools)
| Tool | Description |
|------|-------------|
| [dargslan-firewall-audit](https://pypi.org/project/dargslan-firewall-audit/) | iptables/nftables rule auditing |
| [dargslan-ssh-hardening](https://pypi.org/project/dargslan-ssh-hardening/) | SSH configuration security audit |
| [dargslan-ssh-audit](https://pypi.org/project/dargslan-ssh-audit/) | SSH server and key auditing |
| [dargslan-sudoers-audit](https://pypi.org/project/dargslan-sudoers-audit/) | Sudoers file security analysis |
| [dargslan-pam-audit](https://pypi.org/project/dargslan-pam-audit/) | PAM configuration auditing |
| [dargslan-sysctl-audit](https://pypi.org/project/dargslan-sysctl-audit/) | Kernel parameter security audit |
| [dargslan-env-audit](https://pypi.org/project/dargslan-env-audit/) | Environment variable security scan |
| [dargslan-file-integrity](https://pypi.org/project/dargslan-file-integrity/) | File integrity monitoring |
| [dargslan-audit-log](https://pypi.org/project/dargslan-audit-log/) | Auditd log analysis |
| [dargslan-login-history](https://pypi.org/project/dargslan-login-history/) | Login history and failed attempt tracking |
| [dargslan-login-tracker](https://pypi.org/project/dargslan-login-tracker/) | Login session tracking |
| [dargslan-lastlog-audit](https://pypi.org/project/dargslan-lastlog-audit/) | Last login audit and dormant accounts |
| [dargslan-security-scan](https://pypi.org/project/dargslan-security-scan/) | General security scanning |
| [dargslan-selinux-check](https://pypi.org/project/dargslan-selinux-check/) | SELinux status and policy check |
| [dargslan-passwd-audit](https://pypi.org/project/dargslan-passwd-audit/) | Password policy and shadow file auditor |
| [dargslan-user-audit](https://pypi.org/project/dargslan-user-audit/) | User account auditing |

### Networking (14 tools)
| Tool | Description |
|------|-------------|
| [dargslan-net-scanner](https://pypi.org/project/dargslan-net-scanner/) | Network scanning and port probing |
| [dargslan-port-monitor](https://pypi.org/project/dargslan-port-monitor/) | Listening port monitoring |
| [dargslan-dns-check](https://pypi.org/project/dargslan-dns-check/) | DNS record verification |
| [dargslan-dns-resolver](https://pypi.org/project/dargslan-dns-resolver/) | DNS resolver analysis |
| [dargslan-bandwidth-monitor](https://pypi.org/project/dargslan-bandwidth-monitor/) | Network bandwidth monitoring |
| [dargslan-interface-monitor](https://pypi.org/project/dargslan-interface-monitor/) | Network interface status |
| [dargslan-resolv-check](https://pypi.org/project/dargslan-resolv-check/) | DNS resolver configuration check |
| [dargslan-ssl-checker](https://pypi.org/project/dargslan-ssl-checker/) | SSL certificate validation |
| [dargslan-ip-geo](https://pypi.org/project/dargslan-ip-geo/) | IP geolocation lookup |
| [dargslan-tcp-monitor](https://pypi.org/project/dargslan-tcp-monitor/) | TCP connection monitoring |
| [dargslan-socket-stats](https://pypi.org/project/dargslan-socket-stats/) | Socket statistics analysis |
| [dargslan-network-latency](https://pypi.org/project/dargslan-network-latency/) | Network latency testing |
| [dargslan-route-check](https://pypi.org/project/dargslan-route-check/) | Routing table analyzer |
| [dargslan-hostname-check](https://pypi.org/project/dargslan-hostname-check/) | Hostname and DNS identity verifier |

### Log Analysis (7 tools)
| Tool | Description |
|------|-------------|
| [dargslan-log-parser](https://pypi.org/project/dargslan-log-parser/) | Multi-format log parser |
| [dargslan-journald-analyzer](https://pypi.org/project/dargslan-journald-analyzer/) | Systemd journal analysis |
| [dargslan-journal-export](https://pypi.org/project/dargslan-journal-export/) | Systemd journal log exporter |
| [dargslan-log-rotate](https://pypi.org/project/dargslan-log-rotate/) | Logrotate config validation |
| [dargslan-log-stats](https://pypi.org/project/dargslan-log-stats/) | Log statistics and summaries |
| [dargslan-dmesg-analyzer](https://pypi.org/project/dargslan-dmesg-analyzer/) | Kernel dmesg message analyzer |
| [dargslan-nginx-analyzer](https://pypi.org/project/dargslan-nginx-analyzer/) | Nginx log analysis |

### System Configuration (14 tools)
| Tool | Description |
|------|-------------|
| [dargslan-crontab-backup](https://pypi.org/project/dargslan-crontab-backup/) | Crontab backup and restore |
| [dargslan-cron-audit](https://pypi.org/project/dargslan-cron-audit/) | Cron job auditing |
| [dargslan-cron-parser](https://pypi.org/project/dargslan-cron-parser/) | Cron expression parser |
| [dargslan-systemd-timer](https://pypi.org/project/dargslan-systemd-timer/) | Systemd timer analysis |
| [dargslan-systemd-analyze](https://pypi.org/project/dargslan-systemd-analyze/) | Systemd boot analysis |
| [dargslan-systemd-unit](https://pypi.org/project/dargslan-systemd-unit/) | Systemd unit management |
| [dargslan-grub-check](https://pypi.org/project/dargslan-grub-check/) | GRUB bootloader validation |
| [dargslan-fstab-check](https://pypi.org/project/dargslan-fstab-check/) | Fstab syntax validation |
| [dargslan-locale-check](https://pypi.org/project/dargslan-locale-check/) | Locale and encoding checker |
| [dargslan-timezone-info](https://pypi.org/project/dargslan-timezone-info/) | Timezone and NTP info |
| [dargslan-ulimit-check](https://pypi.org/project/dargslan-ulimit-check/) | Resource limits checker |
| [dargslan-kernel-module](https://pypi.org/project/dargslan-kernel-module/) | Kernel module management |
| [dargslan-kernel-check](https://pypi.org/project/dargslan-kernel-check/) | Kernel version and config checker |
| [dargslan-motd-manager](https://pypi.org/project/dargslan-motd-manager/) | MOTD and login banner management |

### Storage & Filesystems (9 tools)
| Tool | Description |
|------|-------------|
| [dargslan-disk-benchmark](https://pypi.org/project/dargslan-disk-benchmark/) | Disk I/O benchmarking |
| [dargslan-disk-quota](https://pypi.org/project/dargslan-disk-quota/) | Disk quota management |
| [dargslan-disk-health](https://pypi.org/project/dargslan-disk-health/) | Disk health and SMART monitoring |
| [dargslan-lvm-check](https://pypi.org/project/dargslan-lvm-check/) | LVM volume group checker |
| [dargslan-raid-monitor](https://pypi.org/project/dargslan-raid-monitor/) | RAID array monitoring |
| [dargslan-nfs-health](https://pypi.org/project/dargslan-nfs-health/) | NFS share health checker |
| [dargslan-backup-monitor](https://pypi.org/project/dargslan-backup-monitor/) | Backup file monitoring |
| [dargslan-tmpfile-cleaner](https://pypi.org/project/dargslan-tmpfile-cleaner/) | Temp file cleaner |
| [dargslan-tmpfile-clean](https://pypi.org/project/dargslan-tmpfile-clean/) | Temporary file analyzer and cleanup |

### Firewall & Network Security (3 tools)
| Tool | Description |
|------|-------------|
| [dargslan-iptables-export](https://pypi.org/project/dargslan-iptables-export/) | iptables rule exporter |
| [dargslan-netfilter-check](https://pypi.org/project/dargslan-netfilter-check/) | Netfilter conntrack analyzer |
| [dargslan-cert-manager](https://pypi.org/project/dargslan-cert-manager/) | SSL certificate management |

### DevOps & Containers (5 tools)
| Tool | Description |
|------|-------------|
| [dargslan-docker-health](https://pypi.org/project/dargslan-docker-health/) | Docker container health monitoring |
| [dargslan-container-audit](https://pypi.org/project/dargslan-container-audit/) | Container security auditing |
| [dargslan-cgroup-monitor](https://pypi.org/project/dargslan-cgroup-monitor/) | Cgroup resource monitoring |
| [dargslan-cgroup-audit](https://pypi.org/project/dargslan-cgroup-audit/) | Cgroup v2 resource limit auditor |
| [dargslan-git-audit](https://pypi.org/project/dargslan-git-audit/) | Git repository auditing |

### Database Health (3 tools)
| Tool | Description |
|------|-------------|
| [dargslan-mysql-health](https://pypi.org/project/dargslan-mysql-health/) | MySQL health monitoring |
| [dargslan-postgres-health](https://pypi.org/project/dargslan-postgres-health/) | PostgreSQL health monitoring |
| [dargslan-redis-health](https://pypi.org/project/dargslan-redis-health/) | Redis health monitoring |

### Package & Service Management (7 tools)
| Tool | Description |
|------|-------------|
| [dargslan-apt-history](https://pypi.org/project/dargslan-apt-history/) | APT package install history |
| [dargslan-apt-check](https://pypi.org/project/dargslan-apt-check/) | APT package health checker |
| [dargslan-package-audit](https://pypi.org/project/dargslan-package-audit/) | Package security auditing |
| [dargslan-service-monitor](https://pypi.org/project/dargslan-service-monitor/) | Systemd service monitoring |
| [dargslan-service-restart](https://pypi.org/project/dargslan-service-restart/) | Service restart monitor |
| [dargslan-ntp-check](https://pypi.org/project/dargslan-ntp-check/) | NTP time synchronization check |
| [dargslan-apache-analyzer](https://pypi.org/project/dargslan-apache-analyzer/) | Apache log and config analysis |

### User & Session Management (3 tools)
| Tool | Description |
|------|-------------|
| [dargslan-user-sessions](https://pypi.org/project/dargslan-user-sessions/) | Active user session monitoring |
| [dargslan-hostname-info](https://pypi.org/project/dargslan-hostname-info/) | Hostname information utility |
| [dargslan-bash-alias](https://pypi.org/project/dargslan-bash-alias/) | Bash alias manager and analyzer |

## Quick Start

```bash
pip install dargslan-toolkit

dargslan-sysinfo          # System overview
dargslan-fwaudit          # Firewall audit
dargslan-sshd report      # SSH security check
dargslan-logins           # Login history
dargslan-sysctl report    # Kernel parameter audit
dargslan-mounts           # Mount point status
```

## Why dargslan-toolkit?

- **93 tools, 1 install** — Everything a Linux sysadmin needs
- **Zero external dependencies** — Only Python standard library
- **CLI ready** — Every tool works from the terminal immediately
- **Lightweight** — Minimal footprint, fast execution
- **Production tested** — Used on real Linux servers

## More Resources

- [Linux & DevOps eBooks](https://dargslan.com/books) — 210+ professional eBooks for sysadmins
- [Free Cheat Sheets](https://dargslan.com/cheat-sheets) — 360+ downloadable PDF references
- [Blog & Tutorials](https://dargslan.com/blog) — 400+ in-depth Linux and DevOps guides
- [Free Tools](https://dargslan.com/tools) — Linux Distro Finder, IT Career Path Calculator

## License

MIT License — see [LICENSE](LICENSE) for details.

---

**Made with care by [Dargslan](https://dargslan.com)** — Your source for Linux & DevOps knowledge.

[Website](https://dargslan.com) | [eBooks](https://dargslan.com/books) | [Cheat Sheets](https://dargslan.com/cheat-sheets) | [Blog](https://dargslan.com/blog)
