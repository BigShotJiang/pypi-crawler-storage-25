"""
Simulated Claude Code session generator for end-to-end smoke testing.

Produces a realistic sequence of Claude Code hook events and runs them
through the real aggregator + sdk_bridge path — without needing Claude
Code to be installed. Requires valid Infinium credentials (run
`infinium-claude init` first).

Invoked via `infinium-claude simulate` (hidden — internal maintainer use).
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from .aggregator import SessionAggregator
from .config import ConnectorConfig
from .sdk_bridge import send_trace
from .types import InfiniumTracePayload

logger = logging.getLogger(__name__)


@dataclass
class SimulationResult:
    """Outcome of a simulated session."""

    session_id: str
    event_count: int
    trace_id: str
    payload: InfiniumTracePayload


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _generate_session(
    prompt: str = "Fix the failing npm test",
    command: str = "npm test",
    response: str = "All tests passed after fixing the import order.",
    start: Optional[datetime] = None,
    include_v21_events: bool = True,
) -> List[Dict[str, Any]]:
    """Build a realistic Claude Code session covering the core lifecycle.

    When ``include_v21_events`` is True (default) the sequence also exercises
    the v2.1.x event types (TaskCreated, FileChanged, Elicitation /
    ElicitationResult, PermissionDenied, CwdChanged) so the simulated trace
    looks like a modern Claude Code run.
    """
    start = start or datetime.now(timezone.utc)
    sid = f"claude-sim-{uuid.uuid4().hex[:8]}"
    tid = f"turn-{uuid.uuid4().hex[:6]}"
    tool_use = f"use-{uuid.uuid4().hex[:6]}"
    elic_id = f"elic-{uuid.uuid4().hex[:6]}"
    task_id = f"task-{uuid.uuid4().hex[:6]}"

    t = lambda secs: _iso(start + timedelta(seconds=secs))  # noqa: E731

    events: List[Dict[str, Any]] = [
        {
            "hook_event_name": "SessionStart",
            "session_id": sid,
            "timestamp": t(0),
            "cwd": ".",
            "source": "startup",
            "model": "claude-sonnet-4-6",
            "permission_mode": "workspace-write",
        },
        {
            "hook_event_name": "UserPromptSubmit",
            "session_id": sid,
            "timestamp": t(1),
            "prompt": prompt,
        },
    ]

    if include_v21_events:
        events.append({
            "hook_event_name": "TaskCreated",
            "session_id": sid,
            "timestamp": t(2),
            "task_id": task_id,
            "task_description": "Investigate and fix the failing test",
            "task_status": "in_progress",
        })

    events.extend([
        {
            "hook_event_name": "PreToolUse",
            "session_id": sid,
            "timestamp": t(3),
            "tool_name": "Bash",
            "tool_use_id": tool_use,
            "tool_input": {"command": command},
        },
        {
            "hook_event_name": "PostToolUse",
            "session_id": sid,
            "timestamp": t(6),
            "tool_name": "Bash",
            "tool_use_id": tool_use,
            "tool_input": {"command": command},
            "tool_response": "All 42 tests passed",
        },
    ])

    if include_v21_events:
        events.extend([
            {
                "hook_event_name": "FileChanged",
                "session_id": sid,
                "timestamp": t(7),
                "file_path": "src/login.py",
                "change_type": "modified",
            },
            {
                "hook_event_name": "Elicitation",
                "session_id": sid,
                "timestamp": t(8),
                "elicitation_id": elic_id,
                "elicitation_type": "confirm",
                "elicitation_message": "Commit these changes?",
            },
            {
                "hook_event_name": "ElicitationResult",
                "session_id": sid,
                "timestamp": t(9),
                "elicitation_id": elic_id,
                "elicitation_response": "yes",
                "elicitation_accepted": True,
            },
            {
                "hook_event_name": "PermissionDenied",
                "session_id": sid,
                "timestamp": t(10),
                "tool_name": "Bash",
                "tool_use_id": f"use-{uuid.uuid4().hex[:6]}",
                "denial_reason": "User denied a command requiring elevated permissions",
            },
            {
                "hook_event_name": "CwdChanged",
                "session_id": sid,
                "timestamp": t(11),
                "old_cwd": ".",
                "new_cwd": "./src",
            },
        ])

    events.extend([
        {
            "hook_event_name": "Stop",
            "session_id": sid,
            "timestamp": t(12),
            "last_assistant_message": response,
        },
        {
            "hook_event_name": "SessionEnd",
            "session_id": sid,
            "timestamp": t(13),
        },
    ])

    return events


def run_simulation(
    config: ConnectorConfig,
    prompt: str = "Fix the failing npm test",
    command: str = "npm test",
    response: str = "All tests passed after fixing the import order.",
    dry_run: bool = False,
    include_v21_events: bool = True,
) -> SimulationResult:
    """Run one simulated Claude Code session end-to-end.

    If ``dry_run`` is True, build the payload but skip the API call — useful
    for verifying the pipeline without polluting the Infinium dashboard.
    """
    config.validate()

    events = _generate_session(
        prompt=prompt,
        command=command,
        response=response,
        include_v21_events=include_v21_events,
    )
    session_id = events[0]["session_id"]

    aggregator = SessionAggregator(config)
    payload = aggregator.replay_events(events)
    if payload is None:
        raise RuntimeError("Simulated session produced no trace payload")

    if payload.environment is None:
        payload.environment = {}
    tags = dict(payload.environment.get("custom_tags") or {})
    tags["simulated"] = "true"
    payload.environment["custom_tags"] = tags

    trace_id = "dry-run"
    if not dry_run:
        result = send_trace(config, payload)
        trace_id = result.get("traceId") or result.get("id") or "unknown"

    return SimulationResult(
        session_id=session_id,
        event_count=len(events),
        trace_id=str(trace_id),
        payload=payload,
    )
