"""
Session aggregator — collects Claude Code hook events and builds Infinium trace payloads.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from . import __version__
from .config import ConnectorConfig
from .sdk_bridge import sanitize_str as _sanitize_str
from .types import (
    HookEvent,
    InfiniumTracePayload,
    PromptTurn,
    SessionData,
    SubagentRecord,
    ToolUseRecord,
)

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _truncate(text: Optional[str], limit: int) -> Optional[str]:
    if text is None:
        return None
    # Coerce non-strings (structured tool responses) to a compact string
    if not isinstance(text, str):
        try:
            text = json.dumps(text, default=str, separators=(",", ":"))
        except (TypeError, ValueError, UnicodeEncodeError):
            text = str(text)
    # Strip lone surrogates that Claude Code occasionally sends
    text = _sanitize_str(text)
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def _summarize_tool_input(tool_name: str, tool_input: Any, limit: int) -> Optional[str]:
    """Extract a human-readable summary from structured tool input."""
    if not tool_input or not isinstance(tool_input, dict):
        return _truncate(tool_input, limit) if tool_input else None

    ti = tool_input
    summary = None

    if tool_name == "Edit":
        fp = _short_path(ti.get("file_path", ""))
        old = ti.get("old_string", "")
        new = ti.get("new_string", "")
        old_preview = _truncate(old, 40) or ""
        new_preview = _truncate(new, 40) or ""
        summary = f"{fp}: {old_preview} → {new_preview}"
    elif tool_name == "Read":
        fp = _short_path(ti.get("file_path", ""))
        parts = [fp]
        if ti.get("offset"):
            parts.append(f"lines {ti['offset']}-{ti['offset'] + ti.get('limit', 2000)}")
        summary = " ".join(parts)
    elif tool_name == "Write":
        fp = _short_path(ti.get("file_path", ""))
        summary = fp
    elif tool_name == "Grep":
        pattern = ti.get("pattern", "")
        path = _short_path(ti.get("path", ""))
        summary = f'"{pattern}" in {path}' if path else f'"{pattern}"'
    elif tool_name == "Glob":
        pattern = ti.get("pattern", "")
        path = _short_path(ti.get("path", ""))
        summary = f'{pattern} in {path}' if path else pattern
    elif tool_name == "Bash":
        summary = ti.get("command", "")
    elif tool_name == "Agent":
        summary = ti.get("description") or ti.get("prompt", "")

    if summary:
        return _truncate(summary, limit)
    # Fallback: compact JSON
    try:
        return _truncate(json.dumps(ti, default=str, separators=(",", ":")), limit)
    except (TypeError, ValueError):
        return _truncate(str(ti), limit)


def _summarize_tool_output(tool_name: str, tool_response: Any, limit: int) -> Optional[str]:
    """Extract a human-readable summary from structured tool output."""
    if tool_response is None:
        return None
    if isinstance(tool_response, str):
        return _truncate(tool_response, limit)
    if not isinstance(tool_response, dict):
        return _truncate(tool_response, limit)

    tr = tool_response

    if tool_name == "Edit":
        fp = _short_path(tr.get("filePath", ""))
        return f"Edited {fp}" if fp else "Edit applied"
    elif tool_name == "Read":
        # Extract just a content preview, not the full file
        file_data = tr.get("file", {})
        content = file_data.get("content") if isinstance(file_data, dict) else None
        if content:
            fp = _short_path(file_data.get("filePath", ""))
            return _truncate(f"{fp}: {content}", limit)
        return _truncate(str(tr.get("type", "read")), limit)
    elif tool_name == "Write":
        fp = _short_path(tr.get("filePath", tr.get("file_path", "")))
        return f"Wrote {fp}" if fp else "File written"
    elif tool_name == "Grep":
        mode = tr.get("mode", "")
        num_files = tr.get("numFiles", 0)
        filenames = tr.get("filenames", [])
        content = tr.get("content", "")
        if filenames:
            files_str = ", ".join(_short_path(f) for f in filenames[:3])
            if len(filenames) > 3:
                files_str += f" +{len(filenames) - 3} more"
            return _truncate(f"{num_files} files: {files_str}", limit)
        if content:
            return _truncate(content, limit)
        return f"{num_files} files matched"
    elif tool_name == "Glob":
        if isinstance(tr, dict) and tr.get("filenames"):
            return _truncate(", ".join(_short_path(f) for f in tr["filenames"][:5]), limit)
    elif tool_name == "Bash":
        output = tr.get("output") or tr.get("stdout", "")
        if output:
            return _truncate(output, limit)
        return "Command completed"

    # Fallback: compact JSON without noisy fields
    cleaned = {k: v for k, v in tr.items() if k not in ("originalFile", "content", "file")}
    try:
        return _truncate(json.dumps(cleaned, default=str, separators=(",", ":")), limit)
    except (TypeError, ValueError):
        return _truncate(str(tr), limit)


def _short_path(path: str) -> str:
    """Shorten a file path to just filename or last 2 components."""
    if not path:
        return ""
    from pathlib import PurePosixPath, PureWindowsPath
    try:
        p = PureWindowsPath(path) if "\\" in path else PurePosixPath(path)
        parts = p.parts
        if len(parts) <= 2:
            return str(p)
        return str(PurePosixPath(*parts[-2:]))
    except Exception:
        return path


def _pick(payload: Dict[str, Any], *keys: str) -> Any:
    """Return the first present key from *keys* in the payload.

    Helps tolerate field-name variation across Claude Code versions
    (e.g. ``task_description`` vs ``description`` vs ``content``).
    """
    for k in keys:
        if k in payload:
            return payload[k]
    return None


def _parse_hook_event(payload: Dict[str, Any]) -> HookEvent:
    """Parse a raw Claude Code hook JSON payload into a HookEvent."""
    return HookEvent(
        event_name=payload.get("hook_event_name", "Unknown"),
        session_id=payload.get("session_id", "unknown"),
        timestamp=payload.get("timestamp", _now_iso()),
        cwd=payload.get("cwd"),
        permission_mode=payload.get("permission_mode"),
        agent_id=payload.get("agent_id"),
        agent_type=payload.get("agent_type"),
        tool_name=payload.get("tool_name"),
        tool_input=payload.get("tool_input"),
        tool_response=payload.get("tool_response"),
        tool_use_id=payload.get("tool_use_id"),
        prompt=payload.get("prompt"),
        last_assistant_message=payload.get("last_assistant_message"),
        error=payload.get("error"),
        is_interrupt=payload.get("is_interrupt"),
        source=payload.get("source"),
        model=payload.get("model"),
        message=payload.get("message"),
        notification_type=payload.get("notification_type"),
        agent_transcript_path=payload.get("agent_transcript_path"),
        # v2.1.x events — field names accept a couple of variants because the
        # exact upstream shape isn't stable across the 2.1.92-2.1.97 window.
        task_id=_pick(payload, "task_id", "todo_id", "id"),
        task_description=_pick(payload, "task_description", "description", "content"),
        task_status=_pick(payload, "task_status", "status"),
        old_cwd=_pick(payload, "old_cwd", "previous_cwd", "from_cwd"),
        new_cwd=_pick(payload, "new_cwd", "to_cwd"),
        file_path=_pick(payload, "file_path", "path"),
        change_type=_pick(payload, "change_type", "event_type", "action"),
        denial_reason=_pick(payload, "denial_reason", "reason", "permissionDecisionReason"),
        elicitation_id=_pick(payload, "elicitation_id", "id"),
        elicitation_message=_pick(payload, "elicitation_message", "message", "prompt"),
        elicitation_type=_pick(payload, "elicitation_type", "type", "kind"),
        elicitation_response=_pick(payload, "elicitation_response", "response", "value", "answer"),
        elicitation_accepted=_pick(payload, "elicitation_accepted", "accepted"),
        raw=payload,
    )


class SessionAggregator:
    """
    Collects hook events per session and produces Infinium trace payloads.

    Thread-safety: designed for single-threaded async usage (one uvicorn worker).
    """

    def __init__(self, config: ConnectorConfig) -> None:
        self.config = config
        self._sessions: Dict[str, SessionData] = {}
        self._session_timestamps: Dict[str, float] = {}  # monotonic clock

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ingest(self, raw_payload: Dict[str, Any]) -> Tuple[HookEvent, Optional[InfiniumTracePayload]]:
        """
        Ingest a single hook event.

        Returns the parsed event and, if the event triggers a flush,
        the trace payload ready to send to Infinium.
        """
        event = _parse_hook_event(raw_payload)
        session = self._get_or_create_session(event)
        self._apply_event(session, event)

        payload: Optional[InfiniumTracePayload] = None

        if event.event_name == "SessionEnd" and self.config.flush_on_session_end:
            payload = self._build_payload(session)
            self._remove_session(event.session_id)
        elif event.event_name == "Stop" and self.config.flush_on_stop:
            payload = self._build_payload(session)
            # Keep session alive — more turns may follow

        return event, payload

    def flush_session(self, session_id: str) -> Optional[InfiniumTracePayload]:
        """Force-flush a session and return the payload."""
        session = self._sessions.get(session_id)
        if session is None:
            return None
        payload = self._build_payload(session)
        self._remove_session(session_id)
        return payload

    def flush_all(self) -> List[InfiniumTracePayload]:
        """Flush all active sessions. Returns list of payloads."""
        payloads = []
        for sid in list(self._sessions.keys()):
            p = self.flush_session(sid)
            if p is not None:
                payloads.append(p)
        return payloads

    def evict_stale(self) -> List[str]:
        """Remove sessions older than session_ttl_seconds. Returns evicted IDs."""
        now = time.monotonic()
        cutoff = now - self.config.session_ttl_seconds
        stale = [
            sid for sid, ts in self._session_timestamps.items() if ts < cutoff
        ]
        for sid in stale:
            self._remove_session(sid)
        return stale

    def replay_events(
        self, events: List[Dict[str, Any]]
    ) -> Optional[InfiniumTracePayload]:
        """
        Feed a list of raw event dicts through ingest() and return the payload.

        Used by the command hook path to reconstruct session state from JSONL.
        """
        payload: Optional[InfiniumTracePayload] = None
        for ev in events:
            _, p = self.ingest(ev)
            if p is not None:
                payload = p

        # If no flush was triggered naturally, force-flush all sessions
        if payload is None:
            payloads = self.flush_all()
            payload = payloads[0] if payloads else None

        return payload

    @property
    def active_session_count(self) -> int:
        return len(self._sessions)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _get_or_create_session(self, event: HookEvent) -> SessionData:
        sid = event.session_id
        if sid not in self._sessions:
            self._sessions[sid] = SessionData(
                session_id=sid,
                started_at=event.timestamp,
                cwd=event.cwd,
                permission_mode=event.permission_mode,
            )
            self._session_timestamps[sid] = time.monotonic()
            logger.info("New session tracked: %s", sid[:12])
        else:
            # Refresh timestamp on activity
            self._session_timestamps[sid] = time.monotonic()
        return self._sessions[sid]

    def _remove_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)
        self._session_timestamps.pop(session_id, None)

    def _ensure_current_turn(self, session: SessionData) -> PromptTurn:
        if session._current_turn is None:
            turn = PromptTurn(started_at=_now_iso())
            session._current_turn = turn
            session.turns.append(turn)
        return session._current_turn

    def _apply_event(self, session: SessionData, event: HookEvent) -> None:
        handler = getattr(self, f"_handle_{event.event_name}", None)
        if handler is not None:
            handler(session, event)
        else:
            logger.debug("Unhandled event type: %s", event.event_name)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_SessionStart(self, session: SessionData, event: HookEvent) -> None:
        session.started_at = event.timestamp
        session.source = event.source
        session.model = event.model

    def _handle_SessionEnd(self, session: SessionData, event: HookEvent) -> None:
        session.ended_at = event.timestamp

    def _handle_UserPromptSubmit(self, session: SessionData, event: HookEvent) -> None:
        # Start a new turn
        turn = PromptTurn(
            prompt=_truncate(event.prompt, self.config.max_input_preview),
            started_at=event.timestamp,
        )
        session._current_turn = turn
        session.turns.append(turn)

    def _handle_PreToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_name = event.tool_name or "unknown"
        tool_use_id = event.tool_use_id or f"auto-{len(turn.tool_uses)}"

        input_summary = _summarize_tool_input(
            tool_name, event.tool_input, self.config.max_input_preview
        )

        record = ToolUseRecord(
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            input_summary=input_summary,
            started_at=event.timestamp,
        )
        session._pending_tools[tool_use_id] = record

    def _handle_PostToolUse(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_use_id = event.tool_use_id or ""

        record = session._pending_tools.pop(tool_use_id, None)
        if record is None:
            # PostToolUse without matching PreToolUse — create inline
            record = ToolUseRecord(
                tool_name=event.tool_name or "unknown",
                tool_use_id=tool_use_id,
            )

        record.output_summary = _summarize_tool_output(
            record.tool_name, event.tool_response, self.config.max_output_preview
        )
        record.completed_at = event.timestamp
        record.duration_ms = self._compute_duration_ms(
            record.started_at, record.completed_at
        )
        turn.tool_uses.append(record)
        session.total_tool_calls += 1

    def _handle_PostToolUseFailure(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        tool_use_id = event.tool_use_id or ""

        record = session._pending_tools.pop(tool_use_id, None)
        if record is None:
            record = ToolUseRecord(
                tool_name=event.tool_name or "unknown",
                tool_use_id=tool_use_id,
            )

        record.error = _truncate(event.error, self.config.max_output_preview)
        record.completed_at = event.timestamp
        record.duration_ms = self._compute_duration_ms(
            record.started_at, record.completed_at
        )
        turn.tool_uses.append(record)
        session.total_tool_calls += 1
        session.total_errors += 1

    def _handle_Stop(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        turn.response = _truncate(
            event.last_assistant_message, self.config.max_output_preview
        )
        turn.completed_at = event.timestamp
        # Close the current turn
        session._current_turn = None

    def _handle_SubagentStart(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        record = SubagentRecord(
            subagent_id=event.agent_id or "unknown",
            agent_type=event.agent_type,
            started_at=event.timestamp,
        )
        turn.subagents.append(record)
        session.total_subagents += 1

    def _handle_SubagentStop(self, session: SessionData, event: HookEvent) -> None:
        turn = self._ensure_current_turn(session)
        # Try to match existing subagent record
        matched = False
        for sub in turn.subagents:
            if sub.subagent_id == event.agent_id and sub.completed_at is None:
                sub.completed_at = event.timestamp
                sub.transcript_path = event.agent_transcript_path
                matched = True
                break
        if not matched:
            turn.subagents.append(
                SubagentRecord(
                    subagent_id=event.agent_id or "unknown",
                    agent_type=event.agent_type,
                    completed_at=event.timestamp,
                    transcript_path=event.agent_transcript_path,
                )
            )

    def _handle_Notification(self, session: SessionData, event: HookEvent) -> None:
        # Notifications are informational — no action needed for tracing
        pass

    def _handle_PreCompact(self, session: SessionData, event: HookEvent) -> None:
        pass

    def _handle_PostCompact(self, session: SessionData, event: HookEvent) -> None:
        pass

    # --- Claude Code v2.1.x event handlers ---

    def _handle_TaskCreated(self, session: SessionData, event: HookEvent) -> None:
        """A TodoWrite / task-plan entry was created."""
        session.tasks_created.append({
            "task_id": event.task_id or f"task-{len(session.tasks_created)}",
            "description": _truncate(event.task_description, self.config.max_input_preview),
            "status": event.task_status,
            "timestamp": event.timestamp,
        })

    def _handle_CwdChanged(self, session: SessionData, event: HookEvent) -> None:
        """Working directory changed mid-session (e.g. after `cd`)."""
        new_cwd = event.new_cwd or event.cwd
        old_cwd = event.old_cwd or session.cwd
        session.cwd_changes.append({
            "from": old_cwd,
            "to": new_cwd,
            "timestamp": event.timestamp,
        })
        # Keep session.cwd pointing at the latest directory
        if new_cwd:
            session.cwd = new_cwd

    def _handle_FileChanged(self, session: SessionData, event: HookEvent) -> None:
        """A watched file was created / modified / deleted."""
        if not event.file_path:
            return
        session.files_changed.append({
            "path": event.file_path,
            "change_type": event.change_type or "modified",
            "timestamp": event.timestamp,
        })

    def _handle_PermissionDenied(self, session: SessionData, event: HookEvent) -> None:
        """A tool call was blocked by a permission check.

        If we already recorded a PreToolUse for the same tool_use_id, pop the
        pending record so it doesn't linger waiting for a PostToolUse that
        will never arrive.
        """
        tool_name = event.tool_name or "unknown"
        reason = event.denial_reason or "Permission denied"

        if event.tool_use_id:
            session._pending_tools.pop(event.tool_use_id, None)

        session.permission_denials.append({
            "tool_name": tool_name,
            "reason": _truncate(reason, self.config.max_output_preview),
            "tool_use_id": event.tool_use_id,
            "timestamp": event.timestamp,
        })
        session.total_errors += 1

    def _handle_Elicitation(self, session: SessionData, event: HookEvent) -> None:
        """Claude Code asked the user for input (text / choice / confirm)."""
        eid = event.elicitation_id or f"elic-{len(session._pending_elicitations)}"
        session._pending_elicitations[eid] = {
            "id": eid,
            "type": event.elicitation_type,
            "message": _truncate(event.elicitation_message, self.config.max_input_preview),
            "started_at": event.timestamp,
            "response": None,
            "accepted": None,
            "completed_at": None,
        }

    def _handle_ElicitationResult(self, session: SessionData, event: HookEvent) -> None:
        """User answered (or dismissed) a previous Elicitation prompt."""
        eid = event.elicitation_id
        pending = session._pending_elicitations.pop(eid, None) if eid else None
        if pending is None:
            # ElicitationResult without matching Elicitation — record inline
            pending = {
                "id": eid or "unknown",
                "type": event.elicitation_type,
                "message": None,
                "started_at": None,
            }
        pending["response"] = _truncate(event.elicitation_response, self.config.max_output_preview)
        pending["accepted"] = event.elicitation_accepted
        pending["completed_at"] = event.timestamp

        # Stash the completed elicitation in the current turn for the payload
        # builder to find.
        turn = self._ensure_current_turn(session)
        elicitations = getattr(turn, "_elicitations", None)
        if elicitations is None:
            elicitations = []
            turn._elicitations = elicitations  # type: ignore[attr-defined]
        elicitations.append(pending)

    # ------------------------------------------------------------------
    # Payload building
    # ------------------------------------------------------------------

    def _build_payload(self, session: SessionData) -> InfiniumTracePayload:
        """Convert a SessionData into an Infinium-compatible trace payload."""
        now = _now_iso()
        duration = self._compute_session_duration(session)

        # Build execution steps from turns
        steps: List[Dict[str, Any]] = []
        step_num = 0
        all_errors: List[Dict[str, Any]] = []

        for turn_idx, turn in enumerate(session.turns):
            # Step for the prompt itself
            if turn.prompt:
                step_num += 1
                steps.append(
                    {
                        "step_number": step_num,
                        "action": "user_prompt",
                        "description": f"Turn {turn_idx + 1}: User prompt",
                        "input_preview": turn.prompt,
                        "output_preview": turn.response,
                    }
                )

            # Steps for each tool use
            for tool in turn.tool_uses:
                step_num += 1
                step: Dict[str, Any] = {
                    "step_number": step_num,
                    "action": "tool_use",
                    "description": f"Tool: {tool.tool_name}",
                    "duration_ms": tool.duration_ms,
                    "input_preview": tool.input_summary,
                    "output_preview": tool.output_summary,
                }
                if tool.error:
                    step["error"] = {
                        "error_type": "ToolError",
                        "message": tool.error,
                        "recoverable": True,
                    }
                    all_errors.append(step["error"])
                steps.append(step)

            # Steps for subagents
            for sub in turn.subagents:
                step_num += 1
                steps.append(
                    {
                        "step_number": step_num,
                        "action": "subagent",
                        "description": f"Subagent: {sub.agent_type or sub.subagent_id}",
                        "metadata": {
                            "subagent_id": sub.subagent_id,
                            "agent_type": sub.agent_type,
                        },
                    }
                )

            # Steps for elicitations completed during this turn (v2.1.x)
            for elic in getattr(turn, "_elicitations", []) or []:
                step_num += 1
                steps.append(
                    {
                        "step_number": step_num,
                        "action": "elicitation",
                        "description": f"Elicitation: {elic.get('type') or 'prompt'}",
                        "duration_ms": self._compute_duration_ms(
                            elic.get("started_at"), elic.get("completed_at"),
                        ),
                        "input_preview": elic.get("message"),
                        "output_preview": elic.get("response"),
                        "metadata": {
                            "elicitation_id": elic.get("id"),
                            "accepted": elic.get("accepted"),
                        },
                    }
                )

        # Session-level steps for v2.1.x events that aren't turn-scoped
        for task in session.tasks_created:
            step_num += 1
            steps.append({
                "step_number": step_num,
                "action": "task_created",
                "description": f"Task: {task.get('description') or task.get('task_id')}",
                "metadata": {
                    "task_id": task.get("task_id"),
                    "status": task.get("status"),
                },
            })

        for denial in session.permission_denials:
            step_num += 1
            step = {
                "step_number": step_num,
                "action": "permission_denied",
                "description": f"Denied: {denial.get('tool_name')}",
                "input_preview": denial.get("reason"),
                "error": {
                    "error_type": "PermissionDenied",
                    "message": denial.get("reason") or "Tool call blocked by permissions",
                    "recoverable": True,
                },
            }
            steps.append(step)
            all_errors.append(step["error"])

        # Build name and description
        num_turns = len(session.turns)
        first_prompt = None
        for t in session.turns:
            if t.prompt:
                first_prompt = t.prompt
                break

        if first_prompt:
            clean_prompt = " ".join(first_prompt.split())
            name = _truncate(clean_prompt, 30)
            description = first_prompt
        else:
            name = f"Claude Code session ({num_turns} turn{'s' if num_turns != 1 else ''})"
            description = f"Claude Code session with {session.total_tool_calls} tool calls"

        # Last response as output_summary
        output_summary = None
        for t in reversed(session.turns):
            if t.response:
                output_summary = t.response
                break

        # Environment context
        environment: Dict[str, Any] = {
            "framework": "claude-code",
            "runtime": "claude-code-connector",
            "sdk_version": __version__,
        }
        custom_tags: Dict[str, str] = {}
        if session.model:
            custom_tags["model"] = session.model
        if session.source:
            custom_tags["session_source"] = session.source
        if session.cwd:
            custom_tags["working_directory"] = session.cwd
        if session.permission_mode:
            custom_tags["permission_mode"] = session.permission_mode
        custom_tags["session_id"] = session.session_id
        if session.cwd_changes:
            custom_tags["cwd_change_count"] = str(len(session.cwd_changes))
        if session.tasks_created:
            custom_tags["tasks_created_count"] = str(len(session.tasks_created))
        if session.files_changed:
            custom_tags["files_changed_count"] = str(len(session.files_changed))
        if session.permission_denials:
            custom_tags["permission_denials_count"] = str(len(session.permission_denials))
        if custom_tags:
            environment["custom_tags"] = custom_tags

        # Development section (always relevant for Claude Code)
        development: Dict[str, Any] = {
            "framework_used": "claude-code",
        }
        # Collect file paths from FileChanged events (v2.1.x). De-duplicate
        # and cap to keep payload size bounded.
        changed_paths = []
        seen_paths = set()
        for fc in session.files_changed:
            p = fc.get("path")
            if p and p not in seen_paths:
                seen_paths.add(p)
                changed_paths.append(p)
                if len(changed_paths) >= 50:
                    break
        if changed_paths:
            development["files_modified"] = changed_paths
        elif session.cwd:
            development["files_modified"] = [session.cwd]

        # Collect unique tools used
        tools_used = list(
            {
                tool.tool_name
                for turn in session.turns
                for tool in turn.tool_uses
            }
        )

        sections: Dict[str, Any] = {
            "development": development,
            "general": {
                "tools_used": tools_used,
                "tags": ["claude-code", "ai-coding-agent"],
            },
        }

        # Use the most recent turn's timestamp for current_datetime so that
        # incremental (turn) traces show when the turn happened, not when the
        # session originally started.  Fall back to session start for summary
        # traces or sessions with no turns.
        trace_datetime = None
        if session.turns:
            last_turn = session.turns[-1]
            trace_datetime = last_turn.started_at or last_turn.completed_at
        if not trace_datetime:
            trace_datetime = session.started_at or now

        return InfiniumTracePayload(
            name=name,
            description=description,
            current_datetime=trace_datetime,
            duration=duration,
            input_summary=first_prompt,
            output_summary=output_summary,
            steps=steps if steps else None,
            errors=all_errors if all_errors else None,
            environment=environment,
            sections=sections,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_duration_ms(
        start_iso: Optional[str], end_iso: Optional[str]
    ) -> Optional[int]:
        """Compute duration between two ISO timestamps in milliseconds."""
        if not start_iso or not end_iso:
            return None
        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            start = datetime.strptime(start_iso, fmt)
            end = datetime.strptime(end_iso, fmt)
            return max(0, int((end - start).total_seconds() * 1000))
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _compute_session_duration(session: SessionData) -> float:
        """Compute total session duration in seconds."""
        start = session.started_at
        end = session.ended_at
        if not start:
            return 0.0

        # Use last turn's completed_at if no explicit end
        if not end:
            for turn in reversed(session.turns):
                if turn.completed_at:
                    end = turn.completed_at
                    break

        if not end:
            end = _now_iso()

        try:
            fmt = "%Y-%m-%dT%H:%M:%SZ"
            s = datetime.strptime(start, fmt)
            e = datetime.strptime(end, fmt)
            return max(0.0, (e - s).total_seconds())
        except (ValueError, TypeError):
            return 0.0
