"""
Type definitions for Claude Code hook events and Infinium trace payloads.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Claude Code hook event types
# ---------------------------------------------------------------------------

# All hook events that Claude Code can emit.
# Last aligned with Claude Code v2.1.97 (added in v2.1.x series: TaskCreated,
# CwdChanged, FileChanged, PermissionDenied, Elicitation, ElicitationResult).
HOOK_EVENTS = frozenset({
    "SessionStart",
    "SessionEnd",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "Stop",
    "SubagentStart",
    "SubagentStop",
    "Notification",
    "PreCompact",
    "PostCompact",
    # v2.1.x additions
    "TaskCreated",
    "CwdChanged",
    "FileChanged",
    "PermissionDenied",
    "Elicitation",
    "ElicitationResult",
})

# Events that signal session completion
SESSION_END_EVENTS = frozenset({"SessionEnd"})

# Events that represent a completed prompt turn (trigger trace flush)
TURN_END_EVENTS = frozenset({"Stop"})


@dataclass
class HookEvent:
    """Parsed Claude Code hook event."""

    event_name: str
    session_id: str
    timestamp: str  # ISO 8601
    cwd: Optional[str] = None
    permission_mode: Optional[str] = None
    agent_id: Optional[str] = None  # Claude Code subagent ID (not Infinium agent)
    agent_type: Optional[str] = None

    # Event-specific fields (varies by event_name)
    tool_name: Optional[str] = None
    tool_input: Optional[Dict[str, Any]] = None
    tool_response: Optional[str] = None
    tool_use_id: Optional[str] = None
    prompt: Optional[str] = None
    last_assistant_message: Optional[str] = None
    error: Optional[str] = None
    is_interrupt: Optional[bool] = None
    source: Optional[str] = None  # SessionStart source
    model: Optional[str] = None
    message: Optional[str] = None  # Notification
    notification_type: Optional[str] = None
    agent_transcript_path: Optional[str] = None  # SubagentStop

    # v2.1.x event-specific fields
    # TaskCreated
    task_id: Optional[str] = None
    task_description: Optional[str] = None
    task_status: Optional[str] = None

    # CwdChanged
    old_cwd: Optional[str] = None
    new_cwd: Optional[str] = None

    # FileChanged
    file_path: Optional[str] = None
    change_type: Optional[str] = None  # "created" | "modified" | "deleted"

    # PermissionDenied
    denial_reason: Optional[str] = None

    # Elicitation / ElicitationResult
    elicitation_id: Optional[str] = None
    elicitation_message: Optional[str] = None
    elicitation_type: Optional[str] = None  # "text" | "choice" | "confirm" | ...
    elicitation_response: Optional[str] = None
    elicitation_accepted: Optional[bool] = None

    # Raw payload for anything we don't explicitly parse
    raw: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Aggregated session data
# ---------------------------------------------------------------------------


@dataclass
class ToolUseRecord:
    """A single tool invocation within a session."""

    tool_name: str
    tool_use_id: Optional[str] = None
    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_ms: Optional[int] = None


@dataclass
class SubagentRecord:
    """A subagent lifecycle within a session."""

    subagent_id: str
    agent_type: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    transcript_path: Optional[str] = None


@dataclass
class PromptTurn:
    """A single user prompt → assistant response cycle."""

    prompt: Optional[str] = None
    response: Optional[str] = None
    tool_uses: List[ToolUseRecord] = field(default_factory=list)
    subagents: List[SubagentRecord] = field(default_factory=list)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


@dataclass
class SessionData:
    """Accumulated data for a Claude Code session."""

    session_id: str
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
    model: Optional[str] = None
    source: Optional[str] = None  # startup, resume, etc.
    cwd: Optional[str] = None
    permission_mode: Optional[str] = None

    turns: List[PromptTurn] = field(default_factory=list)

    # Counters
    total_tool_calls: int = 0
    total_errors: int = 0
    total_subagents: int = 0

    # v2.1.x tracking: collections populated by TaskCreated / CwdChanged /
    # FileChanged / PermissionDenied / Elicitation* handlers so they can be
    # surfaced in the payload's `sections` and `errors`.
    tasks_created: List[Dict[str, Any]] = field(default_factory=list)
    cwd_changes: List[Dict[str, Any]] = field(default_factory=list)
    files_changed: List[Dict[str, Any]] = field(default_factory=list)
    permission_denials: List[Dict[str, Any]] = field(default_factory=list)

    # Track pending tool uses (PreToolUse received, PostToolUse not yet)
    _pending_tools: Dict[str, ToolUseRecord] = field(default_factory=dict)
    # Elicitation -> ElicitationResult pairing (by elicitation_id)
    _pending_elicitations: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    _current_turn: Optional[PromptTurn] = field(default=None)


# ---------------------------------------------------------------------------
# Infinium trace payload (mirrors SDK TaskData structure)
# ---------------------------------------------------------------------------


@dataclass
class InfiniumTracePayload:
    """Payload sent to POST /agents/{agent_id}/trace."""

    name: str
    description: str
    current_datetime: str
    duration: float

    input_summary: Optional[str] = None
    output_summary: Optional[str] = None
    steps: Optional[List[Dict[str, Any]]] = None
    expected_outcome: Optional[Dict[str, Any]] = None
    environment: Optional[Dict[str, Any]] = None
    errors: Optional[List[Dict[str, Any]]] = None
    llm_usage: Optional[Dict[str, Any]] = None
    sections: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict, omitting None values."""
        result: Dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "current_datetime": self.current_datetime,
            "duration": self.duration,
        }
        for key in (
            "input_summary",
            "output_summary",
            "steps",
            "expected_outcome",
            "environment",
            "errors",
            "llm_usage",
            "sections",
        ):
            val = getattr(self, key)
            if val is not None:
                result[key] = val
        return result
