"""
Configuration for the Infinium Claude Code Connector.

Credential loading order (first match wins):
1. Project config (.infinium/config.json in cwd) + keyring
2. Environment variables (override — for CI/Docker)
3. CLI arguments (override everything)
"""
from __future__ import annotations

import json
import logging
import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "infinium-connector"
_CONFIG_DIR_NAME = ".infinium"
_CONFIG_FILE_NAME = "config.json"


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _find_config_dir(start: Path) -> Optional[Path]:
    """Walk up from *start* to find the nearest .infinium/config.json.

    Stops before the user's home directory to avoid matching the global
    ``~/.infinium/`` used for error logs and history.
    """
    current = start.resolve()
    home = Path.home().resolve()
    for _ in range(50):  # safeguard against infinite loops
        if current == home:
            break  # don't match ~/.infinium/ (global logs dir)
        candidate = current / _CONFIG_DIR_NAME
        if (candidate / _CONFIG_FILE_NAME).is_file():
            return candidate
        parent = current.parent
        if parent == current:
            break  # reached filesystem root
        current = parent
    return None


def project_config_dir(cwd: Optional[Path] = None) -> Path:
    """Return the nearest .infinium/ directory at or above *cwd*.

    Walks up the directory tree (like git finding .git/) so that hooks
    fired from subdirectories still resolve the project-level config.
    Falls back to ``<cwd>/.infinium/`` if nothing is found (e.g. during
    ``infinium-claude init`` before the directory exists).
    """
    base = cwd or Path.cwd()
    found = _find_config_dir(base)
    if found is not None:
        return found
    return base / _CONFIG_DIR_NAME


def project_config_path(cwd: Optional[Path] = None) -> Path:
    """Return <nearest .infinium>/config.json."""
    return project_config_dir(cwd) / _CONFIG_FILE_NAME


# ---------------------------------------------------------------------------
# File I/O
# ---------------------------------------------------------------------------


def _read_config_at(path: Path) -> dict:
    """Read a config file at a specific path, returning empty dict if missing."""
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Could not read config file %s: %s", path, e)
        return {}


def _write_config_at(path: Path, data: dict) -> Path:
    """Write config data to a specific path with restricted permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

    # Restrict permissions to owner only (Unix)
    if sys.platform != "win32":
        try:
            path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0600
        except OSError:
            pass

    return path


# ---------------------------------------------------------------------------
# Keyring
# ---------------------------------------------------------------------------


def _get_secret_from_keyring(agent_id: str) -> Optional[str]:
    """Retrieve the agent secret from the OS keyring."""
    try:
        import keyring

        secret = keyring.get_password(_KEYRING_SERVICE, agent_id)
        return secret
    except Exception as e:
        logger.debug("Keyring unavailable: %s", e)
        return None


def _set_secret_in_keyring(agent_id: str, secret: str) -> bool:
    """Store the agent secret in the OS keyring. Returns True on success."""
    try:
        import keyring

        keyring.set_password(_KEYRING_SERVICE, agent_id, secret)
        return True
    except Exception as e:
        logger.warning("Could not store secret in keyring: %s", e)
        return False


def _delete_secret_from_keyring(agent_id: str) -> None:
    """Remove the agent secret from the OS keyring."""
    try:
        import keyring

        keyring.delete_password(_KEYRING_SERVICE, agent_id)
    except Exception as e:
        logger.warning("Could not remove secret from keyring: %s", e)


# ---------------------------------------------------------------------------
# Credential loading (project first, then env)
# ---------------------------------------------------------------------------


def _load_from_path(path: Path) -> Tuple[str, str, str]:
    """Load credentials from a specific config file + keyring."""
    data = _read_config_at(path)
    agent_id = data.get("agent_id", "")
    base_url = data.get("base_url", "https://platform.i42m.ai/api/v1")

    agent_secret = ""
    if agent_id:
        secret = _get_secret_from_keyring(agent_id)
        if secret is None:
            logger.warning(
                "Could not retrieve agent secret from OS keyring for agent %s. "
                "The keyring service may be unavailable. "
                "Set INFINIUM_AGENT_SECRET env var as a workaround.",
                agent_id[:12],
            )
            agent_secret = ""
        else:
            agent_secret = secret

    return agent_id, agent_secret, base_url


def load_credentials(cwd: Optional[Path] = None) -> Tuple[str, str, str]:
    """
    Load credentials: project config first, then env vars.

    Returns (agent_id, agent_secret, base_url).
    """
    agent_id = ""
    agent_secret = ""
    base_url = "https://platform.i42m.ai/api/v1"

    # 1. Check project-level config
    proj_path = project_config_path(cwd)
    if proj_path.exists():
        agent_id, agent_secret, base_url = _load_from_path(proj_path)

    # 2. Env vars override (for CI/Docker/headless).
    # Uses `or` so that empty/unset env vars fall through to project config.
    # This is intentional: setting VAR="" is treated as "not set".
    agent_id = os.environ.get("INFINIUM_AGENT_ID", "") or agent_id
    agent_secret = os.environ.get("INFINIUM_AGENT_SECRET", "") or agent_secret
    base_url = os.environ.get("INFINIUM_BASE_URL", "") or base_url

    return agent_id, agent_secret, base_url


def save_credentials(
    agent_id: str,
    agent_secret: str,
    base_url: str = "https://platform.i42m.ai/api/v1",
    cwd: Optional[Path] = None,
) -> Tuple[Path, bool]:
    """
    Save credentials: agent_id + base_url to project config, secret to keyring.

    Returns (config_file_path, keyring_success).
    """
    path = project_config_path(cwd)

    # Read existing data at that path
    data = _read_config_at(path)
    data["agent_id"] = agent_id
    data["base_url"] = base_url
    written_path = _write_config_at(path, data)

    # Store secret in keyring (per-user)
    keyring_ok = _set_secret_in_keyring(agent_id, agent_secret)

    return written_path, keyring_ok


def has_existing_config(cwd: Optional[Path] = None) -> bool:
    """Check if credentials are already configured (project config)."""
    agent_id, agent_secret, _ = load_credentials(cwd)
    return bool(agent_id and agent_secret)


def require_project_config(cwd: Optional[Path] = None) -> None:
    """Raise click.UsageError if no .infinium/config.json exists in cwd."""
    import click

    path = project_config_path(cwd)
    if not path.exists():
        raise click.UsageError(
            "No Infinium configuration found.\n"
            "Run 'infinium-claude init' in your project root to set up tracing."
        )


def get_active_config_source(cwd: Optional[Path] = None) -> Optional[str]:
    """Return which config is active: 'project', 'env', or None."""
    # Check env first (highest priority)
    if os.environ.get("INFINIUM_AGENT_ID"):
        return "env"

    # Check project
    proj_data = _read_config_at(project_config_path(cwd))
    if proj_data.get("agent_id"):
        return "project"

    return None


def is_paused(cwd: Optional[Path] = None) -> bool:
    """Check if tracing is currently paused."""
    proj_data = _read_config_at(project_config_path(cwd))
    return proj_data.get("paused", False) is True


def set_paused(paused: bool, cwd: Optional[Path] = None) -> None:
    """Set the paused state in the project config file."""
    path = project_config_path(cwd)
    data = _read_config_at(path)
    if paused:
        data["paused"] = True
    else:
        data.pop("paused", None)
    _write_config_at(path, data)


def save_trace_granularity(
    flush_on_stop: bool,
    flush_on_session_end: bool,
    cwd: Optional[Path] = None,
) -> None:
    """Save trace granularity settings to the project config file."""
    path = project_config_path(cwd)
    data = _read_config_at(path)
    data["flush_on_stop"] = flush_on_stop
    data["flush_on_session_end"] = flush_on_session_end
    _write_config_at(path, data)


def load_trace_granularity(cwd: Optional[Path] = None) -> Tuple[bool, bool]:
    """Load trace granularity from project config. Returns (flush_on_stop, flush_on_session_end)."""
    data = _read_config_at(project_config_path(cwd))
    return data.get("flush_on_stop", True), data.get("flush_on_session_end", True)


def delete_config(cwd: Optional[Path] = None) -> None:
    """Remove project config file and keyring secret."""
    file_path = project_config_path(cwd)
    dir_path = project_config_dir(cwd)

    # Read agent_id before deleting so we can clean keyring
    data = _read_config_at(file_path)
    agent_id = data.get("agent_id", "")
    if agent_id:
        _delete_secret_from_keyring(agent_id)

    if file_path.exists():
        try:
            file_path.unlink()
        except OSError:
            pass

    try:
        dir_path.rmdir()  # Only succeeds if empty
    except OSError:
        pass


def _safe_int(value: str, default: int, name: str) -> int:
    """Parse an integer from a string, returning default on failure."""
    try:
        return int(value)
    except (ValueError, TypeError):
        logger.warning("Invalid integer for %s=%r, using default %d", name, value, default)
        return default


def _safe_float(value: str, default: float, name: str) -> float:
    """Parse a float from a string, returning default on failure."""
    try:
        return float(value)
    except (ValueError, TypeError):
        logger.warning("Invalid float for %s=%r, using default %s", name, value, default)
        return default


@dataclass
class ConnectorConfig:
    """All settings for the connector."""

    # Infinium credentials
    agent_id: str = ""
    agent_secret: str = ""
    base_url: str = "https://platform.i42m.ai/api/v1"

    # Mode: "command" (default, no server) or "http" (requires [server] extra)
    mode: str = "command"

    # Local server (http mode only)
    host: str = "127.0.0.1"
    port: int = 9339
    webhook_path: str = "/hooks/claude-code"

    # Session file storage (command mode only, defaults to system temp dir)
    session_dir: Optional[str] = None

    # Output
    quiet: bool = False  # Suppress stderr trace summaries

    # Behaviour
    flush_on_stop: bool = True
    flush_on_session_end: bool = True
    session_ttl_seconds: int = 3600
    max_input_preview: int = 200
    max_output_preview: int = 300
    log_level: str = "INFO"

    # HTTP client
    timeout: float = 30.0
    max_retries: int = 3
    verify_ssl: bool = True

    @classmethod
    def load(cls, cwd: Optional[Path] = None) -> ConnectorConfig:
        """Load config from credentials file + keyring + env vars."""
        agent_id, agent_secret, base_url = load_credentials(cwd)

        # Trace granularity: config.json first, env vars override if explicitly set
        file_flush_stop, file_flush_session = load_trace_granularity(cwd)
        env_flush_stop = os.environ.get("CONNECTOR_FLUSH_ON_STOP")
        env_flush_session = os.environ.get("CONNECTOR_FLUSH_ON_SESSION_END")

        return cls(
            agent_id=agent_id,
            agent_secret=agent_secret,
            base_url=base_url,
            quiet=os.environ.get("CONNECTOR_QUIET", "false").lower() == "true",
            mode=os.environ.get("CONNECTOR_MODE", "command"),
            host=os.environ.get("CONNECTOR_HOST", "127.0.0.1"),
            port=_safe_int(os.environ.get("CONNECTOR_PORT", "9339"), 9339, "CONNECTOR_PORT"),
            session_dir=os.environ.get("CONNECTOR_SESSION_DIR") or None,
            webhook_path=os.environ.get("CONNECTOR_WEBHOOK_PATH", "/hooks/claude-code"),
            flush_on_stop=(env_flush_stop.lower() == "true") if env_flush_stop else file_flush_stop,
            flush_on_session_end=(env_flush_session.lower() == "true") if env_flush_session else file_flush_session,
            session_ttl_seconds=_safe_int(os.environ.get("CONNECTOR_SESSION_TTL", "3600"), 3600, "CONNECTOR_SESSION_TTL"),
            max_input_preview=_safe_int(os.environ.get("CONNECTOR_MAX_INPUT_PREVIEW", "200"), 200, "CONNECTOR_MAX_INPUT_PREVIEW"),
            max_output_preview=_safe_int(os.environ.get("CONNECTOR_MAX_OUTPUT_PREVIEW", "300"), 300, "CONNECTOR_MAX_OUTPUT_PREVIEW"),
            log_level=os.environ.get("CONNECTOR_LOG_LEVEL", "INFO"),
            timeout=_safe_float(os.environ.get("INFINIUM_TIMEOUT", "30.0"), 30.0, "INFINIUM_TIMEOUT"),
            max_retries=_safe_int(os.environ.get("INFINIUM_MAX_RETRIES", "3"), 3, "INFINIUM_MAX_RETRIES"),
            verify_ssl=os.environ.get("INFINIUM_VERIFY_SSL", "true").lower() == "true",
        )

    @classmethod
    def load_hook_config(cls, cwd: Optional[Path] = None) -> tuple["ConnectorConfig", bool]:
        """Lightweight config load for the hook path — skips keyring access.

        Returns (config, paused).  The config will have empty agent_id and
        agent_secret; only session_dir and behavioural settings are populated.
        The background flush worker calls the full ``load()`` when it needs
        credentials for the API.
        """
        # Read config file once — extract paused flag at the same time
        proj_path = project_config_path(cwd)
        proj_data = _read_config_at(proj_path)
        paused = proj_data.get("paused", False) is True

        # Trace granularity: config.json first, env vars override if explicitly set
        file_flush_stop = proj_data.get("flush_on_stop", True)
        file_flush_session = proj_data.get("flush_on_session_end", True)
        env_flush_stop = os.environ.get("CONNECTOR_FLUSH_ON_STOP")
        env_flush_session = os.environ.get("CONNECTOR_FLUSH_ON_SESSION_END")

        # Build config without credentials (no keyring hit)
        return cls(
            agent_id="",
            agent_secret="",
            base_url=proj_data.get("base_url", "https://platform.i42m.ai/api/v1"),
            quiet=os.environ.get("CONNECTOR_QUIET", "false").lower() == "true",
            mode=os.environ.get("CONNECTOR_MODE", "command"),
            session_dir=os.environ.get("CONNECTOR_SESSION_DIR") or None,
            flush_on_stop=(env_flush_stop.lower() == "true") if env_flush_stop else file_flush_stop,
            flush_on_session_end=(env_flush_session.lower() == "true") if env_flush_session else file_flush_session,
            session_ttl_seconds=_safe_int(os.environ.get("CONNECTOR_SESSION_TTL", "3600"), 3600, "CONNECTOR_SESSION_TTL"),
            max_input_preview=_safe_int(os.environ.get("CONNECTOR_MAX_INPUT_PREVIEW", "200"), 200, "CONNECTOR_MAX_INPUT_PREVIEW"),
            max_output_preview=_safe_int(os.environ.get("CONNECTOR_MAX_OUTPUT_PREVIEW", "300"), 300, "CONNECTOR_MAX_OUTPUT_PREVIEW"),
            log_level=os.environ.get("CONNECTOR_LOG_LEVEL", "INFO"),
        ), paused

    # Keep for backwards compatibility
    @classmethod
    def from_env(cls) -> ConnectorConfig:
        """Alias for load()."""
        return cls.load()

    def validate(self) -> None:
        """Raise ValueError if required fields are missing."""
        if not self.agent_id or not self.agent_id.strip():
            raise ValueError(
                "Agent ID is required. Run 'infinium-claude init' to configure."
            )
        if not self.agent_secret or not self.agent_secret.strip():
            raise ValueError(
                "Agent Secret is required. Run 'infinium-claude init' to configure."
            )

    @property
    def hook_url(self) -> str:
        """Full URL for HTTP hook mode."""
        return f"http://{self.host}:{self.port}{self.webhook_path}"
