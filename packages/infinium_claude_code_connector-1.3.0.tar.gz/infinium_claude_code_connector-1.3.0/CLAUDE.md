# CLAUDE.md

Infinium Claude Code Connector — bridges Claude Code hooks to the Infinium agent tracing API.

## Connector Compatibility Monitor

A scheduled task (`weekly-connector-monitor`) runs every Wednesday at 9 AM to check whether upstream Claude Code changes could break this connector. When making fixes from that monitor, follow these rules.

### Upstream Surface This Connector Depends On

| Surface | What we depend on | Connector file |
|---------|---|---|
| **Hook registration** | `.claude/settings.json` schema with `hooks` key, event matchers, command type | `cli.py` |
| **Hook events (18)** | SessionStart, SessionEnd, UserPromptSubmit, PreToolUse, PostToolUse, PostToolUseFailure, Stop, SubagentStart, SubagentStop, Notification, PreCompact, PostCompact, + v2.1.x: TaskCreated, CwdChanged, FileChanged, PermissionDenied, Elicitation, ElicitationResult | `types.py` |
| **Minimum Claude Code** | v2.1.92+ for TaskCreated / CwdChanged / FileChanged / PermissionDenied / Elicitation* events. Older versions just don't fire them — the connector stays compatible. | README, `cli.py` |
| **Hook event JSON** | Fields: `hook_event_name`, `session_id`, `timestamp`, `cwd`, `tool_name`, `tool_input`, `tool_response`, `prompt`, `last_assistant_message`, `error`, `source`, `model`, `agent_transcript_path` | `types.py`, `hook.py`, `aggregator.py` |
| **Session transcripts** | `~/.claude/projects/{hash}/{session_id}.jsonl` — JSONL with `type: "assistant"` entries containing `message.usage` (input_tokens, output_tokens, cache_creation_input_tokens, cache_read_input_tokens) | `transcript.py` |
| **Hook timeout** | 5000ms — connector must exit quickly and use background worker | `hook.py`, `cli.py` |

### Branching and PR Conventions

- Branch name: `fix/upstream-compat-YYYY-MM-DD`
- PR title format: `fix(claude-code): adapt to Claude Code v<version> changes`
- PR body must include: what changed upstream, what broke or would break, what was updated
- One PR per upstream tool

### Testing Before PR

```bash
pip install -e ".[dev]"
pytest tests/ -v --no-cov
```

### What to Change (and What Not To)

**Change** when Claude Code updates its hook system:
- `types.py` — HOOK_EVENTS frozenset, HookEvent dataclass fields
- `aggregator.py` — event handler methods, tool summarizers
- `hook.py` — stdin JSON parsing, flush trigger events
- `transcript.py` — transcript path structure, usage field names
- `cli.py` — hook registration format in settings.json
- `tests/` — update fixtures and mocks to match new event shapes

**Do not change:**
- `sdk_bridge.py` — talks to Infinium API, not Claude Code
- `config.py` — credential management is connector-internal
- `error_log.py`, `history.py`, `jsonl_log.py` — internal utilities

## Commands

```bash
pip install -e .              # Install (dev)
infinium-claude init                 # Interactive setup wizard
infinium-claude test                 # Verify connection works
infinium-claude status               # Show current config + tracing state
infinium-claude pause                # Temporarily stop tracing
infinium-claude resume               # Resume tracing
infinium-claude history              # View recent traces
infinium-claude errors               # View connector errors
infinium-claude retry                # Resend failed traces
infinium-claude update-credentials   # Change Agent ID or Secret
infinium-claude uninstall            # Remove connector completely
infinium-claude cleanup              # Remove stale session files
infinium-claude start                # HTTP server mode (optional)
```

If `infinium-claude` is not on PATH, use `python -m infinium_connector <command>`.

## Architecture

```
infinium_connector/
  __init__.py          # Package exports, __version__ (single source of truth)
  __main__.py          # python -m infinium_connector entry point → CLI
  cli.py               # Click CLI (init, test, status, pause, resume, history, retry, etc.)
  config.py            # Credentials: project (.infinium/) → env vars (no global config)
                       # Agent secret stored in OS keyring via `keyring` library
  hook.py              # Command hook entry point (stdin → JSONL → spawn background flush)
  flush_worker.py      # Background worker for trace flush + stale cleanup (non-blocking)
  session_store.py     # JSONL session file I/O + failed/ directory + Windows file locking
  error_log.py         # Persistent error log (~/.infinium/errors.jsonl) with rotation
  transcript.py        # Read token usage from Claude Code's session transcript
  history.py           # Local trace history (~/.infinium/history.jsonl) with atomic rotation
  sdk_bridge.py        # InfiniumTracePayload → SDK TaskData → send via InfiniumClient
  aggregator.py        # Session event aggregation → trace payloads
  server.py            # Starlette ASGI app (optional HTTP mode, requires [server] extra)
  types.py             # Data models (HookEvent, SessionData, PromptTurn, etc.)
  py.typed             # PEP 561 typed package marker
```

## Credential Resolution Order

1. **Project config** — `.infinium/config.json` in cwd
2. **Environment variables** — `INFINIUM_AGENT_ID`, `INFINIUM_AGENT_SECRET` (override for CI/Docker)

Agent ID + base URL go in the project config file. Agent secret goes in OS keyring (keyed by agent ID).
There is no global config — tracing is always configured per-project.

## Data Flow (Command Mode)

```
Claude Code → command hook → python -m infinium_connector.hook
                                 │ reads JSON from stdin
                                 │ checks: paused? → skip
                                 │ resolves: project config → env vars
                                 ├─ append to {tmpdir}/infinium-sessions/{session_id}.jsonl
                                 └─ on Stop/SessionEnd:
                                      spawn detached background worker:
                                      python -m infinium_connector.flush_worker
                                        → read .jsonl → SessionAggregator → sdk_bridge.send_trace()
                                        → POST /agents/{agent_id}/trace (with app-level retry)
                                        → append to ~/.infinium/history.jsonl
                                        (on failure: log to ~/.infinium/errors.jsonl,
                                         move to failed/ for later retry,
                                         circuit-break after 3 consecutive failures)
                                      hook exits immediately — Claude Code is never blocked
```

## Version Management

Version is defined once in `__init__.py` (`__version__`). All other files import it:
- `cli.py` — `@click.version_option`
- `aggregator.py` — `sdk_version` in trace environment
- `sdk_bridge.py` — `user_agent` header
- `server.py` — health endpoint response
- `pyproject.toml` — `dynamic = ["version"]` with `[tool.hatch.version]` pointing to `__init__.py`
