"""Tests for the Claude Code `simulate` command pipeline (dry-run)."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from infinium_connector.config import ConnectorConfig
from infinium_connector.simulate import (
    SimulationResult,
    _generate_session,
    run_simulation,
)


class TestGenerateSession:
    def test_produces_at_least_core_events_with_v21(self):
        events = _generate_session()
        # Core: SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, Stop, SessionEnd
        # Plus v2.1.x events added between them.
        names = [e["hook_event_name"] for e in events]
        assert names[0] == "SessionStart"
        assert "UserPromptSubmit" in names
        assert "PreToolUse" in names
        assert "PostToolUse" in names
        assert "Stop" in names
        assert names[-1] == "SessionEnd"

    def test_includes_v21_events_by_default(self):
        names = [e["hook_event_name"] for e in _generate_session()]
        for v21 in ("TaskCreated", "FileChanged", "Elicitation", "ElicitationResult", "PermissionDenied", "CwdChanged"):
            assert v21 in names, f"{v21} missing from default simulation"

    def test_no_v21_mode(self):
        names = [e["hook_event_name"] for e in _generate_session(include_v21_events=False)]
        for v21 in ("TaskCreated", "FileChanged", "Elicitation", "ElicitationResult", "PermissionDenied", "CwdChanged"):
            assert v21 not in names

    def test_shared_session_id(self):
        events = _generate_session()
        sids = {e["session_id"] for e in events}
        assert len(sids) == 1

    def test_timestamps_monotonic(self):
        events = _generate_session()
        timestamps = [e["timestamp"] for e in events]
        assert timestamps == sorted(timestamps)

    def test_prompt_customization(self):
        events = _generate_session(prompt="custom prompt", command="custom-cmd")
        prompt_event = next(e for e in events if e["hook_event_name"] == "UserPromptSubmit")
        pre_tool = next(e for e in events if e["hook_event_name"] == "PreToolUse")
        assert prompt_event["prompt"] == "custom prompt"
        assert pre_tool["tool_input"]["command"] == "custom-cmd"


class TestRunSimulation:
    def test_dry_run_skips_send(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        with patch("infinium_connector.simulate.send_trace") as mock_send:
            result = run_simulation(config, dry_run=True)
        mock_send.assert_not_called()
        assert result.trace_id == "dry-run"
        assert result.session_id.startswith("claude-sim-")

    def test_payload_tagged_as_simulated(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        result = run_simulation(config, dry_run=True)
        tags = result.payload.environment.get("custom_tags") or {}
        assert tags.get("simulated") == "true"

    def test_payload_contains_v21_markers(self):
        """Default simulation should exercise all v2.1.x events."""
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        result = run_simulation(config, dry_run=True)
        tags = result.payload.environment.get("custom_tags") or {}
        # We generated 1 task, 1 cwd change, 1 file change, 1 permission denial
        assert tags.get("tasks_created_count") == "1"
        assert tags.get("cwd_change_count") == "1"
        assert tags.get("files_changed_count") == "1"
        assert tags.get("permission_denials_count") == "1"

    def test_live_run_calls_send_trace(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        with patch("infinium_connector.simulate.send_trace", return_value={"traceId": "claude-trace"}) as mock_send:
            result = run_simulation(config, dry_run=False)
        mock_send.assert_called_once()
        assert result.trace_id == "claude-trace"

    def test_invalid_config_raises(self):
        config = ConnectorConfig(agent_id="", agent_secret="")
        with pytest.raises(ValueError, match="Agent ID"):
            run_simulation(config, dry_run=True)

    def test_no_v21_skips_those_events(self):
        config = ConnectorConfig(agent_id="test-id", agent_secret="test-secret")
        result = run_simulation(config, dry_run=True, include_v21_events=False)
        tags = result.payload.environment.get("custom_tags") or {}
        assert "tasks_created_count" not in tags
        assert "files_changed_count" not in tags
