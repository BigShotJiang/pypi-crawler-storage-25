"""Tests for infinium_connector.config — credential loading, env parsing, validation."""
from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from infinium_connector.config import (
    ConnectorConfig,
    _find_config_dir,
    _safe_int,
    _safe_float,
    load_credentials,
    save_credentials,
    has_existing_config,
    is_paused,
    set_paused,
    project_config_path,
    require_project_config,
    get_active_config_source,
    delete_config,
)


# ---------------------------------------------------------------------------
# _safe_int / _safe_float (Fix #3)
# ---------------------------------------------------------------------------


class TestSafeParsing:
    def test_safe_int_valid(self):
        assert _safe_int("42", 0, "TEST") == 42

    def test_safe_int_invalid_returns_default(self):
        assert _safe_int("abc", 99, "TEST") == 99

    def test_safe_int_empty_string(self):
        assert _safe_int("", 10, "TEST") == 10

    def test_safe_int_float_string(self):
        # "3.14" is not a valid int
        assert _safe_int("3.14", 5, "TEST") == 5

    def test_safe_int_none(self):
        assert _safe_int(None, 7, "TEST") == 7

    def test_safe_float_valid(self):
        assert _safe_float("3.14", 0.0, "TEST") == pytest.approx(3.14)

    def test_safe_float_invalid_returns_default(self):
        assert _safe_float("not-a-float", 1.5, "TEST") == 1.5

    def test_safe_float_int_string(self):
        assert _safe_float("42", 0.0, "TEST") == 42.0

    def test_safe_float_none(self):
        assert _safe_float(None, 9.9, "TEST") == 9.9


# ---------------------------------------------------------------------------
# ConnectorConfig.load with env vars (Fix #3)
# ---------------------------------------------------------------------------


class TestConfigLoad:
    def test_load_defaults(self):
        config = ConnectorConfig.load()
        assert config.port == 9339
        assert config.timeout == 30.0
        assert config.max_retries == 3
        assert config.session_ttl_seconds == 3600

    def test_load_valid_env_overrides(self, monkeypatch):
        monkeypatch.setenv("CONNECTOR_PORT", "8080")
        monkeypatch.setenv("INFINIUM_TIMEOUT", "15.5")
        monkeypatch.setenv("INFINIUM_MAX_RETRIES", "5")
        config = ConnectorConfig.load()
        assert config.port == 8080
        assert config.timeout == pytest.approx(15.5)
        assert config.max_retries == 5

    def test_load_invalid_port_uses_default(self, monkeypatch):
        """Fix #3: invalid CONNECTOR_PORT should not crash."""
        monkeypatch.setenv("CONNECTOR_PORT", "not-a-port")
        config = ConnectorConfig.load()
        assert config.port == 9339

    def test_load_invalid_timeout_uses_default(self, monkeypatch):
        """Fix #3: invalid INFINIUM_TIMEOUT should not crash."""
        monkeypatch.setenv("INFINIUM_TIMEOUT", "not-a-number")
        config = ConnectorConfig.load()
        assert config.timeout == 30.0

    def test_load_invalid_ttl_uses_default(self, monkeypatch):
        monkeypatch.setenv("CONNECTOR_SESSION_TTL", "forever")
        config = ConnectorConfig.load()
        assert config.session_ttl_seconds == 3600

    def test_load_invalid_max_retries_uses_default(self, monkeypatch):
        monkeypatch.setenv("INFINIUM_MAX_RETRIES", "lots")
        config = ConnectorConfig.load()
        assert config.max_retries == 3

    def test_load_boolean_env_vars(self, monkeypatch):
        monkeypatch.setenv("CONNECTOR_QUIET", "true")
        monkeypatch.setenv("INFINIUM_VERIFY_SSL", "false")
        config = ConnectorConfig.load()
        assert config.quiet is True
        assert config.verify_ssl is False

    def test_load_session_dir_from_env(self, monkeypatch, tmp_path):
        monkeypatch.setenv("CONNECTOR_SESSION_DIR", str(tmp_path))
        config = ConnectorConfig.load()
        assert config.session_dir == str(tmp_path)

    def test_from_env_alias(self):
        config = ConnectorConfig.from_env()
        assert isinstance(config, ConnectorConfig)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


class TestValidation:
    def test_validate_missing_agent_id(self):
        config = ConnectorConfig(agent_id="", agent_secret="secret")
        with pytest.raises(ValueError, match="Agent ID"):
            config.validate()

    def test_validate_missing_agent_secret(self):
        config = ConnectorConfig(agent_id="agent-123", agent_secret="")
        with pytest.raises(ValueError, match="Agent Secret"):
            config.validate()

    def test_validate_whitespace_only(self):
        config = ConnectorConfig(agent_id="  ", agent_secret="secret")
        with pytest.raises(ValueError):
            config.validate()

    def test_validate_ok(self):
        config = ConnectorConfig(agent_id="agent-123", agent_secret="s3cret")
        config.validate()  # Should not raise


# ---------------------------------------------------------------------------
# Credential loading
# ---------------------------------------------------------------------------


class TestCredentialLoading:
    def test_load_from_project_config(self, tmp_path):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps({"agent_id": "proj-agent", "base_url": "https://custom.api/v1"}),
            encoding="utf-8",
        )

        with patch(
            "infinium_connector.config._get_secret_from_keyring",
            return_value="proj-secret",
        ):
            agent_id, secret, url = load_credentials(cwd=tmp_path)

        assert agent_id == "proj-agent"
        assert secret == "proj-secret"
        assert url == "https://custom.api/v1"

    def test_env_vars_override_project_config(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps({"agent_id": "proj-agent"}), encoding="utf-8"
        )

        monkeypatch.setenv("INFINIUM_AGENT_ID", "env-agent")
        monkeypatch.setenv("INFINIUM_AGENT_SECRET", "env-secret")

        agent_id, secret, _ = load_credentials(cwd=tmp_path)
        assert agent_id == "env-agent"
        assert secret == "env-secret"

    def test_empty_env_var_does_not_override(self, tmp_path, monkeypatch):
        """Fix #10: empty env var should fall through to project config."""
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps({"agent_id": "proj-agent"}), encoding="utf-8"
        )
        with patch(
            "infinium_connector.config._get_secret_from_keyring",
            return_value="proj-secret",
        ):
            monkeypatch.setenv("INFINIUM_AGENT_ID", "")
            agent_id, _, _ = load_credentials(cwd=tmp_path)
        assert agent_id == "proj-agent"


# ---------------------------------------------------------------------------
# Keyring warnings (Fixes #8, #9)
# ---------------------------------------------------------------------------


class TestKeyringWarnings:
    def test_keyring_unavailable_logs_warning(self, tmp_path):
        """Fix #8: keyring failure should log a warning, not fail silently."""
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps({"agent_id": "agent-123"}), encoding="utf-8"
        )

        with patch(
            "infinium_connector.config._get_secret_from_keyring", return_value=None
        ):
            with patch("infinium_connector.config.logger") as mock_logger:
                agent_id, secret, _ = load_credentials(cwd=tmp_path)
                mock_logger.warning.assert_called_once()
                assert "keyring" in mock_logger.warning.call_args[0][0].lower()
        assert secret == ""

    def test_delete_keyring_failure_logs_warning(self):
        """Fix #9: keyring delete failure should log a warning."""
        with patch("infinium_connector.config.logger") as mock_logger:
            with patch(
                "keyring.delete_password", side_effect=Exception("keyring error")
            ):
                from infinium_connector.config import _delete_secret_from_keyring

                _delete_secret_from_keyring("agent-123")
                mock_logger.warning.assert_called_once()


# ---------------------------------------------------------------------------
# Config path helpers
# ---------------------------------------------------------------------------


class TestConfigPaths:
    def test_find_config_dir_walks_up(self, tmp_path):
        # Create config in parent
        (tmp_path / ".infinium").mkdir()
        (tmp_path / ".infinium" / "config.json").write_text("{}", encoding="utf-8")

        subdir = tmp_path / "deep" / "nested"
        subdir.mkdir(parents=True)

        found = _find_config_dir(subdir)
        assert found == tmp_path / ".infinium"

    def test_find_config_dir_stops_at_home(self, tmp_path):
        # Should not find config above home
        with patch("pathlib.Path.home", return_value=tmp_path):
            result = _find_config_dir(tmp_path)
        assert result is None

    def test_project_config_path(self, tmp_path):
        path = project_config_path(cwd=tmp_path)
        assert path.name == "config.json"
        assert ".infinium" in str(path)


# ---------------------------------------------------------------------------
# Paused state
# ---------------------------------------------------------------------------


class TestPausedState:
    def test_is_paused_default(self, tmp_path):
        assert is_paused(cwd=tmp_path) is False

    def test_set_and_check_paused(self, tmp_path):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        (config_dir / "config.json").write_text("{}", encoding="utf-8")

        set_paused(True, cwd=tmp_path)
        assert is_paused(cwd=tmp_path) is True

        set_paused(False, cwd=tmp_path)
        assert is_paused(cwd=tmp_path) is False


# ---------------------------------------------------------------------------
# require_project_config (Fix #16)
# ---------------------------------------------------------------------------


class TestRequireConfig:
    def test_raises_when_no_config(self, tmp_path):
        import click

        with pytest.raises(click.UsageError, match="infinium-claude init"):
            require_project_config(cwd=tmp_path)

    def test_passes_when_config_exists(self, tmp_path):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        (config_dir / "config.json").write_text("{}", encoding="utf-8")
        require_project_config(cwd=tmp_path)  # Should not raise


# ---------------------------------------------------------------------------
# get_active_config_source
# ---------------------------------------------------------------------------


class TestActiveConfigSource:
    def test_returns_none_when_no_config(self, tmp_path):
        assert get_active_config_source(cwd=tmp_path) is None

    def test_returns_project_when_config_exists(self, tmp_path):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        (config_dir / "config.json").write_text(
            json.dumps({"agent_id": "test"}), encoding="utf-8"
        )
        assert get_active_config_source(cwd=tmp_path) == "project"

    def test_returns_env_when_env_set(self, monkeypatch):
        monkeypatch.setenv("INFINIUM_AGENT_ID", "env-agent")
        assert get_active_config_source() == "env"


# ---------------------------------------------------------------------------
# delete_config
# ---------------------------------------------------------------------------


class TestDeleteConfig:
    def test_delete_removes_file_and_dir(self, tmp_path):
        config_dir = tmp_path / ".infinium"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps({"agent_id": "del-agent"}), encoding="utf-8"
        )

        with patch("infinium_connector.config._delete_secret_from_keyring"):
            delete_config(cwd=tmp_path)

        assert not config_file.exists()
        assert not config_dir.exists()
