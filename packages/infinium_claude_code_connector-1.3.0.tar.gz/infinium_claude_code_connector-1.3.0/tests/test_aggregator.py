"""Tests for infinium_connector.aggregator — event ingestion and payload building."""
from __future__ import annotations

from typing import Any, Dict, List

import pytest

from infinium_connector.aggregator import SessionAggregator, _truncate, _short_path
from infinium_connector.config import ConnectorConfig
from infinium_connector.types import InfiniumTracePayload


@pytest.fixture()
def config() -> ConnectorConfig:
    return ConnectorConfig(
        agent_id="test-agent",
        agent_secret="test-secret",
        max_input_preview=200,
        max_output_preview=300,
    )


@pytest.fixture()
def aggregator(config) -> SessionAggregator:
    return SessionAggregator(config)


# ---------------------------------------------------------------------------
# Truncate helper
# ---------------------------------------------------------------------------


class TestTruncate:
    def test_none_returns_none(self):
        assert _truncate(None, 100) is None

    def test_short_string_unchanged(self):
        assert _truncate("hello", 100) == "hello"

    def test_long_string_truncated(self):
        result = _truncate("a" * 200, 50)
        assert len(result) == 50
        assert result.endswith("...")

    def test_non_string_coerced(self):
        result = _truncate({"key": "value"}, 100)
        assert isinstance(result, str)

    def test_list_coerced(self):
        result = _truncate([1, 2, 3], 100)
        assert isinstance(result, str)


# ---------------------------------------------------------------------------
# Short path helper
# ---------------------------------------------------------------------------


class TestShortPath:
    def test_empty_path(self):
        assert _short_path("") == ""

    def test_filename_only(self):
        assert _short_path("file.py") == "file.py"

    def test_long_path_shortened(self):
        result = _short_path("/home/user/project/src/deep/file.py")
        assert "file.py" in result
        # Should only have last 2 components
        parts = result.split("/")
        assert len(parts) <= 2

    def test_windows_path(self):
        result = _short_path("C:\\Users\\dev\\project\\src\\file.py")
        assert "file.py" in result


# ---------------------------------------------------------------------------
# Session lifecycle
# ---------------------------------------------------------------------------


class TestSessionLifecycle:
    def test_ingest_session_start(self, aggregator, sample_session_start):
        event, payload = aggregator.ingest(sample_session_start)
        assert event.event_name == "SessionStart"
        assert payload is None  # No flush on SessionStart
        assert aggregator.active_session_count == 1

    def test_ingest_full_session(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        # SessionEnd should produce a payload
        assert payload is not None
        assert payload.name is not None
        assert payload.duration >= 0

    def test_stop_produces_payload(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        _, payload = aggregator.ingest(sample_stop)
        assert payload is not None

    def test_session_end_removes_session(self, aggregator, full_session_events):
        for ev in full_session_events:
            aggregator.ingest(ev)
        assert aggregator.active_session_count == 0

    def test_stop_keeps_session_alive(self, aggregator, sample_session_start, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_stop)
        assert aggregator.active_session_count == 1


# ---------------------------------------------------------------------------
# Event handlers
# ---------------------------------------------------------------------------


class TestEventHandlers:
    def test_user_prompt_creates_turn(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        session = aggregator._sessions["sess-abc123"]
        assert len(session.turns) == 1
        assert session.turns[0].prompt == "Fix the login bug"

    def test_tool_use_recorded(
        self, aggregator, sample_session_start, sample_user_prompt,
        sample_pre_tool_use, sample_post_tool_use,
    ):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_pre_tool_use)
        aggregator.ingest(sample_post_tool_use)

        session = aggregator._sessions["sess-abc123"]
        assert session.total_tool_calls == 1
        turn = session.turns[0]
        assert len(turn.tool_uses) == 1
        assert turn.tool_uses[0].tool_name == "Read"

    def test_tool_failure_increments_errors(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PreToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Bash",
            "tool_use_id": "tool-fail",
            "tool_input": {"command": "rm -rf /"},
        })
        aggregator.ingest({
            "hook_event_name": "PostToolUseFailure",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:11Z",
            "tool_name": "Bash",
            "tool_use_id": "tool-fail",
            "error": "Permission denied",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_errors == 1
        assert session.total_tool_calls == 1

    def test_post_tool_use_without_pre(self, aggregator, sample_session_start, sample_user_prompt):
        """PostToolUse without matching PreToolUse should create inline record."""
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PostToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Grep",
            "tool_use_id": "orphan-tool",
            "tool_response": "3 matches found",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_tool_calls == 1

    def test_subagent_lifecycle(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "SubagentStart",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "agent_id": "sub-1",
            "agent_type": "Explore",
        })
        aggregator.ingest({
            "hook_event_name": "SubagentStop",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:20Z",
            "agent_id": "sub-1",
            "agent_transcript_path": "/tmp/transcript.jsonl",
        })

        session = aggregator._sessions["sess-abc123"]
        assert session.total_subagents == 1
        turn = session.turns[0]
        assert len(turn.subagents) == 1
        assert turn.subagents[0].completed_at is not None

    def test_stop_sets_response(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_stop)

        session = aggregator._sessions["sess-abc123"]
        assert session.turns[0].response == "I fixed the login bug."

    def test_unhandled_event_no_crash(self, aggregator, sample_session_start):
        aggregator.ingest(sample_session_start)
        aggregator.ingest({
            "hook_event_name": "FutureEvent",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:01Z",
        })
        # Should not crash


# ---------------------------------------------------------------------------
# Payload building
# ---------------------------------------------------------------------------


class TestPayloadBuilding:
    def test_payload_has_name_from_prompt(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert "Fix the login bug" in (payload.name or "")

    def test_payload_has_steps(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.steps is not None
        assert len(payload.steps) > 0

    def test_payload_has_environment(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.environment is not None
        assert payload.environment["framework"] == "claude-code"
        assert "session_id" in payload.environment.get("custom_tags", {})

    def test_payload_has_errors_when_tool_fails(self, aggregator, sample_session_start, sample_user_prompt):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest({
            "hook_event_name": "PreToolUse",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:10Z",
            "tool_name": "Bash",
            "tool_use_id": "t-1",
        })
        aggregator.ingest({
            "hook_event_name": "PostToolUseFailure",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:11Z",
            "tool_use_id": "t-1",
            "error": "Command failed",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-abc123",
            "timestamp": "2026-03-31T10:00:12Z",
        })

        assert payload.errors is not None
        assert len(payload.errors) == 1

    def test_payload_no_errors_on_clean_session(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.errors is None or len(payload.errors) == 0

    def test_payload_output_summary_from_last_response(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        assert payload.output_summary == "I fixed the login bug."

    def test_turn_trace_uses_turn_timestamp_not_session_start(self, aggregator):
        """current_datetime should reflect the turn time, not session start."""
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T08:00:00Z",  # Session started hours ago
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T11:30:00Z",  # Turn started much later
            "prompt": "Fix the bug",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-ts",
            "timestamp": "2026-03-31T11:31:00Z",
        })

        # current_datetime should be the turn time (11:30), NOT session start (08:00)
        assert payload.current_datetime == "2026-03-31T11:30:00Z"

    def test_session_summary_uses_session_start(self, aggregator):
        """SessionEnd summary should still use session start time."""
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:00:00Z",
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:00:05Z",
            "prompt": "hello",
        })
        # SessionEnd flushes the whole session — should use first turn's time
        _, payload = aggregator.ingest({
            "hook_event_name": "SessionEnd",
            "session_id": "sess-sum",
            "timestamp": "2026-03-31T08:01:00Z",
        })

        # With one turn, current_datetime is the turn's started_at
        assert payload.current_datetime == "2026-03-31T08:00:05Z"

    def test_no_prompt_session_gets_generic_name(self, aggregator):
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-noprompt",
            "timestamp": "2026-03-31T10:00:00Z",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "SessionEnd",
            "session_id": "sess-noprompt",
            "timestamp": "2026-03-31T10:00:10Z",
        })

        assert "session" in payload.name.lower()

    def test_to_dict_omits_none_fields(self, aggregator, full_session_events):
        payload = None
        for ev in full_session_events:
            _, p = aggregator.ingest(ev)
            if p is not None:
                payload = p

        d = payload.to_dict()
        for key, val in d.items():
            assert val is not None


# ---------------------------------------------------------------------------
# Flush / replay
# ---------------------------------------------------------------------------


class TestFlushReplay:
    def test_flush_session(self, aggregator, sample_session_start, sample_user_prompt, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_user_prompt)
        aggregator.ingest(sample_stop)

        payload = aggregator.flush_session("sess-abc123")
        assert payload is not None
        assert aggregator.active_session_count == 0

    def test_flush_nonexistent_session(self, aggregator):
        assert aggregator.flush_session("nope") is None

    def test_flush_all(self, aggregator, sample_session_start, sample_stop):
        aggregator.ingest(sample_session_start)
        aggregator.ingest(sample_stop)

        # Start another session
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-222",
            "timestamp": "2026-03-31T10:00:00Z",
        })

        payloads = aggregator.flush_all()
        assert len(payloads) == 2
        assert aggregator.active_session_count == 0

    def test_replay_events(self, aggregator, full_session_events):
        payload = aggregator.replay_events(full_session_events)
        assert payload is not None
        assert payload.name is not None

    def test_replay_empty_events(self, aggregator):
        assert aggregator.replay_events([]) is None

    def test_evict_stale(self, aggregator, sample_session_start):
        aggregator.ingest(sample_session_start)
        # Fake the timestamp to be old
        aggregator._session_timestamps["sess-abc123"] = 0.0
        aggregator.config.session_ttl_seconds = 1

        evicted = aggregator.evict_stale()
        assert "sess-abc123" in evicted
        assert aggregator.active_session_count == 0


# ---------------------------------------------------------------------------
# Duration computation
# ---------------------------------------------------------------------------


class TestDuration:
    def test_duration_from_timestamps(self, aggregator):
        aggregator.ingest({
            "hook_event_name": "SessionStart",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:00Z",
        })
        aggregator.ingest({
            "hook_event_name": "UserPromptSubmit",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:05Z",
            "prompt": "test",
        })
        _, payload = aggregator.ingest({
            "hook_event_name": "Stop",
            "session_id": "sess-dur",
            "timestamp": "2026-03-31T10:00:30Z",
        })
        assert payload.duration >= 25.0

    def test_duration_ms_computation(self, aggregator):
        ms = aggregator._compute_duration_ms(
            "2026-03-31T10:00:00Z", "2026-03-31T10:00:05Z"
        )
        assert ms == 5000

    def test_duration_ms_none_inputs(self, aggregator):
        assert aggregator._compute_duration_ms(None, "2026-03-31T10:00:00Z") is None
        assert aggregator._compute_duration_ms("2026-03-31T10:00:00Z", None) is None

    def test_duration_ms_invalid_format(self, aggregator):
        assert aggregator._compute_duration_ms("bad", "also bad") is None


# ---------------------------------------------------------------------------
# Claude Code v2.1.x events
# ---------------------------------------------------------------------------


def _base_event(name: str, sid: str = "sess-v21", ts: str = "2026-04-18T10:00:00Z", **extra):
    event = {"hook_event_name": name, "session_id": sid, "timestamp": ts, "cwd": "/tmp"}
    event.update(extra)
    return event


class TestTaskCreatedEvent:
    def test_recorded_on_session(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "TaskCreated",
            ts="2026-04-18T10:00:01Z",
            task_id="task-1",
            task_description="Investigate login bug",
            task_status="pending",
        ))
        session = aggregator._sessions["sess-v21"]
        assert len(session.tasks_created) == 1
        assert session.tasks_created[0]["task_id"] == "task-1"
        assert session.tasks_created[0]["description"] == "Investigate login bug"

    def test_alt_field_names_accepted(self, aggregator):
        """Accept ``description``/``content`` as fallbacks for task_description."""
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "TaskCreated",
            ts="2026-04-18T10:00:01Z",
            id="alt-id",
            description="Using alt field name",
            status="in_progress",
        ))
        session = aggregator._sessions["sess-v21"]
        assert session.tasks_created[0]["task_id"] == "alt-id"
        assert session.tasks_created[0]["description"] == "Using alt field name"

    def test_shows_up_in_payload_steps(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "TaskCreated",
            ts="2026-04-18T10:00:01Z",
            task_id="task-X",
            task_description="Do the thing",
        ))
        payload = aggregator.flush_session("sess-v21")
        d = payload.to_dict()
        task_steps = [s for s in d["steps"] if s["action"] == "task_created"]
        assert len(task_steps) == 1
        assert "Do the thing" in task_steps[0]["description"]


class TestCwdChangedEvent:
    def test_updates_session_cwd(self, aggregator):
        aggregator.ingest(_base_event("SessionStart", cwd="/tmp/old"))
        aggregator.ingest(_base_event(
            "CwdChanged",
            ts="2026-04-18T10:00:01Z",
            old_cwd="/tmp/old",
            new_cwd="/tmp/new",
        ))
        session = aggregator._sessions["sess-v21"]
        assert session.cwd == "/tmp/new"
        assert len(session.cwd_changes) == 1

    def test_cwd_change_count_in_custom_tags(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("CwdChanged", ts="2026-04-18T10:00:01Z", new_cwd="/a"))
        aggregator.ingest(_base_event("CwdChanged", ts="2026-04-18T10:00:02Z", new_cwd="/b"))
        payload = aggregator.flush_session("sess-v21")
        tags = payload.to_dict()["environment"]["custom_tags"]
        assert tags["cwd_change_count"] == "2"


class TestFileChangedEvent:
    def test_collected_into_files_modified(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "FileChanged",
            ts="2026-04-18T10:00:01Z",
            file_path="src/login.py",
            change_type="modified",
        ))
        aggregator.ingest(_base_event(
            "FileChanged",
            ts="2026-04-18T10:00:02Z",
            file_path="src/auth.py",
            change_type="created",
        ))
        payload = aggregator.flush_session("sess-v21")
        d = payload.to_dict()
        assert set(d["sections"]["development"]["files_modified"]) == {"src/login.py", "src/auth.py"}

    def test_deduplicates_paths(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        for _ in range(3):
            aggregator.ingest(_base_event(
                "FileChanged",
                ts="2026-04-18T10:00:01Z",
                file_path="src/same.py",
                change_type="modified",
            ))
        payload = aggregator.flush_session("sess-v21")
        assert payload.to_dict()["sections"]["development"]["files_modified"] == ["src/same.py"]

    def test_no_path_ignored(self, aggregator):
        """FileChanged without a file_path should be skipped, not error."""
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("FileChanged", ts="2026-04-18T10:00:01Z"))
        session = aggregator._sessions["sess-v21"]
        assert session.files_changed == []


class TestPermissionDeniedEvent:
    def test_creates_error_entry(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "PermissionDenied",
            ts="2026-04-18T10:00:01Z",
            tool_name="Bash",
            tool_use_id="deny-1",
            denial_reason="User blocked rm -rf",
        ))
        payload = aggregator.flush_session("sess-v21")
        d = payload.to_dict()
        assert d.get("errors") is not None
        assert any(e["error_type"] == "PermissionDenied" for e in d["errors"])

    def test_pops_matching_pending_tool(self, aggregator):
        """PermissionDenied cleans up a pending PreToolUse for the same id."""
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("UserPromptSubmit", ts="2026-04-18T10:00:01Z", prompt="do"))
        aggregator.ingest(_base_event(
            "PreToolUse",
            ts="2026-04-18T10:00:02Z",
            tool_name="Bash",
            tool_use_id="use-denied",
            tool_input={"command": "rm -rf /"},
        ))
        assert "use-denied" in aggregator._sessions["sess-v21"]._pending_tools

        aggregator.ingest(_base_event(
            "PermissionDenied",
            ts="2026-04-18T10:00:03Z",
            tool_name="Bash",
            tool_use_id="use-denied",
            denial_reason="Nope",
        ))
        assert "use-denied" not in aggregator._sessions["sess-v21"]._pending_tools

    def test_count_in_custom_tags(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("PermissionDenied", ts="2026-04-18T10:00:01Z", tool_name="X"))
        aggregator.ingest(_base_event("PermissionDenied", ts="2026-04-18T10:00:02Z", tool_name="Y"))
        payload = aggregator.flush_session("sess-v21")
        tags = payload.to_dict()["environment"]["custom_tags"]
        assert tags["permission_denials_count"] == "2"


class TestElicitationEvents:
    def test_elicitation_then_result_paired(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("UserPromptSubmit", ts="2026-04-18T10:00:01Z", prompt="go"))
        aggregator.ingest(_base_event(
            "Elicitation",
            ts="2026-04-18T10:00:02Z",
            elicitation_id="elic-1",
            elicitation_type="confirm",
            elicitation_message="Apply changes?",
        ))
        session = aggregator._sessions["sess-v21"]
        assert "elic-1" in session._pending_elicitations

        aggregator.ingest(_base_event(
            "ElicitationResult",
            ts="2026-04-18T10:00:05Z",
            elicitation_id="elic-1",
            elicitation_response="yes",
            elicitation_accepted=True,
        ))
        assert "elic-1" not in session._pending_elicitations
        turn = session._current_turn
        assert hasattr(turn, "_elicitations")
        assert len(turn._elicitations) == 1
        assert turn._elicitations[0]["response"] == "yes"
        assert turn._elicitations[0]["accepted"] is True

    def test_result_without_matching_elicitation(self, aggregator):
        """ElicitationResult without a prior Elicitation still records inline."""
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event(
            "ElicitationResult",
            ts="2026-04-18T10:00:01Z",
            elicitation_id="orphan",
            elicitation_response="maybe",
        ))
        turn = aggregator._sessions["sess-v21"]._current_turn
        assert hasattr(turn, "_elicitations")
        assert turn._elicitations[0]["id"] == "orphan"

    def test_elicitation_surfaced_as_step(self, aggregator):
        aggregator.ingest(_base_event("SessionStart"))
        aggregator.ingest(_base_event("UserPromptSubmit", ts="2026-04-18T10:00:01Z", prompt="go"))
        aggregator.ingest(_base_event(
            "Elicitation",
            ts="2026-04-18T10:00:02Z",
            elicitation_id="e1",
            elicitation_type="text",
            elicitation_message="Enter value",
        ))
        aggregator.ingest(_base_event(
            "ElicitationResult",
            ts="2026-04-18T10:00:05Z",
            elicitation_id="e1",
            elicitation_response="foo",
            elicitation_accepted=True,
        ))
        payload = aggregator.flush_session("sess-v21")
        d = payload.to_dict()
        elic_steps = [s for s in d["steps"] if s["action"] == "elicitation"]
        assert len(elic_steps) == 1
        assert elic_steps[0]["input_preview"] == "Enter value"
        assert elic_steps[0]["output_preview"] == "foo"
        assert elic_steps[0]["duration_ms"] == 3000


class TestV21EventsRegistered:
    def test_all_six_events_in_hook_events(self):
        from infinium_connector.types import HOOK_EVENTS
        for name in (
            "TaskCreated", "CwdChanged", "FileChanged",
            "PermissionDenied", "Elicitation", "ElicitationResult",
        ):
            assert name in HOOK_EVENTS, f"{name} missing from HOOK_EVENTS"

    def test_cli_default_events_includes_v21(self):
        from infinium_connector.cli import _DEFAULT_EVENTS
        for name in (
            "TaskCreated", "CwdChanged", "FileChanged",
            "PermissionDenied", "Elicitation", "ElicitationResult",
        ):
            assert name in _DEFAULT_EVENTS, f"{name} missing from _DEFAULT_EVENTS"
