"""MCP tests module."""
