# flypush (Python)

FlyPush Python server SDK — send push notifications from your backend.

## Installation

```bash
pip install flypush
```

Zero dependencies — uses only the Python standard library.

## Quick start

```python
from flypush import FlyPush
from flypush.models import SendOptions, NotificationTarget

client = FlyPush(api_key="fp_your_api_key")

# Send to all devices
client.notifications.send(SendOptions(
    to=NotificationTarget(type="all"),
    title="Hello!",
    body="Your order has shipped.",
    data={"order_id": "abc123"},
))

# Send to a topic
client.notifications.send(SendOptions(
    to=NotificationTarget(type="topic", topic="breaking-news"),
    title="Breaking News",
    body="Something happened.",
))

# Send to a specific device token
client.notifications.send(SendOptions(
    to=NotificationTarget(type="device", token="device_token_here"),
    title="Personal alert",
    body="Just for you.",
))
```

## Batch send

```python
from flypush.models import BatchItem

client.notifications.send_batch([
    BatchItem(to=NotificationTarget(type="device", token="tok1"), title="Hi Alice", body="..."),
    BatchItem(to=NotificationTarget(type="device", token="tok2"), title="Hi Bob",   body="..."),
])
```

## Device management

```python
from flypush.models import RegisterOptions

device = client.devices.register(RegisterOptions(
    platform="IOS",
    token="apns_token",
    user_id="user_123",
    tags=["premium"],
))

client.devices.update(device["id"], tags=["premium", "beta"])
client.devices.subscribe(device["id"], "sports")
client.devices.unregister(device["id"])
```

## Error handling

```python
from flypush import FlyPushError

try:
    client.notifications.send(...)
except FlyPushError as e:
    print(e.status_code, e.code, str(e))
```

The SDK automatically retries `5xx` errors up to 3 times (2s, 4s, 8s backoff).

## Requirements

Python 3.9+, no third-party dependencies.
