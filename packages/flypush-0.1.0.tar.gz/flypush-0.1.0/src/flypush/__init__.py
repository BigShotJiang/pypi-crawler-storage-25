# FlyPush Python server SDK

from .client import FlyPush, FlyPushError

__all__ = ["FlyPush", "FlyPushError"]
__version__ = "0.1.0"
