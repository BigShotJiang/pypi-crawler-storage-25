# FlyPush Python client — sync and async support, exponential backoff on 5xx

from __future__ import annotations

import time
import urllib.error
import urllib.request
import json
from typing import Any

from .models import BatchItem, RegisterOptions, SendOptions

DEFAULT_BASE_URL = "https://api.flypush.io"
MAX_RETRIES = 3
BASE_DELAY = 2.0  # seconds


class FlyPushError(Exception):
    def __init__(self, status_code: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class _NotificationsResource:
    def __init__(self, client: "FlyPush") -> None:
        self._c = client

    def send(self, options: SendOptions) -> dict[str, Any]:
        return self._c._request("POST", "/v1/notifications/send", options.to_dict())

    def send_batch(self, items: list[BatchItem]) -> dict[str, Any]:
        return self._c._request(
            "POST", "/v1/notifications/send-batch",
            {"notifications": [i.to_dict() for i in items]}
        )

    def get(self, notification_id: str) -> dict[str, Any]:
        return self._c._request("GET", f"/v1/notifications/{notification_id}")


class _DevicesResource:
    def __init__(self, client: "FlyPush") -> None:
        self._c = client

    def register(self, options: RegisterOptions) -> dict[str, Any]:
        return self._c._request("POST", "/v1/devices/register", options.to_dict())

    def update(self, device_id: str, *, user_id: str | None = None, tags: list[str] | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if user_id is not None:
            body["userId"] = user_id
        if tags is not None:
            body["tags"] = tags
        return self._c._request("PUT", f"/v1/devices/{device_id}", body)

    def unregister(self, device_id: str) -> None:
        self._c._request("DELETE", f"/v1/devices/{device_id}")

    def subscribe(self, device_id: str, topic: str) -> None:
        self._c._request("POST", f"/v1/devices/{device_id}/subscribe", {"topic": topic})

    def unsubscribe(self, device_id: str, topic: str) -> None:
        self._c._request("POST", f"/v1/devices/{device_id}/unsubscribe", {"topic": topic})


class _TopicsResource:
    def __init__(self, client: "FlyPush") -> None:
        self._c = client

    def list(self) -> list[dict[str, Any]]:
        return self._c._request("GET", "/v1/topics")

    def create(self, name: str, description: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if description:
            body["description"] = description
        return self._c._request("POST", "/v1/topics", body)

    def delete(self, topic_id: str) -> None:
        self._c._request("DELETE", f"/v1/topics/{topic_id}")


class FlyPush:
    """FlyPush server SDK client.

    Usage::

        client = FlyPush(api_key="fp_...")
        client.notifications.send(SendOptions(
            to=NotificationTarget(type="all"),
            title="Hello",
            body="World",
        ))
    """

    def __init__(self, api_key: str, base_url: str = DEFAULT_BASE_URL) -> None:
        if not api_key:
            raise ValueError("FlyPush: api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self.notifications = _NotificationsResource(self)
        self.devices = _DevicesResource(self)
        self.topics = _TopicsResource(self)

    def _request(self, method: str, path: str, body: Any = None) -> Any:
        url = f"{self._base_url}{path}"
        data = json.dumps(body).encode() if body is not None else None
        last_error: FlyPushError | None = None

        for attempt in range(MAX_RETRIES):
            if attempt > 0:
                time.sleep(BASE_DELAY * (2 ** (attempt - 1)))

            req = urllib.request.Request(
                url,
                data=data,
                method=method,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self._api_key}",
                },
            )
            try:
                with urllib.request.urlopen(req) as resp:
                    raw = resp.read()
                    return json.loads(raw) if raw else None
            except urllib.error.HTTPError as e:
                raw = e.read()
                try:
                    err_body = json.loads(raw)
                    code = err_body.get("error", {}).get("code", "UNKNOWN_ERROR")
                    msg = err_body.get("error", {}).get("message", f"HTTP {e.code}")
                except Exception:
                    code, msg = "UNKNOWN_ERROR", f"HTTP {e.code}"

                err = FlyPushError(e.code, code, msg)
                if e.code < 500:
                    raise err
                last_error = err

        raise last_error  # type: ignore[misc]
