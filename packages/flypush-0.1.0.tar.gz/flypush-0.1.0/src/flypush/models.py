# Request/response data models

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Literal


Platform = Literal["IOS", "ANDROID", "WEB"]
TargetType = Literal["device", "topic", "segment", "all"]


@dataclass
class NotificationTarget:
    type: TargetType
    token: str | None = None
    topic: str | None = None
    segment_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"type": self.type}
        if self.token:
            d["token"] = self.token
        if self.topic:
            d["topic"] = self.topic
        if self.segment_id:
            d["segmentId"] = self.segment_id
        return d


@dataclass
class SendOptions:
    to: NotificationTarget
    title: str
    body: str
    data: dict[str, Any] | None = None
    image_url: str | None = None
    scheduled_at: str | None = None
    platforms: list[Platform] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "to": self.to.to_dict(),
            "title": self.title,
            "body": self.body,
        }
        if self.data:
            d["data"] = self.data
        if self.image_url:
            d["imageUrl"] = self.image_url
        if self.scheduled_at:
            d["scheduledAt"] = self.scheduled_at
        if self.platforms:
            d["platforms"] = self.platforms
        return d


@dataclass
class BatchItem:
    to: NotificationTarget
    title: str
    body: str
    data: dict[str, Any] | None = None
    image_url: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"to": self.to.to_dict(), "title": self.title, "body": self.body}
        if self.data:
            d["data"] = self.data
        if self.image_url:
            d["imageUrl"] = self.image_url
        return d


@dataclass
class RegisterOptions:
    platform: Platform
    token: str
    user_id: str | None = None
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"platform": self.platform, "token": self.token, "tags": self.tags}
        if self.user_id:
            d["userId"] = self.user_id
        if self.metadata:
            d["metadata"] = self.metadata
        return d
