# cloudbrain

**Infrastructure Cost Intelligence CLI** — a safe, read-only scanner that identifies cloud infrastructure waste and generates optimization recommendations.

## What it does

- Scans AWS and Databricks environments using read-only API access
- Identifies idle, underutilized, and misconfigured resources
- Estimates monthly savings potential with current vs recommended configuration
- Prioritizes recommendations by savings impact and risk level
- Scans clusters, SQL warehouses, jobs, Unity Catalog, and compute policies
- Outputs reports to terminal, JSON, or CSV

## Install

```bash
brew install pipx && pipx install cloudbrain-cli
```

## Usage

### Scan Databricks

```bash
cloudbrain scan --provider databricks --workspace-url "https://your-workspace.cloud.databricks.com" --token "dapi..."
```

### Scan AWS

```bash
cloudbrain scan --provider aws --regions us-east-1
```

Note: AWS uses your configured credentials from `~/.aws/credentials` or environment. Run `aws configure` to set up.

### Scan multiple providers

```bash
cloudbrain scan --provider aws --provider databricks --workspace-url "https://your-workspace.cloud.databricks.com" --token "dapi..."
```

### Export reports

After running a scan, save the report without re-scanning:

```bash
cloudbrain export json
cloudbrain export csv
```

Reports are saved to `~/Downloads/`.

### Commands

| Command | Description |
|---------|-------------|
| `cloudbrain scan --provider <name>` | Run a cost scan |
| `cloudbrain export json` | Save last scan as JSON to ~/Downloads |
| `cloudbrain export csv` | Save last scan as CSV to ~/Downloads |
| `cloudbrain init` | Generate default config at ~/.cloudbrain/config.yaml |
| `cloudbrain --version` | Show version |

## What it scans

### Databricks
| Resource | Checks |
|----------|--------|
| Clusters | Idle detection, auto-termination, autoscaling config, oversized drivers |
| SQL Warehouses | Auto-stop config, sizing vs query rate, multi-cluster provisioning |
| Jobs | Failure rates, expensive jobs, long-running jobs, cost per run |
| Unity Catalog | Catalogs, schemas, Delta table optimization, external locations |
| Compute Policies | Missing policies, weak policies, unmanaged clusters |

### AWS
| Resource | Checks |
|----------|--------|
| EC2 | Idle instances (<5% CPU), underutilized instances, rightsizing |
| EBS | Orphaned volumes, old unattached snapshots |
| S3 | Missing lifecycle policies, infrequent access candidates |
| ELB | Load balancers with no healthy targets |
| Elastic IPs | Unassociated IPs |
| NAT Gateways | Low-traffic gateways |

## Pricing methodology

Cost estimates are based on published Databricks and AWS on-demand list pricing:

| Resource | Rate used |
|----------|-----------|
| Databricks All-Purpose Compute | $0.55/DBU-hour (AWS Premium tier) |
| Databricks Jobs Compute | $0.22/DBU-hour (AWS Premium tier) |
| SQL Warehouse | DBU rate × warehouse size in DBUs |
| AWS EC2 | On-demand hourly rate per instance type |
| AWS EBS | Per GB-month by volume type |

Estimates reflect DBU costs only and do not include underlying cloud infrastructure (EC2/VM) costs, which typically add 50-70% on top. Actual costs may differ based on committed-use discounts, reserved instances, or negotiated enterprise pricing.

## Security and privacy

- **Read-only** — never modifies infrastructure
- **Local execution** — all processing on your machine
- **No credential storage** — tokens are used in-memory only, never written to disk
- **No telemetry** — no data sent to external services
- **Scan history** — only scan results (findings, not credentials) are cached locally at `~/.cloudbrain/last_scan.json`

## Configuration

```bash
cloudbrain init
```

Configurable thresholds in `~/.cloudbrain/config.yaml`:

| Setting | Default | Description |
|---------|---------|-------------|
| `observation_window_days` | 90 | How far back to analyze |
| `cpu_idle_percent` | 5 | CPU % below which instance is idle |
| `cpu_underutilized_percent` | 20 | CPU % below which instance needs rightsizing |
| `cluster_idle_minutes` | 30 | Idle time before flagging a cluster |
| `warehouse_low_query_rate` | 5 | Queries/hour below which warehouse is oversized |

## Roadmap

**Next release:**
- Azure support (VMs, AKS, Cosmos DB, Storage Accounts)
- GCP support (Compute Engine, GKE, BigQuery, Cloud Storage)
- Snowflake warehouse optimization
- Historical cost trending and comparison

## Requirements

- Python 3.11+
- AWS credentials (for AWS scanning)
- Databricks Personal Access Token (for Databricks scanning)

## License

MIT
