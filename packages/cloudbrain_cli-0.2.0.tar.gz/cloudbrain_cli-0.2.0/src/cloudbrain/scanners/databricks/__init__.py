"""Databricks scanner module."""

from cloudbrain.scanners.databricks.scanner import DatabricksScanner

__all__ = ["DatabricksScanner"]
