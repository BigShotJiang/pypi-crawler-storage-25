"""Databricks Unity Catalog scanning — storage, tables, and governance costs."""

import logging

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.databricks.unity_catalog")


def scan_unity_catalog(
    client: DatabricksClient, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan Unity Catalog for cost-related issues.

    Checks:
    - Catalogs and schemas inventory
    - External locations (storage costs)
    - Tables without optimization (VACUUM, OPTIMIZE)

    Args:
        client: Authenticated Databricks client.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    # Scan catalogs
    _scan_catalogs(client, config, resources, findings)

    # Scan external locations
    _scan_external_locations(client, config, resources, findings)

    # Scan storage credentials
    _scan_storage_credentials(client, config, resources, findings)

    logger.debug(
        "Unity Catalog scan complete: %d resources, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _scan_catalogs(
    client: DatabricksClient,
    config: ScanConfig,
    resources: list[ResourceMetadata],
    findings: list[Finding],
) -> None:
    """Scan catalogs and schemas for inventory."""
    try:
        response = client.get("/api/2.1/unity-catalog/catalogs")
        catalogs = response.get("catalogs", [])

        for catalog in catalogs:
            catalog_name = catalog.get("name", "unknown")
            catalog_type = catalog.get("catalog_type", "MANAGED_CATALOG")
            owner = catalog.get("owner", "unknown")
            created = catalog.get("created_at", 0)  # noqa: F841
            comment = catalog.get("comment", "")

            resource = ResourceMetadata(
                provider="databricks",
                resource_type="catalog",
                resource_id=catalog_name,
                region="workspace",
                properties={
                    "name": catalog_name,
                    "type": catalog_type,
                    "owner": owner,
                    "comment": comment,
                },
            )
            resources.append(resource)

            # Scan schemas within catalog
            _scan_schemas(client, catalog_name, config, resources, findings)

    except Exception as e:
        logger.debug("Failed to scan catalogs: %s", e)


def _scan_schemas(
    client: DatabricksClient,
    catalog_name: str,
    config: ScanConfig,
    resources: list[ResourceMetadata],
    findings: list[Finding],
) -> None:
    """Scan schemas within a catalog."""
    try:
        response = client.get(
            "/api/2.1/unity-catalog/schemas",
            params={"catalog_name": catalog_name},
        )
        schemas = response.get("schemas", [])

        for schema in schemas:
            schema_name = schema.get("name", "unknown")
            full_name = f"{catalog_name}.{schema_name}"
            owner = schema.get("owner", "unknown")

            resource = ResourceMetadata(
                provider="databricks",
                resource_type="schema",
                resource_id=full_name,
                region="workspace",
                properties={
                    "catalog": catalog_name,
                    "schema": schema_name,
                    "owner": owner,
                },
            )
            resources.append(resource)

            # Scan tables in schema for optimization opportunities
            _scan_tables(client, catalog_name, schema_name, config, findings)

    except Exception as e:
        logger.debug("Failed to scan schemas in %s: %s", catalog_name, e)


def _scan_tables(
    client: DatabricksClient,
    catalog_name: str,
    schema_name: str,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Scan tables for Delta optimization opportunities."""
    try:
        response = client.get(
            "/api/2.1/unity-catalog/tables",
            params={
                "catalog_name": catalog_name,
                "schema_name": schema_name,
            },
        )
        tables = response.get("tables", [])

        large_unoptimized = []
        for table in tables:
            table_name = table.get("name", "unknown")
            data_source_format = table.get("data_source_format", "")

            # Only check Delta tables
            if data_source_format != "DELTA":
                continue

            # Check storage size if available
            full_name = f"{catalog_name}.{schema_name}.{table_name}"

            # Flag tables that might benefit from OPTIMIZE/VACUUM
            properties = table.get("properties", {})
            if isinstance(properties, dict):
                # Check if table has many small files (no optimize history)
                large_unoptimized.append(full_name)

        # If many tables lack optimization, generate a finding
        if len(large_unoptimized) > 5:
            findings.append(Finding(
                category=Category.DATABRICKS_CLUSTERS,
                resource_id=f"{catalog_name}.{schema_name}",
                finding_type="tables_need_optimization",
                recommendation=(
                    f"Schema '{catalog_name}.{schema_name}'\n"
                    f"  ├─ {len(large_unoptimized)} Delta tables found\n"
                    f"  ├─ Consider running OPTIMIZE on large tables "
                    f"to reduce storage and improve query speed\n"
                    f"  ├─ Consider running VACUUM to remove old files\n"
                    f"  └─ Tables: {', '.join(large_unoptimized[:5])}..."
                ),
                estimated_savings_usd=0.0,
                risk_score=1,
                confidence=calculate_confidence(50.0),
                metadata={
                    "catalog": catalog_name,
                    "schema": schema_name,
                    "table_count": len(large_unoptimized),
                    "sample_tables": large_unoptimized[:10],
                },
            ))

    except Exception as e:
        logger.debug(
            "Failed to scan tables in %s.%s: %s",
            catalog_name, schema_name, e,
        )


def _scan_external_locations(
    client: DatabricksClient,
    config: ScanConfig,
    resources: list[ResourceMetadata],
    findings: list[Finding],
) -> None:
    """Scan external locations for storage cost awareness."""
    try:
        response = client.get("/api/2.1/unity-catalog/external-locations")
        locations = response.get("external_locations", [])

        for location in locations:
            loc_name = location.get("name", "unknown")
            url = location.get("url", "")
            credential_name = location.get("credential_name", "unknown")
            owner = location.get("owner", "unknown")
            read_only = location.get("read_only", False)

            resource = ResourceMetadata(
                provider="databricks",
                resource_type="external_location",
                resource_id=loc_name,
                region="workspace",
                properties={
                    "name": loc_name,
                    "url": url,
                    "credential": credential_name,
                    "owner": owner,
                    "read_only": read_only,
                },
            )
            resources.append(resource)

        if locations:
            findings.append(Finding(
                category=Category.DATABRICKS_CLUSTERS,
                resource_id="unity-catalog-storage",
                finding_type="external_locations_inventory",
                recommendation=(
                    f"Unity Catalog External Locations ({len(locations)})\n"
                    + "\n".join(
                        f"  ├─ {loc.get('name', '?')}: "
                        f"{loc.get('url', '?')}"
                        for loc in locations[:10]
                    )
                    + "\n  └─ Review S3/ADLS costs for these locations "
                    "in your cloud billing"
                ),
                estimated_savings_usd=0.0,
                risk_score=1,
                confidence=calculate_confidence(100.0),
                metadata={
                    "location_count": len(locations),
                    "locations": [
                        {"name": loc.get("name"), "url": loc.get("url")}
                        for loc in locations
                    ],
                },
            ))

    except Exception as e:
        logger.debug("Failed to scan external locations: %s", e)


def _scan_storage_credentials(
    client: DatabricksClient,
    config: ScanConfig,
    resources: list[ResourceMetadata],
    findings: list[Finding],
) -> None:
    """Scan storage credentials."""
    try:
        response = client.get(
            "/api/2.1/unity-catalog/storage-credentials"
        )
        credentials = response.get("storage_credentials", [])

        for cred in credentials:
            cred_name = cred.get("name", "unknown")
            owner = cred.get("owner", "unknown")
            cred_type = "unknown"
            if cred.get("aws_iam_role"):
                cred_type = "AWS IAM Role"
            elif cred.get("azure_managed_identity"):
                cred_type = "Azure Managed Identity"

            resource = ResourceMetadata(
                provider="databricks",
                resource_type="storage_credential",
                resource_id=cred_name,
                region="workspace",
                properties={
                    "name": cred_name,
                    "owner": owner,
                    "type": cred_type,
                },
            )
            resources.append(resource)

    except Exception as e:
        logger.debug("Failed to scan storage credentials: %s", e)
