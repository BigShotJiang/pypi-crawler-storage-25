"""Databricks job scanning — cost analysis, failed runs, and efficiency."""

import logging
from datetime import UTC, datetime, timedelta

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.databricks.jobs")

_DBU_PRICE_JOBS = 0.22  # Jobs Compute — AWS Premium tier
_DBU_PRICE_ALL_PURPOSE = 0.55


def scan_jobs(
    client: DatabricksClient, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan Databricks jobs for cost and efficiency issues.

    Args:
        client: Authenticated Databricks client.
        config: Scan configuration with thresholds.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    # Paginate through all jobs
    all_jobs: list[dict] = []
    has_more = True
    offset = 0

    while has_more:
        response = client.get(
            "/api/2.1/jobs/list",
            params={"limit": 25, "offset": offset},
        )
        jobs = response.get("jobs", [])
        all_jobs.extend(jobs)
        has_more = response.get("has_more", False)
        offset += len(jobs)
        if not jobs:
            break

    for job in all_jobs:
        job_id = job.get("job_id", 0)
        settings = job.get("settings", {})
        job_name = settings.get("name", f"job-{job_id}")
        schedule = settings.get("schedule", {})
        creator = job.get("creator_user_name", "unknown")

        # Cluster config
        task_configs = settings.get("tasks", [])
        cluster_info = _extract_cluster_info(settings, task_configs)

        resource = ResourceMetadata(
            provider="databricks",
            resource_type="job",
            resource_id=str(job_id),
            region="workspace",
            properties={
                "job_name": job_name,
                "creator": creator,
                "schedule": schedule,
                "cluster_info": cluster_info,
            },
        )
        resources.append(resource)

        # Analyze recent runs
        _analyze_job_runs(
            client, job_id, job_name, creator, cluster_info, config, findings
        )

    logger.debug(
        "Job scan complete: %d jobs, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _extract_cluster_info(settings: dict, tasks: list[dict]) -> str:
    """Extract cluster configuration summary from job settings."""
    # Check for job clusters
    job_clusters = settings.get("job_clusters", [])
    if job_clusters:
        cluster = job_clusters[0].get("new_cluster", {})
        node_type = cluster.get("node_type_id", "unknown")
        workers = cluster.get("num_workers", 0)
        autoscale = cluster.get("autoscale", {})
        if autoscale:
            return (
                f"{node_type} (autoscale "
                f"{autoscale.get('min_workers', 0)}-"
                f"{autoscale.get('max_workers', 0)})"
            )
        return f"{node_type} × {workers} workers"

    # Check task-level clusters
    if tasks:
        for task in tasks:
            new_cluster = task.get("new_cluster", {})
            if new_cluster:
                node_type = new_cluster.get("node_type_id", "unknown")
                workers = new_cluster.get("num_workers", 0)
                return f"{node_type} × {workers} workers"
            existing = task.get("existing_cluster_id", "")
            if existing:
                return f"existing cluster: {existing[:12]}..."

    return "unknown"


def _analyze_job_runs(
    client: DatabricksClient,
    job_id: int,
    job_name: str,
    creator: str,
    cluster_info: str,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Analyze recent job runs for cost and efficiency issues."""
    try:
        start_time = datetime.now(UTC) - timedelta(
            days=config.observation_window_days
        )
        start_time_ms = int(start_time.timestamp() * 1000)

        runs_response = client.get(
            "/api/2.1/jobs/runs/list",
            params={
                "job_id": job_id,
                "limit": 25,
                "start_time_from": start_time_ms,
            },
        )
        runs = runs_response.get("runs", [])

        if not runs:
            return

        # Categorize runs
        successful_runs = []
        failed_runs = []
        total_duration_s = 0

        for run in runs:
            result_state = run.get("state", {}).get("result_state", "")
            run_duration = run.get("run_duration", 0) / 1000  # ms to seconds

            if result_state == "SUCCESS":
                successful_runs.append(run)
                total_duration_s += run_duration
            elif result_state in ("FAILED", "TIMEDOUT", "CANCELED"):
                failed_runs.append(run)
                total_duration_s += run_duration

        total_runs = len(successful_runs) + len(failed_runs)
        if total_runs == 0:
            return

        # Calculate costs
        avg_duration_hours = (total_duration_s / total_runs) / 3600
        runs_per_month = total_runs * (30 / config.observation_window_days)

        # Estimate cluster size from runs
        num_workers = _get_workers_from_runs(runs)
        total_nodes = num_workers + 1
        cost_per_run = avg_duration_hours * total_nodes * 0.75 * _DBU_PRICE_JOBS
        monthly_cost = round(cost_per_run * runs_per_month, 2)

        # Check for high failure rate
        failure_rate = len(failed_runs) / total_runs if total_runs > 0 else 0
        if failure_rate > 0.2 and len(failed_runs) >= 3:
            wasted_cost = round(monthly_cost * failure_rate, 2)
            findings.append(Finding(
                category=Category.DATABRICKS_JOBS,
                resource_id=str(job_id),
                finding_type="high_failure_rate",
                recommendation=(
                    f"Job '{job_name}' (ID: {job_id})\n"
                    f"  ├─ Creator: {creator}\n"
                    f"  ├─ Cluster: {cluster_info}\n"
                    f"  ├─ Runs in last {config.observation_window_days}d: "
                    f"{total_runs} ({len(failed_runs)} failed)\n"
                    f"  ├─ Failure rate: {failure_rate:.0%}\n"
                    f"  ├─ Wasted compute on failures: "
                    f"~${wasted_cost:.2f}/mo\n"
                    f"  └─ ACTION: Investigate failures, add retries "
                    f"or fix root cause"
                ),
                estimated_savings_usd=wasted_cost,
                risk_score=3,
                confidence=calculate_confidence(80.0),
                metadata={
                    "job_name": job_name,
                    "job_id": job_id,
                    "failure_rate": failure_rate,
                    "failed_runs": len(failed_runs),
                    "total_runs": total_runs,
                },
            ))

        # Check for expensive jobs
        if monthly_cost > 50:
            findings.append(Finding(
                category=Category.DATABRICKS_JOBS,
                resource_id=str(job_id),
                finding_type="expensive_job",
                recommendation=(
                    f"Job '{job_name}' (ID: {job_id})\n"
                    f"  ├─ Creator: {creator}\n"
                    f"  ├─ Cluster: {cluster_info}\n"
                    f"  ├─ Avg duration: {avg_duration_hours:.1f}h\n"
                    f"  ├─ Runs/month: ~{runs_per_month:.0f}\n"
                    f"  ├─ Estimated cost: ${monthly_cost:.2f}/mo\n"
                    f"  ├─ Cost per run: ${cost_per_run:.2f}\n"
                    f"  └─ REVIEW: Consider smaller cluster, "
                    f"optimize Spark code, or reduce frequency"
                ),
                estimated_savings_usd=round(monthly_cost * 0.25, 2),
                risk_score=3,
                confidence=calculate_confidence(70.0),
                metadata={
                    "job_name": job_name,
                    "job_id": job_id,
                    "monthly_cost": monthly_cost,
                    "avg_duration_hours": avg_duration_hours,
                    "runs_per_month": runs_per_month,
                    "cost_per_run": cost_per_run,
                },
            ))

        # Check for long-running jobs
        if avg_duration_hours > 2:
            findings.append(Finding(
                category=Category.DATABRICKS_JOBS,
                resource_id=str(job_id),
                finding_type="long_running_job",
                recommendation=(
                    f"Job '{job_name}' (ID: {job_id})\n"
                    f"  ├─ Avg duration: {avg_duration_hours:.1f} hours\n"
                    f"  ├─ Cluster: {cluster_info}\n"
                    f"  ├─ Cost per run: ${cost_per_run:.2f}\n"
                    f"  └─ REVIEW: Optimize partitioning, caching, "
                    f"or break into smaller tasks"
                ),
                estimated_savings_usd=round(monthly_cost * 0.2, 2),
                risk_score=3,
                confidence=calculate_confidence(60.0),
                metadata={
                    "job_name": job_name,
                    "avg_duration_hours": avg_duration_hours,
                },
            ))

    except Exception as e:
        logger.debug("Failed to analyze runs for job %s: %s", job_id, e)


def _get_workers_from_runs(runs: list[dict]) -> int:
    """Extract worker count from run cluster spec."""
    for run in runs:
        cluster_spec = run.get("cluster_spec", {})
        if cluster_spec:
            return cluster_spec.get("num_workers", 2)
        # Check task-level
        tasks = run.get("tasks", [])
        for task in tasks:
            new_cluster = task.get("new_cluster", {})
            if new_cluster:
                return new_cluster.get("num_workers", 2)
    return 2  # Default assumption
