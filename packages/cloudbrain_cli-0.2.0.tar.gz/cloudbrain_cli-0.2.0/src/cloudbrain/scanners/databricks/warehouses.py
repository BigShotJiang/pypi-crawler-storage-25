"""Databricks SQL Warehouse scanning — idle detection and sizing analysis."""

import logging

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.databricks.warehouses")

# Approximate cost per hour by warehouse size (USD)
# Based on Databricks SQL Classic pricing (DBU rate × DBUs consumed)
# These are approximate — actual cost depends on tier and region
_WAREHOUSE_SIZE_COST = {
    "2X-Small": 0.44,   # ~2 DBU × $0.22
    "X-Small": 0.88,    # ~4 DBU × $0.22
    "Small": 1.76,      # ~8 DBU × $0.22
    "Medium": 3.52,     # ~16 DBU × $0.22
    "Large": 7.04,      # ~32 DBU × $0.22
    "X-Large": 14.08,   # ~64 DBU × $0.22
    "2X-Large": 28.16,  # ~128 DBU × $0.22
    "3X-Large": 42.24,  # ~192 DBU × $0.22
    "4X-Large": 56.32,  # ~256 DBU × $0.22
}

# Size downgrade map
_SIZE_DOWNGRADE = {
    "4X-Large": "3X-Large",
    "3X-Large": "2X-Large",
    "2X-Large": "X-Large",
    "X-Large": "Large",
    "Large": "Medium",
    "Medium": "Small",
    "Small": "X-Small",
    "X-Small": "2X-Small",
}


def _get_warehouse_hourly_cost(size: str) -> float:
    """Get approximate hourly cost for a warehouse size."""
    return _WAREHOUSE_SIZE_COST.get(size, 4.00)


def scan_warehouses(
    client: DatabricksClient, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan SQL warehouses for idle time and sizing inefficiencies.

    Args:
        client: Authenticated Databricks client.
        config: Scan configuration with thresholds.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    response = client.get("/api/2.0/sql/warehouses")
    warehouses = response.get("warehouses", [])

    for warehouse in warehouses:
        warehouse_id = warehouse.get("id", "unknown")
        warehouse_name = warehouse.get("name", "unnamed")
        size = warehouse.get("cluster_size", "unknown")
        state = warehouse.get("state", "UNKNOWN")
        auto_stop_mins = warehouse.get("auto_stop_mins", 0)
        num_clusters = warehouse.get("num_clusters", 1)
        max_num_clusters = warehouse.get("max_num_clusters", 1)
        warehouse_type = warehouse.get("warehouse_type", "CLASSIC")
        creator = warehouse.get("creator_name", "unknown")
        spot_policy = warehouse.get("spot_instance_policy", "COST_OPTIMIZED")

        resource = ResourceMetadata(
            provider="databricks",
            resource_type="sql_warehouse",
            resource_id=warehouse_id,
            region="workspace",
            properties={
                "name": warehouse_name,
                "size": size,
                "state": state,
                "auto_stop_mins": auto_stop_mins,
                "num_clusters": num_clusters,
                "max_num_clusters": max_num_clusters,
                "warehouse_type": warehouse_type,
                "creator": creator,
                "spot_policy": spot_policy,
            },
        )
        resources.append(resource)

        # Check auto-stop configuration
        _check_auto_stop(warehouse, config, findings)

        # Check sizing
        _check_warehouse_sizing(client, warehouse, config, findings)

        # Check multi-cluster config
        _check_multi_cluster(warehouse, config, findings)

    logger.debug(
        "Warehouse scan complete: %d warehouses, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _check_auto_stop(
    warehouse: dict,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check auto-stop configuration."""
    auto_stop_mins = warehouse.get("auto_stop_mins", 0)
    warehouse_id = warehouse.get("id", "unknown")
    warehouse_name = warehouse.get("name", "unnamed")
    size = warehouse.get("cluster_size", "unknown")
    state = warehouse.get("state", "UNKNOWN")
    hourly_cost = _get_warehouse_hourly_cost(size)

    if auto_stop_mins == 0:
        findings.append(Finding(
            category=Category.DATABRICKS_WAREHOUSES,
            resource_id=warehouse_id,
            finding_type="warehouse_no_auto_stop",
            recommendation=(
                f"SQL Warehouse '{warehouse_name}' (ID: {warehouse_id})\n"
                f"  ├─ State: {state} | Size: {size}\n"
                f"  ├─ Cost: ${hourly_cost:.2f}/hr "
                f"(${hourly_cost * 730:.2f}/mo if always on)\n"
                f"  ├─ Auto-stop: DISABLED ⚠️\n"
                f"  ├─ CURRENT CONFIG: auto_stop_mins = 0\n"
                f"  └─ RECOMMENDED: auto_stop_mins = 10"
            ),
            estimated_savings_usd=round(hourly_cost * 730 * 0.4, 2),
            risk_score=2,
            confidence=calculate_confidence(100.0),
            metadata={
                "warehouse_name": warehouse_name,
                "warehouse_id": warehouse_id,
                "size": size,
                "state": state,
                "current_config": "auto_stop_mins = 0",
                "recommended_config": "auto_stop_mins = 10",
            },
        ))
    elif auto_stop_mins > 30:
        # Auto-stop is set but too long
        savings_per_hour = hourly_cost
        extra_idle_hours = (auto_stop_mins - 10) / 60
        # Assume warehouse stops ~5 times per day
        daily_waste = extra_idle_hours * savings_per_hour * 5
        monthly_waste = round(daily_waste * 30, 2)

        if monthly_waste > 50:
            findings.append(Finding(
                category=Category.DATABRICKS_WAREHOUSES,
                resource_id=warehouse_id,
                finding_type="auto_stop_too_long",
                recommendation=(
                    f"SQL Warehouse '{warehouse_name}' "
                    f"(ID: {warehouse_id})\n"
                    f"  ├─ Size: {size} | Cost: ${hourly_cost:.2f}/hr\n"
                    f"  ├─ CURRENT CONFIG: auto_stop_mins = "
                    f"{auto_stop_mins}\n"
                    f"  ├─ Wasting ~${monthly_waste:.2f}/mo in idle time\n"
                    f"  └─ RECOMMENDED: auto_stop_mins = 10"
                ),
                estimated_savings_usd=monthly_waste,
                risk_score=1,
                confidence=calculate_confidence(70.0),
                metadata={
                    "warehouse_name": warehouse_name,
                    "warehouse_id": warehouse_id,
                    "current_config": (
                        f"auto_stop_mins = {auto_stop_mins}"
                    ),
                    "recommended_config": "auto_stop_mins = 10",
                },
            ))


def _check_warehouse_sizing(
    client: DatabricksClient,
    warehouse: dict,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if a warehouse is oversized based on query rate."""
    warehouse_id = warehouse.get("id", "unknown")
    warehouse_name = warehouse.get("name", "unnamed")
    size = warehouse.get("cluster_size", "unknown")
    state = warehouse.get("state", "UNKNOWN")

    if state not in ("RUNNING", "STOPPED"):
        return

    try:
        history = client.get(
            "/api/2.0/sql/history/queries",
            params={
                "filter_by.warehouse_ids": warehouse_id,
                "max_results": 100,
            },
        )
        queries = history.get("res", [])

        if not queries:
            if state == "RUNNING":
                hourly_cost = _get_warehouse_hourly_cost(size)
                findings.append(Finding(
                    category=Category.DATABRICKS_WAREHOUSES,
                    resource_id=warehouse_id,
                    finding_type="warehouse_no_queries",
                    recommendation=(
                        f"SQL Warehouse '{warehouse_name}' "
                        f"(ID: {warehouse_id})\n"
                        f"  ├─ State: RUNNING | Size: {size}\n"
                        f"  ├─ No queries found in recent API history\n"
                        f"  ├─ Cost while running: "
                        f"${hourly_cost:.2f}/hr (DBU only)\n"
                        f"  ├─ NOTE: Verify in Databricks UI query "
                        f"history — API may not show all queries\n"
                        f"  └─ ACTION: Stop warehouse if confirmed unused"
                    ),
                    estimated_savings_usd=round(hourly_cost * 730, 2),
                    risk_score=3,
                    confidence=calculate_confidence(50.0),
                    metadata={
                        "warehouse_name": warehouse_name,
                        "warehouse_id": warehouse_id,
                        "size": size,
                        "note": (
                            "Query history API may not capture all "
                            "queries. Verify in Databricks UI."
                        ),
                    },
                ))
            return

        # Check if warehouse is oversized
        observation_hours = config.observation_window_days * 24
        queries_per_hour = len(queries) / max(observation_hours, 1)

        if queries_per_hour < config.thresholds.warehouse_low_query_rate:
            current_cost = _get_warehouse_hourly_cost(size)
            smaller_size = _SIZE_DOWNGRADE.get(size)
            if smaller_size:
                smaller_cost = _get_warehouse_hourly_cost(smaller_size)
                monthly_savings = round(
                    (current_cost - smaller_cost) * 730, 2
                )

                findings.append(Finding(
                    category=Category.DATABRICKS_WAREHOUSES,
                    resource_id=warehouse_id,
                    finding_type="oversized_warehouse",
                    recommendation=(
                        f"SQL Warehouse '{warehouse_name}' "
                        f"(ID: {warehouse_id})\n"
                        f"  ├─ Size: {size} | "
                        f"Queries: {queries_per_hour:.1f}/hr\n"
                        f"  ├─ CURRENT CONFIG: cluster_size = {size} "
                        f"(${current_cost:.2f}/hr)\n"
                        f"  ├─ RECOMMENDED: cluster_size = {smaller_size} "
                        f"(${smaller_cost:.2f}/hr)\n"
                        f"  └─ ESTIMATED SAVINGS: ${monthly_savings:.2f}/mo"
                    ),
                    estimated_savings_usd=monthly_savings,
                    risk_score=3,
                    confidence=calculate_confidence(50.0),
                    metadata={
                        "warehouse_name": warehouse_name,
                        "warehouse_id": warehouse_id,
                        "current_size": size,
                        "recommended_size": smaller_size,
                        "queries_per_hour": queries_per_hour,
                        "current_config": f"cluster_size = {size}",
                        "recommended_config": (
                            f"cluster_size = {smaller_size}"
                        ),
                    },
                ))
    except Exception as e:
        logger.debug(
            "Failed to analyze warehouse sizing for %s: %s",
            warehouse_id, e,
        )


def _check_multi_cluster(
    warehouse: dict,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if multi-cluster is configured but likely unnecessary."""
    max_clusters = warehouse.get("max_num_clusters", 1)
    if max_clusters <= 1:
        return

    warehouse_id = warehouse.get("id", "unknown")
    warehouse_name = warehouse.get("name", "unnamed")
    size = warehouse.get("cluster_size", "unknown")
    hourly_cost = _get_warehouse_hourly_cost(size)

    # Multi-cluster with max > 3 is often over-provisioned
    if max_clusters > 3:
        extra_cost = round(
            hourly_cost * (max_clusters - 2) * 730 * 0.2, 2
        )
        findings.append(Finding(
            category=Category.DATABRICKS_WAREHOUSES,
            resource_id=warehouse_id,
            finding_type="high_max_clusters",
            recommendation=(
                f"SQL Warehouse '{warehouse_name}' "
                f"(ID: {warehouse_id})\n"
                f"  ├─ Size: {size} | "
                f"Max clusters: {max_clusters}\n"
                f"  ├─ Each additional cluster costs "
                f"${hourly_cost:.2f}/hr when active\n"
                f"  ├─ CURRENT CONFIG: max_num_clusters = "
                f"{max_clusters}\n"
                f"  └─ REVIEW: Do you actually need {max_clusters} "
                f"concurrent clusters?"
            ),
            estimated_savings_usd=extra_cost,
            risk_score=3,
            confidence=calculate_confidence(50.0),
            metadata={
                "warehouse_name": warehouse_name,
                "warehouse_id": warehouse_id,
                "max_clusters": max_clusters,
            },
        ))
