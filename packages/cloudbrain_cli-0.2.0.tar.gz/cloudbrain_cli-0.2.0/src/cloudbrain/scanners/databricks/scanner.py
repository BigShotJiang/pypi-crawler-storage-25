"""Databricks Scanner orchestrator — coordinates all Databricks scans."""

import logging
from datetime import UTC, datetime

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.errors import ScanWarning
from cloudbrain.scanners.base import BaseScanner, ScanResult
from cloudbrain.scanners.databricks.clusters import scan_clusters
from cloudbrain.scanners.databricks.compute_policies import scan_compute_policies
from cloudbrain.scanners.databricks.jobs import scan_jobs
from cloudbrain.scanners.databricks.unity_catalog import scan_unity_catalog
from cloudbrain.scanners.databricks.warehouses import scan_warehouses

logger = logging.getLogger("cloudbrain.scanners.databricks")
console = Console()


class DatabricksScanner(BaseScanner):
    """Scans Databricks workspace for cost optimization opportunities."""

    def __init__(self, client: DatabricksClient) -> None:
        self._client = client

    def provider_name(self) -> str:
        return "databricks"

    def scan(self, config: ScanConfig) -> ScanResult:
        """Execute full Databricks scan with progress indicator."""
        result = ScanResult(provider="databricks")

        console.print(
            f"\n[bold blue]Scanning Databricks workspace:[/bold blue] "
            f"{self._client.workspace_url}\n"
        )

        scan_steps = [
            ("Clusters", lambda: scan_clusters(self._client, config)),
            ("SQL Warehouses", lambda: scan_warehouses(self._client, config)),
            ("Jobs & Runs", lambda: scan_jobs(self._client, config)),
            ("Unity Catalog", lambda: scan_unity_catalog(self._client, config)),
            ("Compute Policies", lambda: scan_compute_policies(self._client, config)),
        ]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=30),
            MofNCompleteColumn(),
            TextColumn("[cyan]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            overall = progress.add_task(
                "Scanning...", total=len(scan_steps)
            )

            for step_name, scan_fn in scan_steps:
                progress.update(
                    overall,
                    description=f"Scanning {step_name}",
                )
                self._run_scan(result, step_name, scan_fn)
                progress.advance(overall)

            progress.update(
                overall,
                description="[bold green]✓ Databricks scan complete",
            )

        console.print()
        return result

    def _run_scan(
        self,
        result: ScanResult,
        resource_type: str,
        scan_fn: object,
    ) -> None:
        """Run a scan function safely, capturing errors as warnings."""
        try:
            resources, metrics, findings = scan_fn()  # type: ignore[operator]
            result.resources.extend(resources)
            result.metrics.update(metrics)
            result.findings.extend(findings)
            logger.debug(
                "Scanned %s: %d resources, %d findings",
                resource_type, len(resources), len(findings),
            )
        except Exception as e:
            logger.warning("Failed to scan %s: %s", resource_type, e)
            result.warnings.append(
                ScanWarning(
                    provider="databricks",
                    resource_type=resource_type,
                    reason=str(e),
                    timestamp=datetime.now(UTC).isoformat(),
                )
            )
