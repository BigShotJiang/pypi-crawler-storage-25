"""Databricks compute policies scanning — governance and cost control."""

import logging

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.databricks.compute_policies")


def scan_compute_policies(
    client: DatabricksClient, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan compute/cluster policies for cost governance gaps.

    Checks:
    - Whether policies exist at all
    - Policy configurations (max workers, auto-termination enforcement)
    - Clusters running without policies

    Args:
        client: Authenticated Databricks client.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    # Get all policies
    policies = _get_policies(client)

    if not policies:
        findings.append(Finding(
            category=Category.DATABRICKS_CLUSTERS,
            resource_id="workspace-policies",
            finding_type="no_compute_policies",
            recommendation=(
                "No compute policies found in workspace\n"
                "  ├─ Without policies, users can create clusters "
                "of any size\n"
                "  ├─ This leads to uncontrolled spending\n"
                "  ├─ RECOMMENDED: Create policies that enforce:\n"
                "  │   • Max workers limit (e.g., 10)\n"
                "  │   • Auto-termination enabled (e.g., 30 min)\n"
                "  │   • Approved instance types only\n"
                "  └─ See: Databricks Admin Console → Compute Policies"
            ),
            estimated_savings_usd=0.0,
            risk_score=4,
            confidence=calculate_confidence(100.0),
            metadata={"issue": "no_policies_defined"},
        ))
    else:
        for policy in policies:
            policy_id = policy.get("policy_id", "unknown")
            policy_name = policy.get("name", "unnamed")
            definition = policy.get("definition", "{}")
            creator = policy.get("creator_user_name", "unknown")

            resource = ResourceMetadata(
                provider="databricks",
                resource_type="compute_policy",
                resource_id=policy_id,
                region="workspace",
                properties={
                    "name": policy_name,
                    "creator": creator,
                    "definition": definition,
                },
            )
            resources.append(resource)

            # Analyze policy for cost control gaps
            _analyze_policy(policy, config, findings)

    # Check for clusters without policies
    _check_clusters_without_policies(client, config, findings)

    logger.debug(
        "Compute policies scan: %d policies, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _get_policies(client: DatabricksClient) -> list[dict]:
    """Get all cluster policies."""
    try:
        response = client.get("/api/2.0/policies/clusters/list")
        return response.get("policies", [])
    except Exception as e:
        logger.debug("Failed to list policies: %s", e)
        return []


def _analyze_policy(
    policy: dict,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Analyze a policy for cost control gaps."""
    policy_id = policy.get("policy_id", "unknown")
    policy_name = policy.get("name", "unnamed")
    definition = policy.get("definition", "")

    # Parse definition (it's a JSON string)
    import json

    try:
        if isinstance(definition, str):
            rules = json.loads(definition) if definition else {}
        else:
            rules = definition
    except json.JSONDecodeError:
        rules = {}

    issues = []

    # Check if auto-termination is enforced
    auto_term_rule = rules.get("autotermination_minutes", {})
    if not auto_term_rule:
        issues.append(
            "No auto-termination enforcement "
            "(users can disable it)"
        )

    # Check if max workers is limited
    num_workers_rule = rules.get("num_workers", {})
    autoscale_max = rules.get("autoscale.max_workers", {})
    if not num_workers_rule and not autoscale_max:
        issues.append(
            "No max worker limit "
            "(users can create very large clusters)"
        )

    # Check if instance types are restricted
    node_type_rule = rules.get("node_type_id", {})
    if not node_type_rule:
        issues.append(
            "No instance type restriction "
            "(users can pick expensive instance types)"
        )

    if issues:
        findings.append(Finding(
            category=Category.DATABRICKS_CLUSTERS,
            resource_id=policy_id,
            finding_type="weak_compute_policy",
            recommendation=(
                f"Compute Policy '{policy_name}' "
                f"(ID: {policy_id})\n"
                f"  ├─ Missing cost controls:\n"
                + "\n".join(f"  │   • {issue}" for issue in issues)
                + "\n  └─ RECOMMENDED: Add restrictions to prevent "
                "cost overruns"
            ),
            estimated_savings_usd=0.0,
            risk_score=3,
            confidence=calculate_confidence(100.0),
            metadata={
                "policy_name": policy_name,
                "policy_id": policy_id,
                "issues": issues,
            },
        ))


def _check_clusters_without_policies(
    client: DatabricksClient,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if any clusters are running without a policy."""
    try:
        response = client.get("/api/2.0/clusters/list")
        clusters = response.get("clusters", [])

        no_policy_clusters = []
        for cluster in clusters:
            policy_id = cluster.get("policy_id")
            cluster_source = cluster.get("cluster_source", "")

            # Skip job clusters (they're managed differently)
            if cluster_source == "JOB":
                continue

            if not policy_id:
                no_policy_clusters.append({
                    "name": cluster.get("cluster_name", "unnamed"),
                    "id": cluster.get("cluster_id", "unknown"),
                    "state": cluster.get("state", "UNKNOWN"),
                })

        if no_policy_clusters:
            cluster_list = "\n".join(
                f"  │   • {c['name']} ({c['state']})"
                for c in no_policy_clusters[:10]
            )
            findings.append(Finding(
                category=Category.DATABRICKS_CLUSTERS,
                resource_id="clusters-no-policy",
                finding_type="clusters_without_policy",
                recommendation=(
                    f"{len(no_policy_clusters)} cluster(s) running "
                    f"without a compute policy\n"
                    f"  ├─ These clusters have no cost guardrails:\n"
                    f"{cluster_list}\n"
                    f"  └─ RECOMMENDED: Assign a compute policy to "
                    f"enforce cost limits"
                ),
                estimated_savings_usd=0.0,
                risk_score=3,
                confidence=calculate_confidence(100.0),
                metadata={
                    "clusters": no_policy_clusters,
                    "count": len(no_policy_clusters),
                },
            ))

    except Exception as e:
        logger.debug("Failed to check clusters without policies: %s", e)
