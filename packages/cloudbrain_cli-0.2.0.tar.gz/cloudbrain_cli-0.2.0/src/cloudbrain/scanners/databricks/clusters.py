"""Databricks cluster scanning — idle detection and configuration analysis."""

import logging
from datetime import UTC, datetime

from cloudbrain.auth.databricks import DatabricksClient
from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.pricing import PricingEngine
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.databricks.clusters")

_pricing = PricingEngine()

# Approximate DBU costs per hour by tier (USD) — AWS Premium tier
# Source: Databricks published pricing (2025/2026)
_DBU_PRICE_JOBS = 0.22  # Jobs Compute
_DBU_PRICE_ALL_PURPOSE = 0.55  # All-Purpose / Interactive
_DBU_PRICE_DLT = 0.36  # Delta Live Tables (approximate)

# Approximate DBU/hour by instance type (common ones)
_INSTANCE_DBU_MAP = {
    "i3.xlarge": 1.0,
    "i3.2xlarge": 2.0,
    "i3.4xlarge": 4.0,
    "m5.large": 0.5,
    "m5.xlarge": 1.0,
    "m5.2xlarge": 2.0,
    "m5.4xlarge": 4.0,
    "m5d.large": 0.5,
    "m5d.xlarge": 1.0,
    "m5d.2xlarge": 2.0,
    "r5.large": 0.5,
    "r5.xlarge": 1.0,
    "r5.2xlarge": 2.0,
    "c5.xlarge": 0.75,
    "c5.2xlarge": 1.5,
    "c5.4xlarge": 3.0,
    "m4.large": 0.5,
    "m4.xlarge": 1.0,
    "m4.2xlarge": 2.0,
    "r4.xlarge": 1.0,
    "r4.2xlarge": 2.0,
}


def _get_dbu_rate(node_type: str) -> float:
    """Get DBU/hour rate for a node type."""
    return _INSTANCE_DBU_MAP.get(node_type, 0.75)  # Default 0.75 DBU/hr


def _estimate_cluster_hourly_cost(
    node_type: str, num_workers: int, is_all_purpose: bool = True
) -> float:
    """Estimate hourly DBU cost for a cluster.

    Args:
        node_type: Worker node type.
        num_workers: Number of worker nodes.
        is_all_purpose: True for interactive/all-purpose, False for jobs.

    Returns:
        Estimated hourly cost in USD.
    """
    dbu_per_node = _get_dbu_rate(node_type)
    total_nodes = num_workers + 1  # workers + driver
    total_dbu_per_hour = total_nodes * dbu_per_node
    price_per_dbu = _DBU_PRICE_ALL_PURPOSE if is_all_purpose else _DBU_PRICE_JOBS
    return total_dbu_per_hour * price_per_dbu


def scan_clusters(
    client: DatabricksClient, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan Databricks clusters for idle time and inefficient configurations.

    Args:
        client: Authenticated Databricks client.
        config: Scan configuration with thresholds.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    response = client.get("/api/2.0/clusters/list")
    clusters = response.get("clusters", [])

    for cluster in clusters:
        cluster_id = cluster.get("cluster_id", "unknown")
        cluster_name = cluster.get("cluster_name", "unnamed")
        state = cluster.get("state", "UNKNOWN")
        node_type = cluster.get("node_type_id", "unknown")
        driver_node_type = cluster.get("driver_node_type_id", node_type)
        spark_version = cluster.get("spark_version", "unknown")
        creator = cluster.get("creator_user_name", "unknown")

        # Autoscaling config
        autoscale = cluster.get("autoscale", {})
        num_workers = cluster.get("num_workers", 0)
        min_workers = autoscale.get("min_workers", num_workers)
        max_workers = autoscale.get("max_workers", num_workers)

        # Auto-termination
        auto_termination_minutes = cluster.get("autotermination_minutes", 0)

        # Cluster source (UI, JOB, API)
        cluster_source = cluster.get("cluster_source", "UNKNOWN")

        # Start time
        start_time_ms = cluster.get("start_time", 0)
        start_time_str = ""
        if start_time_ms:
            start_time_str = datetime.fromtimestamp(
                start_time_ms / 1000, tz=UTC
            ).strftime("%Y-%m-%d %H:%M UTC")

        resource = ResourceMetadata(
            provider="databricks",
            resource_type="cluster",
            resource_id=cluster_id,
            region="workspace",
            tags=_extract_tags(cluster),
            properties={
                "cluster_name": cluster_name,
                "state": state,
                "node_type": node_type,
                "driver_node_type": driver_node_type,
                "min_workers": min_workers,
                "max_workers": max_workers,
                "num_workers": num_workers,
                "auto_termination_minutes": auto_termination_minutes,
                "spark_version": spark_version,
                "creator": creator,
                "cluster_source": cluster_source,
                "start_time": start_time_str,
            },
        )
        resources.append(resource)

        # Skip job clusters — they're ephemeral and managed by the job
        # scheduler. Auto-termination doesn't apply to them.
        if cluster_source == "JOB":
            continue

        # Analyze interactive/all-purpose clusters only
        if state == "RUNNING":
            _check_idle_cluster(client, cluster, resource, config, findings)

        # Config checks for non-job clusters
        _check_auto_termination(cluster, resource, config, findings)
        _check_autoscale_config(cluster, resource, config, findings)
        _check_oversized_driver(cluster, resource, config, findings)

    logger.debug(
        "Cluster scan complete: %d clusters, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _check_idle_cluster(
    client: DatabricksClient,
    cluster: dict,
    resource: ResourceMetadata,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if a running cluster is idle (no active jobs)."""
    cluster_id = cluster.get("cluster_id", "")
    cluster_name = cluster.get("cluster_name", "unnamed")
    node_type = cluster.get("node_type_id", "unknown")

    last_activity_time = cluster.get("last_activity_time")
    if not last_activity_time:
        return

    last_activity = datetime.fromtimestamp(last_activity_time / 1000, tz=UTC)
    now = datetime.now(UTC)
    idle_minutes = (now - last_activity).total_seconds() / 60

    if idle_minutes <= config.thresholds.cluster_idle_minutes:
        return

    # Calculate cost
    num_workers = cluster.get("num_workers", 0)
    autoscale = cluster.get("autoscale", {})
    worker_count = autoscale.get("min_workers", num_workers) or num_workers
    hourly_cost = _estimate_cluster_hourly_cost(node_type, worker_count)
    idle_hours = idle_minutes / 60
    wasted_so_far = round(hourly_cost * idle_hours, 2)
    monthly_cost = round(hourly_cost * 730, 2)

    auto_term = cluster.get("autotermination_minutes", 0)
    auto_term_str = (
        f"{auto_term} min" if auto_term > 0 else "DISABLED"
    )

    findings.append(Finding(
        category=Category.DATABRICKS_CLUSTERS,
        resource_id=cluster_id,
        finding_type="idle_cluster",
        recommendation=(
            f"Cluster '{cluster_name}' (ID: {cluster_id})\n"
            f"  ├─ State: RUNNING (idle for {idle_minutes:.0f} min)\n"
            f"  ├─ Node type: {node_type} × {worker_count} workers\n"
            f"  ├─ Auto-termination: {auto_term_str}\n"
            f"  ├─ Hourly cost: ${hourly_cost:.2f}/hr "
            f"(DBU only, excludes EC2)\n"
            f"  ├─ Wasted so far this idle period: ${wasted_so_far:.2f}\n"
            f"  └─ ACTION: Terminate now or set auto-termination to 30 min"
        ),
        estimated_savings_usd=wasted_so_far,
        risk_score=2,
        confidence=calculate_confidence(100.0),
        metadata={
            "cluster_name": cluster_name,
            "cluster_id": cluster_id,
            "idle_minutes": round(idle_minutes),
            "node_type": node_type,
            "workers": worker_count,
            "hourly_cost": hourly_cost,
            "monthly_cost_if_always_on": monthly_cost,
            "wasted_this_session": wasted_so_far,
            "auto_termination": auto_term_str,
            "note": "DBU cost only. EC2 infrastructure cost is additional.",
            "tags": resource.tags,
        },
    ))


def _check_auto_termination(
    cluster: dict,
    resource: ResourceMetadata,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if auto-termination is disabled on an interactive cluster."""
    auto_term = cluster.get("autotermination_minutes", 0)
    if auto_term > 0:
        return

    state = cluster.get("state", "UNKNOWN")
    # Only flag running or recently active clusters — terminated ones
    # without auto-term are a config risk but not actively costing money
    if state not in ("RUNNING", "PENDING", "RESTARTING"):
        return

    cluster_id = cluster.get("cluster_id", "")
    cluster_name = cluster.get("cluster_name", "unnamed")
    node_type = cluster.get("node_type_id", "unknown")
    num_workers = cluster.get("num_workers", 0)
    autoscale = cluster.get("autoscale", {})
    worker_count = autoscale.get("min_workers", num_workers) or num_workers

    hourly_cost = _estimate_cluster_hourly_cost(node_type, worker_count)

    findings.append(Finding(
        category=Category.DATABRICKS_CLUSTERS,
        resource_id=cluster_id,
        finding_type="no_auto_termination",
        recommendation=(
            f"Cluster '{cluster_name}' (ID: {cluster_id})\n"
            f"  ├─ State: {state}\n"
            f"  ├─ Node type: {node_type} × {worker_count} workers\n"
            f"  ├─ Auto-termination: DISABLED ⚠️\n"
            f"  ├─ Risk: Cluster stays running indefinitely when idle\n"
            f"  ├─ Cost if left running: ${hourly_cost:.2f}/hr "
            f"(${hourly_cost * 730:.2f}/mo)\n"
            f"  ├─ CURRENT CONFIG: autotermination_minutes = 0\n"
            f"  └─ RECOMMENDED: autotermination_minutes = 30"
        ),
        estimated_savings_usd=round(hourly_cost * 730 * 0.3, 2),
        risk_score=2,
        confidence=calculate_confidence(100.0),
        metadata={
            "cluster_name": cluster_name,
            "cluster_id": cluster_id,
            "state": state,
            "current_config": "autotermination_minutes = 0",
            "recommended_config": "autotermination_minutes = 30",
            "tags": resource.tags,
        },
    ))


def _check_autoscale_config(
    cluster: dict,
    resource: ResourceMetadata,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check autoscaling configuration for inefficiencies."""
    # Only check running/pending clusters for config issues
    state = cluster.get("state", "UNKNOWN")
    if state not in ("RUNNING", "PENDING", "RESTARTING", "TERMINATED"):
        return

    autoscale = cluster.get("autoscale", {})
    if not autoscale:
        # Fixed-size cluster — check if it should use autoscaling
        num_workers = cluster.get("num_workers", 0)
        if num_workers >= 4:
            cluster_id = cluster.get("cluster_id", "")
            cluster_name = cluster.get("cluster_name", "unnamed")
            node_type = cluster.get("node_type_id", "unknown")

            fixed_cost = _estimate_cluster_hourly_cost(
                node_type, num_workers
            )
            # With autoscale min=1, max=current, avg ~50% usage
            autoscale_cost = _estimate_cluster_hourly_cost(
                node_type, max(1, num_workers // 2)
            )
            savings = round((fixed_cost - autoscale_cost) * 730, 2)

            findings.append(Finding(
                category=Category.DATABRICKS_CLUSTERS,
                resource_id=cluster_id,
                finding_type="no_autoscaling",
                recommendation=(
                    f"Cluster '{cluster_name}' (ID: {cluster_id})\n"
                    f"  ├─ Node type: {node_type}\n"
                    f"  ├─ CURRENT CONFIG: Fixed {num_workers} workers "
                    f"(${fixed_cost:.2f}/hr)\n"
                    f"  ├─ RECOMMENDED: Enable autoscaling "
                    f"min=1, max={num_workers}\n"
                    f"  └─ ESTIMATED SAVINGS: ${savings:.2f}/mo "
                    f"(assuming ~50% avg utilization)"
                ),
                estimated_savings_usd=savings,
                risk_score=2,
                confidence=calculate_confidence(70.0),
                metadata={
                    "cluster_name": cluster_name,
                    "cluster_id": cluster_id,
                    "current_config": f"num_workers = {num_workers}",
                    "recommended_config": (
                        f"autoscale: min_workers=1, "
                        f"max_workers={num_workers}"
                    ),
                    "tags": resource.tags,
                },
            ))
        return

    # Has autoscaling — check min_workers
    min_workers = autoscale.get("min_workers", 0)
    max_workers = autoscale.get("max_workers", 0)

    if min_workers > 0 and min_workers == max_workers:
        # Autoscale range is 0 — effectively fixed size
        cluster_id = cluster.get("cluster_id", "")
        cluster_name = cluster.get("cluster_name", "unnamed")
        node_type = cluster.get("node_type_id", "unknown")

        findings.append(Finding(
            category=Category.DATABRICKS_CLUSTERS,
            resource_id=cluster_id,
            finding_type="autoscale_no_range",
            recommendation=(
                f"Cluster '{cluster_name}' (ID: {cluster_id})\n"
                f"  ├─ CURRENT CONFIG: autoscale "
                f"min={min_workers}, max={max_workers} (no range!)\n"
                f"  ├─ This is effectively a fixed-size cluster\n"
                f"  └─ RECOMMENDED: Set min_workers=1 or 0 to allow "
                f"scale-down"
            ),
            estimated_savings_usd=0.0,
            risk_score=2,
            confidence=calculate_confidence(100.0),
            metadata={
                "cluster_name": cluster_name,
                "cluster_id": cluster_id,
                "current_config": (
                    f"autoscale: min={min_workers}, max={max_workers}"
                ),
                "recommended_config": (
                    f"autoscale: min=1, max={max_workers}"
                ),
                "tags": resource.tags,
            },
        ))


def _check_oversized_driver(
    cluster: dict,
    resource: ResourceMetadata,
    config: ScanConfig,
    findings: list[Finding],
) -> None:
    """Check if driver node is larger than worker nodes (usually unnecessary)."""
    node_type = cluster.get("node_type_id", "unknown")
    driver_type = cluster.get("driver_node_type_id", node_type)

    if driver_type == node_type:
        return  # Same type, fine

    # Check if driver is a larger instance
    driver_dbu = _get_dbu_rate(driver_type)
    worker_dbu = _get_dbu_rate(node_type)

    if driver_dbu > worker_dbu * 1.5:
        cluster_id = cluster.get("cluster_id", "")
        cluster_name = cluster.get("cluster_name", "unnamed")

        findings.append(Finding(
            category=Category.DATABRICKS_CLUSTERS,
            resource_id=cluster_id,
            finding_type="oversized_driver",
            recommendation=(
                f"Cluster '{cluster_name}' (ID: {cluster_id})\n"
                f"  ├─ Driver: {driver_type} "
                f"({driver_dbu:.1f} DBU/hr)\n"
                f"  ├─ Workers: {node_type} "
                f"({worker_dbu:.1f} DBU/hr)\n"
                f"  ├─ Driver is significantly larger than workers\n"
                f"  └─ RECOMMENDED: Use same instance type for driver "
                f"unless specific memory needs"
            ),
            estimated_savings_usd=round(
                (driver_dbu - worker_dbu) * _DBU_PRICE_ALL_PURPOSE * 730, 2
            ),
            risk_score=2,
            confidence=calculate_confidence(100.0),
            metadata={
                "cluster_name": cluster_name,
                "cluster_id": cluster_id,
                "current_driver": driver_type,
                "current_workers": node_type,
                "recommended_driver": node_type,
                "tags": resource.tags,
            },
        ))


def _extract_tags(cluster: dict) -> dict[str, str]:
    """Extract custom tags from cluster metadata."""
    custom_tags = cluster.get("custom_tags", {})
    if isinstance(custom_tags, dict):
        return custom_tags
    return {}
