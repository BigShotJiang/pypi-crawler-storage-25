"""Base scanner interface."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.errors import ScanWarning


@dataclass
class ScanResult:
    """Result from a provider scan."""

    provider: str
    resources: list[ResourceMetadata] = field(default_factory=list)
    metrics: dict[str, ResourceMetrics] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    warnings: list[ScanWarning] = field(default_factory=list)


class BaseScanner(ABC):
    """Interface all provider scanners must implement.

    Scanners collect metadata and metrics from cloud providers.
    They should never raise exceptions — errors are captured as ScanWarnings.
    """

    @abstractmethod
    def scan(self, config: ScanConfig) -> ScanResult:
        """Execute scan and return results.

        Must not raise — captures errors as warnings in the ScanResult.

        Args:
            config: Scan configuration with thresholds and defaults.

        Returns:
            ScanResult containing resources, metrics, findings, and warnings.
        """

    @abstractmethod
    def provider_name(self) -> str:
        """Return the provider identifier string (e.g., 'aws', 'databricks')."""
