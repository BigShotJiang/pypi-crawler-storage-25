"""Scanner registry for managing provider scanners."""

from cloudbrain.scanners.base import BaseScanner


class ScannerRegistry:
    """Registry of available provider scanners."""

    def __init__(self) -> None:
        self._scanners: dict[str, BaseScanner] = {}

    def register(self, scanner: BaseScanner) -> None:
        """Register a scanner for a provider.

        Args:
            scanner: Scanner instance to register.
        """
        self._scanners[scanner.provider_name()] = scanner

    def get(self, provider: str) -> BaseScanner | None:
        """Get scanner for a provider.

        Args:
            provider: Provider name (e.g., 'aws', 'databricks').

        Returns:
            Scanner instance or None if not registered.
        """
        return self._scanners.get(provider.lower())

    def available_providers(self) -> list[str]:
        """Return list of registered provider names."""
        return sorted(self._scanners.keys())
