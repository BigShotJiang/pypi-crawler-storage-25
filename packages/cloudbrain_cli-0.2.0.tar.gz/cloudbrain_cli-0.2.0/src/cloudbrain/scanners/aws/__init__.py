"""AWS scanner module."""

from cloudbrain.scanners.aws.scanner import AWSScanner

__all__ = ["AWSScanner"]
