"""AWS storage scanning — EBS volumes, snapshots, and S3 buckets."""

import logging
from datetime import UTC, datetime, timedelta

import boto3

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.pricing import PricingEngine
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.aws.storage")

_pricing = PricingEngine()


def scan_ebs_volumes(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan for orphaned EBS volumes (available state, unattached).

    Args:
        session: Authenticated boto3 session.
        region: AWS region being scanned.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    ec2 = session.client("ec2")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    cutoff_date = datetime.now(UTC) - timedelta(days=config.thresholds.ebs_orphan_days)

    paginator = ec2.get_paginator("describe_volumes")
    for page in paginator.paginate(Filters=[{"Name": "status", "Values": ["available"]}]):
        for volume in page.get("Volumes", []):
            volume_id = volume["VolumeId"]
            volume_type = volume.get("VolumeType", "gp3")
            size_gb = volume.get("Size", 0)
            create_time = volume.get("CreateTime")
            tags = _extract_tags(volume.get("Tags", []))

            resource = ResourceMetadata(
                provider="aws",
                resource_type="ebs_volume",
                resource_id=volume_id,
                region=region,
                tags=tags,
                properties={
                    "volume_type": volume_type,
                    "size_gb": size_gb,
                    "state": "available",
                    "create_time": str(create_time),
                },
            )
            resources.append(resource)

            # Check if volume has been unattached longer than threshold
            if create_time and create_time < cutoff_date:
                monthly_cost = _pricing.get_ebs_monthly_cost(volume_type, size_gb, region) or 0.0

                findings.append(Finding(
                    category=Category.STORAGE,
                    resource_id=volume_id,
                    finding_type="orphaned_ebs_volume",
                    recommendation=(
                        f"EBS volume {volume_id} ({volume_type}, {size_gb} GB) has been "
                        f"unattached for more than {config.thresholds.ebs_orphan_days} days. "
                        f"Consider creating a snapshot and deleting the volume."
                    ),
                    estimated_savings_usd=monthly_cost,
                    risk_score=1,
                    confidence=calculate_confidence(100.0),
                    metadata={
                        "volume_type": volume_type,
                        "size_gb": size_gb,
                        "region": region,
                        "tags": tags,
                    },
                ))

    logger.debug(
        "EBS scan complete: %d orphaned volumes, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def scan_snapshots(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan for old EBS snapshots not referenced by AMIs.

    Args:
        session: Authenticated boto3 session.
        region: AWS region being scanned.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    ec2 = session.client("ec2")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    cutoff_date = datetime.now(UTC) - timedelta(days=config.thresholds.snapshot_age_days)

    # Get AMI-referenced snapshot IDs to exclude
    ami_snapshot_ids = _get_ami_snapshot_ids(ec2)

    # Get account ID for owner filter
    sts = session.client("sts")
    account_id = sts.get_caller_identity()["Account"]

    paginator = ec2.get_paginator("describe_snapshots")
    for page in paginator.paginate(OwnerIds=[account_id]):
        for snapshot in page.get("Snapshots", []):
            snapshot_id = snapshot["SnapshotId"]
            start_time = snapshot.get("StartTime")
            size_gb = snapshot.get("VolumeSize", 0)

            # Skip if referenced by an AMI
            if snapshot_id in ami_snapshot_ids:
                continue

            # Skip if newer than threshold
            if start_time and start_time >= cutoff_date:
                continue

            resource = ResourceMetadata(
                provider="aws",
                resource_type="ebs_snapshot",
                resource_id=snapshot_id,
                region=region,
                properties={
                    "size_gb": size_gb,
                    "start_time": str(start_time),
                },
            )
            resources.append(resource)

            # Snapshot storage cost (~$0.05/GB-month for standard)
            monthly_cost = round(size_gb * 0.05, 2)

            findings.append(Finding(
                category=Category.STORAGE,
                resource_id=snapshot_id,
                finding_type="old_snapshot",
                recommendation=(
                    f"Snapshot {snapshot_id} ({size_gb} GB) is older than "
                    f"{config.thresholds.snapshot_age_days} days and not referenced by any AMI. "
                    f"Consider deleting if no longer needed."
                ),
                estimated_savings_usd=monthly_cost,
                risk_score=2,
                confidence=calculate_confidence(100.0),
                metadata={"size_gb": size_gb, "region": region},
            ))

    logger.debug("Snapshot scan complete: %d old snapshots found", len(findings))
    return resources, {}, findings


def scan_s3_buckets(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan S3 buckets for missing lifecycle policies.

    Args:
        session: Authenticated boto3 session.
        region: AWS region being scanned.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    s3 = session.client("s3")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    try:
        response = s3.list_buckets()
    except Exception as e:
        logger.warning("Failed to list S3 buckets: %s", e)
        return resources, {}, findings

    for bucket in response.get("Buckets", []):
        bucket_name = bucket["Name"]

        # Check bucket region — only process buckets in the target region
        try:
            location = s3.get_bucket_location(Bucket=bucket_name)
            bucket_region = location.get("LocationConstraint") or "us-east-1"
            if bucket_region != region:
                continue
        except Exception:
            continue

        resource = ResourceMetadata(
            provider="aws",
            resource_type="s3_bucket",
            resource_id=bucket_name,
            region=bucket_region,
            properties={"name": bucket_name},
        )
        resources.append(resource)

        # Check for lifecycle configuration
        has_lifecycle = _bucket_has_lifecycle(s3, bucket_name)
        if not has_lifecycle:
            findings.append(Finding(
                category=Category.STORAGE,
                resource_id=bucket_name,
                finding_type="s3_missing_lifecycle",
                recommendation=(
                    f"S3 bucket '{bucket_name}' has no lifecycle configuration. "
                    f"Consider adding lifecycle rules to transition old objects to cheaper "
                    f"storage classes or expire them."
                ),
                estimated_savings_usd=0.0,  # Can't estimate without knowing bucket size
                risk_score=1,
                confidence=calculate_confidence(100.0),
                metadata={"bucket_name": bucket_name, "region": bucket_region},
            ))

    logger.debug("S3 scan complete: %d buckets, %d findings", len(resources), len(findings))
    return resources, {}, findings


def _bucket_has_lifecycle(s3: object, bucket_name: str) -> bool:
    """Check if a bucket has a lifecycle configuration."""
    try:
        s3.get_bucket_lifecycle_configuration(Bucket=bucket_name)  # type: ignore[attr-defined]
        return True
    except Exception:
        # NoSuchLifecycleConfiguration or access denied
        return False


def _get_ami_snapshot_ids(ec2: object) -> set[str]:
    """Get all snapshot IDs referenced by AMIs owned by this account."""
    snapshot_ids: set[str] = set()
    try:
        paginator = ec2.get_paginator("describe_images")  # type: ignore[attr-defined]
        for page in paginator.paginate(Owners=["self"]):
            for image in page.get("Images", []):
                for mapping in image.get("BlockDeviceMappings", []):
                    ebs = mapping.get("Ebs", {})
                    if "SnapshotId" in ebs:
                        snapshot_ids.add(ebs["SnapshotId"])
    except Exception as e:
        logger.debug("Failed to get AMI snapshot IDs: %s", e)
    return snapshot_ids


def _extract_tags(tags: list[dict] | None) -> dict[str, str]:
    """Convert AWS tag list to dict."""
    if not tags:
        return {}
    return {tag["Key"]: tag["Value"] for tag in tags if "Key" in tag and "Value" in tag}
