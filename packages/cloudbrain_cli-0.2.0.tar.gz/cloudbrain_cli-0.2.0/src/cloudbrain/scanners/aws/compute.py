"""AWS compute resource scanning — EC2 instances and Load Balancers."""

import logging

import boto3

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import (
    Category,
    Finding,
    ResourceMetadata,
    ResourceMetrics,
)
from cloudbrain.engine.pricing import PricingEngine
from cloudbrain.engine.risk import calculate_confidence
from cloudbrain.scanners.aws.metrics import get_ec2_cpu_metrics

logger = logging.getLogger("cloudbrain.scanners.aws.compute")

_pricing = PricingEngine()

# Instance family downsizing map
_DOWNSIZE_MAP = {
    "xlarge": "large",
    "2xlarge": "xlarge",
    "4xlarge": "2xlarge",
    "8xlarge": "4xlarge",
    "12xlarge": "8xlarge",
    "16xlarge": "12xlarge",
    "24xlarge": "16xlarge",
}


def _suggest_smaller_instance(instance_type: str) -> str | None:
    """Suggest a smaller instance in the same family."""
    parts = instance_type.split(".")
    if len(parts) != 2:
        return None
    family, size = parts
    smaller_size = _DOWNSIZE_MAP.get(size)
    if smaller_size:
        return f"{family}.{smaller_size}"
    return None


def scan_ec2_instances(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan EC2 instances for idle and underutilized resources."""
    ec2 = session.client("ec2")
    resources: list[ResourceMetadata] = []
    metrics_map: dict[str, ResourceMetrics] = {}
    findings: list[Finding] = []

    paginator = ec2.get_paginator("describe_instances")
    running_instance_ids: list[str] = []
    instance_data: dict[str, dict] = {}

    for page in paginator.paginate():
        for reservation in page.get("Reservations", []):
            for instance in reservation.get("Instances", []):
                instance_id = instance["InstanceId"]
                state = instance["State"]["Name"]
                instance_type = instance.get("InstanceType", "unknown")
                tags = _extract_tags(instance.get("Tags", []))
                name_tag = tags.get("Name", "unnamed")
                launch_time = instance.get("LaunchTime", "")

                resource = ResourceMetadata(
                    provider="aws",
                    resource_type="ec2_instance",
                    resource_id=instance_id,
                    region=region,
                    tags=tags,
                    properties={
                        "instance_type": instance_type,
                        "state": state,
                        "name": name_tag,
                        "launch_time": str(launch_time),
                        "vpc_id": instance.get("VpcId", ""),
                        "subnet_id": instance.get("SubnetId", ""),
                        "private_ip": instance.get(
                            "PrivateIpAddress", ""
                        ),
                    },
                )
                resources.append(resource)
                instance_data[instance_id] = {
                    "type": instance_type,
                    "name": name_tag,
                    "tags": tags,
                }

                if state == "running":
                    running_instance_ids.append(instance_id)

    # Fetch CPU metrics for running instances
    if running_instance_ids:
        cpu_metrics = get_ec2_cpu_metrics(
            session, running_instance_ids,
            config.observation_window_days,
        )

        for instance_id, cpu_data in cpu_metrics.items():
            metrics_map[instance_id] = ResourceMetrics(
                resource_id=instance_id,
                avg_cpu_percent=cpu_data.get("avg_cpu"),
                peak_cpu_percent=cpu_data.get("peak_cpu"),
                data_points_count=cpu_data.get("data_points", 0),
                observation_coverage_percent=cpu_data.get(
                    "coverage_percent", 0.0
                ),
            )

        # Generate findings
        for instance_id in running_instance_ids:
            metrics = metrics_map.get(instance_id)
            if not metrics or metrics.avg_cpu_percent is None:
                continue
            if metrics.observation_coverage_percent < 50.0:
                continue

            data = instance_data[instance_id]
            instance_type = data["type"]
            name = data["name"]
            tags = data["tags"]
            monthly_cost = (
                _pricing.get_ec2_monthly_rate(instance_type, region)
                or 0.0
            )
            hourly_cost = (
                _pricing.get_ec2_hourly_rate(instance_type, region)
                or 0.0
            )

            if metrics.avg_cpu_percent < config.thresholds.cpu_idle_percent:
                findings.append(Finding(
                    category=Category.COMPUTE,
                    resource_id=instance_id,
                    finding_type="idle_ec2_instance",
                    recommendation=(
                        f"EC2 Instance '{name}' ({instance_id})\n"
                        f"  ├─ Type: {instance_type} | "
                        f"Region: {region}\n"
                        f"  ├─ Avg CPU: {metrics.avg_cpu_percent:.1f}% "
                        f"(peak: {metrics.peak_cpu_percent:.1f}%) "
                        f"over {config.observation_window_days} days\n"
                        f"  ├─ CURRENT COST: ${hourly_cost:.4f}/hr "
                        f"(${monthly_cost:.2f}/mo)\n"
                        f"  └─ ACTION: Stop or terminate this instance"
                    ),
                    estimated_savings_usd=monthly_cost,
                    risk_score=2,
                    confidence=calculate_confidence(
                        metrics.observation_coverage_percent
                    ),
                    metadata={
                        "instance_type": instance_type,
                        "name": name,
                        "region": region,
                        "avg_cpu": metrics.avg_cpu_percent,
                        "peak_cpu": metrics.peak_cpu_percent,
                        "tags": tags,
                    },
                ))
            elif (
                metrics.avg_cpu_percent
                < config.thresholds.cpu_underutilized_percent
            ):
                smaller = _suggest_smaller_instance(instance_type)
                smaller_cost = 0.0
                if smaller:
                    smaller_cost = (
                        _pricing.get_ec2_monthly_rate(smaller, region)
                        or monthly_cost * 0.5
                    )
                else:
                    smaller = "smaller instance"
                    smaller_cost = monthly_cost * 0.5

                savings = round(monthly_cost - smaller_cost, 2)

                findings.append(Finding(
                    category=Category.COMPUTE,
                    resource_id=instance_id,
                    finding_type="underutilized_ec2_instance",
                    recommendation=(
                        f"EC2 Instance '{name}' ({instance_id})\n"
                        f"  ├─ Type: {instance_type} | "
                        f"Region: {region}\n"
                        f"  ├─ Avg CPU: {metrics.avg_cpu_percent:.1f}% "
                        f"(peak: {metrics.peak_cpu_percent:.1f}%)\n"
                        f"  ├─ CURRENT: {instance_type} "
                        f"(${monthly_cost:.2f}/mo)\n"
                        f"  ├─ RECOMMENDED: {smaller} "
                        f"(${smaller_cost:.2f}/mo)\n"
                        f"  └─ ESTIMATED SAVINGS: ${savings:.2f}/mo"
                    ),
                    estimated_savings_usd=savings,
                    risk_score=3,
                    confidence=calculate_confidence(
                        metrics.observation_coverage_percent
                    ),
                    metadata={
                        "instance_type": instance_type,
                        "suggested_type": smaller,
                        "name": name,
                        "region": region,
                        "avg_cpu": metrics.avg_cpu_percent,
                        "tags": tags,
                    },
                ))

    logger.debug(
        "EC2 scan complete: %d instances, %d findings",
        len(resources), len(findings),
    )
    return resources, metrics_map, findings


def scan_load_balancers(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan Elastic Load Balancers for unused resources."""
    elbv2 = session.client("elbv2")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    paginator = elbv2.get_paginator("describe_load_balancers")

    for page in paginator.paginate():
        for lb in page.get("LoadBalancers", []):
            lb_arn = lb["LoadBalancerArn"]
            lb_name = lb.get("LoadBalancerName", "unknown")
            lb_type = lb.get("Type", "application")

            resource = ResourceMetadata(
                provider="aws",
                resource_type="load_balancer",
                resource_id=lb_arn,
                region=region,
                properties={
                    "name": lb_name,
                    "type": lb_type,
                    "state": lb.get("State", {}).get("Code", "unknown"),
                    "dns_name": lb.get("DNSName", ""),
                },
            )
            resources.append(resource)

            if _has_no_healthy_targets(elbv2, lb_arn):
                hourly_rate = _pricing.get_elb_hourly_rate(lb_type)
                monthly_cost = round(hourly_rate * 730, 2)

                findings.append(Finding(
                    category=Category.COMPUTE,
                    resource_id=lb_arn,
                    finding_type="unused_load_balancer",
                    recommendation=(
                        f"Load Balancer '{lb_name}'\n"
                        f"  ├─ Type: {lb_type} | Region: {region}\n"
                        f"  ├─ No healthy targets registered\n"
                        f"  ├─ CURRENT COST: ${hourly_rate:.4f}/hr "
                        f"(${monthly_cost:.2f}/mo)\n"
                        f"  └─ ACTION: Remove if no longer needed"
                    ),
                    estimated_savings_usd=monthly_cost,
                    risk_score=2,
                    confidence=calculate_confidence(100.0),
                    metadata={
                        "name": lb_name,
                        "type": lb_type,
                        "region": region,
                    },
                ))

    logger.debug(
        "ELB scan complete: %d load balancers, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _has_no_healthy_targets(elbv2: object, lb_arn: str) -> bool:
    """Check if a load balancer has zero healthy targets."""
    try:
        tg_response = elbv2.describe_target_groups(  # type: ignore[attr-defined]
            LoadBalancerArn=lb_arn
        )
        target_groups = tg_response.get("TargetGroups", [])

        if not target_groups:
            return True

        for tg in target_groups:
            tg_arn = tg["TargetGroupArn"]
            health = elbv2.describe_target_health(  # type: ignore[attr-defined]
                TargetGroupArn=tg_arn
            )
            for target in health.get("TargetHealthDescriptions", []):
                if (
                    target.get("TargetHealth", {}).get("State")
                    == "healthy"
                ):
                    return False

        return True
    except Exception as e:
        logger.debug(
            "Failed to check target health for %s: %s", lb_arn, e
        )
        return False


def _extract_tags(tags: list[dict]) -> dict[str, str]:
    """Convert AWS tag list to dict."""
    return {
        tag["Key"]: tag["Value"]
        for tag in tags
        if "Key" in tag and "Value" in tag
    }
