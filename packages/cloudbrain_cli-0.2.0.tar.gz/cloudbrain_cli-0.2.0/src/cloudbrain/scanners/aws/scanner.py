"""AWS Scanner orchestrator — coordinates compute, storage, and networking scans."""

import logging
from datetime import UTC, datetime

import boto3
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from cloudbrain.config.schema import ScanConfig
from cloudbrain.errors import ScanWarning
from cloudbrain.scanners.aws.compute import scan_ec2_instances, scan_load_balancers
from cloudbrain.scanners.aws.networking import scan_elastic_ips, scan_nat_gateways
from cloudbrain.scanners.aws.storage import (
    scan_ebs_volumes,
    scan_s3_buckets,
    scan_snapshots,
)
from cloudbrain.scanners.base import BaseScanner, ScanResult

logger = logging.getLogger("cloudbrain.scanners.aws")
console = Console()


class AWSScanner(BaseScanner):
    """Scans AWS infrastructure for cost optimization opportunities."""

    def __init__(
        self, session: boto3.Session, regions: list[str] | None = None
    ) -> None:
        self._session = session
        self._regions = regions or [session.region_name or "us-east-1"]

    def provider_name(self) -> str:
        return "aws"

    def scan(self, config: ScanConfig) -> ScanResult:
        """Execute full AWS scan with progress indicator."""
        result = ScanResult(provider="aws")

        console.print(
            f"\n[bold blue]Scanning AWS:[/bold blue] "
            f"regions={', '.join(self._regions)}\n"
        )

        # Build scan steps for all regions
        scan_steps: list[tuple[str, object]] = []
        for region in self._regions:
            session = self._get_regional_session(region)
            scan_steps.extend([
                (
                    f"EC2 Instances ({region})",
                    lambda s=session, r=region: scan_ec2_instances(
                        s, r, config
                    ),
                ),
                (
                    f"Load Balancers ({region})",
                    lambda s=session, r=region: scan_load_balancers(
                        s, r, config
                    ),
                ),
                (
                    f"EBS Volumes ({region})",
                    lambda s=session, r=region: scan_ebs_volumes(
                        s, r, config
                    ),
                ),
                (
                    f"EBS Snapshots ({region})",
                    lambda s=session, r=region: scan_snapshots(
                        s, r, config
                    ),
                ),
                (
                    f"S3 Buckets ({region})",
                    lambda s=session, r=region: scan_s3_buckets(
                        s, r, config
                    ),
                ),
                (
                    f"Elastic IPs ({region})",
                    lambda s=session, r=region: scan_elastic_ips(
                        s, r, config
                    ),
                ),
                (
                    f"NAT Gateways ({region})",
                    lambda s=session, r=region: scan_nat_gateways(
                        s, r, config
                    ),
                ),
            ])

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=30),
            MofNCompleteColumn(),
            TextColumn("[cyan]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            overall = progress.add_task(
                "Scanning...", total=len(scan_steps)
            )

            for step_name, scan_fn in scan_steps:
                progress.update(
                    overall,
                    description=f"Scanning {step_name}",
                )
                self._run_scan(result, step_name, scan_fn)
                progress.advance(overall)

            progress.update(
                overall,
                description="[bold green]✓ AWS scan complete",
            )

        console.print()
        return result

    def _get_regional_session(self, region: str) -> boto3.Session:
        """Create a session for a specific region."""
        creds = self._session.get_credentials()
        if creds:
            return boto3.Session(
                aws_access_key_id=creds.access_key,
                aws_secret_access_key=creds.secret_key,
                aws_session_token=creds.token,
                region_name=region,
            )
        return boto3.Session(region_name=region)

    def _run_scan(
        self,
        result: ScanResult,
        resource_type: str,
        scan_fn: object,
    ) -> None:
        """Run a scan function safely, capturing errors as warnings."""
        try:
            resources, metrics, findings = scan_fn()  # type: ignore[operator]
            result.resources.extend(resources)
            result.metrics.update(metrics)
            result.findings.extend(findings)
            logger.debug(
                "Scanned %s: %d resources found",
                resource_type, len(resources),
            )
        except Exception as e:
            logger.warning("Failed to scan %s: %s", resource_type, e)
            result.warnings.append(
                ScanWarning(
                    provider="aws",
                    resource_type=resource_type,
                    reason=str(e),
                    timestamp=datetime.now(UTC).isoformat(),
                )
            )
