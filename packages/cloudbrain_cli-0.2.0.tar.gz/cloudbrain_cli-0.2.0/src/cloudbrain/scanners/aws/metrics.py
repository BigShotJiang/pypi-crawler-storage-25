"""CloudWatch metrics retrieval for AWS resources."""

import logging
from datetime import UTC, datetime, timedelta

import boto3

logger = logging.getLogger("cloudbrain.scanners.aws.metrics")


def get_ec2_cpu_metrics(
    session: boto3.Session,
    instance_ids: list[str],
    observation_window_days: int,
) -> dict[str, dict]:
    """Fetch CPU utilization metrics for EC2 instances from CloudWatch.

    Uses GetMetricData for efficient batch retrieval (up to 500 metrics per call).

    Args:
        session: Authenticated boto3 session.
        instance_ids: List of EC2 instance IDs to query.
        observation_window_days: Number of days to look back.

    Returns:
        Dict mapping instance_id to metrics dict with keys:
        - avg_cpu: Average CPU utilization percentage
        - peak_cpu: Maximum CPU utilization percentage
        - data_points: Number of data points collected
        - coverage_percent: Percentage of observation window covered
    """
    if not instance_ids:
        return {}

    cloudwatch = session.client("cloudwatch")
    end_time = datetime.now(UTC)
    start_time = end_time - timedelta(days=observation_window_days)

    # Expected data points: 1 per hour over the observation window
    expected_points = observation_window_days * 24

    results: dict[str, dict] = {}

    # Process in batches of 500 (CloudWatch limit)
    batch_size = 500
    for i in range(0, len(instance_ids), batch_size):
        batch = instance_ids[i : i + batch_size]
        metrics_data = _fetch_batch_metrics(
            cloudwatch, batch, start_time, end_time, expected_points
        )
        results.update(metrics_data)

    return results


def _fetch_batch_metrics(
    cloudwatch: object,
    instance_ids: list[str],
    start_time: datetime,
    end_time: datetime,
    expected_points: int,
) -> dict[str, dict]:
    """Fetch metrics for a batch of instances.

    Args:
        cloudwatch: CloudWatch client.
        instance_ids: Batch of instance IDs.
        start_time: Start of observation window.
        end_time: End of observation window.
        expected_points: Expected number of data points for full coverage.

    Returns:
        Dict mapping instance_id to metrics.
    """
    # Build metric data queries
    queries = []
    for idx, instance_id in enumerate(instance_ids):
        queries.append({
            "Id": f"avg_{idx}",
            "MetricStat": {
                "Metric": {
                    "Namespace": "AWS/EC2",
                    "MetricName": "CPUUtilization",
                    "Dimensions": [
                        {"Name": "InstanceId", "Value": instance_id},
                    ],
                },
                "Period": 3600,  # 1-hour average
                "Stat": "Average",
            },
            "ReturnData": True,
        })
        queries.append({
            "Id": f"max_{idx}",
            "MetricStat": {
                "Metric": {
                    "Namespace": "AWS/EC2",
                    "MetricName": "CPUUtilization",
                    "Dimensions": [
                        {"Name": "InstanceId", "Value": instance_id},
                    ],
                },
                "Period": 3600,
                "Stat": "Maximum",
            },
            "ReturnData": True,
        })

    try:
        response = cloudwatch.get_metric_data(  # type: ignore[attr-defined]
            MetricDataQueries=queries,
            StartTime=start_time,
            EndTime=end_time,
        )
    except Exception as e:
        logger.warning("CloudWatch GetMetricData failed: %s", e)
        return {}

    # Parse results
    results: dict[str, dict] = {}
    metric_results = response.get("MetricDataResults", [])

    for idx, instance_id in enumerate(instance_ids):
        avg_values = _get_values_for_id(metric_results, f"avg_{idx}")
        max_values = _get_values_for_id(metric_results, f"max_{idx}")

        data_points = len(avg_values)
        coverage = (data_points / expected_points * 100) if expected_points > 0 else 0

        results[instance_id] = {
            "avg_cpu": sum(avg_values) / len(avg_values) if avg_values else None,
            "peak_cpu": max(max_values) if max_values else None,
            "data_points": data_points,
            "coverage_percent": min(coverage, 100.0),
        }

    return results


def _get_values_for_id(metric_results: list[dict], query_id: str) -> list[float]:
    """Extract values for a specific metric query ID."""
    for result in metric_results:
        if result.get("Id") == query_id:
            return result.get("Values", [])
    return []
