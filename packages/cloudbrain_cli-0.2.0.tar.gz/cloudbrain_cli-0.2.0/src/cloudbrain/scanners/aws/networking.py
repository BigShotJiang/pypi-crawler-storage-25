"""AWS networking scanning — Elastic IPs and NAT Gateways."""

import logging
from datetime import UTC, datetime, timedelta

import boto3

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Category, Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.pricing import PricingEngine
from cloudbrain.engine.risk import calculate_confidence

logger = logging.getLogger("cloudbrain.scanners.aws.networking")

_pricing = PricingEngine()


def scan_elastic_ips(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan for unassociated Elastic IP addresses.

    Args:
        session: Authenticated boto3 session.
        region: AWS region being scanned.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    ec2 = session.client("ec2")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    response = ec2.describe_addresses()

    for address in response.get("Addresses", []):
        allocation_id = address.get("AllocationId", address.get("PublicIp", "unknown"))
        public_ip = address.get("PublicIp", "unknown")
        association_id = address.get("AssociationId")

        resource = ResourceMetadata(
            provider="aws",
            resource_type="elastic_ip",
            resource_id=allocation_id,
            region=region,
            properties={
                "public_ip": public_ip,
                "associated": association_id is not None,
            },
        )
        resources.append(resource)

        # Flag unassociated EIPs
        if not association_id:
            hourly_rate = _pricing.get_eip_hourly_rate()
            monthly_cost = round(hourly_rate * 730, 2)

            findings.append(Finding(
                category=Category.NETWORKING,
                resource_id=allocation_id,
                finding_type="unassociated_elastic_ip",
                recommendation=(
                    f"Elastic IP {public_ip} is not associated with any running instance. "
                    f"Release it to avoid charges."
                ),
                estimated_savings_usd=monthly_cost,
                risk_score=1,
                confidence=calculate_confidence(100.0),
                metadata={"public_ip": public_ip, "region": region},
            ))

    logger.debug("EIP scan complete: %d addresses, %d unassociated", len(resources), len(findings))
    return resources, {}, findings


def scan_nat_gateways(
    session: boto3.Session, region: str, config: ScanConfig
) -> tuple[list[ResourceMetadata], dict[str, ResourceMetrics], list[Finding]]:
    """Scan NAT Gateways for low traffic usage.

    Args:
        session: Authenticated boto3 session.
        region: AWS region being scanned.
        config: Scan configuration.

    Returns:
        Tuple of (resources, metrics_map, findings).
    """
    ec2 = session.client("ec2")
    cloudwatch = session.client("cloudwatch")
    resources: list[ResourceMetadata] = []
    findings: list[Finding] = []

    response = ec2.describe_nat_gateways(
        Filters=[{"Name": "state", "Values": ["available"]}]
    )

    end_time = datetime.now(UTC)
    start_time = end_time - timedelta(days=config.observation_window_days)

    for nat_gw in response.get("NatGateways", []):
        nat_gw_id = nat_gw["NatGatewayId"]
        vpc_id = nat_gw.get("VpcId", "unknown")

        resource = ResourceMetadata(
            provider="aws",
            resource_type="nat_gateway",
            resource_id=nat_gw_id,
            region=region,
            properties={"vpc_id": vpc_id, "state": "available"},
        )
        resources.append(resource)

        # Check data processing volume
        avg_daily_gb = _get_nat_daily_traffic(
            cloudwatch, nat_gw_id, start_time, end_time, config.observation_window_days
        )

        if avg_daily_gb is not None and avg_daily_gb < config.thresholds.nat_low_traffic_gb:
            # NAT Gateway hourly charge: $0.045/hour + $0.045/GB processed
            # If low traffic, the fixed hourly cost dominates
            monthly_fixed_cost = round(0.045 * 730, 2)  # ~$32.85/month

            findings.append(Finding(
                category=Category.NETWORKING,
                resource_id=nat_gw_id,
                finding_type="low_traffic_nat_gateway",
                recommendation=(
                    f"NAT Gateway {nat_gw_id} in VPC {vpc_id} processes "
                    f"avg {avg_daily_gb:.2f} GB/day "
                    f"(below {config.thresholds.nat_low_traffic_gb} GB "
                    f"threshold). Consider consolidating or removing."
                ),
                estimated_savings_usd=monthly_fixed_cost,
                risk_score=3,
                confidence=calculate_confidence(100.0),
                metadata={
                    "nat_gateway_id": nat_gw_id,
                    "vpc_id": vpc_id,
                    "avg_daily_gb": avg_daily_gb,
                    "region": region,
                },
            ))

    logger.debug(
        "NAT Gateway scan complete: %d gateways, %d findings",
        len(resources), len(findings),
    )
    return resources, {}, findings


def _get_nat_daily_traffic(
    cloudwatch: object,
    nat_gw_id: str,
    start_time: datetime,
    end_time: datetime,
    window_days: int,
) -> float | None:
    """Get average daily data processed by a NAT Gateway.

    Args:
        cloudwatch: CloudWatch client.
        nat_gw_id: NAT Gateway ID.
        start_time: Start of observation window.
        end_time: End of observation window.
        window_days: Number of days in the window.

    Returns:
        Average daily GB processed, or None if metrics unavailable.
    """
    try:
        response = cloudwatch.get_metric_data(  # type: ignore[attr-defined]
            MetricDataQueries=[
                {
                    "Id": "bytes_out",
                    "MetricStat": {
                        "Metric": {
                            "Namespace": "AWS/NATGateway",
                            "MetricName": "BytesOutToDestination",
                            "Dimensions": [
                                {"Name": "NatGatewayId", "Value": nat_gw_id},
                            ],
                        },
                        "Period": 86400,  # 1 day
                        "Stat": "Sum",
                    },
                    "ReturnData": True,
                },
            ],
            StartTime=start_time,
            EndTime=end_time,
        )

        results = response.get("MetricDataResults", [])
        if results and results[0].get("Values"):
            values = results[0]["Values"]
            total_bytes = sum(values)
            total_gb = total_bytes / (1024**3)
            return total_gb / window_days if window_days > 0 else None

        return None
    except Exception as e:
        logger.debug("Failed to get NAT Gateway metrics for %s: %s", nat_gw_id, e)
        return None
