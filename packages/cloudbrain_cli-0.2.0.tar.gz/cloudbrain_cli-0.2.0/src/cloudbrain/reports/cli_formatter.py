"""CLI terminal output formatting using Rich."""

import re

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cloudbrain.reports.models import ScanReport

console = Console()

# Account ID masking pattern (12-digit AWS account IDs)
_ACCOUNT_ID_PATTERN = re.compile(r"\b(\d{12})\b")


def format_cli_report(report: ScanReport) -> None:
    """Display scan report in the terminal with color-coded output.

    Args:
        report: Complete scan report to display.
    """
    console.print()

    # Header
    _print_header(report)

    # Summary
    _print_summary(report)

    # Detailed findings
    if report.findings:
        _print_detailed_findings(report)

    # Category breakdown
    if report.finding_count_by_category:
        _print_category_breakdown(report)

    # Warnings
    if report.warnings:
        _print_warnings(report)

    console.print()


def _print_header(report: ScanReport) -> None:
    """Print scan metadata header."""
    meta = report.metadata
    header_text = (
        f"[bold]cloudbrain scan report[/bold]\n"
        f"Timestamp: {meta.timestamp}\n"
        f"Providers: {', '.join(meta.providers)}\n"
        f"Regions: {', '.join(meta.regions)}\n"
        f"Observation Window: {meta.observation_window_days} days"
    )
    console.print(Panel(header_text, title="Scan Metadata", border_style="blue"))


def _print_summary(report: ScanReport) -> None:
    """Print savings summary."""
    total_savings = report.total_estimated_savings
    finding_count = len(report.findings)
    actionable_count = sum(
        1 for f in report.findings if f.estimated_savings_usd > 0
    )

    if total_savings > 0:
        savings_style = "bold green"
    else:
        savings_style = "dim"

    console.print()
    console.print(
        f"  💰 Estimated Monthly Savings: "
        f"[{savings_style}]${total_savings:,.2f}[/{savings_style}]"
    )
    console.print(
        f"  📋 Total Findings: {finding_count} "
        f"({actionable_count} with cost impact)"
    )
    console.print()


def _print_detailed_findings(report: ScanReport) -> None:
    """Print all findings with full detail (only those with savings > $0)."""
    # Filter to only findings with actual savings
    actionable = [
        f for f in report.findings if f.estimated_savings_usd > 0
    ]

    # Sort by priority
    sorted_findings = sorted(
        actionable,
        key=lambda f: (f.priority_score, f.estimated_savings_usd),
        reverse=True,
    )

    if not sorted_findings:
        console.print("  [dim]No actionable cost savings found.[/dim]")
        console.print()
        return

    console.print(
        f"[bold]━━━ Actionable Findings ({len(sorted_findings)}) ━━━[/bold]"
    )
    console.print()

    for idx, finding in enumerate(sorted_findings, 1):
        risk_style = _risk_style(finding.risk_score)
        risk_label = _risk_label(finding.risk_score)

        # Finding header
        savings_str = (
            f"[green]${finding.estimated_savings_usd:,.2f}/mo[/green]"
            if finding.estimated_savings_usd > 0
            else "[dim]$0.00/mo[/dim]"
        )

        console.print(
            f"  [bold]#{idx}[/bold] "
            f"[{risk_style}][{risk_label}][/{risk_style}] "
            f"{finding.finding_type.replace('_', ' ').upper()} "
            f"— {savings_str}"
        )

        # Recommendation (multi-line, indented)
        for line in finding.recommendation.split("\n"):
            console.print(f"      {line}")

        console.print()


def _print_category_breakdown(report: ScanReport) -> None:
    """Print finding count by category (only categories with savings)."""
    table = Table(
        title="Summary by Category",
        show_header=True,
        header_style="bold",
    )
    table.add_column("Category", width=25)
    table.add_column("Findings", justify="right", width=10)
    table.add_column("Potential Savings", justify="right", width=18)

    # Calculate savings per category (only actionable)
    category_data: dict[str, dict] = {}
    for finding in report.findings:
        if finding.estimated_savings_usd <= 0:
            continue
        cat = finding.category.value
        if cat not in category_data:
            category_data[cat] = {"count": 0, "savings": 0.0}
        category_data[cat]["count"] += 1
        category_data[cat]["savings"] += finding.estimated_savings_usd

    if not category_data:
        return

    for category in sorted(category_data.keys()):
        data = category_data[category]
        table.add_row(
            category,
            str(data["count"]),
            f"${data['savings']:,.2f}/mo",
        )

    console.print(table)
    console.print()


def _print_warnings(report: ScanReport) -> None:
    """Print scan warnings."""
    console.print("[yellow]⚠️  Warnings:[/yellow]")
    for warning in report.warnings:
        console.print(
            f"  [{warning.provider}] {warning.resource_type}: "
            f"{warning.reason}"
        )
    console.print()


def _risk_style(risk_score: int) -> str:
    """Map risk score to Rich style."""
    if risk_score <= 2:
        return "green"
    elif risk_score == 3:
        return "yellow"
    else:
        return "red bold"


def _risk_label(risk_score: int) -> str:
    """Map risk score to human label."""
    if risk_score <= 2:
        return "LOW RISK"
    elif risk_score == 3:
        return "MEDIUM RISK"
    else:
        return "HIGH RISK"


def _mask_account_ids(text: str) -> str:
    """Mask AWS account IDs in text (show only last 4 digits)."""
    return _ACCOUNT_ID_PATTERN.sub(lambda m: f"****{m.group(1)[-4:]}", text)
