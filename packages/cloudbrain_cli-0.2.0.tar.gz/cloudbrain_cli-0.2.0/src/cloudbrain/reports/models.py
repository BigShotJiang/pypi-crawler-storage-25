"""Report data models."""

from dataclasses import dataclass, field
from datetime import UTC, datetime

from cloudbrain.engine.models import Finding
from cloudbrain.errors import ScanWarning


@dataclass
class ScanMetadata:
    """Metadata about the scan execution."""

    timestamp: str = field(
        default_factory=lambda: datetime.now(UTC).isoformat()
    )
    providers: list[str] = field(default_factory=list)
    regions: list[str] = field(default_factory=list)
    observation_window_days: int = 14
    version: str = "0.1.0"


@dataclass
class ScanReport:
    """Complete scan report with findings and metadata."""

    metadata: ScanMetadata
    findings: list[Finding] = field(default_factory=list)
    warnings: list[ScanWarning] = field(default_factory=list)

    @property
    def total_estimated_savings(self) -> float:
        """Total estimated monthly savings across all findings."""
        return round(sum(f.estimated_savings_usd for f in self.findings), 2)

    @property
    def finding_count_by_category(self) -> dict[str, int]:
        """Count of findings grouped by category."""
        counts: dict[str, int] = {}
        for finding in self.findings:
            category_name = finding.category.value
            counts[category_name] = counts.get(category_name, 0) + 1
        return counts

    @property
    def top_findings(self) -> list[Finding]:
        """Top 5 findings by priority score."""
        sorted_findings = sorted(
            self.findings,
            key=lambda f: (f.priority_score, f.estimated_savings_usd),
            reverse=True,
        )
        return sorted_findings[:5]
