"""JSON report exporter — produces a clean, readable report."""

import json
import re
from pathlib import Path

from cloudbrain.reports.models import ScanReport

_ACCOUNT_ID_PATTERN = re.compile(r"\b(\d{12})\b")


def export_json(report: ScanReport, path: Path) -> None:
    """Export scan report as a well-structured JSON file.

    Only includes actionable findings (savings > $0).
    Organized by category with executive summary.

    Args:
        report: Scan report to export.
        path: Target file path.
    """
    # Filter to actionable findings only
    actionable = [
        f for f in report.findings if f.estimated_savings_usd > 0
    ]
    actionable.sort(
        key=lambda f: (f.priority_score, f.estimated_savings_usd),
        reverse=True,
    )

    # Group by category
    categories: dict[str, list] = {}
    category_totals: dict[str, dict] = {}

    for finding in actionable:
        cat = finding.category.value
        if cat not in categories:
            categories[cat] = []
            category_totals[cat] = {"count": 0, "savings": 0.0}

        categories[cat].append({
            "rank": len(categories[cat]) + 1,
            "resource_id": _mask_account_ids(finding.resource_id),
            "finding_type": finding.finding_type.replace("_", " ").title(),
            "risk_level": _risk_label(finding.risk_score),
            "estimated_monthly_savings_usd": finding.estimated_savings_usd,
            "confidence": finding.confidence.value,
            "recommendation": finding.recommendation,
            "details": {
                k: v for k, v in finding.metadata.items()
                if k != "tags"
            },
        })
        category_totals[cat]["count"] += 1
        category_totals[cat]["savings"] += finding.estimated_savings_usd

    # Round category totals
    for cat in category_totals:
        category_totals[cat]["savings"] = round(
            category_totals[cat]["savings"], 2
        )

    total_savings = round(
        sum(f.estimated_savings_usd for f in actionable), 2
    )

    output = {
        "report": {
            "title": "Infrastructure Cost Intelligence Report",
            "generated_at": report.metadata.timestamp,
            "generated_by": f"cloudbrain v{report.metadata.version}",
            "providers_scanned": report.metadata.providers,
            "regions": report.metadata.regions,
            "observation_window_days": report.metadata.observation_window_days,
        },
        "executive_summary": {
            "total_monthly_savings_potential_usd": total_savings,
            "total_annual_savings_potential_usd": round(
                total_savings * 12, 2
            ),
            "actionable_findings": len(actionable),
            "total_findings_scanned": len(report.findings),
            "breakdown_by_category": category_totals,
            "top_3_actions": [
                {
                    "action": f["recommendation"].split("\n")[0],
                    "savings_usd": f["estimated_monthly_savings_usd"],
                }
                for f in (categories.get(cat, []) for cat in categories)
                for f in (f[:1] if f else [])
            ][:3],
        },
        "findings_by_category": categories,
        "warnings": [
            {
                "provider": w.provider,
                "resource_type": w.resource_type,
                "reason": w.reason,
            }
            for w in report.warnings
        ] if report.warnings else [],
    }

    with open(path, "w") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)


def _mask_account_ids(text: str) -> str:
    """Mask AWS account IDs (show only last 4 digits)."""
    return _ACCOUNT_ID_PATTERN.sub(lambda m: f"****{m.group(1)[-4:]}", text)


def _risk_label(risk_score: int) -> str:
    """Convert risk score to label."""
    if risk_score <= 2:
        return "Low"
    elif risk_score == 3:
        return "Medium"
    else:
        return "High"
