"""Report generator — orchestrates output formatting."""

import logging
from pathlib import Path

from cloudbrain.reports.cli_formatter import format_cli_report
from cloudbrain.reports.csv_exporter import export_csv
from cloudbrain.reports.json_exporter import export_json
from cloudbrain.reports.models import ScanReport

logger = logging.getLogger("cloudbrain.reports")


class ReportGenerator:
    """Generates scan reports in various formats."""

    def generate(
        self,
        report: ScanReport,
        output_path: Path | None = None,
        output_format: str | None = None,
        show_cli: bool = True,
    ) -> None:
        """Generate and output the scan report.

        Args:
            report: Complete scan report with findings.
            output_path: Optional file path for export.
            output_format: Format override ("json", "csv").
            show_cli: Whether to display CLI output.

        Raises:
            ValueError: If output path uses unsupported extension.
            OSError: If output path is not writable.
        """
        # Display CLI summary to stdout
        if show_cli:
            format_cli_report(report)

        # Export to file if requested
        if output_path:
            fmt = self._resolve_format(output_path, output_format)
            self._export_to_file(report, output_path, fmt)
            from rich.console import Console

            console = Console()
            console.print(
                f"  [bold green]✓[/bold green] Report saved to: "
                f"[bold]{output_path}[/bold]"
            )
            console.print()

    def _resolve_format(self, output_path: Path, output_format: str | None) -> str:
        """Determine output format from flag or file extension.

        Args:
            output_path: Target file path.
            output_format: Explicit format flag (takes precedence).

        Returns:
            Format string: "json" or "csv".

        Raises:
            ValueError: If format cannot be determined or is unsupported.
        """
        if output_format:
            fmt = output_format.lower()
            if fmt not in ("json", "csv"):
                raise ValueError(
                    f"Unsupported output format: '{output_format}'. Use 'json' or 'csv'."
                )
            return fmt

        # Infer from file extension
        ext = output_path.suffix.lower()
        if ext == ".json":
            return "json"
        elif ext == ".csv":
            return "csv"
        else:
            raise ValueError(
                f"Unsupported file extension: '{ext}'. Use '.json' or '.csv', "
                f"or specify --format explicitly."
            )

    def _export_to_file(self, report: ScanReport, path: Path, fmt: str) -> None:
        """Export report to file in the specified format.

        Args:
            report: Scan report to export.
            path: Target file path.
            fmt: Output format ("json" or "csv").

        Raises:
            OSError: If file is not writable.
        """
        # Ensure parent directory exists
        path.parent.mkdir(parents=True, exist_ok=True)

        if fmt == "json":
            export_json(report, path)
        elif fmt == "csv":
            export_csv(report, path)
