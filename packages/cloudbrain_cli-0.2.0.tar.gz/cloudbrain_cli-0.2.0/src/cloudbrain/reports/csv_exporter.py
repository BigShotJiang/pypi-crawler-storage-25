"""CSV report exporter — produces a clean spreadsheet-ready report."""

import csv
import re
from pathlib import Path

from cloudbrain.reports.models import ScanReport

_ACCOUNT_ID_PATTERN = re.compile(r"\b(\d{12})\b")


def export_csv(report: ScanReport, path: Path) -> None:
    """Export scan report as CSV file.

    Only includes actionable findings (savings > $0).
    Sorted by savings descending. Ready for Excel/Google Sheets.

    Args:
        report: Scan report to export.
        path: Target file path.
    """
    # Filter and sort
    actionable = [
        f for f in report.findings if f.estimated_savings_usd > 0
    ]
    actionable.sort(
        key=lambda f: f.estimated_savings_usd,
        reverse=True,
    )

    columns = [
        "Rank",
        "Category",
        "Resource ID",
        "Finding Type",
        "Risk Level",
        "Estimated Monthly Savings (USD)",
        "Estimated Annual Savings (USD)",
        "Confidence",
        "Recommendation",
        "Current Configuration",
        "Recommended Configuration",
    ]

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)

        # Header row with report metadata
        writer.writerow([
            f"cloudbrain Cost Report — "
            f"Generated: {report.metadata.timestamp}"
        ])
        writer.writerow([
            f"Providers: {', '.join(report.metadata.providers)} | "
            f"Observation Window: {report.metadata.observation_window_days} days | "
            f"Total Monthly Savings: "
            f"${report.total_estimated_savings:,.2f}"
        ])
        writer.writerow([])  # Blank row

        # Column headers
        writer.writerow(columns)

        # Data rows
        for rank, finding in enumerate(actionable, 1):
            # Extract current/recommended config from metadata
            current_config = finding.metadata.get(
                "current_config", ""
            )
            recommended_config = finding.metadata.get(
                "recommended_config", ""
            )

            # Clean recommendation for CSV (single line)
            rec_clean = finding.recommendation.replace("\n", " | ")
            rec_clean = re.sub(r"\s+", " ", rec_clean).strip()

            writer.writerow([
                rank,
                finding.category.value,
                _mask_account_ids(finding.resource_id),
                finding.finding_type.replace("_", " ").title(),
                _risk_label(finding.risk_score),
                f"{finding.estimated_savings_usd:.2f}",
                f"{finding.estimated_savings_usd * 12:.2f}",
                finding.confidence.value,
                rec_clean,
                current_config,
                recommended_config,
            ])

        # Summary footer
        writer.writerow([])
        writer.writerow(["TOTAL", "", "", "", "",
                         f"{sum(f.estimated_savings_usd for f in actionable):.2f}",
                         f"{sum(f.estimated_savings_usd for f in actionable) * 12:.2f}",
                         "", "", "", ""])


def _mask_account_ids(text: str) -> str:
    """Mask AWS account IDs (show only last 4 digits)."""
    return _ACCOUNT_ID_PATTERN.sub(lambda m: f"****{m.group(1)[-4:]}", text)


def _risk_label(risk_score: int) -> str:
    """Convert risk score to label."""
    if risk_score <= 2:
        return "Low"
    elif risk_score == 3:
        return "Medium"
    else:
        return "High"
