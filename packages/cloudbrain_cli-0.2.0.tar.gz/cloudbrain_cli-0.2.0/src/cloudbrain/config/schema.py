"""Configuration schema using Pydantic for validation."""

from pydantic import BaseModel, Field, field_validator


class ThresholdConfig(BaseModel):
    """Configurable thresholds for scan rules."""

    cpu_idle_percent: float = Field(default=5.0, ge=0, le=100)
    cpu_underutilized_percent: float = Field(default=20.0, ge=0, le=100)
    cluster_idle_minutes: int = Field(default=30, ge=1)
    warehouse_idle_minutes: int = Field(default=60, ge=1)
    warehouse_low_query_rate: int = Field(default=5, ge=1)
    ebs_orphan_days: int = Field(default=7, ge=1)
    snapshot_age_days: int = Field(default=90, ge=1)
    s3_access_days: int = Field(default=90, ge=1)
    nat_low_traffic_gb: float = Field(default=1.0, ge=0)
    cross_region_cost_threshold: float = Field(default=100.0, ge=0)
    shuffle_ratio_threshold: float = Field(default=2.0, ge=0)
    cluster_utilization_threshold: float = Field(default=20.0, ge=0, le=100)

    @field_validator("cpu_underutilized_percent")
    @classmethod
    def underutilized_gt_idle(cls, v: float, info: object) -> float:
        """Ensure underutilized threshold is greater than idle threshold."""
        # Note: cross-field validation happens at ScanConfig level
        return v


class DefaultsConfig(BaseModel):
    """Default values for CLI flags."""

    regions: list[str] = Field(default_factory=lambda: ["us-east-1"])
    output_format: str = Field(default="cli")
    providers: list[str] = Field(default_factory=list)


class ScanConfig(BaseModel):
    """Complete scan configuration."""

    observation_window_days: int = Field(default=90, ge=1, le=365)
    thresholds: ThresholdConfig = Field(default_factory=ThresholdConfig)
    defaults: DefaultsConfig = Field(default_factory=DefaultsConfig)

    @field_validator("observation_window_days")
    @classmethod
    def validate_window(cls, v: int) -> int:
        """Ensure observation window is reasonable."""
        if v > 90:
            import warnings

            warnings.warn(
                f"Observation window of {v} days may result in slow scans",
                stacklevel=2,
            )
        return v
