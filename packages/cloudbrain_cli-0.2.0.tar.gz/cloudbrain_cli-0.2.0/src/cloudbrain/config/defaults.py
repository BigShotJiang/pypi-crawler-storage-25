"""Default configuration template for cloudbrain init."""

DEFAULT_CONFIG_YAML = """\
# cloudbrain configuration
# Location: ~/.cloudbrain/config.yaml

# Number of days to look back for utilization metrics
observation_window_days: 14

# Thresholds for identifying inefficiencies
thresholds:
  # EC2 instance with avg CPU below this is classified as idle
  cpu_idle_percent: 5

  # EC2 instance with avg CPU below this (but above idle) is underutilized
  cpu_underutilized_percent: 20

  # Databricks cluster idle for longer than this triggers a finding
  cluster_idle_minutes: 30

  # SQL warehouse with no queries for longer than this triggers a finding
  warehouse_idle_minutes: 60

  # SQL warehouse with fewer queries/hour than this is considered low-usage
  warehouse_low_query_rate: 5

  # EBS volume unattached for longer than this is flagged
  ebs_orphan_days: 7

  # Snapshots older than this (not referenced by AMI) are flagged
  snapshot_age_days: 90

  # S3 objects not accessed in this many days are IA candidates
  s3_access_days: 90

  # NAT Gateway processing less than this per day is flagged
  nat_low_traffic_gb: 1.0

  # Cross-region transfer paths above this monthly cost are flagged
  cross_region_cost_threshold: 100.0

  # Spark shuffle write exceeding this multiple of input is flagged
  shuffle_ratio_threshold: 2.0

  # Cluster memory utilization below this percent is flagged
  cluster_utilization_threshold: 20.0

# Default values (overridden by CLI flags)
defaults:
  regions:
    - us-east-1
  output_format: cli
  providers: []
"""
