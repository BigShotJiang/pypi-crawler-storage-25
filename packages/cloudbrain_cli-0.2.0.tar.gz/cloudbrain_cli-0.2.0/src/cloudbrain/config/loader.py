"""Configuration file loading and merging."""

import logging
from pathlib import Path

import yaml
from pydantic import ValidationError

from cloudbrain.config.schema import ScanConfig
from cloudbrain.errors import ConfigValidationError

logger = logging.getLogger("cloudbrain.config")

CONFIG_DIR = Path.home() / ".cloudbrain"
CONFIG_FILE = CONFIG_DIR / "config.yaml"


def load_config(config_path: Path | None = None) -> ScanConfig:
    """Load and validate configuration from YAML file.

    Args:
        config_path: Optional path to config file. Defaults to ~/.cloudbrain/config.yaml.

    Returns:
        Validated ScanConfig instance.

    Raises:
        ConfigValidationError: If the config file contains invalid YAML or fails validation.
    """
    path = config_path or CONFIG_FILE

    if not path.exists():
        logger.debug("No config file found at %s, using defaults", path)
        return ScanConfig()

    logger.debug("Loading config from %s", path)

    try:
        with open(path) as f:
            raw = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigValidationError(f"Invalid YAML in {path}: {e}") from e

    if raw is None:
        return ScanConfig()

    if not isinstance(raw, dict):
        raise ConfigValidationError(
            f"Config file {path} must contain a YAML mapping, got {type(raw).__name__}"
        )

    # Check for unrecognized top-level keys
    valid_keys = {"observation_window_days", "thresholds", "defaults"}
    unknown_keys = set(raw.keys()) - valid_keys
    if unknown_keys:
        raise ConfigValidationError(
            f"Unrecognized keys in {path}: {', '.join(sorted(unknown_keys))}. "
            f"Valid keys are: {', '.join(sorted(valid_keys))}"
        )

    try:
        return ScanConfig(**raw)
    except ValidationError as e:
        # Extract the first error for a clear message
        first_error = e.errors()[0]
        field_path = " → ".join(str(loc) for loc in first_error["loc"])
        raise ConfigValidationError(
            f"Invalid value in {path} at '{field_path}': {first_error['msg']}"
        ) from e
