"""Allow running cloudbrain as a module: python -m cloudbrain."""

from cloudbrain.cli.main import cli

if __name__ == "__main__":
    cli()
