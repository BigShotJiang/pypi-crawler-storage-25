"""Custom exceptions for cloudbrain."""

from dataclasses import dataclass, field
from datetime import UTC, datetime


class CloudbrainError(Exception):
    """Base exception for all cloudbrain errors."""


class AuthenticationError(CloudbrainError):
    """Raised when authentication with a cloud provider fails."""


class ConnectionTimeoutError(CloudbrainError):
    """Raised when an API connection times out."""


class ConfigValidationError(CloudbrainError):
    """Raised when the configuration file is invalid."""


@dataclass
class ScanWarning:
    """Non-fatal issue captured during scanning."""

    provider: str
    resource_type: str
    reason: str
    timestamp: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
