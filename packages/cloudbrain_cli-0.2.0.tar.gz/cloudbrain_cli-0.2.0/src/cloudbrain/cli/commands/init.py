"""Implementation of the 'cloudbrain init' command."""

import sys

import click

from cloudbrain.config.defaults import DEFAULT_CONFIG_YAML
from cloudbrain.config.loader import CONFIG_DIR, CONFIG_FILE


def execute_init() -> None:
    """Generate default configuration file.

    Creates ~/.cloudbrain/config.yaml with documented default thresholds.
    """
    if CONFIG_FILE.exists():
        overwrite = click.confirm(
            f"Config file already exists at {CONFIG_FILE}. Overwrite?",
            default=False,
        )
        if not overwrite:
            click.echo("Aborted.")
            sys.exit(0)

    # Create directory
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Write default config
    CONFIG_FILE.write_text(DEFAULT_CONFIG_YAML)

    click.echo(f"✓ Configuration file created at {CONFIG_FILE}")
    click.echo("  Edit thresholds to customize scan behavior.")
