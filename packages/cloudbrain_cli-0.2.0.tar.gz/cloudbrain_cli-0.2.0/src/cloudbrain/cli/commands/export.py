"""Implementation of the 'cloudbrain export' command."""

import json
import sys
from datetime import UTC, datetime
from pathlib import Path

import click

from cloudbrain.engine.models import Category, Confidence, Finding
from cloudbrain.errors import ScanWarning
from cloudbrain.reports import ScanMetadata, ScanReport
from cloudbrain.reports.csv_exporter import export_csv
from cloudbrain.reports.json_exporter import export_json

CACHE_FILE = Path.home() / ".cloudbrain" / "last_scan.json"
DOWNLOADS_DIR = Path.home() / "Downloads"


def execute_export(fmt: str) -> None:
    """Export the last scan result to a file in Downloads.

    Args:
        fmt: Output format — "json" or "csv".
    """
    if not CACHE_FILE.exists():
        click.echo(
            "Error: No scan results found. Run a scan first:\n\n"
            "  cloudbrain scan --provider databricks\n"
            "  cloudbrain scan --provider aws\n",
            err=True,
        )
        sys.exit(1)

    # Load cached report
    try:
        with open(CACHE_FILE) as f:
            cache_data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        click.echo(f"Error reading cached scan: {e}", err=True)
        sys.exit(1)

    # Reconstruct report from cache
    report = _rebuild_report(cache_data)

    # Generate filename
    DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
    providers = "_".join(report.metadata.providers)
    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    filename = f"cloudbrain_{providers}_{timestamp}.{fmt}"
    output_path = DOWNLOADS_DIR / filename

    # Export
    if fmt == "json":
        export_json(report, output_path)
    elif fmt == "csv":
        export_csv(report, output_path)

    click.echo(f"\n  ✓ Report saved to: {output_path}\n")


def _rebuild_report(cache_data: dict) -> ScanReport:
    """Rebuild a ScanReport from cached JSON data."""
    meta = cache_data.get("metadata", {})

    findings = []
    for f in cache_data.get("findings", []):
        findings.append(Finding(
            category=Category(f["category"]),
            resource_id=f["resource_id"],
            finding_type=f["finding_type"],
            recommendation=f["recommendation"],
            estimated_savings_usd=f["estimated_savings_usd"],
            risk_score=f["risk_score"],
            confidence=Confidence(f["confidence"]),
            metadata=f.get("metadata", {}),
        ))

    warnings = []
    for w in cache_data.get("warnings", []):
        warnings.append(ScanWarning(
            provider=w["provider"],
            resource_type=w["resource_type"],
            reason=w["reason"],
            timestamp=w.get("timestamp", ""),
        ))

    return ScanReport(
        metadata=ScanMetadata(
            timestamp=meta.get("timestamp", ""),
            providers=meta.get("providers", []),
            regions=meta.get("regions", []),
            observation_window_days=meta.get("observation_window_days", 90),
            version=meta.get("version", "0.1.0"),
        ),
        findings=findings,
        warnings=warnings,
    )
