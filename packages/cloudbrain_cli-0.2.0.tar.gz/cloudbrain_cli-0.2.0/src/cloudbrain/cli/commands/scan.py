"""Implementation of the 'cloudbrain scan' command."""

import json
import sys
from pathlib import Path

import click

from cloudbrain.config import load_config
from cloudbrain.engine.models import Finding
from cloudbrain.errors import AuthenticationError, CloudbrainError, ConfigValidationError
from cloudbrain.logging import setup_logging
from cloudbrain.reports import ReportGenerator, ScanMetadata, ScanReport
from cloudbrain.scanners.base import ScanResult

# Cache location for last scan result
CACHE_DIR = Path.home() / ".cloudbrain"
CACHE_FILE = CACHE_DIR / "last_scan.json"


def execute_scan(
    providers: list[str],
    regions: list[str] | None,
    role_arn: str | None,
    token: str | None,
    workspace_url: str | None,
    output_path: Path | None,
    output_format: str | None,
    verbose: bool,
) -> None:
    """Execute the scan command — show results in terminal only."""
    # Setup logging
    setup_logging(verbose=verbose)

    # Load configuration
    try:
        config = load_config()
    except ConfigValidationError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    # Resolve regions
    scan_regions = regions or config.defaults.regions

    # Collect results from all providers
    all_findings: list[Finding] = []
    all_warnings: list = []

    for provider in providers:
        try:
            result = _scan_provider(
                provider=provider,
                config=config,
                regions=scan_regions,
                role_arn=role_arn,
                token=token,
                workspace_url=workspace_url,
            )
            all_findings.extend(result.findings)
            all_warnings.extend(result.warnings)
        except AuthenticationError as e:
            click.echo(f"Error [{provider}]: {e}", err=True)
            sys.exit(1)
        except CloudbrainError as e:
            click.echo(f"Error [{provider}]: {e}", err=True)
            sys.exit(1)

    # Sort all findings by priority
    all_findings.sort(
        key=lambda f: (f.priority_score, f.estimated_savings_usd),
        reverse=True,
    )

    # Build report
    report = ScanReport(
        metadata=ScanMetadata(
            providers=providers,
            regions=scan_regions,
            observation_window_days=config.observation_window_days,
        ),
        findings=all_findings,
        warnings=all_warnings,
    )

    # Display in terminal
    generator = ReportGenerator()
    generator.generate(report, output_path=output_path, output_format=output_format)

    # Cache the result for later export
    _cache_report(report)

    click.echo(
        "  💡 To save this report, run: "
        "cloudbrain export json  or  cloudbrain export csv\n"
    )


def _cache_report(report: ScanReport) -> None:
    """Cache the scan report for later export."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    cache_data = {
        "metadata": {
            "timestamp": report.metadata.timestamp,
            "providers": report.metadata.providers,
            "regions": report.metadata.regions,
            "observation_window_days": report.metadata.observation_window_days,
            "version": report.metadata.version,
        },
        "findings": [
            {
                "category": f.category.value,
                "resource_id": f.resource_id,
                "finding_type": f.finding_type,
                "recommendation": f.recommendation,
                "estimated_savings_usd": f.estimated_savings_usd,
                "risk_score": f.risk_score,
                "confidence": f.confidence.value,
                "metadata": f.metadata,
            }
            for f in report.findings
        ],
        "warnings": [
            {
                "provider": w.provider,
                "resource_type": w.resource_type,
                "reason": w.reason,
                "timestamp": w.timestamp,
            }
            for w in report.warnings
        ],
    }

    with open(CACHE_FILE, "w") as f:
        json.dump(cache_data, f, indent=2, default=str)


def _scan_provider(
    provider: str,
    config: object,
    regions: list[str],
    role_arn: str | None,
    token: str | None,
    workspace_url: str | None,
) -> ScanResult:
    """Scan a single provider."""
    if provider == "aws":
        return _scan_aws(config, regions, role_arn)  # type: ignore[arg-type]
    elif provider == "databricks":
        return _scan_databricks(config, token, workspace_url)  # type: ignore[arg-type]
    else:
        raise CloudbrainError(f"Unknown provider: {provider}")


def _scan_aws(
    config: object, regions: list[str], role_arn: str | None
) -> ScanResult:
    """Execute AWS scan."""
    from cloudbrain.auth.aws import AWSCredentialManager
    from cloudbrain.scanners.aws import AWSScanner

    auth = AWSCredentialManager()
    session = auth.authenticate(role_arn=role_arn, region=regions[0])
    scanner = AWSScanner(session=session, regions=regions)
    return scanner.scan(config)  # type: ignore[arg-type]


def _scan_databricks(
    config: object, token: str | None, workspace_url: str | None
) -> ScanResult:
    """Execute Databricks scan."""
    from cloudbrain.auth.databricks import DatabricksCredentialManager
    from cloudbrain.scanners.databricks import DatabricksScanner

    auth = DatabricksCredentialManager()
    client = auth.authenticate(token=token, workspace_url=workspace_url)
    scanner = DatabricksScanner(client=client)
    return scanner.scan(config)  # type: ignore[arg-type]
