"""Main CLI entry point using Click."""

import sys

import click

from cloudbrain import __version__

VALID_PROVIDERS = ["aws", "databricks"]


@click.group()
@click.version_option(version=__version__, prog_name="cloudbrain")
def cli() -> None:
    """cloudbrain — Infrastructure Cost Intelligence CLI.

    Safe, read-only cloud cost optimization scanner.
    """


@cli.command()
@click.option(
    "--provider",
    multiple=True,
    type=click.Choice(VALID_PROVIDERS, case_sensitive=False),
    help="Cloud provider to scan (can be specified multiple times).",
)
@click.option(
    "--regions",
    default=None,
    help="Comma-separated AWS regions to scan (default: from config).",
)
@click.option(
    "--role-arn",
    default=None,
    help="AWS IAM role ARN for cross-account scanning.",
)
@click.option(
    "--token",
    default=None,
    help="Databricks Personal Access Token.",
)
@click.option(
    "--workspace-url",
    default=None,
    help="Databricks workspace URL.",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable debug logging to ~/.cloudbrain/debug.log.",
)
def scan(
    provider: tuple[str, ...],
    regions: str | None,
    role_arn: str | None,
    token: str | None,
    workspace_url: str | None,
    verbose: bool,
) -> None:
    """Scan cloud infrastructure for cost optimization opportunities."""
    from cloudbrain.cli.commands.scan import execute_scan

    # Handle interactive vs non-interactive provider selection
    providers = list(provider)
    if not providers:
        if sys.stdin.isatty():
            providers = _interactive_provider_select()
        else:
            click.echo(
                "Error: --provider flag is required in non-interactive mode.\n"
                f"Valid providers: {', '.join(VALID_PROVIDERS)}",
                err=True,
            )
            sys.exit(1)

    if not providers:
        sys.exit(0)

    # Parse regions
    region_list = [r.strip() for r in regions.split(",")] if regions else None

    # Execute scan
    execute_scan(
        providers=providers,
        regions=region_list,
        role_arn=role_arn,
        token=token,
        workspace_url=workspace_url,
        output_path=None,
        output_format=None,
        verbose=verbose,
    )


@cli.command()
def init() -> None:
    """Generate default configuration file at ~/.cloudbrain/config.yaml."""
    from cloudbrain.cli.commands.init import execute_init

    execute_init()


@cli.command(name="export")
@click.argument("fmt", type=click.Choice(["json", "csv"], case_sensitive=False))
def export_report(fmt: str) -> None:
    """Export the last scan result to ~/Downloads.

    Saves the most recent scan as JSON or CSV without re-running the scan.

    \b
    Examples:
      cloudbrain export json
      cloudbrain export csv
    """
    from cloudbrain.cli.commands.export import execute_export

    execute_export(fmt.lower())


def _interactive_provider_select() -> list[str]:
    """Present interactive provider selection prompt.

    Returns:
        List of selected provider names.
    """
    click.echo("\nAvailable providers:")
    for idx, provider in enumerate(VALID_PROVIDERS, 1):
        click.echo(f"  {idx}. {provider}")
    click.echo()

    selection = click.prompt(
        "Select providers (comma-separated numbers or names)",
        default="1,2",
    )

    selected: list[str] = []
    for item in selection.split(","):
        item = item.strip().lower()
        if item.isdigit():
            idx = int(item) - 1
            if 0 <= idx < len(VALID_PROVIDERS):
                selected.append(VALID_PROVIDERS[idx])
        elif item in VALID_PROVIDERS:
            selected.append(item)

    if not selected:
        click.echo("No valid providers selected.", err=True)
        return []

    click.echo(f"\nScanning: {', '.join(selected)}\n")
    return selected
