"""CLI module for cloudbrain."""
