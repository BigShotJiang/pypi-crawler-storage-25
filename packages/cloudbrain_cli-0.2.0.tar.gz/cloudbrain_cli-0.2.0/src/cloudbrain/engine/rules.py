"""Rule definitions for the recommendation engine."""

from collections.abc import Callable
from dataclasses import dataclass

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import (
    Category,
    Confidence,
    Finding,
    ResourceMetadata,
    ResourceMetrics,
)


@dataclass
class Rule:
    """A single optimization rule.

    Attributes:
        id: Unique rule identifier.
        category: Finding category this rule produces.
        description: Human-readable description of what the rule detects.
        condition: Function that returns True if the rule matches.
        finding_generator: Function that produces a Finding when the rule matches.
    """

    id: str
    category: Category
    description: str
    condition: Callable[[ResourceMetadata, ResourceMetrics, ScanConfig], bool]
    finding_generator: Callable[[ResourceMetadata, ResourceMetrics, ScanConfig], Finding]


# --- AWS Compute Rules ---


def _is_idle_ec2(res: ResourceMetadata, metrics: ResourceMetrics, config: ScanConfig) -> bool:
    """Check if EC2 instance is idle (CPU < idle threshold)."""
    if metrics.avg_cpu_percent is None:
        return False
    if metrics.observation_coverage_percent < 50.0:
        return False
    return metrics.avg_cpu_percent < config.thresholds.cpu_idle_percent


def _is_underutilized_ec2(
    res: ResourceMetadata, metrics: ResourceMetrics, config: ScanConfig
) -> bool:
    """Check if EC2 instance is underutilized (idle < CPU < underutilized threshold)."""
    if metrics.avg_cpu_percent is None:
        return False
    if metrics.observation_coverage_percent < 50.0:
        return False
    return (
        config.thresholds.cpu_idle_percent
        <= metrics.avg_cpu_percent
        < config.thresholds.cpu_underutilized_percent
    )


def _generate_idle_ec2_finding(
    res: ResourceMetadata, metrics: ResourceMetrics, config: ScanConfig
) -> Finding:
    """Generate finding for idle EC2 instance."""
    instance_type = res.properties.get("instance_type", "unknown")
    monthly_cost = res.properties.get("monthly_cost", 0.0)

    return Finding(
        category=Category.COMPUTE,
        resource_id=res.resource_id,
        finding_type="idle_ec2_instance",
        recommendation=(
            f"Instance {res.resource_id} ({instance_type}) has avg CPU of "
            f"{metrics.avg_cpu_percent:.1f}% over {config.observation_window_days} days. "
            f"Consider stopping or terminating."
        ),
        estimated_savings_usd=monthly_cost,
        risk_score=2,
        confidence=_metrics_confidence(metrics),
        metadata={
            "instance_type": instance_type,
            "avg_cpu_percent": metrics.avg_cpu_percent,
            "region": res.region,
        },
    )


def _generate_underutilized_ec2_finding(
    res: ResourceMetadata, metrics: ResourceMetrics, config: ScanConfig
) -> Finding:
    """Generate finding for underutilized EC2 instance."""
    instance_type = res.properties.get("instance_type", "unknown")
    suggested_type = res.properties.get("suggested_instance_type", "smaller instance")
    savings = res.properties.get("rightsizing_savings", 0.0)

    return Finding(
        category=Category.COMPUTE,
        resource_id=res.resource_id,
        finding_type="underutilized_ec2_instance",
        recommendation=(
            f"Instance {res.resource_id} ({instance_type}) has avg CPU of "
            f"{metrics.avg_cpu_percent:.1f}%. Consider rightsizing to {suggested_type}."
        ),
        estimated_savings_usd=savings,
        risk_score=3,
        confidence=_metrics_confidence(metrics),
        metadata={
            "instance_type": instance_type,
            "suggested_type": suggested_type,
            "avg_cpu_percent": metrics.avg_cpu_percent,
            "peak_cpu_percent": metrics.peak_cpu_percent,
            "region": res.region,
        },
    )


# --- Helper ---


def _metrics_confidence(metrics: ResourceMetrics) -> Confidence:
    """Derive confidence from metrics coverage."""
    from cloudbrain.engine.risk import calculate_confidence

    return calculate_confidence(metrics.observation_coverage_percent)


# --- Rule Registry ---

AWS_COMPUTE_RULES: list[Rule] = [
    Rule(
        id="aws-compute-idle-ec2",
        category=Category.COMPUTE,
        description="EC2 instance with avg CPU below idle threshold",
        condition=_is_idle_ec2,
        finding_generator=_generate_idle_ec2_finding,
    ),
    Rule(
        id="aws-compute-underutilized-ec2",
        category=Category.COMPUTE,
        description="EC2 instance with avg CPU below underutilized threshold",
        condition=_is_underutilized_ec2,
        finding_generator=_generate_underutilized_ec2_finding,
    ),
]

# All rules combined
ALL_RULES: list[Rule] = [
    *AWS_COMPUTE_RULES,
]
