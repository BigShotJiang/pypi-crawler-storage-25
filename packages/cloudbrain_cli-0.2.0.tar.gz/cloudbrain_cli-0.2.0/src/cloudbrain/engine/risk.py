"""Risk scoring logic for findings."""

from cloudbrain.engine.models import Confidence

# Production-indicating tag patterns
_PRODUCTION_TAG_VALUES = {"production", "prod"}
_SLA_TAG_KEY = "sla"


def calculate_confidence(coverage_percent: float) -> Confidence:
    """Determine confidence level based on metrics coverage.

    Args:
        coverage_percent: Percentage of observation window covered by metrics (0-100).

    Returns:
        Confidence level.
    """
    if coverage_percent >= 100.0:
        return Confidence.HIGH
    elif coverage_percent >= 50.0:
        return Confidence.MEDIUM
    else:
        return Confidence.LOW


def adjust_risk_for_tags(base_risk: int, tags: dict[str, str]) -> int:
    """Adjust risk score based on resource tags.

    Increases risk by 1 if:
    - Tag "Environment" is set to "production" or "prod" (case-insensitive)
    - Tag "SLA" exists with any value (case-insensitive key match)

    Args:
        base_risk: Initial risk score (1-5).
        tags: Resource tags as key-value pairs.

    Returns:
        Adjusted risk score, capped at 5.
    """
    adjustment = 0

    # Normalize tags for case-insensitive comparison
    normalized_tags = {k.lower(): v.lower() for k, v in tags.items()}

    # Check for production environment tag
    env_value = normalized_tags.get("environment", "")
    if env_value in _PRODUCTION_TAG_VALUES:
        adjustment = 1

    # Check for SLA tag (any value)
    if _SLA_TAG_KEY in normalized_tags:
        adjustment = 1

    return min(5, base_risk + adjustment)
