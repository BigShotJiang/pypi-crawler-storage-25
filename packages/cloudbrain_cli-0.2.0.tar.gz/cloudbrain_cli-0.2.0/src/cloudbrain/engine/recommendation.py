"""Recommendation engine — orchestrates rules evaluation and finding generation."""

import logging

from cloudbrain.config.schema import ScanConfig
from cloudbrain.engine.models import Finding, ResourceMetadata, ResourceMetrics
from cloudbrain.engine.risk import adjust_risk_for_tags
from cloudbrain.engine.rules import ALL_RULES

logger = logging.getLogger("cloudbrain.engine")


class RecommendationEngine:
    """Evaluates scan results against rules and produces prioritized findings."""

    def __init__(self, config: ScanConfig) -> None:
        self._config = config
        self._rules = ALL_RULES

    def analyze(
        self,
        resources: list[ResourceMetadata],
        metrics_map: dict[str, ResourceMetrics],
    ) -> list[Finding]:
        """Analyze resources against all rules and return prioritized findings.

        Args:
            resources: List of resource metadata from scanners.
            metrics_map: Mapping of resource_id to metrics data.

        Returns:
            List of findings sorted by priority score (descending).
        """
        findings: list[Finding] = []

        for resource in resources:
            metrics = metrics_map.get(resource.resource_id, ResourceMetrics(
                resource_id=resource.resource_id
            ))

            for rule in self._rules:
                try:
                    if rule.condition(resource, metrics, self._config):
                        finding = rule.finding_generator(resource, metrics, self._config)

                        # Adjust risk based on tags
                        finding.risk_score = adjust_risk_for_tags(
                            finding.risk_score, resource.tags
                        )

                        findings.append(finding)
                        # First matching rule wins per resource
                        break
                except Exception as e:
                    logger.warning(
                        "Rule %s failed for resource %s: %s",
                        rule.id,
                        resource.resource_id,
                        e,
                    )

        # Sort by priority score descending, ties broken by higher savings
        findings.sort(
            key=lambda f: (f.priority_score, f.estimated_savings_usd),
            reverse=True,
        )

        return findings

    def add_findings(self, findings: list[Finding]) -> list[Finding]:
        """Add pre-generated findings (from scanner-specific logic) and re-sort.

        Used for findings generated directly by scanners (e.g., orphaned EBS,
        idle clusters) that don't follow the resource+metrics pattern.

        Args:
            findings: Pre-generated findings to include.

        Returns:
            All findings sorted by priority score.
        """
        # Adjust risk for tags on pre-generated findings if metadata includes tags
        for finding in findings:
            tags = finding.metadata.get("tags", {})
            if tags:
                finding.risk_score = adjust_risk_for_tags(finding.risk_score, tags)

        findings.sort(
            key=lambda f: (f.priority_score, f.estimated_savings_usd),
            reverse=True,
        )
        return findings
