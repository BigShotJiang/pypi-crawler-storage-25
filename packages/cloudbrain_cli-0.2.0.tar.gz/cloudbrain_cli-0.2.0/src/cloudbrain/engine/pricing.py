"""Pricing lookup for AWS and Databricks resources."""

import json
import logging
from pathlib import Path

logger = logging.getLogger("cloudbrain.engine.pricing")

# Pricing data directory (bundled with package)
_PRICING_DIR = Path(__file__).parent / "pricing_data"


class PricingEngine:
    """Looks up on-demand pricing for cloud resources.

    Uses bundled JSON pricing data for offline operation.
    Falls back to $0.00 if pricing is unavailable.
    """

    def __init__(self) -> None:
        self._ec2_prices: dict[str, dict[str, float]] = {}
        self._ebs_prices: dict[str, dict[str, float]] = {}
        self._dbu_rates: dict[str, float] = {}
        self._loaded = False

    def _ensure_loaded(self) -> None:
        """Lazy-load pricing data on first access."""
        if self._loaded:
            return

        self._ec2_prices = self._load_json("aws_ec2.json")
        self._ebs_prices = self._load_json("aws_ebs.json")
        self._dbu_rates = self._load_json("databricks_dbu.json")
        self._loaded = True

    @staticmethod
    def _load_json(filename: str) -> dict:
        """Load a pricing JSON file, returning empty dict on failure."""
        filepath = _PRICING_DIR / filename
        if not filepath.exists():
            logger.warning("Pricing data not found: %s", filepath)
            return {}
        try:
            with open(filepath) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load pricing data %s: %s", filename, e)
            return {}

    def get_ec2_hourly_rate(self, instance_type: str, region: str) -> float | None:
        """Get on-demand hourly rate for an EC2 instance type.

        Args:
            instance_type: e.g., "t3.medium", "m5.xlarge"
            region: AWS region, e.g., "us-east-1"

        Returns:
            Hourly rate in USD, or None if unavailable.
        """
        self._ensure_loaded()
        region_prices = self._ec2_prices.get(region, {})
        return region_prices.get(instance_type)

    def get_ec2_monthly_rate(self, instance_type: str, region: str) -> float | None:
        """Get estimated monthly cost for an EC2 instance (730 hours).

        Args:
            instance_type: e.g., "t3.medium"
            region: AWS region

        Returns:
            Monthly cost in USD, or None if unavailable.
        """
        hourly = self.get_ec2_hourly_rate(instance_type, region)
        if hourly is None:
            return None
        return round(hourly * 730, 2)

    def get_ebs_monthly_rate_per_gb(self, volume_type: str, region: str) -> float | None:
        """Get monthly cost per GB for an EBS volume type.

        Args:
            volume_type: e.g., "gp3", "io1", "st1"
            region: AWS region

        Returns:
            Monthly cost per GB in USD, or None if unavailable.
        """
        self._ensure_loaded()
        region_prices = self._ebs_prices.get(region, {})
        return region_prices.get(volume_type)

    def get_ebs_monthly_cost(self, volume_type: str, size_gb: int, region: str) -> float | None:
        """Get total monthly cost for an EBS volume.

        Args:
            volume_type: EBS volume type
            size_gb: Volume size in GB
            region: AWS region

        Returns:
            Monthly cost in USD rounded to 2 decimal places, or None.
        """
        rate = self.get_ebs_monthly_rate_per_gb(volume_type, region)
        if rate is None:
            return None
        return round(rate * size_gb, 2)

    def get_dbu_rate(self, node_type: str) -> float | None:
        """Get DBU per hour rate for a Databricks node type.

        Args:
            node_type: Databricks node type identifier.

        Returns:
            DBU/hour rate, or None if unavailable.
        """
        self._ensure_loaded()
        return self._dbu_rates.get(node_type)

    def get_elb_hourly_rate(self, elb_type: str = "application") -> float:
        """Get hourly charge for an Elastic Load Balancer.

        Args:
            elb_type: "application", "network", or "classic"

        Returns:
            Hourly rate in USD. Uses known fixed rates.
        """
        # These are well-known fixed rates (us-east-1 baseline)
        rates = {
            "application": 0.0225,
            "network": 0.0225,
            "classic": 0.025,
        }
        return rates.get(elb_type, 0.0225)

    def get_eip_hourly_rate(self) -> float:
        """Get hourly charge for an unassociated Elastic IP.

        Returns:
            Hourly rate in USD (fixed AWS rate).
        """
        return 0.005
