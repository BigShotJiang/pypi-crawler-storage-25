"""Data models for the recommendation engine."""

from dataclasses import dataclass, field
from enum import Enum


class Category(Enum):
    """Finding categories for grouping recommendations."""

    COMPUTE = "Compute"
    STORAGE = "Storage"
    NETWORKING = "Networking"
    DATABRICKS_CLUSTERS = "Databricks Clusters"
    DATABRICKS_WAREHOUSES = "Databricks Warehouses"
    DATABRICKS_JOBS = "Databricks Jobs"


class Confidence(Enum):
    """Confidence level based on metrics data coverage."""

    HIGH = "High"  # 100% observation window coverage
    MEDIUM = "Medium"  # 50-99% coverage
    LOW = "Low"  # <50% coverage


@dataclass
class Finding:
    """A single identified inefficiency with optimization recommendation."""

    category: Category
    resource_id: str
    finding_type: str
    recommendation: str
    estimated_savings_usd: float
    risk_score: int
    confidence: Confidence
    metadata: dict = field(default_factory=dict)

    @property
    def priority_score(self) -> float:
        """Calculate priority: savings × (6 - risk_score).

        Higher priority = more savings with lower risk.
        """
        return self.estimated_savings_usd * (6 - self.risk_score)

    def __post_init__(self) -> None:
        """Validate and normalize field values."""
        # Ensure savings is rounded to 2 decimal places
        self.estimated_savings_usd = round(self.estimated_savings_usd, 2)

        # Clamp risk score to valid range
        self.risk_score = max(1, min(5, self.risk_score))


@dataclass
class ResourceMetadata:
    """Metadata collected from a cloud resource."""

    provider: str
    resource_type: str
    resource_id: str
    region: str
    tags: dict[str, str] = field(default_factory=dict)
    properties: dict = field(default_factory=dict)


@dataclass
class ResourceMetrics:
    """Utilization metrics for a resource over the observation window."""

    resource_id: str
    avg_cpu_percent: float | None = None
    peak_cpu_percent: float | None = None
    avg_memory_percent: float | None = None
    data_points_count: int = 0
    observation_coverage_percent: float = 0.0
    custom_metrics: dict = field(default_factory=dict)
