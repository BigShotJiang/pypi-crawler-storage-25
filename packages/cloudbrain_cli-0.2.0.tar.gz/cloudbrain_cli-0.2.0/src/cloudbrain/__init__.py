"""cloudbrain — Infrastructure Cost Intelligence CLI."""

__version__ = "0.2.0"
