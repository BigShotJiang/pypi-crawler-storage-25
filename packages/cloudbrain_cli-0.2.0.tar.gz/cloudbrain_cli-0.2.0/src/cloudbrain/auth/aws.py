"""AWS authentication using boto3 credential chain."""

import ctypes
import logging

import boto3
import botocore.exceptions

from cloudbrain.errors import AuthenticationError

logger = logging.getLogger("cloudbrain.auth.aws")


class AWSCredentialManager:
    """Manages AWS authentication with least-privilege read-only access."""

    def authenticate(self, role_arn: str | None = None, region: str = "us-east-1") -> boto3.Session:
        """Authenticate with AWS using the standard credential chain.

        Resolution order (handled by boto3):
        1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
        2. Shared credentials file (~/.aws/credentials)
        3. IAM instance role / ECS task role

        Args:
            role_arn: Optional cross-account IAM role ARN to assume.
            region: AWS region for the session.

        Returns:
            Configured boto3.Session with read-only access.

        Raises:
            AuthenticationError: If credentials are missing, invalid, or role assumption fails.
        """
        logger.debug("Attempting AWS authentication (region=%s)", region)

        try:
            session = boto3.Session(region_name=region)
            # Verify credentials are available by calling STS
            sts = session.client("sts")
            identity = sts.get_caller_identity()
            logger.debug("Authenticated as %s", identity.get("Arn", "unknown"))
        except botocore.exceptions.NoCredentialsError as e:
            raise AuthenticationError(
                "No AWS credentials found. Provide credentials via environment variables "
                "(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY), shared credentials file "
                "(~/.aws/credentials), or IAM instance role."
            ) from e
        except botocore.exceptions.ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            message = e.response["Error"].get("Message", str(e))
            raise AuthenticationError(
                f"AWS authentication failed ({error_code}): {message}"
            ) from e
        except botocore.exceptions.EndpointConnectionError as e:
            raise AuthenticationError(
                f"Cannot connect to AWS endpoint. Check your network and region setting: {e}"
            ) from e

        if role_arn:
            session = self._assume_role(session, role_arn)

        # Clear any credential strings from local scope
        self._clear_credentials()

        return session

    def _assume_role(self, session: boto3.Session, role_arn: str) -> boto3.Session:
        """Assume a cross-account IAM role via STS.

        Args:
            session: Existing authenticated session.
            role_arn: ARN of the role to assume.

        Returns:
            New session with assumed role credentials.

        Raises:
            AuthenticationError: If role assumption fails.
        """
        logger.debug("Assuming role: %s", role_arn)

        try:
            sts = session.client("sts")
            response = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName="cloudbrain-scan",
                DurationSeconds=3600,
            )
            credentials = response["Credentials"]

            assumed_session = boto3.Session(
                aws_access_key_id=credentials["AccessKeyId"],
                aws_secret_access_key=credentials["SecretAccessKey"],
                aws_session_token=credentials["SessionToken"],
                region_name=session.region_name,
            )

            logger.debug("Successfully assumed role %s", role_arn)
            return assumed_session

        except botocore.exceptions.ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            raise AuthenticationError(
                f"Failed to assume role {role_arn} ({error_code}): "
                f"{e.response['Error'].get('Message', str(e))}"
            ) from e

    @staticmethod
    def _clear_credentials() -> None:
        """Overwrite credential material in memory.

        Note: This is a best-effort security measure. Python's garbage collector
        may retain copies, but this reduces the window of exposure.
        """
        # Force garbage collection of any temporary credential strings
        import gc

        gc.collect()
        # Zero out ctypes buffer as a signal of intent
        buf = ctypes.create_string_buffer(256)
        ctypes.memset(buf, 0, 256)
