"""Databricks authentication using Personal Access Tokens."""

import logging
import os

import requests

from cloudbrain.errors import AuthenticationError, ConnectionTimeoutError

logger = logging.getLogger("cloudbrain.auth.databricks")

_CONNECTION_TIMEOUT_SECONDS = 30


class DatabricksClient:
    """Lightweight Databricks API client for read-only operations."""

    def __init__(self, workspace_url: str, token: str):
        self._base_url = workspace_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })
        self._session.timeout = _CONNECTION_TIMEOUT_SECONDS

    def get(self, endpoint: str, params: dict | None = None) -> dict:
        """Make a GET request to the Databricks API.

        Args:
            endpoint: API path (e.g., "/api/2.0/clusters/list").
            params: Optional query parameters.

        Returns:
            JSON response as dict.

        Raises:
            requests.HTTPError: On non-2xx responses.
        """
        url = f"{self._base_url}{endpoint}"
        response = self._session.get(url, params=params, timeout=_CONNECTION_TIMEOUT_SECONDS)
        response.raise_for_status()
        return response.json()

    @property
    def workspace_url(self) -> str:
        """Return the workspace base URL."""
        return self._base_url


class DatabricksCredentialManager:
    """Manages Databricks PAT authentication."""

    def authenticate(
        self,
        token: str | None = None,
        workspace_url: str | None = None,
    ) -> DatabricksClient:
        """Authenticate with a Databricks workspace.

        Token resolution: --token flag > DATABRICKS_TOKEN env var
        URL resolution: --workspace-url flag > DATABRICKS_HOST env var

        Args:
            token: Optional PAT from CLI flag.
            workspace_url: Optional workspace URL from CLI flag.

        Returns:
            Configured DatabricksClient.

        Raises:
            AuthenticationError: If token/URL missing or rejected.
            ConnectionTimeoutError: If workspace unreachable within 30s.
        """
        # Resolve token
        resolved_token = token or os.environ.get("DATABRICKS_TOKEN")
        if not resolved_token:
            raise AuthenticationError(
                "No Databricks token found. Provide a token via:\n"
                "  • --token flag\n"
                "  • DATABRICKS_TOKEN environment variable"
            )

        # Resolve workspace URL
        resolved_url = workspace_url or os.environ.get("DATABRICKS_HOST")
        if not resolved_url:
            raise AuthenticationError(
                "No Databricks workspace URL found. Provide a URL via:\n"
                "  • --workspace-url flag\n"
                "  • DATABRICKS_HOST environment variable"
            )

        # Ensure URL has scheme
        if not resolved_url.startswith("http"):
            resolved_url = f"https://{resolved_url}"

        logger.debug("Connecting to Databricks workspace: %s", resolved_url)

        # Validate connection and token
        client = DatabricksClient(resolved_url, resolved_token)
        self._validate_connection(client)

        logger.debug("Successfully authenticated with Databricks workspace")
        return client

    def _validate_connection(self, client: DatabricksClient) -> None:
        """Verify the token is valid by making a lightweight API call.

        Args:
            client: DatabricksClient to validate.

        Raises:
            AuthenticationError: If token is rejected.
            ConnectionTimeoutError: If workspace is unreachable.
        """
        try:
            # Use clusters/list with a limit as a lightweight auth check
            client.get("/api/2.0/clusters/list", params={"max_results": 1})
        except requests.exceptions.ConnectionError as e:
            raise ConnectionTimeoutError(
                f"Cannot connect to Databricks workspace at {client.workspace_url}. "
                f"Check the URL and your network connection."
            ) from e
        except requests.exceptions.Timeout as e:
            raise ConnectionTimeoutError(
                f"Connection to {client.workspace_url} timed out after "
                f"{_CONNECTION_TIMEOUT_SECONDS} seconds."
            ) from e
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code in (401, 403):
                raise AuthenticationError(
                    f"Databricks token was rejected by workspace {client.workspace_url}. "
                    f"Verify your token is valid and has not expired."
                ) from e
            raise AuthenticationError(
                f"Databricks API error: {e}"
            ) from e
