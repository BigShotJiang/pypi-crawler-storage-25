"""Logging configuration with credential redaction."""

import logging
import re
from pathlib import Path

# Patterns that indicate sensitive data
_SENSITIVE_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS access key ID
    re.compile(r"(?i)(aws_secret_access_key|secret_key)[=:]\s*\S+"),
    re.compile(r"(?i)(token|password|secret)[=:]\s*\S+"),
    re.compile(r"\b\d{12}\b"),  # AWS account ID (12 digits)
    re.compile(r"dapi[a-f0-9]{32}"),  # Databricks PAT
]


class RedactingFilter(logging.Filter):
    """Filters sensitive patterns from log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        """Redact sensitive values in the log message."""
        if isinstance(record.msg, str):
            record.msg = self._redact(record.msg)
        if record.args:
            record.args = tuple(
                self._redact(str(arg)) if isinstance(arg, str) else arg
                for arg in record.args
            )
        return True

    def _redact(self, text: str) -> str:
        """Replace sensitive patterns with masked versions."""
        for pattern in _SENSITIVE_PATTERNS:
            text = pattern.sub(self._mask_match, text)
        return text

    @staticmethod
    def _mask_match(match: re.Match[str]) -> str:
        """Keep last 4 chars, mask the rest."""
        value = match.group(0)
        if len(value) <= 4:
            return "****"
        return "*" * (len(value) - 4) + value[-4:]


def setup_logging(verbose: bool = False) -> logging.Logger:
    """Configure logging for cloudbrain.

    Args:
        verbose: If True, write debug logs to ~/.cloudbrain/debug.log.

    Returns:
        Configured root logger for cloudbrain.
    """
    logger = logging.getLogger("cloudbrain")
    logger.setLevel(logging.DEBUG if verbose else logging.WARNING)

    # Always add redacting filter
    redacting_filter = RedactingFilter()

    if verbose:
        log_dir = Path.home() / ".cloudbrain"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "debug.log"

        file_handler = logging.FileHandler(log_file, mode="w")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        )
        file_handler.addFilter(redacting_filter)
        logger.addHandler(file_handler)

    # Stderr handler for warnings/errors (always active)
    stderr_handler = logging.StreamHandler()
    stderr_handler.setLevel(logging.WARNING)
    stderr_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    stderr_handler.addFilter(redacting_filter)
    logger.addHandler(stderr_handler)

    return logger
