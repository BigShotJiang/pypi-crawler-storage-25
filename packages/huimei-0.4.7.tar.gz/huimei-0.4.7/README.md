# HuiMei 慧媒 — Chinese Social Media Automation CLI & MCP Server

[![PyPI version](https://img.shields.io/pypi/v/huimei)](https://pypi.org/project/huimei/)
[![Python](https://img.shields.io/pypi/pyversions/huimei)](https://pypi.org/project/huimei/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

**The first MCP Server for Chinese social media** — let AI agents publish to Douyin, XHS, Bilibili, Kuaishou, Weibo, and 6 more platforms through one unified interface.

## Why HuiMei?

- **🌏 Only MCP Server for Chinese social media** — Covers 11 platforms including 抖音 (Douyin), 小红书 (XHS), B站 (Bilibili), 快手 (Kuaishou), 微博 (Weibo), and more. No other tool does this.
- **🔀 CLI + MCP dual interface** — Humans use the terminal (`huimei publish`), AI agents use the MCP protocol. Same engine, two entry points.
- **🔒 Local-first execution** — Playwright runs on *your* device. Cookies are encrypted and stored locally. Your credentials never leave your machine.
- **🔄 Hybrid execution** — Cloud for convenience, local for safety. Auto mode gives you the best of both — tries your local browser first, falls back to cloud if offline.
- **⚡ Zero-config worker** — Login once, CLI stays connected. Your WebUI can dispatch tasks to your local machine with no extra setup.

## Supported Platforms

| Platform ID          | Name                     | Video | Image |
|----------------------|--------------------------|:-----:|:-----:|
| `douyin`             | 抖音 (Douyin)            |  ✅   |  ✅   |
| `xhs`                | 小红书 (Xiaohongshu/RED) |  ✅   |  ✅   |
| `bilibili`           | B站 (Bilibili)           |  ✅   |  ✅   |
| `ks`                 | 快手 (Kuaishou)          |  ✅   |  ✅   |
| `weibo`              | 微博 (Weibo)             |  ✅   |  ✅   |
| `tencent`            | 视频号 (WeChat Channels) |  ✅   |  ❌   |
| `tk`                 | TikTok                   |  ✅   |  ❌   |
| `toutiao`            | 头条 (Toutiao)           |  ✅   |  ✅   |
| `baijiahao`          | 百家号 (Baijiahao)       |  ✅   |  ❌   |
| `weixingongzhonghao` | 微信公众号 (WeChat MP)   |  ❌   |  ✅   |
| `zhihu`              | 知乎 (Zhihu)             |  ✅   |  ✅   |

## Installation

### Option 1: pip (recommended)

```bash
pip install huimei
playwright install chromium
```

### Option 2: pipx (isolated environment)

```bash
pipx install huimei
playwright install chromium
```

### Option 3: One-line install script

```bash
curl -fsSL https://raw.githubusercontent.com/huimei-engine/huimei-cli/main/install.sh | bash
```

## Quick Start

```bash
# Log in to your account
huimei login

# List supported platforms
huimei platforms

# List linked social media accounts
huimei account list

# Check CLI and connection status
huimei status
```

## Execution Modes

HuiMei supports three execution modes, configurable via WebUI (Profile → Publish Settings) or CLI:

| Mode | Description | Best For |
|------|------------|----------|
| ☁️ Cloud | Server-side engine publishes | Zero-config, batch publishing |
| 💻 Local | CLI opens local browser | Residential IP, lower risk |
| 🔄 Auto (default) | CLI-first, cloud fallback | Best of both worlds |

```bash
# Switch via CLI
huimei login --server prod   # Connect to production
# Or change in WebUI: Profile → Publish Settings
```

When using Local or Auto mode, the CLI background worker automatically:
- Connects to backend via WebSocket
- Receives publish tasks from WebUI
- Downloads media files from cloud storage
- Opens local browser with your cookies
- Executes the publish automation
- Reports results back to WebUI

No manual worker management needed — it starts on login and reconnects automatically.

## MCP Server Integration

[MCP (Model Context Protocol)](https://modelcontextprotocol.io/) allows AI agents to call external tools as if they were native functions. HuiMei ships a built-in MCP server so agents like Claude, Hermes, and GPT can manage your social media directly.

### Claude Code / Claude Desktop

Add to your MCP config (`~/.claude/claude_code_config.json` or Claude Desktop settings):

```json
{
  "mcpServers": {
    "huimei": {
      "command": "huimei-mcp-server",
      "args": []
    }
  }
}
```

### Hermes Agent

Add to your Hermes config:

```yaml
mcp_servers:
  huimei:
    command: huimei-mcp-server
```

### Available MCP Tools

| Tool               | Description                                      |
|--------------------|--------------------------------------------------|
| `huimei_login`     | Launch browser login flow for a platform         |
| `huimei_status`    | Check CLI status and backend connectivity        |
| `huimei_logout`    | Log out and clear local session                  |
| `huimei_platforms` | List all supported platforms and capabilities    |
| `huimei_accounts`  | List all linked social media accounts            |
| `huimei_publish`   | Create a publish task (video/image to platforms) |

## Architecture

```
┌─────────────────────────┐          ┌─────────────────────────┐
│     CLI  (Your Device)  │◀──WS──▶│   Java Backend (Cloud)  │
│                         │──HTTP──▶│                         │
│  ▸ Playwright browser   │          │  ▸ Account management   │
│  ▸ Encrypted cookies    │          │  ▸ Task scheduling      │
│  ▸ Residential IP       │          │  ▸ Execution routing    │
│  ▸ MCP Server           │          │  ▸ Settings sync        │
│  ▸ Background worker    │          │  ▸ Subscription billing │
└─────────────────────────┘          └─────────────────────────┘
        "The Arm"                          "The Brain"
```

> **CLI is the arm, Backend is the brain.** The CLI executes browser automation locally. All business logic, scheduling, and orchestration happen on the backend.

## Use Cases

**📹 Content Creators** — Write once, publish everywhere. Record a video, add your caption, and distribute to all 11 platforms with a single command.

**🤖 AI Agents** — Let Claude or GPT manage your social media via MCP. Your agent can check account status, schedule posts, and publish content autonomously.

**📊 Marketing Teams** — Automate matrix account publishing across dozens of accounts and platforms. Integrate into your existing CI/CD or content pipeline.

**🔄 Settings Sync** — Settings changed in WebUI instantly sync to CLI via WebSocket.

## Links

- **Homepage:** [huimei.smaroot.tech](https://huimei.smaroot.tech)
- **PyPI:** [pypi.org/project/huimei](https://pypi.org/project/huimei/)
- **Documentation:** [huimei.smaroot.tech/docs](https://huimei.smaroot.tech/docs)
- **Changelog:** [CHANGELOG.md](https://github.com/huimei-engine/huimei-cli/blob/main/CHANGELOG.md)

## License

MIT © 2026 Beijing HuiGen ZhiYan Technology Co., Ltd (北京慧根智研科技有限责任公司)
