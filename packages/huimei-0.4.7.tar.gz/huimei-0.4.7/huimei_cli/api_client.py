"""慧媒引擎 Backend API Client"""
import httpx


class ApiError(Exception):
    """API request error with status code and message."""
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class ApiClient:
    """Synchronous HTTP client for huimei-engine backend API."""

    def __init__(self, server_url: str, token: str | None = None, timeout: float = 30.0):
        self.base_url = server_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.base_url}{path}"
        try:
            resp = httpx.request(
                method, url,
                headers=self._headers(),
                timeout=self.timeout,
                **kwargs,
            )
        except httpx.HTTPError as e:
            raise ApiError(0, f"Request failed: {e}") from e

        if resp.status_code != 200:
            raise ApiError(resp.status_code, f"HTTP {resp.status_code}: {resp.text[:200]}")

        body = resp.json()
        code = body.get("code", -1)
        if code != 200:
            raise ApiError(code, body.get("message", "Unknown error"))
        return body.get("data")

    def _get(self, path: str, **params) -> dict:
        return self._request("GET", path, params=params or None)

    def _post(self, path: str, data: dict = None) -> dict:
        return self._request("POST", path, json=data)

    def _put(self, path: str, data: dict = None) -> dict:
        return self._request("PUT", path, json=data)

    # ── Auth ──────────────────────────────────────────────

    def login(self, username: str, password: str) -> dict:
        """Login and store JWT token. Returns user/token data."""
        result = self._post("/api/v1/auth/login", {
            "username": username,
            "password": password,
            "captchaToken": "dev-token-skip-captcha",
        })
        if result and "token" in result:
            self.token = result["token"]
        return result

    # ── Subscription ──────────────────────────────────────

    def get_subscription_info(self) -> dict:
        """Get current subscription/plan info."""
        return self._get("/api/v1/subscription/current")

    # ── Accounts & Platforms ──────────────────────────────

    def get_accounts(self) -> list:
        """List all bound social media accounts."""
        return self._get("/api/v1/accounts")

    def get_platforms(self) -> list:
        """List all supported platforms."""
        return self._get("/api/v1/platforms")

    def get_publish_params_config(self, platform_id: str) -> dict:
        """Get publish parameter config for a specific platform."""
        return self._get(f"/api/v1/platforms/{platform_id}/publish-params-config")

    # ── Platform Scripts ────────────────────────────────────

    def get_platform_script(self, platform_id: str, action: str) -> dict:
        """Fetch encrypted script for a platform action.

        GET /api/v1/scripts/platform/{platform_id}/{action}

        Returns:
            dict with keys: encryptedScript, encryptedBase, version, etc.
        """
        return self._get(f"/api/v1/scripts/platform/{platform_id}/{action}")

    # ── Publish Tasks ─────────────────────────────────────

    def create_task(self, task_data: dict) -> dict:
        """Create a new publish task."""
        return self._post("/api/v1/publish", task_data)

    def register_device(self, device_id: str, device_name: str, os_type: str) -> dict:
        """Register CLI device with backend."""
        return self._post("/api/v1/cli/device/register", {
            "device_id": device_id,
            "device_name": device_name,
            "os_type": os_type,
        })

    # ── Media Upload ───────────────────────────────────────

    # ── CLI Cookie Upload ────────────────────────────────────

    def upload_account_cookie(self, account_id: int, cookie_data: str,
                              account_name: str = None, account_avatar: str = None) -> dict:
        """Upload cookie for an existing account (PUT).

        Used after CLI local login to sync cookie back to backend.
        """
        body = {"cookie_data": cookie_data}
        if account_name:
            body["account_name"] = account_name
        if account_avatar:
            body["account_avatar"] = account_avatar
        return self._put(f"/api/v1/cli/accounts/{account_id}/cookie", body)

    def create_account_with_cookie(self, platform_id: str, account_name: str,
                                   cookie_data: str, account_id: str = None,
                                   account_avatar: str = None) -> dict:
        """Create or update account with cookie (POST).

        Used when CLI login creates a brand-new account not yet in backend.
        Backend will upsert by platform_id + account_id/account_name.
        """
        body = {
            "platform_id": platform_id,
            "account_name": account_name,
            "cookie_data": cookie_data,
        }
        if account_id:
            body["account_id"] = account_id
        if account_avatar:
            body["account_avatar"] = account_avatar
        return self._post("/api/v1/cli/accounts/cookie", body)

    # ── User Settings ────────────────────────────────────────

    def get_settings(self) -> dict:
        """Get current user settings (execution_mode, cli_upload_media, cli_online)."""
        return self._get("/api/v1/user/settings")

    def update_settings(self, settings: dict) -> dict:
        """Update user settings. Accepts partial updates.

        Supported keys: execution_mode (cloud/local/auto), cli_upload_media (bool).
        """
        return self._put("/api/v1/user/settings", settings)

    # ── Task Result (offline retry) ────────────────────────

    def report_task_result(self, task_uuid: str, result: dict) -> dict:
        """Report the result of a CLI-executed task."""
        return self._put(f"/api/v1/cli/tasks/{task_uuid}/report", result)

    # ── Media Upload ───────────────────────────────────────

    def upload_media(self, file_path: str) -> dict:
        """Upload a local file to the backend media service.

        Returns media file info including 'id' to use as mediaId.
        """
        import os
        url = f"{self.base_url}/api/v1/media/upload"
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f)}
            resp = httpx.post(url, headers=headers, files=files, timeout=120.0)
        if resp.status_code != 200:
            raise ApiError(resp.status_code, f"Upload failed: {resp.text[:200]}")
        body = resp.json()
        code = body.get("code", -1)
        if code != 200:
            raise ApiError(code, body.get("message", "Upload failed"))
        return body.get("data")
