"""慧媒引擎CLI客户端 - 主入口"""

import typer
from rich.console import Console

from huimei_cli import __version__
from huimei_cli.commands import account_cmd, publish_cmd, skill_cmd, config_cmd

console = Console()

app = typer.Typer(
    name="huimei",
    help="慧媒引擎CLI - AI驱动的自媒体矩阵管理平台\n\n官网: https://huimei.smaroot.tech\n文档: huimei about",
    no_args_is_help=True,
)

# ── Worker subcommand group ───────────────────────────────

worker_app = typer.Typer(help="后台Worker进程管理")


@worker_app.command("status")
def worker_status():
    """查看Worker进程状态"""
    from huimei_cli.engine.worker_process import is_worker_running, get_worker_pid, get_worker_uptime

    if is_worker_running():
        pid = get_worker_pid()
        uptime = get_worker_uptime()
        uptime_str = ""
        if uptime is not None:
            hours, remainder = divmod(int(uptime), 3600)
            minutes, seconds = divmod(remainder, 60)
            if hours > 0:
                uptime_str = f"{hours}h{minutes}m{seconds}s"
            elif minutes > 0:
                uptime_str = f"{minutes}m{seconds}s"
            else:
                uptime_str = f"{seconds}s"
        console.print(f"[green]● Worker运行中[/green]  PID={pid}  运行时间={uptime_str}")
    else:
        console.print("[red]● Worker未运行[/red]")
        console.print("[dim]运行 huimei worker start 手动启动[/dim]")


@worker_app.command("start")
def worker_start():
    """手动启动Worker进程"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.engine.worker_process import is_worker_running, start_worker

    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)

    if is_worker_running():
        console.print("[yellow]Worker已在运行中[/yellow]")
        return

    ok = start_worker()
    if ok:
        console.print("[green]✓[/green] Worker已启动")
    else:
        console.print("[red]✗[/red] Worker启动失败，查看日志: huimei worker logs")
        raise typer.Exit(1)


@worker_app.command("stop")
def worker_stop():
    """停止Worker进程"""
    from huimei_cli.engine.worker_process import is_worker_running, stop_worker

    if not is_worker_running():
        console.print("[dim]Worker未在运行[/dim]")
        return

    stop_worker()
    console.print("[green]✓[/green] Worker已停止")


@worker_app.command()
def restart():
    """重启Worker进程"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.engine.worker_process import is_worker_running, stop_worker, start_worker

    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)

    if is_worker_running():
        stop_worker()
        console.print("[dim]已停止旧进程[/dim]")

    ok = start_worker()
    if ok:
        console.print("[green]✓[/green] Worker已重启")
    else:
        console.print("[red]✗[/red] Worker启动失败")
        raise typer.Exit(1)


@worker_app.command()
def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="显示最后N行日志"),
):
    """查看Worker日志"""
    from huimei_cli.engine.worker_process import LOG_FILE

    if not LOG_FILE.exists():
        console.print("[dim]暂无日志[/dim]")
        return

    try:
        all_lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
        tail = all_lines[-lines:] if len(all_lines) > lines else all_lines
        for line in tail:
            console.print(line)
    except Exception as e:
        console.print(f"[red]读取日志失败: {e}[/red]")


app.add_typer(worker_app, name="worker", help="后台Worker进程管理", hidden=True)


# ── Global callback ───────────────────────────────────────


@app.callback()
def main_callback(ctx: typer.Context):
    """CLI 全局回调 — 自动启动后台 Worker 进程。"""
    # 不需要连接的命令跳过
    skip_cmds = {"login", "logout", "version", "about", "worker"}
    # ctx.invoked_subcommand 在 Typer 中可能是 None（顶级命令时）
    cmd = ctx.invoked_subcommand
    if cmd in skip_cmds:
        return

    from huimei_cli.engine.auto_connect import ensure_connected
    ensure_connected()

# Register sub-commands
app.add_typer(account_cmd.app, name="account", help="平台账号管理")
app.add_typer(publish_cmd.app, name="publish", help="内容发布")
app.add_typer(skill_cmd.app, name="skill", help="AI Agent skill管理")
app.add_typer(config_cmd.app, name="config", help="执行模式与配置管理")


# Top-level convenience commands
@app.command()
def login(
    password_mode: bool = typer.Option(
        False, "--password", "-p", help="使用用户名密码登录（非浏览器）"
    ),
    server: str = typer.Option(None, help="服务器地址"),
):
    """登录慧媒引擎账号"""
    from huimei_cli.auth import do_login, do_browser_login, get_current_user
    from huimei_cli.config import resolve_server_alias, resolve_frontend_alias

    resolved_server = resolve_server_alias(server) if server else None

    if password_mode:
        username = typer.prompt("用户名")
        password = typer.prompt("密码", hide_input=True)
        with console.status("正在登录..."):
            ok = do_login(username, password, resolved_server)
        if ok:
            user = get_current_user()
            name = user.get("username", username) if user else username
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
            # 登录成功后自动启动后台Worker
            from huimei_cli.engine.auto_connect import ensure_connected
            ensure_connected()
        else:
            console.print("[red]✗[/red] 登录失败")
            raise typer.Exit(1)
    else:
        from huimei_cli.config import get_server_url
        target = resolved_server or get_server_url()
        frontend_target = resolve_frontend_alias(server) if server else resolve_frontend_alias(None)
        console.print(f"[cyan]正在打开浏览器登录...[/cyan]")
        console.print(f"[dim]服务器: {target}[/dim]")
        if frontend_target != target:
            console.print(f"[dim]前端: {frontend_target}[/dim]")
        console.print("[dim]请在浏览器中完成登录，登录成功后将自动获取凭证[/dim]")
        ok = do_browser_login(resolved_server, frontend_url=frontend_target)
        if ok:
            user = get_current_user()
            name = user.get("username", "用户") if user else "用户"
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
            # 登录成功后自动启动后台Worker
            from huimei_cli.engine.auto_connect import ensure_connected
            ensure_connected()
        else:
            console.print("[red]✗[/red] 登录失败或超时")
            raise typer.Exit(1)


@app.command()
def status():
    """查看当前登录状态和订阅信息"""
    from huimei_cli.auth import is_logged_in, get_current_user
    from huimei_cli.config import get_config, get_server_url
    from huimei_cli.api_client import ApiClient
    from huimei_cli.engine.worker_process import is_worker_running, get_worker_pid
    from rich.table import Table

    if not is_logged_in():
        console.print("[yellow]未登录[/yellow]，请先运行 huimei login")
        raise typer.Exit(1)

    user = get_current_user()
    table = Table(title="账号状态")
    table.add_column("项目", style="cyan")
    table.add_column("值")
    table.add_row("用户名", user.get("username", "未知") if user else "未知")
    table.add_row("服务器", get_server_url())
    table.add_row("登录状态", "[green]已登录[/green]")

    # Worker status
    if is_worker_running():
        pid = get_worker_pid()
        table.add_row("Worker", f"[green]运行中[/green] (PID={pid})")
    else:
        table.add_row("Worker", "[red]未运行[/red]")

    try:
        cfg = get_config()
        client = ApiClient(get_server_url(), cfg.get("token"))
        sub = client.get_subscription_info()
        if sub:
            table.add_row("订阅类型", str(sub.get("plan", "免费版")))
            table.add_row("到期时间", str(sub.get("expire_time", "-")))
    except Exception:
        table.add_row("订阅信息", "[dim]获取失败[/dim]")

    console.print(table)


@app.command()
def logout():
    """退出登录"""
    from huimei_cli.auth import logout as do_logout
    from huimei_cli.engine.auto_connect import stop

    # 先停Worker再清token
    stop()
    do_logout()
    console.print("[green]✓[/green] 已退出登录")


@app.command()
def platforms():
    """列出支持的平台"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.config import get_config, get_server_url
    from huimei_cli.api_client import ApiClient, ApiError
    from rich.table import Table

    table = Table(title="支持的平台")
    table.add_column("平台ID", style="cyan")
    table.add_column("名称")
    table.add_column("视频", justify="center")
    table.add_column("图文", justify="center")

    # 优先从后端API获取
    if is_logged_in():
        try:
            cfg = get_config()
            client = ApiClient(get_server_url(), cfg.get("token"))
            plats = client.get_platforms()
            if plats:
                for p in plats:
                    table.add_row(
                        p.get("id", "?"),
                        p.get("name", "?"),
                        "✅" if p.get("supports_video") else "❌",
                        "✅" if p.get("supports_image") else "❌",
                    )
                console.print(table)
                return
        except Exception:
            console.print("[dim]后端查询失败，显示本地已知平台[/dim]")

    # 降级：本地registry（排除sample和_开头）
    console.print("[yellow]未登录[/yellow]，显示本地已知平台")
    import importlib, os
    registry_dir = os.path.join(
        os.path.dirname(__file__), "platforms", "registry"
    )
    if os.path.isdir(registry_dir):
        for f in sorted(os.listdir(registry_dir)):
            if f.endswith(".py") and not f.startswith("_") and f != "sample.py":
                pid = f[:-3]
                try:
                    mod = importlib.import_module(
                        f"huimei_cli.platforms.registry.{pid}"
                    )
                    cfg = getattr(mod, "PLATFORM_CONFIG", {})
                    table.add_row(
                        pid,
                        cfg.get("name", pid),
                        "✅" if cfg.get("support_video") else "❌",
                        "✅" if cfg.get("support_image") else "❌",
                    )
                except Exception:
                    table.add_row(pid, "加载失败", "?", "?")

    console.print(table)


@app.command()
def version():
    """显示版本信息"""
    console.print(f"慧媒引擎CLI v{__version__}")


@app.command()
def about():
    """打开慧媒引擎产品介绍页面"""
    import webbrowser
    url = "https://huimei.smaroot.tech/about"
    console.print(f"[cyan]正在打开产品介绍页面...[/cyan]")
    console.print(f"[dim]{url}[/dim]")
    webbrowser.open(url)


if __name__ == "__main__":
    app()
