"""Platform router — loads uploader adapters for local execution."""

import importlib
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def get_video_uploader(platform_id: str) -> Optional[object]:
    """Load the video uploader for a given platform.

    Looks up the platform's registry config, then imports
    the uploader class from huimei_cli.platforms.<uploader_dir>.

    Args:
        platform_id: e.g. 'xhs', 'douyin', 'weibo'

    Returns:
        Uploader instance, or None if not available
    """
    config = _get_platform_config(platform_id)
    if not config:
        return None

    class_name = config.get("video_uploader_class")
    uploader_dir = config.get("uploader_dir")
    if not class_name or not uploader_dir:
        logger.warning("Missing video uploader config for: %s", platform_id)
        return None

    return _load_class(platform_id, uploader_dir, "video_uploader", class_name)


def get_image_uploader(platform_id: str) -> Optional[object]:
    """Load the image uploader for a given platform."""
    config = _get_platform_config(platform_id)
    if not config:
        return None

    class_name = config.get("image_uploader_class")
    uploader_dir = config.get("uploader_dir")
    if not class_name or not uploader_dir:
        logger.warning("Missing image uploader config for: %s", platform_id)
        return None

    return _load_class(platform_id, uploader_dir, "image_uploader", class_name)


def get_login_orchestrator(platform_id: str) -> Optional[object]:
    """Load the login orchestrator for a given platform."""
    config = _get_platform_config(platform_id)
    if not config:
        return None

    class_name = config.get("login_orchestrator_class")
    uploader_dir = config.get("uploader_dir")
    if not class_name or not uploader_dir:
        logger.warning("Missing login orchestrator config for: %s", platform_id)
        return None

    return _load_class(platform_id, uploader_dir, "login_orchestrator", class_name)


def get_supported_platforms() -> list[str]:
    """Return list of platform IDs that have local uploader implementations."""
    import pkgutil
    platforms = []
    try:
        pkg = importlib.import_module("huimei_cli.platforms.registry")
        for importer, modname, ispkg in pkgutil.iter_modules(pkg.__path__):
            if modname.startswith("_"):
                continue
            try:
                mod = importlib.import_module(f"huimei_cli.platforms.registry.{modname}")
                config = getattr(mod, "PLATFORM_CONFIG", {})
                uploader_dir = config.get("uploader_dir", "")
                # Only include platforms that have a local uploader package
                try:
                    importlib.import_module(f"huimei_cli.platforms.{uploader_dir}")
                    platforms.append(modname)
                except ImportError:
                    pass
            except ImportError:
                pass
    except Exception:
        pass
    return platforms


def _get_platform_config(platform_id: str) -> Optional[dict]:
    """Load PLATFORM_CONFIG from registry."""
    try:
        registry = importlib.import_module(
            f"huimei_cli.platforms.registry.{platform_id}"
        )
        return getattr(registry, "PLATFORM_CONFIG", None)
    except ImportError:
        logger.warning("No registry config for platform: %s", platform_id)
        return None


def _load_class(platform_id: str, uploader_dir: str,
                module_name: str, class_name: str) -> Optional[object]:
    """Import and instantiate an uploader/orchestrator class."""
    try:
        module = importlib.import_module(
            f"huimei_cli.platforms.{uploader_dir}.{module_name}"
        )
        cls = getattr(module, class_name)
        return cls()
    except (ImportError, AttributeError) as e:
        logger.warning("Cannot load %s for %s: %s", class_name, platform_id, e)
        return None
