"""后台自动连接 — CLI 执行命令时自动启动后台 Worker 进程。

替代旧的 daemon 线程方案，改为独立的后台进程。
Worker 进程不随 CLI 命令退出而结束。
"""

import logging

logger = logging.getLogger(__name__)


def ensure_connected():
    """如果已登录且 Worker 进程未运行，启动它。

    幂等：已在运行则直接返回。
    """
    from huimei_cli.engine.worker_process import is_worker_running, start_worker
    from huimei_cli.auth import is_logged_in

    if is_worker_running():
        return

    if not is_logged_in():
        return

    logger.debug("Starting background worker process")
    start_worker()


def stop():
    """停止后台 Worker 进程。"""
    from huimei_cli.engine.worker_process import stop_worker

    stop_worker()
