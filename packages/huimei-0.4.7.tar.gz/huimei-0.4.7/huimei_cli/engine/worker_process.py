"""Worker后台常驻进程管理 — 通过subprocess启动独立进程运行WebSocket Worker。

进程独立于CLI命令生命周期，PID记录在 ~/.huimei/worker.pid，
日志输出到 ~/.huimei/worker.log。
"""

import asyncio
import logging
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from huimei_cli.config import CONFIG_DIR

logger = logging.getLogger(__name__)

PID_FILE = CONFIG_DIR / "worker.pid"
LOG_FILE = CONFIG_DIR / "worker.log"


# ── Public API ────────────────────────────────────────────


def start_worker() -> bool:
    """启动后台Worker进程。

    Returns:
        True if started successfully, False otherwise.
    """
    if is_worker_running():
        logger.debug("Worker already running")
        return True

    # Ensure config dir exists
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Clean stale PID file
    if PID_FILE.exists():
        PID_FILE.unlink(missing_ok=True)

    try:
        log_file = open(LOG_FILE, "a", encoding="utf-8")
        proc = subprocess.Popen(
            [sys.executable, "-m", "huimei_cli.engine.worker_process"],
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,  # detach from parent terminal
        )
        log_file.close()  # Parent closes fd; child inherited its own copy
        # Write PID file
        PID_FILE.write_text(str(proc.pid), encoding="utf-8")
        logger.debug("Worker process started, pid=%d", proc.pid)
        return True

    except Exception as e:
        logger.warning("Failed to start worker process: %s", e)
        return False


def stop_worker() -> bool:
    """停止后台Worker进程。

    Returns:
        True if stopped (or was already stopped), False on error.
    """
    pid = _read_pid()
    if pid is None:
        return True  # not running

    try:
        os.kill(pid, signal.SIGTERM)
        # Give it a moment to shut down
        for _ in range(10):
            time.sleep(0.2)
            try:
                os.kill(pid, 0)
            except OSError:
                break  # process exited
        logger.debug("Worker process stopped, pid=%d", pid)
    except OSError:
        # Already dead
        pass

    # Clean PID file
    PID_FILE.unlink(missing_ok=True)
    return True


def is_worker_running() -> bool:
    """检查Worker进程是否存活。"""
    pid = _read_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, 0)  # signal 0 = existence check
        return True
    except OSError:
        # Process dead, clean stale PID file
        PID_FILE.unlink(missing_ok=True)
        return False


def get_worker_pid() -> Optional[int]:
    """返回Worker进程PID（仅在进程存活时）。"""
    if is_worker_running():
        return _read_pid()
    return None


def get_worker_uptime() -> Optional[float]:
    """返回Worker进程运行时长（秒），进程不存在返回None。"""
    if not PID_FILE.exists():
        return None
    pid = _read_pid()
    if pid is None:
        return None
    try:
        os.kill(pid, 0)
        # Use PID file mtime as start time proxy
        start_time = PID_FILE.stat().st_mtime
        return time.time() - start_time
    except OSError:
        return None


# ── Internal helpers ──────────────────────────────────────


def _read_pid() -> Optional[int]:
    """从PID文件读取进程ID。"""
    if not PID_FILE.exists():
        return None
    try:
        text = PID_FILE.read_text(encoding="utf-8").strip()
        return int(text)
    except (ValueError, OSError):
        return None


# ── Worker main (subprocess entry point) ──────────────────


def worker_main():
    """后台Worker进程的实际入口 — 运行WebSocket连接循环。"""
    from huimei_cli.auth import is_logged_in
    from huimei_cli.config import get_config, get_server_url
    from huimei_cli.engine.ws_worker import CliWorker

    # Configure logging for the background process
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    log = logging.getLogger("huimei_cli.worker_process")

    if not is_logged_in():
        log.error("Not logged in, worker exiting")
        return

    cfg = get_config()
    token = cfg.get("token")
    if not token:
        log.error("No token found, worker exiting")
        return

    server_url = get_server_url()
    log.info("Worker starting — server=%s pid=%d", server_url, os.getpid())

    worker = CliWorker(server_url, token)

    # Handle SIGTERM for graceful shutdown
    def _handle_sigterm(signum, frame):
        log.info("Received SIGTERM, shutting down...")
        worker._running = False

    signal.signal(signal.SIGTERM, _handle_sigterm)

    try:
        asyncio.run(worker.run())
    except KeyboardInterrupt:
        worker.stop()
    finally:
        log.info("Worker process exiting")
        # Clean up PID file on normal exit
        PID_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    worker_main()
