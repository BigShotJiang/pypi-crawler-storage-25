"""CLI Session adapter — drop-in replacement for cloud Session."""

import asyncio
import logging
import queue
import time
from enum import Enum
from typing import Any, Dict, Optional
from uuid import uuid4

from huimei_cli.engine.output import TerminalOutput

logger = logging.getLogger(__name__)


class SessionType(Enum):
    LOGIN = "login"
    PUBLISH = "publish"
    UNKNOWN = "unknown"

class SessionStatus(Enum):
    CREATED = "created"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"

class BrowserType(Enum):
    PLAYWRIGHT = "playwright"
    DRISSIONPAGE = "drissionpage"
    AUTO = "auto"


class MockRequest:
    """Minimal stand-in for flask.Request."""
    def __init__(self):
        self.headers = {"User-Agent": "huimei-cli"}
        self.remote_addr = "127.0.0.1"


_MSG_MAP = {
    "progress": "progress", "info": "info", "success": "success",
    "error": "error", "warning": "warning", "complete": "complete",
}

# Only these info messages are shown to the user; others are suppressed to debug
_IMPORTANT_PATTERNS = [
    "请扫描", "扫描二维码", "登录成功", "登录失败",
    "请在浏览器", "请使用", "验证码",
    "账号已添加", "账号信息已更新",
    "上传完成", "发布成功", "发布失败",
]


class CliSession:
    """CLI-local session with the same attribute surface as cloud Session."""

    def __init__(self, platform_id: str,
                 session_type: SessionType = SessionType.PUBLISH,
                 browser_type: BrowserType = BrowserType.AUTO):
        self.session_id = str(uuid4())
        self.platform_id = platform_id
        self.session_type = session_type
        self.browser_type = browser_type
        self.status = SessionStatus.CREATED
        self.created_at = time.time()
        self.request = MockRequest()
        self.context = {
            "platform_id": platform_id,
            "user_agent": self.request.headers.get("User-Agent", ""),
            "client_ip": self.request.remote_addr,
        }
        # Browser resources (populated later)
        self.playwright_browser = self.playwright_page = self.playwright_context = None
        self.drissionpage_browser = self.drissionpage_tab = None
        self.browser = self.page = self.context_obj = None
        # Queues (interface compat)
        self.message_queue = queue.Queue()
        self.signal_queue = queue.Queue()
        self.input_queue = queue.Queue(maxsize=100)
        self._output = TerminalOutput()

    # Sanitize engine script output — replace sensitive keywords
    _SANITIZE_MAP = {
        'Cookie': '登录信息',
        'cookie': '登录信息',
        'COOKIE': '登录信息',
        'cookie_data': '账号数据',
        'storage_state': '会话数据',
        '加密': '处理',
        '解密': '处理',
        '脚本': '任务',
        'AES': '',
        'base64': '',
    }

    def send_message(self, message_type: str, data: Dict[str, Any]):
        """Route cloud-style SSE message to terminal output."""
        # Intercept QR code step — render in terminal for headless mode
        if message_type == "step" and isinstance(data, dict):
            if data.get("step_type") == "qr_code":
                self._render_qr_step(data)
                return

        text = data.get("message") or data.get("msg") or str(data)
        # Sanitize sensitive terms from engine scripts
        for old, new in self._SANITIZE_MAP.items():
            text = text.replace(old, new)

        # Filter info messages: only show important ones, suppress noise
        if message_type == "info":
            if not any(p in text for p in _IMPORTANT_PATTERNS):
                logger.debug("script: %s", text)
                return

        method = getattr(self._output, _MSG_MAP.get(message_type, "info"))
        if message_type == "progress":
            method(text, data.get("percent"))
        elif message_type == "complete":
            method(data)
        else:
            method(text)

    def wait_for_input(self, timeout: float = 30.0) -> Optional[Dict]:
        """Synchronous terminal prompt (replaces queue-based wait)."""
        try:
            return {"type": "input", "data": input("  ⌨  Input required> ")}
        except (EOFError, KeyboardInterrupt):
            return None

    async def wait_for_input_async(self, timeout: float = 30.0) -> Optional[Dict]:
        """Async wrapper — runs blocking prompt in a thread."""
        return await asyncio.to_thread(self.wait_for_input, timeout)

    async def wait_for_signal_async(self, timeout: float = 0.01) -> Optional[Dict]:
        """Check signal queue without blocking (e.g. cancel signal)."""
        try:
            return self.signal_queue.get_nowait()
        except queue.Empty:
            return None

    def _render_qr_step(self, data: Dict[str, Any]):
        """Render QR code in terminal using half-block characters."""
        title = data.get("title", "请扫描二维码")
        desc = data.get("description", "")
        ui = data.get("ui_config", {})
        qr_src = ui.get("qr_image", "")
        instructions = ui.get("instructions", [])

        self._output.info(title)
        if desc:
            self._output.info(desc)

        if not qr_src:
            self._output.warning("未获取到二维码图片")
            return

        try:
            img_bytes = self._fetch_image_bytes(qr_src)
            if img_bytes:
                self._print_qr_ascii(img_bytes)
            else:
                self._output.warning("请在浏览器中扫描二维码")
        except Exception as e:
            import logging
            logging.getLogger(__name__).debug("QR render failed: %s", e)
            self._output.warning("请在浏览器中扫描二维码")

        for inst in instructions:
            self._output.info(inst)

    @staticmethod
    def _fetch_image_bytes(src: str) -> Optional[bytes]:
        """Get image bytes from base64 data URI or HTTP URL."""
        import base64
        if src.startswith("data:image/"):
            # data:image/png;base64,xxxxx
            parts = src.split(",", 1)
            if len(parts) == 2:
                return base64.b64decode(parts[1])
            return None
        if src.startswith("http"):
            import urllib.request
            try:
                with urllib.request.urlopen(src, timeout=10) as resp:
                    return resp.read()
            except Exception:
                return None
        return None

    def _print_qr_ascii(self, img_bytes: bytes):
        """Render QR code image as ASCII in terminal using half-block chars."""
        try:
            from PIL import Image
            import io

            img = Image.open(io.BytesIO(img_bytes)).convert("L")
            # Resize to fit terminal (QR codes are typically small)
            w = min(img.width, 60)
            ratio = w / img.width
            h = int(img.height * ratio)
            # Make height even for half-block rendering
            h = h if h % 2 == 0 else h + 1
            img = img.resize((w, h), Image.NEAREST)

            # Threshold: < 128 = black (QR), >= 128 = white (background)
            pixels = list(img.getdata())
            lines = [pixels[i * w:(i + 1) * w] for i in range(h)]

            console = self._output.console
            console.print()
            # Use half-block characters: top row + bottom row → one line
            # ▀ = top half, ▄ = bottom half, █ = both, ' ' = neither
            for row in range(0, h, 2):
                top = lines[row]
                bot = lines[row + 1] if row + 1 < h else [255] * w
                line = ""
                for x in range(w):
                    t_black = top[x] < 128
                    b_black = bot[x] < 128
                    if t_black and b_black:
                        line += "█"
                    elif t_black:
                        line += "▀"
                    elif b_black:
                        line += "▄"
                    else:
                        line += " "
                console.print(f"  {line}")
            console.print()
        except ImportError:
            self._output.warning("请在浏览器中扫描二维码 (安装 Pillow 可在终端显示)")

    async def cleanup(self):
        """Release browser resources (mirrors cloud Session.cleanup)."""
        # Close BrowserManager if set by base.py
        mgr = getattr(self, '_browser_manager', None)
        if mgr:
            try:
                await mgr.close()
            except Exception:
                pass
            self._browser_manager = None
        for attr in ("playwright_page", "playwright_context", "playwright_browser"):
            obj = getattr(self, attr, None)
            if obj:
                try:
                    await asyncio.wait_for(obj.close(), timeout=5.0)
                except Exception:
                    pass
                setattr(self, attr, None)
        self.browser = self.page = self.context_obj = None
        if self.status in (SessionStatus.RUNNING, SessionStatus.CREATED):
            self.status = SessionStatus.CANCELLED

    async def close(self):
        """Alias for cleanup."""
        await self.cleanup()
