"""WebSocket Worker — CLI作为本地Worker连接到后端接受任务调度。"""

import asyncio
import json
import logging
import signal
from typing import Optional

from huimei_cli.engine.pending_results import (
    save_pending_result, remove_pending_result, get_pending_results,
)

logger = logging.getLogger(__name__)


class CliWorker:
    """WebSocket Worker that connects to backend and executes dispatched tasks."""

    def __init__(self, server_url: str, token: str):
        # Convert http(s) to ws(s)
        ws_url = server_url.replace("https://", "wss://").replace("http://", "ws://")
        self.ws_url = f"{ws_url}/ws/cli?token={token}"
        self.token = token
        self._running = False
        self._kicked = False
        self._ws = None

    async def run(self):
        """Main loop: connect, register, receive and execute tasks."""
        import ssl
        import websockets

        self._running = True
        retry_delay = 1

        while self._running:
            try:
                logger.info("Connecting to %s", self.ws_url.split("?")[0])

                # Only use SSL context for wss:// connections
                connect_kwargs = {}
                if self.ws_url.startswith("wss://"):
                    ssl_ctx = ssl.create_default_context()
                    ssl_ctx.check_hostname = False
                    ssl_ctx.verify_mode = ssl.CERT_NONE
                    connect_kwargs["ssl"] = ssl_ctx

                async with websockets.connect(self.ws_url, **connect_kwargs) as ws:
                    self._ws = ws
                    retry_delay = 1  # Reset on successful connect
                    logger.info("Connected to backend WebSocket")

                    # Register as worker
                    await ws.send(json.dumps({
                        "type": "register",
                        "data": {
                            "device_id": self._get_device_id(),
                            "os": self._get_os_info(),
                            "version": self._get_cli_version(),
                        }
                    }))

                    # Request latest settings from server
                    await ws.send(json.dumps({"type": "settings.request"}))

                    # Flush pending results from previous disconnects
                    await self._flush_pending_results(ws)

                    # Start heartbeat task
                    heartbeat_task = asyncio.create_task(self._heartbeat(ws))

                    try:
                        async for message in ws:
                            await self._handle_message(ws, message)
                    finally:
                        heartbeat_task.cancel()

            except Exception as e:
                if not self._running:
                    break
                if self._kicked:
                    logger.info("Kicked by server, not retrying")
                    break
                logger.warning("WebSocket disconnected: %s. Retry in %ds", e, retry_delay)
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 30)

        logger.info("Worker stopped")

    async def _heartbeat(self, ws):
        """Send periodic heartbeat."""
        while True:
            await asyncio.sleep(30)
            try:
                await ws.send(json.dumps({"type": "heartbeat"}))
            except Exception:
                break

    async def _handle_message(self, ws, raw):
        """Handle incoming message from backend."""
        try:
            msg = json.loads(raw)
            msg_type = msg.get("type")

            if msg_type == "task.execute":
                task_data = msg.get("data", {})
                logger.info("Received task: %s", task_data.get("task_uuid", "unknown"))
                result = await self._execute_task(task_data)

                # Save to pending store first (crash-safe)
                task_uuid = result.get("task_uuid", "")
                if task_uuid:
                    save_pending_result(task_uuid, result)

                # Send via WebSocket
                try:
                    await ws.send(json.dumps({
                        "type": "task.result",
                        "data": result
                    }))
                    # Delivery succeeded, remove from pending
                    if task_uuid:
                        remove_pending_result(task_uuid)
                except Exception as e:
                    logger.warning("Failed to send result via WS, saved to pending: %s", e)

            elif msg_type == "task.cancel":
                task_uuid = msg.get("data", {}).get("task_uuid")
                logger.info("Cancel request for: %s", task_uuid)
                # TODO: implement task cancellation

            elif msg_type == "kicked":
                logger.warning("Kicked by server: %s", msg.get("message", ""))
                self._kicked = True
                self._running = False  # Stop reconnect loop
                # Explicitly close WebSocket to break out of async for loop
                try:
                    await ws.close()
                except Exception:
                    pass

            elif msg_type == "settings.sync":
                settings_data = msg.get("data", {})
                self._sync_settings(settings_data)

            elif msg_type == "pong":
                pass  # heartbeat response

            else:
                logger.debug("Unknown message type: %s", msg_type)

        except json.JSONDecodeError:
            logger.warning("Invalid JSON message")

    async def _execute_task(self, task_data: dict) -> dict:
        """Execute a publish task locally using memory executor."""
        from huimei_cli.engine.script_loader import ScriptLoader
        from huimei_cli.engine.memory_executor import MemoryExecutor
        from huimei_cli.engine.session import CliSession, SessionType

        platform_id = task_data.get("platform_id", "")
        task_uuid = task_data.get("task_uuid", "")
        action = task_data.get("action", "publish_video")
        temp_files = []  # track downloaded files for cleanup

        try:
            # Load script
            loader = ScriptLoader()
            script_data = loader.get_script(platform_id, action)

            # Memory load uploader
            executor = MemoryExecutor()
            uploader = executor.load_uploader(
                script_data["script"], script_data["base_script"], action,
                encrypted_cli_script=script_data.get("cli_script"),
                encrypted_cli_base=script_data.get("cli_base_script"))

            # Download remote files to local temp dir
            publish_data = task_data.get("publish_data", {})
            file_list = publish_data.get("file_list", [])
            logger.info("TASK_DATA_KEYS: %s", list(task_data.keys()))
            logger.info("PUBLISH_DATA_KEYS: %s, file_list=%s", list(publish_data.keys()) if publish_data else "EMPTY", file_list)
            if file_list:
                local_paths = await self._download_files(file_list, task_uuid)
                temp_files = local_paths
                publish_data["file_list"] = local_paths
                logger.info("Downloaded %d files for task %s", len(local_paths), task_uuid)

            # Build session
            session = CliSession(platform_id=platform_id, session_type=SessionType.PUBLISH)
            session.context["cookie_data"] = task_data.get("cookie_data", {})
            session.context["headless"] = task_data.get("headless", True)
            session.context["publish_data"] = publish_data

            # Execute
            result = await uploader.execute_publish(session)
            await session.cleanup()

            return {
                "task_uuid": task_uuid,
                "status": "success" if result.get("success") else "failed",
                "message": result.get("message", ""),
                "data": result.get("data", {})
            }

        except Exception as e:
            logger.error("Task execution failed: %s", e)
            return {
                "task_uuid": task_uuid,
                "status": "failed",
                "message": str(e),
                "data": {}
            }
        finally:
            # Cleanup temp files
            for f in temp_files:
                try:
                    import os
                    if os.path.exists(f):
                        os.remove(f)
                except Exception:
                    pass

    async def _flush_pending_results(self, ws):
        """Send any pending results from previous sessions after reconnect."""
        pending = get_pending_results()
        if not pending:
            return

        logger.info("Flushing %d pending results after reconnect", len(pending))
        for result in pending:
            task_uuid = result.get("task_uuid", "")
            if not task_uuid:
                continue
            # Remove internal metadata
            result.pop("_file_path", None)
            try:
                await ws.send(json.dumps({
                    "type": "task.result",
                    "data": result
                }))
                remove_pending_result(task_uuid)
                logger.info("Flushed pending result: %s", task_uuid)
            except Exception as e:
                logger.warning("Failed to flush pending result %s: %s", task_uuid, e)
                break  # Connection probably broken, stop flushing

    def stop(self):
        self._running = False

    async def _download_files(self, url_list: list, task_uuid: str) -> list:
        """Download remote files (OSS URLs) to local temp directory.

        Returns list of local file paths.
        """
        import tempfile
        import httpx
        import os
        from urllib.parse import urlparse

        temp_dir = os.path.join(tempfile.gettempdir(), f"huimei_{task_uuid[:8]}")
        os.makedirs(temp_dir, exist_ok=True)
        local_paths = []

        async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
            for i, url in enumerate(url_list):
                try:
                    # Extract filename from URL
                    parsed = urlparse(url)
                    filename = os.path.basename(parsed.path) or f"file_{i}"
                    local_path = os.path.join(temp_dir, filename)

                    resp = await client.get(url)
                    resp.raise_for_status()
                    with open(local_path, "wb") as f:
                        f.write(resp.content)

                    local_paths.append(local_path)
                    logger.info("Downloaded file %d: %s (%d bytes)", i + 1, filename, len(resp.content))
                except Exception as e:
                    logger.error("Failed to download file %d from %s: %s", i + 1, url[:80], e)

        return local_paths

    def _sync_settings(self, settings_data: dict):
        """Sync settings from server to local config."""
        from huimei_cli.config import get_config, save_config

        execution_mode = settings_data.get("execution_mode")
        if execution_mode and execution_mode in ("cloud", "local", "auto"):
            config = get_config()
            if "execution" not in config:
                config["execution"] = {}
            old_mode = config["execution"].get("mode")
            config["execution"]["mode"] = execution_mode
            save_config(config)
            logger.info("Settings synced from server: execution_mode %s → %s", old_mode, execution_mode)

        cli_upload = settings_data.get("cli_upload_media")
        if cli_upload is not None:
            config = get_config()
            if "execution" not in config:
                config["execution"] = {}
            old_val = config["execution"].get("upload_media")
            config["execution"]["upload_media"] = bool(cli_upload)
            save_config(config)
            logger.info("Settings synced: cli_upload_media %s -> %s", old_val, cli_upload)

    @staticmethod
    def _get_device_id():
        from huimei_cli.config import get_device_id
        return get_device_id()

    @staticmethod
    def _get_os_info():
        import platform
        return f"{platform.system()} {platform.release()}"

    @staticmethod
    def _get_cli_version():
        from huimei_cli import __version__
        return __version__
