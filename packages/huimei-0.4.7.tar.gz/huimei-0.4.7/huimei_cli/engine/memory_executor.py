"""Memory-only script executor — decrypt, compile, exec, wipe.

Platform scripts never touch disk as .py files.
Decrypted source lives in memory only during execution.
"""

import gc
import types
import logging
from typing import Optional, Any

from huimei_cli.engine.crypto import decrypt_script, secure_wipe
from huimei_cli.engine.browser import BrowserManager

logger = logging.getLogger(__name__)


class MemoryExecutor:
    """Load and execute encrypted platform scripts in memory."""

    def __init__(self, encryption_key: str = None):
        self._key = encryption_key  # None = use default from crypto.py

    def load_uploader(self, encrypted_script: str, encrypted_base: str,
                       action: str, encrypted_cli_script: str = None,
                       encrypted_cli_base: str = None) -> Any:
        """Decrypt and load uploader class from encrypted scripts.
        
        Args:
            encrypted_script: Base64 AES encrypted uploader source (原始版本)
            encrypted_base: Base64 AES encrypted base.py source (原始版本)
            action: 'publish_video', 'publish_image', or 'login'
            encrypted_cli_script: Base64 AES encrypted CLI预处理版本 (优先使用)
            encrypted_cli_base: Base64 AES encrypted CLI预处理base (优先使用)
        
        Returns:
            Instantiated uploader/orchestrator object
        """
        base_source = None
        script_source = None
        use_cli_preprocessed = False
        
        try:
            kwargs = {"key": self._key} if self._key else {}
            
            # 优先使用引擎预处理的CLI版本（已移除引擎内部import）
            if encrypted_cli_base and encrypted_cli_script:
                base_source = decrypt_script(encrypted_cli_base, **kwargs)
                script_source = decrypt_script(encrypted_cli_script, **kwargs)
                use_cli_preprocessed = True
                logger.debug("Using pre-processed CLI scripts (%d + %d bytes)",
                           len(base_source), len(script_source))
            else:
                # Fallback: 使用原始脚本 + 本地import拦截
                base_source = decrypt_script(encrypted_base, **kwargs)
                script_source = decrypt_script(encrypted_script, **kwargs)
                logger.debug("Using raw scripts with local import stripping")

            # 3. Build base module in memory
            base_module = self._exec_module("_cli_base", base_source,
                                           skip_import_rewrite=use_cli_preprocessed)

            # 4. Register base module in sys.modules so 'from _cli_base import ...' works
            import sys
            sys.modules["_cli_base"] = base_module

            # 5. Build uploader module with base injected
            uploader_module = self._exec_module(
                "_cli_uploader", script_source,
                extra_globals={"_cli_base": base_module},
                skip_import_rewrite=use_cli_preprocessed
            )

            # 6. Find the uploader class
            class_name = self._find_class(uploader_module, action)
            if not class_name:
                raise RuntimeError(f"No uploader class found for action: {action}")

            cls = getattr(uploader_module, class_name)
            instance = cls()
            logger.info("Loaded uploader: %s", class_name)
            return instance

        finally:
            # 7. Secure wipe decrypted source
            if base_source:
                secure_wipe(base_source)
            if script_source:
                secure_wipe(script_source)
            # Clean up sys.modules
            import sys
            sys.modules.pop("_cli_base", None)
            gc.collect()

    def _exec_module(self, name: str, source: bytes, 
                      extra_globals: dict = None,
                      skip_import_rewrite: bool = False) -> types.ModuleType:
        """Compile and exec source into a new module object."""
        source_str = source.decode("utf-8")
        
        # 如果不是预处理版本，执行本地import拦截(fallback兼容旧引擎)
        if not skip_import_rewrite:
            # Rewrite imports: the engine scripts use 'from platforms.base import ...'
            source_str = source_str.replace(
                "from platforms.base import", "from _cli_base import"
            )
            source_str = source_str.replace(
                "from core.session_manager import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from sls_integration.client import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from core.browser_creator import BrowserCreator",
                "# cli-stripped: BrowserCreator"
            )
            # Engine utils modules — redirect to CLI stubs
            source_str = source_str.replace(
                "from utils.notification import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from utils.platform_optimizer import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from utils.file_downloader import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from utils.environment_info import", "# cli-stripped: "
            )
            source_str = source_str.replace(
                "from utils import", "# cli-stripped: "
            )
            # Some scripts import via platforms package re-export
            source_str = source_str.replace(
                "from platforms import PlatformOptimizer", "# cli-stripped: PlatformOptimizer"
            )
            source_str = source_str.replace(
                "from platforms import NotificationManager", "# cli-stripped: NotificationManager"
            )
        
        code = compile(source_str, f"<memory:{name}>", "exec")
        
        module = types.ModuleType(name)
        module.__file__ = f"<memory:{name}>"
        
        # Inject dependencies
        exec_globals = module.__dict__
        if extra_globals:
            exec_globals.update(extra_globals)
        
        # Provide a no-op log_to_sls for scripts that import it
        exec_globals.setdefault('log_to_sls', lambda *a, **kw: None)
        
        # Inject CLI session types to replace engine's core.session_manager imports
        from huimei_cli.engine.session import CliSession, SessionType, SessionStatus, BrowserType
        exec_globals.setdefault('Session', CliSession)
        exec_globals.setdefault('SessionType', SessionType)
        exec_globals.setdefault('SessionStatus', SessionStatus)
        exec_globals.setdefault('BrowserType', BrowserType)
        
        # Inject BrowserCreator replacement that uses CLI's BrowserManager
        exec_globals.setdefault('BrowserCreator', _CliBrowserCreator)
        
        # Inject engine utils stubs
        exec_globals.setdefault('NotificationManager', _CliNotificationManager)
        exec_globals.setdefault('PlatformOptimizer', _CliPlatformOptimizer)
        
        exec(code, exec_globals)
        return module

    def _find_class(self, module: types.ModuleType, action: str) -> Optional[str]:
        """Find the uploader/orchestrator class name based on action."""
        action_suffix_map = {
            "publish_video": "VideoUploader",
            "publish_image": "ImageUploader",
            "login": "LoginOrchestrator",
        }
        suffix = action_suffix_map.get(action)
        if not suffix:
            return None
        
        for name in dir(module):
            if name.endswith(suffix) and not name.startswith("Base"):
                return name
        return None

    def create_browser_and_session(self, platform_id, cookie_data, headless=True):
        """Helper: prepare browser+session for uploader execution.
        
        Returns (session, browser_manager) tuple.
        Caller must cleanup after use.
        """
        from huimei_cli.engine.session import CliSession, SessionType
        
        session = CliSession(platform_id=platform_id, session_type=SessionType.PUBLISH)
        session.context['cookie_data'] = cookie_data
        session.context['headless'] = headless
        return session


class _CliBrowserCreator:
    """Drop-in replacement for engine's BrowserCreator.
    
    The engine's base.py calls BrowserCreator.create_browser_session(session)
    inside BasePublishUploader/BaseLoginOrchestrator. This class provides 
    the same interface using CLI's BrowserManager.
    """

    @staticmethod
    def _build_browser_options(platform_id=None, platform_config=None, headless=True):
        """Build browser launch options (compatible with engine's BrowserCreator).
        
        Returns a dict of options that can be modified by platform scripts.
        CLI uses Playwright directly so most options are applied via BrowserManager.
        """
        options = {
            'headless': headless,
            'args': [
                '--disable-blink-features=AutomationControlled',
                '--no-first-run',
                '--no-default-browser-check',
            ]
        }
        return options

    @staticmethod
    async def create_browser_session(session):
        from huimei_cli.engine.browser import BrowserManager

        if session.page:
            return {'browser': session.playwright_browser, 'page': session.page}

        headless = session.context.get('headless', True)
        mgr = BrowserManager(headless=headless)
        await mgr.start()

        cookie_data = session.context.get('cookie_data')
        storage_state = None
        cookies = None
        if isinstance(cookie_data, dict):
            if 'cookies' in cookie_data and 'origins' in cookie_data:
                storage_state = cookie_data
            elif 'cookies' in cookie_data:
                cookies = cookie_data['cookies']
        elif isinstance(cookie_data, list):
            cookies = cookie_data

        ctx = await mgr.new_context(cookies=cookies, storage_state=storage_state)
        page = await ctx.new_page()

        session.playwright_browser = mgr._browser
        session.playwright_context = ctx
        session.playwright_page = page
        session.browser = mgr._browser
        session.page = page
        session.context_obj = ctx
        session._browser_manager = mgr

        session.send_message('info', {'message': '浏览器已就绪'})
        return {'browser': mgr._browser, 'page': page, 'context': ctx}


class _CliNotificationManager:
    """No-op stub for engine's utils.notification.NotificationManager.
    
    In CLI mode, notifications (企业微信 etc.) are irrelevant.
    All methods are static no-ops that just log.
    """

    @staticmethod
    def notify_captcha_required(session_id, platform, message, context=None):
        logger.debug("NotificationManager.notify_captcha_required: %s %s", platform, message)

    @staticmethod
    def notify_publish_error(session_id, platform, error, context=None):
        logger.debug("NotificationManager.notify_publish_error: %s %s", platform, error)

    @staticmethod
    def notify_login_error(session_id, platform, error, context=None):
        logger.debug("NotificationManager.notify_login_error: %s %s", platform, error)

    @staticmethod
    def notify_publish_success(session_id, platform, post_id=None, context=None):
        logger.debug("NotificationManager.notify_publish_success: %s", platform)


class _CliPlatformOptimizer:
    """CLI-compatible stub for engine's utils.platform_optimizer.PlatformOptimizer.
    
    Provides the same async interface. The actual typing/delay/upload-wait logic
    is useful in CLI mode too (same Playwright browser), so we replicate it.
    """

    @staticmethod
    async def simulate_typing(element, text, fast_mode=False):
        import random
        import asyncio as _asyncio
        if not text:
            return
        use_fast = fast_mode or len(text) >= 20
        try:
            if hasattr(element, 'fill'):
                if use_fast:
                    await element.fill(text)
                else:
                    await element.fill('')
                    await _asyncio.sleep(random.uniform(0.02, 0.05))
                    for char in text:
                        await element.type(char, delay=random.uniform(15, 40))
            elif hasattr(element, 'input'):
                if use_fast:
                    element.input(text)
                else:
                    element.clear()
                    await _asyncio.sleep(random.uniform(0.02, 0.05))
                    for char in text:
                        element.input(char)
                        await _asyncio.sleep(random.uniform(0.01, 0.03))
        except Exception:
            if hasattr(element, 'fill'):
                await element.fill(text)
            elif hasattr(element, 'input'):
                element.input(text)

    @staticmethod
    async def wait_for_upload_complete(session, page, upload_indicator_selector, timeout=120, wait_strategy='visible'):
        import asyncio as _asyncio
        try:
            session.send_message('info', {'message': '等待上传完成...'})
            if upload_indicator_selector and hasattr(page, 'wait_for_selector'):
                if wait_strategy == 'hidden':
                    await page.wait_for_selector(upload_indicator_selector, state="hidden", timeout=timeout * 1000)
                elif wait_strategy == 'detached':
                    await page.wait_for_selector(upload_indicator_selector, state="detached", timeout=timeout * 1000)
                elif wait_strategy == 'visible':
                    await page.wait_for_selector(upload_indicator_selector, state="visible", timeout=timeout * 1000)
                else:
                    await _asyncio.sleep(12)
            else:
                await _asyncio.sleep(12)
            session.send_message('info', {'message': '上传完成'})
            return True
        except Exception as e:
            session.send_message('error', {'message': f'上传等待出错: {e}'})
            return False

    @staticmethod
    async def simulate_human_behavior(page):
        import random
        import asyncio as _asyncio
        try:
            if hasattr(page, 'mouse') and hasattr(page, 'viewport_size'):
                vs = page.viewport_size
                if callable(vs):
                    vs = vs()
                w, h = vs.get('width', 1280), vs.get('height', 720)
                for _ in range(3):
                    await page.mouse.move(random.randint(100, w - 100), random.randint(100, h - 100))
                    await _asyncio.sleep(random.uniform(0.1, 0.3))
        except Exception:
            pass

    @staticmethod
    async def add_random_delay(min_delay=0.1, max_delay=0.3):
        import random
        import asyncio as _asyncio
        await _asyncio.sleep(random.uniform(min_delay, max_delay))

    @staticmethod
    async def move_mouse_to_element(page, element):
        import random
        import asyncio as _asyncio
        try:
            if hasattr(element, 'bounding_box') and hasattr(page, 'mouse'):
                box = await element.bounding_box()
                if box:
                    x = box['x'] + box['width'] / 2
                    y = box['y'] + box['height'] / 2
                    await page.mouse.move(random.randint(100, 800), random.randint(100, 600))
                    await _asyncio.sleep(random.uniform(0.1, 0.3))
                    await page.mouse.move(x, y)
                    await _asyncio.sleep(random.uniform(0.1, 0.2))
        except Exception:
            pass
