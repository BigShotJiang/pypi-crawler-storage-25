"""Pending task result store — persist undelivered results for retry after reconnect.

Results are saved as JSON files in ~/.huimei/pending_results/.
On successful delivery (HTTP or WebSocket), the file is deleted.
On reconnect, ws_worker flushes all pending results.
"""

import json
import logging
from pathlib import Path
from typing import Optional

from huimei_cli.config import CONFIG_DIR

logger = logging.getLogger(__name__)

PENDING_DIR = CONFIG_DIR / "pending_results"


def save_pending_result(task_uuid: str, result: dict) -> Path:
    """Persist a task result locally for later retry.

    Args:
        task_uuid: Unique task identifier.
        result: Dict with keys: task_uuid, status, message, data, etc.

    Returns:
        Path to the saved file.
    """
    PENDING_DIR.mkdir(parents=True, exist_ok=True)
    file_path = PENDING_DIR / f"{task_uuid}.json"
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)
    logger.info("Saved pending result: %s", task_uuid)
    return file_path


def get_pending_results() -> list[dict]:
    """Load all pending results from disk.

    Returns:
        List of result dicts, oldest first.
    """
    if not PENDING_DIR.exists():
        return []

    results = []
    for file_path in sorted(PENDING_DIR.glob("*.json")):
        try:
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)
            data["_file_path"] = str(file_path)
            results.append(data)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load pending result %s: %s", file_path.name, e)
    return results


def remove_pending_result(task_uuid: str) -> bool:
    """Delete a pending result after successful delivery.

    Returns:
        True if file was found and deleted.
    """
    file_path = PENDING_DIR / f"{task_uuid}.json"
    if file_path.exists():
        try:
            file_path.unlink()
            logger.info("Removed pending result: %s", task_uuid)
            return True
        except OSError as e:
            logger.warning("Failed to remove pending result %s: %s", task_uuid, e)
    return False


def flush_pending_via_http(api_client) -> tuple[int, int]:
    """Try to deliver all pending results via HTTP API.

    Args:
        api_client: An ApiClient instance with valid token.

    Returns:
        (success_count, fail_count) tuple.
    """
    results = get_pending_results()
    if not results:
        return 0, 0

    logger.info("Flushing %d pending results via HTTP", len(results))
    success = 0
    failed = 0

    for result in results:
        task_uuid = result.get("task_uuid", "")
        if not task_uuid:
            # Invalid entry, remove it
            fp = result.get("_file_path")
            if fp:
                Path(fp).unlink(missing_ok=True)
            continue

        try:
            api_client.report_task_result(task_uuid, {
                "status": result.get("status", "failed"),
                "platform_post_id": result.get("platform_post_id"),
                "error_message": result.get("message") or result.get("error_message"),
                "publish_url": result.get("publish_url"),
            })
            remove_pending_result(task_uuid)
            success += 1
            logger.info("Flushed pending result: %s", task_uuid)
        except Exception as e:
            failed += 1
            logger.warning("Failed to flush result %s: %s", task_uuid, e)

    return success, failed
