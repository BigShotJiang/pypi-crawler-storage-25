"""AES-256-CBC encryption/decryption for script transport.

Matches Java backend's ScriptServiceImpl.encryptAES() format:
  Base64(IV[16] + AES-CBC-encrypted-data)
"""

import base64
import logging
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

logger = logging.getLogger(__name__)

# Must match backend's script.encryption.key
_DEFAULT_KEY = "huimei2026secretk"


def decrypt_script(encrypted_b64: str, key: str = _DEFAULT_KEY) -> bytes:
    """Decrypt AES-256-CBC encrypted script from backend.
    
    Args:
        encrypted_b64: Base64 encoded string of IV(16 bytes) + ciphertext
        key: AES key string (will be padded/truncated to 32 bytes)
    
    Returns:
        Decrypted bytes (Python source code)
    """
    raw = base64.b64decode(encrypted_b64)
    iv = raw[:16]
    ciphertext = raw[16:]
    
    # Key must be 32 bytes for AES-256
    key_bytes = key.encode('utf-8')
    key32 = key_bytes.ljust(32, b'\x00')[:32]
    
    cipher = AES.new(key32, AES.MODE_CBC, iv)
    decrypted = unpad(cipher.decrypt(ciphertext), AES.block_size)
    
    return decrypted


def secure_wipe(data):
    """Best-effort secure wipe of bytes from memory."""
    if data is None:
        return
    try:
        import ctypes
        if isinstance(data, (bytes, bytearray)):
            buf = (ctypes.c_char * len(data)).from_buffer_copy(data)
            ctypes.memset(ctypes.addressof(buf), 0, len(data))
    except Exception:
        pass
