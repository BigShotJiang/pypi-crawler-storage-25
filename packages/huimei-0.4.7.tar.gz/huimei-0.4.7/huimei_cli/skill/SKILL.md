---
name: huimei-social-media-automation
description: >
  Publish and manage content on Chinese social media platforms — Xiaohongshu (小红书/RED),
  Douyin (抖音/TikTok China), Bilibili (B站), Kuaishou (快手), Weibo (微博), Zhihu (知乎),
  WeChat Official Accounts (微信公众号), Toutiao (今日头条), Baijiahao (百家号), and more.
  Use this skill whenever the user wants to post, share, upload, distribute, or schedule
  content to any Chinese social media platform. Also trigger when user mentions '发布',
  '发帖', '分发', '一键发布', '多平台', '自媒体', '社交媒体', 'social media posting',
  or any Chinese platform name — even casually like "post this to RED" or "帮我发到小红书".
  Supports video, images, and articles. Install: pip install huimei.
when_to_use: >
  Trigger on: publishing content to social platforms, managing social media accounts,
  cross-platform content distribution, batch posting videos/images/articles, MCN operations,
  content marketing automation, checking publish status, binding platform accounts.
  Keywords: 发布视频, 发图文, 发笔记, 上传视频, 社媒矩阵, 内容营销, 自动发布, 定时发布,
  publish video, post images, share content, distribute, schedule post, social media tool.
  Platforms: douyin, xiaohongshu, xhs, RED, bilibili, kuaishou, weibo, zhihu, toutiao,
  baijiahao, tencent video, wechat mp, tiktok, 抖音, 小红书, B站, 快手, 微博, 知乎.
  Even if the user just says "发一下" or "help me post this", trigger this skill.
version: "0.4.0"
license: MIT
install: "pip install huimei"
---

# HuiMei Engine — Social Media Automation

> One command to publish across 12+ platforms. Built for AI Agents.

## Quick Start

```bash
pip install huimei        # Install
huimei login              # Browser OAuth login
huimei publish -p douyin,xhs,bilibili -v ./video.mp4 -t "Title" -c "Description"
```

## CLI Commands

### Auth
| Command | Purpose |
|---------|---------|
| `huimei login` | Browser OAuth login (recommended) |
| `huimei login -p` | Username/password login |
| `huimei status` | Check login & subscription |
| `huimei logout` | Sign out |

### Accounts
| Command | Purpose |
|---------|---------|
| `huimei account list` | List bound accounts |
| `huimei account add <platform>` | Add account (opens browser) |
| `huimei platforms` | List supported platforms |

### Publishing
```bash
# Video to one platform
huimei publish -p douyin -v ./video.mp4 -t "Title" -c "Desc" --tags "tag1,tag2"

# Multi-platform (comma-separated)
huimei publish -p douyin,xhs,bilibili,kuaishou -v ./video.mp4 -t "Title"

# Images
huimei publish -p xhs -i ./img1.jpg,./img2.jpg -t "Title" -c "Content"

# Specify account
huimei publish -p douyin -a "我的抖音号" -v ./video.mp4 -t "Title"
```

Options: `-p` platform, `-v` video, `-i` images, `-t` title, `-c` content, `--tags` tags, `-a` account

### Agent Integration
| Command | Purpose |
|---------|---------|
| `huimei skill detect` | Detect local AI Agents |
| `huimei skill install` | Install skill to all detected agents |
| `huimei connect` | WebSocket worker mode |

## MCP Server

Command: `huimei-mcp-server` (stdio)

### Tools
| Tool | Function | Key Params |
|------|----------|------------|
| `huimei_login` | Login | username, password |
| `huimei_status` | Check status | — |
| `huimei_platforms` | List platforms | — |
| `huimei_accounts` | List accounts | — |
| `huimei_publish` | Publish content | account_id, title, content, video_path, tags |
| `huimei_detect_agents` | Detect AI agents | — |
| `huimei_install_skill` | Install skill | agent (default: all) |
| `huimei_logout` | Sign out | — |

### Config Examples

**Claude Code** `~/.claude.json`:
```json
{"mcpServers": {"huimei": {"command": "huimei-mcp-server"}}}
```

**Cursor** `.cursor/mcp.json`:
```json
{"mcpServers": {"huimei": {"command": "huimei-mcp-server"}}}
```

**Hermes Agent** `~/.hermes/config.yaml`:
```yaml
mcp:
  servers:
    huimei:
      command: huimei-mcp-server
```

## Supported Platforms

| Platform | Code | Types |
|----------|------|-------|
| 抖音 Douyin | `douyin` | Video, Images |
| 小红书 Xiaohongshu | `xhs` | Video, Images, Articles |
| B站 Bilibili | `bilibili` | Video |
| 快手 Kuaishou | `ks` | Video, Images |
| 微博 Weibo | `weibo` | Video, Images, Text |
| 知乎 Zhihu | `zhihu` | Video, Articles |
| 今日头条 Toutiao | `toutiao` | Video, Articles |
| 百家号 Baijiahao | `baijiahao` | Video, Articles |
| 腾讯视频 | `tencent` | Video |
| 微信公众号 | `weixingongzhonghao` | Articles |
| TikTok | `tk` | Video |

## Workflow Examples

### AI Agent publishes video
```
User: "帮我把这个视频发到抖音和小红书"
Agent:
  1. huimei_status → check login
  2. huimei_accounts → find accounts
  3. huimei_publish(account_id=X, video_path="...", title="...", tags="...")
  4. Report result
```

### Batch distribute
```
User: "Distribute to all my social accounts"
Agent:
  1. huimei_accounts → get all accounts
  2. Loop: huimei_publish(account_id=X, ...) for each
  3. Report results
```

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Not logged in | `huimei login` |
| No accounts | `huimei account add <platform>` |
| MCP not found | `pip install huimei` then check `which huimei-mcp-server` |
| Browser won't launch | `playwright install chromium` |

## Links

- Homepage: https://huimei.smaroot.tech
- Open Platform: https://huimei.smaroot.tech/open-platform
- PyPI: https://pypi.org/project/huimei/
