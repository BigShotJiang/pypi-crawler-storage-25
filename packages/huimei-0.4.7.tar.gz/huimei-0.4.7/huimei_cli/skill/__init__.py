"""Skill资源包 — 包含 SKILL.md 供安装到各AI Agent。"""
