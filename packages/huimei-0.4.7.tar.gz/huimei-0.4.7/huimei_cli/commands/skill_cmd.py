"""Skill commands: detect, install, uninstall, status."""

import glob
import os
import shutil
import subprocess
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

console = Console()
app = typer.Typer(help="AI Agent skill管理")

SKILL_NAME = "huimei-social-media-automation"

AGENT_CONFIGS = {
    "claude-code": {
        "display_name": "Claude Code",
        "detect": [
            {"type": "command", "cmd": "claude", "args": ["--version"]},
            {"type": "dir", "path": "~/.claude"},
        ],
        "skill_dir": f"~/.claude/skills/{SKILL_NAME}",
    },
    "cursor": {
        "display_name": "Cursor",
        "detect": [
            {"type": "command", "cmd": "cursor", "args": ["--version"]},
            {"type": "dir", "path": "~/.cursor"},
        ],
        "skill_dir": f"~/.cursor/skills/{SKILL_NAME}",
        "compat_dir": f"~/.agents/skills/{SKILL_NAME}",
    },
    "opencode": {
        "display_name": "OpenCode",
        "detect": [
            {"type": "command", "cmd": "opencode", "args": ["version"]},
            {"type": "dir", "path": "~/.config/opencode"},
        ],
        "skill_dir": f"~/.config/opencode/skills/{SKILL_NAME}",
    },
    "hermes": {
        "display_name": "Hermes Agent",
        "detect": [
            {"type": "command", "cmd": "hermes", "args": ["--version"]},
            {"type": "dir", "path": "~/.hermes"},
        ],
        "skill_dir": f"~/.hermes/skills/{SKILL_NAME}",
    },
    "windsurf": {
        "display_name": "Windsurf",
        "detect": [
            {"type": "dir", "path": "~/.windsurf"},
            {"type": "dir", "path": "~/.codeium"},
        ],
        "skill_dir": f"~/.windsurf/skills/{SKILL_NAME}",
    },
    "copilot": {
        "display_name": "GitHub Copilot",
        "detect": [
            {"type": "dir_glob", "pattern": "~/.vscode/extensions/github.copilot-*"},
        ],
        "skill_dir": f"~/.agents/skills/{SKILL_NAME}",
    },
}


def _get_skill_md() -> str:
    """读取内置 SKILL.md 内容。"""
    skill_path = Path(__file__).parent.parent / "skill" / "SKILL.md"
    return skill_path.read_text(encoding="utf-8")


def _check_agent(key: str, cfg: dict) -> dict:
    """检测单个Agent，返回 {detected, version, skill_installed}。"""
    detected = False
    version = ""
    for check in cfg["detect"]:
        if check["type"] == "command":
            try:
                r = subprocess.run(
                    [check["cmd"]] + check.get("args", []),
                    capture_output=True, text=True, timeout=5,
                )
                if r.returncode == 0:
                    detected = True
                    version = r.stdout.strip().split("\n")[0][:40]
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
        elif check["type"] == "dir":
            if Path(check["path"]).expanduser().is_dir():
                detected = True
        elif check["type"] == "dir_glob":
            if glob.glob(os.path.expanduser(check["pattern"])):
                detected = True

    skill_dir = Path(cfg["skill_dir"]).expanduser()
    skill_installed = (skill_dir / "SKILL.md").is_file()
    return {"detected": detected, "version": version, "installed": skill_installed}


def detect_all() -> dict:
    """检测所有Agent，返回 {key: {detected, version, installed, cfg}}。"""
    results = {}
    for key, cfg in AGENT_CONFIGS.items():
        info = _check_agent(key, cfg)
        info["cfg"] = cfg
        results[key] = info
    return results


@app.command()
def detect():
    """检测本地已安装的 AI Agent"""
    results = detect_all()
    table = Table(title="AI Agent 检测结果")
    table.add_column("Agent", style="cyan")
    table.add_column("状态")
    table.add_column("版本", style="dim")
    table.add_column("Skill", justify="center")

    found = 0
    for key, info in results.items():
        name = info["cfg"]["display_name"]
        if info["detected"]:
            found += 1
            st = "[green]已安装[/green]"
            sk = "[green]✓[/green]" if info["installed"] else "[dim]未安装[/dim]"
        else:
            st = "[dim]未检测到[/dim]"
            sk = "-"
        table.add_row(name, st, info["version"] or "-", sk)

    console.print(table)
    if found:
        console.print(f"\n检测到 [cyan]{found}[/cyan] 个Agent，运行 [bold]huimei skill install[/bold] 安装skill")
    else:
        console.print("\n[yellow]未检测到任何Agent[/yellow]")


def _install_to(skill_dir: Path, content: str) -> bool:
    """将 SKILL.md 写入目标目录。"""
    skill_dir.mkdir(parents=True, exist_ok=True)
    (skill_dir / "SKILL.md").write_text(content, encoding="utf-8")
    return True


@app.command()
def install(agent: str = typer.Argument("all", help="Agent名称或 all")):
    """安装 skill 到检测到的 AI Agent"""
    content = _get_skill_md()
    results = detect_all()
    targets = {}

    if agent == "all":
        targets = {k: v for k, v in results.items() if v["detected"]}
    elif agent in results:
        targets = {agent: results[agent]}
    else:
        console.print(f"[red]✗[/red] 未知Agent: {agent}")
        console.print(f"可选: {', '.join(AGENT_CONFIGS.keys())}, all")
        raise typer.Exit(1)

    if not targets:
        console.print("[yellow]未检测到可安装的Agent[/yellow]")
        raise typer.Exit(0)

    installed = 0
    for key, info in targets.items():
        cfg = info["cfg"]
        name = cfg["display_name"]
        skill_dir = Path(cfg["skill_dir"]).expanduser()
        try:
            _install_to(skill_dir, content)
            console.print(f"  [green]✓[/green] {name} → {skill_dir}")
            installed += 1
            # 兼容路径
            compat = cfg.get("compat_dir")
            if compat:
                _install_to(Path(compat).expanduser(), content)
                console.print(f"    [dim]+ 兼容路径: {compat}[/dim]")
        except Exception as e:
            console.print(f"  [red]✗[/red] {name}: {e}")

    console.print(f"\n[green]完成[/green]，已安装到 {installed} 个Agent")


@app.command()
def uninstall(agent: str = typer.Argument("all", help="Agent名称或 all")):
    """从 AI Agent 中卸载 skill"""
    results = detect_all()
    targets = {agent: results[agent]} if agent != "all" else results
    removed = 0

    for key, info in targets.items():
        cfg = info["cfg"]
        name = cfg["display_name"]
        for dir_key in ("skill_dir", "compat_dir"):
            d = cfg.get(dir_key)
            if not d:
                continue
            p = Path(d).expanduser()
            if p.is_dir():
                shutil.rmtree(p)
                console.print(f"  [green]✓[/green] 已移除 {name}: {p}")
                removed += 1

    console.print(f"\n移除了 {removed} 处skill文件" if removed else "[dim]无需移除[/dim]")


@app.command()
def status():
    """查看 skill 安装状态"""
    detect()
