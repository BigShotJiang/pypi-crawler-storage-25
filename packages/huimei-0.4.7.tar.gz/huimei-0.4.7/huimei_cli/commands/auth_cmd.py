"""Auth commands: login, logout, status."""

import typer
from rich.console import Console
from rich.table import Table

from huimei_cli.auth import (
    do_login, do_browser_login, is_logged_in,
    get_current_user, logout,
)
from huimei_cli.config import get_server_url, get_frontend_url
from huimei_cli.api_client import ApiClient, ApiError
from huimei_cli.engine.worker_process import is_worker_running, stop_worker, start_worker

console = Console()
app = typer.Typer(help="认证相关命令")


@app.command()
def login(
    password_mode: bool = typer.Option(
        False, "--password", "-p", help="使用用户名密码登录（非浏览器）"
    ),
    server: str = typer.Option(None, help="服务器地址"),
):
    """登录慧媒引擎账号（默认打开浏览器）"""
    from huimei_cli.config import resolve_server_alias, resolve_frontend_alias

    # Record current server URL before login to detect changes
    old_server = get_server_url()

    # Resolve alias (e.g. "prod" → full URL)
    resolved_server = resolve_server_alias(server) if server else None
    resolved_frontend = resolve_frontend_alias(server) if server else None

    if password_mode:
        username = typer.prompt("用户名")
        password = typer.prompt("密码", hide_input=True)
        with console.status("正在登录..."):
            ok = do_login(username, password, resolved_server)
        if ok:
            user = get_current_user()
            name = user.get("username", username) if user else username
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败，请检查用户名和密码")
            raise typer.Exit(1)
    else:
        api_url = resolved_server or get_server_url()
        fe_url = resolved_frontend or get_frontend_url()
        console.print(f"[cyan]正在打开浏览器登录...[/cyan]")
        console.print(f"[dim]服务器: {api_url}[/dim]")
        console.print(f"请在浏览器中完成登录，登录成功后将自动获取凭证")
        ok = do_browser_login(server_url=api_url, frontend_url=fe_url)
        if ok:
            user = get_current_user()
            name = user.get("username", "用户") if user else "用户"
            console.print(f"[green]✓[/green] 登录成功，欢迎 {name}")
        else:
            console.print("[red]✗[/red] 登录失败或超时")
            raise typer.Exit(1)

    # Auto-restart worker if server changed or worker is running
    try:
        _auto_restart_worker(old_server)
    except Exception as e:
        console.print(f"[yellow]⚠ Worker 启动失败: {e}[/yellow]")


@app.command()
def status():
    """查看当前登录状态和订阅信息"""
    if not is_logged_in():
        console.print("[yellow]未登录[/yellow]，请先运行 huimei login")
        raise typer.Exit(1)

    user = get_current_user()
    table = Table(title="账号状态")
    table.add_column("项目", style="cyan")
    table.add_column("值")
    table.add_row("用户名", user.get("username", "未知") if user else "未知")
    table.add_row("服务器", get_server_url())
    table.add_row("登录状态", "[green]已登录[/green]")

    # Try to get subscription info
    try:
        from huimei_cli.config import get_config
        cfg = get_config()
        client = ApiClient(get_server_url(), cfg.get("token"))
        sub = client.get_subscription_info()
        if sub:
            table.add_row("订阅类型", str(sub.get("plan", "免费版")))
            table.add_row("到期时间", str(sub.get("expire_time", "-")))
    except Exception:
        table.add_row("订阅信息", "[dim]获取失败[/dim]")

    console.print(table)


@app.command(name="logout")
def do_logout():
    """退出登录"""
    logout()
    # Also stop worker since credentials are gone
    if is_worker_running():
        stop_worker()
        console.print("[dim]Worker 已停止[/dim]")
    console.print("[green]✓[/green] 已退出登录")


def _auto_restart_worker(old_server: str):
    """Auto-restart worker if server URL changed or worker needs a fresh connection.
    
    Called after successful login to ensure the background worker
    reconnects to the correct server with the new token.
    """
    new_server = get_server_url()
    server_changed = (old_server != new_server)

    if is_worker_running():
        if server_changed:
            console.print(f"[dim]服务器已切换 → 重启 Worker...[/dim]")
        else:
            console.print(f"[dim]Token 已更新 → 重启 Worker...[/dim]")
        stop_worker()
        start_worker()
        console.print("[dim]Worker 已重连[/dim]")
    else:
        # Worker not running — start it automatically after login
        start_worker()
        console.print("[dim]Worker 已启动[/dim]")
