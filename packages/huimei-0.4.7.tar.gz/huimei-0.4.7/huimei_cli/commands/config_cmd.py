"""Config commands: mode switching and settings management."""

import typer
from rich.console import Console
from rich.table import Table

from huimei_cli.auth import is_logged_in
from huimei_cli.config import get_config, save_config, get_server_url
from huimei_cli.api_client import ApiClient, ApiError

console = Console()
app = typer.Typer(help="执行模式与配置管理")

VALID_MODES = ("cloud", "local", "auto")
MODE_LABELS = {
    "cloud": "☁️  云端执行",
    "local": "🖥  本地执行",
    "auto": "⚡ 自动选择",
}
MODE_DESCRIPTIONS = {
    "cloud": "所有任务由云端引擎执行（无需本地浏览器）",
    "local": "所有任务由本地CLI执行（使用本地浏览器，住宅IP）",
    "auto": "优先本地CLI，离线或失败时自动回退云端",
}


def _require_login():
    if not is_logged_in():
        console.print("[red]✗[/red] 请先登录: huimei login")
        raise typer.Exit(1)


def _get_client() -> ApiClient:
    cfg = get_config()
    return ApiClient(get_server_url(), cfg.get("token"))


@app.command(name="mode")
def set_mode(
    mode: str = typer.Argument(
        None,
        help="执行模式: cloud(云端), local(本地), auto(自动)",
    ),
):
    """查看或切换执行模式（cloud/local/auto）

    不带参数: 显示当前模式
    带参数: 切换到指定模式（同步到服务端，WebUI立即生效）
    """
    _require_login()

    if mode is None:
        # 显示当前模式
        _show_current_mode()
        return

    # 标准化输入
    mode = mode.lower().strip()
    if mode not in VALID_MODES:
        console.print(f"[red]✗[/red] 无效模式: {mode}")
        console.print(f"  可选: {', '.join(VALID_MODES)}")
        raise typer.Exit(1)

    # 调用后端 API 更新（后端会同步给 WebUI 和 WebSocket）
    try:
        client = _get_client()
        result = client.update_settings({"execution_mode": mode})
    except ApiError as e:
        console.print(f"[red]✗[/red] 切换失败: {e.message}")
        raise typer.Exit(1)

    # 同步到本地 config
    config = get_config()
    if "execution" not in config:
        config["execution"] = {}
    config["execution"]["mode"] = mode
    save_config(config)

    console.print(f"[green]✓[/green] 执行模式已切换为: [bold]{MODE_LABELS[mode]}[/bold]")
    console.print(f"  [dim]{MODE_DESCRIPTIONS[mode]}[/dim]")


@app.command(name="show")
def show_config():
    """显示当前所有配置和设置"""
    _require_login()
    _show_current_mode()


def _show_current_mode():
    """查询服务端设置并显示。"""
    try:
        client = _get_client()
        settings = client.get_settings()
    except ApiError as e:
        # 降级：显示本地配置
        console.print(f"[dim]服务端查询失败({e.message})，显示本地配置[/dim]")
        config = get_config()
        mode = config.get("execution", {}).get("mode", "auto")
        settings = {"execution_mode": mode, "cli_online": "未知"}

    mode = settings.get("execution_mode", "auto")
    cli_online = settings.get("cli_online", False)
    upload_media = settings.get("cli_upload_media", True)

    table = Table(title="执行配置")
    table.add_column("设置项", style="cyan")
    table.add_column("当前值")
    table.add_column("说明", style="dim")

    # 执行模式
    mode_display = MODE_LABELS.get(mode, mode)
    table.add_row("执行模式", f"[bold]{mode_display}[/bold]", MODE_DESCRIPTIONS.get(mode, ""))

    # CLI 在线状态
    if cli_online is True:
        online_str = "[green]在线[/green]"
    elif cli_online is False:
        online_str = "[red]离线[/red]"
    else:
        online_str = "[dim]未知[/dim]"
    table.add_row("CLI Worker", online_str, "后台Worker连接状态")

    # 上传媒体
    upload_str = "[green]开启[/green]" if upload_media else "[dim]关闭[/dim]"
    table.add_row("上传媒体", upload_str, "本地执行后是否上传结果到云端")

    console.print(table)
    console.print("")
    console.print("[dim]切换模式: huimei config mode <cloud|local|auto>[/dim]")
