"""Authentication management for huimei-cli."""

import json
import base64
import logging
import webbrowser
from urllib.parse import urlencode

from huimei_cli.config import (
    get_config, save_config, get_server_url, get_frontend_url, save_token,
    resolve_frontend_alias,
)
from huimei_cli.api_client import ApiClient, ApiError

logger = logging.getLogger(__name__)


def do_login(username: str, password: str, server_url: str = None) -> bool:
    """Login via username/password API call."""
    url = server_url or get_server_url()
    client = ApiClient(server_url=url)
    try:
        data = client.login(username, password)
        token = data.get("token") if isinstance(data, dict) else None
        if not token:
            return False
        save_token(token)
        if server_url:
            cfg = get_config()
            cfg["server_url"] = server_url
            save_config(cfg)
        return True
    except (ApiError, Exception):
        return False


def do_browser_login(server_url: str = None, frontend_url: str = None,
                     timeout: float = 300) -> bool:
    """Login via system default browser (OAuth Device Flow style).

    Args:
        server_url: Backend API URL (for token validation). Already resolved.
        frontend_url: Frontend URL to open in browser. Already resolved.
                      Falls back to get_frontend_url() if not provided.
        timeout: Seconds to wait for callback.

    Flow:
        1. Start a local HTTP server to receive the callback
        2. Open the login page in the user's default browser with cli_callback param
        3. After login, the frontend redirects to localhost with the token
        4. CLI receives the token and saves it

    Works on any OS, any browser, no Playwright dependency.
    If the user is already logged in, the frontend redirects immediately.
    """
    from huimei_cli.server import CliLocalServer

    url = server_url or get_server_url()
    fe_url = frontend_url or get_frontend_url()

    # Start local callback server
    local_server = CliLocalServer()
    local_server._httpd.frontend_url = fe_url  # Pass to callback handler for redirect
    local_server.start()

    # Build login URL with callback — use frontend URL (not API server)
    login_url = fe_url.rstrip("/") + "/login?" + urlencode({
        "cli_callback": local_server.callback_url,
    })

    # Open in default browser
    logger.info("Opening browser: %s", login_url)
    webbrowser.open(login_url)

    # Wait for callback
    token = local_server.wait_for_token(timeout=timeout)
    local_server.stop()

    if token:
        # Validate before saving
        if _validate_token(token, url):
            save_token(token)
            if server_url and server_url != get_server_url():
                cfg = get_config()
                cfg["server_url"] = server_url
                save_config(cfg)
            return True
        logger.warning("Received token is invalid or expired")
    return False


def _validate_token(token: str, server_url: str) -> bool:
    """Check if a token is still valid by making a lightweight API call."""
    try:
        client = ApiClient(server_url=server_url, token=token)
        client.get_subscription_info()
        return True
    except (ApiError, Exception):
        return False


def is_logged_in() -> bool:
    """Check whether a valid token exists in config."""
    cfg = get_config()
    return bool(cfg.get("token"))


def get_current_user() -> dict | None:
    """Decode the JWT token payload to get current user info.

    Decodes without verification — only reads the payload claims.

    Returns:
        Dict of user claims from token, or None if not logged in.
    """
    cfg = get_config()
    token = cfg.get("token")
    if not token:
        return None
    try:
        payload_b64 = token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes)
    except (IndexError, ValueError, json.JSONDecodeError):
        return None


def logout() -> None:
    """Clear authentication token from config."""
    cfg = get_config()
    cfg.pop("token", None)
    save_config(cfg)
