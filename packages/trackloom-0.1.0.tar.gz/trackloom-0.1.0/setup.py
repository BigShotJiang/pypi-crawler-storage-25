# SPDX-License-Identifier: GPL-3.0-or-later
# Built by Dan Getz, Jr.
from setuptools import setup

setup()
