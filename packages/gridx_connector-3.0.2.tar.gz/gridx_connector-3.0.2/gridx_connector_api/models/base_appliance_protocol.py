from enum import Enum


class BaseApplianceProtocol(str, Enum):
    EEBUS = "EEBUS"
    HTTP_REST = "HTTP_REST"
    MODBUS_RTU = "MODBUS_RTU"
    MODBUS_TCP = "MODBUS_TCP"
    OCPP = "OCPP"
    UNKNOWN = "UNKNOWN"

    def __str__(self) -> str:
        return str(self.value)
