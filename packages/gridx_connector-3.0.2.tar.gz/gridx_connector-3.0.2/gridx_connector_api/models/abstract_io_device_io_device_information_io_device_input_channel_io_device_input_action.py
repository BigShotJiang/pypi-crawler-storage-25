from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AbstractIODeviceIODeviceInformationIODeviceInputChannelIODeviceInputAction")


@_attrs_define
class AbstractIODeviceIODeviceInformationIODeviceInputChannelIODeviceInputAction:
    """One individual input action, that can be registered to a channel of a fieldbus coppler appliance.

    Attributes:
        name (str): Name of the action.
        value (float): Value of the action. Unit must be derived from Name.
    """

    name: str
    value: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "value": value,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        value = d.pop("value")

        abstract_io_device_io_device_information_io_device_input_channel_io_device_input_action = cls(
            name=name,
            value=value,
        )

        abstract_io_device_io_device_information_io_device_input_channel_io_device_input_action.additional_properties = d
        return abstract_io_device_io_device_information_io_device_input_channel_io_device_input_action

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
