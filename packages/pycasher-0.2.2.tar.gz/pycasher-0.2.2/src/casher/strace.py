import dataclasses
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from casher.config import (
    STRACE_IGNORE_CONTAINS,
    STRACE_IGNORE_PREFIXES,
    STRACE_IGNORE_SUFFIXES,
)


@dataclasses.dataclass
class StraceResult:
    stdout: str
    stderr: str
    returncode: int
    read_files: list[Path]
    write_files: list[Path]


# Matches: openat(AT_FDCWD, "/path/to/file", O_RDONLY) = 3
# Also:    openat(AT_FDCWD, "/path/to/file", O_WRONLY|O_CREAT|O_TRUNC, 0666) = 3
_OPENAT_RE = re.compile(r'openat\(AT_FDCWD,\s*"([^"]+)",\s*([^)]+)\)\s*=\s*(\d+)')

# Matches: open("/path/to/file", O_RDONLY) = 3
_OPEN_RE = re.compile(r'open\("([^"]+)",\s*([^)]+)\)\s*=\s*(\d+)')

_WRITE_FLAGS = {"O_WRONLY", "O_RDWR", "O_CREAT", "O_TRUNC"}


def is_strace_available() -> bool:
    return shutil.which("strace") is not None


def _should_ignore(path: str) -> bool:
    if any(path.startswith(p) for p in STRACE_IGNORE_PREFIXES):
        return True
    if any(path.endswith(s) for s in STRACE_IGNORE_SUFFIXES):
        return True
    if any(c in path for c in STRACE_IGNORE_CONTAINS):
        return True
    return False


def parse_strace_log(trace_file: Path) -> tuple[list[Path], list[Path]]:
    read_files: list[Path] = []
    write_files: list[Path] = []
    seen_read: set[str] = set()
    seen_write: set[str] = set()

    text = trace_file.read_text(errors="replace")
    for line in text.splitlines():
        m = _OPENAT_RE.search(line) or _OPEN_RE.search(line)
        if not m:
            continue
        filepath = m.group(1)
        flags_str = m.group(2)
        fd = int(m.group(3))
        # fd < 0 means the open failed
        if fd < 0:
            continue
        if _should_ignore(filepath):
            continue

        flags = {f.strip() for f in flags_str.split("|")}
        if flags & _WRITE_FLAGS:
            if filepath not in seen_write:
                seen_write.add(filepath)
                write_files.append(Path(filepath))
        else:
            if filepath not in seen_read:
                seen_read.add(filepath)
                read_files.append(Path(filepath))

    return read_files, write_files


def run_with_strace(cmd: list[str], **popen_kwargs) -> StraceResult:
    assert is_strace_available(), (
        "strace is required for subprocess=True mode. "
        "Install it (e.g., 'sudo pacman -S strace') or use subprocess=False."
    )

    with tempfile.NamedTemporaryFile(suffix=".strace", delete=False) as tf:
        trace_file = Path(tf.name)

    try:
        strace_cmd = [
            "strace",
            "-f",
            "-e",
            "trace=openat,open",
            "-o",
            str(trace_file),
            "--",
        ] + cmd

        proc = subprocess.run(
            strace_cmd,
            capture_output=True,
            text=True,
            **popen_kwargs,
        )

        read_files, write_files = parse_strace_log(trace_file)

        return StraceResult(
            stdout=proc.stdout,
            stderr=proc.stderr,
            returncode=proc.returncode,
            read_files=read_files,
            write_files=write_files,
        )
    finally:
        trace_file.unlink(missing_ok=True)
