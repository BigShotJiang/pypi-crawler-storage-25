import os
import time

import pytest

from casher.config import META_FILENAME
from casher.eviction import evict_if_needed, get_cache_size, get_entry_size
from casher.store import CacheEntry, store_result


def _make_entry(size_bytes: int = 100, **overrides) -> CacheEntry:
    """Create a cache entry whose serialized return value is approximately size_bytes."""
    defaults = dict(
        return_value="x" * size_bytes,
        stdout="",
        stderr="",
        output_files={},
        input_files={},
        created_at=time.time(),
        func_module="test_mod",
        func_name="test_fn",
    )
    defaults.update(overrides)
    return CacheEntry(**defaults)


def _store_entry(cache_dir, partial_key, file_hash, size_bytes=100, mtime=None):
    """Store an entry and optionally set its meta.json mtime."""
    entry = _make_entry(size_bytes=size_bytes)
    result_dir = store_result(cache_dir, partial_key, file_hash, entry, max_bytes=0)
    if mtime is not None:
        meta_path = result_dir / META_FILENAME
        os.utime(meta_path, (mtime, mtime))
    return result_dir


@pytest.mark.timeout(10)
def test_no_eviction_under_limit(tmp_path):
    cache_dir = tmp_path / "cache"
    for i in range(3):
        _store_entry(cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=100)

    evicted = evict_if_needed(cache_dir, max_bytes=100000)
    assert evicted == 0
    # All entries still exist
    for i in range(3):
        assert (cache_dir / f"pk_{i}" / f"fh_{i}" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_removes_oldest(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 300

    _store_entry(cache_dir, "pk_old", "fh_old", size_bytes=500, mtime=base_time)
    _store_entry(cache_dir, "pk_mid", "fh_mid", size_bytes=500, mtime=base_time + 100)
    _store_entry(cache_dir, "pk_new", "fh_new", size_bytes=500, mtime=base_time + 200)

    total = get_cache_size(cache_dir)
    # Set limit so only ~2 entries fit
    limit = total - 100

    evicted = evict_if_needed(cache_dir, max_bytes=limit)
    assert evicted >= 1
    # Oldest should be gone
    assert not (cache_dir / "pk_old" / "fh_old").exists()
    # Newest should survive
    assert (cache_dir / "pk_new" / "fh_new" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_removes_multiple(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 500

    for i in range(5):
        _store_entry(
            cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=500, mtime=base_time + i * 100
        )

    # Set limit so only ~2 entries fit
    single_size = get_entry_size(cache_dir / "pk_0" / "fh_0")
    limit = single_size * 2 + 50

    evicted = evict_if_needed(cache_dir, max_bytes=limit)
    assert evicted == 3
    # Oldest 3 gone
    for i in range(3):
        assert not (cache_dir / f"pk_{i}" / f"fh_{i}").exists()
    # Newest 2 survive
    for i in range(3, 5):
        assert (cache_dir / f"pk_{i}" / f"fh_{i}" / META_FILENAME).exists()


@pytest.mark.timeout(10)
def test_eviction_unlimited(tmp_path):
    cache_dir = tmp_path / "cache"
    for i in range(3):
        _store_entry(cache_dir, f"pk_{i}", f"fh_{i}", size_bytes=1000)

    evicted = evict_if_needed(cache_dir, max_bytes=0)
    assert evicted == 0


@pytest.mark.timeout(10)
def test_get_cache_size(tmp_path):
    cache_dir = tmp_path / "cache"
    _store_entry(cache_dir, "pk_a", "fh_a", size_bytes=200)
    _store_entry(cache_dir, "pk_b", "fh_b", size_bytes=300)

    total = get_cache_size(cache_dir)
    assert total > 0

    size_a = get_entry_size(cache_dir / "pk_a" / "fh_a")
    size_b = get_entry_size(cache_dir / "pk_b" / "fh_b")
    assert total == size_a + size_b


@pytest.mark.timeout(10)
def test_empty_partial_key_dir_cleaned(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 100

    _store_entry(cache_dir, "pk_solo", "fh_solo", size_bytes=500, mtime=base_time)

    single_size = get_entry_size(cache_dir / "pk_solo" / "fh_solo")
    # Evict with limit smaller than entry
    evicted = evict_if_needed(cache_dir, max_bytes=single_size - 1)
    assert evicted == 1
    assert not (cache_dir / "pk_solo").exists()


@pytest.mark.timeout(10)
def test_eviction_triggered_by_store(tmp_path):
    cache_dir = tmp_path / "cache"
    base_time = time.time() - 200

    # Store an initial entry
    _store_entry(cache_dir, "pk_old", "fh_old", size_bytes=500, mtime=base_time)
    old_size = get_entry_size(cache_dir / "pk_old" / "fh_old")

    # Store a new entry with max_bytes small enough that old entry must be evicted
    entry = _make_entry(size_bytes=500)
    store_result(cache_dir, "pk_new", "fh_new", entry, max_bytes=old_size + 100)

    # Old entry should be evicted
    assert not (cache_dir / "pk_old" / "fh_old").exists()
    # New entry should exist
    assert (cache_dir / "pk_new" / "fh_new" / META_FILENAME).exists()
