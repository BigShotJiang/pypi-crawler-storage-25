import os
import sys
from pathlib import Path

# Environment variable names
CACHE_DIR_ENV_VAR = "CASHER_CACHE_DIR"
MAX_CACHE_BYTES_ENV_VAR = "CASHER_MAX_CACHE_BYTES"

# Defaults
_DEFAULT_CACHE_DIR_PATH = Path("~/.cache/casher").expanduser()
_DEFAULT_MAX_CACHE_BYTES = 32 * 1024 * 1024 * 1024  # 32 GB

# Runtime overrides set via configure()
_overrides: dict[str, object] = {}


def configure(
    *,
    cache_dir: Path | str | None = None,
    max_cache_bytes: int | None = None,
) -> None:
    """Set runtime config. Takes priority over env vars and defaults.
    Call before any @cached function. Pass None to clear an override."""
    if cache_dir is not None:
        p = Path(cache_dir)
        p.mkdir(parents=True, exist_ok=True)
        _overrides["cache_dir"] = p
    elif "cache_dir" in _overrides:
        del _overrides["cache_dir"]

    if max_cache_bytes is not None:
        _overrides["max_cache_bytes"] = max_cache_bytes
    elif "max_cache_bytes" in _overrides:
        del _overrides["max_cache_bytes"]


def get_config() -> dict[str, object]:
    """Return effective config: override > env var > default."""
    return {
        "cache_dir": resolve_cache_dir(None),
        "max_cache_bytes": resolve_max_cache_bytes(None),
    }


def resolve_cache_dir(explicit: Path | str | None) -> Path:
    """Resolution order: explicit arg > configure() > env var > default."""
    if explicit is not None:
        return Path(explicit)
    if "cache_dir" in _overrides:
        return _overrides["cache_dir"]  # type: ignore[return-value]
    env_val = os.environ.get(CACHE_DIR_ENV_VAR)
    if env_val:
        return Path(env_val)
    return _DEFAULT_CACHE_DIR_PATH


def resolve_max_cache_bytes(explicit: int | None) -> int:
    """Resolution order: explicit arg > configure() > env var > default."""
    if explicit is not None:
        return explicit
    if "max_cache_bytes" in _overrides:
        return _overrides["max_cache_bytes"]  # type: ignore[return-value]
    env_val = os.environ.get(MAX_CACHE_BYTES_ENV_VAR)
    if env_val:
        return int(env_val)
    return _DEFAULT_MAX_CACHE_BYTES

HASH_ALGORITHM = "sha256"
META_FILENAME = "meta.json"
RESULT_FILENAME = "result.pkl"
STDOUT_FILENAME = "stdout.txt"
STDERR_FILENAME = "stderr.txt"
OUTPUT_FILES_DIR = "output_files"

# Platform support — caching only works on Linux (strace, audit hooks)
PLATFORM_SUPPORTED = sys.platform == "linux"

# strace filtering: paths matching these prefixes are NOT considered user file I/O
STRACE_IGNORE_PREFIXES = (
    "/dev/",
    "/proc/",
    "/sys/",
    "/tmp/casher-",
    "/usr/lib/",
    "/lib/",
    "/usr/local/lib/",
    "/usr/share/",
    "/etc/",
)
STRACE_IGNORE_SUFFIXES = (".pyc", ".pyo", ".so", ".dll", ".pth")
STRACE_IGNORE_CONTAINS = ("__pycache__", "site-packages", "/python3.")

# Dependency tracking: paths to consider as "own code"
DEFAULT_DEP_ROOTS: list[Path] = []
