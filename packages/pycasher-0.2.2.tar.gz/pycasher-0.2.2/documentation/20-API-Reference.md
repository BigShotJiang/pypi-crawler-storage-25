# API Reference

## `casher.configure`

```python
from casher import configure

configure(cache_dir="/data/my_cache", max_cache_bytes=10 * 1024**3)
```

Set runtime config before any `@cached` call. Takes priority over
environment variables and defaults. Pass `None` to clear an override.

Resolution order: explicit decorator arg > `configure()` > env var > default.

## `casher.get_config`

```python
from casher import get_config

cfg = get_config()
# {"cache_dir": Path("..."), "max_cache_bytes": 34359738368}
```

Returns the effective config after applying the resolution chain.

## `casher.cached`

```python
from casher import cached

@cached(
    cache_dir: str | Path = "~/.cache/casher",
    subprocess: bool = True,
    enabled: bool = True,
    dep_roots: list[str] | None = None,
    input_files: list[str] | None = None,
    ignore_files: list[str] | None = None,
    env_vars: list[str] | None = None,
    max_cache_bytes: int = 0,
)
def my_func(...) -> ...:
    ...
```

| Parameter         | Description                                                                                                |
| ----------------- | ---------------------------------------------------------------------------------------------------------- |
| `cache_dir`       | Directory for cache storage. Default: `CASHER_CACHE_DIR` env var, then `~/.cache/casher`.                  |
| `subprocess`      | `True`: run in subprocess with strace tracking. `False`: run in-process with audit hooks.                  |
| `enabled`         | Set `False` to bypass caching entirely. Also auto-disabled on non-Linux.                                   |
| `dep_roots`       | Directories to scan for Python dependency changes. `None` = auto-detect from function module location.     |
| `input_files`     | Extra files to include in cache key beyond auto-discovered ones.                                           |
| `ignore_files`    | Glob patterns for files to exclude from cache key (e.g., `["*.log"]`).                                     |
| `env_vars`        | Environment variable names to include in cache key.                                                        |
| `max_cache_bytes` | Maximum total cache size in bytes. Default: `CASHER_MAX_CACHE_BYTES` env var, then 32 GB. `0` = unlimited. |

## Cache key computation

1. **Partial key** = `sha256(module + func_name + canonical_args + dep_hash + env_hash)`
2. **Full key** = `sha256(partial_key + input_file_hashes)`

Cache directory layout: `<cache_dir>/<partial_key>/<full_key>/meta.json`

## `casher.auto_cli.run`

```python
from casher.auto_cli import run
run(func)
```

Generates an `argparse.ArgumentParser` from the function's signature and
type annotations, parses `sys.argv`, and calls the function.

| Annotation | argparse type                |
| ---------- | ---------------------------- |
| `str`      | `str`                        |
| `int`      | `int`                        |
| `float`    | `float`                      |
| `bool`     | `store_true` / `store_false` |
| `Path`     | `Path`                       |

## `acache` CLI

```
acache [--cache-dir DIR] [--max-cache-bytes N] -- command...
```

Caches arbitrary CLI programs using strace for I/O tracking. Requires
strace to be installed.

## `casher.store`

```python
from casher.store import find_cached, store_result, invalidate, clear_cache

# Look up cache entry
result = find_cached(cache_dir, partial_key)  # -> (CacheEntry, Path) | None

# Store a new entry
store_result(cache_dir, partial_key, file_hash, entry, max_bytes=0)

# Remove entries for a partial key
invalidate(cache_dir, partial_key)  # -> bool

# Clear entire cache
clear_cache(cache_dir)  # -> int (entries removed)
```

## `casher.store.CacheEntry`

```python
@dataclasses.dataclass
class CacheEntry:
    return_value: object
    stdout: str
    stderr: str
    output_files: dict[str, Path]
    input_files: dict[str, str]
    created_at: float
    func_module: str
    func_name: str
```

## `casher.strace`

```python
from casher.strace import run_with_strace, is_strace_available

available = is_strace_available()  # -> bool
result = run_with_strace(["python", "script.py"])
# result.read_files: list[Path]
# result.write_files: list[Path]
# result.stdout: str
# result.stderr: str
# result.returncode: int
```

## `casher.audit_hook`

```python
from casher.audit_hook import track_file_io

with track_file_io() as tracker:
    with open("data.txt") as f:
        f.read()
# tracker.read_files: set[Path]
# tracker.write_files: set[Path]
```

## `casher.eviction`

```python
from casher.eviction import evict_if_needed, get_cache_size

evicted = evict_if_needed(cache_dir, max_bytes)  # -> int
total = get_cache_size(cache_dir)  # -> int (bytes)
```
