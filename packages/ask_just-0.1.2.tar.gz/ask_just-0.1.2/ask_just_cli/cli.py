#!/usr/bin/env python3
import argparse
import getpass
import hashlib
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from ask_just_cli.agent_setup import DEFAULT_REFRESH_HOURS
from ask_just_cli.agent_setup import setup_agents
from ask_just_cli.agent_setup import skill_refresh_is_fresh


DEFAULT_URL = "https://ask-just.35.222.146.245.sslip.io"
CONFIG_PATH = os.path.expanduser("~/.config/ask-just/config.json")
DEFAULT_BRAINTRUST_ORG = "Andes"
DEFAULT_BRAINTRUST_PROJECT = "ask-just"
DEFAULT_BRAINTRUST_PROJECT_ID = "2a580ddb-dbad-4acd-a8b7-eacc2ab91123"
TRACE_FIELDS = {"trace_id", "trace_span_id", "trace_project", "trace_project_id", "trace_url", "trace_error"}
EXPECTED_CODEX_SKILLS = ("askjust", "just-source", "correction", "braintrust")
VERIFY_QUESTION = "Mar gross revenue"
VERIFY_SOURCE = "scorecard_monthly_data"


def emit(value):
    print(json.dumps(value, ensure_ascii=False, sort_keys=True))


def strip_trace_metadata(value):
    if isinstance(value, dict):
        return {
            key: strip_trace_metadata(child)
            for key, child in value.items()
            if key not in TRACE_FIELDS
        }
    if isinstance(value, list):
        return [strip_trace_metadata(item) for item in value]
    return value


def braintrust_trace_url(trace_id, project=DEFAULT_BRAINTRUST_PROJECT, project_id=DEFAULT_BRAINTRUST_PROJECT_ID, org=DEFAULT_BRAINTRUST_ORG):
    return (
        f"https://www.braintrust.dev/app/{urllib.parse.quote(org, safe='')}/p/{urllib.parse.quote(project, safe='')}/trace"
        f"?object_type=project_logs&object_id={urllib.parse.quote(project_id, safe='')}"
        f"&r={urllib.parse.quote(trace_id, safe='')}&s={urllib.parse.quote(trace_id, safe='')}"
    )


def load_config():
    if not os.path.exists(CONFIG_PATH):
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as handle:
        return json.load(handle)


def save_config(config):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    tmp_path = f"{CONFIG_PATH}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.chmod(tmp_path, 0o600)
    os.replace(tmp_path, CONFIG_PATH)
    os.chmod(CONFIG_PATH, 0o600)


def resolve_url(args, config):
    return (args.url or os.environ.get("ASK_JUST_URL") or config.get("url") or DEFAULT_URL).rstrip("/")


def resolve_token(args, config):
    return args.token or os.environ.get("ASK_JUST_TOKEN") or config.get("token")


def request_json(url, token=None, method="GET", payload=None):
    headers = {"Accept": "application/json"}
    data = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = {"ok": False, "error": raw}
        payload.setdefault("ok", False)
        payload["http_status"] = exc.code
        return payload
    except urllib.error.URLError as exc:
        return {"ok": False, "error": str(exc)}


def call(args, path, method="GET", payload=None):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    result = request_json(f"{url}{path}", token=token, method=method, payload=payload)
    if getattr(args, "open_trace", False) and result.get("trace_url"):
        webbrowser.open(result["trace_url"])
    if not getattr(args, "include_trace", False):
        result = strip_trace_metadata(result)
    emit(result)
    return 0 if result.get("ok", False) else 1


def configure(args):
    config = load_config()
    url = args.url or input(f"Ask Just URL [{config.get('url', DEFAULT_URL)}]: ").strip() or config.get("url") or DEFAULT_URL
    config["url"] = url.rstrip("/")
    if args.token:
        config["token"] = args.token
    elif args.prompt_token:
        token = getpass.getpass("Ask Just bearer token, blank for none: ").strip()
        if token:
            config["token"] = token
        else:
            config.pop("token", None)
    save_config(config)
    emit({"ok": True, "config_path": CONFIG_PATH, "url": config["url"], "has_token": bool(config.get("token"))})


def onboarding_code_create(args):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    payload = {
        "email": args.email,
        "label": args.label,
        "reusable": not bool(getattr(args, "single_use", False)),
    }
    if args.ttl_hours:
        payload["ttl_hours"] = args.ttl_hours
    result = request_json(
        f"{url}/onboarding-codes",
        token=token,
        method="POST",
        payload=payload,
    )
    emit(result)
    return 0 if result.get("ok", False) else 1


def onboarding_code_exchange(args):
    config = load_config()
    url = resolve_url(args, config)
    result = request_json(
        f"{url}/onboarding/exchange",
        token=None,
        method="POST",
        payload={"code": args.code},
    )
    token = result.get("token")
    if result.get("ok") and token and not args.no_configure:
        config["url"] = url
        config["token"] = token
        save_config(config)
        emit(
            {
                "ok": True,
                "configured": True,
                "config_path": CONFIG_PATH,
                "url": url,
                "email": result.get("email", ""),
                "label": result.get("label", ""),
                "expires_at": result.get("expires_at"),
            }
        )
        return 0
    if result.get("ok"):
        sanitized = {key: value for key, value in result.items() if key != "token"}
        sanitized["configured"] = False
        emit(sanitized)
        return 0
    emit(result)
    return 1


def check_record(name, ok, severity, message, **extra):
    record = {"name": name, "ok": bool(ok), "severity": severity, "message": message}
    record.update(extra)
    return record


def path_contains(directory):
    directory = os.path.abspath(os.path.expanduser(directory))
    return directory in {
        os.path.abspath(os.path.expanduser(entry))
        for entry in os.environ.get("PATH", "").split(os.pathsep)
        if entry
    }


def skill_path(codex_home, skill_name):
    return os.path.join(codex_home, "skills", skill_name, "SKILL.md")


def codex_config_path(codex_home):
    return os.path.join(codex_home, "config.toml")


def codex_skill_config_enabled(codex_home, skill_name):
    config_path = codex_config_path(codex_home)
    if not os.path.exists(config_path):
        return False, config_path
    expected_path = skill_path(codex_home, skill_name)
    expected_path_line = f"path = {json.dumps(expected_path)}"
    in_skill_config = False
    path_matches = False
    enabled = False
    with open(config_path, "r", encoding="utf-8") as handle:
        for raw_line in list(handle) + ["["]:
            line = raw_line.strip()
            if line.startswith("["):
                if in_skill_config and path_matches:
                    return enabled, config_path
                in_skill_config = line == "[[skills.config]]"
                path_matches = False
                enabled = False
                continue
            if not in_skill_config or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if key == "path" and line == expected_path_line:
                path_matches = True
            elif key == "enabled":
                enabled = value.lower() == "true"
    return False, config_path


def global_agents_path(codex_home):
    return os.path.join(codex_home, "AGENTS.md")


def global_agents_ask_just_rule_present(codex_home):
    path = global_agents_path(codex_home)
    if not os.path.exists(path):
        return False, path
    with open(path, "r", encoding="utf-8") as handle:
        text = handle.read()
    required_phrases = [
        "ASK_JUST_INSTALLER_BEGIN",
        "Ask Just is the default answer path",
        "Do not use web search",
        "without requiring the user to type a command or skill name",
    ]
    return all(phrase in text for phrase in required_phrases), path


def doctor(args):
    config = load_config()
    url = resolve_url(args, config)
    token = resolve_token(args, config)
    codex_home = os.environ.get("CODEX_HOME") or os.path.expanduser("~/.codex")
    expected_bin = os.environ.get("ASK_JUST_BIN") or os.path.expanduser("~/.local/bin/ask-just")
    expected_bin_dir = os.path.dirname(expected_bin)
    which_bin = shutil.which("ask-just")
    checks = []
    required_gaps = []

    def add_check(name, ok, severity, message, gap=None, **extra):
        checks.append(check_record(name, ok, severity, message, **extra))
        if not ok and severity == "required" and gap:
            required_gaps.append(gap)

    add_check(
        "config_file",
        os.path.exists(CONFIG_PATH),
        "required",
        "Ask Just config file exists.",
        gap="config_file_missing",
        config_path=CONFIG_PATH,
    )
    add_check(
        "token",
        bool(token),
        "required",
        "Ask Just token is configured. The token value is not printed.",
        gap="token_missing",
        has_token=bool(token),
    )
    add_check(
        "configured_url",
        bool(url),
        "required",
        "Ask Just URL is configured.",
        gap="url_missing",
        url=url,
        default_url=DEFAULT_URL,
    )
    add_check(
        "ask_just_binary",
        os.path.exists(expected_bin) and os.access(expected_bin, os.X_OK),
        "required",
        "ask-just binary exists and is executable at the installer target.",
        gap="ask_just_binary_missing",
        expected_path=expected_bin,
        discovered_path=which_bin,
    )
    add_check(
        "local_bin_on_path",
        path_contains(expected_bin_dir),
        "required",
        "The ask-just install directory is on PATH.",
        gap="local_bin_not_on_path",
        expected_directory=expected_bin_dir,
    )
    if which_bin:
        add_check(
            "which_ask_just",
            os.path.realpath(which_bin) == os.path.realpath(expected_bin),
            "required",
            "The ask-just command resolves to the installer target.",
            gap="ask_just_binary_shadowed",
            expected_path=expected_bin,
            discovered_path=which_bin,
        )
    else:
        add_check(
            "which_ask_just",
            False,
            "required",
            "The ask-just command is discoverable on PATH.",
            gap="ask_just_binary_not_discoverable",
            expected_path=expected_bin,
            discovered_path=None,
        )

    missing_skills = []
    installed_skills = []
    enabled_skills = []
    disabled_skills = []
    for skill_name in EXPECTED_CODEX_SKILLS:
        path = skill_path(codex_home, skill_name)
        if os.path.exists(path):
            installed_skills.append(skill_name)
            checks.append(
                check_record(
                    f"codex_skill:{skill_name}",
                    True,
                    "required",
                    f"Codex skill {skill_name} is installed.",
                    path=path,
                )
            )
            config_enabled, skill_config_path = codex_skill_config_enabled(codex_home, skill_name)
            if config_enabled:
                enabled_skills.append(skill_name)
                checks.append(
                    check_record(
                        f"codex_skill_config:{skill_name}",
                        True,
                        "required",
                        f"Codex skill {skill_name} is enabled in global skill config.",
                        path=path,
                        config_path=skill_config_path,
                    )
                )
            else:
                disabled_skills.append(skill_name)
                add_check(
                    f"codex_skill_config:{skill_name}",
                    False,
                    "required",
                    f"Codex skill {skill_name} is not enabled in global skill config.",
                    gap=f"codex_skill_disabled:{skill_name}",
                    path=path,
                    config_path=skill_config_path,
                )
        else:
            missing_skills.append(skill_name)
            add_check(
                f"codex_skill:{skill_name}",
                False,
                "required",
                f"Codex skill {skill_name} is missing.",
                gap=f"codex_skill_missing:{skill_name}",
                path=path,
            )

    agents_rule_present, agents_path = global_agents_ask_just_rule_present(codex_home)
    add_check(
        "global_agents_ask_just_rule",
        agents_rule_present,
        "required",
        "Global Codex AGENTS.md routes plain Just questions to Ask Just in new threads and all projects.",
        gap="global_agents_ask_just_rule_missing",
        path=agents_path,
    )

    ready = request_json(f"{url}/ready", token=token)
    add_check(
        "hosted_ready",
        bool(ready.get("ok")),
        "required",
        "Hosted Ask Just readiness endpoint returned ok.",
        gap="hosted_ready_failed",
        response={key: value for key, value in ready.items() if key != "trace_url"},
    )
    sources = request_json(f"{url}/sources", token=token)
    source_rows = sources.get("rows") if isinstance(sources.get("rows"), list) else []
    if sources.get("http_status") in {401, 403}:
        sources_gap = "hosted_sources_unauthorized"
        sources_message = "Hosted Ask Just rejected the configured token for the source inventory."
    elif sources.get("ok") and not source_rows:
        sources_gap = "hosted_sources_empty"
        sources_message = "Hosted Ask Just source inventory returned no rows."
    else:
        sources_gap = "hosted_sources_failed"
        sources_message = "Hosted Ask Just source inventory returned rows."
    add_check(
        "hosted_sources",
        bool(sources.get("ok")) and bool(source_rows),
        "required",
        sources_message,
        gap=sources_gap,
        http_status=sources.get("http_status"),
        error=sources.get("error"),
        source_count=len(source_rows),
    )

    payload = {
        "ok": not required_gaps,
        "status": "ready" if not required_gaps else "needs_attention",
        "configured_url": url,
        "config_path": CONFIG_PATH,
        "codex_home": codex_home,
        "expected_binary": expected_bin,
        "discovered_binary": which_bin,
        "installed_skills": installed_skills,
        "missing_skills": missing_skills,
        "enabled_skills": enabled_skills,
        "disabled_skills": disabled_skills,
        "hosted_sources": {"source_count": len(source_rows)},
        "required_gaps": required_gaps,
        "expected_private_differences": [
            "Josh's private mailbox overlays are not copied.",
            "Josh's local repo checkouts, wiki vaults, and machine memory are not copied.",
            "Outlook, Teams, SharePoint, Asana, GitHub, and browser auth are separate account-specific integrations.",
        ],
        "optional_integrations": [
            "Install account-specific connectors only when the role requires them and the account owner approves access.",
            "Open a new Codex thread after setup so newly installed Ask Just skills are loaded.",
        ],
        "checks": checks,
    }
    emit(payload)
    return 0 if payload["ok"] else 1


def setup_agent(args):
    if getattr(args, "if_stale", False):
        fresh, refresh_state = skill_refresh_is_fresh(
            max_age_hours=getattr(args, "max_age_hours", DEFAULT_REFRESH_HOURS)
        )
        if fresh:
            if not getattr(args, "quiet", False):
                emit(
                    {
                        "ok": True,
                        "status": "fresh",
                        "refresh_policy": "weekly",
                        "refresh_state": refresh_state,
                    }
                )
            return 0
    result = setup_agents(agents=tuple(args.agent))
    result["status"] = "refreshed" if result.get("ok") else "needs_attention"
    result["refresh_policy"] = "weekly"
    if not getattr(args, "quiet", False):
        emit(result)
    return 0 if result.get("ok") else 1


def prepend_path(directory):
    path_entries = [
        entry
        for entry in os.environ.get("PATH", "").split(os.pathsep)
        if entry and entry != directory
    ]
    os.environ["PATH"] = os.pathsep.join([directory, *path_entries])


def ensure_persistent_cli():
    expected_bin = os.environ.get("ASK_JUST_BIN") or os.path.expanduser("~/.local/bin/ask-just")
    expected_bin_dir = os.path.dirname(expected_bin)
    os.makedirs(expected_bin_dir, exist_ok=True)
    uv_bin = shutil.which("uv")
    tool_source = os.environ.get("ASK_JUST_TOOL_SOURCE", "ask-just")
    if uv_bin:
        command = [uv_bin, "tool", "install", "-U"]
        if tool_source == "ask-just":
            command.append("ask-just")
        else:
            command.extend(["--from", tool_source, "ask-just"])
        result = subprocess.run(command, text=True, capture_output=True, check=False)
        if result.returncode == 0:
            prepend_path(expected_bin_dir)
            return expected_bin
    with open(expected_bin, "w", encoding="utf-8") as handle:
        handle.write("#!/usr/bin/env sh\n")
        handle.write(f"exec {shlex_quote(sys.executable)} -m ask_just_cli.cli \"$@\"\n")
    os.chmod(expected_bin, 0o755)
    prepend_path(expected_bin_dir)
    return expected_bin


def shlex_quote(value):
    return "'" + str(value).replace("'", "'\"'\"'") + "'"


def source_id_from_query(result):
    if not isinstance(result, dict):
        return ""
    for key in ("source_id", "source"):
        if result.get(key):
            return str(result[key])
    rows = result.get("rows")
    if isinstance(rows, list) and rows:
        first = rows[0]
        if isinstance(first, dict):
            return str(first.get("source_id") or first.get("source") or "")
    return ""


def verification_query(args):
    return request_json(
        f"{resolve_url(args, load_config())}/query",
        token=resolve_token(args, load_config()),
        method="POST",
        payload={
            "question": VERIFY_QUESTION,
            "source": VERIFY_SOURCE,
            "kind": "atomic",
            "limit": 3,
            "include_health": False,
            "deep_health": False,
            "trace": False,
        },
    )


def login(args):
    if args.reset and os.path.exists(CONFIG_PATH):
        os.remove(CONFIG_PATH)
    exchange_args = argparse.Namespace(
        code=args.setup_code,
        no_configure=False,
        url=args.url,
        token=None,
        open_trace=False,
        include_trace=False,
    )
    exchange_code = onboarding_code_exchange(exchange_args)
    agent_result = setup_agents(agents=tuple(args.agent))
    doctor_code = doctor(args) if args.doctor else 0
    query_result = verification_query(args) if args.verify else {"ok": True}
    source_id = source_id_from_query(query_result) if args.verify else ""
    ok = (
        exchange_code == 0
        and bool(agent_result.get("ok"))
        and doctor_code == 0
        and bool(query_result.get("ok"))
        and (not args.verify or bool(source_id))
    )
    emit(
        {
            "ok": bool(ok),
            "status": "ready" if ok else "needs_attention",
            "company": "Just",
            "login": "configured" if exchange_code == 0 else "failed",
            "agents": agent_result,
            "doctor_passed": doctor_code == 0 if args.doctor else None,
            "verify_question": VERIFY_QUESTION if args.verify else None,
            "query_passed": bool(query_result.get("ok")) if args.verify else None,
            "source_id": source_id,
        }
    )
    return 0 if ok else 1


def setup(args):
    if args.reset and os.path.exists(CONFIG_PATH):
        os.remove(CONFIG_PATH)
    persistent_bin = ensure_persistent_cli()
    exchange_args = argparse.Namespace(
        code=args.code,
        no_configure=False,
        url=args.url,
        token=None,
        open_trace=False,
        include_trace=False,
    )
    exchange_code = onboarding_code_exchange(exchange_args)
    agent_result = setup_agents(agents=tuple(args.agent))
    doctor_code = doctor(args)
    query_result = verification_query(args)
    source_id = source_id_from_query(query_result)
    ok = (
        exchange_code == 0
        and bool(agent_result.get("ok"))
        and doctor_code == 0
        and bool(query_result.get("ok"))
        and bool(source_id)
    )
    emit(
        {
            "ok": bool(ok),
            "status": "ready" if ok else "needs_attention",
            "company": "Just",
            "persistent_binary": persistent_bin,
            "setup_code": "accepted" if exchange_code == 0 else "failed",
            "agents": agent_result,
            "doctor_passed": doctor_code == 0,
            "verify_question": VERIFY_QUESTION,
            "query_passed": bool(query_result.get("ok")),
            "source_id": source_id,
        }
    )
    return 0 if ok else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description="CLI for the Ask Just source service.")
    parser.add_argument("--url", help=f"Ask Just endpoint. Default: {DEFAULT_URL}")
    parser.add_argument("--token", help="Bearer token. Local hosting does not require one by default.")
    parser.add_argument("--open-trace", action="store_true", help="Open the Braintrust trace URL returned by a traced query.")
    parser.add_argument("--include-trace", action="store_true", help="Include Braintrust trace metadata in JSON output.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    setup_parser = subparsers.add_parser("setup", help="One-command Ask Just teammate setup.")
    setup_parser.add_argument("--code", required=True, help="Stable Ask Just setup code.")
    setup_parser.add_argument("--reset", action="store_true", help="Refresh CLI-owned local config before setup.")
    setup_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])

    login_parser = subparsers.add_parser("login", help="Exchange a stable Ask Just setup code and refresh agent guidance.")
    login_parser.add_argument("--setup-code", required=True, help="Stable Ask Just setup code.")
    login_parser.add_argument("--reset", action="store_true", help="Refresh CLI-owned local config before login.")
    login_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])
    login_parser.add_argument("--doctor", action="store_true", help="Run doctor after login.")
    login_parser.add_argument("--verify", action="store_true", help="Run the canonical verification query after login.")

    configure_parser = subparsers.add_parser("configure", help="Save endpoint and optional token to local user config.")
    configure_parser.add_argument("--url", default=None)
    configure_parser.add_argument("--token", default=None)
    configure_parser.add_argument("--prompt-token", action="store_true")

    health = subparsers.add_parser("health")
    health.add_argument("--deep", action="store_true")

    subparsers.add_parser("doctor", help="Check local Ask Just install parity without printing secrets.")

    setup_agent_parser = subparsers.add_parser("setup-agent", help="Install or refresh Ask Just agent harness guidance.")
    setup_agent_parser.add_argument("--agent", action="append", choices=("codex", "claude"), default=["codex", "claude"])
    setup_agent_parser.add_argument("--quiet", action="store_true", help="Suppress output for invisible agent-start refreshes.")
    setup_agent_parser.add_argument("--if-stale", action="store_true", help="Refresh only when the local skill bundle is older than the refresh window.")
    setup_agent_parser.add_argument("--max-age-hours", type=float, default=DEFAULT_REFRESH_HOURS, help="Skill refresh window in hours. Default: one week.")

    subparsers.add_parser("summary")
    subparsers.add_parser("sources")

    onboarding_code = subparsers.add_parser("onboarding-code", help="Create, rotate, or exchange Ask Just setup codes.")
    onboarding_subparsers = onboarding_code.add_subparsers(dest="onboarding_code_command", required=True)
    onboarding_create = onboarding_subparsers.add_parser("create", help="Create or rotate a stable setup code for a teammate group.")
    onboarding_create.add_argument("--email", default="")
    onboarding_create.add_argument("--label", default="")
    onboarding_create.add_argument("--ttl-hours", type=float, default=None)
    onboarding_create.add_argument("--single-use", action="store_true", help="Create an expiring one-time code instead of the stable default.")
    onboarding_exchange = onboarding_subparsers.add_parser("exchange", help="Exchange a setup code for local Ask Just configuration.")
    onboarding_exchange.add_argument("code")
    onboarding_exchange.add_argument("--no-configure", action="store_true", help="Do not save the returned token to local config.")

    token_hash = subparsers.add_parser("token-hash", help="Print the SHA-256 hash for the configured or provided Ask Just bearer token.")
    token_hash.add_argument("--prompt-token", action="store_true", help="Prompt for a token instead of reading saved config/env.")

    trace_url_parser = subparsers.add_parser("trace-url", help="Render the Braintrust full trace URL for an Ask Just trace id.")
    trace_url_parser.add_argument("trace_id")
    trace_url_parser.add_argument("--org", default=DEFAULT_BRAINTRUST_ORG)
    trace_url_parser.add_argument("--project", default=DEFAULT_BRAINTRUST_PROJECT)
    trace_url_parser.add_argument("--project-id", default=DEFAULT_BRAINTRUST_PROJECT_ID)

    search = subparsers.add_parser("search", help="Raw keyword diagnostic search. Use query for normal questions.")
    search.add_argument("query")
    search.add_argument("--source", default="all")
    search.add_argument("--kind", choices=["all", "units", "chunks", "atomic", "receipts"], default="all")
    search.add_argument("--limit", type=int, default=20)
    search.add_argument("--with-health", action="store_true")
    search.add_argument("--deep-health", action="store_true")

    query = subparsers.add_parser("query", help="Ask a natural-language business question through Ask Just routing.")
    query.add_argument("question")
    query.add_argument("--source", default="all")
    query.add_argument("--kind", choices=["all", "units", "chunks", "atomic", "receipts"], default="all")
    query.add_argument("--limit", type=int, default=20)
    query.add_argument("--with-health", action="store_true")
    query.add_argument("--deep-health", action="store_true")

    sql = subparsers.add_parser("sql")
    sql.add_argument("sql")
    sql.add_argument("--question", default="", help="Plain-language user question to preserve in Braintrust trace metadata.")
    sql.add_argument("--limit", type=int, default=20)
    sql.add_argument("--with-health", action="store_true")
    sql.add_argument("--deep-health", action="store_true")

    kpi = subparsers.add_parser("kpi", help="Fetch the latest Scorecard monthly KPI through the fast SQLite path.")
    kpi.add_argument("metric", help="Scorecard monthly metric key, e.g. gross_margin or gross_revenue.")
    kpi.add_argument("--with-health", action="store_true")
    kpi.add_argument("--deep-health", action="store_true")

    ops_kpi = subparsers.add_parser("ops-kpi", help="Fetch a Scorecard ops metric through the fast SQLite path.")
    ops_kpi.add_argument("metric", help="Scorecard ops metric name, e.g. 'Protein on Hold (MT)'.")
    ops_kpi.add_argument("field", help="Scorecard ops field key, e.g. mar.")
    ops_kpi.add_argument("--group", default="", help="Optional Scorecard ops group name to disambiguate.")
    ops_kpi.add_argument("--with-health", action="store_true")
    ops_kpi.add_argument("--deep-health", action="store_true")

    cash_flow = subparsers.add_parser(
        "finance-cash-flow",
        help="Fetch a typed 2026 cash-flow forecast metric through the fast SQLite path.",
    )
    cash_flow.add_argument("metric_key", help="Metric key, e.g. net_cash_flow, cash_outflow, payment_list_proof, bank_accounts_total.")
    cash_flow.add_argument("--period-end", default="", help="Period end date, e.g. 2026-04-30 or 2026-05-01.")
    cash_flow.add_argument("--period-type", default="", help="Optional period type: week or month_total.")
    cash_flow.add_argument("--account-name", default="", help="Optional exact bank account name for bank account rows.")
    cash_flow.add_argument("--limit", type=int, default=20)
    cash_flow.add_argument("--with-health", action="store_true")
    cash_flow.add_argument("--deep-health", action="store_true")

    spins_ranking = subparsers.add_parser(
        "spins-ranking",
        help="Rank SPINS Item Ranking rows, failing closed when required Just SKU rows are missing.",
    )
    spins_ranking.add_argument("--source-id", default="spins_breakfast_powertabs")
    spins_ranking.add_argument("--geography", default="TOTAL US - MULO")
    spins_ranking.add_argument("--channel", default="MULO")
    spins_ranking.add_argument("--time-period", default="4 Weeks")
    spins_ranking.add_argument("--category", default="")
    spins_ranking.add_argument("--subcategory", default="")
    spins_ranking.add_argument("--product-type", default="")
    spins_ranking.add_argument(
        "--order-by",
        choices=["dollars", "units", "unit_velocity", "dollar_velocity"],
        default="dollars",
    )
    spins_ranking.add_argument(
        "--required-product-keys",
        default="",
        help="Comma-separated Just SKU product keys that must be present for this slice.",
    )
    spins_ranking.add_argument(
        "--required-metrics",
        default="",
        help="Comma-separated metric fields required for the requested answer; defaults from --order-by.",
    )
    spins_ranking.add_argument("--limit", type=int, default=20)
    spins_ranking.add_argument("--with-health", action="store_true")
    spins_ranking.add_argument("--deep-health", action="store_true")

    spins_velocity = subparsers.add_parser(
        "spins-velocity",
        help="Fetch exact SPINS unit velocity for one SKU x geography x channel x time period.",
    )
    spins_velocity.add_argument("--source-id", default="spins_breakfast_powertabs")
    spins_velocity.add_argument("--geography", required=True)
    spins_velocity.add_argument("--channel", default="MULO")
    spins_velocity.add_argument("--time-period", default="4 Weeks")
    spins_velocity.add_argument("--category", default="")
    spins_velocity.add_argument("--subcategory", default="")
    spins_velocity.add_argument("--product-type", default="")
    spins_velocity.add_argument("--product-key", default="")
    spins_velocity.add_argument("--upc", default="")
    spins_velocity.add_argument("--description", default="")
    spins_velocity.add_argument("--with-health", action="store_true")
    spins_velocity.add_argument("--deep-health", action="store_true")

    whole_foods_us_velocity = subparsers.add_parser(
        "whole-foods-us-velocity",
        help="Fetch exact Whole Foods US WHO-cube velocity rows for an item x period x region slice.",
    )
    whole_foods_us_velocity.add_argument("--source-id", default="whole_foods_us_who_cube_2026_04_19")
    whole_foods_us_velocity.add_argument("--period", default="Last 04 Weeks")
    whole_foods_us_velocity.add_argument("--region", default="")
    whole_foods_us_velocity.add_argument("--item", default="")
    whole_foods_us_velocity.add_argument("--upc", default="")
    whole_foods_us_velocity.add_argument("--segment", default="")
    whole_foods_us_velocity.add_argument("--limit", type=int, default=20)
    whole_foods_us_velocity.add_argument("--with-health", action="store_true")
    whole_foods_us_velocity.add_argument("--deep-health", action="store_true")

    whole_foods_us_store_sales = subparsers.add_parser(
        "whole-foods-us-store-sales",
        help="Fetch Whole Foods US WHO-cube store sales rows, optionally filtered to an item or segment.",
    )
    whole_foods_us_store_sales.add_argument("--source-id", default="whole_foods_us_who_cube_2026_04_19")
    whole_foods_us_store_sales.add_argument("--period", default="Latest 12 Weeks")
    whole_foods_us_store_sales.add_argument("--store", default="")
    whole_foods_us_store_sales.add_argument("--region-code", default="")
    whole_foods_us_store_sales.add_argument("--item", default="")
    whole_foods_us_store_sales.add_argument("--upc", default="")
    whole_foods_us_store_sales.add_argument("--segment", default="")
    whole_foods_us_store_sales.add_argument("--order-by", choices=["dollars", "units"], default="dollars")
    whole_foods_us_store_sales.add_argument("--limit", type=int, default=20)
    whole_foods_us_store_sales.add_argument("--with-health", action="store_true")
    whole_foods_us_store_sales.add_argument("--deep-health", action="store_true")

    whole_foods_canada_velocity = subparsers.add_parser(
        "whole-foods-canada-velocity",
        help="Fetch Whole Foods Canada RL UPSW unit and dollar velocity rows.",
    )
    whole_foods_canada_velocity.add_argument("--source-id", default="whole_foods_canada_just_egg_rl_upsw")
    whole_foods_canada_velocity.add_argument("--product-key", choices=["", "liquid", "folded"], default="")
    whole_foods_canada_velocity.add_argument("--item", default="")
    whole_foods_canada_velocity.add_argument("--store", default="")
    whole_foods_canada_velocity.add_argument("--province", default="")
    whole_foods_canada_velocity.add_argument("--limit", type=int, default=20)
    whole_foods_canada_velocity.add_argument("--with-health", action="store_true")
    whole_foods_canada_velocity.add_argument("--deep-health", action="store_true")

    whole_foods_canada_store_sales = subparsers.add_parser(
        "whole-foods-canada-store-sales",
        help="Fetch Whole Foods Canada RL UPSW store sales rows, optionally filtered to liquid or folded.",
    )
    whole_foods_canada_store_sales.add_argument("--source-id", default="whole_foods_canada_just_egg_rl_upsw")
    whole_foods_canada_store_sales.add_argument("--product-key", choices=["", "liquid", "folded"], default="")
    whole_foods_canada_store_sales.add_argument("--item", default="")
    whole_foods_canada_store_sales.add_argument("--store", default="")
    whole_foods_canada_store_sales.add_argument("--province", default="")
    whole_foods_canada_store_sales.add_argument(
        "--order-by", choices=["dollars", "units", "unit_velocity", "dollar_velocity"], default="dollars"
    )
    whole_foods_canada_store_sales.add_argument("--limit", type=int, default=20)
    whole_foods_canada_store_sales.add_argument("--with-health", action="store_true")
    whole_foods_canada_store_sales.add_argument("--deep-health", action="store_true")

    links = subparsers.add_parser("source-links", help="Resolve SQLite provenance to upstream source artifact links.")
    links.add_argument("--provenance-grain", default="", help="JSON provenance_grain from a SQLite answer row.")
    links.add_argument("--source-id", default=None, help="Source id to resolve when passing a locator directly.")
    links.add_argument("--locator", default=None, help="Provenance locator to resolve.")
    links.add_argument("--with-health", action="store_true")
    links.add_argument("--deep-health", action="store_true")

    subparsers.add_parser(
        "personal-mail-status",
        help="Check whether the current Ask Just token has a personal mailbox overlay.",
    )

    personal_mail_search = subparsers.add_parser(
        "personal-mail-search",
        help="Search the personal Microsoft Graph mailbox mapped to the current Ask Just token.",
    )
    personal_mail_search.add_argument("query", nargs="?", default="")
    personal_mail_search.add_argument("--limit", type=int, default=10)
    personal_mail_search.add_argument("--days", type=int, default=30)
    personal_mail_search.add_argument("--max-scan", type=int, default=250)

    personal_mail_read = subparsers.add_parser(
        "personal-mail-read",
        help="Read a full personal mailbox message by Microsoft Graph message id.",
    )
    personal_mail_read.add_argument("message_id")

    personal_mail_draft = subparsers.add_parser(
        "personal-mail-draft",
        help="Create a new draft in the personal mailbox mapped to the current token.",
    )
    personal_mail_draft.add_argument("--to", required=True, help="Comma-separated recipient email addresses.")
    personal_mail_draft.add_argument("--cc", default="", help="Comma-separated cc email addresses.")
    personal_mail_draft.add_argument("--bcc", default="", help="Comma-separated bcc email addresses.")
    personal_mail_draft.add_argument("--subject", required=True)
    personal_mail_draft.add_argument("--body", required=True)
    personal_mail_draft.add_argument("--content-type", choices=["Text", "HTML"], default="Text")

    personal_mail_reply_draft = subparsers.add_parser(
        "personal-mail-reply-draft",
        help="Create a reply draft for a personal mailbox message.",
    )
    personal_mail_reply_draft.add_argument("message_id")
    personal_mail_reply_draft.add_argument("--body", required=True)
    personal_mail_reply_draft.add_argument("--reply-all", action="store_true")
    personal_mail_reply_draft.add_argument("--content-type", choices=["Text", "HTML"], default="Text")

    personal_mail_send_draft = subparsers.add_parser(
        "personal-mail-send-draft",
        help="Send an existing personal mailbox draft. This is an explicit send action.",
    )
    personal_mail_send_draft.add_argument("message_id")

    actions = subparsers.add_parser("actions", help="Run approval-gated Ask Just actions.")
    action_subparsers = actions.add_subparsers(dest="action_name", required=True)
    order_allocation = action_subparsers.add_parser("order-allocation", help="Prepare and process order allocation runs.")
    order_allocation_subparsers = order_allocation.add_subparsers(dest="action_command", required=True)

    order_allocation_prepare = order_allocation_subparsers.add_parser(
        "prepare",
        help="Prepare the order allocation draft if all source families are fresh.",
    )
    order_allocation_prepare.add_argument("--run-date", default="", help="Pacific run date in YYYY-MM-DD form.")

    order_allocation_rehearse = order_allocation_subparsers.add_parser(
        "rehearse",
        help="Run a no-commit practice pass through the order allocation source gate.",
    )
    order_allocation_rehearse.add_argument("--run-date", default="", help="Pacific run date in YYYY-MM-DD form.")

    order_allocation_process = order_allocation_subparsers.add_parser(
        "process-approved",
        help="Process approved order allocation artifacts.",
    )
    order_allocation_process.add_argument("--run-date", default="", help="Pacific run date in YYYY-MM-DD form.")

    order_allocation_status = order_allocation_subparsers.add_parser("status", help="Inspect an order allocation run.")
    order_allocation_status.add_argument("run_id")

    order_allocation_receipts = order_allocation_subparsers.add_parser("receipts", help="Inspect order allocation run receipts.")
    order_allocation_receipts.add_argument("run_id")

    args = parser.parse_args(argv)
    if args.command == "setup":
        return setup(args)
    if args.command == "login":
        return login(args)
    if args.command == "configure":
        configure(args)
        return
    if args.command == "health":
        if args.deep:
            raise SystemExit(call(args, "/health?deep=1"))
        raise SystemExit(call(args, "/ready"))
    if args.command == "doctor":
        raise SystemExit(doctor(args))
    if args.command == "setup-agent":
        raise SystemExit(setup_agent(args))
    if args.command == "summary":
        raise SystemExit(call(args, "/summary"))
    if args.command == "sources":
        raise SystemExit(call(args, "/sources"))
    if args.command == "onboarding-code":
        if args.onboarding_code_command == "create":
            raise SystemExit(onboarding_code_create(args))
        if args.onboarding_code_command == "exchange":
            raise SystemExit(onboarding_code_exchange(args))
    if args.command == "token-hash":
        if args.prompt_token:
            token = getpass.getpass("Ask Just bearer token: ").strip()
        else:
            token = resolve_token(args, load_config())
        if not token:
            emit({"ok": False, "error": "no Ask Just token found in --token, ASK_JUST_TOKEN, or config"})
            raise SystemExit(1)
        emit({"ok": True, "token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest()})
        return
    if args.command == "trace-url":
        emit(
            {
                "ok": True,
                "trace_id": args.trace_id,
                "trace_project": args.project,
                "trace_project_id": args.project_id,
                "trace_url": braintrust_trace_url(args.trace_id, project=args.project, project_id=args.project_id, org=args.org),
            }
        )
        return
    if args.command == "search":
        qs = urllib.parse.urlencode(
            {
                "q": args.query,
                "source": args.source,
                "kind": args.kind,
                "limit": args.limit,
                "include_health": int(args.with_health),
                "deep_health": int(args.deep_health),
                "trace": int(args.include_trace or args.open_trace),
            }
        )
        raise SystemExit(call(args, f"/search?{qs}"))
    if args.command == "query":
        raise SystemExit(
            call(
                args,
                "/query",
                method="POST",
                payload={
                    "question": args.question,
                    "source": args.source,
                    "kind": args.kind,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "sql":
        raise SystemExit(
            call(
                args,
                "/sql",
                method="POST",
                payload={
                    "sql": args.sql,
                    "question": args.question,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "kpi":
        raise SystemExit(
            call(
                args,
                "/kpi",
                method="POST",
                payload={"metric": args.metric, "include_health": args.with_health, "deep_health": args.deep_health},
            )
        )
    if args.command == "ops-kpi":
        raise SystemExit(
            call(
                args,
                "/ops-kpi",
                method="POST",
                payload={
                    "metric": args.metric,
                    "field": args.field,
                    "group": args.group,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                },
            )
        )
    if args.command == "finance-cash-flow":
        raise SystemExit(
            call(
                args,
                "/finance-cash-flow",
                method="POST",
                payload={
                    "metric_key": args.metric_key,
                    "period_end": args.period_end,
                    "period_type": args.period_type,
                    "account_name": args.account_name,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "spins-ranking":
        raise SystemExit(
            call(
                args,
                "/spins-ranking",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "geography": args.geography,
                    "channel": args.channel,
                    "time_period": args.time_period,
                    "category": args.category,
                    "subcategory": args.subcategory,
                    "product_type": args.product_type,
                    "order_by": args.order_by,
                    "required_product_keys": args.required_product_keys,
                    "required_metrics": args.required_metrics,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "spins-velocity":
        raise SystemExit(
            call(
                args,
                "/spins-velocity",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "geography": args.geography,
                    "channel": args.channel,
                    "time_period": args.time_period,
                    "category": args.category,
                    "subcategory": args.subcategory,
                    "product_type": args.product_type,
                    "product_key": args.product_key,
                    "upc": args.upc,
                    "description": args.description,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "whole-foods-us-velocity":
        raise SystemExit(
            call(
                args,
                "/whole-foods-us-velocity",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "period": args.period,
                    "region": args.region,
                    "item": args.item,
                    "upc": args.upc,
                    "segment": args.segment,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "whole-foods-us-store-sales":
        raise SystemExit(
            call(
                args,
                "/whole-foods-us-store-sales",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "period": args.period,
                    "store": args.store,
                    "region_code": args.region_code,
                    "item": args.item,
                    "upc": args.upc,
                    "segment": args.segment,
                    "order_by": args.order_by,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "whole-foods-canada-velocity":
        raise SystemExit(
            call(
                args,
                "/whole-foods-canada-velocity",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "product_key": args.product_key,
                    "item": args.item,
                    "store": args.store,
                    "province": args.province,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "whole-foods-canada-store-sales":
        raise SystemExit(
            call(
                args,
                "/whole-foods-canada-store-sales",
                method="POST",
                payload={
                    "source_id": args.source_id,
                    "product_key": args.product_key,
                    "item": args.item,
                    "store": args.store,
                    "province": args.province,
                    "order_by": args.order_by,
                    "limit": args.limit,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                    "trace": args.include_trace or args.open_trace,
                },
            )
        )
    if args.command == "source-links":
        raise SystemExit(
            call(
                args,
                "/source-links",
                method="POST",
                payload={
                    "provenance_grain": args.provenance_grain,
                    "source_id": args.source_id,
                    "locator": args.locator,
                    "include_health": args.with_health,
                    "deep_health": args.deep_health,
                },
            )
        )
    if args.command == "personal-mail-status":
        raise SystemExit(call(args, "/personal-mail/status"))
    if args.command == "personal-mail-search":
        raise SystemExit(
            call(
                args,
                "/personal-mail/search",
                method="POST",
                payload={
                    "query": args.query,
                    "limit": args.limit,
                    "days": args.days,
                    "max_scan": args.max_scan,
                },
            )
        )
    if args.command == "personal-mail-read":
        raise SystemExit(
            call(
                args,
                "/personal-mail/read",
                method="POST",
                payload={"message_id": args.message_id},
            )
        )
    if args.command == "personal-mail-draft":
        raise SystemExit(
            call(
                args,
                "/personal-mail/draft",
                method="POST",
                payload={
                    "to": args.to,
                    "cc": args.cc,
                    "bcc": args.bcc,
                    "subject": args.subject,
                    "body": args.body,
                    "content_type": args.content_type,
                },
            )
        )
    if args.command == "personal-mail-reply-draft":
        raise SystemExit(
            call(
                args,
                "/personal-mail/reply-draft",
                method="POST",
                payload={
                    "message_id": args.message_id,
                    "body": args.body,
                    "reply_all": args.reply_all,
                    "content_type": args.content_type,
                },
            )
        )
    if args.command == "personal-mail-send-draft":
        raise SystemExit(
            call(
                args,
                "/personal-mail/send-draft",
                method="POST",
                payload={"message_id": args.message_id},
            )
        )
    if args.command == "actions":
        if args.action_name == "order-allocation":
            if args.action_command == "prepare":
                raise SystemExit(
                    call(
                        args,
                        "/actions/order-allocation/prepare",
                        method="POST",
                        payload={"run_date": args.run_date},
                    )
                )
            if args.action_command == "process-approved":
                raise SystemExit(
                    call(
                        args,
                        "/actions/order-allocation/process-approved",
                        method="POST",
                        payload={"run_date": args.run_date},
                    )
                )
            if args.action_command == "rehearse":
                raise SystemExit(
                    call(
                        args,
                        "/actions/order-allocation/rehearse",
                        method="POST",
                        payload={"run_date": args.run_date},
                    )
                )
            if args.action_command == "status":
                qs = urllib.parse.urlencode({"run_id": args.run_id})
                raise SystemExit(call(args, f"/actions/order-allocation/status?{qs}"))
            if args.action_command == "receipts":
                qs = urllib.parse.urlencode({"run_id": args.run_id})
                raise SystemExit(call(args, f"/actions/order-allocation/receipts?{qs}"))


if __name__ == "__main__":
    main()
