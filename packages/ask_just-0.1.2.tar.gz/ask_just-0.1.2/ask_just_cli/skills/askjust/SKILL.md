---
name: askjust
description: Ask Just's hosted source plane and answer from source-grade Just evidence. Use when the user invokes `askjust`, `/askjust`, `$askjust`, asks a Just source/company-memory question, or explicitly asks to force the Ask Just path.
---

# Ask Just

Use this skill as the deterministic Codex front door for Just source questions.

## Contract

- `$askjust` means "ask Just what it knows from verified source-grade artifacts."
- The user should not need to know which artifact, database, table, source id, or CLI flag to use. Routing is the agent's job.
- Hide retrieval mechanics by default. Ask Just should feel like a business
  answer surface, not a debugging console.
- Do not narrate tool exploration, endpoint selection, SQL fallback, schema
  inspection, CLI discovery, `pragma`, `sqlite_master`, table names, workbook
  internals, source-file probing, or "falling back" language unless the user
  explicitly asks how the answer was obtained or asks to debug Ask Just.
- Use Ask Just quietly. For normal business questions, run the needed hosted
  retrieval internally, then answer the question directly. If the answer takes
  longer than expected, use at most one short status line, such as "I am
  checking Ask Just for the source-backed answer."
- Lead with the business answer. Put compact provenance after the answer. Do
  not expose raw JSON, SQL, tables, schemas, CLI flags, trace metadata, or
  source-plane plumbing in the final response unless requested.
- If a typed helper or first route fails, recover silently through the hosted
  Ask Just source plane when another hosted path can answer. If no hosted path
  can answer, state a source gap in business terms. Do not give the user a
  visible debugging tour.
- Treat user wording as intent, not as a literal source id, workbook name, app
  name, table name, field name, column label, artifact path, or internal
  taxonomy. When literal terms miss or look weak, run the verified-index
  source-resolution loop: identify the likely fact type, search nearby indexed
  source lanes/tables/files/fields that could hold that fact type, inspect
  representative atomic rows or schemas, prove the mapping from VM SQLite rows
  with `provenance_grain`, then state the mapping explicitly. This applies
  across Ask Just: Scorecard, NetSuite, SPINS, SharePoint workbooks, Asana,
  product/spec/formulation lanes, app/repo lanes, source links, and future
  verified lanes. This is not embedding-router behavior; it is source-index
  resolution.
- All Just source questions go through the hosted Ask Just source service by default. The shared service runs on the Ask Just VM behind public HTTPS and bearer-token auth; local development can run the same service directly.
- If a question is explicitly about the current user's own email, use the personal source overlay when available: `ask-just personal-mail-status`, `ask-just personal-mail-search "terms"`, and `ask-just personal-mail-read MESSAGE_ID`. For writing, create drafts with `ask-just personal-mail-draft` or `ask-just personal-mail-reply-draft`; only send with the explicit `ask-just personal-mail-send-draft DRAFT_MESSAGE_ID` command. Personal mailbox rows are live delegated Graph results scoped to the token owner and are not part of the shared SQLite source plane.
- Ordinary Ask Just answers should not query raw Just artifacts directly unless an explicit exception was made. Raw artifacts are upstream evidence; the answer surface is `ask-just` calling the hosted API, which reads the verified SQLite3 source index on the Ask Just VM at `/home/josh/ask-just/artifacts/ask-just-fresh-source-plane/source_index.sqlite`.
- Do not answer Just source questions from general model knowledge, memory summaries, screenshots, local notes outside this source plane, or any other project browsing as a substitute.
- Treat the VM SQLite3 `source_index.sqlite` as the source of record behind the
  hosted API, not as an agent-facing answer fallback. Use local SQLite only for
  development/rebuild verification, never to answer a normal Ask Just question.
- If the hosted `ask-just` API times out, returns 5xx, or is too slow, do not
  answer by SSHing into the VM, opening SQLite directly, using a localhost
  tunnel, querying local SQLite, browsing raw files, or switching source
  surfaces. Report that the hosted Ask Just API is unhealthy and fix the API
  path. SSH is allowed for service repair, deploy, logs, and readiness checks,
  but not as a user-answer path.
- Be precise about answer-path language. For normal answers, say "queried",
  "selected", "filtered", or "returned from the Ask Just source plane / VM
  SQLite" when describing the work. Do not say "extracted", "parsed",
  "ingested", "rebuilt", or imply raw workbook/API/file access unless a rebuild
  or source parser actually ran in that turn.
- Product facts, nutritionals, ingredients, formula, label, spec-sheet, and
  product-brochure questions must route to the hosted GCP VM SQLite source
  index. Do not route by keyword alone. First classify the user's semantic
  intent, then resolve the named source boundary, then choose the source role.
  A named declared source boundary beats a generic fact type. For example,
  `V6`, `liquid egg`, `JEL6`, or `v6 2026.xlsx` formulation-development
  questions route first to `rd_liquid_egg_v6` for R&D workbook trials, sample
  formulas, dated test sheets, comments, and observations. `Power Jacks`
  formulation questions route first to `rd_powerjacks_formulations`.
  pH questions are quality / release evidence questions, not ENTR formula
  questions. Route product pH, acidity, and similar quality-attribute questions
  first to `batch_release_app`. Use `qualification_*` lanes and source files
  whose path contains `qualification` or `qualfication` as backup sources.
  Never treat `replace_enter_repo_github` / ENTR as the pH authority unless the
  user explicitly asks what ENTR itself says, and label that answer as ENTR
  metadata rather than quality-release truth.
  Replace Enter is the source role for formula catalog/app records, ingredient
  statements, label/nutrition/proof/supplier records, current live ENTR
  formula rows, and questions that explicitly ask for approved/in-review/draft
  formula records or formula ids. Satellite is the current spec-sheet /
  product-brochure lane. If the role is ambiguous and the named boundary plus
  catalog role are both plausible, query both hosted lanes and state the
  distinction instead of silently picking one.
- Prefer exact structured rows from the selected source role over general FTS.
  If the selected hosted lanes do not contain the requested product fact in VM
  SQLite, report a source gap instead of answering from public `ju.st` pages,
  memory, screenshots, or raw local artifacts.
- Keep the phases separate: source ingestion turns upstream artifacts into
  SQLite rows; querying asks the hosted API for rows; answer shaping formats
  returned rows for the user. Do not blur those phases in user-facing
  language.
- There is no old answer plane in the Ask Just repo. Do not say "older memory", "remembered number", or similar in answers; query the active lane or say the active lane does not contain the fact.
- Treat Scorecard as the canonical business KPI source whenever a user question can be answered from `scorecard_monthly_data` or `scorecard_ops_metrics`.
- Use NetSuite finance lanes for ledger/accounting/P&L detail, AR, AP, inventory, or when the user explicitly asks for NetSuite. If both Scorecard and NetSuite have related values, lead with the Scorecard answer and explain any NetSuite comparison as supporting or reconciliation detail, not the canonical KPI.
- Do not volunteer alternate NetSuite values after a canonical Scorecard answer unless the user asked for NetSuite, accounting, P&L, or reconciliation. A plain KPI answer should be short: answer, source line, stop.
- Do not mention NetSuite at all in preambles, status text, answer caveats, or follow-up framing for plain Scorecard KPI questions such as revenue or margin. Say only that you are checking the Scorecard monthly KPI lane.
- For Just Egg liquid BOM, P&L, standard-cost, gross-margin, or SKU-cost
  questions, resolve entity/geography before routing. TofuTown / Just Europe,
  Europe, EU, Germany/DE, `237000`, `237000HF`, or `JUST EGG 6x340ml DE` route
  to the TofuTown / Just Europe P&L and BOM-folder finance lanes:
  `tofutown_standard_cost_gross_margin_by_sku_2026_05`,
  `tofutown_bom_tt_skus`, and `tofutown_preliminary_pl_march_2026`. Just US,
  US domestic, US retail, US foodservice, or Canada BOM/P&L questions route to
  `just_us_canada_p_and_l_boms` when that lane is fresh and hosted-queryable;
  do not answer them from TofuTown / Just Europe lanes. If that lane is stale,
  missing from the hosted Ask surface, or not atomically queryable, report a
  Just US/Canada source gap instead of substituting Europe data. Do not answer BOM questions from Replace Enter formula records
  unless the user asks for formulation, label, ingredient, or nutrition details.
  If the correct BOM-folder lane is missing the SKU, say that the BOM-folder
  lane is missing that SKU instead of substituting formula data.
- For Asana questions, `asana_work_management` is a key source lane and should
  be the first route for project, task, owner, blocker, status, due-date, and
  recent-work questions. The selected Asana source teams are Sensory,
  Administrators, Ops, and Program Management Team; route team-scoped Asana
  questions through those teams and their project catalog rows first. Always
  distinguish the source lane from the team/project filter: `Ops` is a team
  scope inside the `asana_work_management` source lane, not the source lane
  itself. Asana answers, including compact tables, must include a source line
  naming `asana_work_management`, the task/project/story/attachment locator or
  row key used, and the source/fetch time. The
  explicit Asana projects Inside sales, Sales Projects, Creative Tasks, and Eat
  Just Social Media are also source boundaries for work-item questions, scoped
  to rolling 30-day activity for task/story/attachment/subtask evidence. The
  project catalog is source-grade for project existence, owner, team,
  active/archive status, membership, and project links. A cached rolling
  modified-task snapshot can miss long-lived projects such as `Select v6`. If
  the user names an Asana project and VM SQLite cannot find it, say this is an
  Asana source coverage gap and route to `just-source` refresh; do not conclude
  the project is absent from Asana.
- For Asana write requests on Josh's Mac, use the Keychain-backed helper
  `/Users/josh/.local/bin/ask-just-asana-env` to load
  `ASK_JUST_ASANA_ACCESS_TOKEN` only for the command that needs it. Do not print
  the token, store it in repo files, or export it globally. Verify writes with a
  direct Asana readback, then wait for the hosted Ask Just snapshot to refresh
  before treating the new row as source-plane evidence.
- For Appleton/JPC factory dashboard questions, route to
  `appleton_jpc_factory_dashboard`. Use current-reading rows for latest tag
  values, tag metadata rows for descriptions/units/areas, health rows for API
  connection status and total readings, and history-point rows for trends
  inside the ingested hours window. Do not answer from dashboard code,
  screenshots, memory, or local files when endpoint rows are absent.
- If the source plane says a source is routing/context only, do not present it as an exact current business fact.
- Deep Research Max must cover every shared verified Ask Just source lane.
  It must read the generated lane inventory from hosted `ask-just sources`,
  cross-check it against `config/queryable-source-ids.json`, verify every shared
  verified lane against hosted SQLite receipt rows before launch, and write the
  full list to `source_lanes_covered` in the evidence bundle. Do not use a
  prompt-specific "relevant lanes" set or a manually maintained source list as
  the coverage boundary. Relevance affects row selection and ranking inside
  each lane, not lane coverage. Personal/private overlays stay excluded unless
  promoted into the shared verified source lane inventory.
- If a retrieval fails, times out, returns a server error, or looks empty in a way that conflicts with the expected source boundary, use `ask-just health` or `ask-just health --deep` to diagnose readiness. If health fails, report the failure plainly and stop. Do not provide a fallback answer from memory.
- Do not share `trace_id`, `trace_span_id`, `trace_project`, `trace_url`, Braintrust URLs, or other run/debug trace metadata unless the user explicitly asks for a trace, `/trace`, Braintrust review, or run debugging. Treat trace metadata as observability, not answer provenance.

## Retrieval

Use the `ask-just` CLI, which calls the hosted HTTP service:

```bash
ask-just query "QUESTION" --limit 5
ask-just query "QUESTION" --source SOURCE_ID --limit 5
ask-just sql "select ... limit 5"
ask-just --include-trace query "QUESTION" --source SOURCE_ID --limit 5
```

For ordinary user and teammate questions, always use `ask-just query`.
Treat `ask-just search` as a raw keyword diagnostic for source debugging, not
as the normal Ask Just answer path and not as something users need to choose.

For ordinary business questions, run the actual retrieval first. Do not add
`--with-health` as a default readiness ritual. Use `--with-health` only when
the user asks for runtime/source-plane proof or when debugging a failed,
timed-out, or suspiciously empty retrieval.

For broad list questions that may return many rows, such as employees,
customers, SKUs, stores, tasks, invoices, or files, optimize for latency and
signal. Use one targeted SQL query for the count and first useful page of
business fields instead of paginating repeatedly through the whole source lane.
Default to a compact answer with the total row count, a representative or first
page list, and the exact source line. Only retrieve every row into chat when
the user explicitly asks for the full list in the conversation. If a full list
is needed and it is long, prefer preparing a CSV/table artifact from one hosted
SQL result rather than issuing many small page queries.

If the hosted API times out or returns 5xx, stop the answer attempt and
diagnose the hosted API. Do not use SSH, direct SQLite, local SQLite, tunnels,
raw artifacts, or another source surface to answer the user's business
question.

Use standalone health only when diagnosing readiness:

```bash
ask-just health
ask-just health --deep
```

## Current Source Lanes

Do not trust a hard-coded lane list in this skill. The active source inventory
is repo-owned and must be read from:

- `config/all-source-ids.json` for every declared source lane
- `config/queryable-source-ids.json` for lanes expected on the ask surface
- `docs/strict-source-completion-table.md` for lane-by-lane completion state
- `docs/source-required-inputs.md` for current external-input blockers

Do not rely on any lane count printed in this skill. During the 2026-05-07
naming pass, hosted `ask-just sources` returned 54 rows, while local config and
receipt work may be ahead of the deployed surface during active source-lane
work. Re-run the proof commands below before relying on lane counts, because
the hosted VM SQLite, queryable-source config, and strict audit are the source
of truth.

Hosted health currently derives critical row counts from live SQLite, not stale
`source_status.json`. The current SQLite proof should be checked live with
`ask-just health`; do not hard-code row counts in answers.

Source proof commands:

```bash
cd /Users/josh/projects/ask-just
python3 scripts/build_strict_source_completion_table.py
python3 scripts/build_source_required_inputs.py
python3 scripts/verify_source_goal_complete.py
ask-just health --deep
ask-just sources
ask-just query "Mar gross revenue" --source scorecard_monthly_data --kind atomic --limit 3
ask-just query "PUBLIX CORP RMA JUST Egg Plant Based Scramble 16 Oz 4.2" --source spins_breakfast_powertabs --kind atomic --limit 1
ask-just query "customrecord outlook sync part tracker" --source netsuite_account_catalog --kind atomic --limit 5
python3 scripts/deep_research_just.py --bundle-only --row-limit 0
```

Do not answer live ENTR/Replace Enter or TofuTown current-truth questions as
fully sourced unless their required proof remains present and the strict source
gate exits 0.

For `rd_powerjacks_formulations`, the declared boundary is exactly:
the R&D SharePoint workbook
`Power Jacks Formulation Tracker-3.5.2026.xlsx` with
`sourcedoc={9A23CECD-3DA1-4581-986A-FEE0E816350C}`. Do not use the stale
`just-research/knowledge/rd-downloads` copy for Power Jacks formulation
answers, and do not describe this lane as coverage of the full R&D
Formulations-Vault folder.

For `hr_just_food_company_headcount`, the declared boundary is exactly
`source-material/hr_just_food_company_headcount/Headcount for Josh.xlsx`.
Route Just Food Company employee roster, headcount, work email, job title,
department, and employee-status questions here. This lane contains confidential
employee PII; answer narrowly and preserve workbook, sheet, row, and cell
provenance.

For `spins_plant_based_meat_powertabs`, the declared boundary is exactly:
`/Users/josh/Downloads/SPINS PowerTabs Eat Just Plant Based Meat Data Ending 04-19-26 (1).xlsb`.
Route SPINS PowerTabs plant-based meat retail velocity questions here,
including brand, retailer, item, promotions, distribution opportunity, growth
drivers, and competitive retailer/banner questions. Preserve provider/report,
sheet, row, brand/product scope, retailer/banner, geography/channel, period
window, measure, and `workbook_rows` or `pivot_cache_records` provenance. Do
not use the older 2026-03-22 workbook or external mirror rows as evidence for
this lane. Retailer plus SKU questions should use exact SQL against
`pivot_cache_records` when the user names a retailer, SKU/flavor, UPC, or time
period; broad FTS can rank competitor "Original" rows above the exact Just Meat
SKU. The current Walmart Just Meat SKU labels in the decoded cache are
`Original`, `Sesame Ginger`, `Buffalo`, and `Chili-Lime`.

Correction rule from SPINS Walmart Just Meat testing: when the user asks for
weekly `u/s/w`, `units/store/week`, or weekly units per store per week, answer
only the named weekly velocity field `Weekly u/s/w` /
`Average Weekly Units Per Store Selling Per Item`, preferring
`spins_item_ranking_rows` before decoded `pivot_cache_records`. Do not answer
weekly u/s/w from raw `Units per Store Selling`, raw `Units`, `# of Stores
Selling`, or a chat-time calculation. If the named weekly field is missing for
the requested retailer/SKU/time period, say the weekly field is not queryable
or not reported at that grain yet and treat true parser misses as source gaps.

Serious correction: for velocity questions, use SPINS last 4 weeks as the
canonical source by default. Do not answer velocity from `target_tracker`,
retailer review/reset rollups, Scorecard values, or chat-time calculations unless the
user explicitly asks for those noncanonical artifacts. The `target_tracker`
source id is a retailer review calendar and reset-planning workbook, not Target
customer evidence.
Production planner questions route to `operations_production_plan_latest`.
This includes production plan, production planner, forecasted demand, fill
order, run plan, upstream demand, capacity, inventory, and production schedule
questions. Do not use `target_tracker` as supporting evidence for production
planner answers. `target_tracker` is only for retailer review timelines, reset
timing, buyer review, submission status, accepted/declined status, and other
retailer calendar context unless the user explicitly asks for that workbook.
For customer forecast questions, look for exact `2026 Forecast` rows in
`operations_production_plan_latest` first, filtered by named customer or
retailer and product family. Use production sheets or workbook comments after
that only when the exact customer forecast row is missing or the question asks
about fill-order or production-plan context.
The exceptions are HEB and Whole Foods velocity questions, which may route to
their declared retailer-specific lanes with exact workbook/API provenance. Keep
Whole Foods Canada and Whole Foods US separate: Canada routes only to
`whole_foods_canada_just_egg_rl_upsw`; US WHO-cube questions route to
`whole_foods_us_who_cube_2026_04_19` / `ask-just whole-foods-us-velocity` when
that lane is hosted-queryable.
For Whole Foods Canada, the active workbook is the simple RL UPSW sheet.
Column E, `Units per Store per Week (w/zeros)`, is unit velocity; column F,
`Sales$ per Store per Week (w/zeros)`, is dollar velocity. Treat `LIQ`,
`liquid`, and `pourable` as `JUST EGG PLANT LIQ`. Treat `JUST PLANT EGG`,
`patty`, and `folded` as the Canada Just Egg Patty/Folded item.
Whole Foods US individual store sales/ranking questions route to
`ask-just whole-foods-us-store-sales`; use the all-selected Store Sales table
for broad store rankings and the By Store Units / By Store Dollars facts for
SKU or segment filters such as Just Meat.
Treat "Just Meat" as the `Plant Based Chicken` segment across Original and
Buffalo meat SKUs.
For Whole Foods US WHO-cube SKU questions, treat "patty" and "folded" as
synonyms: both refer to `EGG PATTY PLANT BASED 4CT 8 OZ`, segment
`Frzn Folded Egg Patty`.
Scorecard is downstream for velocity: its delta API should be refreshed from
canonical SPINS L4W, or the declared HEB/Whole Foods exception lane, and
Scorecard should not override the canonical source if values conflict.

For any SPINS velocity answer, require an unambiguous last-4-weeks row with
matching Just/Eat Just brand or item, retailer/geography, product/SKU, period,
measure, and source provenance. Do not use SPINS rows where description says
Just Egg but brand is `TAYLOR FARMS`, and do not use 12/24/52-week rows when
the user asks for most recent or current velocity. If active SQLite lacks an
unambiguous SPINS L4W row at the requested grain, say the source plane cannot
answer yet and record it as a parser/source gap.

SPINS visible-report correction: for all SPINS retail analytics questions,
query structured visible report rows from `spins_item_ranking_rows` first,
before `pivot_cache_records`. This is broader than Just-only velocity: the user
may ask flexible ranking/slicing questions across frozen breakfast,
refrigerated eggs, protein powder, condiments, and plant-based meat, including
competitors such as Impossible, Beyond, Applegate, Eggland's Best, Pete &
Gerry's, Chino Valley, Jimmy Dean, and other category brands. Support filters
and rankings by retailer/geography, channel, category, subcategory, product
type, brand, SKU, UPC, size, plant-based flag, time period, dollars, units,
dollar velocity, unit velocity, distribution, promo, price, share, and change
metrics. The `target_tracker` retailer review calendar/reset-planning workbook
is irrelevant to this SPINS path unless explicitly requested.

SPINS retailer names are user-facing aliases, not exact database keys. Resolve
plain retailer names such as `Kroger`, `Albertsons`, `Publix`, `Sprouts`,
`Wegmans`, `Walmart`, or `Plum Market` to the canonical SPINS geography value
in SQLite before matching rows. For example, `Kroger` should resolve to
`KROGER BANNER TOTAL - RMA`; do not report a source gap just because the user
did not know the exact SPINS geography label.

The default SPINS retail analytics answer period is last four weeks
(`4 Weeks`) when the user does not name a period, but the durable source layer
should be pre-materialized for all supported PowerTabs periods (`4 Weeks`,
`12 Weeks`, `24 Weeks`, `52 Weeks`) across `MULO`, `NATURAL`, and every
retailer/geography listed in SPINS. Preserve all visible Item Ranking SKU rows,
not just JUST rows, so competitor ranking questions work. Default unit velocity
to `Average Weekly Units Per Store Selling Per Item`
(`velocity_units_per_store_per_week`). Default dollars per door per week /
dollar velocity to `Average Weekly Dollars Per Store Selling Per Item`
(`velocity_dollars_per_store_per_week`). If the exact requested period/channel
slice is missing, say the source plane needs that SPINS snapshot instead of
answering from a nearby channel, period, workbook, retailer review calendar/reset
tracker, or Scorecard.

For Just SKU velocity, this applies across retailers and across Just SKU
families: JUST Egg refrigerated pourable/scramble 16 oz, JUST Egg Folded,
JUST Egg burritos, Just Meat Original/Sesame Ginger/Buffalo/Chili-Lime, JUST
protein powder SKUs, and JUST condiments. A pivot-cache miss is not a source
miss when the visible PowerTabs `Item` / Item Ranking report row exists.
Preserve the report geography, time period, latest data ending date, active
filters, description, UPC, brand, exact metric name, value, row/cell locator,
and normalized Just SKU family where applicable.
For PowerTabs manual reproduction, `Geo` is the retailer/geography selector.
Pair slicers by SKU family before declaring a miss: JUST Egg liquid belongs in
`REFRIGERATED EGGS` / `RF EGGS LIQUID`, while JUST Egg Folded and burritos
belong in `FROZEN BREAKFAST FOODS` with the matching frozen breakfast
subcategory. Empty rows from an incompatible category/subcategory state are not
source gaps.
For cross-category SPINS comparisons, resolve each SKU family to its own
declared SPINS workbook before ranking or comparing rows. JUST Egg, JUST Egg
Folded, and JUST Egg burritos live in `spins_breakfast_powertabs`; Beyond Meat
and Just Meat live in `spins_plant_based_meat_powertabs`. Do not report a
JUST Egg source gap because the plant-based meat workbook lacks egg rows, and
do not use a nearby plant-based-meat slice as evidence for egg velocity.
If the open Excel workbook has unsaved recovered slicer/filter changes, save or
persist that workbook state before rebuilding SQLite. Use
`scripts/capture_spins_visible_item_ranking.py` to capture the Excel-visible
Item Ranking report as additive snapshots under
`source-material/<source_id>/visible-item-ranking-snapshots/`; the builder
ingests every snapshot into `spins_item_ranking_rows` with
`local:excel_visible_report_snapshot` provenance. Stale downloaded bytes can
show a different visible report state.

For `scorecard_ops_metrics`, the declared boundary is exactly the current
`https://just-scorecard.vercel.app/api/read-data?key=ops_metrics` response at
build time. Route operational KPI questions such as Protein on Hold, upstream
inventory, shelf life, month-end inventory, warehousing, transportation, and
write-offs to this lane. Preserve `application/record/field` provenance.

For `scorecard_monthly_data`, the declared boundary is exactly the current
`https://just-scorecard.vercel.app/api/read-data?key=monthly_data` response at
build time. Route company KPI questions that the Scorecard can answer to this
lane by default, including monthly revenue, Scorecard metrics, and dashboard
business-performance values. Margin is a Scorecard KPI by default. Preserve the
Scorecard metric label and period exactly. Do not replace or caveat a
Scorecard-answerable KPI with a NetSuite P&L value unless the user explicitly
asks for NetSuite, accounting ledger, P&L detail, or reconciliation.

For `operations_logistics_otif_2024v2`, the declared boundary is exactly the
Operations / ALLOCATION / `Logistics OTIF 2024v2.xlsx` SharePoint workbook.
Route questions about logistics OTIF calculation mechanics, revised OT/IF/OTIF,
order allocation schedule rows, CPU exclusion, late-and-affected treatment, and
Pushed/Short/Cancelled customer-impact formulas to this lane. Use
`workbook_calculation_rules` as a routing overview, then cite the underlying
`OTIF Revised 2025` formula cells or threaded comments for exact wording.
Plain monthly OTIF KPI values remain Scorecard-canonical unless the user asks
about this workbook or the calculation method.

For Just Meat in-market sensory comments, tasting dates, shelf-life tasting
notes, action items, texture, flavor, mold, packaging, or trial notes, route
first to `rd_in_market_testing`, not `batch_release_app`. The declared boundary
is exactly `In-Market Testing.xlsx`. On the `In-Market` sheet, later rows can
inherit the tasting date from the most recent dated row above in column B; do
not treat those as undated merely because the row itself has a blank date cell.
Use `batch_release_app` sensory only for Batch Release app-state questions or
when the user explicitly asks about the Batch Release app sensory records.

For `batch_release_app`, the declared boundary is exactly the current
Batch Release read-data app-state at build time: `batch_release:batches`,
declared static keys such as protein lots, batch sheets, thresholds, audit log,
sync states, sensory, and IQ Kitchen slices, plus per-batch `micro`,
`product_tests`, `water_activity`, and `qa_sensory` side keys enumerated from
the current batch ids. Route current Batch Release questions about batch
status, held/reviewing/pending/released batches, product name, production date,
protein lot ids, thresholds, audit events, micro fields, product test fields,
water activity, QA sensory, documentation flags, and IQ Kitchen evidence fields
to this lane. Preserve `application/record/field` or
`application/app_state_key/field` provenance. Do not present this as full upstream
raw SharePoint batch sheet, COA PDF, IQ Kitchen raw submission, email/Graph,
lab-system raw record, Vercel log, or every-route coverage.

For `netsuite_items`, the declared boundary is exactly the live NetSuite
SuiteQL `item` query at build time. Route NetSuite item and SKU lookup questions
to this lane. Preserve `application/record/field` provenance and the
`netsuite:/suiteql/item` locator. Do not use external mirror exports for this
lane. Do not route P&L, AR aging, transactions, vendors, customers, or
account-wide NetSuite catalog questions here until those boundaries have their
own parsed source lanes.

For `netsuite_account_catalog`, the declared boundary is the live NetSuite
account catalog audit receipt at
`receipts/fresh/source-granularity-netsuite_account_catalog.json`. Route
NetSuite source-coverage, record-type availability, field-count, REST
accessibility, SuiteQL accessibility, row-count, and metadata-catalog questions
here. Preserve `account_catalog/root_item` or
`account_catalog/record_type/schema_count` provenance. Do not use this lane as
transaction, item, P&L, vendor, customer, or AR aging source data; use a
specific parsed NetSuite lane for those values.

For NetSuite finance questions, route to the specific NetSuite finance lane:
`netsuite_pnl_monthly` for revenue, profit, loss, P&L, COGS, gross profit, and
gross margin; `netsuite_ar_open_invoices` for AR and receivables;
`netsuite_ap_open_bills` for AP and payables; and
`netsuite_inventory_snapshot` for inventory quantity/value by item and
location. For explicit NetSuite revenue by product, item, SKU, itemid, or
product SKU to date, route to `netsuite_revenue_by_sku_ytd`. For explicit
NetSuite revenue by customer, account, channel, class, customer/SKU, or
customer/SKU/channel to date, route to
`netsuite_revenue_by_customer_sku_channel_ytd`. These YTD revenue lanes are
currently partial: Finance corrected the boundary on 2026-05-05 and said
canonical product/SKU revenue must reconcile to the NetSuite UI Income
Statement row `41005 Gross CPG sales`. Do not include `41008` in product/SKU
revenue; CFO feedback says it is co-packer raw material sales to TofuTown.
Do not include `41025` or other 41xxx deduction/allowance rows as Gross CPG
sales unless Finance supplies an explicit reconciliation. Finance also records
an EDLC pricing gross-up inside Gross CPG sales; until the source lane captures
or allocates that gross-up and reconciles to the UI Income Statement `41005`
total, answer with a reconciliation caveat rather than calling the SKU revenue
lane canonical. Preserve the row-level SuiteQL provenance and do not answer
these from the catalog lane.

For cash projection, bank account balance, weekly payments, payment-list proof,
cash inflow/outflow, ending balance, available cash, or net cashflow questions
from the Finance cash-flow workbook, route to
`finance_cash_flow_forecast_2026` and prefer the typed
`finance_cash_flow_metrics` table before generic workbook FTS. Use
`ask-just finance-cash-flow` or exact SQL against `finance_cash_flow_metrics`.
The canonical projection sheet is `Cash Projection 2026 by Vendor`: row 4
Beginning Balance, row 5 Cash Inflow, row 6 Cash Outflow, row 7 Ending Balance,
rows 94-100 Bank Accounts, row 102 cash reconciliation before payments, row 107
Payment list proof, row 109 reconciliation Ending Balance, and row 111
Available. Monthly questions should use `period_type = month_total` with the
month-end `period_end`; weekly questions should use `period_type = week` with
the Friday `period_end`. Net cashflow is a typed computed metric from Cash
Inflow plus Cash Outflow and must cite both source cells.

Scorecard precedence overrides this default finance routing when the question
is a business KPI that the Scorecard already answers. In that case, use the
Scorecard lane as canonical and only pull NetSuite for explicit accounting or
reconciliation follow-up.

## Answer Rules

- Answer only from returned rows.
- Lead with the plain business answer, then give a compact source line. Do not
  narrate implementation mechanics unless the user asks how the answer was
  obtained or the retrieval path is failing.
- Every factual answer must include a compact provenance line. Use this shape:
  `Source: SOURCE_ID, grain/row LOCATOR_OR_ROW_KEY, as of SOURCE_TIME_OR_FETCH_TIME.`
- A formatted table is not complete until the source line appears after the
  table. Do not let table formatting, brevity, or UI polish drop the source id,
  locator or row key, and source/fetch time.
- Do not rely on vague phrases like "from Scorecard" or "from NetSuite" as provenance. Name the exact source id such as `scorecard_monthly_data`, `scorecard_ops_metrics`, or `netsuite_pnl_monthly`.
- Cite source ids and provenance grains.
- For atomic rows, cite table, source file, row key or locator, and period/date when available.
- Do not use removed context exports as answer evidence.
- If exact current truth belongs to a live system that has not been materialized into hosted Ask Just, say the hosted Ask Just source index identifies the source boundary but does not contain the live value.
- Do not add a "small caveat" or alternate-system comparison to a Scorecard-canonical answer unless the user explicitly asked for that comparison. In particular, do not mention NetSuite after answering revenue or margin from Scorecard unless the user asked for NetSuite, P&L, accounting, or reconciliation.
- For plain revenue or margin questions, avoid explanatory preambles about source precedence. Do not say "NetSuite only for..." or similar. Just answer from `scorecard_monthly_data` with the provenance line.
- Do not dump raw JSON unless the user asks for raw output.
- For inventory, stock, SKU, or operational list questions, prefer a clean table
  with the business columns the user asked for, then a one-line provenance note.
  Avoid long process explanations and avoid saying raw files were extracted when
  the answer came from already-materialized SQLite rows.
