---
name: just-source
description: "Use for Ask Just source work: onboarding Just artifacts, checking whether Just sources are mapped, parsed, receipted, refreshed, wired to ask-just, or correcting source-routing gaps for Just company memory."
---

# Just Source

Use `just-source` when the task is about whether a Just artifact is source-grade
or how to make it source-grade. Use `askjust` for normal business answers.

## Ask Just Contract

An artifact is not Ask Just source-grade because it exists in SharePoint,
NetSuite, Scorecard, an app, a workbook, a repo folder, or a screenshot. It
becomes source-grade only when its declared boundary is mapped, accessible,
atomically queryable with `provenance_grain`, receipted, and wired through the
`ask-just` API/CLI.

Ordinary answers should not query raw Just artifacts directly unless an explicit
exception was made. Raw artifacts are upstream evidence. The ask surface is
`ask-just` calling the hosted API, which reads the verified SQLite3 source index
on the Ask Just VM:
`/home/josh/ask-just/artifacts/ask-just-fresh-source-plane/source_index.sqlite`.
Local SQLite is for development/rebuild verification unless the user explicitly
asks for local inspection.

Use exact phase language. Source work may ingest, parse, extract, rebuild, and
receipt upstream artifacts. Normal Ask Just answering queries already-indexed
SQLite rows and formats the result. Do not describe a normal answer as
"extracting from" a workbook, API, SharePoint folder, or raw artifact unless
that parser/rebuild actually ran in the current turn.

## Job

Decide whether a declared Just source boundary is:

1. mapped
2. accessible
3. atomically queryable
4. wired to `ask-just`

If any gate fails, say which one failed and record the gap. Do not turn a source
gap into an answer rule.

## Current Lanes

Use `skills/askjust/SKILL.md` for detailed answer routing. For source work, do
not trust a hard-coded lane list in this skill. The active lane inventory is
repo-owned and must be read from:

- `config/all-source-ids.json` for every declared source lane
- `config/queryable-source-ids.json` for lanes expected on the ask surface
- `docs/strict-source-completion-table.md` for lane-by-lane completion state
- `docs/source-required-inputs.md` for the current external-input blockers

Do not rely on any lane count printed in this skill. During the 2026-05-07
naming pass, hosted `ask-just sources` returned 54 rows, while local config and
receipt work may be ahead of the deployed surface during active source-lane
work. Re-run the proof commands below before relying on counts, because the
queryable-source config and hosted VM source-index audit are the source of
truth. Exposed does not mean fully sourced:
`netsuite_revenue_by_sku_ytd` and
`netsuite_revenue_by_customer_sku_channel_ytd` are partial until they reconcile
to the NetSuite UI Income Statement `41005 Gross CPG sales` row.

If an artifact is outside these lanes, treat it as a new lane candidate or a
source gap. Do not silently fold it into the closest lane.

NetSuite revenue correction: Finance corrected the product/SKU revenue boundary
on 2026-05-05. Canonical product/SKU revenue must reconcile to the NetSuite UI
Income Statement row `41005 Gross CPG sales`. Do not include `41008`; it is
co-packer raw material sales to TofuTown. Do not include `41025` or other 41xxx
deduction/allowance rows as Gross CPG sales unless Finance supplies an explicit
reconciliation. Finance also records an EDLC pricing gross-up inside Gross CPG
sales. The March 2026 workbook/financials tie-out is known to be off by 490.43
because of a NetSuite issue per CFO feedback. Until the SKU/customer/channel
lanes capture or allocate the EDLC gross-up and reconcile to `41005`, mark them
partial rather than fully `$source`.

Personal source overlay: a user's own mailbox is not a team source lane. It is
a private overlay keyed by that user's Ask Just bearer token hash and delegated
Microsoft Graph refresh token. Source work for personal email should verify
`ask-just personal-mail-status`, `ask-just personal-mail-search`,
`ask-just personal-mail-read`, and the draft/send endpoints, not add the mailbox
to the shared SQLite source plane. Personal mailbox write access should create
drafts by default; sending must remain an explicit send-draft action.

Deep Research Max source coverage is also a source-plane contract. It must cover
every shared verified Ask Just source lane, using the generated hosted
`ask-just sources` inventory cross-checked against
`config/queryable-source-ids.json`. It must stop before launch if any shared
verified lane is missing, stale, unverified, or has failing receipts. Do not
replace this with a "relevant lanes" filter or a manually maintained checklist.
Relevance affects row selection and ranking inside each lane, not lane coverage.
Personal/private overlays stay excluded unless promoted into the shared verified
source lane inventory.

For source-status and onboarding work, treat user wording as intent, not as a
literal source id, workbook name, app name, table name, field name, column label,
artifact path, or internal taxonomy. If literal terms miss or look weak, resolve
through the verified index: identify the fact type, search nearby indexed
lanes/tables/files/fields that could hold it, inspect representative atomic rows
or schemas, prove the mapping with `provenance_grain`, and then either encode
the mapping or record the source gap. This is source-index resolution, not
embedding-router behavior.

Asana source correction: the Ask Just Asana lane is a key source lane for Just
work-management questions and must not be treated as proper coverage when it is
only a cached rolling `modified_at.after` snapshot. Long-lived projects can be
missed even when they exist in Asana. Proper Asana coverage requires a runtime
token-backed refresh that enumerates the visible active and archived project
catalog first, including owner-filtered browse results such as every active
project owned by Florencia Tripoli, plus the selected source teams Sensory,
Administrators, Ops, and Program Management Team, plus explicit project
boundaries such as Inside sales, Sales Projects, Creative Tasks, and Eat Just
Social Media. All visible projects and project data under those selected teams
are part of `$just-source`; task/story/attachment/subtask ingestion for those
selected teams and explicit projects is scoped to rolling 30-day activity. The
project catalog is source-grade for project existence, owner, team,
active/archive status, membership, and project links; do not block those answers
on crawling every task, story, attachment, or subtask. Full task coverage
additionally requires project task references, rolling modified-task search
results, recent stories/comments, recent attachments, and recent subtasks. If a
named project such as
`Select v6` is absent from the hosted Ask Just source index, record an Asana source coverage gap
and refresh through the live API rather than answering that Asana lacks it.

Appleton/JPC factory dashboard source correction: the Appleton dashboard source
lane is endpoint-native. Proper coverage comes from
`appleton_jpc_factory_dashboard` over `https://jpc-factory.ju.st/api/current`,
`/api/tags`, `/api/health`, and configured `/api/history` windows. Do not treat
dashboard code, screenshots, local JSON outside source-material, or chat memory
as answer evidence for Appleton plant/FactoryTalk tag questions. If the hosted
SQLite lane lacks the tag, current value, health record, or history window the
question needs, record a source or freshness gap and refresh the HTTP API
snapshot.

BOM source correction: for Just Egg liquid BOM, P&L, SKU cost, standard-cost,
gross margin, or product-cost questions, resolve the entity/geography first.
TofuTown / Just Europe, Europe, EU, Germany/DE, `237000`, `237000HF`, or `JUST
EGG 6x340ml DE` are the TofuTown / Just Europe P&L and BOM-folder finance
source family: `tofutown_standard_cost_gross_margin_by_sku_2026_05`,
`tofutown_bom_tt_skus`, and `tofutown_preliminary_pl_march_2026`. Just US, US
domestic, US retail, US foodservice, or Canada BOM/P&L questions route to
`just_us_canada_p_and_l_boms` when that lane is fresh and hosted-queryable; do
not answer them from TofuTown / Just Europe lanes. If the declared Just
US/Canada BOM/P&L folder lane is stale, missing from the hosted Ask surface, or
not atomically queryable, record a Just US/Canada source-lane gap instead of
filling the answer from Europe data. Replace Enter may answer formulation, label, ingredient,
nutrition, and proof-record questions, but it is not the BOM source. If the
correct BOM-folder lane is missing the SKU, record a BOM-folder parser/source
gap instead of filling the answer from formulation records.

## Proof Commands

```bash
ask-just sources
ask-just health --deep
ask-just query "real question" --source SOURCE_ID --kind atomic --limit 5
ask-just search "TERM" --source SOURCE_ID --kind atomic --limit 5
ask-just sql "select ... limit 20"
ask-just source-links --source-id SOURCE_ID --locator "SOURCE_LOCATOR_OR_ROW_LOCATOR"
python3 scripts/audit_source_links.py
python3 scripts/audit_full_source_contract.py --json
python3 scripts/build_strict_source_completion_table.py
python3 scripts/build_source_required_inputs.py
python3 scripts/check_vm_source_refresh_status.py
python3 scripts/verify_source_goal_complete.py
python3 scripts/deep_research_just.py --bundle-only --row-limit 0
```

For workbook, API, app-state, SuiteQL, or audit questions, inspect atomic rows
and `provenance_grain`, not only source-map metadata.

## Source Link Resolution

The hosted VM SQLite source index remains the source of truth behind the Ask
Just API. Source links are inspection handles, not a second answer path. When a
user asks to see the source file, full workbook, BOM, API endpoint, or upstream
locator behind an answer, resolve the returned row's `provenance_grain` through
`ask-just source-links` or the
`/source-links` HTTP endpoint.

The resolver reads only the hosted source index tables (`atomic_rows`, `source_files`,
and `sources`) and returns source artifact handles such as local workbook paths,
HTTP/API URLs, or structured locators like `netsuite:/suiteql/...`. For local
files and HTTP URLs, `openable` indicates whether the current machine can open
the handle directly. For structured systems such as NetSuite, preserve the
locator even when there is no browser URL.

## SPINS Retail Analytics Goal

Ask Just must support flexible SPINS PowerTabs retail analytics from the
business-visible report layer across frozen breakfast, refrigerated eggs,
protein powder, condiments, and plant-based meat. This includes Just/Eat Just
SKUs and all relevant competitors such as Impossible, Beyond, Applegate,
Eggland's Best, Pete & Gerry's, Chino Valley, Jimmy Dean, and category-specific
brands surfaced in the workbook.

The user may ask to slice, rank, or compare by retailer/geography, channel,
positioning group, category, subcategory, product type, brand, SKU, UPC, size,
plant-based filter, time period, dollars, units, dollar velocity, unit velocity,
distribution, promo, price, share, change versus prior period, or competitor.
Those questions should be answered from SPINS PowerTabs visible Item Ranking
rows materialized in SQLite, not from the `target_tracker` retailer review
calendar/reset-planning workbook.

For velocity and retailer ranking questions, SPINS last 4 weeks is canonical by
default when the user does not name a period. The required SPINS slice layer is
every supported PowerTabs time period (`4 Weeks`, `12 Weeks`, `24 Weeks`,
`52 Weeks`) x `MULO` x `NATURAL` x every retailer/geography listed in SPINS,
across each relevant PowerTabs workbook. It must preserve all visible SKU rows,
including JUST/Eat Just and competitors. Unit velocity means `Average Weekly
Units Per Store Selling Per Item`; dollar velocity / dollars per door per week
means `Average Weekly Dollars Per Store Selling Per Item`. The `target_tracker`
review-calendar/reset-planning lane is not canonical answer evidence for
velocity or Target customer performance, and Scorecard is a
downstream sink that should be refreshed from canonical velocity sources through
its delta API. If Scorecard conflicts with SPINS L4W, SPINS L4W wins for
unspecified-period/current velocity answers.

HEB and Whole Foods are exceptions to the SPINS-default rule: route those
velocity questions to their declared retailer-specific source lanes when those
lanes are mapped, accessible, atomically queryable, and wired. Keep Whole Foods
Canada and Whole Foods US separate: Canada routes only to
`whole_foods_canada_just_egg_rl_upsw`; US WHO-cube routes to
`whole_foods_us_who_cube_2026_04_19` and its typed
`whole_foods_us_who_cube_velocity` table when hosted-queryable. If the declared
SPINS L4W row or exception lane is missing, record a parser/source gap instead
of answering from the retailer review calendar/reset tracker, stale Scorecard,
or a nearby period.
For Whole Foods Canada, the active workbook is the simple RL UPSW sheet.
Column E, `Units per Store per Week (w/zeros)`, is unit velocity; column F,
`Sales$ per Store per Week (w/zeros)`, is dollar velocity. Treat `LIQ`,
`liquid`, and `pourable` as `JUST EGG PLANT LIQ`. Treat `JUST PLANT EGG`,
`patty`, and `folded` as the Canada Just Egg Patty/Folded item.
For Whole Foods US individual store sales/ranking questions, route to
`whole_foods_us_who_cube_store_sales` for the all-selected product universe or
`whole_foods_us_who_cube_store_item_sales` for SKU/segment-filtered questions.
Treat "Just Meat" as the `Plant Based Chicken` segment across the Original and
Buffalo meat SKUs.
For Whole Foods US WHO-cube SKU routing, "patty" and "folded" are the same
product language: both map to `EGG PATTY PLANT BASED 4CT 8 OZ` / segment
`Frzn Folded Egg Patty`.

For SPINS lanes, visible PowerTabs report rows are first-class source grains.
The source plane should materialize the `Item` worksheet / Item Ranking report
as `spins_item_ranking_rows` with retailer/geography, time period, latest data
ending date, active report filters, row/cell locator, metric names, values,
brand, UPC, description, and normalized Just SKU family fields where applicable.
Use these rows before decoded `pivot_cache_records` for SPINS ranking, slicing,
and velocity answers. A pivot-cache miss is not a source gap if the visible
report row exists. If Excel shows unsaved recovered slicer/filter changes,
persist that workbook state before rebuilding. The durable capture path is
`scripts/capture_spins_visible_item_ranking.py`, which writes a
`*.json` snapshot under
`source-material/<source_id>/visible-item-ranking-snapshots/`; the builder
ingests every snapshot in that folder into `spins_item_ranking_rows` with
`local:excel_visible_report_snapshot` provenance. Otherwise SQLite may reflect
stale downloaded bytes rather than the visible report the user is looking at.
When walking the workbook by hand, use the PowerTabs path `Item` -> `Geo`
(retailer/geography) -> time period -> category -> subcategory. Breakfast
JUST Egg liquid belongs under `REFRIGERATED EGGS` / `RF EGGS LIQUID`; JUST Egg
Folded and burritos belong under `FROZEN BREAKFAST FOODS` with the matching
frozen breakfast subcategory. Capture the corrected visible row instead of
recording a gap when an incompatible slicer state hides rows.
For the full SPINS correction, do not patch retailer examples one at a time.
Generate the workbook-visible materialization plan and export jobs, then use
`scripts/run_spins_visible_item_ranking_export_job.py` to dry-run, verify the
current visible workbook state, and capture only exact planned slicer universes.
The completion gate must remain red while any planned visible slice is still
missing from SQLite.

All planned SPINS visible Item Ranking slices must be captured. A planned job
is not coverage. The scalable capture path is the Windows-only offline runner
`scripts/windows_spins_visible_item_ranking_exporter.py`, which uses desktop
Excel COM `Workbook.SlicerCaches` to set workbook-native slicers, verify the
report filter universe, and export the visible `Item` rows to the same snapshot
schema used by manual captures. Mac Excel/AppleScript is acceptable for
watching or one-off human walkthrough capture, but it must not be treated as
the all-slice automation path because it does not reliably set the PowerTabs
slicer caches. After running the Windows exporter, import the snapshots with
`scripts/import_spins_visible_item_ranking_snapshots.py` and keep
`scripts/audit_spins_just_velocity_source_goal.py` failing until planned,
captured, and imported visible jobs reconcile to zero pending jobs.

## Source Files

- Source map: `config/fresh-source-map.yaml`
- Queryable ids: `config/queryable-source-ids.json`
- VM SQLite3 index: `/home/josh/ask-just/artifacts/ask-just-fresh-source-plane/source_index.sqlite`
- Local dev SQLite index: `artifacts/ask-just-fresh-source-plane/source_index.sqlite`
- Builder: `scripts/build_fresh_source_database.py`
- Contract audit: `scripts/audit_full_source_contract.py`
- Strict completion table: `scripts/build_strict_source_completion_table.py`, `docs/strict-source-completion-table.md`, and `artifacts/ask-just-fresh-source-plane/strict_source_completion_table.json`
- Required input handoff: `scripts/build_source_required_inputs.py`, `docs/source-required-inputs.md`, and `artifacts/ask-just-fresh-source-plane/source_required_inputs.json`
- VM runtime freshness gate: `scripts/check_vm_source_refresh_status.py` and `artifacts/ask-just-fresh-source-plane/vm_source_refresh_status.json`
- Completion gate: `scripts/verify_source_goal_complete.py`
- Answer audit: `scripts/audit_answer_surface.py`
- Receipts: `receipts/fresh/` and `docs/source-receipts/`

## Rebuild / Freshness

```bash
python3 scripts/build_fresh_source_database.py
python3 scripts/audit_full_source_contract.py --json
python3 scripts/build_strict_source_completion_table.py
python3 scripts/build_source_required_inputs.py
python3 scripts/check_vm_source_refresh_status.py
python3 scripts/verify_source_goal_complete.py
ask-just health --deep
```

VM refresh path:

```text
ask-just-source-refresh.timer
-> ask-just-source-refresh.service
-> scripts/build_fresh_source_database.py
```

Use Graph delta for SharePoint/Microsoft Graph sources when available. Otherwise
use HTTP validators, API cursors, modified time, content hash, or a full rebuild,
depending on the lane. Non-SPINS lanes refresh daily at midnight
America/Los_Angeles through the VM source-refresh timer or an equivalent
source-specific delta proof. SPINS lanes remain delivered reporting snapshots
and refresh when a new SPINS workbook snapshot is delivered. Do not claim current
truth from a stale snapshot when a lane requires rebuild or live-query proof.

## New Lane Checklist

- Add/update `config/fresh-source-map.yaml`.
- Add/update `config/queryable-source-ids.json`.
- Add parser/build support in `scripts/build_fresh_source_database.py`.
- Generate atomic rows, source files, receipts, status, summary, and gaps.
- Verify with `python3 scripts/audit_full_source_contract.py --json`.
- Verify through `ask-just query/search/sql ... --source SOURCE_ID`.
- Update the strict lane-by-lane table with `python3 scripts/build_strict_source_completion_table.py`.
- Update required external inputs with `python3 scripts/build_source_required_inputs.py`.
- Do not claim the source goal is complete unless `python3 scripts/verify_source_goal_complete.py` exits 0.
- Update `skills/askjust/SKILL.md` only if answer routing changes.
- Update README/spec/source receipt docs.
- Update the Ask Just architecture docs and visual when the lane changes the
  answerable source plane: `README.md`, `SPEC.md`, `ARCHITECTURE.md`,
  `docs/ask-just-architecture.svg`, and the rendered
  `docs/ask-just-architecture.png`.
- Promote to VM/runtime only after health, count, gap, and query checks pass.

## Post-Confirmation Doc Sync

After a Just lane is confirmed mapped, accessible, atomically queryable, wired
to `ask-just`, and governed by a freshness contract, immediately update the
repo-facing docs before reporting the lane as shipped. This is automatic source
work, not an optional follow-up.

Required Just artifacts:

- `README.md`: current-state/source inventory language visible to operators.
- `SPEC.md`: product/source contract, routing boundary, freshness behavior,
  and exclusions or caveats.
- `ARCHITECTURE.md`: source-plane architecture and runtime boundary.
- `docs/ask-just-architecture.svg`: editable architecture visual source.
- `docs/ask-just-architecture.png`: rendered README-facing architecture image.
- The lane-specific source receipt/docs under `receipts/fresh/` or
  `docs/source-receipts/`.

When updating the architecture image, edit the SVG/source artifact first and
then render the PNG using the repo's documented command, for example:

```bash
sips -s format png docs/ask-just-architecture.svg --out docs/ask-just-architecture.png
```

Do not say "shipped", "confirmed", "source-complete", "fully `$source`", or
"queryable source lane" until those docs are updated, rendered if applicable,
and included in the same repo/VM sync as the parser/source-map/runtime change.
If a doc or visual artifact is missing, create or update the closest repo-owned
architecture artifact and record any remaining gap explicitly.

## Hard Rules

- Before saying a source lane is fully `$source`, inspect `docs/strict-source-completion-table.md` or `artifacts/ask-just-fresh-source-plane/strict_source_completion_table.json`.
- Full `$source` means the lane has evidence for declared boundary, complete enumeration, atomic parse/query coverage, provenance grain sample, receipt path, source-specific hosted query proof, freshness state, and `explicit_gaps = none`.
- A lane with any real useful gap is partial or not sourced, never fully `$source`.
- The thread/source goal is complete only when `scripts/verify_source_goal_complete.py` exits 0.
- Do not say "covered", "available", "mapped", "embedded", "indexed", "source-complete", "wired", or "queryable" unless you can name the proof.
- Do not trust labels like "verified", "covered", "pass", "complete", or "yes" without inspecting what the receipt or audit actually proves.
- Do not claim full Just, full NetSuite, full Scorecard, full Batch Release, full SharePoint, or full R&D coverage from one declared source boundary.
- Do not claim full-boundary proof unless every useful unit in the declared boundary has atomic provenance or an explicit gap.
- Do not call a SharePoint folder or workbook corpus fully parsed unless every file was recursively parsed workbook-by-workbook, sheet-by-sheet, row-by-row, cell-by-cell, with receipts for gaps and exclusions.
- Do not accept generic provenance labels as atomic proof. "SharePoint", "Scorecard", "NetSuite", "Batch Release", "source map", "database", "API", and "workbook" are containers; the proof must identify the exact source id plus file, row, record, field, cell, API response, timestamp, query, or locator.
- Do not soften missing full-boundary proof as nuance. If the proof is partial, say partial. If the proof does not cover the declared boundary, say no.
- Do not use routing/context-only source-map rows as exact business facts.
- Do not answer current business facts from stale artifacts when a live source, refreshed source lane, or rebuild is authoritative.
- Durable source status belongs in maps, ids, receipts, docs, scripts, or tests, not chat memory.

## Answer Shape

```text
Mapped: yes/no/partial
Accessible: yes/no/partial
Atomically queryable: yes/no/partial
Ask-surface wired: yes/no/partial

What I verified:
- ...

Gaps:
- ...

Next source action:
- ...
```
