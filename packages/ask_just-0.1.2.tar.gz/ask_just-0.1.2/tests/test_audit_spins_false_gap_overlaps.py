import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import audit_spins_false_gap_overlaps
import build_fresh_source_database as builder
import backfill_spins_item_rankings


class AuditSpinsFalseGapOverlapsTest(unittest.TestCase):
    def make_db_and_config(self, overlap=True):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = Path(tmp.name) / "source_index.sqlite"
        config_path = Path(tmp.name) / "goal.json"
        config_path.write_text(
            json.dumps(
                {
                    "products": [
                        {
                            "source_id": "spins_breakfast_powertabs",
                            "product_key": "just_egg_folded_8oz",
                            "upcs": ["01-91011-00087"],
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        conn.executescript(backfill_spins_item_rankings.TYPED_SPINS_SCHEMA)
        conn.execute(
            """
            INSERT INTO spins_item_rankings (
              row_id, source_id, source_file, sheet, row_index, geography, channel,
              time_period, description, upc, unit_velocity, dollar_velocity,
              is_just_sku, provenance_grain
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "ranking-row",
                "spins_breakfast_powertabs",
                "fixture",
                "Item",
                15,
                "PUBLIX CORP - RMA",
                "MULO",
                "4 Weeks",
                "Just Folded Eggs From Plants 8 Oz",
                "01-91011-00087",
                1.425,
                7.8099,
                1,
                "{}",
            ),
        )
        if overlap:
            conn.execute(
                """
                INSERT INTO spins_item_ranking_gaps (
                  row_id, source_id, product_key, geography, channel, time_period, provenance_grain
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "gap-row",
                    "spins_breakfast_powertabs",
                    "just_egg_folded_8oz",
                    "PUBLIX CORP - RMA",
                    "MULO",
                    "4 Weeks",
                    "{}",
                ),
            )
        conn.commit()
        conn.close()
        return db_path, config_path

    def test_fails_when_gap_overlaps_complete_numeric_row(self):
        db_path, config_path = self.make_db_and_config(overlap=True)
        result = audit_spins_false_gap_overlaps.audit(db_path, config_path)
        self.assertFalse(result["ok"])
        self.assertEqual(result["false_gap_overlap_count"], 1)

    def test_passes_when_no_gap_overlaps_complete_numeric_row(self):
        db_path, config_path = self.make_db_and_config(overlap=False)
        result = audit_spins_false_gap_overlaps.audit(db_path, config_path)
        self.assertTrue(result["ok"])
        self.assertEqual(result["false_gap_overlap_count"], 0)


if __name__ == "__main__":
    unittest.main()
