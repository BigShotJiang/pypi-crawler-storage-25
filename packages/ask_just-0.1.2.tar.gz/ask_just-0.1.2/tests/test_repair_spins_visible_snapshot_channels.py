import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database as builder
import repair_spins_visible_snapshot_channels


class RepairSpinsVisibleSnapshotChannelsTest(unittest.TestCase):
    def test_repairs_visible_snapshot_channel_and_backfills_typed_row(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = Path(tmp.name) / "source_index.sqlite"
        conn = sqlite3.connect(db_path)
        builder.create_schema(conn)
        row = builder.make_spins_item_ranking_row(
            path=Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb"),
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-04T00:00:00Z",
            extracted_at="2026-05-04T01:00:00Z",
            row_index=15,
            fields={
                "Geography": "PUBLIX CORP - RMA",
                "Time Period": "4 Weeks",
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "SPINS Visible Snapshot": True,
                "SPINS Visible Snapshot ID": "publix_folded_eggs_mulo_4w_frozen_breakfast_omelettes",
                "Average Weekly Units Per Store Selling Per Item": 1.425,
                "Average Weekly Dollars Per Store Selling Per Item": 7.8099,
            },
            locator="/tmp/source.json#sheet=Item&row=15",
            source_file=Path("/tmp/source.json"),
            row_key_suffix="visible_item_ranking_snapshot_publix_folded_eggs_mulo_4w_frozen_breakfast_omelettes",
            source_type="local:excel_visible_report_snapshot",
        )
        builder.insert_atomic_row(conn, row)
        conn.commit()
        conn.close()

        result = repair_spins_visible_snapshot_channels.repair_channels(
            db_path,
            ["spins_breakfast_powertabs"],
            regenerate_gaps=False,
        )

        self.assertEqual(result["visible_snapshot_channels_updated"], 1)
        conn = sqlite3.connect(db_path)
        try:
            typed = conn.execute(
                """
                SELECT channel, unit_velocity, dollar_velocity
                FROM spins_item_rankings
                WHERE upc = '01-91011-00087'
                """
            ).fetchone()
            atomic_payload = json.loads(
                conn.execute("SELECT row_json FROM atomic_rows WHERE row_id = ?", (row["row_id"],)).fetchone()[0]
            )
        finally:
            conn.close()

        self.assertEqual(typed, ("MULO", 1.425, 7.8099))
        self.assertEqual(atomic_payload["fields"]["Channel"], "MULO")


if __name__ == "__main__":
    unittest.main()
