import os
import subprocess
import tempfile
import textwrap
import tomllib
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INSTALL = ROOT / "install.sh"


class InstallScriptTest(unittest.TestCase):
    def skill_config(self, codex_home):
        config_path = codex_home / "config.toml"
        with config_path.open("rb") as handle:
            payload = tomllib.load(handle)
        return payload.get("skills", {}).get("config", [])

    def assert_skill_enabled(self, codex_home, skill_name):
        expected_path = str(codex_home / "skills" / skill_name / "SKILL.md")
        entries = [
            entry
            for entry in self.skill_config(codex_home)
            if entry.get("path") == expected_path
        ]
        self.assertEqual(len(entries), 1, expected_path)
        self.assertIs(entries[0].get("enabled"), True, expected_path)

    def assert_global_agents_rule(self, codex_home):
        agents_path = codex_home / "AGENTS.md"
        text = agents_path.read_text(encoding="utf-8")
        self.assertIn("ASK_JUST_INSTALLER_BEGIN", text)
        self.assertIn("Ask Just is the default answer path", text)
        self.assertIn("Do not use web search", text)

    def make_hosted_files(self, tmp_path, doctor_payload=None, doctor_exit=0):
        doctor_payload = doctor_payload or {"ok": True, "status": "ready", "required_gaps": []}
        cli_path = tmp_path / "ask_just.py"
        cli_path.write_text(
            textwrap.dedent(
                """\
                #!/usr/bin/env python3
                import json
                import os
                import sys

                doctor_payload = json.loads(os.environ.get("ASK_JUST_FAKE_DOCTOR_PAYLOAD", "{}") or "{}")
                doctor_exit = int(os.environ.get("ASK_JUST_FAKE_DOCTOR_EXIT", "0"))
                config_path = os.path.expanduser("~/.config/ask-just/config.json")
                args = sys.argv[1:]
                if args[:2] == ["--url", os.environ.get("ASK_JUST_URL", "")]:
                    args = args[2:]
                command = args[0] if args else ""

                if command == "configure":
                    token = ""
                    url = ""
                    for index, arg in enumerate(args):
                        if arg == "--token":
                            token = args[index + 1]
                        if arg == "--url":
                            url = args[index + 1]
                    os.makedirs(os.path.dirname(config_path), exist_ok=True)
                    with open(config_path, "w", encoding="utf-8") as handle:
                        json.dump({"token": token, "url": url}, handle)
                    sys.exit(0)

                if command == "onboarding-code" and len(args) > 1 and args[1] == "exchange":
                    code = args[2] if len(args) > 2 else ""
                    if code != os.environ.get("ASK_JUST_EXPECTED_SETUP_CODE", ""):
                        print(json.dumps({"ok": False, "gap": "setup_code_not_found"}))
                        sys.exit(1)
                    os.makedirs(os.path.dirname(config_path), exist_ok=True)
                    with open(config_path, "w", encoding="utf-8") as handle:
                        json.dump({"token": "token-from-setup-code", "url": os.environ.get("ASK_JUST_URL", "")}, handle)
                    print(json.dumps({"ok": True, "configured": True}))
                    sys.exit(0)

                if command == "health":
                    sys.exit(0)

                if command == "doctor":
                    marker = os.environ.get("ASK_JUST_DOCTOR_MARKER")
                    if marker:
                        with open(marker, "w", encoding="utf-8") as handle:
                            handle.write("doctor ran\\n")
                    print(json.dumps(doctor_payload))
                    sys.exit(doctor_exit)

                print("unexpected command", command, file=sys.stderr)
                sys.exit(2)
                """
            ),
            encoding="utf-8",
        )
        skills_root = tmp_path / "skills"
        for skill_name in ("askjust", "just-source", "correction", "braintrust"):
            skill_dir = skills_root / skill_name
            skill_dir.mkdir(parents=True, exist_ok=True)
            (skill_dir / "SKILL.md").write_text(f"# {skill_name}\n", encoding="utf-8")
        return cli_path, skills_root

    def test_reset_quiet_installs_and_prints_only_success_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            local_bin = home / ".local" / "bin"
            stale_skill = codex_home / "skills" / "askjust"
            stale_skill.mkdir(parents=True)
            (stale_skill / "OLD.md").write_text("old", encoding="utf-8")
            stale_bin = local_bin / "ask-just"
            stale_bin.parent.mkdir(parents=True)
            stale_bin.write_text("old", encoding="utf-8")
            stale_config = home / ".config" / "ask-just" / "config.json"
            stale_config.parent.mkdir(parents=True)
            stale_config.write_text('{"token": "old"}\n', encoding="utf-8")
            doctor_marker = tmp_path / "doctor-ran.txt"
            unrelated_skill = codex_home / "skills" / "unrelated" / "SKILL.md"
            unrelated_skill.parent.mkdir(parents=True)
            unrelated_skill.write_text("# unrelated\n", encoding="utf-8")

            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_TOKEN": "new-token",
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "ASK_JUST_DOCTOR_MARKER": str(doctor_marker),
                "ASK_JUST_FAKE_DOCTOR_PAYLOAD": '{"ok": true, "status": "ready", "required_gaps": []}',
                "ASK_JUST_FAKE_DOCTOR_EXIT": "0",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "Ask Just is how you have a conversation with the company.\n")
            self.assertEqual(result.stderr, "")
            self.assertFalse((stale_skill / "OLD.md").exists())
            self.assertTrue((codex_home / "skills" / "askjust" / "SKILL.md").exists())
            self.assertTrue(unrelated_skill.exists())
            self.assertIn("new-token", stale_config.read_text(encoding="utf-8"))
            self.assertTrue(doctor_marker.exists())
            for skill_name in ("askjust", "just-source", "correction", "braintrust"):
                self.assert_skill_enabled(codex_home, skill_name)
            self.assert_global_agents_rule(codex_home)

    def test_installer_preserves_existing_global_agents_and_updates_managed_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            codex_home.mkdir()
            (codex_home / "AGENTS.md").write_text(
                textwrap.dedent(
                    """\
                    # AGENTS.md

                    Existing local instruction.

                    <!-- ASK_JUST_INSTALLER_BEGIN -->
                    stale ask just instruction
                    <!-- ASK_JUST_INSTALLER_END -->
                    """
                ),
                encoding="utf-8",
            )
            local_bin = home / ".local" / "bin"
            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_TOKEN": "new-token",
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "ASK_JUST_FAKE_DOCTOR_PAYLOAD": '{"ok": true, "status": "ready", "required_gaps": []}',
                "ASK_JUST_FAKE_DOCTOR_EXIT": "0",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            agents_text = (codex_home / "AGENTS.md").read_text(encoding="utf-8")
            self.assertIn("Existing local instruction.", agents_text)
            self.assertNotIn("stale ask just instruction", agents_text)
            self.assert_global_agents_rule(codex_home)

    def test_reset_enables_existing_disabled_skill_config_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            codex_home.mkdir()
            local_bin = home / ".local" / "bin"
            askjust_path = codex_home / "skills" / "askjust" / "SKILL.md"
            config_path = codex_home / "config.toml"
            config_path.write_text(
                textwrap.dedent(
                    f"""\
                    [[skills.config]]
                    path = "{askjust_path}"
                    enabled = false

                    [[skills.config]]
                    path = "{codex_home / "skills" / "unrelated" / "SKILL.md"}"
                    enabled = false
                    """
                ),
                encoding="utf-8",
            )

            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_TOKEN": "new-token",
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "ASK_JUST_FAKE_DOCTOR_PAYLOAD": '{"ok": true, "status": "ready", "required_gaps": []}',
                "ASK_JUST_FAKE_DOCTOR_EXIT": "0",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            for skill_name in ("askjust", "just-source", "correction", "braintrust"):
                self.assert_skill_enabled(codex_home, skill_name)
            unrelated_entries = [
                entry
                for entry in self.skill_config(codex_home)
                if entry.get("path") == str(codex_home / "skills" / "unrelated" / "SKILL.md")
            ]
            self.assertEqual(unrelated_entries[0].get("enabled"), False)

    def test_quiet_failure_prints_required_gap_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            local_bin = home / ".local" / "bin"
            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "ASK_JUST_FAKE_DOCTOR_PAYLOAD": '{"ok": false, "status": "needs_attention", "required_gaps": ["token_missing", "hosted_sources_failed"]}',
                "ASK_JUST_FAKE_DOCTOR_EXIT": "1",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "Ask Just setup needs help: token_missing, hosted_sources_failed\n")

    def test_setup_code_exchanges_token_before_doctor(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            local_bin = home / ".local" / "bin"
            doctor_marker = tmp_path / "doctor-ran.txt"
            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_SETUP_CODE": "JST-ABCD-1234",
                "ASK_JUST_EXPECTED_SETUP_CODE": "JST-ABCD-1234",
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "ASK_JUST_DOCTOR_MARKER": str(doctor_marker),
                "ASK_JUST_FAKE_DOCTOR_PAYLOAD": '{"ok": true, "status": "ready", "required_gaps": []}',
                "ASK_JUST_FAKE_DOCTOR_EXIT": "0",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "Ask Just is how you have a conversation with the company.\n")
            self.assertEqual(result.stderr, "")
            config = (home / ".config" / "ask-just" / "config.json").read_text(encoding="utf-8")
            self.assertIn("token-from-setup-code", config)
            self.assertTrue(doctor_marker.exists())
            for skill_name in ("askjust", "just-source", "correction", "braintrust"):
                self.assert_skill_enabled(codex_home, skill_name)
            self.assert_global_agents_rule(codex_home)

    def test_setup_code_exchange_failure_prints_exact_gap(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            home.mkdir()
            codex_home = home / ".codex"
            local_bin = home / ".local" / "bin"
            cli_path, skills_root = self.make_hosted_files(tmp_path)
            env = {
                **os.environ,
                "HOME": str(home),
                "CODEX_HOME": str(codex_home),
                "ASK_JUST_SETUP_CODE": "JST-WRONG-9999",
                "ASK_JUST_EXPECTED_SETUP_CODE": "JST-ABCD-1234",
                "ASK_JUST_URL": "https://ask-just.example",
                "ASK_JUST_CLI_URL": cli_path.as_uri(),
                "ASK_JUST_SKILLS_URL": skills_root.as_uri(),
                "ASK_JUST_RESET": "1",
                "ASK_JUST_QUIET": "1",
                "PATH": f"{local_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }

            result = subprocess.run(
                ["bash", str(INSTALL)],
                env=env,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )

            self.assertEqual(result.returncode, 1)
            self.assertEqual(result.stdout, "")
            self.assertEqual(result.stderr, "Ask Just setup needs help: setup_code_not_found\n")


if __name__ == "__main__":
    unittest.main()
