import sqlite3
import tempfile
from pathlib import Path
import unittest

from scripts import backfill_spins_item_rankings
from scripts import build_spins_item_ranking_registry as registry


def make_db():
    tmp = tempfile.TemporaryDirectory()
    db_path = Path(tmp.name) / "source_index.sqlite"
    conn = sqlite3.connect(db_path)
    conn.executescript(backfill_spins_item_rankings.TYPED_SPINS_SCHEMA)
    conn.executemany(
        """
        INSERT INTO spins_item_rankings (
          row_id, source_id, source_file, sheet, row_index, geography, channel,
          time_period, latest_data_ending, category, subcategory, product_type,
          brand, description, upc, rank_value, dollars, units, dollar_velocity,
          unit_velocity, source_locator, source_type, provenance_grain
        ) VALUES (
          :row_id, :source_id, :source_file, :sheet, :row_index, :geography, :channel,
          :time_period, :latest_data_ending, :category, :subcategory, :product_type,
          :brand, :description, :upc, :rank_value, :dollars, :units, :dollar_velocity,
          :unit_velocity, :source_locator, :source_type, :provenance_grain
        )
        """,
        [
            {
                "row_id": "row-1",
                "source_id": "spins_breakfast_powertabs",
                "source_file": "breakfast.xlsb",
                "sheet": "Item",
                "row_index": 17,
                "geography": "KROGER BANNER TOTAL - RMA",
                "channel": "MULO",
                "time_period": "4 Weeks",
                "latest_data_ending": "2026-04-19",
                "category": "REFRIGERATED EGGS",
                "subcategory": "RF EGGS LIQUID",
                "product_type": "RF LIQUID EGGS",
                "brand": "JUST",
                "description": "Just Egg Plant Based Scramble 16 Oz",
                "upc": "01-91011-00127",
                "rank_value": 1.0,
                "dollars": 100.0,
                "units": 20.0,
                "dollar_velocity": 25.0,
                "unit_velocity": 4.3,
                "source_locator": "breakfast.xlsb#row=17",
                "source_type": "local:excel_visible_report_snapshot",
                "provenance_grain": "{\"locator\":\"breakfast.xlsb#row=17\"}",
            },
            {
                "row_id": "row-2",
                "source_id": "spins_breakfast_powertabs",
                "source_file": "breakfast.xlsb",
                "sheet": "Item",
                "row_index": 18,
                "geography": "TOTAL US - NATURAL",
                "channel": "NATURAL",
                "time_period": "4 Weeks",
                "latest_data_ending": "2026-04-19",
                "category": "REFRIGERATED EGGS",
                "subcategory": "RF EGGS LIQUID",
                "product_type": "RF LIQUID EGGS",
                "brand": "COMPETITOR",
                "description": "Competitor Liquid Egg 16 Oz",
                "upc": "00-00000-00000",
                "rank_value": 2.0,
                "dollars": 50.0,
                "units": 12.0,
                "dollar_velocity": 12.0,
                "unit_velocity": 2.0,
                "source_locator": "breakfast.xlsb#row=18",
                "source_type": "local:excel_visible_report_snapshot",
                "provenance_grain": "{\"locator\":\"breakfast.xlsb#row=18\"}",
            },
        ],
    )
    conn.commit()
    conn.close()
    return tmp, db_path


class SpinsItemRankingRegistryTests(unittest.TestCase):
    def test_build_registry_groups_by_slice_and_reports_metrics(self):
        tmp, db_path = make_db()
        self.addCleanup(tmp.cleanup)

        payload = registry.build_registry(db_path)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["slice_count"], 2)
        first = payload["slices"][0]
        self.assertIn(first["channel"], {"MULO", "NATURAL"})
        self.assertEqual(first["source_id"], "spins_breakfast_powertabs")
        self.assertEqual(first["category"], "REFRIGERATED EGGS")
        self.assertIn("unit_velocity", first["available_metrics"])
        self.assertTrue(first["provenance_sample"])


if __name__ == "__main__":
    unittest.main()
