import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import audit_answer_surface


def write_json(path, payload):
    path.write_text(json.dumps(payload), encoding="utf-8")


def hosted_row(source_id, **overrides):
    row = {
        "source_id": source_id,
        "mapped": "yes",
        "accessible": "yes",
        "atomically_queryable": "yes",
    }
    row.update(overrides)
    return row


class AuditAnswerSurfaceTest(unittest.TestCase):
    def test_hosted_inventory_exact_match_passes_without_local_sqlite(self):
        payload = audit_answer_surface.hosted_audit_payload(
            expected_ids=["scorecard_monthly_data"],
            hosted_rows=[hosted_row("scorecard_monthly_data")],
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["inventory_source"], "hosted_ask_just_sources")
        self.assertEqual(payload["active_source_count"], 1)

    def test_hosted_inventory_reports_missing_and_unexpected_source_ids(self):
        payload = audit_answer_surface.hosted_audit_payload(
            expected_ids=["scorecard_monthly_data"],
            hosted_rows=[hosted_row("target_tracker")],
        )

        self.assertFalse(payload["ok"])
        self.assertEqual(
            payload["errors"],
            [
                {
                    "source_id_mismatch": {
                        "missing": ["scorecard_monthly_data"],
                        "unexpected": ["target_tracker"],
                    }
                }
            ],
        )

    def test_hosted_inventory_reports_gate_failures(self):
        payload = audit_answer_surface.hosted_audit_payload(
            expected_ids=["scorecard_monthly_data"],
            hosted_rows=[hosted_row("scorecard_monthly_data", accessible="no")],
        )

        self.assertFalse(payload["ok"])
        self.assertEqual(
            payload["errors"],
            [
                {
                    "hosted_gate_failures": [
                        {
                            "source_id": "scorecard_monthly_data",
                            "gates": {
                                "mapped": "yes",
                                "accessible": "no",
                                "atomically_queryable": "yes",
                            },
                        }
                    ]
                }
            ],
        )

    def test_main_defaults_to_hosted_inventory(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        queryable_path = Path(tmp.name) / "queryable-source-ids.json"
        write_json(queryable_path, ["scorecard_monthly_data"])

        with mock.patch.object(audit_answer_surface, "QUERYABLE_IDS", str(queryable_path)), mock.patch.object(
            audit_answer_surface, "fetch_hosted_rows", return_value=[hosted_row("scorecard_monthly_data")]
        ), mock.patch.object(sys, "argv", ["audit_answer_surface.py"]), redirect_stdout(StringIO()):
            self.assertEqual(audit_answer_surface.main(), 0)
