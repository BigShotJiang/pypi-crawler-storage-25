import importlib
import os
import sys
import types
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class FakeSpan:
    def __init__(self, name, event=None, root_span_id=None):
        self.name = name
        self.event = event or {}
        self.span_id = f"{name}-span"
        self.root_span_id = root_span_id or self.span_id
        self.children = []
        self.logs = []
        self.ended = False

    def start_span(self, name=None, set_current=False, **event):
        child = FakeSpan(name or "child", event=event, root_span_id=self.root_span_id)
        self.children.append(child)
        return child

    def log(self, **event):
        self.logs.append(event)

    def end(self):
        self.ended = True


class FakeLogger:
    def __init__(self):
        self.spans = []
        self.flushed = False

    def start_span(self, name=None, set_current=False, **event):
        span = FakeSpan(name or "root", event=event)
        self.spans.append(span)
        return span

    def flush(self):
        self.flushed = True


class BraintrustTracingTests(unittest.TestCase):
    def setUp(self):
        sys.modules.pop("braintrust_tracing", None)
        self.fake_logger = FakeLogger()
        fake_braintrust = types.SimpleNamespace(
            init_logger=mock.Mock(return_value=self.fake_logger)
        )
        self.module_patcher = mock.patch.dict(sys.modules, {"braintrust": fake_braintrust})
        self.module_patcher.start()
        self.env_patcher = mock.patch.dict(
            os.environ,
            {
                "BRAINTRUST_API_KEY": "test-key",
                "ASK_JUST_BRAINTRUST_PROJECT": "ask-just",
                "ASK_JUST_BRAINTRUST_PROJECT_ID": "project-123",
            },
            clear=False,
        )
        self.env_patcher.start()

    def tearDown(self):
        self.env_patcher.stop()
        self.module_patcher.stop()
        sys.modules.pop("braintrust_tracing", None)

    def test_trace_recorder_returns_trace_metadata_without_blocking_flush(self):
        tracing = importlib.import_module("braintrust_tracing")

        recorder = tracing.start_trace(
            "query",
            {"question": "gross revenue", "source": "scorecard_monthly_data", "trace": True},
            surface="http",
        )
        recorder.event("trace.user_question", output={"question": "gross revenue"})
        metadata = recorder.finish(output={"ok": True, "rows": 2})

        self.assertEqual(metadata["trace_id"], "ask_just.query-span")
        self.assertEqual(metadata["trace_project"], "ask-just")
        self.assertEqual(metadata["trace_project_id"], "project-123")
        self.assertIn("/p/ask-just/trace?", metadata["trace_url"])
        self.assertFalse(self.fake_logger.flushed)
        self.assertEqual(sys.modules["braintrust"].init_logger.call_args.kwargs["async_flush"], True)
        self.assertEqual(self.fake_logger.spans[0].children[0].name, "trace.user_question")

    def test_sync_flush_can_be_enabled_for_debugging(self):
        with mock.patch.dict(os.environ, {"ASK_JUST_BRAINTRUST_SYNC_FLUSH": "1"}, clear=False):
            tracing = importlib.reload(importlib.import_module("braintrust_tracing"))

            recorder = tracing.start_trace("query", {"question": "gross revenue", "trace": True}, surface="http")
            recorder.finish(output={"ok": True})

        self.assertTrue(self.fake_logger.flushed)

    def test_tracing_is_opt_in_for_cli_requests(self):
        tracing = importlib.import_module("braintrust_tracing")

        recorder = tracing.start_trace("query", {"question": "gross revenue"}, surface="http")
        metadata = recorder.finish(output={"ok": True})

        self.assertEqual(metadata, {})
        self.assertFalse(sys.modules["braintrust"].init_logger.called)

    def test_tracing_is_disabled_without_an_api_key(self):
        with mock.patch.dict(os.environ, {"BRAINTRUST_API_KEY": ""}, clear=False):
            tracing = importlib.reload(importlib.import_module("braintrust_tracing"))

            recorder = tracing.start_trace("query", {"q": "revenue", "trace": True}, surface="http")
            metadata = recorder.finish(output={"ok": True})

        self.assertEqual(metadata, {})


if __name__ == "__main__":
    unittest.main()
