import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database as builder
import regenerate_spins_item_ranking_gaps


class RegenerateSpinsItemRankingGapsTest(unittest.TestCase):
    def make_db(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = Path(tmp.name) / "source_index.sqlite"
        conn = sqlite3.connect(db_path)
        builder.create_schema(conn)
        return db_path, conn

    def insert_item_row(self, conn):
        path = Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb")
        item_row = builder.make_spins_item_ranking_row(
            path=path,
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-03T00:00:00Z",
            extracted_at="2026-05-03T01:00:00Z",
            row_index=17,
            fields={
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Average Weekly Units Per Store Selling Per Item": 3.3,
            },
            locator="/tmp/source.xlsb#sheet=Item&row=17",
        )
        universe_row = builder.make_spins_item_ranking_row(
            path=path,
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-03T00:00:00Z",
            extracted_at="2026-05-03T01:00:00Z",
            row_index=18,
            fields={
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Description": "Competitor Liquid Eggs 16 Oz",
                "UPC": "00-00000-00000",
                "Brand": "COMPETITOR",
                "Average Weekly Units Per Store Selling Per Item": 1.0,
                "Average Weekly Dollars Per Store Selling Per Item": 4.0,
            },
            locator="/tmp/source.xlsb#sheet=Item&row=18",
        )
        builder.insert_atomic_row(conn, item_row)
        builder.insert_atomic_row(conn, universe_row)

    def insert_stale_gap_row(self, conn):
        row = {
            "row_id": "stale-gap",
            "source_id": "spins_breakfast_powertabs",
            "source_table": "spins_item_ranking_source_gaps",
            "source_file": "/tmp/stale.xlsb",
            "sheet": "Item",
            "row_index": None,
            "row_key": "stale-gap",
            "row_json": json.dumps(
                {
                    "fields": {
                        "product_key": "stale",
                        "Geography": "STALE",
                        "Channel": "MULO",
                        "Time Period": "4 Weeks",
                        "gap_type": "missing_spins_item_ranking_row",
                    }
                }
            ),
            "search_text": "stale",
            "provenance_grain": json.dumps({"source_id": "spins_breakfast_powertabs"}),
        }
        builder.insert_atomic_row(conn, row)

    def test_regenerates_all_supported_gap_periods_and_backfills_typed_gaps(self):
        db_path, conn = self.make_db()
        self.insert_item_row(conn)
        self.insert_stale_gap_row(conn)
        conn.commit()
        conn.close()

        product = {
            "product_key": "just_egg_pourable_scramble_16oz",
            "source_id": "spins_breakfast_powertabs",
            "family": "just_egg_pourable_scramble",
            "label": "JUST Egg Plant Based Scramble 16 Oz",
            "upcs": ["01-91011-00127"],
        }
        sources = {
            "spins_breakfast_powertabs": {
                "boundary": ["/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb"]
            }
        }
        with mock.patch.object(builder, "spins_goal_products_for_source", return_value=[product]):
            result = regenerate_spins_item_ranking_gaps.regenerate_gap_rows(
                db_path,
                ["spins_breakfast_powertabs"],
                generated_at="2026-05-16T00:00:00Z",
                sources=sources,
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["atomic_gap_rows_deleted"], 1)
        self.assertEqual(result["typed_gap_rows_deleted"], 1)
        self.assertEqual(result["inserted"][0]["item_ranking_source_gap_row_count"], 8)
        self.assertEqual(result["backfill"]["typed_item_ranking_rows"], 2)
        self.assertEqual(result["backfill"]["typed_gap_rows"], 8)

        conn = sqlite3.connect(db_path)
        try:
            periods = {
                row[0]
                for row in conn.execute(
                    """
                    SELECT DISTINCT time_period
                    FROM spins_item_ranking_gaps
                    WHERE source_id = 'spins_breakfast_powertabs'
                    """
                )
            }
            stale_count = conn.execute(
                "SELECT COUNT(*) FROM atomic_rows WHERE row_id = 'stale-gap'"
            ).fetchone()[0]
        finally:
            conn.close()

        self.assertEqual(periods, {"4 Weeks", "12 Weeks", "24 Weeks", "52 Weeks"})
        self.assertEqual(stale_count, 0)


if __name__ == "__main__":
    unittest.main()
