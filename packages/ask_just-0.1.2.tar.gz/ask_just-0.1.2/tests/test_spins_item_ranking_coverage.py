import sqlite3
import tempfile
from pathlib import Path
import unittest

from scripts import backfill_spins_item_rankings
from scripts import build_spins_item_ranking_coverage as coverage


def make_db():
    tmp = tempfile.TemporaryDirectory()
    db_path = Path(tmp.name) / "source_index.sqlite"
    conn = sqlite3.connect(db_path)
    conn.executescript(backfill_spins_item_rankings.TYPED_SPINS_SCHEMA)
    conn.executemany(
        """
        INSERT INTO spins_item_rankings (
          row_id, source_id, source_file, sheet, row_index, geography, channel,
          time_period, latest_data_ending, category, subcategory, product_type,
          brand, description, upc, rank_value, dollars, units, dollar_velocity,
          unit_velocity, is_just_sku, just_sku_family, just_sku_label,
          source_locator, source_type, provenance_grain
        ) VALUES (
          :row_id, :source_id, :source_file, :sheet, :row_index, :geography, :channel,
          :time_period, :latest_data_ending, :category, :subcategory, :product_type,
          :brand, :description, :upc, :rank_value, :dollars, :units, :dollar_velocity,
          :unit_velocity, :is_just_sku, :just_sku_family, :just_sku_label,
          :source_locator, :source_type, :provenance_grain
        )
        """,
        [
            {
                "row_id": "just-liquid-kroger",
                "source_id": "spins_breakfast_powertabs",
                "source_file": "breakfast.xlsb",
                "sheet": "Item",
                "row_index": 17,
                "geography": "KROGER BANNER TOTAL - RMA",
                "channel": "MULO",
                "time_period": "4 Weeks",
                "latest_data_ending": "2026-04-19",
                "category": "REFRIGERATED EGGS",
                "subcategory": "RF EGGS LIQUID",
                "product_type": "RF LIQUID EGGS",
                "brand": "JUST",
                "description": "Just Egg Plant Based Scramble 16 Oz",
                "upc": "01-91011-00127",
                "rank_value": 2.0,
                "dollars": 100.0,
                "units": 20.0,
                "dollar_velocity": 25.0,
                "unit_velocity": 4.3,
                "is_just_sku": 1,
                "just_sku_family": "just_egg_pourable_scramble",
                "just_sku_label": "JUST Egg refrigerated liquid",
                "source_locator": "breakfast.xlsb#row=17",
                "source_type": "local:excel_visible_report_snapshot",
                "provenance_grain": "{\"locator\":\"breakfast.xlsb#row=17\"}",
            },
            {
                "row_id": "competitor-liquid-kroger",
                "source_id": "spins_breakfast_powertabs",
                "source_file": "breakfast.xlsb",
                "sheet": "Item",
                "row_index": 18,
                "geography": "KROGER BANNER TOTAL - RMA",
                "channel": "MULO",
                "time_period": "4 Weeks",
                "latest_data_ending": "2026-04-19",
                "category": "REFRIGERATED EGGS",
                "subcategory": "RF EGGS LIQUID",
                "product_type": "RF LIQUID EGGS",
                "brand": "COMPETITOR",
                "description": "Competitor Liquid Egg 16 Oz",
                "upc": "00-00000-00000",
                "rank_value": 1.0,
                "dollars": 200.0,
                "units": 40.0,
                "dollar_velocity": 35.0,
                "unit_velocity": 5.0,
                "is_just_sku": 0,
                "just_sku_family": None,
                "just_sku_label": None,
                "source_locator": "breakfast.xlsb#row=18",
                "source_type": "local:excel_visible_report_snapshot",
                "provenance_grain": "{\"locator\":\"breakfast.xlsb#row=18\"}",
            },
        ],
    )
    conn.commit()
    conn.close()
    return tmp, db_path


class SpinsItemRankingCoverageTests(unittest.TestCase):
    def test_build_coverage_reports_just_sku_slice_metrics_rank_and_provenance(self):
        tmp, db_path = make_db()
        self.addCleanup(tmp.cleanup)
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        self.addCleanup(conn.close)

        payload = coverage.build_coverage(conn)

        self.assertEqual(payload["schema_version"], 1)
        self.assertEqual(payload["source_ids"], ["spins_breakfast_powertabs"])
        self.assertEqual(len(payload["just_skus"]), 1)
        sku = payload["just_skus"][0]
        self.assertEqual(sku["upc"], "01-91011-00127")
        self.assertEqual(sku["just_sku_family"], "just_egg_pourable_scramble")
        self.assertEqual(sku["slice_count"], 1)
        self.assertEqual(len(payload["slices"]), 1)
        slice_row = payload["slices"][0]
        self.assertEqual(slice_row["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(slice_row["channel"], "MULO")
        self.assertEqual(slice_row["time_period"], "4 Weeks")
        self.assertEqual(slice_row["category"], "REFRIGERATED EGGS")
        self.assertEqual(slice_row["subcategory"], "RF EGGS LIQUID")
        self.assertEqual(slice_row["just_row_count"], 1)
        self.assertEqual(slice_row["competitor_row_count"], 1)
        self.assertIn("unit_velocity", slice_row["available_metrics"])
        self.assertIn("dollar_velocity", slice_row["available_metrics"])
        self.assertTrue(slice_row["rank_available"])
        self.assertEqual(slice_row["provenance_sample"], "{\"locator\":\"breakfast.xlsb#row=17\"}")
        self.assertEqual(payload["coverage_gaps"], [])


if __name__ == "__main__":
    unittest.main()
