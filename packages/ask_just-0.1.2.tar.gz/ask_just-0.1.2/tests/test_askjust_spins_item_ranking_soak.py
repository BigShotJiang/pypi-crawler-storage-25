import importlib.util
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "run_askjust_spins_item_ranking_soak.py"


def load_soak():
    spec = importlib.util.spec_from_file_location("run_askjust_spins_item_ranking_soak", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules["run_askjust_spins_item_ranking_soak"] = module
    spec.loader.exec_module(module)
    return module


class AskJustSpinsItemRankingSoakTests(unittest.TestCase):
    def test_generate_cases_includes_kroger_trap_and_competitor_comparison(self):
        soak = load_soak()

        cases = soak.generate_cases()
        ids = {case["id"] for case in cases}

        self.assertIn("kroger_pourable_l4w_velocity", ids)
        self.assertIn("natural_refrigerated_egg_competitor_ranking", ids)
        self.assertIn("mulo_vs_natural_refrigerated_egg_ranking", ids)
        for case in cases:
            self.assertLessEqual(case["latency_target_seconds"], 20)
            self.assertTrue(case["question"])
            self.assertTrue(case["expect"])

    def test_score_payload_rejects_wrong_geography_and_missing_provenance(self):
        soak = load_soak()
        case = {
            "id": "kroger_pourable_l4w_velocity",
            "expect": {
                "path": "typed_spins_item_rankings",
                "geography": "KROGER BANNER TOTAL - RMA",
                "forbidden_geographies": ["KROGER RULER - RMA"],
                "metric": "unit_velocity",
                "approx_value": 4.3,
                "tolerance": 0.06,
                "min_rows": 1,
                "require_provenance": True,
            },
            "latency_target_seconds": 20,
        }
        payload = {
            "ok": True,
            "path": "typed_spins_item_rankings",
            "rows": [
                {
                    "geography": "KROGER RULER - RMA",
                    "unit_velocity": 1.6667,
                }
            ],
        }

        result = soak.score_payload(case, payload, latency_seconds=0.1)

        self.assertFalse(result["ok"])
        self.assertIn("wrong_geography", result["failure_clusters"])
        self.assertIn("forbidden_geography", result["failure_clusters"])
        self.assertIn("missing_provenance", result["failure_clusters"])


if __name__ == "__main__":
    unittest.main()
