import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import backfill_spins_item_rankings


class BackfillSpinsItemRankingsTest(unittest.TestCase):
    def make_atomic_db(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        return db_path, conn

    def insert_atomic_row(self, conn, row_id, source_table, fields):
        conn.execute(
            """
            INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                row_id,
                "spins_breakfast_powertabs",
                source_table,
                "SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsx",
                "Item",
                15,
                row_id,
                json.dumps({"fields": fields}),
                " ".join(str(value) for value in fields.values()),
                json.dumps(
                    {
                        "source_id": "spins_breakfast_powertabs",
                        "source_type": "workbook",
                        "locator": f"Item!{row_id}",
                    }
                ),
            ),
        )

    def test_backfills_typed_tables_from_existing_atomic_rows(self):
        db_path, conn = self.make_atomic_db()
        self.insert_atomic_row(
            conn,
            "row-just-egg-wegmans",
            "spins_item_ranking_rows",
            {
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": "$60,218.37",
                "Units": "8,116",
                "velocity_units_per_store_per_week": "18.625",
                "velocity_dollars_per_store_per_week": "$138.12",
            },
        )
        self.insert_atomic_row(
            conn,
            "gap-just-folded-wegmans",
            "spins_item_ranking_source_gaps",
            {
                "product_key": "just_egg_folded_8oz",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row", "velocity_units_per_store_per_week"],
            },
        )
        conn.commit()
        conn.close()

        result = backfill_spins_item_rankings.backfill(db_path, ["spins_breakfast_powertabs"])

        self.assertTrue(result["ok"])
        self.assertEqual(result["atomic_rows_scanned"], 2)
        self.assertEqual(result["typed_item_ranking_rows"], 1)
        self.assertEqual(result["typed_gap_rows"], 1)

        conn = sqlite3.connect(db_path)
        row = conn.execute(
            """
            SELECT geography, upc, dollars, units, unit_velocity
            FROM spins_item_rankings
            WHERE row_id = 'row-just-egg-wegmans'
            """
        ).fetchone()
        gap = conn.execute(
            """
            SELECT product_key, gap_type
            FROM spins_item_ranking_gaps
            WHERE row_id = 'gap-just-folded-wegmans'
            """
        ).fetchone()
        conn.close()

        self.assertEqual(row, ("WEGMANS CORP W/O METRO NY - RMA", "01-91011-00127", 60218.37, 8116.0, 18.625))
        self.assertEqual(gap, ("just_egg_folded_8oz", "missing_spins_item_ranking_row"))

    def test_typed_spins_schema_has_comparison_indexes(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "source_index.sqlite"
            conn = sqlite3.connect(db_path)
            try:
                conn.executescript(backfill_spins_item_rankings.TYPED_SPINS_SCHEMA)
                indexes = {
                    row[0]
                    for row in conn.execute(
                        "select name from sqlite_master where type='index' and tbl_name='spins_item_rankings'"
                    )
                }
            finally:
                conn.close()

        self.assertIn("idx_spins_item_rankings_category_metric_slice", indexes)
        self.assertIn("idx_spins_item_rankings_brand_category_slice", indexes)
        self.assertIn("idx_spins_item_rankings_product_type_slice", indexes)


if __name__ == "__main__":
    unittest.main()
