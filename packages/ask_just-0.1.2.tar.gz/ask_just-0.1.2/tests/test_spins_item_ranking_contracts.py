import json
from pathlib import Path
import unittest

from scripts import spins_item_ranking_contracts as contracts


ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = ROOT / "config" / "spins-item-ranking-contracts.json"


class SpinsItemRankingContractsConfigTests(unittest.TestCase):
    def test_contract_file_defines_required_contracts(self):
        data = json.loads(CONTRACTS.read_text(encoding="utf-8"))
        contract_ids = {contract["contract_id"] for contract in data["contracts"]}

        self.assertEqual(data["schema_version"], 1)
        self.assertEqual(data["latency_target_seconds"], 20)
        self.assertEqual(
            {
                "spins_item_velocity",
                "spins_item_ranking",
                "spins_competitor_ranking",
                "spins_channel_comparison",
                "spins_retailer_comparison",
                "spins_period_comparison",
                "spins_source_gap",
            }
            - contract_ids,
            set(),
        )

    def test_each_contract_declares_route_metric_and_provenance_rules(self):
        data = json.loads(CONTRACTS.read_text(encoding="utf-8"))
        required_keys = {
            "contract_id",
            "label",
            "question_family",
            "required_resolver_fields",
            "allowed_source_ids",
            "required_table",
            "metric_fields",
            "answer_shape",
            "provenance_required",
            "latency_target_seconds",
            "refusal_rule",
            "golden_examples",
        }
        for contract in data["contracts"]:
            self.assertEqual(required_keys - set(contract), set(), contract["contract_id"])
            self.assertEqual(contract["required_table"], "spins_item_rankings")
            self.assertTrue(contract["golden_examples"], contract["contract_id"])
            self.assertTrue(contract["provenance_required"], contract["contract_id"])


class SpinsItemRankingResolverTests(unittest.TestCase):
    def test_resolver_maps_kroger_to_banner_total_not_ruler(self):
        resolved = contracts.resolve_question("what is just pourable velocity at kroger in the last 4 weeks")

        self.assertEqual(resolved["contract_id"], "spins_item_velocity")
        self.assertEqual(resolved["source_id"], "spins_breakfast_powertabs")
        self.assertEqual(resolved["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(resolved["channel"], "MULO")
        self.assertEqual(resolved["time_period"], "4 Weeks")
        self.assertEqual(resolved["product_key"], "just_egg_pourable_scramble_16oz")
        self.assertEqual(resolved["metric"], "unit_velocity")
        self.assertIn("KROGER RULER - RMA", resolved["forbidden_geographies"])

    def test_resolver_maps_explicit_kroger_ruler_to_ruler(self):
        resolved = contracts.resolve_question("what is just pourable velocity at kroger ruler in the last 4 weeks")

        self.assertEqual(resolved["geography"], "KROGER RULER - RMA")
        self.assertEqual(resolved["requested_geography"], "kroger ruler")

    def test_resolver_preserves_explicit_upc(self):
        resolved = contracts.resolve_question(
            "what is UPC 01-91011-00149 velocity for breakfast skillet at kroger in the last 4 weeks"
        )

        self.assertEqual(resolved["contract_id"], "spins_item_velocity")
        self.assertEqual(resolved["upc"], "01-91011-00149")
        self.assertEqual(resolved["time_period"], "4 Weeks")

    def test_resolver_ignores_upc_digits_when_resolving_period(self):
        resolved = contracts.resolve_question(
            "what is UPC 01-91011-00127 velocity for just egg at publix in the last 4 weeks"
        )

        self.assertEqual(resolved["upc"], "01-91011-00127")
        self.assertEqual(resolved["time_period"], "4 Weeks")

    def test_resolver_ignores_package_size_when_resolving_period(self):
        resolved = contracts.resolve_question(
            "what is UPC 01-91011-00153 velocity for Just Original Ranch 12 Oz at Hy-Vee mulo last 4 weeks"
        )

        self.assertEqual(resolved["time_period"], "4 Weeks")

    def test_resolver_maps_natural_competitor_ranking(self):
        resolved = contracts.resolve_question("top natural refrigerated egg competitors by unit velocity")

        self.assertEqual(resolved["contract_id"], "spins_competitor_ranking")
        self.assertEqual(resolved["source_id"], "spins_breakfast_powertabs")
        self.assertEqual(resolved["channel"], "NATURAL")
        self.assertEqual(resolved["category"], "REFRIGERATED EGGS")
        self.assertEqual(resolved["metric"], "unit_velocity")
        self.assertTrue(resolved["competitor_only"])

    def test_resolver_maps_mulo_vs_natural_channel_comparison(self):
        resolved = contracts.resolve_question("compare mulo and natural refrigerated egg rankings")

        self.assertEqual(resolved["contract_id"], "spins_channel_comparison")
        self.assertEqual(resolved["source_id"], "spins_breakfast_powertabs")
        self.assertEqual(resolved["category"], "REFRIGERATED EGGS")
        self.assertEqual(resolved["channels"], ["MULO", "NATURAL"])

    def test_validate_velocity_payload_requires_expected_metric_and_provenance(self):
        resolved = contracts.resolve_question("what is just pourable velocity at kroger in the last 4 weeks")
        payload = {
            "ok": True,
            "path": "typed_spins_item_rankings",
            "rows": [
                {
                    "description": "Just Egg Plant Based Scramble 16 Oz",
                    "geography": "KROGER BANNER TOTAL - RMA",
                    "channel": "MULO",
                    "time_period": "4 Weeks",
                    "unit_velocity": 4.3,
                    "provenance_grain": "{\"locator\":\"fixture#row=17\"}",
                }
            ],
        }

        result = contracts.validate_payload(resolved, payload)

        self.assertTrue(result["ok"], result)
        self.assertEqual(result["answer_shape"], "direct_metric_with_scope_and_row_provenance")

    def test_validate_velocity_payload_rejects_wrong_geography(self):
        resolved = contracts.resolve_question("what is just pourable velocity at kroger in the last 4 weeks")
        payload = {
            "ok": True,
            "path": "typed_spins_item_rankings",
            "rows": [
                {
                    "description": "Just Egg Plant Based Scramble 16 Oz",
                    "geography": "KROGER RULER - RMA",
                    "channel": "MULO",
                    "time_period": "4 Weeks",
                    "unit_velocity": 1.6667,
                    "provenance_grain": "{\"locator\":\"fixture#row=24334\"}",
                }
            ],
        }

        result = contracts.validate_payload(resolved, payload)

        self.assertFalse(result["ok"])
        self.assertIn("forbidden_geography", result["errors"])


if __name__ == "__main__":
    unittest.main()
