import json
import os
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http
from onboarding_codes import OnboardingCodeRegistry


class ServeHttpOnboardingTest(unittest.TestCase):
    def make_server(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute("CREATE TABLE sources (id INTEGER)")
        conn.commit()
        conn.close()
        with open(status_path, "w", encoding="utf-8") as handle:
            json.dump({}, handle)
        service = serve_http.AskJustService(db_path, status_path)
        registry = OnboardingCodeRegistry(
            os.path.join(tmp.name, "codes.json"),
            now=lambda: 1000.0,
            code_generator=lambda: "JST-ABCD-1234",
        )
        handler = serve_http.make_handler(service, token="shared-token", onboarding_registry=registry)
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        return f"http://127.0.0.1:{server.server_address[1]}"

    def post_json(self, url, payload, token=None):
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            return response.status, json.loads(response.read().decode("utf-8"))

    def test_admin_creates_code_and_teammate_exchanges_without_existing_token(self):
        base_url = self.make_server()

        status, created = self.post_json(
            f"{base_url}/onboarding-codes",
            {"label": "Pri setup", "ttl_hours": 24},
            token="shared-token",
        )
        exchange_status, exchanged = self.post_json(
            f"{base_url}/onboarding/exchange",
            {"code": created["code"]},
        )

        self.assertEqual(status, 201)
        self.assertEqual(created["code"], "JST-ABCD-1234")
        self.assertEqual(created["label"], "Pri setup")
        self.assertEqual(exchange_status, 200)
        self.assertEqual(exchanged["token"], "shared-token")
        self.assertTrue(exchanged["ok"])

    def test_create_requires_authorized_token(self):
        base_url = self.make_server()

        with self.assertRaises(urllib.error.HTTPError) as raised:
            self.post_json(f"{base_url}/onboarding-codes", {"label": "Pri setup"})

        self.assertEqual(raised.exception.code, 401)
        raised.exception.close()


if __name__ == "__main__":
    unittest.main()
