import json
import os
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import urlopen


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http
import build_fresh_source_database as builder


def provenance(locator, as_of="2026-05-04T11:54:54Z"):
    return json.dumps(
        {
            "source_id": "scorecard_monthly_data",
            "source_type": "live_app:scorecard",
            "grain_type": "application/record/field",
            "grain_id": "scorecard_monthly_data:test:7:gross_margin",
            "locator": locator,
            "as_of": as_of,
        }
    )


class ServeHttpHealthTest(unittest.TestCase):
    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        for table in (
            "sources",
            "source_files",
            "source_units",
            "source_chunks",
            "atomic_rows",
            "atomic_rows_fts",
            "receipts",
            "verification_questions",
            "gaps",
        ):
            conn.execute(f"CREATE TABLE {table} (id INTEGER)")
        for table, count in {
            "sources": 2,
            "source_files": 3,
            "atomic_rows": 5,
            "atomic_rows_fts": 5,
            "receipts": 7,
            "gaps": 11,
        }.items():
            conn.executemany(f"INSERT INTO {table} (id) VALUES (?)", [(i,) for i in range(count)])
        conn.commit()
        conn.close()
        with open(status_path, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "source_count": 99,
                    "source_file_count": 99,
                    "atomic_row_count": 99,
                    "external_answer_artifacts_used": False,
                    "db_path": "stale/status/path.sqlite",
                },
                handle,
            )
        return tmp, serve_http.AskJustService(db_path, status_path)

    def test_health_is_fast_readiness_without_deep_mode(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        health = service.health(deep=False)["health"]

        self.assertEqual(health["health_mode"], "ready")
        self.assertEqual(health["source_count"], 2)
        self.assertNotIn("source_file_count", health)
        self.assertNotIn("atomic_row_count", health)
        self.assertNotIn("atomic_row_fts_count", health)
        self.assertIn("cheap readiness health", health["health_note"])

    def test_deep_health_uses_live_sqlite_counts(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        health = service.health(deep=True)["health"]

        self.assertEqual(health["health_mode"], "deep")
        self.assertEqual(health["source_count"], 2)
        self.assertEqual(health["source_file_count"], 3)
        self.assertEqual(health["atomic_row_count"], 5)
        self.assertEqual(health["atomic_row_fts_count"], 5)
        self.assertEqual(health["receipt_count"], 7)
        self.assertEqual(health["backlog_gap_count"], 11)

    def test_summary_uses_live_sqlite_counts(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        summary = service.summary()

        self.assertEqual(summary["source_count"], 2)
        self.assertEqual(summary["source_file_count"], 3)
        self.assertEqual(summary["atomic_row_count"], 5)
        self.assertEqual(summary["atomic_row_fts_count"], 5)
        self.assertEqual(summary["receipt_count"], 7)
        self.assertEqual(summary["backlog_gap_count"], 11)

    def test_public_skill_endpoint_serves_allowlisted_skill_only(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        handler = serve_http.make_handler(service, token="secret")
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base_url = f"http://127.0.0.1:{server.server_address[1]}"

        with urlopen(f"{base_url}/skills/askjust/SKILL.md", timeout=5) as response:
            body = response.read().decode("utf-8")

        self.assertEqual(response.status, 200)
        self.assertIn("name: askjust", body)
        self.assertIn("Hide retrieval mechanics by default", body)
        self.assertIn("Do not narrate tool exploration", body)

        with self.assertRaises(HTTPError) as raised:
            urlopen(f"{base_url}/skills/not-real/SKILL.md", timeout=5)

        self.assertEqual(raised.exception.code, 404)
        raised.exception.close()

    def test_kpi_uses_materialized_scorecard_table(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE scorecard_monthly_metrics (
              metric TEXT NOT NULL,
              month TEXT NOT NULL,
              short_month TEXT,
              record_index INTEGER NOT NULL,
              value REAL,
              weeks INTEGER,
              row_key TEXT NOT NULL,
              provenance_locator TEXT NOT NULL,
              as_of TEXT NOT NULL,
              fetched_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            INSERT INTO scorecard_monthly_metrics
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "gross_margin",
                "Mar '26",
                "Mar 26",
                7,
                15.9,
                4,
                "Mar '26:gross_margin",
                "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin",
                "2026-05-04T11:54:54Z",
                "2026-05-04T11:54:54Z",
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.kpi("gross_margin")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "materialized_scorecard_monthly_metrics")
        self.assertEqual(payload["source_id"], "scorecard_monthly_data")
        self.assertEqual(payload["metric"], "gross_margin")
        self.assertEqual(payload["month"], "Mar '26")
        self.assertEqual(payload["value"], 15.9)
        self.assertEqual(payload["provenance"]["locator"], "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin")
        self.assertEqual(payload["as_of"], "2026-05-04T11:54:54Z")

    def test_kpi_falls_back_to_scorecard_atomic_rows(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        locator = "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin"
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "scorecard_monthly_data:test:7:gross_margin",
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "https://just-scorecard.vercel.app/api/read-data?key=monthly_data",
                None,
                7,
                "Mar '26:gross_margin",
                json.dumps(
                    {
                        "metric": "gross_margin",
                        "month": "Mar '26",
                        "short_month": "Mar 26",
                        "record_index": 7,
                        "value": 15.9,
                        "weeks": 4,
                        "row_key": "Mar '26:gross_margin",
                        "fetched_at": "2026-05-04T11:54:54Z",
                    }
                ),
                "gross_margin Mar '26",
                provenance(locator),
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.kpi("gross_margin")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "atomic_rows_scorecard_fallback")
        self.assertEqual(payload["source_id"], "scorecard_monthly_data")
        self.assertEqual(payload["row_key"], "Mar '26:gross_margin")
        self.assertEqual(payload["value"], 15.9)
        self.assertEqual(payload["provenance"]["locator"], locator)

    def test_ops_kpi_uses_materialized_scorecard_ops_table(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE scorecard_ops_metrics (
              group_name TEXT NOT NULL,
              group_index INTEGER NOT NULL,
              metric_name TEXT NOT NULL,
              metric_index INTEGER NOT NULL,
              field_key TEXT NOT NULL,
              value REAL,
              row_key TEXT NOT NULL,
              provenance_locator TEXT NOT NULL,
              as_of TEXT NOT NULL,
              fetched_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            INSERT INTO scorecard_ops_metrics
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "Upstream Inventory",
                1,
                "Protein on Hold (MT)",
                2,
                "mar",
                46,
                "Upstream Inventory:Protein on Hold (MT):mar",
                "https://just-scorecard.vercel.app/api/read-data?key=ops_metrics#group=1&row=2&field=mar",
                "2026-05-04T11:54:54Z",
                "2026-05-04T11:54:54Z",
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.ops_kpi("Protein on Hold (MT)", "mar")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "materialized_scorecard_ops_metrics")
        self.assertEqual(payload["source_id"], "scorecard_ops_metrics")
        self.assertEqual(payload["group"], "Upstream Inventory")
        self.assertEqual(payload["metric"], "Protein on Hold (MT)")
        self.assertEqual(payload["field"], "mar")
        self.assertEqual(payload["value"], 46)

    def make_spins_service(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        builder.create_schema(conn)
        conn.commit()
        conn.close()
        return tmp, serve_http.AskJustService(db_path, status_path)

    def insert_spins_atomic_row(self, service, row_id, source_table, fields, source_type="workbook", source_id="spins_breakfast_powertabs"):
        conn = sqlite3.connect(service.db_path)
        builder.insert_atomic_row(
            conn,
            {
                "row_id": row_id,
                "source_id": source_id,
                "source_table": source_table,
                "source_file": "SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsx",
                "sheet": "Item",
                "row_index": 15,
                "row_key": row_id,
                "row_json": json.dumps({"fields": fields}),
                "search_text": " ".join(str(value) for value in fields.values()),
                "provenance_grain": json.dumps(
                    {
                        "source_id": source_id,
                        "source_type": source_type,
                        "grain_type": "visible_item_ranking_row",
                        "locator": f"Item!{row_id}",
                    }
                ),
            },
        )
        conn.commit()
        conn.close()

    def insert_workbook_atomic_row(self, service, row):
        conn = sqlite3.connect(service.db_path)
        builder.insert_atomic_row(conn, row)
        conn.commit()
        conn.close()

    def whole_foods_workbook_row(self, source_id, row_id, sheet, cells):
        return {
            "row_id": row_id,
            "source_id": source_id,
            "source_table": "workbook_rows",
            "source_file": "WHO-cube, (JUST EGG, 2026.04.19).xlsx",
            "sheet": sheet,
            "row_index": 42,
            "row_key": row_id,
            "row_json": json.dumps(
                {
                    "workbook": "WHO-cube, (JUST EGG, 2026.04.19).xlsx",
                    "sheet": sheet,
                    "row_index": 42,
                    "cells": [
                        {"address": f"{column}42", "column_letter": column, "value": value}
                        for column, value in cells.items()
                    ],
                }
            ),
            "search_text": " ".join(str(value) for value in cells.values() if value is not None),
            "provenance_grain": json.dumps(
                {
                    "source_id": source_id,
                    "source_type": "local:xlsx_workbook_snapshot",
                    "grain_type": "workbook/sheet/row/column/cell",
                    "locator": f"WHO-cube, (JUST EGG, 2026.04.19).xlsx#sheet={sheet}&row=42",
                }
            ),
        }

    def test_spins_ranking_blocks_when_required_just_sku_gap_exists(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "TOTAL US - MULO",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-liquid-16oz",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["row", "velocity_units_per_store_per_week", "velocity_dollars_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-competitor",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Egglands Best Liquid Egg Whites 64 Oz",
                "UPC": "07-15141-93070",
                "Brand": "EGGLANDS BEST",
                "Dollars": 323489,
                "Units": 47032,
                "velocity_units_per_store_per_week": 20.3,
                "velocity_dollars_per_store_per_week": 139.6,
            },
        )

        payload = service.spins_ranking(
            geography="TOTAL US - MULO",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertFalse(payload["ok"])
        self.assertFalse(payload["complete"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["rows"], [])
        self.assertEqual(len(payload["blocking_gaps"]), 1)
        self.assertEqual(payload["blocking_gaps"][0]["product_key"], "just_egg_pourable_scramble_16oz")
        self.assertIn("JUST Egg Plant Based Scramble 16 Oz", payload["error"])

    def test_spins_ranking_returns_rows_when_required_just_sku_is_present(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "FROZEN BREAKFAST FOODS",
            "Subcategory": "FZ BREAKFAST ENTREES",
        }
        self.insert_spins_atomic_row(
            service,
            "row-just-folded",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "Dollars": 4393472,
                "Units": 673866,
                "velocity_units_per_store_per_week": 4.9,
                "velocity_dollars_per_store_per_week": 29.5,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-competitor",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Applegate Farms Chkn Ssg Frittata Bites 8.4 Oz",
                "UPC": "00-25317-31411",
                "Brand": "APPLEGATE FARMS",
                "Dollars": 2332453,
                "Units": 235598,
                "velocity_units_per_store_per_week": 3.1,
                "velocity_dollars_per_store_per_week": 19.6,
            },
        )

        payload = service.spins_ranking(
            geography="SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            order_by="dollars",
        )

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual([row["description"] for row in payload["rows"]], [
            "Just Folded Eggs From Plants 8 Oz",
            "Applegate Farms Chkn Ssg Frittata Bites 8.4 Oz",
        ])
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.9)

    def test_spins_ranking_present_visible_row_overrides_missing_row_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "FROZEN BREAKFAST FOODS",
            "Subcategory": "FZ BREAKFAST ENTREES",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-folded",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_folded_8oz",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row", "velocity_units_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-folded-visible",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "Dollars": 1948380.42,
                "Units": 335126.5,
                "velocity_units_per_store_per_week": 4.9,
            },
        )

        payload = service.spins_ranking(
            geography="SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            order_by="unit_velocity",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["blocking_gaps"], [])
        self.assertEqual(payload["rows"][0]["description"], "Just Folded Eggs From Plants 8 Oz")

    def test_spins_ranking_prefers_visible_snapshot_rows_for_exact_slice(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "row-egglands-cache",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Egglands Best Liquid Egg Whites 32oz",
                "UPC": "07-15141-11369",
                "Brand": "EGGLANDS BEST",
                "Dollars": 5128.64,
                "velocity_units_per_store_per_week": 7.7,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-visible",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 345083.52,
                "velocity_units_per_store_per_week": 6.225,
                "velocity_dollars_per_store_per_week": 45.6064,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.spins_ranking(
            geography="TOTAL US - NATURAL EXPANDED CHANNEL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="unit_velocity",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(len(payload["rows"]), 1)
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 6.225)

    def test_spins_ranking_does_not_block_dollars_rank_on_unneeded_dollar_velocity_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-dollar-velocity",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_required_velocity_metric",
                "missing_fields": ["velocity_dollars_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-egg",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "JUST Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 144098,
                "Units": 23746,
                "velocity_units_per_store_per_week": 4.2,
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"], [])
        self.assertEqual(payload["rows"][0]["description"], "JUST Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.2)

    def test_spins_ranking_blocks_dollar_velocity_rank_on_dollar_velocity_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-dollar-velocity",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_required_velocity_metric",
                "missing_fields": ["velocity_dollars_per_store_per_week"],
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollar_velocity",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_required_velocity_metric")
        self.assertEqual(payload["blocking_gaps"][0]["source_gap_id"], "missing_spins_measure")

    def test_spins_ranking_blocks_when_required_answer_metric_is_null_on_present_row(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "row-just-egg",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "JUST Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.2,
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_required_answer_metric")
        self.assertEqual(payload["blocking_gaps"][0]["source_gap_id"], "missing_spins_measure")
        self.assertIn("Dollars", payload["blocking_gaps"][0]["missing_fields"])

    def test_spins_velocity_returns_exact_typed_sku_slice(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "wegmans-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 60218.37,
                "Units": 8116,
                "velocity_units_per_store_per_week": 18.625,
                "velocity_dollars_per_store_per_week": 138.1155275229358,
            },
        )

        payload = service.spins_velocity(
            geography="WEGMANS CORP W/O METRO NY - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            product_key="just_egg_pourable_scramble_16oz",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 18.625)

    def test_spins_velocity_resolves_human_retailer_and_just_egg_shorthand(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "kroger-banner-total-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
        )

        payload = service.spins_velocity(
            geography="Kroger",
            channel="MULO",
            time_period="4 Weeks",
            description="Just Egg",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["requested_geography"], "Kroger")
        self.assertEqual(payload["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.3)

    def test_query_routes_plain_just_egg_kroger_velocity_to_spins_velocity(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "kroger-banner-total-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
        )

        payload = service.search("what is the Just Egg velocity in Kroger")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["requested_geography"], "Kroger")
        self.assertEqual(payload["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.3)
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "spins_item_ranking_contract")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], "spins_breakfast_powertabs")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "fail_closed_no_prose_fallback")

    def test_query_routes_kroger_pourable_to_banner_total_contract(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "kroger-banner-total-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "kroger-ruler-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER RULER - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 1.6667,
            },
        )

        payload = service.search("what is just pourable velocity at kroger in the last 4 weeks")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.3)
        self.assertEqual(payload["answer_shape_validation"]["ok"], True)
        self.assertEqual(payload["routing_decision"]["adapter"], "spins_item_ranking_contract")

    def test_query_routes_natural_refrigerated_egg_competitors_to_typed_ranking(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "natural-just-row",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - NATURAL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Rank": 2.0,
                "velocity_units_per_store_per_week": 4.0,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "natural-competitor-row",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - NATURAL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Competitor Liquid Egg 16 Oz",
                "UPC": "00-00000-00000",
                "Brand": "COMPETITOR",
                "Rank": 1.0,
                "velocity_units_per_store_per_week": 5.0,
            },
        )

        payload = service.search("top natural refrigerated egg competitors by unit velocity")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["channel"], "NATURAL")
        self.assertEqual(payload["rows"][0]["brand"], "COMPETITOR")
        self.assertNotEqual(payload["rows"][0]["brand"], "JUST")

    def test_full_channel_ranking_uses_all_geographies_slicer_universe(self):
        _tmp, service = self.make_spins_service()
        for row_id, rank, description, brand, dollars, velocity in (
            ("all-natural-just", 8.0, "Just Egg Plant Based Scramble 16 Oz", "JUST", 345083.52, 6.225),
            ("all-natural-competitor", 2.0, "Competitor Liquid Egg 16 Oz", "COMPETITOR", 800000.0, 7.5),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": "(All)",
                    "Channel": "NATURAL",
                    "Time Period": "4 Weeks",
                    "Category": "REFRIGERATED EGGS",
                    "Subcategory": "RF EGGS LIQUID",
                    "Brand": brand,
                    "Description": description,
                    "UPC": "01-91011-00127" if brand == "JUST" else "00-00000-00000",
                    "Rank": rank,
                    "Dollars": dollars,
                    "Average Weekly Units Per Store Selling Per Item": velocity,
                    "velocity_units_per_store_per_week": velocity,
                },
                source_type="local:excel_visible_report_snapshot",
            )

        payload = service.search("top natural refrigerated egg competitors by unit velocity")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "(All)")
        self.assertEqual(payload["slicer_universe"]["Geography"], "(All)")
        self.assertEqual(payload["slicer_universe"]["Channel"], "NATURAL")
        self.assertEqual(payload["slicer_universe"]["Time Period"], "4 Weeks")
        self.assertEqual(payload["slicer_universe"]["Category"], "REFRIGERATED EGGS")
        self.assertEqual(payload["slicer_universe"]["Subcategory"], "RF EGGS LIQUID")
        self.assertEqual(payload["slicer_universe"]["Brand"], "(All)")
        self.assertEqual(payload["slicer_universe"]["Measure"], "Average Weekly Units Per Store Selling Per Item")
        self.assertEqual(payload["rows"][0]["brand"], "COMPETITOR")

    def test_full_channel_ranking_reports_all_even_when_snapshot_uses_legacy_total_label(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "legacy-natural-competitor",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Brand": "COMPETITOR",
                "Description": "Competitor Liquid Egg 16 Oz",
                "UPC": "00-00000-00000",
                "Rank": 2.0,
                "Dollars": 800000.0,
                "Average Weekly Units Per Store Selling Per Item": 7.5,
                "velocity_units_per_store_per_week": 7.5,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.search("top natural refrigerated egg competitors by unit velocity")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "(All)")
        self.assertEqual(payload["data_geography"], "TOTAL US - NATURAL EXPANDED CHANNEL")
        self.assertEqual(payload["slicer_universe"]["Geography"], "(All)")
        self.assertEqual(payload["rows"][0]["geography"], "TOTAL US - NATURAL EXPANDED CHANNEL")
        self.assertEqual(payload["answer_shape_validation"]["ok"], True)

    def test_full_channel_ranking_prefers_legacy_total_rows_over_all_geography_gap(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "legacy-mulo-liquid",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - MULO",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Brand": "COMPETITOR",
                "Description": "Competitor Liquid Egg 16 Oz",
                "UPC": "00-00000-00000",
                "Rank": 1.0,
                "Dollars": 800000.0,
                "Average Weekly Units Per Store Selling Per Item": 7.5,
                "velocity_units_per_store_per_week": 7.5,
            },
            source_type="local:excel_visible_report_snapshot",
        )
        self.insert_spins_atomic_row(
            service,
            "all-mulo-gap",
            "spins_item_ranking_source_gaps",
            {
                "Geography": "(All)",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "product_key": "just_egg_folded_8oz",
                "family": "just_egg_folded",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row"],
                "required_metrics": ["unit_velocity"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "all-mulo-other-category",
            "spins_item_ranking_rows",
            {
                "Geography": "(All)",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN BREAKFAST FOODS",
                "Subcategory": "FZ BREAKFAST ENTREES",
                "Brand": "OTHER",
                "Description": "Other Category Item 8 Oz",
                "UPC": "00-00000-11111",
                "Rank": 1.0,
                "Dollars": 1.0,
                "Average Weekly Units Per Store Selling Per Item": 1.0,
                "velocity_units_per_store_per_week": 1.0,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.spins_ranking(
            source_id="spins_breakfast_powertabs",
            geography="(All)",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="unit_velocity",
            required_product_keys=[],
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "(All)")
        self.assertEqual(payload["data_geography"], "TOTAL US - MULO")
        self.assertEqual(payload["rows"][0]["geography"], "TOTAL US - MULO")

    def test_spins_ranking_preserves_workbook_rank_and_labels_derived_sort(self):
        _tmp, service = self.make_spins_service()
        for row_id, workbook_rank, description, dollars in (
            ("rank-10-high-dollars", 10.0, "Higher Dollar Item 8 Oz", 1000.0),
            ("rank-3-lower-dollars", 3.0, "Lower Dollar Item 8 Oz", 100.0),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": "(All)",
                    "Channel": "MULO",
                    "Time Period": "4 Weeks",
                    "Category": "FROZEN BREAKFAST FOODS",
                    "Subcategory": "FZ BREAKFAST ENTREES",
                    "Brand": "JUST" if workbook_rank == 10.0 else "COMPETITOR",
                    "Description": description,
                    "UPC": f"00-00000-0000{int(workbook_rank)}",
                    "Rank": workbook_rank,
                    "Dollars": dollars,
                    "Average Weekly Units Per Store Selling Per Item": 1.0,
                    "velocity_units_per_store_per_week": 1.0,
                },
                source_type="local:excel_visible_report_snapshot",
            )

        payload = service.spins_ranking(
            source_id="spins_breakfast_powertabs",
            geography="(All)",
            channel="MULO",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            order_by="dollars",
            required_product_keys=[],
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["rows"][0]["description"], "Higher Dollar Item 8 Oz")
        self.assertEqual(payload["rows"][0]["rank"], 10.0)
        self.assertEqual(payload["rows"][0]["derived_rank"], 1)
        self.assertEqual(payload["rows"][0]["rank_source"], "workbook_rank_column")
        self.assertEqual(payload["ranking_basis"], "derived_sort:dollars")

    def test_rank_question_returns_clearly_labeled_derived_rank_when_workbook_rank_is_unavailable(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "sprouts-just-meat-derived-only",
            "spins_item_ranking_rows",
            {
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "Subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "Brand": "JUST",
                "Description": "Just Meat Plant Based Chicken 8 Oz",
                "UPC": "01-91011-00188",
                "Dollars": 38372.54,
                "Average Weekly Units Per Store Selling Per Item": 3.3,
                "velocity_units_per_store_per_week": 3.3,
            },
            source_type="local:xlsb_decoded_pivot_cache",
            source_id="spins_plant_based_meat_powertabs",
        )

        payload = service.search("what is just meat ranking at sprouts in the category")

        self.assertTrue(payload["ok"], payload)
        self.assertFalse(payload["blocked"], payload)
        self.assertEqual(payload["rank_answer_status"], "derived_rank_clearly_labeled")
        self.assertEqual(payload["answer_shape_validation"]["errors"], [])
        self.assertEqual(payload["rows"][0]["rank_source"], "derived_sort:unit_velocity")
        self.assertEqual(payload["rows"][0]["rank"], 1)

    def test_combined_channel_payload_is_labeled_as_combined_not_mulo_or_natural(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "combined-channel-just-folded",
            "spins_item_ranking_rows",
            {
                "Geography": "(All)",
                "Channel": "(All)",
                "Time Period": "4 Weeks",
                "Category": "FROZEN BREAKFAST FOODS",
                "Subcategory": "FZ BREAKFAST ENTREES",
                "Brand": "JUST",
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Rank": 3.0,
                "Dollars": 1000.0,
                "Average Weekly Units Per Store Selling Per Item": 4.9,
                "velocity_units_per_store_per_week": 4.9,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.search("rank frozen breakfast entrees across mulo and natural combined")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["channel"], "(All)")
        self.assertEqual(payload["slicer_universe"]["Channel"], "(All)")
        self.assertEqual(payload["slicer_universe"]["Channel Label"], "MULO and NATURAL combined")

    def test_competitor_category_query_does_not_resolve_to_just_sku_velocity(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "natural-breakfast-skillet",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "FROZEN APPETIZERS & SNACKS",
                "Subcategory": "FZ BURRITOS & POCKETS",
                "Description": "Just Breakfast Skillet Burrito 5.5 Oz",
                "UPC": "01-91011-00149",
                "Brand": "JUST",
                "Rank": 2.0,
                "velocity_units_per_store_per_week": 1.5,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "natural-breakfast-competitor",
            "spins_item_ranking_rows",
            {
                "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "FROZEN APPETIZERS & SNACKS",
                "Subcategory": "FZ BURRITOS & POCKETS",
                "Description": "Competitor Breakfast Burrito 5.5 Oz",
                "UPC": "00-00000-00149",
                "Brand": "COMPETITOR",
                "Rank": 1.0,
                "velocity_units_per_store_per_week": 7.5,
            },
        )

        payload = service.search("top natural frozen appetizers and snacks competitors by unit velocity")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["spins_item_ranking_contract"]["contract_id"], "spins_competitor_ranking")
        self.assertEqual(payload["category"], "FROZEN APPETIZERS & SNACKS")
        self.assertEqual(payload["rows"][0]["brand"], "COMPETITOR")

    def test_query_uses_explicit_upc_for_exact_spins_sku_slice(self):
        _tmp, service = self.make_spins_service()
        for row_id, description, upc, velocity in (
            ("skillet-kroger", "Just Breakfast Skillet Burrito 5.5 Oz", "01-91011-00149", 1.0),
            ("chili-kroger", "Just Egg Chili Crisp Breakfast Burrito Ogc 5.5 Oz", "01-91011-00150", 2.0),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": "KROGER BANNER TOTAL - RMA",
                    "Channel": "MULO",
                    "Time Period": "4 Weeks",
                    "Category": "FROZEN APPETIZERS & SNACKS",
                    "Subcategory": "FZ BURRITOS & POCKETS",
                    "Description": description,
                    "UPC": upc,
                    "Brand": "JUST",
                    "velocity_units_per_store_per_week": velocity,
                },
            )

        payload = service.search(
            "what is UPC 01-91011-00150 velocity for Just Egg Chili Crisp Breakfast Burrito Ogc 5.5 Oz "
            "at KROGER BANNER TOTAL - RMA mulo last 4 weeks"
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["spins_item_ranking_contract"]["upc"], "01-91011-00150")
        self.assertEqual(payload["rows"][0]["upc"], "01-91011-00150")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 2.0)

    def test_query_does_not_filter_exact_upc_to_unrelated_visible_snapshot(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "pivot-skillet-kroger",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN APPETIZERS & SNACKS",
                "Subcategory": "FZ BURRITOS & POCKETS",
                "Description": "Just Breakfast Skillet Burrito 5.5 Oz",
                "UPC": "01-91011-00149",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 1.0,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "visible-liquid-kroger",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.search(
            "what is UPC 01-91011-00149 velocity for Just Breakfast Skillet Burrito 5.5 Oz "
            "at KROGER BANNER TOTAL - RMA mulo last 4 weeks"
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["rows"][0]["upc"], "01-91011-00149")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 1.0)

    def test_query_routes_mulo_vs_natural_refrigerated_egg_comparison(self):
        _tmp, service = self.make_spins_service()
        for channel, geography, row_id, velocity in (
            ("MULO", "TOTAL US - MULO", "mulo-just-row", 6.1),
            ("NATURAL", "TOTAL US - NATURAL", "natural-just-row", 4.0),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": geography,
                    "Channel": channel,
                    "Time Period": "4 Weeks",
                    "Category": "REFRIGERATED EGGS",
                    "Subcategory": "RF EGGS LIQUID",
                    "Description": "Just Egg Plant Based Scramble 16 Oz",
                    "UPC": "01-91011-00127",
                    "Brand": "JUST",
                    "Rank": 1.0,
                    "velocity_units_per_store_per_week": velocity,
                },
            )

        payload = service.search("compare mulo and natural refrigerated egg rankings")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["routing_decision"]["adapter"], "spins_item_ranking_contract")
        self.assertEqual({row["channel"] for row in payload["rows"]}, {"MULO", "NATURAL"})
        self.assertEqual(payload["answer_shape_validation"]["ok"], True)

    def test_query_resolves_just_sku_from_typed_item_ranking_rows(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "publix-just-mayo",
            "spins_item_ranking_rows",
            {
                "Geography": "PUBLIX CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "CONDIMENTS",
                "Subcategory": "MAYONNAISE",
                "Description": "Just Mayo Original 12 Oz",
                "UPC": "01-91011-00001",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 3.2,
            },
            source_id="spins_condiments_powertabs",
        )

        payload = service.search("what is just mayo velocity at publix last 4 weeks")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["source_id"], "spins_condiments_powertabs")
        self.assertEqual(payload["geography"], "PUBLIX CORP - RMA")
        self.assertEqual(payload["rows"][0]["description"], "Just Mayo Original 12 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 3.2)

    def test_query_resolves_retailer_from_typed_item_ranking_rows(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "fresh-market-just-mayo",
            "spins_item_ranking_rows",
            {
                "Geography": "THE FRESH MARKET - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "CONDIMENTS",
                "Subcategory": "MAYONNAISE",
                "Description": "Just Mayo Original 12 Oz",
                "UPC": "01-91011-00001",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 2.4,
            },
            source_id="spins_condiments_powertabs",
        )

        payload = service.search("what is just mayo velocity at fresh market last 4 weeks")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "THE FRESH MARKET - RMA")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 2.4)

    def test_query_resolves_just_sku_velocity_before_category_ranking(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "walmart-just-meat",
            "spins_item_ranking_rows",
            {
                "Geography": "WALMART CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "Subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "Description": "Just Meat Plant Based Chicken 8 Oz",
                "UPC": "01-91011-00420",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 2.875,
            },
            source_id="spins_plant_based_meat_powertabs",
        )
        self.insert_spins_atomic_row(
            service,
            "walmart-competitor-meat",
            "spins_item_ranking_rows",
            {
                "Geography": "WALMART CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "Subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "Description": "Competitor Plant Based Chicken 8 Oz",
                "UPC": "00-00000-00420",
                "Brand": "COMPETITOR",
                "velocity_units_per_store_per_week": 7.0,
            },
            source_id="spins_plant_based_meat_powertabs",
        )
        self.insert_spins_atomic_row(
            service,
            "walmart-just-buffalo-meat",
            "spins_item_ranking_rows",
            {
                "Geography": "WALMART CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "Subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "Description": "Just Meat Plant Based Buffalo Chicken 8 Oz",
                "UPC": "01-91011-00421",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 1.525,
            },
            source_id="spins_plant_based_meat_powertabs",
        )

        payload = service.search("what is just meat plant based chicken velocity at walmart last 4 weeks")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["spins_item_ranking_contract"]["contract_id"], "spins_item_velocity")
        self.assertEqual(payload["rows"][0]["description"], "Just Meat Plant Based Chicken 8 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 2.875)

    def test_query_resolves_spins_velocity_across_all_declared_just_product_families(self):
        _tmp, service = self.make_spins_service()
        cases = [
            {
                "row_id": "kroger-liquid",
                "source_id": "spins_breakfast_powertabs",
                "geography": "KROGER BANNER TOTAL - RMA",
                "category": "REFRIGERATED EGGS",
                "subcategory": "RF EGGS LIQUID",
                "description": "JUST Egg Plant Based Scramble 16 Oz",
                "upc": "01-91011-00127",
                "query": "what is just egg liquid velocity at kroger last 4 weeks",
                "velocity": 4.3,
            },
            {
                "row_id": "walmart-folded",
                "source_id": "spins_breakfast_powertabs",
                "geography": "WALMART CORP - RMA",
                "category": "FROZEN BREAKFAST FOODS",
                "subcategory": "FZ BREAKFAST ENTREES",
                "description": "Just Folded Eggs From Plants 8 Oz",
                "upc": "01-91011-00087",
                "query": "what is just egg folded velocity at walmart last 4 weeks",
                "velocity": 2.7,
            },
            {
                "row_id": "publix-burrito",
                "source_id": "spins_breakfast_powertabs",
                "geography": "PUBLIX CORP - RMA",
                "category": "FROZEN BREAKFAST FOODS",
                "subcategory": "FZ BREAKFAST ENTREES",
                "description": "Just Breakfast Skillet Burrito 5.5 Oz",
                "upc": "01-91011-00149",
                "query": "what is just breakfast skillet burrito velocity at publix last 4 weeks",
                "velocity": 1.6,
            },
            {
                "row_id": "sprouts-meat",
                "source_id": "spins_plant_based_meat_powertabs",
                "geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "channel": "NATURAL",
                "category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "description": "Just Meat Plant Based Chicken 8 Oz",
                "upc": "01-91011-00188",
                "query": "what is just meat plant based chicken velocity at sprouts last 4 weeks",
                "velocity": 3.3,
            },
            {
                "row_id": "publix-ranch",
                "source_id": "spins_condiments_powertabs",
                "geography": "PUBLIX CORP - RMA",
                "category": "CONDIMENTS",
                "subcategory": "SALAD DRESSING",
                "description": "Just Original Ranch 12 Oz",
                "upc": "01-91011-00153",
                "query": "what is just original ranch velocity at publix last 4 weeks",
                "velocity": 0.9,
            },
            {
                "row_id": "walmart-protein",
                "source_id": "spins_protein_powder_powertabs",
                "geography": "WALMART CORP - RMA",
                "category": "PROTEIN POWDER",
                "subcategory": "PLANT BASED PROTEIN POWDER",
                "description": "Just One Vanilla & Chai Plant Based Protein Powder 12 Oz",
                "upc": "01-91011-00200",
                "query": "what is just one vanilla chai protein powder velocity at walmart last 4 weeks",
                "velocity": 0.4,
            },
        ]
        for case in cases:
            self.insert_spins_atomic_row(
                service,
                case["row_id"],
                "spins_item_ranking_rows",
                {
                    "Geography": case["geography"],
                    "Channel": case.get("channel", "MULO"),
                    "Time Period": "4 Weeks",
                    "Category": case["category"],
                    "Subcategory": case["subcategory"],
                    "Description": case["description"],
                    "UPC": case["upc"],
                    "Brand": "JUST",
                    "velocity_units_per_store_per_week": case["velocity"],
                },
                source_id=case["source_id"],
            )

        for case in cases:
            with self.subTest(query=case["query"]):
                payload = service.search(case["query"])
                self.assertTrue(payload["ok"], payload)
                self.assertEqual(payload["path"], "typed_spins_item_rankings")
                self.assertEqual(payload["source_id"], case["source_id"])
                self.assertEqual(payload["geography"], case["geography"])
                self.assertEqual(payload["channel"], case.get("channel", "MULO"))
                self.assertEqual(payload["time_period"], "4 Weeks")
                self.assertEqual(payload["slicer_universe"]["Geography"], case["geography"])
                self.assertEqual(payload["slicer_universe"]["Channel"], case.get("channel", "MULO"))
                self.assertEqual(
                    payload["slicer_universe"]["Measure"],
                    "Average Weekly Units Per Store Selling Per Item",
                )
                self.assertEqual(payload["rows"][0]["description"], case["description"])
                self.assertEqual(payload["rows"][0]["unit_velocity"], case["velocity"])
                self.assertTrue(payload["rows"][0]["provenance_grain"])

    def test_query_returns_folded_and_liquid_velocities_for_publix(self):
        _tmp, service = self.make_spins_service()
        for row_id, description, upc, subcategory, velocity in (
            (
                "publix-liquid",
                "Just Egg Plant Based Scramble 16 Oz",
                "01-91011-00127",
                "RF EGGS LIQUID",
                4.2,
            ),
            (
                "publix-folded",
                "Just Folded Eggs From Plants 8 Oz",
                "01-91011-00087",
                "FZ BREAKFAST ENTREES",
                1.425,
            ),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": "PUBLIX CORP - RMA",
                    "Channel": "MULO",
                    "Time Period": "4 Weeks",
                    "Category": "FROZEN BREAKFAST FOODS" if "Folded" in description else "REFRIGERATED EGGS",
                    "Subcategory": subcategory,
                    "Description": description,
                    "UPC": upc,
                    "Brand": "JUST",
                    "velocity_units_per_store_per_week": velocity,
                },
            )

        payload = service.search("what is just egg velocity at publix, both folded and liquid")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["spins_item_ranking_contract"]["contract_id"], "spins_multi_item_velocity")
        rows_by_upc = {row["upc"]: row for row in payload["rows"]}
        self.assertEqual(rows_by_upc["01-91011-00127"]["unit_velocity"], 4.2)
        self.assertEqual(rows_by_upc["01-91011-00087"]["unit_velocity"], 1.425)

    def test_query_routes_explicit_folded_velocity_to_folded_sku(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "publix-liquid",
            "spins_item_ranking_rows",
            {
                "Geography": "PUBLIX CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.2,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "publix-folded",
            "spins_item_ranking_rows",
            {
                "Geography": "PUBLIX CORP - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "FROZEN BREAKFAST FOODS",
                "Subcategory": "FZ BREAKFAST ENTREES",
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 1.425,
            },
        )

        payload = service.search("what is JUST Egg folded velocity at Publix in the last 4 weeks")

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["spins_item_ranking_contract"]["product_key"], "just_egg_folded_8oz")
        self.assertEqual(payload["rows"][0]["upc"], "01-91011-00087")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 1.425)

    def test_query_resolves_long_spins_retailer_name_for_known_sku(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "shaws-just-egg-12w",
            "spins_item_ranking_rows",
            {
                "Geography": "AC - ALBERTSONSCO SHAWS DIV W/ STAR MARKET - RMA",
                "Channel": "MULO",
                "Time Period": "12 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.8125,
            },
        )

        payload = service.search(
            "what is Just Egg Plant Based Scramble 16 Oz velocity at "
            "AC - ALBERTSONSCO SHAWS DIV W/ STAR MARKET - RMA mulo last 12 weeks"
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "AC - ALBERTSONSCO SHAWS DIV W/ STAR MARKET - RMA")
        self.assertEqual(payload["time_period"], "12 Weeks")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.8125)

    def test_query_resolves_full_kroger_geography_without_banner_alias_collapse(self):
        _tmp, service = self.make_spins_service()
        for row_id, geography, velocity in (
            ("kroger-banner-skillet", "KROGER BANNER TOTAL - RMA", 1.0),
            (
                "kroger-full-skillet",
                "KROGER CORP W/ HARRIS TEETER, ROUNDYS AND RULER - RMA",
                0.9,
            ),
        ):
            self.insert_spins_atomic_row(
                service,
                row_id,
                "spins_item_ranking_rows",
                {
                    "Geography": geography,
                    "Channel": "MULO",
                    "Time Period": "12 Weeks",
                    "Category": "FROZEN APPETIZERS & SNACKS",
                    "Subcategory": "FZ BURRITOS & POCKETS",
                    "Description": "Just Breakfast Skillet Burrito 5.5 Oz",
                    "UPC": "01-91011-00149",
                    "Brand": "JUST",
                    "velocity_units_per_store_per_week": velocity,
                },
            )

        payload = service.search(
            "what is Just Breakfast Skillet Burrito 5.5 Oz velocity at "
            "KROGER CORP W/ HARRIS TEETER, ROUNDYS AND RULER - RMA mulo last 12 weeks"
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["geography"], "KROGER CORP W/ HARRIS TEETER, ROUNDYS AND RULER - RMA")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 0.9)

    def test_spins_velocity_reports_gap_for_missing_exact_sku_slice(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "wegmans-folded-gap",
            "spins_item_ranking_source_gaps",
            {
                "product_key": "just_egg_folded_8oz",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row", "velocity_units_per_store_per_week"],
            },
        )

        payload = service.spins_velocity(
            geography="WEGMANS CORP W/O METRO NY - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            product_key="just_egg_folded_8oz",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_spins_item_ranking_row")
        self.assertEqual(payload["blocking_gaps"][0]["source_gap_id"], "missing_spins_sku_slice")
        self.assertEqual(payload["source_gap_id"], "missing_spins_sku_slice")

    def test_spins_velocity_ignores_multiple_upcs_as_exact_upc_filter(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "sprouts-just-meat-exact-upc",
            "spins_item_ranking_rows",
            {
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Category": "FROZEN PLANT BASED MEAT ALTERNATIVES",
                "Subcategory": "FZ PLANT BASED NUGGETS & STRIPS & CUTLETS",
                "Description": "Just Meat Plant Based Chicken 8 Oz",
                "UPC": "01-91011-00188",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 3.3,
            },
            source_id="spins_plant_based_meat_powertabs",
        )

        payload = service.spins_velocity(
            source_id="spins_plant_based_meat_powertabs",
            geography="SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            channel="NATURAL",
            time_period="4 Weeks",
            upc="Multiple UPCs",
            description="Just Meat Plant Based Chicken 8 Oz",
        )

        self.assertTrue(payload["ok"], payload)
        self.assertEqual(payload["rows"][0]["upc"], "01-91011-00188")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 3.3)

    def test_whole_foods_us_velocity_materializes_period_data_row(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_us_who_cube_2026_04_19",
                "whole-foods-us-period-data-liquid",
                "Period DATA",
                {
                    "B": "Florida",
                    "C": "Grocery Dairy-Refrigerated Plant Based Protein",
                    "D": "Breakfast",
                    "E": "Other",
                    "F": "EAT JUST",
                    "G": "0019101100127 EGG LIQUID PLANT BASED 16 OZ",
                    "H": "0019101100127",
                    "J": "16 OZ",
                    "K": "Last 04 Weeks",
                    "L": 16545.68,
                    "N": 2166,
                    "P": 35,
                    "R": 35,
                    "T": 1,
                    "V": "Liquid Egg 16oz",
                    "W": 4,
                },
            ),
        )

        payload = service.whole_foods_us_velocity(
            period="Last 04 Weeks",
            region="Florida",
            item="EGG LIQUID PLANT BASED",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_velocity")
        self.assertEqual(payload["source_id"], "whole_foods_us_who_cube_2026_04_19")
        self.assertEqual(payload["rows"][0]["upc"], "0019101100127")
        self.assertAlmostEqual(payload["rows"][0]["unit_velocity"], 2166 / 35 / 4)

    def test_whole_foods_canada_question_does_not_route_to_us_velocity(self):
        params = serve_http._whole_foods_us_velocity_question_params(
            "what is whole foods canada just egg liquid velocity",
            "all",
        )

        self.assertIsNone(params)

    def test_whole_foods_canada_rl_upsw_materializes_velocity_rows(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-liquid",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50816334,
                    "B": "JUST EGG PLANT LIQ",
                    "C": 580.40,
                    "D": 64,
                    "E": 5.818182,
                    "F": 52.763636,
                    "G": 1000,
                    "H": "1280 STEELES AVE E",
                    "I": "MILTON",
                    "J": "ON",
                },
            ),
        )
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-folded",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50835048,
                    "B": "JUST PLANT EGG",
                    "C": 291.00,
                    "D": 37,
                    "E": 3.4,
                    "F": 26.47,
                    "G": 3076,
                    "H": "3939 ROCHDALE BLVD",
                    "I": "REGINA",
                    "J": "SK",
                },
            ),
        )

        liquid = service.whole_foods_canada_velocity(product_key="liquid")
        folded = service.search("what is just egg folded velocity in whole foods canada")

        self.assertTrue(liquid["ok"])
        self.assertEqual(liquid["path"], "typed_whole_foods_canada_rl_upsw")
        self.assertEqual(liquid["rows"][0]["product_label"], "JUST Egg Liquid / Pourable")
        self.assertAlmostEqual(liquid["rows"][0]["unit_velocity"], 5.818182)
        self.assertEqual(folded["product_key"], "folded")
        self.assertEqual(folded["rows"][0]["product_label"], "JUST Egg Patty / Folded")
        self.assertEqual(folded["routing_decision"]["route_shape"], "structured")
        self.assertEqual(folded["routing_decision"]["adapter"], "whole_foods_canada_velocity")
        self.assertEqual(folded["routing_decision"]["selected_source_lane"], "whole_foods_canada_just_egg_rl_upsw")
        self.assertEqual(folded["routing_decision"]["fallback_policy"], "fail_closed_no_prose_fallback")

    def test_whole_foods_canada_unqualified_just_egg_velocity_defaults_to_liquid(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-liquid",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50816334,
                    "B": "JUST EGG PLANT LIQ",
                    "C": 580.40,
                    "D": 64,
                    "E": 5.818182,
                    "F": 52.763636,
                    "G": 1000,
                    "H": "1280 STEELES AVE E",
                    "I": "MILTON",
                    "J": "ON",
                },
            ),
        )
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-folded",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50835048,
                    "B": "JUST PLANT EGG",
                    "C": 291.00,
                    "D": 37,
                    "E": 9.4,
                    "F": 26.47,
                    "G": 3076,
                    "H": "3939 ROCHDALE BLVD",
                    "I": "REGINA",
                    "J": "SK",
                },
            ),
        )

        payload = service.search("what is just egg velocity in canada whole foods")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["adapter"], "whole_foods_canada_velocity")
        self.assertEqual(payload["product_key"], "liquid")
        self.assertEqual(payload["rows"][0]["product_label"], "JUST Egg Liquid / Pourable")

    def test_whole_foods_canada_store_sales_orders_by_total_sales(self):
        _tmp, service = self.make_spins_service()
        for row_id, store_number, city, item, sales, qty, units_per_store, dollars_per_store in [
            ("liquid-low", 1000, "MILTON", "JUST EGG PLANT LIQ", 100.0, 10, 1.0, 10.0),
            ("folded-low", 1000, "MILTON", "JUST PLANT EGG", 150.0, 15, 1.5, 15.0),
            ("liquid-high", 3109, "VICTORIA", "JUST EGG PLANT LIQ", 1000.0, 100, 10.0, 100.0),
            ("folded-high", 3109, "VICTORIA", "JUST PLANT EGG", 900.0, 90, 9.0, 90.0),
        ]:
            self.insert_workbook_atomic_row(
                service,
                self.whole_foods_workbook_row(
                    "whole_foods_canada_just_egg_rl_upsw",
                    f"whole-foods-canada-{row_id}",
                    "mj1ws46_109331306_6E64B3A8X9680",
                    {
                        "A": 50816334 if "LIQ" in item else 50835048,
                        "B": item,
                        "C": sales,
                        "D": qty,
                        "E": units_per_store,
                        "F": dollars_per_store,
                        "G": store_number,
                        "H": "address",
                        "I": city,
                        "J": "BC" if city == "VICTORIA" else "ON",
                    },
                ),
            )

        payload = service.search("what store has highest sales for all just products in whole foods canada")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_canada_rl_upsw")
        self.assertEqual(payload["rows"][0]["store_number"], "3109")
        self.assertAlmostEqual(payload["rows"][0]["pos_sales"], 1900.0)
        self.assertEqual(payload["rows"][0]["sku_count"], 2)

    def test_whole_foods_us_store_sales_materializes_summary_row(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_us_who_cube_2026_04_19",
                "whole-foods-us-store-sales-westbury",
                "Store Sales",
                {
                    "B": 2,
                    "C": "NE - Westbury - 10706",
                    "D": 2,
                    "E": 12670.92,
                    "F": 14296.81,
                    "G": -11.37,
                    "H": 1055.91,
                    "I": 1191.40,
                    "J": 1,
                    "K": 1742,
                    "L": 2040,
                    "M": -14.61,
                    "N": 145.17,
                    "O": 170,
                    "P": 7.27,
                    "Q": 7.01,
                },
            ),
        )

        payload = service.whole_foods_us_store_sales(order_by="units")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_store_sales")
        self.assertEqual(payload["rows"][0]["store_id"], "10706")
        self.assertEqual(payload["rows"][0]["region_code"], "NE")
        self.assertEqual(payload["rows"][0]["unit_rank"], 1)
        self.assertAlmostEqual(payload["rows"][0]["units_per_week"], 145.17)

    def test_whole_foods_us_store_sales_filters_just_meat_from_store_item_tabs(self):
        _tmp, service = self.make_spins_service()
        for row_id, sheet, store, original, buffalo in [
            ("units-altamonte", "By Store Units", "FL - Altamonte Springs - 10516", 85, 39),
            ("units-bayhill", "By Store Units", "FL - Bayhill - 10194", 10, 8),
            ("dollars-altamonte", "By Store Dollars", "FL - Altamonte Springs - 10516", 550.26, 243.64),
            ("dollars-bayhill", "By Store Dollars", "FL - Bayhill - 10194", 67.68, 56.62),
        ]:
            self.insert_workbook_atomic_row(
                service,
                self.whole_foods_workbook_row(
                    "whole_foods_us_who_cube_2026_04_19",
                    f"whole-foods-us-{row_id}",
                    sheet,
                    {
                        "B": 1,
                        "C": store,
                        "P": original,
                        "Q": buffalo,
                    },
                ),
            )

        payload = service.whole_foods_us_store_sales(segment="Plant Based Chicken", order_by="dollars")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_store_item_sales")
        self.assertEqual(payload["rows"][0]["store"], "FL - Altamonte Springs - 10516")
        self.assertEqual(payload["rows"][0]["sku_count"], 2)
        self.assertAlmostEqual(payload["rows"][0]["dollar_sales"], 793.90)
        self.assertAlmostEqual(payload["rows"][0]["units"], 124)

    def test_whole_foods_store_sales_question_routes_just_meat_segment(self):
        params = serve_http._whole_foods_us_store_sales_question_params(
            "show me top whole foods store sales for just meat by dollars",
            "all",
        )

        self.assertEqual(params["segment"], "Plant Based Chicken")
        self.assertEqual(params["order_by"], "dollars")
        self.assertEqual(params["period"], "Latest 12 Weeks")


if __name__ == "__main__":
    unittest.main()
