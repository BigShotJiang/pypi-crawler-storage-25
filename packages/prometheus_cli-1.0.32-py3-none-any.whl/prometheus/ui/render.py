"""Render tool receipts and result panels for the chat log."""
from __future__ import annotations

from rich.console import Group, RenderableType
from rich.markdown import Markdown
from rich.text import Text

from prometheus.tools.base import ToolResult
from prometheus.ui.theme import (
    AMBER,
    ASSISTANT_INK,
    DIM,
    ERROR,
    GLYPH_COLLAPSE,
    GLYPH_EXPAND,
    GLYPH_RECEIPT,
    INK,
    MUTED,
    SUCCESS,
    USER_INK,
)

# Round-23: Claude-Code parity — `●` is a steady-state status glyph
# (NOT animated). Three colors:
#   • running  → dim (not used in receipt_summary_line, which only
#                fires AFTER tool completion)
#   • success  → green
#   • error    → red
# Anthropic explicitly does not pulse the dot — the spinner runs on
# its own row to avoid the v0.2.69 flicker class (issue #769).
GLYPH_CONTINUATION = "⎿"


def receipt_line(label: str) -> Text:
    """A single ⏺ receipt header line. Always amber, no clutter."""
    t = Text()
    t.append(GLYPH_RECEIPT + " ", style=AMBER)
    t.append(label, style=AMBER)
    return t


def receipt_summary_line(label: str, summary: str, line_count: int = 0, error: bool = False, denied: bool = False):
    """Round-27 Claude-parity receipt: header line + `⎿` continuation.

    Five dot color states (matches Anthropic's documented behavior):
      • dim/grey  — running / pending-execution (rendered by activity
                    line during in-flight; not used here since this
                    fires AFTER completion)
      • yellow    — in-progress (long-running tool actively producing;
                    used when summary indicates progress not finality)
      • green     — success (the default after a clean tool result)
      • red       — error (exit non-zero or thrown)
      • pink      — denied / user-rejected (denial is NOT the same as
                    error — the user pivoted; the model treats it as a
                    redirect signal, not a retry trigger)

    No `· suffix` on the header — every outcome lives in the
    continuation row. This matches Anthropic's documented behavior
    (Bash tool docs + tool rejection issues #36321 / #29499 / #23699).
    """
    from rich.style import Style
    from rich.console import Group as _Group
    label = _strip_ansi(label or "")
    summary = _strip_ansi(summary or "")[:200]
    if len(label) > 80:
        label = label[:48] + "…" + label[-28:]
    # Round-27: distinguish denied from error. Denied gets pink/magenta
    # so the user can tell at a glance: red = something broke, pink =
    # user said no. Heuristic: if `summary` contains "(denied)" or
    # "user doesn't want to proceed", treat as denial.
    denied = denied or (
        "(denied)" in summary.lower()
        or "doesn't want to proceed" in summary.lower()
        or "user denied" in summary.lower()
    )
    if denied:
        dot_style = "magenta"
    elif error:
        dot_style = ERROR
    else:
        dot_style = SUCCESS
    head = Text()
    head.append(GLYPH_RECEIPT + " ", style=dot_style)
    # Detect path-shaped label suffixes like "Read foo.py" / "Edit src/x.go"
    # and hyperlink the last whitespace-delimited token if it resolves.
    parts = label.rsplit(" ", 1)
    if len(parts) == 2 and parts[1] and ("." in parts[1] or "/" in parts[1] or "\\" in parts[1]):
        from pathlib import Path as _P
        verb, tail = parts
        try:
            p = _P(tail)
            if not p.is_absolute():
                p = (_P.cwd() / p)
            uri = p.resolve().as_uri() if p.exists() else None
        except Exception:
            uri = None
        head.append(verb + " ", style=AMBER)
        if uri:
            head.append(tail, style=Style(color=AMBER, link=uri))
        else:
            head.append(tail, style=AMBER)
    else:
        head.append(label, style=AMBER)
    if not summary:
        return head
    # Continuation row (⎿) — outcome lives here, never on the header.
    cont = Text()
    cont.append("  " + GLYPH_CONTINUATION + " ", style=DIM)
    cont.append(summary, style=ERROR if error else DIM)
    return _Group(head, cont)


# Round-96/96.1: regex matchers for "useful" lines vs "noise" in bash
# output. The compact filter keeps useful lines (success/failure
# markers, error tracebacks, tool result summaries) and drops noise
# (pytest progress dots, deprecation warnings spanning many lines).
import re as _re_filter

_BASH_USEFUL_PATTERNS = [
    _re_filter.compile(r"\d+\s+passed", _re_filter.IGNORECASE),
    _re_filter.compile(r"\d+\s+failed", _re_filter.IGNORECASE),
    _re_filter.compile(r"\d+\s+error", _re_filter.IGNORECASE),
    _re_filter.compile(r"\d+\s+skipped", _re_filter.IGNORECASE),
    _re_filter.compile(r"\bFAILED\b"),
    _re_filter.compile(r"\bPASSED\b"),
    _re_filter.compile(r"\bERROR\b"),
    _re_filter.compile(r"\btest result:", _re_filter.IGNORECASE),
    _re_filter.compile(r"^ok\s+\S+\s+[\d.]+s", _re_filter.MULTILINE),
    _re_filter.compile(r"\bTraceback\b"),
    _re_filter.compile(r"^Error:", _re_filter.MULTILINE),
    _re_filter.compile(r"^E\s+\w", _re_filter.MULTILINE),  # pytest error indent
]

# Round-96.1 enhanced: warning-block detection.
# Lines that LOOK like a Python warning header (file:line: WarningClass:)
# OR like the inside of a deprecation warning block. Both get suppressed
# from the compact view AND counted so the receipt can show
# "1 warning hidden · use /verbose or /details last to view".
_WARNING_HEAD_RX = _re_filter.compile(
    r"\.py:\d+:\s*\w*Warning\b",
)
_WARNING_BODY_HINT_RX = _re_filter.compile(
    r"^\s+\S",  # leading whitespace (continuation of indented block)
)

_BASH_NOISE_PATTERNS = [
    # pytest progress dots: "..............." or with percentage
    _re_filter.compile(r"^[.\sFsx]+(\[\s*\d+%\])?\s*$"),
    # pytest deprecation warning indentation (kept for completeness;
    # the new warning-block logic in filter_bash_output_compact is the
    # primary path for these).
    _re_filter.compile(r"^\s+warnings\.warn\("),
    _re_filter.compile(r"^\s*The event loop scope for asynchronous"),
    _re_filter.compile(r"^\s*pytest-asyncio will default the loop"),
    _re_filter.compile(r"^\s*will default the loop scope"),
    # plain whitespace
    _re_filter.compile(r"^\s*$"),
]


def count_warning_blocks(lines: list[str]) -> int:
    """Round-96.1: count Python warning blocks in the output.

    A "warning block" starts on a line matching `\\.py:\\d+:\\s*\\w*Warning`
    and continues through subsequent indented continuation lines until
    a non-indented / blank line. We use this count to surface a
    "N warnings hidden" row on the compact receipt without leaking
    the verbose warning text into the chat.
    """
    if not lines:
        return 0
    n = 0
    in_block = False
    for line in lines:
        if _WARNING_HEAD_RX.search(line):
            n += 1
            in_block = True
            continue
        if in_block:
            # Continuation if the line is indented OR blank.
            stripped = line.strip()
            if not stripped:
                in_block = False
                continue
            if line.startswith((" ", "\t")):
                continue
            in_block = False
    return n


def filter_bash_output_compact(lines: list[str]) -> list[str]:
    """Round-96/96.1: drop noise + warning blocks, keep up to 5
    useful lines from a tail of bash output.

    Useful lines (test summary, errors, tracebacks) win. Noise lines
    (progress dots, plain whitespace) and entire warning blocks
    (file:N: SomeWarning + their continuation lines, including
    UNindented continuation paragraphs that pytest deprecation
    warnings habitually emit) are filtered. The result is truncated
    to at most 5 lines so the receipt stays compact even on a busy
    run. If filtering removes everything (e.g. a silent `echo`), we
    keep the original tail capped at 3 lines so the user still sees
    SOMETHING.

    Round-96.1 enhanced warning-block heuristic: a warning block
    continues until a "real content" line is reached — defined as a
    blank line, a useful-pattern match (test summary), or a noise-
    pattern match (progress dots). Without this, the second line of
    pytest_asyncio's deprecation warning (`configuration option "..."
    is unset.`) leaked into the compact receipt because it had no
    leading whitespace.
    """
    if not lines:
        return []
    useful: list[str] = []
    in_warning_block = False
    for line in lines:
        # Warning-block suppression — drops the head AND every
        # continuation line until a "real content" boundary.
        if _WARNING_HEAD_RX.search(line):
            in_warning_block = True
            continue
        if in_warning_block:
            stripped = line.strip()
            if not stripped:
                # Blank line ends the warning paragraph.
                in_warning_block = False
                continue
            if any(p.search(line) for p in _BASH_NOISE_PATTERNS):
                # Progress dots / known noise — block ends here, the
                # noise line itself is also dropped.
                in_warning_block = False
                continue
            if any(p.search(line) for p in _BASH_USEFUL_PATTERNS):
                # Genuine useful content (test summary, error) ends
                # the block AND counts as a kept line.
                in_warning_block = False
                useful.append(line)
                continue
            # Otherwise this is still part of the warning paragraph
            # (indented OR unindented continuation prose). Keep
            # suppressed.
            continue
        if any(p.search(line) for p in _BASH_NOISE_PATTERNS):
            continue
        if any(p.search(line) for p in _BASH_USEFUL_PATTERNS):
            useful.append(line)
            continue
        # Non-noise, non-recognized — keep as a candidate but only
        # admit if we don't have something more useful.
        useful.append(line)
    if not useful:
        # Everything was filtered — fall back to the last 3 raw lines.
        return [l for l in lines[-3:] if l.strip()][-3:]
    # Prefer the last few useful lines (the tail is what matters).
    return useful[-5:]


def bash_readonly_oneliner(result: ToolResult) -> "RenderableType | None":
    """R222: collapsed receipt for safe read-only bash successes.

    NYC-time screenshot showed the user a 5-row labeled block
    (Command finished / status / duration / result) for a
    one-line PowerShell time query. That's appropriate for pytest
    or a build — but for a `Get-Date`-class read it's noise. This
    helper returns a tight two-row form:

        ● Bash(<cmd-truncated>)
          ⎿ <first output line> · <duration>s

    Caller routes here BEFORE `receipt_summary_line` for run_bash
    results that meet all of:
      * exit == 0
      * `is_obviously_safe_command(cmd)` is True (the same
        classifier the R221 auto-approve gate uses)
      * tool result has the bash-shape metadata

    Returns None for everything else so the caller falls back to
    the existing `receipt_summary_line` + `bash_compact_receipt`
    chain, which gives pytest/build runs the labeled multi-row
    output users want for those cases.
    """
    from rich.console import Group as _Group
    meta = result.metadata or {}
    if "command" not in meta or "exit" not in meta:
        return None
    if meta.get("exit") != 0:
        return None
    cmd = str(meta.get("command", ""))
    if not cmd:
        return None
    try:
        from prometheus.safety.trust_gradient import is_obviously_safe_command
    except Exception:
        return None
    if not is_obviously_safe_command(cmd):
        return None
    # R222 carve-out: SAFE_BASH_PREFIXES includes test/build runners
    # (`pytest -q`, `cargo test`, `npm test`, `go test`, etc.) because
    # those are read-only WRT the workspace. But their output is
    # structured (counts, timings) and benefits from the labeled
    # receipt. Send those down the legacy path.
    first = cmd.lstrip().split(maxsplit=1)[0].lower() if cmd else ""
    if first.endswith(".exe") or first.endswith(".cmd"):
        first = first.rsplit(".", 1)[0]
    _RUNNERS = {"pytest", "cargo", "go", "npm", "yarn", "docker", "python", "python3", "node"}
    if first in _RUNNERS:
        return None
    # Build the receipt.
    duration = meta.get("duration_s")
    last_lines = meta.get("last_lines") or []
    # R222 secondary guard: even a safe command (e.g. `pytest -q`)
    # can produce verbose, structured output — for those the
    # labeled multi-row form (status / duration / result) is more
    # scannable than a oneliner. Only collapse when the filtered
    # output is truly minimal (≤3 non-empty lines). `Get-Date`
    # produces 1 line; `git status` clean produces 2; `pytest -q`
    # produces 5+. Using a real line count instead of just the
    # first one avoids surprising users with a hidden test summary.
    nonempty = [ln for ln in last_lines if (ln or "").strip()]
    if len(nonempty) > 3:
        return None
    first_useful = nonempty[0].strip()[:120] if nonempty else ""
    bits: list[str] = []
    if first_useful:
        bits.append(first_useful)
    if duration is not None:
        bits.append(f"{duration}s")
    summary = " · ".join(bits) if bits else "(done)"
    # Header: `● Bash(<cmd>)` — R226: end-truncate (was middle-truncate
    # `[:48] + "…" + [-28:]`). Showing the start of the command keeps
    # the verb / cmdlet visible and matches the user's preferred
    # form. Also unwrap a `powershell -Command "..."` shell so the
    # receipt reads PowerShell(<inner>) instead of
    # Bash(powershell -Command "<inner>").
    import re as _re_oneliner
    label_cmd = cmd
    label_prefix = "Bash"
    cmd_lower = cmd.lstrip().lower()
    if (
        cmd_lower.startswith(("pwsh ", "pwsh.exe ", "powershell ", "powershell.exe "))
        or cmd_lower in ("pwsh", "powershell")
    ):
        label_prefix = "PowerShell"
        m = _re_oneliner.match(
            r"^(?:pwsh(?:\.exe)?|powershell(?:\.exe)?)\s+"
            r"(?:-NoProfile\s+)?(?:-ExecutionPolicy\s+\S+\s+)?"
            r"-(?:Command|c)\s+(.*)$",
            cmd.lstrip(), _re_oneliner.IGNORECASE,
        )
        if m:
            inner = m.group(1).strip()
            if len(inner) >= 2 and inner[0] == inner[-1] and inner[0] in ("'", '"'):
                inner = inner[1:-1].strip()
            if inner:
                label_cmd = inner
    if len(label_cmd) > 80:
        label_cmd = label_cmd[:79] + "…"
    head = Text()
    head.append(GLYPH_RECEIPT + " ", style=SUCCESS)
    head.append(f"{label_prefix}({label_cmd})", style=AMBER)
    cont = Text()
    cont.append("  " + GLYPH_CONTINUATION + " ", style=DIM)
    cont.append(summary, style=DIM)
    return _Group(head, cont)


def bash_compact_receipt(result: ToolResult) -> Text | None:
    """Round-96.1/96.7: ultra-compact receipt for run_bash.

    Round-96.7 simplification: replaces the previous multi-row
    "Command finished · X / status: / duration: / result: / warnings:"
    block with a single ⎿ continuation row that carries the result
    line + (when present) a warning-count tail. The receipt header
    above this block already shows `● Bash(cmd)` — repeating the
    command + status here was redundant and read as bureaucratic
    output.

    New compact form:

        ● Bash(python -m pytest -q)
          ⎿ 331 passed in 3.52s · 1 warning hidden

    Returns None when the result isn't a bash result (no `command` /
    no `exit` keys) so callers can route to the legacy renderer for
    other tools.
    """
    from prometheus.ui.theme import (
        AMBER, DIM, ERROR, INK, MUTED, SUCCESS,
    )
    meta = result.metadata or {}
    if "command" not in meta or "exit" not in meta:
        return None
    cmd = str(meta.get("command", ""))[:120]
    exit_v = meta.get("exit", "?")
    duration = meta.get("duration_s", None)
    last_lines = meta.get("last_lines") or []
    # Determine status label + style.
    if exit_v == "timeout":
        status_label = "TIMEOUT"
        status_style = ERROR
    elif isinstance(exit_v, int) and exit_v == 0:
        status_label = "DONE"
        status_style = SUCCESS
    elif isinstance(exit_v, int):
        status_label = f"FAILED (exit {exit_v})"
        status_style = ERROR
    else:
        status_label = str(exit_v).upper() or "DONE"
        status_style = DIM
    # The "result" line is the test/run summary. Pytest-style summaries
    # (`N passed in X.Xs`, `N failed, M passed in X.Xs`) carry the
    # most informative single line — prefer those over per-test
    # markers (`FAILED tests/...`) by walking the filtered tail in
    # REVERSE first to catch the summary line. Falls back to the last
    # useful line, then to the last filtered line.
    filtered = filter_bash_output_compact(last_lines)
    _SUMMARY_RX = _re_filter.compile(
        r"\d+\s+(passed|failed|error|skipped).+\bin\s+[\d.]+s",
        _re_filter.IGNORECASE,
    )
    result_line = ""
    for line in reversed(filtered):
        if _SUMMARY_RX.search(line):
            result_line = line.strip()[:160]
            break
    if not result_line:
        for line in filtered:
            if any(p.search(line) for p in _BASH_USEFUL_PATTERNS):
                result_line = line.strip()[:160]
                break
    if not result_line and filtered:
        result_line = filtered[-1].strip()[:160]
    warning_count = count_warning_blocks(last_lines)
    # Round-96.8: restored the readable labeled multi-row form per
    # user's preference. Renders:
    #     ⎿ Command finished · python -m pytest -q
    #       status:   DONE
    #       duration: 17.7s
    #       result:   379 passed in 4.01s
    #       warnings: 1 hidden · /details last
    # The earlier 96.7 ultra-compact single-line form was tighter but
    # less scannable; the labeled rows make each piece of information
    # easy to find at a glance, which is what users wanted.
    body = Text()
    head = Text()
    head.append("    " + GLYPH_CONTINUATION + " ", style=DIM)
    head.append("Command finished", style=AMBER)
    head.append(" · ", style=MUTED)
    head.append(cmd, style=INK)
    body.append(head)

    def _row(label: str, value_text: Text) -> None:
        body.append("\n      ", style=DIM)
        body.append(f"{label:<10}", style=DIM)
        body.append_text(value_text)

    _row("status:", Text(status_label, style=status_style))
    if duration is not None:
        _row("duration:", Text(f"{duration}s", style=DIM))
    if result_line:
        _row("result:", Text(result_line, style=INK))
    if warning_count > 0:
        wval = Text()
        plural = "s" if warning_count != 1 else ""
        wval.append(f"{warning_count} hidden", style=AMBER)
        wval.append(" · /details last", style=DIM)
        _row("warnings:", wval)
    return body


def execution_receipt(
    result: ToolResult, *, verbose: bool = False,
) -> Text | None:
    """Round-95/96 commercial receipt block: shown after tool calls
    that expose structured execution metadata (currently `run_bash`).
    Lays out cmd / cwd / exit / duration / last-N output / retry-
    suggestion in a compact, scannable form.

    Round-96 verbose split:
      verbose=False (default)  → keep up to 5 filtered useful lines
                                 (success / failure markers, errors,
                                 tracebacks). Drops pytest progress
                                 dots and deprecation warnings.
      verbose=True             → show the full last_lines tail (up
                                 to 20) verbatim.

    Returns None when the tool result has no Round-95 metadata so the
    legacy single-line `receipt_summary_line` stays the only output.
    Skipped entirely when compact mode is on (caller checks the flag).

    Round-95 turn-7 hardening: requires the FULL bash-execution shape
    (`command` AND `exit` keys present). Without `exit`, the renderer
    used to print "? · cwd=" — exactly the broken output the user
    flagged on discover_test_command results. Other tools that emit
    a "command" key without the rest of the bash shape (e.g.
    discover_test_command's discovery metadata) are now skipped here
    and routed to `discovery_receipt` instead.
    """
    meta = result.metadata or {}
    if not meta or "command" not in meta:
        return None
    if "exit" not in meta:
        # Discovery-shaped metadata (discover_test_command, etc.)
        # uses the same renderer entry-point and was producing the
        # `? · cwd=` rendering before this guard. The dedicated
        # `discovery_receipt` is the right call for those.
        return None
    body = Text()
    cmd = str(meta.get("command", ""))[:180]
    cwd = str(meta.get("cwd", ""))
    exit_v = meta.get("exit", "?")
    duration = meta.get("duration_s", None)
    last_lines = meta.get("last_lines") or []
    retry = meta.get("retry_suggestion") or ""

    # Status pill — completed (green) / timeout (red) / failed (red) / done.
    if exit_v == "timeout":
        status_label = "TIMEOUT"
        status_style = ERROR
    elif isinstance(exit_v, int) and exit_v == 0:
        status_label = "DONE"
        status_style = SUCCESS
    elif isinstance(exit_v, int):
        status_label = f"FAILED (exit {exit_v})"
        status_style = ERROR
    else:
        status_label = str(exit_v).upper() or "DONE"
        status_style = DIM

    # Header line: status pill + duration + cwd basename. Round-95
    # turn-7: cwd row is suppressed entirely when blank instead of
    # rendering a broken `cwd=` empty-suffix label.
    cwd_short = cwd.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1] or cwd
    head = Text()
    head.append("    " + GLYPH_CONTINUATION + " ", style=DIM)
    head.append(status_label, style=status_style)
    if duration is not None:
        head.append(f"  ·  {duration}s", style=DIM)
    if cwd_short:
        head.append(f"  ·  cwd={cwd_short}", style=DIM)
    body.append(head)

    # Round-96: command echo only in verbose. The receipt summary
    # above the block already shows the command label, so repeating
    # it inside the block is just noise in compact mode.
    if verbose:
        cmd_row = Text("\n      $ ", style=DIM)
        cmd_row.append(cmd, style=INK)
        body.append(cmd_row)

    # Last N lines — verbose shows full tail (20), compact filters
    # to ~5 useful lines (success markers, errors). Drops pytest
    # progress dots, asyncio deprecation warning blocks, etc.
    rendered_lines = (
        last_lines if verbose
        else filter_bash_output_compact(last_lines)
    )
    if rendered_lines:
        body.append("\n", style="")
        for line in rendered_lines:
            row = Text("      ")
            row.append(line[:200], style=DIM)
            body.append(row)
            body.append("\n", style="")

    # Retry suggestion on timeout / non-zero exit (only when present)
    if retry and (exit_v == "timeout" or (isinstance(exit_v, int) and exit_v != 0)):
        body.append("    next: ", style=DIM)
        body.append(retry, style=AMBER)

    return body


def discovery_one_liner(result: ToolResult) -> Text | None:
    """Round-96: single-line public-facing render for discovery
    results. Replaces the multi-line receipt header + receipt block
    in compact mode (the default) so the chat doesn't show:

        ● Selected test command
          ⎿ python -m pytest -q
            source: pytest config in pyproject.toml

    and instead shows just:

        ✦ Selected command · python -m pytest -q · source: pyproject.toml

    Verbose mode keeps the multi-line block via discovery_receipt().
    Returns None when the result isn't a discovery (callers can
    safely invoke this on any tool result).
    """
    from prometheus.ui.theme import AMBER, DIM, INK, MUTED
    meta = result.metadata or {}
    chosen = str(meta.get("chosen_command", "")).strip()
    if not chosen:
        return None
    source = str(meta.get("source") or meta.get("why") or "").strip()
    # Source can be wordy ("pytest config in pyproject.toml") — trim
    # to the load-bearing tail. We keep the file/source name so the
    # user knows where the pick came from, drop the lead-in prose.
    short_source = _shorten_source(source) if source else ""
    # Round-96.5: hide the synthetic "fallback" marker from the
    # public timeline. The fallback marker is set by app.py when
    # discover_test_command failed internally and the agent rescued
    # itself with run_bash directly. Showing "source: fallback" reads
    # as internal debug to public users — they don't know what was
    # falling back from. The bash receipt + final summary already
    # tell the success story; suppress the source row entirely in
    # this case. /details last + verbose mode still expose it.
    t = Text()
    t.append("✦ ", style=AMBER)
    t.append("Selected command", style=AMBER)
    t.append(" · ", style=MUTED)
    t.append(chosen[:120], style=INK)
    is_internal_marker = short_source.lower() in ("fallback", "safe fallback")
    if short_source and not is_internal_marker:
        t.append(" · source: ", style=DIM)
        t.append(short_source[:60], style=DIM)
    return t


def _shorten_source(source: str) -> str:
    """Trim a discovery `source` / `why` string for the one-line
    receipt. Heuristic: keep the file or config-section name, drop
    leading prose. Falls through to the original string when nothing
    obvious matches.

    Examples:
      'pytest config in pyproject.toml'         → 'pyproject.toml'
      'tox.ini drives test execution'           → 'tox.ini'
      'package.json scripts.test'               → 'package.json'
      'Cargo workspace'                         → 'Cargo workspace'
    """
    if not source:
        return ""
    import re as _re
    # Try to find a known config-file token first.
    for fname in (
        "pyproject.toml", "pytest.ini", "tox.ini", "setup.cfg",
        "package.json", "Cargo.toml", "go.mod", "Makefile",
    ):
        if fname in source:
            return fname
    # Otherwise return the source verbatim, just length-capped.
    return source[:60]


def discovery_receipt(result: ToolResult, *, verbose: bool = False) -> Text | None:
    """Round-95 turn-7/9: public-facing receipt block for tools that
    pre-pick a command (discover_test_command + future siblings).

    Renders ONE line in default mode:
        source: pytest config in pyproject.toml

    Round-95 turn-9: dropped the chosen-command line entirely. The
    receipt header (e.g. `● Selected test command`) already includes
    the command in its summary continuation row; printing it again
    here read as nested duplication. Now this renderer only adds the
    `source: ...` line that the receipt summary can't fit.

    Confidence is internal scoring — only included when `verbose=True`
    (driven by the app's verbose flag / `/timeline --debug`).

    Returns None when the result doesn't look like a discovery (no
    chosen_command in metadata) so the renderer is safe to call on
    every tool result without first checking the tool name.
    """
    meta = result.metadata or {}
    chosen = str(meta.get("chosen_command", "")).strip()
    if not chosen:
        return None
    source = str(meta.get("source") or meta.get("why") or "").strip()
    confidence_text = str(meta.get("confidence", "")).strip()
    evidence = meta.get("evidence") or []
    # Default rendering: one source line, indented under the
    # receipt summary's continuation row. No leading newline — the
    # caller's logger inserts the break between the summary and
    # this block. If there's no source AND we're not in verbose,
    # there's nothing to add — return None so we don't emit an
    # empty / lonely block.
    if not source and not verbose:
        return None
    body = Text()
    if source:
        srow = Text("    source: ", style=DIM)
        srow.append(source[:180], style=DIM)
        body.append(srow)
    if verbose:
        # Confidence + evidence are internal; only surface them when
        # the user opted in to debug-style output.
        if confidence_text:
            if body.plain:
                body.append("\n")
            body.append(Text("    confidence: ", style=DIM))
            body.append(Text(confidence_text, style=DIM))
        if isinstance(evidence, list) and evidence:
            if body.plain:
                body.append("\n")
            body.append(Text("    evidence:", style=DIM))
            for ev in evidence[:5]:
                body.append(Text(f"\n      · {str(ev)[:140]}", style=DIM))
    return body if body.plain else None


def expanded_body(result: ToolResult) -> Text | None:
    """Used only when the user explicitly expands a receipt. Hidden by default.

    Round-39: matches Claude Code's text-affordance pattern. The
    collapsed default surfaces the trailing string
    `+N lines (ctrl+o to expand)` inside the ⎿ continuation row;
    only when the user toggles do we render the full body. The
    legacy `▾` triangle has been retired (CC never used it).
    """
    output = result.output or ""
    lines = output.splitlines() or [""]
    body = Text()
    n = len(lines)
    body.append(f"   ⎿ {n} line{'s' if n != 1 else ''}\n", style=DIM)
    indented = "\n".join("   " + l for l in lines[:200])
    body.append(indented, style=INK)
    if n > 200:
        body.append(f"\n   …[+{n - 200} more lines]", style=DIM)
    return body


def collapsed_summary(line_count: int) -> str:
    """Round-39: Claude-Code-parity collapse affordance text.

    Format: '+N lines (ctrl+o to expand)' — appears inside the ⎿
    continuation row of a tool receipt when output is collapsed.
    """
    if line_count <= 0:
        return ""
    return f"+{line_count} line{'s' if line_count != 1 else ''} (ctrl+o to expand)"


_ANSI_RX = None


def _strip_ansi(text: str) -> str:
    """Remove CSI / OSC / DCS escape sequences and bare control bytes.

    Defends against:
      - models accidentally echoing terminal escape codes from copied output
      - prompt-injection in pasted/fetched content that contains `\x1b]...`
        sequences (which can rewrite the terminal title, change colors,
        or in some terminals open URLs)
    """
    global _ANSI_RX
    if _ANSI_RX is None:
        import re
        _ANSI_RX = re.compile(
            r"\x1b\[[0-?]*[ -/]*[@-~]"
            r"|\x1b\][^\x07\x1b]*[\x07\x1b\\]"
            r"|\x1b[PX^_][^\x1b]*\x1b\\"
            r"|[\x00-\x08\x0b-\x1f\x7f]"
        )
    return _ANSI_RX.sub("", text)


def assistant_markdown(text: str) -> RenderableType:
    """Assistant text — rendered as Markdown so **bold**, *italic*, and
    code fences render properly, then themed amber so user vs assistant
    is visually distinct.

    Always strips ANSI / control bytes first so a hostile or accidental
    escape sequence in the model's output cannot rewrite the user's
    terminal title, change colors, or trigger OS-specific actions.

    R226: prepend a green `●` step glyph so assistant replies match the
    CC screenshot pattern where every conversational step (tool call OR
    assistant text) carries the bullet. For plain-text replies the glyph
    is inline with the first line; for markdown replies it sits on its
    own line above the rendered markdown body (Rich's Markdown renderer
    doesn't compose cleanly with an inline prefix on the same line).
    """
    from rich.console import Group as _Group
    text = _strip_ansi(text)
    prefix = Text()
    prefix.append(GLYPH_RECEIPT + " ", style=SUCCESS)
    has_md = any(tok in text for tok in ("```", "**", "* ", "# ", "## ", "- ", "1. ", "[", "`"))
    if has_md:
        from rich.style import Style
        from prometheus.ui.theme import active_theme
        # Match the code-block highlighter to the active theme. The
        # default `ansi_dark` is unreadable on light/paper themes —
        # syntax colors blend into the parchment background. Pygments
        # ships `vs` (Visual Studio Light) and `monokai` (high-contrast
        # dark) which work for our four palettes.
        theme_name = active_theme()
        if theme_name in ("light", "paper"):
            code_theme = "vs"
        else:
            code_theme = "ansi_dark"
        md = Markdown(text, code_theme=code_theme, style=Style(color=ASSISTANT_INK))
        return _Group(prefix, md)
    # Plain-text reply: inline glyph + first line, no extra row.
    body = Text()
    body.append_text(prefix)
    body.append(text, style=ASSISTANT_INK)
    return body


def user_line(text: str) -> Text:
    t = Text()
    t.append("> ", style=DIM)
    t.append(text, style=USER_INK)
    return t


def system_dim(text: str) -> Text:
    return Text(text, style=DIM)


def error_line(text: str) -> Text:
    return Text(f"⚠︎ {text}", style=ERROR)


def osc8_link(display: str, target: str) -> Text:
    """Render `display` as an OSC-8 hyperlink that opens `target`.

    Modern terminals (iTerm2, Windows Terminal, Kitty, Alacritty,
    WezTerm, GNOME Terminal recent) recognize the sequence and make
    the text clickable. Terminals that don't simply render the display
    text without the escape — graceful fallback.

    For local files we use file:// URIs so Ctrl-clicking opens the
    user's default editor / OS file handler.
    """
    from rich.style import Style
    t = Text()
    # Rich supports `meta={'link': ...}` on Text spans which it
    # renders as OSC-8 when the terminal supports hyperlinks.
    t.append(display, style=Style(link=target))
    return t


def _format_elapsed_short(seconds: int) -> str:
    """Round 96.21: same compact elapsed-time format the live rail
    uses (`widgets._format_elapsed_short`). Duplicated here to avoid
    a render→widgets import cycle. `45s` for sub-minute, `1m 18s`
    for longer runs, `2m` when seconds == 0."""
    s = max(0, int(seconds))
    if s < 60:
        return f"{s}s"
    m, rem = divmod(s, 60)
    if rem == 0:
        return f"{m}m"
    return f"{m}m {rem}s"


def inline_timing_line(
    elapsed_s: int,
    *,
    status: str = "done",
    seed: int | str | None = None,
) -> "RenderableType":
    """R227 / Item 5: minimal post-turn timing marker — one dim line
    between turns, replacing the verbose `✓ <title> · ↑X · ↓Y · N
    tools` summary + horizontal rule that R96.7 was building.

    CC's screenshots show `✻ Crunched for 8s` / `✻ Brewed for 37s`
    as a single small line between the previous turn's output and
    the next prompt. PrometheUS adopts the same shape but with the
    R226 themed-verb pool: `✻ Forged for 8s`, `✻ Smelted for 12s`,
    `✻ Channeled for 4s`.

    For non-success statuses we keep a clear failure signal — the
    user needs to see at a glance that something didn't work — by
    swapping the success glyph + verb for status-specific ones.
    Tokens, tool counts, and active-context tokens that the old
    summary line carried are intentionally dropped here; users
    looking for those numbers can run /stats.
    """
    from prometheus.ui.theme import AMBER, DIM, ERROR, MUTED, SUCCESS
    from prometheus.ui.playful_verbs import pick
    s = max(0, int(elapsed_s))
    if s < 60:
        elapsed_text = f"{s}s"
    else:
        m, rem = divmod(s, 60)
        elapsed_text = f"{m}m" if rem == 0 else f"{m}m {rem}s"
    # Pick a stable per-turn verb. The seed defaults to the elapsed
    # time so different-length turns get different verbs without
    # tracking turn ids; callers that have a real id should pass it.
    seed_val: int | str = seed if seed is not None else s
    _present, past = pick(seed_val)
    if status == "done":
        glyph = "✻"
        glyph_style = AMBER
        body = f"{past} for {elapsed_text}"
        body_style = DIM
    elif status == "failed":
        glyph = "✗"
        glyph_style = ERROR
        body = f"Failed at {elapsed_text}"
        body_style = ERROR
    elif status == "timeout":
        glyph = "⚠"
        glyph_style = AMBER
        body = f"Timed out at {elapsed_text}"
        body_style = AMBER
    elif status == "interrupted":
        glyph = "⊘"
        glyph_style = MUTED
        body = f"Interrupted at {elapsed_text}"
        body_style = MUTED
    else:
        glyph = "✻"
        glyph_style = AMBER
        body = f"{past} for {elapsed_text}"
        body_style = DIM
    line = Text()
    line.append(glyph + " ", style=glyph_style)
    line.append(body, style=body_style)
    return line


def activity_summary_line(
    elapsed_s: int,
    tokens_out: int,
    *,
    title: str = "",
    status: str = "done",
    tool_calls: int = 0,
    files_changed: int = 0,
    chrome: bool = True,
    tool_runtime_s: float | None = None,
    approval_wait_s: float | None = None,
    active_ctx_tokens: int | None = None,
    show_tokens: bool = False,
    tokens_in: int = 0,
) -> RenderableType:
    """Round-95 turn-5/6: polished post-turn activity summary.

    Replaces the legacy `thought_marker` ("Thought for Ns") at active
    call sites with a status-aware one-liner: clear icon, crisp title,
    elapsed-time + token + tool + file stats.

    Status icons (PrometheUS-branded — not a clone of any one product):
      ✓ done         — clean success (green)
      ⚠ timeout      — command exceeded its budget (amber)
      ✗ failed       — non-zero exit / tool error (red)
      ⊘ interrupted  — user hit Esc (muted)
      ✶ generic      — turn ran but no specific outcome inferred (amber)

    Example renderings:
      ─────────────────  ← turn-6 chrome: thin separator above
      ✓ Tests passed: 139 in 2.68s   ·  14.1s · ↓2.4k tokens · 1 tool
      ⚠ Command timed out            ·  180s · ↓1.2k tokens · 1 tool
      ✗ Edit failed                  ·    3s · ↓0.4k tokens · 1 tool
      ⊘ Interrupted                  ·   12s · ↓0.5k tokens
      ✶ Turn complete                ·   32s · ↓2.4k tokens · 4 tools · 2 files

    Round-95 turn-6: when `chrome=True` (default), the summary is
    wrapped in a Group with a thin horizontal rule above it. The rule
    is dim by default so the line reads as terminal chrome / status
    pillow rather than another assistant chat message. Set
    `chrome=False` (used in tests / audits that need to assert on the
    raw line content) to skip the wrapper.
    """
    from prometheus.ui.theme import AMBER, CYAN, MUTED, ERROR, INK, SUCCESS
    icon_map = {
        "done":         ("✓", SUCCESS),
        "timeout":      ("⚠", AMBER),
        "failed":       ("✗", ERROR),
        "interrupted":  ("⊘", MUTED),
        "generic":      ("✶", AMBER),
    }
    icon, icon_style = icon_map.get(status, icon_map["generic"])
    if not title:
        title = {
            "done":        "Turn complete",
            "timeout":     "Command timed out",
            "failed":      "Turn failed",
            "interrupted": "Interrupted",
            "generic":     "Turn complete",
        }.get(status, "Turn complete")
    t = Text()
    t.append(icon + " ", style=icon_style)
    # Trim verbose titles — keep one short line, no line-wrap drama.
    t.append(title[:90], style=INK)
    t.append("  ·  ", style=MUTED)
    # Round-95 turn-7: prefer the honest "tool runtime + approval wait"
    # breakdown over a misleading single elapsed number. The previous
    # rendering reported 48s for a turn whose actual work was 18.6s of
    # bash + 26s of the user reading the approval card — making
    # PrometheUS look slow when most of that time was the user's own
    # decision time. We surface the real signal: tool work + approval
    # wait (when non-trivial) instead of total wall-clock.
    if tool_runtime_s is not None and tool_runtime_s >= 0.1:
        t.append(f"tool {tool_runtime_s:.1f}s", style=MUTED)
        if approval_wait_s is not None and approval_wait_s >= 3:
            t.append(" · ", style=MUTED)
            t.append(
                f"waited {int(round(approval_wait_s))}s",
                style=MUTED,
            )
    else:
        # Chat-only / no-tool turn: fall back to overall elapsed.
        # Round 96.21: use the same `_format_elapsed_short` shape as
        # the live rail (`45s` / `1m 18s` / `2m`) so a long pure-chat
        # turn doesn't read as `127s` here while the rail showed
        # `2m 7s` mid-turn. Cross-surface consistency.
        t.append(_format_elapsed_short(elapsed_s), style=MUTED)
    # Round-96.7: bring back Claude-style token-delta on the public
    # summary — `↓Xk tokens` for per-turn output. Always shown when
    # tokens_out > 0. The earlier 96.2 concern (`↓273.4k tokens`
    # leaking session-cumulative) is now moot: tokens_out is the
    # PER-TURN output count (set in app.py from `_turn_tokens_out`),
    # not the lifetime sum. On reasoning-heavy free models a turn
    # may genuinely produce a large output count and that's accurate
    # — the public summary surfaces it honestly.
    # Round 96.20: Claude-style — public summary always uses the
    # `↓X tokens` form, mirroring the live rail. Same arrow whether
    # the count comes from output (typical) or input fallback. No
    # `input` / `output` labels on public surfaces. The live rail
    # and the post-turn summary now read identically — no flip from
    # ↑ to ↓ at the boundary.
    def _fmt_tok(n: int) -> str:
        return f"{n / 1000:.1f}k" if n >= 1000 else str(n)

    n_out = max(0, int(tokens_out))
    n_in = max(0, int(tokens_in))
    public_n = n_out if n_out > 0 else n_in
    if public_n > 0:
        t.append(" · ", style=MUTED)
        # Round 96.22: SPACE after the arrow, matching the canonical
        # public format documented in tweakcc:
        #   `✻ Improvising… (35s · ↓ 279 tokens)`
        t.append(f"↓ {_fmt_tok(public_n)} tokens", style=CYAN)
    # Round-96.7: `thought for Ys` — wall-clock NOT spent in tool
    # execution or approval wait. Surfaces the agent's actual
    # thinking time as a clean public timing metric (not the raw
    # reasoning text — that stays private). Computed only when
    # all three inputs are available; suppressed when trivial (<2s).
    if (
        tool_runtime_s is not None
        and approval_wait_s is not None
    ):
        thought_s = max(
            0,
            int(elapsed_s)
            - int(tool_runtime_s or 0)
            - int(approval_wait_s or 0),
        )
        if thought_s >= 2:
            t.append(" · ", style=MUTED)
            t.append(f"thought for {thought_s}s", style=MUTED)
    # Round-96.6 active_ctx_tokens kwarg kept for backward compat
    # but no longer surfaces in default output — the `↓Xk tokens`
    # row above already provides the user-meaningful token signal.
    # /stats and /stats --debug remain the explicit ctx surface.
    if show_tokens and active_ctx_tokens is not None and active_ctx_tokens > 0:
        n_ctx = int(active_ctx_tokens)
        ctx_str = f"{n_ctx / 1000:.1f}k" if n_ctx >= 1000 else str(n_ctx)
        t.append(" · ", style=MUTED)
        t.append(f"ctx {ctx_str}", style=CYAN)
    if tool_calls > 0:
        t.append(" · ", style=MUTED)
        t.append(f"{tool_calls} tool{'s' if tool_calls != 1 else ''}", style=MUTED)
    if files_changed > 0:
        t.append(" · ", style=MUTED)
        plural = "s" if files_changed != 1 else ""
        t.append(f"{files_changed} file{plural} changed", style=MUTED)
    if not chrome:
        return t
    # Round-95 turn-6/9 terminal chrome: stronger visual separation
    # so the summary line clearly reads as terminal status pillow,
    # not another assistant chat row. Three elements:
    #   1. a blank line of breathing room above the rule
    #   2. a horizontal rule wide enough to read as a section break
    #   3. the summary line itself (icon + title + stats)
    #
    # The rule uses U+2500 BOX DRAWINGS LIGHT HORIZONTAL — a pure-
    # text codepoint that Windows Terminal can't emoji-promote — at
    # width 64. Always MUTED so the icon + title stay the visual
    # hook, but wide enough to feel deliberate (the previous 56-wide
    # rule was too short and got lost in dense chat output).
    blank = Text("")
    rule = Text("─" * 64, style=MUTED)
    return Group(blank, rule, t)


def thought_marker(
    elapsed_s: int,
    tokens_out: int,
    interrupted: bool = False,
    *,
    tool_calls: int = 0,
    files_changed: int = 0,
) -> Text:
    """Persistent footer line for a finished turn.

    Format: ✻ Thought for 3s  ·  ↓21 tokens  ·  4 tools  ·  2 files

    Sits in the chat scroll forever so the user can see how long the
    agent thought, how much it spent on each question, and what it
    actually did (round-39: tools + files counters mirror Claude Code's
    "task summary" pattern surfaced in best-practices docs).
    """
    from prometheus.ui.theme import AMBER, CYAN, MUTED, GLYPH_THOUGHT
    t = Text()
    t.append(GLYPH_THOUGHT + " ", style=AMBER)
    if interrupted:
        t.append(f"Interrupted after {elapsed_s}s", style=MUTED)
    else:
        t.append(f"Thought for {elapsed_s}s", style=MUTED)
    t.append("  ·  ", style=MUTED)
    n = max(0, int(tokens_out))
    tok = f"{n / 1000:.1f}k" if n >= 1000 else str(n)
    t.append(f"↓{tok} tokens", style=CYAN)
    if tool_calls > 0:
        t.append("  ·  ", style=MUTED)
        t.append(f"{tool_calls} tool{'s' if tool_calls != 1 else ''}", style=MUTED)
    if files_changed > 0:
        t.append("  ·  ", style=MUTED)
        plural = "s" if files_changed != 1 else ""
        t.append(f"{files_changed} file{plural} changed", style=MUTED)
    return t
