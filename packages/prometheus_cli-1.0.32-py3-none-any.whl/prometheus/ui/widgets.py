"""Custom Textual widgets: Welcome card, TodoBar, PermissionBar, StatusBar,
and an inline approval prompt.
"""
from __future__ import annotations

from typing import Any

from rich.align import Align
from rich.console import Group
from rich.panel import Panel
from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.reactive import reactive
from textual.widgets import Static

from prometheus.ui.theme import (
    AMBER,
    CYAN,
    DIM,
    ERROR,
    GLYPH_ACTIVE,
    GLYPH_DONE,
    GLYPH_PENDING,
    GLYPH_PERM,
    GLYPH_SPINNER,
    INK,
    MUTED,
    SPINNER_FRAMES,
    SUCCESS,
)


def _short_model_label(model_id: str) -> str:
    """Round 172: compress a model identifier into a single word.

    Claude Code's bottom strip shows the active model so the user
    always knows what's responding. Full identifiers like
    `anthropic/claude-sonnet-4-6` are too wide for the strip; this
    helper returns the human-recognizable suffix.
    """
    if not model_id:
        return ""
    s = model_id.strip().lower()
    # Drop a leading provider prefix: `anthropic/...`, `openrouter/...`.
    if "/" in s:
        s = s.rsplit("/", 1)[-1]
    # Common Anthropic family: claude-{sonnet,opus,haiku}-X-Y →
    # `sonnet 4.6`, `opus 4.7`, `haiku 4.5`.
    parts = s.split("-")
    if len(parts) >= 4 and parts[0] == "claude" and parts[1] in (
        "sonnet", "opus", "haiku",
    ):
        try:
            major = int(parts[2])
            minor = int(parts[3])
            return f"{parts[1]} {major}.{minor}"
        except ValueError:
            pass
    # OpenAI family: gpt-4o, gpt-4-turbo, etc — just return the
    # bare identifier minus provider prefix.
    return s


WELCOME_TEXT = r"""
                                         _      _   _ ___
   _ __  _ __ ___  _ __ ___   ___| |_| |__ ___| | | / __|
  | '_ \| '__/ _ \| '_ ` _ \ / _ \ __| '_ \ / _ \ | | \__ \
  | |_) | | | (_) | | | | | |  __/ |_| | | |  __/ |_| |__) |
  | .__/|_|  \___/|_| |_| |_|\___|\__|_| |_|\___|\___/____/
  |_|
"""


class SessionHeader(Static):
    """Top-of-screen session header (opencode-style).

    Layout:
        ┃  <session label>                       11,782  6%  ($0.00)
    """
    DEFAULT_CSS = """
    SessionHeader { padding: 0 2; height: 1; background: black; }
    """
    label: reactive[str] = reactive("session", recompose=False)
    tokens: reactive[int] = reactive(0, recompose=False)
    ctx_pct: reactive[int] = reactive(0, recompose=False)
    cost_usd: reactive[float] = reactive(0.0, recompose=False)
    cap_usd: reactive[float] = reactive(0.0, recompose=False)

    def watch_label(self, _) -> None: self.refresh()
    def watch_tokens(self, _) -> None: self.refresh()
    def watch_ctx_pct(self, _) -> None: self.refresh()
    def watch_cost_usd(self, _) -> None: self.refresh()
    def watch_cap_usd(self, _) -> None: self.refresh()

    def render(self) -> Any:
        # Round-46: metrics moved to bottom StatusBar (cleaner top, eye
        # near the input box). SessionHeader now renders just the
        # session label so it stays a recognizable identity bar.
        out = Text()
        out.append("┃ ", style=AMBER)
        out.append(self.label or "session", style=INK)
        return out


class WelcomeCard(Static):
    DEFAULT_CSS = """
    WelcomeCard { padding: 1 2; height: auto; }
    WelcomeCard.-hidden { display: none; }
    """

    def __init__(self, model: str, workdir: str, recent_sessions: list | None = None) -> None:
        super().__init__()
        self.model = model
        self.workdir = workdir
        # Round-47: progressive disclosure. First-time users see "ask
        # anything" tips; returning users see their recent sessions
        # inline so they can /resume without typing /sessions first.
        # Matches CC's first-time-vs-returning welcome split.
        self.recent_sessions = recent_sessions or []

    def render(self) -> Any:
        # Round 213: polished banner. Earlier copy editorialized
        # ("the autonomous terminal assistant", scripted example
        # prompts, "drop a PROMETHEUS.md in this folder for
        # instructions read every turn") in a way the user flagged
        # as marketing-toned and grammatically off. The new layout
        # mirrors Claude Code's sparse welcome — logo, one
        # command-hint line, cwd. Returning users still see their
        # recent sessions inline so /resume is one click away.
        logo = Text(WELCOME_TEXT, style=AMBER)
        tips = Text(
            "  /help for help  ·  @file to attach  ·  !cmd for shell  "
            "·  Shift+Tab for modes\n",
            style=DIM,
        )
        if self.recent_sessions:
            tips.append("  recent activity:\n", style=DIM)
            for s in self.recent_sessions[:3]:
                sid = s.get("id", "")[:8]
                ago = s.get("ago", "")
                preview = s.get("preview", "")[:50]
                tips.append(
                    f"    /resume {sid}  ·  {ago}  ·  {preview}\n",
                    style=DIM,
                )
        tips.append(f"  cwd: {self.workdir}\n", style=DIM)
        return Group(logo, tips)


class TodoBar(Static):
    """Renders ✓●○ task tracker once 1+ todos exist (round-41: CC parity)."""
    DEFAULT_CSS = """
    TodoBar { padding: 0 2; height: auto; }
    TodoBar.-hidden { display: none; }
    """

    todos: reactive[list[dict[str, Any]]] = reactive(list, recompose=False)

    def watch_todos(self, todos: list[dict[str, Any]]) -> None:
        self.set_class(not todos, "-hidden")
        self.refresh()

    def render(self) -> Any:
        if not self.todos:
            return Text("")
        glyphs = {
            "completed":   (GLYPH_DONE, SUCCESS),
            "in_progress": (GLYPH_ACTIVE, AMBER),
            "pending":     (GLYPH_PENDING, DIM),
        }
        t = Text()
        # Round 96.29: Claude-style task progress summary.
        # Replaces the round-41 `plan N/M` header with a per-status
        # breakdown: `N tasks (X done, Y in progress, Z open)`. When
        # there's a single task the header degrades to `1 task` so
        # `(0 done, 1 in progress, 0 open)` doesn't read as noisy.
        total = len(self.todos)
        done = sum(1 for x in self.todos if x["status"] == "completed")
        in_prog = sum(1 for x in self.todos if x["status"] == "in_progress")
        pending = sum(1 for x in self.todos if x["status"] == "pending")
        word = "task" if total == 1 else "tasks"
        t.append(f"{total} {word} ", style=DIM)
        t.append(
            f"({done} done, {in_prog} in progress, {pending} open)  ",
            style=DIM,
        )
        for i, item in enumerate(self.todos):
            g, c = glyphs.get(item["status"], (GLYPH_PENDING, DIM))
            t.append(g, style=c)
            t.append(" ", style="")
            t.append(
                item["subject"][:50],
                style=INK if item["status"] != "completed" else DIM,
            )
            if i != len(self.todos) - 1:
                t.append("   ")
        return t


class PermissionBar(Static):
    DEFAULT_CSS = """
    PermissionBar { padding: 0 2; height: 1; color: white; }
    """
    mode: reactive[str] = reactive("default", recompose=False)
    interrupting: reactive[bool] = reactive(False, recompose=False)

    def watch_mode(self, _) -> None:
        self.refresh()

    def watch_interrupting(self, _) -> None:
        self.refresh()

    def render(self) -> Any:
        # (label, pill_bg, pill_fg)
        pills = {
            "default":     ("ask before edits",  "grey23",  INK),
            "acceptEdits": ("accept edits on",   AMBER,     "black"),
            "plan":        ("plan only",         "#3a6fa6", "white"),
            # Round 96.28 (research-driven): neutral phrasing.
            # Claude Code uses `bypass permissions` (issue #11073);
            # the prior `yolo · skip all` label read as informal
            # for a public CLI shipping to paying users.
            "skipAll":     ("bypass permissions", "#9a3030", "white"),
        }
        label, bg, fg = pills.get(self.mode, ("default", "grey23", INK))
        t = Text()
        t.append(" " + GLYPH_PERM + " " + label + " ", style=f"{fg} on {bg}")
        t.append("    ")
        t.append("shift+tab modes  ·  ctrl+r history  ·  ctrl+c quit", style=MUTED)
        return t


class StatusBar(Static):
    """Stable identity bar at the very bottom.

    Round-46 layout (always identical width, never reflows):
      [spinner|·] PrometheUS  ·  <folder>  ·  <custom>           tokens  ctx%  ($cost)

    Metrics moved here from SessionHeader (top) per user feedback —
    keeps the user's eyes near the input box where they're typing.
    The CURRENT TOOL / busy text is rendered separately by
    ActivityLine so it cannot push the identity columns off-edge.
    """
    DEFAULT_CSS = """
    StatusBar { padding: 0 2; height: 1; }
    """
    model: reactive[str] = reactive("", recompose=False)
    folder: reactive[str] = reactive("", recompose=False)
    tokens_in: reactive[int] = reactive(0, recompose=False)
    tokens_out: reactive[int] = reactive(0, recompose=False)
    ctx_pct: reactive[int] = reactive(0, recompose=False)
    spinner_frame: reactive[int] = reactive(0, recompose=False)
    busy: reactive[bool] = reactive(False, recompose=False)
    # Round-46: metrics relocated from SessionHeader.
    # Round-96.2: `tokens` now means ACTIVE context tokens (what
    # _approx_token_load returns), not session-cumulative. The
    # cumulative count moved to `session_tokens_total`, hidden by
    # default behind PROMETHEUS_SHOW_SESSION_TOKENS=1.
    tokens: reactive[int] = reactive(0, recompose=False)
    session_tokens_total: reactive[int] = reactive(0, recompose=False)
    cost_usd: reactive[float] = reactive(0.0, recompose=False)
    cap_usd: reactive[float] = reactive(0.0, recompose=False)
    # Activity moved to ActivityLine; kept here for compat with old code paths.
    current_tool: reactive[str] = reactive("", recompose=False)
    # Output of ~/.prometheus/statusline.sh (or .ps1). When non-empty,
    # appended after the identity columns. Empty by default.
    custom_line: reactive[str] = reactive("", recompose=False)

    def watch_current_tool(self, _) -> None: self.refresh()
    def watch_custom_line(self, _) -> None: self.refresh()

    def watch_model(self, _) -> None: self.refresh()
    def watch_folder(self, _) -> None: self.refresh()
    def watch_tokens_in(self, _) -> None: self.refresh()
    def watch_tokens_out(self, _) -> None: self.refresh()
    def watch_tokens(self, _) -> None: self.refresh()
    def watch_session_tokens_total(self, _) -> None: self.refresh()
    def watch_ctx_pct(self, _) -> None: self.refresh()
    def watch_cost_usd(self, _) -> None: self.refresh()
    def watch_cap_usd(self, _) -> None: self.refresh()
    def watch_spinner_frame(self, _) -> None: self.refresh()
    def watch_busy(self, _) -> None: self.refresh()

    def render(self) -> Any:
        # Round-52: minimal bottom strip. Folder dropped — the welcome
        # card already shows the working dir on launch, and CC keeps
        # its bottom statusLine to identity + metrics only. The custom
        # statusline (from ~/.prometheus/statusline.sh) still appends
        # if the user has one configured.
        left = Text()
        if self.busy:
            frame = SPINNER_FRAMES[self.spinner_frame % len(SPINNER_FRAMES)]
            left.append(f"{frame} ", style=AMBER)
        else:
            left.append("· ", style=MUTED)
        left.append("PrometheUS", style=AMBER)
        # Round 172: render the model name next to the brand the way
        # Claude Code shows model identity in its bottom strip. The
        # `model` reactive was set on launch and updated by /model
        # but the original render path forgot to surface it — users
        # had no on-screen indication of which model they were
        # talking to without running /model. Compact display only:
        # show short alias when it's a known one, otherwise the
        # provider-prefix-stripped tail.
        if self.model:
            short = _short_model_label(self.model)
            if short:
                left.append("  ·  ", style=MUTED)
                left.append(short, style=DIM)
        if self.custom_line:
            left.append("  ·  ", style=MUTED)
            left.append(self.custom_line, style=DIM)

        # Round-96.2: active context is what matters for budget — the
        # cumulative session total (1.4m+ on long resumes) was scaring
        # users into thinking compaction was broken when really the
        # session-lifetime accumulator was the largest visible number.
        # The bottom strip now shows: `ctx 12.3k · 5%` — the active
        # message-buffer size in tokens AND the percentage of the
        # configured context window. Cumulative session tokens move
        # to /stats (admin/debug surface) instead of the always-on bar.
        import os as _os
        show_cost = (
            _os.getenv("PROMETHEUS_ADMIN") == "1"
            or _os.getenv("PROMETHEUS_SHOW_COST") == "1"
        )
        show_session_total = _os.getenv("PROMETHEUS_SHOW_SESSION_TOKENS") == "1"
        right = Text()
        # Active context — tokens currently in the message buffer.
        # The value is fed in via the `tokens` reactive (kept name for
        # backward compat) but populated from _approx_token_load(), the
        # active-context estimate, NOT the session-lifetime sum.
        #
        # Round-96.11c: always render the token field, even when 0.
        # Smoke 5 retest spot: on slash-command-only screens (e.g.
        # /sessions on a freshly-launched chat where the agent has no
        # messages yet) the HUD collapsed to `0% ($0.00)` because the
        # earlier `if active > 0:` gate hid the field entirely. The
        # bar now always shows the number — fresh sessions read
        # `0 · 0% ($0.00)` so the layout is identical to a busy
        # session reading `1.7k · 0% ($0.00)`. No `ctx` label.
        active = self.tokens
        if active >= 1_000_000:
            active_str = f"{active / 1_000_000:.1f}m"
        elif active >= 1_000:
            # Round-96.6: bump under-10k entries into k-format too
            # so the HUD stays compact (`1.9k` instead of `1,981`).
            # Smoke 4 retest screenshot showed `ctx 1,981 · 0%`
            # which read as raw internal telemetry. New format:
            # `1.9k · 0%` with no `ctx` label — closer to the
            # premium-CLI feel users expect.
            active_str = f"{active / 1_000:.1f}k"
        elif active > 0:
            active_str = f"{active:,}"
        else:
            active_str = "0"
        right.append(active_str, style=DIM)
        right.append("  ·  ", style=MUTED)
        ctx_color = ERROR if self.ctx_pct >= 85 else (
            AMBER if self.ctx_pct >= 70 else DIM
        )
        right.append(f"{self.ctx_pct}%", style=ctx_color)
        if show_session_total:
            # Admin / debug opt-in: show the cumulative session-lifetime
            # tokens (sum of _tokens_total_in + _tokens_total_out across
            # ALL turns including resumes). Hidden by default since
            # users mistake it for active-context bloat.
            sess = getattr(self, "session_tokens_total", 0)
            if sess > 0:
                if sess >= 1_000_000:
                    s_str = f"{sess / 1_000_000:.1f}m"
                elif sess >= 10_000:
                    s_str = f"{sess / 1_000:.1f}k"
                else:
                    s_str = f"{sess:,}"
                right.append("  ·  session ", style=MUTED)
                right.append(s_str, style=DIM)
        if show_cost:
            right.append("  ", style="")
            if self.cap_usd > 0:
                pct = self.cost_usd / self.cap_usd
                cost_color = ERROR if pct >= 0.95 else (AMBER if pct >= 0.80 else DIM)
                right.append(
                    f"(${self.cost_usd:.2f} / ${self.cap_usd:.2f})",
                    style=cost_color,
                )
            else:
                right.append(f"(${self.cost_usd:.2f})", style=DIM)
        try:
            width = max(0, self.size.width - 4)
        except Exception:
            width = 120
        gap = max(2, width - left.cell_len - right.cell_len)
        out = Text()
        out.append_text(left)
        out.append(" " * gap)
        out.append_text(right)
        return out


# Verb rotation matches Claude Code's "still thinking / thinking more /
# almost done thinking" pattern (v2.1.116). For PrometheUS we cycle
# playful synonyms early in a turn, then switch to honest "still
# working / hang tight / nearly there" verbs once a turn drags past
# 30s — so the user gets reassurance that the process isn't stuck.
#
# Users can override the lists by writing
#     ~/.prometheus/spinner-verbs.json
# with shape {"early": [...], "long": [...]} — the community wrote
# 1,900 themed verbs for Claude Code; supporting custom verb packs
# is cheap surface but huge brand affection.
# Round-25 polish: expanded verb set inspired by Claude's 187-verb
# dictionary but tilted serious-with-occasional-warmth for a
# commercial professional tone. Users can override entirely via
# `~/.prometheus/verbs.json`.
_THINKING_VERBS_EARLY = [
    "thinking", "reasoning", "considering", "weighing",
    "exploring", "planning", "synthesizing", "drafting",
    "analyzing", "investigating", "checking", "reading",
    "tracing", "comparing", "evaluating", "examining",
    "parsing", "outlining", "scoping", "sketching",
    "consulting", "looking up", "cross-checking", "thinking it through",
]
_THINKING_VERBS_LONG = [
    "still working", "still on it", "hang tight", "nearly there",
    "this one's chewy", "almost done", "still thinking",
    "thinking more", "almost done thinking", "wrapping up",
    "putting it together", "double-checking", "polishing",
    "tying loose ends", "verifying", "running the last checks",
]


def _load_verb_overrides() -> None:
    """Best-effort load of user-customised verb packs. Run once at import."""
    global _THINKING_VERBS_EARLY, _THINKING_VERBS_LONG
    try:
        import json as _json
        from pathlib import Path as _P
        target = _P.home() / ".prometheus" / "spinner-verbs.json"
        if not target.exists():
            return
        data = _json.loads(target.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            early = data.get("early")
            long = data.get("long")
            if isinstance(early, list) and early:
                _THINKING_VERBS_EARLY = [str(v)[:40] for v in early[:200] if str(v).strip()]
            if isinstance(long, list) and long:
                _THINKING_VERBS_LONG = [str(v)[:40] for v in long[:200] if str(v).strip()]
    except Exception:
        # Never fail the TUI because of a verb config typo.
        pass


_load_verb_overrides()


# Round-94: per-second verb cache so the 10Hz render loop doesn't
# flip the visible verb 10× per second. Cleared whenever elapsed_s
# resets to 0 (new turn). Rotation is random per second from the
# pool — same verb stable for one wall-clock second, fresh pick on
# the next. Mirrors Claude Code's 1Hz verb cycle.
_VERB_CACHE: dict[int, str] = {}


def _verb_for_tick(elapsed_s: int) -> str:
    """Round-27 Claude-parity (v2.1.116): on top of the rotating verb,
    append an inline "still thinking" / "thinking more" / "almost done
    thinking" suffix at 15s / 45s / 90s. Per Anthropic's documented
    design (issue #50510), this dampens the "is it stuck?" panic on
    extended-thinking sessions.

    Round-94: results memoized per `elapsed_s` second so the render
    loop at 10Hz observes a stable 1Hz rotation. Cache resets when
    `elapsed_s == 0` (new turn).

    Verb selection is RANDOM, not modular-deterministic, per the
    research finding that Claude picks "a fresh word each time it
    needs one" — avoids the "ugh, here comes 'Considering' again on
    schedule" pattern that betrays a fixed cycle.
    """
    import random as _random
    # New-turn detection — clear stale cache so the next turn doesn't
    # accidentally hand back yesterday's verbs.
    if elapsed_s <= 0:
        _VERB_CACHE.clear()
        first = _THINKING_VERBS_EARLY[0]
        _VERB_CACHE[0] = first
        return first
    cached = _VERB_CACHE.get(elapsed_s)
    if cached is not None:
        return cached
    pool = _THINKING_VERBS_EARLY if elapsed_s < 30 else _THINKING_VERBS_LONG
    base = _random.choice(pool)
    if elapsed_s >= 90:
        result = f"{base} · almost done thinking"
    elif elapsed_s >= 45:
        result = f"{base} · thinking more"
    elif elapsed_s >= 15:
        result = f"{base} · still thinking"
    else:
        result = base
    _VERB_CACHE[elapsed_s] = result
    # Bound cache growth — a single turn shouldn't last >1h.
    if len(_VERB_CACHE) > 4096:
        _VERB_CACHE.clear()
        _VERB_CACHE[elapsed_s] = result
    return result


# Backward-compat alias for the older audit scenario.
_THINKING_VERBS = _THINKING_VERBS_EARLY + _THINKING_VERBS_LONG


# Round-95 turn-6: deterministic lifecycle labels. The vague verb pool
# above ("comparing", "almost done thinking", "still thinking", ...) read
# as casual chatbot fluff — wrong tone for a commercial autonomous-coding
# product. The user explicitly called this out: "looks unprofessional and
# does not match the clean activity summary style we want."
#
# This map drives ActivityLine.render() when `current_tool` is empty
# (i.e. the model is reasoning, not invoking a tool). One stable label
# per phase, no rotation, no "thinking more" suffixes. The companion
# `_lifecycle_label` helper picks the active phase based on the
# `phase` reactive set by app.py.
_LIFECYCLE_LABELS: dict[str, str] = {
    # Round-96.7: polished labels with ellipsis for active phases
    # so the rail reads as a live activity timeline, not a static
    # state. "Processing result" was renamed to "Reviewing result…"
    # because the user explicitly flagged the original phrasing as
    # internal-debug. New phases: "inspecting", "editing",
    # "finalizing" — fired by the tool-aware phase router in app.py.
    #
    # Round-96.7b: contextual run_bash phases (`running_tests`,
    # `checking_git`, `installing`) so the rail reads as
    # "Running test suite · Bash(...)" instead of the generic
    # "Running command · Bash(...)" when the activity is recognizable.
    "planning":    "Planning…",
    "thinking":    "Planning…",      # alias of planning — early default
    "approval":    "Awaiting approval",
    "running":     "Running command",
    "running_tests":   "Running test suite",
    "checking_git":    "Checking git",
    "installing":      "Installing dependencies",
    "inspecting":  "Inspecting project",
    "searching":   "Searching",
    "editing":     "Editing files",
    "processing":  "Reviewing result…",
    "finalizing":  "Finalizing…",
    "completed":   "Completed",
    "failed":      "Failed",
    "timeout":     "Timed out",
    "interrupted": "Interrupted",
}


# Round 96.25: phases that ALWAYS render `↓` regardless of the
# `live_token_dir` reactive. These are output-lifecycle phases —
# the model's decision is already on screen, a tool is running,
# the user is reviewing, etc. Smoke retest live: round 96.24's
# event-driven flag never flipped to "down" when the agent went
# straight from request to tool_call (no text delta), so the rail
# stayed on `↑` through Reviewing/Approval/Running. Phase-derived
# direction makes the public meter match what the user is actually
# looking at: the model's output side of the turn.
_PHASES_FORCE_DOWN: frozenset[str] = frozenset({
    "approval",
    "running", "running_tests", "checking_git", "installing",
    "processing",      # "Reviewing result…"
    "finalizing",
    "inspecting",      # read-side tools
    "searching",       # round 96.29: glob/grep mid-flight
    "editing",         # write-side tools
    "completed", "failed", "timeout", "interrupted",
})


def _format_elapsed_short(seconds: int) -> str:
    """Round-96.7c: compact elapsed-time format. `45s` for sub-minute,
    `1m 18s` for longer runs. Drops the seconds when zero (`2m`).
    Used by the activity rail so a long-running operation reads as
    `2m 7s` rather than `127s`."""
    s = max(0, int(seconds))
    if s < 60:
        return f"{s}s"
    m, rem = divmod(s, 60)
    if rem == 0:
        return f"{m}m"
    return f"{m}m {rem}s"


def _lifecycle_label(phase: str, elapsed_s: int) -> str:
    """R227: thinking-class phases (planning / thinking / processing
    / finalizing) now render PrometheUS-themed playful verbs
    (Forging…, Smelting…, Channeling…, etc.) by default. Tool-
    specific phases (approval, running, running_tests, searching,
    editing, etc.) and terminal states (completed, failed, timeout,
    interrupted) keep their concrete lifecycle labels because they
    convey real lifecycle info that playful verbs would obscure.

    Set `PROMETHEUS_PLAYFUL_VERBS=0` to restore the legacy
    Planning… / Working… / Reviewing result… / Finalizing… labels.
    """
    # R227: try playful-verb path first for thinking-class phases.
    try:
        from prometheus.ui.playful_verbs import label_for_phase
        playful = label_for_phase(phase, elapsed_s)
        if playful is not None:
            return playful
    except Exception:
        pass
    if phase in _LIFECYCLE_LABELS and phase != "thinking":
        return _LIFECYCLE_LABELS[phase]
    if int(elapsed_s) < 8:
        return "Planning…"
    return "Working…"


def _thinking_phrase_for(elapsed_s: int) -> str:
    """Round 96.28 (research-driven): parenthetical thinking-state
    phrase from the v2.1.116 changelog's documented progression
    `still thinking → thinking more → almost done thinking`.

    `thinking some more` was REMOVED — it appeared in no official
    source, only my prior speculation. The three phrases above are
    the canonical Claude Code rotation set.

    Time-bucketed progression:
      <  8s   ""                      (suppressed — too early)
      <  30s  "still thinking"
      <  90s  "thinking more"
      >= 90s  "almost done thinking"
    """
    e = max(0, int(elapsed_s))
    if e < 8:
        return ""
    if e < 30:
        return "still thinking"
    if e < 90:
        return "thinking more"
    return "almost done thinking"


class ActivityLine(Static):
    """Single-line activity indicator above the input row.

    When busy, renders:
        ✳ thinking · 12s · ↓1.2k    esc to interrupt

    The elapsed seconds and live output-token counter ride right next to
    the spinner so users can watch progress in real time. Both use one
    bright color (cyan) so they pop against the amber brand.
    """
    DEFAULT_CSS = """
    ActivityLine { padding: 0 2; height: 1; color: white; }
    ActivityLine.-hidden { display: none; }
    """
    busy: reactive[bool] = reactive(False, recompose=False)
    current_tool: reactive[str] = reactive("", recompose=False)
    # Round 96.27: when an in-progress todo exists, its subject is
    # set here and used as the rail label, matching Claude Code's
    # task-driven rail rhythm:
    #   `* Designing round 90 TaskState… (2m 47s · ↑ 7.0k tokens · still thinking)`
    # When empty, the rail falls back to lifecycle labels
    # (Planning… / Working… / Awaiting approval / etc).
    current_task: reactive[str] = reactive("", recompose=False)
    spinner_frame: reactive[int] = reactive(0, recompose=False)
    elapsed_s: reactive[int] = reactive(0, recompose=False)
    live_tokens: reactive[int] = reactive(0, recompose=False)
    # Round 96.14: input-direction tokens for the live rail. When > 0
    # the rail surfaces both `↑input · ↓output` instead of just the
    # output side. Smoke 6 retest live screenshots showed `↓82.7k
    # tokens` only — the input direction was tracked but never fed
    # into the rail render.
    live_tokens_in: reactive[int] = reactive(0, recompose=False)
    # Round 96.18: which arrow to render on the public rail. The
    # rail shows ONE token segment (Claude-style — no `input` /
    # `output` labels, no both-arrow split). app.py picks the
    # direction per tick based on which side is currently moving:
    # `down` when output streamed since last tick, `up` when only
    # input grew (e.g. a large context load before any response
    # streams). Falls back gracefully when one side is unknown.
    live_token_dir: reactive[str] = reactive("down", recompose=False)
    # Round 96.16: live "thought for Ys" segment on the public rail.
    # The post-turn summary already shows `thought for Ys` (elapsed
    # minus tool runtime minus approval wait). The live rail had only
    # `(elapsed · ↓tokens)` — users wanted the full Claude-style
    # rhythm `(elapsed · ↓tokens · thought for Ys)`. Fed from app.py
    # via _update_status, which has the same elapsed/tool/approval
    # numbers it uses for the post-turn summary.
    live_thought_s: reactive[int] = reactive(0, recompose=False)
    # Round-95 turn-6: deterministic lifecycle phase. App.py sets this
    # before mounting an approval card and clears it on tool_result.
    # When empty/"thinking", the label falls through to the
    # planning→working default. See _lifecycle_label() for the mapping.
    phase: reactive[str] = reactive("thinking", recompose=False)
    # Last non-empty line of bash output, shown after the verb so
    # users know whether a long install is still moving. Matches the
    # Codex CLI background-terminal pattern.
    last_output_line: reactive[str] = reactive("", recompose=False)

    def watch_last_output_line(self, _) -> None: self.refresh()

    def watch_busy(self, _) -> None:
        self.set_class(not self.busy, "-hidden")
        self.refresh()

    def watch_current_tool(self, _) -> None: self.refresh()
    def watch_current_task(self, _) -> None: self.refresh()
    def watch_spinner_frame(self, _) -> None: self.refresh()
    def watch_elapsed_s(self, _) -> None: self.refresh()
    def watch_live_tokens(self, _) -> None: self.refresh()
    def watch_live_tokens_in(self, _) -> None: self.refresh()
    def watch_live_token_dir(self, _) -> None: self.refresh()
    def watch_live_thought_s(self, _) -> None: self.refresh()
    def watch_phase(self, _) -> None: self.refresh()

    def render(self) -> Any:
        if not self.busy:
            return Text("")
        frame = SPINNER_FRAMES[self.spinner_frame % len(SPINNER_FRAMES)]
        # Round-95 turn-6/9 status rail polish: deterministic lifecycle
        # labels — no more random verb rotation. Priority:
        #   1. phase == "approval" + current_tool → "Awaiting approval ·
        #      Bash(...)"  (turn-9 fix: must NOT show "[tool] Bash · 264s"
        #      while the user is reading an approval card — that read as
        #      "the command has been running for 264 seconds" and made
        #      PrometheUS look slow when most of that time was the user
        #      deciding off-loop).
        #   2. current_tool set + phase != "approval" → "Running command ·
        #      Bash(...)"  (the tool is actually executing; commercial
        #      language, no debug-style "[tool]" prefix).
        #   3. phase explicitly set (e.g. "processing" between iters) →
        #      that label.
        #   4. fallback → "Planning" early in turn / "Working" later.
        phase = self.phase or "thinking"
        # Round 96.28 (research-driven): label decision tree matches
        # Claude Code's actual public rail rhythm. Tool-name
        # qualifier prefixes (`Running command · `, `Editing files
        # · `, `Inspecting project · `, etc.) are DROPPED — Claude
        # rail shows `Verb…` or task subject only; the tool name
        # appears on the receipt, not the rail (research finding
        # from issue #19663). Approval phase keeps the
        # `Awaiting approval · <Tool>` shape because the user
        # actively needs to see what they're approving.
        task = (self.current_task or "").strip()
        if self.current_tool and phase == "approval":
            label = f"Awaiting approval · {self.current_tool}"
        elif task:
            # Task-driven label with ellipsis — Claude rhythm.
            label = f"{task}…"
        else:
            label = _lifecycle_label(phase, self.elapsed_s)
        # Word-boundary truncation — keeps last whole word so we don't
        # cut mid-token. Falls back to hard cut when there's no space
        # in the prefix (e.g. one giant URL).
        if len(label) > 80:
            cut = label[:77].rsplit(" ", 1)
            label = (cut[0] if len(cut) == 2 and cut[0] else label[:77]) + "…"
        # Round 96.21: spinner color flips to ERROR on `Awaiting
        # approval` so a stalled-on-user state is visually
        # distinguishable from a still-running tool. Matches the
        # public CLI convention (Claude v2.1.122) — same physics: the
        # turn isn't crashing, it's waiting on the human, and the
        # color cue lets the user spot it from across the room.
        spinner_style = ERROR if phase == "approval" else AMBER
        t = Text()
        t.append(frame + " ", style=spinner_style)
        t.append(label, style=INK)
        # Round-96.7c: wrap metrics in parens for a tighter,
        # premium-CLI feel: `✦ Running test suite (1m 18s · ↓1.5k tokens)`.
        # Time format upgrades to `Xm Ys` once elapsed crosses 60s
        # so a long-running operation reads as `2m 7s` rather than `127s`.
        # Round 96.28 (research-driven): `esc to interrupt` is the
        # FIRST segment of the parens block, matching the verbatim
        # Claude rail string from issue #14630:
        #   `✶ Simmering… (esc to interrupt · 1m 2s · ↓ 2.7k tokens · thought for 46s)`
        elapsed_str = _format_elapsed_short(self.elapsed_s)
        metric_parts = ["esc to interrupt", elapsed_str]
        # Round 96.15: public rail shows ONE token metric — prefer
        # `↓output` (what the user expects to see while the model is
        # responding), fall back to `↑input` only when no output has
        # streamed yet. Smoke 6 retest live screenshots showed
        # `↑315.4k input · ↓17.2k output` mid-turn — accurate but
        # noisy; users want Claude-style compactness on the public
        # rail. The both-directions split is preserved internally and
        # surfaces in /stats for diagnostic use.
        def _fmt_tok(n: int) -> str:
            return f"{n / 1000:.1f}k" if n >= 1000 else str(n)

        # Round 96.25: ONE token segment, direction derived from
        # PHASE first, then from the `live_token_dir` reactive.
        # If the current phase is in `_PHASES_FORCE_DOWN` (output-
        # lifecycle: approval, running, processing, inspecting,
        # editing, etc.), the rail ALWAYS shows `↓` regardless of
        # the reactive flag. This fixes the round 96.24 live bug
        # where a turn that went straight from request to tool_call
        # without any text delta kept the rail on `↑` through
        # Reviewing / Approval / Running because the reactive flag
        # only flipped on text events.
        # Pre-stream phases (`thinking`, `planning`) honor the
        # reactive flag so the brief request-assembly window can
        # show `↑`. NEVER renders dual arrows or `input`/`output`/
        # `ctx` labels.
        n_out = int(self.live_tokens) if self.live_tokens > 0 else 0
        n_in = int(self.live_tokens_in) if self.live_tokens_in > 0 else 0
        if phase in _PHASES_FORCE_DOWN:
            # Output-lifecycle: arrow is always ↓.
            if n_out > 0:
                metric_parts.append(f"↓ {_fmt_tok(n_out)} tokens")
            elif n_in > 0:
                metric_parts.append(f"↓ {_fmt_tok(n_in)} tokens")
        elif self.live_token_dir == "up" and n_in > 0:
            metric_parts.append(f"↑ {_fmt_tok(n_in)} tokens")
        elif n_out > 0:
            metric_parts.append(f"↓ {_fmt_tok(n_out)} tokens")
        elif n_in > 0:
            metric_parts.append(f"↑ {_fmt_tok(n_in)} tokens")
        # Round 96.28 (research-driven): the thinking phrase and
        # the `thought for Xs` stat can BOTH appear in the parens
        # at the same time, per the verbatim Claude rail from
        # issue #14630:
        #   `✶ Simmering… (esc to interrupt · 1m 2s · ↓ 2.7k tokens · thought for 46s)`
        # Round 96.27 incorrectly made `thought for Xs` post-hoc
        # only — research showed it surfaces alongside the
        # in-flight rotation. During `phase == "thinking"` we show
        # the rotating phrase (`still thinking` / `thinking more`
        # / `almost done thinking`) AND `thought for Xs` once the
        # threshold is met. Outside thinking, only `thought for Xs`.
        if phase == "thinking":
            phrase = _thinking_phrase_for(self.elapsed_s)
            if phrase:
                metric_parts.append(phrase)
        if self.live_thought_s >= 2:
            metric_parts.append(f"thought for {int(self.live_thought_s)}s")
        t.append("  ", style="")
        t.append("(", style=MUTED)
        for i, part in enumerate(metric_parts):
            if i > 0:
                t.append(" · ", style=MUTED)
            t.append(part, style=CYAN)
        t.append(")", style=MUTED)
        if self.last_output_line:
            tail = self.last_output_line.strip()
            # Long bash output — show start + end so users see both
            # "what's running" and "where it's at" without losing either.
            # Better than naive `[:60]` which drops the percentage / file
            # being installed when it's at the right edge of the line.
            if len(tail) > 80:
                tail = tail[:40] + "…" + tail[-30:]
            t.append("  ·  ", style=MUTED)
            t.append(f"› {tail}", style=DIM)
        # Round 96.28: trailing standalone `    esc to interrupt`
        # tag REMOVED — the hint now lives inside the parens block
        # as the first segment, matching Claude's verbatim rail
        # string from issue #14630.
        # R229 / Item 12: surface a `(ctrl+b to run in background)`
        # hint sub-line when a foreground bash has been running long
        # enough that the user might want to background it. Threshold
        # is 5s — short enough that quick git/ls-class commands don't
        # ever get the hint, long enough that genuinely useful
        # background-able commands (downloads, installers, watchers)
        # surface it well before the user gets tired of waiting.
        try:
            import time as _t_rail
            # Prefer the test-injectable `_host_app` slot, fall back
            # to Textual's self.app when mounted in a live app.
            app = self.__dict__.get("_host_app")
            if app is None:
                try:
                    app = self.app
                except Exception:
                    app = None
            started_at = getattr(app, "_fg_bash_started_at", None) if app else None
            fg_proc = getattr(app, "_fg_bash_proc", None) if app else None
            if started_at is not None and fg_proc is not None:
                elapsed = _t_rail.monotonic() - float(started_at)
                if elapsed >= 5.0:
                    from rich.console import Group as _Group
                    hint = Text()
                    hint.append("    ", style="")
                    hint.append("(ctrl+b to run in background)", style=DIM)
                    return _Group(t, hint)
        except Exception:
            # Never let the hint render kill the whole rail.
            pass
        return t


class VUMeterWidget(Static):
    """5-segment level meter shown while voice recording is active.

    Renders:
        ● rec  ████░    3s   ctrl+space stop · esc cancel
    """
    DEFAULT_CSS = """
    VUMeterWidget { padding: 0 2; height: 1; }
    """
    level: reactive[float] = reactive(0.0, recompose=False)
    elapsed_s: reactive[int] = reactive(0, recompose=False)

    def watch_level(self, _) -> None: self.refresh()
    def watch_elapsed_s(self, _) -> None: self.refresh()

    def render(self) -> Any:
        n_full = int(self.level * 5 + 0.5)
        t = Text()
        t.append("● rec  ", style=ERROR)
        for i in range(5):
            if i < n_full:
                color = SUCCESS if i < 2 else (AMBER if i < 4 else ERROR)
                t.append("█", style=color)
            else:
                t.append("░", style=MUTED)
        t.append(f"   {self.elapsed_s:>2}s", style=DIM)
        t.append("    ctrl+space stop · esc cancel", style=DIM)
        return t


class FileSuggestions(Static):
    """Popup-style list of files matching the last @-prefix in the input.

    Mirrors SlashSuggestions but for files. Used by the @ file picker.
    """
    DEFAULT_CSS = """
    FileSuggestions {
        padding: 0 2;
        height: auto;
        max-height: 12;
        background: black;
    }
    FileSuggestions.-hidden { display: none; }
    """
    matches: reactive[list[str]] = reactive(list, recompose=False)
    selected: reactive[int] = reactive(0, recompose=False)

    def watch_matches(self, _) -> None:
        self.set_class(not self.matches, "-hidden")
        self.refresh()

    def watch_selected(self, _) -> None:
        self.refresh()

    def render(self) -> Any:
        if not self.matches:
            return Text("")
        from rich.console import Group
        rows = []
        visible = self.matches[:10]
        for i, path in enumerate(visible):
            arrow = "› " if i == self.selected else "  "
            arrow_style = AMBER if i == self.selected else MUTED
            line = Text()
            line.append(arrow, style=arrow_style)
            line.append("@", style=AMBER if i == self.selected else DIM)
            line.append(path, style=INK if i == self.selected else DIM)
            rows.append(line)
        if len(self.matches) > 10:
            rows.append(Text(f"  …{len(self.matches) - 10} more", style=DIM))
        return Group(*rows)

    def select_next(self) -> None:
        if self.matches:
            self.selected = (self.selected + 1) % min(len(self.matches), 10)

    def select_prev(self) -> None:
        if self.matches:
            self.selected = (self.selected - 1) % min(len(self.matches), 10)


class SlashSuggestions(Static):
    """Popup-style list of matching slash commands shown above the input.

    Hidden unless the prompt input starts with `/`. Updates live as the
    user types. Up/Down navigates; Enter or Tab commits the highlighted
    command.
    """
    DEFAULT_CSS = """
    SlashSuggestions {
        padding: 0 2;
        height: auto;
        max-height: 12;
        background: black;
    }
    SlashSuggestions.-hidden { display: none; }
    """
    matches: reactive[list[tuple[str, str]]] = reactive(list, recompose=False)
    selected: reactive[int] = reactive(0, recompose=False)

    def watch_matches(self, _) -> None:
        self.set_class(not self.matches, "-hidden")
        self.refresh()

    def watch_selected(self, _) -> None:
        self.refresh()

    def render(self) -> Any:
        if not self.matches:
            return Text("")
        from rich.console import Group
        rows = []
        # Show up to 10 to keep the panel compact.
        visible = self.matches[:10]
        max_name = max(len(name) for name, _ in visible) + 2
        for i, (name, desc) in enumerate(visible):
            arrow = "› " if i == self.selected else "  "
            arrow_style = AMBER if i == self.selected else MUTED
            name_style = AMBER if i == self.selected else INK
            line = Text()
            line.append(arrow, style=arrow_style)
            line.append(("/" + name).ljust(max_name + 1), style=name_style)
            line.append(desc, style=DIM)
            rows.append(line)
        if len(self.matches) > 10:
            rows.append(Text(f"  …{len(self.matches) - 10} more", style=DIM))
        return Group(*rows)

    def select_next(self) -> None:
        if self.matches:
            self.selected = (self.selected + 1) % min(len(self.matches), 10)

    def select_prev(self) -> None:
        if self.matches:
            self.selected = (self.selected - 1) % min(len(self.matches), 10)


class QuestionPrompt(Static, can_focus=True):
    """A multi-choice prompt the model can ask the user.

    Renders:
        Do you want to proceed?
      › 1. Yes
        2. No

      Esc to cancel · Tab to amend · ctrl+e to explain

    Use up/down or 1-9 to navigate, Enter to commit, Esc to cancel.

    Focusable so digit keys hit this widget directly (without Input
    swallowing them as text input).
    """
    DEFAULT_CSS = """
    QuestionPrompt { padding: 0 2; height: auto; }
    QuestionPrompt:focus { background: black; }
    """
    selected: reactive[int] = reactive(0, recompose=False)

    def __init__(self, question: str, options: list[str]) -> None:
        super().__init__()
        self.question = question
        self.options = options
        self.selected = 0

    def watch_selected(self, _) -> None:
        self.refresh()

    def render(self) -> Any:
        from rich.console import Group
        head = Text(self.question, style=INK)
        rows = []
        for i, opt in enumerate(self.options):
            arrow = "› " if i == self.selected else "  "
            number_style = AMBER if i == self.selected else DIM
            label_style = INK if i == self.selected else DIM
            line = Text()
            line.append(arrow, style=AMBER)
            line.append(f"{i + 1}. ", style=number_style)
            line.append(opt, style=label_style)
            rows.append(line)
        footer = Text("Esc to cancel · Tab to amend · ctrl+e to explain", style=DIM)
        return Group(head, *rows, Text(""), footer)

    def select_next(self) -> None:
        self.selected = (self.selected + 1) % len(self.options)

    def select_prev(self) -> None:
        self.selected = (self.selected - 1) % len(self.options)


class InlineApproval(Static):
    """Inline arrow-key approval picker for a tool action.

    Round-22 Claude-parity layout:

        ● Bash command
            winget install --id Opera.Opera -e --accept-source-agreements
            Install Opera browser via winget

          Do you want to proceed?
          ❯ 1. Yes
            2. Yes, and don't ask again for `winget`
            3. No, and tell me what to do differently (esc)

            Esc to cancel · Tab to amend

    Selection semantics:
        Yes               → approve this one call
        Yes, don't ask    → approve + remember this prefix (skipAll mode)
        No                → deny
    """
    DEFAULT_CSS = """
    InlineApproval { padding: 0 2; height: auto; }
    """
    selected: reactive[int] = reactive(0, recompose=False)

    # Round-22: Claude Code's option wording verbatim. The "don't ask"
    # prefix is computed per-call from the parsed command and stitched
    # into the label by the caller; default placeholder is the bare
    # tool kind. Hotkeys are 1/2/3 (digits) — `y/a/n` legacy aliases
    # remain supported in the on_key handler for muscle memory.
    @staticmethod
    def labels_for(kind: str = "this command") -> list[str]:
        # Round-43: option-2 wording was per-pattern ("for `winget`") but
        # actually flips to acceptEdits mode session-wide. Honest label
        # now describes the real behavior. Per-pattern persistence is a
        # planned future round (matches CC's still-buggy `Bash(cd:*)`
        # rule writeback, issue #29400 — community has been waiting on it).
        return [
            "Yes",
            "Yes, and don't ask again this session",
            "No, and tell me what to do differently (esc)",
        ]

    def __init__(
        self, question: str, *, header: str = "",
        kind: str = "this command",
        meta: dict | None = None,
    ) -> None:
        """Round-95 Phase B: optional `meta` adds a structured info
        block between the body and the prompt. Shapes the approval
        card into a trustable artifact:
            cwd:     <working dir>
            risk:    read-only / writes-files / network / destructive
            timeout: 180s
            why:     <one-line reason>
        Any subset of these keys may be present; missing keys are
        skipped. `meta=None` keeps the legacy compact card.
        """
        super().__init__()
        self.question = question
        self.header = header
        self.kind = kind
        self.meta = meta or {}
        self.LABELS = self.labels_for(kind)
        self.selected = 0

    def watch_selected(self, _) -> None:
        self.refresh()

    def render(self) -> Any:
        from rich.console import Group
        # The caller passes the model's natural-language description as
        # `question`. The verbatim command (or other primary content)
        # arrives in the body via `\n`-split. Layout matches Claude
        # Code: header line first (e.g. "Bash command"), command
        # verbatim second, description (dim) third.
        if "\n" in self.question:
            primary, _, secondary = self.question.partition("\n")
        else:
            primary, secondary = self.question, ""
        # Header — round-50: ● (BLACK CIRCLE) instead of ⏺ (RECORD).
        # Windows Terminal + Cascadia Code renders ⏺ as a teal emoji
        # box even with U+FE0E. ● is guaranteed monochrome on every
        # font and renders amber via the style.
        head = Text()
        head.append("  ● ", style=AMBER)
        # Round 97.3: subagent provenance. When a background agent
        # triggers an approval, prefix the header with `Agent(<name>)
        # wants to run ` so the user knows which agent is asking.
        # This was the round-97 live failure: a stuck `Bash command
        # pwd` card under Agent 3 looked like a generic parent
        # request — user couldn't tell who needed approval.
        from_agent = (self.meta or {}).get("from_agent_name", "")
        if from_agent:
            name_disp = (
                from_agent[:48] + ("…" if len(from_agent) > 48 else "")
            )
            head.append(f"Agent({name_disp}) wants to run ", style=DIM)
        head.append(self.header or "Tool action", style=INK)
        # Primary line — verbatim command / target. Color INK so it
        # reads as primary content, not chrome.
        primary_row = Text()
        primary_row.append("    ", style="")
        primary_row.append(primary, style=INK)
        body_renderables: list[Text] = [primary_row]
        # Secondary description line (dim).
        if secondary.strip():
            for line in secondary.splitlines()[:8]:
                row = Text("    ")
                # Diff-style coloring still respected when present so
                # edit_file / multi_edit previews keep red/green hunks.
                if line.startswith("+++") or line.startswith("---") or line.startswith("@@"):
                    row.append(line, style=DIM)
                elif line.startswith("+"):
                    row.append(line, style=SUCCESS)
                elif line.startswith("-"):
                    row.append(line, style=ERROR)
                else:
                    row.append(line, style=DIM)
                body_renderables.append(row)
        # Round-95 Phase B (turn-4 refinement): metadata block now
        # includes `why` (synthesized when the model didn't pass a
        # description) and `expected` duration. Risk has 5 buckets
        # with `low` mapped to green for trust on test-runners.
        meta_rows: list[Text] = []
        # Round 96.13: trim the approval card to the rows users
        # actually need to make a decision. Smoke 6 retest feedback:
        # the public approval block read as a debug TUI dump (`why /
        # expected / cwd / risk / timeout` × every approval). The
        # public CLI shows ONLY `why` + `expected` by default — both
        # short, both meaningful. `cwd`, `risk`, `timeout` stay in
        # `self.meta` for internal consumers (audit log, future
        # /verbose-approvals toggle) but don't appear on screen.
        meta_order = [
            ("why",      "why",       INK),
            ("expected", "expected",  DIM),
        ]
        for key, label, color in meta_order:
            value = self.meta.get(key)
            if value in (None, "", []):
                continue
            row = Text("    ")
            row.append(f"{label:<8} ", style=DIM)
            row.append(str(value)[:120], style=color or INK)
            meta_rows.append(row)

        # "Do you want to proceed?" prompt line above options.
        prompt_row = Text()
        prompt_row.append("    Do you want to proceed?", style=INK)
        # Options
        rows = []
        for i, label in enumerate(self.LABELS):
            arrow = "❯ " if i == self.selected else "  "
            arrow_style = AMBER if i == self.selected else MUTED
            num_style = AMBER if i == self.selected else DIM
            label_style = INK if i == self.selected else DIM
            line = Text()
            line.append(f"    {arrow}", style=arrow_style)
            line.append(f"{i + 1}. ", style=num_style)
            line.append(label, style=label_style)
            rows.append(line)
        # R228: restore the Tab + Ctrl+E hints. The R96.28 simplified
        # form was right when those keys were unbound — showing them
        # without working bindings would have been misleading. Now
        # both work (app.py:_pending_approval handler):
        #   Tab    → close card + populate input with the command so
        #             the user can edit and resubmit
        #   Ctrl+E → close card + populate input with an explain-this
        #             prompt the user can send back to the agent
        footer = Text(
            "    Esc to cancel · Tab to amend · ctrl+e to explain",
            style=DIM,
        )
        # Insert meta block (if any) between body and prompt.
        meta_block: list[Text] = []
        if meta_rows:
            meta_block = [Text("")] + meta_rows
        return Group(
            head, *body_renderables, *meta_block, Text(""),
            prompt_row, *rows, Text(""), footer,
        )

    def select_next(self) -> None:
        self.selected = (self.selected + 1) % len(self.LABELS)

    def select_prev(self) -> None:
        self.selected = (self.selected - 1) % len(self.LABELS)
