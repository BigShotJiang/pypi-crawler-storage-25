"""run_bash: execute a shell command with timeout, streaming stdout/stderr.

We capture combined output up to a cap so the model gets a useful tool
message back. Heavy outputs are truncated with a tail-keep policy.
"""
from __future__ import annotations

import asyncio
import os
import re
import shlex
import sys
import time
from typing import Any

from prometheus.tools.base import (
    PermissionDenied,
    SideEffect,
    Tool,
    ToolContext,
    ToolResult,
)

MAX_OUTPUT = 30_000  # chars fed back to model
DEFAULT_TIMEOUT = 180  # seconds — short enough that hung commands fail fast,
                      # long enough for typical builds. Installer commands
                      # should pass timeout_seconds=600 explicitly.

# Heuristic: if the command starts with one of these, allow more time.
LONG_RUNNING_PREFIXES = (
    "winget install", "winget upgrade", "choco install", "scoop install",
    "brew install", "brew upgrade", "apt-get install", "apt install",
    "dnf install", "yum install", "pacman -s", "pacman -syu",
    "npm install", "npm i ", "yarn install", "pnpm install",
    "pip install", "uv sync", "poetry install", "cargo install",
    "go install", "go build", "make ", "cmake --build", "docker build",
    "docker pull", "gradle build", "mvn install", "mvn package",
)
LONG_RUNNING_TIMEOUT = 600

# Map known cryptic exit codes to human-readable hints. Helps the model
# recover instead of giving up on `exit 2316632084` and similar.
#
# Round 96.12: rc=1 ("process: generic failure") was REMOVED. Smoke 6
# retest live case: pytest exits 1 on a failing assertion → the bash
# receipt summary read `exit 1 · process: generic failure` which is
# misleading public-facing copy (the failure isn't generic — it's a
# specific test assertion). The output already explains the failure
# in detail; a generic hint just adds public noise. For test-runner
# commands specifically, _explain_exit detects pytest-style failure
# markers in the output and returns a clean test-failure hint
# instead.
EXIT_CODE_HINTS: dict[int, str] = {
    # winget — see microsoft/winget-cli/AppInstallerErrors.h
    -1978335212: "winget: no applications matched the query (id wrong?). Run `winget search <name>`.",
     2316632084: "winget: no applications matched the query (id wrong?). Run `winget search <name>`.",
    -1978335230: "winget: package not installed.",
    -1978335231: "winget: install failed; check installer log.",
    -1978335211: "winget: package agreements not accepted (use --accept-source-agreements --accept-package-agreements).",
    -1978335189: "winget: package already installed.",
    -1978335187: "winget: invalid command line arguments.",
    # generic
    127: "shell: command not found (PATH or installation issue).",
    126: "shell: permission denied or not executable.",
    # rc=1 deliberately omitted — see comment above.
}


# Round 96.12: pytest / common test-runner failure markers. When rc!=0
# and the output contains one of these, _explain_exit returns a
# context-aware "tests failed" hint instead of falling through to ""
# (or, pre-96.12, the unhelpful "process: generic failure" string).
_TEST_FAILURE_PATTERNS = (
    " failed in ",   # pytest: "1 failed in 0.39s"
    " failed, ",     # pytest mixed: "1 failed, 4 passed in 0.5s"
    "FAILED ",       # pytest header line: "FAILED tests/test_x.py::..."
    "AssertionError",
    "Test Failed",   # rust / go / common
    "FAIL\t",        # go test failure marker
)


_TEST_RESULT_LINE_RE = re.compile(
    r"((?:\d+ failed(?:, \d+ passed)?|\d+ passed)"
    r"(?:, \d+ skipped)?(?:, \d+ warnings?)?"
    r"(?:, \d+ errors?)?"
    r" in [\d.]+s)"
)


def _build_command_summary(rc: int, output: str) -> str:
    """Round 96.13: build the public-facing receipt summary.

    For test runners, parse the canonical pytest-style result line
    ("N failed in X.Xs", "N passed in X.Xs", etc.) and produce a
    `Tests failed · …` / `Tests passed · …` summary so the receipt
    reads as a meaningful public message rather than raw exit-code
    telemetry. Non-test commands fall through to `exit N`.

    Examples:
      "1 failed in 0.43s"         → "Tests failed · 1 failed in 0.43s"
      "356 passed in 3.81s"       → "Tests passed · 356 passed in 3.81s"
      "1 failed, 4 passed in 0.5s" → "Tests failed · 1 failed, 4 passed in 0.5s"
    """
    # Search the last ~30 lines (pytest puts the summary at the very
    # end). Avoids accidental matches inside warning text.
    if output:
        tail = "\n".join(output.splitlines()[-30:])
        m = _TEST_RESULT_LINE_RE.search(tail)
        if m:
            line = m.group(1)
            label = "Tests failed" if "failed" in line else "Tests passed"
            return f"{label} · {line}"
    # Non-test command — keep the simple exit-code form.
    if rc == 0:
        return "exit 0"
    hint = _explain_exit(rc, output)
    if hint:
        short_hint = hint.split(".")[0]
        return f"exit {rc} · {short_hint[:40]}"
    return f"exit {rc}"


# Round 96.29: Windows command-line length is 8191 chars in cmd.exe;
# cmd.exe is the parent shell asyncio.create_subprocess_shell spawns
# on Windows. When the agent emits a multiline PowerShell here-string
# (or a long `pwsh -Command "…"` invocation), the wrapper blows the
# limit and prints `pwsh exited with code 1: The command line is too
# long.` The fix: detect long Windows commands targeting pwsh /
# powershell, write the script body to a temp `.ps1` file, and
# invoke `pwsh -NoProfile -ExecutionPolicy Bypass -File <tempfile>`.
# Threshold ~7000 chars leaves headroom for the pwsh wrapper itself.
_WIN_CMD_LINE_LIMIT_THRESHOLD = 7000


def _maybe_rewrite_powershell_for_length(
    cmd: str,
) -> tuple[str, str | None]:
    """Round 96.29: rewrite a long PowerShell command to use a temp
    `.ps1` file so it doesn't blow Windows' 8191-char command-line
    limit.

    Returns (rewritten_cmd, tempfile_path_or_None). Caller deletes
    the tempfile after the subprocess exits.

    Heuristic: only rewrite if
      1. running on Windows (sys.platform == "win32"), and
      2. command length > 7000 chars OR contains literal newlines, and
      3. the command starts with `pwsh ` or `powershell ` and uses
         `-Command` (the form that hits the length limit).
    Other long commands fall through unchanged — caller handles the
    failure cleanly via the existing error path.
    """
    if sys.platform != "win32":
        return cmd, None
    if len(cmd) <= _WIN_CMD_LINE_LIMIT_THRESHOLD and "\n" not in cmd:
        return cmd, None
    head = cmd.lstrip()
    head_lower = head.lower()
    is_powershell = (
        head_lower.startswith("pwsh ")
        or head_lower.startswith("pwsh.exe ")
        or head_lower.startswith("powershell ")
        or head_lower.startswith("powershell.exe ")
    )
    if not is_powershell:
        return cmd, None
    # Find `-Command` (case-insensitive). PowerShell also supports
    # `-c` short form.
    import re as _re
    m = _re.search(r"\s-(?:Command|c)\s+", head, flags=_re.IGNORECASE)
    if not m:
        # Long pwsh invocation but no -Command — nothing to rewrite.
        return cmd, None
    script_body = head[m.end():].strip()
    # Strip surrounding quotes if the agent wrapped the script in
    # them (`pwsh -Command "..."` or `'...'`).
    if len(script_body) >= 2 and script_body[0] in ('"', "'"):
        if script_body[-1] == script_body[0]:
            script_body = script_body[1:-1]
    if not script_body:
        return cmd, None
    # Write to a temp .ps1.
    import tempfile as _tempfile
    fd, tmp_path = _tempfile.mkstemp(suffix=".ps1", prefix="prometheus_pwsh_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(script_body)
    except Exception:
        try:
            os.close(fd)
        except Exception:
            pass
        return cmd, None
    # Invoke via -File. NoProfile keeps this hermetic; ExecutionPolicy
    # Bypass lets the script run without per-machine policy fighting.
    rewritten = (
        f"pwsh -NoProfile -ExecutionPolicy Bypass -File "
        f'"{tmp_path}"'
    )
    return rewritten, tmp_path


def _explain_exit(rc: int, output: str = "") -> str:
    """Best-effort human hint for a non-zero rc.

    Round 96.12: an optional `output` argument lets the caller route
    test-runner failures (any rc!=0 with pytest-style failure markers
    in the output) to a clean "test failures (see output)" hint
    instead of "process: generic failure". The output explains the
    real cause; the hint just labels the receipt.
    """
    # Some exit codes appear as huge unsigned values in PowerShell.
    candidates = {rc, rc & 0xFFFFFFFF, rc - 0x100000000 if rc > 0x7FFFFFFF else rc}
    for c in candidates:
        if c in EXIT_CODE_HINTS:
            return EXIT_CODE_HINTS[c]
    if rc != 0 and output:
        for pat in _TEST_FAILURE_PATTERNS:
            if pat in output:
                return "test failures (see output)."
    return ""

# Commands that we will *never* run regardless of permission mode.
# These are unambiguous foot-guns and the agent is rerouted.
FORBIDDEN_PREFIXES = (
    "rm -rf /",
    "rm -rf /*",
    ":(){:|:&};:",
    "mkfs",
    "dd if=/dev/zero of=/dev/sd",
    "shutdown ",
    "reboot",
    "halt",
)


# Round-95 turn-8: registered internal tool names that the model
# sometimes mistakes for shell commands. Smoke 4 turn-7 retest live
# bug: after `discover_test_command` failed, the agent ran
# `Bash(discover_test_command)` thinking it was a shell command —
# producing a confusing `'discover_test_command' is not recognized`
# system error. The list is exhaustive over the registered tool
# names (see prometheus/tools/registry.py); first-token match against
# any of these is rejected with a clear message that points the
# model back to the tool-call interface.
INTERNAL_TOOL_NAMES = frozenset({
    "read_file", "write_file", "edit_file", "multi_edit", "apply_patch",
    "glob_files", "list_files", "search_code", "run_bash",
    "bash_output", "kill_shell", "web_fetch", "web_search",
    "todo_write", "calculator", "discover_test_command",
    "ask_user_question", "task",
})


# Round-95 turn-8: Unix-only command heads the model sometimes
# suggests on Windows. Each maps to the internal tool / Windows-
# native command that does the same job. We refuse the original and
# point the model at the right interface instead of letting CMD
# fail with `'ls' is not recognized`.
_UNIX_ONLY_HEADS: dict[str, str] = {
    "ls":     "list_files (internal tool) or `Get-ChildItem` / `dir`",
    "ll":     "list_files (internal tool) or `Get-ChildItem`",
    "cat":    "read_file (internal tool) or `Get-Content`",
    "head":   "read_file with line slicing, or `Get-Content -TotalCount N`",
    "tail":   "read_file with line slicing, or `Get-Content -Tail N`",
    "grep":   "search_code (internal tool) or `Select-String`",
    "egrep":  "search_code (internal tool) or `Select-String`",
    "fgrep":  "search_code (internal tool) or `Select-String`",
    "find":   "glob_files (internal tool) or `Get-ChildItem -Recurse`",
    "which":  "`Get-Command` (PowerShell) or `where.exe` (CMD)",
    "rm":     "`Remove-Item` (PowerShell) or `del` / `rmdir` (CMD)",
    "cp":     "`Copy-Item` (PowerShell) or `copy` (CMD)",
    "mv":     "`Move-Item` (PowerShell) or `move` (CMD)",
    "touch":  "`New-Item` (PowerShell) or write_file (internal tool)",
    "chmod":  "(no Windows equivalent — file ACLs work differently)",
    "chown":  "(no Windows equivalent — use icacls / takeown if needed)",
    "uname":  "`(Get-CimInstance Win32_OperatingSystem).Caption` (PowerShell)",
    # Round 208: real-user bug. The model emitted `TZ="America/Chicago"
    # date` to check time. cmd.exe doesn't understand the env-var prefix
    # AND `date` on cmd is the interactive set-date prompt, not the
    # time printer. Both arms break — refuse with the PowerShell
    # equivalent that actually returns the current time in a tz.
    "date":   (
        "`Get-Date` (PowerShell). For another timezone, use "
        "`[System.TimeZoneInfo]::ConvertTimeFromUtc((Get-Date).ToUniversalTime(), "
        "[System.TimeZoneInfo]::FindSystemTimeZoneById('Central Standard Time'))` "
        "— Windows uses display names like 'Central Standard Time' "
        "(see `Get-TimeZone -ListAvailable`) instead of IANA tz database names."
    ),
    # Round 211: surfaced by user audit. Genuine missing translations.
    "pwd":    "`cd` (no args, prints current dir on cmd.exe) or `Get-Location` (PowerShell).",
    "clear":  "`cls` (cmd.exe / PowerShell). The Unix `clear` is not present on Windows.",
    "source": (
        "Windows venvs activate via `venv\\Scripts\\activate.bat` (cmd.exe) "
        "or `venv\\Scripts\\Activate.ps1` (PowerShell). The Unix "
        "`source venv/bin/activate` form has no Windows equivalent."
    ),
    "export": (
        "`set KEY=value` (cmd.exe) or `$env:KEY = 'value'` (PowerShell). "
        "The Unix `export` builtin doesn't exist on Windows."
    ),
    "sudo":   (
        "Windows uses elevation (UAC), not sudo. Open an elevated "
        "PowerShell/cmd.exe terminal as Administrator, or use "
        "`Start-Process pwsh -Verb RunAs -ArgumentList '...'` to "
        "spawn one inline. The `sudo` command does not exist on "
        "Windows out of the box."
    ),
    "nohup":  (
        "Windows has no nohup. For a detached background process use "
        "`Start-Process -FilePath '<exe>' -ArgumentList '...' -NoNewWindow` "
        "(PowerShell), or run_bash with `run_in_background: true` from "
        "the TUI session."
    ),
}


# NOTE: the `_PYTHON3_RX` definition lives below the
# `import re as _re_shell` line because that import is the canonical
# regex import for this module. Search for "Round 211: `python3` is"
# below.



# Round 208: a leading `KEY=value` (or `KEY="value"`) env-var
# assignment is POSIX shell syntax. cmd.exe/PowerShell don't
# understand it, so a command like `TZ="America/Chicago" date`
# fails with `'TZ="America/Chicago"' is not recognized as an
# internal or external command`. Strip these prefixes BEFORE
# checking the command head so we route the user toward the
# Windows-native alternative for the *real* command (`date` here),
# not for the env-var token.
import re as _re_shell
_ENV_VAR_PREFIX_RX = _re_shell.compile(
    r'^\s*[A-Za-z_][A-Za-z0-9_]*=(?:"[^"]*"|\'[^\']*\'|\S+)\s+',
)


def _strip_env_var_prefixes(cmd: str) -> tuple[str, bool]:
    """Remove leading `KEY=value` (or quoted) tokens. Returns
    ``(remaining_cmd, had_prefix)``. Multiple prefixes are
    stripped iteratively so `FOO=1 BAR=2 baz` reduces to `baz`."""
    had_prefix = False
    while True:
        m = _ENV_VAR_PREFIX_RX.match(cmd)
        if not m:
            return cmd, had_prefix
        had_prefix = True
        cmd = cmd[m.end():]


# Round 211: `python3` is a Unix convention. On Windows the canonical
# binary is `python.exe`; `python3` is usually absent unless the user
# manually created a shim. Auto-rewrite `python3 ...` to `python ...`
# so the agent's natural emission just works. This is a fixup, not a
# refusal — the rewrite is transparent.
_PYTHON3_RX = _re_shell.compile(r"^(\s*)python3(\s+|$)", _re_shell.IGNORECASE)


def _rewrite_python3(cmd: str) -> str:
    """Rewrite `python3 <args>` to `python <args>` on Windows.
    Returns the original command unchanged when no match."""
    if not cmd:
        return cmd
    return _PYTHON3_RX.sub(r"\1python\2", cmd, count=1)


def _windows_unix_redirect(cmd: str) -> str:
    """Round-95 turn-8: when a command's first token is a known
    Unix-only utility, return a refusal message that includes the
    Windows-native or internal-tool equivalent. Empty string means
    the command isn't on the Unix-only list — pass through.

    Round 208: also strip leading `KEY=value` env-var prefixes
    (POSIX-only shell syntax) before checking the head, so we
    route the model toward the Windows alternative for the
    *actual* command instead of letting cmd.exe choke on the
    `TZ="..."` token itself.

    Heuristic: only refuse when the first token (lowercased) is in
    the table AND the command isn't wrapped in `bash -c`/`sh -c`
    (those run under WSL or Git Bash and are user's responsibility).
    """
    if not cmd:
        return ""
    stripped, had_env_prefix = _strip_env_var_prefixes(cmd.strip())
    head = stripped.split(None, 1)[0] if stripped else ""
    head_lower = head.lower().strip("'\"`")
    if head_lower not in _UNIX_ONLY_HEADS:
        return ""
    # Honor explicit POSIX shell wrappers — user opted into bash.
    if head_lower in ("bash", "sh", "zsh"):
        return ""
    redirect = _UNIX_ONLY_HEADS[head_lower]
    note = ""
    if had_env_prefix:
        note = (
            " Also: the leading `KEY=value` env-var prefix is "
            "POSIX-only — on Windows, set the variable separately "
            "(`$env:KEY = 'value'` in PowerShell, `set KEY=value` in CMD)."
        )
    return (
        f"refused on Windows: `{head_lower}` is a Unix-only command "
        f"and is not available in CMD/PowerShell. "
        f"Use {redirect} instead.{note}"
    )


_CMD_NOT_RECOGNIZED_RX = _re_shell.compile(
    r"['\"]?([^'\"\s]+)['\"]?\s+is not recognized as an internal or external command",
    _re_shell.IGNORECASE,
)
_OPERABLE_PROGRAM_RX = _re_shell.compile(
    r"operable program or batch file",
    _re_shell.IGNORECASE,
)


def _windows_cmd_error_hint(output: str) -> str:
    """Round 208: post-process Windows cmd.exe error text and return
    a one-line PowerShell-native recovery hint, or "" if the output
    doesn't match the cmd.exe "not recognized" / "operable program"
    pattern. Used to augment the ToolResult.output string after a
    failed run_bash on Windows so the model has a concrete next step.

    The hint identifies the failing command head from cmd.exe's
    error message and, if it's in `_UNIX_ONLY_HEADS`, points at the
    PowerShell/internal-tool equivalent. Otherwise we surface a
    generic PATH/PowerShell pointer — the raw "operable program or
    batch file" text is diagnostic noise without guidance.
    """
    if not output:
        return ""
    if not (
        _OPERABLE_PROGRAM_RX.search(output)
        or _CMD_NOT_RECOGNIZED_RX.search(output)
    ):
        return ""
    m = _CMD_NOT_RECOGNIZED_RX.search(output)
    head = ""
    if m:
        head = m.group(1).strip("'\"`").lower()
    if head and head in _UNIX_ONLY_HEADS:
        redirect = _UNIX_ONLY_HEADS[head]
        return (
            f"\n\n[Windows hint] cmd.exe rejected `{head}` because it's not a "
            f"Windows command. Use {redirect} instead. Do not retry the same "
            f"command — it will fail the same way."
        )
    if head:
        return (
            f"\n\n[Windows hint] cmd.exe doesn't know `{head}`. If it's a Unix "
            f"tool, use the PowerShell equivalent (Get-ChildItem / Get-Content / "
            f"Select-String / Get-Date / Invoke-WebRequest). If it's a program "
            f"that should be installed, try `winget search {head}` or "
            f"`Get-Command {head}` to check PATH. Do not retry the same "
            f"command — it will fail the same way."
        )
    return (
        "\n\n[Windows hint] cmd.exe couldn't find the program. Use PowerShell "
        "natives (Get-ChildItem, Get-Content, Get-Date, Invoke-WebRequest) or "
        "check PATH with `Get-Command <name>`. Do not retry the same command."
    )


# Round 210: `mkdir -p PATH` is a Unix-ism (the `-p` flag means
# "make parents as needed"). cmd.exe's mkdir doesn't recognize `-p`
# but ALREADY creates intermediate directories natively — so the
# fix is just to drop the `-p` flag, not redirect to a different
# command. Surfaced live in the round-210 T4 portfolio-site task
# where the agent emitted `mkdir -p portfolio/assets` and cmd.exe
# rejected it ("The syntax of the command is incorrect.").
_MKDIR_DASH_P_RX = _re_shell.compile(
    r"^(\s*mkdir)\s+-p\s+",
    _re_shell.IGNORECASE,
)


def _strip_mkdir_dash_p(cmd: str) -> str:
    """Rewrite `mkdir -p X` to `mkdir X` on Windows. cmd.exe's
    mkdir already creates intermediate directories without a flag,
    so the `-p` is just noise that the parser chokes on. Returns
    the original command unchanged when the pattern doesn't match.
    """
    if not cmd:
        return cmd
    return _MKDIR_DASH_P_RX.sub(r"\1 ", cmd, count=1)


# Round 211: T5 (full-stack app) live capture caught
# `mkdir backend frontend backend/data` failing on Windows with
# "The syntax of the command is incorrect." cmd.exe's mkdir parses
# `/` as the start of a switch flag (e.g. `/D`), so a forward-slash
# path component is interpreted as an unknown switch and rejected.
# The fix is path-separator-aware only for native Windows shell
# commands where `/` is unambiguously a separator: mkdir, rmdir, md,
# rd, copy, move, del, type, dir, cd. We do NOT rewrite forward
# slashes inside python / git / node / curl / wget invocations
# because those tools accept forward slashes natively and the args
# can contain URLs / regex / other legitimate slashes.
_PATH_SEP_REWRITE_HEADS = frozenset({
    "mkdir", "md", "rmdir", "rd", "copy", "move", "del", "erase",
    "type", "dir", "cd", "pushd", "popd",
})


def _rewrite_forward_slash_paths_for_cmd(cmd: str) -> str:
    """When the head is a native cmd.exe builtin that uses `/` as a
    switch, rewrite forward slashes in path-like args to backslashes
    so cmd.exe doesn't parse them as switch flags.

    Conservative: only rewrites slashes inside whitespace-delimited
    tokens that *don't* start with `/` (those ARE switches the user
    deliberately passed, like `dir /B`) and don't contain `://` (URL
    patterns). Returns the command unchanged when the head isn't on
    the rewrite list.
    """
    if not cmd:
        return cmd
    parts = cmd.split(None, 1)
    if not parts:
        return cmd
    head = parts[0].lower().strip("'\"`")
    if head not in _PATH_SEP_REWRITE_HEADS:
        return cmd
    if len(parts) == 1:
        return cmd
    # Tokenize the args (preserve quoted strings and switches as-is)
    rest = parts[1]
    tokens = rest.split()
    new_tokens: list[str] = []
    for tok in tokens:
        # Don't touch a leading switch flag (dir /B, copy /Y, etc.)
        if tok.startswith("/") and len(tok) <= 4 and "/" not in tok[1:]:
            new_tokens.append(tok)
            continue
        # Don't touch URLs or anything that looks like one
        if "://" in tok:
            new_tokens.append(tok)
            continue
        # Inside quoted segments leave it alone too — quotes signal
        # the user wanted that exact string
        if tok.startswith(("'", '"')) and tok.endswith(("'", '"')):
            new_tokens.append(tok)
            continue
        new_tokens.append(tok.replace("/", "\\"))
    return f"{parts[0]} {' '.join(new_tokens)}"


# Round 208 follow-up: when the Unix-only redirect points the model
# at a PowerShell cmdlet (Get-Date, Get-ChildItem, Invoke-WebRequest,
# etc.), the model emits the cmdlet bare on the next iteration. But
# run_bash spawns `cmd.exe` on Windows, not PowerShell, so the bare
# cmdlet fails with "is not recognized as an internal or external
# command" — the same failure mode the redirect was supposed to
# prevent. Auto-wrap any leading Verb-Noun token through
# `powershell.exe -NoProfile -Command "<cmd>"` so the cmdlet runs in
# the right interpreter. We use `powershell` (Windows PowerShell 5.1,
# universally present since Vista) instead of `pwsh` (PS 7+, only on
# machines where the user installed it).
_PS_VERB_NOUN_RX = _re_shell.compile(
    r"^([A-Z][a-z]+(?:-[A-Z][A-Za-z0-9]*)+)(\b|$)",
)
# .NET static-method invocation: `[System.TimeZoneInfo]::Method(...)`.
# This is PowerShell-only syntax — cmd.exe can't parse it. The
# round-208 redirect for `date` literally recommends this form, so
# the auto-wrap MUST cover it or the redirect points the model at
# something that fails the same way under cmd.exe.
_PS_DOTNET_HEAD_RX = _re_shell.compile(r"^\[[A-Za-z_][A-Za-z0-9_.]*\]::")

# Round 209: scan the WHOLE command (not just the head) for canonical
# PowerShell cmdlet names. Round-208 round-trip caught Get-Date /
# Get-ChildItem at the head, but the round-209 baseline showed
# `(Get-ChildItem -Recurse | Measure-Object).Count` and
# `if (Test-Path '...') { Remove-Item ... }` slip through because
# the FIRST token is `(` or `if`, not a Verb-Noun. Both forms are
# PowerShell syntax that cmd.exe can't parse, so we need a global
# scan: if a Verb-Noun cmdlet appears anywhere as a standalone token
# (preceded by start / whitespace / `(` / `|` / `;` / `&`), the whole
# command is PowerShell.
_PS_VERB_NOUN_ANYWHERE_RX = _re_shell.compile(
    r"(?:^|[\s(|;&{])"
    r"([A-Z][a-z]+(?:-[A-Z][A-Za-z0-9]*)+)"
    r"(?=\b)"
)
# .NET static method call anywhere in the line:
# `... | Out-String; [System.Guid]::NewGuid()`.
_PS_DOTNET_ANYWHERE_RX = _re_shell.compile(
    r"(?:^|[\s(|;&{])\[[A-Za-z_][A-Za-z0-9_.]*\]::"
)
# PowerShell control-flow / variable-assignment shapes that cmd.exe
# also cannot parse: `if (...)`, `while (...)`, `foreach (...)`,
# `switch (...)`, `try { ... } catch { ... }`, `$var = ...`. When
# the cmd starts with one of these, the whole expression is PS.
_PS_HEAD_PATTERNS = (
    _re_shell.compile(r"^\s*if\s*\("),
    _re_shell.compile(r"^\s*while\s*\("),
    _re_shell.compile(r"^\s*for\s*\("),
    _re_shell.compile(r"^\s*foreach\s*\("),
    _re_shell.compile(r"^\s*switch\s*\("),
    _re_shell.compile(r"^\s*try\s*\{"),
    _re_shell.compile(r"^\s*\$[A-Za-z_][A-Za-z0-9_]*\s*="),
    # parenthesized cmdlet expression: `(Get-X ...).Property`
    _re_shell.compile(r"^\s*\(\s*[A-Z][a-z]+-[A-Z]"),
)


def _looks_like_powershell_cmdlet(cmd: str) -> bool:
    """Return True iff the command contains PowerShell-only syntax
    that cmd.exe can't parse.

    Round 208 first cut: head-token-only (``Get-Date``, ``[Type]::M``).
    Round 209: also catches whole-command shapes the model emits in
    real Windows tasks:

    * ``(Get-ChildItem -Recurse | Measure-Object).Count`` —
      parenthesized cmdlet expressions with property access.
    * ``if (Test-Path '...') { Remove-Item ... }`` —
      PowerShell control flow (``if``/``while``/``foreach``/
      ``switch``/``try``).
    * ``$var = Get-Date`` — variable assignments.
    * Cmdlet names appearing AFTER a pipe / inside a block.

    Heuristic: scan the whole command for standalone Verb-Noun
    cmdlet tokens (preceded by start / whitespace / ``(`` / ``|`` /
    ``;`` / ``&`` / ``{``) or .NET static-method calls. If any
    appears, the command is PowerShell. Plain ``python script.py``
    and ``winget install ...`` are unaffected because they contain
    no PS-shape tokens.
    """
    if not cmd:
        return False
    stripped = cmd.strip()
    if not stripped:
        return False
    # Bail if the user already wrapped through pwsh/powershell —
    # they know what they're doing; double-wrapping breaks quoting.
    head_tok = stripped.split(None, 1)[0].lower().rstrip(".exe")
    if head_tok in ("pwsh", "powershell", "cmd"):
        return False
    # Original head-only matches.
    if _PS_DOTNET_HEAD_RX.match(stripped):
        return True
    head = stripped.split(None, 1)[0]
    if _PS_VERB_NOUN_RX.match(head):
        return True
    # Round 209: PowerShell control-flow / assignment heads.
    for rx in _PS_HEAD_PATTERNS:
        if rx.match(stripped):
            return True
    # Round 209: cmdlet anywhere as a standalone token. Limit to one
    # search to keep this cheap.
    if _PS_VERB_NOUN_ANYWHERE_RX.search(stripped):
        return True
    if _PS_DOTNET_ANYWHERE_RX.search(stripped):
        return True
    return False


def _wrap_powershell_cmdlet(cmd: str) -> str:
    """Wrap ``cmd`` through ``powershell.exe -NoProfile -Command``
    quoting safely. Caller is expected to have checked
    ``_looks_like_powershell_cmdlet`` first.

    The wrapped form embeds the original command inside double
    quotes; any embedded ``"`` is escaped to ``\"`` per cmd.exe rules
    so the outer cmd.exe parser passes the full argument through to
    powershell.exe untouched.

    R232: when ``cmd`` starts with ``[`` (a type-literal expression
    like ``[System.TimeZoneInfo]::ConvertTimeFromUtc(...)``),
    PowerShell's ``-Command`` parser interprets the leading ``[…]``
    as an *attribute* declaration (like ``[Parameter()]``) attached
    to whatever follows, and emits
    ``EndSquareBracketExpectedAtEndOfAttribute`` exit-1. Force script-
    block expression context with ``& { … }`` so the type-literal
    parses as a static-method invocation. Live-screenshot evidence:
    the canonical NYC time one-liner the system prompt instructs the
    model to emit was failing this exact way; the model was working
    around it with ad-hoc ``$tz = …`` two-liners. The wrapper is the
    right layer to fix this — one place, all type-literal calls."""
    stripped = cmd.lstrip()
    if stripped.startswith("["):
        # Wrap in a script-block invocation so the leading [Type] is
        # parsed as a type literal, not as an attribute declaration.
        cmd = "& { " + cmd + " }"
    escaped = cmd.replace('"', r'\"')
    return f'powershell.exe -NoProfile -Command "{escaped}"'


def _is_internal_tool_name(cmd: str) -> str:
    """Return the matched internal tool name if `cmd` looks like a
    bare invocation of one (e.g. `discover_test_command` or
    `read_file foo.py`); empty string otherwise.

    Round-95 turn-8: catches the failure mode where the agent feeds a
    tool name to run_bash. The first whitespace-delimited token is
    the only thing that matters; quoted/escaped variants of arbitrary
    bash commands that happen to contain a tool name elsewhere are
    NOT blocked (otherwise we'd false-positive on
    `python -c \"print('read_file')\"` which is legitimate).
    """
    if not cmd:
        return ""
    head = cmd.strip().split(None, 1)[0] if cmd.strip() else ""
    head = head.strip("'\"`")
    return head if head in INTERNAL_TOOL_NAMES else ""

# DANGEROUS commands that require explicit confirmation EVEN IN skipAll
# mode — these are the patterns that have caused public data-loss
# incidents in commercial agents (Claude Code issues #45893 / #29420 /
# #54477 / #29023). The agent must never silently execute them; we
# force a permission prompt regardless of the bypass-all flag.
#
# Pattern semantics: substring match against the lowercased command,
# matched only when the command actually triggers the destructive
# action (we try not to over-flag — e.g. `git filter-branch --help`
# is harmless, but `git filter-branch -- ...` rewrites history).
_HELP_LOOKAHEAD = r"(?!.*(?:\s|^)(?:--help|-h|--dry-run|-n)(?:\s|$))"

DANGEROUS_REGEXES = [
    # Git history-destroying commands. We require an actual ARG after
    # the subcommand so harmless `--help` / `-h` / `--dry-run` invocations
    # don't trigger. The lookahead matches whitespace (or start-of-string)
    # before the flag because `\b` doesn't fire between two non-word
    # chars (space + `-`), which is what made the first-pass regex flag
    # `git filter-branch --help` as dangerous.
    re.compile(r"\bgit\s+filter-(repo|branch)\b" + _HELP_LOOKAHEAD, re.I),
    re.compile(r"\bgit\s+push\s+(--force\b|-f\b)" + _HELP_LOOKAHEAD, re.I),
    re.compile(r"\bgit\s+reset\s+--hard\s+\S", re.I),
    re.compile(r"\bgit\s+clean\s+-[a-z]*f" + _HELP_LOOKAHEAD, re.I),
    re.compile(r"\bgit\s+update-ref\s+-d\b", re.I),
    # Wholesale deletion of large path families.
    re.compile(r"\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r)\s+(\$HOME|~|/)", re.I),
    re.compile(r"\brm\s+-rf\s+[A-Z]:\\", re.I),  # Windows root drive
    # 1.0.3 round-200 live audit: `rm /etc/passwd` (no -rf) was not
    # caught — only `rm -rf /` matched. Plain `rm` of any system
    # path is destructive even without -rf. Match `rm` (any flags)
    # touching well-known unsafe roots: /etc, /sys, /proc, /boot,
    # /var/lib, /usr/lib, /lib (POSIX). Windows: C:\Windows.
    re.compile(
        r"\brm\b(?:\s+-[a-zA-Z]+)*\s+/(etc|sys|proc|boot|var/lib|usr/lib|lib)/",
        re.I,
    ),
    re.compile(
        r"\brm\b(?:\s+-[a-zA-Z]+)*\s+[A-Z]:\\Windows\\", re.I,
    ),
    # 1.0.3 round-200: classic POSIX fork bomb in any whitespace
    # variation. The literal string was already in FORBIDDEN_PREFIXES
    # but only as a strict prefix; match it as a regex so it's
    # caught even when buried inside a chained command.
    re.compile(
        r":\s*\(\s*\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:",
    ),
    # Round 182: Mike Wolak case — `rm -rf tests/ patches/ plan/ ~/`.
    # The above regex only catches `~` immediately after `-rf`. This
    # one catches the home-directory token anywhere in the argument
    # list, which is the actual public incident from Oct 2025
    # (Claude Code GH #10077). Pattern: `rm` followed by a flag
    # bundle that contains both `r` and `f` (any order, plus
    # optional verbose/interactive flags like -rfv, -rfi), then
    # any tokens, then `~`, `~/`, `$HOME`, or `$HOME/` as a
    # standalone argument (delimited by whitespace or end-of-line).
    re.compile(
        r"\brm\s+-[a-z]*[rR][a-z]*[fF][a-z]*\b.*?\s(~|~/|\$HOME|\$HOME/)\s*(?:$|\s)",
        re.I,
    ),
    re.compile(
        r"\brm\s+-[a-z]*[fF][a-z]*[rR][a-z]*\b.*?\s(~|~/|\$HOME|\$HOME/)\s*(?:$|\s)",
        re.I,
    ),
    # SQL bulk destruction.
    re.compile(r"\bDROP\s+(DATABASE|TABLE|SCHEMA)\b", re.I),
    re.compile(r"\bTRUNCATE\s+TABLE\b", re.I),
    re.compile(r"\bDELETE\s+FROM\s+\w+\s*(;|$)", re.I),  # DELETE without WHERE
    # Disk-write nukes.
    re.compile(r"\bdd\s+if=.*\s+of=/dev/(sd|nvme|hd|disk)", re.I),
    re.compile(r">\s*/dev/(sd|nvme|hd|disk)", re.I),
    # Permission/ownership wipes.
    re.compile(r"\bchmod\s+-R\s+(000|777)\s+(/|\$HOME|~)", re.I),
    re.compile(r"\bchown\s+-R\s+\S+\s+(/|\$HOME|~)", re.I),
    # Windows equivalents.
    re.compile(r"\b(rd|rmdir)\s+/s\s+/q\s+(c:\\|%userprofile%|%systemroot%)", re.I),
    re.compile(r"\bformat\s+[a-z]:", re.I),
    re.compile(r"\bdiskpart\b", re.I),
    # Package-manager nuclear options.
    re.compile(r"\bnpm\s+uninstall\s+--global\s+(\*|--all)", re.I),
    re.compile(r"\bpip\s+uninstall\s+-y\s+(--all|\*)", re.I),
    # Cloud destruction.
    re.compile(r"\b(aws|gcloud|az|kubectl)\s+\S*delete", re.I),
    re.compile(r"\bterraform\s+destroy\b", re.I),
]


def _shellquote(s: str) -> str:
    """POSIX shell single-quote escape for embedding a command inside
    a sandbox-exec wrapper string. shlex.quote is fine but we want a
    deterministic, easy-to-read output."""
    import shlex as _shlex
    return _shlex.quote(s)


def _kill_tree(proc: Any) -> None:
    """Round-17 P0: kill a subprocess and every child it spawned.

    POSIX: send SIGTERM/SIGKILL to the process group. Requires the proc
    to have been started with `start_new_session=True` (we do that
    above), so the shell is a session leader and `os.killpg(pgid)`
    reaches all descendants.
    Windows: send CTRL_BREAK_EVENT to the process group, then fall
    through to `proc.kill()` if the tree is still alive.
    Best-effort. Silently no-ops if the proc is already dead.
    """
    pid = getattr(proc, "pid", None)
    if pid is None:
        return
    if sys.platform == "win32":
        try:
            import signal as _sig
            os.kill(pid, _sig.CTRL_BREAK_EVENT)
        except (OSError, AttributeError, ValueError):
            pass
        try:
            proc.kill()
        except (ProcessLookupError, OSError):
            pass
    else:
        try:
            import signal as _sig
            pgid = os.getpgid(pid)
            os.killpg(pgid, _sig.SIGTERM)
        except (ProcessLookupError, OSError, AttributeError):
            try:
                proc.kill()
            except (ProcessLookupError, OSError):
                pass


def _flatten_shell_command(cmd: str) -> str:
    """Return a string with the contents of every quoted segment exposed
    as plain words, so the dangerous-pattern regex sees what would
    actually run.

    Example: `bash -c "DROP TABLE users"` → `bash -c  DROP TABLE users`.
    Without this, the regex never sees `DROP TABLE` because it's hidden
    inside double quotes (audit P0). We use shlex with posix-mode lexing
    to walk tokens; eval/base64-decoded payloads can't be inspected
    statically, but the common bash -c / sh -c / zsh -c / cmd /c wrappers
    are now caught.
    """
    import shlex
    try:
        # posix=True correctly strips quoting so `bash -c "DROP X"` becomes
        # ['bash', '-c', 'DROP X'] — exactly what we want for substring search.
        tokens = shlex.split(cmd, posix=True)
    except ValueError:
        # Unbalanced quotes — fall back to the raw string. Caller still
        # gets the original-cmd regex match if any pattern is plain text.
        return cmd
    return " ".join(tokens)


def is_dangerous(cmd: str) -> tuple[bool, str]:
    """Returns (matched, human-readable reason). Used by run_bash to force
    a confirmation prompt EVEN IN skipAll mode.

    Scans BOTH the original command AND the shell-flattened form so a
    destructive payload wrapped in `bash -c "..."` / `sh -c '...'` /
    `cmd /c "..."` still trips the guard. We can't inspect base64 /
    eval / curl-to-shell — those still require the user's vigilance —
    but the common quoted-payload pattern is now covered.
    """
    c = cmd.strip()
    if not c:
        return False, ""
    flattened = _flatten_shell_command(c)
    for haystack in (c, flattened) if c != flattened else (c,):
        for rx in DANGEROUS_REGEXES:
            m = rx.search(haystack)
            if m:
                return True, f"matches dangerous pattern: {m.group(0)[:60]}"
    return False, ""


def _is_forbidden(cmd: str) -> bool:
    c = cmd.strip()
    return any(c.startswith(p) for p in FORBIDDEN_PREFIXES)


class RunBash(Tool):
    name = "run_bash"
    description = (
        "Run a shell command in the project working directory. Captures "
        "stdout+stderr (combined) and returns exit code. Time-limited. "
        "Don't use for file ops — prefer read_file / write_file / edit_file."
    )
    side_effect = SideEffect.EXEC
    schema = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "shell command to run"},
            "timeout_seconds": {"type": "integer", "default": DEFAULT_TIMEOUT, "description": "timeout in seconds (Prometheus name)"},
            "timeout": {"type": "integer", "description": "timeout in milliseconds (Claude Code name; alias for timeout_seconds × 1000)"},
            "description": {"type": "string", "description": "1-line reason; shown to user"},
            "run_in_background": {
                "type": "boolean",
                "default": False,
                "description": (
                    "If true, the command spawns and run_bash returns "
                    "immediately with a shell_id. Use bash_output to "
                    "poll the shell's stdout and kill_shell to stop it. "
                    "Use this for dev servers, watchers, long-running "
                    "compilers — anything you want to keep running while "
                    "you do other work."
                ),
            },
        },
        "required": ["command"],
    }

    def receipt_label(self, args: dict[str, Any]) -> str:
        # Round-21: quiet receipt. `Bash(command)` parens style matches
        # the conversational "⏺ Bash(npm install)" pattern the field
        # converged on, instead of the noisy "Bash $ ..." verb prefix
        # that read like the user was about to see live shell output.
        # Round 96.29: when the agent is invoking Windows PowerShell
        # (pwsh / powershell), surface the receipt label as
        # `PowerShell(...)` so a Windows user reading the chat sees
        # accurate provenance instead of a misleading `Bash(...)`.
        # R226: when the command is a `powershell -Command "..."` /
        # `pwsh -c "..."` shell, strip the wrapper and show the inner
        # expression. User saw `Bash(powershell -Command "[System.
        # TimeZoneInfo]::Conv…eById(...)")` and wanted the cleaner
        # `PowerShell([System.TimeZoneInfo]::ConvertTimeBy...)` form
        # — the verb prefix carries the shell identity, the
        # parenthesized body should carry the actual code being run.
        # End-truncate (no middle ellipsis) so the start of the
        # expression — the part that identifies what's happening —
        # is always visible.
        import re as _re_label
        cmd = str(args.get("command", ""))
        head = cmd.strip().split("\n", 1)[0]
        head_lower = head.lower()
        is_powershell = (
            head_lower.startswith("pwsh ")
            or head_lower.startswith("pwsh.exe ")
            or head_lower.startswith("powershell ")
            or head_lower.startswith("powershell.exe ")
            or head_lower == "pwsh"
            or head_lower == "powershell"
        )
        prefix = "PowerShell" if is_powershell else "Bash"
        body = head
        if is_powershell:
            # Match the same shape R217's _is_safe_powershell uses
            # so the unwrap stays consistent across the safety gate
            # and the receipt label.
            m = _re_label.match(
                r"^(?:pwsh(?:\.exe)?|powershell(?:\.exe)?)\s+"
                r"(?:-NoProfile\s+)?(?:-ExecutionPolicy\s+\S+\s+)?"
                r"-(?:Command|c)\s+(.*)$",
                head, _re_label.IGNORECASE,
            )
            if m:
                inner = m.group(1).strip()
                # Strip a single layer of surrounding quotes if the
                # entire body is quoted.
                if len(inner) >= 2 and inner[0] == inner[-1] and inner[0] in ("'", '"'):
                    inner = inner[1:-1].strip()
                if inner:
                    body = inner
        # R226: end-truncate (no middle ellipsis). The leading
        # cmdlet / verb is always visible; tail goes to `…`.
        if len(body) > 80:
            body = body[:79] + "…"
        return f"{prefix}({body})"

    async def execute(self, args: dict[str, Any], ctx: ToolContext) -> ToolResult:
        if (r := ctx.plan_mode_refusal("run_bash")):
            return r
        # Round-95 receipt: stamp start time so every result reports
        # duration. The renderer uses this for the receipt block.
        _exec_started_at = time.monotonic()
        cmd = str(args.get("command", "")).strip()
        if not cmd:
            return ToolResult(output="empty command", error=True, summary="empty")
        # Round-94 smoke-test bug: free models (especially Chinese-
        # tokenizer ones like DeepSeek/Qwen) sometimes emit their
        # chain-of-thought reasoning AS the `command` argument,
        # complete with `<|begin_of_sentence|>` tokenizer markers.
        # Verbatim example caught in 0.1.30 smoke test:
        #   "We need to run test suite. But we have no tool for test
        #    suite. ... <|begin_of_sentence|>We need to run the test
        #    suite. Since we are in a repo, likely there is a test
        #    runner like pytest..."
        # That prose got handed to bash, which timed out at 180s.
        # Detect the leak shape and refuse with a corrective message
        # so the model retries with a clean command.
        prose_markers = (
            "<|begin_of_sentence|>", "<|end_of_sentence|>",
            "<|begin▁of▁sentence|>", "<|end▁of▁sentence|>",  # different glyph variant
            "<|im_start|>", "<|im_end|>",
            "[BEGIN_OF_SENTENCE]", "[END_OF_SENTENCE]",
        )
        if any(m in cmd for m in prose_markers):
            return ToolResult(
                output=(
                    "refused: the `command` argument contains tokenizer "
                    "special tokens (your reasoning leaked into the tool "
                    "call). Re-emit the call with a plain shell command "
                    "ONLY in `command` — for example: `pytest -q` or "
                    "`python scripts/workflow_audit.py`. Do not include "
                    "reasoning prose, paragraphs, or `<|...|>` tokens."
                ),
                error=True,
                summary="reasoning leaked into command",
            )
        # Multi-paragraph prose detector: shell commands rarely have
        # multiple sentences ending in periods + capital-letter starts.
        # If the command is >300 chars AND has 2+ sentence-end patterns,
        # it's almost certainly leaked reasoning.
        import re as _re_prose
        if len(cmd) > 300:
            sentence_ends = len(_re_prose.findall(r"[.!?]\s+[A-Z][a-z]", cmd))
            reasoning_starts = sum(1 for p in (
                "We need", "We can", "Let's", "Let us", "I will",
                "I'll ", "Since we", "Thinking ", "Better:",
                "Maybe ", "Actually ", "First, ", "First we",
            ) if p in cmd)
            if sentence_ends >= 2 or reasoning_starts >= 2:
                return ToolResult(
                    output=(
                        "refused: the `command` argument looks like "
                        "reasoning prose, not a shell command "
                        f"(length={len(cmd)} chars, "
                        f"sentence-pattern hits={sentence_ends}, "
                        f"reasoning-starter hits={reasoning_starts}). "
                        "Re-emit the call with ONLY the shell command "
                        "in `command`. Keep your reasoning out of tool "
                        "arguments — put it in your reply text instead."
                    ),
                    error=True,
                    summary="prose leaked into command",
                )
        if _is_forbidden(cmd):
            return ToolResult(
                output=f"command refused: matches forbidden pattern",
                error=True,
                summary="refused",
            )
        # Round-95 turn-8: block internal tool names from being run
        # as shell commands. Smoke 4 turn-7 live bug: after
        # discover_test_command's first call failed, the model tried
        # `Bash(discover_test_command)` thinking the tool name was a
        # shell command — wasting an iteration and producing a
        # confusing system error. We refuse with a clear message
        # that points the model back to the actual tool-call
        # interface, including a suggested fallback for the most
        # common case (test discovery).
        _internal = _is_internal_tool_name(cmd)
        if _internal:
            fallback_hint = ""
            if _internal == "discover_test_command":
                fallback_hint = (
                    " If discover_test_command isn't available, run "
                    "`python -m pytest -q` directly with run_bash."
                )
            return ToolResult(
                output=(
                    f"refused: `{_internal}` is an internal PrometheUS "
                    f"tool, not a shell command. Use the tool call "
                    f"interface (emit a structured tool_call with "
                    f"name=\"{_internal}\"), not run_bash.{fallback_hint}"
                ),
                error=True,
                summary=f"refused: {_internal} is an internal tool",
            )
        # Round-95 turn-8: Windows OS guard against Unix-only
        # commands the model might suggest by habit (most free-tier
        # models are trained predominantly on Linux/macOS shell
        # examples). Smoke 4 turn-7 live bug: agent ran `ls -F` on
        # Windows; CMD/PowerShell rejected it with `'ls' is not
        # recognized as an internal or external command`, wasting an
        # iteration. We refuse with a concrete redirect to the
        # internal tool that does the same job.
        if sys.platform == "win32":
            _win_unix_redirect = _windows_unix_redirect(cmd)
            if _win_unix_redirect:
                return ToolResult(
                    output=_win_unix_redirect,
                    error=True,
                    summary="refused: Unix-only command on Windows",
                )
        # Heuristic auto-bump for known-slow commands (installers, builds).
        head = cmd.lower().lstrip()
        auto_bump = any(head.startswith(p) for p in LONG_RUNNING_PREFIXES)
        default_timeout = LONG_RUNNING_TIMEOUT if auto_bump else DEFAULT_TIMEOUT
        # Round-19: per-tool timeout config. Honors PROMETHEUS_TIMEOUT_BASH_S
        # env var (or .prometheus/settings.json `tool_timeouts.run_bash`)
        # over the heuristic default. Lets users globally bump or trim
        # the cap without per-call args.
        try:
            override_env = os.environ.get("PROMETHEUS_TIMEOUT_BASH_S", "")
            if override_env:
                default_timeout = int(float(override_env))
        except ValueError:
            pass
        # Round 173: accept Claude Code's `timeout` (milliseconds)
        # alongside Prometheus's `timeout_seconds`. If both are set,
        # the explicit `timeout_seconds` wins (it's the more specific
        # name). The CC convention is ms; convert.
        if "timeout_seconds" in args:
            timeout = int(args.get("timeout_seconds", default_timeout))
        elif "timeout" in args:
            try:
                timeout = max(1, int(args["timeout"]) // 1000)
            except (TypeError, ValueError):
                timeout = default_timeout
        else:
            timeout = default_timeout
        timeout = max(1, min(3600, timeout))
        # Dangerous-pattern blocklist: forces a confirmation prompt
        # even in skipAll. These are the patterns that caused public
        # data-loss incidents (git filter-repo, force-push, DROP TABLE,
        # rm -rf $HOME, etc.). Bypassing this in YOLO mode is the
        # single biggest risk users take with autonomous agents — we
        # refuse to do that for them.
        is_dangerous_cmd, danger_reason = is_dangerous(cmd)
        require_approval = (
            ctx.permission_mode != "skipAll"
            or is_dangerous_cmd
        )
        if require_approval:
            # Round-22: Claude-parity. The card header ("Bash command")
            # is rendered by the InlineApproval widget; we pass the
            # verbatim command as the primary line and the model's
            # description as the dim secondary line. No "run:" verb,
            # no tool-name prefix.
            desc = args.get("description") or ""
            # Round-96.4: don't render the model's `description` as a
            # secondary line on the approval card — it duplicates the
            # `why` row in the structured meta block below. Smoke 4
            # retest screenshot showed:
            #     Bash command
            #       python -m pytest -q
            #       Running test suite        ← desc duplicated
            #       why    Running test suite ← same string in meta row
            # Keep the desc ONLY in `meta["why"]` so each piece of
            # information appears exactly once on the card.
            prompt_detail = cmd
            if is_dangerous_cmd:
                prompt_detail = f"⚠︎ DESTRUCTIVE — {danger_reason}\n{prompt_detail}"
            # Round-95 Phase B + turn-4: structured approval card
            # meta. Always populate `why` (synthesized from cmd if the
            # model didn't pass description) and `expected` so the
            # card always tells the user WHY + EXPECTED duration on
            # top of the cwd / risk / timeout rows.
            risk_label = _classify_bash_risk(cmd, is_dangerous_cmd)
            approval_meta = {
                "why":      (desc[:100] if desc else _synthesize_why(cmd)),
                "expected": _expected_duration_hint(cmd),
                "cwd":      str(ctx.workdir),
                "risk":     risk_label,
                "timeout":  f"{timeout}s",
            }
            try:
                ok = await ctx.request_approval(
                    "run_bash", prompt_detail, meta=approval_meta,
                )
            except TypeError:
                # Old _request_approval signature — fall back to legacy.
                ok = await ctx.request_approval("run_bash", prompt_detail)
            if not ok:
                raise PermissionDenied(f"user denied run_bash: {cmd[:60]}")
        # Round-17 P0: per-OS sandboxing for run_bash so a timeout
        # actually kills child processes instead of orphaning them.
        # POSIX: `start_new_session=True` puts the shell in its own
        # process group, then a kill on timeout reaches every child via
        # os.killpg. Optional RLIMIT_AS/RLIMIT_CPU caps are applied via
        # preexec_fn when PROMETHEUS_BASH_RLIMIT_MB / _CPU_S are set.
        # Windows: CREATE_NEW_PROCESS_GROUP so Ctrl+Break (TerminateJob
        # path) reaps the whole tree.
        # Round 165 / B4: inject PYTHONIOENCODING=utf-8 into the
        # subprocess env on Windows. Round-163's audit caught the
        # cross-platform gotcha that Python `print('⚠')` raises
        # UnicodeEncodeError on Windows under cp1252 — which then
        # surfaces as a real traceback in the public surface. The
        # safe move is to force UTF-8 on every child process; users
        # rarely override this and when they do, our injection
        # respects an existing value.
        _env = os.environ.copy()
        # Round 183: scrub the agent's own LLM provider API keys
        # from the subprocess env by default. Codex CLI's
        # `shell_environment_policy` (inherit="core") and OpenAI's
        # subprocess env-scrub doc both follow this principle: a
        # shell command (pip install, npm install, custom script)
        # has no business reading the agent's keys, and a hostile
        # package or compromised registry could exfiltrate them.
        # User-controlled keys (GITHUB_TOKEN, AWS_*, NPM_TOKEN, etc.)
        # pass through unchanged so existing workflows aren't
        # broken.
        # Opt out with `PROMETHEUS_SHELL_PASS_API_KEYS=1` for users
        # whose subprocess scripts genuinely need them.
        _scrub_keys = os.environ.get(
            "PROMETHEUS_SHELL_PASS_API_KEYS", ""
        ).strip().lower() not in ("1", "true", "yes")
        if _scrub_keys:
            for k in (
                "PROMETHEUS_API_KEY",
                "OPENROUTER_API_KEY",
                "ANTHROPIC_API_KEY",
                "OPENAI_API_KEY",
                "GROQ_API_KEY",
                "TOGETHER_API_KEY",
                "DEEPSEEK_API_KEY",
            ):
                _env.pop(k, None)
        if sys.platform == "win32" and "PYTHONIOENCODING" not in _env:
            _env["PYTHONIOENCODING"] = "utf-8"
        # Round 180: Claude-Code parity — surface the active
        # session id to the spawned subprocess. Hook scripts and
        # user post-execution helpers correlate against this so
        # one chain of: agent → bash command → hook → external
        # tool can all reference the same session id without
        # the user having to plumb it themselves. We also export
        # PROMETHEUS_SESSION_ID for native users; both names
        # carry the same value so a CC-trained script that reads
        # `$CLAUDE_CODE_SESSION_ID` works unchanged.
        try:
            sid = getattr(ctx, "session_id", "") or ""
            if sid:
                _env.setdefault("CLAUDE_CODE_SESSION_ID", sid)
                _env.setdefault("PROMETHEUS_SESSION_ID", sid)
        except Exception:
            pass
        # 1.0.3 (Claude Code w19 parity): expose the active reasoning
        # effort to the subprocess so user scripts can branch on it
        # the same way Claude Code's $CLAUDE_EFFORT works.
        try:
            effort = (
                os.environ.get("PROMETHEUS_REASONING_EFFORT", "")
                or getattr(getattr(ctx, "settings", None), "reasoning_effort", "")
                or ""
            ).strip()
            if effort:
                _env.setdefault("CLAUDE_EFFORT", effort)
                _env.setdefault("PROMETHEUS_REASONING_EFFORT", effort)
        except Exception:
            pass
        # 1.0.3 (Claude Code w19 parity): don't leak the agent's own
        # OTLP endpoint into OTEL-instrumented apps run via Bash. An
        # `npm run start` that ships its own OTEL collector should
        # ship its own traces, not silently merge them with whatever
        # the CLI is exporting. Opt out with PROMETHEUS_BASH_PASS_OTEL=1.
        if os.environ.get(
            "PROMETHEUS_BASH_PASS_OTEL", "",
        ).strip().lower() not in ("1", "true", "yes"):
            for _k in [k for k in _env if k.startswith("OTEL_")]:
                _env.pop(_k, None)
        spawn_kw: dict[str, Any] = dict(
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(ctx.workdir),
            env=_env,
        )
        # Round 96.29: Windows-only PowerShell length-fix. Long
        # `pwsh -Command "..."` invocations (multiline scripts the
        # agent emits as one giant arg) blow the 8191-char cmd.exe
        # limit and surface as `pwsh exited with code 1: The
        # command line is too long.` The helper rewrites such
        # commands to use a temp `.ps1` file invoked via -File.
        _ps_tempfile: str | None = None
        if sys.platform == "win32":
            # Round 210: drop the Unix-only `-p` flag from `mkdir`
            # before any other Windows-shape transformation. cmd.exe's
            # mkdir creates intermediate dirs natively. This is a
            # fixup, not a refusal — running `mkdir -p X` should just
            # work on Windows like the user expects.
            cmd = _strip_mkdir_dash_p(cmd)
            # Round 211: `python3 ...` → `python ...` on Windows
            # (Windows installs `python.exe`, not `python3.exe`).
            # Transparent rewrite, not a refusal.
            cmd = _rewrite_python3(cmd)
            # Round 211: forward-slash paths in cmd.exe builtins
            # (mkdir foo/bar) parse `/bar` as a switch flag and
            # fail with "syntax incorrect". Rewrite slashes in
            # path-like args of native cmd.exe commands so the
            # model's natural Unix-flavored emission just works.
            cmd = _rewrite_forward_slash_paths_for_cmd(cmd)
            # Round 208 follow-up: auto-wrap bare PowerShell cmdlets
            # (Get-Date, Get-ChildItem, Invoke-WebRequest, ...) through
            # `powershell.exe -NoProfile -Command` so the cmdlet runs
            # in PowerShell instead of cmd.exe. Without this wrap, the
            # Round-208 redirect that says "use Get-Date" is hollow:
            # the model would then emit `Get-Date` on the next turn
            # and cmd.exe would reject it with the same "is not
            # recognized" error. Heuristic: only wrap if the head
            # token matches the canonical PS Verb-Noun shape, so
            # plain `python script.py` / `winget install ...` are not
            # disturbed.
            _autowrapped_for_ps = False
            if _looks_like_powershell_cmdlet(cmd):
                cmd = _wrap_powershell_cmdlet(cmd)
                _autowrapped_for_ps = True
            cmd_to_run, _ps_tempfile = (
                _maybe_rewrite_powershell_for_length(cmd)
            )
            try:
                import subprocess as _sp
                spawn_kw["creationflags"] = getattr(_sp, "CREATE_NEW_PROCESS_GROUP", 0)
            except Exception:
                pass
            proc = await asyncio.create_subprocess_shell(cmd_to_run, **spawn_kw)
        else:
            spawn_kw["start_new_session"] = True
            # Round-18: opt-in macOS sandbox-exec. When the user sets
            # PROMETHEUS_BASH_SANDBOX=1 on darwin, we wrap the command
            # in a sandbox-exec profile that allows reads anywhere but
            # restricts writes to workdir + tmp + the prometheus state
            # dir. Network is left enabled (curl, npm install, etc.
            # are common run_bash use cases). Off by default — most
            # users want full host access for `pip install` etc.
            sandbox_wrapped: str | None = None
            if (
                sys.platform == "darwin"
                and os.environ.get("PROMETHEUS_BASH_SANDBOX") == "1"
            ):
                try:
                    import tempfile as _tf
                    workdir_abs = str(ctx.workdir.resolve())
                    profile = (
                        '(version 1)\n'
                        '(allow default)\n'
                        '(deny file-write*)\n'
                        f'(allow file-write* (subpath "{workdir_abs}"))\n'
                        '(allow file-write* (subpath "/tmp"))\n'
                        '(allow file-write* (subpath "/private/tmp"))\n'
                        '(allow file-write* (subpath "/private/var/folders"))\n'
                        '(allow file-write* (regex #"^/dev/(null|tty|stdin|stdout|stderr|fd)"))\n'
                    )
                    fd, prof_path = _tf.mkstemp(prefix="prometheus-bash-",
                                                suffix=".sb")
                    with os.fdopen(fd, "w") as f:
                        f.write(profile)
                    sandbox_wrapped = (
                        f"sandbox-exec -f {prof_path} /bin/sh -c "
                        + _shellquote(cmd)
                    )
                except Exception:
                    sandbox_wrapped = None
            mem_mb = os.environ.get("PROMETHEUS_BASH_RLIMIT_MB", "")
            cpu_s = os.environ.get("PROMETHEUS_BASH_RLIMIT_CPU_S", "")
            if mem_mb or cpu_s:
                def _apply_rlimits() -> None:
                    try:
                        import resource as _r
                        if mem_mb:
                            try:
                                bytes_cap = int(float(mem_mb)) * 1024 * 1024
                                _r.setrlimit(_r.RLIMIT_AS, (bytes_cap, bytes_cap))
                            except (ValueError, OSError):
                                pass
                        if cpu_s:
                            try:
                                s = int(float(cpu_s))
                                _r.setrlimit(_r.RLIMIT_CPU, (s, s))
                            except (ValueError, OSError):
                                pass
                    except Exception:
                        pass
                spawn_kw["preexec_fn"] = _apply_rlimits
            if sandbox_wrapped is not None:
                # sandbox-exec wraps the user's `cmd` itself; we still
                # spawn through /bin/sh -c so a single string command
                # path is preserved.
                proc = await asyncio.create_subprocess_exec(
                    "/bin/sh", "-c", sandbox_wrapped, **spawn_kw,
                )
            else:
                proc = await asyncio.create_subprocess_exec(
                    "/bin/sh", "-c", cmd, **spawn_kw,
                )
        # Register with the App so Ctrl+B can hand this process off to
        # the background-jobs registry. We expose the proc + cmd; the
        # action_background_bash() callback adopts them on demand.
        app = getattr(ctx.runtime, "app", None) if ctx.runtime else None
        background = bool(args.get("run_in_background", False))
        if app is not None and not background:
            app._fg_bash_proc = proc
            app._fg_bash_cmd = cmd
            # R229 / Item 12: stamp the start time so the activity
            # rail can surface a `(ctrl+b to run in background)` hint
            # once a foreground bash has been running long enough
            # that the user might want to background it. Threshold
            # check lives in the rail render; we just record the
            # monotonic timestamp here.
            app._fg_bash_started_at = time.monotonic()
        # Background mode: hand off immediately to the bg_jobs registry
        # and return a shell_id the model can poll via bash_output.
        # The dev-server gap (issue #64 audit P0) — agents that can't
        # run a watcher alongside their work are blocked on every
        # modern dev workflow.
        if background:
            if app is None or not hasattr(app, "bg_jobs"):
                # Round 209: the round-209 baseline T8 ("Run a
                # background agent to list all files") landed here
                # because the model interpreted "background agent"
                # as `run_in_background:true`. That's the wrong tool
                # — for spawning a parallel agent the right surface
                # is the `task` (subagent_dispatch) tool. Surface a
                # directive message so the model picks the right
                # interface instead of retrying a forbidden one.
                return ToolResult(
                    output=(
                        "run_in_background is only available in the "
                        "interactive TUI (it needs a foreground app "
                        "to track the background process). Two "
                        "alternatives: (1) for a 'background agent' "
                        "that lists files / runs a sub-task, use the "
                        "`task` tool to dispatch a subagent — it runs "
                        "in parallel and reports back. (2) For a long-"
                        "running shell process, drop run_in_background "
                        "and let it run synchronously, or run from the "
                        "TUI session."
                    ),
                    error=True,
                    summary="bg unavailable; use task() for subagents",
                )
            job = app.bg_jobs.adopt(cmd, proc)
            ctx.audit("run_bash", {"cmd": cmd, "shell_id": job.job_id, "background": True})
            return ToolResult(
                output=(
                    f"shell_id: {job.job_id}\n"
                    f"started in background. Use bash_output(shell_id='{job.job_id}') "
                    f"to read new output, kill_shell(shell_id='{job.job_id}') to stop."
                ),
                summary=f"bg started · {job.job_id}",
            )

        # Bounded ring buffer for raw bytes — caps memory at ~16MB
        # regardless of how much output the process produces. The model
        # only ever sees the last MAX_OUTPUT chars (truncated tail), so
        # accumulating gigabytes was wasted RAM (Claude Code issues
        # #21378 / #11315 / #19720 — minified-bundle freezes were caused
        # by analogous unbounded buffers).
        from collections import deque
        chunks: deque[bytes] = deque(maxlen=4096)  # 4096 × 4KB ≈ 16MB ceiling
        # Use an incremental decoder so multi-byte UTF-8 sequences
        # split across read(4096) boundaries don't get mangled into
        # U+FFFD permanently.
        import codecs
        decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        decoded_buf: list[str] = []
        last_flush = time.monotonic()
        live_emit = None
        if app is not None and hasattr(app, "_log") and hasattr(app, "_log_live_bash"):
            live_emit = app._log_live_bash

        try:
            async def reader() -> None:
                nonlocal last_flush
                assert proc.stdout
                while True:
                    chunk = await proc.stdout.read(4096)
                    if not chunk:
                        break
                    chunks.append(chunk)
                    decoded_buf.append(decoder.decode(chunk))
                    # Flush at most every 2s so we don't spam the chat.
                    if live_emit and (time.monotonic() - last_flush) > 2.0:
                        new_text = "".join(decoded_buf)
                        decoded_buf.clear()
                        last_flush = time.monotonic()
                        if new_text.strip():
                            try:
                                live_emit(new_text)
                            except Exception:
                                pass
            try:
                # Race the reader against a stdin-idle watchdog. When a
                # subprocess hasn't produced output for STDIN_IDLE_S
                # AND hasn't exited, it's almost certainly waiting on
                # an interactive prompt (sudo password, apt y/n, pip
                # confirmation). Claude Code issue #37523: this is the
                # #1 most-reported run_bash gap. We kill the process
                # and give the model a hint to retry with a non-
                # interactive flag.
                STDIN_IDLE_S = 30
                # Track output arrival separately from `last_flush`
                # (which is gated on the 2s UI-flush throttle). Round-11
                # audit P0: previously the watchdog read `last_flush`
                # which only updates on flush, so a process producing
                # output but not yet flushed could trip the watchdog.
                last_chunk_at = time.monotonic()
                # Wrap the reader so it stamps last_chunk_at on every
                # chunk arrival (not just on flush).
                _orig_decoder_decode = decoder.decode
                def _stamping_decode(chunk_bytes: bytes, *a, **kw) -> str:
                    nonlocal last_chunk_at
                    last_chunk_at = time.monotonic()
                    return _orig_decoder_decode(chunk_bytes, *a, **kw)
                decoder.decode = _stamping_decode  # type: ignore[method-assign]
                async def watchdog() -> str | None:
                    while True:
                        await asyncio.sleep(2.0)
                        # Has the process exited? Then watchdog is moot.
                        if proc.returncode is not None:
                            return None
                        elapsed_idle = time.monotonic() - last_chunk_at
                        if elapsed_idle >= STDIN_IDLE_S:
                            return f"stdin-idle for {int(elapsed_idle)}s"
                done, pending = await asyncio.wait(
                    [asyncio.create_task(reader()),
                     asyncio.create_task(watchdog())],
                    timeout=timeout,
                    return_when=asyncio.FIRST_COMPLETED,
                )
                # Cancel whichever side didn't win.
                for task in pending:
                    task.cancel()
                # If watchdog tripped, kill and bail with a hint.
                idle_reason: str | None = None
                for task in done:
                    try:
                        result = task.result()
                        if isinstance(result, str):
                            idle_reason = result
                    except (asyncio.CancelledError, Exception):
                        pass
                if idle_reason is not None:
                    _kill_tree(proc)
                    try:
                        await asyncio.wait_for(proc.wait(), timeout=3)
                    except asyncio.TimeoutError:
                        pass
                    ctx.audit("run_bash", {"cmd": cmd, "stdin_idle": True})
                    full = b"".join(chunks).decode("utf-8", "replace")
                    head = cmd.lower().lstrip().split()[0] if cmd.strip() else ""
                    hint_table = {
                        "apt": "Add `-y` (or `DEBIAN_FRONTEND=noninteractive` env var) to skip y/N prompts.",
                        "apt-get": "Add `-y` (or `DEBIAN_FRONTEND=noninteractive` env var) to skip y/N prompts.",
                        "pip": "Add `--no-input` to refuse interactive auth prompts.",
                        "pip3": "Add `--no-input` to refuse interactive auth prompts.",
                        "npm": "Add `--yes` to skip y/N prompts (or `--no-audit` for prompts on audits).",
                        "yarn": "Add `--non-interactive` to skip y/N prompts.",
                        "winget": "Add `--accept-source-agreements --accept-package-agreements`.",
                        "ssh": "Use a key-based auth path; password prompts can't be answered here.",
                        "sudo": "Run sudo separately or configure NOPASSWD for this command — interactive password can't be entered.",
                    }
                    hint = hint_table.get(head, "")
                    hint_block = f"\n--- hint ---\n{hint}" if hint else ""
                    if _ps_tempfile:
                        try:
                            os.unlink(_ps_tempfile)
                        except Exception:
                            pass
                    return ToolResult(
                        output=(
                            f"killed: {idle_reason}. The process produced no "
                            f"output for ≥{STDIN_IDLE_S}s — it's almost "
                            f"certainly waiting on stdin (interactive prompt)."
                            f"{hint_block}\n--- output so far ---\n{_tail(full)}"
                        ),
                        summary="stdin-idle (interactive prompt)",
                        error=True,
                    )
                # Reader finished cleanly; collect exit code. If the
                # outer asyncio.wait timed out before either side won,
                # fall through to the legacy timeout path.
                #
                # Round-95 BUG FIX: previously this raised TimeoutError
                # whenever `pending` was non-empty, but with
                # FIRST_COMPLETED the watchdog (which loops forever) is
                # ALWAYS pending when the reader wins normally. That
                # mis-classified every successful command as a timeout —
                # the chat receipt showed "TIMEOUT 15.8s" even when
                # `pytest` passed cleanly in 2.94s. The correct check
                # is `not done`: only when NEITHER task completed within
                # the outer timeout window did the timeout actually fire.
                if not done:
                    raise asyncio.TimeoutError()
                rc = await asyncio.wait_for(proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                # Round-17 P0: tree-kill so children of the shell die
                # too — npm/winget/docker/python-build all spawn child
                # processes that survived our old proc.kill() and ate
                # the user's CPU silently after a timeout.
                _kill_tree(proc)
                try:
                    await asyncio.wait_for(proc.wait(), timeout=3)
                except asyncio.TimeoutError:
                    pass
                ctx.audit("run_bash", {"cmd": cmd, "timeout": True})
                full = b"".join(chunks).decode("utf-8", "replace")
                # Round-95: structured timeout diagnostic. Include a
                # focused-retry suggestion so the model knows EXACTLY
                # how to narrow scope on the retry — not just "it
                # timed out, try again". Last 20 output lines come
                # along in metadata so the renderer can show progress
                # context, not just the spinner.
                retry_suggestion = _focused_retry_suggestion(cmd)
                last_n = _last_n_lines(full, 20)
                duration_s = time.monotonic() - _exec_started_at
                output = (
                    f"command exceeded {timeout}s and was killed.\n"
                    f"--- last {len(last_n)} output lines ---\n"
                    + ("\n".join(last_n) if last_n else "(no output captured)")
                    + f"\n--- suggested retry ---\n{retry_suggestion}"
                )
                if _ps_tempfile:
                    try:
                        os.unlink(_ps_tempfile)
                    except Exception:
                        pass
                return ToolResult(
                    output=output,
                    summary=f"timeout after {timeout}s",
                    error=True,
                    metadata={
                        "command": cmd,
                        "cwd": str(ctx.workdir),
                        "exit": "timeout",
                        "duration_s": round(duration_s, 1),
                        "last_lines": last_n,
                        "retry_suggestion": retry_suggestion,
                        "timeout_s": timeout,
                    },
                )
            except asyncio.CancelledError:
                # User hit Esc. Make sure the subprocess and every child
                # die before we propagate — otherwise we orphan winget/
                # npm/docker that keeps running silently.
                _kill_tree(proc)
                try:
                    await asyncio.wait_for(proc.wait(), timeout=3)
                except asyncio.TimeoutError:
                    pass
                if app is not None and app._fg_bash_proc is proc:
                    app._fg_bash_proc = None
                    app._fg_bash_cmd = ""
                    # R229: clear the start-time stamp too so the
                    # rail's bg-hint disappears when the bash ends.
                    app._fg_bash_started_at = None
                ctx.audit("run_bash", {"cmd": cmd, "cancelled": True})
                if _ps_tempfile:
                    try:
                        os.unlink(_ps_tempfile)
                    except Exception:
                        pass
                raise
        except Exception as e:
            # Clean up the proc on any other exit path too.
            try:
                if proc.returncode is None:
                    proc.kill()
                    await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                pass
            # Round 96.29: clean up the temp .ps1 if we created one.
            if _ps_tempfile:
                try:
                    os.unlink(_ps_tempfile)
                except Exception:
                    pass
            return ToolResult(output=f"exec error: {e}", error=True, summary="exec error")

        # Tool finished — clear the foreground-bash slot so a stale
        # Ctrl+B doesn't try to background a dead process.
        if app is not None and app._fg_bash_proc is proc:
            app._fg_bash_proc = None
            app._fg_bash_cmd = ""
            app._fg_bash_started_at = None
        # Round-21: close the per-session live-bash log handle so the
        # user can `tail -f` it from another pane and so the next bash
        # call gets its own log file.
        if app is not None:
            fh = getattr(app, "_bash_live_log_fh", None)
            if fh is not None:
                try:
                    fh.close()
                except Exception:
                    pass
                app._bash_live_log_fh = None
        raw = b"".join(chunks)
        # Heuristic: if every other byte is NUL, the stream is UTF-16-LE
        # (some Windows commands emit this). Re-decode accordingly.
        if raw[:200].count(b"\x00") > len(raw[:200]) // 4:
            try:
                full = raw.decode("utf-16-le", errors="replace")
            except Exception:
                full = raw.decode("utf-8", errors="replace")
        else:
            full = raw.decode("utf-8", errors="replace")
        ctx.audit("run_bash", {"cmd": cmd, "exit": rc, "bytes": len(full)})
        # Round 96.12: pass the captured output so test-runner failures
        # get a clean "test failures (see output)" hint instead of the
        # legacy "process: generic failure" generic-rc-1 string.
        hint = _explain_exit(rc, full) if rc != 0 else ""
        hint_block = f"\n--- hint ---\n{hint}" if hint else ""
        result = (
            f"exit: {rc}{hint_block}\n--- output ---\n{_tail(full) if full else '(no output)'}"
        )
        # Round 96.13: extract a clean public-facing summary from the
        # output. Smoke 6 retest receipts read `exit 1 · test failures
        # (see output)` — accurate but raw. Public CLI should read
        # `Tests failed · 1 failed in 0.43s` (failure) or `Tests
        # passed · N in X.XXs` (success) — same shape Claude Code
        # uses. Falls back to `exit N` for non-test commands.
        summary = _build_command_summary(rc, full)
        # Round-95 receipt: structured metadata for every command —
        # duration, cwd, exit, last-N output. The renderer can show a
        # consistent receipt block; the model also benefits because
        # the metadata is part of the tool result it sees next turn.
        duration_s = time.monotonic() - _exec_started_at
        # Round 96.29: clean up the temp .ps1 (if the length-fix
        # helper created one) now that the process has finished and
        # we've captured the output.
        if _ps_tempfile:
            try:
                os.unlink(_ps_tempfile)
            except Exception:
                pass
        # Round 184: fire OSC 9 / OSC 777 desktop notification when
        # a long-running command finishes (>10s) and the user has
        # opted in via PROMETHEUS_NOTIFY=1. Codex CLI / Warp parity.
        # Default off — aggressive notifications are the #1 cited
        # annoyance in agent-CLI feedback (Codex #3962).
        if duration_s >= 10.0:
            try:
                from prometheus.notify import notify_task_done
                # Surface the head of the command so the user sees
                # WHAT finished, not just "done". Truncate to fit
                # into common notification widgets (~80 chars).
                head = (cmd or "").strip().split("\n", 1)[0][:60]
                notify_task_done(
                    f"bash done · rc={rc}{' · ' + head if head else ''}",
                    duration_s,
                )
            except Exception:
                # Notification failures must never break a tool result.
                pass
        # Round 208: on Windows, when the command failed because
        # cmd.exe didn't recognize it, append a one-line recovery
        # hint to the output so the model has a concrete next step
        # instead of retrying the same failing command. Only fires
        # for actual cmd.exe rejection patterns; quiet otherwise.
        if sys.platform == "win32" and rc != 0:
            _hint = _windows_cmd_error_hint(result or full)
            if _hint:
                result = (result or "") + _hint
        return ToolResult(
            output=result,
            summary=summary,
            error=rc != 0,
            metadata={
                "command": cmd,
                "cwd": str(ctx.workdir),
                "exit": rc,
                "duration_s": round(duration_s, 1),
                "last_lines": _last_n_lines(full, 20),
                "bytes": len(full),
            },
        )


def _tail(text: str) -> str:
    if len(text) <= MAX_OUTPUT:
        return text
    keep = MAX_OUTPUT - 200
    return f"…[{len(text) - keep} chars truncated]\n" + text[-keep:]


def _last_n_lines(text: str, n: int = 20) -> list[str]:
    """Round-95: capture the last N non-empty lines for the receipt."""
    lines = [ln for ln in (text or "").splitlines() if ln.strip()]
    return lines[-n:]


def _synthesize_why(cmd: str) -> str:
    """Round-95 turn-4: when the model didn't pass `description`, build
    a one-line `why` from the command itself so the approval card never
    has an empty reason field. Pattern-based — covers the common cases."""
    if not cmd or not cmd.strip():
        return "Run command"
    head = cmd.lower().lstrip().split()
    if not head:
        return "Run command"
    h0 = head[0].rstrip(":")
    # `python -m pytest` / `pytest`
    if h0 == "pytest" or (h0 == "python" and len(head) >= 3 and head[1] in ("-m", "-mu") and head[2] == "pytest"):
        return "Run the project test suite"
    if h0 in ("npm", "yarn", "pnpm") and len(head) >= 2 and head[1] == "test":
        return "Run npm/yarn test suite"
    if h0 == "cargo" and len(head) >= 2 and head[1] == "test":
        return "Run cargo test suite"
    if h0 == "go" and len(head) >= 2 and head[1] == "test":
        return "Run Go test suite"
    if h0 == "make" and len(head) >= 2 and head[1] in ("test", "check"):
        return "Run Make test target"
    if h0 == "git" and len(head) >= 2:
        return f"git {head[1]}: {' '.join(head[2:])[:60]}"[:80] or f"Run git {head[1]}"
    if h0 in ("pip", "pip3", "pipx"):
        return f"Install Python package(s): {' '.join(head[1:])[:60]}"
    if h0 in ("npm", "yarn", "pnpm"):
        return f"npm/yarn: {' '.join(head[1:])[:60]}"
    if h0 in ("apt", "apt-get", "dnf", "yum", "pacman", "apk", "brew", "winget", "choco", "scoop"):
        return f"System package install: {' '.join(head[1:])[:60]}"
    if h0 in ("curl", "wget"):
        return "Fetch URL"
    if h0 in ("ls", "dir", "cat", "type", "head", "tail", "grep", "rg", "find", "fd"):
        return "Inspect filesystem"
    if h0 == "python":
        return f"Run Python: {' '.join(head[1:])[:60]}"
    return f"Run shell command: {h0}"


def _expected_duration_hint(cmd: str) -> str:
    """Round-95 turn-4 / Round-96.5: rough wall-clock estimate based
    on the command head. Approval card surface only — gives the user
    a heads-up of expected runtime.

    Round-96.5: phrasing polished for the public approval card.
    Previous output ("~under 1 min for typical suites") read as
    half-machine half-prose. New form is one short conversational
    phrase per category. Numbers stay approximate — these are
    heuristics, not promises.
    """
    if not cmd or not cmd.strip():
        return "varies"
    head = cmd.lower().lstrip().split()
    if not head:
        return "varies"
    h0 = head[0].rstrip(":")
    is_pytest = (
        h0 == "pytest"
        or (h0 == "python" and len(head) >= 3 and head[1] in ("-m", "-mu") and head[2] == "pytest")
    )
    if is_pytest:
        return "usually under 1 minute"
    if h0 in ("npm", "yarn", "pnpm") and len(head) >= 2 and head[1] == "test":
        return "usually 30-90 seconds"
    if h0 == "cargo" and len(head) >= 2 and head[1] == "test":
        return "usually 30 seconds to 2 minutes"
    if h0 == "cargo" and len(head) >= 2 and head[1] == "build":
        return "1 to 5 minutes on cold cache"
    if h0 in ("pip", "pip3"):
        return "30 seconds to 3 minutes"
    if h0 in ("npm", "yarn") and head[1:2] == ["install"]:
        return "usually 30 to 90 seconds"
    if h0 in ("apt", "apt-get", "dnf", "yum", "winget", "choco", "brew"):
        return "a few minutes — system installer"
    if h0 == "git" and len(head) >= 2 and head[1] == "clone":
        return "5 seconds to a minute depending on repo size"
    if h0 in ("ls", "dir", "cat", "type", "head", "tail", "echo", "pwd", "git"):
        return "instant"
    if h0 in ("curl", "wget"):
        return "1 to 30 seconds"
    return "varies"


def _classify_bash_risk(cmd: str, is_dangerous: bool = False) -> str:
    """Round-95 Phase B (turn-4 refinement): five risk buckets:
        destructive  — irreversible writes (rm -rf, git filter-repo, ...)
        network      — outbound network call (curl, wget, pip install, ...)
        writes-files — modifies source files in a recoverable way
        low          — touches only cache/temp (pytest, cargo test, ...)
        read-only    — pure inspection (ls, cat, grep, git status, ...)

    Round-95 turn-4 added `low` because users complained that pytest /
    cargo test / npm test were labeled `writes-files` — technically
    true (they write `__pycache__`, `target/`, `node_modules/.cache/`)
    but misleading at a glance. The `low` bucket means: "yes there's
    filesystem activity, but only in build/test cache locations".
    """
    if is_dangerous:
        return "destructive"
    head = (cmd or "").lower().lstrip().split()
    if not head:
        return "writes-files"
    h0 = head[0].rstrip(":")
    READ_ONLY = {
        "ls", "dir", "cat", "type", "head", "tail", "less", "more",
        "grep", "egrep", "fgrep", "rg", "find", "fd", "wc", "stat",
        "echo", "printf", "pwd", "whoami", "uname", "date", "env",
        "which", "where", "true", "false", "test", "diff", "tree",
        "file", "du", "df", "ps", "uptime",
    }
    NETWORK = {
        "curl", "wget", "ping", "ssh", "scp", "sftp", "rsync",
        "pip", "pip3", "pipx", "npm", "yarn", "pnpm",
        "apt", "apt-get", "dnf", "yum", "pacman", "apk", "brew",
        "winget", "choco", "scoop", "docker", "podman",
        "gh", "git",  # git includes clone/fetch/pull/push (network)
    }
    if h0 in READ_ONLY:
        return "read-only"
    if h0 == "git" and len(head) >= 2 and head[1] in (
        "status", "log", "diff", "show", "blame", "branch",
        "config", "rev-parse", "describe",
    ):
        return "read-only"
    # Test-runner detection — `low` bucket. Only cache writes, no
    # source modification. Has to come BEFORE the NETWORK check
    # because some test runners (cargo, pytest via python) overlap.
    is_pytest = (
        h0 == "pytest"
        or (h0 == "python" and len(head) >= 3 and head[1] in ("-m", "-mu") and head[2] == "pytest")
    )
    if is_pytest:
        return "low"
    if h0 == "cargo" and len(head) >= 2 and head[1] in ("test", "check", "clippy"):
        return "low"
    if h0 == "go" and len(head) >= 2 and head[1] in ("test", "vet"):
        return "low"
    if h0 in ("npm", "yarn", "pnpm") and len(head) >= 2 and head[1] == "test":
        return "low"
    if h0 == "make" and len(head) >= 2 and head[1] in ("test", "check"):
        return "low"
    if h0 == "ruff" or h0 == "mypy" or h0 == "pyright" or h0 == "black" and "--check" in head:
        return "low"
    if h0 == "tox":
        return "low"
    if h0 in NETWORK:
        return "network"
    return "writes-files"


def _focused_retry_suggestion(cmd: str) -> str:
    """Round-95: when a command times out, propose a narrower retry
    that's more likely to surface the actual problem fast. Heuristic
    table — same shape as the existing exit-code hint table, but for
    commands that need scope-reduction."""
    head = cmd.lower().lstrip().split()
    if not head:
        return ""
    h0 = head[0]
    # `python -m pytest` style
    is_pytest = (
        h0 == "pytest"
        or (h0 == "python" and len(head) >= 3 and head[1] in ("-m", "-mu") and head[2] == "pytest")
    )
    if is_pytest:
        return (
            "Try a narrower scope: `pytest -x --tb=short -q` to fail "
            "fast on the first error, or `pytest <single_test_file>` "
            "to run only one file. The full suite likely has slow "
            "tests; narrow first."
        )
    if h0 in ("pip", "pip3"):
        return (
            "Try `--no-cache-dir` and `--timeout 60` to fail fast on "
            "stuck downloads. For a heavy install, consider "
            "`run_in_background: true` and `bash_output` to monitor."
        )
    if h0 == "npm":
        return (
            "Try `npm install --no-audit --no-fund --no-progress` to "
            "skip slow audit phases, or `run_in_background: true`."
        )
    if h0 == "git" and len(head) >= 2 and head[1] == "clone":
        return (
            "Try `git clone --depth 1` to shallow-clone (faster). "
            "For a large repo, consider `run_in_background: true`."
        )
    if h0 in ("apt", "apt-get", "winget", "choco", "brew"):
        return (
            "Package managers can take minutes. Either bump the "
            "timeout via `timeout_seconds: 600`, or use "
            "`run_in_background: true` and poll with `bash_output`."
        )
    if h0 == "curl" or h0 == "wget":
        return (
            "Add `--max-time 30` (curl) / `--timeout=30` (wget) to "
            "fail fast on stuck connections."
        )
    return (
        "Either narrow the command's scope (e.g. `-x` flags for "
        "fail-fast), bump `timeout_seconds`, or run in background "
        "via `run_in_background: true` + `bash_output` to monitor."
    )
