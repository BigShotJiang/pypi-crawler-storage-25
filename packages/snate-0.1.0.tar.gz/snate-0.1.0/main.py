class Snate:
    RESET = "\033[0m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    CYAN = "\033[36m"

    def __init__(self):
        self.tests = []
        self.failed = 0
        self.passed = 0

    def test(self):
        print("")
        for test in self.tests:

            func_name = test[0].__name__
            print(f"{self.CYAN}test {func_name} ... {self.RESET}", end = "")

            result = test[0]()
            if result == test[1]:
                print(f"{self.GREEN}ok.{self.RESET}")
                print("")
                self.passed += 1
            else:
                print(f"{self.RED}FAILED.{self.RESET}")
                print("")
                print(f"{self.YELLOW}expected: {test[1]}{self.RESET}")
                print(f"{self.YELLOW}actual: {result}{self.RESET}")
                print("")
                self.failed += 1
                
        print(f"{self.CYAN}test result: {self.RESET}", end = "")
        print(f"{self.GREEN}{self.passed} passed{self.RESET};", end = " ")
        print(f"{self.RED}{self.failed} failed{self.RESET}.")
        print("")
        
        if self.failed != 0:
            status = f"{self.RED}FAILED.{self.RESET}"
        else:
            status = f"{self.GREEN}ok.{self.RESET}"
            
        print(f"{self.CYAN}total: {status}{self.RESET}")

    def add(self , func, expected):
        self.tests.append([func, expected])



