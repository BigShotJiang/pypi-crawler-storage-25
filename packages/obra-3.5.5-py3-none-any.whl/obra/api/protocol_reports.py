"""Report and session protocol families shared across client and server."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .protocol_core import (
    AgentType,
    ExecutionStatus,
    SessionPhase,
    SessionStatus,
    UserDecisionChoice,
    _coerce_lifecycle_payload,
    _coerce_optional_dict,
    safe_enum_parse,
)


@dataclass
class PlanUploadRequest:
    """Request to upload a plan file to server."""

    name: str
    plan_data: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "name": self.name,
            "plan_data": self.plan_data,
        }


@dataclass
class PlanUploadResponse:
    """Response from plan upload operation."""

    plan_id: str
    name: str
    story_count: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PlanUploadResponse":
        """Create from API response dictionary."""
        return cls(
            plan_id=data.get("plan_id", ""),
            name=data.get("name", ""),
            story_count=data.get("story_count", 0),
        )


@dataclass
class ResumeRequest:
    """Resume an existing orchestration session with optional lifecycle hints."""

    session_id: str
    bypass_modes: list[str] = field(default_factory=list)
    resume_target: str | None = None
    workflow_lifecycle: dict[str, Any] | None = None
    lifecycle_decisions: dict[str, Any] | None = None
    legacy_phase_normalization: dict[str, Any] | None = None
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] | None = None
    expected_baseline_ref: dict[str, Any] | None = None
    correlation: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result: dict[str, Any] = {
            "session_id": self.session_id,
        }
        if self.bypass_modes:
            result["bypass_modes"] = list(self.bypass_modes)
        if self.resume_target is not None:
            result["resume_target"] = self.resume_target
        if self.workflow_lifecycle is not None:
            result["workflow_lifecycle"] = self.workflow_lifecycle
        if self.lifecycle_decisions is not None:
            result["lifecycle_decisions"] = self.lifecycle_decisions
        if self.legacy_phase_normalization is not None:
            result["legacy_phase_normalization"] = self.legacy_phase_normalization
        if self.derivation_id is not None:
            result["derivation_id"] = self.derivation_id
        if self.operator_review_checkpoint_state is not None:
            result["operator_review_checkpoint_state"] = (
                self.operator_review_checkpoint_state
            )
        if self.expected_baseline_ref is not None:
            result["expected_baseline_ref"] = self.expected_baseline_ref
        if self.correlation is not None:
            result["correlation"] = self.correlation
        return result


@dataclass
class SessionStart:
    """Start a new orchestration session."""

    objective: str
    project_hash: str
    project_context: dict[str, Any] = field(default_factory=dict)
    client_version: str = ""
    working_dir: str = ""
    effective_llm_map: dict[str, dict[str, str]] = field(default_factory=dict)
    auxiliary_llm_map: dict[str, dict[str, str]] = field(default_factory=dict)
    plan_id: str | None = None
    userplan_id: str | None = None
    plan_only: bool = False
    pipeline_only: bool = False
    bypass_modes: list[str] = field(default_factory=list)
    from_step: int | None = None
    quality_policy_mode: str | None = None
    domain: str | None = None
    domain_resolution_state: dict[str, Any] | None = None
    workflow_derivation_request: dict[str, Any] | None = None
    spike_policy: dict[str, Any] | None = None
    spike_context: dict[str, Any] | None = None
    derivation_id: str | None = None
    correlation: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result: dict[str, Any] = {
            "objective": self.objective,
            "project_hash": self.project_hash,
            "working_dir": self.working_dir,
            "project_context": self.project_context,
            "client_version": self.client_version,
            "effective_llm_map": self.effective_llm_map,
        }
        if self.auxiliary_llm_map:
            result["auxiliary_llm_map"] = self.auxiliary_llm_map
        if self.plan_id is not None:
            result["plan_id"] = self.plan_id
        if self.userplan_id is not None:
            result["userplan_id"] = self.userplan_id
        if self.plan_only:
            result["plan_only"] = True
        if self.pipeline_only:
            result["pipeline_only"] = True
        if self.bypass_modes:
            result["bypass_modes"] = self.bypass_modes
        if self.from_step is not None:
            result["from_step"] = self.from_step
        if self.quality_policy_mode is not None:
            result["quality_policy_mode"] = self.quality_policy_mode
        if self.domain is not None:
            result["domain"] = self.domain
        if self.domain_resolution_state:
            result["domain_resolution_state"] = self.domain_resolution_state
        if self.workflow_derivation_request is not None:
            result["workflow_derivation_request"] = self.workflow_derivation_request
        if self.spike_policy is not None:
            result["spike_policy"] = self.spike_policy
        if self.spike_context is not None:
            result["spike_context"] = self.spike_context
        if self.derivation_id is not None:
            result["derivation_id"] = self.derivation_id
        if self.correlation is not None:
            result["correlation"] = self.correlation
        return result


@dataclass
class IntentReport:
    """Report enriched intent and reusable planning resolution to server."""

    session_id: str
    intent: dict[str, Any]
    userplan_id: str | None = None
    userplan_version: int | None = None
    from_step: int | None = None
    intent_enrichment: dict[str, Any] | None = None
    planning_resolution: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result: dict[str, Any] = {
            "session_id": self.session_id,
            "intent": self.intent,
        }
        if self.userplan_id is not None:
            result["userplan_id"] = self.userplan_id
        if self.userplan_version is not None:
            result["userplan_version"] = self.userplan_version
        if self.from_step is not None:
            result["from_step"] = self.from_step
        if self.intent_enrichment is not None:
            result["intent_enrichment"] = self.intent_enrichment
        if self.planning_resolution is not None:
            result["planning_resolution"] = self.planning_resolution
        return result


@dataclass
class GenerateTestsReport:
    """Report generated failing acceptance tests to the server."""

    session_id: str
    failing_test_manifest: dict[str, Any]
    brownfield_index: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "session_id": self.session_id,
            "failing_test_manifest": self.failing_test_manifest,
        }
        if self.brownfield_index is not None:
            payload["brownfield_index"] = self.brownfield_index
        return payload


@dataclass
class DerivedPlan:
    """Report derived plan to server."""

    session_id: str
    userplan_id: str
    userplan_version: int
    plan_items: list[dict[str, Any]]
    raw_response: str = ""
    work_type: str | None = None
    verification_tools: dict[str, Any] | None = None
    story0_prerequisites: list[dict[str, Any]] | None = None
    normalized_inputs: dict[str, Any] | None = None
    derived_workflow_artifact: dict[str, Any] | None = None
    baseline_evaluation: dict[str, Any] | None = None
    validation_report: dict[str, Any] | None = None
    operator_review_points: list[dict[str, Any]] | None = None
    operator_review_checkpoint_state: dict[str, Any] | None = None
    result_bundle: dict[str, Any] | None = None
    accepted_revision_ref: dict[str, Any] | None = None
    expected_baseline_ref: dict[str, Any] | None = None
    workflow_lifecycle: dict[str, Any] | None = None
    lifecycle_decisions: dict[str, Any] | None = None
    legacy_phase_normalization: dict[str, Any] | None = None
    derivation_id: str | None = None
    correlation: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result = {
            "session_id": self.session_id,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
        }
        if self.work_type is not None:
            result["work_type"] = self.work_type
        if self.verification_tools is not None:
            result["verification_tools"] = self.verification_tools
        if self.story0_prerequisites is not None:
            result["story0_prerequisites"] = self.story0_prerequisites
        if self.normalized_inputs is not None:
            result["normalized_inputs"] = self.normalized_inputs
        if self.derived_workflow_artifact is not None:
            result["derived_workflow_artifact"] = self.derived_workflow_artifact
        if self.baseline_evaluation is not None:
            result["baseline_evaluation"] = self.baseline_evaluation
        if self.validation_report is not None:
            result["validation_report"] = self.validation_report
        if self.operator_review_points is not None:
            result["operator_review_points"] = self.operator_review_points
        if self.operator_review_checkpoint_state is not None:
            result["operator_review_checkpoint_state"] = (
                self.operator_review_checkpoint_state
            )
        if self.result_bundle is not None:
            result["result_bundle"] = self.result_bundle
        if self.accepted_revision_ref is not None:
            result["accepted_revision_ref"] = self.accepted_revision_ref
        if self.expected_baseline_ref is not None:
            result["expected_baseline_ref"] = self.expected_baseline_ref
        if self.workflow_lifecycle is not None:
            result["workflow_lifecycle"] = self.workflow_lifecycle
        if self.lifecycle_decisions is not None:
            result["lifecycle_decisions"] = self.lifecycle_decisions
        if self.legacy_phase_normalization is not None:
            result["legacy_phase_normalization"] = self.legacy_phase_normalization
        if self.derivation_id is not None:
            result["derivation_id"] = self.derivation_id
        if self.correlation is not None:
            result["correlation"] = self.correlation
        return result


@dataclass
class ExaminationReport:
    """Report examination results to server."""

    session_id: str
    iteration: int
    issues: list[dict[str, Any]]
    thinking_budget_used: int = 0
    thinking_fallback: bool = False
    raw_response: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "iteration": self.iteration,
            "issues": self.issues,
            "thinking_budget_used": self.thinking_budget_used,
            "thinking_fallback": self.thinking_fallback,
            "raw_response": self.raw_response,
        }


@dataclass
class RevisedPlan:
    """Report revised plan to server."""

    session_id: str
    plan_items: list[dict[str, Any]]
    addressed_issues: list[str] = field(default_factory=list)
    deferred_issues: list[dict[str, Any]] = field(default_factory=list)
    changes_summary: str = ""
    raw_response: str = ""
    revision_failure_class: str | None = None
    no_changes: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        result = {
            "session_id": self.session_id,
            "plan_items": self.plan_items,
            "addressed_issues": self.addressed_issues,
            "deferred_issues": self.deferred_issues,
            "changes_summary": self.changes_summary,
            "raw_response": self.raw_response,
            "no_changes": self.no_changes,
        }
        if self.revision_failure_class is not None:
            result["revision_failure_class"] = self.revision_failure_class
        return result


@dataclass
class ExecutionBatchResultItem:
    """Per-sibling execution outcome carried inside a batched report_execution payload."""

    item_id: str
    status: ExecutionStatus
    summary: str = ""
    files_changed: int = 0
    changed_file_paths: list[str] = field(default_factory=list)
    tests_passed: bool = False
    test_count: int = 0
    test_result: dict[str, Any] | None = None
    coverage_delta: float = 0.0
    verification_tools: dict[str, Any] | None = None
    decomposition_suggested: bool = False
    decomposition_reason: str | None = None
    failure_reason_code: str | None = None
    verification_category: str | None = None
    skip_reason: str | None = None
    partial_work_summary: str | None = None
    decomposition_context: dict[str, Any] | None = None
    execution_context: dict[str, Any] | None = None
    worker_run_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to report payload dictionary."""
        payload: dict[str, Any] = {
            "item_id": self.item_id,
            "status": self.status.value,
            "summary": self.summary,
            "files_changed": self.files_changed,
            "changed_file_paths": self.changed_file_paths,
            "tests_passed": self.tests_passed,
            "test_count": self.test_count,
            "coverage_delta": self.coverage_delta,
            "decomposition_suggested": self.decomposition_suggested,
        }
        if self.test_result is not None:
            payload["test_result"] = self.test_result
        if self.verification_tools:
            payload["verification_tools"] = self.verification_tools
        if self.decomposition_reason is not None:
            payload["decomposition_reason"] = self.decomposition_reason
        if self.failure_reason_code is not None:
            payload["failure_reason_code"] = self.failure_reason_code
        if self.verification_category is not None:
            payload["verification_category"] = self.verification_category
        if self.skip_reason is not None:
            payload["skip_reason"] = self.skip_reason
        if self.partial_work_summary is not None:
            payload["partial_work_summary"] = self.partial_work_summary
        if self.decomposition_context is not None:
            payload["decomposition_context"] = self.decomposition_context
        if self.execution_context is not None:
            payload["execution_context"] = self.execution_context
        if self.worker_run_id is not None:
            payload["worker_run_id"] = self.worker_run_id
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionBatchResultItem":
        """Create from dictionary."""
        return cls(
            item_id=data.get("item_id", ""),
            status=safe_enum_parse(
                ExecutionStatus, data.get("status"), ExecutionStatus.SUCCESS
            ),
            summary=data.get("summary", ""),
            files_changed=data.get("files_changed", 0),
            changed_file_paths=list(data.get("changed_file_paths") or []),
            tests_passed=data.get("tests_passed", False),
            test_count=data.get("test_count", 0),
            test_result=data.get("test_result"),
            coverage_delta=data.get("coverage_delta", 0.0),
            verification_tools=data.get("verification_tools"),
            decomposition_suggested=data.get("decomposition_suggested", False),
            decomposition_reason=data.get("decomposition_reason"),
            failure_reason_code=data.get("failure_reason_code"),
            verification_category=data.get("verification_category"),
            skip_reason=data.get("skip_reason"),
            partial_work_summary=data.get("partial_work_summary"),
            decomposition_context=data.get("decomposition_context"),
            execution_context=data.get("execution_context"),
            worker_run_id=data.get("worker_run_id"),
        )


@dataclass
class ExecutionResult:
    """Report execution result to server."""

    session_id: str
    item_id: str
    status: ExecutionStatus
    summary: str = ""
    files_changed: int = 0
    changed_file_paths: list[str] = field(default_factory=list)
    tests_passed: bool = False
    test_count: int = 0
    test_result: dict[str, Any] | None = None
    coverage_delta: float = 0.0
    verification_tools: dict[str, Any] | None = None
    decomposition_suggested: bool = False
    decomposition_reason: str | None = None
    failure_reason_code: str | None = None
    verification_category: str | None = None
    skip_reason: str | None = None
    partial_work_summary: str | None = None
    decomposition_context: dict[str, Any] | None = None
    execution_context: dict[str, Any] | None = None
    worker_run_id: str | None = None
    batch_id: str | None = None
    batch_failure_policy: str | None = None
    batch_metadata: dict[str, Any] | None = None
    batch_results: list[ExecutionBatchResultItem] = field(default_factory=list)
    progress_cursor: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        payload: dict[str, Any] = {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "status": self.status.value,
            "summary": self.summary,
            "files_changed": self.files_changed,
            "changed_file_paths": self.changed_file_paths,
            "tests_passed": self.tests_passed,
            "test_count": self.test_count,
            "coverage_delta": self.coverage_delta,
            "decomposition_suggested": self.decomposition_suggested,
        }
        if self.test_result is not None:
            payload["test_result"] = self.test_result
        if self.verification_tools:
            payload["verification_tools"] = self.verification_tools
        if self.decomposition_reason is not None:
            payload["decomposition_reason"] = self.decomposition_reason
        if self.failure_reason_code is not None:
            payload["failure_reason_code"] = self.failure_reason_code
        if self.verification_category is not None:
            payload["verification_category"] = self.verification_category
        if self.skip_reason is not None:
            payload["skip_reason"] = self.skip_reason
        if self.partial_work_summary is not None:
            payload["partial_work_summary"] = self.partial_work_summary
        if self.decomposition_context is not None:
            payload["decomposition_context"] = self.decomposition_context
        if self.execution_context is not None:
            payload["execution_context"] = self.execution_context
        if self.worker_run_id is not None:
            payload["worker_run_id"] = self.worker_run_id
        if self.batch_id is not None:
            payload["batch_id"] = self.batch_id
        if self.batch_failure_policy is not None:
            payload["batch_failure_policy"] = self.batch_failure_policy
        if self.batch_metadata is not None:
            payload["batch_metadata"] = self.batch_metadata
        if self.batch_results:
            payload["batch_results"] = [
                item.to_dict() if hasattr(item, "to_dict") else dict(item)
                for item in self.batch_results
            ]
        if self.progress_cursor is not None:
            payload["progress_cursor"] = self.progress_cursor
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionResult":
        """Create from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            item_id=data.get("item_id", ""),
            status=safe_enum_parse(
                ExecutionStatus, data.get("status"), ExecutionStatus.SUCCESS
            ),
            summary=data.get("summary", ""),
            files_changed=data.get("files_changed", 0),
            changed_file_paths=list(data.get("changed_file_paths") or []),
            tests_passed=data.get("tests_passed", False),
            test_count=data.get("test_count", 0),
            test_result=data.get("test_result"),
            coverage_delta=data.get("coverage_delta", 0.0),
            verification_tools=data.get("verification_tools"),
            decomposition_suggested=data.get("decomposition_suggested", False),
            decomposition_reason=data.get("decomposition_reason"),
            failure_reason_code=data.get("failure_reason_code"),
            verification_category=data.get("verification_category"),
            skip_reason=data.get("skip_reason"),
            partial_work_summary=data.get("partial_work_summary"),
            decomposition_context=data.get("decomposition_context"),
            execution_context=data.get("execution_context"),
            worker_run_id=data.get("worker_run_id"),
            batch_id=data.get("batch_id"),
            batch_failure_policy=data.get("batch_failure_policy"),
            batch_metadata=data.get("batch_metadata"),
            batch_results=[
                ExecutionBatchResultItem.from_dict(item)
                for item in data.get("batch_results", [])
                if isinstance(item, dict)
            ],
        )


@dataclass
class AgentReport:
    """Report review agent results to server."""

    session_id: str
    item_id: str
    agent_type: AgentType
    execution_time_ms: int
    status: str
    issues: list[dict[str, Any]] = field(default_factory=list)
    scores: dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "agent_type": self.agent_type.value,
            "execution_time_ms": self.execution_time_ms,
            "status": self.status,
            "issues": self.issues,
            "scores": self.scores,
        }


@dataclass
class FixResult:
    """Report fix attempt result to server."""

    session_id: str
    issue_id: str
    status: str
    canonical_id: str = ""
    reason: str = ""
    files_modified: list[str] = field(default_factory=list)
    verification: dict[str, bool] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "issue_id": self.issue_id,
            "canonical_id": self.canonical_id or self.issue_id,
            "status": self.status,
            "reason": self.reason,
            "files_modified": self.files_modified,
            "verification": self.verification,
        }


@dataclass
class FixReport:
    """Report fix-loop summary to server."""

    session_id: str
    item_id: str = ""
    fixes_applied: int = 0
    fixes_failed: int = 0
    fix_details: list[dict[str, Any]] = field(default_factory=list)
    progress_cursor: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        payload: dict[str, Any] = {
            "session_id": self.session_id,
            "item_id": self.item_id,
            "fixes_applied": self.fixes_applied,
            "fixes_failed": self.fixes_failed,
            "fix_details": self.fix_details,
        }
        if self.progress_cursor:
            payload["progress_cursor"] = self.progress_cursor
        return payload

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FixReport":
        """Create from dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            item_id=data.get("item_id", ""),
            fixes_applied=int(data.get("fixes_applied") or 0),
            fixes_failed=int(data.get("fixes_failed") or 0),
            fix_details=list(data.get("fix_details") or []),
            progress_cursor=(
                str(data.get("progress_cursor")).strip()
                if data.get("progress_cursor") is not None
                and str(data.get("progress_cursor")).strip()
                else None
            ),
        )


@dataclass
class UserDecision:
    """Report user decision during escalation."""

    session_id: str
    escalation_id: str
    decision: UserDecisionChoice
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dictionary."""
        return {
            "session_id": self.session_id,
            "escalation_id": self.escalation_id,
            "decision": self.decision.value,
            "reason": self.reason,
        }


@dataclass
class EscalationDecision:
    """Client-side escalation decision returned by the on_escalation callback."""

    choice: UserDecisionChoice = UserDecisionChoice.FORCE_COMPLETE
    was_timeout: bool = False


@dataclass
class ResumeContext:
    """Context for resuming an interrupted session."""

    session_id: str
    status: SessionStatus
    current_phase: SessionPhase
    can_resume: bool = False
    last_successful_step: str = ""
    pending_action: str = ""
    resume_instructions: str = ""
    awaiting_message: str = ""
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ResumeContext":
        """Create from API response dictionary."""
        return cls(
            session_id=data.get("session_id", ""),
            status=safe_enum_parse(
                SessionStatus,
                data.get("status"),
                SessionStatus.ACTIVE,
            ),
            current_phase=safe_enum_parse(
                SessionPhase,
                data.get("current_phase"),
                SessionPhase.DERIVATION,
            ),
            can_resume=data.get("can_resume", False),
            last_successful_step=data.get("last_successful_step", ""),
            pending_action=data.get("pending_action", ""),
            resume_instructions=data.get("resume_instructions", ""),
            awaiting_message=data.get("awaiting_message", ""),
            workflow_lifecycle=_coerce_lifecycle_payload(
                data.get("workflow_lifecycle")
            ),
            lifecycle_decisions=_coerce_optional_dict(data.get("lifecycle_decisions")),
            legacy_phase_normalization=_coerce_optional_dict(
                data.get("legacy_phase_normalization")
            ),
        )


@dataclass
class ProgressEvent:
    """Progress event transmitted from server to client during polling."""

    event_type: str
    timestamp: str
    payload: dict[str, Any] = field(default_factory=dict)
    event_name: str | None = None
    sequence: int | None = None
    correlation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProgressEvent":
        """Create from dictionary with validation."""
        if "event_type" not in data:
            raise ValueError("ProgressEvent requires 'event_type' field")
        if "timestamp" not in data:
            raise ValueError("ProgressEvent requires 'timestamp' field")
        return cls(
            event_type=data["event_type"],
            timestamp=data["timestamp"],
            payload=data.get("payload", {}),
            event_name=(
                str(data.get("event_name"))
                if data.get("event_name") is not None
                else None
            ),
            sequence=(
                int(data["sequence"])
                if data.get("sequence") is not None
                else None
            ),
            correlation=_coerce_optional_dict(data.get("correlation")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "payload": self.payload,
        }
        if self.event_name is not None:
            result["event_name"] = self.event_name
        if self.sequence is not None:
            result["sequence"] = self.sequence
        if self.correlation:
            result["correlation"] = self.correlation
        return result


__all__ = [
    "PlanUploadRequest",
    "PlanUploadResponse",
    "ResumeRequest",
    "SessionStart",
    "GenerateTestsReport",
    "DerivedPlan",
    "ExaminationReport",
    "RevisedPlan",
    "ExecutionBatchResultItem",
    "ExecutionResult",
    "AgentReport",
    "FixResult",
    "FixReport",
    "UserDecision",
    "EscalationDecision",
    "ResumeContext",
    "ProgressEvent",
]
