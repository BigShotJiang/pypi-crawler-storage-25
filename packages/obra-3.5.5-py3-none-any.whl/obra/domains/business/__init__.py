"""Business workflow domain module.

This domain provides specialized configuration for business process
automation workflows including document processing, approval workflows,
and compliance reviews.

Usage:
    >>> from obra.domains.business import BusinessDomain
    >>> domain = BusinessDomain()
    >>> print(domain.name)
    business
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    5

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
from functools import lru_cache
from typing import Any

import yaml

from obra.domains.interface import FileFilterConfig, QualityDimension
from obra.domains.lifecycle import (
    ACTIVE_STATE,
    DERIVE_CAPABILITY,
    EXECUTE_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    SKIPPED_STATE,
    STORY0_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
    DomainDerivationDefaults,
    DomainLifecyclePolicy,
)
from obra.workflow.stage_contract import collect_stage_contract_issues
from obra.workflow.quality_loop import collect_stage_quality_loop_issues

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)

# Runtime quality keys expected by active review agents.
RUNTIME_QUALITY_PROMPT_TO_FILE: dict[str, str] = {
    "code_quality": "document_quality",
    "docs_analysis": "docs_analysis",
    "testing_coverage": "data_consistency",
    "security_sweep": "process_compliance",
    "security_deep": "security_deep",
}

# Backward-compatible business-native aliases.
LEGACY_QUALITY_ALIASES: dict[str, str] = {
    "document_quality": "code_quality",
    "process_compliance": "security_sweep",
    "data_consistency": "testing_coverage",
}

_BUSINESS_STAGE_TIMEOUT_S = 600
_BUSINESS_STAGE_COMMAND_RUNNER_ID = "business.stage.command"
_BUSINESS_STAGE_WORKFLOW_RUNNER_ID = "business.stage.workflow"


def _business_runner_catalog_entries(*, source_type: str, package: str) -> list[dict[str, Any]]:
    base = {
        "version": "1.0.0",
        "scope": "domain",
        "domain_ids": ["business"],
        "portability": "portable",
        "source": {"source_type": source_type, "package": package},
    }
    return [
        {
            **base,
            "id": _BUSINESS_STAGE_COMMAND_RUNNER_ID,
            "display_name": "Business Stage Command Runner",
            "kind": "command_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                "stage_archetypes": ["delegate", "workflow_runtime"],
                "platforms": ["linux", "darwin", "win32"],
                "required_executables": ["obra"],
            },
            "activation": {
                "command": ["obra", "stage", "execute"],
                "env_contract": ["OBRA_STAGE_CONTEXT_PATH"],
            },
            "description": "Dispatch a business pipeline stage through the Obra runtime.",
            "tags": ["business", "pipeline", "command"],
        },
        {
            **base,
            "id": _BUSINESS_STAGE_WORKFLOW_RUNNER_ID,
            "display_name": "Business Stage Workflow Runner",
            "kind": "workflow_runner",
            "compatibility": {
                "catalog_api_version": "1",
                "input_types": ["derived_plan", "step_result", "implementation"],
                "stage_archetypes": ["workflow_runtime"],
            },
            "activation": {
                "workflow_id": "business.workflow.stage",
                "revision_id": "current",
            },
            "description": "Launch a nested business workflow from a pipeline stage.",
            "tags": ["business", "pipeline", "workflow"],
        },
    ]


def _business_default_pipeline_config() -> dict[str, Any]:
    config = {
        "custom_stages": [
            {
                "name": "business_pipeline_execute",
                "trigger": "on_start",
                "input": "derived_plan",
                "timeout_s": _BUSINESS_STAGE_TIMEOUT_S,
                "runner": {"runner_id": _BUSINESS_STAGE_COMMAND_RUNNER_ID},
                "archetype": "workflow_runtime",
                "quality_loop": _default_stage_quality_loop(
                    checkpoint="business-pipeline-execute-loop",
                    max_total_findings=3,
                ),
            }
        ]
    }
    issues = [
        issue
        for stage in config["custom_stages"]
        for issue in collect_stage_contract_issues(stage)
    ]
    if issues:
        msg = f"business domain pipeline defaults are invalid: {issues[0]}"
        raise ValueError(msg)
    return config


def _default_stage_quality_loop(
    *,
    checkpoint: str,
    max_total_findings: int,
) -> dict[str, Any]:
    quality_loop = {
        "entry": {"when": "after_stage_runner"},
        "routing": {
            "on_pass": "continue",
            "on_advisory_pass": "continue_with_findings",
            "on_revise_required": "revise_same_stage",
            "on_block": "block_stage",
            "on_escalate": "escalate",
            "on_pending_manual": "wait_for_manual_action",
            "on_manual_resume": "resume_stage",
        },
        "evaluators": [
            {
                "runner": "quality.sense_check",
                "subject": "current_stage_output",
                "required": True,
            }
        ],
        "aggregation": {"strategy": "all_required_pass"},
        "thresholds": {"max_total_findings": max_total_findings},
        "pending_manual": {
            "required_action": "approve_revision",
            "resume": {"checkpoint": checkpoint, "strategy": "resume_stage"},
        },
    }
    issues = collect_stage_quality_loop_issues({"quality_loop": quality_loop})
    if issues:
        msg = f"business domain quality_loop default is invalid: {issues[0]['message']}"
        raise ValueError(msg)
    return quality_loop


class BusinessDomain:
    """Domain module for business workflow automation.

    Provides work types, quality prompts, and file filters optimized for
    business process automation tasks.
    """

    @property
    def name(self) -> str:
        """Return domain name."""
        return "business"

    @property
    def display_name(self) -> str:
        """Return human-readable domain name."""
        return "Business Workflows"

    @property
    def description(self) -> str:
        """Return short description for this domain."""
        return "Orchestration for document processing and approval workflows"

    @property
    def example_objectives(self) -> list[str]:
        """Return representative objective examples."""
        return [
            "Process quarterly invoices",
            "Review compliance documents",
            "Generate financial report",
        ]

    @property
    def requires_git(self) -> bool:
        """Return whether this domain requires a git repository."""
        return False

    @property
    def default_sandbox_policy(self) -> str:
        """Return default sandbox policy for this domain."""
        return "WORKSPACE_WRITE"

    @property
    def closeout_key(self) -> str:
        """Return closeout template key for this domain."""
        return self.name

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.business")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for business workflows.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for business workflows.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality assessment dimensions for business workflows."""
        return [
            QualityDimension(
                id="code_quality",
                display_name="Document Quality",
                description="Review document completeness and execution readiness",
                default_enabled=True,
            ),
            QualityDimension(
                id="security_sweep",
                display_name="Process Compliance",
                description="Validate workflow compliance and policy adherence",
                default_enabled=True,
            ),
            QualityDimension(
                id="testing_coverage",
                display_name="Data Consistency",
                description="Detect conflicting values across business artifacts",
                default_enabled=False,
            ),
            QualityDimension(
                id="docs_analysis",
                display_name="Documentation",
                description="Review business-document clarity and delivery readiness",
                default_enabled=False,
            ),
        ]

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.business.prompts")
        prompts: dict[str, str] = {}

        # Canonical runtime key set consumed by active quality agents.
        for prompt_key, file_stem in RUNTIME_QUALITY_PROMPT_TO_FILE.items():
            prompts[prompt_key] = (files / f"{file_stem}.txt").read_text()

        # Compatibility aliases for existing business-native keys.
        for legacy_key, canonical_key in LEGACY_QUALITY_ALIASES.items():
            prompts[legacy_key] = prompts[canonical_key]

        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for business projects.

        Returns:
            FileFilterConfig with business-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_stage_quality_loop_defaults(
        self,
        archetype: str | None = None,
    ) -> dict[str, Any] | None:
        """Return canonical quality-loop defaults for eligible stage archetypes."""
        normalized = str(archetype or "").strip().lower()
        if normalized == "decide":
            return _default_stage_quality_loop(
                checkpoint="business-decide-loop",
                max_total_findings=2,
            )
        if normalized == "generate":
            return _default_stage_quality_loop(
                checkpoint="business-generate-loop",
                max_total_findings=3,
            )
        return None

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for business workflows.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return workflow-lifecycle defaults for business workflows."""
        return DomainLifecyclePolicy(
            capability_states={
                DERIVE_CAPABILITY: ACTIVE_STATE,
                EXECUTE_CAPABILITY: ACTIVE_STATE,
                STORY0_CAPABILITY: SKIPPED_STATE,
                PREFLIGHT_CAPABILITY: SKIPPED_STATE,
                REVIEW_CAPABILITY: SKIPPED_STATE,
                WAIT_RESUME_CAPABILITY: ACTIVE_STATE,
                GIT_REQUIRED_CAPABILITY: SKIPPED_STATE,
                TOOLING_VERIFICATION_CAPABILITY: SKIPPED_STATE,
            }
        )

    def get_derivation_defaults(self) -> DomainDerivationDefaults:
        """Return structured derivation defaults for business workflows."""
        return DomainDerivationDefaults(
            default_work_type="general_business",
            skip_scaffolded_enrichment=True,
            skip_intent_alignment=True,
        )

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Return catalog-backed runner declarations for the business domain."""
        return _business_runner_catalog_entries(source_type="obra_builtin", package="obra")

    def get_default_pipeline_config(self) -> dict[str, Any] | None:
        """Return direct-execution pipeline defaults for compiled business workflows."""
        return _business_default_pipeline_config()

    def execute_pipeline_stage(self, request: Any) -> Any:
        """Dispatch a pipeline stage invoked through `obra stage execute`.

        The default ``business_pipeline_execute`` on_start stage acts as a
        dispatch shim: it confirms that the worker received a well-formed
        stage-context for a compiled business workflow and signals the loop
        to continue. Real per-stage business work is delegated by the
        downstream pipeline (or by a domain-specific subcommand layered on
        top of this contract); keeping this dispatch handler minimal lets
        the surface stay testable in isolation.
        """
        from obra.api.protocol import (
            PipelineStageResult,
            ProducedArtifactPayload,
        )

        artifact = ProducedArtifactPayload(
            artifact_type="stage_output",
            artifact_id=f"stage_dispatch:{request.stage_execution_id}",
            version="v1",
            producer_kind="runtime",
            producer_id=request.runner_id or _BUSINESS_STAGE_COMMAND_RUNNER_ID,
            stage_name=request.stage_name,
            operation_kind="executed",
            metadata={
                "runner_kind": "command_runner",
                "dispatch_target": "obra.stage.execute",
                "domain_id": "business",
            },
        )
        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status="complete",
            outcome="passed",
            findings=[],
            stage_output_artifacts=[artifact],
            candidate_stage_output_artifacts=[artifact],
            routing_signal={"recommended_action": "continue"},
            loop_signal={
                "recommended_action": "continue",
                "current_iteration": request.iteration,
                "max_iterations": request.max_iterations,
            },
            runner_id=request.runner_id or _BUSINESS_STAGE_COMMAND_RUNNER_ID,
            runner_version=request.runner_version,
            runner_selector=request.runner_selector,
            verdict="sound",
            iteration=request.iteration,
        )


def build_code_quality_prompt() -> str:
    """Return business-domain prompt for code-quality review slot."""
    return BusinessDomain().get_quality_prompts()["code_quality"]


def build_testing_coverage_prompt() -> str:
    """Return business-domain prompt for testing-coverage review slot."""
    return BusinessDomain().get_quality_prompts()["testing_coverage"]


def build_docs_analysis_prompt() -> str:
    """Return business-domain prompt for docs-analysis review slot."""
    return BusinessDomain().get_quality_prompts()["docs_analysis"]


def build_security_sweep_prompt() -> str:
    """Return business-domain prompt for fast security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_sweep"]


def build_security_deep_prompt() -> str:
    """Return business-domain prompt for deep security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_deep"]
