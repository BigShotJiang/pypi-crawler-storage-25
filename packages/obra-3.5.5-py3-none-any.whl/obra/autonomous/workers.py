"""Shared bounded analysis and fix worker helpers."""

from __future__ import annotations

from collections.abc import Callable
import logging
from pathlib import Path
from typing import Any, TypeVar, cast

from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)

AnalysisResultT = TypeVar("AnalysisResultT", bound=dict[str, Any])


def run_analysis_worker(
    *,
    working_dir: Path,
    action_name: str,
    llm_config: dict[str, Any],
    prompt: str,
    template_content: dict[str, Any],
    validator: Callable[[dict[str, Any] | str], tuple[bool, str | None]],
    fallback_fn: Callable[[], AnalysisResultT],
    timeout_s: int,
    output_schema: dict[str, Any] | None = None,
    post_validate: Callable[[dict[str, Any]], AnalysisResultT] | None = None,
) -> AnalysisResultT:
    """Run a bounded structured analysis worker with deterministic fallback."""
    try:
        pipeline = build_preexecution_pipeline(
            working_dir=working_dir,
            action_name=action_name,
            max_retries=1,
        )
        result, _metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_content,
            validator=validator,
            fallback_fn=fallback_fn,
            llm_config=llm_config,
            timeout_s=timeout_s,
            allow_unchanged=False,
            output_schema=output_schema,
        )
        if not isinstance(result, dict):
            raise TypeError("Analysis worker output must be a JSON object")
        if post_validate is not None:
            return post_validate(result)
        return cast(AnalysisResultT, result)
    except Exception:
        logger.warning(
            "Analysis worker LLM call failed, using deterministic fallback",
            exc_info=True,
        )
        return fallback_fn()


def run_fix_worker(
    *,
    working_dir: Path,
    call_site: str,
    llm_config: dict[str, Any],
    prompt: str,
    timeout_s: int,
) -> dict[str, Any]:
    """Run a bounded fix worker in execute mode and normalize its summary."""
    summary = invoke_llm_via_cli(
        prompt=prompt,
        cwd=working_dir,
        provider=str(llm_config["provider"]),
        model=str(llm_config["model"]),
        reasoning_level=str(llm_config["reasoning_level"]),
        auth_method=str(llm_config["auth_method"]),
        timeout_s=timeout_s,
        mode="execute",
        response_format="text",
        call_site=call_site,
        skip_interactive_guard=True,
    )
    return {
        "status": "completed",
        "summary": summary.strip(),
    }
