"""Obra CLI package."""

from __future__ import annotations

import importlib
import importlib.util

from obra.cli._main import app, main
from obra.cli.auth import login, logout, whoami
from obra.cli.business import business_app
from obra.cli.briefing import briefing_app
from obra.cli.config import _ensure_dict_section, config_callback
from obra.cli.connectors import connectors_app
from obra.cli.context import context_app
from obra.cli.credentials import credentials_app
from obra.cli.docs import docs_app, logs_app
from obra.cli.feedback import (
    bug as _bug_command,
)
from obra.cli.feedback import (
    feedback_app,
    offer_bug_report,
    telemetry_app,
    triage_app,
)
from obra.cli.gateway import gateway_app
from obra.cli.mcp import mcp_app
from obra.cli.intent import intent_app
from obra.cli.plans import plans_app
from obra.cli.prompts import prompts_app
from obra.cli.run import (
    _resolve_working_dir_selection,  # noqa: F401
    _route_progress_event,  # noqa: F401
    _should_isolate,  # noqa: F401
    auto,
    derive,
    run_objective,
    verify,
)
from obra.cli.run_support.session_flow import (  # noqa: F401
    _normalize_objective_preview,
)
from obra.cli.sessions import sessions_app
from obra.cli.skips import skips_app
from obra.cli.spike import spike_app
from obra.cli.stage import stage_app
from obra.cli.studio import studio_app
from obra.cli.sync import sync_app
from obra.cli.userplan import userplan_app
from obra.cli.workflow_commands import workflow_app
from obra.display.session_banner import (  # noqa: F401
    _format_git_status,
    _format_llm_banner,
    _format_quality_policy_lines,
    _format_review_line,
    _format_run_mode,
    _summarize_config_layers,
)
from obra.session.working_dir import WorkingDirSelection  # noqa: F401


def _register_optional_typer(
    module_name: str,
    attr_name: str,
    command_name: str,
    *,
    rich_help_panel: str | None = None,
) -> None:
    """Register an optional Typer surface when the backing module is present."""
    try:
        spec = importlib.util.find_spec(module_name)
    except ModuleNotFoundError:
        return
    if spec is None:
        return
    module = importlib.import_module(module_name)
    app.add_typer(
        getattr(module, attr_name),
        name=command_name,
        rich_help_panel=rich_help_panel,
    )


app.add_typer(briefing_app, name="briefing", rich_help_panel="AI Operator Resources")
app.add_typer(feedback_app, name="feedback", rich_help_panel="Feedback & Bug Reporting")
app.add_typer(triage_app, name="triage", rich_help_panel="Feedback & Bug Reporting")
app.add_typer(telemetry_app, name="telemetry", rich_help_panel="Feedback & Bug Reporting")
app.command(name="bug", rich_help_panel="Feedback & Bug Reporting")(_bug_command)
app.add_typer(intent_app, name="intent", rich_help_panel="Derivation")
app.add_typer(userplan_app, name="userplan", rich_help_panel="Derivation")
app.add_typer(sessions_app, name="sessions")
app.add_typer(spike_app, name="spike", rich_help_panel="User Commands")
_register_optional_typer(
    "obra.cli.simulate",
    "simulate_app",
    "simulate",
    rich_help_panel="User Commands",
)
_register_optional_typer(
    "obra.cli.local",
    "local_app",
    "local",
    rich_help_panel="User Commands",
)
_register_optional_typer(
    "obra.benchmarks.cli",
    "benchmark_app",
    "benchmark",
    rich_help_panel="User Commands",
)
app.add_typer(plans_app, name="plans")
app.add_typer(sync_app, name="sync", rich_help_panel="User Commands")
app.command(name="login", rich_help_panel="User Commands")(login)
app.command(name="logout", rich_help_panel="User Commands")(logout)
app.command(name="whoami", rich_help_panel="User Commands")(whoami)
app.add_typer(docs_app, name="docs", rich_help_panel="User Commands")
app.add_typer(logs_app, name="logs", rich_help_panel="User Commands")
app.add_typer(skips_app, name="skips", rich_help_panel="User Commands")
app.add_typer(prompts_app, name="prompts", rich_help_panel="User Commands")
app.add_typer(gateway_app, name="gateway", rich_help_panel="User Commands")
app.add_typer(mcp_app, name="mcp", rich_help_panel="User Commands")
app.add_typer(studio_app, name="studio", rich_help_panel="User Commands")
app.add_typer(stage_app, name="stage", rich_help_panel="User Commands")
app.add_typer(business_app, name="business", rich_help_panel="User Commands")
app.add_typer(business_app, name="biz", rich_help_panel="User Commands", hidden=True)
app.add_typer(workflow_app, name="workflow", rich_help_panel="User Commands")
app.add_typer(connectors_app, name="connectors", rich_help_panel="User Commands")
app.add_typer(credentials_app, name="credentials", rich_help_panel="User Commands")
app.add_typer(context_app, name="context", rich_help_panel="User Commands")
app.command(name="run", hidden=False)(run_objective)
app.command(name="derive", rich_help_panel="Derivation")(derive)
app.command(name="verify", rich_help_panel="User Commands")(verify)
app.command(name="auto", rich_help_panel="User Commands")(auto)

__all__ = ["app", "main", "config_callback", "offer_bug_report", "_ensure_dict_section"]


def __getattr__(name: str) -> object:
    # Check _main first (remaining commands), then run (extracted lifecycle)
    for mod_name in ("obra.cli._main", "obra.cli.run", "obra.cli.config"):
        mod = importlib.import_module(mod_name)
        if hasattr(mod, name):
            globals()[name] = getattr(mod, name)
            return globals()[name]
    raise AttributeError(f"module obra.cli has no attribute {name}")
