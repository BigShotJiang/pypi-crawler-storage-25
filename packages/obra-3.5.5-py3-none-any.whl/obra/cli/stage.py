"""`obra stage` CLI: generic pipeline-stage execution worker.

The runtime writes a stage-context JSON file describing the stage to execute
and invokes ``obra stage execute --context <path>``. The worker reads the
file, dispatches through the domain's registered stage executor, and emits
a ``PipelineStageResult`` as JSON on stdout. This pattern mirrors the
driver/worker split in mature job systems (Temporal, Celery, GitHub Actions
runners): one entrypoint serves every domain; the domain-specific logic
lives in the domain module, not in the CLI.
"""

from __future__ import annotations

import json
import os
import sys
import traceback
from pathlib import Path

import typer

from obra.cli._shared import _resolve_command_verbosity, require_terms_accepted
from obra.display import handle_encoding_errors
from obra.stage import StageContextError, load_stage_context

stage_app = typer.Typer(
    help="Execute a pipeline stage from a serialized stage-context file.",
    no_args_is_help=True,
)

_STAGE_CONTEXT_ENV = "OBRA_STAGE_CONTEXT_PATH"


def _emit_result(result_dict: dict[str, object]) -> None:
    """Write the PipelineStageResult JSON to stdout as a single line."""
    sys.stdout.write(json.dumps(result_dict, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _failure_result(
    *,
    stage_name: str,
    stage_execution_id: str,
    runner_id: str,
    runner_version: str,
    code: str,
    message: str,
) -> dict[str, object]:
    """Build a minimal failed PipelineStageResult-shaped dict."""
    return {
        "stage_name": stage_name,
        "stage_execution_id": stage_execution_id,
        "execution_status": "failed",
        "outcome": "error",
        "findings": [
            {
                "id": code,
                "title": "Stage worker failure",
                "description": message,
                "priority": "P1",
            }
        ],
        "routing_signal": {"recommended_action": "block"},
        "runner_id": runner_id,
        "runner_version": runner_version,
        "verdict": "issues",
        "iteration": 0,
    }


def _resolve_context_path(
    context: str | None,
) -> Path:
    """Resolve the context file path from --context or $OBRA_STAGE_CONTEXT_PATH."""
    candidate = context or os.environ.get(_STAGE_CONTEXT_ENV, "").strip()
    if not candidate:
        msg = (
            "No stage context supplied. Pass --context <path> or set "
            f"${_STAGE_CONTEXT_ENV} to the path of a stage-context file."
        )
        raise typer.BadParameter(msg)
    return Path(candidate).expanduser().resolve()


def _lookup_domain_executor(domain_id: str):
    """Return the domain's ``execute_pipeline_stage`` callable if registered."""
    if not domain_id:
        return None
    try:
        from obra.domains.loader import load_domain
    except ImportError:  # pragma: no cover - defensive
        return None
    try:
        domain = load_domain(domain_id)
    except Exception:  # noqa: BLE001 - any load failure falls back to None
        return None
    executor = getattr(domain, "execute_pipeline_stage", None)
    return executor if callable(executor) else None


@stage_app.command("execute")
@handle_encoding_errors
@require_terms_accepted
def execute(
    ctx: typer.Context,
    context: str | None = typer.Option(
        None,
        "--context",
        "-c",
        help=(
            f"Path to a stage-context JSON file. Defaults to ${_STAGE_CONTEXT_ENV} "
            "when unset."
        ),
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        help="Verbosity level for worker logs (stderr only).",
    ),
) -> None:
    """Execute the pipeline stage described by the supplied context file.

    The worker emits a ``PipelineStageResult`` JSON document on stdout and
    exits 0 on success or 1 on any unrecoverable error (the result itself
    may still describe a stage-level failure).
    """
    _ = _resolve_command_verbosity(ctx, verbose)
    path = _resolve_context_path(context)
    try:
        stage_context = load_stage_context(path)
    except StageContextError as exc:
        _emit_result(
            _failure_result(
                stage_name="",
                stage_execution_id="",
                runner_id="",
                runner_version="",
                code="stage_context_invalid",
                message=str(exc),
            )
        )
        raise typer.Exit(1) from exc

    request = stage_context.request
    domain_id = stage_context.domain_id
    executor = _lookup_domain_executor(domain_id)
    if executor is None:
        message = (
            f"Domain {domain_id!r} does not register an execute_pipeline_stage "
            "hook. Add BusinessDomain.execute_pipeline_stage (or the equivalent "
            "for this domain) to dispatch stages via `obra stage execute`."
        )
        _emit_result(
            _failure_result(
                stage_name=request.stage_name,
                stage_execution_id=request.stage_execution_id,
                runner_id=request.runner_id,
                runner_version=request.runner_version,
                code="domain_executor_missing",
                message=message,
            )
        )
        raise typer.Exit(1)

    try:
        result = executor(request)
    except Exception as exc:  # noqa: BLE001 - surface any domain-side failure
        tb = traceback.format_exc()
        _emit_result(
            _failure_result(
                stage_name=request.stage_name,
                stage_execution_id=request.stage_execution_id,
                runner_id=request.runner_id,
                runner_version=request.runner_version,
                code="stage_executor_crashed",
                message=f"{type(exc).__name__}: {exc}\n{tb}",
            )
        )
        raise typer.Exit(1) from exc

    if hasattr(result, "to_dict"):
        _emit_result(result.to_dict())
    elif isinstance(result, dict):
        _emit_result(result)
    else:
        _emit_result(
            _failure_result(
                stage_name=request.stage_name,
                stage_execution_id=request.stage_execution_id,
                runner_id=request.runner_id,
                runner_version=request.runner_version,
                code="stage_executor_returned_invalid",
                message=(
                    "Domain stage executor must return a PipelineStageResult "
                    "or a serializable dict"
                ),
            )
        )
        raise typer.Exit(1)
