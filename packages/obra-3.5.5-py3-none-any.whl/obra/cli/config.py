"""Config command cluster — obra config subcommands and helpers."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path
from typing import Any

import typer
import yaml  # type: ignore[import-untyped]

from obra.config import (
    load_config,
)
from obra.config.persisted_llm_validation import (
    PersistedLLMConfigValidationError,
    merge_config_layers,
    validate_persistable_llm_config,
)
from obra.display import (
    console,
    err_console,
    glyphs,
    handle_encoding_errors,
    print_error,
    print_success,
    print_warning,
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError
from obra.exceptions import ConnectionError as ObraConnectionError
from obra.messages import get_message
from obra.messages.warnings import build_deprecation_warning

logger = logging.getLogger(__name__)

from obra.cli.config_display import _display_validation_human
from obra.cli.config_support import (
    _MODEL_PATHS,
    _apply_auto_provider_detection,
    _apply_provider_side_effects,
    _config_apply_defaults,
    _config_deprecated_paths,
    _config_emit_error,
    _config_emit_warnings,
    _config_flatten,
    _config_format_human_value,
    _config_get_nested_value,
    _config_get_schema_value,
    _config_infer_expected_type,
    _config_is_known_path,
    _config_load_scope,
    _config_normalize_path,
    _config_parse_value,
    _config_path_has_children,
    _config_print_show,
    _config_prune_deprecated_paths,
    _config_redact,
    _config_redact_value,
    _config_schema,
    _config_schema_has_children,
    _config_schema_paths,
    _config_set_nested_value,
    _config_suggest_paths,
    _ensure_dict_section,
    _maybe_emit_ollama_fast_tip,
    _resolve_workspace_id_for_layers,
)
from obra.cli.config_validation import (
    ConfigSchemaIssues,
    _config_schema_missing_sections,
    _config_schema_type_mismatches,
    _config_schema_version_warnings,
    _config_unknown_keys,
    _run_config_validation,
)

# Create config subcommand group (S3.T0)
config_app = typer.Typer(
    name="config",
    help=(
        "Manage Obra configuration (TUI, show, get, set, reset, validate)\n\n"
        "Examples:\n"
        "  obra config --validate\n"
        "  obra config --validate --json\n"
        "  obra config validate --json"
    ),
    invoke_without_command=True,
    rich_markup_mode="rich",
)


def _validate_project_config_before_persist(project_config: dict[str, Any]) -> None:
    """Reject invalid provider/model pairs before writing the workspace layer."""
    from obra.config.loaders._schema import _get_default_schema_cached

    try:
        validate_persistable_llm_config(
            merge_config_layers(
                _get_default_schema_cached(),
                load_config(),
                project_config,
            )
        )
    except PersistedLLMConfigValidationError as exc:
        raise ConfigurationError(
            str(exc),
            recovery=(
                "Choose a model that matches the configured provider, or reset the "
                "conflicting model/tier path to 'default'."
            ),
        ) from exc


def _config_launch_tui(debug: bool = False) -> None:
    """Launch the interactive config TUI.

    Args:
        debug: Enable debug logging for diagnosing config change issues.
    """
    from obra.config.loaders import load_layered_config

    try:
        from obra.config.explorer import run_explorer

        # Load local config and apply defaults so all settings are visible
        # (matches VS Code, Firefox, Docker pattern - show all settings with defaults)
        local_config, origins, warnings = load_layered_config(include_defaults=True)
        if warnings:
            for warning in warnings:
                logger.warning("Config layer warning: %s", warning)
        try:
            from obra.config.loaders import CONFIG_PATH_ALIASES

            for legacy_path in CONFIG_PATH_ALIASES:
                local_config.pop(legacy_path, None)
        except Exception:
            pass

        # Try to get server config if authenticated.  Use a generous
        # timeout so high-latency connections (cross-region, VPN, cold
        # start) don't trigger a false "Offline" banner in the TUI.
        server_config: dict = {}
        api_client = None
        try:
            from obra.api import APIClient

            api_client = APIClient.from_config(pool_retries=False)
            config_data = api_client.get_user_config(retry=True, timeout=15)
            server_config = config_data.get("resolved", {})
            server_config["_preset"] = config_data.get("preset", "unknown")
        except (APIError, ConfigurationError, ObraConnectionError):
            # Server unavailable or not authenticated - offline mode
            logger.debug("Server config unavailable, using offline mode")
        except typer.Exit:
            raise
        except Exception as e:
            # Log unexpected errors but continue in offline mode
            logger.warning(f"Unexpected error fetching server config: {e}")

        run_explorer(
            local_config=local_config,
            server_config=server_config,
            api_client=api_client,
            origins=origins,
            debug=debug,
        )
    except ImportError:
        print_error("Config explorer not available")
        console.print("\nUse 'obra config show' to view current configuration.")
        console.print("Edit ~/.obra/config-layers/01-user.yaml directly to make changes.")
        raise typer.Exit(1) from None


@config_app.callback(invoke_without_command=True)
@handle_encoding_errors
def config_callback(
    ctx: typer.Context,
    # Debug flag for diagnosing config change issues
    debug: bool = typer.Option(
        False,
        "--debug",
        "-d",
        help="Enable debug logging to ~/.obra/logs/config-explorer.log",
    ),
    # Hidden aliases for deprecated flags (S3.T2 - backwards compatibility)
    show: bool = typer.Option(
        False,
        "--show",
        "-s",
        hidden=True,
        help="[DEPRECATED] Use 'obra config show' instead",
    ),
    get_path: str | None = typer.Option(
        None,
        "--get",
        hidden=True,
        help="[DEPRECATED] Use 'obra config get <path>' instead",
    ),
    set_path: str | None = typer.Option(
        None,
        "--set",
        hidden=True,
        help="[DEPRECATED] Use 'obra config set <path> <value>' instead",
    ),
    set_value: str | None = typer.Option(
        None,
        "--value",
        hidden=True,
        help="[DEPRECATED] Value for --set (use 'obra config set <path> <value>' instead)",
    ),
    reset: bool = typer.Option(
        False,
        "--reset",
        hidden=True,
        help="[DEPRECATED] Use 'obra config reset' instead",
    ),
    validate: bool = typer.Option(
        False,
        "--validate",
        help="Validate provider CLIs and configuration",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output validation/show data as JSON",
    ),
    confirm: bool = typer.Option(False, "--confirm", hidden=True),
    scope: str = typer.Option("local", "--scope", hidden=True),
    verbose: bool = typer.Option(False, "--verbose", "-v", hidden=True),
) -> None:
    """Manage Obra configuration.

    Without subcommands, launches the interactive configuration TUI.

    Subcommands:
        show      - Display current configuration
        get       - Get value for a specific config path
        set       - Set a config value
        reset     - Reset configuration to defaults
        validate  - Validate provider CLIs and configuration

    Examples:
        obra config                              # Launch TUI
        obra config show                         # Show all config
        obra config show --json                  # Show as JSON
        obra config get llm.orchestrator.provider
        obra config set llm.orchestrator.provider openai
        obra config reset
        obra config validate
    """
    try:
        # Handle deprecated flag usage with warnings (S3.T2)
        deprecated_flags = [validate, reset, show, bool(get_path), bool(set_path)]
        if any(deprecated_flags):
            # Validate flag combinations
            if sum(1 for flag in deprecated_flags if flag) > 1:
                _config_emit_error(
                    "Only one of --show, --get, --set, --reset, or --validate may be used at a time"
                )
                raise typer.Exit(2)

            if confirm and not set_path:
                _config_emit_error("--confirm is only valid with --set")
                raise typer.Exit(2)

            if set_path and json_output and not confirm:
                _config_emit_error("--set --json requires --confirm")
                raise typer.Exit(2)

            if json_output and not (validate or show or get_path or (set_path and confirm)):
                _config_emit_error(
                    "--json is only valid with --show, --get, --validate, or --set --confirm"
                )
                raise typer.Exit(2)

            if scope not in ("local", "project", "server"):
                _config_emit_error("Invalid scope. Use --scope local, project, or server")
                raise typer.Exit(2)

            if set_path:
                _config_emit_error(
                    f"{build_deprecation_warning('--set', 'obra config set <path> <value>')}"
                )
                raise typer.Exit(2)

            # Handle --validate (deprecated)
            if validate:
                _run_config_validation(json_output=json_output)
                return

            # Handle --reset (deprecated) — delegate to subcommand
            if reset:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--reset', 'obra config reset')}[/yellow]",
                    style="yellow",
                )
                config_reset(yes=False, factory=False, force=False)
                return

            # Handle --show (deprecated) — delegate to subcommand
            if show:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--show', 'obra config show')}[/yellow]",
                    style="yellow",
                )
                config_show(json_output=json_output, scope=scope, verbose=verbose)
                return

            # Handle --get (deprecated) — delegate to subcommand
            if get_path:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--get', f'obra config get {get_path}')}[/yellow]",
                    style="yellow",
                )
                config_get(path=get_path, json_output=json_output, scope=scope)
                return

        # If no subcommand was invoked, launch TUI (default behavior)
        if ctx.invoked_subcommand is None:
            _config_launch_tui(debug=debug)

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to access configuration file: {e}")
        logger.error(f"File I/O error in config command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config command: {e}")
        raise typer.Exit(1) from e


# Config subcommands (S3.T1)
@config_app.command(name="show")
@handle_encoding_errors
def config_show(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show where each value comes from"),
) -> None:
    """Display current configuration.

    Shows all configuration values with their current settings.
    Use --json for machine-readable output.
    Use --scope server to show server-side configuration.
    Use --scope project to show project-layer overrides.

    Examples:
        obra config show
        obra config show --json
        obra config show --scope server
        obra config show --scope project
        obra config show --verbose

    Exit Codes:
        0: Success
        1: Configuration error
    """
    try:
        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        config_data, _, _, warnings, origins = _config_load_scope(scope, warn_unknown_keys=True)
        _config_emit_warnings(warnings)
        _config_print_show(config_data, scope, json_output, origins=origins, verbose=verbose)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config show: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="list")
@handle_encoding_errors
def config_list(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show where each value comes from"),
) -> None:
    """List all configuration values (alias for 'show').

    This is an alias for 'obra config show' to match common CLI patterns.

    Examples:
        obra config list
        obra config list --json
        obra config list --scope server

    Exit Codes:
        0: Success
        1: Configuration error
    """
    # Delegate to config_show
    config_show(json_output=json_output, scope=scope, verbose=verbose)


@config_app.command(name="get")
@handle_encoding_errors
def config_get(
    path: str = typer.Argument(..., help="Configuration path (e.g., llm.orchestrator.provider)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
) -> None:
    """Get value for a specific configuration path.

    Retrieves the value of a single configuration key.
    Use dotted paths to access nested values.

    Examples:
        obra config get llm.orchestrator.provider
        obra config get llm.orchestrator.model --json
        obra config get api.timeout --scope server
        obra config get api.timeout --scope project

    Exit Codes:
        0: Success
        1: Unknown path or error
    """
    try:
        import json

        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        normalized_path, warning = _config_normalize_path(path)
        if warning:
            _config_emit_warnings([warning])
        if not _config_is_known_path(normalized_path):
            _config_emit_error(
                f"Unknown config path '{path}'",
                _config_suggest_paths(path),
            )
            raise typer.Exit(1)

        config_data, _, _, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)
        value = _config_get_nested_value(config_data, normalized_path)
        value = _config_redact_value(normalized_path, value)

        if json_output:
            payload = {"scope": scope, "data": {normalized_path: value}}
            print(json.dumps(payload, ensure_ascii=True))
        else:
            print(_config_format_human_value(value))

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config get: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="set")
@handle_encoding_errors
def config_set(
    path: str = typer.Argument(..., help="Configuration path to set"),
    value: str = typer.Argument(..., help="Value to set"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON after setting"),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    confirm: bool = typer.Option(False, "--confirm", help="Show config after changes"),
) -> None:
    """Set a configuration value.

    Sets a single configuration key to the specified value.
    Values are automatically parsed (true/false become booleans, numbers stay numbers).

    Examples:
        obra config set llm.orchestrator.provider openai
        obra config set api.timeout 30
        obra config set api.timeout 30 --scope project
        obra config set debug true --confirm

    Exit Codes:
        0: Success
        1: Invalid path, value, or error
    """
    try:
        from obra.config import save_config
        from obra.config.explorer.descriptions import (
            get_choices,
            get_lock_reason,
            is_locked,
        )

        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        normalized_path, warning = _config_normalize_path(path)
        if warning:
            _config_emit_warnings([warning])
        if not _config_is_known_path(normalized_path):
            _config_emit_error(
                f"Unknown config path '{path}'",
                _config_suggest_paths(path),
            )
            raise typer.Exit(1)

        if _config_path_has_children(normalized_path):
            _config_emit_error(f"Cannot set non-leaf config path '{path}'")
            raise typer.Exit(1)

        config_data, _, raw_config, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)
        if is_locked(normalized_path):
            reason = get_lock_reason(normalized_path) or "This setting is locked."
            _config_emit_error(reason)
            raise typer.Exit(1)
        raw_value = value
        choices = get_choices(normalized_path, config_data)
        if choices and raw_value not in choices:
            _config_emit_error(
                f"Invalid value '{raw_value}' for {normalized_path}",
                f"Valid choices: {', '.join(choices)}",
            )
            raise typer.Exit(1)

        parsed_value = _config_parse_value(raw_value)
        expected_type = _config_infer_expected_type(normalized_path, config_data)
        if expected_type is bool and not isinstance(parsed_value, bool):
            _config_emit_error(f"Expected boolean for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)
        if expected_type is int and not isinstance(parsed_value, int):
            _config_emit_error(f"Expected integer for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)
        if expected_type is float and not isinstance(parsed_value, (int, float)):
            _config_emit_error(f"Expected number for {normalized_path}, got '{raw_value}'")
            raise typer.Exit(1)

        # ISSUE-SAAS-052: Auto-set provider when setting a model that implies a different provider
        auto_set_provider_path, inferred_provider = _apply_auto_provider_detection(
            normalized_path,
            parsed_value,
            config_data,
            raw_config,
        )

        if scope == "server":
            from obra.api import APIClient

            api_client = APIClient.from_config()
            overrides: dict[str, object] = {normalized_path: parsed_value}
            # Include auto-detected provider in server update
            if auto_set_provider_path and inferred_provider:
                overrides[auto_set_provider_path] = inferred_provider
            server_config = api_client.update_user_config(overrides=overrides)
            config_data = server_config.get("resolved", {})
        else:
            _config_set_nested_value(raw_config, normalized_path, parsed_value)
            # Apply OpenAI-specific git config side effects
            _apply_provider_side_effects(
                normalized_path,
                parsed_value,
                auto_set_provider_path,
                inferred_provider,
                raw_config,
            )
            if scope == "project":
                from obra.config.loaders import get_workspace_layer_path

                project_id, id_warnings = _resolve_workspace_id_for_layers()
                _config_emit_warnings(id_warnings)
                if not project_id:
                    _config_emit_error("Unable to resolve workspace ID for project scope.")
                    raise typer.Exit(1)
                project_path = get_workspace_layer_path(project_id)
                project_path.parent.mkdir(parents=True, exist_ok=True)
                _validate_project_config_before_persist(raw_config)
                project_path.write_text(
                    yaml.safe_dump(raw_config, default_flow_style=False, sort_keys=False),
                    encoding="utf-8",
                )
            else:
                save_config(raw_config)
            config_data, _, _, warnings, _origins = _config_load_scope(scope)
            _config_emit_warnings(warnings)

        if not json_output:
            print_success(f"Set {normalized_path} = {raw_value}")
            from obra.cli.config_support import _PROVIDER_PATHS

            ollama_selected = (
                (normalized_path in _PROVIDER_PATHS and parsed_value == "ollama")
                or (auto_set_provider_path and inferred_provider == "ollama")
                or (normalized_path in _MODEL_PATHS and inferred_provider == "ollama")
            )
            if ollama_selected:
                _maybe_emit_ollama_fast_tip(config_data)
        if confirm or json_output:
            _config_print_show(config_data, scope, json_output)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config set: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="provider")
@handle_encoding_errors
def config_provider(
    provider: str = typer.Argument(..., help="Provider name: anthropic, openai, google, ollama"),
    model: str = typer.Option(
        None, "--model", "-m", help="Override default model for this provider"
    ),
    role: str = typer.Option(
        "both",
        "--role",
        "-r",
        help="Which role to configure: orchestrator, implementation, or both",
    ),
    auth_method: str = typer.Option(
        None,
        "--auth",
        "-a",
        help="Auth method: oauth or api_key (defaults to provider's recommended)",
    ),
    fast: bool = typer.Option(
        False,
        "--fast",
        help="Apply fast local settings when using Ollama (disables heavy planning/review)",
    ),
    scope: str = typer.Option("local", "--scope", help="Config scope: local, project, or server"),
    confirm: bool = typer.Option(False, "--confirm", help="Show config after changes"),
) -> None:
    """Switch LLM provider with automatic tier configuration.

    This is the recommended way to change LLM providers. It sets the provider,
    model, and automatically updates tier defaults (fast/medium/high models).

    Examples:
        obra config provider anthropic              # Switch to Anthropic Claude
        obra config provider openai --model gpt-5.2 # OpenAI with specific model
        obra config provider google --role implementation  # Only change implementation
        obra config provider anthropic --auth api_key      # Use API key auth
        obra config provider ollama --fast          # Apply fast local settings

    Exit Codes:
        0: Success
        1: Invalid provider, role, or error
    """
    try:
        from obra.config import save_config
        from obra.config.llm import infer_provider_from_model
        from obra.config.loaders import get_workspace_layer_path
        from obra.config.providers import LLM_AUTH_METHODS, LLM_PROVIDERS

        # Validate provider
        valid_providers = list(LLM_PROVIDERS.keys())
        if provider not in valid_providers:
            _config_emit_error(
                f"Unknown provider '{provider}'",
                f"Valid providers: {', '.join(valid_providers)}",
            )
            raise typer.Exit(1)

        # Validate role
        valid_roles = ["orchestrator", "implementation", "both"]
        if role not in valid_roles:
            _config_emit_error(
                f"Invalid role '{role}'",
                f"Valid roles: {', '.join(valid_roles)}",
            )
            raise typer.Exit(1)

        # Validate auth method if provided
        if auth_method and auth_method not in LLM_AUTH_METHODS:
            _config_emit_error(
                f"Invalid auth method '{auth_method}'",
                f"Valid methods: {', '.join(LLM_AUTH_METHODS.keys())}",
            )
            raise typer.Exit(1)

        # Validate scope
        if scope not in ("local", "project", "server"):
            _config_emit_error("Invalid scope. Use --scope local, project, or server")
            raise typer.Exit(2)

        # Validate model matches provider if specified
        if model:
            inferred = infer_provider_from_model(model)
            if inferred and inferred != provider:
                _config_emit_error(
                    f"Model '{model}' is associated with provider '{inferred}', not '{provider}'",
                    f"Either change provider to '{inferred}' or use a {provider} model",
                )
                raise typer.Exit(1)

        # Load current config
        config_data, _, raw_config, warnings, _ = _config_load_scope(scope)
        _config_emit_warnings(warnings)

        # Determine roles to update
        roles_to_update = ["orchestrator", "implementation"] if role == "both" else [role]

        # Default auth method if not specified
        effective_auth = auth_method or "oauth"

        # Apply provider config using shared codepath
        from obra.config.llm import apply_provider_config

        raw_config, notifications = apply_provider_config(
            raw_config,
            provider,
            model=model,
            auth_method=effective_auth,
            roles=roles_to_update,
        )

        # Apply fast local settings for Ollama if requested
        if provider == "ollama" and fast:
            _config_set_nested_value(raw_config, "planning.enrichment.enabled", False)
            _config_set_nested_value(raw_config, "planning.enrichment.always_on", False)
            _config_set_nested_value(raw_config, "planning.intent_alignment.model_tier", "fast")
            _config_set_nested_value(raw_config, "planning.intent_alignment.reasoning_level", "off")
            _config_set_nested_value(raw_config, "planning.intent_alignment.max_passes", 1)
            _config_set_nested_value(raw_config, "planning.intent_alignment.block_on_fail", False)
            _config_set_nested_value(raw_config, "planning.intent_gap_check.story_enabled", False)
            _config_set_nested_value(raw_config, "planning.intent_gap_check.epic_enabled", False)
            _config_set_nested_value(raw_config, "refinement.planning.enabled", False)
            _config_set_nested_value(raw_config, "agents.code_review", False)
            _config_set_nested_value(raw_config, "agents.test_gen", False)
            _config_set_nested_value(raw_config, "agents.test_exec", False)
            _config_set_nested_value(raw_config, "agents.rca", False)
            for r in roles_to_update:
                _config_set_nested_value(raw_config, f"llm.{r}.reasoning_level", "off")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.fast", "qwen2.5-coder:3b")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.medium", "qwen2.5-coder:7b")
                _config_set_nested_value(raw_config, f"llm.{r}.tiers.high", "qwen2.5-coder:14b")
            _config_set_nested_value(raw_config, "llm.reasoning_level", "off")
            _config_set_nested_value(raw_config, "llm.reasoning.force_level", "off")

        # Save config
        if scope == "server":
            from obra.api import APIClient

            # Build updates for server (mirror apply_provider_config logic)
            updates = {}
            effective_model = model if model else "default"
            for r in roles_to_update:
                updates[f"llm.{r}.provider"] = provider
                updates[f"llm.{r}.auth_method"] = effective_auth
                updates[f"llm.{r}.model"] = effective_model
                for tier_name in ("fast", "medium", "high"):
                    updates[f"llm.{r}.tiers.{tier_name}"] = "default"

            api_client = APIClient.from_config()
            api_client.update_user_config(overrides=updates)
        elif scope == "project":
            project_id, id_warnings = _resolve_workspace_id_for_layers()
            _config_emit_warnings(id_warnings)
            if not project_id:
                _config_emit_error("Unable to resolve workspace ID for project scope.")
                raise typer.Exit(1)
            project_path = get_workspace_layer_path(project_id)
            project_path.parent.mkdir(parents=True, exist_ok=True)
            _validate_project_config_before_persist(raw_config)
            project_path.write_text(
                yaml.safe_dump(raw_config, default_flow_style=False, sort_keys=False),
                encoding="utf-8",
            )
        else:
            save_config(raw_config)

        # Print success
        roles_str = " and ".join(roles_to_update)
        model_str = f" with model '{model}'" if model else ""
        print_success(f"Switched {roles_str} to {provider}{model_str}")
        if provider == "ollama" and fast:
            console.print(
                f"  [green]{glyphs.success}[/green] Applied fast local settings for Ollama"
            )
            console.print(
                "  [dim]Disabled intent enrichment, refinement, review agents,"
                "and reasoning; adjusted tiers to 3b/7b/14b.[/dim]"
            )
        if provider == "ollama":
            _maybe_emit_ollama_fast_tip(raw_config)

        # Print tier notifications
        for notif in notifications:
            console.print(f"  {notif}")

        if confirm:
            config_data, _, _, warnings, _ = _config_load_scope(scope)
            _config_emit_warnings(warnings)
            _config_print_show(config_data, scope, json_output=False)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config provider: {e}")
        raise typer.Exit(1) from e


# Fields to preserve during soft reset (terms acceptance only;
# auth credentials live in ~/.obra/auth.yaml and are unaffected by config reset)
_CONFIG_PRESERVE_FIELDS = {
    "terms_accepted",
}


def _soft_reset_config(config_path: Path, preserve_fields: set[str]) -> None:
    """Soft reset: preserve auth fields, reset everything else to defaults.

    Args:
        config_path: Path to the main user config file.
        preserve_fields: Set of top-level field names to preserve across reset.
    """
    from obra.config import save_config
    from obra.config.explorer.utils import build_reset_user_config, load_default_config_schema
    from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config
    from obra.config.loaders import CONFIG_LAYER_DIR

    defaults = load_default_config_schema()
    if not defaults:
        console.print("[yellow]Warning: Could not load bundled defaults[/yellow]")
        defaults = {}
    apply_default_persona_to_config(defaults)

    # Load current config to extract auth fields
    try:
        current_config = load_config()
    except Exception:
        current_config = {}

    preserved: dict[str, object] = {}
    for field in preserve_fields:
        if field in current_config:
            preserved[field] = current_config[field]

    # Delete extra layer files (keep main user config)
    if CONFIG_LAYER_DIR.exists():
        for path in CONFIG_LAYER_DIR.glob("*.yaml"):
            if path != config_path:
                path.unlink()
                console.print(f"[dim]Deleted: {path}[/dim]")

    new_config = build_reset_user_config(defaults, preserved)
    save_config(new_config)

    console.print(f"[green]Preserved {len(preserved)} auth/account fields[/green]")
    print_success("Soft reset complete (auth preserved)")


def _factory_reset_config(config_path: Path) -> None:
    """Factory reset: delete ALL config including auth, restore from defaults.

    Args:
        config_path: Path to the main user config file.
    """
    from obra.config.explorer.utils import build_reset_user_config, load_default_config_schema
    from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config
    from obra.config.loaders import AUTH_STATE_PATH, CONFIG_LAYER_DIR

    defaults = load_default_config_schema()
    if not defaults:
        console.print("[yellow]Warning: Could not load bundled defaults[/yellow]")
        defaults = {}
    apply_default_persona_to_config(defaults)

    if AUTH_STATE_PATH.exists():
        AUTH_STATE_PATH.unlink()
        console.print(f"[dim]Deleted: {AUTH_STATE_PATH}[/dim]")

    if CONFIG_LAYER_DIR.exists():
        for path in CONFIG_LAYER_DIR.glob("*.yaml"):
            path.unlink()
            console.print(f"[dim]Deleted: {path}[/dim]")

    CONFIG_LAYER_DIR.mkdir(parents=True, exist_ok=True)

    import yaml

    reset_config = build_reset_user_config(defaults)
    config_content = yaml.safe_dump(
        reset_config,
        default_flow_style=False,
        sort_keys=False,
    )
    config_path.write_text(
        f"# Obra user configuration (factory reset)\n"
        f"# Use 'obra config' to configure settings\n\n"
        f"{config_content}",
        encoding="utf-8",
    )
    console.print(f"Regenerated: {config_path}")
    print_success("Factory reset complete - please run 'obra login' to authenticate")


def _force_reset_config(config_path: Path, preserve_fields: set[str]) -> None:
    """Force reset: delete and regenerate config for corrupted files.

    Attempts to extract auth fields from potentially corrupted config before
    deleting everything.

    Args:
        config_path: Path to the main user config file.
        preserve_fields: Set of top-level field names to preserve across reset.
    """
    from obra.config.explorer.utils import build_reset_user_config, load_default_config_schema
    from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config
    from obra.config.loaders import CONFIG_LAYER_DIR

    defaults = load_default_config_schema()
    if not defaults:
        console.print("[yellow]Warning: Could not load bundled defaults[/yellow]")
        defaults = {}
    apply_default_persona_to_config(defaults)

    preserved: dict[str, object] = {}

    # Try to extract auth fields from potentially corrupted config
    if config_path.exists():
        try:
            import yaml

            raw_content = config_path.read_text(encoding="utf-8")
            raw_config = yaml.safe_load(raw_content) or {}
            for field in preserve_fields:
                if field in raw_config:
                    preserved[field] = raw_config[field]
        except Exception:
            console.print("[yellow]Could not extract auth from corrupted config[/yellow]")

    # Delete all config files
    if CONFIG_LAYER_DIR.exists():
        for path in CONFIG_LAYER_DIR.glob("*.yaml"):
            path.unlink()
            console.print(f"[dim]Deleted: {path}[/dim]")

    CONFIG_LAYER_DIR.mkdir(parents=True, exist_ok=True)

    new_config = build_reset_user_config(defaults, preserved)

    import yaml

    config_content = yaml.safe_dump(new_config, default_flow_style=False, sort_keys=False)
    config_path.write_text(
        f"# Obra user configuration (force reset)\n"
        f"# Use 'obra config' to configure settings\n\n"
        f"{config_content}",
        encoding="utf-8",
    )
    console.print(f"Regenerated: {config_path}")

    if preserved:
        console.print(f"[green]Preserved {len(preserved)} auth/account fields[/green]")
    print_success("Force reset complete (auth preserved)")


@config_app.command(name="reset")
@handle_encoding_errors
def config_reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    factory: bool = typer.Option(
        False,
        "--factory",
        help="Full factory reset: delete ALL config including auth (requires re-login)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force file operations (use when config is corrupted)",
    ),
) -> None:
    """Reset configuration to defaults.

    Two reset modes available:

    SOFT RESET (default):
        Resets all settings to defaults from the bundled default_config.yaml,
        but PRESERVES your authentication and terms acceptance. You won't need
        to log in again or re-accept the terms of service.

    FACTORY RESET (--factory):
        Complete factory reset. Deletes ALL configuration including auth tokens
        and terms acceptance. You will need to log in again and re-accept the
        terms of service. Use this for a completely fresh start.

    Examples:
        obra config reset              # Soft reset (preserves auth)
        obra config reset --yes        # Soft reset without confirmation
        obra config reset --factory    # Full factory reset (requires re-login)
        obra config reset --force      # Force reset if config is corrupted

    Exit Codes:
        0: Success or cancelled
        1: Error
    """
    try:
        from obra.config.loaders import CONFIG_PATH

        if not yes:
            # C14: Check for non-interactive mode before prompting
            if not sys.stdin.isatty():
                console.print(
                    "Non-interactive mode: skipping reset confirmation (defaulting to cancel)"
                )
                console.print("Use --yes flag to skip confirmation.")
                return

            if factory:
                console.print(
                    "[bold red]WARNING: Factory reset will delete ALL configuration "
                    "including authentication.[/bold red]"
                )
                console.print("You will need to log in again and re-accept the terms of service.")
                do_reset = typer.confirm(get_message("prompt.confirm.factory_reset"))
            else:
                console.print("[bold]Soft reset[/bold]: All settings will be reset to defaults.")
                console.print("Your authentication and terms acceptance will be preserved.")
                do_reset = typer.confirm(get_message("prompt.confirm.soft_reset"))

            if not do_reset:
                console.print("Cancelled")
                return

        if factory:
            _factory_reset_config(CONFIG_PATH)
        elif force:
            _force_reset_config(CONFIG_PATH, _CONFIG_PRESERVE_FIELDS)
        else:
            _soft_reset_config(CONFIG_PATH, _CONFIG_PRESERVE_FIELDS)

    except ConfigurationError as e:
        display_obra_error(e, console)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config reset: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="validate")
@handle_encoding_errors
def config_validate(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    schema: bool = typer.Option(
        False, "--schema", help="Validate config keys and types against schema"
    ),
) -> None:
    """Validate provider CLIs and configuration.

    Checks that provider CLIs are installed and configuration is valid.
    Reports status for each provider and overall configuration health.

    Examples:
        obra config validate
        obra config validate --json
        obra config validate --schema

    Exit Codes:
        0: All checks passed
        1: Issues found or error
    """
    try:
        _run_config_validation(json_output=json_output, include_schema=schema)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in config validate: {e}")
        raise typer.Exit(1) from e


@config_app.command(name="search")
@handle_encoding_errors
def config_search(
    keyword: str = typer.Argument(
        ..., help="Keyword to search for in config paths and descriptions"
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Search configuration paths by keyword.

    Searches config paths and descriptions for the given keyword.
    Useful for finding settings when you don't know the exact path.

    Examples:
        obra config search security
        obra config search timeout
        obra config search agent
        obra config search model

    Exit Codes:
        0: Found matching settings
        1: No matches found
    """
    import json as json_module

    from obra.config.loaders import SEMANTIC_CONFIG_ALIASES

    schema_paths = _config_schema_paths()
    keyword_lower = keyword.lower()

    # Find matching paths in schema
    matches: list[dict[str, str]] = []

    # Check schema paths
    for path in sorted(schema_paths):
        if keyword_lower in path.lower():
            matches.append({"path": path, "type": "config", "description": ""})

    # Check semantic aliases
    alias_matches: list[dict[str, str]] = []
    for alias, canonical in SEMANTIC_CONFIG_ALIASES.items():
        if keyword_lower in alias.lower():
            alias_matches.append(
                {
                    "alias": alias,
                    "canonical": canonical,
                    "type": "alias",
                }
            )

    # Get descriptions for matches (if available)
    try:
        from obra.config.explorer.descriptions import get_description

        for match in matches:
            desc = get_description(match["path"])
            if desc:
                match["description"] = desc
    except ImportError:
        pass

    if not matches and not alias_matches:
        if json_output:
            print(
                json_module.dumps(
                    {"keyword": keyword, "matches": [], "aliases": []},
                    ensure_ascii=True,
                )
            )
        else:
            console.print(f"[yellow]No settings found matching '{keyword}'[/yellow]")
            console.print()
            console.print("[dim]Try searching for:[/dim]")
            console.print("  • security, doc, review - agent settings")
            console.print("  • timeout - timeout settings")
            console.print("  • model, llm - LLM settings")
            console.print("  • budget - budget framework settings")
        raise typer.Exit(1)

    if json_output:
        output = {
            "keyword": keyword,
            "matches": matches,
            "aliases": alias_matches,
        }
        print(json_module.dumps(output, ensure_ascii=True))
    else:
        console.print(f"[bold]Config settings matching '{keyword}':[/bold]")
        console.print()

        if alias_matches:
            console.print("[bold cyan]Shortcuts (semantic aliases):[/bold cyan]")
            for alias_match in alias_matches:
                console.print(
                    f"  • [green]{alias_match['alias']}[/green] → {alias_match['canonical']}"
                )
            console.print()

        if matches:
            console.print("[bold cyan]Config paths:[/bold cyan]")
            for match in matches[:20]:  # Limit to 20 results
                path = match["path"]
                desc = match.get("description", "")
                if desc:
                    console.print(f"  • [green]{path}[/green] - {desc}")
                else:
                    console.print(f"  • [green]{path}[/green]")
            if len(matches) > 20:
                console.print(f"  ... and {len(matches) - 20} more")
            console.print()

        console.print("[dim]Use 'obra config get <path>' to view a value[/dim]")
        console.print("[dim]Use 'obra config set <path> <value>' to change a value[/dim]")


@config_app.command(name="recipes")
@handle_encoding_errors
def config_recipes() -> None:
    """Show common configuration recipes.

    Displays common configuration patterns for typical use cases
    like disabling agents, changing models, and adjusting timeouts.

    Examples:
        obra config recipes

    Exit Codes:
        0: Always (informational command)
    """
    console.print()
    console.print("[bold cyan]Common Configuration Recipes[/bold cyan]")
    console.print()

    console.print("[bold]1. Disable Security Audits[/bold]")
    console.print("   obra config set agents.security false")
    console.print(
        "   [dim]Or: obra config set features.quality_automation.agents.security_audit.enabled false[/dim]"
    )
    console.print()

    console.print("[bold]2. Disable Documentation Audits[/bold]")
    console.print("   obra config set agents.doc_audit false")
    console.print(
        "   [dim]Or: obra config set features.quality_automation.agents.doc_audit.enabled false[/dim]"
    )
    console.print()

    console.print("[bold]3. Change LLM Model[/bold]")
    console.print("   obra config set llm.model sonnet")
    console.print("   obra config set llm.model opus")
    console.print("   obra config set llm.model haiku")
    console.print()

    console.print("[bold]4. Adjust Timeouts[/bold]")
    console.print("   obra config set orchestration.timeouts.llm_call_s 3600  # 1 hour")
    console.print("   obra config set orchestration.timeouts.agent_execution_s 7200  # 2 hours")
    console.print()

    console.print("[bold]5. Disable All Quality Automation Agents[/bold]")
    console.print("   obra config set features.quality_automation.enabled false")
    console.print()

    console.print("[bold]6. Enable Budget Framework[/bold]")
    console.print("   obra config set orchestration.budgets.enabled true")
    console.print()

    console.print("[bold]7. Pre-flight Setup (Disable Audits, Set Model)[/bold]")
    console.print("   obra config set llm.model sonnet")
    console.print("   obra config set agents.security false")
    console.print("   obra config set agents.doc_audit false")
    console.print()

    console.print("[dim]Use 'obra config search <keyword>' to find more settings[/dim]")
    console.print("[dim]Use 'obra config show' to view all current settings[/dim]")
