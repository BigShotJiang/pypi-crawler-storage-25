"""Knowledge document management API routes."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.routes.assistant import _resolve_assistant_project_root
from obra.gateway.security.scopes import GatewayScope, require_scope

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


def _get_knowledge_repo(
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
):
    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository

    config = get_gateway_assistant_config()
    project_root = _resolve_assistant_project_root(
        request,
        project_id=project_id,
        working_dir=working_dir,
    )
    return KnowledgeRepository(
        project_root,
        max_document_bytes=config["knowledge_max_document_bytes"],
        max_total_bytes=config["knowledge_max_total_bytes"],
    )


@router.post("/documents", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def upload_document(
    request: Request,
    file: UploadFile = File(...),
    name: str = Form(...),
    scope: str = Form(...),
    project_id: str | None = Form(default=None),
    workflow_id: str | None = Form(default=None),
    description: str | None = Form(default=None),
    working_dir: str | None = Form(default=None),
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    content = await file.read()
    content_type = file.content_type or "text/plain"
    try:
        metadata = repo.add_document(
            name=name,
            content=content,
            content_type=content_type,
            scope=scope,
            workflow_id=workflow_id,
            description=description,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )
    return {"document": metadata}


@router.get("/documents", dependencies=_READ_SCOPE)
async def list_documents(
    request: Request,
    project_id: str | None = None,
    scope: str | None = None,
    workflow_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    documents = repo.list_documents(scope=scope, workflow_id=workflow_id)
    return paginate_collection(
        collection_key="documents",
        items=documents,
        params=pagination_params_from_request(request),
    )


@router.get("/documents/{doc_id}", dependencies=_READ_SCOPE)
async def get_document(
    doc_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    try:
        metadata, content_text = repo.get_document(doc_id)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found",
        )
    return {"document": metadata, "content_text": content_text}


@router.delete(
    "/documents/{doc_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=_OPERATE_SCOPE,
)
async def delete_document(
    doc_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> None:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    if not repo.delete_document(doc_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found",
        )
