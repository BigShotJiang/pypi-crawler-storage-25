"""Canonical Workflow Studio workflow inspection routes."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.automation.workspaces import derive_workspace_id
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.routes.assistant import (
    _maybe_resolve_assistant_project_root,
    _resolve_assistant_project_root,
)
from obra.gateway.workflow_studio.composition import (
    CompositionConflictError,
    bind_child_workflow,
    filter_bindable_workflows,
)
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore
from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.contract_projection import build_workflow_contract
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService
from obra.workflow.package import (
    WorkflowPackageBuilder,
    WorkflowPackageImporter,
    sanitize_package_filename_component,
)

router = APIRouter(prefix="/api/workflows", tags=["workflow-studio"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


class BindChildWorkflowRequest(BaseModel):
    """Request body for binding a workflow_runner child workflow."""

    model_config = ConfigDict(extra="forbid")

    child_workflow_id: str = Field(..., min_length=1, max_length=256)
    project_id: str | None = Field(default=None, min_length=1, max_length=256)
    working_dir: str | None = Field(default=None, min_length=1, max_length=4096)
    revision_id: str | None = Field(default=None, max_length=256)


@router.get("/", dependencies=_READ_SCOPE)
async def list_workflows(
    request: Request,
    view: Literal["active", "archived", "trash"] | None = None,
    bindable: bool | None = None,
    exclude_workflow_id: str | None = None,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflows = await asyncio.to_thread(repository.list_workflows, view=view)
    if bindable:
        local_store = getattr(request.app.state, "local_workflow_store", None)
        workflows = await asyncio.to_thread(
            filter_bindable_workflows,
            workflows,
            exclude_workflow_id,
            local_store if isinstance(local_store, LocalWorkflowStore) else None,
        )
    return paginate_collection(
        collection_key="workflows",
        items=workflows,
        params=pagination_params_from_request(request),
    )


@router.get("/export", dependencies=_READ_SCOPE)
async def export_workflows(request: Request) -> dict[str, object]:
    store = _local_workflow_store(request)
    return await asyncio.to_thread(store.export_snapshot)


@router.post("/import", dependencies=_OPERATE_SCOPE)
async def import_workflows(
    payload: dict[str, Any],
    request: Request,
) -> dict[str, object]:
    store = _local_workflow_store(request)
    result = await asyncio.to_thread(store.import_snapshot, payload)
    return result


@router.get("/{workflow_id}/export-package", dependencies=_READ_SCOPE)
async def export_workflow_package(
    workflow_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> JSONResponse:
    store = _local_workflow_store(request)
    workflow = await asyncio.to_thread(store.get_workflow_head, workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")

    revisions = await asyncio.to_thread(store.list_workflow_revisions, workflow_id)
    knowledge_repository = _maybe_knowledge_repository(
        request,
        project_id=project_id,
        working_dir=working_dir,
    )
    documents: list[dict[str, Any]] = []
    if knowledge_repository is not None:
        documents = await asyncio.to_thread(
            knowledge_repository.list_documents,
            "workflow",
            workflow_id,
        )
    try:
        package = await asyncio.to_thread(
            WorkflowPackageBuilder(
                workflow=workflow,
                revisions=revisions,
                knowledge_documents=documents,
                knowledge_docs_dir=(
                    knowledge_repository.docs_dir
                    if knowledge_repository is not None
                    else _placeholder_docs_dir()
                ),
            ).build
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc
    title = str((package.get("manifest") or {}).get("title") or workflow.get("title") or "").strip()
    filename = f'{sanitize_package_filename_component(title, fallback=workflow_id)}.obra'
    response = JSONResponse(package)
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


@router.post(
    "/import-package",
    status_code=status.HTTP_201_CREATED,
    dependencies=_OPERATE_SCOPE,
)
async def import_workflow_package(
    payload: dict[str, Any],
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> JSONResponse:
    store = _local_workflow_store(request)

    # Check whether the package actually contains knowledge documents.
    # If it does, workspace resolution is required so we can write them.
    # If not, a missing working directory should not block the import.
    has_knowledge_docs = bool(
        isinstance(payload, dict)
        and isinstance(payload.get("knowledge_documents"), list)
        and len(payload["knowledge_documents"]) > 0
    )
    if has_knowledge_docs:
        try:
            knowledge_repository: KnowledgeRepository | None = _knowledge_repository(
                request,
                project_id=project_id,
                working_dir=working_dir,
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    f"Cannot import knowledge documents: {exc}. "
                    "Select a project with a configured working directory, "
                    "or remove knowledge documents from the package."
                ),
            ) from exc
    else:
        knowledge_repository = _maybe_knowledge_repository(
            request,
            project_id=project_id,
            working_dir=working_dir,
        )

    try:
        result = await asyncio.to_thread(
            WorkflowPackageImporter(
                package=payload,
                workflow_store=store,
                knowledge_repository=knowledge_repository,
            ).import_package
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc
    return JSONResponse(result, status_code=status.HTTP_201_CREATED)


@router.get("/{workflow_id}", dependencies=_READ_SCOPE)
async def get_workflow(workflow_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow = await asyncio.to_thread(repository.get_workflow, workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
    return {"workflow": workflow}


@router.get("/{workflow_id}/contract", dependencies=_READ_SCOPE)
async def get_workflow_contract(workflow_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow = await asyncio.to_thread(repository.get_workflow, workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
    return {"contract": build_workflow_contract(workflow_id, workflow)}


@router.get("/{workflow_id}/revisions", dependencies=_READ_SCOPE)
async def list_workflow_revisions(
    workflow_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revisions = await asyncio.to_thread(repository.list_workflow_revisions, workflow_id)
    if not revisions:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
    return paginate_collection(
        collection_key="revisions",
        items=revisions,
        params=pagination_params_from_request(request),
        extra={"workflow_id": workflow_id},
    )


@router.get("/{workflow_id}/revisions/{revision_id}", dependencies=_READ_SCOPE)
async def get_workflow_revision(
    workflow_id: str,
    revision_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revision = await asyncio.to_thread(repository.get_workflow_revision, workflow_id, revision_id)
    if revision is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Workflow revision not found"
        )
    return {"workflow_revision": revision}


@router.post("/", dependencies=_OPERATE_SCOPE)
async def create_workflow(
    payload: dict[str, Any],
    request: Request,
    response: Response,
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = await asyncio.to_thread(service.create_workflow, payload)
    response.status_code = status.HTTP_201_CREATED
    _emit_workflow_event(request, "workflow.created", result)
    return result


@router.post("/{workflow_id}/validate", dependencies=_READ_SCOPE)
async def validate_workflow(
    workflow_id: str,
    payload: dict[str, Any],
    request: Request,
    if_match: str | None = Header(default=None, alias="If-Match"),
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = await asyncio.to_thread(
        service.validate_workflow, workflow_id, payload, expected_revision_id=if_match,
    )
    _emit_workflow_event(request, "workflow.validated", result)
    return result


@router.post("/{workflow_id}/archive", dependencies=_OPERATE_SCOPE)
async def archive_workflow(
    workflow_id: str,
    request: Request,
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = await asyncio.to_thread(service.archive_workflow, workflow_id)
    _emit_workflow_event(request, "workflow.archived", result)
    return result


@router.post("/{workflow_id}/restore", dependencies=_OPERATE_SCOPE)
async def restore_workflow(
    workflow_id: str,
    request: Request,
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = await asyncio.to_thread(service.restore_workflow, workflow_id)
    _emit_workflow_event(request, "workflow.restored", result)
    return result


@router.patch("/{workflow_id}", dependencies=_OPERATE_SCOPE)
async def patch_workflow(
    workflow_id: str,
    payload: dict[str, Any],
    request: Request,
    if_match: str | None = Header(default=None, alias="If-Match"),
) -> dict[str, object]:
    await asyncio.to_thread(
        _raise_stale_revision_conflict, request, workflow_id, expected_revision_id=if_match,
    )
    service = _workflow_action_service(request)
    result = await asyncio.to_thread(
        service.apply_workflow, workflow_id, payload, expected_revision_id=if_match,
    )
    if str(result.get("outcome") or "").strip().lower() == "conflict":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=result)
    if str(result.get("outcome") or "").strip().lower() == "accepted":
        _emit_workflow_event(
            request,
            "workflow.created"
            if result.get("resulting_revision_ref", {}).get("workflow_id") != workflow_id
            else "workflow.updated",
            result,
        )
    return result


@router.post("/{workflow_id}/stages/{stage_id}/bind-child-workflow", dependencies=_OPERATE_SCOPE)
async def bind_workflow_stage_child(
    workflow_id: str,
    stage_id: str,
    body: BindChildWorkflowRequest,
    request: Request,
) -> dict[str, object]:
    store = _local_workflow_store(request)
    workspace_id = body.project_id
    if not workspace_id:
        if body.working_dir is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="working_dir is required when project_id is omitted",
            )
        workspace_id = derive_workspace_id(Path(body.working_dir).expanduser().resolve(strict=False))
    try:
        result = await asyncio.to_thread(
            bind_child_workflow,
            store,
            workflow_id,
            stage_id,
            body.child_workflow_id,
            workspace_id,
            body.revision_id,
        )
    except CompositionConflictError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error_code": exc.error_code, "message": str(exc)},
        ) from exc
    except ValueError as exc:
        message = str(exc)
        status_code = (
            status.HTTP_404_NOT_FOUND if "not found" in message.lower() else status.HTTP_400_BAD_REQUEST
        )
        raise HTTPException(status_code=status_code, detail=message) from exc

    _emit_workflow_event(request, "workflow.updated", result)
    return result


@router.delete("/{workflow_id}", response_model=None, dependencies=_OPERATE_SCOPE)
async def delete_workflow(
    workflow_id: str,
    request: Request,
    x_force_delete: str | None = Header(default=None, alias="X-Force-Delete"),
) -> Any:
    service = _workflow_action_service(request)
    if str(x_force_delete or "").strip().lower() == "true":
        await asyncio.to_thread(service.hard_delete_workflow, workflow_id)
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    result = await asyncio.to_thread(service.soft_delete_workflow, workflow_id)
    _emit_workflow_event(request, "workflow.deleted", result)
    return result


def _raise_stale_revision_conflict(
    request: Request,
    workflow_id: str,
    *,
    expected_revision_id: str | None,
) -> None:
    normalized_expected = str(expected_revision_id or "").strip()
    if not normalized_expected:
        return

    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_workflow_revisions(workflow_id)
    if not revisions:
        return

    current_revision_id = str(revisions[0].get("revision_id") or "").strip()
    if not current_revision_id or current_revision_id == normalized_expected:
        return

    workflow = repository.get_workflow(workflow_id)
    raise HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail={
            "outcome": "conflict",
            "workflow": workflow or {},
            "base_revision_ref": {
                "workflow_id": workflow_id,
                "revision_id": normalized_expected,
            },
            "current_revision_ref": {
                "workflow_id": workflow_id,
                "revision_id": current_revision_id,
            },
            "conflict_summary": {
                "status": "stale_revision",
                "reason": "expected_revision_mismatch",
            },
        },
    )


def _workflow_action_service(request: Request) -> WorkflowActionService:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    local_store = getattr(request.app.state, "local_workflow_store", None)
    repository = WorkflowStudioRepository.from_request(request)
    workflow_storage = str(
        getattr(
            request.app.state,
            "workflow_storage",
            getattr(request.app.state, "gateway_config", {}).get("workflow_storage", "cloud"),
        )
        or "cloud"
    ).strip().lower()
    if callable(client_factory):
        return WorkflowActionService(
            client_factory=client_factory,
            local_store=local_store if isinstance(local_store, LocalWorkflowStore) else None,
            workflow_storage=workflow_storage,
            workflow_run_count_resolver=lambda workflow_id: len(
                repository.list_runs(workflow_id=workflow_id)
            ),
        )
    return WorkflowActionService(
        local_store=local_store if isinstance(local_store, LocalWorkflowStore) else None,
        workflow_storage=workflow_storage,
        workflow_run_count_resolver=lambda workflow_id: len(
            repository.list_runs(workflow_id=workflow_id)
        ),
    )


def _local_workflow_store(request: Request) -> LocalWorkflowStore:
    store = getattr(request.app.state, "local_workflow_store", None)
    if isinstance(store, LocalWorkflowStore):
        return store
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail="Local workflow storage is unavailable",
    )


def _knowledge_repository(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
) -> KnowledgeRepository:
    config = get_gateway_assistant_config()
    project_root = _resolve_assistant_project_root(
        request,
        project_id=project_id,
        working_dir=working_dir,
    )
    return KnowledgeRepository(
        project_root,
        max_document_bytes=config["knowledge_max_document_bytes"],
        max_total_bytes=config["knowledge_max_total_bytes"],
    )


def _maybe_knowledge_repository(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
) -> KnowledgeRepository | None:
    """Resolve a knowledge repository, returning None when workspace cannot be determined.

    Used by export-package where the workflow may have no knowledge docs and
    the project may have no configured working directory.
    """
    project_root = _maybe_resolve_assistant_project_root(
        request,
        project_id=project_id,
        working_dir=working_dir,
    )
    if project_root is None:
        return None
    config = get_gateway_assistant_config()
    return KnowledgeRepository(
        project_root,
        max_document_bytes=config["knowledge_max_document_bytes"],
        max_total_bytes=config["knowledge_max_total_bytes"],
    )


def _placeholder_docs_dir() -> Path:
    """Return a non-existent docs dir for exports with no knowledge repository."""
    return Path("/dev/null/obra-no-knowledge-docs")


def _emit_workflow_event(request: Request, event_name: str, result: dict[str, Any]) -> None:
    session_manager = request.app.state.session_manager
    emit = getattr(session_manager, "emit_workflow_event", None)
    if not callable(emit):
        return
    workflow_id = str(
        result.get("workflow_id")
        or result.get("workflow", {}).get("workflow_id")
        or result.get("resulting_revision_ref", {}).get("workflow_id")
        or ""
    ).strip()
    if not workflow_id:
        return
    workflow_revision_id = str(
        result.get("revision_id")
        or result.get("resulting_revision_ref", {}).get("revision_id")
        or result.get("workflow", {}).get("revision_id")
        or ""
    ).strip()
    emit(
        workflow_id,
        {
            "event_name": event_name,
            "payload": result,
            "workflow_id": workflow_id,
            "workflow_revision_id": workflow_revision_id or None,
            "base_revision_id": result.get("base_revision_ref", {}).get("revision_id"),
            "current_revision_id": result.get("current_revision_ref", {}).get("revision_id"),
        },
    )
