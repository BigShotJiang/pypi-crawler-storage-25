"""Workflow composition helpers for Workflow Studio."""

from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from typing import Any

from obra.config.loaders import (
    load_workspace_layer,
    save_workspace_layer,
)
from obra.config.loaders._core import (
    _get_pipeline_project_overlay_entries,
    _set_pipeline_project_overlay_entries,
)
from obra.gateway.workflow_studio.local_workflow_store import LocalWorkflowStore
from obra.workflow.runner_catalog import (
    RUNNER_CATALOG_API_VERSION,
    RunnerActivation,
    RunnerCatalogEntry,
    RunnerCompatibility,
    RunnerKind,
    RunnerPortability,
    RunnerScope,
    RunnerSource,
    RunnerSourceType,
)

COMPOSITE_RUNNER_ID_PREFIX = "composite."


class CompositionConflictError(ValueError):
    """Raised when a composition request would create an invalid workflow graph."""

    def __init__(self, error_code: str, message: str) -> None:
        super().__init__(message)
        self.error_code = error_code


def bind_child_workflow(
    store: LocalWorkflowStore,
    workflow_id: str,
    stage_id: str,
    child_workflow_id: str,
    project_id: str,
    revision_id: str | None = None,
) -> dict[str, Any]:
    """Bind a child workflow as the stage runner for one parent stage."""
    parent_workflow = store.get_workflow_head(workflow_id)
    if parent_workflow is None:
        raise ValueError(f"Workflow not found: {workflow_id}")
    child_workflow = store.get_workflow_head(child_workflow_id)
    if child_workflow is None:
        raise ValueError(f"Workflow not found: {child_workflow_id}")
    if workflow_id == child_workflow_id:
        raise CompositionConflictError(
            "composition_cycle_detected",
            "A workflow cannot bind itself as a child workflow runner.",
        )
    if workflow_id in collect_workflow_runner_chain(store, child_workflow_id):
        raise CompositionConflictError(
            "composition_cycle_detected",
            f"Binding {child_workflow_id} into {workflow_id} would create a workflow_runner cycle.",
        )

    _persist_project_overlay_runner(project_id, child_workflow, revision_id=revision_id)
    updated_workflow = _patch_stage_runner_reference(
        parent_workflow,
        stage_id=stage_id,
        child_workflow_id=child_workflow_id,
        revision_id=revision_id,
    )
    previous_revision_id = str(
        parent_workflow.get("head_revision_id") or parent_workflow.get("revision_id") or ""
    ).strip()
    resulting_revision_id = datetime.now(UTC).isoformat()
    stored = store.apply_workflow_revision(
        workflow_id,
        resulting_revision_id,
        updated_workflow,
        expected_revision_id=previous_revision_id or None,
    )
    stage = _find_stage(stored, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")
    return {
        "stage": stage,
        "resulting_revision_ref": {
            "workflow_id": workflow_id,
            "revision_id": str(stored.get("revision_id") or resulting_revision_id),
        },
        "workflow": stored,
    }


def filter_bindable_workflows(
    workflows: list[dict[str, Any]],
    exclude_workflow_id: str | None,
    store: LocalWorkflowStore | None,
) -> list[dict[str, Any]]:
    """Filter workflow summaries down to legal child-workflow bind targets."""
    excluded_ids = {str(exclude_workflow_id or "").strip()} if exclude_workflow_id else set()
    if exclude_workflow_id and store is not None:
        excluded_ids.update(collect_workflow_runner_chain(store, exclude_workflow_id))

    filtered: list[dict[str, Any]] = []
    for workflow in workflows:
        workflow_id = str(workflow.get("workflow_id") or "").strip()
        if not workflow_id or workflow_id in excluded_ids:
            continue
        definition = _workflow_definition(workflow)
        stages = definition.get("stages") if isinstance(definition, dict) else []
        input_document = (
            definition.get("input_document") if isinstance(definition.get("input_document"), dict) else {}
        )
        output_document = (
            definition.get("output_document") if isinstance(definition.get("output_document"), dict) else {}
        )
        enriched = dict(workflow)
        enriched["stage_count"] = len(stages) if isinstance(stages, list) else int(
            workflow.get("stage_count") or 0
        )
        if isinstance(input_document, dict):
            enriched["input_format"] = input_document.get("format")
        if isinstance(output_document, dict):
            enriched["output_format"] = output_document.get("format")
        filtered.append(enriched)
    return filtered


def build_composition_diagnostics(
    workflow: dict[str, Any],
    store: LocalWorkflowStore,
) -> list[dict[str, Any]]:
    """Build warn-severity workflow_runner contract diagnostics for one workflow."""
    diagnostics: list[dict[str, Any]] = []
    definition = _workflow_definition(workflow)
    stages = definition.get("stages") if isinstance(definition, dict) else []
    if not isinstance(stages, list):
        return diagnostics
    for stage in stages:
        if not isinstance(stage, dict):
            continue
        child_workflow_id = extract_child_workflow_id(stage)
        if not child_workflow_id:
            continue
        child_workflow = store.get_workflow_head(child_workflow_id)
        if child_workflow is None:
            continue
        child_definition = _workflow_definition(child_workflow)
        child_input_document = child_definition.get("input_document")
        child_input_format = (
            str(child_input_document.get("format") or "").strip()
            if isinstance(child_input_document, dict)
            else ""
        )
        parent_expected_format = _resolve_parent_stage_expected_format(stage)
        if not child_input_format or not parent_expected_format or child_input_format == parent_expected_format:
            continue
        diagnostics.append(
            {
                "severity": "warn",
                "code": "composite_contract_mismatch",
                "stage_id": str(stage.get("id") or "").strip() or None,
                "message": (
                    f"Child workflow '{child_workflow_id}' expects input format "
                    f"'{child_input_format}', but stage '{stage.get('title') or stage.get('id') or 'stage'}' "
                    f"expects '{parent_expected_format}'."
                ),
            }
        )
    return diagnostics


def merge_composition_diagnostics(
    workflow: dict[str, Any],
    diagnostics: list[dict[str, Any]],
) -> dict[str, Any]:
    """Attach composition diagnostics into validation_summary.issues."""
    if not diagnostics:
        return workflow
    merged = dict(workflow)
    validation_summary = (
        dict(merged.get("validation_summary"))
        if isinstance(merged.get("validation_summary"), dict)
        else {}
    )
    issues = [
        dict(issue)
        for issue in validation_summary.get("issues", [])
        if isinstance(issue, dict)
    ]
    existing = {
        (
            str(issue.get("code") or ""),
            str(issue.get("stage_id") or ""),
            str(issue.get("message") or ""),
        )
        for issue in issues
    }
    for diagnostic in diagnostics:
        key = (
            str(diagnostic.get("code") or ""),
            str(diagnostic.get("stage_id") or ""),
            str(diagnostic.get("message") or ""),
        )
        if key in existing:
            continue
        issues.append(dict(diagnostic))
    blocking_issue_count = sum(
        1 for issue in issues if str(issue.get("severity") or "").strip().lower() == "fail"
    )
    validation_summary["issues"] = issues
    validation_summary["blocking_issue_count"] = blocking_issue_count
    validation_summary["advisory_issue_count"] = max(len(issues) - blocking_issue_count, 0)
    merged["validation_summary"] = validation_summary
    return merged


def collect_workflow_runner_chain(
    store: LocalWorkflowStore,
    workflow_id: str,
) -> set[str]:
    """Collect descendant workflow IDs reachable through workflow_runner stages."""
    normalized_root = str(workflow_id or "").strip()
    visited: set[str] = set()
    pending = [normalized_root]
    while pending:
        current_workflow_id = pending.pop()
        if not current_workflow_id or current_workflow_id in visited:
            continue
        visited.add(current_workflow_id)
        workflow = store.get_workflow_head(current_workflow_id)
        if workflow is None:
            continue
        definition = _workflow_definition(workflow)
        stages = definition.get("stages") if isinstance(definition, dict) else []
        if not isinstance(stages, list):
            continue
        for stage in stages:
            if not isinstance(stage, dict):
                continue
            child_workflow_id = extract_child_workflow_id(stage)
            if child_workflow_id and child_workflow_id not in visited:
                pending.append(child_workflow_id)
    visited.discard(normalized_root)
    return visited


def extract_child_workflow_id(stage: dict[str, Any]) -> str | None:
    """Resolve a child workflow id from one stage runner reference."""
    runner = stage.get("runner")
    if not isinstance(runner, dict):
        return None
    runner_id = str(runner.get("runner_id") or runner.get("id") or "").strip()
    if runner_id.startswith(COMPOSITE_RUNNER_ID_PREFIX):
        normalized = runner_id.removeprefix(COMPOSITE_RUNNER_ID_PREFIX).strip()
        return normalized or None
    runner_config = runner.get("runner_config")
    if isinstance(runner_config, dict):
        workflow_id = str(runner_config.get("workflow_id") or "").strip()
        if workflow_id:
            return workflow_id
    return None


def _persist_project_overlay_runner(
    project_id: str,
    child_workflow: dict[str, Any],
    *,
    revision_id: str | None,
) -> None:
    project_config, _warnings, _exists = load_workspace_layer(project_id)
    entries = list(_get_pipeline_project_overlay_entries(project_config) or [])
    child_workflow_id = str(child_workflow.get("workflow_id") or "").strip()
    entry = RunnerCatalogEntry(
        id=f"{COMPOSITE_RUNNER_ID_PREFIX}{child_workflow_id}",
        display_name=str(child_workflow.get("title") or child_workflow_id).strip() or child_workflow_id,
        kind=RunnerKind.WORKFLOW_RUNNER,
        version="1",
        scope=RunnerScope.SHARED,
        domain_ids=(),
        portability=RunnerPortability.LOCAL_ONLY,
        compatibility=RunnerCompatibility(catalog_api_version=RUNNER_CATALOG_API_VERSION),
        source=RunnerSource(source_type=RunnerSourceType.PROJECT_OVERLAY),
        activation=RunnerActivation(
            workflow_id=child_workflow_id,
            revision_id=str(revision_id or "").strip() or None,
        ),
        description=str(child_workflow.get("description") or "").strip() or None,
        tags=("workflow_runner", "composite"),
    )
    updated_entries = [
        existing
        for existing in entries
        if not (
            isinstance(existing, dict)
            and str(existing.get("id") or "").strip() == entry.id
        )
    ]
    updated_entries.append(entry.to_dict())
    _set_pipeline_project_overlay_entries(project_config, updated_entries)
    save_workspace_layer(project_id, project_config)


def _patch_stage_runner_reference(
    workflow: dict[str, Any],
    *,
    stage_id: str,
    child_workflow_id: str,
    revision_id: str | None,
) -> dict[str, Any]:
    updated = deepcopy(workflow)
    definition = _workflow_definition(updated)
    stages = definition.get("stages")
    if not isinstance(stages, list):
        raise ValueError(f"Stage not found: {stage_id}")
    matched = False
    for stage in stages:
        if not isinstance(stage, dict) or str(stage.get("id") or "").strip() != stage_id:
            continue
        matched = True
        stage["runner"] = {
            "runner_id": f"{COMPOSITE_RUNNER_ID_PREFIX}{child_workflow_id}",
            "runner_config": {
                "timeout_s": 900,
                "workflow_id": child_workflow_id,
                **({"revision_id": revision_id} if revision_id else {}),
            },
        }
        break
    if not matched:
        raise ValueError(f"Stage not found: {stage_id}")
    updated["workflow_definition"] = definition
    updated["updated_at"] = datetime.now(UTC).isoformat()
    return updated


def _find_stage(workflow: dict[str, Any], stage_id: str) -> dict[str, Any] | None:
    definition = _workflow_definition(workflow)
    stages = definition.get("stages") if isinstance(definition, dict) else []
    if not isinstance(stages, list):
        return None
    for stage in stages:
        if isinstance(stage, dict) and str(stage.get("id") or "").strip() == stage_id:
            return deepcopy(stage)
    return None


def _workflow_definition(workflow: dict[str, Any]) -> dict[str, Any]:
    definition = workflow.get("workflow_definition")
    return dict(definition) if isinstance(definition, dict) else {}


def _resolve_parent_stage_expected_format(stage: dict[str, Any]) -> str | None:
    candidates: list[Any] = [
        stage.get("expected_input_format"),
        stage.get("input_format"),
        stage.get("output_format"),
    ]
    lifecycle = stage.get("lifecycle")
    if isinstance(lifecycle, dict):
        candidates.extend(
            [
                lifecycle.get("expected_input_format"),
                lifecycle.get("input_format"),
                lifecycle.get("output_format"),
            ]
        )
        input_document = lifecycle.get("input_document")
        if isinstance(input_document, dict):
            candidates.append(input_document.get("format"))
        output_document = lifecycle.get("output_document")
        if isinstance(output_document, dict):
            candidates.append(output_document.get("format"))
    for candidate in candidates:
        normalized = str(candidate or "").strip()
        if normalized:
            return normalized
    return None
