"""Runtime and local-environment config getters."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults
from ._helpers import _coerce_bool

logger = logging.getLogger(__name__)

_SPIKE_RIGOR_MODES = ("light", "balanced", "thorough")

__all__ = [
    "get_api_base_url",
    "get_benchmark_dockerhub_username",
    "get_benchmark_eval_harness_dir",
    "get_benchmark_remediation_config",
    "get_benchmark_repo_root",
    "get_benchmark_workspace_directory",
    "get_cli_cleanup_runtime_log_config",
    "get_heartbeat_initial_delay",
    "get_heartbeat_interval",
    "get_local_emulator_api_url",
    "get_projects_default_directory",
    "get_runtime_platform_config",
    "get_spike_first_config",
    "get_workspace_context_config",
    "get_template_retention_settings",
    "is_local_mode",
]


def get_local_emulator_api_url() -> str:
    """Get local emulator API base URL from the current emulator project id."""
    project_id = os.environ.get(
        "OBRA_FIREBASE_EMULATOR_PROJECT_ID",
        _defaults.LOCAL_EMULATOR_PROJECT_ID,
    )
    return f"http://localhost:5001/{project_id.rstrip('/')}/us-central1"


def get_api_base_url() -> str:
    """Get API base URL with environment variable override support.

    Resolution order:
    1. OBRA_API_BASE_URL environment variable
    2. api_base_url from config file
    3. DEFAULT_API_BASE_URL constant

    Returns:
        API base URL string
    """
    env_url = os.environ.get("OBRA_API_BASE_URL")
    if env_url:
        return env_url.rstrip("/")

    config, _, _ = _core.load_layered_config()
    config_url = config.get("api_base_url")
    if isinstance(config_url, str):
        return config_url.rstrip("/")

    return _defaults.DEFAULT_API_BASE_URL


def is_local_mode() -> bool:
    """Check if local emulator mode is currently enabled.

    Returns:
        True if the API base URL is set to the local emulator URL
    """
    return get_api_base_url() == get_local_emulator_api_url()


def get_template_retention_settings() -> tuple[bool, bool]:
    """Get template edit retention settings.

    Resolution order:
    1. orchestration.template_retention.keep_on_success from config file
    2. orchestration.template_retention.keep_on_error from config file
    3. DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS/ERROR constants

    Returns:
        Tuple of (keep_on_success, keep_on_error)
    """
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    keep_on_success = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_SUCCESS
    keep_on_error = _defaults.DEFAULT_TEMPLATE_RETAIN_ON_ERROR
    if isinstance(orch_config, dict):
        template_config = orch_config.get("template_retention", {})
        if isinstance(template_config, dict):
            if template_config.get("keep_on_success") is not None:
                keep_on_success = bool(template_config.get("keep_on_success"))
            if template_config.get("keep_on_error") is not None:
                keep_on_error = bool(template_config.get("keep_on_error"))

    return (keep_on_success, keep_on_error)


def get_heartbeat_interval() -> int:
    """Get heartbeat interval in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INTERVAL environment variable
    2. orchestration.progress.heartbeat_interval_s from config file
    3. Default 60 seconds

    Returns:
        Heartbeat interval in seconds
    """
    env_interval = os.environ.get("OBRA_HEARTBEAT_INTERVAL")
    if env_interval:
        try:
            value = int(env_interval)
            if value > 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INTERVAL must be > 0 (got %s)", env_interval)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            interval = progress_config.get("heartbeat_interval_s")
            if interval is not None:
                value = int(interval)
                if value > 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_interval_s must be > 0 (got %s)",
                    interval,
                )

    return 60


def get_heartbeat_initial_delay() -> int:
    """Get heartbeat initial delay in seconds.

    Resolution order:
    1. OBRA_HEARTBEAT_INITIAL_DELAY environment variable
    2. orchestration.progress.heartbeat_initial_delay_s from config file
    3. Default 30 seconds

    Returns:
        Heartbeat initial delay in seconds
    """
    env_delay = os.environ.get("OBRA_HEARTBEAT_INITIAL_DELAY")
    if env_delay:
        try:
            value = int(env_delay)
            if value >= 0:
                return value
            logger.warning("OBRA_HEARTBEAT_INITIAL_DELAY must be >= 0 (got %s)", env_delay)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {})
    if isinstance(orch_config, dict):
        progress_config = orch_config.get("progress", {})
        if isinstance(progress_config, dict):
            delay = progress_config.get("heartbeat_initial_delay_s")
            if delay is not None:
                value = int(delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.progress.heartbeat_initial_delay_s must be >= 0 (got %s)",
                    delay,
                )

    return 30
def get_benchmark_workspace_directory() -> Path:
    """Get the benchmark workspace root with env override support."""

    env_value = os.environ.get("OBRA_BENCHMARK_WORKSPACE_DIRECTORY")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("workspace_directory")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: benchmark.workspace_directory")


def get_benchmark_eval_harness_dir() -> Path:
    """Get the SWE-bench Pro eval harness root with env override support."""

    env_value = os.environ.get("OBRA_BENCHMARK_EVAL_HARNESS_DIR")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("eval_harness_dir")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: benchmark.eval_harness_dir")


def get_benchmark_dockerhub_username() -> str:
    """Get the SWE-bench Pro Docker Hub namespace with env override support."""

    env_value = os.environ.get("OBRA_BENCHMARK_DOCKERHUB_USERNAME")
    if env_value and env_value.strip():
        return env_value.strip()

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("dockerhub_username")
        if isinstance(value, str) and value.strip():
            return value.strip()

    raise RuntimeError("Missing required config key: benchmark.dockerhub_username")


def get_benchmark_repo_root() -> Path:
    """Get the protected Obra repo root used by benchmark path guards."""

    env_value = os.environ.get("OBRA_BENCHMARK_REPO_ROOT")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if isinstance(benchmark_config, dict):
        value = benchmark_config.get("repo_root")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: benchmark.repo_root")


def get_benchmark_remediation_config() -> dict[str, Any]:
    """Get benchmark remediation defaults with environment overrides."""

    config, _, _ = _core.load_layered_config(include_defaults=True)
    benchmark_config = config.get("benchmark", {})
    if not isinstance(benchmark_config, dict):
        raise RuntimeError("Missing required config key: benchmark")
    remediation = benchmark_config.get("remediation")
    if not isinstance(remediation, dict):
        raise RuntimeError("Missing required config key: benchmark.remediation")

    result_root_directory = remediation.get("result_root_directory")
    repair_workspace_directory = remediation.get("repair_workspace_directory")
    default_workspace_mode = remediation.get("default_workspace_mode")
    default_checkout_python = remediation.get("default_checkout_python")
    progress_poll_interval_s = remediation.get("progress_poll_interval_s")
    if not isinstance(result_root_directory, str) or not result_root_directory.strip():
        raise RuntimeError("Missing required config key: benchmark.remediation.result_root_directory")
    if (
        not isinstance(repair_workspace_directory, str)
        or not repair_workspace_directory.strip()
    ):
        raise RuntimeError(
            "Missing required config key: benchmark.remediation.repair_workspace_directory"
        )
    if not isinstance(default_workspace_mode, str) or not default_workspace_mode.strip():
        raise RuntimeError("Missing required config key: benchmark.remediation.default_workspace_mode")
    if not isinstance(default_checkout_python, str) or not default_checkout_python.strip():
        raise RuntimeError("Missing required config key: benchmark.remediation.default_checkout_python")
    if progress_poll_interval_s is None:
        raise RuntimeError(
            "Missing required config key: benchmark.remediation.progress_poll_interval_s"
        )

    env_result_root = os.environ.get("OBRA_BENCHMARK_REMEDIATION_RESULT_ROOT_DIRECTORY")
    env_repair_root = os.environ.get("OBRA_BENCHMARK_REMEDIATION_REPAIR_WORKSPACE_DIRECTORY")
    env_python = os.environ.get("OBRA_BENCHMARK_REMEDIATION_CHECKOUT_PYTHON")
    env_progress_poll_interval = os.environ.get(
        "OBRA_BENCHMARK_REMEDIATION_PROGRESS_POLL_INTERVAL_S"
    )

    return {
        "result_root_directory": str(
            Path(env_result_root).expanduser().resolve(strict=False)
            if env_result_root and env_result_root.strip()
            else Path(result_root_directory).expanduser().resolve(strict=False)
        ),
        "repair_workspace_directory": str(
            Path(env_repair_root).expanduser().resolve(strict=False)
            if env_repair_root and env_repair_root.strip()
            else Path(repair_workspace_directory).expanduser().resolve(strict=False)
        ),
        "default_workspace_mode": default_workspace_mode.strip(),
        "default_checkout_python": (
            env_python.strip()
            if env_python and env_python.strip()
            else default_checkout_python.strip()
        ),
        "progress_poll_interval_s": float(
            env_progress_poll_interval.strip()
            if env_progress_poll_interval and env_progress_poll_interval.strip()
            else progress_poll_interval_s
        ),
        "max_attempts": int(remediation.get("max_attempts")),
        "max_planning_rounds": int(remediation.get("max_planning_rounds")),
        "max_patch_attempts": int(remediation.get("max_patch_attempts")),
        "max_no_improvement_attempts": int(remediation.get("max_no_improvement_attempts")),
        "worker_timeout_s": int(remediation.get("worker_timeout_s")),
    }


def get_projects_default_directory() -> Path:
    """Get the default directory for Obra-managed projects."""

    env_value = os.environ.get("OBRA_PROJECTS_DEFAULT_DIRECTORY")
    if env_value and env_value.strip():
        return Path(env_value).expanduser().resolve(strict=False)

    config, _, _ = _core.load_layered_config(include_defaults=True)
    projects = config.get("projects", {})
    if isinstance(projects, dict):
        value = projects.get("default_directory")
        if isinstance(value, str) and value.strip():
            return Path(value).expanduser().resolve(strict=False)

    raise RuntimeError("Missing required config key: projects.default_directory")


def get_cli_cleanup_runtime_log_config() -> dict[str, int]:
    """Get runtime log cleanup thresholds for the universal cleanup command."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    cli = config.get("cli", {})
    cleanup = cli.get("cleanup", {}) if isinstance(cli, dict) else {}

    max_size_raw = os.environ.get("OBRA_CLI_CLEANUP_RUNTIME_LOG_MAX_SIZE_BYTES") or (
        cleanup.get("runtime_log_max_size_bytes") if isinstance(cleanup, dict) else None
    )
    backup_count_raw = os.environ.get("OBRA_CLI_CLEANUP_RUNTIME_LOG_BACKUP_COUNT") or (
        cleanup.get("runtime_log_backup_count") if isinstance(cleanup, dict) else None
    )

    if max_size_raw is None:
        raise RuntimeError("Missing required config key: cli.cleanup.runtime_log_max_size_bytes")
    if backup_count_raw is None:
        raise RuntimeError("Missing required config key: cli.cleanup.runtime_log_backup_count")

    max_size = int(max_size_raw)
    backup_count = int(backup_count_raw)
    if max_size <= 0:
        raise RuntimeError("cli.cleanup.runtime_log_max_size_bytes must be > 0")
    if backup_count <= 0:
        raise RuntimeError("cli.cleanup.runtime_log_backup_count must be > 0")
    return {
        "runtime_log_max_size_bytes": max_size,
        "runtime_log_backup_count": backup_count,
    }


def get_runtime_platform_config() -> dict[str, int]:
    """Get runtime platform compatibility settings with env override support."""
    env_value = os.environ.get("OBRA_RUNTIME_PLATFORM_FD_SOFT_LIMIT_MINIMUM")
    if env_value is not None:
        minimum = int(env_value)
    else:
        config, _, _ = _core.load_layered_config(include_defaults=True)
        runtime = config.get("runtime", {})
        platform_config = runtime.get("platform", {}) if isinstance(runtime, dict) else {}
        if "fd_soft_limit_minimum" not in platform_config:
            raise RuntimeError(
                "Missing required config key: runtime.platform.fd_soft_limit_minimum"
            )
        minimum = int(platform_config["fd_soft_limit_minimum"])

    if minimum <= 0:
        raise RuntimeError("runtime.platform.fd_soft_limit_minimum must be > 0")
    return {"fd_soft_limit_minimum": minimum}


def get_spike_first_config() -> dict[str, Any]:
    """Get spike-first execution config with env-backed enabled override."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    orchestration = config.get("orchestration", {})
    if not isinstance(orchestration, dict):
        raise ConfigurationError("orchestration section not found in config")

    spike_first = orchestration.get("spike_first", {})
    return _normalize_spike_first_config(spike_first)


def get_workspace_context_config() -> dict[str, Any]:
    """Get workspace-context management config with env override support."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    workspace = config.get("workspace", {})
    if not isinstance(workspace, dict):
        raise ConfigurationError("workspace section not found in config")

    context = workspace.get("context", {})
    return _normalize_workspace_context_config(context)


def _resolve_spike_bool(
    *,
    env_key: str,
    raw_value: Any,
    default: bool,
    label: str,
    config_path: str,
) -> bool:
    """Resolve a spike-first boolean from env first, then raw config value."""
    raw_env = os.environ.get(env_key)
    if raw_env is not None:
        try:
            return _coerce_bool(raw_env)
        except ConfigurationError as exc:
            raise ConfigurationError(f"{label} {config_path} is invalid: {raw_env!r}") from exc

    if raw_value is None:
        return default

    try:
        return _coerce_bool(raw_value)
    except ConfigurationError as exc:
        raise ConfigurationError(f"{label} {config_path} is invalid: {raw_value!r}") from exc


def _normalize_spike_first_config(
    spike_first: dict[str, Any],
    *,
    fallback: dict[str, Any] | None = None,
    force_enabled: bool | None = None,
    force_pre_derive_enabled: bool | None = None,
) -> dict[str, Any]:
    """Normalize a spike-first config dict with env overrides and umbrella gating."""
    if not isinstance(spike_first, dict):
        raise ConfigurationError("orchestration.spike_first must be a dictionary")

    effective: dict[str, Any] = {}
    if isinstance(fallback, dict):
        effective.update(fallback)
    effective.update(spike_first)

    max_spikes = effective.get("max_spikes", {})
    if not isinstance(max_spikes, dict):
        raise ConfigurationError("orchestration.spike_first.max_spikes must be a dictionary")
    grounding_extractor = effective.get("grounding_extractor", {})
    if grounding_extractor is None:
        grounding_extractor = {}
    if not isinstance(grounding_extractor, dict):
        raise ConfigurationError(
            "orchestration.spike_first.grounding_extractor must be a dictionary"
        )

    if force_enabled is None:
        enabled = _resolve_spike_bool(
            env_key="OBRA_SPIKE_FIRST_ENABLED",
            raw_value=effective.get("enabled"),
            default=True,
            label="Spike-first setting",
            config_path="orchestration.spike_first.enabled",
        )
    else:
        enabled = bool(force_enabled)

    if force_pre_derive_enabled is None:
        raw_pre_derive_enabled = _resolve_spike_bool(
            env_key="OBRA_SPIKE_PRE_DERIVE_ENABLED",
            raw_value=effective.get("pre_derive_enabled"),
            default=True,
            label="Pre-derive spike setting",
            config_path="orchestration.spike_first.pre_derive_enabled",
        )
    else:
        raw_pre_derive_enabled = bool(force_pre_derive_enabled)

    per_story_enabled = _resolve_spike_bool(
        env_key="OBRA_SPIKE_PER_STORY_ENABLED",
        raw_value=effective.get("per_story_enabled"),
        default=True,
        label="Per-story spike setting",
        config_path="orchestration.spike_first.per_story_enabled",
    )

    executor_timeout = effective.get("executor_timeout_s")
    evaluator_timeout = effective.get("evaluator_timeout_s")
    per_story_timeout = effective.get("per_story_timeout_s")
    per_story_skip_on_rigor = effective.get("per_story_skip_on_rigor")
    if executor_timeout is None:
        raise ConfigurationError("orchestration.spike_first.executor_timeout_s is required")
    if evaluator_timeout is None:
        raise ConfigurationError("orchestration.spike_first.evaluator_timeout_s is required")
    if per_story_timeout is None:
        raise ConfigurationError("orchestration.spike_first.per_story_timeout_s is required")
    if per_story_skip_on_rigor is None:
        raise ConfigurationError("orchestration.spike_first.per_story_skip_on_rigor is required")
    if not isinstance(per_story_skip_on_rigor, list):
        raise ConfigurationError("orchestration.spike_first.per_story_skip_on_rigor must be a list")

    normalized_max_spikes: dict[str, int] = {}
    for rigor_mode in _SPIKE_RIGOR_MODES:
        raw_value = max_spikes.get(rigor_mode)
        if raw_value is None:
            raise ConfigurationError(
                f"orchestration.spike_first.max_spikes.{rigor_mode} is required"
            )
        try:
            normalized_max_spikes[rigor_mode] = int(raw_value)
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(
                f"orchestration.spike_first.max_spikes.{rigor_mode} must be an integer"
            ) from exc

    normalized_per_story_skip_on_rigor: list[str] = []
    for raw_value in per_story_skip_on_rigor:
        normalized = str(raw_value or "").strip().lower()
        if not normalized:
            continue
        if normalized not in _SPIKE_RIGOR_MODES:
            allowed = ", ".join(_SPIKE_RIGOR_MODES)
            raise ConfigurationError(
                "orchestration.spike_first.per_story_skip_on_rigor contains unsupported "
                f"value '{normalized}' (expected one of: {allowed})"
            )
        if normalized not in normalized_per_story_skip_on_rigor:
            normalized_per_story_skip_on_rigor.append(normalized)

    exclude_dirs = effective.get("exclude_dirs")
    if exclude_dirs is not None and not isinstance(exclude_dirs, list):
        raise ConfigurationError("orchestration.spike_first.exclude_dirs must be a list")
    exclude_files = effective.get("exclude_files")
    if exclude_files is not None and not isinstance(exclude_files, list):
        raise ConfigurationError("orchestration.spike_first.exclude_files must be a list")

    try:
        grounding_extractor_enabled = _coerce_bool(grounding_extractor.get("enabled", True))
    except ConfigurationError as exc:
        raise ConfigurationError(
            "orchestration.spike_first.grounding_extractor.enabled is invalid"
        ) from exc
    try:
        grounding_extractor_timeout = int(grounding_extractor.get("timeout_s", 600))
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            "orchestration.spike_first.grounding_extractor.timeout_s must be an integer"
        ) from exc
    if grounding_extractor_timeout < 600:
        raise ConfigurationError(
            "orchestration.spike_first.grounding_extractor.timeout_s must be >= 600"
        )
    grounding_extractor_tier = str(grounding_extractor.get("tier", "fast")).strip().lower()
    if grounding_extractor_tier not in {"fast", "medium", "high"}:
        raise ConfigurationError(
            "orchestration.spike_first.grounding_extractor.tier contains unsupported "
            f"value '{grounding_extractor_tier}' (expected one of: fast, medium, high)"
        )

    return {
        **effective,
        "enabled": enabled,
        "pre_derive_enabled": bool(enabled and raw_pre_derive_enabled),
        "max_spikes": normalized_max_spikes,
        "executor_timeout_s": int(executor_timeout),
        "evaluator_timeout_s": int(evaluator_timeout),
        "grounding_extractor": {
            "enabled": grounding_extractor_enabled,
            "timeout_s": grounding_extractor_timeout,
            "tier": grounding_extractor_tier,
        },
        "per_story_enabled": bool(enabled and per_story_enabled),
        "per_story_timeout_s": int(per_story_timeout),
        "per_story_skip_on_rigor": normalized_per_story_skip_on_rigor,
        "exclude_dirs": [str(value) for value in exclude_dirs] if isinstance(exclude_dirs, list) else [],
        "exclude_files": [str(value) for value in exclude_files] if isinstance(exclude_files, list) else [],
    }


def _normalize_workspace_context_config(workspace_context: dict[str, Any]) -> dict[str, Any]:
    """Normalize workspace-context config with env override support."""
    if not isinstance(workspace_context, dict):
        raise ConfigurationError("workspace.context must be a dictionary")

    enabled = _resolve_spike_bool(
        env_key="OBRA_WORKSPACE_CONTEXT_ENABLED",
        raw_value=workspace_context.get("enabled"),
        default=True,
        label="Workspace context setting",
        config_path="workspace.context.enabled",
    )

    raw_mode = os.environ.get("OBRA_WORKSPACE_CONTEXT_MODE", workspace_context.get("mode", "managed"))
    mode = str(raw_mode or "managed").strip().lower()
    if mode not in {"managed", "passthrough"}:
        raise ConfigurationError(
            "workspace.context.mode must be 'managed' or 'passthrough' "
            f"(got {raw_mode!r})"
        )

    auto_import = _resolve_spike_bool(
        env_key="OBRA_WORKSPACE_CONTEXT_AUTO_IMPORT",
        raw_value=workspace_context.get("auto_import"),
        default=False,
        label="Workspace context setting",
        config_path="workspace.context.auto_import",
    )

    return {
        "enabled": enabled,
        "mode": mode,
        "auto_import": bool(enabled and auto_import),
    }
