#  Copyright (c) 2019. Tobias Kurze

import json

from ocpy.model.server import Server


class Organization:
    def __init__(  # noqa: PLR0913
        self,
        orga_id: str,
        name: str,
        servers: list[dict] | dict,
        admin_role: str,
        anonymous_role: str,
        properties: dict,
    ) -> None:
        self.id = orga_id
        self.name = name
        self.servers = servers
        self.admin_role = admin_role
        self.anonymous_role = anonymous_role
        self.properties = properties

    def __str__(self) -> str:
        return json.dumps(
            {
                "id": self.id,
                "name": self.name,
                "servers": self.servers,
                "adminRole": self.admin_role,
                "anonymousRole": self.anonymous_role,
                "properties": self.properties,
            },
        )

    def __repr__(self) -> str:
        return self.__str__()

    def get_id(self) -> str:
        return self.id

    def get_name(self) -> str:
        return self.name

    def get_servers(self) -> list[Server]:
        print(self.servers)
        if isinstance(self.servers, dict):
            return [Server(**self.servers["server"])]
        return [Server(**s["server"]) for s in self.servers]

    def get_admin_role(self) -> str:
        return self.admin_role

    def get_anonymous_role(self) -> str:
        return self.anonymous_role

    def get_properties(self) -> dict:
        return self.properties
