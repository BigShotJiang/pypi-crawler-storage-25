#  Copyright (c) 2019. Tobias Kurze

import json
from typing import Literal, overload

from ocpy.utils import camel_case_to_snake_case


class EventMetadataItem:
    def __init__(  # noqa: PLR0913
        self,
        identifier: str,
        label: str,
        required: bool,
        read_only: bool,
        type: str,  # noqa: A002
        value: str | int,
    ):
        self.id = identifier
        self.label = label
        self.read_only = read_only
        self.required = required
        self.type = type
        self.value = value

    def __str__(self):
        obj = self.get_as_dict()
        return json.dumps(obj, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_as_dict(self):
        return {
            "id": self.id,
            "label": self.label,
            "readOnly": self.read_only,
            "required": self.required,
            "type": self.type,
            "value": self.value,
        }


class EventMetadata:
    def __init__(
        self,
        metadata_item: EventMetadataItem | list[EventMetadataItem],
        flavor: str = "dublincore/episode",
        title: str = "EVENTS.EVENTS.DETAILS.CATALOG.EPISODE",
    ):
        self.flavor = flavor
        self.title = title
        self.meta_data_items: list[EventMetadataItem] = []
        self.add_metadata_item(metadata_item)

    def __str__(self):
        obj = self.get_metadata_as_dict(compact=False)
        return json.dumps(obj, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_metadata_as_dict(self, compact: bool = True):
        if compact:
            return {i.id: i.value for i in self.meta_data_items}
        return {
            "fields": self.meta_data_items,
            "flavor": self.flavor,
            "title": self.title,
        }

    def add_metadata_item(
        self,
        metadata_item: EventMetadataItem | list[EventMetadataItem],
    ):
        if isinstance(metadata_item, list):
            for i in metadata_item:
                if isinstance(i, dict):
                    self.meta_data_items.append(
                        EventMetadataItem(**self.rename_event_metadata_keys(i)),
                    )
        else:
            if isinstance(metadata_item, dict):
                metadata_item = EventMetadataItem(
                    **self.rename_event_metadata_keys(metadata_item),
                )
            self.meta_data_items.append(metadata_item)

    @staticmethod
    def rename_event_metadata_keys(metadata_dict: dict):
        """
        Converts keys specified in camelCase form to snake_case form.
        :param metadata_dict:
        :return:
        """
        for key in metadata_dict:
            metadata_dict[camel_case_to_snake_case(key)] = metadata_dict.pop(key)
        return metadata_dict


class PublicationMetadata:
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_id(self):
        return self.data["id"]

    def get_checksum(self):
        return self.data["checksum"]

    def get_flavor(self):
        return self.data["flavor"]

    def get_mediatype(self):
        return self.data["mediatype"]

    def get_size(self):
        return self.data["size"]

    def get_tags(self):
        return self.data["tags"]

    def get_url(self):
        return self.data["url"]


class Media:
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_id(self):
        return self.data["id"]

    def get_checksum(self):
        return self.data["checksum"]

    def get_bitrate(self):
        return self.data["bitrate"]

    def get_duration(self):
        return self.data["duration"]

    def get_description(self):
        return self.data["description"]

    def get_flavor(self):
        return self.data["flavor"]

    def get_framecount(self):
        return self.data["framecount"]

    def get_framerate(self):
        return self.data["framerate"]

    def has_audio(self):
        return self.data["has_audio"]

    def has_video(self):
        return self.data["has_video"]

    def get_height(self):
        return self.data["height"]

    def get_mediatype(self):
        return self.data["mediatype"]

    def get_size(self):
        return self.data["size"]

    def get_tags(self):
        return self.data["tags"]

    def get_url(self):
        return self.data["url"]

    def get_width(self):
        return self.data["width"]


class Attachment:
    def __init__(self, data):
        self.data = data

    def __str__(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_checksum(self):
        return self.data["checksum"]

    def get_flavor(self):
        return self.data["flavor"]

    def get_id(self):
        return self.data["id"]

    def get_mediatype(self):
        return self.data["mediatype"]

    def get_ref(self):
        return self.data["ref"]

    def get_size(self):
        return self.data["size"]

    def get_tags(self):
        return self.data["tags"]

    def get_url(self):
        return self.data["url"]


class Publication:
    def __init__(self, user, password, url, data):
        self.base_url = url
        self.user = user
        self.password = password
        self.data = data

    def __str__(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_attachments(self, raw=False):
        if raw:
            return self.data["attachments"]
        return [Attachment(a) for a in self.data["attachments"]]

    def get_attachments_presentation_segment_preview(self) -> list[Attachment]:
        return [
            a
            for a in self.get_attachments()
            if a.get_flavor() == "presentation/segment+preview"
        ]

    def get_attachments_presentation_timeline_preview(self) -> list[Attachment]:
        return [
            a
            for a in self.get_attachments()
            if a.get_flavor() == "presentation/timeline+preview"
        ]

    def get_attachments_presentation_search_preview(self) -> list[Attachment]:
        return [
            a
            for a in self.get_attachments()
            if a.get_flavor() == "presentation/search+preview"
        ]

    def get_attachments_presenter_player_preview(self) -> list[Attachment]:
        return [
            a
            for a in self.get_attachments()
            if a.get_flavor() == "presenter/player+preview"
        ]

    def get_channel(self):
        return self.data["channel"]

    def get_id(self):
        return self.data["id"]

    def get_media(self, raw=False) -> list[Media]:
        if raw:
            return self.data["media"]
        return [Media(m) for m in self.data["media"]]

    def get_presentation_delivery_media(self) -> Media | None:
        media = self.get_media()
        for m in media:
            if m.get_flavor() == "presentation/delivery":
                return m
        return None

    def get_mediatype(self):
        return self.data["mediatype"]

    @overload
    def get_metadata(self, raw: Literal[True]) -> list[dict]: ...

    @overload
    def get_metadata(
        self,
        raw: Literal[False] = False,
    ) -> list[PublicationMetadata]: ...

    def get_metadata(
        self,
        raw: bool = False,
    ) -> list[PublicationMetadata] | list[dict]:
        if raw:
            return self.data["metadata"]
        return [PublicationMetadata(m) for m in self.data["metadata"]]

    def get_metadata_dc_episode(self) -> PublicationMetadata | None:
        for m in self.get_metadata(raw=False):
            if m.get_flavor() == "dublincore/episode":
                return m
        return None

    def get_metadata_dc_series(self) -> PublicationMetadata | None:
        for m in self.get_metadata():
            if m.get_flavor() == "dublincore/series":
                return m
        return None

    def get_metadata_mpeg7_text(self) -> PublicationMetadata | None:
        for m in self.get_metadata():
            if m.get_flavor() == "mpeg-7/text":
                return m
        return None

    def get_url(self):
        return self.data["url"]
