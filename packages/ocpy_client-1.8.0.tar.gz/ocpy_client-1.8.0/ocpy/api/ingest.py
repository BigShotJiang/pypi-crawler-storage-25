#!/usr/bin/env python3
import os
import tempfile
import xml
import xml.etree.ElementTree as ElemTree
import xml.parsers.expat

from loguru import logger
from requests import Request, Session
from requests.auth import HTTPBasicAuth, HTTPDigestAuth

from ocpy import OcPyError
from ocpy.api.api_client import (
    OpenCastApiService,
    OpenCastBaseApiClient,
    OpenCastDigestBaseApiClient,
)
from ocpy.model.mediapackage import MediaPackage
from ocpy.utils import create_acl_xml


class IngestApi(OpenCastApiService, OpenCastBaseApiClient, OpenCastDigestBaseApiClient):
    def __init__(  # noqa: PLR0913
        self,
        service_url,
        user=None,
        password=None,
        digest_user=None,
        digest_password=None,
        use_digest_auth=False,
        **_kwargs,
    ):
        OpenCastApiService.__init__(self, service_url)
        OpenCastBaseApiClient.__init__(self, user, password)
        OpenCastDigestBaseApiClient.__init__(
            self,
            digest_user,
            digest_password,
            optional=True,
        )
        self.use_digest_auth = use_digest_auth

        self.session = Session()
        if self.use_digest_auth:
            if not (self.digest_user and self.digest_password):
                raise OcPyError(
                    "Digest auth:, but no digest_user or digest_password set!",
                )
            self.session.auth = HTTPDigestAuth(self.digest_user, self.digest_password)
            self.session.headers.update({"X-Requested-Auth": "Digest"})
        else:
            self.session.auth = HTTPBasicAuth(self.user, self.password)

    def create_empty_media_package(self, **kwargs) -> MediaPackage:
        url = self.base_url + "/createMediaPackage"
        res = self.session.get(url, **kwargs)
        if res.ok:
            try:
                return MediaPackage(res.text)
            except xml.parsers.expat.ExpatError as exc:
                raise OcPyError(
                    "No valid XML response (probably authentication failure)!",
                ) from exc
        raise OcPyError(
            f"Could not create empty media_package! ({res.status_code})",
        )

    def add_attachment(
        self,
        media_package: MediaPackage,
        flavor: str,
        file: str,
        **kwargs,
    ):
        url = self.base_url + "/addAttachment"
        data = {"flavor": flavor, "mediaPackage": media_package.get_xml()}

        with open(os.path.expanduser(file), "rb") as f:
            files = {"file": f}
            request = Request(method="POST", url=url, data=data, files=files, **kwargs)
            res = self.session.send(self.session.prepare_request(request))
            print(res.url)
            if res.ok:
                return MediaPackage(res.content)
            print(res.content)
            print(res.status_code)
            raise Exception("Could not add attachment!")

    def add_track(
        self,
        media_package: MediaPackage,
        flavor: str = "presentation/source",
        file: str | None = None,
        url: str | None = None,
    ):
        logger.info("adding track")
        res = None
        if (file is None and url is None) or (file is not None and url is not None):
            raise ValueError("exactly one of file and url has to be specified!")
        track_url = self.base_url + "/addTrack"
        if url is not None:
            data = {
                "url": url,
                "flavor": flavor,
                "mediaPackage": media_package.get_xml(),
            }
            request = Request(
                method="POST",
                url=track_url,
                data=data,
            )
            res = self.session.send(self.session.prepare_request(request))
        elif file is not None:
            with open(os.path.expanduser(file), "rb") as f:
                files = {"file": f}

                data = {"flavor": flavor, "mediaPackage": media_package.get_xml()}
                request = Request(
                    method="POST",
                    url=track_url,
                    data=data,
                    files=files,
                )
                res = self.session.send(self.session.prepare_request(request))

        if res:
            logger.debug(res.url)
            if res.ok:
                return MediaPackage(res.content)
            logger.debug(res.content)
            logger.debug(res.status_code)
        raise OcPyError("Could not add track!")

    def add_media_package(
        self,
        files: str | list[str] | list[tuple[str, str]],
        workflow_id: str = "",
        **kwargs,
    ):
        """
        :param files:
        :param workflow_id:
        :param kwargs:
        :return:
        """
        if "title" not in kwargs:
            raise ValueError("Title must be specified!")
        url = self.base_url + "/addMediaPackage"
        if not workflow_id:
            url += "/" + workflow_id
        form_data = [(k, (None, kwargs[k])) for k in kwargs]
        if isinstance(files, str):
            files = [files]
        if len(files) == 1 and isinstance(files[0], str):
            form_data.append(("flavor", (None, "presentation/source")))
            form_data.append(("file", (None, open(files[0], "rb"))))  # noqa: SIM115
        else:
            for file in files:
                if not isinstance(file, tuple):
                    raise ValueError(
                        "files must be a list of tuples in the form: (flavor, file)",
                    )
                form_data.append(("flavor", (None, file[0])))
                form_data.append(("file", (None, open(file[1], "rb"))))  # noqa: SIM115

        for k, v in kwargs.items():
            form_data.append((k, v))

        request = Request(
            method="POST",
            url=url,
            files=form_data,
        )
        res = self.session.send(self.session.prepare_request(request))
        if res.ok:
            return res.text
        logger.critical("Could not add media package to Opencast!")
        logger.critical("Status code: " + str(res.status_code))
        print(request.url)
        print(request.headers)

        raise OcPyError("Could not add media package to Opencast!")

    def add_dc_catalog(
        self,
        media_package: MediaPackage,
        dublin_core_xml: str,
        flavor="dublincore/episode",
    ):
        url = self.base_url + "/addDCCatalog"
        data = {"mediaPackage": media_package.get_xml(), "dublinCore": dublin_core_xml}
        if flavor is not None:
            data["flavor"] = flavor

        request = Request(
            method="POST",
            url=url,
            data=data,
        )
        res = self.session.send(self.session.prepare_request(request))
        if res.ok:
            return MediaPackage(res.content)
        logger.critical("Could not add dc catalog")
        logger.critical("Status code: " + str(res.status_code))
        raise OcPyError("Could not add dc catalog!")

    def add_metadata(  # noqa: PLR0913
        # ruff: noqa: N803, A002
        self,
        media_package: MediaPackage,
        flavor="dublincore/episode",
        root_element_name="dublincore",
        abstract: str = "",
        accessRights: str = "",
        available: str = "",
        contributor: str = "",
        coverage: str = "",
        created: str = "",
        creator: str = "",
        date: str = "",
        description: str = "",
        extent: str = "",
        format: str = "",
        identifier: str = "",
        isPartOf: str = "",
        isReferencedBy: str = "",
        isReplacedBy: str = "",
        language: str = "",
        license: str = "",
        publisher: str = "",
        relation: str = "",
        replaces: str = "",
        rights: str = "",
        rightsHolder: str = "",
        source: str = "",
        spatial: str = "",
        subject: str = "",
        temporal: str = "",
        title: str = "",
        type: str = "",
        **kwargs,
    ):
        """

        :param media_package:
        :param flavor:
        :param abstract:
        :param accessRights:
        :param available:
        :param contributor:
        :param coverage:
        :param created:
        :param creator:
        :param date:
        :param description:
        :param extent: length of media file (in ISO8601 format) can perhaps left empty
        :param format:
        :param identifier:
        :param isPartOf:
        :param isReferencedBy:
        :param isReplacedBy:
        :param language:
        :param license:
        :param publisher:
        :param relation:
        :param replaces:
        :param rights:
        :param rightsHolder:
        :param source:
        :param spatial:
        :param subject:
        :param temporal:
        :param title:
        :param type:
        :return:
        """

        # TODO: implement other metadata fields
        logger.debug(
            f"following fields not yet implemented: {abstract}, {accessRights}, "
            f"{available}, {contributor}, {coverage}, {created}, {creator}, {date}, "
            f"{description}, {extent}, {format}, {identifier}, {isPartOf}, "
            f"{isReferencedBy}, {isReplacedBy}, {language}, {license}, "
            f"{publisher}, {relation}, {replaces}, {rights}, {rightsHolder}, "
            f"{source}, {spatial}, {subject}, {temporal}, {title}, {type}",
        )

        root = ElemTree.Element(root_element_name)
        root.set("xmlns", "http://www.opencastproject.org/xsd/1.0/dublincore/")
        root.set("xmlns:dcterms", "http://purl.org/dc/terms/")
        root.set("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        if title:
            ElemTree.SubElement(root, "dcterms:title").text = title
        if description:
            ElemTree.SubElement(root, "dcterms:description").text = description
        if isPartOf:
            ElemTree.SubElement(root, "dcterms:isPartOf").text = isPartOf
        if source:
            ElemTree.SubElement(root, "dcterms:source").text = source
        if creator:
            ElemTree.SubElement(root, "dcterms:creator").text = creator
        if spatial:
            ElemTree.SubElement(root, "dcterms:spatial").text = spatial
        if rightsHolder:
            ElemTree.SubElement(root, "dcterms:rightsHolder").text = rightsHolder
        if temporal:
            ElemTree.SubElement(root, "dcterms:temporal").set(
                "xsi:type",
                "dcterms:Period",
            )
            ElemTree.SubElement(root, "dcterms:temporal").text = temporal

        _temporal_str = "start={start}; end={end}; scheme=W3C-DTF;"

        # ruff: noqa: E501
        _ = r"""
         $start_end_string_iso = (new ilDateTime(
            strtotime($this->metadata->getField('startDate')->getValue() . ' ' . $this->metadata->getField('startTime')->getValue()),
            IL_CAL_UNIX)
        )->get(IL_CAL_FKT_DATE, 'Y-m-d\TH:i:s.u\Z');
        $xml_writer->xmlElement('dcterms:temporal', [
            'xsi:type' => 'dcterms:Period'
        ], 'start=' . $start_end_string_iso . '; ' . 'end=' . $start_end_string_iso . '; scheme=W3C-DTF;');
        """

        # ElemTree.SubElement(root, 'dcterms:created').text = created
        _ = r"""
        $xml_writer->xmlElement(
            'dcterms:created',
            [],
            (new ilDateTime(time(), IL_CAL_UNIX))
                ->get(IL_CAL_FKT_DATE, 'Y-m-d\TH:i:s.u\Z', 'UTC')
        );
        """

        for k, v in kwargs.items():
            ElemTree.SubElement(root, f"dcterms:{k}").text = v

        dublin_core_xml = ElemTree.tostring(root, method="xml").decode()

        return self.add_dc_catalog(
            media_package,
            dublin_core_xml=dublin_core_xml,
            flavor=flavor,
        )

    def ingest(
        self,
        media_package: MediaPackage,
        workflow_definition_id: str,
        workflow_instance_id: str = "",
        # workflow_parameters: List[str] = [],
        **kwargs,
    ):
        url = self.base_url + "/ingest"
        if not workflow_instance_id:
            url += "/" + workflow_definition_id
            data = {**kwargs, "mediaPackage": media_package.get_xml()}
        else:
            data = {
                **kwargs,
                "mediaPackage": media_package.get_xml(),
                "workflowDefinitionId": workflow_definition_id,
                "workflowInstanceId": workflow_instance_id,
            }

        request = Request(method="POST", url=url, data=data)
        res = self.session.send(self.session.prepare_request(request))

        print(res.url)
        if res.ok:
            return res.content
        print(res.content)
        print(res.status_code)
        raise Exception("Could not ingest media package!")

    def add_acl_attachment(
        self,
        media_package: MediaPackage,
        event_id: str,
        role_right_tuples: list[tuple[str, str]],
        **_kwargs,
    ):
        flavor = "security/xacml+episode"
        _ = """
         $plupload = new Plupload();
        $tmp_name = uniqid('tmp');
        file_put_contents($plupload->getTargetDir() . '/' . $tmp_name, (new ACLtoXML($event->getAcl()))->getXML());
        $upload_file = new xoctUploadFile();
        $upload_file->setFileSize(filesize($plupload->getTargetDir() . '/' . $tmp_name));
        $upload_file->setPostVar('attachment');
        $upload_file->setTitle('attachment');
        $upload_file->setTmpName($tmp_name);
        return $upload_file;
        :return:
        """

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "security-policy-episode.xml")
            create_acl_xml(event_id, role_right_tuples, output=path)

            return self.add_attachment(media_package, flavor, file=path)
