from pprint import pprint

import requests
from requests.auth import HTTPBasicAuth

from ocpy import OcPyRequestError
from ocpy.api.api_client import OpenCastBaseApiClient


class OrgApi(OpenCastBaseApiClient):
    def __init__(self, user=None, password=None, server_url=None, **_kwargs):
        super().__init__(user, password, server_url)
        self.base_url = self.server_url + "/org"

    def get_all_orgs(self, **kwargs):
        res = requests.get(
            self.base_url + "/all.json",
            auth=HTTPBasicAuth(self.user, self.password),
            timeout=kwargs.pop("timeout", 30),
            **kwargs,
        )
        if res.ok:
            return res.json()
        raise OcPyRequestError("could not get event!", response=res)

    def get_org(self, org_id: str, **kwargs):
        res = requests.get(
            self.base_url + f"/{org_id}.json",
            auth=HTTPBasicAuth(self.user, self.password),
            timeout=kwargs.pop("timeout", 30),
            **kwargs,
        )
        if res.ok:
            return res.json()
        raise OcPyRequestError("could not get event!", response=res)


def main():
    api = OrgApi()
    pprint(api.get_all_orgs())
    pprint(api.get_org("mh_default_org"))


if __name__ == "__main__":
    main()
