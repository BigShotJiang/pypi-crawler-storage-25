import json
import os

import requests
from requests.auth import HTTPBasicAuth

from ocpy import OcPyError
from ocpy.api.api_client import OpenCastBaseApiClient


class User:
    def __init__(self, user, password, url, data):
        self.base_url = url
        self.user = user
        self.password = password
        self.data = data

    def __str__(self):
        return json.dumps(self.data, sort_keys=True, indent=4, separators=(",", ": "))

    def __repr__(self):
        return self.__str__()

    def get_email(self) -> str:
        return self.data["email"]

    def get_name(self) -> str:
        return self.data["name"]

    def get_provider(self) -> str:
        return self.data["provider"]

    def get_username(self) -> str:
        return self.data["username"]

    def get_user_role(self) -> str:
        return self.data["userRole"]


class UploadApi(OpenCastBaseApiClient):
    def __init__(self, user=None, password=None, server_url=None, **_kwargs):
        super().__init__(user, password, server_url)
        self.base_url = self.server_url + "/upload"

    def get_job(self, job_id, **kwargs) -> dict:
        res = requests.get(
            self.base_url + "/" + job_id + ".json",
            auth=HTTPBasicAuth(self.user, self.password),
            timeout=int(kwargs.pop("timeout", 30)),
            **kwargs,
        )
        if res.ok:
            return res.json()
        raise OcPyError("Could not get job info!")

    def create_new_job(
        self,
        file_name: str | None = None,
        file_size: int | None = None,
        chunk_size: int | None = None,
        flavor: str | None = None,
        mediapackage: str | None = None,
        **kwargs,
    ) -> str:

        raw = {
            "filename": file_name,
            "filesize": file_size,
            "chunksize": chunk_size,
            "flavor": flavor,
            "mediapackage": mediapackage,
        }
        files: dict[str, str] = {k: str(v) for k, v in raw.items() if v is not None}

        res = requests.post(
            self.base_url + "/newjob",
            auth=HTTPBasicAuth(self.user, self.password),
            files=files,
            timeout=int(kwargs.pop("timeout", 30)),
            **kwargs,
        )
        if res.ok:
            return res.text
        print(res.content)
        raise OcPyError("Could not create new upload!")

    def append_chunk_to_job(
        self,
        job_id,
        file_data,
        chunk_number: int | None = None,
        **kwargs,
    ) -> str:
        files: dict[str, str | bytes] = {"filedata": file_data}
        if chunk_number is not None:
            files["chunknumber"] = str(chunk_number)

        res = requests.post(
            self.base_url + "/job/" + job_id,
            auth=HTTPBasicAuth(self.user, self.password),
            files=files,
            timeout=int(kwargs.pop("timeout", 30)),
            **kwargs,
        )

        if res.ok:
            return res.text
        print(res.content)
        raise OcPyError("Could not append chunk to job!")


def read_in_chunks(file_object, chunk_size=1024):
    """Lazy function (generator) to read a file piece by piece.
    Default chunk size: 1k."""
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break
        yield data


def test_file_upload():
    api = UploadApi()
    file = "/home/tobias/Downloads/lot_small_files.zip"
    print(os.path.getsize(file))
    job_id = api.create_new_job(
        file_name=os.path.basename(file),
        file_size=os.path.getsize(file),
    )
    with open(file, "rb") as f:
        for count, piece in enumerate(read_in_chunks(f)):
            print(count)
            api.append_chunk_to_job(job_id, piece)


def main():
    test_file_upload()
    api = UploadApi()
    job_id = api.create_new_job()
    print(api.append_chunk_to_job(job_id, "file_data"))


if __name__ == "__main__":
    main()
