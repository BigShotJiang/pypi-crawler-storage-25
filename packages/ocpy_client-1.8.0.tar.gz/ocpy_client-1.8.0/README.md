# OpenCastPythonClient (ocpy)

[![Build Status](https://drone.home.t-kurze.de/api/badges/tobias/OpenCastPythonClient/status.svg)](https://drone.home.t-kurze.de/tobias/OpenCastPythonClient)

Python client library to access the different APIs of OpenCast.

You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.
