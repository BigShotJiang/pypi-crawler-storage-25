# Smoketests for examples
