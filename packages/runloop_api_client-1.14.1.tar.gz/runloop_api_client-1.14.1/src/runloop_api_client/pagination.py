# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Any, List, Generic, TypeVar, Optional, cast
from typing_extensions import Protocol, override, runtime_checkable

from ._base_client import BasePage, PageInfo, BaseSyncPage, BaseAsyncPage

__all__ = [
    "SyncBlueprintsCursorIDPage",
    "AsyncBlueprintsCursorIDPage",
    "SyncDevboxesCursorIDPage",
    "AsyncDevboxesCursorIDPage",
    "SyncDiskSnapshotsCursorIDPage",
    "AsyncDiskSnapshotsCursorIDPage",
    "SyncBenchmarksCursorIDPage",
    "AsyncBenchmarksCursorIDPage",
    "SyncAgentsCursorIDPage",
    "AsyncAgentsCursorIDPage",
    "SyncAxonsCursorIDPage",
    "AsyncAxonsCursorIDPage",
    "SyncBenchmarkRunsCursorIDPage",
    "AsyncBenchmarkRunsCursorIDPage",
    "SyncScenariosCursorIDPage",
    "AsyncScenariosCursorIDPage",
    "SyncScenarioRunsCursorIDPage",
    "AsyncScenarioRunsCursorIDPage",
    "SyncScenarioScorersCursorIDPage",
    "AsyncScenarioScorersCursorIDPage",
    "SyncObjectsCursorIDPage",
    "AsyncObjectsCursorIDPage",
    "SyncNetworkPoliciesCursorIDPage",
    "AsyncNetworkPoliciesCursorIDPage",
    "SyncGatewayConfigsCursorIDPage",
    "AsyncGatewayConfigsCursorIDPage",
    "SyncMcpConfigsCursorIDPage",
    "AsyncMcpConfigsCursorIDPage",
]

_T = TypeVar("_T")


@runtime_checkable
class BlueprintsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class DevboxesCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class DiskSnapshotsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class BenchmarksCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class AgentsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class AxonsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class BenchmarkRunsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class ScenariosCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class ScenarioRunsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class ScenarioScorersCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class ObjectsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class NetworkPoliciesCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class GatewayConfigsCursorIDPageItem(Protocol):
    id: str


@runtime_checkable
class McpConfigsCursorIDPageItem(Protocol):
    id: str


class SyncBlueprintsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    blueprints: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        blueprints = self.blueprints
        if not blueprints:
            return []
        return blueprints

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        blueprints = self.blueprints
        if not blueprints:
            return None

        item = cast(Any, blueprints[-1])
        if not isinstance(item, BlueprintsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncBlueprintsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    blueprints: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        blueprints = self.blueprints
        if not blueprints:
            return []
        return blueprints

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        blueprints = self.blueprints
        if not blueprints:
            return None

        item = cast(Any, blueprints[-1])
        if not isinstance(item, BlueprintsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncDevboxesCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    devboxes: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        devboxes = self.devboxes
        if not devboxes:
            return []
        return devboxes

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        devboxes = self.devboxes
        if not devboxes:
            return None

        item = cast(Any, devboxes[-1])
        if not isinstance(item, DevboxesCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncDevboxesCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    devboxes: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        devboxes = self.devboxes
        if not devboxes:
            return []
        return devboxes

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        devboxes = self.devboxes
        if not devboxes:
            return None

        item = cast(Any, devboxes[-1])
        if not isinstance(item, DevboxesCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncDiskSnapshotsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    snapshots: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        snapshots = self.snapshots
        if not snapshots:
            return []
        return snapshots

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        snapshots = self.snapshots
        if not snapshots:
            return None

        item = cast(Any, snapshots[-1])
        if not isinstance(item, DiskSnapshotsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncDiskSnapshotsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    snapshots: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        snapshots = self.snapshots
        if not snapshots:
            return []
        return snapshots

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        snapshots = self.snapshots
        if not snapshots:
            return None

        item = cast(Any, snapshots[-1])
        if not isinstance(item, DiskSnapshotsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncBenchmarksCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    benchmarks: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        benchmarks = self.benchmarks
        if not benchmarks:
            return []
        return benchmarks

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        benchmarks = self.benchmarks
        if not benchmarks:
            return None

        item = cast(Any, benchmarks[-1])
        if not isinstance(item, BenchmarksCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncBenchmarksCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    benchmarks: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        benchmarks = self.benchmarks
        if not benchmarks:
            return []
        return benchmarks

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        benchmarks = self.benchmarks
        if not benchmarks:
            return None

        item = cast(Any, benchmarks[-1])
        if not isinstance(item, BenchmarksCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncAgentsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    agents: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        agents = self.agents
        if not agents:
            return []
        return agents

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        agents = self.agents
        if not agents:
            return None

        item = cast(Any, agents[-1])
        if not isinstance(item, AgentsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncAgentsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    agents: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        agents = self.agents
        if not agents:
            return []
        return agents

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        agents = self.agents
        if not agents:
            return None

        item = cast(Any, agents[-1])
        if not isinstance(item, AgentsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncAxonsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    axons: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        axons = self.axons
        if not axons:
            return []
        return axons

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        axons = self.axons
        if not axons:
            return None

        item = cast(Any, axons[-1])
        if not isinstance(item, AxonsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncAxonsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    axons: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        axons = self.axons
        if not axons:
            return []
        return axons

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        axons = self.axons
        if not axons:
            return None

        item = cast(Any, axons[-1])
        if not isinstance(item, AxonsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncBenchmarkRunsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    runs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        runs = self.runs
        if not runs:
            return []
        return runs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        runs = self.runs
        if not runs:
            return None

        item = cast(Any, runs[-1])
        if not isinstance(item, BenchmarkRunsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncBenchmarkRunsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    runs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        runs = self.runs
        if not runs:
            return []
        return runs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        runs = self.runs
        if not runs:
            return None

        item = cast(Any, runs[-1])
        if not isinstance(item, BenchmarkRunsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncScenariosCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    scenarios: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        scenarios = self.scenarios
        if not scenarios:
            return []
        return scenarios

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        scenarios = self.scenarios
        if not scenarios:
            return None

        item = cast(Any, scenarios[-1])
        if not isinstance(item, ScenariosCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncScenariosCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    scenarios: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        scenarios = self.scenarios
        if not scenarios:
            return []
        return scenarios

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        scenarios = self.scenarios
        if not scenarios:
            return None

        item = cast(Any, scenarios[-1])
        if not isinstance(item, ScenariosCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncScenarioRunsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    runs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        runs = self.runs
        if not runs:
            return []
        return runs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        runs = self.runs
        if not runs:
            return None

        item = cast(Any, runs[-1])
        if not isinstance(item, ScenarioRunsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncScenarioRunsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    runs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        runs = self.runs
        if not runs:
            return []
        return runs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        runs = self.runs
        if not runs:
            return None

        item = cast(Any, runs[-1])
        if not isinstance(item, ScenarioRunsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncScenarioScorersCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    scorers: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        scorers = self.scorers
        if not scorers:
            return []
        return scorers

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        scorers = self.scorers
        if not scorers:
            return None

        item = cast(Any, scorers[-1])
        if not isinstance(item, ScenarioScorersCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncScenarioScorersCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    scorers: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        scorers = self.scorers
        if not scorers:
            return []
        return scorers

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        scorers = self.scorers
        if not scorers:
            return None

        item = cast(Any, scorers[-1])
        if not isinstance(item, ScenarioScorersCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncObjectsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    objects: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        objects = self.objects
        if not objects:
            return []
        return objects

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        objects = self.objects
        if not objects:
            return None

        item = cast(Any, objects[-1])
        if not isinstance(item, ObjectsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncObjectsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    objects: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        objects = self.objects
        if not objects:
            return []
        return objects

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        objects = self.objects
        if not objects:
            return None

        item = cast(Any, objects[-1])
        if not isinstance(item, ObjectsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncNetworkPoliciesCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    network_policies: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        network_policies = self.network_policies
        if not network_policies:
            return []
        return network_policies

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        network_policies = self.network_policies
        if not network_policies:
            return None

        item = cast(Any, network_policies[-1])
        if not isinstance(item, NetworkPoliciesCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncNetworkPoliciesCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    network_policies: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        network_policies = self.network_policies
        if not network_policies:
            return []
        return network_policies

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        network_policies = self.network_policies
        if not network_policies:
            return None

        item = cast(Any, network_policies[-1])
        if not isinstance(item, NetworkPoliciesCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncGatewayConfigsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    gateway_configs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        gateway_configs = self.gateway_configs
        if not gateway_configs:
            return []
        return gateway_configs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        gateway_configs = self.gateway_configs
        if not gateway_configs:
            return None

        item = cast(Any, gateway_configs[-1])
        if not isinstance(item, GatewayConfigsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncGatewayConfigsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    gateway_configs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        gateway_configs = self.gateway_configs
        if not gateway_configs:
            return []
        return gateway_configs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        gateway_configs = self.gateway_configs
        if not gateway_configs:
            return None

        item = cast(Any, gateway_configs[-1])
        if not isinstance(item, GatewayConfigsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class SyncMcpConfigsCursorIDPage(BaseSyncPage[_T], BasePage[_T], Generic[_T]):
    mcp_configs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        mcp_configs = self.mcp_configs
        if not mcp_configs:
            return []
        return mcp_configs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        mcp_configs = self.mcp_configs
        if not mcp_configs:
            return None

        item = cast(Any, mcp_configs[-1])
        if not isinstance(item, McpConfigsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})


class AsyncMcpConfigsCursorIDPage(BaseAsyncPage[_T], BasePage[_T], Generic[_T]):
    mcp_configs: List[_T]
    has_more: Optional[bool] = None
    total_count: Optional[int] = None

    @override
    def _get_page_items(self) -> List[_T]:
        mcp_configs = self.mcp_configs
        if not mcp_configs:
            return []
        return mcp_configs

    @override
    def has_next_page(self) -> bool:
        has_more = self.has_more
        if has_more is not None and has_more is False:
            return False

        return super().has_next_page()

    @override
    def next_page_info(self) -> Optional[PageInfo]:
        mcp_configs = self.mcp_configs
        if not mcp_configs:
            return None

        item = cast(Any, mcp_configs[-1])
        if not isinstance(item, McpConfigsCursorIDPageItem) or item.id is None:  # pyright: ignore[reportUnnecessaryComparison]
            # TODO emit warning log
            return None

        return PageInfo(params={"starting_after": item.id})
