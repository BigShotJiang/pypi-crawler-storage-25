# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["ScenarioListPublicParams"]


class ScenarioListPublicParams(TypedDict, total=False):
    include_total_count: bool
    """If true (default), includes total_count in the response.

    Set to false to skip the count query for better performance on large datasets.
    """

    limit: int
    """The limit of items to return. Default is 20. Max is 5000."""

    name: str
    """Query for Scenarios with a given name."""

    starting_after: str
    """Load the next page of data starting after the item with the given ID."""
