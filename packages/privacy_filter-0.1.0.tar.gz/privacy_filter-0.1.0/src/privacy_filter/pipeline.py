from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .types import ClassifierPipeline

logger: logging.Logger = logging.getLogger(__name__)

_pipeline: ClassifierPipeline | None = None
_lock: threading.Lock = threading.Lock()


class ModelLoadError(Exception):
    """Raised when the PII detection model fails to load."""

    pass


def get_classifier(cache_dir: str | None = None) -> ClassifierPipeline:
    """Load and return the PII detection classifier pipeline.

    Uses a thread-safe singleton pattern with double-checked locking.
    First call downloads ~50MB from HuggingFace (cached after).

    Args:
        cache_dir: Optional custom directory for model cache.
                  Defaults to ~/.cache/huggingface/.

    Returns:
        A callable pipeline that accepts text and returns entity list.

    Raises:
        ModelLoadError: If the model fails to load (missing dependencies,
                       network issues, insufficient disk space, etc.).
    """
    global _pipeline
    if _pipeline is not None:
        return _pipeline

    with _lock:
        if _pipeline is not None:
            return _pipeline

        try:
            logger.info(
                "Loading privacy-filter model (this may take a moment on first run)..."
            )
            from transformers import pipeline as hf_pipeline

            kwargs: dict[str, Any] = {
                "task": "token-classification",
                "model": "openai/privacy-filter",
                "aggregation_strategy": "simple",
            }
            if cache_dir:
                kwargs["cache_dir"] = cache_dir

            _pipeline = hf_pipeline(**kwargs)
            logger.info("Privacy-filter model loaded successfully")
            return _pipeline

        except ImportError as e:
            msg = (
                "Failed to import transformers. "
                "Install with: pip install 'privacy-filter'"
            )
            logger.exception(msg)
            raise ModelLoadError(msg) from e

        except Exception as e:
            msg = f"Failed to load PII detection model: {e}"
            logger.exception(msg)
            raise ModelLoadError(msg) from e
