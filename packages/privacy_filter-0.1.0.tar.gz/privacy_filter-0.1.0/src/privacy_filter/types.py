from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, TypedDict

# Type alias for the classifier pipeline returned by get_classifier()
ClassifierPipeline = Callable[[str], list["Entity"]]


ENTITY_SHORT_NAMES: dict[str, str] = {
    "account_number": "ACCOUNT",
    "private_address": "ADDRESS",
    "private_email": "EMAIL",
    "private_person": "PERSON",
    "private_phone": "PHONE",
    "private_url": "URL",
    "private_date": "DATE",
    "secret": "SECRET",
}


class Entity(TypedDict):
    """Entity detected by the HuggingFace token-classification pipeline.

    Matches the structure returned by the openai/privacy-filter model
    when using aggregation_strategy="simple".
    """

    entity_group: str
    score: float
    word: str
    start: int
    end: int


@dataclass
class PiiStore:
    """Storage for PII placeholder mappings and per-type counters.

    The forward mapping stores placeholder → original value mappings.
    Counters track per-type placeholder numbering (e.g., EMAIL_1, EMAIL_2).
    """

    forward: dict[str, str] = field(default_factory=dict)
    counters: dict[str, int] = field(default_factory=dict)
    _pattern: re.Pattern[str] | None = field(
        default=None, repr=False, compare=False, hash=False, init=False
    )
    _pattern_keys: frozenset[str] | None = field(
        default=None, repr=False, compare=False, hash=False, init=False
    )

    def get_pattern(self) -> re.Pattern[str] | None:
        """Get cached regex pattern for unredaction.

        Compiles and caches the pattern on first call or when forward
        mappings change. Returns None if no mappings exist.
        """
        if not self.forward:
            return None

        current_keys: frozenset[str] = frozenset(self.forward.keys())
        if self._pattern is None or self._pattern_keys != current_keys:
            sorted_placeholders = sorted(self.forward.keys(), key=len, reverse=True)
            self._pattern = re.compile(
                "|".join(re.escape(p) for p in sorted_placeholders)
            )
            self._pattern_keys = current_keys

        return self._pattern
