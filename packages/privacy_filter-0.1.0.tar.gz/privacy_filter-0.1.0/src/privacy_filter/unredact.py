from __future__ import annotations

import logging

from .types import PiiStore

logger: logging.Logger = logging.getLogger(__name__)


def unredact_text(text: str, store: PiiStore) -> str:
    """Restore original PII values from placeholders in text.

    Args:
        text: Text containing placeholders like [EMAIL_1], [PERSON_2].
        store: PiiStore containing placeholder → original value mappings.

    Returns:
        Text with placeholders replaced by original values.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")
    if not isinstance(store, PiiStore):
        raise TypeError(f"store must be PiiStore, got {type(store).__name__}")

    pattern = store.get_pattern()
    if pattern is None:
        return text

    restored_count = len(store.forward)
    logger.debug("Unredacting %d placeholders from text", restored_count)

    return pattern.sub(lambda m: store.forward[m.group(0)], text)
