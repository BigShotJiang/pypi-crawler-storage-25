"""Shared utilities for message content extraction.

These utilities are shared between NanoBot and OpenAI Agents SDK integrations
to avoid code duplication when extracting text from message content.
"""

from __future__ import annotations


def extract_text_from_content(content: str | list[dict] | None) -> str:
    """Extract text from message content.

    Handles multiple formats:
    - Plain string: returned as-is
    - List of content parts (OpenAI vision format): extracts text parts only
    - None: returns empty string

    Args:
        content: Message content in various formats.

    Returns:
        Extracted text string.

    Raises:
        TypeError: If content is of an unsupported type.
    """
    if content is None:
        return ""

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        text_parts: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        return "\n".join(text_parts)

    raise TypeError(
        f"Unsupported content type: {type(content).__name__}. "
        f"Expected str, list, or None."
    )


def is_redactable_role(role: str | None) -> bool:
    """Check if a message role should have its content redacted.

    Only user and system messages should be redacted.
    Assistant/tool messages should pass through unchanged.

    Args:
        role: The message role string.

    Returns:
        True if the message content should be redacted.
    """
    return role in ("user", "system")
