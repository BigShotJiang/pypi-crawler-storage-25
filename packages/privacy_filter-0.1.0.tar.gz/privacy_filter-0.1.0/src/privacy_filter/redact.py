from __future__ import annotations

import logging

from .types import ENTITY_SHORT_NAMES, Entity, PiiStore

logger: logging.Logger = logging.getLogger(__name__)


def _merge_adjacent(entities: list[Entity], text: str) -> list[Entity]:
    """Merge adjacent entities of the same type.

    Combines touching entities with the same entity_group to handle
    tokenization splits (e.g., "John" + "Smith" -> "John Smith").
    """
    if not entities:
        return []
    sorted_entities = sorted(entities, key=lambda e: e["start"])
    result: list[Entity] = [sorted_entities[0]]

    for current in sorted_entities[1:]:
        last = result[-1]
        if (
            current["entity_group"] == last["entity_group"]
            and current["start"] <= last["end"] + 1
        ):
            score = max(last["score"], current["score"])
            word = text[last["start"] : current["end"]]
            result[-1] = {
                "entity_group": last["entity_group"],
                "score": score,
                "word": word,
                "start": last["start"],
                "end": current["end"],
            }
            continue
        result.append(current)

    return result


def _deduplicate_overlaps(entities: list[Entity]) -> list[Entity]:
    """Remove overlapping entities, keeping the higher-scoring one."""
    if not entities:
        return []
    sorted_entities = sorted(entities, key=lambda e: e["start"])
    result: list[Entity] = [sorted_entities[0]]

    for current in sorted_entities[1:]:
        last = result[-1]
        if current["start"] >= last["end"]:
            result.append(current)
            continue
        if current["score"] > last["score"]:
            result[-1] = current

    return result


def _filter_entities(
    entities: list[Entity],
    min_score: float = 0.8,
    entity_types: list[str] | None = None,
) -> list[Entity]:
    """Filter entities by score threshold and optional type whitelist."""
    return [
        e
        for e in entities
        if e["score"] >= min_score
        and (entity_types is None or e["entity_group"] in entity_types)
    ]


def _validate_redact_inputs(
    text: object,
    entities: object,
    store: object,
    min_score: object,
) -> None:
    """Validate inputs to redact_text. Raises TypeError or ValueError on invalid input."""
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")
    if not isinstance(entities, list):
        raise TypeError(f"entities must be list, got {type(entities).__name__}")
    if not isinstance(store, PiiStore):
        raise TypeError(f"store must be PiiStore, got {type(store).__name__}")
    if not isinstance(min_score, (int, float)):
        raise TypeError(f"min_score must be numeric, got {type(min_score).__name__}")
    if not 0 <= min_score <= 1:
        raise ValueError(f"min_score must be between 0 and 1, got {min_score}")

    # Validate entity structure (basic check)
    required_keys = {"entity_group", "score", "word", "start", "end"}
    for i, entity in enumerate(entities):
        if not isinstance(entity, dict):
            raise TypeError(f"entities[{i}] must be dict, got {type(entity).__name__}")
        missing = required_keys - entity.keys()
        if missing:
            raise ValueError(f"entities[{i}] missing required keys: {missing}")


def redact_text(
    text: str,
    entities: list[Entity],
    store: PiiStore,
    min_score: float = 0.8,
    entity_types: list[str] | None = None,
) -> str:
    """Redact PII entities from text, replacing them with placeholders.

    Args:
        text: Original text containing PII.
        entities: List of detected entities from the classifier.
        store: PiiStore instance to record placeholder mappings.
        min_score: Minimum confidence score (0-1) for entity inclusion.
        entity_types: Optional whitelist of entity types to redact.
                     If None, all types are considered.

    Returns:
        Text with PII replaced by placeholders like [EMAIL_1], [PERSON_2].

    Raises:
        TypeError: If inputs are of incorrect types.
        ValueError: If min_score is not between 0 and 1.
    """
    _validate_redact_inputs(text, entities, store, min_score)

    filtered = _filter_entities(entities, min_score, entity_types)
    merged = _merge_adjacent(filtered, text)
    deduped = _deduplicate_overlaps(merged)
    sorted_entities = sorted(deduped, key=lambda e: e["start"], reverse=True)

    result = text
    redacted_count = 0

    for entity in sorted_entities:
        short = ENTITY_SHORT_NAMES.get(entity["entity_group"])
        if not short:
            logger.warning(
                "Unknown entity_group '%s' - skipping redaction",
                entity["entity_group"],
            )
            continue

        prev = store.counters.get(short, 0)
        count = prev + 1
        store.counters[short] = count

        placeholder = f"[{short}_{count}]"
        store.forward[placeholder] = entity["word"]

        start = entity["start"]
        end = entity["end"]
        result = result[:start] + placeholder + result[end:]
        redacted_count += 1

    if redacted_count > 0:
        logger.debug("Redacted %d entities from text", redacted_count)

    return result
