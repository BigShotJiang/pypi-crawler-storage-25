Memman Package
