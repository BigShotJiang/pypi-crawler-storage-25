# ComplianceRow


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assignment_id** | **str** | The policy-model assignment ID. | 
**rule_type** | [**ComplianceRuleType**](ComplianceRuleType.md) | Whether this is an alert rule or attestation rule. | 
**rule** | [**ComplianceRuleSummary**](ComplianceRuleSummary.md) | The rule. | 
**model** | [**ComplianceModelSummary**](ComplianceModelSummary.md) | The assigned model. | 
**policy** | [**CompliancePolicySummary**](CompliancePolicySummary.md) | The policy. | 
**compliance_status** | [**ComplianceStatus**](ComplianceStatus.md) | Rule-level compliance status: &#39;COMPLIANT&#39; or &#39;NON_COMPLIANT&#39;. | 
**approved_by** | [**User**](User.md) |  | [optional] 
**next_due** | **datetime** |  | [optional] 
**frequency_days** | **int** |  | [optional] 
**alert** | [**ComplianceAlertSummary**](ComplianceAlertSummary.md) |  | [optional] 
**error_message** | **str** |  | [optional] 
**created_at** | **datetime** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.compliance_row import ComplianceRow

# TODO update the JSON string below
json = "{}"
# create an instance of ComplianceRow from a JSON string
compliance_row_instance = ComplianceRow.from_json(json)
# print the JSON string representation of the object
print(ComplianceRow.to_json())

# convert the object into a dict
compliance_row_dict = compliance_row_instance.to_dict()
# create an instance of ComplianceRow from a dict
compliance_row_from_dict = ComplianceRow.from_dict(compliance_row_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


