# PolicyAlertGuardrailRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_type** | **str** |  | [optional] [default to 'guardrail']
**resource_name** | [**RuleType**](RuleType.md) |  | 

## Example

```python
from arthur_client.api_bindings.models.policy_alert_guardrail_rule import PolicyAlertGuardrailRule

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAlertGuardrailRule from a JSON string
policy_alert_guardrail_rule_instance = PolicyAlertGuardrailRule.from_json(json)
# print the JSON string representation of the object
print(PolicyAlertGuardrailRule.to_json())

# convert the object into a dict
policy_alert_guardrail_rule_dict = policy_alert_guardrail_rule_instance.to_dict()
# create an instance of PolicyAlertGuardrailRule from a dict
policy_alert_guardrail_rule_from_dict = PolicyAlertGuardrailRule.from_dict(policy_alert_guardrail_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


