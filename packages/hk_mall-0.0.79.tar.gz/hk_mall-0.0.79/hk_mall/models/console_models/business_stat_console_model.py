# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-04-29 00:00:00
:LastEditTime: 2026-05-13 15:03:21
:LastEditors: CaiYouBin
:Description: 业务统计消费控制台
"""

import threading
import time
import traceback
from datetime import timedelta

from seven_cloudapp_frame.libs.common.frame_console import *
from seven_cloudapp_frame.libs.customize.seven_helper import *
from seven_cloudapp_frame.libs.common import *

from hk_mall.models.db_models.business.business_stat_log_model import *
from hk_mall.models.db_models.business.business_stat_orm_model import *
from hk_mall.models.db_models.business.business_stat_report_hour_model import *
from hk_mall.models.db_models.business.business_stat_report_day_model import *
from hk_mall.models.db_models.business.business_stat_report_week_model import *
from hk_mall.models.db_models.business.business_stat_report_month_model import *


class BusinessStatConsoleModel:
    """
    :description: 业务统计消费控制台
    """

    def __init__(self):
        """
        :description: 初始化
        :return:
        :last_editors: SunYiTan
        """
        self.db_connect_key, self.redis_config_dict = SevenHelper.get_connect_config("db_member_stat", "redis_member_stat")

    def console_business_stat_queue(self,mod_value):
        """
        :description: 启动业务统计消费队列
        :return:
        :last_editors: SunYiTan
        """
        for i in range(mod_value):
            threading.Thread(target=self._process_redis_business_stat_queue, args=[i]).start()

    def _process_redis_business_stat_queue(self, mod_value):
        """
        :description: 处理业务统计redis队列
        :param mod_value: 当前队列值
        :return:
        :last_editors: SunYiTan
        """
        print(f"{TimeHelper.get_now_format_time()} 业务统计队列{mod_value}启动")

        while True:
            try:
                time.sleep(0.1)
                heart_beat_monitor(f"_process_redis_business_stat_queue_{mod_value}")
                redis_init = SevenHelper.redis_init(config_dict=self.redis_config_dict)
                redis_stat_key = f"business_stat_queue_list:{mod_value}"
                check_redis_stat_key = f"business_stat_queue_list:check:{mod_value}"
                stat_queue_json = redis_init.rpoplpush(redis_stat_key, check_redis_stat_key)
                if not stat_queue_json:
                    time.sleep(1)
                    continue

                stat_queue_dict = {}
                try:
                    stat_queue_dict = SevenHelper.json_loads(stat_queue_json)
                    self._process_stat_queue_dict(stat_queue_dict)
                    redis_init.lrem(check_redis_stat_key, 1, stat_queue_json)
                except Exception:
                    if "Duplicate entry" not in traceback.format_exc():
                        redis_init.lpush(redis_stat_key, stat_queue_json)
                        logger_error.error(f"业务统计队列{mod_value}异常,json串:{SevenHelper.json_dumps(stat_queue_dict)},ex:{traceback.format_exc()}")
                    redis_init.lrem(check_redis_stat_key, 1, stat_queue_json)
                    continue

            except Exception:
                logger_error.error(f"业务统计队列{mod_value}异常,ex:{traceback.format_exc()}")
                time.sleep(5)

    def _process_stat_queue_dict(self, stat_queue_dict):
        """
        :description: 处理业务统计队列数据
        :param stat_queue_dict: 队列数据
        :return:
        :last_editors: SunYiTan
        """
        db_transaction = DbTransaction(db_config_dict=config.get_value(self.db_connect_key))
        business_stat_orm_model = BusinessStatOrmModel(is_auto=True)
        object_id = stat_queue_dict.get("object_id", "")
        business_stat_orm = business_stat_orm_model.get_cache_entity("((act_id=%s and module_id=%s and object_id=%s) or (act_id=0 and module_id=0 and object_id='')) and key_name=%s", params=[stat_queue_dict["act_id"], stat_queue_dict["module_id"], object_id, stat_queue_dict["key_name"]])
        if not business_stat_orm:
            return

        create_date = TimeHelper.format_time_to_datetime(stat_queue_dict["create_date"])
        create_hour_int = int(create_date.strftime("%H"))
        create_day_int = int(create_date.strftime("%Y%m%d"))
        create_month_int = int(create_date.strftime("%Y%m"))
        create_year_int = int(create_date.strftime("%Y"))
        create_week_int = int(create_date.strftime("%G%V"))
        week_start_date = create_date - timedelta(days=create_date.weekday())
        week_end_date = week_start_date + timedelta(days=6)
        week_start_day_int = int(week_start_date.strftime("%Y%m%d"))
        week_end_day_int = int(week_end_date.strftime("%Y%m%d"))

        business_stat_log_model = BusinessStatLogModel(db_transaction=db_transaction).set_sub_table(stat_queue_dict["app_id"])
        if not self._check_can_add_log(business_stat_log_model, stat_queue_dict):
            return

        business_stat_log = self._build_log(stat_queue_dict, business_stat_orm, object_id, create_date, create_hour_int, create_day_int, create_week_int, week_start_day_int, week_end_day_int, create_month_int, create_year_int)
        member_level = int(stat_queue_dict.get("member_level", 0))
        gender = int(stat_queue_dict.get("gender", 0))
        dimension = (member_level, gender)

        business_stat_report_hour_model = BusinessStatReportHourModel(db_transaction=db_transaction)
        business_stat_report_day_model = BusinessStatReportDayModel(db_transaction=db_transaction)
        business_stat_report_week_model = BusinessStatReportWeekModel(db_transaction=db_transaction)
        business_stat_report_month_model = BusinessStatReportMonthModel(db_transaction=db_transaction)
        can_add_report_hour = self._check_can_add_report(business_stat_log_model, business_stat_orm, stat_queue_dict, object_id, "create_day=%s and create_hour=%s", [create_day_int, create_hour_int])
        can_add_report_day = self._check_can_add_report(business_stat_log_model, business_stat_orm, stat_queue_dict, object_id, "create_day=%s", [create_day_int])
        can_add_report_week = self._check_can_add_report(business_stat_log_model, business_stat_orm, stat_queue_dict, object_id, "create_year=%s and create_week=%s", [create_year_int, create_week_int])
        can_add_report_month = self._check_can_add_report(business_stat_log_model, business_stat_orm, stat_queue_dict, object_id, "create_month=%s", [create_month_int])

        db_transaction.begin_transaction()
        business_stat_log_model.add_entity(business_stat_log)
        if can_add_report_hour:
            self._add_report_hour(business_stat_report_hour_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_hour_int, create_day_int, create_month_int, create_year_int, dimension)
        if can_add_report_day:
            self._add_report_day(business_stat_report_day_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_day_int, create_month_int, create_year_int, dimension)
        if can_add_report_week:
            self._add_report_week(business_stat_report_week_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_week_int, week_start_day_int, week_end_day_int, create_month_int, create_year_int, dimension)
        if can_add_report_month:
            self._add_report_month(business_stat_report_month_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_month_int, create_year_int, dimension)
        result, message = db_transaction.commit_transaction(True)
        if result == False:
            raise Exception("执行事务失败", message)

    def _check_can_add_log(self, business_stat_log_model, stat_queue_dict):
        """
        :description: 判断是否允许写入统计日志
        :param business_stat_log_model: 统计日志模型
        :param stat_queue_dict: 队列数据
        :return: 是否允许写入
        :last_editors: SunYiTan
        """
        request_id = stat_queue_dict.get("request_id", "")
        if request_id:
            business_stat_log_dict = business_stat_log_model.get_cache_dict("request_id=%s", field="id", params=[request_id])
            if business_stat_log_dict:
                return False
        return True

    def _check_can_add_report(self, business_stat_log_model, business_stat_orm, stat_queue_dict, object_id, where, params):
        """
        :description: 判断是否允许写入统计报表
        :param business_stat_log_model: 统计日志模型
        :param business_stat_orm: 统计映射
        :param stat_queue_dict: 队列数据
        :param object_id: 对象标识
        :param where: 周期条件
        :param params: 周期参数
        :return: 是否允许写入
        :last_editors: SunYiTan
        """
        # repeat_type: 0不去重，1周期内按用户去重，2全周期按用户去重
        if business_stat_orm.repeat_type not in (1, 2):
            return True

        # 全周期去重只按用户和统计对象判断，不追加小时/日/周/月等周期条件
        repeat_where = "act_id=%s and module_id=%s and orm_id=%s and user_id=%s and object_id=%s"
        repeat_params = [stat_queue_dict["act_id"], stat_queue_dict["module_id"], business_stat_orm.id, stat_queue_dict["user_id"], object_id]
        if business_stat_orm.repeat_type == 1:
            repeat_where += " and " + where
            repeat_params += params

        business_stat_log_dict = business_stat_log_model.get_cache_dict(
            repeat_where,
            field="id",
            params=repeat_params,
        )
        return not bool(business_stat_log_dict)

    def _build_log(self, stat_queue_dict, business_stat_orm, object_id, create_date, create_hour_int, create_day_int, create_week_int, week_start_day_int, week_end_day_int, create_month_int, create_year_int):
        """
        :description: 构建业务统计日志
        :param stat_queue_dict: 队列数据
        :param business_stat_orm: 统计映射
        :param object_id: 对象标识
        :param create_date: 创建时间
        :param create_hour_int: 创建小时
        :param create_day_int: 创建日期
        :param create_week_int: 创建周
        :param week_start_day_int: 周开始日期
        :param week_end_day_int: 周结束日期
        :param create_month_int: 创建月份
        :param create_year_int: 创建年份
        :return: 业务统计日志
        :last_editors: SunYiTan
        """
        business_stat_log = BusinessStatLog()
        business_stat_log.app_id = stat_queue_dict["app_id"]
        business_stat_log.act_id = stat_queue_dict["act_id"]
        business_stat_log.module_id = stat_queue_dict["module_id"]
        business_stat_log.object_id = object_id
        business_stat_log.orm_id = business_stat_orm.id
        business_stat_log.user_id = stat_queue_dict["user_id"]
        business_stat_log.open_id = stat_queue_dict.get("open_id", "")
        business_stat_log.key_name = stat_queue_dict["key_name"]
        business_stat_log.key_value = stat_queue_dict["key_value"]
        business_stat_log.request_id = stat_queue_dict.get("request_id", "")
        business_stat_log.member_level = int(stat_queue_dict.get("member_level", 0))
        business_stat_log.gender = int(stat_queue_dict.get("gender", 0))
        business_stat_log.create_hour = create_hour_int
        business_stat_log.create_day = create_day_int
        business_stat_log.create_week = create_week_int
        business_stat_log.week_start_day = week_start_day_int
        business_stat_log.week_end_day = week_end_day_int
        business_stat_log.create_month = create_month_int
        business_stat_log.create_year = create_year_int
        business_stat_log.create_date = create_date
        return business_stat_log

    def _fill_report_base(self, business_stat_report, stat_queue_dict, business_stat_orm, object_id, create_date, dimension):
        """
        :description: 填充统计报表基础字段
        :param business_stat_report: 统计报表
        :param stat_queue_dict: 队列数据
        :param business_stat_orm: 统计映射
        :param object_id: 对象标识
        :param create_date: 创建时间
        :param dimension: 维度
        :return:
        :last_editors: SunYiTan
        """
        business_stat_report.app_id = stat_queue_dict["app_id"]
        business_stat_report.act_id = stat_queue_dict["act_id"]
        business_stat_report.module_id = stat_queue_dict["module_id"]
        business_stat_report.object_id = object_id
        business_stat_report.orm_id = business_stat_orm.id
        business_stat_report.key_name = stat_queue_dict["key_name"]
        business_stat_report.key_value = stat_queue_dict["key_value"]
        business_stat_report.member_level = dimension[0]
        business_stat_report.gender = dimension[1]
        business_stat_report.create_date = create_date

    def _add_or_update_report(self, report_model, report_entity, where, where_params, key_value):
        """
        :description: 新增或累加更新统计报表
        :param report_model: 报表模型
        :param report_entity: 报表实体
        :param where: 唯一条件
        :param where_params: 唯一条件参数
        :param key_value: 本次累加值
        :return:
        :last_editors: SunYiTan
        """
        report_dict = report_model.get_dict(field="id", where=where, params=where_params)
        if report_dict:
            report_model.update_table(update_sql="key_value=key_value+%s", where=where, params=[key_value] + where_params)
        else:
            report_model.add_entity(report_entity)

    def _get_report_where(self, stat_queue_dict, object_id, dimension, extra_condition, extra_params):
        """
        :description: 获取报表唯一条件
        :param stat_queue_dict: 队列数据
        :param object_id: 对象标识
        :param dimension: 统计维度
        :param extra_condition: 粒度条件
        :param extra_params: 粒度参数
        :return: 条件和参数
        :last_editors: SunYiTan
        """
        where = "app_id=%s AND act_id=%s AND module_id=%s AND object_id=%s AND key_name=%s AND member_level=%s AND gender=%s AND " + extra_condition
        params = [stat_queue_dict["app_id"], stat_queue_dict["act_id"], stat_queue_dict["module_id"], object_id, stat_queue_dict["key_name"], dimension[0], dimension[1]]
        params.extend(extra_params)
        return where, params

    def _add_report_hour(self, business_stat_report_hour_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_hour_int, create_day_int, create_month_int, create_year_int, dimension):
        business_stat_report_hour = BusinessStatReportHour()
        self._fill_report_base(business_stat_report_hour, stat_queue_dict, business_stat_orm, object_id, create_date, dimension)
        business_stat_report_hour.create_hour = create_hour_int
        business_stat_report_hour.create_day = create_day_int
        where, params = self._get_report_where(stat_queue_dict, object_id, dimension, "create_day=%s AND create_hour=%s", [create_day_int, create_hour_int])
        self._add_or_update_report(business_stat_report_hour_model, business_stat_report_hour, where, params, stat_queue_dict["key_value"])

    def _add_report_day(self, business_stat_report_day_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_day_int, create_month_int, create_year_int, dimension):
        business_stat_report_day = BusinessStatReportDay()
        self._fill_report_base(business_stat_report_day, stat_queue_dict, business_stat_orm, object_id, create_date, dimension)
        business_stat_report_day.create_day = create_day_int
        where, params = self._get_report_where(stat_queue_dict, object_id, dimension, "create_day=%s", [create_day_int])
        self._add_or_update_report(business_stat_report_day_model, business_stat_report_day, where, params, stat_queue_dict["key_value"])

    def _add_report_week(self, business_stat_report_week_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_week_int, week_start_day_int, week_end_day_int, create_month_int, create_year_int, dimension):
        business_stat_report_week = BusinessStatReportWeek()
        self._fill_report_base(business_stat_report_week, stat_queue_dict, business_stat_orm, object_id, create_date, dimension)
        business_stat_report_week.create_week = create_week_int
        business_stat_report_week.week_start_day = week_start_day_int
        business_stat_report_week.week_end_day = week_end_day_int
        business_stat_report_week.create_year = create_year_int
        where, params = self._get_report_where(stat_queue_dict, object_id, dimension, "create_year=%s AND create_week=%s", [create_year_int, create_week_int])
        self._add_or_update_report(business_stat_report_week_model, business_stat_report_week, where, params, stat_queue_dict["key_value"])

    def _add_report_month(self, business_stat_report_month_model, stat_queue_dict, business_stat_orm, object_id, create_date, create_month_int, create_year_int, dimension):
        business_stat_report_month = BusinessStatReportMonth()
        self._fill_report_base(business_stat_report_month, stat_queue_dict, business_stat_orm, object_id, create_date, dimension)
        business_stat_report_month.create_month = create_month_int
        business_stat_report_month.create_year = create_year_int
        where, params = self._get_report_where(stat_queue_dict, object_id, dimension, "create_month=%s", [create_month_int])
        self._add_or_update_report(business_stat_report_month_model, business_stat_report_month, where, params, stat_queue_dict["key_value"])
