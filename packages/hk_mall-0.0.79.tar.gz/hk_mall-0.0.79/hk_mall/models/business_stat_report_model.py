# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-04-29 00:00:00
:LastEditTime: 2026-05-18 18:19:52
:LastEditors: SunYiTan
:Description: 业务统计上报与报表查询
"""

import calendar
import datetime
from decimal import Decimal, InvalidOperation

from seven_cloudapp_frame.libs.common import *
from seven_cloudapp_frame.libs.customize.seven_helper import *
from seven_cloudapp_frame.models.seven_model import ConditionWhere

from hk_mall.models.db_models.business.business_stat_orm_model import BusinessStatOrmModel
from hk_mall.models.db_models.business.business_stat_report_hour_model import BusinessStatReportHourModel
from hk_mall.models.db_models.business.business_stat_report_day_model import BusinessStatReportDayModel
from hk_mall.models.db_models.business.business_stat_report_week_model import BusinessStatReportWeekModel
from hk_mall.models.db_models.business.business_stat_report_month_model import BusinessStatReportMonthModel


class BusinessStatReportModel:
    """
    :description: 业务统计上报与报表查询，负责业务事件入队、后台统计卡片和曲线数据聚合
    :last_editors: SunYiTan
    """

    PERIOD_LIST = ["real", "day", "week", "month", "custom"]

    def __init__(self, context=None):
        """
        :description: 初始化业务统计上报与报表查询模型
        :param context: 请求上下文，用于数据库连接、日志链路和Redis配置
        :return:
        :last_editors: SunYiTan
        """
        self.context = context
        self.db_connect_key, self.redis_config_dict = SevenHelper.get_connect_config("db_member_stat", "redis_member_stat")

    def add_stat_report(self, app_id, user_id, open_id, stat_data, act_id=0, module_id=0, object_id="", request_id="", create_date=""):
        """
        :description: 添加业务统计上报，将统计数据转换为Redis队列消息
        :param app_id: 应用标识
        :param user_id: 用户标识，用于计算Redis分片队列
        :param open_id: open_id
        :param stat_data: 统计数据，支持[{"key":"trade_amount","value":100}]或{"trade_amount":100}
        :param act_id: 活动标识
        :param module_id: 模块标识
        :param object_id: 对象标识
        :param request_id: 请求标识，用于消费端幂等
        :param create_date: 统计发生时间
        :return: dict，success=True时data.accepted为入队数量，success=False时返回错误码和错误信息
        :last_editors: SunYiTan
        """
        if not create_date:
            create_date = TimeHelper.get_now_format_time()

        from hk_mall.libs.customize.member_base_model import MemberBaseModel
        member_info = MemberBaseModel(context=self.context).get_user_member_info(app_id, one_id=open_id, field="one_id,level_id,member_status,sex")
        member_level = 0
        gender = 0
        if member_info:
            member_level = int(member_info.get("level_id", 0) or 0)
            gender = int(member_info.get("sex", 0) or 0)

        queue_list, error_message = self._build_stat_queue_list(
            app_id=app_id,
            user_id=user_id,
            open_id=open_id,
            stat_data=stat_data,
            act_id=act_id,
            module_id=module_id,
            object_id=object_id,
            member_level=member_level,
            gender=gender,
            request_id=request_id,
            create_date=create_date,
        )
        if error_message:
            return {"success": False, "error_code": "error", "error_message": error_message}

        redis_init = SevenHelper.redis_init(config_dict=self.redis_config_dict)
        redis_init.rpush(f"business_stat_queue_list:{str(user_id % 10)}", *queue_list)
        return {"success": True, "data": {"accepted": len(queue_list)}}

    def _build_stat_queue_list(self, app_id, user_id, open_id, stat_data, act_id=0, module_id=0, object_id="", member_level=0, gender=0, request_id="", create_date=""):
        """
        :description: 构建业务统计Redis队列数据，统一list和dict两种上报格式
        :param app_id: 应用标识
        :param user_id: 用户标识
        :param open_id: open_id
        :param stat_data: 统计数据
        :param act_id: 活动标识
        :param module_id: 模块标识
        :param object_id: 对象标识
        :param member_level: 会员等级
        :param gender: 性别
        :param request_id: 请求标识
        :param create_date: 创建时间
        :return: tuple，队列JSON列表和错误信息；错误信息为空表示构建成功
        :last_editors: SunYiTan
        """
        if isinstance(stat_data, list):
            data_items = stat_data
        elif isinstance(stat_data, dict):
            data_items = [{"key": key, "value": value} for key, value in stat_data.items()]
        else:
            return [], "data参数错误"

        if len(data_items) <= 0:
            return [], "data不能为空"

        queue_list = []
        for item in data_items:
            if not isinstance(item, dict) or not item.get("key"):
                return [], "data格式错误"
            try:
                key_value = Decimal(str(item.get("value")))
            except (InvalidOperation, TypeError):
                return [], "value参数错误"

            queue_list.append(SevenHelper.json_dumps({
                "app_id": app_id,
                "act_id": act_id,
                "module_id": module_id,
                "object_id": object_id,
                "user_id": user_id,
                "open_id": open_id,
                "key_name": item.get("key"),
                "key_value": str(key_value),
                "member_level": member_level,
                "gender": gender,
                "request_id": request_id,
                "create_date": create_date,
            }))

        return queue_list, ""

    def get_card_list(self, app_id, period, member_level, gender, start_date="", end_date="", act_id=0, module_id=0, object_id="", dashboard_code="", latest_hour_key_name_list=None, extra_ratio_config_list=None, derived_ratio_config_list=None):
        """
        :description: 获取业务统计卡片列表，返回本期值、展示对比值、环比基准、同比基准和文案
        :param app_id: 应用标识
        :param period: 统计周期，real实时/day按日/week按周/month按月/custom自定义
        :param member_level: 会员等级，0全部/1-9会员等级
        :param gender: 性别，0全部/1男/2女
        :param start_date: 自定义开始日期，period=custom时必填，格式YYYY-MM-DD
        :param end_date: 自定义结束日期，period=custom时必填，格式YYYY-MM-DD
        :param act_id: 活动标识，0表示全部活动
        :param module_id: 活动模块标识，0表示全部模块
        :param object_id: 统计对象标识，空字符串表示全部对象
        :param dashboard_code: 看板编码，空字符串表示不过滤，如home/member
        :param latest_hour_key_name_list: 实时卡片本期值需要取当天最新小时的key_name列表
        :param extra_ratio_config_list: 卡片附加占比配置列表
        :param derived_ratio_config_list: 派生比例主指标配置列表
        :return: dict，success=True时data为统计卡片列表，success=False时返回错误码和错误信息
        :last_editors: SunYiTan
        """
        # 先统一校验周期和筛选参数，custom 的日期会在这里转成 datetime，后续所有区间计算都依赖这个结果。
        validate_result = self._validate_params(period, member_level, gender, start_date, end_date)
        if not validate_result["success"]:
            return validate_result

        # 计算本期、展示对比、环比基准、同比基准四套查询区间和模型；卡片接口所有值都从这里取时间口径。
        period_range = self._get_card_period_range(period, validate_result.get("start_date"), validate_result.get("end_date"))
        orm_list = self._get_orm_list(app_id, act_id, module_id, object_id, dashboard_code=dashboard_code)
        key_name_list = [orm.key_name for orm in orm_list]
        key_name_set = set(key_name_list)
        # 派生指标只在目标卡片存在时生效，例如净成交额、客单价这类卡片值需要由分子/分母临时计算。
        derived_ratio_config_dict = {}
        for config in derived_ratio_config_list or []:
            target_key_name = config.get("target_key_name")
            if target_key_name in key_name_set:
                derived_ratio_config_dict[target_key_name] = config
        # 附加占比只挂在已配置出来的目标卡片上，避免查询和返回未展示卡片的扩展占比。
        extra_ratio_config_list = self._get_effective_extra_ratio_config_list(key_name_list, extra_ratio_config_list)
        # 当前值查询不只查卡片自身 key，还要把附加占比分子/分母加入，后面 extra_ratio_list 才能直接复用同一批值。
        current_key_name_list = self._get_card_current_key_name_list(key_name_list, extra_ratio_config_list)
        # 派生卡片的 current/display/mom/yoy 都要分别计算，所以分子/分母必须加入四套 value_dict 的查询 key。
        for config in derived_ratio_config_dict.values():
            for key_name in (config.get("numerator_key_name"), config.get("denominator_key_name")):
                if key_name and key_name not in current_key_name_list:
                    current_key_name_list.append(key_name)
        if period == "real":
            # real 本期查小时表：快照类指标取当天已有数据的最新小时，流量类指标按当天已完成小时累计。
            current_value_dict = self._get_real_current_value_dict(period_range["current_model"], app_id, act_id, module_id, object_id, current_key_name_list, latest_hour_key_name_list or [], member_level, gender, period_range["current_start"], period_range["current_end"])
            display_value_dict = self._get_range_value_dict(period_range["display_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["display_start"], period_range["display_end"])
            mom_value_dict = self._get_range_value_dict(period_range["mom_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["mom_start"], period_range["mom_end"])
            yoy_value_dict = self._get_range_value_dict(period_range["yoy_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["yoy_start"], period_range["yoy_end"])
        elif period == "custom":
            # custom 可能跨多天，四套区间里的快照类指标都不能 SUM，必须分别取各自区间内小时表最新小时。
            current_value_dict = self._get_custom_card_value_dict(period_range["current_model"], app_id, act_id, module_id, object_id, current_key_name_list, latest_hour_key_name_list or [], member_level, gender, period_range["current_start"], period_range["current_end"])
            display_value_dict = self._get_custom_card_value_dict(period_range["display_model"], app_id, act_id, module_id, object_id, current_key_name_list, latest_hour_key_name_list or [], member_level, gender, period_range["display_start"], period_range["display_end"])
            mom_value_dict = self._get_custom_card_value_dict(period_range["mom_model"], app_id, act_id, module_id, object_id, current_key_name_list, latest_hour_key_name_list or [], member_level, gender, period_range["mom_start"], period_range["mom_end"])
            yoy_value_dict = self._get_custom_card_value_dict(period_range["yoy_model"], app_id, act_id, module_id, object_id, current_key_name_list, latest_hour_key_name_list or [], member_level, gender, period_range["yoy_start"], period_range["yoy_end"])
        else:
            # day/week/month 使用各自完整报表粒度，区间内通常只覆盖目标日、周、月报表，直接按范围聚合即可。
            current_value_dict = self._get_range_value_dict(period_range["current_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["current_start"], period_range["current_end"])
            display_value_dict = self._get_range_value_dict(period_range["display_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["display_start"], period_range["display_end"])
            mom_value_dict = self._get_range_value_dict(period_range["mom_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["mom_start"], period_range["mom_end"])
            yoy_value_dict = self._get_range_value_dict(period_range["yoy_model"], app_id, act_id, module_id, object_id, current_key_name_list, member_level, gender, period_range["yoy_start"], period_range["yoy_end"])

        data_list = []
        for orm in orm_list:
            # 每个 ORM 配置对应一张卡片；如果命中派生配置，卡片主值不读自身 key，而是按分子/分母临时计算。
            derived_ratio_config = derived_ratio_config_dict.get(orm.key_name)
            if derived_ratio_config:
                # 派生卡片的四套值都用同一套运算规则，保证主值和环比/同比基准口径一致。
                numerator_key_name = derived_ratio_config.get("numerator_key_name")
                denominator_key_name = derived_ratio_config.get("denominator_key_name")
                operation_type = derived_ratio_config.get("operation_type", "percent")
                current_value = self._format_value(self._get_derived_value(current_value_dict.get(numerator_key_name, Decimal("0")), current_value_dict.get(denominator_key_name, Decimal("0")), operation_type), orm.value_type)
                display_value = self._format_value(self._get_derived_value(display_value_dict.get(numerator_key_name, Decimal("0")), display_value_dict.get(denominator_key_name, Decimal("0")), operation_type), orm.value_type)
                mom_base_value = self._format_value(self._get_derived_value(mom_value_dict.get(numerator_key_name, Decimal("0")), mom_value_dict.get(denominator_key_name, Decimal("0")), operation_type), orm.value_type)
                yoy_base_value = self._format_value(self._get_derived_value(yoy_value_dict.get(numerator_key_name, Decimal("0")), yoy_value_dict.get(denominator_key_name, Decimal("0")), operation_type), orm.value_type)
            else:
                # 普通卡片直接从四套 value_dict 取自身 key；缺失数据按 0 返回，前端不需要额外兜底。
                current_value = self._format_value(current_value_dict.get(orm.key_name, Decimal("0")), orm.value_type)
                display_value = self._format_value(display_value_dict.get(orm.key_name, Decimal("0")), orm.value_type)
                mom_base_value = self._format_value(mom_value_dict.get(orm.key_name, Decimal("0")), orm.value_type)
                yoy_base_value = self._format_value(yoy_value_dict.get(orm.key_name, Decimal("0")), orm.value_type)
            # 环比/同比涨跌幅基于已经格式化后的卡片值计算，派生卡片也走同一套展示口径。
            mom_rate = self._get_rate(current_value, mom_base_value)
            yoy_rate = self._get_rate(current_value, yoy_base_value)
            # extra_ratio_list 只描述本期附加占比，如会员总数卡片的首购/复购占比，不单独返回环比/同比占比。
            data_list.append({
                "current_value": current_value,
                "display_compare_value": display_value,
                "display_compare_text": period_range["display_compare_text"],
                "mom_base_value": mom_base_value,
                "yoy_base_value": yoy_base_value,
                "mom_rate": mom_rate,
                "yoy_rate": yoy_rate,
                "mom_text": self._get_compare_text("环比", mom_base_value, mom_rate),
                "yoy_text": self._get_compare_text("同比", yoy_base_value, yoy_rate),
                "extra_ratio_list": self._build_card_extra_ratio_list(orm.key_name, current_value_dict, extra_ratio_config_list),
                "orm": self._orm_to_dict(orm)
            })

        return {"success": True, "data": data_list}

    def get_trend_list(self, app_id, period, member_level, gender, start_date="", end_date="", act_id=0, module_id=0, object_id="", orm_id=0, dashboard_code="", derived_ratio_config_list=None):
        """
        :description: 获取业务统计曲线列表，根据统计周期选择小时、日、周或月报表并补齐缺失点
        :param app_id: 应用标识
        :param period: 统计周期，real实时/day按日/week按周/month按月/custom自定义
        :param member_level: 会员等级，0全部/1-9会员等级
        :param gender: 性别，0全部/1男/2女
        :param start_date: 自定义开始日期，period=custom时必填，格式YYYY-MM-DD
        :param end_date: 自定义结束日期，period=custom时必填，格式YYYY-MM-DD
        :param act_id: 活动标识，0表示全部活动
        :param module_id: 活动模块标识，0表示全部模块
        :param object_id: 统计对象标识，空字符串表示全部对象
        :param orm_id: 统计指标标识，对应business_stat_orm_tb.id
        :param dashboard_code: 看板编码，空字符串表示不过滤，如home/member
        :param derived_ratio_config_list: 派生比例主指标配置列表
        :return: dict，success=True时data为指标曲线列表，success=False时返回错误码和错误信息
        :last_editors: SunYiTan
        """
        validate_result = self._validate_params(period, member_level, gender, start_date, end_date)
        if not validate_result["success"]:
            return validate_result
        if orm_id <= 0:
            return {"success": False, "error_code": "orm_id_error", "error_message": "统计指标不能为空"}

        trend_range = self._get_trend_range(period, validate_result.get("start_date"), validate_result.get("end_date"))
        orm_list = self._get_orm_list(app_id, act_id, module_id, object_id, orm_id=orm_id, dashboard_code=dashboard_code)
        if not orm_list:
            return {"success": False, "error_code": "orm_error", "error_message": "统计指标不存在"}
        key_name_list = [orm.key_name for orm in orm_list]
        key_name_set = set(key_name_list)
        derived_ratio_config_dict = {}
        for config in derived_ratio_config_list or []:
            target_key_name = config.get("target_key_name")
            if target_key_name in key_name_set:
                derived_ratio_config_dict[target_key_name] = config
        if period == "real":
            return {"success": True, "data": self._get_real_trend_data(app_id, act_id, module_id, object_id, orm_list, member_level, gender, derived_ratio_config_dict)}
        query_key_name_list = list(key_name_list)
        for config in derived_ratio_config_dict.values():
            for key_name in (config.get("numerator_key_name"), config.get("denominator_key_name")):
                if key_name and key_name not in query_key_name_list:
                    query_key_name_list.append(key_name)
        report_list = self._get_trend_report_list(trend_range["model"], app_id, act_id, module_id, object_id, query_key_name_list, member_level, gender, trend_range["start"], trend_range["end"], trend_range["date_field"])
        report_value_dict = {}
        for report in report_list:
            report_value_dict[(report["key_name"], report["date_text"])] = self._to_decimal(report.get("key_value", 0))

        data_list = []
        for orm in orm_list:
            value_list = []
            derived_ratio_config = derived_ratio_config_dict.get(orm.key_name)
            for point in trend_range["point_list"]:
                if derived_ratio_config:
                    numerator_key_name = derived_ratio_config.get("numerator_key_name")
                    denominator_key_name = derived_ratio_config.get("denominator_key_name")
                    operation_type = derived_ratio_config.get("operation_type", "percent")
                    value = self._get_derived_value(report_value_dict.get((numerator_key_name, point["date_text"]), Decimal("0")), report_value_dict.get((denominator_key_name, point["date_text"]), Decimal("0")), operation_type)
                else:
                    value = report_value_dict.get((orm.key_name, point["date_text"]), Decimal("0"))
                value_list.append({
                    "date": point["date_text"],
                    "title": point["title"],
                    "value": self._format_value(value, orm.value_type)
                })
            data_list.append({
                "orm": self._orm_to_dict(orm),
                "value": value_list
            })

        return {"success": True, "data": data_list}

    def _get_real_trend_data(self, app_id, act_id, module_id, object_id, orm_list, member_level, gender, derived_ratio_config_dict=None):
        """
        :description: 获取实时曲线今日和昨日小时数据
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param orm_list: 统计指标配置列表
        :param member_level: 会员等级
        :param gender: 性别
        :param derived_ratio_config_dict: 派生比例主指标配置字典
        :return: 实时曲线数据
        :last_editors: SunYiTan
        """
        now = datetime.datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday = today - datetime.timedelta(days=1)
        current_hour_start = now.replace(minute=0, second=0, microsecond=0)
        key_name_list = [orm.key_name for orm in orm_list]
        query_key_name_list = list(key_name_list)
        for config in (derived_ratio_config_dict or {}).values():
            for key_name in (config.get("numerator_key_name"), config.get("denominator_key_name")):
                if key_name and key_name not in query_key_name_list:
                    query_key_name_list.append(key_name)
        today_point_list = [{"date_text": str(hour), "title": f"{hour:02d}:00"} for hour in range(now.hour)]
        yesterday_point_list = [{"date_text": str(hour), "title": f"{hour:02d}:00"} for hour in range(24)]
        today_report_list = self._get_trend_report_list(BusinessStatReportHourModel, app_id, act_id, module_id, object_id, query_key_name_list, member_level, gender, today, current_hour_start, "hour")
        yesterday_report_list = self._get_trend_report_list(BusinessStatReportHourModel, app_id, act_id, module_id, object_id, query_key_name_list, member_level, gender, yesterday, today, "hour")
        today_value_dict = {}
        for report in today_report_list:
            today_value_dict[(report["key_name"], report["date_text"])] = self._to_decimal(report.get("key_value", 0))
        yesterday_value_dict = {}
        for report in yesterday_report_list:
            yesterday_value_dict[(report["key_name"], report["date_text"])] = self._to_decimal(report.get("key_value", 0))

        data_list = []
        for orm in orm_list:
            data_list.append(self._build_real_trend_item(orm, f"今日{orm.display_name or orm.key_value}", today_point_list, today_value_dict, derived_ratio_config_dict))
            data_list.append(self._build_real_trend_item(orm, f"昨日{orm.display_name or orm.key_value}", yesterday_point_list, yesterday_value_dict, derived_ratio_config_dict))
        return data_list

    def _build_real_trend_item(self, orm, title, point_list, value_dict, derived_ratio_config_dict=None):
        """
        :description: 构建实时曲线单条数据
        :param orm: 统计指标配置
        :param title: 曲线标题
        :param point_list: 小时点位列表
        :param value_dict: 小时值字典
        :param derived_ratio_config_dict: 派生比例主指标配置字典
        :return: 实时曲线单条数据
        :last_editors: SunYiTan
        """
        orm_dict = self._orm_to_dict(orm)
        orm_dict["title"] = title
        value_list = []
        derived_ratio_config = (derived_ratio_config_dict or {}).get(orm.key_name)
        for point in point_list:
            if derived_ratio_config:
                numerator_key_name = derived_ratio_config.get("numerator_key_name")
                denominator_key_name = derived_ratio_config.get("denominator_key_name")
                operation_type = derived_ratio_config.get("operation_type", "percent")
                value = self._get_derived_value(value_dict.get((numerator_key_name, point["date_text"]), Decimal("0")), value_dict.get((denominator_key_name, point["date_text"]), Decimal("0")), operation_type)
            else:
                value = value_dict.get((orm.key_name, point["date_text"]), Decimal("0"))
            value_list.append({
                "date": point["date_text"],
                "title": point["title"],
                "value": self._format_value(value, orm.value_type)
            })
        return {"orm": orm_dict, "value": value_list}

    def _validate_params(self, period, member_level, gender, start_date, end_date):
        """
        :description: 校验统计周期、会员等级、性别和自定义日期范围
        :param period: 统计周期，必须在PERIOD_LIST内
        :param member_level: 会员等级，0全部/1-9会员等级
        :param gender: 性别，0全部/1男/2女
        :param start_date: 自定义开始日期，period=custom时必填
        :param end_date: 自定义结束日期，period=custom时必填
        :return: dict，校验成功时返回success=True，自定义周期会附带解析后的start_date和end_date
        :last_editors: SunYiTan
        """
        if period not in self.PERIOD_LIST:
            return {"success": False, "error_code": "period_error", "error_message": "统计周期错误"}
        if member_level < 0 or member_level > 9:
            return {"success": False, "error_code": "member_level_error", "error_message": "会员等级错误"}
        if gender not in (0, 1, 2):
            return {"success": False, "error_code": "gender_error", "error_message": "性别错误"}
        if period != "custom":
            return {"success": True}
        if not start_date or not end_date:
            return {"success": False, "error_code": "date_empty", "error_message": "自定义日期不能为空"}
        try:
            start_datetime = self._parse_date(start_date)
            end_datetime = self._parse_date(end_date)
        except Exception:
            return {"success": False, "error_code": "date_error", "error_message": "日期格式错误"}
        if end_datetime < start_datetime:
            return {"success": False, "error_code": "date_error", "error_message": "结束日期不能小于开始日期"}
        if (end_datetime - start_datetime).days > 365:
            return {"success": False, "error_code": "date_limit", "error_message": "自定义日期最多查询366天"}
        return {"success": True, "start_date": start_datetime, "end_date": end_datetime}

    def _get_orm_list(self, app_id, act_id, module_id, object_id, orm_id=0, dashboard_code=""):
        """
        :description: 查询可展示的统计指标配置，优先匹配指定活动模块对象并兼容全局指标
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param orm_id: 统计指标标识，大于0时只查询指定指标
        :param dashboard_code: 看板编码，空字符串表示不过滤，如home/member
        :return: list，business_stat_orm_tb实体列表
        :last_editors: SunYiTan
        """
        where = ConditionWhere()
        params = []
        where.add_condition("is_show=1")
        where.add_condition("((act_id=%s AND module_id=%s AND object_id=%s) OR (act_id=0 AND module_id=0 AND object_id=''))")
        params.extend([act_id, module_id, object_id])
        if orm_id > 0:
            where.add_condition("id=%s")
            params.append(orm_id)
        if dashboard_code:
            where.add_condition("dashboard_code LIKE %s")
            params.append(f"%,{dashboard_code},%")
        orm_list = BusinessStatOrmModel(context=self.context, is_auto=True).get_list(
            where=where.to_string(),
            order_by="sort_index ASC",
            params=params
        )
        orm_list = sorted(
            orm_list,
            key=lambda orm: (0 if orm.act_id == act_id and orm.module_id == module_id and orm.object_id == object_id else 1, orm.sort_index)
        )
        result_list = []
        key_name_dict = {}
        for orm in orm_list:
            if orm.key_name in key_name_dict:
                continue
            key_name_dict[orm.key_name] = 1
            result_list.append(orm)
        return result_list

    def _get_card_period_range(self, period, start_date=None, end_date=None):
        """
        :description: 计算统计卡片四套时间口径，分别用于本期值、底部展示对比值、环比计算和同比计算
        :param period: 统计周期，real实时/day昨日/week上一周/month上月/custom自定义区间
        :param start_date: 自定义开始日期，仅period=custom时使用，已在_validate_params中转为datetime
        :param end_date: 自定义结束日期，仅period=custom时使用，已在_validate_params中转为datetime
        :return: dict，包含current/display/mom/yoy各自的报表模型、左闭右开时间范围和展示对比文案
        :last_editors: SunYiTan
        """
        now = datetime.datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        current_hour_start = now.replace(minute=0, second=0, microsecond=0)
        if period == "real":
            # 实时卡片本期查今天小时表；展示值和环比都对比昨天全天，同比对比上一年同日全天。
            yesterday = today - datetime.timedelta(days=1)
            last_year_day = self._add_year(yesterday, -1)
            return self._build_card_range(BusinessStatReportHourModel, today, current_hour_start, BusinessStatReportDayModel, yesterday, today, BusinessStatReportDayModel, yesterday, today, BusinessStatReportDayModel, last_year_day, last_year_day + datetime.timedelta(days=1), "昨日全天")
        if period == "day":
            # 日卡片本期查昨日；底部展示上月同日，环比基准为前一日，同比基准为上一年同日。
            yesterday = today - datetime.timedelta(days=1)
            before_yesterday = today - datetime.timedelta(days=2)
            last_month_day = self._add_month(yesterday, -1)
            last_year_day = self._add_year(yesterday, -1)
            return self._build_card_range(BusinessStatReportDayModel, yesterday, today, BusinessStatReportDayModel, last_month_day, last_month_day + datetime.timedelta(days=1), BusinessStatReportDayModel, before_yesterday, yesterday, BusinessStatReportDayModel, last_year_day, last_year_day + datetime.timedelta(days=1), "上月同日")
        if period == "week":
            # 周卡片本期查上一完整自然周；底部展示上月同周，环比基准为上上周，同比基准为上一年同周。
            current_start = today - datetime.timedelta(days=today.weekday() + 7)
            current_end = current_start + datetime.timedelta(days=7)
            display_start = self._add_month(current_start, -1)
            mom_start = current_start - datetime.timedelta(days=7)
            yoy_start = self._add_year(current_start, -1)
            return self._build_card_range(BusinessStatReportWeekModel, current_start, current_end, BusinessStatReportWeekModel, display_start, display_start + datetime.timedelta(days=7), BusinessStatReportWeekModel, mom_start, current_start, BusinessStatReportWeekModel, yoy_start, yoy_start + datetime.timedelta(days=7), "上月同周")
        if period == "month":
            # 月卡片本期查上一个完整自然月；底部展示去年同月，环比基准为上上个月，同比基准为上一年同月。
            month_start = today.replace(day=1)
            current_start = self._add_month(month_start, -1)
            mom_start = self._add_month(month_start, -2)
            yoy_start = self._add_year(current_start, -1)
            return self._build_card_range(BusinessStatReportMonthModel, current_start, month_start, BusinessStatReportMonthModel, yoy_start, self._add_month(yoy_start, 1), BusinessStatReportMonthModel, mom_start, current_start, BusinessStatReportMonthModel, yoy_start, self._add_month(yoy_start, 1), "去年同月")
        # 自定义卡片本期查用户选择区间；底部展示和同比都对比去年同期，环比基准为前一个等长区间。
        current_end = end_date + datetime.timedelta(days=1)
        day_count = (end_date - start_date).days + 1
        mom_end = start_date
        mom_start = start_date - datetime.timedelta(days=day_count)
        yoy_start = self._add_year(start_date, -1)
        yoy_end = self._add_year(current_end, -1)
        return self._build_card_range(BusinessStatReportDayModel, start_date, current_end, BusinessStatReportDayModel, yoy_start, yoy_end, BusinessStatReportDayModel, mom_start, mom_end, BusinessStatReportDayModel, yoy_start, yoy_end, "去年同期")

    def _build_card_range(self, current_model, current_start, current_end, display_model, display_start, display_end, mom_model, mom_start, mom_end, yoy_model, yoy_start, yoy_end, display_text):
        """
        :description: 组装统计卡片周期范围结构
        :param current_model: 本期查询使用的报表模型
        :param current_start: 本期开始时间，闭区间
        :param current_end: 本期结束时间，开区间
        :param display_model: 展示对比值查询使用的报表模型
        :param display_start: 展示对比期开始时间，闭区间
        :param display_end: 展示对比期结束时间，开区间
        :param mom_model: 环比基准查询使用的报表模型
        :param mom_start: 环比基准开始时间，闭区间
        :param mom_end: 环比基准结束时间，开区间
        :param yoy_model: 同比基准查询使用的报表模型
        :param yoy_start: 同比基准开始时间，闭区间
        :param yoy_end: 同比基准结束时间，开区间
        :param display_text: 展示对比文案
        :return: dict，卡片查询所需的模型、时间范围和展示文案
        :last_editors: SunYiTan
        """
        return {
            "current_model": current_model,
            "current_start": current_start,
            "current_end": current_end,
            "display_model": display_model,
            "display_start": display_start,
            "display_end": display_end,
            "mom_model": mom_model,
            "mom_start": mom_start,
            "mom_end": mom_end,
            "yoy_model": yoy_model,
            "yoy_start": yoy_start,
            "yoy_end": yoy_end,
            "display_compare_text": display_text
        }

    def _get_trend_range(self, period, start_date=None, end_date=None):
        """
        :description: 计算曲线查询使用的报表模型、时间范围、分组字段和补零点位
        :param period: 统计周期，real/day/week/month/custom
        :param start_date: 自定义开始日期，仅custom周期使用
        :param end_date: 自定义结束日期，仅custom周期使用
        :return: dict，包含model、start、end、date_field和point_list
        :last_editors: SunYiTan
        """
        now = datetime.datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        if period == "real":
            current_hour_start = now.replace(minute=0, second=0, microsecond=0)
            point_list = [{"date_text": str(hour), "title": f"{hour:02d}:00"} for hour in range(now.hour)]
            return {"model": BusinessStatReportHourModel, "start": today, "end": current_hour_start, "date_field": "hour", "point_list": point_list}
        if period == "day":
            start = today - datetime.timedelta(days=30)
            point_list = self._get_day_point_list(start, today - datetime.timedelta(days=1))
            return {"model": BusinessStatReportDayModel, "start": start, "end": today, "date_field": "day", "point_list": point_list}
        if period == "week":
            current_week_start = today - datetime.timedelta(days=today.weekday())
            start = current_week_start - datetime.timedelta(weeks=52)
            point_list = []
            for index in range(52):
                week_start = start + datetime.timedelta(weeks=index)
                point_list.append({"date_text": week_start.strftime("%Y-%m-%d"), "title": week_start.strftime("%Y-%m-%d")})
            return {"model": BusinessStatReportWeekModel, "start": start, "end": current_week_start, "date_field": "week", "point_list": point_list}
        if period == "month":
            current_month_start = today.replace(day=1)
            start = self._add_month(current_month_start, -12)
            point_list = []
            for index in range(12):
                month_start = self._add_month(start, index)
                point_list.append({"date_text": month_start.strftime("%Y-%m"), "title": month_start.strftime("%Y-%m")})
            return {"model": BusinessStatReportMonthModel, "start": start, "end": current_month_start, "date_field": "month", "point_list": point_list}
        custom_end = end_date + datetime.timedelta(days=1)
        return {"model": BusinessStatReportDayModel, "start": start_date, "end": custom_end, "date_field": "day", "point_list": self._get_day_point_list(start_date, end_date)}

    def _get_effective_extra_ratio_config_list(self, key_name_list, extra_ratio_config_list):
        """
        :description: 过滤当前卡片列表需要生效的附加占比配置
        :param key_name_list: 当前返回卡片key_name列表
        :param extra_ratio_config_list: 外层传入的附加占比配置列表
        :return: list，目标卡片存在的附加占比配置
        :last_editors: SunYiTan
        """
        key_name_set = set(key_name_list)
        return [config for config in (extra_ratio_config_list or []) if config.get("target_key_name") in key_name_set]

    def _get_card_current_key_name_list(self, key_name_list, extra_ratio_config_list):
        """
        :description: 获取卡片本期值查询key列表，包含附加占比依赖的分子和分母key
        :param key_name_list: 当前返回卡片key_name列表
        :param extra_ratio_config_list: 已过滤的附加占比配置列表
        :return: list，本期值查询key_name列表
        :last_editors: SunYiTan
        """
        result_list = []
        key_name_dict = {}
        for key_name in key_name_list:
            if key_name in key_name_dict:
                continue
            key_name_dict[key_name] = 1
            result_list.append(key_name)
        for config in extra_ratio_config_list:
            for ratio_config in config.get("ratio_list", []):
                for key_name in (ratio_config.get("numerator_key_name"), ratio_config.get("denominator_key_name")):
                    if not key_name or key_name in key_name_dict:
                        continue
                    key_name_dict[key_name] = 1
                    result_list.append(key_name)
        return result_list

    def _get_custom_card_value_dict(self, model_class, app_id, act_id, module_id, object_id, key_name_list, latest_hour_key_name_list, member_level, gender, start_date, end_date):
        """
        :description: 获取自定义周期卡片值，快照类指标取区间内最新小时，普通指标取区间累计
        :param model_class: 普通指标查询使用的报表模型类
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param key_name_list: 统计指标key_name列表
        :param latest_hour_key_name_list: 自定义周期需要取区间最新小时的key_name列表
        :param member_level: 会员等级，0表示不按会员等级过滤
        :param gender: 性别，0表示不按性别过滤
        :param start_date: 查询开始时间，闭区间
        :param end_date: 查询结束时间，开区间
        :return: dict，key为key_name，value为Decimal聚合值
        :last_editors: SunYiTan
        """
        latest_hour_key_name_set = set(latest_hour_key_name_list or [])
        custom_latest_hour_key_name_list = [key_name for key_name in key_name_list if key_name in latest_hour_key_name_set]
        custom_normal_key_name_list = [key_name for key_name in key_name_list if key_name not in latest_hour_key_name_set]
        # custom 可能跨多天，快照类指标不能按日表累加，需按各自区间内最新小时取值。
        value_dict = self._get_range_value_dict(model_class, app_id, act_id, module_id, object_id, custom_normal_key_name_list, member_level, gender, start_date, end_date)
        value_dict.update(self._get_real_current_value_dict(BusinessStatReportHourModel, app_id, act_id, module_id, object_id, custom_latest_hour_key_name_list, custom_latest_hour_key_name_list, member_level, gender, start_date, end_date))
        return value_dict

    def _get_real_current_value_dict(self, model_class, app_id, act_id, module_id, object_id, key_name_list, latest_hour_key_name_list, member_level, gender, start_date, end_date):
        """
        :description: 获取实时卡片本期值，指定指标取当天已有数据的最新小时，普通指标取当天累计
        :param model_class: 实时本期查询使用的小时报表模型类
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param key_name_list: 统计指标key_name列表
        :param latest_hour_key_name_list: 实时卡片本期值需要取当天最新小时的key_name列表
        :param member_level: 会员等级，0表示不按会员等级过滤
        :param gender: 性别，0表示不按性别过滤
        :param start_date: 实时本期开始时间，通常为当天零点
        :param end_date: 实时本期结束时间，通常为下一个整点
        :return: dict，key为key_name，value为Decimal聚合值
        :last_editors: SunYiTan
        """
        latest_hour_key_name_set = set(latest_hour_key_name_list or [])
        latest_hour_key_name_list = [key_name for key_name in key_name_list if key_name in latest_hour_key_name_set]
        normal_key_name_list = [key_name for key_name in key_name_list if key_name not in latest_hour_key_name_set]
        value_dict = self._get_range_value_dict(model_class, app_id, act_id, module_id, object_id, normal_key_name_list, member_level, gender, start_date, end_date)
        if not latest_hour_key_name_list:
            return value_dict

        where, params = self._build_report_where(app_id, act_id, module_id, object_id, latest_hour_key_name_list, member_level, gender, start_date, end_date)
        latest_hour_dict = model_class(context=self.context, is_auto=True).get_dict(where=where, params=params, field="MAX(create_date) AS create_date")
        latest_create_date = latest_hour_dict.get("create_date") if latest_hour_dict else ""
        if not latest_create_date:
            return value_dict
        if isinstance(latest_create_date, str):
            latest_create_date = datetime.datetime.strptime(latest_create_date, "%Y-%m-%d %H:%M:%S")
        latest_hour_start = latest_create_date.replace(minute=0, second=0, microsecond=0)
        latest_hour_end = latest_hour_start + datetime.timedelta(hours=1)
        value_dict.update(self._get_range_value_dict(model_class, app_id, act_id, module_id, object_id, latest_hour_key_name_list, member_level, gender, latest_hour_start, latest_hour_end))
        return value_dict

    def _get_range_value_dict(self, model_class, app_id, act_id, module_id, object_id, key_name_list, member_level, gender, start_date, end_date):
        """
        :description: 按时间范围聚合多个统计指标的卡片值
        :param model_class: 报表模型类，小时/日/周/月报表之一
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param key_name_list: 统计指标key_name列表
        :param member_level: 会员等级，0表示不按会员等级过滤
        :param gender: 性别，0表示不按性别过滤
        :param start_date: 查询开始时间，闭区间
        :param end_date: 查询结束时间，开区间
        :return: dict，key为key_name，value为Decimal聚合值
        :last_editors: SunYiTan
        """
        if not key_name_list:
            return {}
        where, params = self._build_report_where(app_id, act_id, module_id, object_id, key_name_list, member_level, gender, start_date, end_date)
        report_list = model_class(context=self.context, is_auto=True).get_dict_list(where=where, params=params, field="key_name,SUM(key_value) AS key_value", group_by="key_name")
        return {report["key_name"]: self._to_decimal(report.get("key_value", 0)) for report in report_list}

    def _get_trend_report_list(self, model_class, app_id, act_id, module_id, object_id, key_name_list, member_level, gender, start_date, end_date, date_field):
        """
        :description: 查询曲线报表数据并按曲线粒度分组聚合
        :param model_class: 报表模型类，小时/日/周/月报表之一
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param key_name_list: 统计指标key_name列表
        :param member_level: 会员等级，0表示不按会员等级过滤
        :param gender: 性别，0表示不按性别过滤
        :param start_date: 查询开始时间，闭区间
        :param end_date: 查询结束时间，开区间
        :param date_field: 曲线粒度字段，hour/day/week/month
        :return: list，包含key_name、date_text和key_value的聚合结果
        :last_editors: SunYiTan
        """
        if not key_name_list:
            return []
        where, params = self._build_report_where(app_id, act_id, module_id, object_id, key_name_list, member_level, gender, start_date, end_date)
        if date_field == "hour":
            field = "key_name,create_hour AS date_text,SUM(key_value) AS key_value"
            group_by = "key_name,create_hour"
        elif date_field == "week":
            field = "key_name,DATE_FORMAT(STR_TO_DATE(week_start_day,'%%Y%%m%%d'),'%%Y-%%m-%%d') AS date_text,SUM(key_value) AS key_value"
            group_by = "key_name,week_start_day"
        elif date_field == "month":
            field = "key_name,CONCAT(LEFT(create_month,4),'-',RIGHT(create_month,2)) AS date_text,SUM(key_value) AS key_value"
            group_by = "key_name,create_month"
        else:
            field = "key_name,DATE_FORMAT(create_date,'%%Y-%%m-%%d') AS date_text,SUM(key_value) AS key_value"
            group_by = "key_name,DATE_FORMAT(create_date,'%%Y-%%m-%%d')"
        report_list = model_class(context=self.context, is_auto=True).get_dict_list(where=where, params=params, field=field, group_by=group_by)
        for report in report_list:
            report["date_text"] = str(report.get("date_text"))
        return report_list

    def _build_report_where(self, app_id, act_id, module_id, object_id, key_name_list, member_level, gender, start_date, end_date):
        """
        :description: 构建报表查询条件和参数，member_level/gender为0时不追加对应维度筛选
        :param app_id: 应用标识
        :param act_id: 活动标识
        :param module_id: 活动模块标识
        :param object_id: 统计对象标识
        :param key_name_list: 统计指标key_name列表
        :param member_level: 会员等级，0表示聚合全部会员等级
        :param gender: 性别，0表示聚合全部性别
        :param start_date: 查询开始时间，闭区间
        :param end_date: 查询结束时间，开区间
        :return: tuple，where字符串和params参数列表
        :last_editors: SunYiTan
        """
        placeholder = ",".join(["%s" for key_name in key_name_list])
        where = ConditionWhere()
        params = []
        where.add_condition("app_id=%s AND (act_id = %s OR act_id = 0) AND module_id=%s AND object_id=%s")
        params.extend([app_id, act_id, module_id, object_id])
        if member_level:
            where.add_condition("member_level=%s")
            params.append(member_level)
        if gender:
            where.add_condition("gender=%s")
            params.append(gender)
        where.add_condition(f"key_name IN ({placeholder})")
        params.extend(key_name_list)
        where.add_condition("create_date>=%s AND create_date<%s")
        params.extend([start_date.strftime("%Y-%m-%d %H:%M:%S"), end_date.strftime("%Y-%m-%d %H:%M:%S")])
        return where.to_string(), params

    def _get_day_point_list(self, start_date, end_date):
        """
        :description: 生成按日曲线点位列表，包含起止日期并按日期升序排列
        :param start_date: 开始日期
        :param end_date: 结束日期
        :return: list，每项包含date_text和title
        :last_editors: SunYiTan
        """
        point_list = []
        day_count = (end_date - start_date).days + 1
        for index in range(day_count):
            date_day = start_date + datetime.timedelta(days=index)
            point_list.append({"date_text": date_day.strftime("%Y-%m-%d"), "title": date_day.strftime("%Y-%m-%d")})
        return point_list

    def _parse_date(self, date_text):
        """
        :description: 解析日期字符串并归一到当天零点
        :param date_text: 日期字符串，支持YYYY-MM-DD或YYYY-MM-DD HH:MM:SS
        :return: datetime，解析后的日期时间
        :last_editors: SunYiTan
        """
        if len(date_text) == 10:
            return datetime.datetime.strptime(date_text, "%Y-%m-%d")
        return datetime.datetime.strptime(date_text, "%Y-%m-%d %H:%M:%S").replace(hour=0, minute=0, second=0, microsecond=0)

    def _add_month(self, date_time, month_count):
        """
        :description: 对日期增减指定月份，目标月份天数不足时取该月最后一天
        :param date_time: 原始日期时间
        :param month_count: 增减月份数，负数表示向前推
        :return: datetime，增减月份后的日期时间
        :last_editors: SunYiTan
        """
        month = date_time.month - 1 + month_count
        year = date_time.year + month // 12
        month = month % 12 + 1
        day = min(date_time.day, calendar.monthrange(year, month)[1])
        return date_time.replace(year=year, month=month, day=day)

    def _add_year(self, date_time, year_count):
        """
        :description: 对日期增减指定年份，闰年2月29日落到非闰年时取2月28日
        :param date_time: 原始日期时间
        :param year_count: 增减年份数，负数表示向前推
        :return: datetime，增减年份后的日期时间
        :last_editors: SunYiTan
        """
        try:
            return date_time.replace(year=date_time.year + year_count)
        except ValueError:
            return date_time.replace(year=date_time.year + year_count, day=28)

    def _build_card_extra_ratio_list(self, target_key_name, value_dict, extra_ratio_config_list):
        """
        :description: 根据附加占比配置构建卡片扩展占比列表
        :param target_key_name: 当前卡片key_name
        :param value_dict: 本期值字典
        :param extra_ratio_config_list: 附加占比配置列表
        :return: list，卡片扩展占比列表
        :last_editors: SunYiTan
        """
        for config in extra_ratio_config_list:
            if config.get("target_key_name") != target_key_name:
                continue
            data_list = []
            for ratio_config in config.get("ratio_list", []):
                numerator_value = value_dict.get(ratio_config.get("numerator_key_name"), Decimal("0"))
                denominator_value = value_dict.get(ratio_config.get("denominator_key_name"), Decimal("0"))
                data_list.append({
                    "key": ratio_config.get("key", ""),
                    "title": ratio_config.get("title", ""),
                    "value": self._get_percent(numerator_value, denominator_value),
                    "unit": ratio_config.get("unit", "%"),
                    "numerator_value": self._format_value(numerator_value, ratio_config.get("numerator_value_type", "decimal")),
                    "denominator_value": self._format_value(denominator_value, ratio_config.get("denominator_value_type", "decimal"))
                })
            return data_list
        return []

    def _get_percent(self, numerator_value, denominator_value):
        """
        :description: 计算分子占分母的百分比
        :param numerator_value: 分子值
        :param denominator_value: 分母值
        :return: float，百分比值，分母为0时返回0
        :last_editors: SunYiTan
        """
        denominator_decimal = self._to_decimal(denominator_value)
        if denominator_decimal == 0:
            return 0
        return float((self._to_decimal(numerator_value) / denominator_decimal * Decimal("100")).quantize(Decimal("0.01")))

    def _get_derived_value(self, numerator_value, denominator_value, operation_type="percent"):
        """
        :description: 根据派生指标计算类型计算指标值
        :param numerator_value: 分子值
        :param denominator_value: 分母值
        :param operation_type: 计算类型，percent/subtract/divide
        :return: float或Decimal，派生指标值
        :last_editors: SunYiTan
        """
        if operation_type == "subtract":
            return self._to_decimal(numerator_value) - self._to_decimal(denominator_value)
        if operation_type == "divide":
            denominator_decimal = self._to_decimal(denominator_value)
            if denominator_decimal == 0:
                return 0
            return float((self._to_decimal(numerator_value) / denominator_decimal).quantize(Decimal("0.01")))
        return self._get_percent(numerator_value, denominator_value)

    def _get_rate(self, current_value, base_value):
        """
        :description: 计算当前值相对基准值的增长率百分比
        :param current_value: 当前值
        :param base_value: 对比基准值
        :return: float或None，base为0且current大于0时返回None，base和current均为0时返回0
        :last_editors: SunYiTan
        """
        current_decimal = self._to_decimal(current_value)
        base_decimal = self._to_decimal(base_value)
        if base_decimal == 0:
            return None if current_decimal > 0 else 0
        return float(((current_decimal - base_decimal) / base_decimal * Decimal("100")).quantize(Decimal("0.01")))

    def _get_compare_text(self, compare_name, base_value, rate):
        """
        :description: 根据对比名称、基准值和增长率生成环比或同比展示文案
        :param compare_name: 对比名称，环比或同比
        :param base_value: 对比基准值
        :param rate: 增长率百分比
        :return: str，对比展示文案
        :last_editors: SunYiTan
        """
        base_decimal = self._to_decimal(base_value)
        if base_decimal == 0 or rate is None:
            return f"{compare_name}对比期无数据"
        if rate > 0:
            return f"{compare_name}增长{abs(rate)}%"
        if rate < 0:
            return f"{compare_name}下降{abs(rate)}%"
        return f"{compare_name}持平"

    def _format_value(self, value, value_type):
        """
        :description: 根据统计指标值类型格式化返回值
        :param value: 原始数值
        :param value_type: 指标值类型，integer或int返回整数，其余返回浮点数
        :return: int或float，格式化后的数值
        :last_editors: SunYiTan
        """
        decimal_value = self._to_decimal(value)
        if value_type in ("integer", "int"):
            return int(decimal_value)
        return float(decimal_value)

    def _to_decimal(self, value):
        """
        :description: 将任意数值转换为Decimal，空值按0处理
        :param value: 待转换数值
        :return: Decimal，转换后的精确数值
        :last_editors: SunYiTan
        """
        if isinstance(value, Decimal):
            return value
        return Decimal(str(value or 0))

    def _orm_to_dict(self, orm):
        """
        :description: 将统计指标ORM实体转换为接口返回字典
        :param orm: business_stat_orm_tb实体
        :return: dict，包含指标标识、展示名称、分组、单位和排序信息
        :last_editors: SunYiTan
        """
        return {
            "id": orm.id,
            "key_name": orm.key_name,
            "app_id": orm.app_id,
            "act_id": orm.act_id,
            "module_id": orm.module_id,
            "object_id": orm.object_id,
            "group_name": orm.group_name,
            "group_sub_name": orm.group_sub_name,
            "key_value": orm.key_value,
            "title": orm.display_name or orm.key_value,
            "tip_title": orm.tip_title,
            "value_type": orm.value_type,
            "unit": orm.unit,
            "sort_index": orm.sort_index
        }
