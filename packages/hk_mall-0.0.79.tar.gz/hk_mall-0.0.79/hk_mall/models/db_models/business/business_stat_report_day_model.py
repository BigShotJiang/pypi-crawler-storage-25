# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-04-29 00:00:00
:LastEditTime: 2026-04-29 10:50:00
:LastEditors: SunYiTan
:Description: 业务日统计模型
"""

from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class BusinessStatReportDayModel(CacheModel):
    def __init__(self, db_connect_key="db_cloudapp_member", sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(BusinessStatReportDayModel, self).__init__(BusinessStatReportDay, sub_table)
        db_connect_key, self.redis_config_dict = SevenHelper.get_connect_config("db_member_stat", "redis_member_stat", db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context


class BusinessStatReportDay:

    def __init__(self):
        super(BusinessStatReportDay, self).__init__()
        self.id = 0
        self.app_id = ""
        self.act_id = 0
        self.module_id = 0
        self.object_id = ""
        self.orm_id = 0
        self.key_name = ""
        self.key_value = 0
        self.member_level = 0
        self.gender = 0
        self.create_day = 0
        self.create_date = "1900-01-01 00:00:00"

    @classmethod
    def get_field_list(self):
        return ["id", "app_id", "act_id", "module_id", "object_id", "orm_id", "key_name", "key_value", "member_level", "gender", "create_day", "create_date"]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "business_stat_report_day_tb"
