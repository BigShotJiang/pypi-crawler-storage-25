# -*- coding: utf-8 -*-
"""
:Author: SunYiTan
:Date: 2026-04-29 00:00:00
:LastEditTime: 2026-05-11 20:06:20
:LastEditors: SunYiTan
:Description: 业务统计ORM模型
"""

from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class BusinessStatOrmModel(CacheModel):
    def __init__(self, db_connect_key="db_cloudapp_member", sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(BusinessStatOrmModel, self).__init__(BusinessStatOrm, sub_table)
        db_connect_key, self.redis_config_dict = SevenHelper.get_connect_config("db_member_stat", "redis_member_stat", db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context


class BusinessStatOrm:

    def __init__(self):
        super(BusinessStatOrm, self).__init__()
        self.id = 0
        self.app_id = ""
        self.act_id = 0
        self.module_id = 0
        self.object_id = ""
        self.group_name = ""
        self.group_sub_name = ""
        self.key_name = ""
        self.key_value = ""
        self.tip_title = ""
        self.value_type = "decimal"
        self.repeat_type = 0
        self.sort_index = 0
        self.create_date = "1900-01-01 00:00:00"
        self.is_show = 0
        self.dashboard_code = ""
        self.i1 = 0
        self.i2 = 0
        self.s1 = ""
        self.s2 = ""
        self.display_name = ""
        self.unit = ""
        self.is_core = 0

    @classmethod
    def get_field_list(self):
        return ["id", "app_id", "act_id", "module_id", "object_id", "group_name", "group_sub_name", "key_name", "key_value", "tip_title", "value_type", "repeat_type", "sort_index", "create_date", "is_show", "dashboard_code", "i1", "i2", "s1", "s2", "display_name", "unit", "is_core"]

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "business_stat_orm_tb"
