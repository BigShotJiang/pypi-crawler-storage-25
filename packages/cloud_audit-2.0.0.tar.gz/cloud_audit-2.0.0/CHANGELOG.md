# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.0.0] - 2026-04-14

### Added

- **IAM Privilege Escalation Detection** - 25 escalation methods across 6 categories (IAM self-mutation, credential access, PassRole+service, Lambda code modification, trust policy abuse, permission boundary bypass). Replaces dead PMapper as the only maintained open-source IAM escalation scanner
- **What-If Remediation Simulator** - `cloud-audit simulate --fix aws-vpc-002` shows before/after impact on score, chains, and risk without changing anything in AWS
- **Security Posture Trend** - `cloud-audit trend` tracks health score, attack chains, and risk over time with sparkline visualization. Scan history auto-saved to `~/.cloud-audit/history/`
- **AI-SPM (Bedrock + SageMaker)** - 5 new checks: model invocation logging (aws-bedrock-001), guardrails (aws-bedrock-002), notebook root access (aws-sagemaker-001), notebook internet access (aws-sagemaker-002), endpoint encryption (aws-sagemaker-003)
- **Root Cause Grouping** - "fix 4 things, break 22 chains" prioritization. Groups findings by root cause and ranks by chain-breaking impact
- **Quick Wins** - CLI section showing LOW-effort fixes that break CRITICAL chains, with copy-paste commands
- **6 new attack chain rules** - AC-34 (PassRole escalation), AC-35 (IAM self-escalation), AC-36 (OIDC + escalation), AC-37 (AI model theft), AC-38 (LLMjacking), AC-39 (AI data poisoning)
- Compliance Beta labels for BSI C5, ISO 27001, HIPAA, NIS2 (CIS and SOC 2 remain Stable)
- `list-frameworks` shows Status column (Stable/Beta)

### Changed

- Remediation CLI commands now inject real AWS account ID (via `provider.get_account_id()`) instead of `ACCOUNT_ID` placeholders
- Terraform remediation snippets completed with missing dependent resources (IAM roles, S3 buckets, KMS keys, CloudWatch log groups)
- VPC flow logs Terraform scoped IAM policy to specific log group ARN (was `Resource: *`)
- `get_account_id()` cached in AWSProvider (1 STS call instead of 10+ per scan)
- Root cause computation moved after cost estimation (fixes risk aggregation)
- `get_account_id()` calls moved inside try/except in kms, iam, s3 checks

### Fixed

- Unicode characters (arrows, em-dashes, block characters) replaced with ASCII for Windows cp1250 compatibility

## [1.3.0] - 2026-04-03

### Added

- **BSI C5:2020 compliance framework** - 134 Cloud Computing Compliance Criteria mapped (20 automated, 37 partial, 77 manual), covering all 17 BSI domains (OIS, SP, HR, AM, PS, OPS, IDM, CRY, COM, PI, DEV, SIM, BCM, COS, INQ, PSS, LOG)
- **ISO/IEC 27001:2022 compliance framework** - 93 Annex A controls mapped (16 automated, 31 partial, 46 manual), covering Organizational (A.5), People (A.6), Physical (A.7), and Technological (A.8) controls
- **HIPAA Security Rule compliance framework** - 47 implementation specifications mapped (15 automated, 14 partial, 18 manual) across Administrative (§164.308), Physical (§164.310), and Technical (§164.312) safeguards
- **NIS2 Directive compliance framework** - 43 technical measures mapped (11 automated, 22 partial, 10 manual) covering Article 21(2)(a)-(j) minimum measures, Article 23 incident reporting, and Article 20 governance
- `--compliance bsi_c5_2020` CLI flag - BSI C5:2020 readiness assessment
- `--compliance iso27001_2022` CLI flag - ISO 27001:2022 Annex A readiness assessment
- `--compliance hipaa_security` CLI flag - HIPAA Security Rule readiness assessment
- `--compliance nis2_directive` CLI flag - NIS2 Directive readiness assessment
- All 20 attack chain rules mapped to controls in each new framework
- **8 new security checks** (80 -> 88 total):
  - `aws-backup-001` - AWS Backup vault with backup plan (Backup)
  - `aws-inspector-001` - Amazon Inspector v2 enabled (Inspector)
  - `aws-waf-001` - WAFv2 WebACL exists (WAF)
  - `aws-cw-016` - CloudWatch log group KMS encryption (CloudWatch)
  - `aws-ssm-003` - EC2 patch compliance via SSM (SSM)
  - `aws-vpc-006` - VPC subnet isolation (VPC)
  - `aws-iam-017` - IAM role max session duration (IAM)
  - `aws-ct-008` - CloudTrail delivers to CloudWatch Logs (CloudTrail)
- **5 new attack chain rules** (20 -> 25 total):
  - AC-29: Unpatched Instance Exposed to Internet (CRITICAL)
  - AC-30: Unpatched Instances Without Vulnerability Scanning (HIGH)
  - AC-31: Internet-Exposed Without WAF or Flow Logs (HIGH)
  - AC-32: CloudTrail Blind Spot — Alarms Non-Functional (HIGH)
  - AC-33: All-Public VPC Without Network Segmentation (HIGH)
- 3 new service modules: AWS Backup, Amazon Inspector, AWS WAF
- 67 new tests for framework validation (412 total)

### Changed

- Check count: 80 -> 88 across 21 AWS services (was 18)
- Attack chain count: 20 -> 25 rules
- `list-frameworks` now shows 6 frameworks (was 2)
- CLI help text updated with all 6 framework IDs
- pyproject.toml description updated to reflect 6 compliance frameworks
- 21 CIS controls corrected from Manual to Partial (had automated checks but wrong assessment type)

## [1.2.2] - 2026-04-01

### Added

- Parallel check execution via ThreadPoolExecutor for faster scans on large accounts
- Wildcard pattern support in suppressions (`aws-iam-*`, `arn:aws:*:*:*:role/deploy-*`)
- Debug logging in attack chain correlation engine for diagnosing collection failures
- Makefile with `make all` (lint + format + typecheck + test), `make test-cov`, `make security`
- `provider.client()` method with boto3 adaptive retry (max 5 attempts) and per-service client caching
- `_region_overlap()` helper for shared region-matching logic in attack chain rules
- 7 new tests for attack chains AC-25, AC-26, AC-27 and wildcard suppressions (345 total)

### Changed

- Thread-safe module-level caches in S3 and CloudTrail checks (threading.Lock)
- Cache reset abstracted into `BaseProvider.reset_caches()` (was hardcoded S3-only import)
- Scanner enforces canonical check_id from make_check metadata (single source of truth)
- `compute_summary()` optimized to single pass over findings (was 5+ iterations)
- IAM checks migrated to `provider.client()` for adaptive retry and client caching
- Demo command updated to show 80 checks (was 47)

### Fixed

- SARIF `artifactLocation.uri` now uses valid relative URI format (`checks/{check_id}`)
- Progress bar no longer advances past 100% in interactive mode
- Documentation URL in pyproject.toml points to docs site instead of GitHub README

## [1.2.1] - 2026-04-01

### Added

- **Attack chain visualization** in HTML reports - interactive SVG graphs showing attack paths with node-and-edge diagrams, color-coded by resource type (compute, identity, network, storage), animated edges, and glow effects on entry/impact nodes
- `VizStep` model with `Literal` type validation for node types
- 3 new tests for viz_steps validation (structure, types, edge labels)
- `viz_steps` field on `AttackChain` model (backward compatible, defaults to empty list)

### Changed

- `VizStep.type` constrained to Literal type (internet, compute, identity, network, storage, finding, impact) with Pydantic validation
- Attack chain cards in HTML report now have header/graph/body layout instead of flat text
- Sub-labels in visualization truncated to 22 characters to prevent overflow
- ROADMAP.md merged duplicate v1.3.0 sections into single entry
- SOC 2 docs clarified Automated column includes partially automated criteria

### Fixed

- Long resource IDs in visualization labels truncated to prevent SVG overflow

## [1.2.0] - 2026-04-01

### Added

- **SOC 2 Type II compliance framework** - 43 Trust Services Criteria mapped (AICPA 2017, revised 2022), 24 automated, 19 manual
- `--compliance soc2_type2` CLI flag - run SOC 2 readiness assessment alongside security scan
- SOC 2 compliance HTML and Markdown reports with per-control PASS/FAIL, evidence statements, and remediation
- 78 of 80 checks mapped to SOC 2 criteria across 12 categories (CC1-CC9, A1, C1, PI1)
- 20 attack chain rules mapped to SOC 2 controls they would violate
- SOC 2 documentation page in MkDocs site
- 32 new tests for SOC 2 framework validation

### Changed

- `--compliance` help text now references both `cis_aws_v3` and `soc2_type2`
- `show-framework` help text updated with SOC 2 example
- Compliance overview docs updated with SOC 2 as available

## [1.1.0] - 2026-03-27

### Added

- **CIS AWS Foundations Benchmark v3.0.0 compliance engine** - 62 controls mapped, 55 fully automated, per-control evidence templates, readiness scoring
- `--compliance cis_aws_v3` CLI flag - run compliance assessment alongside security scan
- `list-frameworks` command - show available compliance frameworks
- `show-framework` command - display control mappings without scanning
- Compliance HTML report - auditor-ready, per-control PASS/FAIL with evidence statements, remediation (CLI + Terraform), and attack chain violations
- Compliance Markdown report - same data for PR comments and documentation
- **33 new security checks** (47 -> 80 total) covering CIS v3.0 requirements:
  - IAM: root access keys (1.4), multiple active keys (1.13), direct user policies (1.15), support role (1.17), IAM Access Analyzer (1.20), expired certificates (1.19), CloudShell access (1.22), hardware MFA for root (1.6), EC2 instance roles (1.18)
  - S3: deny HTTP policy (2.1.1), MFA Delete (2.1.2)
  - VPC: default security group restricts all traffic (5.4), NACL admin port detection (5.1)
  - CloudTrail: S3 bucket access logging (3.4), KMS encryption (3.5), S3 object-level write logging (3.8), S3 object-level read logging (3.9)
  - CloudWatch: 14 CIS Section 4 monitoring checks (4.1-4.2, 4.4-4.15) using metric filter + alarm detection
  - EFS: encryption at rest (2.4.1)
  - Security Hub: enabled check (4.16)
  - Account: security alternate contact (1.2)
- **4 new attack chain rules** (16 -> 20 total):
  - AC-25: Root Access Keys Without Audit Trail
  - AC-26: Unmonitored Admin Escalation Path
  - AC-27: Default Network Access Without Logging
  - AC-28: External Access Without Analysis
- **3 new AWS service modules**: Account, EFS, Security Hub
- CloudTrail API call cache (7 -> 1 API call per scan for trail listing)
- MkDocs Material documentation site (25 pages) at haitmg.pl/cloud-audit/
- CIS control-to-attack-chain mapping (20 chains mapped to specific CIS controls)

### Changed

- Check count: 47 -> 80 across 18 AWS services (was 15)
- Attack chains: 16 -> 20 rules
- CIS coverage: 16 controls -> 62 controls (100% of automatable recommendations)
- `aws-iam-004` threshold changed from 30 to 45 days (CIS 1.12 compliance)
- `aws-iam-006` now validates password reuse prevention >= 24 (CIS 1.9)
- `aws-vpc-004` now detects admin ports (22, 3389) specifically (CIS 5.1)
- `aws-ct-003` compliance_refs cleared (CIS 3.3 removed in v3.0)
- `aws-iam-002` compliance_refs corrected from CIS 1.4 to CIS 1.10
- AccessDenied handling improved in check_support_role, check_iam_access_analyzer, check_cloudshell_access
- README.md fully rewritten with updated numbers and documentation links

### Fixed

- S3 deny HTTP check CLI remediation was a tuple instead of string (trailing comma)
- CloudTrail bucket access logging CLI remediation same issue
- S3 Advanced Event Selector parsing now validates resources.type = AWS::S3::Object
- Errored checks no longer counted as "passed" in compliance engine

## [1.0.1] - 2026-03-24

### Changed

- MCP is now a regular dependency (not optional) - install with `uvx cloud-audit-mcp`
- Updated pyproject.toml description and keywords for MCP discoverability

## [1.0.0] - 2026-03-24

### Added

- **Breach cost estimation** - every finding and attack chain includes an estimated financial risk range (low/high USD) based on IBM Cost of a Data Breach 2024, Verizon DBIR, and published enforcement actions
- Total risk exposure displayed in scan summary, CLI output, HTML report, and markdown report
- Attack chain cost estimates use a compound risk multiplier (chained vulnerabilities have higher impact)
- New `CostEstimateData` model for structured cost data in JSON output
- **MCP Server** - Model Context Protocol server for AI agent integration (Claude Code, Cursor, VS Code Copilot)
- 6 MCP tools: `scan_aws`, `get_findings`, `get_attack_chains`, `get_remediation`, `get_health_score`, `list_checks`
- One-liner install: `claude mcp add cloud-audit -- uvx cloud-audit-mcp`
- `cloud-audit-mcp` entry point for uvx/pipx
- `.mcp.json` project configuration for team-wide MCP setup
- `mcp` included as regular dependency (no extras needed)

### Changed

- Health Score panel now shows "Risk exposure: $X - $Y" when findings are present
- Attack chain display in CLI includes per-chain cost estimates
- Markdown report header includes total risk exposure
- Markdown attack chain table shows cost column instead of narrative
- Development Status classifier changed from Alpha to Beta

## [0.9.1] - 2026-03-19

### Added

- **GitHub Action** - reusable composite action for CI/CD (`gebalamariusz/cloud-audit@v0`) with SARIF upload, OIDC auth, and diff baseline support
- **pre-commit hooks** - `cloud-audit` and `cloud-audit-diff` hooks for the pre-commit framework (pre-push stage)
- GitHub Sponsors funding link
- YouTube demo video embedded in README

### Changed

- Lambda deprecated runtimes list extended with EOL dates (community contribution by @P-r-e-m-i-u-m, PR #18)
- GitHub Actions bumped: checkout v6, codeql-action v4, configure-aws-credentials v6

## [0.9.0] - 2026-03-18

### Added

- **Attack chain detection** - 16 rules correlating findings into exploitable multi-service attack paths
- Attack chains output in terminal (Rich panel), HTML report, markdown, and JSON
- Resource relationship collector (EC2->IAM role, Lambda->role, OIDC->policies)
- 4 attack chain tiers: Internet Exposure + Privilege, Missing Controls, Data Protection, Container/Secrets + CI/CD
- Rules based on MITRE ATT&CK Cloud Matrix, Datadog pathfinding.cloud, and AWS CIRT Threat Catalog
- New check: `aws-iam-007` - OIDC trust policy without sub condition (CRITICAL)
- New check: `aws-ec2-006` - EBS default encryption disabled (MEDIUM)
- Enhanced HTML report: executive summary, priority grouping (Fix Now/This Week/Next Sprint), CIS pass/fail indicators
- Logo added to README and HTML report
- Pre-commit hook for ruff format

### Changed

- Check count: 45 -> 47
- README: Attack Chains as primary feature, logo, updated tagline
- ROADMAP: v0.9.0 Attack Chains milestone added

### Fixed

- False-confidence tests: ECS exec (mocked), secrets unused (mocked), config recorder assertion
- New test scenarios: IPv6 ::/0 SG, RDP port 3389, multi-provider attack chains
- SECURITY.md: supported version updated to 0.8.x
- Bug report template: added WSL/Other OS options

## [0.8.0] - 2026-03-14

### Added

- `cloud-audit diff` command - compare two scan JSON files, show new/fixed/changed findings
- Diff output formats: terminal (Rich), markdown (`--format markdown`), JSON (`--format json`)
- Diff exit codes: 0 = no new findings, 1 = regression detected, 2 = error
- Scope warnings when comparing scans from different regions or accounts
- File size limit (50 MB) and `is_file()` validation on diff inputs
- Rich markup escaping for user-controlled strings in diff output
- Format auto-detection from `--output` file extension in diff command
- CI/CD example: `examples/daily-scan-with-diff.yml` (scheduled daily scan with cache-based baseline)
- CI/CD example: `examples/post-deploy-scan.yml` (pre/post terraform apply comparison)
- 35 new tests for diff engine, markdown output, and CLI integration
- 213 tests passing total

### Changed

- `unchanged_count` replaced with `unchanged_findings` list (shows what stayed the same)
- README: added "Track changes between scans" section with diff usage
- README: CI/CD section expanded with table of ready-to-use workflows
- README: S3 encryption check updated to reflect SSE-KMS vs SSE-S3 pivot (LOW severity)
- README: severity counts updated (7/14/16/8)

## [0.7.0] - 2026-03-14

### Changed

- SARIF: use `physicalLocation` + `logicalLocations` (fixes GitHub Code Scanning compatibility)
- SARIF: add `help.markdown` to rules (remediation now visible in GitHub Security tab)
- SARIF: add `semanticVersion` to tool driver
- S3 encryption check pivoted: SSE-S3 (AES-256) is now LOW severity, SSE-KMS = PASS (AWS auto-encrypts since Jan 2023)
- Markdown: escape pipes and newlines in all table columns
- Markdown: round duration to 1 decimal place
- HTML report: duration formatted consistently (1 decimal)
- HTML report: ARIA attributes on score ring (`role="meter"`) and severity badges
- Imports moved to top level in HTML report renderer
- Ruff: enabled `RUF`, `PIE`, `RET` rule groups; `S101` now per-file for tests only

### Fixed

- SARIF `physicalLocation` missing caused GitHub Code Scanning to reject uploads
- S3 encryption check false positives on buckets using default SSE-S3
- Extracted `_kms_encryption_remediation()` helper (DRY)

### Tests

- 179 tests passing (+5 new)
- New SARIF tests: `semanticVersion`, `help.markdown`, `logicalLocations`, `physicalLocation`
- New S3 tests: SSE-KMS pass, SSE-S3 LOW with compliance_refs, DSSE-KMS pass

## [0.6.0] - 2026-03-06

### Security

- Bump Jinja2 minimum to >=3.1.6 (fixes CVE-2025-27516 sandbox breakout)
- Sanitize shell metacharacters in `--export-fixes` bash script output
- Use `shlex.quote()` for user-controlled EC2 Name tags in remediation CLI commands
- Set restrictive file permissions (700) on generated remediation scripts
- SHA-pin all GitHub Actions in CI and release workflows
- Dockerfile: non-root user, pinned base image digest, `--no-input` flag

### Added

- `make_check()` helper for consistent check registration with metadata
- `.cloud-audit.example.yml` config template
- Pre-filtering of excluded checks before API calls (no wasted requests)
- S3 bucket cache with proper reset between scans
- NACL check now detects open TCP/UDP rules (not just protocol `-1`)

### Changed

- ECS `list_clusters` and GuardDuty `list_detectors` now paginate correctly
- ECS `describe_services` batched to 10 per call (API limit)
- Security group findings deduplicated per rule (one finding lists all exposed ports)
- CloudWatch root usage alarm check tries CloudTrail-named log groups first
- Default VPC check reports "at least N" ENIs when count hits API limit
- `list-checks --categories` filtering fixed for Python 3.10 compatibility
- Moved `datetime`/`json` imports to module level in IAM and GuardDuty checks
- SARIF output: fixed `uriBaseId`, added `fullDescription` and `originalUriBaseIds`
- HTML report: light mode support, print CSS, ARIA labels, copyCode fix
- Markdown report: pipe escaping in table cells
- ASCII severity icons (fixes UnicodeEncodeError on Windows cp1250)
- CloudTrail: `includeShadowTrails=True` with ARN deduplication
- S3: error code check instead of string matching for encryption detection
- S3: `_tf_name()` handles bucket names starting with digits
- S3: extracted `_lifecycle_remediation()` helper (DRY)

### Fixed

- S3 AccessDenied no longer produces false positive findings
- Deprecated runtimes list updated (python3.9, nodejs18.x, dotnet6)
- `PackageNotFoundError` fallback in `__init__.py`
- `list-checks` warns on module load failure instead of silently continuing

### Documentation

- Backfilled CHANGELOG for v0.3.0 through v0.5.2
- Updated SECURITY.md supported versions to 0.5.x
- Documented suppression `expires` semantics (inclusive last day)
- Added docstring to `compute_summary()`
- Clarified `.gitignore` `*.md` pattern

## [0.5.2] - 2026-03-06

### Changed

- README overhaul with updated examples and OIDC recommendation for CI/CD
- Demo command updated to reflect current check count

### Fixed

- Various check accuracy improvements

## [0.5.1] - 2026-03-05

### Fixed

- Remove invalid SARIF `fixes` field; move remediation to `properties`
- Ruff format fixes for v0.5.0 files

## [0.5.0] - 2026-03-05

### Added

- `.cloud-audit.yml` config file with suppressions (allowlist pattern)
- SARIF v2.1.0 output for GitHub Code Scanning integration
- Markdown report generator for PR comments
- `--format` flag (json, sarif, markdown, html)
- `--min-severity`, `--quiet`, `--role-arn`, `--config` CLI flags
- `list-checks` command
- 4 environment variables: `CLOUD_AUDIT_MIN_SEVERITY`, `CLOUD_AUDIT_EXCLUDE_CHECKS`, `CLOUD_AUDIT_ROLE_ARN`, `CLOUD_AUDIT_REGIONS`
- Exit codes: 0=clean, 1=findings, 2=errors
- Cross-account scanning via STS AssumeRole (`--role-arn`)
- 3 new checks: EC2 termination protection, RDS auto minor upgrade, unrestricted NACL (45 total)
- 168 tests passing

## [0.4.1] - 2026-03-04

### Fixed

- Use absolute image URLs in README for PyPI rendering

## [0.4.0] - 2026-03-04

### Added

- Lambda checks: public function URL, deprecated runtime, env var secrets
- ECS checks: privileged containers, missing logging, ECS Exec enabled
- SSM checks: unmanaged EC2, insecure parameters
- Secrets Manager checks: rotation disabled, unused secrets
- IAM: overly permissive policy (Action:*/Resource:*), weak password policy (CIS 1.8)
- S3: lifecycle policy (cost), access logging
- EC2: IMDSv1 enabled (SSRF risk)
- Version sourced from `importlib.metadata`
- 96 moto tests, 15 CIS controls mapped (42 checks total)

## [0.3.0] - 2026-03-04

### Added

- CloudTrail checks (3): multi-region trail, log validation, S3 logging
- GuardDuty checks (2): detector enabled, high-severity findings
- AWS Config checks (2): recorder enabled, delivery channel
- KMS checks (2): key rotation, unused keys
- CloudWatch check: root account usage alarm
- CIS Benchmark coverage expanded to 14 controls
- 66 moto tests

## [0.2.0] - 2026-03-03

### Added

- Structured remediation for all 17 checks - every finding includes:
  - Copy-paste AWS CLI command with real resource IDs
  - Terraform HCL snippet
  - AWS documentation link
  - Estimated effort level (LOW / MEDIUM / HIGH)
- CIS AWS Foundations Benchmark mapping (10 controls covered)
- `--remediation` / `-R` CLI flag - print fix details after scan summary
- `--export-fixes <path>` CLI flag - export all CLI commands as a dry-run bash script
- HTML report enhancements:
  - Expandable "How to fix" panel per finding with CLI and Terraform snippets
  - Copy-to-clipboard button for commands
  - CIS Benchmark coverage section
  - Compliance reference badges on findings
- Comprehensive moto-based test suite (45 tests covering all checks)

## [0.1.0] - 2026-03-03

### Added

- Initial release
- CLI interface with `scan` and `version` commands
- 17 AWS security, cost, and reliability checks:
  - **IAM:** Root MFA, user MFA, access key rotation, unused access keys
  - **S3:** Public buckets, encryption at rest, versioning
  - **EC2:** Public AMIs, unencrypted EBS volumes, stopped instances
  - **VPC:** Default VPC usage, open security groups, flow logs
  - **RDS:** Public instances, encryption at rest, Multi-AZ
  - **EIP:** Unattached Elastic IPs
- Health score (0-100) based on finding severity
- HTML report with dark-mode design
- JSON output for CI/CD integration
- Docker image support
- Rich terminal UI with progress bar and color-coded findings

[Unreleased]: https://github.com/gebalamariusz/cloud-audit/compare/v1.3.0...HEAD
[1.3.0]: https://github.com/gebalamariusz/cloud-audit/compare/v1.2.2...v1.3.0
[1.2.2]: https://github.com/gebalamariusz/cloud-audit/compare/v1.2.1...v1.2.2
[1.2.1]: https://github.com/gebalamariusz/cloud-audit/compare/v1.2.0...v1.2.1
[1.2.0]: https://github.com/gebalamariusz/cloud-audit/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/gebalamariusz/cloud-audit/compare/v1.0.1...v1.1.0
[1.0.1]: https://github.com/gebalamariusz/cloud-audit/compare/v1.0.0...v1.0.1
[1.0.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.9.1...v1.0.0
[0.9.1]: https://github.com/gebalamariusz/cloud-audit/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.5.2...v0.6.0
[0.5.2]: https://github.com/gebalamariusz/cloud-audit/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/gebalamariusz/cloud-audit/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.4.1...v0.5.0
[0.4.1]: https://github.com/gebalamariusz/cloud-audit/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/gebalamariusz/cloud-audit/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/gebalamariusz/cloud-audit/releases/tag/v0.1.0
