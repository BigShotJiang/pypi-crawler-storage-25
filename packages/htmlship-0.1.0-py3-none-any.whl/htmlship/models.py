from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import HTMLShipClient


@dataclass
class Paste:
    """A paste created via the HTMLShip API.

    The `owner_key` is set on creation and is the only credential to mutate or
    delete the paste. It is None for pastes loaded via `get()` since the server
    does not return it after creation.
    """

    slug: str
    url: str
    owner_key: str | None = None
    expires_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    title: str | None = None
    view_count: int = 0
    size_bytes: int = 0
    has_password: bool = False
    parent_slug: str | None = None

    _client: "HTMLShipClient | None" = field(default=None, repr=False, compare=False)

    def update(self, html: str, *, title: str | None = None) -> "Paste":
        """Replace this paste's HTML. Requires owner_key."""
        if self._client is None:
            raise RuntimeError("Paste is detached from a client; reattach to mutate")
        if not self.owner_key:
            raise RuntimeError(
                "owner_key is required to update; load via get() first or pass owner_key explicitly"
            )
        return self._client.update(self.slug, html, owner_key=self.owner_key, title=title)

    def delete(self) -> None:
        """Soft-delete this paste. Requires owner_key."""
        if self._client is None:
            raise RuntimeError("Paste is detached from a client; reattach to delete")
        if not self.owner_key:
            raise RuntimeError(
                "owner_key is required to delete; load via get() first or pass owner_key explicitly"
            )
        self._client.delete(self.slug, owner_key=self.owner_key)

    def fetch_metadata(self) -> "Paste":
        """Refresh metadata from the server."""
        if self._client is None:
            raise RuntimeError("Paste is detached from a client; reattach to fetch metadata")
        fresh = self._client.get(self.slug)
        # Preserve owner_key (server doesn't return it).
        fresh.owner_key = self.owner_key
        return fresh
