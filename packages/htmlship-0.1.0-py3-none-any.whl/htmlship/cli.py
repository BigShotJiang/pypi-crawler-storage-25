from __future__ import annotations

import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import click

from . import HTMLShipClient
from ._version import __version__
from .exceptions import HTMLShipError, NotFoundError

KEYS_DIR = Path(os.environ.get("HTMLSHIP_KEYS_DIR", str(Path.home() / ".htmlship")))
KEYS_FILE = KEYS_DIR / "keys.json"


# --- key store ----------------------------------------------------------------


def _load_keys() -> dict[str, dict[str, Any]]:
    if not KEYS_FILE.exists():
        return {}
    try:
        return json.loads(KEYS_FILE.read_text())
    except Exception:
        return {}


def _save_keys(data: dict[str, dict[str, Any]]) -> None:
    KEYS_DIR.mkdir(parents=True, exist_ok=True)
    KEYS_FILE.write_text(json.dumps(data, indent=2, sort_keys=True))
    try:
        KEYS_FILE.chmod(0o600)
    except OSError:
        pass


def _remember(slug: str, owner_key: str, url: str, title: str | None) -> None:
    keys = _load_keys()
    keys[slug] = {
        "owner_key": owner_key,
        "url": url,
        "title": title,
        "saved_at": datetime.now(UTC).isoformat(),
    }
    _save_keys(keys)


def _forget(slug: str) -> None:
    keys = _load_keys()
    if slug in keys:
        del keys[slug]
        _save_keys(keys)


def _lookup_owner_key(slug: str) -> str | None:
    return _load_keys().get(slug, {}).get("owner_key")


# --- helpers ------------------------------------------------------------------


def _read_html(source: str | None, file: str | None) -> str:
    """Resolve the HTML payload from --file, a positional path, or stdin."""
    if file:
        return Path(file).read_text(encoding="utf-8")
    if source == "-" or source is None:
        if sys.stdin.isatty() and source is None:
            raise click.UsageError("Provide a file path or pipe HTML on stdin.")
        return sys.stdin.read()
    return Path(source).read_text(encoding="utf-8")


def _try_clipboard(text: str) -> bool:
    try:
        import pyperclip  # type: ignore
    except Exception:
        return False
    try:
        pyperclip.copy(text)
        return True
    except Exception:
        return False


def _make_client(api_url: str | None) -> HTMLShipClient:
    return HTMLShipClient(base_url=api_url)


# --- CLI ----------------------------------------------------------------------


@click.group(help="HTMLShip — host and share HTML in one line.")
@click.version_option(__version__, prog_name="htmlship")
@click.option(
    "--api-url",
    envvar="HTMLSHIP_API_URL",
    default=None,
    help="API base URL (default: https://api.htmlship.com).",
)
@click.pass_context
def main(ctx: click.Context, api_url: str | None) -> None:
    ctx.ensure_object(dict)
    ctx.obj["api_url"] = api_url


@main.command()
@click.argument("source", required=False)
@click.option("--file", "-f", "file_", type=click.Path(exists=True, dir_okay=False), help="HTML file path.")
@click.option("--title", default=None, help="Optional title.")
@click.option("--password", default=None, help="Password-protect the paste.")
@click.option("--expires-in", type=int, default=None, help="Seconds until expiry.")
@click.option("--no-clipboard", is_flag=True, help="Don't copy URL to clipboard.")
@click.option("--quiet", "-q", is_flag=True, help="Print only the URL.")
@click.pass_context
def publish(
    ctx: click.Context,
    source: str | None,
    file_: str | None,
    title: str | None,
    password: str | None,
    expires_in: int | None,
    no_clipboard: bool,
    quiet: bool,
) -> None:
    """Publish HTML.

    Examples:

      htmlship publish report.html
      cat report.html | htmlship publish -
      htmlship publish --file report.html --title "Q4 Report"
    """
    html = _read_html(source, file_)
    client = _make_client(ctx.obj["api_url"])
    try:
        paste = client.publish(
            html,
            title=title,
            password=password,
            expires_in=expires_in,
        )
    except HTMLShipError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()

    _remember(paste.slug, paste.owner_key or "", paste.url, title)

    if quiet:
        click.echo(paste.url)
        return

    click.echo(paste.url)
    click.echo(f"slug:      {paste.slug}", err=True)
    click.echo(f"owner_key: {paste.owner_key}  (saved to {KEYS_FILE})", err=True)
    if paste.expires_at:
        click.echo(f"expires:   {paste.expires_at.isoformat()}", err=True)
    if not no_clipboard and _try_clipboard(paste.url):
        click.echo("(URL copied to clipboard)", err=True)


@main.command()
@click.argument("slug")
@click.pass_context
def get(ctx: click.Context, slug: str) -> None:
    """Show metadata for a paste."""
    client = _make_client(ctx.obj["api_url"])
    try:
        paste = client.get(slug)
    except NotFoundError as exc:
        raise click.ClickException(f"paste '{slug}' not found") from exc
    except HTMLShipError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()

    click.echo(json.dumps(
        {
            "slug": paste.slug,
            "url": paste.url,
            "title": paste.title,
            "view_count": paste.view_count,
            "size_bytes": paste.size_bytes,
            "has_password": paste.has_password,
            "parent_slug": paste.parent_slug,
            "expires_at": paste.expires_at.isoformat() if paste.expires_at else None,
            "created_at": paste.created_at.isoformat() if paste.created_at else None,
            "updated_at": paste.updated_at.isoformat() if paste.updated_at else None,
        },
        indent=2,
    ))


@main.command()
@click.argument("slug")
@click.argument("source", required=False)
@click.option("--file", "-f", "file_", type=click.Path(exists=True, dir_okay=False))
@click.option("--title", default=None, help="Optional new title.")
@click.option("--owner-key", default=None, help="Owner key (defaults to local store).")
@click.pass_context
def update(
    ctx: click.Context,
    slug: str,
    source: str | None,
    file_: str | None,
    title: str | None,
    owner_key: str | None,
) -> None:
    """Replace HTML for an existing paste."""
    html = _read_html(source, file_)
    key = owner_key or _lookup_owner_key(slug)
    if not key:
        raise click.ClickException(
            f"no owner key for '{slug}' in {KEYS_FILE}; pass --owner-key explicitly"
        )
    client = _make_client(ctx.obj["api_url"])
    try:
        paste = client.update(slug, html, owner_key=key, title=title)
    except HTMLShipError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()

    click.echo(paste.url)


@main.command()
@click.argument("slug")
@click.option("--owner-key", default=None, help="Owner key (defaults to local store).")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
@click.pass_context
def delete(ctx: click.Context, slug: str, owner_key: str | None, yes: bool) -> None:
    """Soft-delete a paste."""
    key = owner_key or _lookup_owner_key(slug)
    if not key:
        raise click.ClickException(
            f"no owner key for '{slug}' in {KEYS_FILE}; pass --owner-key explicitly"
        )
    if not yes:
        click.confirm(f"Delete paste '{slug}'?", abort=True)
    client = _make_client(ctx.obj["api_url"])
    try:
        client.delete(slug, owner_key=key)
    except HTMLShipError as exc:
        raise click.ClickException(str(exc)) from exc
    finally:
        client.close()
    _forget(slug)
    click.echo(f"deleted {slug}")


@main.command("list-mine")
@click.option("--limit", type=int, default=20, show_default=True)
@click.pass_context
def list_mine(ctx: click.Context, limit: int) -> None:
    """List pastes whose owner keys are saved locally."""
    keys = _load_keys()
    if not keys:
        click.echo(f"No saved pastes in {KEYS_FILE}.")
        return
    items = sorted(keys.items(), key=lambda kv: kv[1].get("saved_at", ""), reverse=True)[:limit]

    client = _make_client(ctx.obj["api_url"])
    try:
        rows = []
        for slug, info in items:
            try:
                paste = client.get(slug)
                size = f"{paste.size_bytes}B"
                views = paste.view_count
                title = paste.title or info.get("title") or ""
                status = "ok"
            except NotFoundError:
                paste = None
                size = "—"
                views = "—"
                title = info.get("title") or ""
                status = "gone"
            rows.append(
                {
                    "slug": slug,
                    "url": info.get("url"),
                    "title": title,
                    "size": size,
                    "views": views,
                    "status": status,
                }
            )
    finally:
        client.close()

    width = max((len(r["slug"]) for r in rows), default=8)
    for r in rows:
        click.echo(
            f"{r['slug']:<{width}}  {r['status']:<5}  {r['views']:>5} views  "
            f"{r['size']:>8}  {r['title']}"
        )
        click.echo(f"  {r['url']}")
