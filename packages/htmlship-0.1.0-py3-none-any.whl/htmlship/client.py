from __future__ import annotations

import os
from datetime import datetime
from typing import Any

import httpx

from ._version import __version__
from .exceptions import APIError, AuthError, HTMLShipError, NotFoundError, RateLimitError
from .models import Paste

DEFAULT_API_URL = "https://api.htmlship.com"
DEFAULT_TIMEOUT = 30.0


def _parse_dt(v: str | None) -> datetime | None:
    if v is None:
        return None
    return datetime.fromisoformat(v.replace("Z", "+00:00"))


class HTMLShipClient:
    """Synchronous HTTP client for the HTMLShip API.

    Reads `HTMLSHIP_API_URL` and `HTMLSHIP_API_KEY` from the environment by default.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        transport: httpx.BaseTransport | None = None,
    ):
        self.base_url = (base_url or os.getenv("HTMLSHIP_API_URL") or DEFAULT_API_URL).rstrip("/")
        self.api_key = api_key or os.getenv("HTMLSHIP_API_KEY")
        headers = {"User-Agent": f"htmlship-python/{__version__}"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        self._http = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
            transport=transport,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "HTMLShipClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # --- public API ---------------------------------------------------------

    def publish(
        self,
        html: str,
        *,
        title: str | None = None,
        password: str | None = None,
        expires_in: int | None = None,
        parent_slug: str | None = None,
        sandbox_mode: str = "strict",
    ) -> Paste:
        """Create a paste. Returns a Paste with owner_key set."""
        body: dict[str, Any] = {"html": html, "sandbox_mode": sandbox_mode}
        if title is not None:
            body["title"] = title
        if password is not None:
            body["password"] = password
        if expires_in is not None:
            body["expires_in"] = expires_in
        if parent_slug is not None:
            body["parent_slug"] = parent_slug
        r = self._http.post("/api/v1/pastes", json=body)
        data = self._handle(r)
        return Paste(
            slug=data["slug"],
            url=data["url"],
            owner_key=data["owner_key"],
            expires_at=_parse_dt(data.get("expires_at")),
            created_at=_parse_dt(data.get("created_at")),
            _client=self,
        )

    def get(self, slug: str) -> Paste:
        """Fetch metadata for a paste. owner_key is None on the returned object."""
        r = self._http.get(f"/api/v1/pastes/{slug}")
        data = self._handle(r)
        return Paste(
            slug=data["slug"],
            url=data["url"],
            owner_key=None,
            title=data.get("title"),
            expires_at=_parse_dt(data.get("expires_at")),
            created_at=_parse_dt(data.get("created_at")),
            updated_at=_parse_dt(data.get("updated_at")),
            view_count=data.get("view_count", 0),
            size_bytes=data.get("size_bytes", 0),
            has_password=data.get("has_password", False),
            parent_slug=data.get("parent_slug"),
            _client=self,
        )

    def update(
        self,
        slug: str,
        html: str,
        *,
        owner_key: str,
        title: str | None = None,
    ) -> Paste:
        body: dict[str, Any] = {"html": html}
        if title is not None:
            body["title"] = title
        r = self._http.patch(
            f"/api/v1/pastes/{slug}",
            json=body,
            headers={"X-Owner-Key": owner_key},
        )
        data = self._handle(r)
        return Paste(
            slug=data["slug"],
            url=data["url"],
            owner_key=owner_key,
            expires_at=_parse_dt(data.get("expires_at")),
            updated_at=_parse_dt(data.get("updated_at")),
            _client=self,
        )

    def delete(self, slug: str, *, owner_key: str) -> None:
        r = self._http.delete(
            f"/api/v1/pastes/{slug}",
            headers={"X-Owner-Key": owner_key},
        )
        self._handle(r, expect_no_body=True)

    def create_version(
        self,
        parent_slug: str,
        html: str,
        *,
        title: str | None = None,
        password: str | None = None,
        expires_in: int | None = None,
    ) -> Paste:
        body: dict[str, Any] = {"html": html, "sandbox_mode": "strict"}
        if title is not None:
            body["title"] = title
        if password is not None:
            body["password"] = password
        if expires_in is not None:
            body["expires_in"] = expires_in
        r = self._http.post(f"/api/v1/pastes/{parent_slug}/version", json=body)
        data = self._handle(r)
        return Paste(
            slug=data["slug"],
            url=data["url"],
            owner_key=data["owner_key"],
            expires_at=_parse_dt(data.get("expires_at")),
            created_at=_parse_dt(data.get("created_at")),
            _client=self,
        )

    # --- error mapping ------------------------------------------------------

    def _handle(self, r: httpx.Response, *, expect_no_body: bool = False) -> dict[str, Any]:
        if 200 <= r.status_code < 300:
            if expect_no_body or not r.content:
                return {}
            return r.json()

        detail = self._error_detail(r)

        if r.status_code == 404:
            raise NotFoundError(detail)
        if r.status_code in (401, 403):
            raise AuthError(detail)
        if r.status_code == 429:
            retry = r.headers.get("Retry-After")
            try:
                retry_after = float(retry) if retry else None
            except ValueError:
                retry_after = None
            raise RateLimitError(detail, retry_after=retry_after)
        raise APIError(detail, status_code=r.status_code)

    @staticmethod
    def _error_detail(r: httpx.Response) -> str:
        try:
            data = r.json()
            if isinstance(data, dict):
                if "detail" in data:
                    return str(data["detail"])
                return str(data)
            return str(data)
        except Exception:
            return r.text or f"HTTP {r.status_code}"


__all__ = [
    "HTMLShipClient",
    "HTMLShipError",
    "NotFoundError",
    "AuthError",
    "RateLimitError",
    "APIError",
]
