from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import Settings, get_settings
from ..database import get_session
from ..db_models.paste import Paste
from ..schemas.pastes import (
    PasteCreate,
    PasteCreateResponse,
    PasteMetadata,
    PasteUpdate,
    PasteUpdateResponse,
)
from ..security import (
    generate_owner_key,
    hash_owner_key,
    hash_password,
    verify_owner_key,
)
from ..slugs import generate_unique_slug
from ..storage import get_blob_store, make_blob_key

router = APIRouter(prefix="/api/v1")


def _view_url(settings: Settings, slug: str) -> str:
    return f"{settings.view_base_url.rstrip('/')}/{slug}"


async def _slug_exists(session: AsyncSession, slug: str) -> bool:
    res = await session.execute(select(Paste.id).where(Paste.slug == slug))
    return res.first() is not None


async def _load_active(session: AsyncSession, slug: str) -> Paste:
    res = await session.execute(select(Paste).where(Paste.slug == slug))
    paste = res.scalar_one_or_none()
    if paste is None or paste.deleted_at is not None:
        raise HTTPException(status_code=404, detail="paste not found")
    if paste.expires_at is not None and paste.expires_at <= datetime.now(UTC):
        raise HTTPException(status_code=404, detail="paste expired")
    return paste


def _require_owner_key(x_owner_key: str | None) -> str:
    if not x_owner_key:
        raise HTTPException(status_code=401, detail="missing X-Owner-Key header")
    return x_owner_key


@router.post(
    "/pastes",
    status_code=status.HTTP_201_CREATED,
    response_model=PasteCreateResponse,
)
async def create_paste(
    payload: PasteCreate,
    request: Request,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PasteCreateResponse:
    return await _create_paste_impl(
        payload=payload,
        parent_override=payload.parent_slug,
        settings=settings,
        session=session,
    )


@router.post(
    "/pastes/{slug}/version",
    status_code=status.HTTP_201_CREATED,
    response_model=PasteCreateResponse,
)
async def create_version(
    slug: str,
    payload: PasteCreate,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PasteCreateResponse:
    parent = await _load_active(session, slug)
    return await _create_paste_impl(
        payload=payload,
        parent_override=parent.slug,
        settings=settings,
        session=session,
    )


async def _create_paste_impl(
    *,
    payload: PasteCreate,
    parent_override: str | None,
    settings: Settings,
    session: AsyncSession,
) -> PasteCreateResponse:
    html_bytes = payload.html.encode("utf-8")
    if len(html_bytes) > settings.max_payload_bytes:
        raise HTTPException(status_code=413, detail="html exceeds size limit")

    if parent_override and parent_override != payload.parent_slug:
        # Path version takes precedence; verify it exists
        await _load_active(session, parent_override)

    async def exists(s: str) -> bool:
        return await _slug_exists(session, s)

    slug = await generate_unique_slug(exists)

    owner_key = generate_owner_key()
    owner_hash = hash_owner_key(owner_key)
    pwd_hash = hash_password(payload.password) if payload.password else None

    expires_at: datetime | None = None
    if payload.expires_in is not None:
        expires_at = datetime.now(UTC) + timedelta(seconds=payload.expires_in)
    elif settings.default_expires_in_seconds:
        expires_at = datetime.now(UTC) + timedelta(seconds=settings.default_expires_in_seconds)

    paste = Paste(
        slug=slug,
        blob_key="",  # set after we know the id
        title=payload.title,
        owner_key_hash=owner_hash,
        password_hash=pwd_hash,
        sandbox_mode=payload.sandbox_mode,
        expires_at=expires_at,
        size_bytes=len(html_bytes),
        parent_slug=parent_override,
    )
    session.add(paste)
    await session.flush()

    blob_key = make_blob_key(paste.id)
    paste.blob_key = blob_key

    store = get_blob_store()
    await store.put(blob_key, html_bytes)

    await session.commit()
    await session.refresh(paste)

    return PasteCreateResponse(
        slug=paste.slug,
        url=_view_url(settings, paste.slug),
        owner_key=owner_key,
        expires_at=paste.expires_at,
        created_at=paste.created_at,
    )


@router.get("/pastes/{slug}", response_model=PasteMetadata)
async def get_paste_metadata(
    slug: str,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PasteMetadata:
    paste = await _load_active(session, slug)
    return PasteMetadata(
        slug=paste.slug,
        title=paste.title,
        url=_view_url(settings, paste.slug),
        expires_at=paste.expires_at,
        created_at=paste.created_at,
        updated_at=paste.updated_at,
        view_count=paste.view_count,
        size_bytes=paste.size_bytes,
        has_password=paste.password_hash is not None,
        parent_slug=paste.parent_slug,
    )


@router.patch("/pastes/{slug}", response_model=PasteUpdateResponse)
async def update_paste(
    slug: str,
    payload: PasteUpdate,
    x_owner_key: str | None = Header(default=None, alias="X-Owner-Key"),
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PasteUpdateResponse:
    owner_key = _require_owner_key(x_owner_key)
    paste = await _load_active(session, slug)
    if not verify_owner_key(owner_key, paste.owner_key_hash):
        raise HTTPException(status_code=403, detail="invalid owner key")

    html_bytes = payload.html.encode("utf-8")
    if len(html_bytes) > settings.max_payload_bytes:
        raise HTTPException(status_code=413, detail="html exceeds size limit")

    paste.size_bytes = len(html_bytes)
    if payload.title is not None:
        paste.title = payload.title

    store = get_blob_store()
    await store.put(paste.blob_key, html_bytes)

    await session.commit()
    await session.refresh(paste)

    return PasteUpdateResponse(
        slug=paste.slug,
        url=_view_url(settings, paste.slug),
        expires_at=paste.expires_at,
        updated_at=paste.updated_at,
    )


@router.delete(
    "/pastes/{slug}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
async def delete_paste(
    slug: str,
    x_owner_key: str | None = Header(default=None, alias="X-Owner-Key"),
    session: AsyncSession = Depends(get_session),
) -> Response:
    owner_key = _require_owner_key(x_owner_key)
    paste = await _load_active(session, slug)
    if not verify_owner_key(owner_key, paste.owner_key_hash):
        raise HTTPException(status_code=403, detail="invalid owner key")
    paste.deleted_at = datetime.now(UTC)
    store = get_blob_store()
    try:
        await store.delete(paste.blob_key)
    except Exception:
        pass
    await session.commit()
    return Response(status_code=204)
