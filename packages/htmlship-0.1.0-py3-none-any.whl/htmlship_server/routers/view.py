from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, Form, HTTPException, Request, Response
from itsdangerous import BadSignature, URLSafeSerializer
from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.responses import HTMLResponse

from ..config import Settings, get_settings
from ..database import get_session
from ..db_models.paste import Paste
from ..security import verify_password
from ..storage import get_blob_store

router = APIRouter()

STRICT_CSP = (
    "default-src 'none'; "
    "img-src data: https:; "
    "style-src 'unsafe-inline' https:; "
    "font-src https: data:; "
    "media-src https:; "
    "frame-ancestors *"
)

SECURITY_HEADERS = {
    "Content-Security-Policy": STRICT_CSP,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": (
        "accelerometer=(), camera=(), geolocation=(), microphone=(), payment=()"
    ),
    "Cache-Control": "public, max-age=3600",
}


PASSWORD_FORM_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Password required · HTMLShip</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  html,body{{margin:0;padding:0;background:#fdfcfa;color:#111;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}}
  main{{max-width:380px;margin:14vh auto;padding:32px 24px;border:1px solid #e8e4dd;border-radius:12px;background:#fff}}
  h1{{font-size:18px;margin:0 0 8px}}
  p{{font-size:14px;color:#555;margin:0 0 16px}}
  form{{display:flex;flex-direction:column;gap:10px}}
  input[type=password]{{padding:10px 12px;border:1px solid #d8d4cd;border-radius:8px;font-size:14px}}
  button{{padding:10px 12px;background:#111;color:#fff;border:0;border-radius:8px;cursor:pointer;font-size:14px}}
  .err{{color:#b00020;font-size:13px}}
</style>
</head>
<body>
<main>
  <h1>This paste is password-protected.</h1>
  <p>Enter the password to view it.</p>
  {error_html}
  <form method="post">
    <input type="password" name="password" autofocus required>
    <button type="submit">View</button>
  </form>
</main>
</body>
</html>
"""


def _serializer(settings: Settings) -> URLSafeSerializer:
    return URLSafeSerializer(settings.secret_key, salt="htmlship-paste-session")


def _cookie_name(slug: str) -> str:
    return f"htmlship_pw_{slug}"


def _has_valid_session(request: Request, slug: str, settings: Settings) -> bool:
    raw = request.cookies.get(_cookie_name(slug))
    if not raw:
        return False
    try:
        payload = _serializer(settings).loads(raw)
    except BadSignature:
        return False
    return payload.get("slug") == slug


def _set_session_cookie(response: Response, slug: str, settings: Settings) -> None:
    token = _serializer(settings).dumps({"slug": slug})
    response.set_cookie(
        _cookie_name(slug),
        token,
        max_age=60 * 60 * 24 * 7,
        httponly=True,
        samesite="lax",
        secure=settings.environment == "production",
        path="/",
    )


def _password_form(slug: str, error: str | None = None) -> HTMLResponse:
    error_html = f'<p class="err">{error}</p>' if error else ""
    body = PASSWORD_FORM_TEMPLATE.format(error_html=error_html)
    headers = dict(SECURITY_HEADERS)
    headers["Cache-Control"] = "no-store"
    return HTMLResponse(body, headers=headers)


async def _load_active_view(session: AsyncSession, slug: str) -> Paste:
    from sqlalchemy import select

    res = await session.execute(select(Paste).where(Paste.slug == slug))
    paste = res.scalar_one_or_none()
    if paste is None or paste.deleted_at is not None:
        raise HTTPException(status_code=404, detail="not found")
    if paste.expires_at is not None and paste.expires_at <= datetime.now(UTC):
        raise HTTPException(status_code=404, detail="expired")
    return paste


async def _serve_html(paste: Paste) -> HTMLResponse:
    store = get_blob_store()
    data = await store.get(paste.blob_key)
    return HTMLResponse(data, headers=SECURITY_HEADERS)


async def _bump_view_count(session: AsyncSession, paste_id) -> None:
    await session.execute(
        update(Paste).where(Paste.id == paste_id).values(view_count=Paste.view_count + 1)
    )
    await session.commit()


@router.get("/{slug}")
async def view_get(
    slug: str,
    request: Request,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> Response:
    paste = await _load_active_view(session, slug)

    if paste.password_hash and not _has_valid_session(request, slug, settings):
        return _password_form(slug)

    response = await _serve_html(paste)
    await _bump_view_count(session, paste.id)
    return response


@router.post("/{slug}")
async def view_post_password(
    slug: str,
    request: Request,
    password: str = Form(...),
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> Response:
    paste = await _load_active_view(session, slug)

    if not paste.password_hash:
        # No password set; redirect-equivalent: just serve.
        response = await _serve_html(paste)
        await _bump_view_count(session, paste.id)
        return response

    if not verify_password(password, paste.password_hash):
        return _password_form(slug, error="Wrong password.")

    response = await _serve_html(paste)
    _set_session_cookie(response, slug, settings)
    await _bump_view_count(session, paste.id)
    return response
