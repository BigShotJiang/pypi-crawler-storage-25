from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class PasteCreate(BaseModel):
    html: str = Field(..., min_length=0, max_length=10 * 1024 * 1024)
    title: str | None = Field(default=None, max_length=200)
    password: str | None = Field(default=None, max_length=128)
    expires_in: int | None = Field(default=None, ge=60, le=60 * 60 * 24 * 365)
    parent_slug: str | None = Field(default=None, min_length=4, max_length=12)
    sandbox_mode: Literal["strict", "relaxed"] = "strict"


class PasteUpdate(BaseModel):
    html: str = Field(..., min_length=0, max_length=10 * 1024 * 1024)
    title: str | None = Field(default=None, max_length=200)


class PasteCreateResponse(BaseModel):
    slug: str
    url: str
    owner_key: str
    expires_at: datetime | None
    created_at: datetime


class PasteMetadata(BaseModel):
    slug: str
    title: str | None
    url: str
    expires_at: datetime | None
    created_at: datetime
    updated_at: datetime
    view_count: int
    size_bytes: int
    has_password: bool
    parent_slug: str | None


class PasteUpdateResponse(BaseModel):
    slug: str
    url: str
    expires_at: datetime | None
    updated_at: datetime
