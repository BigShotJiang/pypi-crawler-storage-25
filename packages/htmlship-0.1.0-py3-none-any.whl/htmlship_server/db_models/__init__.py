from .paste import Base, Paste

__all__ = ["Base", "Paste"]
