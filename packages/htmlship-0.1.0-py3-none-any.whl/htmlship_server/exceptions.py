from __future__ import annotations


class StorageError(Exception):
    """Raised when the blob store fails."""


class PasteNotFoundError(Exception):
    pass
