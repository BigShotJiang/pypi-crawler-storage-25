from __future__ import annotations

import json

from starlette.types import ASGIApp, Message, Receive, Scope, Send

VIEW_HOST_PREFIX = "view."
API_HOST_PREFIX = "api."

# Slug character set — must match htmlship_server.slugs.ALPHABET.
SLUG_CHARS = frozenset("0123456789abcdefghijklmnopqrstuvwxyz")

# Paths always allowed on every host kind.
ALWAYS_ALLOWED_PATHS = frozenset({"/health", "/version", "/api/openapi.json", "/api/docs"})

# Path prefixes allowed on every host kind (e.g., FastAPI internals).
ALWAYS_ALLOWED_PREFIXES = ("/docs/", "/api/openapi", "/api/docs")


def host_from_scope(scope: Scope) -> str:
    """Return the lowercased Host header (without port), or empty string."""
    if scope.get("type") not in ("http", "websocket"):
        return ""
    headers = dict(scope.get("headers") or [])
    raw = headers.get(b"host", b"")
    host = raw.decode("latin-1").split(":", 1)[0].strip().lower()
    return host


def host_override_from_query(scope: Scope) -> str | None:
    """For local dev: read `?_host=view.htmlship.com` to spoof a host without DNS."""
    if scope.get("type") != "http":
        return None
    qs = scope.get("query_string") or b""
    if b"_host=" not in qs:
        return None
    for part in qs.decode("latin-1").split("&"):
        if part.startswith("_host="):
            return part[len("_host="):].split(":", 1)[0].strip().lower()
    return None


class HostRoutingMiddleware:
    """ASGI middleware that classifies requests by Host header.

    Sets `scope["htmlship_host_kind"]` to one of: 'view', 'api', 'landing'.
    """

    def __init__(self, app: ASGIApp, *, view_host: str, api_host: str, landing_host: str):
        self.app = app
        self.view_host = view_host.lower()
        self.api_host = api_host.lower()
        self.landing_host = landing_host.lower()

    def classify(self, host: str) -> str:
        if not host:
            return "landing"
        if host == self.view_host or host.startswith(VIEW_HOST_PREFIX):
            return "view"
        if host == self.api_host or host.startswith(API_HOST_PREFIX):
            return "api"
        return "landing"

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        host = host_override_from_query(scope) or host_from_scope(scope)
        kind = self.classify(host)
        scope["htmlship_host_kind"] = kind
        scope["htmlship_host"] = host

        if scope["type"] == "http" and not self._allowed(scope, kind):
            await _send_404(send)
            return

        await self.app(scope, receive, send)

    def _allowed(self, scope: Scope, kind: str) -> bool:
        path: str = scope.get("path", "/")
        if path in ALWAYS_ALLOWED_PATHS:
            return True
        for pref in ALWAYS_ALLOWED_PREFIXES:
            if path.startswith(pref):
                return True

        is_api_path = path.startswith("/api/")
        if is_api_path:
            # API allowed on landing/api hosts; blocked on view host.
            return kind != "view"

        # Non-API paths: anything that looks like /{slug} is reserved for the view host.
        # A slug is 8-12 chars from the slug alphabet only — this avoids matching
        # static-asset paths like /styles.css or /favicon.ico.
        stripped = path.strip("/")
        is_slug_shape = (
            bool(stripped)
            and "/" not in stripped
            and 6 <= len(stripped) <= 12
            and all(c in SLUG_CHARS for c in stripped)
        )
        if is_slug_shape:
            return kind == "view"

        # Other paths (e.g., "/" landing, static assets) — allow on landing host only.
        # On view host, only /{slug} is allowed.
        if kind == "view":
            return False
        return True


async def _send_404(send: Send) -> None:
    body = json.dumps({"detail": "not found"}).encode()
    await send(
        {
            "type": "http.response.start",
            "status": 404,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode()),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})


__all__ = ["HostRoutingMiddleware", "host_from_scope", "host_override_from_query"]


# Local Message import used only for typing in _send_404 future helpers.
_ = Message
