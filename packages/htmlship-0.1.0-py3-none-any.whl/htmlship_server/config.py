from __future__ import annotations

from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    environment: str = "development"
    log_level: str = "info"

    database_url: str = Field(
        default="postgresql+asyncpg://htmlship:htmlship@localhost:5433/htmlship"
    )

    public_base_domain: str = "htmlship.com"
    api_base_url: str = "https://api.htmlship.com"
    view_base_url: str = "https://view.htmlship.com"
    landing_base_url: str = "https://htmlship.com"

    spaces_bucket: str = ""
    spaces_region: str = "nyc3"
    spaces_endpoint_url: str = "https://nyc3.digitaloceanspaces.com"
    spaces_access_key: str = ""
    spaces_secret_key: str = ""

    secret_key: str = "dev-secret-do-not-use-in-prod"

    max_payload_bytes: int = 10 * 1024 * 1024
    default_expires_in_seconds: int | None = None

    @field_validator("default_expires_in_seconds", mode="before")
    @classmethod
    def _empty_to_none(cls, v):
        if v == "" or v is None:
            return None
        return v

    @property
    def use_local_blob_store(self) -> bool:
        return not self.spaces_bucket

    @property
    def view_host(self) -> str:
        return f"view.{self.public_base_domain}"

    @property
    def api_host(self) -> str:
        return f"api.{self.public_base_domain}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
