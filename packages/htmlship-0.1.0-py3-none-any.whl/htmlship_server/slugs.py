from __future__ import annotations

from collections.abc import Awaitable, Callable

from nanoid import generate as _nanoid_generate

ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz"
DEFAULT_LENGTH = 8
MAX_RETRIES = 3


def generate_slug(length: int = DEFAULT_LENGTH) -> str:
    return _nanoid_generate(ALPHABET, size=length)


async def generate_unique_slug(
    exists: Callable[[str], Awaitable[bool]],
    *,
    length: int = DEFAULT_LENGTH,
) -> str:
    """Generate a slug that doesn't already exist.

    Retries up to MAX_RETRIES times at the requested length, then bumps length by 2
    if it still collides.
    """
    cur_length = length
    for _ in range(MAX_RETRIES):
        candidate = generate_slug(cur_length)
        if not await exists(candidate):
            return candidate
    cur_length += 2
    for _ in range(MAX_RETRIES):
        candidate = generate_slug(cur_length)
        if not await exists(candidate):
            return candidate
    raise RuntimeError("could not generate unique slug after retries")
