from __future__ import annotations

import secrets

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

OWNER_KEY_PREFIX = "ws_"

_owner_hasher = PasswordHasher(
    memory_cost=65536,
    time_cost=3,
    parallelism=4,
)
_password_hasher = PasswordHasher(
    memory_cost=32768,
    time_cost=2,
    parallelism=2,
)


def generate_owner_key() -> str:
    return f"{OWNER_KEY_PREFIX}{secrets.token_urlsafe(24)}"


def hash_owner_key(key: str) -> str:
    return _owner_hasher.hash(key)


def verify_owner_key(key: str, hashed: str) -> bool:
    try:
        return _owner_hasher.verify(hashed, key)
    except VerifyMismatchError:
        return False
    except Exception:
        return False


def hash_password(password: str) -> str:
    return _password_hasher.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    try:
        return _password_hasher.verify(hashed, password)
    except VerifyMismatchError:
        return False
    except Exception:
        return False
