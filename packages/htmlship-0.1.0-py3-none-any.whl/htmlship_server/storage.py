from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol

from botocore.config import Config

from .config import get_settings


def make_blob_key(paste_id: uuid.UUID, *, when: datetime | None = None) -> str:
    when = when or datetime.now(UTC)
    return f"pastes/{when.year:04d}/{when.month:02d}/{paste_id}.html"


class BlobStore(Protocol):
    async def put(self, key: str, data: bytes) -> None: ...
    async def get(self, key: str) -> bytes: ...
    async def delete(self, key: str) -> None: ...


class LocalBlobStore:
    """Filesystem-backed blob store for local development and tests."""

    def __init__(self, root: Path | str = "./tmp/blobs"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path_for(self, key: str) -> Path:
        return self.root / key

    async def put(self, key: str, data: bytes) -> None:
        def _write() -> None:
            path = self._path_for(key)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)

        await asyncio.to_thread(_write)

    async def get(self, key: str) -> bytes:
        def _read() -> bytes:
            return self._path_for(key).read_bytes()

        return await asyncio.to_thread(_read)

    async def delete(self, key: str) -> None:
        def _delete() -> None:
            path = self._path_for(key)
            if path.exists():
                path.unlink()

        await asyncio.to_thread(_delete)


class SpacesBlobStore:
    """DigitalOcean Spaces-backed blob store. Wired in Phase 8."""

    def __init__(
        self,
        bucket: str,
        endpoint_url: str,
        region: str,
        access_key: str,
        secret_key: str,
    ):
        try:
            import boto3
        except ImportError as exc:
            raise RuntimeError("boto3 not installed") from exc
        self.bucket = bucket
        self._client = boto3.client(
            "s3",
            region_name=region,
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=Config(
                signature_version="s3v4",
                request_checksum_calculation="when_required",
                response_checksum_validation="when_required",
                s3={"addressing_style": "virtual"},
            ),
        )

    async def put(self, key: str, data: bytes) -> None:
        def _put() -> None:
            self._client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=data,
                ContentType="text/html; charset=utf-8",
            )

        await asyncio.to_thread(_put)

    async def get(self, key: str) -> bytes:
        def _get() -> bytes:
            obj = self._client.get_object(Bucket=self.bucket, Key=key)
            return obj["Body"].read()

        return await asyncio.to_thread(_get)

    async def delete(self, key: str) -> None:
        def _delete() -> None:
            self._client.delete_object(Bucket=self.bucket, Key=key)

        await asyncio.to_thread(_delete)


_store: BlobStore | None = None


def get_blob_store() -> BlobStore:
    global _store
    if _store is not None:
        return _store
    settings = get_settings()
    if settings.use_local_blob_store:
        _store = LocalBlobStore()
    else:
        _store = SpacesBlobStore(
            bucket=settings.spaces_bucket,
            endpoint_url=settings.spaces_endpoint_url,
            region=settings.spaces_region,
            access_key=settings.spaces_access_key,
            secret_key=settings.spaces_secret_key,
        )
    return _store


def reset_blob_store() -> None:
    """Test helper to clear the cached store."""
    global _store
    _store = None
