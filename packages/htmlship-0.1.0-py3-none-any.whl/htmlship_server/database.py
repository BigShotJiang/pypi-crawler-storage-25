from __future__ import annotations

from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from .config import get_settings

_settings = get_settings()


def _build_engine(url: str):
    kwargs: dict = {"echo": False}
    if "sqlite" not in url:
        kwargs.update(pool_size=20, max_overflow=10, pool_pre_ping=True)
    return create_async_engine(url, **kwargs)


engine = _build_engine(_settings.database_url)

SessionLocal = async_sessionmaker(
    engine,
    expire_on_commit=False,
    class_=AsyncSession,
)


async def get_session() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
