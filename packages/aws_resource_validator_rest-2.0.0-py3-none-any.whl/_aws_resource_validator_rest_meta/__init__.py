"""Metapackage marker for aws-resource-validator-rest."""
