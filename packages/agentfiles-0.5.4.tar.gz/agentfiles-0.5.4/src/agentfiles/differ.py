"""Compare source items with installed items and classify differences.

The :class:`Differ` uses a :class:`~agentfiles.target.TargetManager` to inspect
what is currently installed on each target platform, then compares filesystem
metadata against the source repository to produce
:class:`~agentfiles.models.DiffEntry` objects.

**Comparison strategy** — each item is evaluated through a two-stage pipeline:

1. **Installation check** — query ``TargetManager.is_item_installed`` to
   determine whether the item exists at all on the target platform.
   Missing items are classified as :attr:`~agentfiles.models.DiffStatus.NEW`
   immediately.

2. **Metadata comparison** — compare lightweight filesystem metadata (file
   size for files; file count and total byte size for directories).  When
   metadata differs the item is classified as
   :attr:`~agentfiles.models.DiffStatus.UPDATED`; otherwise it is
   :attr:`~agentfiles.models.DiffStatus.UNCHANGED`.

**Content diff** — when verbose output is requested,
:func:`compute_content_diff` reads both source and target file contents
and produces a unified diff using :func:`difflib.unified_diff`.  This is
only performed on-demand to avoid unnecessary I/O.

**Error resilience:**

* Individual item failures are caught and logged so that one broken item
  does not prevent the rest from being diffed.
* Permission errors, vanished files, and I/O failures produce meaningful
  :class:`~agentfiles.models.DiffEntry` objects rather than raising.
"""

from __future__ import annotations

import contextlib
import difflib
import logging
import os
from pathlib import Path

from agentfiles.models import (
    AgentfilesError,
    DiffEntry,
    DiffStatus,
    Item,
    TargetError,
)
from agentfiles.paths import get_item_dest_path, read_item_content
from agentfiles.target import TargetManager

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _resolve_target_path(
    item: Item,
    target_manager: TargetManager,
) -> Path | None:
    """Resolve the on-disk path for *item* on the target platform.

    Returns ``None`` when the platform has not been discovered or does
    not support the item's type.
    """
    try:
        target_dir = target_manager.get_target_dir(item.item_type)
    except TargetError:
        return None
    if target_dir is None:
        return None
    return get_item_dest_path(target_dir, item)


def _dir_stats(path: Path) -> tuple[int, int]:
    """Return (file_count, total_bytes) for a directory in one walk.

    Returns ``-1, -1`` when the stats cannot be determined or *path* is
    not a directory.
    """
    if not path.is_dir():
        return -1, -1
    count = 0
    total = 0
    try:
        for root, _dirs, files in os.walk(path):
            for fname in files:
                with contextlib.suppress(OSError):
                    total += os.path.getsize(Path(root) / fname)
                count += 1
    except OSError:
        return -1, -1
    return count, total


# ---------------------------------------------------------------------------
# Differ class
# ---------------------------------------------------------------------------


class Differ:
    """Compares source items with installed items on target platforms.

    For each source :class:`~agentfiles.models.Item`, classifies the installed
    state as one of:

    * :attr:`~agentfiles.models.DiffStatus.NEW`        — not present at target.
    * :attr:`~agentfiles.models.DiffStatus.UPDATED`    — present but metadata
      differs from source.
    * :attr:`~agentfiles.models.DiffStatus.UNCHANGED`  — present and metadata
      matches source.

    The comparison uses a two-stage strategy (see module docstring) that
    avoids expensive I/O by using lightweight metadata checks.

    Errors during comparison (permission denied, vanished files, I/O
    failures) are caught per-item so that a single failure does not abort
    the entire diff operation.

    Args:
        target_manager: Provides access to discovered platform targets.

    """

    def __init__(self, target_manager: TargetManager) -> None:
        """Initialise the Differ with a target manager."""
        self._target_manager = target_manager
        logger.debug("Differ initialised")

    def diff(self, items: list[Item]) -> list[DiffEntry]:
        """Compare source items against installed items.

        For every item, classifies the difference:

        * **NEW** — not installed at target.
        * **UPDATED** — installed but metadata differs from source.
        * **UNCHANGED** — installed and metadata matches.

        Args:
            items: Source items to compare.

        Returns:
            Flat list of :class:`DiffEntry` objects.

        """
        results: list[DiffEntry] = []

        for item in items:
            try:
                entry = self._compare_item(item)
                results.append(entry)
            except (AgentfilesError, OSError):
                logger.warning(
                    "Failed to diff item %s, skipping",
                    item.name,
                    exc_info=True,
                )

        logger.info("Diff complete: %d items", len(items))
        return results

    # -- private helpers --------------------------------------------------

    def _compare_item(self, item: Item) -> DiffEntry:
        """Classify the difference for a single item.

        Two-stage comparison:
        1. Installation check — not installed → NEW.
        2. Metadata check — size/count differs → UPDATED, otherwise → UNCHANGED.
        """
        # Stage 1: installation check — not installed → NEW.
        is_installed = self._target_manager.is_item_installed(item)

        if not is_installed:
            return DiffEntry(
                item=item,
                status=DiffStatus.NEW,
                details="not installed at target",
            )

        # Stage 2: metadata comparison — if metadata differs, mark as UPDATED.
        if self._metadata_differs(item):
            return DiffEntry(
                item=item,
                status=DiffStatus.UPDATED,
                details="size differs",
            )

        # Metadata matches — consider unchanged.
        return DiffEntry(
            item=item,
            status=DiffStatus.UNCHANGED,
            details="metadata matches",
        )

    def _metadata_differs(self, item: Item) -> bool:
        """Conservative metadata check: returns True only when metadata clearly differs.

        File items compare st_size; directory items compare file count then total bytes.
        Returns False when metadata is unavailable (permissions, missing files).
        """
        target_path = _resolve_target_path(
            item,
            self._target_manager,
        )
        if target_path is None:
            return False

        source_path = item.source_path

        # File-based items: compare file sizes directly.
        if source_path.is_file():
            if not target_path.is_file():
                return True
            try:
                return source_path.stat().st_size != target_path.stat().st_size
            except PermissionError:
                logger.warning(
                    "Permission denied comparing metadata for %s",
                    item.name,
                    exc_info=True,
                )
                return False
            except OSError:
                return False

        # Directory-based items: compare file counts then total sizes.
        if source_path.is_dir() and target_path.is_dir():
            src_count, src_size = _dir_stats(source_path)
            tgt_count, tgt_size = _dir_stats(target_path)

            if src_count >= 0 and tgt_count >= 0 and src_count != tgt_count:
                return True

            if src_size >= 0 and tgt_size >= 0 and src_size != tgt_size:
                return True

        return False


# ---------------------------------------------------------------------------
# Content diff — unified diff between source and target file contents
# ---------------------------------------------------------------------------

# Number of context lines to include around changes in unified diff output.
_UNIFIED_DIFF_CONTEXT_LINES = 3


def compute_content_diff(
    entry: DiffEntry,
    target_manager: TargetManager,
) -> list[str]:
    """Compute a unified diff between source and target file contents.

    Reads the primary content file for both source and target items and
    produces a unified diff using :func:`difflib.unified_diff`.  Binary
    files and unreadable paths are handled gracefully.

    This function performs I/O and should only be called when verbose
    diff output is needed (``--verbose`` flag).

    Args:
        entry: The :class:`~agentfiles.models.DiffEntry` whose content to diff.
        target_manager: Provides access to target filesystem paths.

    Returns:
        A list of unified diff lines (without trailing newlines).
        Returns an empty list when both contents are identical or
        when the diff cannot be computed.

    """
    source_result = _read_content_safe(entry.item.source_path)

    target_path = _resolve_target_path(
        entry.item,
        target_manager,
    )
    if target_path is None:
        logger.debug(
            "No target path for %s, skipping content diff",
            entry.item.name,
        )
        return []

    target_result = _read_content_safe(target_path)

    if source_result is None or target_result is None:
        logger.debug(
            "Cannot read content for %s (source=%s, target=%s)",
            entry.item.name,
            "ok" if source_result else "unreadable",
            "ok" if target_result else "unreadable",
        )
        return []

    source_content, source_file = source_result
    target_content, target_file = target_result

    # Detect binary content by checking for null bytes in the first chunk.
    if _is_binary_content(source_content) or _is_binary_content(target_content):
        return ["  (binary file, content diff skipped)"]

    source_lines = source_content.splitlines(keepends=True)
    target_lines = target_content.splitlines(keepends=True)

    # Produce diff as "old → new" convention:
    # fromfile = installed (target/old), tofile = source (new).
    diff_lines = list(
        difflib.unified_diff(
            target_lines,
            source_lines,
            fromfile=str(target_file),
            tofile=str(source_file),
            n=_UNIFIED_DIFF_CONTEXT_LINES,
        )
    )

    # Strip trailing newlines from each line for consistent output formatting.
    return [line.rstrip("\n") for line in diff_lines]


def _read_content_safe(path: Path) -> tuple[str, Path] | None:
    """Read content from a path, returning None on any I/O failure."""
    try:
        return read_item_content(path)
    except (OSError, UnicodeDecodeError):
        logger.debug("Failed to read content from %s", path, exc_info=True)
        return None


def _is_binary_content(content: str, sample_size: int = 8192) -> bool:
    """Return True if *content* appears to be binary data.

    Checks for null bytes in the first *sample_size* characters, which
    is a reliable heuristic for distinguishing text from binary files.
    """
    return "\x00" in content[:sample_size]
