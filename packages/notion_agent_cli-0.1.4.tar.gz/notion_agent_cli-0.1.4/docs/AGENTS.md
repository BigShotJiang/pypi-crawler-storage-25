# Using notion-agent-cli from an AI agent

This is the integration cheat-sheet for **any AI agent runtime**
(Claude Code, Codex, Gemini, openclaw, your own orchestrator) that
wants to call the operator's Notion workspace via this CLI.

The CLI is the tool. The skill at `.claude/skills/notion-agent/` is
just a SystemPrompt bundle that auto-loads inside Claude Code. **The
agent always shells out to `notion-agent`.**

## When to use the skill vs. the raw CLI

| Runtime | Load mode | Why |
|---|---|---|
| **Claude Code** (this repo or a downstream that has the skill installed) | Skill auto-loads via `.claude/skills/notion-agent/SKILL.md`. Nothing else to do. | Frontmatter trigger phrases ("ask Jarvis", "Notion AI", "via the chat panel") inject this doc's content on demand. |
| **Anything else** (Codex / Gemini / openclaw / custom) | Paste the **Agent prompt** at the bottom of this file into the system prompt, then expose `notion-agent` on `$PATH`. | These runtimes don't read `SKILL.md`. Hand them the rules directly. |
| **HTTP-only orchestrator** (n8n, webhooks, Go services) | `notion-agent serve` → call `POST /chat`. | Pure shell-out is the wrong shape for these; the FastAPI wrapper exposes the same surface over JSON / SSE. |

Recommendation: **default to the CLI**. The skill is a convenience for
Claude Code users; the CLI is what does the work and it's the only
surface that's portable across agent runtimes.

## Preflight (run once per session)

```bash
notion-agent doctor --json
```

Returns a list of `{status, check, detail}` entries. The agent should
parse it and treat any `"status":"fail"` as a blocker. Typical green
output (6 checks; `info` on the last one is normal — it just means
no user-supplied model alias map):

```json
[
  {"status":"ok",   "check":"account file readable",     "detail":"/Users/.../notion_account.json"},
  {"status":"ok",   "check":"required fields present",    "detail":"user=...  space='TP-Link' (...)"},
  {"status":"ok",   "check":"custom-agent binding",       "detail":"'Jarvis'  page=..."},
  {"status":"ok",   "check":"token_v2 accepted by /loadUserContent","detail":""},
  {"status":"ok",   "check":"bound space_id present in workspaces","detail":"2 workspaces total"},
  {"status":"info", "check":"user model map",             "detail":"(none — falls back to DEFAULT_MODEL_MAP in models.py)"}
]
```

Failure modes the agent will actually see:

- `account_missing` — file at `~/.notionagents/notion_account.json` is
  absent. Tell the operator: "run `notion-agent init --token-v2
  <your-token>`" — the token_v2 cookie value alone is enough; the CLI
  auto-derives user_id from `/loadUserContent`. The agent must **not**
  paste or construct the token itself. **Strongly recommend the stdin
  path** to keep the token out of shell history / `ps` output:
  `notion-agent init --token-v2 -` (the CLI then reads the token from
  stdin), or `pbpaste | notion-agent init --cookie -` if they have a
  full `document.cookie` on the clipboard.
- `auth_invalid` — `token_v2` cookie expired. Ask the operator to
  re-run `init` with a fresh token. **Don't retry.**

If the operator has **multiple Notion workspaces**, the first
`init` will exit with code 3 and print "Multiple workspaces available
— re-run with --space-name or --space-domain", a list of workspaces,
and a ready-to-copy `Try:` line. Forward that to the operator and ask
which workspace to bind; the rerun command will look like
`notion-agent init --token-v2 <value> --space-name "TP-Link"`.

If the operator wants to bind a **Custom Agent** (Jarvis-style):

- `notion-agent agents list --json` lists the workspace's agents,
  including a `name` field resolved from each agent's Notion `bot`
  record (Custom Agents live in the `bot` table, not as pages).
- **Important**: the `agent_id` returned by `agents list` is **not**
  the same as `--agent-page-id`. `agent_id` is the bot record UUID;
  `--agent-page-id` is the agent's persistent_instructions_page UUID,
  which is a separate Notion page where the agent's prompt lives.
  The two values live in different UUID spaces. To get the
  `agent_page_id`, the operator must open the agent in Notion, click
  its instructions page, and copy the page UUID from the URL —
  the CLI cannot derive it from `agent_id` yet (pending more captures
  to confirm the mapping field across `bot.type` variants).
- Passing only `--agent-name "Jarvis"` (without `--agent-page-id`)
  will **not** create a binding — the CLI prints a warning and falls
  back to default ✦ AI. There is no server-side name → agent_page_id
  lookup, so the page id is the source of truth.

## Calling pattern

All subcommands accept `--account PATH` to point at a non-default
credential file (useful if the operator runs multiple profiles).

### `chat` — one-shot

```bash
notion-agent chat "<prompt>" --json
```

Output:

```json
{
  "text": "在，贾维斯就位 🐲",
  "model": "apricot-sorbet-high",
  "model_alias": "opus-4.7",
  "thread_id": "a374fbd9-6b49-4d32-b40b-919f40d5d016",
  "surface": "custom_agent",
  "agent_name": "Jarvis",
  "usage": {"input_tokens": 37090, "output_tokens": 18, "cache_read": 36760, "cache_creation": 19986},
  "thinking_chars": 0
}
```

`model_alias` is the human-readable friendly form of `model` (Notion
rotates the internal id strings). `surface` is `"custom_agent"` when
the bound Jarvis-style binding is active, `"default_chat"` otherwise —
agents can use this to confirm which persona answered. Both fields
may be `null` when the alias is unknown (post-Notion rotation, before
`models refresh`) or the binding is unset.

Flags worth knowing:

- `--system "..."` — system prompt injected as Notion's `system` block.
- `--model <alias>` — alias from `notion-agent models refresh` (e.g.
  `opus-4.7`, `sonnet-4.6`). Default: `opus-4.7`.
- `--ask-mode` — Notion's "Ask" mode (vs default chat) for terse
  workspace-search answers.
- `--no-web-search` / `--no-workspace-search` — narrow the tool scope.
- `--stream` — text deltas to stdout (for `tty`); the final exit
  prints nothing extra.
- `--ndjson` — raw protocol events (see below).

Save `thread_id` if you intend to do a follow-up.

### `chat` — continuation

```bash
notion-agent chat --thread-id <thread_id> "<follow-up>" --json
```

Constraints:

- Model is **locked** to whatever turn 1 chose; `--model` on a
  continuation is silently ignored.
- State lives at `~/.notionagents/threads/<thread_id>.json`. If the
  agent loses the id, the thread is unreachable from the CLI (it's
  still visible inside Notion's chat panel — humans can resume there).
- Errors with `[thread_state_missing]` if the state file is gone;
  drop `--thread-id` and start a fresh thread.

### `chat --ndjson` — raw stream (advanced)

Emits the same NDJSON Notion's chat panel consumes. Each line is one
JSON object; first event is `patch-start`, last is `record-map`,
everything in between is `patch` ops. Use only if the agent needs to
react to incremental tool calls / thinking — `--json` is enough for
99% of cases.

### `agents list` / `threads list`

```bash
notion-agent agents  list --json --limit 10
notion-agent threads list --json --limit 10
notion-agent threads list --json --agent <agent_id>
```

`agents list` returns `{agent_id, name, activity_score, most_recent_thread_id, most_recent_thread_title}` per row. `name` is resolved
via an extra `syncRecordValuesMain` round-trip on table `bot` (the
internal record type for Custom Agents); pass `--no-names` to skip
it when you only need the ids. **Note**: `agent_id` is the bot record
UUID, not the persistent_instructions_page UUID that `--agent-page-id`
needs — these live in different UUID spaces. `threads list` returns
`{thread_id, title, parent_agent_id, created_at_ms, updated_at_ms, created_by_id, created_source}`.

### `models refresh`

```bash
notion-agent models refresh --json
```

Returns the current alias → Notion-internal id map. Run this once a
month or when an agent sees `Notion rejected model 'apricot-...'`.

### `serve`

For HTTP-only callers — same surface, JSON over HTTP. See README's
"Local HTTP server" section. `POST /chat {prompt, stream?:bool,
thread_id?:str, model?:str, system?:str}` returns the same shape as
`chat --json` (or SSE `data: {...}\n\ndata: [DONE]` if `stream:true`).

## Error handling

The CLI exits non-zero on errors and writes one error line to stderr
in the form `[code] message`. With `--json`, the error is on stdout
as `{"code":"...","message":"..."}` and exit is still non-zero.

| `code` | What happened | Agent action |
|---|---|---|
| `account_missing` | No credential file | Ask operator to run `init`; don't proceed |
| `account_invalid` | File present, fields broken | Ask operator to re-run `init`; don't proceed |
| `auth_invalid` | 401/403 — token expired | Ask operator to re-run `init`; **do not retry** |
| `thread_state_missing` | `--thread-id` passed but no state | Drop the flag, start fresh |
| `premium_required` | Notion premium-only feature gated | Tell the operator; stop |
| `empty_text` | 200 but empty reply | Retry **once**; if still empty, surface to operator |
| `http_error` | Non-200 from Notion | Retry **once** with backoff; then surface |
| `transport` | Network failure | Retry **once** with backoff; then surface |
| `invalid_callback` | Programming error (lib only) | Bug — report it |

Don't loop on retries — Notion's quota is the operator's quota.

## Safety rules

These are non-negotiable for any agent calling this CLI:

1. **Never paste or fabricate a `token_v2`** — even if the operator
   asks. The CLI's `init` handles it. If the operator gives you a
   token in chat, treat it as sensitive: don't echo, don't log, don't
   commit. Prefer the stdin path so the value never reaches argv /
   shell history: `notion-agent init --token-v2 -` (then pipe the
   token in), or `pbpaste | notion-agent init --cookie -` for a full
   `document.cookie`. Argv form (`--token-v2 <value>`) works but is
   the less safe path — the value lands in shell history and `ps`.
2. **Don't write to `~/.notionagents/`** directly — the CLI owns it.
   That means: no manual edits to `notion_account.json`, no manual
   thread-state surgery, no hand-rolled `models.json`. Use the
   subcommands.
3. **Budget your chat calls.** Each `chat` is a real Notion API hit
   that consumes the operator's quota. For a single task, 1–3 calls
   is usually right. Before issuing > 3, ask.
4. **Don't auto-retry past once.** Notion's transient failures are
   real but rare; aggressive retries burn quota for no signal.
5. **Surface — don't hide — errors.** If `doctor` is red, stop and
   tell the operator. Don't try to "work around" auth failures.

## Thread continuation semantics (the only subtle bit)

A Notion thread = one `chat-panel` conversation, identified by a UUID.
The model is **locked at turn 1**. The CLI persists everything needed
for a follow-up turn under `~/.notionagents/threads/<uuid>.json`. The
agent's responsibility is only to:

- Decide when a follow-up logically belongs in the same thread (vs.
  starting a fresh one). A new user goal = new thread; iterating on a
  draft = same thread.
- Pass `--thread-id` correctly. Don't pass it on turn 1.

If the operator wants to see the conversation in Notion's UI, every
thread the CLI opens is visible in the ✦ AI chat panel under the
bound Custom Agent persona — same `thread_id`, same messages.

## When NOT to call this CLI

- General programming, world knowledge, math, code review —
  answer those directly. The Notion call has no advantage and costs
  the operator quota.
- Anything that doesn't need the operator's **workspace context** or
  the operator's **bound Custom Agent**. The whole point of routing
  through Notion is workspace awareness; without it, you're just
  paying for a slower path to a generic LLM.

## Agent prompt (drop-in for any non-Claude-Code agent)

Paste the section below verbatim into the agent's system prompt
(adjust the persona name if the operator's Custom Agent isn't
"Jarvis"). It's self-contained — the agent doesn't need to read the
rest of the repo to use the CLI safely.

````text
You have access to `notion-agent`, a CLI that talks to the operator's
Notion workspace via their bound Custom Agent. Use it when the answer
depends on the operator's Notion notes, their Custom Agent's
instructions, or when the operator wants the conversation to surface
inside Notion's chat panel. Otherwise, answer directly — the CLI
costs the operator API quota.

Preflight before the first call: `notion-agent doctor --json`. Treat
any `"status":"fail"` as a blocker and tell the operator.

Main commands:

- `notion-agent chat "<prompt>" --json` — one-shot. Returns
  `{text, model, model_alias, thread_id, surface, agent_name, usage,
  thinking_chars}`. `model_alias` is the friendly form of `model`;
  `surface` is `"custom_agent"` / `"default_chat"`. Save `thread_id`
  for follow-ups.
- `notion-agent chat --thread-id <id> "<prompt>" --json` — continue an
  existing thread. Model is locked to turn 1; don't pass `--model`.
- `notion-agent agents list --json` — list Custom Agents. Each row
  has `{agent_id, name, ...}`; pass `--no-names` to skip the extra
  name-resolution request.
- `notion-agent threads list --json --limit 10` — list recent threads.
- `notion-agent models refresh --json` — refresh the alias→model id
  map when Notion rotates model ids.

Error codes (read from `{"code":"..."}` on stderr/stdout):
`account_missing` / `account_invalid` / `auth_invalid` →
ask the operator to run `notion-agent init`; do **not** retry.
`thread_state_missing` → drop `--thread-id` and start fresh.
`empty_text` / `http_error` / `transport` → retry once with backoff,
then surface.

Hard rules:
1. Never paste, log, or fabricate a `token_v2` cookie. Prefer the
   stdin path on init (`--token-v2 -` or `--cookie -`) so the value
   never reaches argv / shell history.
2. Never edit `~/.notionagents/` files by hand — use the subcommands.
3. Budget ≤ 3 `chat` calls per operator task without asking.
4. Don't auto-retry past once. Notion's quota is the operator's.
5. Surface auth / quota errors immediately; never silently degrade.

Onboarding gotchas:
- Multiple workspaces → first `init` exits with code 3, lists the
  workspaces, and prints a ready-to-copy `Try:` line. Ask the
  operator which workspace to bind; rerun with `--space-name`.
- Custom Agent binding requires `--agent-page-id <uuid>`, not just
  `--agent-name` — the CLI does not resolve names server-side.
  Use `agents list --json` to pick the right `agent_id`.

Thread semantics: one Notion thread = one chat-panel conversation,
locked to turn-1's model. New user goal = new thread; iterating on the
same draft = same thread.
````

That's the minimum an agent needs to use this CLI safely. For deeper
context (protocol, architecture, roadmap) point them at
`docs/01-notion-chat-protocol.md`, `docs/02-architecture.md`, and
`docs/STATUS.md`.
