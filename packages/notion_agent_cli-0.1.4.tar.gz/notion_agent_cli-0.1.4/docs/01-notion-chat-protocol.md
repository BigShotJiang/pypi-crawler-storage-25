# 05 — Notion ✦ AI Chat Panel 抓包归档（M4 反向工程基线）

> 抓包来源：Lucien Chen 在 `https://www.notion.so/ai` 唤起 ✦ AI 输入「你好，Jarvis，报告你现在的情况。」
> 抓包时间：2026-05-15 22:17 PT
> 工作区：TP-Link（space_id `883c77cc-e7d8-4103-84a8-13ba401a991c`）
> 浏览器：Chrome 146 / macOS / `notion-client-version: 23.13.20260516.0113`
>
> 敏感值已脱敏（token_v2 / sync_session / cf_bm / hashids 类只留前后若干字符）。
> 真实凭据放在 `~/.notionagents/notion_account.json`，不提交 git。

## 0. 关键判断（修正 m4-handoff §1）

m4-handoff §1 推断「notion_manager 的 thread 不出现在 chat panel = `threadType:"workflow"` + space parent pointer」**与抓包不符**：

- 抓包真实 chat panel 也用 `threadType: "workflow"` + `threadParentPointer.table: "space"`
- 真正的差异在 **context 块的 agentName / agentAccessory / context_page_id 三连**：把 thread 绑到一个 `persistent_instructions_page`（这里是 Jarvis 的 instructions 页），让对话被归到一个 custom agent persona 名下，chat panel 据此聚合显示
- 另一处差异：`asPatchResponse: true`（notion_manager 用 `false`）；这只影响响应编码（patch ops vs 累积 agent-inference），不影响线程是否可见

我们的 MVP 决策（见 m4-handoff §6 + 用户确认）：
- **绑定 Jarvis**（agentName/agent_context_page_id 从 `notion_account.json` 取）
- **`asPatchResponse: true`**（精准 mirror 抓包，避免出现「跑得通但 chat panel 看不见」的隐患）

---

## 1. Request — first user message（`createThread=true`）

### 1.1 URL / method

```
POST https://www.notion.so/api/v3/runInferenceTranscript
```

### 1.2 Request headers（关键项）

```http
:authority: www.notion.so
accept: application/x-ndjson
accept-encoding: gzip, deflate, br, zstd
accept-language: zh-CN,zh;q=0.9
content-type: application/json
notion-audit-log-platform: web
notion-client-version: 23.13.20260516.0113
origin: https://www.notion.so
priority: u=1, i
referer: https://www.notion.so/ai
sec-ch-ua: "Not-A.Brand";v="24", "Chromium";v="146"
sec-ch-ua-mobile: ?0
sec-ch-ua-platform: "macOS"
sec-fetch-dest: empty
sec-fetch-mode: cors
sec-fetch-site: same-origin
user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36
x-notion-active-user-header: 3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2
x-notion-space-id: 883c77cc-e7d8-4103-84a8-13ba401a991c
cookie: <见 §1.3 全集>
sentry-trace: <每请求不同，可不复刻>
baggage: <Sentry 注入；可不复刻>
```

非关键头（可省）：sentry-trace、baggage、priority。

### 1.3 Cookie 全集（脱敏）

```
notion_browser_id=8f74fbbe-2dfb-4c21-b948-40f9d4d553be
device_id=21ed872b-594c-81c4-b151-003bad94ecc7
notion_user_id=3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2
notion_users=[%223f4b90ff-b3eb-4e34-b080-0b45a23f4fa2%22]
notion_check_cookie_consent=false
notion_locale=en-US/user_choice
notion_cookie_sync_completed=%7B%22completed%22%3Atrue%2C%22version%22%3A4%2C%22attempts%22%3A1%7D
_cioid=3f4b90ffb3eb4e34b0800b45a23f4fa2
token_v2=v03%3AeyJhbGci…[REDACTED ~700 chars]…ckIZls    # ← 真正的登录凭据
p_sync_session=%7B%22tokenId%22%3A%22v02%3Async_session%3A[REDACTED]…
__cf_bm=[REDACTED]                  # Cloudflare bot mitigation；服务端会自动 refresh
_cfuvid=[REDACTED]                  # 同上
# 还有一堆 GA / Hotjar / Amplitude / __ps_* 等分析 cookie，对 API 调用不必须
```

**MVP 实际需要的 cookie 子集**（验证后可裁剪）：

```
token_v2=<…>                      # 必须；登录凭据
notion_browser_id=<uuid>          # 必须；浏览器指纹
device_id=<uuid>                  # 推荐；设备指纹
notion_user_id=<uuid>             # 推荐
notion_users=[%22<user_id>%22]    # 推荐
notion_check_cookie_consent=false # 防止 SPA 重定向
```

`__cf_bm` 由 Cloudflare 在响应里 `Set-Cookie`，我们不需要主动塞——但要在长会话里复用 httpx 的 cookie jar 保持。

### 1.4 Request payload（核心）

```jsonc
{
  "traceId":  "<uuid>",
  "spaceId":  "883c77cc-e7d8-4103-84a8-13ba401a991c",
  "threadId": "<uuid>",
  "threadParentPointer": {
    "table":   "space",
    "id":      "883c77cc-e7d8-4103-84a8-13ba401a991c",
    "spaceId": "883c77cc-e7d8-4103-84a8-13ba401a991c"
  },
  "createThread":            true,
  "isPartialTranscript":     false,
  "generateTitle":           true,
  "saveAllThreadOperations": true,
  "setUnreadState":          true,
  "threadType":              "workflow",
  "asPatchResponse":         true,
  "hasHeartbeat":            false,
  "createdSource":           "ai_module",
  "isUserInAnySalesAssistedSpace": false,
  "isSpaceSalesAssisted":         false,
  "debugOverrides": {
    "emitAgentSearchExtractedResults": true,
    "cachedInferences":     {},
    "annotationInferences": {},
    "emitInferences":       false
  },
  "transcript": [
    /* §1.5 三条 */
  ]
}
```

注意：m4-handoff §2 的"notion_manager 当前发的 payload"示例**漏掉了 `setUnreadState: true / hasHeartbeat / createdSource / isUserInAnySalesAssistedSpace / isSpaceSalesAssisted`** 等顶层字段。抓包确认 chat panel 用 `setUnreadState: true`，而 notion_manager 用 `false`——这一项可能也是 chat panel 显示与否的相关因素。我们 MVP 跟抓包走 `true`。

### 1.5 Transcript 三条

**[0] config**（id 为本次请求随机生成的 uuid）：

```jsonc
{
  "id":   "36215375-830d-808c-a947-00aabf9dff98",
  "type": "config",
  "value": {
    "type": "workflow",
    "enableAgentAutomations":         true,
    "enableAgentIntegrations":        true,
    "enableCustomAgents":             true,
    "enableExperimentalIntegrations": false,
    "enableAgentDiffs":               true,
    "enableAgentUpdatePagePatch":     true,
    "enableCsvAttachmentSupport":     true,
    "enableDatabaseAgents":           true,
    "showDatabaseAgentsDiscoverability": true,
    "enableAgentThreadTools":         false,
    "enableCrdtOperations":           false,
    "enableAgentCardCustomization":   true,
    "enableSystemPromptAsPage":       false,
    "enableUserSessionContext":       false,
    "enableLargeToolResultComputerOffload": false,
    "enableScriptAgentAdvanced":      false,
    "enableScriptAgent":              true,
    "enableScriptAgentSearchConnectorsInCustomAgent": false,
    "enableScriptAgentGoogleDriveInCustomAgent":      false,
    "enableScriptAgentGoogleDriveOAuthInCustomAgent": false,
    "enableScriptAgentSlack":         true,
    "enableScriptAgentMcpServers":    false,
    "enableScriptAgentMail":          true,
    "enableScriptAgentCustomToolCalling": true,
    "enableComputer":                 false,
    "enableCreateAndRunThread":       true,
    "enableSoftwareFactoryPage":      false,
    "enableAgentGenerateImage":       true,
    "enableSpeculativeSearch":        false,
    "enableQueryCalendar":            false,
    "enableQueryMail":                false,
    "enableMailExplicitToolCalls":    true,
    "enableMailNotificationPreferences": false,
    "enableMailAgentMultiProviderSupport": false,
    "useRulePrioritization":          true,
    "availableConnectors":            ["notion-calendar"],
    "customConnectorInfo":            [],
    "searchScopes":                   [{"type": "everything"}],
    "useSearchToolV2":                false,
    "useWebSearch":                   true,
    "isHipaa":                        false,
    "yoloMode":                       false,
    "useReadOnlyMode":                false,
    "writerMode":                     false,
    "model":                          "apricot-sorbet-high",
    "modelFromUser":                  true,
    "isCustomAgent":                  false,
    "isCustomAgentBuilder":           false,
    "isAgentResearchRequest":         false,
    "useCustomAgentDraft":            false,
    "use_draft_actor_pointer":        false,
    "enableUpdatePageAutofixer":      true,
    "enableMarkdownVNext":            false,
    "updatePageStaleViewGuardEnabled": false,
    "enableUpdatePageOrderUpdates":   true,
    "enableAgentSupportPropertyReorder": true,
    "agentShortUpdatePageResult":     true,
    "enableAgentAskSurvey":           true,
    "databaseAgentConfigMode":        false,
    "isOnboardingAgent":              false,
    "isMobile":                       false
  }
}
```

**模型 ID `apricot-sorbet-high`** ≠ notion_manager Go 端 `DefaultModelMap` 里任意一项。猜测：
- `apricot-sorbet-high` = Claude Opus 4.7 high reasoning（用户在 chat panel 显式选的模型）
- notion_manager 的 `avocado-froyo-medium` 是旧 opus-4.6 别名

需要在 `notion_models.py` 里把这个新 id 加进去；后续可以加一个 `getAvailableModels` 调用动态拉。

**[1] context**：

```jsonc
{
  "id":   "36215375-830d-800b-b774-00aaef1e281c",
  "type": "context",
  "value": {
    "timezone":         "America/Los_Angeles",
    "userName":         "Lucien Chen",
    "userId":           "3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2",
    "userEmail":        "lucien.chen@tp-link.com",
    "spaceName":        "TP-Link",
    "spaceId":          "883c77cc-e7d8-4103-84a8-13ba401a991c",
    "spaceViewId":      "19c15375-830d-81cc-b1cd-0006dd8181df",
    "currentDatetime":  "2026-05-15T22:17:16.188-07:00",
    "surface":          "ai_module",
    "agentName":        "Jarvis",             // ← 关键：custom agent persona 绑定
    "agentAccessory":   "cat",                // ← 头像装饰；UI only
    "context_page_id":  "2e115375-830d-8184-bf4d-f427d847c6bc"  // ← Jarvis 的 persistent_instructions_page
  }
}
```

**[2] user message**：

```jsonc
{
  "id":        "36215375-830d-8036-a32f-00aae60bf2da",
  "type":      "user",
  "value":     [["你好，Jarvis，报告你现在的情况。"]],
  "userId":    "3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2",
  "createdAt": "2026-05-15T22:17:16.187-07:00"
}
```

注意 `value` 是 `[[string]]` 双层数组——内层每个 string 是一段 markdown，外层每个 list 是一条 user turn（通常只有一个）。

---

## 2. Response（NDJSON stream，`asPatchResponse: true` 模式）

### 2.1 Stream 结构

`Accept: application/x-ndjson` → 服务器逐行返回 JSON 事件。压缩按 `Accept-Encoding` 协商（这次 Chrome 给 `gzip, deflate, br, zstd` → 大概率 `br` 或 `zstd`）。

### 2.2 关键事件类型（已截取部分）

**`patch-start`**：thread 元数据初始化（title 占位等）：

```jsonc
{
  "type": "patch-start",
  "data": {
    "s": [
      {
        "id":   "<title-block-id>",
        "type": "title",
        "value": "向Jarvis报告情况",   // ← generateTitle=true 自动产
        "icon":  "/icons/chat_lightgray.svg"
      }
    ]
  },
  "version": 1
}
```

**`patch`**：jsonpatch 风格的增量更新；op + path + value：

```jsonc
{
  "type": "patch",
  "v": [
    {
      "o": "a",                            // operation: a=add, x=append, p=replace
      "p": "/s/-",                          // path: /s/- = append to s array
      "v": {                                // value
        "id":     "<state-block-id>",
        "type":   "agent-instruction-state",
        "owner":  "regular",
        "root":   {"type": "page", "pageId": "2e115375-830d-8184-bf4d-f427d847c6bc"},
        "sources": [
          {"kind": "persistent_instructions_page", "pageId": "2e115375-830d-8184-bf4d-f427d847c6bc"}
        ],
        "selectedSkillPageIds": [],
        "trackedInstructionTreePages": [
          {"pageId": "1fac93e1-...", "version": 123, "lastEditedTime": 1774391801145, "alive": true}
        ]
      }
    }
    // ... 后续会出现 agent-inference 类的 patch，path 形如 /s/N/value/M/content
    // op=x 时是 append text；op=p 时是 replace text 段
  ]
}
```

### 2.3 我们 parser 必须处理的事件子集（MVP）

| 事件 type | 用途 | 我们的处理 |
|---|---|---|
| `patch-start` | 初始化 `s[]`（title 等） | 忽略（不影响 text/token） |
| `patch` op=`a` path 含 `/value/-` type=`agent-inference` 子 entry | 追加新 value 段 | 用 path 注册 entry 类型（thinking/text/tool_use） |
| `patch` op=`x` path 末段 `/content` | text/thinking 增量追加 | 按 entry 类型分流；text 累入 raw，thinking 增量上报（MVP 可丢弃） |
| `patch` op=`p` path 末段 `/content` | text/thinking 整段替换 | text 走 `handle_patch_replace` 逻辑 |
| `patch` op=`a` path 末段 `/inputTokens` | usage | 累入 prompt_tokens |
| `patch` op=`a` path 末段 `/outputTokens` | usage | 累入 completion_tokens |
| `patch` op=`a` path 末段 `/signature` | thinking signature | MVP 可丢弃 |
| `patch` op=`a` path 末段 `/finishedAt` | step 收官 | 触发 final emit |
| `error` | 服务端错误 | 抛 `LLMCallError(message)` |
| `premium-feature-unavailable` | premium 限制 | 抛 `LLMCallError("premium feature unavailable")` |
| 其他 | 工具调用 / 引用元数据 / etc | MVP 忽略 |

参考实现：`~/Documents/notion_manager/internal/proxy/notion.go:2638-2731` `case "patch":`。

---

## 3. 字段对照表 — chat panel 抓包 vs notion_manager Go vs 我们 MVP

| 字段（top-level） | chat panel 抓包 | notion_manager | MVP 决策 |
|---|---|---|---|
| `threadType` | `"workflow"` | `"workflow"` | `"workflow"` |
| `threadParentPointer.table` | `"space"` | `"space"` | `"space"` |
| `createThread` | `true`（首条） | `true`（首条） | `true` |
| `isPartialTranscript` | `false`（首条） | `false`（首条） | `false`（per-run-new-thread） |
| `generateTitle` | `true` | `true`（首条） | `true` |
| `saveAllThreadOperations` | `true` | `true` | `true` |
| `setUnreadState` | **`true`** | `false` | **`true`** ← 跟抓包 |
| `asPatchResponse` | **`true`** | `false` | **`true`** ← 跟抓包 |
| `hasHeartbeat` | `false` | 未发 | `false` |
| `createdSource` | `"ai_module"` | 未发 | `"ai_module"` |
| `isUserInAnySalesAssistedSpace` | `false` | 未发 | `false` |
| `isSpaceSalesAssisted` | `false` | 未发 | `false` |
| `debugOverrides.model` | 未发（model 在 config 块里） | 发 | **不发**（model 走 config 块） |
| `debugOverrides.emitInferences` | `false` | 未发 | `false` |

| 字段（context） | chat panel | notion_manager | MVP |
|---|---|---|---|
| `surface` | `"ai_module"` | `"ai_module"` | `"ai_module"` |
| `agentName` | `"Jarvis"` | 未发 | **从 account.json 取** |
| `agentAccessory` | `"cat"` | 未发 | **从 account.json 取** |
| `context_page_id` | `<Jarvis page id>` | 未发 | **从 account.json 取** |

| 字段（config）数量级 | chat panel | notion_manager | MVP |
|---|---|---|---|
| 顶层 enable* / use* / is* 字段 | ~50 | ~12 | **~50（直接抄抓包）** |

---

## 4. notion_account.json schema（MVP 实际形态）

```jsonc
{
  // === 凭据 ===
  "token_v2":       "v03:eyJhbG…",                        // 必须
  "full_cookie":    "token_v2=…; notion_browser_id=…; …", // 可选；若提供则覆盖单独字段拼出的 cookie

  // === 身份 ===
  "user_id":        "3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2",
  "user_name":      "Lucien Chen",
  "user_email":     "lucien.chen@tp-link.com",

  // === 工作区 ===
  "space_id":       "883c77cc-e7d8-4103-84a8-13ba401a991c",
  "space_name":     "TP-Link",
  "space_view_id":  "19c15375-830d-81cc-b1cd-0006dd8181df",

  // === 浏览器指纹 ===
  "browser_id":     "8f74fbbe-2dfb-4c21-b948-40f9d4d553be",
  "device_id":      "21ed872b-594c-81c4-b151-003bad94ecc7",
  "client_version": "23.13.20260516.0113",
  "user_agent":     "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 …",
  "timezone":       "America/Los_Angeles",

  // === Jarvis 绑定 ===（让对话出现在 chat panel）
  "agent_name":            "Jarvis",
  "agent_accessory":       "cat",
  "agent_context_page_id": "2e115375-830d-8184-bf4d-f427d847c6bc",

  // === 默认模型 ===
  "default_model":  "apricot-sorbet-high"    // 选用 chat panel 同款；可被 agents.yaml 覆盖
}
```

---

## 5. 还没回答的问题（留给后续 session）

1. **token_v2 续期机制**：抓包看不到 refresh 流程；Notion 应该是 JWT 长寿命（数月～数年），失效=用户重抽。需要在 401 时 emit `cookie_invalid` alert。
2. **模型 ID 漂移**：`apricot-sorbet-high` 这类内部 id 会定期改名（notion_manager 提供 `getAvailableModels` 拉取）。MVP 先 hard-code，加 `--refresh-models` 子命令是后续优化。
3. **per-agent-rolling thread 策略**：MVP 用 per-run-new-thread，每次新建 thread。如果用户反馈 chat panel 太刷屏，再加 `notion_threads` 表存滚动 thread id。
4. **续聊（isPartialTranscript=true）的 transcript 形态**：~~本抓包只有首条，没续聊样本~~。**已在 §6 解决** —— 2026-05-16 在 full_page_chat 视图里抓到了真实续聊请求。结论：`config_id` / `context_id` 复用 turn-1 的 uuid，`context.currentDatetime` 也复用 turn-1 的时间戳；`updated-config` 块的 `id` 是 **新生成的 uuid**（不是 config_id 重复），每过一轮 user/assistant 追加一条。详见 §6。
5. **__cf_bm 失效**：Cloudflare 会自动 `Set-Cookie` 续新；httpx 用 cookie jar 持久化即可。MVP 用 `httpx.AsyncClient` 长连接保持。

---

## 6. Continuation (isPartialTranscript=true) capture — 2026-05-16

> 抓包来源：同一 thread（turn 1 来自 §1 的 chat panel），turn 2 在
> `https://www.notion.so/<thread-id>` 全页视图里输入「你现在的状态如何？」
> 抓包时间：2026-05-16 01:18 PT（turn 1 是 2026-05-15 22:17 PT，间隔 ~3h）
> 关键作用：解决 §5.4 留的 `updated-config.id` 究竟是新 uuid 还是 config_id 复用的 Go 源歧义。

### 6.1 Top-level diff vs §1 首条请求

```jsonc
{
  "traceId":          "<NEW uuid per request>",     // 每请求新生成
  "spaceId":          "883c77cc-...",                // 同首条
  "threadId":         "<SAME as turn 1>",            // ★ 同 thread 复用
  "createThread":     false,                         // ★ 不再开新 thread
  "isPartialTranscript": true,                       // ★
  "generateTitle":    false,                         // ★ 标题已在 turn 1 生成完
  "saveAllThreadOperations": true,                   // 同首条
  "setUnreadState":   true,                          // ★ 不会变 false — m4-handoff 顾虑解除
  "threadType":       "workflow",                    // 同首条
  "asPatchResponse":  true,                          // 同首条
  "hasHeartbeat":     false,                         // 同首条
  "createdSource":    "ai_module",                   // 同首条
  "isUserInAnySalesAssistedSpace": false,            // 同首条
  "isSpaceSalesAssisted":         false,             // 同首条
  "debugOverrides": { /* 同首条 */ },
  // ★ NO threadParentPointer — 仅 createThread=true 时存在
  "transcript": [ /* §6.2 */ ]
}
```

### 6.2 Transcript 五条（本次抓包；surface 切换导致比"最简续聊"多 1 条）

```jsonc
[
  // [0] config — id 复用 turn 1 config 块的 uuid，value 重新发全套 ~50 字段
  {
    "id":   "36215375-830d-808c-a947-00aabf9dff98",   // ★ 同 turn-1 config.id
    "type": "config",
    "value": { /* §1.5 [0] 同款；modelFromUser=true 这次也保持 true */ }
  },

  // [1] context — id + currentDatetime 都复用 turn-1 原值
  {
    "id":   "36215375-830d-800b-b774-00aaef1e281c",   // ★ 同 turn-1 context.id
    "type": "context",
    "value": {
      "currentDatetime": "2026-05-15T22:17:16.188-07:00",  // ★ turn-1 的时间戳
      "surface":         "ai_module",                       // ★ turn-1 的 surface
      /* ...其余字段同 §1.5 [1]... */
    }
  },

  // [2] context delta — 仅当 surface 在两次 turn 之间发生切换时出现
  // 抓包时 turn 1 在 chat panel (ai_module)，turn 2 在 full_page_chat
  // 我们的 CLI 始终 ai_module，故此条不需要产生
  {
    "id":   "36215375-830d-80db-9419-00aa9c25eaf2",   // NEW uuid
    "type": "context",
    "value": {
      "currentDatetime": "2026-05-16T01:18:12.416-07:00",   // 当前时间
      "surface":         "full_page_chat"                    // 切换后的 surface
      /* 其余字段同 [1]，agentName / agentAccessory / context_page_id 都在 */
    }
  },

  // [3] updated-config — ★ id 是 NEW uuid，**不是** turn-1 config.id 的复用
  // 每完成一轮 user/assistant 追加 1 条；本次是 turn 1 完成后的占位
  {
    "id":   "36215375-830d-8064-aa40-00aab11bdb0c",   // ★ NEW uuid
    "type": "updated-config"
    // 无 value
  },

  // [4] 新 user 消息
  {
    "id":        "36215375-830d-80a1-a8ce-00aa75681492",   // NEW uuid
    "type":      "user",
    "value":     [["你现在的状态如何？"]],
    "userId":    "3f4b90ff-...",
    "createdAt": "2026-05-16T01:18:12.413-07:00"
  }
]
```

### 6.3 我们 CLI 的最简续聊形态（无 surface 切换）

```
[0] config        (id 复用)
[1] context       (id + currentDatetime 复用 turn-1)
[2] updated-config × N   (每过一轮新生成 1 个 uuid)
[3] user          (新)
```

`src/notion_agent_cli/transcript.py::build_partial_transcript` 已经按这个
形态构造，2026-05-16 抓包验证通过。

### 6.4 续聊在 client 端要持久化的最小状态集

| 字段 | 来源 | 用途 |
|---|---|---|
| `thread_id` | turn-1 请求的 `threadId` | 续聊请求填 `threadId` |
| `config_id` | turn-1 transcript[0].id | 续聊 transcript[0].id |
| `context_id` | turn-1 transcript[1].id | 续聊 transcript[1].id |
| `original_datetime` | turn-1 transcript[1].value.currentDatetime | 续聊 transcript[1].value.currentDatetime |
| `notion_model` | turn-1 config.model 解析后的 Notion id | 续聊 config.model（锁定，避免中途换模型） |
| `updated_config_ids` | client 端每轮追加一个 `uuid4()` | 续聊 transcript[2..N+1].id |

存储路径：`~/.notionagents/threads/<thread-id>.json`（见
`src/notion_agent_cli/thread_state.py`）。

### 6.5 Resolved — 6 个原始疑问

| 疑问（出处） | 结论 |
|---|---|
| §5.4 `updated-config.id` 是新 uuid 还是 config_id 复用？ | **新 uuid**，每轮追加一个 |
| `setUnreadState` 续聊是否翻成 false？ | **不翻**，仍是 `true` |
| `generateTitle` 续聊是否仍是 true？ | **false**（首条 already generated title） |
| `modelFromUser` 续聊是否翻成 false？ | 抓包此次保持 `true`（用户在面板里没换模型）；推测仅当用户切模型时才会翻 false |
| `createThread` 续聊是否还要带 `threadParentPointer`？ | **不带**（pointer 只在 createThread=true 时存在） |
| `traceId` 续聊是否复用 turn-1 的？ | **不复用**，每请求新 uuid |
