# Roadmap

Status legend: 🟢 done · 🟡 in flight · 🚧 blocked · ⚪ planned · 🔵 stretch

> **State as of v0.1.0 (2026-05-16)**: Phase 2 closed out, D3 shipped
> (async callback variant + FastAPI serve), backlog essentials done
> (`chat --ndjson`, `init --stdin`, `_now_iso` tz fix, `profile`
> subcommand). Only `threads show <id>` deferred (needs live token to
> probe endpoint candidates). Repo can sit here until the next protocol
> drift or operator-driven feature request.

## Phase 1 — MVP CLI ✅ done

Goal: `notion-agent init` + `notion-agent chat` work end-to-end against
the real Notion endpoint; library is importable; existing unit tests
all pass against `httpx.MockTransport`. Bootstrapped from NotionAgents
M4 work which already had a live-tested provider.

- 🟢 Core library extracted from NotionAgents (`account` / `models` /
  `transcript` / `ndjson` / `provider` / `bootstrap`)
- 🟢 `notion-agent init` subcommand
- 🟢 `notion-agent chat` subcommand with text / `--stream` / `--json`
  output modes (`--stream` tty buffering eyeball still pending)
- 🟢 `pip install -e ".[dev]"` + `pytest` (180 tests) + `ruff check` —
  all green in this repo
- 🟢 `LICENSE` file (MIT)
- 🟢 `notion-agent --version` smoke
- 🟢 Live smoke 2026-05-16: `init --cookie "..."` → `chat`/`--json`/
  `--stream`/`doctor`/`models refresh`/`agents list`/`threads list`
  all round-trip against a real TP-Link account

## Phase 2 — Surface polish ✅ done

- ⚪ `notion-agent chat --stream` with proper line-buffered tty output
  (currently uses `print(flush=True)` per chunk; verify on slow streams
  + interactive ttys)
- 🟢 `notion-agent chat --ndjson` — passthrough the raw NDJSON event
  stream to stdout for programmatic consumers that want everything.
  Backed by `NotionAgentClient.stream_lines()` (a new public async
  generator). Thread state still persists, so `--thread-id`
  continuation works from raw consumers too.
- 🟢 `notion-agent chat --thread-id <uuid>` — continuation via per-thread
  JSON state under `~/.notionagents/threads/`. Capture-derived shape
  documented at `docs/01-notion-chat-protocol.md §6`; unit-test verified
  against captured payload. Live round-trip against a real account
  still pending operator token rotation.
- 🟢 `notion-agent init --cookie "<full document.cookie>"` — single-flag
  bootstrap; parser extracts token_v2, browser_id, user_id from one
  pasted string. `--token-v2 / --user-id / --browser-id` still accepted
  as overrides on top of `--cookie`.
- 🟢 `notion-agent init --cookie -` — read cookie from stdin instead of
  argv, so it never appears in shell history / `ps aux`.
- 🟢 `_now_iso(tz)` honors `acc.timezone` (was using system local) —
  `currentDatetime` / `createdAt` rendered offsets now match the
  workspace's declared timezone, so date-aware replies ("what day is
  it today?") work for operators whose host tz differs from
  `acc.timezone`.
- ⚪ Split `cli/__main__.py` into per-command files (it's now 8
  subcommands; splitting becomes worthwhile)
- 🟢 `notion-agent doctor` — 6-step health check (account file readable,
  required fields, jarvis binding, live `/loadUserContent` ping, bound
  space_id still present, user model map). `--json` mode for cron.

## Phase 3 — More subcommands ✅ mostly done

- 🟢 `notion-agent agents list` — uses `/api/v3/getCustomAgents`; lists
  agent page ids ranked by activity_score, with each agent's most
  recent thread title as a breadcrumb. (Agent display names still
  require a separate page-chunk lookup; deferred.)
- 🟢 `notion-agent threads list` — same endpoint's
  `mostRecentTranscripts`; supports `--agent <id>` filter, `--limit`,
  `--json`.
- ⚪ `notion-agent threads show <id>` — endpoint probe deferred. Live
  account needed to test three candidate endpoints
  (`loadInferenceTranscript`, `getInferenceTranscript`,
  `loadCachedPageChunk`); next session with a fresh token can run
  the probe. If all 404, this entry drops to non-goal.
- 🟢 `notion-agent models refresh` — POST `/api/v3/getAvailableModels`
  `{spaceId}`, writes friendly-alias → internal-id map to
  `~/.notionagents/models.json`; `resolve_model` prefers it over
  `DEFAULT_MODEL_MAP`.
- 🟢 `notion-agent profile list / current / use <name> / migrate <name>`
  — symlink-based dispatch. Each profile is a named credential file
  under `~/.notionagents/<name>.json`; `notion_account.json` is a
  symlink retargetted by `profile use`. `migrate` promotes a
  pre-profile setup non-destructively.

## Phase 4 — Ecosystem hooks ✅ done

- 🟢 **D1**  Claude Code skill — `.claude/skills/notion-agent/SKILL.md`
  shipped. Frontmatter follows the
  `~/.claude/skills/collaborating-with-{codex,gemini}` convention
  (name + description with embedded trigger phrases, no separate
  trigger_keywords). Body covers all 8 subcommands + B1
  continuation pipeline + 8-row ErrorCode reference for `--json`
  consumers.
- 🟢 **D2**  Adopted by NotionAgents — done in NotionAgents
  `ef476a3 M5: hoist LLM client to notion-agent-cli (D9)` before
  this repo existed; this session's editable install keeps changes
  propagating instantly. NotionAgents 147 tests stay green across
  every refactor here.
- 🟢 **D3**  FastAPI `notion-agent serve` — local HTTP wrapper exposing
  `POST /chat` (blocking JSON or SSE), `GET /healthz`, `GET /agents`,
  `GET /threads`. Optional install group `[serve]`. Backed by a new
  `on_text_delta_async` parameter on `NotionAgentClient.complete()`
  (non-breaking — existing sync `on_text_delta` still works).
- 🔵 Docker image (alpine + Python 3.12 + this CLI) for cron-style
  one-shot invocations — stretch, not on critical path.

## Phase 5 — Hardening (stretch)

- 🟢 Token-v2 expiry telemetry: `NotionAgentError.code` (StrEnum
  `ErrorCode`) lets watchers branch on `auth_invalid` / `quota_exhausted`
  / `premium_required` without parsing the human message
- 🔵 Concurrent calls coordinator: rate-limit + queue so a fleet of
  cron jobs can share one account file without race-condition risk
- 🔵 TLS fingerprint hardening (utls / curl_cffi) if Notion ever starts
  blocking httpx
- 🔵 Encrypted account file at rest (`age` / `gpg` / OS keychain)

## Phase 6 — Maintenance (post-v0.1.0)

- 🟡 Live re-validation after operator rotates a token — exercise the
  full subcommand surface (especially `chat --thread-id` + `serve`
  end-to-end + the `threads show` endpoint probe) against a real
  account.
- ⚪ `notion-agent threads gc --older-than 30d` — prune accumulated
  `~/.notionagents/threads/<id>.json` files. Low-priority (small
  files), but downstream NotionAgents runs every minute and never
  reuses thread_id, so the dir grows ~17 KB/day there.
- ⚪ When Notion rotates internal model ids next (every few months
  per the M4 ledger), `models refresh` should still cover it — but if
  the rotation also changes shape, this file's
  `parse_available_models` would need updating.

---

## Non-goals

- ❌ Multi-account pool with auto-rotation (notion_manager already
  does this; out of scope here — single-user CLI)
- ❌ Web dashboard / GUI (this stays CLI-only; orchestration UIs belong
  in downstream projects like NotionAgents)
- ❌ Account registration / signup automation
- ❌ Reverse-engineering write-side endpoints beyond what's needed for
  chat (write blocks / databases — use Notion's public REST API for
  those; this CLI is read-only against the AI endpoint)
