# Releasing

`notion-agent-cli` is published to PyPI via GitHub Actions Trusted
Publishing — no API tokens stored anywhere, the workflow trades a
short-lived OIDC token for an upload credential at publish time.

## One-time setup (already done)

- PyPI **Pending Publisher** registered against
  `chenyqthu/notion-agent-cli` / workflow `release.yml` / environment
  `pypi`. After the first successful upload PyPI flips it to a regular
  Trusted Publisher automatically.
- GitHub repo has an `pypi` environment (`Settings → Environments`).
  Recommend adding "Required reviewers = self" — the publish job will
  pause on the environment gate, giving one last chance to abort a
  mis-tagged release before bits hit PyPI.

## Cutting a release

```bash
# 1. Bump version in pyproject.toml (semver — patch / minor / major)
$EDITOR pyproject.toml

# 2. (If anything material shipped) update STATUS / ROADMAP
$EDITOR docs/STATUS.md

# 3. Commit
git commit -am "Bump version to X.Y.Z"

# 4. Push main, then tag
git push origin main
git tag vX.Y.Z
git push origin vX.Y.Z

# 5. Watch Actions → Release
#    Two jobs: build (~30s) → publish (waits for env approval, then ~10s).
#    On green: pipx install notion-agent-cli==X.Y.Z works.
```

The tag prefix must be `v` (matches `on.push.tags: ['v*']`). PEP 440
pre-release suffixes (`v0.2.0rc1`, `v0.2.0a3`, `v0.2.0b1`) are
honored — PyPI lists them as pre-releases and `pipx install` skips
them unless `--pip-args=--pre` is passed.

## Verifying the build locally before tagging

The release workflow runs `twine check --strict` and fails on README
rendering issues. Mirror that locally first to avoid round-trips:

```bash
.venv/bin/pip install --upgrade build twine
rm -rf dist/ && .venv/bin/python -m build
.venv/bin/twine check --strict dist/*
```

Inspect the built artifacts to make sure secrets / dev files didn't
sneak in:

```bash
tar tzf dist/notion_agent_cli-*.tar.gz | sort
unzip -l dist/notion_agent_cli-*.whl
```

## Rolling back a bad release

**PyPI does not allow re-uploading the same version** — even if you
delete it, the version number is permanently retired. The correct
move:

1. Go to https://pypi.org/manage/project/notion-agent-cli/releases/
   and **Yank** the broken release. Yanking keeps the version
   installable by exact pin (`==X.Y.Z`) for anyone with an existing
   lockfile, but `pipx install notion-agent-cli` resolves to "latest
   non-yanked".
2. Fix the bug.
3. Cut a new patch release (`vX.Y.(Z+1)`).

Never click "Delete" on a release page — that's the one-way door.

## Bootstrapping a publisher on a new repo

If this repo ever moves or forks need to publish independently:

1. New PyPI account holder visits
   https://pypi.org/manage/account/publishing/ and adds a Pending
   Publisher for their target project name.
2. Repo must contain `.github/workflows/release.yml` with
   `permissions.id-token: write` on the publish job and
   `environment.name` matching what was registered on PyPI.
3. Tag + push. First green upload promotes the Pending Publisher to a
   regular one.
