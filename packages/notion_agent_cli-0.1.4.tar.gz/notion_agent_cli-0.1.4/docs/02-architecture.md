# Architecture — notion-agent-cli

## TL;DR

```
┌────────────────────────────────────────────────────────────────┐
│  notion-agent (CLI)                                           │
│  ┌─────────────┐   ┌─────────────┐                             │
│  │ init cmd    │   │ chat cmd    │                             │
│  └─────┬───────┘   └─────┬───────┘                             │
└────────┼─────────────────┼─────────────────────────────────────┘
         │                 │
         ▼                 ▼
┌────────────────┐   ┌──────────────────────────────────────────┐
│ bootstrap.py   │   │ NotionAgentClient (provider.py)          │
│  ↓             │   │  ↓                                       │
│ /loadUserContent│  │ /runInferenceTranscript (NDJSON stream)  │
└────────┬───────┘   └────────┬─────────────────────────────────┘
         │                    │
         ▼                    ▼
   notion_account.json   account.py + transcript.py + ndjson.py + models.py
```

The library splits into small modules so each one is independently
testable and reusable:

| module | purpose |
|---|---|
| `account.py` | dataclass + loader + saver + cookie builder for `notion_account.json` |
| `models.py` | friendly alias / Anthropic id → Notion internal model id |
| `transcript.py` | builds the request body (config / context / user blocks + top-level) |
| `ndjson.py` | stateful parser for the NDJSON response (patch ops + agent-inference fallback) |
| `provider.py` | `NotionAgentClient` — orchestrates the round-trip; this is the library entry point |
| `bootstrap.py` | one-time init helper: takes `token_v2`, calls `/loadUserContent`, fills workspace metadata |
| `cli/__main__.py` | argparse wiring for `notion-agent init` + `notion-agent chat` |
| `exceptions.py` | single `NotionAgentError` type |
| `types.py` | `ChatResponse` + `TokenUsage` dataclasses |

## Why these splits

1. **Library-first, CLI-second** — the CLI is just a thin wrapper over
   `NotionAgentClient`. Anything importable from the CLI is also
   importable from a notebook / cron job / FastAPI handler. The library
   has no CLI dependencies.
2. **One-call client, not a long-running session** — `NotionAgentClient`
   is async-context-manager friendly but each `complete()` creates a
   fresh thread. Rolling-thread strategies (per-day / per-agent) belong
   in the application layer that calls us.
3. **Stateful parser, not a function** — Notion streams NDJSON over a
   long-lived HTTP/2 connection, with patches arriving over time. A
   stateful `NDJSONStreamParser` lets us emit text deltas through the
   `on_text_delta` callback as patches arrive, instead of buffering
   until end-of-stream.
4. **Cookie + workspace metadata as a separate file** — credentials
   are user-private and rotate independently of code; `notion_account.json`
   stays out of `git` and out of the package install location.

## Request flow (`chat` command)

```
shell ──► argparse parses CLI args
       └► NotionAgentClient(account_path)
             └► load_account()          # reads notion_account.json
             └► resolve_model(alias)    # opus-4.7 → apricot-sorbet-high
             └► build_full_transcript() # config + context + user blocks
             └► build_inference_request()
             └► httpx.AsyncClient.stream("POST", url)
                  └► (Notion responds 200 + br-encoded NDJSON stream)
                  └► async for line in resp.aiter_lines():
                       NDJSONStreamParser.feed_line(line)
                       if on_text_delta: emit delta
             └► parser.finalize() → ChatResponse(text, model, usage, …)
```

## Why this works against Notion's edge (without TLS fingerprinting)

notion_manager uses [`utls`](https://github.com/refraction-networking/utls)
to mimic Chrome's JA3/JA4 TLS fingerprint, on the theory that Notion's
edge will block "non-browser" clients. In practice for a single user
calling at human cadence, plain Python `httpx` works fine — we've
sustained multiple successful round-trips with default TLS in
NotionAgents M4 testing. If we ever start getting blocked, the fix is
to add `tls_client` or `httpx[brotli]` with custom ALPN, but it's not
needed today.

The headers that *do* matter (`x-notion-active-user-header`,
`x-notion-space-id`, `notion-client-version`) are all set in
`provider.build_headers()`. Cookie is the auth token; everything else
is browser hygiene.

## Future direction — see [ROADMAP.md](ROADMAP.md)

Short version: split CLI commands into per-file modules, add streaming
JSON output, add multi-account profiles, package as a Claude Code
skill, wire into NotionAgents runner via subprocess once stable.
