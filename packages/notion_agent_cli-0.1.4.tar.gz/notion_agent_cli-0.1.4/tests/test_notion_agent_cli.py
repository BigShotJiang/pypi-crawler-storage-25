"""Unit tests for notion-agent-cli.

The provider tests hit ``httpx.MockTransport`` — no real network. The
fixtures mirror the captured chat-panel payload shapes documented in
``docs/01-notion-chat-protocol.md``.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.account import (
    NotionAccount,
    build_cookie_header,
    load_notion_account,
    save_notion_account,
)
from notion_agent_cli.models import (
    ANTHROPIC_ALIASES,
    DEFAULT_MODEL_MAP,
    resolve_model,
)
from notion_agent_cli.ndjson import (
    NDJSONStreamParser,
    parse_ndjson_stream,
)
from notion_agent_cli.transcript import (
    build_full_transcript,
    build_inference_request,
    build_partial_transcript,
)

# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path, **overrides: Any) -> Path:
    base = {
        "token_v2":              "v03:test-token-xyz",
        "user_id":               "11111111-1111-1111-1111-111111111111",
        "user_name":             "Test User",
        "user_email":            "test@example.com",
        "space_id":              "22222222-2222-2222-2222-222222222222",
        "space_name":            "Test Space",
        "space_view_id":         "33333333-3333-3333-3333-333333333333",
        "browser_id":            "44444444-4444-4444-4444-444444444444",
        "device_id":             "55555555-5555-5555-5555-555555555555",
        "client_version":        "23.13.20260516.0113",
        "user_agent":            "Mozilla/5.0 Test",
        "timezone":              "America/Los_Angeles",
        "agent_name":            "Jarvis",
        "agent_accessory":       "cat",
        "agent_context_page_id": "66666666-6666-6666-6666-666666666666",
        "default_model":         "opus-4.7",
    }
    base.update(overrides)
    base = {k: v for k, v in base.items() if v is not ...}
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps(base), encoding="utf-8")
    return p


def _account(**overrides: Any) -> NotionAccount:
    base = {
        "token_v2":              "v03:test-token-xyz",
        "user_id":               "11111111-1111-1111-1111-111111111111",
        "user_name":             "Test User",
        "user_email":            "test@example.com",
        "space_id":              "22222222-2222-2222-2222-222222222222",
        "space_name":            "Test Space",
        "space_view_id":         "33333333-3333-3333-3333-333333333333",
        "browser_id":            "44444444-4444-4444-4444-444444444444",
        "device_id":             "55555555-5555-5555-5555-555555555555",
        "agent_name":            "Jarvis",
        "agent_accessory":       "cat",
        "agent_context_page_id": "66666666-6666-6666-6666-666666666666",
    }
    base.update(overrides)
    return NotionAccount(**base)


def _ndjson(*events: dict[str, Any]) -> bytes:
    return ("\n".join(json.dumps(e) for e in events) + "\n").encode("utf-8")


def _mock_client(
    tmp_path: Path,
    handler: Callable[[httpx.Request], httpx.Response],
    **client_kwargs: Any,
) -> tuple[NotionAgentClient, list[httpx.Request]]:
    captured: list[httpx.Request] = []

    def _h(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return handler(request)

    transport = httpx.MockTransport(_h)
    http_client = httpx.AsyncClient(transport=transport)
    # Pin thread_state_dir to tmp_path so successful completes never
    # touch the real ~/.notionagents/threads/ directory.
    client_kwargs.setdefault("thread_state_dir", tmp_path / "threads")
    return (
        NotionAgentClient(_account_file(tmp_path), http_client=http_client, **client_kwargs),
        captured,
    )


# --------------------------------------------------------------------------- #
# account
# --------------------------------------------------------------------------- #

class TestAccount:
    def test_load_ok(self, tmp_path: Path):
        path = _account_file(tmp_path)
        acc = load_notion_account(path)
        assert acc.token_v2 == "v03:test-token-xyz"
        assert acc.space_id == "22222222-2222-2222-2222-222222222222"
        assert acc.agent_name == "Jarvis"
        assert acc.has_jarvis_binding is True

    def test_load_missing_file(self, tmp_path: Path):
        with pytest.raises(NotionAgentError, match="not found"):
            load_notion_account(tmp_path / "nope.json")

    def test_load_malformed_json(self, tmp_path: Path):
        p = tmp_path / "bad.json"
        p.write_text("definitely not json {", encoding="utf-8")
        with pytest.raises(NotionAgentError, match="malformed"):
            load_notion_account(p)

    @pytest.mark.parametrize("missing", ["token_v2", "user_id", "space_id"])
    def test_load_missing_required(self, tmp_path: Path, missing: str):
        path = _account_file(tmp_path, **{missing: ""})
        with pytest.raises(NotionAgentError, match=f"missing required.*{missing}"):
            load_notion_account(path)

    def test_load_stashes_extras(self, tmp_path: Path):
        path = _account_file(tmp_path, custom_thing="yes")
        acc = load_notion_account(path)
        assert acc.extras == {"custom_thing": "yes"}

    def test_has_jarvis_binding_partial(self):
        acc = _account(agent_name="Jarvis", agent_context_page_id="")
        assert acc.has_jarvis_binding is False
        acc = _account(agent_name="", agent_context_page_id="page-id")
        assert acc.has_jarvis_binding is False

    def test_cookie_header_full_cookie_wins(self):
        acc = _account(full_cookie="token_v2=full; misc=1")
        assert build_cookie_header(acc) == "token_v2=full; misc=1"

    def test_cookie_header_builds_minimal(self):
        acc = _account(full_cookie="")
        cookie = build_cookie_header(acc)
        assert "token_v2=v03:test-token-xyz" in cookie
        assert "notion_browser_id=44444444-4444-4444-4444-444444444444" in cookie
        assert "notion_user_id=11111111-1111-1111-1111-111111111111" in cookie
        assert "notion_check_cookie_consent=false" in cookie

    def test_save_then_load_round_trip(self, tmp_path: Path):
        acc = _account()
        out = tmp_path / "rt.json"
        save_notion_account(acc, out)
        loaded = load_notion_account(out)
        assert loaded.token_v2 == acc.token_v2
        assert loaded.agent_name == acc.agent_name


# --------------------------------------------------------------------------- #
# models
# --------------------------------------------------------------------------- #

class TestResolveModel:
    def test_friendly_alias(self):
        assert resolve_model("opus-4.7") == "apricot-sorbet-high"
        assert resolve_model("sonnet-4.6") == "almond-croissant-low"

    def test_anthropic_alias(self):
        assert resolve_model("claude-opus-4-7") == "apricot-sorbet-high"
        assert resolve_model("claude-sonnet-4-6") == "almond-croissant-low"

    def test_notion_id_passes_through(self):
        assert resolve_model("apricot-sorbet-high") == "apricot-sorbet-high"

    def test_date_suffix_stripped(self):
        assert resolve_model("claude-opus-4-7-20260301") == "apricot-sorbet-high"

    def test_fuzzy_family_fallback(self):
        assert resolve_model("custom-opus-blend") == "apricot-sorbet-high"
        assert resolve_model("anything-sonnet-x") == "almond-croissant-low"

    def test_empty_defaults_to_opus(self):
        assert resolve_model("") == "apricot-sorbet-high"

    def test_unknown_passes_through(self):
        assert resolve_model("totally-made-up-model") == "totally-made-up-model"

    def test_all_anthropic_aliases_resolve(self):
        for alias, friendly in ANTHROPIC_ALIASES.items():
            assert friendly in DEFAULT_MODEL_MAP, (
                f"anthropic alias {alias} → {friendly} missing from DEFAULT_MODEL_MAP"
            )


# --------------------------------------------------------------------------- #
# transcript
# --------------------------------------------------------------------------- #

class TestTranscript:
    def test_full_transcript_shape(self):
        acc = _account()
        t = build_full_transcript(acc, user_text="hi", notion_model="apricot-sorbet-high")
        assert len(t) == 3
        assert [e["type"] for e in t] == ["config", "context", "user"]

    def test_full_transcript_user_message_double_list(self):
        acc = _account()
        t = build_full_transcript(acc, user_text="hello", notion_model="apricot-sorbet-high")
        assert t[2]["value"] == [["hello"]]
        assert t[2]["userId"] == acc.user_id

    def test_config_block_essentials(self):
        acc = _account()
        t = build_full_transcript(acc, user_text="x", notion_model="apricot-sorbet-high")
        cfg = t[0]["value"]
        assert cfg["type"] == "workflow"
        assert cfg["model"] == "apricot-sorbet-high"
        assert cfg["modelFromUser"] is True
        assert sum(1 for k in cfg if k.startswith("enable")) > 20

    def test_context_includes_jarvis_when_bound(self):
        acc = _account()
        ctx = build_full_transcript(acc, user_text="x", notion_model="opus-4.7")[1]["value"]
        assert ctx["surface"] == "ai_module"
        assert ctx["agentName"] == "Jarvis"
        assert ctx["context_page_id"] == "66666666-6666-6666-6666-666666666666"

    def test_context_omits_jarvis_when_unbound(self):
        acc = _account(agent_name="", agent_context_page_id="")
        ctx = build_full_transcript(acc, user_text="x", notion_model="opus-4.7")[1]["value"]
        assert "agentName" not in ctx
        assert "context_page_id" not in ctx

    def test_partial_transcript_includes_updated_configs(self):
        acc = _account()
        t = build_partial_transcript(
            acc, new_user_text="follow-up", notion_model="opus-4.7",
            config_id="cfg-id", context_id="ctx-id",
            updated_config_ids=["uc1", "uc2"],
        )
        assert [e["type"] for e in t] == [
            "config", "context", "updated-config", "updated-config", "user",
        ]
        assert t[0]["value"]["modelFromUser"] is False

    def test_inference_request_first_turn(self):
        acc = _account()
        body = build_inference_request(
            acc, transcript=[], thread_id="th-1",
            create_thread=True, is_partial_transcript=False,
        )
        assert body["threadParentPointer"]["table"] == "space"
        assert body["asPatchResponse"] is True
        assert body["setUnreadState"] is True
        assert body["hasHeartbeat"] is False
        assert body["createdSource"] == "ai_module"
        assert body["generateTitle"] is True

    def test_inference_request_partial_turn(self):
        acc = _account()
        body = build_inference_request(
            acc, transcript=[], thread_id="th-1",
            create_thread=False, is_partial_transcript=True,
        )
        assert "threadParentPointer" not in body
        assert body["generateTitle"] is False

    def test_current_datetime_uses_acc_timezone(self):
        """``currentDatetime`` + ``createdAt`` render in acc.timezone, not
        whatever the host's local tz happens to be.

        Notion stamps the workspace timezone into ``timezone`` in the
        context block — the matching offset on the datetime field is
        load-bearing for date-aware replies ("what day is it today?").
        """
        # America/Anchorage is -09:00 in standard time, -08:00 in DST.
        # America/Los_Angeles is -08:00 / -07:00. Whatever the host's
        # tz, these two will produce different offsets, so we just
        # confirm the rendered offset matches the requested zone.
        from datetime import datetime
        from zoneinfo import ZoneInfo

        for tz_name in ("America/Anchorage", "Asia/Tokyo", "Europe/Berlin"):
            acc = _account(timezone=tz_name)
            t = build_full_transcript(
                acc, user_text="x", notion_model="apricot-sorbet-high",
            )
            ctx_dt = t[1]["value"]["currentDatetime"]
            user_dt = t[2]["createdAt"]

            # Both fields share a suffix matching the requested zone.
            expected_offset = datetime.now(ZoneInfo(tz_name)).strftime("%z")
            # Python emits "%z" as "+0900"; isoformat emits "+09:00".
            expected_iso = f"{expected_offset[:3]}:{expected_offset[3:]}"
            assert ctx_dt.endswith(expected_iso), (tz_name, ctx_dt)
            assert user_dt.endswith(expected_iso), (tz_name, user_dt)

    def test_partial_transcript_createdat_uses_acc_timezone(self):
        from datetime import datetime
        from zoneinfo import ZoneInfo

        acc = _account(timezone="Asia/Tokyo")
        t = build_partial_transcript(
            acc, new_user_text="follow-up", notion_model="opus-4.7",
            config_id="cfg", context_id="ctx", updated_config_ids=[],
        )
        user_dt = t[-1]["createdAt"]
        offset = datetime.now(ZoneInfo("Asia/Tokyo")).strftime("%z")
        expected_iso = f"{offset[:3]}:{offset[3:]}"
        assert user_dt.endswith(expected_iso)


# --------------------------------------------------------------------------- #
# NDJSON parser
# --------------------------------------------------------------------------- #

class TestNDJSONPatchMode:
    def _setup_with_inference_section(self) -> NDJSONStreamParser:
        p = NDJSONStreamParser()
        p.feed_line(json.dumps({
            "type": "patch-start",
            "data": {"s": [{"id": "t", "type": "title", "value": "T"}]},
        }))
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/-", "v": {"id": "ai", "type": "agent-inference"}}],
        }))
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/1/value/-", "v": {"type": "text", "content": ""}}],
        }))
        return p

    def test_text_appended_via_op_x(self):
        p = self._setup_with_inference_section()
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "x", "p": "/s/1/value/0/content", "v": "Hello"}]}))
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "x", "p": "/s/1/value/0/content", "v": ", world!"}]}))
        assert p.finalize().text == "Hello, world!"

    def test_text_replaced_op_p_keeps_longer(self):
        p = self._setup_with_inference_section()
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "x", "p": "/s/1/value/0/content", "v": "Hello"}]}))
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "p", "p": "/s/1/value/0/content",
                                       "v": "Hello, longer"}]}))
        assert p.finalize().text == "Hello, longer"

    def test_thinking_routed_separately(self):
        p = NDJSONStreamParser()
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/0/value/-",
                   "v": {"type": "thinking", "content": ""}}],
        }))
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "Hmm"}]}))
        r = p.finalize()
        assert r.thinking == "Hmm"
        assert r.text == ""

    def test_tool_use_content_dropped(self):
        p = NDJSONStreamParser()
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/0/value/-",
                   "v": {"type": "tool_use", "content": ""}}],
        }))
        p.feed_line(json.dumps({"type": "patch",
                                "v": [{"o": "x", "p": "/s/0/value/0/content",
                                       "v": '{"q":"x"}'}]}))
        assert p.finalize().text == ""

    def test_usage_tokens_accumulate(self):
        p = NDJSONStreamParser()
        for path, val in [("inputTokens", 42), ("outputTokens", 15),
                          ("cachedTokensRead", 100), ("cachedTokensCreated", 50)]:
            p.feed_line(json.dumps({"type": "patch",
                                    "v": [{"o": "a", "p": f"/s/0/{path}", "v": val}]}))
        r = p.finalize()
        assert (r.input_tokens, r.output_tokens) == (42, 15)
        assert (r.cache_read_tokens, r.cache_creation_tokens) == (100, 50)

    def test_inline_section_value_short_reply(self):
        """Live-capture-pattern (2026-05-15): Notion bundles a short
        reply's full text into the /s/- append patch itself."""
        chinese_reply = "在线，随时待命 \U0001f432"  # noqa: RUF001 — fullwidth comma intentional
        p = NDJSONStreamParser()
        p.feed_line(json.dumps({"type": "patch-start",
                                "data": {"s": [{"id": "t", "type": "title", "value": "Test"}]}}))
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/-",
                   "v": {"id": "instr", "type": "agent-instruction-state"}}],
        }))
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [{"o": "a", "p": "/s/-",
                   "v": {"id": "ai", "type": "agent-inference",
                         "value": [{"type": "text", "content": chinese_reply}]}}],
        }))
        p.feed_line(json.dumps({
            "type": "patch",
            "v": [
                {"o": "a", "p": "/s/2/inputTokens", "v": 44852},
                {"o": "a", "p": "/s/2/outputTokens", "v": 16},
                {"o": "a", "p": "/s/2/cachedTokensRead", "v": 36760},
                {"o": "a", "p": "/s/2/model", "v": "apricot-sorbet-high"},
            ],
        }))
        r = p.finalize()
        assert r.text == chinese_reply
        assert r.input_tokens == 44852
        assert r.cache_read_tokens == 36760
        assert r.notion_model == "apricot-sorbet-high"


class TestNDJSONErrorPaths:
    def test_error_event_raises(self):
        p = NDJSONStreamParser()
        with pytest.raises(NotionAgentError, match="quota exceeded"):
            p.feed_line(json.dumps({"type": "error", "message": "quota exceeded"}))

    def test_premium_event_raises(self):
        p = NDJSONStreamParser()
        with pytest.raises(NotionAgentError, match="premium feature"):
            p.feed_line(json.dumps({"type": "premium-feature-unavailable"}))

    def test_invalid_json_lines_skipped(self):
        r = parse_ndjson_stream(["not json", '{"type":"patch","v":[]}', ""])
        assert r.line_count == 2

    def test_empty_stream(self):
        r = parse_ndjson_stream([])
        assert r.text == ""
        assert r.line_count == 0


class TestNDJSONLegacyMode:
    def test_agent_inference_cumulative(self):
        p = NDJSONStreamParser()
        p.feed_line(json.dumps({
            "type": "agent-inference", "id": "s1",
            "value": [{"type": "text", "content": "Hello"}],
        }))
        p.feed_line(json.dumps({
            "type": "agent-inference", "id": "s1",
            "value": [{"type": "text", "content": "Hello, world!"}],
            "inputTokens": 42, "outputTokens": 15, "model": "almond-croissant-low",
            "finishedAt": 1000,
        }))
        r = p.finalize()
        assert r.text == "Hello, world!"
        assert r.input_tokens == 42
        assert r.notion_model == "almond-croissant-low"


# --------------------------------------------------------------------------- #
# Provider — httpx MockTransport
# --------------------------------------------------------------------------- #

class TestProviderHappy:
    async def test_patch_stream_returns_text_and_usage(self, tmp_path: Path):
        ndjson = _ndjson(
            {"type": "patch-start",
             "data": {"s": [{"id": "t", "type": "title", "value": "T"}]}},
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-", "v": {"id": "ai", "type": "agent-inference",
                    "value": [{"type": "text", "content": "Hello, world!"}]}}]},
            {"type": "patch",
             "v": [
                 {"o": "a", "p": "/s/1/inputTokens", "v": 12},
                 {"o": "a", "p": "/s/1/outputTokens", "v": 5},
                 {"o": "a", "p": "/s/1/model", "v": "apricot-sorbet-high"},
             ]},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson,
                                  headers={"content-type": "application/x-ndjson"})

        client, _ = _mock_client(tmp_path, handler)
        try:
            resp = await client.complete(prompt="hi")
        finally:
            await client.aclose()

        assert resp.text == "Hello, world!"
        assert resp.model == "apricot-sorbet-high"
        assert resp.usage.input_tokens == 12
        assert resp.usage.output_tokens == 5
        assert resp.thread_id

    async def test_request_shape_matches_capture(self, tmp_path: Path):
        ndjson = _ndjson({"type": "patch",
                          "v": [{"o": "a", "p": "/s/-",
                                 "v": {"type": "agent-inference",
                                       "value": [{"type": "text", "content": "ok"}]}}]})

        def handler(_):
            return httpx.Response(200, content=ndjson)

        client, requests = _mock_client(tmp_path, handler)
        try:
            await client.complete(prompt="hi", system="be helpful")
        finally:
            await client.aclose()

        req = requests[0]
        assert req.method == "POST"
        assert str(req.url) == "https://www.notion.so/api/v3/runInferenceTranscript"
        assert req.headers["x-notion-active-user-header"] == \
            "11111111-1111-1111-1111-111111111111"
        assert req.headers["x-notion-space-id"] == \
            "22222222-2222-2222-2222-222222222222"
        assert "token_v2=v03:test-token-xyz" in req.headers["cookie"]
        body = json.loads(req.content)
        assert body["asPatchResponse"] is True
        assert body["setUnreadState"] is True
        assert body["threadType"] == "workflow"
        assert body["transcript"][0]["value"]["model"] == "apricot-sorbet-high"
        assert body["transcript"][1]["value"]["agentName"] == "Jarvis"
        assert body["transcript"][2]["value"] == [["be helpful\n\nhi"]]

    async def test_stream_callback_fires_on_each_chunk(self, tmp_path: Path):
        ndjson = _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference",
                          "value": [{"type": "text", "content": ""}]}}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "Hel"}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "lo"}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "!"}]},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson)

        chunks: list[str] = []
        client, _ = _mock_client(tmp_path, handler)
        try:
            resp = await client.complete(
                prompt="hi", on_text_delta=lambda c: chunks.append(c),
            )
        finally:
            await client.aclose()

        # Streaming callback got each chunk independently…
        assert chunks == ["Hel", "lo", "!"]
        # …and the final response carries the concatenated text.
        assert resp.text == "Hello!"

    async def test_async_stream_callback_awaited_per_chunk(self, tmp_path: Path):
        """``on_text_delta_async`` exists for HTTP consumers (FastAPI SSE)
        that need to ``await`` per chunk — confirm both that each chunk
        is awaited and that the coroutine sees the same content the sync
        callback would.
        """
        ndjson = _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference",
                          "value": [{"type": "text", "content": ""}]}}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "Hel"}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "lo"}]},
            {"type": "patch",
             "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "!"}]},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson)

        chunks: list[str] = []

        async def on_delta(c: str) -> None:
            chunks.append(c)

        client, _ = _mock_client(tmp_path, handler)
        try:
            resp = await client.complete(
                prompt="hi", on_text_delta_async=on_delta,
            )
        finally:
            await client.aclose()

        assert chunks == ["Hel", "lo", "!"]
        assert resp.text == "Hello!"

    async def test_stream_lines_yields_raw_ndjson_lines(self, tmp_path: Path):
        """``stream_lines`` is the raw passthrough used by ``chat --ndjson``.

        Each yielded value is one non-empty NDJSON line; the parser
        never runs, so terminal events embedded in the stream are
        surfaced verbatim rather than translated into NotionAgentError.
        """
        ndjson = _ndjson(
            {"type": "patch-start", "data": {"s": [{"id": "t", "type": "title"}]}},
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference",
                          "value": [{"type": "text", "content": "hi"}]}}]},
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/0/model", "v": "apricot-sorbet-high"}]},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson)

        client, _ = _mock_client(tmp_path, handler)
        try:
            lines = [
                line async for line in client.stream_lines(prompt="hi")
            ]
        finally:
            await client.aclose()

        # 3 events in, 3 lines out (no blanks).
        assert len(lines) == 3
        parsed = [json.loads(line) for line in lines]
        assert parsed[0]["type"] == "patch-start"
        assert parsed[2]["v"][0]["v"] == "apricot-sorbet-high"

    async def test_stream_lines_persists_thread_state(self, tmp_path: Path):
        """Raw passthrough still writes state — continuation keeps working."""
        ndjson = _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference",
                          "value": [{"type": "text", "content": "ok"}]}}]},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson)

        client, _ = _mock_client(tmp_path, handler)
        try:
            received: list[str] = []
            async for line in client.stream_lines(prompt="hi"):
                received.append(line)
        finally:
            await client.aclose()

        # Find the state file written under tmp_path/threads/.
        state_files = list((tmp_path / "threads").glob("*.json"))
        assert len(state_files) == 1
        assert received  # got at least one line through

    async def test_stream_lines_401_raises_auth_invalid(self, tmp_path: Path):
        def handler(_):
            return httpx.Response(401, json={"name": "Unauthorized"})

        client, _ = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match="token_v2 expired"):
                async for _line in client.stream_lines(prompt="hi"):
                    pass
        finally:
            await client.aclose()

    async def test_both_callbacks_set_raises_invalid_callback(self, tmp_path: Path):
        """Setting both sync and async deltas is a caller bug — fail fast."""
        def handler(_):
            raise AssertionError("handler should not be called")

        async def on_delta_async(_: str) -> None:
            pass

        client, requests = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(
                    prompt="hi",
                    on_text_delta=lambda _c: None,
                    on_text_delta_async=on_delta_async,
                )
        finally:
            await client.aclose()
        assert exc.value.code == "invalid_callback"
        assert requests == []


class TestProviderErrors:
    async def test_401_raises_with_token_expired_message(self, tmp_path: Path):
        def handler(_):
            return httpx.Response(401, json={"name": "UnauthorizedError",
                                             "message": "Token was invalid or expired."})
        client, _ = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match="token_v2 expired"):
                await client.complete(prompt="hi")
        finally:
            await client.aclose()

    async def test_500_raises_with_body_snippet(self, tmp_path: Path):
        def handler(_):
            return httpx.Response(500, text="internal boom")
        client, _ = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match=r"500.*internal boom"):
                await client.complete(prompt="hi")
        finally:
            await client.aclose()

    async def test_empty_stream_raises_empty_text(self, tmp_path: Path):
        def handler(_):
            return httpx.Response(200, content=b"")
        client, _ = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match="empty text"):
                await client.complete(prompt="hi")
        finally:
            await client.aclose()

    async def test_error_event_mid_stream_raises(self, tmp_path: Path):
        ndjson = _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference", "value": []}}]},
            {"type": "error", "message": "quota exhausted"},
        )

        def handler(_):
            return httpx.Response(200, content=ndjson)
        client, _ = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match="quota exhausted"):
                await client.complete(prompt="hi")
        finally:
            await client.aclose()

    async def test_empty_prompt_raises_locally(self, tmp_path: Path):
        def handler(_):
            raise AssertionError("handler should not be called")
        client, requests = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError, match="empty prompt"):
                await client.complete(prompt="  ")
        finally:
            await client.aclose()
        assert requests == []


# --------------------------------------------------------------------------- #
# Provider — continuation (isPartialTranscript=true)
#
# Covers the B1 work: thread state is persisted after a successful first
# turn, then loaded + replayed into a partial transcript on the next
# call with --thread-id. Capture-derived shape lives in
# docs/01-notion-chat-protocol.md §6.
# --------------------------------------------------------------------------- #

class TestProviderContinuation:
    @staticmethod
    def _short_reply_ndjson(text: str = "ok") -> bytes:
        return _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference",
                          "value": [{"type": "text", "content": text}]}}]},
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/0/model", "v": "apricot-sorbet-high"}]},
        )

    async def test_first_turn_writes_thread_state(self, tmp_path: Path):
        def handler(_):
            return httpx.Response(200, content=self._short_reply_ndjson())
        client, _ = _mock_client(tmp_path, handler)
        try:
            resp = await client.complete(prompt="hi")
        finally:
            await client.aclose()

        state_file = tmp_path / "threads" / f"{resp.thread_id}.json"
        assert state_file.exists()
        state = json.loads(state_file.read_text(encoding="utf-8"))
        assert state["thread_id"] == resp.thread_id
        assert state["notion_model"] == "apricot-sorbet-high"
        assert state["updated_config_ids"] == []  # no past turns yet
        assert state["config_id"]   # populated
        assert state["context_id"]  # populated
        assert state["original_datetime"]

    async def test_continuation_payload_matches_capture(self, tmp_path: Path):
        """Turn 1 saves state; turn 2 (--thread-id) rebuilds the partial
        transcript shape captured in docs/01 §6.2."""
        def handler(_):
            return httpx.Response(200, content=self._short_reply_ndjson())
        client, requests = _mock_client(tmp_path, handler)
        try:
            r1 = await client.complete(prompt="turn 1")
            r2 = await client.complete(prompt="turn 2", thread_id=r1.thread_id)
        finally:
            await client.aclose()

        assert r2.thread_id == r1.thread_id
        assert len(requests) == 2
        body = json.loads(requests[1].content)

        # Top-level continuation flags
        assert body["threadId"] == r1.thread_id
        assert body["createThread"] is False
        assert body["isPartialTranscript"] is True
        assert body["generateTitle"] is False
        assert body["setUnreadState"] is True
        assert body["asPatchResponse"] is True
        assert "threadParentPointer" not in body

        # Turn-1 state ids/datetime are reused into turn 2's transcript
        turn1_body = json.loads(requests[0].content)
        cfg_id_1 = turn1_body["transcript"][0]["id"]
        ctx_id_1 = turn1_body["transcript"][1]["id"]
        ctx_dt_1 = turn1_body["transcript"][1]["value"]["currentDatetime"]

        transcript = body["transcript"]
        assert transcript[0]["id"]   == cfg_id_1
        assert transcript[0]["type"] == "config"
        assert transcript[0]["value"]["modelFromUser"] is False  # subsequent turn
        assert transcript[1]["id"]   == ctx_id_1
        assert transcript[1]["type"] == "context"
        assert transcript[1]["value"]["currentDatetime"] == ctx_dt_1

        # Exactly 1 updated-config block (one past assistant turn), and
        # its id is a NEW uuid — not a re-use of cfg_id_1.
        uc_blocks = [t for t in transcript if t["type"] == "updated-config"]
        assert len(uc_blocks) == 1
        assert uc_blocks[0]["id"] != cfg_id_1
        assert uc_blocks[0]["id"]  # non-empty

        # Last block is the new user message
        assert transcript[-1]["type"]  == "user"
        assert transcript[-1]["value"] == [["turn 2"]]

    async def test_continuation_appends_updated_config_id(self, tmp_path: Path):
        """After N continuations, state has N updated_config_ids."""
        def handler(_):
            return httpx.Response(200, content=self._short_reply_ndjson())
        client, _ = _mock_client(tmp_path, handler)
        try:
            r1 = await client.complete(prompt="turn 1")
            await client.complete(prompt="turn 2", thread_id=r1.thread_id)
            await client.complete(prompt="turn 3", thread_id=r1.thread_id)
        finally:
            await client.aclose()

        state = json.loads(
            (tmp_path / "threads" / f"{r1.thread_id}.json").read_text("utf-8")
        )
        # 2 continuations ⇒ 2 updated-config ids accumulated
        assert len(state["updated_config_ids"]) == 2
        # All distinct
        assert len(set(state["updated_config_ids"])) == 2

    async def test_continuation_missing_state_raises(self, tmp_path: Path):
        def handler(_):
            raise AssertionError("handler should not be called")
        client, requests = _mock_client(tmp_path, handler)
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(
                    prompt="hi",
                    thread_id="11111111-2222-3333-4444-555555555555",
                )
        finally:
            await client.aclose()
        # No request to Notion if we can't even build the body
        assert requests == []
        # ErrorCode contract (also covered in test_error_codes.py)
        assert exc.value.code == "thread_state_missing"

    async def test_continuation_locks_model_to_thread_original(self, tmp_path: Path):
        """`--model` on continuation is ignored — model comes from state."""
        def handler(_):
            return httpx.Response(200, content=self._short_reply_ndjson())
        client, requests = _mock_client(tmp_path, handler)
        try:
            r1 = await client.complete(prompt="turn 1")
            # Try to switch to sonnet on continuation — should be ignored.
            await client.complete(
                prompt="turn 2",
                thread_id=r1.thread_id,
                model="sonnet-4.6",
            )
        finally:
            await client.aclose()

        body2 = json.loads(requests[1].content)
        # Still apricot-sorbet-high (turn-1 default), not the sonnet alias
        assert body2["transcript"][0]["value"]["model"] == "apricot-sorbet-high"
