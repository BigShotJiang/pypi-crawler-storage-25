"""Unit tests for the doctor CLI subcommand's pure renderer.

The HTTP-and-account-aware part of doctor is covered by live smoke
against a real account; this file pins the report formatting so future
changes don't accidentally break consumers that grep for the icons or
the JSON shape.
"""
from __future__ import annotations

import json

from notion_agent_cli.cli.__main__ import _render_doctor


def test_render_human_includes_icons_and_details():
    out = _render_doctor(
        [
            ("ok",   "step one",   "details one"),
            ("fail", "step two",   "[auth_invalid] token expired"),
            ("info", "step three", "(advisory)"),
        ],
        as_json=False,
    )
    lines = out.splitlines()
    assert lines[0].startswith("[ok]")
    assert "step one" in lines[0]
    assert "details one" in lines[0]
    assert lines[1].startswith("[FAIL]")
    assert "auth_invalid" in lines[1]
    assert lines[2].startswith("[..]")


def test_render_human_omits_em_dash_when_detail_empty():
    out = _render_doctor([("ok", "no detail step", "")], as_json=False)
    # No "  --  " trailing when detail is blank.
    assert "  --" not in out
    assert out == "[ok]   no detail step"


def test_render_json_emits_structured_list():
    out = _render_doctor(
        [
            ("ok",   "check 1", "ok-detail"),
            ("fail", "check 2", "[code] msg"),
        ],
        as_json=True,
    )
    parsed = json.loads(out)
    assert parsed == [
        {"status": "ok",   "check": "check 1", "detail": "ok-detail"},
        {"status": "fail", "check": "check 2", "detail": "[code] msg"},
    ]
