"""Tests for ``notion_agent_cli.serve`` — the FastAPI HTTP wrapper.

Each test builds an isolated FastAPI app + a ``NotionAgentClient`` wired
through ``httpx.MockTransport`` so no real network is touched, then
exercises the app via ``httpx.AsyncClient(transport=ASGITransport(app))``.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient
from notion_agent_cli.serve import create_app

# --------------------------------------------------------------------------- #
# Fixtures + helpers
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":              "v03:test-token",
        "user_id":               "11111111-1111-1111-1111-111111111111",
        "user_name":             "Test User",
        "user_email":            "test@example.com",
        "space_id":              "22222222-2222-2222-2222-222222222222",
        "space_name":            "Test Space",
        "space_view_id":         "33333333-3333-3333-3333-333333333333",
        "browser_id":            "44444444-4444-4444-4444-444444444444",
        "device_id":             "55555555-5555-5555-5555-555555555555",
        "agent_name":            "Jarvis",
        "agent_context_page_id": "66666666-6666-6666-6666-666666666666",
        "default_model":         "opus-4.7",
    }), encoding="utf-8")
    return p


def _ndjson(*events: dict[str, Any]) -> bytes:
    return ("\n".join(json.dumps(e) for e in events) + "\n").encode("utf-8")


def _build_app_with_handler(
    tmp_path: Path,
    handler: Callable[[httpx.Request], httpx.Response],
):
    """Build app + return (app, mock_http_client, captured_requests)."""
    captured: list[httpx.Request] = []

    def _h(req: httpx.Request) -> httpx.Response:
        captured.append(req)
        return handler(req)

    transport = httpx.MockTransport(_h)
    http = httpx.AsyncClient(transport=transport)
    client = NotionAgentClient(
        _account_file(tmp_path),
        http_client=http,
        thread_state_dir=tmp_path / "threads",
    )
    app = create_app(_account_file(tmp_path))
    # Override get_client dependency — find by inspecting routes.
    # The dependency function was defined inside create_app so we
    # need to reach into the app's dependency overrides via the
    # FastAPI route table. Simplest: set app.state.client and
    # override get_client lookups by replacing the function in
    # dependency_overrides. Since get_client is a closure, we
    # instead reset app.state.client directly — and replace any
    # dependency lookup that returns it.
    app.state.client = client
    return app, http, client, captured


async def _asgi_client(app) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://test",
    )


# Short-reply NDJSON used by /chat happy-path tests.
def _short_reply_ndjson() -> bytes:
    return _ndjson(
        {"type": "patch",
         "v": [{"o": "a", "p": "/s/-",
                "v": {"type": "agent-inference",
                      "value": [{"type": "text", "content": "Hello, world!"}]}}]},
        {"type": "patch",
         "v": [
             {"o": "a", "p": "/s/0/inputTokens", "v": 12},
             {"o": "a", "p": "/s/0/outputTokens", "v": 5},
             {"o": "a", "p": "/s/0/model", "v": "apricot-sorbet-high"},
         ]},
    )


def _stream_ndjson() -> bytes:
    return _ndjson(
        {"type": "patch",
         "v": [{"o": "a", "p": "/s/-",
                "v": {"type": "agent-inference",
                      "value": [{"type": "text", "content": ""}]}}]},
        {"type": "patch",
         "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "Hel"}]},
        {"type": "patch",
         "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "lo"}]},
        {"type": "patch",
         "v": [{"o": "x", "p": "/s/0/value/0/content", "v": "!"}]},
    )


# Routing the inference URL — used by the mock handler when we need
# different responses depending on the path.
_INFERENCE_PATH = "/api/v3/runInferenceTranscript"
_LOAD_USER_PATH = "/api/v3/loadUserContent"


# --------------------------------------------------------------------------- #
# /chat blocking happy path
# --------------------------------------------------------------------------- #

class TestServeChat:
    async def test_chat_blocking_returns_response(self, tmp_path: Path):
        def handler(req: httpx.Request) -> httpx.Response:
            assert req.url.path == _INFERENCE_PATH
            return httpx.Response(200, content=_short_reply_ndjson())

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.post("/chat", json={"prompt": "hi"})
            assert r.status_code == 200
            body = r.json()
            assert body["text"] == "Hello, world!"
            assert body["model"] == "apricot-sorbet-high"
            assert body["thread_id"]
            assert body["usage"]["input_tokens"] == 12
            assert body["usage"]["output_tokens"] == 5
        finally:
            await client.aclose()
            await http.aclose()

    async def test_chat_sse_streams_chunks_then_done(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content=_stream_ndjson())

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.post("/chat",
                                  json={"prompt": "hi", "stream": True})
            assert r.status_code == 200
            assert r.headers["content-type"].startswith("text/event-stream")

            # Parse "data: ...\n\n" frames.
            frames = [
                line[len("data: "):]
                for line in r.text.split("\n\n")
                if line.startswith("data: ")
            ]
            # 3 text chunks + 1 [DONE]
            assert frames[-1] == "[DONE]"
            payloads = [json.loads(f) for f in frames[:-1]]
            assert [p["text"] for p in payloads] == ["Hel", "lo", "!"]
        finally:
            await client.aclose()
            await http.aclose()

    async def test_chat_with_thread_id_loads_state(self, tmp_path: Path):
        """Two-turn: first /chat creates state, second /chat with thread_id
        round-trips through it — we verify the second body carries
        isPartialTranscript=true."""
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(200, content=_short_reply_ndjson())

        app, http, client, captured = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r1 = await ac.post("/chat", json={"prompt": "turn 1"})
                assert r1.status_code == 200
                tid = r1.json()["thread_id"]
                r2 = await ac.post(
                    "/chat",
                    json={"prompt": "turn 2", "thread_id": tid},
                )
            assert r2.status_code == 200
            # Second inference call should be a partial transcript.
            inference_calls = [
                req for req in captured if req.url.path == _INFERENCE_PATH
            ]
            assert len(inference_calls) == 2
            body2 = json.loads(inference_calls[1].content)
            assert body2["isPartialTranscript"] is True
            assert body2["threadId"] == tid
        finally:
            await client.aclose()
            await http.aclose()

    async def test_chat_401_bubbles_with_auth_invalid(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"name": "Unauthorized"})

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.post("/chat", json={"prompt": "hi"})
            assert r.status_code == 401
            body = r.json()
            assert body["code"] == "auth_invalid"
        finally:
            await client.aclose()
            await http.aclose()


# --------------------------------------------------------------------------- #
# /healthz
# --------------------------------------------------------------------------- #

class TestServeHealthz:
    async def test_healthz_passes_on_valid_account(self, tmp_path: Path):
        # loadUserContent must return a sane recordMap.
        def handler(req: httpx.Request) -> httpx.Response:
            assert req.url.path == _LOAD_USER_PATH
            return httpx.Response(200, json={
                "recordMap": {"space": {"22222222-2222-2222-2222-222222222222": {}}},
            })

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.get("/healthz")
            assert r.status_code == 200
            body = r.json()
            assert body["status"] == "ok"
            assert any(c["check"] == "live_ping" for c in body["checks"])
        finally:
            await client.aclose()
            await http.aclose()

    async def test_healthz_503_on_auth_failure(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="nope")

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.get("/healthz")
            assert r.status_code == 503
            body = r.json()
            assert body["status"] == "fail"
            assert any(c["check"] == "live_ping" and c["status"] == "fail"
                       for c in body["checks"])
        finally:
            await client.aclose()
            await http.aclose()


# --------------------------------------------------------------------------- #
# /agents + /threads
# --------------------------------------------------------------------------- #

def _custom_agents_response() -> dict[str, Any]:
    return {
        "agentIds": ["agent-a", "agent-b"],
        "activityScores": [
            {"parent_id": "agent-a", "activity_score": 200},
            {"parent_id": "agent-b", "activity_score": 100},
        ],
        "mostRecentTranscripts": [
            {"id": "th-1", "title": "T1", "parent_id": "agent-a",
             "created_time": 1000, "updated_time": 2000,
             "created_by_id": "u", "created_source": "ai_module"},
            {"id": "th-2", "title": "T2", "parent_id": "agent-b",
             "created_time": 500, "updated_time": 800,
             "created_by_id": "u", "created_source": "ai_module"},
        ],
    }


class TestServeAgentsThreads:
    async def test_agents_list(self, tmp_path: Path):
        def handler(req: httpx.Request) -> httpx.Response:
            assert req.url.path == "/api/v3/getCustomAgents"
            return httpx.Response(200, json=_custom_agents_response())

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.get("/agents")
            assert r.status_code == 200
            data = r.json()
            # Sorted by activity desc — agent-a (200) before agent-b (100).
            assert [a["agent_id"] for a in data] == ["agent-a", "agent-b"]
            assert data[0]["most_recent_thread_title"] == "T1"
        finally:
            await client.aclose()
            await http.aclose()

    async def test_threads_list_with_agent_filter(self, tmp_path: Path):
        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=_custom_agents_response())

        app, http, client, _ = _build_app_with_handler(tmp_path, handler)
        try:
            async with await _asgi_client(app) as ac:
                r = await ac.get("/threads", params={"agent": "agent-b"})
            assert r.status_code == 200
            data = r.json()
            assert len(data) == 1
            assert data[0]["thread_id"] == "th-2"
        finally:
            await client.aclose()
            await http.aclose()


# --------------------------------------------------------------------------- #
# pytest fixtures
# --------------------------------------------------------------------------- #

@pytest.fixture(autouse=True)
def _no_real_home(monkeypatch, tmp_path):
    """Defensive — guarantee nothing under tests touches the user's
    real ``~/.notionagents/`` directory even on accidents (the per-test
    overrides set ``thread_state_dir`` explicitly, but this is belt +
    suspenders)."""
    monkeypatch.setenv("HOME", str(tmp_path))
