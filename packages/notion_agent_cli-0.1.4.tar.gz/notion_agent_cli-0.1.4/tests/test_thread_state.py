"""Tests for the per-thread JSON state store under ~/.notionagents/threads/.

The provider tests in ``test_notion_agent_cli.py`` cover the end-to-end
save → reload → partial-transcript-build round-trip; this file pins the
storage primitives in isolation so a regression here surfaces at the
right granularity.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from notion_agent_cli import ErrorCode, NotionAgentError
from notion_agent_cli.thread_state import (
    ThreadState,
    load_thread_state,
    save_thread_state,
    thread_state_path,
)


def _state(**overrides) -> ThreadState:
    base = {
        "thread_id":         "th-1234",
        "config_id":         "cfg-aaaa",
        "context_id":        "ctx-bbbb",
        "original_datetime": "2026-05-15T22:17:16.188-07:00",
        "notion_model":      "apricot-sorbet-high",
        "updated_config_ids": ["uc-1"],
        "last_activity_iso": "2026-05-16T01:18:12.000-07:00",
    }
    base.update(overrides)
    return ThreadState(**base)


class TestThreadStateRoundTrip:
    def test_save_then_load(self, tmp_path: Path):
        s = _state()
        out = save_thread_state(s, tmp_path)
        assert out == tmp_path / "th-1234.json"
        assert out.exists()

        loaded = load_thread_state("th-1234", tmp_path)
        assert loaded == s

    def test_save_creates_parent_dir(self, tmp_path: Path):
        base = tmp_path / "does" / "not" / "exist"
        assert not base.exists()
        save_thread_state(_state(), base)
        assert (base / "th-1234.json").exists()

    def test_save_overwrites_existing(self, tmp_path: Path):
        save_thread_state(_state(updated_config_ids=["a"]), tmp_path)
        save_thread_state(_state(updated_config_ids=["a", "b"]), tmp_path)
        loaded = load_thread_state("th-1234", tmp_path)
        assert loaded.updated_config_ids == ["a", "b"]

    def test_default_base_dir_resolves_to_home(self):
        # We don't actually write — just confirm the path resolution
        # points where the rest of the system expects it.
        p = thread_state_path("th-xyz")
        assert p == Path.home() / ".notionagents" / "threads" / "th-xyz.json"


class TestThreadStateErrors:
    def test_load_missing_raises_thread_state_missing(self, tmp_path: Path):
        with pytest.raises(NotionAgentError) as exc:
            load_thread_state("nope", tmp_path)
        assert exc.value.code == ErrorCode.THREAD_STATE_MISSING

    def test_load_malformed_raises_thread_state_malformed(self, tmp_path: Path):
        p = tmp_path / "bad.json"
        p.write_text("definitely not json {", encoding="utf-8")
        with pytest.raises(NotionAgentError) as exc:
            load_thread_state("bad", tmp_path)
        assert exc.value.code == ErrorCode.THREAD_STATE_MALFORMED


class TestThreadStateSchema:
    def test_json_keys_match_dataclass_fields(self, tmp_path: Path):
        s = _state()
        save_thread_state(s, tmp_path)
        raw = json.loads((tmp_path / "th-1234.json").read_text(encoding="utf-8"))
        assert set(raw.keys()) == {
            "thread_id", "config_id", "context_id",
            "original_datetime", "notion_model",
            "updated_config_ids", "last_activity_iso",
        }
