"""Unit tests for the bootstrap module.

Covers:

- :func:`parse_browser_cookie` — pure string-splitting helper used by the
  ``--cookie`` CLI shortcut.
- :func:`bootstrap_account` end-to-end against ``httpx.MockTransport``,
  exercising the ``/loadUserContent`` round-trip + record-map parsing
  paths that are otherwise unverified.
"""
from __future__ import annotations

import uuid as _uuid
from typing import Any

import httpx
import pytest

from notion_agent_cli.bootstrap import (
    AmbiguousWorkspaceError,
    bootstrap_account,
    parse_browser_cookie,
)
from notion_agent_cli.exceptions import NotionAgentError

USER_ID = "11111111-1111-1111-1111-111111111111"


# --------------------------------------------------------------------------- #
# parse_browser_cookie — pure helper, no network
# --------------------------------------------------------------------------- #

class TestParseBrowserCookie:
    def test_happy_path(self):
        cookie = (
            "notion_browser_id=8f74fbbe-2dfb-4c21-b948-40f9d4d553be; "
            "notion_user_id=3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2; "
            "token_v2=v03%3AeyJhbG"
        )
        parsed = parse_browser_cookie(cookie)
        assert parsed["notion_browser_id"] == "8f74fbbe-2dfb-4c21-b948-40f9d4d553be"
        assert parsed["notion_user_id"] == "3f4b90ff-b3eb-4e34-b080-0b45a23f4fa2"
        # URL-encoded token preserved verbatim — that's the form Notion expects back.
        assert parsed["token_v2"] == "v03%3AeyJhbG"

    def test_empty_string(self):
        assert parse_browser_cookie("") == {}

    def test_only_separators(self):
        assert parse_browser_cookie("   ;  ; ") == {}

    def test_entry_without_equals_dropped(self):
        parsed = parse_browser_cookie("k1=v1; badentry; k2=v2")
        assert parsed == {"k1": "v1", "k2": "v2"}

    def test_value_containing_equals_preserved(self):
        # token_v2 sometimes contains base64 padding (=, ==) after URL-decoding
        # context, and partition('=') keeps the rest of the value intact.
        parsed = parse_browser_cookie("token_v2=v03=base64==; foo=bar")
        assert parsed["token_v2"] == "v03=base64=="
        assert parsed["foo"] == "bar"

    def test_url_encoded_value_kept_verbatim(self):
        parsed = parse_browser_cookie("notion_users=[%22abc%22]")
        assert parsed["notion_users"] == "[%22abc%22]"

    def test_trailing_semicolon_tolerated(self):
        parsed = parse_browser_cookie("token_v2=v03:abc;")
        assert parsed == {"token_v2": "v03:abc"}


# --------------------------------------------------------------------------- #
# Fixtures + MockTransport plumbing
# --------------------------------------------------------------------------- #

def _record(value: dict[str, Any]) -> dict[str, Any]:
    """Notion record-map entries wrap the payload in {"value": {"value": {...}}}."""
    return {"role": "reader", "value": {"role": "reader", "value": value}}


def _load_user_content_payload(
    *,
    user_id: str = USER_ID,
    spaces: list[tuple[str, str, str]],  # (space_id, name, domain)
    user_given: str = "Test",
    user_family: str = "User",
    user_email: str = "test@example.com",
) -> dict[str, Any]:
    space_records: dict[str, Any] = {}
    space_views: dict[str, Any] = {}
    for space_id, name, domain in spaces:
        space_records[space_id] = _record({"name": name, "domain": domain})
        sv_id = f"sv-{space_id}"
        space_views[sv_id] = _record({"space_id": space_id})
    return {
        "recordMap": {
            "space": space_records,
            "space_view": space_views,
            "notion_user": {
                user_id: _record({
                    "given_name": user_given,
                    "family_name": user_family,
                    "email": user_email,
                }),
            },
        },
    }


def _mock_client(
    payload: dict[str, Any] | None = None,
    status_code: int = 200,
) -> httpx.AsyncClient:
    def handler(_req: httpx.Request) -> httpx.Response:
        if status_code != 200:
            return httpx.Response(status_code, text="upstream boom")
        return httpx.Response(200, json=payload or {})
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


# --------------------------------------------------------------------------- #
# bootstrap_account — workspace selection + identity wiring
# --------------------------------------------------------------------------- #

class TestBootstrapAccount:
    async def test_single_workspace_no_disambig(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "personal-d")],
        )
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                http_client=client,
            )
        assert acc.space_id == "space-A-id"
        assert acc.space_name == "Personal"
        assert acc.space_view_id == "sv-space-A-id"
        assert acc.user_name == "Test User"
        assert acc.user_email == "test@example.com"
        assert acc.token_v2 == "v03:test"
        assert acc.browser_id == "bid"

    async def test_multi_workspace_picks_by_name(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "Alice WS", "alice-d"),
            ("space-B-id", "Bob WS",   "bob-d"),
        ])
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                space_name="Bob WS", http_client=client,
            )
        assert acc.space_id == "space-B-id"
        assert acc.space_name == "Bob WS"

    async def test_multi_workspace_name_match_is_case_insensitive(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "TP-Link", "tp-d"),
            ("space-B-id", "Other",   "other-d"),
        ])
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                space_name="tp-link", http_client=client,
            )
        assert acc.space_id == "space-A-id"

    async def test_multi_workspace_picks_by_domain(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "Alice WS", "alice-d"),
            ("space-B-id", "Bob WS",   "bob-d"),
        ])
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                space_domain="alice-d", http_client=client,
            )
        assert acc.space_id == "space-A-id"

    async def test_multi_workspace_no_disambig_raises_with_choices(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "Alice WS", "alice-d"),
            ("space-B-id", "Bob WS",   "bob-d"),
        ])
        async with _mock_client(payload) as client:
            with pytest.raises(AmbiguousWorkspaceError) as exc:
                await bootstrap_account(
                    token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                    http_client=client,
                )
        names = {w.space_name for w in exc.value.workspaces}
        assert names == {"Alice WS", "Bob WS"}

    async def test_name_mismatch_raises_ambiguous(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "Alice", "a-d"),
            ("space-B-id", "Bob",   "b-d"),
        ])
        async with _mock_client(payload) as client:
            with pytest.raises(AmbiguousWorkspaceError):
                await bootstrap_account(
                    token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                    space_name="Charlie", http_client=client,
                )

    async def test_domain_mismatch_raises_ambiguous(self):
        payload = _load_user_content_payload(spaces=[
            ("space-A-id", "Alice", "a-d"),
            ("space-B-id", "Bob",   "b-d"),
        ])
        async with _mock_client(payload) as client:
            with pytest.raises(AmbiguousWorkspaceError):
                await bootstrap_account(
                    token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                    space_domain="no-such-d", http_client=client,
                )

    async def test_no_workspaces_raises_explicit_error(self):
        payload = {"recordMap": {"space": {}}}
        async with _mock_client(payload) as client:
            with pytest.raises(NotionAgentError, match="no workspaces"):
                await bootstrap_account(
                    token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                    http_client=client,
                )

    async def test_http_500_raises_with_loaduser_marker(self):
        async with _mock_client(status_code=500) as client:
            with pytest.raises(NotionAgentError, match="loadUserContent failed"):
                await bootstrap_account(
                    token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                    http_client=client,
                )

    async def test_missing_user_record_does_not_crash(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        payload["recordMap"]["notion_user"] = {}  # strip user record entirely
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                http_client=client,
            )
        assert acc.user_name == ""
        assert acc.user_email == ""
        # Workspace still wired up correctly.
        assert acc.space_id == "space-A-id"

    async def test_browser_id_auto_generated_when_omitted(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, http_client=client,
            )
        # Bootstrap fills in a fresh uuid when caller didn't pass one.
        _uuid.UUID(acc.browser_id)
        _uuid.UUID(acc.device_id)

    async def test_jarvis_binding_round_trips(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid",
                agent_name="Jarvis", agent_accessory="cat",
                agent_context_page_id="page-uuid", http_client=client,
            )
        assert acc.has_jarvis_binding is True
        assert acc.agent_name == "Jarvis"
        assert acc.agent_accessory == "cat"
        assert acc.agent_context_page_id == "page-uuid"

    async def test_request_carries_required_notion_headers(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=payload)

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, browser_id="bid-123",
                http_client=client,
            )
        assert len(captured) == 1
        req = captured[0]
        assert str(req.url).endswith("/loadUserContent")
        assert req.headers["x-notion-active-user-header"] == USER_ID
        assert "token_v2=v03:test" in req.headers["cookie"]
        assert "notion_browser_id=bid-123" in req.headers["cookie"]

    # ------------------------------------------------------------------- #
    # token_v2-only bootstrap — user_id derived from the response.
    # ------------------------------------------------------------------- #

    async def test_token_v2_only_derives_user_id_from_response(self):
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        async with _mock_client(payload) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", http_client=client,
            )
        assert acc.user_id == USER_ID
        assert acc.user_name == "Test User"
        assert acc.user_email == "test@example.com"
        assert acc.space_id == "space-A-id"

    async def test_token_v2_only_request_omits_identity_signals(self):
        """When user_id isn't known yet, the bootstrap request must not
        send x-notion-active-user-header or include identity-bearing cookie
        entries — only token_v2 + browser_id go out, and Notion's response
        carries the user_id back."""
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=payload)

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            await bootstrap_account(
                token_v2="v03:test", browser_id="bid-only", http_client=client,
            )
        assert len(captured) == 1
        req = captured[0]
        assert "x-notion-active-user-header" not in req.headers
        cookie = req.headers["cookie"]
        assert "token_v2=v03:test" in cookie
        assert "notion_browser_id=bid-only" in cookie
        assert "notion_user_id=" not in cookie
        assert "notion_users=" not in cookie

    async def test_token_v2_only_empty_user_record_raises_auth_invalid(self):
        """If /loadUserContent succeeds with HTTP 200 but the response
        contains no notion_user record, the token didn't really
        authenticate. Bootstrap should call that out as auth_invalid
        rather than silently writing an account file with empty user_id."""
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        payload["recordMap"]["notion_user"] = {}
        async with _mock_client(payload) as client:
            with pytest.raises(NotionAgentError, match="no user record") as exc:
                await bootstrap_account(token_v2="v03:test", http_client=client)
        assert exc.value.code == "auth_invalid"

    async def test_explicit_user_id_overrides_derivation(self):
        """When the caller passes user_id, bootstrap must not silently
        substitute whatever the response says — operators sometimes
        pre-populate user_id from another source and the request still
        carries the active-user-header in that mode."""
        payload = _load_user_content_payload(
            spaces=[("space-A-id", "Personal", "d")],
        )
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=payload)

        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            acc = await bootstrap_account(
                token_v2="v03:test", user_id=USER_ID, http_client=client,
            )
        assert acc.user_id == USER_ID
        # Identity-bearing headers + cookie entries present in this mode.
        req = captured[0]
        assert req.headers["x-notion-active-user-header"] == USER_ID
        assert f"notion_user_id={USER_ID}" in req.headers["cookie"]
