"""Verify ErrorCode propagation from every raise site.

This is the contract test for the structured-error promise: automated
callers can branch on ``err.code`` without scraping the human message.
If a new raise site is added without a code, that site won't appear in
this file and will silently fall through to ``ErrorCode.UNKNOWN`` — the
fix is to add a code at the raise site AND a test here.
"""
from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from notion_agent_cli import ErrorCode, NotionAgentClient, NotionAgentError
from notion_agent_cli.account import load_notion_account
from notion_agent_cli.bootstrap import (
    AmbiguousWorkspaceError,
    bootstrap_account,
)
from notion_agent_cli.ndjson import NDJSONStreamParser
from notion_agent_cli.thread_state import load_thread_state


def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":   "v03:test",
        "user_id":    "11111111-1111-1111-1111-111111111111",
        "space_id":   "22222222-2222-2222-2222-222222222222",
        "space_name": "Test",
        "browser_id": "bid",
    }), encoding="utf-8")
    return p


def _ndjson(*events: dict) -> bytes:
    return ("\n".join(json.dumps(e) for e in events) + "\n").encode("utf-8")


# --------------------------------------------------------------------------- #
# Construction + invariants
# --------------------------------------------------------------------------- #

class TestNotionAgentErrorBasics:
    def test_default_code_is_unknown(self):
        err = NotionAgentError("legacy raise site")
        assert err.code == ErrorCode.UNKNOWN
        assert err.code == "unknown"  # StrEnum compares to plain str

    def test_explicit_code(self):
        err = NotionAgentError("nope", code=ErrorCode.AUTH_INVALID)
        assert err.code == "auth_invalid"
        # str(err) still surfaces the human message
        assert "nope" in str(err)

    def test_error_code_is_str_enum(self):
        # Critical: branching on `.code == "auth_invalid"` must work
        # for callers that don't import ErrorCode.
        assert ErrorCode.AUTH_INVALID == "auth_invalid"
        assert ErrorCode("transport") == ErrorCode.TRANSPORT


# --------------------------------------------------------------------------- #
# account.py raise sites
# --------------------------------------------------------------------------- #

class TestAccountErrorCodes:
    def test_missing_file_is_account_missing(self, tmp_path: Path):
        with pytest.raises(NotionAgentError) as exc:
            load_notion_account(tmp_path / "nope.json")
        assert exc.value.code == ErrorCode.ACCOUNT_MISSING

    def test_malformed_json_is_account_malformed(self, tmp_path: Path):
        p = tmp_path / "bad.json"
        p.write_text("not json {", encoding="utf-8")
        with pytest.raises(NotionAgentError) as exc:
            load_notion_account(p)
        assert exc.value.code == ErrorCode.ACCOUNT_MALFORMED

    def test_missing_required_fields_is_account_invalid(self, tmp_path: Path):
        p = tmp_path / "thin.json"
        p.write_text(json.dumps({"token_v2": "v03:x"}), encoding="utf-8")  # missing user_id + space_id
        with pytest.raises(NotionAgentError) as exc:
            load_notion_account(p)
        assert exc.value.code == ErrorCode.ACCOUNT_INVALID


# --------------------------------------------------------------------------- #
# bootstrap.py raise sites
# --------------------------------------------------------------------------- #

def _mock_bootstrap(payload=None, status=200):
    def handler(_req):
        if status != 200:
            return httpx.Response(status, text="boom")
        return httpx.Response(200, json=payload or {})
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


class TestBootstrapErrorCodes:
    USER_ID = "11111111-1111-1111-1111-111111111111"

    async def test_401_is_auth_invalid(self):
        async with _mock_bootstrap(status=401) as c:
            with pytest.raises(NotionAgentError) as exc:
                await bootstrap_account(
                    token_v2="x", user_id=self.USER_ID, browser_id="b",
                    http_client=c,
                )
        assert exc.value.code == ErrorCode.AUTH_INVALID

    async def test_500_is_http_error(self):
        async with _mock_bootstrap(status=500) as c:
            with pytest.raises(NotionAgentError) as exc:
                await bootstrap_account(
                    token_v2="x", user_id=self.USER_ID, browser_id="b",
                    http_client=c,
                )
        assert exc.value.code == ErrorCode.HTTP_ERROR

    async def test_no_workspaces_is_workspace_empty(self):
        async with _mock_bootstrap({"recordMap": {"space": {}}}) as c:
            with pytest.raises(NotionAgentError) as exc:
                await bootstrap_account(
                    token_v2="x", user_id=self.USER_ID, browser_id="b",
                    http_client=c,
                )
        assert exc.value.code == ErrorCode.WORKSPACE_EMPTY

    async def test_multi_workspace_is_workspace_ambiguous(self):
        payload = {"recordMap": {
            "space": {
                "a": {"value": {"value": {"name": "Alice", "domain": "a"}}},
                "b": {"value": {"value": {"name": "Bob",   "domain": "b"}}},
            },
            "space_view": {},
            "notion_user": {},
        }}
        async with _mock_bootstrap(payload) as c:
            with pytest.raises(AmbiguousWorkspaceError) as exc:
                await bootstrap_account(
                    token_v2="x", user_id=self.USER_ID, browser_id="b",
                    http_client=c,
                )
        assert exc.value.code == ErrorCode.WORKSPACE_AMBIGUOUS


# --------------------------------------------------------------------------- #
# ndjson.py raise sites
# --------------------------------------------------------------------------- #

class TestNDJSONErrorCodes:
    def test_error_event_is_notion_error(self):
        p = NDJSONStreamParser()
        with pytest.raises(NotionAgentError) as exc:
            p.feed_line(json.dumps({"type": "error", "message": "quota"}))
        assert exc.value.code == ErrorCode.NOTION_ERROR

    def test_premium_event_is_premium_required(self):
        p = NDJSONStreamParser()
        with pytest.raises(NotionAgentError) as exc:
            p.feed_line(json.dumps({"type": "premium-feature-unavailable"}))
        assert exc.value.code == ErrorCode.PREMIUM_REQUIRED


# --------------------------------------------------------------------------- #
# provider.py raise sites (chat + fetch_available_models)
# --------------------------------------------------------------------------- #

def _mock_provider(handler, tmp_path):
    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    # thread_state_dir pinned to tmp_path so a success path (if a test
    # adds one later) doesn't pollute ~/.notionagents/threads/.
    return (
        NotionAgentClient(
            _account_file(tmp_path),
            http_client=http,
            thread_state_dir=tmp_path / "threads",
        ),
        http,
    )


class TestProviderChatErrorCodes:
    async def test_empty_prompt_is_empty_prompt(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: pytest.fail("handler should not be called"), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(prompt="   ")
            assert exc.value.code == ErrorCode.EMPTY_PROMPT
        finally:
            await http.aclose()

    async def test_both_text_delta_callbacks_is_invalid_callback(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: pytest.fail("handler should not be called"), tmp_path,
        )

        async def on_delta_async(_: str) -> None:
            pass

        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(
                    prompt="hi",
                    on_text_delta=lambda _c: None,
                    on_text_delta_async=on_delta_async,
                )
            assert exc.value.code == ErrorCode.INVALID_CALLBACK
        finally:
            await http.aclose()

    async def test_401_is_auth_invalid(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: httpx.Response(401, json={"name": "Unauthorized"}),
            tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(prompt="hi")
            assert exc.value.code == ErrorCode.AUTH_INVALID
        finally:
            await http.aclose()

    async def test_500_is_http_error(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: httpx.Response(500, text="boom"), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(prompt="hi")
            assert exc.value.code == ErrorCode.HTTP_ERROR
        finally:
            await http.aclose()

    async def test_empty_stream_is_empty_text(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: httpx.Response(200, content=b""), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(prompt="hi")
            assert exc.value.code == ErrorCode.EMPTY_TEXT
        finally:
            await http.aclose()

    async def test_mid_stream_error_is_notion_error(self, tmp_path: Path):
        ndjson = _ndjson(
            {"type": "patch",
             "v": [{"o": "a", "p": "/s/-",
                    "v": {"type": "agent-inference", "value": []}}]},
            {"type": "error", "message": "quota exhausted"},
        )
        client, http = _mock_provider(
            lambda _r: httpx.Response(200, content=ndjson), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.complete(prompt="hi")
            assert exc.value.code == ErrorCode.NOTION_ERROR
        finally:
            await http.aclose()


class TestThreadStateErrorCodes:
    def test_missing_file_is_thread_state_missing(self, tmp_path: Path):
        with pytest.raises(NotionAgentError) as exc:
            load_thread_state("no-such-thread", tmp_path)
        assert exc.value.code == ErrorCode.THREAD_STATE_MISSING

    def test_malformed_json_is_thread_state_malformed(self, tmp_path: Path):
        p = tmp_path / "bad.json"
        p.write_text("not json {", encoding="utf-8")
        with pytest.raises(NotionAgentError) as exc:
            load_thread_state("bad", tmp_path)
        assert exc.value.code == ErrorCode.THREAD_STATE_MALFORMED


class TestFetchModelsErrorCodes:
    async def test_401_is_auth_invalid(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: httpx.Response(401, text="nope"), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.fetch_available_models()
            assert exc.value.code == ErrorCode.AUTH_INVALID
        finally:
            await http.aclose()

    async def test_500_is_http_error(self, tmp_path: Path):
        client, http = _mock_provider(
            lambda _r: httpx.Response(500, text="boom"), tmp_path,
        )
        try:
            with pytest.raises(NotionAgentError) as exc:
                await client.fetch_available_models()
            assert exc.value.code == ErrorCode.HTTP_ERROR
        finally:
            await http.aclose()
