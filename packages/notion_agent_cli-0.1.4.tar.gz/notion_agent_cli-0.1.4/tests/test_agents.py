"""Unit tests for the agents module + /getCustomAgents wrapper.

Uses ``tests/fixtures/get_custom_agents.json`` — a sanitized copy of a
real Notion response (UUIDs and titles redacted to synthetic patterns
``a0000001-...`` for agents, ``70000001-...`` for threads, etc.).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from notion_agent_cli import NotionAgentClient, NotionAgentError
from notion_agent_cli.agents import (
    AgentSummary,
    ThreadSummary,
    extract_bot_name,
    parse_agents,
    parse_bot_records,
    parse_threads,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _load_fixture(name: str) -> dict[str, Any]:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# parse_threads
# --------------------------------------------------------------------------- #

class TestParseThreads:
    def test_real_fixture_yields_all_entries(self):
        data = _load_fixture("get_custom_agents.json")
        threads = parse_threads(data)
        assert len(threads) == len(data["mostRecentTranscripts"])
        # All ids preserved as strings
        for t in threads:
            assert isinstance(t.thread_id, str)
            assert t.thread_id.startswith("7")  # sanitized prefix for threads

    def test_real_fixture_sorted_newest_first(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Take entries with timestamps; verify monotonic non-increasing.
        timestamps = [
            (t.updated_at_ms or t.created_at_ms or 0) for t in threads
        ]
        assert timestamps == sorted(timestamps, reverse=True)

    def test_real_fixture_titles_round_trip_with_none(self):
        threads = parse_threads(_load_fixture("get_custom_agents.json"))
        # Some real transcripts had null titles — that should survive as None.
        any_none = any(t.title is None for t in threads)
        any_str = any(isinstance(t.title, str) for t in threads)
        assert any_none, "fixture should contain at least one null title"
        assert any_str

    def test_empty_response(self):
        assert parse_threads({}) == []
        assert parse_threads({"mostRecentTranscripts": []}) == []

    def test_skips_non_dict_and_missing_id(self):
        data = {"mostRecentTranscripts": [
            "not-a-dict",
            {"no_id_field": True},
            {"id": 42},
            {"id": "good", "title": "ok"},
        ]}
        threads = parse_threads(data)
        assert len(threads) == 1
        assert threads[0].thread_id == "good"

    def test_int_coercion_of_timestamps(self):
        # Notion returns timestamps as strings.
        data = {"mostRecentTranscripts": [
            {"id": "t1", "created_time": "1778017615141",
             "updated_time": "1778021049107"},
        ]}
        t = parse_threads(data)[0]
        assert t.created_at_ms == 1778017615141
        assert t.updated_at_ms == 1778021049107


# --------------------------------------------------------------------------- #
# parse_agents
# --------------------------------------------------------------------------- #

class TestParseAgents:
    def test_real_fixture_yields_all_agents(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        assert len(agents) == len(data["agentIds"])
        for a in agents:
            assert isinstance(a.agent_id, str)

    def test_real_fixture_active_agents_have_scores(self):
        data = _load_fixture("get_custom_agents.json")
        agents = parse_agents(data)
        # activityScores covered 12 of 19 agents in the captured fixture.
        scored = [a for a in agents if a.activity_score is not None]
        unscored = [a for a in agents if a.activity_score is None]
        assert len(scored) == len(data["activityScores"])
        assert len(unscored) == len(data["agentIds"]) - len(data["activityScores"])

    def test_active_agents_sort_before_inactive(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        seen_none = False
        for a in agents:
            if a.activity_score is None:
                seen_none = True
            elif seen_none:
                pytest.fail(
                    f"agent {a.agent_id} (score={a.activity_score}) followed "
                    f"a None-score agent — sort order broken"
                )

    def test_breadcrumb_uses_most_recent_thread_per_agent(self):
        agents = parse_agents(_load_fixture("get_custom_agents.json"))
        # At least one agent in the fixture has its breadcrumb set.
        with_breadcrumb = [a for a in agents if a.most_recent_thread_id]
        assert len(with_breadcrumb) >= 1
        # Spot check: breadcrumb thread id should belong to an entry whose
        # parent_id matches the agent_id.
        data = _load_fixture("get_custom_agents.json")
        ts_by_id = {t["id"]: t for t in data["mostRecentTranscripts"] if t.get("id")}
        for a in with_breadcrumb:
            assert ts_by_id[a.most_recent_thread_id]["parent_id"] == a.agent_id

    def test_empty_agent_ids(self):
        assert parse_agents({}) == []
        assert parse_agents({"agentIds": []}) == []

    def test_activity_score_dedup_keeps_highest(self):
        data = {
            "agentIds": ["a1"],
            "activityScores": [
                {"parent_id": "a1", "activity_score": "100"},
                {"parent_id": "a1", "activity_score": "200"},
                {"parent_id": "a1", "activity_score": "50"},
            ],
        }
        a = parse_agents(data)[0]
        assert a.activity_score == 200


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_custom_agents via MockTransport
# --------------------------------------------------------------------------- #

def _account_file(tmp_path: Path) -> Path:
    p = tmp_path / "notion_account.json"
    p.write_text(json.dumps({
        "token_v2":   "v03:test",
        "user_id":    "11111111-1111-1111-1111-111111111111",
        "space_id":   "22222222-2222-2222-2222-222222222222",
        "space_name": "T",
        "browser_id": "bid",
    }), encoding="utf-8")
    return p


class TestFetchCustomAgents:
    async def test_happy_path_returns_top_keys(self, tmp_path: Path):
        fixture = _load_fixture("get_custom_agents.json")
        captured: list[httpx.Request] = []

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            data = await client.fetch_custom_agents()

        assert set(data.keys()) >= {"agentIds", "mostRecentTranscripts",
                                    "activityScores"}
        req = captured[0]
        assert str(req.url).endswith("/getCustomAgents")
        assert req.headers["accept"] == "application/json"
        body = json.loads(req.content)
        assert body == {"spaceId": "22222222-2222-2222-2222-222222222222"}

    async def test_401_surfaces_auth_invalid_code(self, tmp_path: Path):
        from notion_agent_cli import ErrorCode

        def handler(_req: httpx.Request) -> httpx.Response:
            return httpx.Response(401, text="nope")

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            with pytest.raises(NotionAgentError) as exc:
                await client.fetch_custom_agents()
        assert exc.value.code == ErrorCode.AUTH_INVALID


# --------------------------------------------------------------------------- #
# Cross-check: parse_agents + parse_threads on the same fixture stay
# consistent — every breadcrumb thread id appears in the threads list.
# --------------------------------------------------------------------------- #

def test_breadcrumb_thread_ids_are_subset_of_threads_list():
    data = _load_fixture("get_custom_agents.json")
    agents = parse_agents(data)
    threads = parse_threads(data)
    thread_ids = {t.thread_id for t in threads}
    for a in agents:
        if a.most_recent_thread_id is not None:
            assert a.most_recent_thread_id in thread_ids


# --------------------------------------------------------------------------- #
# Bot-record name resolution via syncRecordValuesMain table=bot
# (v0.1.4: fix to the v0.1.3 P0-4 attempt that mistakenly used table=block)
# --------------------------------------------------------------------------- #

class TestExtractBotName:
    def test_simple_name(self):
        bot = {"name": "Jarvis", "type": "custom"}
        assert extract_bot_name(bot) == "Jarvis"

    def test_trims_whitespace(self):
        assert extract_bot_name({"name": "  Email Agent  "}) == "Email Agent"

    def test_missing_name_returns_none(self):
        assert extract_bot_name({}) is None
        assert extract_bot_name({"type": "workflow"}) is None
        assert extract_bot_name({"name": ""}) is None
        assert extract_bot_name({"name": "   "}) is None

    def test_non_string_name_safe(self):
        assert extract_bot_name({"name": 123}) is None
        assert extract_bot_name({"name": None}) is None

    def test_non_dict_input_safe(self):
        assert extract_bot_name(None) is None  # type: ignore[arg-type]
        assert extract_bot_name("not-a-dict") is None  # type: ignore[arg-type]


class TestParseBotRecords:
    def test_real_capture_shape(self):
        """The sanitized fixture mirrors the operator's live capture
        (Email Agent + Jarvis variants of the bot record).
        """
        resp = _load_fixture("sync_record_values_bot.json")
        out = parse_bot_records(resp)
        assert "a0000016-0000-0000-0000-000000000000" in out
        assert out["a0000016-0000-0000-0000-000000000000"]["name"] == "Email Agent"
        assert "a0000013-0000-0000-0000-000000000000" in out
        assert out["a0000013-0000-0000-0000-000000000000"]["name"] == "Jarvis"
        # The Email Agent is type=workflow + has a workflow_id; the
        # custom-type bot doesn't expose workflow_id. parse keeps both
        # transparently so callers can branch on `type` later.
        email = out["a0000016-0000-0000-0000-000000000000"]
        assert email["type"] == "workflow"
        assert email["workflow_id"] == "a0000016-1111-0000-0000-000000000000"
        jarvis = out["a0000013-0000-0000-0000-000000000000"]
        assert jarvis["type"] == "custom"
        assert "workflow_id" not in jarvis

    def test_double_nested_value(self):
        resp = {"recordMap": {"bot": {
            "b1": {"value": {"value": {"name": "Hi"}}},
        }}}
        assert parse_bot_records(resp)["b1"]["name"] == "Hi"

    def test_single_nested_fallback(self):
        resp = {"recordMap": {"bot": {
            "b2": {"value": {"name": "Yo"}},
        }}}
        assert parse_bot_records(resp)["b2"]["name"] == "Yo"

    def test_empty_or_malformed(self):
        assert parse_bot_records({}) == {}
        assert parse_bot_records({"recordMap": {}}) == {}
        assert parse_bot_records({"recordMap": {"bot": "wrong-type"}}) == {}
        # The /api/v3/syncRecordValuesMain happy-empty signature
        assert parse_bot_records({"recordMap": {"bot": {}}}) == {}


class TestParseAgentsWithNames:
    def test_names_filled_when_provided(self):
        data = _load_fixture("get_custom_agents.json")
        # Pick the first three real agent ids to attach names to.
        all_ids = [x for x in data.get("agentIds", []) if isinstance(x, str)]
        names = {all_ids[0]: "Jarvis", all_ids[1]: "Friday"}
        agents = parse_agents(data, names=names)
        by_id = {a.agent_id: a for a in agents}
        assert by_id[all_ids[0]].name == "Jarvis"
        assert by_id[all_ids[1]].name == "Friday"
        # Unmentioned agents stay name=None.
        unset = [a for a in agents if a.agent_id not in names]
        assert unset and all(a.name is None for a in unset)

    def test_default_is_none(self):
        data = _load_fixture("get_custom_agents.json")
        for a in parse_agents(data):
            assert a.name is None


# --------------------------------------------------------------------------- #
# NotionAgentClient.fetch_bot_records — provider-side wiring
# --------------------------------------------------------------------------- #

class TestFetchBotRecords:
    async def test_empty_ids_short_circuits(self, tmp_path: Path):
        """No HTTP call when given an empty id list."""
        called = False

        def handler(_req: httpx.Request) -> httpx.Response:  # pragma: no cover
            nonlocal called
            called = True
            return httpx.Response(500)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            out = await client.fetch_bot_records([])
        assert called is False
        assert out == {"recordMap": {"bot": {}}}

    async def test_posts_bot_pointers_without_spaceid(self, tmp_path: Path):
        """Each pointer is {table:'bot', id, version:-1}; no spaceId.

        Captured from the chat panel's "switch custom agent" UI:
        Notion authenticates on the session cookie alone for bot
        records — including spaceId in the pointer would 400.
        """
        captured: list[httpx.Request] = []
        fixture = _load_fixture("sync_record_values_bot.json")

        def handler(req: httpx.Request) -> httpx.Response:
            captured.append(req)
            return httpx.Response(200, json=fixture)

        transport = httpx.MockTransport(handler)
        async with httpx.AsyncClient(transport=transport) as http:
            client = NotionAgentClient(_account_file(tmp_path), http_client=http)
            raw = await client.fetch_bot_records([
                "a0000016-0000-0000-0000-000000000000",
                "a0000013-0000-0000-0000-000000000000",
            ])

        assert str(captured[0].url).endswith("/syncRecordValuesMain")
        body = json.loads(captured[0].content)
        assert len(body["requests"]) == 2
        assert all(r["pointer"]["table"] == "bot" for r in body["requests"])
        assert all("spaceId" not in r["pointer"] for r in body["requests"])
        assert all(r["version"] == -1 for r in body["requests"])
        # Round-trips through parse_bot_records → names readable
        flat = parse_bot_records(raw)
        assert flat["a0000016-0000-0000-0000-000000000000"]["name"] == "Email Agent"
        assert flat["a0000013-0000-0000-0000-000000000000"]["name"] == "Jarvis"


def test_dataclasses_are_frozen():
    # Frozen dataclasses are immutable — tests + downstream wrappers
    # can stash them in sets / dict keys safely.
    a = AgentSummary("x", None, None, None, None)
    t = ThreadSummary("y", None, None, None, None, None, None)
    with pytest.raises((AttributeError, Exception)):  # FrozenInstanceError
        a.agent_id = "z"  # type: ignore[misc]
    with pytest.raises((AttributeError, Exception)):
        t.thread_id = "z"  # type: ignore[misc]
