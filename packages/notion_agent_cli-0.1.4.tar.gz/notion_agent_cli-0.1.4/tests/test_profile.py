"""Tests for ``notion_agent_cli.profile`` — multi-workspace symlink swap.

Tests pin the symlink-based dispatch model:
- ``list_profiles`` enumerates ``*.json`` files in the profile dir,
  excluding the ``notion_account.json`` symlink target itself.
- ``use_profile`` retargets the symlink atomically.
- ``current_profile`` resolves the symlink back to a named profile.
- ``migrate_account_to_profile`` promotes a pre-profile setup.

The CLI plumbing on top is covered by smoke-testing through ``main([...])``.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from notion_agent_cli.exceptions import ErrorCode, NotionAgentError
from notion_agent_cli.profile import (
    current_profile,
    list_profiles,
    migrate_account_to_profile,
    use_profile,
)


def _write_profile(profile_dir: Path, name: str, **fields) -> Path:
    profile_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "token_v2": f"v03:{name}-token",
        "user_id": "11111111-1111-1111-1111-111111111111",
        "space_id": f"space-{name}",
        "space_name": name.title(),
        "browser_id": "bid",
        **fields,
    }
    p = profile_dir / f"{name}.json"
    p.write_text(json.dumps(payload), encoding="utf-8")
    return p


# --------------------------------------------------------------------------- #
# list_profiles
# --------------------------------------------------------------------------- #

class TestListProfiles:
    def test_empty_dir_returns_empty_list(self, tmp_path: Path):
        assert list_profiles(tmp_path) == []

    def test_missing_dir_returns_empty_list(self, tmp_path: Path):
        assert list_profiles(tmp_path / "nope") == []

    def test_enumerates_named_profiles(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        _write_profile(tmp_path, "beta")
        profiles = list_profiles(tmp_path)
        names = {p.name for p in profiles}
        assert names == {"alpha", "beta"}

    def test_skips_notion_account_target(self, tmp_path: Path):
        # notion_account.json (the symlink target) is dispatch, not a profile.
        _write_profile(tmp_path, "alpha")
        (tmp_path / "notion_account.json").symlink_to("alpha.json")
        profiles = list_profiles(tmp_path)
        assert [p.name for p in profiles] == ["alpha"]

    def test_marks_active_profile(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        _write_profile(tmp_path, "beta")
        (tmp_path / "notion_account.json").symlink_to("beta.json")
        profiles = list_profiles(tmp_path)
        active = {p.name: p.is_active for p in profiles}
        assert active == {"alpha": False, "beta": True}


# --------------------------------------------------------------------------- #
# use_profile
# --------------------------------------------------------------------------- #

class TestUseProfile:
    def test_swaps_symlink_to_named_profile(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        _write_profile(tmp_path, "beta")
        (tmp_path / "notion_account.json").symlink_to("alpha.json")

        link = use_profile("beta", tmp_path)
        assert link.is_symlink()
        # Resolves to the new target.
        assert (tmp_path / "notion_account.json").resolve() == \
            (tmp_path / "beta.json").resolve()

    def test_creates_symlink_when_absent(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        # No notion_account.json yet — `profile use` initializes it.
        use_profile("alpha", tmp_path)
        link = tmp_path / "notion_account.json"
        assert link.is_symlink()
        assert link.resolve() == (tmp_path / "alpha.json").resolve()

    def test_missing_profile_raises_account_missing(self, tmp_path: Path):
        with pytest.raises(NotionAgentError) as exc:
            use_profile("ghost", tmp_path)
        assert exc.value.code == ErrorCode.ACCOUNT_MISSING

    def test_regular_file_at_link_target_refuses_overwrite(self, tmp_path: Path):
        """Plain notion_account.json (not a symlink) → ask the user to
        migrate first, don't clobber their credential."""
        _write_profile(tmp_path, "alpha")
        # Existing notion_account.json as a regular file.
        (tmp_path / "notion_account.json").write_text("{}", encoding="utf-8")
        with pytest.raises(NotionAgentError) as exc:
            use_profile("alpha", tmp_path)
        assert exc.value.code == ErrorCode.ACCOUNT_INVALID

    @pytest.mark.parametrize(
        "name", ["", "notion_account", "../escape", ".hidden", "with/slash"],
    )
    def test_invalid_names_rejected(self, tmp_path: Path, name: str):
        with pytest.raises(NotionAgentError):
            use_profile(name, tmp_path)


# --------------------------------------------------------------------------- #
# current_profile
# --------------------------------------------------------------------------- #

class TestCurrentProfile:
    def test_returns_active_entry(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        (tmp_path / "notion_account.json").symlink_to("alpha.json")
        entry = current_profile(tmp_path)
        assert entry is not None
        assert entry.name == "alpha"
        assert entry.is_active is True

    def test_returns_none_when_no_symlink(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        # No symlink at all — operator hasn't adopted profiles.
        assert current_profile(tmp_path) is None

    def test_returns_none_when_link_doesnt_match_a_profile(self, tmp_path: Path):
        """notion_account.json as a regular file → no matching profile."""
        (tmp_path / "notion_account.json").write_text("{}", encoding="utf-8")
        assert current_profile(tmp_path) is None


# --------------------------------------------------------------------------- #
# migrate_account_to_profile
# --------------------------------------------------------------------------- #

class TestMigrate:
    def test_renames_and_relinks(self, tmp_path: Path):
        (tmp_path / "notion_account.json").write_text(
            json.dumps({"token_v2": "v03:x", "user_id": "u", "space_id": "s"}),
            encoding="utf-8",
        )
        link = migrate_account_to_profile("default", tmp_path)
        # Original file is now the named profile.
        assert (tmp_path / "default.json").exists()
        # And the symlink points at it.
        assert link.is_symlink()
        assert link.resolve() == (tmp_path / "default.json").resolve()

    def test_already_migrated_is_noop(self, tmp_path: Path):
        _write_profile(tmp_path, "alpha")
        (tmp_path / "notion_account.json").symlink_to("alpha.json")
        # No-op — already a symlink.
        migrate_account_to_profile("beta", tmp_path)
        # No new beta.json was created.
        assert not (tmp_path / "beta.json").exists()

    def test_collision_with_existing_profile_errors(self, tmp_path: Path):
        _write_profile(tmp_path, "default")
        (tmp_path / "notion_account.json").write_text("{}", encoding="utf-8")
        with pytest.raises(NotionAgentError) as exc:
            migrate_account_to_profile("default", tmp_path)
        assert exc.value.code == ErrorCode.ACCOUNT_INVALID

    def test_missing_account_file_errors(self, tmp_path: Path):
        with pytest.raises(NotionAgentError) as exc:
            migrate_account_to_profile("default", tmp_path)
        assert exc.value.code == ErrorCode.ACCOUNT_MISSING


# --------------------------------------------------------------------------- #
# CLI smoke
# --------------------------------------------------------------------------- #

class TestProfileCLI:
    def test_list_use_current_round_trip(self, tmp_path: Path, capsys):
        from notion_agent_cli.cli.__main__ import main

        _write_profile(tmp_path, "alpha")
        _write_profile(tmp_path, "beta")

        # list with no symlink yet
        rc = main(["profile", "list", "--profile-dir", str(tmp_path)])
        assert rc == 0
        out = capsys.readouterr().out
        assert "alpha" in out
        assert "beta" in out
        assert "* " not in out  # nothing active yet

        # use beta
        rc = main(["profile", "use", "beta", "--profile-dir", str(tmp_path)])
        assert rc == 0
        capsys.readouterr()  # drain the "[profile use]" confirmation

        # current → beta
        rc = main(["profile", "current", "--profile-dir", str(tmp_path)])
        assert rc == 0
        assert capsys.readouterr().out.strip() == "beta"

        # list now marks beta active
        rc = main(["profile", "list", "--profile-dir", str(tmp_path)])
        assert rc == 0
        out = capsys.readouterr().out
        assert "* beta" in out
        assert "  alpha" in out
