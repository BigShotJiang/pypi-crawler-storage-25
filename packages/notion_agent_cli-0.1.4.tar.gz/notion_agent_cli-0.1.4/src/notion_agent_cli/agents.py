"""Parse ``/api/v3/getCustomAgents`` into agent + thread summaries.

A single round-trip to ``getCustomAgents`` answers both "what custom
agents do I have here?" and "what threads have I run recently?" —
:func:`parse_agents` / :func:`parse_threads` split the response into
two ranked lists the ``agents list`` / ``threads list`` CLI
subcommands print.

The endpoint does **not** return agent display names. To resolve
names we hit ``/api/v3/syncRecordValuesMain`` on table ``bot`` —
each Custom Agent is a ``bot`` record (the Notion internal data
model name for workflows / personas), **not** a page block.
``recordMap.bot.<id>.value.value`` carries ``{name, icon, type,
workflow_id, …}``. See :func:`extract_bot_name` /
:func:`parse_bot_records` and
:meth:`NotionAgentClient.fetch_bot_records`. The CLI calls this
lazily inside ``agents list`` and tolerates failure: an agent
without a resolved name shows up with ``name=None`` rather than
blocking the listing.

History: v0.1.3 shipped the lookup against ``table="block"``
(written from spec, not a live capture). It never returned a hit
on real workspaces — fixed in v0.1.4 once the operator captured the
real ``table="bot"`` request from Notion's chat panel.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True, frozen=True)
class ThreadSummary:
    """One entry from ``mostRecentTranscripts``."""
    thread_id:        str
    title:            str | None
    parent_agent_id:  str | None
    created_at_ms:    int | None
    updated_at_ms:    int | None
    created_by_id:    str | None
    created_source:   str | None


@dataclass(slots=True, frozen=True)
class AgentSummary:
    """One custom agent + its most recent activity breadcrumb.

    ``name`` is the agent's Notion page title (e.g. ``"Jarvis"``) when
    it has been resolved via :meth:`NotionAgentClient.fetch_block_records`
    + :func:`extract_page_title`. It is ``None`` when the caller chose
    not to resolve names (``parse_agents`` without ``names=``) or when
    the syncRecordValuesMain lookup failed for that page.
    """
    agent_id:                  str
    activity_score:            int | None  # epoch ms, None if no activity recorded
    most_recent_thread_id:     str | None
    most_recent_thread_title:  str | None
    name:                      str | None = None


def _to_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_threads(response: dict[str, Any]) -> list[ThreadSummary]:
    """Pull ``mostRecentTranscripts`` into a list sorted updated→created→id desc.

    Missing fields land as ``None`` rather than raising — Notion returns
    nulls for transcripts that never got past creation.
    """
    out: list[ThreadSummary] = []
    for entry in response.get("mostRecentTranscripts") or []:
        if not isinstance(entry, dict):
            continue
        tid = entry.get("id")
        if not isinstance(tid, str):
            continue
        out.append(ThreadSummary(
            thread_id=       tid,
            title=           entry.get("title") if isinstance(entry.get("title"), str) else None,
            parent_agent_id= entry.get("parent_id") if isinstance(entry.get("parent_id"), str) else None,
            created_at_ms=   _to_int(entry.get("created_time")),
            updated_at_ms=   _to_int(entry.get("updated_time")),
            created_by_id=   entry.get("created_by_id") if isinstance(entry.get("created_by_id"), str) else None,
            created_source=  entry.get("created_source") if isinstance(entry.get("created_source"), str) else None,
        ))
    # Sort newest-first by max(updated, created) so transcripts that
    # never got an updated_at still slot in chronologically by their
    # creation time — matches what the CLI prints in the timestamp
    # column. Tiebreak on thread_id for stable output.
    def _sort_key(t: ThreadSummary) -> tuple[int, str]:
        newest = max(t.updated_at_ms or 0, t.created_at_ms or 0)
        return (-newest, t.thread_id)
    out.sort(key=_sort_key)
    return out


def parse_agents(
    response: dict[str, Any],
    *,
    names: dict[str, str] | None = None,
) -> list[AgentSummary]:
    """Combine ``agentIds`` + ``activityScores`` + most-recent thread title.

    Sorted by activity_score desc (most-recently-used first). Agents
    with no recorded activity sink to the bottom with ``activity_score
    = None``.

    ``names`` (optional) maps agent_id → human-readable page title. When
    provided, :attr:`AgentSummary.name` is filled in; otherwise it
    defaults to ``None``. The lookup is keyed by exact agent_id; missing
    keys are silently treated as unresolved.
    """
    names = names or {}
    agent_ids: list[str] = [
        x for x in (response.get("agentIds") or []) if isinstance(x, str)
    ]

    activity: dict[str, int] = {}
    for entry in response.get("activityScores") or []:
        if not isinstance(entry, dict):
            continue
        pid = entry.get("parent_id")
        score = _to_int(entry.get("activity_score"))
        if (
            isinstance(pid, str)
            and score is not None
            and (pid not in activity or activity[pid] < score)
        ):
            # If duplicates, keep the highest score (= most recent activity).
            activity[pid] = score

    # Best-effort breadcrumb: agent's most recent thread (title + id).
    threads = parse_threads(response)  # already sorted newest-first
    recent_by_agent: dict[str, ThreadSummary] = {}
    for t in threads:
        if t.parent_agent_id and t.parent_agent_id not in recent_by_agent:
            recent_by_agent[t.parent_agent_id] = t

    out: list[AgentSummary] = []
    for aid in agent_ids:
        recent = recent_by_agent.get(aid)
        out.append(AgentSummary(
            agent_id=                aid,
            activity_score=          activity.get(aid),
            most_recent_thread_id=   recent.thread_id if recent else None,
            most_recent_thread_title=recent.title if recent else None,
            name=                    names.get(aid),
        ))

    def _sort_key(a: AgentSummary) -> tuple[int, str]:
        # None scores sink to the bottom; tiebreak on agent_id for stable order.
        return (-(a.activity_score or 0), a.agent_id)
    out.sort(key=_sort_key)
    return out


# --------------------------------------------------------------------------- #
# Bot-record extraction (used to resolve agent display names)
# --------------------------------------------------------------------------- #

def extract_bot_name(bot_value: dict[str, Any]) -> str | None:
    """Pull the display name from an unwrapped ``bot`` record.

    ``bot_value`` is the inner payload from
    ``recordMap.bot.<id>.value.value`` (the doubly-unwrapped form
    returned by :func:`parse_bot_records`). Notion stores agent names
    as plain strings on the bot record (no rich-text arrays here, unlike
    page blocks). Returns ``None`` if the record has no ``name`` field
    or it's empty / non-string.
    """
    if not isinstance(bot_value, dict):
        return None
    name = bot_value.get("name")
    if not isinstance(name, str):
        return None
    out = name.strip()
    return out or None


def parse_bot_records(
    sync_response: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    """Unwrap ``syncRecordValuesMain``'s response into ``{bot_id: value}``.

    The wire shape is ``recordMap.bot.<id> = {value: {value: {...}}}``
    (double-nested role/value envelope, same convention as the chat
    panel uses elsewhere). Single-nested fallback kept defensively.
    Returns ``{}`` when the response lacks ``recordMap.bot``, which is
    Notion's signature for "no records matched" (no error).
    """
    out: dict[str, dict[str, Any]] = {}
    rm = sync_response.get("recordMap") if isinstance(sync_response, dict) else None
    if not isinstance(rm, dict):
        return out
    bots = rm.get("bot")
    if not isinstance(bots, dict):
        return out
    for bid, record in bots.items():
        if not isinstance(record, dict):
            continue
        val = record.get("value")
        if isinstance(val, dict):
            inner = val.get("value")
            # Standard double-nested form: {"value":{"value":{...bot_data...}}}
            if isinstance(inner, dict):
                out[bid] = inner
            else:
                # Fallback for hypothetical single-nested form.
                out[bid] = val
    return out
