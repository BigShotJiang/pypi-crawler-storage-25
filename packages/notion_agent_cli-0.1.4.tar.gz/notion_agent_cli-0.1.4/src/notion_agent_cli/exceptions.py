"""Single error class for the whole library + a small code taxonomy.

All recoverable failures raise :class:`NotionAgentError`. The
``.code`` attribute lets automated callers branch on the failure mode
without parsing the human message — useful for cron / pipeline wrappers
that need to distinguish "user's token expired, alert them" from
"Notion is having a 503 day, retry later".

Codes are kept as a closed set (:class:`ErrorCode`) so adding new ones
requires touching this module — that's the point of the taxonomy.
"""
from __future__ import annotations

from enum import StrEnum


class ErrorCode(StrEnum):
    UNKNOWN             = "unknown"
    AUTH_INVALID        = "auth_invalid"        # 401/403 — token_v2 expired / rejected
    PREMIUM_REQUIRED    = "premium_required"    # premium-feature-unavailable event
    NOTION_ERROR        = "notion_error"        # error event in NDJSON stream
    HTTP_ERROR          = "http_error"          # other non-200 from Notion
    TRANSPORT           = "transport"           # httpx network failure
    EMPTY_PROMPT        = "empty_prompt"        # local validation — caller bug
    INVALID_CALLBACK    = "invalid_callback"    # local validation — both sync+async deltas set
    EMPTY_TEXT          = "empty_text"          # Notion responded 200 but no text
    ACCOUNT_MISSING     = "account_missing"     # notion_account.json file absent
    ACCOUNT_MALFORMED   = "account_malformed"   # notion_account.json unparseable
    ACCOUNT_INVALID     = "account_invalid"     # notion_account.json missing fields
    WORKSPACE_AMBIGUOUS = "workspace_ambiguous" # caller must disambiguate
    WORKSPACE_EMPTY     = "workspace_empty"     # /loadUserContent returned no spaces
    THREAD_STATE_MISSING   = "thread_state_missing"   # --thread-id but no saved file
    THREAD_STATE_MALFORMED = "thread_state_malformed" # saved state JSON unparseable


class NotionAgentError(Exception):
    """All recoverable failures from this package raise this type.

    ``code`` is a string drawn from :class:`ErrorCode`; defaults to
    ``ErrorCode.UNKNOWN`` for legacy raise sites that haven't been
    annotated. Automated callers should branch on ``.code``, not on the
    human-readable message.
    """

    def __init__(self, message: str, *, code: str = ErrorCode.UNKNOWN):
        super().__init__(message)
        self.code = code
