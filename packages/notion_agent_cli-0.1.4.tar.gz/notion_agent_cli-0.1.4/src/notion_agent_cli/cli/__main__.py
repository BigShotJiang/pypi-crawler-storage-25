"""``notion-agent`` console entry point.

Subcommands: ``init`` / ``chat`` / ``doctor`` / ``models`` /
``agents`` / ``threads`` / ``serve``. Run ``notion-agent --help``.

See ``docs/ROADMAP.md`` for what's pending.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import shlex
import sys
from pathlib import Path

from notion_agent_cli import __version__
from notion_agent_cli.account import NotionAccount, load_notion_account, save_notion_account
from notion_agent_cli.agents import (
    AgentSummary,
    ThreadSummary,
    extract_bot_name,
    parse_agents,
    parse_bot_records,
    parse_threads,
)
from notion_agent_cli.bootstrap import (
    AmbiguousWorkspaceError,
    bootstrap_account,
    fetch_user_content,
    parse_browser_cookie,
)
from notion_agent_cli.exceptions import NotionAgentError
from notion_agent_cli.models import (
    DEFAULT_USER_MODELS_PATH,
    load_user_model_map,
    parse_available_models,
    resolve_alias,
    save_user_model_map,
)
from notion_agent_cli.profile import (
    DEFAULT_PROFILE_DIR,
    current_profile,
    list_profiles,
    migrate_account_to_profile,
    use_profile,
)
from notion_agent_cli.provider import NotionAgentClient

DEFAULT_ACCOUNT_PATH = Path.home() / ".notionagents" / "notion_account.json"


# --------------------------------------------------------------------------- #
# init subcommand
# --------------------------------------------------------------------------- #

def _add_init_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "init",
        help="Bootstrap notion_account.json from a token_v2 cookie.",
        description=(
            "Bootstrap workflow: pass just `--token-v2 <value>` — Notion's "
            "/loadUserContent endpoint reports your user_id back, so the "
            "token alone is enough. For convenience you can also paste a "
            "full `document.cookie` string via `--cookie` (token_v2, "
            "notion_user_id, notion_browser_id are extracted automatically); "
            "individual flags override matching values inside --cookie."
        ),
    )
    p.add_argument("--cookie", default=None,
                   help="Full document.cookie string from DevTools "
                        "(Application -> Cookies -> notion.so, then 'copy all'). "
                        "token_v2, notion_user_id, notion_browser_id are "
                        "extracted automatically. "
                        "Pass `--cookie -` to read the cookie from stdin "
                        "(keeps it out of shell history).")
    p.add_argument("--token-v2", default=None,
                   help="token_v2 cookie value (URL-encoded form is fine). "
                        "Required unless --cookie supplies it. "
                        "Pass `--token-v2 -` to read it from stdin "
                        "(keeps the token out of shell history / `ps`).")
    p.add_argument("--user-id", default=None,
                   help="Your Notion user_id (UUID). Optional — auto-derived "
                        "from /loadUserContent if neither --user-id nor "
                        "--cookie supplies it.")
    p.add_argument("--browser-id", default=None,
                   help="notion_browser_id cookie value (random UUID if "
                        "neither --browser-id nor --cookie supplies it).")
    p.add_argument("--space-name", default=None,
                   help="Workspace display name when you have multiple workspaces.")
    p.add_argument("--space-domain", default=None,
                   help="Workspace domain slug when you have multiple workspaces.")
    p.add_argument("--agent-name", default="",
                   help="Custom-agent display name (e.g. 'Jarvis') for chat-panel binding.")
    p.add_argument("--agent-accessory", default="",
                   help="Custom-agent avatar accessory (e.g. 'cat').")
    p.add_argument("--agent-page-id", default="",
                   help="Custom-agent persistent_instructions_page UUID.")
    p.add_argument("--default-model", default="opus-4.7",
                   help="Default model alias (default: %(default)s).")
    p.add_argument("--timezone", default="America/Los_Angeles",
                   help="IANA timezone for the context block (default: %(default)s).")
    p.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                   help="Where to write the credential file (default: %(default)s).")
    p.add_argument("--force", action="store_true",
                   help="Overwrite an existing account file without prompting.")
    p.set_defaults(func=_cmd_init)


async def _run_init(args: argparse.Namespace) -> NotionAccount:
    return await bootstrap_account(
        token_v2=args.token_v2,
        user_id=args.user_id,
        browser_id=args.browser_id,
        space_name=args.space_name,
        space_domain=args.space_domain,
        agent_name=args.agent_name,
        agent_accessory=args.agent_accessory,
        agent_context_page_id=args.agent_page_id,
        default_model=args.default_model,
        timezone=args.timezone,
    )


def _cmd_init(args: argparse.Namespace) -> int:
    if args.cookie == "-":
        # Keep the cookie out of shell history / `ps` output by reading
        # it from stdin instead of argv.
        args.cookie = sys.stdin.read().strip()
        if not args.cookie:
            print("error: --cookie - read an empty cookie from stdin",
                  file=sys.stderr)
            return 2
    if args.token_v2 == "-":
        args.token_v2 = sys.stdin.read().strip()
        if not args.token_v2:
            print("error: --token-v2 - read an empty token from stdin",
                  file=sys.stderr)
            return 2
    if args.cookie:
        parsed = parse_browser_cookie(args.cookie)
        # The full document.cookie should contain a token_v2= entry. If
        # the operator passed a bare token string to --cookie, the parse
        # yields nothing useful — surface that as a clearer hint than the
        # generic "--token-v2 is required" we used to print.
        if not parsed.get("token_v2") and not args.token_v2:
            print(
                "error: --cookie didn't contain `token_v2=...` — did you "
                "mean `--token-v2 <value>` instead? "
                "--cookie expects a full document.cookie string "
                "(name=value pairs separated by `;`).",
                file=sys.stderr,
            )
            return 2
        args.token_v2 = args.token_v2 or parsed.get("token_v2", "")
        args.user_id = args.user_id or parsed.get("notion_user_id", "")
        if args.browser_id is None:
            args.browser_id = parsed.get("notion_browser_id") or None

    if not args.token_v2:
        print(
            "error: --token-v2 (or --cookie containing token_v2=...) is required. "
            "If you only have the token value, pass `--token-v2 <value>` "
            "(or `--token-v2 -` to read from stdin).",
            file=sys.stderr,
        )
        return 2

    # Heads-up: an unbound --agent-name silently lands the account in
    # "default chat" because has_jarvis_binding requires BOTH name and
    # page_id. Surface that before we write so the operator doesn't think
    # the flag worked.
    if args.agent_name and not args.agent_page_id:
        print(
            f"warning: --agent-name {args.agent_name!r} given without "
            "--agent-page-id; no custom-agent binding will be created "
            "(threads will appear under default ✦ AI). Pass "
            "--agent-page-id <uuid> from the agent's instructions-page "
            "URL to bind. The CLI does not resolve agent names server-side.",
            file=sys.stderr,
        )

    if args.account.exists() and not args.force:
        print(
            f"error: {args.account} already exists — pass --force to overwrite",
            file=sys.stderr,
        )
        return 2
    try:
        acc = asyncio.run(_run_init(args))
    except AmbiguousWorkspaceError as e:
        print("Multiple workspaces available — re-run with --space-name or --space-domain:",
              file=sys.stderr)
        for w in e.workspaces:
            print(
                f"  - name={w.space_name!r}  domain={w.domain!r}  id={w.space_id}",
                file=sys.stderr,
            )
        # Suggest a ready-to-copy rerun for the first workspace; shlex
        # quotes the name so workspaces containing spaces or curly quotes
        # (e.g. "Lucien Chen's space") don't get mis-split by the shell.
        first = e.workspaces[0]
        rerun = (
            "  notion-agent init --token-v2 <your-token-v2> "
            f"--space-name {shlex.quote(first.space_name or first.domain)}"
        )
        print("Try:", file=sys.stderr)
        print(rerun, file=sys.stderr)
        return 3
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    save_notion_account(acc, args.account)
    print(f"[init] wrote {args.account}")
    print(f"[init] workspace: {acc.space_name!r}  ({acc.space_id})")
    print(f"[init] user:      {acc.user_name!r} <{acc.user_email}>")
    if acc.has_jarvis_binding:
        print(f"[init] agent:     {acc.agent_name!r}  page={acc.agent_context_page_id}")
    else:
        print("[init] agent:     (default chat — no custom-agent binding)")
    return 0


# --------------------------------------------------------------------------- #
# chat subcommand
# --------------------------------------------------------------------------- #

def _add_chat_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "chat",
        help="Send one prompt, print the reply.",
        description=(
            "One round-trip to Notion's ✦ AI chat endpoint. The conversation "
            "appears in the chat panel under the bound custom agent (if set "
            "during `init`)."
        ),
    )
    p.add_argument("prompt", nargs="?",
                   help="Prompt text. If omitted, read from stdin.")
    p.add_argument("--system", default=None,
                   help="Optional system-style preamble stitched into the user message.")
    p.add_argument("--model", default=None,
                   help="Model alias or Notion id (defaults to account.default_model).")
    p.add_argument("--ask-mode", action="store_true",
                   help="useReadOnlyMode=true — model answers but skips page edits.")
    p.add_argument("--no-web-search", action="store_true",
                   help="Disable the built-in web search tool.")
    p.add_argument("--no-workspace-search", action="store_true",
                   help="Disable workspace search.")
    p.add_argument("--stream", action="store_true",
                   help="Print text chunks as they stream in (vs all-at-end).")
    p.add_argument("--json", dest="json_out", action="store_true",
                   help="Output a structured JSON object to stdout (text + usage + thread_id).")
    p.add_argument("--ndjson", action="store_true",
                   help="Pipe Notion's raw NDJSON event stream straight to stdout "
                        "(no parsing, no terminator). Mutually exclusive with --stream/--json. "
                        "Thread state still persists on success — --thread-id round-trips.")
    p.add_argument("--thread-id", default=None,
                   help="Continue an existing thread (use the thread_id from "
                        "a prior --json response). Requires the thread's "
                        "state file under ~/.notionagents/threads/. The "
                        "thread's original model is locked — --model is "
                        "ignored on continuation.")
    p.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                   help="Account file (default: %(default)s).")
    p.set_defaults(func=_cmd_chat)


def _read_prompt(args: argparse.Namespace) -> str:
    if args.prompt is not None:
        return args.prompt
    if sys.stdin.isatty():
        print("error: no prompt given (pass a positional arg or pipe stdin)",
              file=sys.stderr)
        sys.exit(2)
    return sys.stdin.read()


async def _run_chat(args: argparse.Namespace, prompt: str) -> int:
    on_delta = None
    if args.stream and not args.json_out:
        def on_delta(chunk: str) -> None:
            print(chunk, end="", flush=True)

    async with NotionAgentClient(args.account) as client:
        if args.ndjson:
            try:
                async for line in client.stream_lines(
                    prompt=prompt,
                    system=args.system,
                    model=args.model,
                    web_search=not args.no_web_search,
                    workspace_search=not args.no_workspace_search,
                    ask_mode=args.ask_mode,
                    thread_id=args.thread_id,
                ):
                    print(line, flush=True)
            except NotionAgentError as e:
                print(f"error: {e}", file=sys.stderr)
                return 1
            return 0

        try:
            resp = await client.complete(
                prompt=prompt,
                system=args.system,
                model=args.model,
                web_search=not args.no_web_search,
                workspace_search=not args.no_workspace_search,
                ask_mode=args.ask_mode,
                on_text_delta=on_delta,
                thread_id=args.thread_id,
            )
        except NotionAgentError as e:
            print(f"error: {e}", file=sys.stderr)
            return 1

    if args.json_out:
        # Resolve Notion's internal id ("apricot-sorbet-high") back to the
        # friendly alias ("opus-4.7") so agents see something they can
        # reason about. user_map wins so post-`models refresh` ids stay
        # accurate even before a release.
        alias = resolve_alias(resp.model, user_map=load_user_model_map())
        # Load the account once more to surface which chat surface this
        # turn landed on. has_jarvis_binding == True means the thread
        # shows up in Notion's ✦ AI panel under the bound custom agent.
        try:
            acc = load_notion_account(args.account)
            bound = acc.has_jarvis_binding
            agent_name = acc.agent_name or None
        except NotionAgentError:
            bound = False
            agent_name = None
        out = {
            "text":         resp.text,
            "model":        resp.model,
            "model_alias":  alias,
            "thread_id":    resp.thread_id,
            "surface":      "custom_agent" if bound else "default_chat",
            "agent_name":   agent_name,
            "usage": {
                "input_tokens":   resp.usage.input_tokens,
                "output_tokens":  resp.usage.output_tokens,
                "cache_read":     resp.usage.cache_read,
                "cache_creation": resp.usage.cache_creation,
            },
            "thinking_chars": len(resp.thinking),
        }
        print(json.dumps(out, ensure_ascii=False))
    elif args.stream:
        # The text has already been printed delta-by-delta — terminate the line.
        print()
    else:
        print(resp.text)
    return 0


def _cmd_chat(args: argparse.Namespace) -> int:
    if args.ndjson and (args.json_out or args.stream):
        print("error: --ndjson is mutually exclusive with --json / --stream",
              file=sys.stderr)
        return 2
    prompt = _read_prompt(args)
    return asyncio.run(_run_chat(args, prompt))


# --------------------------------------------------------------------------- #
# doctor subcommand — validate account file + ping Notion
# --------------------------------------------------------------------------- #

def _add_doctor_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "doctor",
        help="Validate the account file and ping /loadUserContent.",
        description=(
            "Sanity-checks an account file: file readable + required fields "
            "present + token_v2 still accepted by Notion + bound space_id "
            "still in the user's workspace list. Use when chat suddenly "
            "errors with 'token_v2 expired' or 'space not found' — doctor "
            "pinpoints which check failed."
        ),
    )
    p.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                   help="Account file to check (default: %(default)s).")
    p.add_argument("--json", dest="json_out", action="store_true",
                   help="Emit a structured JSON report to stdout.")
    p.set_defaults(func=_cmd_doctor)


_DoctorStatus = str  # one of "ok", "fail", "info"


def _render_doctor(
    checks: list[tuple[_DoctorStatus, str, str]],
    *,
    as_json: bool,
) -> str:
    if as_json:
        payload = [
            {"status": status, "check": name, "detail": detail}
            for status, name, detail in checks
        ]
        return json.dumps(payload, indent=2, ensure_ascii=False)
    icons = {"ok": "[ok]  ", "fail": "[FAIL]", "info": "[..]  "}
    lines = []
    for status, name, detail in checks:
        icon = icons.get(status, "[?]   ")
        line = f"{icon} {name}"
        if detail:
            line += f"  -- {detail}"
        lines.append(line)
    return "\n".join(lines)


async def _ping_load_user_content(acc: NotionAccount) -> dict:
    return await fetch_user_content(
        token_v2=acc.token_v2,
        user_id=acc.user_id,
        browser_id=acc.browser_id or "",
    )


def _cmd_doctor(args: argparse.Namespace) -> int:
    checks: list[tuple[_DoctorStatus, str, str]] = []

    # 1) Account file readable + required fields
    try:
        acc = load_notion_account(args.account)
    except NotionAgentError as e:
        checks.append(("fail", "account file readable", f"[{e.code}] {e}"))
        print(_render_doctor(checks, as_json=args.json_out))
        return 1
    checks.append(("ok", "account file readable", str(args.account)))
    checks.append(("ok", "required fields present",
                   f"user={acc.user_email or acc.user_id}  "
                   f"space={acc.space_name!r} ({acc.space_id})"))

    # 2) Jarvis binding (informational)
    if acc.has_jarvis_binding:
        checks.append(("ok", "custom-agent binding",
                       f"{acc.agent_name!r}  page={acc.agent_context_page_id}"))
    else:
        checks.append(("info", "custom-agent binding",
                       "(none — chats appear in the default ✦ AI surface)"))

    # 3) Live ping: token_v2 + /loadUserContent
    try:
        data = asyncio.run(_ping_load_user_content(acc))
    except NotionAgentError as e:
        checks.append(("fail", "token_v2 accepted by /loadUserContent",
                       f"[{e.code}] {e}"))
        print(_render_doctor(checks, as_json=args.json_out))
        return 1
    checks.append(("ok", "token_v2 accepted by /loadUserContent", ""))

    # 4) Bound space_id still in the response
    rm_spaces = list((data.get("recordMap") or {}).get("space") or {})
    if acc.space_id in rm_spaces:
        checks.append(("ok", "bound space_id present in workspaces",
                       f"{len(rm_spaces)} workspaces total"))
    else:
        checks.append(("fail", "bound space_id present in workspaces",
                       f"bound={acc.space_id!r} but server returned {rm_spaces!r}"))
        print(_render_doctor(checks, as_json=args.json_out))
        return 1

    # 5) User model map (informational)
    user_map = load_user_model_map()
    if user_map:
        checks.append(("ok", "user model map loaded",
                       f"{len(user_map)} aliases at {DEFAULT_USER_MODELS_PATH}"))
    else:
        checks.append(("info", "user model map",
                       "(none — falls back to DEFAULT_MODEL_MAP in models.py)"))

    print(_render_doctor(checks, as_json=args.json_out))
    return 0


# --------------------------------------------------------------------------- #
# models refresh subcommand
# --------------------------------------------------------------------------- #

def _add_models_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "models",
        help="Manage the local friendly-alias → Notion model id map.",
        description=(
            "Notion rotates internal model ids ('apricot-sorbet-high', "
            "etc.) every few months. `models refresh` pulls the current "
            "list from /api/v3/getAvailableModels and writes it to "
            f"{DEFAULT_USER_MODELS_PATH}, which `notion-agent chat` "
            "prefers over the hard-coded fallback in models.py."
        ),
    )
    msub = p.add_subparsers(dest="models_cmd", required=True)

    refresh = msub.add_parser(
        "refresh",
        help="Fetch the current model list from Notion and save the map.",
    )
    refresh.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                         help="Account file (default: %(default)s).")
    refresh.add_argument("--output", type=Path, default=None,
                         help=f"Output path (default: {DEFAULT_USER_MODELS_PATH}).")
    refresh.add_argument("--json", dest="json_out", action="store_true",
                         help="Print the resulting alias map as JSON to stdout.")
    refresh.set_defaults(func=_cmd_models_refresh)


async def _run_models_refresh(args: argparse.Namespace) -> dict[str, object]:
    async with NotionAgentClient(args.account) as client:
        return await client.fetch_available_models()


def _cmd_models_refresh(args: argparse.Namespace) -> int:
    try:
        raw = asyncio.run(_run_models_refresh(args))
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    aliases = parse_available_models(raw)
    if not aliases:
        print("error: /getAvailableModels returned no usable models",
              file=sys.stderr)
        return 1

    out_path = save_user_model_map(aliases, args.output)
    if args.json_out:
        print(json.dumps(aliases, indent=2, ensure_ascii=False))
    else:
        print(f"[models refresh] wrote {out_path} ({len(aliases)} models)")
        for alias, mid in sorted(aliases.items()):
            print(f"  {alias:<28} -> {mid}")
    return 0


# --------------------------------------------------------------------------- #
# agents / threads subcommands — wrap /getCustomAgents
# --------------------------------------------------------------------------- #

def _add_agents_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "agents",
        help="List custom agents in the bound workspace.",
        description=(
            "Calls /api/v3/getCustomAgents and shows agent page ids "
            "ranked by activity, with the most recent thread title as a "
            "breadcrumb. Useful when you need to find the page id to "
            "pass to `init --agent-page-id` without copying it out of a "
            "Notion URL."
        ),
    )
    asub = p.add_subparsers(dest="agents_cmd", required=True)

    ls = asub.add_parser("list", help="Print one line per custom agent.")
    ls.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                    help="Account file (default: %(default)s).")
    ls.add_argument("--limit", type=int, default=20,
                    help="Max rows to print (default: %(default)s).")
    ls.add_argument("--json", dest="json_out", action="store_true",
                    help="Emit JSON list instead of the human table.")
    ls.add_argument(
        "--no-names", action="store_true",
        help=(
            "Skip the extra syncRecordValuesMain round-trip used to "
            "resolve agent page titles. Use when you only need agent_ids "
            "and want one fewer HTTP request."
        ),
    )
    ls.set_defaults(func=_cmd_agents_list)


def _add_threads_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "threads",
        help="List recent chat threads in the bound workspace.",
        description=(
            "Calls /api/v3/getCustomAgents and prints its "
            "`mostRecentTranscripts` list, newest first. Filter by "
            "--agent to scope to one custom agent."
        ),
    )
    tsub = p.add_subparsers(dest="threads_cmd", required=True)

    ls = tsub.add_parser("list", help="Print one line per recent thread.")
    ls.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                    help="Account file (default: %(default)s).")
    ls.add_argument("--limit", type=int, default=20,
                    help="Max rows to print (default: %(default)s).")
    ls.add_argument("--agent", default=None,
                    help="Filter to threads under this agent (page id).")
    ls.add_argument("--json", dest="json_out", action="store_true",
                    help="Emit JSON list instead of the human table.")
    ls.set_defaults(func=_cmd_threads_list)


async def _run_fetch_custom_agents(args: argparse.Namespace) -> dict[str, object]:
    async with NotionAgentClient(args.account) as client:
        return await client.fetch_custom_agents()


async def _run_fetch_agent_names(
    args: argparse.Namespace, agent_ids: list[str],
) -> dict[str, str]:
    """Resolve agent_id → bot.name via syncRecordValuesMain (table=bot).

    Returns an empty dict on any failure — the caller falls back to
    name=None per agent rather than aborting the listing. The lookup
    is best-effort: a bot record without a name field, or a 404 for
    a stale agent_id, both simply omit that agent from the result.
    """
    if not agent_ids:
        return {}
    try:
        async with NotionAgentClient(args.account) as client:
            raw = await client.fetch_bot_records(agent_ids)
    except NotionAgentError as e:
        log_msg = f"agent-name lookup failed ({e.code}); listing without names"
        print(f"warning: {log_msg}", file=sys.stderr)
        return {}
    bots = parse_bot_records(raw)
    out: dict[str, str] = {}
    for aid in agent_ids:
        name = extract_bot_name(bots.get(aid) or {})
        if name:
            out[aid] = name
    return out


def _format_ms_epoch(ms: int | None) -> str:
    if ms is None:
        return "-"
    from datetime import UTC, datetime
    return datetime.fromtimestamp(ms / 1000, tz=UTC).strftime("%Y-%m-%d %H:%M")


def _cmd_agents_list(args: argparse.Namespace) -> int:
    try:
        raw = asyncio.run(_run_fetch_custom_agents(args))
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    agent_ids = [x for x in (raw.get("agentIds") or []) if isinstance(x, str)]
    # Trim the title-lookup set to the agents we'll actually print so we
    # don't pay for resolving names on agents we're about to slice off.
    visible_ids = agent_ids if args.limit <= 0 else agent_ids[: max(args.limit * 2, args.limit)]
    names: dict[str, str] = {}
    if not args.no_names:
        names = asyncio.run(_run_fetch_agent_names(args, visible_ids))

    agents: list[AgentSummary] = parse_agents(raw, names=names)
    if args.limit > 0:
        agents = agents[: args.limit]

    if args.json_out:
        payload = [{
            "agent_id":                 a.agent_id,
            "name":                     a.name,
            "activity_score":           a.activity_score,
            "most_recent_thread_id":    a.most_recent_thread_id,
            "most_recent_thread_title": a.most_recent_thread_title,
        } for a in agents]
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    if not agents:
        print("(no custom agents found in the bound workspace)")
        return 0
    print(f"{'agent_id':<40} {'name':<20} {'last_active':<17} most_recent_thread")
    for a in agents:
        last = _format_ms_epoch(a.activity_score)
        name = (a.name or "(no name)")[:20]
        title = a.most_recent_thread_title or "(no title)"
        print(f"{a.agent_id:<40} {name:<20} {last:<17} {title}")
    return 0


def _cmd_threads_list(args: argparse.Namespace) -> int:
    try:
        raw = asyncio.run(_run_fetch_custom_agents(args))
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    threads: list[ThreadSummary] = parse_threads(raw)
    if args.agent:
        threads = [t for t in threads if t.parent_agent_id == args.agent]
    if args.limit > 0:
        threads = threads[: args.limit]

    if args.json_out:
        payload = [{
            "thread_id":       t.thread_id,
            "title":           t.title,
            "parent_agent_id": t.parent_agent_id,
            "created_at_ms":   t.created_at_ms,
            "updated_at_ms":   t.updated_at_ms,
            "created_by_id":   t.created_by_id,
            "created_source":  t.created_source,
        } for t in threads]
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0

    if not threads:
        print("(no recent threads)")
        return 0
    print(f"{'updated':<17} {'thread_id':<40} title")
    for t in threads:
        when = _format_ms_epoch(t.updated_at_ms or t.created_at_ms)
        title = t.title or "(no title)"
        print(f"{when:<17} {t.thread_id:<40} {title}")
    return 0


# --------------------------------------------------------------------------- #
# profile subcommand — multi-workspace symlink swap
# --------------------------------------------------------------------------- #

def _add_profile_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "profile",
        help="Switch between named ~/.notionagents/<name>.json credentials.",
        description=(
            "Manage multi-workspace credentials. Each profile is a "
            "separate notion_account.json saved under ~/.notionagents/ "
            "with a custom name (e.g. tplink.json, personal.json). The "
            "active credential is a symlink at notion_account.json — "
            "`profile use <name>` retargets it."
        ),
    )
    psub = p.add_subparsers(dest="profile_cmd", required=True)

    ls = psub.add_parser("list", help="Print available profiles, * marks active.")
    ls.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR,
                    help="Profile directory (default: %(default)s).")
    ls.set_defaults(func=_cmd_profile_list)

    cur = psub.add_parser("current", help="Print the currently-active profile name.")
    cur.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR,
                     help="Profile directory (default: %(default)s).")
    cur.set_defaults(func=_cmd_profile_current)

    use = psub.add_parser("use", help="Retarget notion_account.json at <name>.json.")
    use.add_argument("name", help="Profile name (without the .json extension).")
    use.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR,
                     help="Profile directory (default: %(default)s).")
    use.set_defaults(func=_cmd_profile_use)

    mig = psub.add_parser(
        "migrate",
        help="Promote an existing notion_account.json into a named profile.",
    )
    mig.add_argument("name", help="Profile name to create (without .json).")
    mig.add_argument("--profile-dir", type=Path, default=DEFAULT_PROFILE_DIR,
                     help="Profile directory (default: %(default)s).")
    mig.set_defaults(func=_cmd_profile_migrate)


def _cmd_profile_list(args: argparse.Namespace) -> int:
    profiles = list_profiles(args.profile_dir)
    if not profiles:
        print(f"(no profiles in {args.profile_dir})")
        return 0
    for entry in profiles:
        marker = "* " if entry.is_active else "  "
        print(f"{marker}{entry.name}")
    return 0


def _cmd_profile_current(args: argparse.Namespace) -> int:
    entry = current_profile(args.profile_dir)
    if entry is None:
        print("(no active profile — notion_account.json is not a symlink "
              "or no named profile matches it)", file=sys.stderr)
        return 1
    print(entry.name)
    return 0


def _cmd_profile_use(args: argparse.Namespace) -> int:
    try:
        link = use_profile(args.name, args.profile_dir)
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"[profile use] {link} -> {args.name}.json")
    return 0


def _cmd_profile_migrate(args: argparse.Namespace) -> int:
    try:
        link = migrate_account_to_profile(args.name, args.profile_dir)
    except NotionAgentError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"[profile migrate] notion_account.json -> {args.name}.json")
    print(f"[profile migrate] symlink at {link}")
    return 0


# --------------------------------------------------------------------------- #
# serve subcommand — FastAPI wrapper
# --------------------------------------------------------------------------- #

def _add_serve_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "serve",
        help="Run a local FastAPI server exposing /chat /agents /threads /healthz.",
        description=(
            "Start a uvicorn-hosted FastAPI app wrapping this CLI. Useful "
            "when an orchestrator (n8n, Make, a Go service) prefers HTTP "
            "over shell-out. Requires the [serve] extra: "
            "`pip install 'notion-agent-cli[serve]'`."
        ),
    )
    p.add_argument("--host", default="127.0.0.1",
                   help="Bind address (default: %(default)s — localhost only).")
    p.add_argument("--port", type=int, default=8000,
                   help="Bind port (default: %(default)s).")
    p.add_argument("--account", type=Path, default=DEFAULT_ACCOUNT_PATH,
                   help="Account file (default: %(default)s).")
    p.add_argument("--reload", action="store_true",
                   help="Dev-only: uvicorn auto-reload on code changes.")
    p.set_defaults(func=_cmd_serve)


def _cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn

        from notion_agent_cli.serve import create_app
    except ImportError:
        print(
            "error: `notion-agent serve` requires the [serve] extra. "
            "Run: pip install 'notion-agent-cli[serve]'",
            file=sys.stderr,
        )
        return 2

    if args.reload:
        # uvicorn --reload needs an import string, not an app instance.
        # We expose a factory at module level for that path.
        import os
        os.environ["NOTION_AGENT_CLI_ACCOUNT"] = str(args.account.expanduser())
        uvicorn.run(
            "notion_agent_cli.serve:_reload_app",
            host=args.host, port=args.port, reload=True, factory=True,
        )
    else:
        app = create_app(args.account)
        uvicorn.run(app, host=args.host, port=args.port)
    return 0


# --------------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------------- #

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="notion-agent",
        description="Direct CLI for Notion's ✦ AI / Custom Agent endpoint.",
    )
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="cmd", required=True)
    _add_init_parser(sub)
    _add_chat_parser(sub)
    _add_doctor_parser(sub)
    _add_models_parser(sub)
    _add_agents_parser(sub)
    _add_threads_parser(sub)
    _add_profile_parser(sub)
    _add_serve_parser(sub)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
