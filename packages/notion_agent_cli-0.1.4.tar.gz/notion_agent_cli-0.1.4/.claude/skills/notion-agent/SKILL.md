---
name: notion-agent
description: Ask Notion's ✦ AI / Custom Agent (e.g. Jarvis) via the local `notion-agent` CLI. Use when the user wants a workspace-aware answer from their bound Notion agent, wants to pipe a draft through Notion AI, list their agents / threads, or continue a prior thread. Trigger phrases include "ask Jarvis", "Notion AI", "via the chat panel", "notion-agent", "Custom Agent".
---

## When to use

- The user wants an answer that depends on **their Notion workspace**
  (their notes, their Custom Agent's instructions / skill pages) and a
  public Claude can't see that context.
- The user mentions a Custom Agent by name ("Jarvis", "the chat panel
  one", "my Notion agent") — that's a workspace-bound persona, not a
  general assistant.
- The user wants to dump a draft into Notion's ✦ AI for them to react
  to inside Notion (the conversation surfaces in the chat panel under
  the bound persona).

Skip this skill for general programming / world-knowledge questions —
answer those directly. Notion's chat costs the user API quota.

## Quick start

```bash
# One-shot chat — prints the assistant reply to stdout
notion-agent chat "summarize my last week of project notes"

# Streaming output for long replies
notion-agent chat --stream "draft a status update from this week's notes"

# Structured JSON (text + usage + thread_id) for piping into other tools
notion-agent chat --json "what tickets did I close in May?"
```

Check `notion-agent --help` for the full subcommand list. Six
subcommands: `init`, `chat`, `doctor`, `models refresh`, `agents list`,
`threads list`.

## Pre-flight

Before the first call, the user needs an account file at
`~/.notionagents/notion_account.json`. If chat errors with
`[account_missing]`:

```bash
# Paste the full document.cookie string from a logged-in Notion tab
notion-agent init --cookie "token_v2=...; notion_user_id=...; ..."
```

`init` auto-extracts `token_v2` / `notion_user_id` / `notion_browser_id`
from the pasted cookie string. Add `--agent-name "Jarvis"
--agent-page-id <uuid>` to bind to a Custom Agent so threads surface in
the chat panel.

If chat errors with `[auth_invalid]`, the `token_v2` cookie expired —
re-run `init` with a fresh one.

## Multi-turn continuation

```bash
# Turn 1 — get the thread_id from --json output
THREAD=$(notion-agent chat --json "start a brainstorm on X" | jq -r .thread_id)

# Turn 2+ — pass --thread-id to continue
notion-agent chat --thread-id "$THREAD" "now narrow down to 3 ideas"
notion-agent chat --thread-id "$THREAD" "expand idea 1"
```

State is stored under `~/.notionagents/threads/<thread-id>.json`.
The thread's original model is locked — `--model` is ignored on
continuation. If state is missing the error is `[thread_state_missing]`
and the user should drop `--thread-id` to start fresh.

## Looking up agent / thread ids

```bash
notion-agent agents  list --limit 10     # 19-ish agents, page_id + activity
notion-agent threads list --limit 10     # recent threads, newest first
notion-agent threads list --agent <id>   # threads under one agent
```

JSON variants (`--json`) for both. Use `agents list` when the user asks
to bind a new Custom Agent during `init` — the page_id column is what
goes into `--agent-page-id`.

## Troubleshooting

```bash
notion-agent doctor          # human-readable 6-step report
notion-agent doctor --json   # structured, for cron / automation
```

`doctor` checks: account file readable, required fields, Custom Agent
binding (informational), `/loadUserContent` ping, bound space_id still
in workspace list, user model map present. Each line tagged
`[ok] / [FAIL] / [..]`.

If Notion rotates internal model ids (the `apricot-sorbet-high` style):

```bash
notion-agent models refresh   # writes ~/.notionagents/models.json
```

## Don't

- **Don't paste real `token_v2` values into prompts** — `init` already
  bound it, and the CLI handles auth transparently. The token is
  long-lived (~months); only re-run `init` when `doctor` says
  `[auth_invalid]`.
- **Don't loop more than ~3 chats per user task** — each call is a real
  Notion API hit consuming the operator's quota. If a batch run is
  unavoidable, ask the user first.
- **Don't write to `~/.notionagents/`** directly — the CLI owns it.
  Account file, models map, and thread state are all CLI-managed.
- **Don't switch `--model` mid-thread** — the flag is silently ignored
  on `--thread-id` continuations because Notion locks the model to
  turn 1. If the user wants a different model, start a new thread.

## ErrorCode reference (for `--json` consumers)

| Code | Meaning | Action |
|---|---|---|
| `account_missing`     | No file at `~/.notionagents/notion_account.json` | Run `init` |
| `account_invalid`     | File present but missing required fields | Re-run `init` |
| `auth_invalid`        | 401/403 — `token_v2` expired or rejected | Re-run `init` with fresh cookie |
| `thread_state_missing`| `--thread-id` used but no saved state | Drop `--thread-id` to start fresh |
| `premium_required`    | Notion premium feature gated | Tell the user their plan blocks this |
| `empty_text`          | 200 but empty stream | Likely transient — retry once |
| `http_error`          | Non-200 from Notion | Likely transient — retry once |
| `transport`           | Network failure | Check connectivity |

`NotionAgentError.code` is a `StrEnum` — branching on the literal
string is fine.
