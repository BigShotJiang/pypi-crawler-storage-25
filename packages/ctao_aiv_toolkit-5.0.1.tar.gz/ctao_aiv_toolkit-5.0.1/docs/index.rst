AIV Toolkit handbook
====================

**Version**: |version| **Date**: |today|

.. toctree::
    :maxdepth: 3
    :caption: Contents:

    quick-start
    config
    gitlab-ci/index
    best-practices
    support
    reference
    changelog



Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
