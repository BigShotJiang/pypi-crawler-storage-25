.. _best-practices:

AIV best practices
==================

This section provides some best practices for developing AIV-enabled applications, including Helm charts and CWL.

Helm charts
-----------

Secret values in Helm charts
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For every secret value, Helm charts should be designed to accept secret values in two ways:

* Passing a name of a Kubernetes secret containing the value, e.g. using ``{{ .Values.credentials.secret_key }}`` in the chart templates and setting ``credentials.secret_key`` to the name of the Kubernetes secret.
* Passing the secret value directly, e.g. using ``{{ .Values.secret_key }}``. In this case, the value is typically stored in a kubernetes secret created by the helm chart.


CWL
---

TBD
