"""Functions to manage a kind cluster."""

import contextlib
import json
import logging
import os
import pathlib
import random
import subprocess as sp
import time
from importlib.resources import as_file, files
from tempfile import NamedTemporaryFile

from ruamel.yaml import YAML

from aivkit.deploy.images import preload_image, verify_cluster_images
from aivkit.deploy.tools import helm_bin, install_tools, kind_bin, kubectl_bin
from aivkit.deploy.utils import retry
from aivkit.runcmd import run_subprocess_tracing_logging as run

logger = logging.getLogger(__name__)


increase_pod_limit = """
kind: KubeletConfiguration
maxPods: 250
"""


def write_kind_config(
    kind_config_path: pathlib.Path | None = None,
    enable_registry_mirrors: bool = True,
    enable_ingress: bool = False,
    mount_repo: bool = True,
    host_port_http: int = 80,
    host_port_https: int = 443,
) -> pathlib.Path:
    """Write kind config to a file.

    Args:
        kind_config_path: Path to the kind config file. If None, a default path is used.
        enable_registry_mirrors: Whether to use registry mirrors.
        enable_ingress: Whether to enable ingress.
        mount_repo: Whether to mount the repository in the kind cluster.
    """
    if kind_config_path is None:
        kind_config_path = pathlib.Path(
            os.environ.get("TOOLKIT_DIR", ".toolkit/kind-config.yaml")
        ).absolute()
    else:
        kind_config_path = pathlib.Path(kind_config_path)

    yaml = YAML()

    kind_config_data = {
        "kind": "Cluster",
        "apiVersion": "kind.x-k8s.io/v1alpha4",
        "nodes": [
            {
                "role": "control-plane",
                "kubeadmConfigPatches": [increase_pod_limit],
                "image": "harbor.cta-observatory.org/proxy_cache/kindest/node:v1.34.0@sha256:7416a61b42b1662ca6ca89f02028ac133a309a2a30ba309614e8ec94d976dc5a",
            }
        ],
    }

    if not enable_registry_mirrors:
        logger.warning(
            "Registry mirrors are disabled: currently we do not support this, enabling anyway"
        )
        enable_registry_mirrors = True

    if enable_registry_mirrors:
        kind_config_data["containerdConfigPatches"] = [
            """[plugins."io.containerd.grpc.v1.cri".registry.mirrors."docker.io"]
                endpoint = ["http://proxy-docker-hub:5000"]""",
            """[plugins."io.containerd.grpc.v1.cri".registry.mirrors."harbor.cta-observatory.org"]
                endpoint = ["http://proxy-harbor-ctao:5000"]""",
            """[plugins."io.containerd.grpc.v1.cri".registry.mirrors."ghcr.io"]
                endpoint = ["http://proxy-ghcr:5000"]""",
            """[plugins."io.containerd.grpc.v1.cri".registry.mirrors."quay.io"]
                endpoint = ["http://proxy-quay:5000"]""",
        ]

    for node in kind_config_data["nodes"]:
        if mount_repo:
            node["extraMounts"] = [{"hostPath": ".", "containerPath": "/repo/"}]

        if enable_ingress:
            node["extraPortMappings"] = [
                {"containerPort": 30080, "hostPort": host_port_http, "protocol": "TCP"},
                {
                    "containerPort": 30443,
                    "hostPort": host_port_https,
                    "protocol": "TCP",
                },
            ]

    kind_config_path.parent.mkdir(parents=True, exist_ok=True)

    with kind_config_path.open("w") as f:
        yaml.dump(kind_config_data, f)

    with kind_config_path.open("r") as f:
        logger.info("Kind config written to %s:", kind_config_path)
        for line in f:
            logger.debug(line.rstrip("\n"))

    return kind_config_path


def list_clusters() -> list[str]:
    """List kind clusters."""
    result = run(
        [kind_bin(), "get", "-q", "clusters"],
    )
    return result.splitlines()


def need_to_create_cluster(kind_cluster_name: str, if_cluster_exists: str) -> bool:
    """Check if the kind cluster needs to be created."""
    if kind_cluster_name in list_clusters():
        logger.info("Cluster %s already exists", kind_cluster_name)
        match if_cluster_exists:
            case "reuse":
                logger.info("Reusing existing cluster %s", kind_cluster_name)
                return False
            case "raise":
                raise RuntimeError(f"Cluster {kind_cluster_name} already exists")
            case "recreate":
                logger.info(
                    "Destroying existing cluster %s as per if_cluster_exists='recreate'",
                    kind_cluster_name,
                )
                kind_down(kind_cluster_name)
                logger.info("Cluster %s destroyed", kind_cluster_name)
                return True
            case _:
                raise ValueError(
                    f"Unknown if_cluster_exists option: {if_cluster_exists}"
                )
    else:
        logger.info("Cluster %s does not exist, creating it", kind_cluster_name)
        return True


def current_kind_cluster_name() -> str:
    """Get the name of the current kind cluster based on the current directory and timestamp."""
    return f"aiv-local-{pathlib.Path.cwd().name}"


@retry(exception_type=sp.CalledProcessError)
def kind_export_kubeconfig(kind_cluster_name: str, kubeconfig_args):
    """Export kubeconfig for the kind cluster."""
    sp.run(
        [
            kind_bin(),
            "export",
            "kubeconfig",
            "--name",
            kind_cluster_name,
        ]
        + kubeconfig_args,
        check=True,
    )


def kind_up(
    kind_cluster_name: str | None = None,
    kind_config: str | dict | None = None,
    if_cluster_exists: str = "reuse",
    kubeconfig: pathlib.Path | None = None,
    allowed_image_prefixes: str | None = None,
    ingress_controller: bool = True,
):
    """Start a kind cluster.

    Args:
        kind_cluster_name: Name of the kind cluster. If None, selecting name based on current directory and timestamp.
        kind_config: Path to the kind config file or a dictionary with config parameters. If None, using default config.
        if_cluster_exists: Action to take if the cluster already exists. Options are 'reuse', 'raise', 'recreate'.
        kubeconfig:
            Path to the kubeconfig file. This is where the kubeconfig context will be written.
            If None but KUBECONFIG environment variable is set, will be used as the kubeconfig path.
            If None and KUBECONFIG is not set, will use the default path `~/.kube/config`.
    """
    if kind_config is None or kind_config == "":
        kind_config = {}

    if isinstance(kind_config, dict):
        kind_config_path = write_kind_config(**kind_config)
    elif pathlib.Path(kind_config).is_file():
        logger.info("Using provided kind config at %s", kind_config)
        kind_config_path = pathlib.Path(kind_config).absolute()
    else:
        raise ValueError(f"Invalid kind config: {kind_config}")

    if kind_cluster_name is None:
        kind_cluster_name = current_kind_cluster_name()

    logger.debug("kubeconfig: %s", kubeconfig)
    logger.debug("KUBECONFIG environment variable: %s", os.environ.get("KUBECONFIG"))

    if kubeconfig is None and os.environ.get("KUBECONFIG") is not None:
        # kind does use KUBECONFIG environment variable, so we need to set it explicitly
        logger.info("Using KUBECONFIG from environment: %s", os.environ["KUBECONFIG"])
        kubeconfig = pathlib.Path(os.environ["KUBECONFIG"]).absolute()

    logger.info(
        "Requested to create kind cluster %s with %s",
        kind_cluster_name,
        kind_config_path,
    )

    if kubeconfig is None:
        logger.info("Using default kubeconfig path")
        kubeconfig_args = []
    else:
        kubeconfig_args = ["--kubeconfig", str(kubeconfig)]

    install_tools()

    if need_to_create_cluster(kind_cluster_name, if_cluster_exists):
        logger.info(
            "Creating kind cluster %s with config %s",
            kind_cluster_name,
            kind_config_path,
        )

        args = [
            kind_bin(),
            "create",
            "cluster",
            "--name",
            kind_cluster_name,
            "--config",
            str(kind_config_path),
        ]

        if kubeconfig is not None:
            logger.info("Will write kubeconfig to: %s", kubeconfig)
            args.extend(kubeconfig_args)

        t0 = time.time()
        sp.run(args, check=True)
        logger.info(
            "Kind cluster %s created in %.2f seconds",
            kind_cluster_name,
            time.time() - t0,
        )
    else:
        logger.info("Skipping creation of kind cluster %s", kind_cluster_name)
        # re-export the kubeconfig
        kind_export_kubeconfig(kind_cluster_name, kubeconfig_args)
        logger.info("Re-exported kubeconfig for cluster %s", kind_cluster_name)

    context_name = f"kind-{kind_cluster_name}"

    # list contexts in kubeconfig
    result = sp.run(
        [kubectl_bin(), "config", "get-contexts"] + kubeconfig_args,
        check=True,
        capture_output=True,
        text=True,
    )
    contexts = result.stdout.strip().splitlines()
    logger.debug("Current kubeconfig contexts:\n%s", "\n".join(contexts))

    cmd = [
        kubectl_bin(),
        "cluster-info",
        "--context",
        context_name,
    ] + kubeconfig_args

    logger.debug("Running command: %s", " ".join(cmd))
    sp.run(
        cmd,
        check=True,
    )

    # set the kubeconfig context to the created cluster
    sp.run(
        [
            kubectl_bin(),
            "config",
            "use-context",
            context_name,
        ]
        + kubeconfig_args,
        check=True,
    )

    # this is needed since if a runner is in a k8s cluster, it will try to use context from the runner in non-default namespace
    # also we will install helm chart in default namespace
    sp.run(
        [
            kubectl_bin(),
            "config",
            "set-context",
            "--current",
            "--namespace=default",
        ]
        + kubeconfig_args,
        check=True,
    )

    verify_cluster_images(kubeconfig_args, allowed_image_prefixes)

    # install ingress and setup DNS
    if ingress_controller:
        setup_ingress_controller(kubeconfig_args)


INGRESS_HELM_VALUES = """
controller:
    replicaCount: 1
    image:
        repository: harbor.cta-observatory.org/proxy_cache/haproxytech/kubernetes-ingress
"""


def setup_ingress_controller(kubeconfig_args):
    """Add ingress and DNS rules for it to the cluster."""
    repo = "haproxytech"
    repo_url = "https://haproxytech.github.io/helm-charts"
    release_name = "haproxy-kubernetes-ingress"
    namespace = "haproxy-controller"

    helm = helm_bin()
    sp.run([helm, "repo", "add", repo, repo_url], check=True)
    sp.run([helm, "repo", "update", repo], check=True)

    with NamedTemporaryFile(suffix=".yaml", mode="w", delete_on_close=False) as f:
        f.write(INGRESS_HELM_VALUES)
        f.close()
        install_cmd = [
            helm,
            "upgrade",
            "--install",
            "--force",
            release_name,
            f"{repo}/kubernetes-ingress",
            "-f",
            f.name,
            "--create-namespace",
            "--namespace",
            namespace,
            "--set",
            "controller.service.nodePorts.http=30080",
            "--set",
            "controller.service.nodePorts.https=30443",
            "--set",
            "controller.logging.level=debug",
            "--set",
            "controller.extraArgs={--disable-ipv6}",
        ]
        sp.run(install_cmd + kubeconfig_args, check=True)

    with as_file(files("aivkit") / "deploy/resources/Corefile") as config_map:
        corefile = config_map.read_text()

    patch_args = "-n", "kube-system", "patch", "configmap", "coredns", "--type", "merge"
    patch = json.dumps({"data": {"Corefile": corefile}})
    sp.run(
        [kubectl_bin(), *patch_args, "-p", patch, *kubeconfig_args],
        check=True,
    )

    restart_dns = ["-n", "kube-system", "rollout", "restart", "deployment", "coredns"]
    sp.run([kubectl_bin(), *restart_dns, *kubeconfig_args], check=True)

    logging.info("Waiting for ingress to be ready")
    wait = [
        "rollout",
        "status",
        "-n",
        namespace,
        "deployment/haproxy-kubernetes-ingress",
        "--timeout=300s",
    ]
    sp.run([kubectl_bin(), *wait, *kubeconfig_args], check=True)


@retry(exception_type=sp.CalledProcessError)
def kind_delete_cluster(kind_cluster_name: str):
    """Delete a kind cluster."""
    sp.run(
        [
            kind_bin(),
            "delete",
            "cluster",
            "--name",
            kind_cluster_name,
        ],
        check=True,
    )


def kind_down(
    kind_cluster_name: str | None = None,
):
    """Stop a kind cluster."""
    install_tools()
    if kind_cluster_name not in list_clusters():
        logger.warning("Cluster %s does not exist, nothing to stop", kind_cluster_name)
    else:
        logger.info("Stopping kind cluster %s", kind_cluster_name)
        kind_delete_cluster(kind_cluster_name)
        logger.info("Kind cluster %s stopped", kind_cluster_name)


def kind_purge():
    """Purge all kind clusters."""
    install_tools()

    clusters = list_clusters()
    if not clusters:
        logger.info("No kind clusters to purge")
    else:
        logger.info("Purging all kind clusters: %s", ", ".join(clusters))

        for cluster in clusters:
            logger.info("Purging kind cluster %s", cluster)
            kind_down(cluster)

        logger.info("All kind clusters purged")


@contextlib.contextmanager
def kind_cluster(
    kind_cluster_name: str | None = None,
    stop: bool = True,
    kind_config: str | None = None,
    preload_images: list[str] | None = None,
    ingress_controller: bool = False,
):
    """Context manager for kind cluster."""
    if kind_cluster_name is None:
        kind_cluster_name = f"{pathlib.Path.cwd().name}-{time.strftime('%Y%m%d-%H%M%S')}-{random.randint(1000, 9999)}"

    try:
        kind_up(kind_cluster_name, kind_config, ingress_controller=ingress_controller)

        if preload_images is not None:
            for image in preload_images:
                preload_image(image, kind_cluster_name)

        yield kind_cluster_name
    finally:
        if stop:
            kind_down(kind_cluster_name)
