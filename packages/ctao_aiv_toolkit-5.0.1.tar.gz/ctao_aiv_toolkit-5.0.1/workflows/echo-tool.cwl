%YAML-1.1
---
cwlVersion: v1.2
class: CommandLineTool

label: Echo Tool
doc: |
  This tool echoes the input string to the standard output.

inputs:
  input_string:
    type: string
    label: Input String
    doc: The string to be echoed.
    inputBinding:
      position: 1

outputs:
  output_string:
    type: stdout
    label: Output String
    doc: The echoed output string.

baseCommand: echo
