%YAML-1.1
---
cwlVersion: v1.2
class: Workflow

label: Echo Workflow
doc: |
  This workflow runs the echo tool to demonstrate a simple workflow execution.
inputs:
  input_string:
    type: string
    label: Input String
    doc: The string to be echoed.
steps:
  echo:
    run: echo-tool.cwl
    in:
      input_string: input_string
    out: [output_string]
outputs:
  output_string:
    type: File
    label: Output String
    doc: The echoed output string.
    outputSource: echo/output_string
