# =============================================================================
# Logistic Regression Classifier
# Dataset: Breast Cancer Wisconsin — Kaggle
# https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
#
# SETUP:
#   kaggle datasets download -d uciml/breast-cancer-wisconsin-data --unzip
#   → this gives you data.csv
#   OR manually download from Kaggle and place data.csv in the same folder
# =============================================================================

# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             classification_report, ConfusionMatrixDisplay,
                             roc_curve, auc)
from sklearn.preprocessing import StandardScaler, LabelEncoder

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================

df = pd.read_csv('data.csv')      # CSV must be in the same folder as this file

print("Shape         :", df.shape)
print("\nColumns       :", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())
print("\nMissing values:")
print(df.isnull().sum())
print("\nClass distribution:")
print(df['diagnosis'].value_counts())   # M = Malignant, B = Benign

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Drop columns we don't need
df = df.drop(columns=['id', 'Unnamed: 32'], errors='ignore')

# Encode target: M → 1, B → 0
le              = LabelEncoder()
df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Separate features and target
X             = df.drop(columns=['diagnosis']).values
y             = df['diagnosis'].values
feature_names = df.drop(columns=['diagnosis']).columns.tolist()

# Train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale features — VERY important for Logistic Regression
# LR uses gradient descent; unscaled features make it converge slowly/poorly
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)     # only transform, never fit on test data

print("\nTraining samples  :", X_train.shape[0])
print("Testing  samples  :", X_test.shape[0])
print("Number of features:", X_train.shape[1])

# =============================================================================
# Step 4 - Train Logistic Regression Model
# =============================================================================
# Logistic Regression estimates the probability that a sample belongs to a class
# using the sigmoid function:
#
#   P(y=1 | x) = 1 / (1 + e^(-z))   where z = w.x + b
#
# If P > 0.5  → predict class 1 (Malignant)
# If P <= 0.5 → predict class 0 (Benign)

lr = LogisticRegression(
    C           = 1.0,          # regularisation strength (smaller C = stronger regularisation)
    penalty     = 'l2',         # L2 regularisation (Ridge) — prevents overfitting
    solver      = 'lbfgs',      # optimisation algorithm (works well for small datasets)
    max_iter    = 1000,         # max iterations for solver to converge
    random_state= 42
)

lr.fit(X_train, y_train)
print("\nModel trained successfully!")
print("Solver used    :", lr.solver)
print("Regularisation :", lr.penalty)

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred      = lr.predict(X_test)
y_pred_prob = lr.predict_proba(X_test)[:, 1]   # probability of being Malignant

print("\n========== Evaluation ==========")
print("Accuracy         :", round(accuracy_score(y_test, y_pred), 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Benign', 'Malignant']))

# Cross-validation (5-fold)
cv_scores = cross_val_score(lr, X, y, cv=5, scoring='accuracy')
print("5-Fold CV Scores :", cv_scores.round(4))
print("CV Mean Accuracy :", round(cv_scores.mean(), 4))
print("CV Std Dev       :", round(cv_scores.std(), 4))

# Confusion Matrix
cm   = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                               display_labels=['Benign', 'Malignant'])
disp.plot(cmap='Blues')
plt.title('Logistic Regression - Confusion Matrix')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6 - ROC Curve (unique to probabilistic classifiers like LR)
# =============================================================================
# ROC curve shows the tradeoff between True Positive Rate and False Positive Rate
# AUC (Area Under Curve) closer to 1.0 = better model

fpr, tpr, thresholds = roc_curve(y_test, y_pred_prob)
roc_auc              = auc(fpr, tpr)

plt.figure(figsize=(7, 5))
plt.plot(fpr, tpr, color='blue', linewidth=2,
         label=f'ROC Curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='grey', linestyle='--', linewidth=1,
         label='Random Classifier (AUC = 0.5)')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Logistic Regression - ROC Curve')
plt.legend()
plt.tight_layout()
plt.show()

print(f"\nAUC Score: {roc_auc:.4f}  (1.0 = perfect, 0.5 = random)")

# =============================================================================
# Step 7 - Feature Coefficients (what LR actually learned)
# =============================================================================
# In Logistic Regression, coefficients tell you:
#   Positive coefficient → feature pushes toward class 1 (Malignant)
#   Negative coefficient → feature pushes toward class 0 (Benign)

coefficients = lr.coef_[0]
coef_df      = pd.DataFrame({
    'Feature'    : feature_names,
    'Coefficient': coefficients
}).sort_values('Coefficient', ascending=False)

print("\nTop 5 features pushing toward Malignant (positive coeff):")
print(coef_df.head(5).to_string(index=False))

print("\nTop 5 features pushing toward Benign (negative coeff):")
print(coef_df.tail(5).to_string(index=False))

# Plot top 10 + bottom 10 coefficients
top10    = coef_df.head(10)
bottom10 = coef_df.tail(10)
plot_df  = pd.concat([top10, bottom10])

plt.figure(figsize=(10, 6))
colors = ['red' if c > 0 else 'blue' for c in plot_df['Coefficient']]
plt.barh(plot_df['Feature'], plot_df['Coefficient'],
         color=colors, edgecolor='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.8)
plt.xlabel('Coefficient Value')
plt.title('Logistic Regression - Feature Coefficients\n(Red = Malignant, Blue = Benign)')
plt.tight_layout()
plt.show()