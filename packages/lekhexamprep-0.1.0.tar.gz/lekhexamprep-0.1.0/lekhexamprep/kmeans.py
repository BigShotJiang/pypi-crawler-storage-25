# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Download from: https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python
# Place Mall_Customers.csv in the same folder as this file

df = pd.read_csv('kmeans.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Select features for clustering
X = df[['Annual Income (k$)', 'Spending Score (1-100)']].values

# Standardise — K-Means uses Euclidean distance so scaling is mandatory
scaler  = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("\nOriginal X shape:", X.shape)
print("Scaled  X shape:", X_scaled.shape)

# =============================================================================
# Step 4 - Implement K-Means Clustering
# =============================================================================

kmeans = KMeans(n_clusters=5, init='k-means++', n_init=10, random_state=42)
labels = kmeans.fit_predict(X_scaled)

# Add cluster labels to dataframe
df['Cluster'] = labels

print("\nCluster assignments (first 10):", labels[:10])
print("\nPoints per cluster:")
print(pd.Series(labels).value_counts().sort_index())

print("\nCluster Centroids (scaled space):")
print(kmeans.cluster_centers_)

# Convert centroids back to original scale
centroids_original = scaler.inverse_transform(kmeans.cluster_centers_)
print("\nCluster Centroids (original scale):")
centroid_df = pd.DataFrame(centroids_original,
                            columns=['Annual Income (k$)', 'Spending Score (1-100)'])
print(centroid_df.round(2))

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

print("\n========== Evaluation ==========")
print("Inertia (WCSS)   :", round(kmeans.inertia_, 4))
print("Silhouette Score :", round(silhouette_score(X_scaled, labels), 4))
print("Iterations taken :", kmeans.n_iter_)

# =============================================================================
# Step 6 - Visualise Clusters
# =============================================================================

COLORS = ['red', 'blue', 'green', 'orange', 'purple']

plt.figure(figsize=(8, 5))

for i in range(5):
    plt.scatter(X_scaled[labels == i, 0],
                X_scaled[labels == i, 1],
                c=COLORS[i], s=60, label=f'Cluster {i}')

# Plot centroids
plt.scatter(kmeans.cluster_centers_[:, 0],
            kmeans.cluster_centers_[:, 1],
            s=200, c='black', marker='X', label='Centroids')

plt.title('K-Means Clustering (K=5)')
plt.xlabel('Annual Income (scaled)')
plt.ylabel('Spending Score (scaled)')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Choosing Optimal K (Elbow Method)
# =============================================================================

wcss = []

for k in range(1, 11):
    km = KMeans(n_clusters=k, init='k-means++', n_init=10, random_state=42)
    km.fit(X_scaled)
    wcss.append(km.inertia_)
    print(f"K={k:2d}  ->  WCSS = {km.inertia_:.2f}")

plt.figure(figsize=(8, 5))
plt.plot(range(1, 11), wcss, marker='o', color='blue', linewidth=2)
plt.title('Elbow Method - Finding Optimal K')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('WCSS (Inertia)')
plt.xticks(range(1, 11))
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - Silhouette Score for each K
# =============================================================================

sil_scores = []

for k in range(2, 11):
    km  = KMeans(n_clusters=k, init='k-means++', n_init=10, random_state=42)
    lbl = km.fit_predict(X_scaled)
    score = silhouette_score(X_scaled, lbl)
    sil_scores.append(score)
    print(f"K={k:2d}  ->  Silhouette Score = {score:.4f}")

best_k = range(2, 11)[np.argmax(sil_scores)]
print(f"\nBest K = {best_k}  (Silhouette Score = {max(sil_scores):.4f})")

plt.figure(figsize=(8, 5))
plt.plot(range(2, 11), sil_scores, marker='o', color='green', linewidth=2)
plt.title('Silhouette Score Method')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Silhouette Score')
plt.xticks(range(2, 11))
plt.tight_layout()
plt.show()