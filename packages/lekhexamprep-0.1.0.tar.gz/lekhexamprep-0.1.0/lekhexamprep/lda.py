# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: health_risk.csv
# Features: Age, Blood_Pressure, Cholesterol, BMI
# Target:   Risk_Level (Mild / Moderate / Severe)

df = pd.read_csv('health_risk.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())
print("\nClass distribution:")
print(df['Risk_Level'].value_counts())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Encode target labels: Mild=0, Moderate=1, Severe=2
le = LabelEncoder()
df['Risk_Encoded'] = le.fit_transform(df['Risk_Level'])
print("\nLabel Encoding:", dict(zip(le.classes_, le.transform(le.classes_))))

# Features (X) and Labels (y)
X = df[['Age', 'Blood_Pressure', 'Cholesterol', 'BMI']].values
y = df['Risk_Encoded'].values

# Standardise — good practice before LDA
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)
print("Train size:", X_train.shape, " | Test size:", X_test.shape)

# =============================================================================
# Step 4 - Apply LDA (Dimensionality Reduction)
# =============================================================================

# LDA reduces to at most (n_classes - 1) components
# 3 classes (Mild, Moderate, Severe) → max 2 LDA components
lda = LDA(n_components=2)
X_train_lda = lda.fit_transform(X_train, y_train)   # Fit on train, transform train
X_test_lda  = lda.transform(X_test)                 # Transform test using same model

print("\nOriginal training shape :", X_train.shape)
print("LDA-reduced train shape :", X_train_lda.shape)

print("\nExplained Variance Ratio per component:")
for i, var in enumerate(lda.explained_variance_ratio_):
    print(f"  LD{i+1}: {var:.4f} ({var*100:.2f}%)")

print(f"\nTotal Variance Explained: {sum(lda.explained_variance_ratio_)*100:.2f}%")

# =============================================================================
# Step 5 - Evaluate: Classify using LDA-Reduced Data
# =============================================================================

# Train a fresh LDA classifier on the reduced components
lda_clf = LDA()
lda_clf.fit(X_train_lda, y_train)
y_pred = lda_clf.predict(X_test_lda)

print("\n========== Evaluation ==========")
print("Accuracy on Test Set:", round(accuracy_score(y_test, y_pred), 4))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=le.classes_))

# =============================================================================
# Step 6 - Visualise LDA Components (2D Scatter Plot)
# =============================================================================

COLORS      = ['red', 'blue', 'green']
CLASS_NAMES = le.classes_   # ['Mild', 'Moderate', 'Severe']

plt.figure(figsize=(8, 5))

for i in range(3):
    plt.scatter(X_train_lda[y_train == i, 0],
                X_train_lda[y_train == i, 1],
                c=COLORS[i], s=60, label=CLASS_NAMES[i], alpha=0.7)

plt.title('LDA - 2D Projection of Health Risk Dataset')
plt.xlabel('Linear Discriminant 1 (LD1)')
plt.ylabel('Linear Discriminant 2 (LD2)')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Compare: Original vs LDA-Reduced Accuracy
# =============================================================================

# Accuracy using all 4 original features
lda_orig = LDA()
lda_orig.fit(X_train, y_train)
y_pred_orig = lda_orig.predict(X_test)

# Accuracy using only 1 LDA component (LD1)
lda_1d = LDA(n_components=1)
X_train_1d = lda_1d.fit_transform(X_train, y_train)
X_test_1d  = lda_1d.transform(X_test)
lda_clf_1d = LDA()
lda_clf_1d.fit(X_train_1d, y_train)
y_pred_1d = lda_clf_1d.predict(X_test_1d)

print("\n========== Comparison ==========")
print(f"Accuracy - 4 features (original) : {accuracy_score(y_test, y_pred_orig):.4f}")
print(f"Accuracy - 2 LDA components      : {accuracy_score(y_test, y_pred):.4f}")
print(f"Accuracy - 1 LDA component       : {accuracy_score(y_test, y_pred_1d):.4f}")

# =============================================================================
# Step 6c - Explained Variance Bar Chart
# =============================================================================

components = [f'LD{i+1}' for i in range(len(lda.explained_variance_ratio_))]
variances  = lda.explained_variance_ratio_ * 100

plt.figure(figsize=(6, 4))
plt.bar(components, variances, color=['steelblue', 'orange'])
plt.title('Explained Variance per LDA Component')
plt.xlabel('LDA Component')
plt.ylabel('Variance Explained (%)')
for i, v in enumerate(variances):
    plt.text(i, v + 0.5, f'{v:.2f}%', ha='center', fontweight='bold')
plt.tight_layout()
plt.show()