# =============================================================================
# Random Forest Classifier
# Dataset: Breast Cancer Wisconsin — Kaggle
# https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
#
# SETUP:
#   kaggle datasets download -d uciml/breast-cancer-wisconsin-data --unzip
#   → this gives you data.csv
#   OR manually download from Kaggle and place data.csv in the same folder
# =============================================================================

# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay)
from sklearn.preprocessing import StandardScaler, LabelEncoder

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================

df = pd.read_csv('data.csv')      # CSV must be in the same folder as this file

print("Shape         :", df.shape)
print("\nColumns       :", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())
print("\nMissing values:")
print(df.isnull().sum())
print("\nClass distribution:")
print(df['diagnosis'].value_counts())   # M = Malignant, B = Benign

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Drop columns we don't need
df = df.drop(columns=['id', 'Unnamed: 32'], errors='ignore')

# Encode target: M → 1, B → 0
le           = LabelEncoder()
df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Separate features and target
X             = df.drop(columns=['diagnosis']).values
y             = df['diagnosis'].values
feature_names = df.drop(columns=['diagnosis']).columns.tolist()

# Train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale features
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)     # only transform, never fit on test data

print("\nTraining samples  :", X_train.shape[0])
print("Testing  samples  :", X_test.shape[0])
print("Number of features:", X_train.shape[1])

# =============================================================================
# Step 4 - Train Random Forest Model
# =============================================================================
# Random Forest = many Decision Trees trained on random subsets of data
# Final prediction = majority vote across all trees

rf = RandomForestClassifier(
    n_estimators = 100,       # number of trees in the forest
    max_depth    = None,      # trees grow fully (no depth limit)
    random_state = 42,
    n_jobs       = -1         # use all CPU cores
)

rf.fit(X_train, y_train)
print("\nModel trained successfully!")
print("Number of trees:", rf.n_estimators)

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = rf.predict(X_test)

print("\n========== Evaluation ==========")
print("Accuracy         :", round(accuracy_score(y_test, y_pred), 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Benign', 'Malignant']))

# Cross-validation (5-fold)
cv_scores = cross_val_score(rf, X, y, cv=5, scoring='accuracy')
print("5-Fold CV Scores :", cv_scores.round(4))
print("CV Mean Accuracy :", round(cv_scores.mean(), 4))
print("CV Std Dev       :", round(cv_scores.std(), 4))

# Confusion Matrix
cm   = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                               display_labels=['Benign', 'Malignant'])
disp.plot(cmap='Blues')
plt.title('Random Forest - Confusion Matrix')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6 - Feature Importance
# =============================================================================

importances = rf.feature_importances_
indices     = np.argsort(importances)[::-1]
top_n       = 10

print("\nTop 10 Important Features:")
for i in range(top_n):
    print(f"  {i+1}. {feature_names[indices[i]]:35s} {importances[indices[i]]:.4f}")

plt.figure(figsize=(10, 5))
plt.bar(range(top_n),
        importances[indices[:top_n]],
        color='steelblue', edgecolor='black', linewidth=0.6)
plt.xticks(range(top_n),
           [feature_names[i] for i in indices[:top_n]],
           rotation=45, ha='right', fontsize=8)
plt.title('Random Forest - Top 10 Feature Importances')
plt.ylabel('Importance Score')
plt.tight_layout()
plt.show()