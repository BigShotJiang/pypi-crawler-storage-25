# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: bp_regression.csv
# Features: Age, BMI, Cholesterol, Smoking
# Target:   Blood_Pressure (continuous — regression problem)

df = pd.read_csv('bp_regression.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Features (X) and Target (y)
X = df[['Age', 'BMI', 'Cholesterol', 'Smoking']].values
y = df['Blood_Pressure'].values

# Standardise features
scaler  = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)
print("Train size:", X_train.shape, " | Test size:", X_test.shape)

# =============================================================================
# Step 4 - Train the Linear Regression Model
# =============================================================================

model = LinearRegression()
model.fit(X_train, y_train)

print("\nIntercept :", round(model.intercept_, 4))
print("\nCoefficients (one per feature):")
feature_names = ['Age', 'BMI', 'Cholesterol', 'Smoking']
for name, coef in zip(feature_names, model.coef_):
    print(f"  {name:12s}: {coef:.4f}")

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = model.predict(X_test)

mae  = mean_absolute_error(y_test, y_pred)
mse  = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2   = r2_score(y_test, y_pred)

print("\n========== Evaluation ==========")
print("MAE  (Mean Absolute Error) :", round(mae, 4))
print("MSE  (Mean Squared Error)  :", round(mse, 4))
print("RMSE (Root MSE)            :", round(rmse, 4))
print("R²   (R-Squared Score)     :", round(r2, 4))

# =============================================================================
# Step 6 - Visualise: Actual vs Predicted
# =============================================================================

plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, color='steelblue', s=60, alpha=0.7, label='Predicted vs Actual')
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()],
         color='red', linewidth=2, linestyle='--', label='Perfect Prediction Line')
plt.title('Linear Regression — Actual vs Predicted Blood Pressure')
plt.xlabel('Actual Blood Pressure')
plt.ylabel('Predicted Blood Pressure')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Residual Plot (should be randomly scattered around 0)
# =============================================================================

residuals = y_test - y_pred

plt.figure(figsize=(8, 5))
plt.scatter(y_pred, residuals, color='orange', s=60, alpha=0.7)
plt.axhline(y=0, color='red', linewidth=2, linestyle='--')
plt.title('Residual Plot')
plt.xlabel('Predicted Blood Pressure')
plt.ylabel('Residuals (Actual - Predicted)')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - Feature Importance (Coefficient Bar Chart)
# =============================================================================

plt.figure(figsize=(7, 4))
plt.bar(feature_names, model.coef_, color=['steelblue', 'orange', 'green', 'red'])
plt.title('Feature Coefficients — Linear Regression')
plt.xlabel('Feature')
plt.ylabel('Coefficient Value')
plt.axhline(y=0, color='black', linewidth=0.8, linestyle='--')
plt.tight_layout()
plt.show()