# =============================================================================
# XGBoost Classifier
# Dataset: Breast Cancer Wisconsin — Kaggle
# https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
#
# SETUP:
#   pip install xgboost                   (only needed once)
#   kaggle datasets download -d uciml/breast-cancer-wisconsin-data --unzip
#   → this gives you data.csv
#   OR manually download from Kaggle and place data.csv in the same folder
# =============================================================================

# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (accuracy_score, confusion_matrix, classification_report, ConfusionMatrixDisplay)
from sklearn.preprocessing import StandardScaler, LabelEncoder
from xgboost import XGBClassifier

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================

df = pd.read_csv('data.csv')      # CSV must be in the same folder as this file

print("Shape         :", df.shape)
print("\nColumns       :", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())
print("\nMissing values:")
print(df.isnull().sum())
print("\nClass distribution:")
print(df['diagnosis'].value_counts())   # M = Malignant, B = Benign

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Drop columns we don't need
df = df.drop(columns=['id', 'Unnamed: 32'], errors='ignore')

# Encode target: M → 1, B → 0
le = LabelEncoder()
df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Separate features and target
X = df.drop(columns=['diagnosis']).values
y = df['diagnosis'].values
feature_names = df.drop(columns=['diagnosis']).columns.tolist()

# Train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale features
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)     # only transform, never fit on test data

print("\nTraining samples  :", X_train.shape[0])
print("Testing  samples  :", X_test.shape[0])
print("Number of features:", X_train.shape[1])

# =============================================================================
# Step 4 - Train XGBoost Model
# =============================================================================
# XGBoost = Extreme Gradient Boosting
# Idea: Build trees one by one. Each tree corrects the RESIDUAL ERRORS
#       (gradient of the loss) left by the previous trees.
#       Adds L1 + L2 regularisation to prevent overfitting.

xgb = XGBClassifier(
    n_estimators     = 100,    # number of boosting rounds (trees)
    max_depth        = 6,      # max depth of each tree
    learning_rate    = 0.1,    # shrinks each tree's contribution (eta)
    subsample        = 0.8,    # fraction of rows used per tree
    colsample_bytree = 0.8,    # fraction of features used per tree
    eval_metric      = 'logloss',
    random_state     = 42
)

xgb.fit(X_train, y_train)
print("\nModel trained successfully!")
print("Number of trees:", xgb.n_estimators)

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = xgb.predict(X_test)

print("\n========== Evaluation ==========")
print("Accuracy         :", round(accuracy_score(y_test, y_pred), 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Benign', 'Malignant']))

# Cross-validation (5-fold)
cv_scores = cross_val_score(xgb, X, y, cv=5, scoring='accuracy')
print("5-Fold CV Scores :", cv_scores.round(4))
print("CV Mean Accuracy :", round(cv_scores.mean(), 4))
print("CV Std Dev       :", round(cv_scores.std(), 4))

# Confusion Matrix
cm   = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Benign', 'Malignant'])
disp.plot(cmap='Greens')
plt.title('XGBoost - Confusion Matrix')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6 - Feature Importance
# =============================================================================

importances = xgb.feature_importances_
indices     = np.argsort(importances)[::-1]
top_n       = 10

print("\nTop 10 Important Features:")
for i in range(top_n):
    print(f"  {i+1}. {feature_names[indices[i]]:35s} {importances[indices[i]]:.4f}")

plt.figure(figsize=(10, 5))
plt.bar(range(top_n),
        importances[indices[:top_n]],
        color='seagreen', edgecolor='black', linewidth=0.6)
plt.xticks(range(top_n),
           [feature_names[i] for i in indices[:top_n]],
           rotation=45, ha='right', fontsize=8)
plt.title('XGBoost - Top 10 Feature Importances')
plt.ylabel('Importance Score (Gain)')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 7 - Accuracy vs Number of Trees
# =============================================================================

train_accs  = []
test_accs   = []
tree_counts = range(1, 101, 5)

for n in tree_counts:
    model = XGBClassifier(
        n_estimators     = n,
        max_depth        = 6,
        learning_rate    = 0.1,
        eval_metric      = 'logloss',
        random_state     = 42
    )
    model.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, model.predict(X_train)))
    test_accs.append(accuracy_score(y_test,   model.predict(X_test)))

plt.figure(figsize=(9, 5))
plt.plot(tree_counts, train_accs, label='Train Accuracy', color='blue',  linewidth=2)
plt.plot(tree_counts, test_accs,  label='Test Accuracy',  color='green', linewidth=2)
plt.xlabel('Number of Trees (n_estimators)')
plt.ylabel('Accuracy')
plt.title('XGBoost - Accuracy vs Number of Trees')
plt.legend()
plt.tight_layout()
plt.show()