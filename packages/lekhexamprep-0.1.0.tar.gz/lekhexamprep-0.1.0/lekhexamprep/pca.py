# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: health_risk.csv
# Features: Age, Blood_Pressure, Cholesterol, BMI
# Target:   Risk_Level (Mild / Moderate / Severe)

df = pd.read_csv('health_risk.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())
print("\nClass distribution:")
print(df['Risk_Level'].value_counts())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Encode target labels: Mild=0, Moderate=1, Severe=2
le = LabelEncoder()
y = le.fit_transform(df['Risk_Level'])
print("\nLabel Encoding:", dict(zip(le.classes_, le.transform(le.classes_))))

# Features
X = df[['Age', 'Blood_Pressure', 'Cholesterol', 'BMI']].values

# Standardise — PCA is based on variance, so scaling is MANDATORY
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)

# =============================================================================
# Step 4a - Apply PCA (Dimensionality Reduction)
# =============================================================================

# Fit PCA keeping ALL components first — to study explained variance
pca_full = PCA(n_components=None)   # None = keep all components
pca_full.fit(X_scaled)

print("\n===== PCA — All Components =====")
print("Explained Variance Ratio per component:")
for i, var in enumerate(pca_full.explained_variance_ratio_):
    print(f"  PC{i+1}: {var:.4f} ({var*100:.2f}%)")
print(f"\nCumulative Variance Explained: {np.cumsum(pca_full.explained_variance_ratio_)*100}")

# Now reduce to 2 components for visualization
pca_2d = PCA(n_components=2)
X_pca_2d = pca_2d.fit_transform(X_scaled)

print("\n===== PCA — Reduced to 2 Components =====")
print("Original shape :", X_scaled.shape)
print("Reduced  shape :", X_pca_2d.shape)
print(f"Variance explained by PC1 + PC2: {sum(pca_2d.explained_variance_ratio_)*100:.2f}%")

print("\nPCA Components (Eigenvectors / Loadings):")
loading_df = pd.DataFrame(
    pca_2d.components_,
    columns=['Age', 'Blood_Pressure', 'Cholesterol', 'BMI'],
    index=['PC1', 'PC2']
)
print(loading_df.round(4))

# =============================================================================
# Step 4b - Apply SVD (Manual — same result as PCA, shows the math)
# =============================================================================

print("\n===== SVD — Manual Decomposition =====")

# SVD decomposes X = U * S * Vt
# U  = left singular vectors  (samples in new space)
# S  = singular values        (importance of each direction)
# Vt = right singular vectors (principal directions, same as PCA components)

U, S, Vt = np.linalg.svd(X_scaled, full_matrices=False)

print("U  shape (samples × components):", U.shape)
print("S  shape (singular values)      :", S.shape)
print("Vt shape (components × features):", Vt.shape)

print("\nSingular Values:", S.round(4))

# Convert singular values to explained variance ratio (same as PCA)
explained_variance_svd = (S ** 2) / (len(X_scaled) - 1)
total_variance         = explained_variance_svd.sum()
evr_svd                = explained_variance_svd / total_variance

print("\nExplained Variance Ratio (via SVD):")
for i, var in enumerate(evr_svd):
    print(f"  Component {i+1}: {var:.4f} ({var*100:.2f}%)")

# Project data onto first 2 SVD components (same as PCA projection)
X_svd_2d = U[:, :2] * S[:2]

print("\nSVD 2D projection shape:", X_svd_2d.shape)

# Verify PCA and SVD give same result (signs may differ but structure is same)
print("\nPCA vs SVD projections match (ignoring sign)?",
      np.allclose(np.abs(X_pca_2d), np.abs(X_svd_2d)))

# =============================================================================
# Step 5 - Evaluate: Classification Accuracy Before vs After PCA
# =============================================================================

X_train_orig, X_test_orig, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

# Reduce train and test using PCA (fit only on train!)
pca_eval = PCA(n_components=2)
X_train_pca = pca_eval.fit_transform(X_train_orig)
X_test_pca  = pca_eval.transform(X_test_orig)

# Classifier: Logistic Regression on original features
clf_orig = LogisticRegression(max_iter=1000, random_state=42)
clf_orig.fit(X_train_orig, y_train)
acc_orig = accuracy_score(y_test, clf_orig.predict(X_test_orig))

# Classifier: Logistic Regression on PCA-reduced features
clf_pca = LogisticRegression(max_iter=1000, random_state=42)
clf_pca.fit(X_train_pca, y_train)
acc_pca = accuracy_score(y_test, clf_pca.predict(X_test_pca))

print("\n========== Evaluation ==========")
print(f"Accuracy - 4 original features  : {acc_orig:.4f}")
print(f"Accuracy - 2 PCA components     : {acc_pca:.4f}")
print(f"Dimensionality reduced from 4 → 2 features")

# =============================================================================
# Step 6 - Visualise: PCA 2D Scatter Plot
# =============================================================================

COLORS      = ['red', 'blue', 'green']
CLASS_NAMES = le.classes_   # ['Mild', 'Moderate', 'Severe']

plt.figure(figsize=(8, 5))
for i in range(3):
    plt.scatter(X_pca_2d[y == i, 0], X_pca_2d[y == i, 1],
                c=COLORS[i], s=60, label=CLASS_NAMES[i], alpha=0.7)

plt.title('PCA — 2D Projection of Health Risk Dataset')
plt.xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0]*100:.1f}% variance)')
plt.ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1]*100:.1f}% variance)')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Scree Plot (Elbow Plot for PCA — how many components to keep)
# =============================================================================

variances   = pca_full.explained_variance_ratio_ * 100
cum_var     = np.cumsum(variances)
components  = range(1, len(variances) + 1)

fig, ax1 = plt.subplots(figsize=(8, 5))

ax1.bar(components, variances, color='steelblue', alpha=0.7, label='Individual Variance')
ax1.set_xlabel('Principal Component')
ax1.set_ylabel('Variance Explained (%)', color='steelblue')
ax1.set_xticks(list(components))

ax2 = ax1.twinx()
ax2.plot(components, cum_var, marker='o', color='red', linewidth=2, label='Cumulative Variance')
ax2.set_ylabel('Cumulative Variance Explained (%)', color='red')
ax2.axhline(y=95, color='orange', linestyle='--', linewidth=1.5, label='95% threshold')
ax2.set_ylim(0, 110)

plt.title('Scree Plot — PCA Explained Variance')
fig.legend(loc='center right', bbox_to_anchor=(0.88, 0.5))
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - PCA Loadings Heatmap (which features contribute to each PC)
# =============================================================================

pca_all = PCA(n_components=4)
pca_all.fit(X_scaled)

loadings = pd.DataFrame(
    pca_all.components_,
    columns=['Age', 'Blood_Pressure', 'Cholesterol', 'BMI'],
    index=[f'PC{i+1}' for i in range(4)]
)

plt.figure(figsize=(7, 4))
plt.imshow(loadings.values, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)
plt.colorbar(label='Loading Value')
plt.xticks(range(4), loadings.columns, fontsize=11)
plt.yticks(range(4), loadings.index, fontsize=11)
plt.title('PCA Loadings Heatmap\n(How much each feature contributes to each PC)')

for i in range(4):
    for j in range(4):
        plt.text(j, i, f'{loadings.values[i, j]:.2f}',
                 ha='center', va='center', fontsize=10, fontweight='bold',
                 color='white' if abs(loadings.values[i, j]) > 0.5 else 'black')

plt.tight_layout()
plt.show()

# =============================================================================
# Step 6d - SVD 2D Scatter Plot (compare with PCA above — should look same)
# =============================================================================

plt.figure(figsize=(8, 5))
for i in range(3):
    plt.scatter(X_svd_2d[y == i, 0], X_svd_2d[y == i, 1],
                c=COLORS[i], s=60, label=CLASS_NAMES[i], alpha=0.7)

plt.title('SVD — 2D Projection of Health Risk Dataset')
plt.xlabel('SVD Component 1')
plt.ylabel('SVD Component 2')
plt.legend()
plt.tight_layout()
plt.show()