from .linear_regression       import run as linear_regression
from .polynomial_regression   import run as polynomial_regression
from .classification_regression import run as classification_regression
from .decision_tree           import run as decision_tree
from .linear_svm              import run as linear_svm
from .nonlinear_svm           import run as nonlinear_svm
from .random_forest           import run as random_forest
from .xgboost_model           import run as xgboost
from .kmeans                  import run as kmeans
from .svd                     import run as svd
from .pca                     import run as pca
from .lda                     import run as lda

__version__ = "0.1.0"
__all__ = [
    "linear_regression",
    "polynomial_regression",
    "classification_regression",
    "decision_tree",
    "linear_svm",
    "nonlinear_svm",
    "random_forest",
    "xgboost",
    "kmeans",
    "svd",
    "pca",
    "lda",
]
