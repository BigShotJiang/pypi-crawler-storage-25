# =============================================================================
# Decision Tree Classifier
# Dataset: Breast Cancer Wisconsin — Kaggle
# https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
#
# SETUP:
#   kaggle datasets download -d uciml/breast-cancer-wisconsin-data --unzip
#   → this gives you data.csv
#   OR manually download from Kaggle and place data.csv in the same folder
# =============================================================================

# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, plot_tree, export_text
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             classification_report, ConfusionMatrixDisplay)
from sklearn.preprocessing import StandardScaler, LabelEncoder

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================

df = pd.read_csv('data.csv')      # CSV must be in the same folder as this file

print("Shape         :", df.shape)
print("\nColumns       :", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())
print("\nMissing values:")
print(df.isnull().sum())
print("\nClass distribution:")
print(df['diagnosis'].value_counts())   # M = Malignant, B = Benign

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Drop columns we don't need
df = df.drop(columns=['id', 'Unnamed: 32'], errors='ignore')

# Encode target: M → 1, B → 0
le              = LabelEncoder()
df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Separate features and target
X             = df.drop(columns=['diagnosis']).values
y             = df['diagnosis'].values
feature_names = df.drop(columns=['diagnosis']).columns.tolist()

# Train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Note: Decision Trees don't strictly need scaling (they split on thresholds)
# but we scale anyway for consistency and fair comparison with other models
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

print("\nTraining samples  :", X_train.shape[0])
print("Testing  samples  :", X_test.shape[0])
print("Number of features:", X_train.shape[1])

# =============================================================================
# Step 4 - Train Decision Tree Model
# =============================================================================
# Decision Tree splits data at each node by asking a question:
#   "Is feature X > threshold T?"
# It picks the split that best separates classes using a criterion (Gini / Entropy)
#
# Gini Impurity: measures how often a randomly chosen element is misclassified
#   Gini = 1 - sum(p_i^2)    → 0 means perfectly pure node
#
# Entropy (Information Gain): measures disorder
#   Entropy = -sum(p_i * log2(p_i))   → 0 means perfectly pure node

dt = DecisionTreeClassifier(
    criterion    = 'gini',    # split criterion: 'gini' or 'entropy'
    max_depth    = 5,         # limit tree depth to prevent overfitting
    min_samples_split = 2,    # min samples needed to split a node
    min_samples_leaf  = 1,    # min samples required at a leaf node
    random_state = 42
)

dt.fit(X_train, y_train)
print("\nModel trained successfully!")
print("Tree depth   :", dt.get_depth())
print("Num of leaves:", dt.get_n_leaves())

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = dt.predict(X_test)

print("\n========== Evaluation ==========")
print("Accuracy         :", round(accuracy_score(y_test, y_pred), 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Benign', 'Malignant']))

# Cross-validation (5-fold)
cv_scores = cross_val_score(dt, X, y, cv=5, scoring='accuracy')
print("5-Fold CV Scores :", cv_scores.round(4))
print("CV Mean Accuracy :", round(cv_scores.mean(), 4))
print("CV Std Dev       :", round(cv_scores.std(), 4))

# Confusion Matrix
cm   = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                               display_labels=['Benign', 'Malignant'])
disp.plot(cmap='Purples')
plt.title('Decision Tree - Confusion Matrix')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6 - Visualise the Decision Tree
# =============================================================================
# This is the best part of Decision Trees — you can actually SEE the rules

plt.figure(figsize=(20, 8))
plot_tree(
    dt,
    feature_names = feature_names,
    class_names   = ['Benign', 'Malignant'],
    filled        = True,          # colour nodes by class
    rounded       = True,          # rounded boxes
    fontsize      = 8
)
plt.title('Decision Tree Visualisation (max_depth=5)', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()

# Print tree as text rules (useful for exam/report)
print("\n=== Decision Tree Rules (Text) ===")
tree_rules = export_text(dt, feature_names=feature_names, max_depth=3)
print(tree_rules)

# =============================================================================
# Step 7 - Feature Importance
# =============================================================================

importances = dt.feature_importances_
indices     = np.argsort(importances)[::-1]
top_n       = 10

print("\nTop 10 Important Features:")
for i in range(top_n):
    print(f"  {i+1}. {feature_names[indices[i]]:35s} {importances[indices[i]]:.4f}")

plt.figure(figsize=(10, 5))
plt.bar(range(top_n),
        importances[indices[:top_n]],
        color='mediumpurple', edgecolor='black', linewidth=0.6)
plt.xticks(range(top_n),
           [feature_names[i] for i in indices[:top_n]],
           rotation=45, ha='right', fontsize=8)
plt.title('Decision Tree - Top 10 Feature Importances')
plt.ylabel('Importance Score (Gini)')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 8 - Effect of max_depth on Accuracy (Overfitting Demo)
# =============================================================================
# A tree with no depth limit memorises training data = overfitting
# This plot shows the sweet spot for max_depth

train_accs = []
test_accs  = []
depths     = range(1, 21)

for d in depths:
    model = DecisionTreeClassifier(criterion='gini', max_depth=d, random_state=42)
    model.fit(X_train, y_train)
    train_accs.append(accuracy_score(y_train, model.predict(X_train)))
    test_accs.append(accuracy_score(y_test,   model.predict(X_test)))

plt.figure(figsize=(9, 5))
plt.plot(depths, train_accs, marker='o', label='Train Accuracy',
         color='blue', linewidth=2)
plt.plot(depths, test_accs,  marker='s', label='Test Accuracy',
         color='red',  linewidth=2)
plt.axvline(5, color='grey', linestyle='--', linewidth=1.2, label='Our max_depth=5')
plt.xlabel('max_depth')
plt.ylabel('Accuracy')
plt.title('Decision Tree - Accuracy vs max_depth\n(shows overfitting as depth increases)')
plt.legend()
plt.xticks(depths)
plt.tight_layout()
plt.show()