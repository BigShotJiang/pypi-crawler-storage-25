# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import itertools

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: health_risk.csv
# Features: Age, Blood_Pressure, Cholesterol, BMI
# Target:   Risk_Level (Mild / Moderate / Severe)

df = pd.read_csv('health_risk.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())
print("\nClass distribution:")
print(df['Risk_Level'].value_counts())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Encode target labels: Mild=0, Moderate=1, Severe=2
le = LabelEncoder()
df['Risk_Encoded'] = le.fit_transform(df['Risk_Level'])
print("\nLabel Encoding:", dict(zip(le.classes_, le.transform(le.classes_))))

# Features (X) and Labels (y)
X = df[['Age', 'Blood_Pressure', 'Cholesterol', 'BMI']].values
y = df['Risk_Encoded'].values

# Standardise — SVM is sensitive to feature scale
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)
print("Train size:", X_train.shape, " | Test size:", X_test.shape)

# =============================================================================
# Step 4 - Train Linear SVM
# =============================================================================

# kernel='linear' → straight hyperplane to separate classes
# C = regularisation parameter (higher C = less margin, tries harder to classify correctly)
svm_linear = SVC(kernel='linear', C=1.0, random_state=42)
svm_linear.fit(X_train, y_train)

print("\nKernel used       :", svm_linear.kernel)
print("C (Regularisation):", svm_linear.C)
print("Number of Support Vectors per class:", svm_linear.n_support_)

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = svm_linear.predict(X_test)

print("\n========== Evaluation ==========")
print("Accuracy on Test Set:", round(accuracy_score(y_test, y_pred), 4))
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=le.classes_))

# =============================================================================
# Step 6 - Visualise: Confusion Matrix
# =============================================================================

cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(6, 5))
plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
plt.title('Confusion Matrix — Linear SVM')
plt.colorbar()
tick_marks = range(len(le.classes_))
plt.xticks(tick_marks, le.classes_, rotation=45)
plt.yticks(tick_marks, le.classes_)

# Add numbers inside each cell
for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
    plt.text(j, i, str(cm[i, j]),
             horizontalalignment='center',
             color='white' if cm[i, j] > cm.max() / 2 else 'black')

plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Decision Boundary (using only 2 features for 2D plot)
# =============================================================================

# Use only Age and Blood_Pressure for visualization
X_2f = df[['Age', 'Blood_Pressure']].values
X_2f_scaled = StandardScaler().fit_transform(X_2f)

X_train_2f, X_test_2f, y_train_2f, y_test_2f = train_test_split(
    X_2f_scaled, y, test_size=0.2, random_state=42, stratify=y
)

svm_2f = SVC(kernel='linear', C=1.0, random_state=42)
svm_2f.fit(X_train_2f, y_train_2f)

# Create mesh grid
x_min, x_max = X_2f_scaled[:, 0].min() - 0.5, X_2f_scaled[:, 0].max() + 0.5
y_min, y_max = X_2f_scaled[:, 1].min() - 0.5, X_2f_scaled[:, 1].max() + 0.5
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                     np.linspace(y_min, y_max, 300))
Z = svm_2f.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)

COLORS = ['red', 'blue', 'green']
CLASS_NAMES = le.classes_

plt.figure(figsize=(8, 5))
plt.contourf(xx, yy, Z, alpha=0.2, cmap=plt.cm.RdYlGn)
for i in range(3):
    plt.scatter(X_2f_scaled[y == i, 0], X_2f_scaled[y == i, 1],
                c=COLORS[i], s=50, label=CLASS_NAMES[i], edgecolors='k', linewidths=0.4)
plt.title('Linear SVM — Decision Boundary (Age vs Blood Pressure)')
plt.xlabel('Age (scaled)')
plt.ylabel('Blood Pressure (scaled)')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - Effect of C on Accuracy
# =============================================================================

C_values = [0.001, 0.01, 0.1, 1, 10, 100]
accuracies = []

for c in C_values:
    clf = SVC(kernel='linear', C=c, random_state=42)
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))
    accuracies.append(acc)
    print(f"C={c:6}  ->  Accuracy = {acc:.4f}")

plt.figure(figsize=(8, 5))
plt.semilogx(C_values, accuracies, marker='o', color='steelblue', linewidth=2)
plt.title('Effect of C on Linear SVM Accuracy')
plt.xlabel('C (Regularisation Parameter) — log scale')
plt.ylabel('Accuracy')
plt.xticks(C_values, [str(c) for c in C_values])
plt.tight_layout()
plt.show()