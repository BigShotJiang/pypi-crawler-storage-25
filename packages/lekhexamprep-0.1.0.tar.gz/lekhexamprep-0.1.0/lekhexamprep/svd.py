# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: health_risk.csv
# Features: Age, Blood_Pressure, Cholesterol, BMI
# Target:   Risk_Level (Mild / Moderate / Severe)

df = pd.read_csv('health_risk.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())
print("\nClass distribution:")
print(df['Risk_Level'].value_counts())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Encode target labels: Mild=0, Moderate=1, Severe=2
le = LabelEncoder()
y  = le.fit_transform(df['Risk_Level'])
print("\nLabel Encoding:", dict(zip(le.classes_, le.transform(le.classes_))))

# Features
X = df[['Age', 'Blood_Pressure', 'Cholesterol', 'BMI']].values

# Standardise — SVD is variance-based, so scaling is MANDATORY
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)

# =============================================================================
# Step 4 - Apply SVD (Dimensionality Reduction)
# =============================================================================

# SVD decomposes the matrix X into three matrices:
#   X = U * S * Vt
#   U  = left singular vectors  — each row is a sample in the new space
#   S  = singular values        — how important each component is
#   Vt = right singular vectors — the principal directions (like PCA eigenvectors)

U, S, Vt = np.linalg.svd(X_scaled, full_matrices=False)

print("\nU  shape (samples × components) :", U.shape)
print("S  shape (singular values)       :", S.shape)
print("Vt shape (components × features) :", Vt.shape)

print("\nSingular Values:", S.round(4))

# Convert singular values → explained variance ratio
explained_variance = (S ** 2) / (len(X_scaled) - 1)
total_variance     = explained_variance.sum()
evr                = explained_variance / total_variance

print("\nExplained Variance Ratio per SVD Component:")
for i, var in enumerate(evr):
    print(f"  Component {i+1}: {var:.4f} ({var*100:.2f}%)")

print(f"\nCumulative Variance Explained: {np.cumsum(evr)*100}")

# Project data onto first 2 SVD components (dimensionality reduction)
# Equivalent to: X_reduced = X_scaled @ Vt[:2].T
X_svd_2d = U[:, :2] * S[:2]

print("\nOriginal shape  :", X_scaled.shape)
print("SVD reduced shape:", X_svd_2d.shape)
print(f"Variance explained by Component 1 + 2: {sum(evr[:2])*100:.2f}%")

# Right singular vectors = principal directions (what each component represents)
print("\nRight Singular Vectors Vt (top 2 rows = first 2 components):")
vt_df = pd.DataFrame(Vt[:2],
                     columns=['Age', 'Blood_Pressure', 'Cholesterol', 'BMI'],
                     index=['SVD Component 1', 'SVD Component 2'])
print(vt_df.round(4))

# =============================================================================
# Step 5 - Evaluate: Classification Accuracy Before vs After SVD
# =============================================================================

# Split original scaled data
X_train_orig, X_test_orig, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

# Apply SVD on train, project test using the SAME Vt (fit on train only)
U_tr, S_tr, Vt_tr = np.linalg.svd(X_train_orig, full_matrices=False)
X_train_svd = U_tr[:, :2] * S_tr[:2]          # project train
X_test_svd  = X_test_orig @ Vt_tr[:2].T        # project test using train's Vt

# Classifier on original 4 features
clf_orig = LogisticRegression(max_iter=1000, random_state=42)
clf_orig.fit(X_train_orig, y_train)
acc_orig = accuracy_score(y_test, clf_orig.predict(X_test_orig))

# Classifier on 2 SVD components
clf_svd = LogisticRegression(max_iter=1000, random_state=42)
clf_svd.fit(X_train_svd, y_train)
acc_svd = accuracy_score(y_test, clf_svd.predict(X_test_svd))

print("\n========== Evaluation ==========")
print(f"Accuracy - 4 original features   : {acc_orig:.4f}")
print(f"Accuracy - 2 SVD components      : {acc_svd:.4f}")
print(f"Dimensionality reduced from 4 → 2 features")

# =============================================================================
# Step 6 - Visualise: SVD 2D Scatter Plot
# =============================================================================

COLORS      = ['red', 'blue', 'green']
CLASS_NAMES = le.classes_   # ['Mild', 'Moderate', 'Severe']

plt.figure(figsize=(8, 5))
for i in range(3):
    plt.scatter(X_svd_2d[y == i, 0], X_svd_2d[y == i, 1],
                c=COLORS[i], s=60, label=CLASS_NAMES[i], alpha=0.7)

plt.title('SVD — 2D Projection of Health Risk Dataset')
plt.xlabel(f'SVD Component 1 ({evr[0]*100:.1f}% variance)')
plt.ylabel(f'SVD Component 2 ({evr[1]*100:.1f}% variance)')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Scree Plot (how many SVD components to keep)
# =============================================================================

variances  = evr * 100
cum_var    = np.cumsum(variances)
comp_range = range(1, len(variances) + 1)

fig, ax1 = plt.subplots(figsize=(8, 5))

ax1.bar(comp_range, variances, color='steelblue', alpha=0.7, label='Individual Variance')
ax1.set_xlabel('SVD Component')
ax1.set_ylabel('Variance Explained (%)', color='steelblue')
ax1.set_xticks(list(comp_range))

ax2 = ax1.twinx()
ax2.plot(comp_range, cum_var, marker='o', color='red', linewidth=2, label='Cumulative Variance')
ax2.set_ylabel('Cumulative Variance Explained (%)', color='red')
ax2.axhline(y=95, color='orange', linestyle='--', linewidth=1.5, label='95% threshold')
ax2.set_ylim(0, 110)

plt.title('Scree Plot — SVD Explained Variance')
fig.legend(loc='center right', bbox_to_anchor=(0.88, 0.5))
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - Singular Values Bar Chart
# =============================================================================

plt.figure(figsize=(6, 4))
plt.bar([f'S{i+1}' for i in range(len(S))], S,
        color=['steelblue', 'orange', 'green', 'red'])
plt.title('Singular Values — SVD')
plt.xlabel('Singular Value')
plt.ylabel('Magnitude')
for i, s in enumerate(S):
    plt.text(i, s + 0.1, f'{s:.2f}', ha='center', fontweight='bold')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6d - Vt Heatmap (how features load onto each SVD component)
# =============================================================================

plt.figure(figsize=(7, 4))
plt.imshow(Vt, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)
plt.colorbar(label='Loading Value')
plt.xticks(range(4), ['Age', 'Blood_Pressure', 'Cholesterol', 'BMI'], fontsize=11)
plt.yticks(range(4), [f'Component {i+1}' for i in range(4)], fontsize=11)
plt.title('SVD Right Singular Vectors (Vt) Heatmap\n(How much each feature loads onto each component)')

for i in range(4):
    for j in range(4):
        plt.text(j, i, f'{Vt[i, j]:.2f}',
                 ha='center', va='center', fontsize=10, fontweight='bold',
                 color='white' if abs(Vt[i, j]) > 0.5 else 'black')

plt.tight_layout()
plt.show()