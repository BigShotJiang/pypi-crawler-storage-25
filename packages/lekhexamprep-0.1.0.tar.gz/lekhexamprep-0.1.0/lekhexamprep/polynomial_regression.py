# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================
# Dataset: bp_regression.csv
# Features: Age, BMI, Cholesterol, Smoking
# Target:   Blood_Pressure (continuous — regression problem)

df = pd.read_csv('bp_regression.csv')

print("Shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:", list(df.columns))
print("\nMissing values:\n", df.isnull().sum())
print("\nBasic Statistics:")
print(df.describe())

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Features (X) and Target (y)
X = df[['Age', 'BMI', 'Cholesterol', 'Smoking']].values
y = df['Blood_Pressure'].values

# Standardise features
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

print("\nOriginal feature shape:", X.shape)
print("Scaled  feature shape :", X_scaled.shape)
print("Train size:", X_train.shape, " | Test size:", X_test.shape)

# =============================================================================
# Step 4 - Apply Polynomial Features + Train Model
# =============================================================================

# PolynomialFeatures transforms [a, b] into [1, a, b, a^2, ab, b^2] for degree=2
# This lets a LINEAR model learn NON-LINEAR relationships

degree = 2   # try 2, 3, 4 — higher = more complex curve

poly      = PolynomialFeatures(degree=degree, include_bias=False)
X_train_poly = poly.fit_transform(X_train)   # expand features on train
X_test_poly  = poly.transform(X_test)        # same transformation on test

print(f"\nDegree            : {degree}")
print(f"Original features : {X_train.shape[1]}")
print(f"Polynomial features generated: {X_train_poly.shape[1]}")
print(f"Feature names (first 10): {poly.get_feature_names_out(['Age','BMI','Chol','Smoke'])[:10]}")

# Train Linear Regression on the expanded polynomial features
model = LinearRegression()
model.fit(X_train_poly, y_train)

print(f"\nNumber of coefficients: {len(model.coef_)}")
print(f"Intercept: {model.intercept_:.4f}")

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = model.predict(X_test_poly)

mae  = mean_absolute_error(y_test, y_pred)
mse  = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2   = r2_score(y_test, y_pred)

print("\n========== Evaluation (Degree =", degree, ")==========")
print("MAE  (Mean Absolute Error) :", round(mae, 4))
print("MSE  (Mean Squared Error)  :", round(mse, 4))
print("RMSE (Root MSE)            :", round(rmse, 4))
print("R²   (R-Squared Score)     :", round(r2, 4))

# =============================================================================
# Step 6 - Visualise: Actual vs Predicted
# =============================================================================

plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, color='steelblue', s=60, alpha=0.7, label='Predicted vs Actual')
plt.plot([y_test.min(), y_test.max()],
         [y_test.min(), y_test.max()],
         color='red', linewidth=2, linestyle='--', label='Perfect Prediction Line')
plt.title(f'Polynomial Regression (Degree={degree}) — Actual vs Predicted')
plt.xlabel('Actual Blood Pressure')
plt.ylabel('Predicted Blood Pressure')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6b - Residual Plot
# =============================================================================

residuals = y_test - y_pred

plt.figure(figsize=(8, 5))
plt.scatter(y_pred, residuals, color='orange', s=60, alpha=0.7)
plt.axhline(y=0, color='red', linewidth=2, linestyle='--')
plt.title(f'Residual Plot — Polynomial Regression (Degree={degree})')
plt.xlabel('Predicted Blood Pressure')
plt.ylabel('Residuals (Actual - Predicted)')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6c - Polynomial Curve (1 feature only: Age vs Blood_Pressure)
# =============================================================================

# Use only Age to plot a clean 2D polynomial curve
X_age = df[['Age']].values
y_bp  = df['Blood_Pressure'].values

X_age_train, X_age_test, y_age_train, y_age_test = train_test_split(
    X_age, y_bp, test_size=0.2, random_state=42
)

# Use a Pipeline: PolynomialFeatures → LinearRegression
pipe = Pipeline([
    ('poly',  PolynomialFeatures(degree=degree, include_bias=False)),
    ('model', LinearRegression())
])
pipe.fit(X_age_train, y_age_train)

# Generate smooth curve across the Age range
age_range    = np.linspace(X_age.min(), X_age.max(), 300).reshape(-1, 1)
bp_predicted = pipe.predict(age_range)

plt.figure(figsize=(8, 5))
plt.scatter(X_age, y_bp, color='steelblue', s=40, alpha=0.5, label='Actual Data')
plt.plot(age_range, bp_predicted, color='red', linewidth=2.5,
         label=f'Polynomial Fit (Degree={degree})')
plt.title(f'Polynomial Regression Curve — Age vs Blood Pressure')
plt.xlabel('Age')
plt.ylabel('Blood Pressure')
plt.legend()
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6d - Compare Degrees: Underfitting vs Overfitting
# =============================================================================

degrees    = [1, 2, 3, 4, 5, 6]
train_r2s  = []
test_r2s   = []

print("\n========== Degree Comparison ==========")
for d in degrees:
    poly_d       = PolynomialFeatures(degree=d, include_bias=False)
    X_train_d    = poly_d.fit_transform(X_train)
    X_test_d     = poly_d.transform(X_test)

    m = LinearRegression()
    m.fit(X_train_d, y_train)

    train_r2 = r2_score(y_train, m.predict(X_train_d))
    test_r2  = r2_score(y_test,  m.predict(X_test_d))

    train_r2s.append(train_r2)
    test_r2s.append(test_r2)
    print(f"Degree={d}  ->  Train R²={train_r2:.4f}  |  Test R²={test_r2:.4f}")

plt.figure(figsize=(8, 5))
plt.plot(degrees, train_r2s, marker='o', color='blue',   linewidth=2, label='Train R²')
plt.plot(degrees, test_r2s,  marker='o', color='orange', linewidth=2, label='Test R²')
plt.title('Polynomial Degree vs R² — Bias-Variance Tradeoff')
plt.xlabel('Polynomial Degree')
plt.ylabel('R² Score')
plt.xticks(degrees)
plt.legend()
plt.tight_layout()
plt.show()

# When Train R² keeps rising but Test R² drops → OVERFITTING
# When both are low → UNDERFITTING
# Best degree = where Test R² is highest
best_degree = degrees[np.argmax(test_r2s)]
print(f"\nBest Degree = {best_degree}  (Test R² = {max(test_r2s):.4f})")