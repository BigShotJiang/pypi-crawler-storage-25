import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ── sklearn utilities (replaces all manual preprocessing & evaluation) ─────

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    PrecisionRecallDisplay,
    roc_auc_score,
)

# ══════════════════════════════════════════════════════════════════════════════
#  CUSTOM XGBoost MATHS — do not touch
# ══════════════════════════════════════════════════════════════════════════════

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))


def log_loss_xgb(y, F):
    p = np.clip(sigmoid(F), 1e-9, 1 - 1e-9)
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))


def compute_gradients(y, F):
    """Gradient g (residual) and Hessian h of log-loss used in XGBoost."""
    p = sigmoid(F)
    return p - y, p * (1.0 - p)


class _Node:
    def __init__(self):
        self.feature   = None
        self.threshold = None
        self.left      = None
        self.right     = None
        self.leaf_value = None

    @property
    def is_leaf(self):
        return self.leaf_value is not None


class _XGBTree:
    """
    Shallow decision tree using XGBoost split criterion.
        Leaf weight  = -ΣG / (ΣH + λ)
        Split gain   = 0.5 * [GL²/(HL+λ) + GR²/(HR+λ) - G²/(H+λ)] - γ
    """

    def __init__(self, max_depth=3, min_child_weight=5,
                 reg_lambda=3.0, gamma=0.5, n_quantiles=20, colsample=0.8):
        self.max_depth        = max_depth
        self.min_child_weight = min_child_weight
        self.reg_lambda       = reg_lambda
        self.gamma            = gamma
        self.n_quantiles      = n_quantiles
        self.colsample        = colsample
        self.root             = None
        self.selected_features = None

    def _lw(self, g, h):
        return -g.sum() / (h.sum() + self.reg_lambda)

    def _gain(self, gL, hL, gR, hR):
        def S(g, h): return g.sum() ** 2 / (h.sum() + self.reg_lambda)
        return 0.5 * (S(gL, hL) + S(gR, hR) - S(np.r_[gL, gR], np.r_[hL, hR])) - self.gamma

    def _best_split(self, X, g, h):
        best_gain, best_feature, best_threshold = -np.inf, None, None
        for feat in self.selected_features:
            col  = X[:, feat]
            uniq = np.unique(col)
            thresholds = (
                np.percentile(col, np.linspace(5, 95, self.n_quantiles))
                if len(uniq) > self.n_quantiles else uniq[:-1]
            )
            for thr in thresholds:
                lm = col <= thr
                if h[lm].sum() < self.min_child_weight or h[~lm].sum() < self.min_child_weight:
                    continue
                gain = self._gain(g[lm], h[lm], g[~lm], h[~lm])
                if gain > best_gain:
                    best_gain, best_feature, best_threshold = gain, feat, thr
        return best_feature, best_threshold, best_gain

    def _build(self, X, g, h, depth):
        node = _Node()
        if depth >= self.max_depth or len(X) <= 1:
            node.leaf_value = self._lw(g, h); return node
        feat, thr, gain = self._best_split(X, g, h)
        if feat is None or gain <= 0:
            node.leaf_value = self._lw(g, h); return node
        lm = X[:, feat] <= thr
        node.feature, node.threshold = feat, thr
        node.left  = self._build(X[lm],  g[lm],  h[lm],  depth + 1)
        node.right = self._build(X[~lm], g[~lm], h[~lm], depth + 1)
        return node

    def fit(self, X, g, h):
        n_cols = max(1, int(X.shape[1] * self.colsample))
        self.selected_features = np.random.choice(X.shape[1], n_cols, replace=False)
        self.root = self._build(X, g, h, 0)

    def _predict_row(self, x, node):
        if node.is_leaf: return node.leaf_value
        return self._predict_row(x, node.left if x[node.feature] <= node.threshold else node.right)

    def predict(self, X):
        return np.array([self._predict_row(x, self.root) for x in X])


class XGBoostClassifier:
    """
    XGBoost binary classifier — algorithm from Experiment 6.
        F0        = log-odds(mean(y))           ← initialisation
        g, h      = gradients & hessians        ← residuals
        subsample = row subsampling             ← variance reduction
        colsample = column subsampling          ← in _XGBTree
        η * tree  = shrinkage                   ← learning rate
        early stop on val loss plateau
        ŷ = sigmoid(F0 + η·Σtrees)
    """

    def __init__(self, n_estimators=500, max_depth=4, learning_rate=0.03,
                 reg_lambda=1.5, gamma=0.1, min_child_weight=3,
                 subsample=0.8, colsample=0.8, early_stopping_rounds=50):
        self.n_estimators        = n_estimators
        self.max_depth           = max_depth
        self.learning_rate       = learning_rate
        self.reg_lambda          = reg_lambda
        self.gamma               = gamma
        self.min_child_weight    = min_child_weight
        self.subsample           = subsample
        self.colsample           = colsample
        self.early_stopping_rounds = early_stopping_rounds

        self.trees        = []
        self.train_losses = []
        self.val_losses   = []
        self.base_score   = None
        self.best_round_  = None

    def fit(self, X, y, X_val=None, y_val=None, verbose=True):
        if isinstance(X, pd.DataFrame): X = X.values
        if isinstance(y, pd.Series):   y = y.values

        p0 = np.clip(y.mean(), 1e-6, 1 - 1e-6)
        F  = np.full(len(y), np.log(p0 / (1 - p0)))
        self.base_score = F[0]

        best_val, best_round, wait = np.inf, 0, 0

        for i in range(self.n_estimators):
            ns  = max(1, int(len(X) * self.subsample))
            idx = np.random.choice(len(X), ns, replace=False)
            g, h = compute_gradients(y[idx], F[idx])

            tree = _XGBTree(max_depth=self.max_depth,
                            min_child_weight=self.min_child_weight,
                            reg_lambda=self.reg_lambda,
                            gamma=self.gamma, colsample=self.colsample)
            tree.fit(X[idx], g, h)

            F += self.learning_rate * tree.predict(X)
            self.trees.append(tree)
            self.train_losses.append(log_loss_xgb(y, F))

            if X_val is not None:
                val_loss = log_loss_xgb(y_val, self._predict_F(X_val))
                self.val_losses.append(val_loss)
                if val_loss < best_val:
                    best_val, best_round, wait = val_loss, i, 0
                else:
                    wait += 1
                    if wait >= self.early_stopping_rounds:
                        self.trees = self.trees[:best_round + 1]
                        self.best_round_ = best_round + 1
                        if verbose:
                            print(f" Early stop @ round {i+1} | best: {self.best_round_}")
                        break

            if verbose and (i + 1) % 50 == 0:
                acc = np.mean((sigmoid(F) >= 0.5) == y)
                print(f" Round {i+1:4d} | loss={self.train_losses[-1]:.4f} | train acc={acc:.4f}")

        if self.best_round_ is None:
            self.best_round_ = len(self.trees)
        return self

    def _predict_F(self, X):
        if isinstance(X, pd.DataFrame): X = X.values
        F = np.full(len(X), self.base_score)
        for tree in self.trees:
            F += self.learning_rate * tree.predict(X)
        return F

    def predict_proba(self, X):
        return sigmoid(self._predict_F(X))

    def predict(self, X, thr=0.5):
        return (self.predict_proba(X) >= thr).astype(int)


print("Custom XGBoost (maths) ready.")

# ══════════════════════════════════════════════════════════════════════════════
#  SKLEARN PIPELINE — preprocessing, splitting, evaluation, plots
# ══════════════════════════════════════════════════════════════════════════════

# ── 1. Load data ──────────────────────────────────────────────────────────────

df = pd.read_csv("heart_disease.csv")
print(f"Shape: {df.shape} | Classes: {dict(df['heart_disease'].value_counts())}")
print(df.head())

X_raw = df.drop("heart_disease", axis=1)
y     = df["heart_disease"].values.astype(float)

# ── 2. sklearn: StandardScaler ────────────────────────────────────────────────

scaler = StandardScaler()
X      = scaler.fit_transform(X_raw)       # zero mean, unit variance

# ── 3. sklearn: train_test_split (80 / 10 / 10) ───────────────────────────────

X_train, X_test,  y_train, y_test  = train_test_split(
    X, y, test_size=0.10, random_state=42, stratify=y
)

X_tr2, X_val, y_tr2, y_val = train_test_split(
    X_train, y_train, test_size=0.10/0.90, random_state=42, stratify=y_train
)

print(f"Train: {len(X_tr2)} | Val: {len(X_val)} | Test: {len(X_test)}")

# ── 4. Train (custom XGBoost) ─────────────────────────────────────────────────

np.random.seed(0)
model = XGBoostClassifier(
    n_estimators=500,   max_depth=4,     learning_rate=0.03,
    reg_lambda=1.5,     gamma=0.1,       min_child_weight=3,
    subsample=0.80,     colsample=0.80,  early_stopping_rounds=50
)
model.fit(X_tr2, y_tr2, X_val=X_val, y_val=y_val, verbose=True)
print(f"\nTotal trees used: {len(model.trees)}")

# ── 5. sklearn: classification_report ─────────────────────────────────────────

for split_name, Xs, ys in [("Train", X_train, y_train), ("Test", X_test, y_test)]:
    preds = model.predict(Xs)
    print(f"\n── {split_name} Set ────────────────────────────────────────")
    print(classification_report(ys, preds, target_names=["No Disease", "Disease"]))

# AUC-ROC (bonus — one line with sklearn)
probs    = model.predict_proba(X_test)
auc_roc  = roc_auc_score(y_test, probs)
print(f"Test ROC-AUC: {auc_roc:.4f}")

# ── 6. Threshold scan (still useful, kept manual since it's analysis not ML) ──

print("\n── Threshold Scan ──────────────────────────────────────────")
print(f"{'Thr':>5} {'Acc':>6} {'Prec':>6} {'Rec':>6} {'F1':>6}")
for thr in np.arange(0.30, 0.71, 0.05):
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
    yp  = (probs >= thr).astype(int)
    marker = " <-- default" if abs(thr - 0.50) < 0.01 else ""
    print(
        f"{thr:>5.2f} "
        f"{accuracy_score(y_test, yp):>6.4f} "
        f"{precision_score(y_test, yp, zero_division=0):>6.4f} "
        f"{recall_score(y_test, yp, zero_division=0):>6.4f} "
        f"{f1_score(y_test, yp, zero_division=0):>6.4f}"
        f"{marker}"
    )

# ── 7. sklearn: Visualisations ─────────────────────────────────────────────────

fig, axes = plt.subplots(1, 4, figsize=(20, 4))
fig.suptitle("Experiment 6 — XGBoost from Scratch + sklearn Evaluation", fontsize=13)

# (a) Loss curves (custom — sklearn has no hook into our tree loop)
rounds = range(1, len(model.train_losses) + 1)
axes[0].plot(rounds, model.train_losses, label="Train")
if model.val_losses:
    axes[0].plot(range(1, len(model.val_losses) + 1), model.val_losses, label="Validation")
axes[0].axvline(model.best_round_, linestyle="--", label=f"Best ({model.best_round_})")
axes[0].set_title("Loss vs Boosting Rounds")
axes[0].set_xlabel("Round"); axes[0].set_ylabel("Log Loss")
axes[0].legend(); axes[0].grid(alpha=0.3)

# (b) sklearn: ConfusionMatrixDisplay
ConfusionMatrixDisplay.from_predictions(
    y_test, model.predict(X_test),
    display_labels=["No Disease", "Disease"],
    cmap="Blues", ax=axes[1]
)
axes[1].set_title("Confusion Matrix (Test)")

# (c) sklearn: RocCurveDisplay
RocCurveDisplay.from_predictions(y_test, probs, ax=axes[2])
axes[2].set_title(f"ROC Curve (AUC = {auc_roc:.3f})")
axes[2].grid(alpha=0.3)

# (d) sklearn: PrecisionRecallDisplay
PrecisionRecallDisplay.from_predictions(y_test, probs, ax=axes[3])
axes[3].set_title("Precision–Recall Curve")
axes[3].grid(alpha=0.3)

plt.tight_layout()
plt.savefig("xgboost_results.png", dpi=120, bbox_inches="tight")
plt.show()