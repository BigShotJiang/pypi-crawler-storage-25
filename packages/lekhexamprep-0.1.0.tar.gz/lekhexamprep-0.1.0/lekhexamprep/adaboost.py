# =============================================================================
# AdaBoost Classifier
# Dataset: Breast Cancer Wisconsin — Kaggle
# https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
#
# SETUP:
#   kaggle datasets download -d uciml/breast-cancer-wisconsin-data --unzip
#   → this gives you data.csv
#   OR manually download from Kaggle and place data.csv in the same folder
# =============================================================================

# Step 1 - Import Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (accuracy_score, confusion_matrix,
                             classification_report, ConfusionMatrixDisplay)
from sklearn.preprocessing import StandardScaler, LabelEncoder

# =============================================================================
# Step 2 - Load and Explore Dataset
# =============================================================================

df = pd.read_csv('data.csv')      # CSV must be in the same folder as this file

print("Shape         :", df.shape)
print("\nColumns       :", list(df.columns))
print("\nFirst 5 rows:")
print(df.head())
print("\nMissing values:")
print(df.isnull().sum())
print("\nClass distribution:")
print(df['diagnosis'].value_counts())   # M = Malignant, B = Benign

# =============================================================================
# Step 3 - Preprocess the Data
# =============================================================================

# Drop columns we don't need
df = df.drop(columns=['id', 'Unnamed: 32'], errors='ignore')

# Encode target: M → 1, B → 0
le              = LabelEncoder()
df['diagnosis'] = le.fit_transform(df['diagnosis'])

# Separate features and target
X             = df.drop(columns=['diagnosis']).values
y             = df['diagnosis'].values
feature_names = df.drop(columns=['diagnosis']).columns.tolist()

# Train-test split (80-20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Scale features
scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)     # only transform, never fit on test data

print("\nTraining samples  :", X_train.shape[0])
print("Testing  samples  :", X_test.shape[0])
print("Number of features:", X_train.shape[1])

# =============================================================================
# Step 4 - Train AdaBoost Model
# =============================================================================
# AdaBoost = Adaptive Boosting
# Idea: Train weak learners (stumps) one by one.
#       Each new learner focuses more on the samples the previous one got WRONG.
#       Final prediction = weighted vote of all weak learners.

base_estimator = DecisionTreeClassifier(max_depth=1)   # weak learner = stump

ada = AdaBoostClassifier(
    estimator     = base_estimator,   # weak learner
    n_estimators  = 100,              # number of weak learners to train
    learning_rate = 1.0,              # shrinks contribution of each learner
    algorithm     = 'SAMME',          # use SAMME (SAMME.R is deprecated)
    random_state  = 42
)

ada.fit(X_train, y_train)
print("\nModel trained successfully!")
print("Number of estimators:", ada.n_estimators)

# =============================================================================
# Step 5 - Evaluate the Model
# =============================================================================

y_pred = ada.predict(X_test)

print("\n========== Evaluation ==========")
print("Accuracy         :", round(accuracy_score(y_test, y_pred), 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Benign', 'Malignant']))

# Cross-validation (5-fold)
cv_scores = cross_val_score(ada, X, y, cv=5, scoring='accuracy')
print("5-Fold CV Scores :", cv_scores.round(4))
print("CV Mean Accuracy :", round(cv_scores.mean(), 4))
print("CV Std Dev       :", round(cv_scores.std(), 4))

# Confusion Matrix
cm   = confusion_matrix(y_test, y_pred)
print("\nConfusion Matrix:\n", cm)

disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                               display_labels=['Benign', 'Malignant'])
disp.plot(cmap='Oranges')
plt.title('AdaBoost - Confusion Matrix')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 6 - Feature Importance
# =============================================================================

importances = ada.feature_importances_
indices     = np.argsort(importances)[::-1]
top_n       = 10

print("\nTop 10 Important Features:")
for i in range(top_n):
    print(f"  {i+1}. {feature_names[indices[i]]:35s} {importances[indices[i]]:.4f}")

plt.figure(figsize=(10, 5))
plt.bar(range(top_n),
        importances[indices[:top_n]],
        color='darkorange', edgecolor='black', linewidth=0.6)
plt.xticks(range(top_n),
           [feature_names[i] for i in indices[:top_n]],
           rotation=45, ha='right', fontsize=8)
plt.title('AdaBoost - Top 10 Feature Importances')
plt.ylabel('Importance Score')
plt.tight_layout()
plt.show()

# =============================================================================
# Step 7 - Accuracy vs Number of Estimators
# =============================================================================
# Shows how AdaBoost improves as it adds more weak learners

train_errors = []
test_errors  = []

for y_pred_train, y_pred_test in zip(
    ada.staged_predict(X_train),
    ada.staged_predict(X_test)
):
    train_errors.append(1 - accuracy_score(y_train, y_pred_train))
    test_errors.append(1 - accuracy_score(y_test,   y_pred_test))

plt.figure(figsize=(9, 5))
plt.plot(train_errors, label='Train Error', color='blue',  linewidth=2)
plt.plot(test_errors,  label='Test Error',  color='red',   linewidth=2)
plt.xlabel('Number of Estimators (Weak Learners)')
plt.ylabel('Error Rate')
plt.title('AdaBoost - Error vs Number of Estimators')
plt.legend()
plt.tight_layout()
plt.show()