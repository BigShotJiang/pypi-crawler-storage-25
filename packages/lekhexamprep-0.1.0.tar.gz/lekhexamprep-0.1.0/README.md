# lekhexamprep

ML exam prep package — 12 algorithms, one `run()` call each.

## Install

```bash
pip install lekhexamprep        # from PyPI (after publishing)
# or locally:
pip install .
```

## Usage

```python
import lekhexamprep as lep

lep.linear_regression()
lep.polynomial_regression(degree=3)
lep.classification_regression()
lep.decision_tree(max_depth=3)
lep.linear_svm()
lep.nonlinear_svm(kernel="rbf")
lep.random_forest(n_estimators=100)
lep.xgboost()
lep.kmeans(k=3)
lep.svd()
lep.pca(n_components=2)
lep.lda(n_components=2)

# Pass plot=True to any function for a matplotlib visualisation
lep.pca(plot=True)
```

## Algorithms

| # | Module | Algorithm |
|---|--------|-----------|
| 1 | `linear_regression` | Simple Linear Regression |
| 2 | `polynomial_regression` | Polynomial Regression (Pipeline) |
| 3 | `classification_regression` | Logistic Regression (Classification) |
| 4 | `decision_tree` | Decision Tree Classifier |
| 5 | `linear_svm` | Linear SVM |
| 6 | `nonlinear_svm` | Non-Linear SVM (RBF kernel) |
| 7 | `random_forest` | Random Forest |
| 8 | `xgboost` | XGBoost |
| 9 | `kmeans` | K-Means Clustering |
| 10 | `svd` | Singular Value Decomposition |
| 11 | `pca` | Principal Component Analysis |
| 12 | `lda` | Linear Discriminant Analysis |
