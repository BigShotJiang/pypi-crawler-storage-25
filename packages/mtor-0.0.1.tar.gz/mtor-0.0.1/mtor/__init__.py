"""mtor — architect-implementer dispatch for AI coding agents.

Smart model plans, cheap model builds. Temporal-backed task queue
with coaching injection, stall detection, and worker reflection.
"""

__version__ = "0.0.1"
