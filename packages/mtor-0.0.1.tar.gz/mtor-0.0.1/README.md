# mtor

> Named after [mTOR](https://en.wikipedia.org/wiki/MTOR), the master kinase that regulates when cells start translating mRNA into protein. mtor regulates when AI agents start translating specs into code.

Architect-implementer dispatch for AI coding agents.

**Smart model plans. Cheap model builds.**

- **Architect-implementer split**: Expensive model (Claude, GPT-4o) handles judgment and code review. Cheap model (GLM, DeepSeek, Qwen) handles bulk implementation.
- **Temporal-backed task queue**: Durable dispatch with retry, timeout, and worker pools. Ship code while you sleep.
- **Coaching injection**: Structured feedback from reviewers is prepended to every dispatch. The cheap model learns from past mistakes without fine-tuning.
- **Stall detection**: Signal-based detection (monologue, built-nothing, self-reported) replaces hard timeouts.
- **Worker reflection**: Workers self-report what surprised them after each task. Patterns compound into coaching.

## Status

Planning. Not yet usable. See the [design doc](https://terryli.hm) for architecture details.
