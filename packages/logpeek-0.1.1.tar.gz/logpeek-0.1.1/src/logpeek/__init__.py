"""logpeek — a colorful CLI log viewer."""

__version__ = "0.1.1"