"""Log line parsing and ANSI colorization."""

import re

# ANSI escape codes
RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"

COLORS = {
    "DEBUG":    "\033[36m",    # cyan
    "INFO":     "\033[32m",    # green
    "WARNING":  "\033[33m",    # yellow
    "WARN":     "\033[33m",
    "ERROR":    "\033[31m",    # red
    "CRITICAL": "\033[35m",    # magenta
    "FATAL":    "\033[35m",
}

# Matches common log level tokens in a line
LEVEL_RE = re.compile(
    r"\b(DEBUG|INFO|WARNING|WARN|ERROR|CRITICAL|FATAL)\b", re.IGNORECASE
)


def detect_level(line: str) -> str | None:
    """Return the first log level token found in line, uppercased."""
    m = LEVEL_RE.search(line)
    return m.group(1).upper() if m else None


def colorize(line: str, level: str | None) -> str:
    """Return the line with ANSI color applied based on its level."""
    if level is None:
        return DIM + line + RESET

    color = COLORS.get(level, "")
    # Highlight the level keyword itself in bold, rest in the level color
    def replace_level(m: re.Match) -> str:
        return BOLD + color + m.group(0).upper() + RESET + color

    colored = color + LEVEL_RE.sub(replace_level, line) + RESET
    return colored


def matches_filter(line: str, include: str | None, exclude: str | None) -> bool:
    """Return True if the line passes include/exclude filters."""
    if include and include.lower() not in line.lower():
        return False
    if exclude and exclude.lower() in line.lower():
        return False
    return True
