"""logpeek CLI — colorful log viewer."""

import sys
import time
import click

from logpeek.parser import detect_level, colorize, matches_filter
from logpeek import __version__


def process_line(line: str, include: str | None, exclude: str | None, no_color: bool) -> None:
    line = line.rstrip("\n")
    level = detect_level(line)
    if not matches_filter(line, include, exclude):
        return
    output = line if no_color else colorize(line, level)
    click.echo(output)


@click.command()
@click.version_option(__version__, prog_name="logpeek")
@click.argument("file", type=click.Path(exists=True), required=False)
@click.option("-f", "--follow", is_flag=True, help="Follow file (like tail -f).")
@click.option("-n", "--lines", default=0, help="Show last N lines before following (use with -f).")
@click.option("-i", "--include", default=None, help="Only show lines containing this text.")
@click.option("-e", "--exclude", default=None, help="Hide lines containing this text.")
@click.option("--level", "filter_level", default=None,
              type=click.Choice(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], case_sensitive=False),
              help="Only show lines at this log level.")
@click.option("--no-color", is_flag=True, help="Disable colored output.")
def main(file, follow, lines, include, exclude, filter_level, no_color):
    """
    \b
    logpeek — colorful log viewer

    Read a log FILE (or stdin) and pretty-print it with color-coded levels.

    \b
    Examples:
      logpeek app.log
      logpeek app.log --level ERROR
      logpeek app.log -f -n 20
      logpeek app.log -i "database" -e "debug"
      cat app.log | logpeek
    """
    # If a level filter is set, override include to match that level keyword
    effective_include = filter_level if filter_level else include

    # ── stdin mode ──────────────────────────────────────────────────────────
    if file is None:
        if sys.stdin.isatty():
            raise click.UsageError("Provide a FILE argument or pipe log data via stdin.")
        for line in sys.stdin:
            process_line(line, effective_include, exclude, no_color)
        return

    # ── follow mode (tail -f) ───────────────────────────────────────────────
    if follow:
        with open(file, "r", errors="replace") as fh:
            # Optionally seek to last N lines first
            if lines > 0:
                all_lines = fh.readlines()
                for l in all_lines[-lines:]:
                    process_line(l, effective_include, exclude, no_color)
                # Don't seek back — continue from end
            else:
                fh.seek(0, 2)  # seek to end

            click.echo(click.style(f"  Following {file} — press Ctrl+C to stop\n", fg="bright_black"))
            try:
                while True:
                    chunk = fh.readline()
                    if chunk:
                        process_line(chunk, effective_include, exclude, no_color)
                    else:
                        time.sleep(0.1)
            except KeyboardInterrupt:
                click.echo(click.style("\n  Stopped.", fg="bright_black"))
        return

    # ── normal read mode ────────────────────────────────────────────────────
    with open(file, "r", errors="replace") as fh:
        for line in fh:
            process_line(line, effective_include, exclude, no_color)
