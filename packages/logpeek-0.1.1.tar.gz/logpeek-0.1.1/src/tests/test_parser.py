"""Tests for logpeek."""

from logpeek.parser import detect_level, colorize, matches_filter


def test_detect_level_info():
    assert detect_level("2024-01-01 INFO server started") == "INFO"


def test_detect_level_error():
    assert detect_level("[ERROR] connection refused") == "ERROR"


def test_detect_level_none():
    assert detect_level("just a plain log line") is None


def test_detect_level_case_insensitive():
    assert detect_level("warning: disk space low") == "WARNING"


def test_matches_filter_include():
    assert matches_filter("INFO database connected", include="database", exclude=None)
    assert not matches_filter("INFO server started", include="database", exclude=None)


def test_matches_filter_exclude():
    assert not matches_filter("DEBUG polling heartbeat", include=None, exclude="heartbeat")
    assert matches_filter("ERROR disk full", include=None, exclude="heartbeat")


def test_matches_filter_both():
    assert matches_filter("INFO database ok", include="database", exclude="error")
    assert not matches_filter("INFO database error", include="database", exclude="error")


def test_colorize_returns_string():
    result = colorize("INFO server started", "INFO")
    assert "INFO" in result
    assert isinstance(result, str)


def test_colorize_no_level():
    result = colorize("plain line", None)
    assert "plain line" in result
