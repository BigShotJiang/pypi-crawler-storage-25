# logpeek

A colorful CLI log viewer with filtering and follow mode.

```
logpeek app.log
logpeek app.log --level ERROR
logpeek app.log -f -n 20
logpeek app.log -i "database" -e "debug"
cat app.log | logpeek
```

## Install

```bash
pip install logpeek
# or
uv add logpeek
```

## Usage

```
Usage: logpeek [OPTIONS] [FILE]

  logpeek — colorful log viewer

  Read a log FILE (or stdin) and pretty-print it with color-coded levels.

Options:
  --version               Show the version and exit.
  -f, --follow            Follow file (like tail -f).
  -n, --lines INTEGER     Show last N lines before following (use with -f).
  -i, --include TEXT      Only show lines containing this text.
  -e, --exclude TEXT      Hide lines containing this text.
  --level [DEBUG|INFO|WARNING|ERROR|CRITICAL]
                          Only show lines at this log level.
  --no-color              Disable colored output.
  --help                  Show this message and exit.
```

## Log level colors

| Level    | Color   |
|----------|---------|
| DEBUG    | Cyan    |
| INFO     | Green   |
| WARNING  | Yellow  |
| ERROR    | Red     |
| CRITICAL | Magenta |

## License

MIT
