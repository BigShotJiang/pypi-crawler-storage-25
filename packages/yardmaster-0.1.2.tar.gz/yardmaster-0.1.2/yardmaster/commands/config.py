from __future__ import annotations

import shutil
from importlib.resources import files
from pathlib import Path

import click
from rich.console import Console

console = Console()

GLOBAL_CONFIG_PATH = Path.home() / ".yardmaster.yaml"


@click.group(help="Manage yardmaster configuration.")
def config_command() -> None:
    pass


@config_command.command(name="init", help="Create a global config at ~/.yardmaster.yaml.")
@click.option("--force", is_flag=True, help="Overwrite existing config if present.")
def init_command(force: bool) -> None:
    if GLOBAL_CONFIG_PATH.exists() and not force:
        console.print(f"[yellow]Config already exists at {GLOBAL_CONFIG_PATH}[/yellow]")
        console.print("Use [cyan]--force[/cyan] to overwrite.")
        return

    sample = files("yardmaster").joinpath("yardmaster.yaml.sample")
    if not sample.is_file():
        console.print("[red]Sample config not found in package.[/red]")
        raise SystemExit(1)

    with sample.open("rb") as src, GLOBAL_CONFIG_PATH.open("wb") as dst:
        shutil.copyfileobj(src, dst)
    console.print(f"[green]Config created at {GLOBAL_CONFIG_PATH}[/green]")
    console.print("Edit the file to set your Jenkins URL, credentials, and paths.")
