from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console

from yardmaster import __version__
from yardmaster.commands.config import config_command
from yardmaster.commands.epoch import epoch_command
from yardmaster.commands.jenkins import jenkins_command
from yardmaster.commands.release import release_command
from yardmaster.commands.retag import retag_command
from yardmaster.commands.sdk import sdk_command
from yardmaster.commands.status import status_command
from yardmaster.config import load_config
from yardmaster.utils.logger import setup_logger

console = Console()
CONFIG_FILE = ".yardmaster.yaml"
CONFIG_ENV_VAR = "YARDMASTER_CONFIG"


@click.group()
@click.version_option(version=__version__, prog_name="yardmaster")
@click.option(
    "-c",
    "--config",
    type=click.Path(path_type=Path),
    default=None,
    envvar=CONFIG_ENV_VAR,
    help=f"Configuration file path (env: {CONFIG_ENV_VAR})",
)
@click.option("-v", "--verbose", is_flag=True, help="Verbose output")
@click.pass_context
def cli(ctx: click.Context, config: Path | None, verbose: bool) -> None:
    """🚂 Yardmaster - Flatcar Container Linux Release Management Tool"""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose

    # Commands that don't need configuration
    if ctx.invoked_subcommand in ("epoch", "config"):
        return

    if config is None:
        local = Path(CONFIG_FILE)
        global_ = Path.home() / ".yardmaster.yaml"
        if local.exists():
            config = local
        elif global_.exists():
            config = global_
        else:
            console.print(f"[red]Error: Config file not found: {CONFIG_FILE}[/red]")
            console.print(
                "Run [cyan]yardmaster config init[/cyan] to create a global config, or "
                f"copy [cyan].yardmaster.yaml.sample[/cyan] to [cyan]{CONFIG_FILE}[/cyan]."
            )
            sys.exit(1)

    ctx.obj["config"] = load_config(config)
    log_level = "DEBUG" if verbose else ctx.obj["config"].logging.level
    setup_logger(log_level, fmt=ctx.obj["config"].logging.format)


cli.add_command(config_command, name="config")
cli.add_command(epoch_command, name="epoch")
cli.add_command(release_command, name="release")
cli.add_command(jenkins_command, name="jenkins")
cli.add_command(retag_command, name="retag")
cli.add_command(sdk_command, name="sdk")
cli.add_command(status_command, name="status")


def main() -> None:
    cli(obj={})


if __name__ == "__main__":
    main()
