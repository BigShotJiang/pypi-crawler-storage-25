"""Grid carbon intensity by cloud region.

Values are in gCO₂e per kWh. Sources:
- AWS: Electricity Maps / AWS Customer Carbon Footprint Tool (2024)
- GCP: Google Cloud region-level carbon data (2024)
- Azure: Microsoft Emissions Impact Dashboard (2024)
- Country fallbacks: IEA 2022 electricity generation intensity data

All values are annual averages; real-time intensity varies significantly.
"""

from __future__ import annotations

from agent_carbon.factors import GLOBAL_AVG_GRID_GCO2_PER_KWH

# gCO₂e / kWh for major cloud regions.
REGION_INTENSITY: dict[str, float] = {
    # -- AWS ------------------------------------------------------------------
    "us-east-1": 386.0,       # Virginia         (US Mid-Atlantic grid)
    "us-east-2": 500.0,       # Ohio             (US Midwest grid)
    "us-west-1": 203.0,       # N. California    (WECC California)
    "us-west-2": 135.0,       # Oregon           (WECC NW, heavy hydro)
    "ca-central-1": 120.0,    # Canada           (mostly hydro)
    "eu-west-1": 278.0,       # Ireland          (2024 avg incl. wind)
    "eu-west-2": 225.0,       # London           (UK grid)
    "eu-west-3": 58.0,        # Paris            (heavy nuclear)
    "eu-central-1": 338.0,    # Frankfurt        (DE grid)
    "eu-north-1": 8.0,        # Stockholm        (SE, hydro + nuclear)
    "eu-south-1": 290.0,      # Milan            (IT grid)
    "ap-northeast-1": 465.0,  # Tokyo            (JP grid)
    "ap-northeast-2": 415.0,  # Seoul            (KR grid)
    "ap-southeast-1": 493.0,  # Singapore        (SG grid)
    "ap-southeast-2": 610.0,  # Sydney           (NSW grid, coal-heavy)
    "ap-south-1": 632.0,      # Mumbai           (IN grid)
    "sa-east-1": 74.0,        # São Paulo        (BR grid, mostly hydro)
    "me-south-1": 680.0,      # Bahrain          (ME grid, gas-heavy)
    "af-south-1": 750.0,      # Cape Town        (ZA grid, coal-heavy)
    # -- GCP ------------------------------------------------------------------
    "us-central1": 534.0,     # Iowa             (US Midwest)
    "us-east1": 386.0,        # South Carolina   (US South-East)
    "us-east4": 386.0,        # Northern Virginia
    "us-east5": 386.0,        # Columbus, Ohio
    "us-west1": 135.0,        # Oregon
    "us-west2": 203.0,        # Los Angeles
    "us-west3": 460.0,        # Salt Lake City
    "us-west4": 460.0,        # Las Vegas
    "us-south1": 430.0,       # Dallas
    "northamerica-northeast1": 37.0,   # Montréal (QC hydro)
    "northamerica-northeast2": 120.0,  # Toronto
    "europe-west1": 150.0,    # Belgium
    "europe-west2": 225.0,    # London
    "europe-west3": 338.0,    # Frankfurt
    "europe-west4": 390.0,    # Netherlands
    "europe-west6": 58.0,     # Zürich (CH, mostly hydro)
    "europe-west9": 58.0,     # Paris
    "europe-north1": 8.0,     # Helsinki (FI, wind + nuclear)
    "asia-east1": 530.0,      # Taiwan
    "asia-east2": 360.0,      # Hong Kong
    "asia-northeast1": 465.0, # Tokyo
    "asia-northeast2": 340.0, # Osaka
    "asia-northeast3": 415.0, # Seoul
    "asia-southeast1": 493.0, # Singapore
    "asia-southeast2": 620.0, # Jakarta
    "asia-south1": 632.0,     # Mumbai
    "australia-southeast1": 610.0,  # Sydney
    "southamerica-east1": 74.0,     # São Paulo
    # -- Azure ----------------------------------------------------------------
    "eastus": 386.0,           # Virginia
    "eastus2": 386.0,          # Virginia (zone 2)
    "centralus": 500.0,        # Iowa
    "northcentralus": 500.0,   # Chicago
    "southcentralus": 430.0,   # Texas
    "westcentralus": 460.0,    # Wyoming
    "westus": 203.0,           # California
    "westus2": 135.0,          # Washington (hydro)
    "westus3": 460.0,          # Phoenix
    "canadacentral": 120.0,    # Toronto
    "canadaeast": 37.0,        # Québec City
    "northeurope": 278.0,      # Ireland
    "westeurope": 390.0,       # Netherlands
    "uksouth": 225.0,          # London
    "ukwest": 225.0,           # Cardiff
    "francecentral": 58.0,     # Paris
    "francesouth": 58.0,       # Marseille
    "germanywestcentral": 338.0,      # Frankfurt
    "germanynorth": 338.0,            # Hamburg
    "switzerlandnorth": 58.0,         # Zürich
    "swedencentral": 8.0,             # Gävle
    "norwayeast": 30.0,               # Oslo (heavy hydro)
    "japaneast": 465.0,               # Tokyo
    "japanwest": 340.0,               # Osaka
    "koreacentral": 415.0,            # Seoul
    "southeastasia": 493.0,           # Singapore
    "eastasia": 360.0,                # Hong Kong
    "australiaeast": 610.0,           # New South Wales
    "australiasoutheast": 580.0,      # Victoria
    "brazilsouth": 74.0,              # São Paulo
    "southafricanorth": 750.0,        # Johannesburg
    "uaenorth": 680.0,                # Dubai
    "centralindia": 632.0,            # Pune
    "southindia": 632.0,              # Chennai
    "westindia": 632.0,               # Mumbai
}


def get_grid_intensity(region: str | None) -> float:
    """Return gCO₂e/kWh for a region, falling back to the global average."""
    if region is None:
        return GLOBAL_AVG_GRID_GCO2_PER_KWH
    return REGION_INTENSITY.get(region, GLOBAL_AVG_GRID_GCO2_PER_KWH)
