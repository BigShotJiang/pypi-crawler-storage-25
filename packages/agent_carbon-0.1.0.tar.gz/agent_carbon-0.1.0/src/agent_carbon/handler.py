"""CarbonCallbackHandler — drop-in LangChain callback that tracks emissions."""

from __future__ import annotations

import asyncio
import functools
import threading
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult

from agent_carbon.factors import GLOBAL_AVG_GRID_GCO2_PER_KWH, resolve_factors
from agent_carbon.receipt import CallRecord, CarbonReceipt
from agent_carbon.regions import get_grid_intensity


class CarbonCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that accumulates per-call carbon emissions.

    Works with any LangChain-compatible framework (LangGraph, CrewAI, etc.).
    Pass it in the ``callbacks`` list of any ``invoke`` / ``ainvoke`` call and
    read ``handler.receipt`` afterwards.

    Args:
        region: Cloud region for grid intensity lookup (e.g. ``"us-east-1"``).
            Omit to use the global average (494 gCO₂e/kWh, IEA 2022).
        frontier_model: Model slug used as the savings baseline.
            Defaults to ``"claude-opus-4-6"``.
    """

    def __init__(
        self,
        region: str | None = None,
        frontier_model: str = "claude-opus-4-6",
    ) -> None:
        super().__init__()
        self.region = region
        self.frontier_model = frontier_model
        self._pending: dict[str, dict[str, Any]] = {}
        self._records: list[CallRecord] = []
        self._lock = threading.Lock()
        self._started_at: datetime | None = None

    # ------------------------------------------------------------------
    # LangChain callback entry points
    # ------------------------------------------------------------------

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._on_llm_start_common(serialized, run_id, kwargs)

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._on_llm_start_common(serialized, run_id, kwargs)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        pending = self._pending.pop(str(run_id), {})
        model_name = pending.get("model_name", "unknown")

        llm_output = response.llm_output or {}

        # Some providers set model name in the response rather than the request.
        if model_name == "unknown":
            model_name = (
                llm_output.get("model_name")
                or llm_output.get("model")
                or "unknown"
            )

        input_tokens, output_tokens = self._extract_tokens(llm_output, response)

        factors = resolve_factors(model_name)
        grid_intensity = get_grid_intensity(self.region)

        if factors is not None and input_tokens is not None and output_tokens is not None:
            wh = (
                input_tokens / 1_000_000 * factors.input_wh_per_1m
                + output_tokens / 1_000_000 * factors.output_wh_per_1m
            )
            gco2e = wh * grid_intensity / 1000
            estimated = factors.estimated
            provider = factors.provider
        else:
            wh = 0.0
            gco2e = 0.0
            estimated = True
            provider = "unknown"

        record = CallRecord(
            call_id=str(uuid4()),
            run_id=str(run_id),
            model=model_name,
            provider=provider,
            input_tokens=input_tokens or 0,
            output_tokens=output_tokens or 0,
            gco2e=round(gco2e, 6),
            wh=round(wh, 6),
            cost_usd=None,
            region=self.region,
            grid_multiplier=round(grid_intensity / GLOBAL_AVG_GRID_GCO2_PER_KWH, 4),
            estimated=estimated,
            timestamp=pending.get("timestamp", datetime.now(timezone.utc)),
        )

        with self._lock:
            self._records.append(record)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self._pending.pop(str(run_id), None)

    # Async versions delegate to sync so the handler works in both contexts.
    async def aon_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self.on_chat_model_start(serialized, messages, run_id=run_id, **kwargs)

    async def aon_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self.on_llm_end(response, run_id=run_id, **kwargs)

    async def aon_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        self.on_llm_error(error, run_id=run_id, **kwargs)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def receipt(self) -> CarbonReceipt:
        """Return the current accumulated receipt (safe to call mid-run)."""
        with self._lock:
            records = list(self._records)
        return CarbonReceipt.from_records(
            records,
            region=self.region,
            frontier_model=self.frontier_model,
            started_at=self._started_at,
        )

    def reset(self) -> None:
        """Clear accumulated records, keeping region and frontier config."""
        with self._lock:
            self._records.clear()
        self._pending.clear()
        self._started_at = None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _on_llm_start_common(
        self,
        serialized: dict[str, Any],
        run_id: UUID,
        kwargs: dict[str, Any],
    ) -> None:
        if self._started_at is None:
            self._started_at = datetime.now(timezone.utc)

        invocation = kwargs.get("invocation_params") or {}
        model_name = self._extract_model_name(serialized, invocation)
        self._pending[str(run_id)] = {
            "model_name": model_name,
            "timestamp": datetime.now(timezone.utc),
        }

    @staticmethod
    def _extract_model_name(
        serialized: dict[str, Any],
        invocation_params: dict[str, Any],
    ) -> str:
        """Pull the model name from whichever dict has it."""
        skw = serialized.get("kwargs") or {}
        return (
            invocation_params.get("model")
            or invocation_params.get("model_name")
            or invocation_params.get("model_id")
            or skw.get("model_name")
            or skw.get("model")
            or serialized.get("name", "unknown")
            or "unknown"
        )

    @staticmethod
    def _extract_tokens(
        llm_output: dict[str, Any],
        response: LLMResult,
    ) -> tuple[int | None, int | None]:
        """Extract (input_tokens, output_tokens) from provider-specific dicts."""
        # OpenAI / most providers
        usage = llm_output.get("token_usage") or llm_output.get("usage") or {}

        input_tokens = (
            usage.get("prompt_tokens")
            or usage.get("input_tokens")
            or usage.get("prompt_token_count")
            or llm_output.get("prompt_tokens")
        )
        output_tokens = (
            usage.get("completion_tokens")
            or usage.get("output_tokens")
            or usage.get("candidates_token_count")
            or llm_output.get("completion_tokens")
        )

        # Fall back to summing generation token counts if the LLM reports them
        # per-generation (some providers attach usage to each generation chunk).
        if input_tokens is None or output_tokens is None:
            gen_input = gen_output = 0
            for gen_list in response.generations:
                for gen in gen_list:
                    info = getattr(gen, "generation_info", None) or {}
                    gen_input += (
                        info.get("input_tokens")
                        or info.get("prompt_tokens")
                        or 0
                    )
                    gen_output += (
                        info.get("output_tokens")
                        or info.get("completion_tokens")
                        or 0
                    )
            if gen_input or gen_output:
                input_tokens = input_tokens or gen_input or None
                output_tokens = output_tokens or gen_output or None

        return (
            int(input_tokens) if input_tokens is not None else None,
            int(output_tokens) if output_tokens is not None else None,
        )


# ---------------------------------------------------------------------------
# @track_carbon decorator
# ---------------------------------------------------------------------------

def track_carbon(
    fn: Any = None,
    *,
    region: str | None = None,
    frontier_model: str = "claude-opus-4-6",
) -> Any:
    """Decorator that tracks carbon for a function using LangChain callbacks.

    Injects a ``CarbonCallbackHandler`` into the ``config["callbacks"]`` kwarg
    and returns a ``(result, CarbonReceipt)`` namedtuple-like tuple.

    Can be used with or without arguments::

        @track_carbon
        def call_chain(query, config=None): ...

        @track_carbon(region="us-west-2")
        def call_chain(query, config=None): ...

        result, receipt = call_chain("hello")
    """

    def decorator(func: Any) -> Any:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> tuple[Any, CarbonReceipt]:
            handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)
            cfg: dict[str, Any] = dict(kwargs.get("config") or {})
            cfg["callbacks"] = list(cfg.get("callbacks") or []) + [handler]
            kwargs["config"] = cfg
            result = func(*args, **kwargs)
            return result, handler.receipt

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> tuple[Any, CarbonReceipt]:
            handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)
            cfg: dict[str, Any] = dict(kwargs.get("config") or {})
            cfg["callbacks"] = list(cfg.get("callbacks") or []) + [handler]
            kwargs["config"] = cfg
            result = await func(*args, **kwargs)
            return result, handler.receipt

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper

    if fn is not None:
        return decorator(fn)
    return decorator
