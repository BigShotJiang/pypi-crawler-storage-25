"""LangGraph integration helpers.

LangGraph uses the LangChain callback system internally, so
``CarbonCallbackHandler`` works out of the box. This module provides
convenience wrappers for common LangGraph patterns.
"""

from __future__ import annotations

try:
    from langgraph.graph.state import CompiledStateGraph  # noqa: F401
    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _LANGGRAPH_AVAILABLE = False

from agent_carbon.handler import CarbonCallbackHandler
from agent_carbon.receipt import CarbonReceipt


def carbon_config(handler: CarbonCallbackHandler) -> dict:
    """Return a LangGraph-compatible ``RunnableConfig`` dict with the handler registered.

    Usage::

        handler = CarbonCallbackHandler(region="us-west-2")
        result = graph.invoke(state, config=carbon_config(handler))
        print(handler.receipt)
    """
    return {"callbacks": [handler]}


def invoke_with_carbon(
    graph: "CompiledStateGraph",
    state: dict,
    *,
    region: str | None = None,
    frontier_model: str = "claude-opus-4-6",
    **kwargs,
) -> tuple[dict, CarbonReceipt]:
    """Invoke a compiled LangGraph graph and return ``(output, CarbonReceipt)``.

    Args:
        graph: A ``CompiledStateGraph`` (result of ``builder.compile()``).
        state: Initial graph state dict.
        region: Cloud region for grid intensity lookup.
        frontier_model: Model slug for savings comparison baseline.
        **kwargs: Additional kwargs forwarded to ``graph.invoke()``.

    Returns:
        ``(graph_output, receipt)`` tuple.
    """
    if not _LANGGRAPH_AVAILABLE:
        raise ImportError(
            "langgraph is not installed. Run: pip install agent-carbon[langgraph]"
        )

    handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)
    cfg = dict(kwargs.pop("config", {}) or {})
    cfg["callbacks"] = list(cfg.get("callbacks") or []) + [handler]
    result = graph.invoke(state, config=cfg, **kwargs)
    return result, handler.receipt


async def ainvoke_with_carbon(
    graph: "CompiledStateGraph",
    state: dict,
    *,
    region: str | None = None,
    frontier_model: str = "claude-opus-4-6",
    **kwargs,
) -> tuple[dict, CarbonReceipt]:
    """Async version of :func:`invoke_with_carbon`."""
    if not _LANGGRAPH_AVAILABLE:
        raise ImportError(
            "langgraph is not installed. Run: pip install agent-carbon[langgraph]"
        )

    handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)
    cfg = dict(kwargs.pop("config", {}) or {})
    cfg["callbacks"] = list(cfg.get("callbacks") or []) + [handler]
    result = await graph.ainvoke(state, config=cfg, **kwargs)
    return result, handler.receipt
