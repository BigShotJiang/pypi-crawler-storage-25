"""AutoGen integration helpers.

AutoGen 0.4 (agentchat) uses model clients whose ``create`` method handles
LLM calls. This module provides a ``CarbonModelClient`` wrapper that
intercepts ``create`` calls to compute emissions without modifying agent code.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

try:
    from autogen_core.models import ChatCompletionClient  # noqa: F401
    _AUTOGEN_AVAILABLE = True
except ImportError:
    _AUTOGEN_AVAILABLE = False

from agent_carbon.factors import resolve_factors
from agent_carbon.handler import CarbonCallbackHandler
from agent_carbon.receipt import CallRecord, CarbonReceipt
from agent_carbon.regions import get_grid_intensity
from agent_carbon.factors import GLOBAL_AVG_GRID_GCO2_PER_KWH


class CarbonModelClient:
    """Wraps an AutoGen ``ChatCompletionClient`` to track carbon emissions.

    Args:
        client: Any AutoGen-compatible model client.
        region: Cloud region for grid intensity lookup.
        frontier_model: Model slug for savings comparison baseline.

    Usage::

        from autogen_ext.models.openai import OpenAIChatCompletionClient
        from agent_carbon.integrations.autogen import CarbonModelClient

        base_client = OpenAIChatCompletionClient(model="gpt-4o-mini")
        client = CarbonModelClient(base_client, region="us-west-2")

        # pass ``client`` wherever AutoGen expects a model client
        agent = AssistantAgent("assistant", model_client=client)
        ...
        print(client.handler.receipt)
    """

    def __init__(
        self,
        client: Any,
        *,
        region: str | None = None,
        frontier_model: str = "claude-opus-4-6",
    ) -> None:
        if not _AUTOGEN_AVAILABLE:
            raise ImportError(
                "autogen-agentchat is not installed. "
                "Run: pip install agent-carbon[autogen]"
            )
        self._client = client
        self.handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)

    async def create(self, messages: list, **kwargs: Any) -> Any:
        """Delegate to the wrapped client and record emissions."""
        started = datetime.now(timezone.utc)
        response = await self._client.create(messages, **kwargs)

        usage = getattr(response, "usage", None)
        model_name = getattr(response, "model", None) or getattr(
            self._client, "model", "unknown"
        )

        if usage is not None:
            input_tokens = getattr(usage, "prompt_tokens", None) or getattr(
                usage, "input_tokens", 0
            )
            output_tokens = getattr(usage, "completion_tokens", None) or getattr(
                usage, "output_tokens", 0
            )
        else:
            input_tokens = output_tokens = 0

        factors = resolve_factors(model_name or "unknown")
        grid_intensity = get_grid_intensity(self.handler.region)

        if factors and (input_tokens or output_tokens):
            wh = (
                input_tokens / 1_000_000 * factors.input_wh_per_1m
                + output_tokens / 1_000_000 * factors.output_wh_per_1m
            )
            gco2e = wh * grid_intensity / 1000
            estimated = factors.estimated
            provider = factors.provider
        else:
            wh = gco2e = 0.0
            estimated = True
            provider = "unknown"

        record = CallRecord(
            call_id=str(uuid4()),
            run_id=str(uuid4()),
            model=model_name or "unknown",
            provider=provider,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            gco2e=round(gco2e, 6),
            wh=round(wh, 6),
            region=self.handler.region,
            grid_multiplier=round(grid_intensity / GLOBAL_AVG_GRID_GCO2_PER_KWH, 4),
            estimated=estimated,
            timestamp=started,
        )
        with self.handler._lock:
            self.handler._records.append(record)

        return response

    @property
    def receipt(self) -> CarbonReceipt:
        """Current accumulated receipt."""
        return self.handler.receipt

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)
