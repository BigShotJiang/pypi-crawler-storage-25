# Integration helpers for LangGraph, CrewAI, and AutoGen.
# Each module is guarded by a try/except import so none are required at install time.
