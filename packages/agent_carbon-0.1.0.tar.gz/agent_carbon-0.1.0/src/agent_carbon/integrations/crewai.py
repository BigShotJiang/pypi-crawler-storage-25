"""CrewAI integration helpers.

CrewAI wraps LangChain LLMs internally, so the simplest way to hook in
``CarbonCallbackHandler`` is to inject it into the underlying LLM's
callback list before the crew runs.
"""

from __future__ import annotations

try:
    from crewai import Crew  # noqa: F401
    _CREWAI_AVAILABLE = True
except ImportError:
    _CREWAI_AVAILABLE = False

from agent_carbon.handler import CarbonCallbackHandler
from agent_carbon.receipt import CarbonReceipt


def patch_crew_llm(crew: "Crew", handler: CarbonCallbackHandler) -> None:
    """Inject *handler* into every agent LLM in the crew.

    Call this after constructing the ``Crew`` and before ``crew.kickoff()``.

    Args:
        crew: A ``crewai.Crew`` instance.
        handler: The ``CarbonCallbackHandler`` to attach.
    """
    if not _CREWAI_AVAILABLE:
        raise ImportError(
            "crewai is not installed. Run: pip install agent-carbon[crewai]"
        )

    for agent in crew.agents:
        llm = getattr(agent, "llm", None)
        if llm is None:
            continue
        existing = list(getattr(llm, "callbacks", None) or [])
        if handler not in existing:
            llm.callbacks = existing + [handler]


def kickoff_with_carbon(
    crew: "Crew",
    *,
    region: str | None = None,
    frontier_model: str = "claude-opus-4-6",
    **kwargs,
) -> tuple[str, CarbonReceipt]:
    """Kick off a crew run and return ``(result, CarbonReceipt)``.

    Args:
        crew: A ``crewai.Crew`` instance.
        region: Cloud region for grid intensity lookup.
        frontier_model: Model slug for savings comparison baseline.
        **kwargs: Forwarded to ``crew.kickoff()``.

    Returns:
        ``(crew_output, receipt)`` tuple.
    """
    if not _CREWAI_AVAILABLE:
        raise ImportError(
            "crewai is not installed. Run: pip install agent-carbon[crewai]"
        )

    handler = CarbonCallbackHandler(region=region, frontier_model=frontier_model)
    patch_crew_llm(crew, handler)
    result = crew.kickoff(**kwargs)
    return result, handler.receipt
