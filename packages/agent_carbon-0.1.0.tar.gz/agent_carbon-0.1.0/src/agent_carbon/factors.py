"""Emissions factors for LLM inference energy and CO₂e estimation.

All values are estimated for commercial-scale deployments (high-batch-size,
tensor-parallel serving on H100/A100 clusters). See factors_meta.json for
per-model source citations and methodology.
"""

from __future__ import annotations

from dataclasses import dataclass

# IEA World Energy Outlook 2022 — global average electricity generation intensity.
GLOBAL_AVG_GRID_GCO2_PER_KWH: float = 494.0


@dataclass(frozen=True)
class ModelFactors:
    """Energy and emissions factors for one model."""

    provider: str
    input_wh_per_1m: float    # Wh per 1 million input (prompt) tokens
    output_wh_per_1m: float   # Wh per 1 million output (completion) tokens
    estimated: bool            # True for all v1 entries; no precise published data exists
    source: str                # one-line citation


# ---------------------------------------------------------------------------
# Factor table — keyed by canonical model slug.
# Sources are cited inline; see factors_meta.json for the machine-readable copy.
# ---------------------------------------------------------------------------

FACTORS: dict[str, ModelFactors] = {
    # -- OpenAI ---------------------------------------------------------------
    # GPT-5 family: no published inference energy data.
    # Extrapolated from frontier-model GPU cluster assumptions (large MoE
    # architecture on H100 pods) and Patterson et al. 2021 scaling estimates.
    "gpt-5": ModelFactors(
        provider="openai",
        input_wh_per_1m=180.0,
        output_wh_per_1m=1200.0,
        estimated=True,
        source="Estimated; no published data. Extrapolated from frontier MoE GPU assumptions.",
    ),
    "gpt-5-mini": ModelFactors(
        provider="openai",
        input_wh_per_1m=15.0,
        output_wh_per_1m=100.0,
        estimated=True,
        source="Estimated; small model class, scaled from Llama-3.3-8B H100 benchmark baseline.",
    ),
    "gpt-5-nano": ModelFactors(
        provider="openai",
        input_wh_per_1m=10.0,
        output_wh_per_1m=70.0,
        estimated=True,
        source="Estimated; sub-8B class model, scaled from Llama-3.3-8B H100 benchmark baseline.",
    ),
    # -- Anthropic -------------------------------------------------------------
    # Anthropic has not published per-model inference energy data.
    # Scaled from frontier-model assumptions and EcoLogITs framework
    # (Lannelongue et al. 2023 — https://doi.org/10.1093/gigascience/giac031).
    "claude-opus-4-6": ModelFactors(
        provider="anthropic",
        input_wh_per_1m=150.0,
        output_wh_per_1m=1000.0,
        estimated=True,
        source="Estimated; Anthropic publishes no per-model energy data. EcoLogITs framework, Lannelongue et al. 2023.",
    ),
    "claude-sonnet-4-6": ModelFactors(
        provider="anthropic",
        input_wh_per_1m=37.0,
        output_wh_per_1m=250.0,
        estimated=True,
        source="Estimated; mid-tier model, scaled ~4x below Opus using pricing ratio as efficiency proxy.",
    ),
    "claude-haiku-4-5": ModelFactors(
        provider="anthropic",
        input_wh_per_1m=12.0,
        output_wh_per_1m=80.0,
        estimated=True,
        source="Estimated; small/fast model, scaled from 8B-class H100 vLLM throughput benchmark (~10k tok/s at 700W).",
    ),
    # -- Google ----------------------------------------------------------------
    # Google DeepMind has not published per-model inference energy data.
    # Scaled from MoE architecture assumptions and Hugging Face AI Energy Score
    # methodology (https://huggingface.co/spaces/optimum/llm-perf-leaderboard).
    "gemini-2.5-pro": ModelFactors(
        provider="google",
        input_wh_per_1m=90.0,
        output_wh_per_1m=600.0,
        estimated=True,
        source="Estimated; no published data. MoE architecture on TPU v5p, HF AI Energy Score methodology.",
    ),
    "gemini-2.5-flash": ModelFactors(
        provider="google",
        input_wh_per_1m=14.0,
        output_wh_per_1m=90.0,
        estimated=True,
        source="Estimated; efficient smaller Gemini model on TPU v5, comparable to 8-13B dense class.",
    ),
    # -- Meta ------------------------------------------------------------------
    # Llama-3.3 models: estimated from vLLM performance benchmarks for Llama-3
    # on H100 GPUs (batch throughput) and Luccioni et al. 'Power Hungry
    # Processing' (2023, https://doi.org/10.18653/v1/2023.emnlp-main.980).
    # Input cost estimated at ~15% of output (prefill vs. decode ratio).
    "llama-3.3-70b": ModelFactors(
        provider="meta",
        input_wh_per_1m=30.0,
        output_wh_per_1m=200.0,
        estimated=True,
        source="Estimated; 4×H100 (2800W) at ~1500 output tok/s batch. vLLM benchmarks 2024; Luccioni et al. 2023.",
    ),
    "llama-3.3-8b": ModelFactors(
        provider="meta",
        input_wh_per_1m=10.0,
        output_wh_per_1m=70.0,
        estimated=True,
        source="Estimated; 1×H100 (700W) at ~10000 output tok/s batch. vLLM benchmarks 2024; Luccioni et al. 2023.",
    ),
    # -- Mistral ---------------------------------------------------------------
    # Mistral AI has not published inference energy data.
    # Scaled from Llama-3.3 baselines at comparable parameter classes.
    "mistral-large": ModelFactors(
        provider="mistral",
        input_wh_per_1m=27.0,
        output_wh_per_1m=180.0,
        estimated=True,
        source="Estimated; ~70B+ class, scaled from Llama-3.3-70B with ~10% efficiency premium.",
    ),
    "mistral-small": ModelFactors(
        provider="mistral",
        input_wh_per_1m=12.0,
        output_wh_per_1m=80.0,
        estimated=True,
        source="Estimated; 7-8B class, scaled from Llama-3.3-8B baseline.",
    ),
}

# Substring keywords used for fuzzy model-name resolution.
# Ordered from most-specific to least-specific to avoid false matches.
_KEYWORD_MAP: list[tuple[str, str]] = [
    ("gpt-5-nano", "gpt-5-nano"),
    ("gpt-5-mini", "gpt-5-mini"),
    ("gpt-5", "gpt-5"),
    ("gemini-2.5-pro", "gemini-2.5-pro"),
    ("gemini-2.5-flash", "gemini-2.5-flash"),
    ("llama-3.3-70b", "llama-3.3-70b"),
    ("llama-3.3-8b", "llama-3.3-8b"),
    ("claude-opus", "claude-opus-4-6"),
    ("claude-sonnet", "claude-sonnet-4-6"),
    ("claude-haiku", "claude-haiku-4-5"),
    ("mistral-large", "mistral-large"),
    ("mistral-small", "mistral-small"),
    ("opus", "claude-opus-4-6"),
    ("sonnet", "claude-sonnet-4-6"),
    ("haiku", "claude-haiku-4-5"),
]


def resolve_factors(model_name: str) -> ModelFactors | None:
    """Return factors for a model slug, or None if the model is not in the table.

    Resolution order:
    1. Exact match (case-insensitive)
    2. Prefix match (e.g. "gpt-5-mini-2025" → "gpt-5-mini")
    3. Substring keyword match (e.g. "claude-3-opus-20240229" → "claude-opus-4-6")
    """
    if not model_name:
        return None

    lower = model_name.lower()

    if lower in FACTORS:
        return FACTORS[lower]

    # Sort longest-first so "gpt-5-mini" wins over "gpt-5" for "gpt-5-mini-preview".
    for key in sorted(FACTORS, key=len, reverse=True):
        if lower.startswith(key) or key.startswith(lower):
            return FACTORS[key]

    for keyword, slug in _KEYWORD_MAP:
        if keyword in lower:
            return FACTORS[slug]

    return None
