"""CarbonReceipt and CallRecord — the output schema for agent-carbon."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class CallRecord(BaseModel):
    """Emissions record for a single LLM call."""

    call_id: str
    run_id: str
    model: str
    provider: str
    input_tokens: int
    output_tokens: int
    gco2e: float = Field(description="Grams of CO₂ equivalent for this call")
    wh: float = Field(description="Watt-hours consumed for this call")
    cost_usd: float | None = None
    region: str | None = None
    grid_multiplier: float = Field(
        default=1.0,
        description="Region intensity / global average; <1 means cleaner grid",
    )
    estimated: bool = True
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


_METHODOLOGY = (
    "Emissions estimated from token counts × model-specific energy factors "
    "(Wh/1M tokens) × regional grid intensity (gCO₂e/kWh). "
    "All values are approximate; see factors_meta.json for sources and caveats."
)

_FRONTIER_NOTE = (
    "savings_vs_frontier_gco2e is the difference between what the frontier "
    "model would have emitted for the same token workload and what was actually "
    "emitted. Zero means the model used was at least as heavy as the frontier."
)


class CarbonReceipt(BaseModel):
    """Aggregate carbon emissions receipt for an agent run."""

    total_tokens: int
    total_input_tokens: int
    total_output_tokens: int
    total_gco2e: float = Field(description="Total grams CO₂e for the run")
    total_wh: float = Field(description="Total watt-hours for the run")
    total_cost_usd: float | None = None

    savings_vs_frontier_gco2e: float = Field(
        description="Emissions saved vs. running the same workload on the frontier model"
    )
    frontier_model: str

    region: str | None = None
    estimate: bool = True
    methodology: str = _METHODOLOGY

    calls: list[CallRecord] = Field(default_factory=list)

    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_seconds: float | None = None

    @classmethod
    def from_records(
        cls,
        calls: list[CallRecord],
        *,
        region: str | None = None,
        frontier_model: str = "claude-opus-4-6",
        started_at: datetime | None = None,
    ) -> "CarbonReceipt":
        """Build a receipt by aggregating a list of CallRecords."""
        from agent_carbon.factors import resolve_factors, GLOBAL_AVG_GRID_GCO2_PER_KWH
        from agent_carbon.regions import get_grid_intensity

        total_input = sum(c.input_tokens for c in calls)
        total_output = sum(c.output_tokens for c in calls)
        total_wh = sum(c.wh for c in calls)
        total_gco2e = sum(c.gco2e for c in calls)

        frontier_factors = resolve_factors(frontier_model)
        grid_intensity = get_grid_intensity(region)
        if frontier_factors and calls:
            frontier_gco2e = sum(
                c.input_tokens / 1_000_000 * frontier_factors.input_wh_per_1m
                * grid_intensity / 1000
                + c.output_tokens / 1_000_000 * frontier_factors.output_wh_per_1m
                * grid_intensity / 1000
                for c in calls
            )
            savings = max(0.0, frontier_gco2e - total_gco2e)
        else:
            savings = 0.0

        finished_at = datetime.now(timezone.utc) if calls else None
        duration = (
            (finished_at - started_at).total_seconds()
            if started_at and finished_at
            else None
        )

        return cls(
            total_tokens=total_input + total_output,
            total_input_tokens=total_input,
            total_output_tokens=total_output,
            total_gco2e=round(total_gco2e, 6),
            total_wh=round(total_wh, 6),
            total_cost_usd=None,
            savings_vs_frontier_gco2e=round(savings, 6),
            frontier_model=frontier_model,
            region=region,
            estimate=True,
            methodology=_METHODOLOGY,
            calls=calls,
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=round(duration, 2) if duration is not None else None,
        )

    # ------------------------------------------------------------------
    # Output helpers
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return self.model_dump(mode="json")

    def to_markdown(self) -> str:
        """Return a human-readable Markdown summary."""
        region_label = self.region or "global average"
        lines = [
            "## Carbon Receipt",
            "",
            f"| Metric | Value |",
            f"|--------|-------|",
            f"| Total tokens | {self.total_tokens:,} "
            f"({self.total_input_tokens:,} in / {self.total_output_tokens:,} out) |",
            f"| Total energy | {self.total_wh:.4f} Wh |",
            f"| Total CO₂e | {self.total_gco2e:.4f} gCO₂e |",
            f"| Savings vs `{self.frontier_model}` | "
            f"{self.savings_vs_frontier_gco2e:.4f} gCO₂e |",
            f"| Region | {region_label} |",
            f"| LLM calls | {len(self.calls)} |",
            f"| Estimate | {self.estimate} |",
        ]
        if self.duration_seconds is not None:
            lines.append(f"| Duration | {self.duration_seconds:.2f}s |")
        lines += [
            "",
            f"> *{self.methodology}*",
            "",
        ]
        if self.calls:
            lines += [
                "### Per-call Breakdown",
                "",
                "| # | Model | In tok | Out tok | gCO₂e | Wh |",
                "|---|-------|--------|---------|-------|----|",
            ]
            for i, call in enumerate(self.calls, 1):
                lines.append(
                    f"| {i} | `{call.model}` | {call.input_tokens:,} | "
                    f"{call.output_tokens:,} | {call.gco2e:.4f} | {call.wh:.4f} |"
                )
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"CarbonReceipt(total_tokens={self.total_tokens}, "
            f"total_gco2e={self.total_gco2e:.4f}, "
            f"total_wh={self.total_wh:.4f}, "
            f"savings_vs_frontier_gco2e={self.savings_vs_frontier_gco2e:.4f}, "
            f"calls={len(self.calls)})"
        )
