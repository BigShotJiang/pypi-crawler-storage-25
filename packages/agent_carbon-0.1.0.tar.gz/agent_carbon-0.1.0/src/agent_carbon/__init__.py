"""agent-carbon: carbon emissions tracking for LLM agent frameworks."""

from agent_carbon.handler import CarbonCallbackHandler, track_carbon
from agent_carbon.receipt import CallRecord, CarbonReceipt

__all__ = [
    "CarbonCallbackHandler",
    "CarbonReceipt",
    "CallRecord",
    "track_carbon",
]

__version__ = "0.1.0"
