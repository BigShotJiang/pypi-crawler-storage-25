"""CrewAI example — two-agent research crew with carbon tracking.

Requirements:
    pip install agent-carbon[crewai]
    export OPENAI_API_KEY=sk-...   (CrewAI defaults to OpenAI)
"""

from crewai import Agent, Crew, Task

from agent_carbon import CarbonCallbackHandler
from agent_carbon.integrations.crewai import kickoff_with_carbon

researcher = Agent(
    role="Research Analyst",
    goal="Produce concise, accurate research summaries",
    backstory="You are an expert at distilling complex topics into clear summaries.",
    verbose=False,
    allow_delegation=False,
)

writer = Agent(
    role="Technical Writer",
    goal="Turn research into polished one-paragraph explanations",
    backstory="You specialize in clear technical writing for a general audience.",
    verbose=False,
    allow_delegation=False,
)

research_task = Task(
    description="What are the main environmental benefits of solar energy?",
    expected_output="A bullet-point list of 3 key environmental benefits.",
    agent=researcher,
)

writing_task = Task(
    description="Turn the research into a single polished paragraph.",
    expected_output="One paragraph, 3-5 sentences, suitable for a blog post.",
    agent=writer,
)

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    verbose=False,
)

result, receipt = kickoff_with_carbon(crew, region="eu-west-1")

print("Crew output:")
print(result)
print()
print(receipt.to_markdown())
