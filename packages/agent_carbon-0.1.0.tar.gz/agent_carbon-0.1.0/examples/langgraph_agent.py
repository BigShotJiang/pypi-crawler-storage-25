"""LangGraph example — multi-step agent making 3 LLM calls.

Requirements:
    pip install agent-carbon[langgraph] langchain-openai
    export OPENAI_API_KEY=sk-...
"""

import os
from typing import TypedDict

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, StateGraph

from agent_carbon import CarbonCallbackHandler

MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

handler = CarbonCallbackHandler(region="us-west-2")
llm = ChatOpenAI(model=MODEL)


class AgentState(TypedDict):
    messages: list[BaseMessage]


def research(state: AgentState) -> AgentState:
    response = llm.invoke(state["messages"], config={"callbacks": [handler]})
    return {"messages": state["messages"] + [response]}


def critique(state: AgentState) -> AgentState:
    messages = state["messages"] + [
        HumanMessage(content="What are the weaknesses in that answer?")
    ]
    response = llm.invoke(messages, config={"callbacks": [handler]})
    return {"messages": state["messages"] + [response]}


def summarize(state: AgentState) -> AgentState:
    messages = state["messages"] + [
        HumanMessage(content="Summarize the full discussion in two sentences.")
    ]
    response = llm.invoke(messages, config={"callbacks": [handler]})
    return {"messages": state["messages"] + [response]}


builder = StateGraph(AgentState)
builder.add_node("research", research)
builder.add_node("critique", critique)
builder.add_node("summarize", summarize)
builder.add_edge(START, "research")
builder.add_edge("research", "critique")
builder.add_edge("critique", "summarize")
builder.add_edge("summarize", END)

graph = builder.compile()

final_state = graph.invoke(
    {"messages": [HumanMessage(content="What is quantum computing?")]}
)

print("Final summary:")
print(final_state["messages"][-1].content)
print()
print(handler.receipt.to_markdown())
