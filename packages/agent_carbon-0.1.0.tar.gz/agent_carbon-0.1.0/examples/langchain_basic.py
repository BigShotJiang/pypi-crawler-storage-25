"""Basic LangChain example — one chain call with carbon tracking.

Requirements:
    pip install agent-carbon langchain-openai
    export OPENAI_API_KEY=sk-...
"""

import os

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from agent_carbon import CarbonCallbackHandler

MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

handler = CarbonCallbackHandler(region="us-east-1")

llm = ChatOpenAI(model=MODEL)
prompt = ChatPromptTemplate.from_messages([("human", "{input}")])
chain = prompt | llm

result = chain.invoke(
    {"input": "Name three renewable energy sources in one sentence."},
    config={"callbacks": [handler]},
)

print("Response:", result.content)
print()
print(handler.receipt.to_markdown())
