"""Tests for CarbonReceipt."""

from __future__ import annotations

import json
from datetime import datetime

import pytest

from agent_carbon.receipt import CallRecord, CarbonReceipt


def _make_record(
    model: str = "claude-sonnet-4-6",
    input_tokens: int = 100,
    output_tokens: int = 50,
    gco2e: float = 1.0,
    wh: float = 2.0,
) -> CallRecord:
    return CallRecord(
        call_id="test-call-1",
        run_id="test-run-1",
        model=model,
        provider="anthropic",
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        gco2e=gco2e,
        wh=wh,
    )


class TestCarbonReceiptFromRecords:
    def test_empty_records(self):
        receipt = CarbonReceipt.from_records([])
        assert receipt.total_tokens == 0
        assert receipt.total_gco2e == 0.0
        assert receipt.savings_vs_frontier_gco2e == 0.0
        assert receipt.calls == []

    def test_totals_aggregated(self):
        records = [
            _make_record(input_tokens=100, output_tokens=50, gco2e=1.0, wh=2.0),
            _make_record(input_tokens=200, output_tokens=100, gco2e=2.0, wh=4.0),
        ]
        receipt = CarbonReceipt.from_records(records)
        assert receipt.total_input_tokens == 300
        assert receipt.total_output_tokens == 150
        assert receipt.total_tokens == 450
        assert receipt.total_gco2e == pytest.approx(3.0, rel=1e-4)
        assert receipt.total_wh == pytest.approx(6.0, rel=1e-4)

    def test_estimate_always_true(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        assert receipt.estimate is True

    def test_frontier_model_preserved(self):
        receipt = CarbonReceipt.from_records([], frontier_model="gpt-5")
        assert receipt.frontier_model == "gpt-5"

    def test_region_preserved(self):
        receipt = CarbonReceipt.from_records([], region="eu-north-1")
        assert receipt.region == "eu-north-1"

    def test_savings_computed_from_token_counts(self):
        from agent_carbon.factors import resolve_factors
        from agent_carbon.regions import get_grid_intensity

        frontier = "claude-opus-4-6"
        f = resolve_factors(frontier)
        grid = get_grid_intensity(None)

        records = [_make_record(input_tokens=1000, output_tokens=500)]
        receipt = CarbonReceipt.from_records(records, frontier_model=frontier)

        expected_frontier_gco2e = (
            1000 / 1_000_000 * f.input_wh_per_1m * grid / 1000
            + 500 / 1_000_000 * f.output_wh_per_1m * grid / 1000
        )
        expected_savings = max(0.0, expected_frontier_gco2e - receipt.total_gco2e)
        assert receipt.savings_vs_frontier_gco2e == pytest.approx(expected_savings, rel=1e-4)

    def test_started_at_preserved(self):
        now = datetime(2026, 1, 1, 12, 0, 0)
        receipt = CarbonReceipt.from_records([], started_at=now)
        assert receipt.started_at == now


class TestToDict:
    def test_returns_dict(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        d = receipt.to_dict()
        assert isinstance(d, dict)

    def test_json_serializable(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        serialized = json.dumps(receipt.to_dict())
        assert isinstance(serialized, str)

    def test_contains_key_fields(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        d = receipt.to_dict()
        assert "total_tokens" in d
        assert "total_gco2e" in d
        assert "total_wh" in d
        assert "savings_vs_frontier_gco2e" in d
        assert "calls" in d
        assert "estimate" in d
        assert "methodology" in d


class TestToMarkdown:
    def test_returns_string(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        md = receipt.to_markdown()
        assert isinstance(md, str)

    def test_contains_header(self):
        md = CarbonReceipt.from_records([]).to_markdown()
        assert "Carbon Receipt" in md

    def test_contains_per_call_table(self):
        receipt = CarbonReceipt.from_records([_make_record(model="claude-haiku-4-5")])
        md = receipt.to_markdown()
        assert "claude-haiku-4-5" in md
        assert "Per-call Breakdown" in md

    def test_no_per_call_table_for_empty(self):
        md = CarbonReceipt.from_records([]).to_markdown()
        assert "Per-call Breakdown" not in md

    def test_methodology_disclaimer_present(self):
        md = CarbonReceipt.from_records([]).to_markdown()
        assert "estimated" in md.lower() or "approximate" in md.lower()


class TestRepr:
    def test_repr_readable(self):
        receipt = CarbonReceipt.from_records([_make_record()])
        r = repr(receipt)
        assert "CarbonReceipt" in r
        assert "total_tokens" in r
        assert "total_gco2e" in r
