"""Shared fixtures for agent-carbon tests."""

from __future__ import annotations

from unittest.mock import MagicMock
from uuid import uuid4

import pytest
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, LLMResult


def make_llm_result(
    model: str = "claude-sonnet-4-6",
    input_tokens: int = 100,
    output_tokens: int = 50,
    provider: str = "anthropic",
) -> LLMResult:
    """Build a mock LLMResult with realistic token usage dicts."""
    gen = ChatGeneration(message=AIMessage(content="Hello, world!"))
    result = LLMResult(generations=[[gen]])

    if provider == "anthropic":
        result.llm_output = {
            "usage": {"input_tokens": input_tokens, "output_tokens": output_tokens},
            "model": model,
        }
    elif provider == "openai":
        result.llm_output = {
            "token_usage": {
                "prompt_tokens": input_tokens,
                "completion_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            },
            "model_name": model,
        }
    elif provider == "google":
        result.llm_output = {
            "usage": {
                "prompt_token_count": input_tokens,
                "candidates_token_count": output_tokens,
            },
            "model": model,
        }
    else:
        result.llm_output = {}

    return result


def make_serialized(model_name: str = "claude-sonnet-4-6") -> dict:
    """Build a mock serialized dict as LangChain passes to on_chat_model_start."""
    return {
        "name": "ChatAnthropic",
        "kwargs": {"model_name": model_name},
    }


@pytest.fixture
def run_id():
    return uuid4()


@pytest.fixture
def handler():
    from agent_carbon import CarbonCallbackHandler
    return CarbonCallbackHandler()


@pytest.fixture
def handler_us_west():
    from agent_carbon import CarbonCallbackHandler
    return CarbonCallbackHandler(region="us-west-2")


@pytest.fixture
def handler_us_east():
    from agent_carbon import CarbonCallbackHandler
    return CarbonCallbackHandler(region="us-east-1")
