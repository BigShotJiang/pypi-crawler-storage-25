"""Tests for integration helpers (langgraph, crewai, autogen).

Integration modules guard their imports with try/except, so these tests
cover both the import-guard paths and the framework-agnostic helpers that
work without the optional dependencies.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from agent_carbon import CarbonCallbackHandler, CarbonReceipt
from agent_carbon.integrations import langgraph as lg_mod
from agent_carbon.integrations import crewai as crewai_mod
from agent_carbon.integrations import autogen as autogen_mod


# ---------------------------------------------------------------------------
# LangGraph
# ---------------------------------------------------------------------------

class TestLangGraphCarbonConfig:
    def test_carbon_config_returns_callbacks_dict(self):
        handler = CarbonCallbackHandler()
        cfg = lg_mod.carbon_config(handler)
        assert cfg == {"callbacks": [handler]}

    def test_invoke_with_carbon_no_langgraph(self):
        with patch.object(lg_mod, "_LANGGRAPH_AVAILABLE", False):
            with pytest.raises(ImportError, match="langgraph"):
                lg_mod.invoke_with_carbon(MagicMock(), {})

    def test_ainvoke_with_carbon_no_langgraph(self):
        with patch.object(lg_mod, "_LANGGRAPH_AVAILABLE", False):
            with pytest.raises(ImportError, match="langgraph"):
                import asyncio
                asyncio.run(lg_mod.ainvoke_with_carbon(MagicMock(), {}))

    def test_invoke_with_carbon_injects_handler(self):
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {"answer": "42"}

        with patch.object(lg_mod, "_LANGGRAPH_AVAILABLE", True):
            result, receipt = lg_mod.invoke_with_carbon(mock_graph, {"q": "hi"})

        mock_graph.invoke.assert_called_once()
        call_kwargs = mock_graph.invoke.call_args
        config = call_kwargs[1]["config"] if "config" in call_kwargs[1] else call_kwargs[0][1]
        assert "callbacks" in config
        assert len(config["callbacks"]) == 1
        assert isinstance(config["callbacks"][0], CarbonCallbackHandler)
        assert result == {"answer": "42"}
        assert isinstance(receipt, CarbonReceipt)

    def test_ainvoke_with_carbon_injects_handler(self):
        import asyncio

        mock_graph = MagicMock()
        mock_graph.ainvoke = AsyncMock(return_value={"answer": "async"})

        with patch.object(lg_mod, "_LANGGRAPH_AVAILABLE", True):
            result, receipt = asyncio.run(
                lg_mod.ainvoke_with_carbon(mock_graph, {"q": "hi"})
            )

        mock_graph.ainvoke.assert_called_once()
        assert result == {"answer": "async"}
        assert isinstance(receipt, CarbonReceipt)

    def test_invoke_preserves_existing_config(self):
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {}
        existing_cb = MagicMock()

        with patch.object(lg_mod, "_LANGGRAPH_AVAILABLE", True):
            lg_mod.invoke_with_carbon(mock_graph, {}, config={"callbacks": [existing_cb], "tags": ["t"]})

        call_kwargs = mock_graph.invoke.call_args
        config = call_kwargs[1]["config"]
        assert existing_cb in config["callbacks"]
        assert config["tags"] == ["t"]


# ---------------------------------------------------------------------------
# CrewAI
# ---------------------------------------------------------------------------

class TestCrewAI:
    def test_patch_crew_llm_no_crewai(self):
        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", False):
            with pytest.raises(ImportError, match="crewai"):
                crewai_mod.patch_crew_llm(MagicMock(), CarbonCallbackHandler())

    def test_kickoff_with_carbon_no_crewai(self):
        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", False):
            with pytest.raises(ImportError, match="crewai"):
                crewai_mod.kickoff_with_carbon(MagicMock())

    def test_patch_crew_llm_injects_callbacks(self):
        mock_llm = MagicMock()
        mock_llm.callbacks = []
        mock_agent = MagicMock()
        mock_agent.llm = mock_llm
        mock_crew = MagicMock()
        mock_crew.agents = [mock_agent]

        handler = CarbonCallbackHandler()

        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", True):
            crewai_mod.patch_crew_llm(mock_crew, handler)

        assert handler in mock_llm.callbacks

    def test_patch_crew_llm_idempotent(self):
        """Calling patch twice should not add the handler twice."""
        mock_llm = MagicMock()
        mock_llm.callbacks = []
        mock_agent = MagicMock()
        mock_agent.llm = mock_llm
        mock_crew = MagicMock()
        mock_crew.agents = [mock_agent]
        handler = CarbonCallbackHandler()

        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", True):
            crewai_mod.patch_crew_llm(mock_crew, handler)
            crewai_mod.patch_crew_llm(mock_crew, handler)

        assert mock_llm.callbacks.count(handler) == 1

    def test_patch_crew_llm_skips_agents_without_llm(self):
        mock_agent = MagicMock(spec=[])  # no llm attribute
        mock_crew = MagicMock()
        mock_crew.agents = [mock_agent]
        handler = CarbonCallbackHandler()

        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", True):
            crewai_mod.patch_crew_llm(mock_crew, handler)  # should not raise

    def test_kickoff_with_carbon_returns_tuple(self):
        mock_llm = MagicMock()
        mock_llm.callbacks = []
        mock_agent = MagicMock()
        mock_agent.llm = mock_llm
        mock_crew = MagicMock()
        mock_crew.agents = [mock_agent]
        mock_crew.kickoff.return_value = "done"

        with patch.object(crewai_mod, "_CREWAI_AVAILABLE", True):
            result, receipt = crewai_mod.kickoff_with_carbon(mock_crew)

        assert result == "done"
        assert isinstance(receipt, CarbonReceipt)


# ---------------------------------------------------------------------------
# AutoGen
# ---------------------------------------------------------------------------

class TestAutoGen:
    def test_carbon_model_client_no_autogen(self):
        with patch.object(autogen_mod, "_AUTOGEN_AVAILABLE", False):
            with pytest.raises(ImportError, match="autogen"):
                autogen_mod.CarbonModelClient(MagicMock())

    def test_carbon_model_client_create(self):
        import asyncio

        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 100
        mock_usage.completion_tokens = 50

        mock_response = MagicMock()
        mock_response.usage = mock_usage
        mock_response.model = "claude-sonnet-4-6"

        mock_client = MagicMock()
        mock_client.create = AsyncMock(return_value=mock_response)

        with patch.object(autogen_mod, "_AUTOGEN_AVAILABLE", True):
            client = autogen_mod.CarbonModelClient(mock_client, region="us-west-2")
            response = asyncio.run(client.create([{"role": "user", "content": "hi"}]))

        assert response is mock_response
        receipt = client.receipt
        assert receipt.total_input_tokens == 100
        assert receipt.total_output_tokens == 50
        assert isinstance(receipt, CarbonReceipt)

    def test_carbon_model_client_delegates_attributes(self):
        mock_client = MagicMock()
        mock_client.model = "test-model"

        with patch.object(autogen_mod, "_AUTOGEN_AVAILABLE", True):
            client = autogen_mod.CarbonModelClient(mock_client)

        assert client.model == "test-model"

    def test_carbon_model_client_receipt_property(self):
        mock_client = MagicMock()

        with patch.object(autogen_mod, "_AUTOGEN_AVAILABLE", True):
            client = autogen_mod.CarbonModelClient(mock_client)

        receipt = client.receipt
        assert isinstance(receipt, CarbonReceipt)
        assert receipt.total_tokens == 0
