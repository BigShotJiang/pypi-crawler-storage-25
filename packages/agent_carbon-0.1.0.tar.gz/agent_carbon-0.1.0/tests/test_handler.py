"""Tests for CarbonCallbackHandler."""

from __future__ import annotations

import asyncio
from uuid import uuid4

import pytest

from tests.conftest import make_llm_result, make_serialized


class TestSingleCall:
    def test_accumulates_one_record(self, handler, run_id):
        serialized = make_serialized("claude-sonnet-4-6")
        handler.on_chat_model_start(serialized, [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 100, 50), run_id=run_id)

        assert len(handler.receipt.calls) == 1

    def test_record_has_correct_tokens(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("claude-haiku-4-5"), [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("claude-haiku-4-5", 200, 75), run_id=run_id)

        rec = handler.receipt.calls[0]
        assert rec.input_tokens == 200
        assert rec.output_tokens == 75

    def test_record_nonzero_emissions_known_model(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 100, 50), run_id=run_id)

        rec = handler.receipt.calls[0]
        assert rec.gco2e > 0
        assert rec.wh > 0

    def test_record_zero_emissions_unknown_model(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("totally-made-up-model-xyz"), [[]], run_id=run_id)
        handler.on_llm_end(
            make_llm_result("totally-made-up-model-xyz", 100, 50), run_id=run_id
        )

        rec = handler.receipt.calls[0]
        assert rec.gco2e == 0.0
        assert rec.wh == 0.0
        assert rec.estimated is True


class TestMultiCall:
    def test_accumulates_multiple_records(self, handler):
        for i in range(8):
            rid = uuid4()
            handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=rid)
            handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 50, 25), run_id=rid)

        receipt = handler.receipt
        assert len(receipt.calls) == 8

    def test_totals_sum_correctly(self, handler):
        rids = [uuid4() for _ in range(3)]
        for rid in rids:
            handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=rid)
            handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 100, 50), run_id=rid)

        receipt = handler.receipt
        assert receipt.total_input_tokens == 300
        assert receipt.total_output_tokens == 150
        assert receipt.total_tokens == 450
        assert receipt.total_gco2e == pytest.approx(
            sum(c.gco2e for c in receipt.calls), rel=1e-5
        )

    def test_concurrent_run_ids_dont_collide(self, handler):
        """Concurrent calls with different run_ids must track independently."""
        rid1, rid2 = uuid4(), uuid4()

        handler.on_chat_model_start(make_serialized("claude-haiku-4-5"), [[]], run_id=rid1)
        handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=rid2)

        handler.on_llm_end(make_llm_result("claude-haiku-4-5", 10, 5), run_id=rid1)
        handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 200, 100), run_id=rid2)

        receipt = handler.receipt
        assert len(receipt.calls) == 2
        models = {c.model for c in receipt.calls}
        assert "claude-haiku-4-5" in models
        assert "claude-sonnet-4-6" in models


class TestRegion:
    def test_clean_grid_lowers_gco2e(self, handler, handler_us_west, run_id):
        """Oregon (us-west-2) has a cleaner grid than the global average."""
        rid_global = uuid4()
        rid_west = uuid4()

        handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=rid_global)
        handler.on_llm_end(make_llm_result("claude-sonnet-4-6", 100, 50), run_id=rid_global)

        handler_us_west.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=rid_west)
        handler_us_west.on_llm_end(make_llm_result("claude-sonnet-4-6", 100, 50), run_id=rid_west)

        assert handler_us_west.receipt.total_gco2e < handler.receipt.total_gco2e

    def test_grid_multiplier_below_one_for_clean_region(self, handler_us_west, run_id):
        handler_us_west.on_chat_model_start(make_serialized("llama-3.3-8b"), [[]], run_id=run_id)
        handler_us_west.on_llm_end(make_llm_result("llama-3.3-8b", 100, 50, provider="openai"), run_id=run_id)

        rec = handler_us_west.receipt.calls[0]
        assert rec.grid_multiplier < 1.0


class TestSavingsVsFrontier:
    def test_savings_positive_for_small_model(self, handler, run_id):
        """A small model should show positive savings vs the frontier."""
        handler.on_chat_model_start(make_serialized("claude-haiku-4-5"), [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("claude-haiku-4-5", 500, 200), run_id=run_id)

        assert handler.receipt.savings_vs_frontier_gco2e > 0

    def test_savings_zero_for_frontier_itself(self):
        from agent_carbon import CarbonCallbackHandler
        handler = CarbonCallbackHandler(frontier_model="claude-opus-4-6")
        rid = uuid4()
        handler.on_chat_model_start(make_serialized("claude-opus-4-6"), [[]], run_id=rid)
        handler.on_llm_end(make_llm_result("claude-opus-4-6", 100, 50), run_id=rid)

        assert handler.receipt.savings_vs_frontier_gco2e == pytest.approx(0.0, abs=1e-9)


class TestOpenAIFormat:
    def test_openai_token_format_parsed(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("gpt-5-mini"), [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("gpt-5-mini", 80, 40, provider="openai"), run_id=run_id)

        rec = handler.receipt.calls[0]
        assert rec.input_tokens == 80
        assert rec.output_tokens == 40


class TestReset:
    def test_reset_clears_records(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("claude-haiku-4-5"), [[]], run_id=run_id)
        handler.on_llm_end(make_llm_result("claude-haiku-4-5", 100, 50), run_id=run_id)

        assert len(handler.receipt.calls) == 1
        handler.reset()
        assert len(handler.receipt.calls) == 0
        assert handler.receipt.total_tokens == 0

    def test_reset_preserves_config(self, handler_us_west):
        handler_us_west.reset()
        assert handler_us_west.region == "us-west-2"


class TestError:
    def test_error_cleans_pending(self, handler, run_id):
        handler.on_chat_model_start(make_serialized("claude-sonnet-4-6"), [[]], run_id=run_id)
        handler.on_llm_error(RuntimeError("timeout"), run_id=run_id)

        assert str(run_id) not in handler._pending
        assert len(handler.receipt.calls) == 0


class TestOnLlmStart:
    def test_on_llm_start_also_works(self, handler, run_id):
        serialized = make_serialized("llama-3.3-70b")
        handler.on_llm_start(serialized, ["prompt text"], run_id=run_id)
        handler.on_llm_end(make_llm_result("llama-3.3-70b", 50, 30, provider="openai"), run_id=run_id)

        rec = handler.receipt.calls[0]
        assert rec.input_tokens == 50
        assert rec.output_tokens == 30


class TestTrackCarbonDecorator:
    def test_decorator_returns_tuple(self):
        from langchain_core.runnables import RunnableLambda
        from agent_carbon import track_carbon, CarbonCallbackHandler

        @track_carbon
        def my_fn(x, config=None):
            return x * 2

        result, receipt = my_fn(21)
        assert result == 42
        from agent_carbon import CarbonReceipt
        assert isinstance(receipt, CarbonReceipt)

    def test_decorator_with_region(self):
        from agent_carbon import track_carbon, CarbonReceipt

        @track_carbon(region="eu-west-3")
        def my_fn(x, config=None):
            return x

        _, receipt = my_fn(1)
        assert receipt.region == "eu-west-3"

    def test_decorator_async(self):
        from agent_carbon import track_carbon, CarbonReceipt

        @track_carbon
        async def my_fn(x, config=None):
            return x * 3

        result, receipt = asyncio.run(my_fn(7))
        assert result == 21
        assert isinstance(receipt, CarbonReceipt)
