"""Tests for the factors lookup table."""

from __future__ import annotations

import pytest

from agent_carbon.factors import FACTORS, ModelFactors, resolve_factors

REQUIRED_MODELS = [
    "gpt-5",
    "gpt-5-mini",
    "gpt-5-nano",
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-haiku-4-5",
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "llama-3.3-70b",
    "llama-3.3-8b",
    "mistral-large",
    "mistral-small",
]


class TestFactorsTable:
    def test_all_required_models_present(self):
        for slug in REQUIRED_MODELS:
            assert slug in FACTORS, f"Missing model: {slug}"

    def test_all_factors_are_model_factors(self):
        for slug, f in FACTORS.items():
            assert isinstance(f, ModelFactors), f"{slug} is not a ModelFactors instance"

    def test_all_wh_values_positive(self):
        for slug, f in FACTORS.items():
            assert f.input_wh_per_1m > 0, f"{slug}: input_wh_per_1m must be positive"
            assert f.output_wh_per_1m > 0, f"{slug}: output_wh_per_1m must be positive"

    def test_output_more_expensive_than_input(self):
        """Output generation is always more expensive than prefill."""
        for slug, f in FACTORS.items():
            assert f.output_wh_per_1m > f.input_wh_per_1m, (
                f"{slug}: output should cost more than input"
            )

    def test_all_estimated_true(self):
        for slug, f in FACTORS.items():
            assert f.estimated is True, f"{slug}: all v1 factors must be marked estimated"

    def test_all_providers_set(self):
        for slug, f in FACTORS.items():
            assert f.provider, f"{slug}: provider must not be empty"

    def test_frontier_heavier_than_small(self):
        assert FACTORS["claude-opus-4-6"].output_wh_per_1m > FACTORS["claude-haiku-4-5"].output_wh_per_1m
        assert FACTORS["gpt-5"].output_wh_per_1m > FACTORS["gpt-5-nano"].output_wh_per_1m

    def test_size_ordering_llama(self):
        assert FACTORS["llama-3.3-70b"].output_wh_per_1m > FACTORS["llama-3.3-8b"].output_wh_per_1m


class TestResolveFactors:
    def test_exact_match(self):
        f = resolve_factors("claude-sonnet-4-6")
        assert f is not None
        assert f.provider == "anthropic"

    def test_case_insensitive(self):
        f = resolve_factors("Claude-Sonnet-4-6")
        assert f is not None

    def test_prefix_match(self):
        f = resolve_factors("gpt-5-mini-preview")
        assert f is not None
        assert f is FACTORS["gpt-5-mini"]

    def test_keyword_match_opus(self):
        f = resolve_factors("claude-3-opus-20240229")
        assert f is not None
        assert f is FACTORS["claude-opus-4-6"]

    def test_keyword_match_haiku(self):
        f = resolve_factors("claude-haiku-20240307")
        assert f is not None
        assert f is FACTORS["claude-haiku-4-5"]

    def test_unknown_returns_none(self):
        f = resolve_factors("completely-unknown-model-xyz-9999")
        assert f is None

    def test_empty_string_returns_none(self):
        assert resolve_factors("") is None

    def test_specific_before_generic(self):
        """'gpt-5-nano' should not match 'gpt-5' slug."""
        f = resolve_factors("gpt-5-nano")
        assert f is FACTORS["gpt-5-nano"]

    def test_gpt5_mini_not_gpt5(self):
        f = resolve_factors("gpt-5-mini")
        assert f is FACTORS["gpt-5-mini"]
        assert f is not FACTORS["gpt-5"]
