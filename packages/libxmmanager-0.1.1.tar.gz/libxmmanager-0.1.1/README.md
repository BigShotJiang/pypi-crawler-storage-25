# libxmmanager
![CI status](https://ci.codeberg.org/api/badges/17044/status.svg)

libxmmanager will power tools like XMManager-MB and other frontends empowering you to mine easily.

## CI
This project is written in Python, and only needs to use Python, install requirements, build, then publish to PyPi.

## No AI Notice
No AI was used in the developing of this project.

## Contributers
- [@rocklake](https://codeberg.org/rocklake/) ([rocklake's github](https://github.com/rocklake/)) - Helped get the code into a usable state since the whole codebase was crumbling 
<!--
## This project is now on Codeberg

You can now find this project at [CodeBerg](https://codeberg.org/numycode/libxmmanager/) instead.

Any use of this project's code by GitHub Copilot, past or present, is done without my permission.  I do not consent to GitHub's use of this project's code in Copilot.
^no github mirror yet -->