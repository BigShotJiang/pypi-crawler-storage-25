from .main import xmrig_start, xmrig_stop, mining_controller, quit

__all__ = ["xmrig_start", "xmrig_stop", "mining_controller", "quit"]
__version__ = "0.1.0"
__author__ = "numycode"