import subprocess
import sys

def xmrig_start(xmrig_status, xmrig_path, args):
  subprocess.Popen(xmrig_path + " -B " + args, shell=True)
  return True
def xmrig_stop(xmrig_status, kill_command):
  subprocess.Popen(kill_command, shell=True)
  return False

def mining_controller():
  global xmrig_status
  if xmrig_status:
    xmrig_status = xmrig_start(xmrig_status)
  elif not xmrig_status:
    xmrig_status = xmrig_stop(xmrig_status)
def quit():
  global xmrig_status
  xmrig_status = xmrig_stop(xmrig_status)
  sys.exit()