# 一个简单的加法函数（待测试）
def add(a: int, b: int) -> int:
    return a + b