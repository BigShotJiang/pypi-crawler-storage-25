"""Tests for PendoSpanExporter, attribute mapping, and PII redaction."""

import pytest
from unittest.mock import patch, MagicMock

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExportResult
from opentelemetry.trace import StatusCode

from pendo_sdk.exporter import (
    PendoSpanExporter,
    _redact,
    _redact_attributes,
    _ns_to_ms,
    _trim_event_to_limit,
    _event_size,
    _MAX_EVENT_BYTES,
    _TRUNCATION_MARKER,
)
from pendo_sdk.schema import SpanStatusCode, SpanType


# ---------------------------------------------------------------------------
# PII Redaction
# ---------------------------------------------------------------------------

class TestPIIRedaction:
    def test_redact_email(self):
        assert _redact("contact john@example.com please") == \
            "contact [EMAIL_REDACTED] please"

    def test_redact_phone(self):
        assert _redact("call 555-123-4567") == "call [PHONE_REDACTED]"
        assert _redact("call 555.123.4567") == "call [PHONE_REDACTED]"
        assert _redact("call 5551234567") == "call [PHONE_REDACTED]"

    def test_redact_ssn(self):
        assert _redact("ssn: 123-45-6789") == "ssn: [SSN_REDACTED]"

    def test_redact_no_pii(self):
        text = "The weather in Denver is sunny"
        assert _redact(text) == text

    def test_redact_multiple_patterns(self):
        text = "Email john@test.com, phone 555-123-4567, ssn 123-45-6789"
        result = _redact(text)
        assert "[EMAIL_REDACTED]" in result
        assert "[PHONE_REDACTED]" in result
        assert "[SSN_REDACTED]" in result

    def test_redact_attributes_only_strings(self):
        attrs = {
            "message": "contact john@test.com",
            "token_count": 42,
            "is_cached": True,
        }
        result = _redact_attributes(attrs)
        assert result["message"] == "contact [EMAIL_REDACTED]"
        assert result["token_count"] == 42
        assert result["is_cached"] is True


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_span(
    name="test-span",
    attrs=None,
    parent=None,
    start_ns=1_000_000_000,
    end_ns=1_500_000_000,
    status_code=StatusCode.OK,
    status_description=None,
):
    """Create a mock ReadableSpan for testing."""
    span = MagicMock(spec=ReadableSpan)
    span.name = name
    span.attributes = attrs or {}
    span.start_time = start_ns
    span.end_time = end_ns

    context = MagicMock()
    context.trace_id = 0x1234567890ABCDEF1234567890ABCDEF
    context.span_id = 0x1234567890ABCDEF
    span.context = context

    if parent:
        parent_ctx = MagicMock()
        parent_ctx.span_id = parent
        span.parent = parent_ctx
    else:
        span.parent = None

    status = MagicMock()
    status.status_code = status_code
    status.description = status_description
    span.status = status

    return span


def _make_exporter(**kwargs):
    defaults = {
        "api_key": "test-key",
        "endpoint": "https://test.pendo.io",
        "visitor_id": "user@example.com",
        "account_id": "acct_123",
    }
    defaults.update(kwargs)
    return PendoSpanExporter(**defaults)


# ---------------------------------------------------------------------------
# Attribute Mapping — _build_event
# ---------------------------------------------------------------------------

class TestBuildEvent:
    def test_basic_generation_span(self):
        exporter = _make_exporter()
        span = _make_span(
            name="messages.create",
            attrs={
                "pendo.span.type": "GENERATION",
                "llm.model_name": "claude-sonnet-4-20250514",
                "llm.token_count.prompt": 100,
                "llm.token_count.completion": 50,
            },
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.name == "messages.create"
        assert event.type == SpanType.GENERATION
        assert event.props.model == ["claude-sonnet-4-20250514"]
        assert event.props.prompt_tokens == 100
        assert event.props.completion_tokens == 50

    def test_tool_span_mapping(self):
        exporter = _make_exporter()
        span = _make_span(
            name="search_db",
            attrs={
                "pendo.span.type": "TOOL_REQUEST",
                "tool.name": "search_db",
                "tool.input": "{'q': 'hello'}",
                "tool.output": "[{'id': 1}]",
                "tool.status": "success",
            },
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.type == SpanType.TOOL_REQUEST
        assert event.props.tool_name == "search_db"
        assert event.props.tool_input == "{'q': 'hello'}"
        assert event.props.tool_output == "[{'id': 1}]"
        assert event.props.tool_status == "success"

    def test_identity_injected(self):
        exporter = _make_exporter(
            visitor_id="mick@pendo.io",
            account_id="acct_pendo",
        )
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.visitor_id == "mick@pendo.io"
        assert event.account_id == "acct_pendo"

    def test_anonymous_when_no_visitor(self):
        exporter = _make_exporter(visitor_id=None)
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.visitor_id == "anonymous"

    def test_timestamps_converted_to_ms(self):
        exporter = _make_exporter()
        span = _make_span(
            start_ns=1_700_000_000_000_000_000,  # 1.7 trillion ns
            end_ns=1_700_000_001_234_000_000,
            attrs={"pendo.span.type": "GENERATION"},
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.start_time == 1_700_000_000_000
        assert event.end_time == 1_700_000_001_234
        assert event.duration_ms == 1234.0

    def test_trace_ids_formatted(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert len(event.trace_id) == 32
        assert all(c in "0123456789abcdef" for c in event.trace_id)
        assert len(event.span_id) == 16

    def test_parent_span_id_mapped(self):
        exporter = _make_exporter()
        span = _make_span(
            parent=0xABCDEF1234567890,
            attrs={"pendo.span.type": "GENERATION"},
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.parent_span_id is not None
        assert len(event.parent_span_id) == 16

    def test_no_parent_span_id(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.parent_span_id is None

    def test_error_status_mapped(self):
        exporter = _make_exporter()
        span = _make_span(
            attrs={"pendo.span.type": "GENERATION"},
            status_code=StatusCode.ERROR,
            status_description="timeout connecting to LLM",
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.status == SpanStatusCode.ERROR
        assert event.error_message == "timeout connecting to LLM"

    def test_ok_status_no_error_message(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.status == SpanStatusCode.OK
        assert event.error_message is None

    def test_unknown_span_type(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "FOOBAR"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.type == SpanType.UNKNOWN

    def test_missing_span_type(self):
        exporter = _make_exporter()
        span = _make_span(attrs={})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.type == SpanType.UNKNOWN

    def test_conversation_id_mapped(self):
        exporter = _make_exporter()
        span = _make_span(
            attrs={
                "pendo.span.type": "GENERATION",
                "pendo.conversation_id": "conv_abc",
            },
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.conversation_id == "conv_abc"

    def test_unknown_attrs_go_to_extra(self):
        exporter = _make_exporter()
        span = _make_span(
            attrs={
                "pendo.span.type": "GENERATION",
                "llm.model_name": "gpt-4",
                "custom.tag": "experiment-42",
                "custom.version": 3,
            },
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.props.model == ["gpt-4"]
        assert event.props.extra["custom.tag"] == "experiment-42"
        assert event.props.extra["custom.version"] == 3

    def test_total_tokens_and_cost(self):
        exporter = _make_exporter()
        span = _make_span(
            attrs={
                "pendo.span.type": "GENERATION",
                "llm.token_count.prompt": 200,
                "llm.token_count.completion": 80,
                "llm.token_count.total": 280,
                "llm.cost_usd": 0.0042,
            },
        )
        event = exporter._build_event(span, dict(span.attributes))

        assert event.props.prompt_tokens == 200
        assert event.props.completion_tokens == 80
        assert event.props.total_tokens == 280
        assert event.props.cost_usd == 0.0042

    def test_sdk_metadata(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "GENERATION"})
        event = exporter._build_event(span, dict(span.attributes))

        assert event.sdk_name == "pendo_sdk"
        assert event.sdk_version == "0.1.0"


# ---------------------------------------------------------------------------
# to_wire() output
# ---------------------------------------------------------------------------

class TestBuildEventWire:
    def test_wire_format_structure(self):
        exporter = _make_exporter()
        span = _make_span(
            name="classify",
            attrs={
                "pendo.span.type": "GENERATION",
                "llm.model_name": "claude-sonnet-4-20250514",
                "llm.token_count.prompt": 100,
            },
        )
        event = exporter._build_event(span, dict(span.attributes))
        wire = event.to_wire()

        assert wire["visitor_id"] == "user@example.com"
        assert wire["type"] == "GENERATION"
        assert wire["name"] == "classify"
        assert wire["props"]["modelUsed"] == "claude-sonnet-4-20250514"
        assert wire["props"]["modelsUsed"] == ["claude-sonnet-4-20250514"]
        assert wire["props"]["promptTokens"] == 100
        # pendo.span.type should NOT appear in props
        assert "pendo.span.type" not in wire["props"]

    def test_wire_excludes_none(self):
        exporter = _make_exporter()
        span = _make_span(attrs={"pendo.span.type": "TOOL_REQUEST"})
        event = exporter._build_event(span, dict(span.attributes))
        wire = event.to_wire()

        assert "parent_span_id" not in wire
        assert "error_message" not in wire
        assert "conversation_id" not in wire


# ---------------------------------------------------------------------------
# OTel GenAI semconv (Pydantic AI, OpenLLMetry) — piggyback path
# ---------------------------------------------------------------------------

class TestGenAiSemconv:
    def test_chat_operation_emits_llm_request_and_response(self):
        exporter = _make_exporter()
        span = _make_span(
            name="chat gpt-4o",
            attrs={
                "gen_ai.operation.name": "chat",
                "gen_ai.system": "openai",
                "gen_ai.request.model": "gpt-4o",
                "gen_ai.response.model": "gpt-4o-2024-08-06",
                "gen_ai.usage.input_tokens": 120,
                "gen_ai.usage.output_tokens": 45,
                "gen_ai.prompt": "What's the weather?",
                "gen_ai.completion": "Sunny, 72F.",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        types = [e["props"]["agentTraceType"] for e in events]
        assert "llm_request" in types
        assert "llm_response" in types

        req = next(e for e in events if e["props"]["agentTraceType"] == "llm_request")
        assert req["props"]["modelUsed"] == "gpt-4o"
        assert req["props"]["agentInputTokenCount"] == 120
        assert req["props"]["agentOutputTokenCount"] == 45
        assert req["props"]["agentTraceContent"] == "What's the weather?"

        resp = next(e for e in events if e["props"]["agentTraceType"] == "llm_response")
        assert resp["props"]["agentTraceContent"] == "Sunny, 72F."

    def test_execute_tool_operation_emits_tool_request(self):
        exporter = _make_exporter()
        span = _make_span(
            name="running tool get_weather",
            attrs={
                "gen_ai.operation.name": "execute_tool",
                "gen_ai.tool.name": "get_weather",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert len(events) >= 1
        assert events[0]["props"]["agentTraceType"] == "tool_request"
        assert events[0]["props"]["toolsUsed"] == ["get_weather"]

    def test_execute_tool_without_gen_ai_tool_name_falls_back_to_span_name(self):
        exporter = _make_exporter()
        span = _make_span(
            name="search_db",
            attrs={"gen_ai.operation.name": "execute_tool"},
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert events[0]["props"]["toolsUsed"] == ["search_db"]

    def test_pydantic_ai_agent_run_root_becomes_llm_request(self):
        """Pydantic AI root span can't be validated as a subagent — falls back
        to llm_request (BE-accepted). subagent_request is reserved for the
        LangChain callback's is_subagent-validated path only."""
        exporter = _make_exporter()
        span = _make_span(
            name="agent run",
            attrs={
                "agent_name": "weather_agent",
                "model_name": "gpt-4o",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert len(events) >= 1
        assert events[0]["props"]["agentTraceType"] == "llm_request"

    def test_unclassifiable_span_is_dropped(self):
        exporter = _make_exporter()
        span = _make_span(name="something", attrs={"custom.x": "y"})
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)
        assert events == []

    def test_pydantic_ai_tool_span_without_operation_name(self):
        """Pydantic AI's "running tool" span has gen_ai.tool.name but no op name."""
        exporter = _make_exporter()
        span = _make_span(
            name="running tool",
            attrs={
                "gen_ai.tool.name": "get_weather",
                "tool_arguments": '{"city": "Denver"}',
                "tool_response": "Sunny, 72F",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        types = [e["props"]["agentTraceType"] for e in events]
        assert "tool_request" in types
        assert "tool_response" in types
        req = next(e for e in events if e["props"]["agentTraceType"] == "tool_request")
        assert req["props"]["toolsUsed"] == ["get_weather"]
        assert req["props"]["agentTraceContent"] == '{"city": "Denver"}'

    def test_gen_ai_input_output_messages_mirrored_to_content(self):
        """Pydantic AI uses gen_ai.input.messages / output.messages (arrays)."""
        exporter = _make_exporter()
        span = _make_span(
            name="chat test",
            attrs={
                "gen_ai.operation.name": "chat",
                "gen_ai.request.model": "gpt-4o",
                "gen_ai.input.messages": '[{"role": "user", "content": "hi"}]',
                "gen_ai.output.messages": '[{"role": "assistant", "content": "hello"}]',
                "gen_ai.usage.input_tokens": 10,
                "gen_ai.usage.output_tokens": 5,
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        req = next(e for e in events if e["props"]["agentTraceType"] == "llm_request")
        resp = next(e for e in events if e["props"]["agentTraceType"] == "llm_response")
        assert "user" in req["props"]["agentTraceContent"]
        assert "assistant" in resp["props"]["agentTraceContent"]

    def test_pendo_span_type_still_takes_precedence_over_gen_ai(self):
        exporter = _make_exporter()
        span = _make_span(
            name="chat",
            attrs={
                "pendo.span.type": "TOOL_REQUEST",
                "tool.name": "search",
                "gen_ai.operation.name": "chat",
                "gen_ai.request.model": "gpt-4o",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)
        assert events[0]["props"]["agentTraceType"] == "tool_request"


class TestReactionAndSuggestedPrompt:
    """REACTION span → user_reaction conversation event (no agent_trace).
    USER_MESSAGE with message.suggested_prompt=True → prompt event with
    suggestedPrompt=True on the wire."""

    def test_reaction_emits_user_reaction_with_wire_fields(self):
        exporter = _make_exporter()
        span = _make_span(
            name="user.reaction",
            attrs={
                "pendo.span.type": "REACTION",
                "message.role": "user",
                "pendo.conversation_id": "conv-123",
                "reaction.type": "thumbs_up",
                "reaction.feedback_comment": "great answer",
                "reaction.message_span_id": "abcdef0123456789",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        # Reaction emits exactly one event (conversation user_reaction). No
        # trailing agent_trace event — reactions have no trace-tree counterpart.
        assert len(events) == 1
        evt = events[0]
        assert evt["type"] == "user_reaction"
        assert evt["props"]["reactionType"] == "thumbs_up"
        assert evt["props"]["feedbackComment"] == "great answer"
        assert evt["props"]["messageSpanId"] == "abcdef0123456789"
        assert evt["props"]["conversationId"] == "conv-123"
        # back-compat: content still carries the reaction value (web-SDK parity)
        assert evt["props"]["content"] == "thumbs_up"

    def test_reaction_without_message_span_id_omits_wire_field(self):
        exporter = _make_exporter()
        span = _make_span(
            name="user.reaction",
            attrs={
                "pendo.span.type": "REACTION",
                "message.role": "user",
                "reaction.type": "thumbs_down",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)
        assert len(events) == 1
        assert "messageSpanId" not in events[0]["props"]

    def test_suggested_prompt_flag_surfaces_on_user_prompt_event(self):
        exporter = _make_exporter()
        span = _make_span(
            name="user.prompt",
            attrs={
                "pendo.span.type": "USER_MESSAGE",
                "message.role": "user",
                "message.content": "Summarize my sales pipeline",
                "message.suggested_prompt": True,
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert len(events) == 1
        assert events[0]["type"] == "prompt"
        assert events[0]["props"]["suggestedPrompt"] is True


class TestMultiModelAgentResponse:
    """Multi-model turns (LangChain callback) carry the full set of models on
    llm.model_names. The donut chart groups on agentModelsUsed, so the exporter
    must split them into a list — never a comma-joined string (APP-152157).
    Wire field name matches AgenticEventProps.AgentModelsUsed in pendo-appengine."""

    def test_multi_model_emits_list_not_comma_joined(self):
        exporter = _make_exporter()
        span = _make_span(
            name="agent.response",
            attrs={
                "pendo.span.type": "ASSISTANT_RESPONSE",
                "message.role": "assistant",
                "message.content": "Here's the summary.",
                "message.response_content": "Here's the summary.",
                "llm.model_name": "gpt-5",
                "llm.model_names": ("gemini-2.5-flash", "gpt-4o-mini", "gpt-5"),
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        # ASSISTANT_RESPONSE only emits the conversation event, no trace event.
        assert len(events) == 1
        evt = events[0]
        assert evt["type"] == "agent_response"
        # Primary model = single string (back-compat for existing readers)
        assert evt["props"]["modelUsed"] == "gpt-5"
        # Full list — never a comma-joined string
        assert evt["props"]["agentModelsUsed"] == [
            "gemini-2.5-flash", "gpt-4o-mini", "gpt-5",
        ]
        assert "," not in evt["props"]["modelUsed"]

    def test_single_model_falls_back_to_one_element_list(self):
        exporter = _make_exporter()
        span = _make_span(
            name="agent.response",
            attrs={
                "pendo.span.type": "ASSISTANT_RESPONSE",
                "message.role": "assistant",
                "message.content": "ok",
                "message.response_content": "ok",
                "llm.model_name": "claude-sonnet-4-20250514",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert len(events) == 1
        assert events[0]["props"]["modelUsed"] == "claude-sonnet-4-20250514"
        assert events[0]["props"]["agentModelsUsed"] == ["claude-sonnet-4-20250514"]

    def test_no_model_emits_empty_list(self):
        exporter = _make_exporter()
        span = _make_span(
            name="agent.response",
            attrs={
                "pendo.span.type": "ASSISTANT_RESPONSE",
                "message.role": "assistant",
                "message.content": "ok",
                "message.response_content": "ok",
            },
        )
        events = exporter._build_wire_events(span, dict(span.attributes), sequence=1)

        assert events[0]["props"]["modelUsed"] == ""
        assert events[0]["props"]["agentModelsUsed"] == []


# ---------------------------------------------------------------------------
# Export flow
# ---------------------------------------------------------------------------

class TestExportFlow:
    @patch("pendo_sdk.exporter.PendoSpanExporter._send_jzb")
    def test_export_success(self, mock_send):
        exporter = _make_exporter()
        spans = [_make_span(attrs={"pendo.span.type": "GENERATION"})]
        result = exporter.export(spans)

        assert result == SpanExportResult.SUCCESS
        mock_send.assert_called_once()
        wire_events = mock_send.call_args[0][0]
        assert isinstance(wire_events, list)
        assert len(wire_events) == 1

    @patch("pendo_sdk.exporter.PendoSpanExporter._send_jzb")
    def test_export_batch_format(self, mock_send):
        exporter = _make_exporter()
        spans = [
            _make_span(name="span_1", attrs={"pendo.span.type": "GENERATION"}),
            _make_span(name="span_2", attrs={"pendo.span.type": "TOOL_REQUEST", "tool.input": "test"}),
        ]
        exporter.export(spans)

        wire_events = mock_send.call_args[0][0]
        # GENERATION emits 1 llm_request, TOOL_REQUEST emits 1 tool_request
        assert len(wire_events) == 2

    @patch("pendo_sdk.exporter.PendoSpanExporter._send_jzb")
    def test_export_with_redaction(self, mock_send):
        exporter = _make_exporter(redact_pii=True)
        span = _make_span(
            attrs={
                "pendo.span.type": "GENERATION",
                "message.content": "email john@test.com",
            },
        )
        exporter.export([span])

        wire_events = mock_send.call_args[0][0]
        # GENERATION spans emit agent_trace with agentTraceContent
        trace_event = [e for e in wire_events if e["type"] == "agent_trace"][0]
        content = trace_event["props"]["agentTraceContent"]
        assert "[EMAIL_REDACTED]" in content

    @patch("pendo_sdk.exporter.PendoSpanExporter._send_jzb")
    def test_export_without_redaction(self, mock_send):
        exporter = _make_exporter(redact_pii=False)
        span = _make_span(
            attrs={
                "pendo.span.type": "GENERATION",
                "message.content": "email john@test.com",
            },
        )
        exporter.export([span])

        wire_events = mock_send.call_args[0][0]
        trace_event = [e for e in wire_events if e["type"] == "agent_trace"][0]
        content = trace_event["props"]["agentTraceContent"]
        assert "john@test.com" in content

    @patch("pendo_sdk.exporter.PendoSpanExporter._send_jzb", side_effect=Exception("boom"))
    def test_export_failure_returns_failure(self, mock_send):
        exporter = _make_exporter()
        result = exporter.export([_make_span(attrs={"pendo.span.type": "GENERATION"})])
        assert result == SpanExportResult.FAILURE

    def test_endpoint_trailing_slash_stripped(self):
        exporter = PendoSpanExporter(
            api_key="test-key",
            endpoint="https://test.pendo.io/",
        )
        assert exporter._endpoint == "https://test.pendo.io"

    def test_send_jzb_url_has_correct_path(self):
        """Guards against the slash getting dropped between endpoint and path.
        Every export hit must go to /data/agenticsdk/<key>, not <endpoint>data/..."""
        import urllib.request
        exporter = PendoSpanExporter(
            api_key="test-key",
            endpoint="https://test.pendo.io",
        )
        captured = {}

        class _FakeResp:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *a): return False

        def _fake_urlopen(req, timeout=None):
            captured["url"] = req.full_url
            return _FakeResp()

        with patch.object(urllib.request, "urlopen", _fake_urlopen):
            exporter._send_jzb([{"type": "agent_trace", "props": {"agentTraceType": "llm_request"}}])

        assert "/data/agenticsdk/test-key" in captured["url"], captured["url"]
        assert "pendo.iodata" not in captured["url"], captured["url"]


# ---------------------------------------------------------------------------
# Identity management
# ---------------------------------------------------------------------------

class TestIdentity:
    def test_set_identity(self):
        exporter = _make_exporter(visitor_id="old@test.com")
        exporter.set_identity(visitor_id="new@test.com", account_id="new_acct")

        assert exporter._visitor_id == "new@test.com"
        assert exporter._account_id == "new_acct"

    def test_set_identity_partial(self):
        exporter = _make_exporter(visitor_id="user@test.com", account_id="acct_1")
        exporter.set_identity(account_id="acct_2")

        assert exporter._visitor_id == "user@test.com"  # unchanged
        assert exporter._account_id == "acct_2"


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

class TestNsToMs:
    def test_conversion(self):
        assert _ns_to_ms(1_000_000_000) == 1000

    def test_none(self):
        assert _ns_to_ms(None) is None

    def test_zero(self):
        assert _ns_to_ms(0) == 0


# ---------------------------------------------------------------------------
# Per-event 1MB size enforcement
# ---------------------------------------------------------------------------

class TestTrimEventToLimit:
    def test_small_event_untouched(self):
        evt = {"type": "agent_trace", "props": {"agentTraceContent": "hi"}}
        _trim_event_to_limit(evt)
        assert evt["props"]["agentTraceContent"] == "hi"

    def test_trims_agent_trace_content(self):
        huge = "x" * (_MAX_EVENT_BYTES + 5000)
        evt = {"type": "agent_trace", "props": {"agentTraceContent": huge, "content": "keep"}}
        _trim_event_to_limit(evt)
        assert _event_size(evt) <= _MAX_EVENT_BYTES
        assert evt["props"]["agentTraceContent"].endswith(_TRUNCATION_MARKER)
        assert evt["props"]["content"] == "keep"

    def test_trims_content_when_no_trace_content(self):
        huge = "y" * (_MAX_EVENT_BYTES + 5000)
        evt = {"type": "prompt", "props": {"content": huge}}
        _trim_event_to_limit(evt)
        assert _event_size(evt) <= _MAX_EVENT_BYTES
        assert evt["props"]["content"].endswith(_TRUNCATION_MARKER)

    def test_trims_both_fields_when_each_too_large(self):
        # agentTraceContent alone isn't enough to get under; content must also trim.
        half = "a" * (_MAX_EVENT_BYTES // 2 + 1000)
        evt = {"type": "agent_trace", "props": {"agentTraceContent": half, "content": half}}
        _trim_event_to_limit(evt)
        assert _event_size(evt) <= _MAX_EVENT_BYTES

    def test_clears_content_when_other_fields_overflow(self):
        # Overhead from extra fields alone exceeds the limit — content must be cleared.
        overflow_extra = "z" * (_MAX_EVENT_BYTES + 1000)
        evt = {
            "type": "agent_trace",
            "props": {"agentTraceContent": "small", "content": "small", "extra": overflow_extra},
        }
        _trim_event_to_limit(evt)
        # Can't guarantee under the limit (the SDK can't truncate `extra`), but
        # content fields should be cleared so we don't compound the problem.
        assert evt["props"]["agentTraceContent"] == ""
        assert evt["props"]["content"] == ""
