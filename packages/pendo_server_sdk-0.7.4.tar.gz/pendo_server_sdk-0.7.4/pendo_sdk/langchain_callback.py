"""
LangChain Callback Handler for Pendo SDK

Creates OTel spans from LangChain callbacks. Every LLM call, tool call,
and chain execution becomes a traced span that flows to Pendo.

Usage:
    from pendo_sdk.langchain_callback import PendoCallbackHandler
    handler = PendoCallbackHandler()

    # Add to LangChain as a global callback:
    import langchain
    langchain.callbacks.manager.add_handler(handler)

    # Or pass per-call:
    llm.invoke(prompt, config={"callbacks": [handler]})
"""

import logging
import time
import uuid
from typing import Any, Dict, List, Optional, Union

from opentelemetry import trace, context
from opentelemetry.trace import StatusCode

logger = logging.getLogger("pendo_sdk")

_SDK_NAME = "pendo_sdk"


# Max bytes of tool input/output content stamped on a span. LangGraph
# Command(update={...}) returns can stringify to tens of KB of serialized
# state, which blows up the agentTraceContent blob on the ingested event.
# 2048 is enough to show the shape of the payload without drowning the UI.
_TRACE_CONTENT_MAX_CHARS = 2048


def _coerce_otel_attr(value: Any) -> Any:
    """Coerce a Python value into an OTel-compatible attribute value.

    OpenTelemetry spans accept scalars (str/bool/int/float) and homogeneous
    sequences of those scalars as attributes. Mappings, arbitrary objects,
    and heterogeneous lists must be stringified to avoid a ``TypeError`` on
    ``span.set_attribute``. Earlier versions of this callback stringified
    *everything* non-numeric, which corrupted legitimate list attributes
    like ``pendo.subagents_used = ["quantitative_agent"]`` into the string
    ``"['quantitative_agent']"`` — the exporter then couldn't parse it back
    into a JSON list, and the wire ended up with a nested string.
    """
    if isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, (list, tuple)):
        # OTel allows homogeneous sequences of scalars. If every element is
        # already a supported scalar, pass the list through unchanged; if not,
        # coerce each element via str() to preserve the "it's a list" shape.
        if all(isinstance(x, (str, bool, int, float)) for x in value):
            return list(value)
        return [str(x) for x in value]
    return str(value)


def _truncate_for_trace(value: Any) -> str:
    """Stringify ``value`` and truncate to ``_TRACE_CONTENT_MAX_CHARS`` with
    a trailing marker recording how many bytes were dropped. Keeps the UI
    trace viewer readable without discarding that a large payload existed.
    """
    try:
        s = value if isinstance(value, str) else str(value)
    except Exception:
        return "<unstringifiable tool payload>"
    if len(s) <= _TRACE_CONTENT_MAX_CHARS:
        return s
    dropped = len(s) - _TRACE_CONTENT_MAX_CHARS
    return f"{s[:_TRACE_CONTENT_MAX_CHARS]}…[truncated {dropped} bytes]"


def _extract_usage_metadata(response: Any) -> Optional[Dict[str, Any]]:
    """Pull usage_metadata from an LLMResult, checking all known locations.

    LangChain's ``usage_metadata`` dict (``input_tokens`` / ``output_tokens``
    / ``total_tokens``, with optional ``input_token_details`` and
    ``output_token_details`` breakdowns) is populated in different places
    depending on the code path:

    - **Non-streaming Chat Completions or Responses API**: on the single
      ``generations[0][0].message.usage_metadata``.
    - **Streaming**: ``generations[0]`` is a list of ``ChatGenerationChunk``
      and only the final chunk (``response.completed`` for Responses API,
      the last ``chat.completion.chunk`` with usage for Chat Completions)
      carries the aggregated usage. Walking the list in reverse finds it.
    - **Some integrations**: usage is stashed in ``message.response_metadata``
      under ``token_usage`` or ``usage`` rather than ``usage_metadata``.
    - **Older patterns**: usage sits on ``gen.generation_info`` (the
      OpenAI-compatibility dict) instead of on the message itself.

    Returns a dict with ``input_tokens`` / ``output_tokens`` /
    ``total_tokens`` keys (converting ``prompt_tokens`` /
    ``completion_tokens`` if that's what's present), plus the raw
    ``usage_metadata`` nested detail dicts when available.
    """
    generations = getattr(response, "generations", None)
    if not generations or not generations[0]:
        return None

    gens = generations[0] if isinstance(generations[0], list) else [generations[0]]

    # Walk in reverse — for streaming, only the final chunk carries aggregated usage.
    for gen in reversed(gens):
        msg = getattr(gen, "message", None)

        if msg is not None:
            usage_md = getattr(msg, "usage_metadata", None)
            if isinstance(usage_md, dict) and usage_md:
                return usage_md

            # response_metadata.token_usage — some providers stash it here.
            response_md = getattr(msg, "response_metadata", None) or {}
            for key in ("token_usage", "usage"):
                raw = response_md.get(key) if isinstance(response_md, dict) else None
                if isinstance(raw, dict) and raw:
                    normalized = _normalize_openai_usage(raw)
                    if normalized:
                        return normalized

        # Legacy location: gen.generation_info carries the raw OpenAI usage dict.
        gen_info = getattr(gen, "generation_info", None) or {}
        if isinstance(gen_info, dict):
            # gen_info may directly have input_tokens/output_tokens...
            if "input_tokens" in gen_info or "output_tokens" in gen_info:
                normalized = _normalize_openai_usage(gen_info)
                if normalized:
                    return normalized
            # ...or nest it under usage / token_usage / usage_metadata.
            for key in ("usage_metadata", "token_usage", "usage"):
                raw = gen_info.get(key)
                if isinstance(raw, dict) and raw:
                    normalized = _normalize_openai_usage(raw)
                    if normalized:
                        return normalized
    return None


def _normalize_openai_usage(raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Coerce an OpenAI-style usage dict into the LangChain usage_metadata shape.

    Chat Completions returns ``prompt_tokens`` / ``completion_tokens`` /
    ``total_tokens`` plus ``prompt_tokens_details`` / ``completion_tokens_details``.
    The Responses API returns ``input_tokens`` / ``output_tokens`` /
    ``total_tokens`` plus ``input_tokens_details`` / ``output_tokens_details``.
    LangChain's ``usage_metadata`` uses the Responses-style names. Normalize
    to that so callers only have to read one shape.
    """
    if not isinstance(raw, dict) or not raw:
        return None

    input_tokens = raw.get("input_tokens")
    if input_tokens is None:
        input_tokens = raw.get("prompt_tokens")
    output_tokens = raw.get("output_tokens")
    if output_tokens is None:
        output_tokens = raw.get("completion_tokens")
    total_tokens = raw.get("total_tokens")

    if input_tokens is None and output_tokens is None and total_tokens is None:
        return None

    result: Dict[str, Any] = {}
    if input_tokens is not None:
        result["input_tokens"] = input_tokens
    if output_tokens is not None:
        result["output_tokens"] = output_tokens
    if total_tokens is not None:
        result["total_tokens"] = total_tokens

    # Preserve detail breakdowns if present under either naming.
    input_details = (
        raw.get("input_token_details")
        or raw.get("input_tokens_details")
        or raw.get("prompt_tokens_details")
    )
    if isinstance(input_details, dict):
        result["input_token_details"] = input_details
    output_details = (
        raw.get("output_token_details")
        or raw.get("output_tokens_details")
        or raw.get("completion_tokens_details")
    )
    if isinstance(output_details, dict):
        result["output_token_details"] = output_details

    return result


class PendoCallbackHandler:
    """LangChain callback handler that creates OTel spans for Pendo tracing."""

    # Required attributes for LangChain callback manager compatibility
    run_inline = True
    raise_error = False
    ignore_chain = False
    ignore_llm = False
    ignore_retry = True
    ignore_agent = False
    ignore_chat_model = False
    ignore_retriever = True
    ignore_custom_event = True

    # Chain names to suppress — these are LangGraph infrastructure, not meaningful traces
    _NOISE_CHAINS = {
        "start_node", "route_after_start_node", "__start__", "__end__",
        "next_actions_node", "route_after_supervisor", "route_after_start",
        "RunnableSequence", "RunnableLambda", "RunnableParallel",
        "ChannelWrite", "ChannelRead", "",
    }

    def __init__(self, conversation_id: Optional[str] = None,
                 visitor_id: Optional[str] = None,
                 account_id: Optional[str] = None,
                 auto_turn: bool = False,
                 suggested_prompt: bool = False):
        self._tracer = trace.get_tracer(_SDK_NAME)
        self._prompt_emitted = False  # Only emit one prompt event per turn
        self._spans: Dict[str, Any] = {}  # run_id -> (span, token)
        self._chain_parents: Dict[str, Optional[str]] = {}  # chain run_id -> parent run_id
        self._conversation_id = conversation_id or ""
        self._visitor_id = visitor_id or ""
        self._account_id = account_id or ""
        self._auto_turn = auto_turn  # Auto-end turn when all spans complete
        # When set, the single prompt event this turn emits is flagged as a
        # suggested/pre-built prompt (e.g. user clicked a starter chip in the UI
        # rather than typing). Consumed by _emit_prompt_event.
        self._suggested_prompt = bool(suggested_prompt)
        self._root_span = None  # Root span for the current conversation turn
        self._root_token = None
        # Accumulate response data across the turn for a single merged agent_response
        self._turn_response_text = ""  # Last response text wins
        self._turn_models: List[str] = []
        self._turn_tools: List[str] = []
        # Per-run_id tokens for the langchain_llm_active ContextVar. Set when
        # on_llm_start/on_chat_model_start fires so the OpenAI patchers can
        # detect "LangChain already owns this LLM call" and skip creating a
        # duplicate GENERATION span. Reset in on_llm_end/on_llm_error.
        self._llm_active_tokens: Dict[str, Any] = {}
        # Tool call ids that on_tool_end has already emitted a span for in the
        # current turn. ``_emit_tool_result_spans`` checks this to avoid
        # emitting a second TOOL_RESPONSE span for the same tool call when the
        # next LLM call sees the tool result in its message history.
        self._emitted_tool_call_ids: set = set()
        # Per-run_id tags captured at llm_start so on_llm_end can skip internal
        # LLM calls (tag "no_stream") from overwriting the turn's user-facing
        # response text. Without this, a classifier/evaluator LLM that runs
        # after the main response wins "last response" and pollutes agent_response.
        #
        # Thread-safety: this dict is not locked. We rely on the handler being
        # scoped to a single request (the typical `langchain_turn()` pattern),
        # in which LangChain callbacks for a given run_id fire serially on the
        # same event loop. Sharing a handler across concurrent requests (e.g.
        # a long-lived global handler with auto_turn=True under RunnableParallel
        # across threads) would be unsafe — callers should prefer per-request
        # handlers via `langchain_turn()`.
        self._span_tags: Dict[str, List[str]] = {}

    def set_conversation_id(self, conversation_id: str):
        self._conversation_id = conversation_id

    def set_identity(self, visitor_id: Optional[str] = None,
                     account_id: Optional[str] = None):
        """Set visitor/account identity stamped on every span this handler creates."""
        if visitor_id is not None:
            self._visitor_id = visitor_id
        if account_id is not None:
            self._account_id = account_id

    def start_turn(self):
        """Start a new conversation turn — creates a root span that all child spans nest under.
        This ensures all spans in a single turn share the same agentTraceId.
        """
        self.end_turn()  # Clean up any previous turn
        self._prompt_emitted = False  # Reset prompt flag for new turn
        self._turn_response_text = ""
        self._turn_models = []
        self._emitted_tool_call_ids = set()
        self._turn_tools = []
        self._span_tags = {}
        self._root_span = self._tracer.start_span("conversation.turn")
        self._root_span.set_attribute("pendo.span.type", "AGENT")
        self._root_span.set_attribute("message.role", "system")  # Won't emit conversation event
        if self._conversation_id:
            self._root_span.set_attribute("pendo.conversation_id", self._conversation_id)
        # Tell the exporter this span ID should be stripped from children's parent
        # Set immediately so it's available before any child spans flush
        from .core import _exporter
        if _exporter:
            _exporter._suppressed_root_span_id = format(self._root_span.context.span_id, "016x")

    def end_turn(self):
        """End the current conversation turn.
        Emits a single merged agent_response conversation event with accumulated
        models and tools from all LLM calls in the turn.
        """
        if self._root_span:
            # Emit one merged agent_response if we have response text
            if self._turn_response_text:
                parent_ctx = trace.set_span_in_context(self._root_span)
                span = self._tracer.start_span("agent.response", context=parent_ctx)
                span.set_attribute("pendo.span.type", "ASSISTANT_RESPONSE")
                span.set_attribute("message.role", "assistant")
                span.set_attribute("message.content", self._turn_response_text)
                span.set_attribute("message.response_content", self._turn_response_text)
                if self._turn_models:
                    # Primary model = the last one used (the one that produced the
                    # visible response text). The full set goes on llm.model_names so
                    # the exporter can emit agentModelsUsed as a list — joining models
                    # into a single comma-string broke the donut chart by treating
                    # each combination as its own slice (APP-152157).
                    span.set_attribute("llm.model_name", self._turn_models[-1])
                    if len(self._turn_models) > 1:
                        span.set_attribute("llm.model_names", tuple(self._turn_models))
                if self._turn_tools:
                    span.set_attribute("tool.name", ", ".join(self._turn_tools))
                if self._conversation_id:
                    span.set_attribute("pendo.conversation_id", self._conversation_id)
                self._stamp_identity(span)
                span.end()

            self._root_span.end()
            self._root_span = None

    def _stamp_identity(self, span) -> None:
        """Stamp visitor/account identity on a span at creation time.

        This captures identity on the request thread so the exporter
        reads it from the span — not from mutable exporter state that
        may be overwritten by a concurrent request.
        """
        if self._visitor_id:
            span.set_attribute("pendo.visitor_id", self._visitor_id)
        if self._account_id:
            span.set_attribute("pendo.account_id", self._account_id)

    def _mark_llm_active(self, run_id: Any) -> None:
        """Mark the langchain_llm_active ContextVar True for the duration of
        this LLM call. The OpenAI patchers check this and skip span creation,
        so a streamed ``ChatOpenAI`` call produces exactly one GENERATION span
        (from this handler) instead of two (handler + patcher).
        """
        try:
            from .patchers.langchain import langchain_llm_active
            self._llm_active_tokens[str(run_id)] = langchain_llm_active.set(True)
        except Exception:
            # Never let instrumentation bookkeeping break the LLM call.
            pass

    def _unmark_llm_active(self, run_id: Any) -> None:
        """Reset the langchain_llm_active ContextVar set by _mark_llm_active."""
        token = self._llm_active_tokens.pop(str(run_id), None)
        if token is None:
            return
        try:
            from .patchers.langchain import langchain_llm_active
            langchain_llm_active.reset(token)
        except Exception:
            pass

    def _resolve_parent_run_id(self, parent_run_id: Optional[str]) -> Optional[str]:
        """Traverse chain parents to find an ancestor that has a real span.
        Chains don't emit events but sub-agent LLM/tool calls are parented to them.
        Walk up the chain_parents map until we find a run_id in self._spans.
        """
        if not parent_run_id:
            return None
        current = str(parent_run_id)
        visited = set()
        while current and current not in visited:
            if current in self._spans:
                return current
            visited.add(current)
            current = self._chain_parents.get(current)
        return None

    def _start_span(self, run_id: str, name: str, span_type: str,
                    attrs: Optional[Dict] = None, parent_run_id: Optional[str] = None):
        # Determine parent context:
        # 1. Resolve parent through chain hierarchy to find a real span
        # 2. Otherwise use the root turn span (so all spans share same trace ID)
        # 3. If no root span, create one automatically
        parent_ctx = None
        resolved_parent = self._resolve_parent_run_id(str(parent_run_id) if parent_run_id else None)
        if resolved_parent and resolved_parent in self._spans:
            parent_span, _ = self._spans[resolved_parent]
            parent_ctx = trace.set_span_in_context(parent_span)

        if not parent_ctx and self._root_span:
            parent_ctx = trace.set_span_in_context(self._root_span)

        if not parent_ctx:
            # Auto-create root span if none exists
            self.start_turn()
            parent_ctx = trace.set_span_in_context(self._root_span)

        span = self._tracer.start_span(name, context=parent_ctx)
        span.set_attribute("pendo.span.type", span_type)
        if self._conversation_id:
            span.set_attribute("pendo.conversation_id", self._conversation_id)
        self._stamp_identity(span)
        if attrs:
            for k, v in attrs.items():
                if v is None:
                    continue
                span.set_attribute(k, _coerce_otel_attr(v))
        # Don't attach to global context — async tasks cross boundaries
        # and context.detach fails across different async contexts.
        # Just store the span for parent lookup.
        self._spans[str(run_id)] = (span, None)

    def _emit_prompt_event(self, content: str, model: str = ""):
        """Emit a standalone prompt span for the user's message.

        This creates a separate short-lived span so the user's prompt
        appears as a 'prompt' conversation event, independent of the
        LLM generation span which will become 'agent_response'.
        """
        parent_ctx = trace.set_span_in_context(self._root_span) if self._root_span else None
        span = self._tracer.start_span("user.prompt", context=parent_ctx)
        span.set_attribute("pendo.span.type", "USER_MESSAGE")
        span.set_attribute("message.role", "user")
        span.set_attribute("message.content", content if content else "")
        if model:
            span.set_attribute("llm.model_name", model)
        if self._conversation_id:
            span.set_attribute("pendo.conversation_id", self._conversation_id)
        if self._suggested_prompt:
            span.set_attribute("message.suggested_prompt", True)
        self._stamp_identity(span)
        span.end()  # End immediately — this is a point event

    def _end_span(self, run_id: str, error: Optional[str] = None):
        key = str(run_id)
        if key not in self._spans:
            # No span was started for this run_id — nothing to end. Leave any
            # _span_tags entry alone (it shouldn't exist, but if it does,
            # start_turn() will clear it on the next turn).
            return
        span, _ = self._spans.pop(key)
        # Pop tag entry AFTER we've confirmed the span existed, to keep
        # _span_tags and _spans lifecycles symmetric.
        self._span_tags.pop(key, None)
        if error:
            span.set_status(StatusCode.ERROR, error)
        else:
            span.set_status(StatusCode.OK)
        span.end()

        # In auto_turn mode, end the turn when all spans have completed.
        # This means the outermost LangChain invocation has finished.
        if self._auto_turn and not self._spans and not self._chain_parents and self._root_span:
            self.end_turn()
            from .core import flush
            flush()

    # ---- LLM callbacks ----

    def _format_messages_as_prompt(self, messages: List[Any]) -> str:
        """Format the delta messages for this specific LLM call's agentTraceContent.

        Only captures NEW non-tool messages since the last assistant response.
        Tool results are emitted as separate TOOL_RESPONSE trace events by
        _emit_tool_result_spans(), so they're excluded here to avoid duplication
        and keep the llm_request content focused on the actual prompt/instruction.

        For the first LLM call in a turn: includes system + user message.
        For subsequent calls (after tool use): includes only new user/human messages.
        """
        if not messages:
            return ""
        msg_list = messages[0] if isinstance(messages[0], list) else messages

        # Find the last assistant message index — everything after it is "new"
        last_ai_idx = -1
        for i, msg in enumerate(msg_list):
            role = getattr(msg, "type", "unknown")
            if role in ("ai", "assistant"):
                last_ai_idx = i

        # If no prior AI message, this is the first LLM call — include system + user
        if last_ai_idx == -1:
            parts = []
            for msg in msg_list:
                role = getattr(msg, "type", "unknown")
                # Skip tool messages — they get their own trace events
                if role == "tool":
                    continue
                content = str(getattr(msg, "content", ""))
                if not content:
                    continue
                parts.append(f"[{role}] {content}")
            return "\n".join(parts)

        # Otherwise, only include non-tool messages AFTER the last AI response
        parts = []
        delta = msg_list[last_ai_idx + 1:]
        has_tool_results = False
        for msg in delta:
            role = getattr(msg, "type", "unknown")
            # Skip tool messages — they get their own trace events
            if role == "tool":
                has_tool_results = True
                continue
            content = str(getattr(msg, "content", ""))
            if not content:
                continue
            parts.append(f"[{role}] {content}")
        if parts:
            return "\n".join(parts)
        # Continuation call driven purely by tool results: return a placeholder
        # so downstream trace_content is non-empty. Without this the exporter
        # would fall back to message.content (which on_llm_end overwrites with
        # the response), making the llm_request event display the response text.
        if has_tool_results:
            return "[continuation after tool results]"
        return ""

    def _emit_tool_result_spans(self, messages: List[Any]) -> None:
        """Emit TOOL_RESPONSE trace spans for tool result messages in the delta.

        When the LLM is called after tools return, the message history includes
        tool result messages. These are emitted as separate tool_response nodes
        in the trace tree — unless ``on_tool_end`` has already emitted a span
        for the same ``tool_call_id`` in this turn, in which case we'd produce
        a duplicate event. Two correctness requirements:

        1. Skip ToolMessages whose ``tool_call_id`` was already handled by
           ``on_tool_end`` (tracked in ``_emitted_tool_call_ids``). This is the
           common path in LangGraph-based agents.
        2. Skip entirely when there is no active ``_root_span`` — without a
           parent context, the emitted span would orphan on the wire with an
           empty ``agentParentSpanId`` and render as a disconnected node.

        Emitted attributes use ``message.content`` (what the exporter reads
        for TOOL_RESPONSE spans), not ``tool.output`` (which the exporter
        routes into tool_request/response pairs on TOOL_REQUEST spans).
        """
        if not messages or self._root_span is None:
            return
        msg_list = messages[0] if isinstance(messages[0], list) else messages

        # Find delta messages (after last AI response)
        last_ai_idx = -1
        for i, msg in enumerate(msg_list):
            role = getattr(msg, "type", "unknown")
            if role in ("ai", "assistant"):
                last_ai_idx = i

        delta = msg_list[last_ai_idx + 1:] if last_ai_idx >= 0 else []

        for msg in delta:
            role = getattr(msg, "type", "unknown")
            if role != "tool":
                continue

            tool_call_id = getattr(msg, "tool_call_id", None)
            if tool_call_id and str(tool_call_id) in self._emitted_tool_call_ids:
                # on_tool_end already emitted a paired tool_request/tool_response
                # for this call — don't double-emit.
                continue

            tool_name = getattr(msg, "name", "") or "tool"
            content = str(getattr(msg, "content", ""))
            if not content:
                continue

            # Emit a point span nested under the current conversation turn.
            parent_ctx = trace.set_span_in_context(self._root_span)
            span = self._tracer.start_span(f"tool.{tool_name}", context=parent_ctx)
            span.set_attribute("pendo.span.type", "TOOL_RESPONSE")
            span.set_attribute("tool.name", tool_name)
            # The exporter reads message.content for non-tool-split spans; use
            # that instead of tool.output so the content actually renders on
            # the wire (tool.output is only consulted for TOOL_REQUEST spans).
            span.set_attribute("message.content", _truncate_for_trace(content))
            if self._conversation_id:
                span.set_attribute("pendo.conversation_id", self._conversation_id)
            self._stamp_identity(span)
            span.end()

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        serialized_kwargs = (serialized.get("kwargs") or {})
        model = (
            serialized_kwargs.get("model_name", "")
            or serialized_kwargs.get("model", "")
            or serialized.get("id", [""])[-1]
        )
        content = "\n".join(prompts) if prompts else ""
        self._span_tags[str(run_id)] = list(tags or [])
        self._mark_llm_active(run_id)
        self._start_span(run_id, f"llm.{model}", "GENERATION", {
            "llm.model_name": model,
            "message.content": content,
            "message.role": "user",
        }, parent_run_id=parent_run_id)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[Any],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        serialized = serialized or {}
        serialized_kwargs = serialized.get("kwargs") or {}
        model = (
            serialized_kwargs.get("model_name", "")
            or serialized_kwargs.get("model", "")
            or kwargs.get("invocation_params", {}).get("model_name", "")
            or kwargs.get("invocation_params", {}).get("model", "")
            or serialized.get("id", [""])[-1]
        )
        # Emit tool results as separate TOOL_RESPONSE trace events
        self._emit_tool_result_spans(messages)
        # Full prompt context for agentTraceContent (excludes tool results)
        full_prompt = self._format_messages_as_prompt(messages)
        # User's actual message for conversation event content
        user_content = ""
        msg_list = messages[0] if messages and isinstance(messages[0], list) else (messages or [])
        for msg in reversed(msg_list):
            if getattr(msg, "type", "") == "human":
                user_content = str(getattr(msg, "content", ""))
                break
        # Emit a separate prompt event for the user's message
        # Always emit — use user_content if found, otherwise extract from full prompt
        prompt_text = user_content
        if not prompt_text and full_prompt:
            # Try to extract last [human] message from formatted prompt
            for line in reversed(full_prompt.split("\n")):
                if line.startswith("[human]"):
                    prompt_text = line[len("[human]"):].strip()
                    break
        if prompt_text and not self._prompt_emitted:
            self._emit_prompt_event(prompt_text, model)
            self._prompt_emitted = True
            logger.info("Emitted prompt event: %s", prompt_text[:80])
        else:
            logger.warning("No user content found for prompt event. msg_list types: %s",
                          [type(m).__name__ for m in msg_list[:3]])

        # The LLM generation span starts as "assistant" — it'll become agent_response
        # when on_llm_end fires with the model's response content
        self._span_tags[str(run_id)] = list(tags or [])
        self._mark_llm_active(run_id)
        self._start_span(run_id, f"llm.{model}", "GENERATION", {
            "llm.model_name": model,
            "message.content": "",  # Will be set by on_llm_end with response content
            "message.trace_content": full_prompt,
            "message.role": "assistant",
        }, parent_run_id=parent_run_id)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key in self._spans:
            span, _ = self._spans[key]
            # Resolve token usage. Preference order:
            #   1. llm_output.token_usage (non-streaming Chat Completions).
            #   2. usage_metadata on the final generation / response_metadata
            #      / generation_info — the most reliable for streaming and for
            #      the Responses API path used by reasoning models (o1/o3/gpt-5.x).
            llm_output = getattr(response, "llm_output", None) or {}
            raw_usage = llm_output.get("token_usage") if isinstance(llm_output, dict) else None
            usage_source = "llm_output.token_usage"
            normalized = _normalize_openai_usage(raw_usage) if isinstance(raw_usage, dict) else None

            if normalized is None:
                normalized = _extract_usage_metadata(response)
                usage_source = "generations.usage_metadata" if normalized else "none"

            if normalized:
                input_tokens = normalized.get("input_tokens")
                output_tokens = normalized.get("output_tokens")
                total_tokens = normalized.get("total_tokens")
                if input_tokens is not None:
                    span.set_attribute("llm.token_count.prompt", input_tokens)
                if output_tokens is not None:
                    span.set_attribute("llm.token_count.completion", output_tokens)
                if total_tokens is not None:
                    span.set_attribute("llm.token_count.total", total_tokens)

                # Cache-read input tokens and reasoning output tokens — these
                # mirror what LangSmith's cost-tracking UI shows under
                # "cache read" and "reasoning" sub-rows.
                input_details = normalized.get("input_token_details") or {}
                if isinstance(input_details, dict):
                    cache_read = input_details.get("cache_read")
                    if cache_read is None:
                        # Chat Completions names it cached_tokens under prompt_tokens_details.
                        cache_read = input_details.get("cached_tokens")
                    if cache_read is not None:
                        span.set_attribute(
                            "llm.token_count.prompt_cache_read", cache_read
                        )

                output_details = normalized.get("output_token_details") or {}
                if isinstance(output_details, dict):
                    reasoning = output_details.get("reasoning")
                    if reasoning is None:
                        reasoning = output_details.get("reasoning_tokens")
                    if reasoning is not None:
                        span.set_attribute(
                            "llm.token_count.completion_reasoning", reasoning
                        )

                logger.info(
                    "pendo_sdk tokens stamped (source=%s): prompt=%s completion=%s total=%s",
                    usage_source,
                    input_tokens,
                    output_tokens,
                    total_tokens,
                )
            else:
                logger.warning(
                    "pendo_sdk: no token usage found on LLM response — "
                    "llm_output.token_usage empty and no usage_metadata on any generation"
                )

            model = llm_output.get("model_name", "") if isinstance(llm_output, dict) else ""
            if model:
                span.set_attribute("llm.model_name", model)

            # Extract the LLM's response text for agent_response event
            response_text = ""
            generations = getattr(response, "generations", None)
            if generations and generations[0]:
                gen = generations[0][0] if isinstance(generations[0], list) else generations[0]
                response_text = str(getattr(gen, "text", ""))
                # Check for tool calls in the response
                msg = getattr(gen, "message", None)
                if msg:
                    tool_calls = getattr(msg, "tool_calls", None)
                    if tool_calls:
                        tool_names = [tc.get("name", "") for tc in tool_calls if isinstance(tc, dict)]
                        if tool_names:
                            span.set_attribute("tool.name", tool_names[0])
                            response_text = response_text or f"tool_call: {', '.join(tool_names)}"

            # Determine if this is a tool call or a real text response
            has_tool_calls = bool(getattr(getattr(gen, "message", None), "tool_calls", None) if generations and generations[0] else None)

            # Internal/meta LLM calls (classifiers, next-action evaluators,
            # tool-generation helpers) are tagged "no_stream" by ai-connect.
            # Suppress ALL accumulation for these calls — content, model name,
            # and tool names — so the merged agent_response event reflects
            # only user-facing LLM activity. (Pre-fix, the classifier's JSON
            # output + gpt-4o-mini model name would leak into agent_response,
            # masking the real gemini-2.5-flash response.)
            #
            # ASSUMPTION: LangChain propagates `tags` from
            # make_runnable_config(tags=[...]) into on_llm_start /
            # on_chat_model_start callbacks, including through
            # with_structured_output() wrappers. Verified empirically against
            # ai-connect's create_guide evaluator (which uses both). If this
            # propagation ever regresses, classifier output will leak back
            # into agent_response events.
            is_internal = "no_stream" in self._span_tags.get(key, [])

            if has_tool_calls:
                # Tool call decision — LLM decided to call a tool/agent.
                # Capture the full response including reasoning + tool call info.
                span.set_attribute("message.role", "tool_decision")

                # Build the decision output: reasoning text + tool calls
                decision_parts = []
                # Get reasoning from message.content (where LLMs put their thinking)
                if msg:
                    msg_content = str(getattr(msg, "content", ""))
                    if msg_content:
                        decision_parts.append(msg_content)
                # Append tool call details
                tool_calls_list = getattr(msg, "tool_calls", []) if msg else []
                for tc in tool_calls_list:
                    if isinstance(tc, dict):
                        tc_name = tc.get("name", "")
                        tc_args = tc.get("args", {})
                        decision_parts.append(f"Action: {tc_name}({tc_args})")
                        if tc_name and not is_internal and tc_name not in self._turn_tools:
                            self._turn_tools.append(tc_name)

                decision_text = "\n".join(decision_parts) if decision_parts else response_text
                span.set_attribute("message.response_content", decision_text)
            else:
                # Real text response — accumulate for merged agent_response at end_turn
                # Don't set role="assistant" so exporter skips conversation event
                span.set_attribute("message.role", "llm_response")
                if response_text:
                    span.set_attribute("message.content", response_text)
                    span.set_attribute("message.response_content", response_text)
                    if not is_internal:
                        self._turn_response_text = response_text  # Last response wins

            # Accumulate model name (skip for internal/no_stream calls —
            # otherwise classifier models like gpt-4o-mini would pollute
            # agent_response.ModelUsed alongside the real main-LLM model).
            current_model = span.attributes.get("llm.model_name", "") if hasattr(span, 'attributes') else ""
            if not current_model:
                current_model = model
            if current_model and not is_internal and current_model not in self._turn_models:
                self._turn_models.append(current_model)

        self._end_span(run_id)
        self._unmark_llm_active(run_id)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._end_span(run_id, error=str(error))
        self._unmark_llm_active(run_id)

    # ---- Tool callbacks ----

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = (serialized or {}).get("name", "") or (serialized or {}).get("id", [""])[-1]
        # Detect subagent calls (tools that delegate to sub-agents)
        is_subagent = tool_name.startswith("call_") or tool_name.startswith("handoff_")
        span_type = "SUBAGENT_REQUEST" if is_subagent else "TOOL_REQUEST"

        span_attrs: Dict[str, Any] = {
            "tool.name": tool_name,
            "tool.input": _truncate_for_trace(input_str),
        }

        if is_subagent:
            # Pass the tool name through verbatim so the UI shows exactly what
            # the customer's code called it (e.g. `call_quantitative_agent`),
            # rather than a derived/massaged form.
            span_attrs["pendo.subagents_used"] = [tool_name]

        self._start_span(run_id, f"tool.{tool_name}", span_type, span_attrs,
                         parent_run_id=parent_run_id)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        key = str(run_id)
        if key in self._spans:
            span, _ = self._spans[key]
            span.set_attribute("tool.output", _truncate_for_trace(output))
        # Record the tool_call_id so _emit_tool_result_spans can dedup on the
        # next LLM call — LangChain's ToolMessage carries the same tool_call_id
        # that the tool invocation was keyed on.
        tool_call_id = (
            getattr(output, "tool_call_id", None)
            or (kwargs.get("inputs") or {}).get("tool_call_id")
        )
        if tool_call_id:
            self._emitted_tool_call_ids.add(str(tool_call_id))
        self._end_span(run_id)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._end_span(run_id, error=str(error))

    # ---- Chain callbacks ----

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        # Don't emit events for chain spans — they're LangGraph internal routing.
        # BUT track the run_id → parent_run_id so child LLM/tool spans inside
        # sub-agents can traverse up to find their real parent span.
        key = str(run_id)
        self._chain_parents[key] = str(parent_run_id) if parent_run_id else None

    def on_chain_end(
        self,
        outputs: Any,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._chain_parents.pop(str(run_id), None)
        self._end_span(run_id)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: Any,
        parent_run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self._chain_parents.pop(str(run_id), None)
        self._end_span(run_id, error=str(error))

    # ---- Required no-op callbacks ----

    def on_text(self, text: str, **kwargs: Any) -> None:
        pass

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        pass

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        pass

    def on_retry(self, retry_state: Any, **kwargs: Any) -> None:
        pass

    def on_llm_new_token(self, token: str, **kwargs: Any) -> None:
        pass
