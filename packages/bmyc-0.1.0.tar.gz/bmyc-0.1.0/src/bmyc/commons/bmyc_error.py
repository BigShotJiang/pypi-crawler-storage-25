class BmycError(Exception):
    pass
