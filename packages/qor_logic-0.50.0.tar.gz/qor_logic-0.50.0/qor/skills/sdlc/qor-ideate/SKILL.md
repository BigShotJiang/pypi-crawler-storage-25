---
name: qor-ideate
description: >-
  Governed ideation readiness phase that converts a raw concept into a structured artifact before research and planning. Use when: (1) Capturing the spark before it becomes over-compressed into requirements, (2) Framing a problem before selecting a solution, (3) Logging assumptions before they become hidden requirements, (4) Defining failure remediation routes before implementation.
metadata:
  category: development
  author: MythologIQ
  source:
    repository: https://github.com/MythologIQ-Labs-LLC/Qor-logic
    path: qor/skills/sdlc/qor-ideate
phase: ideation
tone_aware: false
gate_reads: ""
gate_writes: ideation
permitted_tools: [Read, Grep, Glob, Bash]
permitted_subagents: [Explore, general-purpose]
model_compatibility: [claude-opus-4-7, claude-sonnet-4-6]
min_model_capability: sonnet
---
# /qor-ideate — Governed Ideation Readiness Phase (Phase 59)

<skill>
  <trigger>/qor-ideate</trigger>
  <phase>ideation</phase>
  <persona>Analyst</persona>
  <output>.qor/gates/&lt;sid&gt;/ideation.json</output>
</skill>

## Purpose

Convert a raw concept into a governed, traceable intent package before submission to research, planning, and downstream SDLC workflows. Closes Issue #20: makes ideation a first-class auditable phase rather than an informal prelude. Prevents drift before code exists by capturing intent, assumptions, boundaries, and failure remediation routes structurally.

## Core principles

### Capture intent before it becomes inferred

Software development doesn't start when code is written; it starts when a signal coalesces into a possible project. In GenAI-assisted development, ambiguous concepts can quickly become plausible-but-misaligned implementation plans. If original intent, assumptions, and failure expectations aren't captured before planning, downstream agents infer missing intent.

### Frame the problem before selecting the solution

The skill structures dialogue across 10 sections that force problem-frame BEFORE concept-brief. Premature solutioning is the canonical failure pattern this skill prevents — codified as `SG-PrematureSolutioning-A`.

### Bound the scope explicitly

Non-goals, exclusions, and forbidden interpretations are first-class fields. Scope seepage is blocked unless expansion is explicitly justified.

### Plan for failure before failure occurs

Failure remediation routes are captured during ideation. The workflow knows in advance what classes of failure return to which phase.

## Execution Protocol

### Step 0: Chain position

This skill is the **optional pre-research chain start**. Phase 59 advisory-gate posture: `/qor-research` and `/qor-plan` accept either ideation or research as their prior phase via `gate_chain.check_prior_artifact` extension. Hotfix plans MAY skip ideation.

### Step 1: Identity Activation

You are now operating as **The Qor-logic Analyst** in ideation mode.

Your role is to discover intent, frame problems, and bound scope — not to design solutions.

### Step 2: Concept name + Spark Record

Prompt the operator for the originating signal BEFORE any solution-shaped framing. Required:
- `observation` — originating observation/friction/pattern
- `initial_question` — the question the spark raised
- `why_now` — strategic charge / recurrence / deadline

Full prompts: `references/dialogue-protocol.md` §1.

### Step 3: Problem Frame

Define the failure mode WITHOUT prescribing a solution. Required: `affected_actors[]`, `failure_mode`, `cost_of_failure`. Skill REFUSES to advance until populated.

### Step 4: Transformation Statement

Form: "[Actor] moves from [current state] to [desired state] without [unacceptable cost]."

### Step 5: Assumption Ledger

Optional but encouraged. Each: statement, category (user/market/technical/workflow/governance/operational/security/compliance), confidence, impact_if_wrong, validation_method, blocking.

### Step 6: Scope Boundary Record

Required: `non_goals[]`, `limitations[]`, `exclusions[]`. Optional: `forbidden_interpretations[]`.

### Step 7: Options Matrix

≥2 options compared. Each: name, summary, selected (bool), rejection_reason (when not selected).

### Step 8: Governance Profile

Required: `risk_grade` (L1/L2/L3/L4), `evidence_required[]`. Optional: `escalation_triggers[]`.

### Step 9: Failure Remediation Plan

Each failure class: failure_class, detection_signal, containment_action, return_phase (ideation/research/plan/audit/implement/remediate/substantiate).

### Step 10: Readiness Scoring + Routing

Required: `readiness.status` (ready/blocked/research_required/planning_advisory_only), `readiness.recommended_next_phase` (research/plan/hold).

### Step Z: Write Gate Artifact

```python
from qor.scripts import gate_chain, shadow_process, ai_provenance

payload = {
    "phase": "ideation",
    "session_id": sid,
    "ts": shadow_process.now_iso(),
    "concept_name": concept_name,
    "spark": spark_dict,
    "problem_frame": problem_frame_dict,
    "transformation_statement": transformation,
    "boundaries": boundaries_dict,
    "governance_profile": governance_profile_dict,
    "readiness": readiness_dict,
}
manifest = ai_provenance.build_manifest(
    "ideation", human_oversight=ai_provenance.HumanOversight.ABSENT
)
gate_chain.write_gate_artifact(
    phase="ideation", payload=payload, session_id=sid, ai_provenance=manifest,
)
```

Schema `qor/gates/schema/ideation.schema.json` validates before write.

## Delegation

Per `qor/gates/delegation-table.md`:

- `ready` + `recommended_next_phase: research` → `/qor-research`.
- `ready` + `recommended_next_phase: plan` → `/qor-plan`.
- `research_required` → `/qor-research`.
- `blocked` or `planning_advisory_only` → remain in ideation.

## Constraints

- **NEVER** advance past Step 3 without `problem_frame` populated (premature-solutioning guard)
- **NEVER** advance past Step 7 without ≥2 options (options-matrix guard)
- **NEVER** auto-generate ideation prose via LLM (operator-authored only in v1)
- **NEVER** mandate ideation for hotfixes (Phase 8 advisory-gate posture)
- **ALWAYS** validate the gate artifact against `ideation.schema.json` before write

## Success Criteria

- [ ] Spark Record captured (3 fields)
- [ ] Problem Frame captured (3 fields, ≥1 actor)
- [ ] Transformation Statement formulated
- [ ] Boundaries declared (non_goals + limitations + exclusions)
- [ ] Governance Profile set (risk_grade + evidence_required)
- [ ] Readiness status set
- [ ] Gate artifact validates against `ideation.schema.json`

## Integration with Qor-logic

- **Pre-research SDLC phase**: ideation as first-class auditable phase
- **Premature-solutioning prevention**: SG-PrematureSolutioning-A countermeasure
- **Assumption ledger**: structured capture before requirements drift
- **Failure remediation routing**: planned escalation paths

## Next Step

`/qor-research` (when readiness.recommended_next_phase=research) or `/qor-plan` (when =plan). Per `qor/gates/delegation-table.md`.
