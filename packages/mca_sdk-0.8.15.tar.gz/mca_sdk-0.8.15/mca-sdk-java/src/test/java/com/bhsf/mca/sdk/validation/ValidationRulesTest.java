package com.bhsf.mca.sdk.validation;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class ValidationRulesTest {

    @Test
    public void testInternalRegressionRules() {
        ValidationRules.RuleSet rules = ValidationRules.getValidationRules("internal", "regression");

        List<String> required = rules.getRequired();
        assertEquals(4, required.size());
        assertTrue(required.contains("service.name"));
        assertTrue(required.contains("model.id"));
        assertTrue(required.contains("model.version"));
        assertTrue(required.contains("team.name"));
    }

    @Test
    public void testInternalGenerativeRules() {
        ValidationRules.RuleSet rules = ValidationRules.getValidationRules("internal", "generative");

        List<String> required = rules.getRequired();
        assertEquals(4, required.size());
        assertTrue(required.contains("service.name"));
        assertTrue(required.contains("llm.provider"));
        assertTrue(required.contains("llm.model"));
        assertTrue(required.contains("team.name"));
    }

    @Test
    public void testInternalAgenticRules() {
        ValidationRules.RuleSet rules = ValidationRules.getValidationRules("internal", "agentic");

        List<String> required = rules.getRequired();
        assertEquals(3, required.size());
        assertTrue(required.contains("service.name"));
        assertTrue(required.contains("llm.provider"));
        assertTrue(required.contains("team.name"));
        assertFalse(required.contains("llm.model"));

        List<String> optional = rules.getOptional();
        assertTrue(optional.contains("llm.model"));
    }

    @Test
    public void testVendorRules() {
        ValidationRules.RuleSet rules = ValidationRules.getValidationRules("vendor", "anytype");

        List<String> required = rules.getRequired();
        assertEquals(3, required.size());
        assertTrue(required.contains("service.name"));
        assertTrue(required.contains("vendor.name"));
        assertTrue(required.contains("team.name"));
    }

    @Test
    public void testVendorWildcard_DifferentTypes() {
        // Vendor uses wildcard, so any model_type should work
        ValidationRules.RuleSet rules1 = ValidationRules.getValidationRules("vendor", "classification");
        ValidationRules.RuleSet rules2 = ValidationRules.getValidationRules("vendor", "regression");

        assertEquals(rules1.getRequired(), rules2.getRequired());
    }

    @Test
    public void testInvalidCategory_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            ValidationRules.getValidationRules("invalid", "regression");
        });
    }

    @Test
    public void testInvalidType_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            ValidationRules.getValidationRules("internal", "invalid");
        });
    }

    @Test
    public void testNullCategory_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            ValidationRules.getValidationRules(null, "regression");
        });
    }

    @Test
    public void testEmptyCategory_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            ValidationRules.getValidationRules("", "regression");
        });
    }

    @Test
    public void testNullType_ForInternal_ShouldThrow() {
        assertThrows(IllegalArgumentException.class, () -> {
            ValidationRules.getValidationRules("internal", null);
        });
    }

    @Test
    public void testCaseInsensitive() {
        ValidationRules.RuleSet rules1 = ValidationRules.getValidationRules("INTERNAL", "REGRESSION");
        ValidationRules.RuleSet rules2 = ValidationRules.getValidationRules("internal", "regression");

        assertEquals(rules1.getRequired(), rules2.getRequired());
    }

    @Test
    public void testGetRequiredAttributes_ConvenienceMethod() {
        List<String> required = ValidationRules.getRequiredAttributes("internal", "regression");

        assertEquals(4, required.size());
        assertTrue(required.contains("service.name"));
    }

    @Test
    public void testGetOptionalAttributes_ConvenienceMethod() {
        List<String> optional = ValidationRules.getOptionalAttributes("internal", "regression");

        assertFalse(optional.isEmpty());
        assertTrue(optional.contains("service.version") || optional.contains("deployment.environment"));
    }

    @Test
    public void testRuleSetImmutability() {
        ValidationRules.RuleSet rules = ValidationRules.getValidationRules("internal", "regression");

        // Should not be able to modify the returned lists
        assertThrows(UnsupportedOperationException.class, () -> {
            rules.getRequired().add("new.field");
        });

        assertThrows(UnsupportedOperationException.class, () -> {
            rules.getOptional().add("new.field");
        });
    }
}
