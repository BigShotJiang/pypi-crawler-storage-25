package com.bhsf.mca.sdk.resilience;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TelemetryQueue.
 */
public class TelemetryQueueTest {

    @Test
    public void testEnqueueAndDequeue() {
        TelemetryQueue queue = new TelemetryQueue(100);

        assertTrue(queue.isEmpty());
        assertEquals(0, queue.size());

        queue.enqueue("{\"metric\":\"test\",\"value\":1}");

        assertFalse(queue.isEmpty());
        assertEquals(1, queue.size());

        String item = queue.dequeue();
        assertEquals("{\"metric\":\"test\",\"value\":1}", item);
        assertTrue(queue.isEmpty());
    }

    @Test
    public void testFIFOOrder() {
        TelemetryQueue queue = new TelemetryQueue(100);

        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.enqueue("item3");

        assertEquals("item1", queue.dequeue());
        assertEquals("item2", queue.dequeue());
        assertEquals("item3", queue.dequeue());
    }

    @Test
    public void testPeek() {
        TelemetryQueue queue = new TelemetryQueue(100);

        assertNull(queue.peek());

        queue.enqueue("item1");
        queue.enqueue("item2");

        assertEquals("item1", queue.peek());
        assertEquals(2, queue.size()); // Peek doesn't remove
        assertEquals("item1", queue.dequeue());
    }

    @Test
    public void testBoundedCapacityWithEviction() {
        TelemetryQueue queue = new TelemetryQueue(3);

        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.enqueue("item3");

        assertTrue(queue.isFull());

        // Adding 4th item should evict item1
        queue.enqueue("item4");

        assertEquals(3, queue.size());
        assertEquals("item2", queue.dequeue()); // item1 was evicted
        assertEquals("item3", queue.dequeue());
        assertEquals("item4", queue.dequeue());
    }

    @Test
    public void testDequeueBatch() {
        TelemetryQueue queue = new TelemetryQueue(100);

        for (int i = 0; i < 10; i++) {
            queue.enqueue("item" + i);
        }

        List<String> batch = queue.dequeueBatch(5);

        assertEquals(5, batch.size());
        assertEquals("item0", batch.get(0));
        assertEquals("item4", batch.get(4));
        assertEquals(5, queue.size()); // 5 remaining
    }

    @Test
    public void testDequeueBatchMoreThanAvailable() {
        TelemetryQueue queue = new TelemetryQueue(100);

        queue.enqueue("item1");
        queue.enqueue("item2");

        List<String> batch = queue.dequeueBatch(10);

        assertEquals(2, batch.size());
        assertTrue(queue.isEmpty());
    }

    @Test
    public void testClear() {
        TelemetryQueue queue = new TelemetryQueue(100);

        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.enqueue("item3");

        int cleared = queue.clear();

        assertEquals(3, cleared);
        assertTrue(queue.isEmpty());
        assertEquals(0, queue.size());
    }

    @Test
    public void testStatistics() {
        TelemetryQueue queue = new TelemetryQueue(10);

        TelemetryQueue.TelemetryQueueStats stats = queue.getStats();

        assertEquals(0, stats.getSize());
        assertEquals(10, stats.getMaxSize());
        assertTrue(stats.isEmpty());
        assertFalse(stats.isFull());
        assertEquals(0.0, stats.getUtilization(), 0.01);
        assertFalse(stats.isPersistEnabled());

        // Add items
        for (int i = 0; i < 5; i++) {
            queue.enqueue("item" + i);
        }

        stats = queue.getStats();
        assertEquals(5, stats.getSize());
        assertEquals(50.0, stats.getUtilization(), 0.01);
    }

    @Test
    public void testPersistenceRoundtrip(@TempDir Path tempDir) throws InterruptedException {
        String queuePath = tempDir.resolve("test-queue.json").toString();

        // Create queue and add items
        TelemetryQueue queue1 = new TelemetryQueue(100, true, queuePath, null, null);
        queue1.enqueue("item1");
        queue1.enqueue("item2");
        queue1.enqueue("item3");

        // Shutdown to flush
        queue1.shutdown(5000);

        // Create new queue from same path
        TelemetryQueue queue2 = new TelemetryQueue(100, true, queuePath, null, null);

        assertEquals(3, queue2.size());
        assertEquals("item1", queue2.dequeue());
        assertEquals("item2", queue2.dequeue());
        assertEquals("item3", queue2.dequeue());

        TelemetryQueue.TelemetryQueueStats stats = queue2.getStats();
        assertEquals(3, stats.getItemsRecovered());

        queue2.shutdown(5000);
    }

    @Test
    public void testConcurrentEnqueue() throws InterruptedException {
        TelemetryQueue queue = new TelemetryQueue(1000);
        int numThreads = 10;
        int itemsPerThread = 100;

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        CountDownLatch latch = new CountDownLatch(numThreads);

        for (int t = 0; t < numThreads; t++) {
            int threadId = t;
            executor.submit(() -> {
                try {
                    for (int i = 0; i < itemsPerThread; i++) {
                        queue.enqueue("thread" + threadId + "-item" + i);
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(10, TimeUnit.SECONDS);
        executor.shutdown();

        assertEquals(numThreads * itemsPerThread, queue.size());
    }

    @Test
    public void testConcurrentEnqueueDequeue() throws InterruptedException {
        TelemetryQueue queue = new TelemetryQueue(1000);
        int numProducers = 5;
        int numConsumers = 5;
        int itemsPerProducer = 100;

        ExecutorService executor = Executors.newFixedThreadPool(numProducers + numConsumers);
        CountDownLatch producerLatch = new CountDownLatch(numProducers);
        CountDownLatch consumerLatch = new CountDownLatch(numConsumers);

        List<String> consumed = Collections.synchronizedList(new ArrayList<>());

        // Start producers
        for (int t = 0; t < numProducers; t++) {
            int threadId = t;
            executor.submit(() -> {
                try {
                    for (int i = 0; i < itemsPerProducer; i++) {
                        queue.enqueue("thread" + threadId + "-item" + i);
                    }
                } finally {
                    producerLatch.countDown();
                }
            });
        }

        // Start consumers
        for (int t = 0; t < numConsumers; t++) {
            executor.submit(() -> {
                try {
                    while (!producerLatch.await(0, TimeUnit.MILLISECONDS) || !queue.isEmpty()) {
                        String item = queue.dequeue();
                        if (item != null) {
                            consumed.add(item);
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    consumerLatch.countDown();
                }
            });
        }

        producerLatch.await(10, TimeUnit.SECONDS);
        consumerLatch.await(10, TimeUnit.SECONDS);
        executor.shutdown();

        // All items should be consumed
        assertTrue(queue.size() + consumed.size() >= itemsPerProducer * numProducers);
    }

    @Test
    public void testInvalidConfigurationThrowsException() {
        // maxSize <= 0
        assertThrows(ResilienceException.class, () -> {
            new TelemetryQueue(0);
        });

        assertThrows(ResilienceException.class, () -> {
            new TelemetryQueue(-1);
        });

        // persist=true but no path
        assertThrows(ResilienceException.class, () -> {
            new TelemetryQueue(100, true, null, null, null);
        });
    }

    @Test
    public void testDequeueBatchInvalidSizeThrowsException() {
        TelemetryQueue queue = new TelemetryQueue(100);

        assertThrows(ResilienceException.class, () -> {
            queue.dequeueBatch(0);
        });

        assertThrows(ResilienceException.class, () -> {
            queue.dequeueBatch(-1);
        });
    }

    @Test
    public void testPathValidationRejectsSensitiveDirs() {
        // Should reject /etc
        assertThrows(ResilienceException.class, () -> {
            new TelemetryQueue(100, true, "/etc/queue.json", null, null);
        });

        // Should reject /sys
        assertThrows(ResilienceException.class, () -> {
            new TelemetryQueue(100, true, "/sys/queue.json", null, null);
        });
    }

    @Test
    public void testShutdownGracefully(@TempDir Path tempDir) throws InterruptedException {
        String queuePath = tempDir.resolve("test-queue.json").toString();

        TelemetryQueue queue = new TelemetryQueue(100, true, queuePath, null, null);

        queue.enqueue("item1");
        queue.enqueue("item2");

        queue.shutdown(5000);

        // Queue should still be accessible after shutdown
        assertEquals(2, queue.size());
    }

    @Test
    public void testAtomicEnqueuePreventsDataLoss() throws InterruptedException {
        // Test the fix for race condition in enqueue()
        // Create small queue to force evictions
        TelemetryQueue queue = new TelemetryQueue(10);
        int numThreads = 20;
        int itemsPerThread = 50;

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        CountDownLatch latch = new CountDownLatch(numThreads);

        // All threads enqueue concurrently
        for (int t = 0; t < numThreads; t++) {
            int threadId = t;
            executor.submit(() -> {
                try {
                    for (int i = 0; i < itemsPerThread; i++) {
                        // This should NEVER fail - the atomic loop ensures success
                        boolean result = queue.enqueue("thread" + threadId + "-item" + i);
                        // Result tells us if eviction occurred, but item is always added
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(10, TimeUnit.SECONDS);
        executor.shutdown();

        // Queue should be exactly at max capacity (not less due to race conditions)
        assertEquals(10, queue.size());

        // Verify all items are valid (no nulls from failed offers)
        for (int i = 0; i < 10; i++) {
            String item = queue.dequeue();
            assertNotNull(item, "Queue should not contain null items from failed offers");
            assertTrue(item.startsWith("thread"), "Items should have expected format");
        }
    }
}
