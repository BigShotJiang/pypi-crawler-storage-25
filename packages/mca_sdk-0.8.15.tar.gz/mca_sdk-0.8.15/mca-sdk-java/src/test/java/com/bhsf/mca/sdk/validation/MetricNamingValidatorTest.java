package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.exceptions.ValidationException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MetricNamingValidatorTest {

    // Internal/regression model tests (model.* prefix)

    @Test
    public void testValidModelMetric_Regression() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertDoesNotThrow(() -> validator.validate("model.predictions_total"));
        assertDoesNotThrow(() -> validator.validate("model.latency_seconds"));
        assertDoesNotThrow(() -> validator.validate("model.accuracy_ratio"));
        assertDoesNotThrow(() -> validator.validate("model.error_count"));
    }

    @Test
    public void testInvalidPrefix_Regression_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("genai.requests_total");  // Wrong prefix
        });
    }

    @Test
    public void testInvalidSuffix_Regression_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.predictions_invalid");  // Wrong suffix
        });
    }

    // Internal/generative model tests (genai.* prefix)

    @Test
    public void testValidGenAIMetric() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "generative", true);

        assertDoesNotThrow(() -> validator.validate("genai.requests_total"));
        assertDoesNotThrow(() -> validator.validate("genai.latency_seconds"));
        assertDoesNotThrow(() -> validator.validate("genai.token_count"));
        assertDoesNotThrow(() -> validator.validate("genai.cost_dollars"));
        assertDoesNotThrow(() -> validator.validate("genai.cost_usd"));
    }

    // Internal/agentic model tests (agentic.* prefix)

    @Test
    public void testValidAgenticMetric() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "agentic", true);

        assertDoesNotThrow(() -> validator.validate("agentic.goals_total"));
        assertDoesNotThrow(() -> validator.validate("agentic.reasoning_seconds"));
        assertDoesNotThrow(() -> validator.validate("agentic.success_ratio"));
        assertDoesNotThrow(() -> validator.validate("agentic.tool_count"));
        assertDoesNotThrow(() -> validator.validate("agentic.cost_dollars"));
    }

    // Vendor model tests (vendor.* prefix)

    @Test
    public void testValidVendorMetric() {
        MetricNamingValidator validator = new MetricNamingValidator("vendor", "classification", true);

        assertDoesNotThrow(() -> validator.validate("vendor.predictions_total"));
        assertDoesNotThrow(() -> validator.validate("vendor.latency_seconds"));
        assertDoesNotThrow(() -> validator.validate("vendor.accuracy_ratio"));
    }

    // Metric name format tests

    @Test
    public void testMetricNameTooShort_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("ab");  // Only 2 chars, need 3
        });
    }

    @Test
    public void testMetricNameTooLong_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);
        String longName = "model." + "a".repeat(300) + "_total";

        assertThrows(ValidationException.class, () -> {
            validator.validate(longName);  // Over 256 chars
        });
    }

    @Test
    public void testMetricNameNull_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate(null);
        });
    }

    @Test
    public void testMetricNameEmpty_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("");
        });
    }

    @Test
    public void testMetricNameStartsWithoutLetter_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            validator.validate("1model.count");
        });
        assertEquals("Metric names must start with letter", ex.getMessage());
    }

    // Security tests

    @Test
    public void testDangerousCharacter_Quote_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.test'_total");  // Single quote
        });
    }

    @Test
    public void testDangerousCharacter_Semicolon_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.test;drop_total");  // Semicolon (injection risk)
        });
    }

    @Test
    public void testDangerousCharacter_Backtick_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.test`cmd`_total");  // Backtick (command injection)
        });
    }

    @Test
    public void testControlCharacter_ShouldThrow() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.test\n_total");  // Newline (control char)
        });
    }

    // Strict vs permissive mode tests

    @Test
    public void testStrictMode_RejectsInvalidPattern() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("custom_metric");  // Doesn't match model.* pattern
        });
    }

    @Test
    public void testPermissiveMode_AllowsAnyPattern() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", false);

        // Should not throw for custom pattern (after security checks)
        assertDoesNotThrow(() -> {
            validator.validate("custom.metric_total");
        });
    }

    @Test
    public void testPermissiveMode_StillRejectsDangerous() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", false);

        // Even in permissive mode, dangerous chars should be rejected
        assertThrows(ValidationException.class, () -> {
            validator.validate("metric;drop_total");  // Semicolon still dangerous
        });
    }

    @Test
    public void testStrictMode_RejectsHyphen() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        assertThrows(ValidationException.class, () -> {
            validator.validate("model.test-metric_total");  // Hyphen not allowed in strict
        });
    }

    @Test
    public void testPermissiveMode_AllowsHyphen() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", false);

        // Hyphen allowed in permissive mode (though won't match pattern)
        assertDoesNotThrow(() -> {
            validator.validate("test-metric");
        });
    }

    // Invalid taxonomy tests

    @Test
    public void testInvalidModelCategory_ShouldThrow() {
        assertThrows(ValidationException.class, () -> {
            new MetricNamingValidator("invalid", "regression", true);
        });
    }

    @Test
    public void testInvalidModelType_ShouldThrow() {
        assertThrows(ValidationException.class, () -> {
            new MetricNamingValidator("internal", "invalid_type", true);
        });
    }

    @Test
    public void testNullModelCategory_ShouldThrow() {
        assertThrows(ValidationException.class, () -> {
            new MetricNamingValidator(null, "regression", true);
        });
    }

    // Error message tests

    @Test
    public void testErrorMessage_ContainsExamples() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            validator.validate("invalid_name");
        });

        // Error message should contain examples
        assertTrue(ex.getMessage().contains("model.predictions_total"));
        assertTrue(ex.getMessage().contains("model.latency_seconds"));
    }

    @Test
    public void testErrorMessage_ContainsModelType() {
        MetricNamingValidator validator = new MetricNamingValidator("internal", "regression", true);

        ValidationException ex = assertThrows(ValidationException.class, () -> {
            validator.validate("invalid_name");
        });

        assertTrue(ex.getMessage().contains("regression"));
        assertTrue(ex.getMessage().contains("internal"));
    }
}
