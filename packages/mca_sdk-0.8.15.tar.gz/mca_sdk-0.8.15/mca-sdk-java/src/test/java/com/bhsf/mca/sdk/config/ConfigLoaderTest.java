package com.bhsf.mca.sdk.config;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;

public class ConfigLoaderTest {

    @Test
    public void testBuilderPrecedenceOverEnvAndFile() {
        MCAConfig config = ConfigLoader.load(new MCAConfig.Builder()
                .serviceName("builder-service")
                .useGcpAuth(true));

        assertEquals("builder-service", config.getServiceName());
        assertTrue(config.isUseGcpAuth());
        assertEquals(ConfigSource.BUILDER, config.getSource("serviceName"));
        assertEquals(ConfigSource.BUILDER, config.getSource("useGcpAuth"));
    }

    @Test
    public void testDefaultsAreRetainedWhenNotOverridden() {
        MCAConfig config = ConfigLoader.load(new MCAConfig.Builder());

        assertEquals("1.0.0", config.getModelVersion());
        assertEquals("http://localhost:4318", config.getOtelEndpoint());
        assertFalse(config.isUseGcpAuth());
        
        assertEquals(ConfigSource.DEFAULT, config.getSource("modelVersion"));
        assertEquals(ConfigSource.DEFAULT, config.getSource("otelEndpoint"));
        assertEquals(ConfigSource.DEFAULT, config.getSource("useGcpAuth"));
    }
}
