package com.bhsf.mca.sdk.registry.models;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ModelConfig.
 */
public class ModelConfigTest {

    @Test
    public void testBuilderWithRequiredFields() {
        ModelConfig config = ModelConfig.builder()
                .serviceName("test-service")
                .modelId("mdl-001")
                .modelVersion("1.0.0")
                .teamName("test-team")
                .modelType("regression")
                .modelCategory("internal")
                .build();

        assertEquals("test-service", config.getServiceName());
        assertEquals("mdl-001", config.getModelId());
        assertEquals("1.0.0", config.getModelVersion());
        assertEquals("test-team", config.getTeamName());
        assertEquals("regression", config.getModelType());
        assertEquals("internal", config.getModelCategory());
    }

    @Test
    public void testBuilderWithOptionalFields() {
        Map<String, Double> thresholds = new HashMap<>();
        thresholds.put("MAE", 12.5);
        thresholds.put("RMSE", 18.3);

        ModelConfig config = ModelConfig.builder()
                .serviceName("test-service")
                .modelId("mdl-001")
                .modelVersion("2.0.0")
                .teamName("test-team")
                .modelType("classification")
                .modelCategory("internal")
                .registryId("reg-001")
                .deploymentId("dep-001")
                .thresholds(thresholds)
                .build();

        assertEquals("reg-001", config.getRegistryId());
        assertEquals("dep-001", config.getDeploymentId());
        assertEquals(2, config.getThresholds().size());
        assertEquals(12.5, config.getThresholds().get("MAE"));
        assertEquals(18.3, config.getThresholds().get("RMSE"));
    }

    @Test
    public void testBuilderWithIndividualThreshold() {
        ModelConfig config = ModelConfig.builder()
                .serviceName("test-service")
                .modelId("mdl-001")
                .modelVersion("1.0.0")
                .teamName("test-team")
                .modelType("regression")
                .modelCategory("internal")
                .threshold("accuracy", 0.85)
                .threshold("latency_ms", 500.0)
                .build();

        assertEquals(2, config.getThresholds().size());
        assertEquals(0.85, config.getThresholds().get("accuracy"));
        assertEquals(500.0, config.getThresholds().get("latency_ms"));
    }

    @Test
    public void testMissingRequiredFieldThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            ModelConfig.builder()
                    // Missing serviceName
                    .modelId("mdl-001")
                    .modelVersion("1.0.0")
                    .teamName("test-team")
                    .modelType("regression")
                    .modelCategory("internal")
                    .build();
        });
    }

    @Test
    public void testEmptyRequiredFieldThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            ModelConfig.builder()
                    .serviceName("")  // Empty
                    .modelId("mdl-001")
                    .modelVersion("1.0.0")
                    .teamName("test-team")
                    .modelType("regression")
                    .modelCategory("internal")
                    .build();
        });
    }

    @Test
    public void testImmutability() {
        Map<String, Double> thresholds = new HashMap<>();
        thresholds.put("MAE", 12.5);

        ModelConfig config = ModelConfig.builder()
                .serviceName("test-service")
                .modelId("mdl-001")
                .modelVersion("1.0.0")
                .teamName("test-team")
                .modelType("regression")
                .modelCategory("internal")
                .thresholds(thresholds)
                .build();

        // Modify original map
        thresholds.put("RMSE", 18.3);

        // Config should not be affected
        assertEquals(1, config.getThresholds().size());
        assertNull(config.getThresholds().get("RMSE"));
    }

    @Test
    public void testGetThresholdsReturnsUnmodifiableMap() {
        ModelConfig config = ModelConfig.builder()
                .serviceName("test-service")
                .modelId("mdl-001")
                .modelVersion("1.0.0")
                .teamName("test-team")
                .modelType("regression")
                .modelCategory("internal")
                .threshold("MAE", 12.5)
                .build();

        assertThrows(UnsupportedOperationException.class, () -> {
            config.getThresholds().put("RMSE", 18.3);
        });
    }
}
