package com.bhsf.mca.sdk.exporters;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import com.bhsf.mca.sdk.gcp.GCPAuthFactory;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.logs.Severity;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.TraceFlags;
import io.opentelemetry.api.trace.TraceState;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.common.InstrumentationScopeInfo;
import io.opentelemetry.sdk.logs.data.Body;
import io.opentelemetry.sdk.logs.data.LogRecordData;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.data.StatusData;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import io.opentelemetry.sdk.logs.export.LogRecordExporter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import static org.junit.jupiter.api.Assumptions.assumeTrue;
import static org.junit.jupiter.api.Assumptions.assumeFalse;

import java.io.IOException;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for GCP exporters using Factory pattern.
 *
 * Note: These tests require optional GCP dependencies.
 * Tests gracefully skip when dependencies are not available.
 * Some tests are disabled unless GCP credentials are available.
 */
class GCPExportersTest {

    private static final String TEST_PROJECT_ID = "test-project-123";
    private static final String TEST_LOG_NAME = "test-log";

    private static final String VALID_SERVICE_ACCOUNT_JSON = """
            {
              "type": "service_account",
              "project_id": "test-project-123",
              "private_key_id": "key-id-123",
              "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASC\\n-----END PRIVATE KEY-----\\n",
              "client_email": "test@test-project-123.iam.gserviceaccount.com",
              "client_id": "123456789",
              "auth_uri": "https://accounts.google.com/o/oauth2/auth",
              "token_uri": "https://oauth2.googleapis.com/token",
              "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
              "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/test%40test-project-123.iam.gserviceaccount.com"
            }
            """;

    @Test
    void testGCPTraceExporterFactoryWithoutDependency() {
        // If dependency available, test constructor succeeds
        // If dependency not available, test throws ConfigurationException
        if (GCPTraceExporterFactory.isAvailable() && GCPAuthFactory.isAvailable()) {
            assumeTrue(true, "Dependencies available - constructor should work");
            try {
                Object mockCredentials = GCPAuthFactory.loadCredentials(null, VALID_SERVICE_ACCOUNT_JSON);
                SpanExporter exporter = GCPTraceExporterFactory.create(TEST_PROJECT_ID, mockCredentials);

                assertNotNull(exporter);
                exporter.shutdown();
            } catch (Exception e) {
                // Expected - may fail due to actual GCP API call or invalid credentials
                // What matters is it doesn't throw NoClassDefFoundError
            }
        } else {
            assumeFalse(GCPTraceExporterFactory.isAvailable(), "Trace library not available");
            // Test that it throws ConfigurationException with clear message
            ConfigurationException exception = assertThrows(
                    ConfigurationException.class,
                    () -> GCPTraceExporterFactory.create(TEST_PROJECT_ID, new Object())
            );
            assertTrue(exception.getMessage().contains("google-cloud-trace"));
        }
    }

    @Test
    void testGCPLoggingExporterFactoryWithoutDependency() {
        // If dependency available, test constructor succeeds
        // If dependency not available, test throws ConfigurationException
        if (GCPLoggingExporterFactory.isAvailable() && GCPAuthFactory.isAvailable()) {
            assumeTrue(true, "Dependencies available - constructor should work");
            try {
                Object mockCredentials = GCPAuthFactory.loadCredentials(null, VALID_SERVICE_ACCOUNT_JSON);
                LogRecordExporter exporter = GCPLoggingExporterFactory.create(
                        TEST_PROJECT_ID,
                        TEST_LOG_NAME,
                        mockCredentials
                );

                assertNotNull(exporter);
                exporter.shutdown();
            } catch (Exception e) {
                // Expected - may fail due to actual GCP API call
                // What matters is it doesn't throw NoClassDefFoundError
            }
        } else {
            assumeFalse(GCPLoggingExporterFactory.isAvailable(), "Logging library not available");
            // Test that it throws ConfigurationException with clear message
            ConfigurationException exception = assertThrows(
                    ConfigurationException.class,
                    () -> GCPLoggingExporterFactory.create(TEST_PROJECT_ID, TEST_LOG_NAME, new Object())
            );
            assertTrue(exception.getMessage().contains("google-cloud-logging"));
        }
    }

    @Test
    void testGCPTraceExporterInvalidProjectId() {
        // Skip if dependencies not available
        assumeTrue(GCPTraceExporterFactory.isAvailable() && GCPAuthFactory.isAvailable(),
                "GCP dependencies not available");

        try {
            Object credentials = GCPAuthFactory.loadCredentials(null, VALID_SERVICE_ACCOUNT_JSON);

            // Empty project ID should fail
            assertThrows(
                    ConfigurationException.class,
                    () -> GCPTraceExporterFactory.create("", credentials)
            );
        } catch (Exception e) {
            // Expected - validation should catch empty project ID
        }
    }

    @Test
    void testGCPTraceExporterMetrics() {
        // Skip if dependencies not available
        assumeTrue(GCPTraceExporterFactory.isAvailable() && GCPAuthFactory.isAvailable(),
                "GCP dependencies not available");

        try {
            Object credentials = GCPAuthFactory.loadCredentials(null, VALID_SERVICE_ACCOUNT_JSON);
            GCPTraceExporterFactory exporter = GCPTraceExporterFactory.create(TEST_PROJECT_ID, credentials);

            // Get initial metrics
            var metrics = exporter.getMetrics();
            assertNotNull(metrics);
            assertEquals(0L, metrics.get("spans_exported_total"));
            assertEquals(0L, metrics.get("spans_dropped_total"));
            assertEquals(0L, metrics.get("export_attempts_total"));

            exporter.shutdown();
        } catch (Exception e) {
            // Expected - may fail due to actual GCP API call
            // What matters is it doesn't crash with NoClassDefFoundError
        }
    }

    /**
     * Integration test - only runs if GCP_PROJECT_ID environment variable is set.
     */
    @Test
    @EnabledIfEnvironmentVariable(named = "GCP_PROJECT_ID", matches = ".+")
    void testGCPTraceExporterIntegration() {
        // Skip if dependencies not available
        assumeTrue(GCPTraceExporterFactory.isAvailable() && GCPAuthFactory.isAvailable(),
                "GCP dependencies not available");

        String projectId = System.getenv("GCP_PROJECT_ID");

        try {
            Object credentials = GCPAuthFactory.loadCredentials(null, null);
            SpanExporter exporter = GCPTraceExporterFactory.create(projectId, credentials);

            // Create mock span data
            SpanData mockSpan = createMockSpanData();

            // Export span (will fail without proper credentials, but tests constructor)
            CompletableResultCode result = exporter.export(Collections.singleton(mockSpan));

            // Don't assert success - may fail due to permissions
            assertNotNull(result);

            exporter.shutdown();
        } catch (Exception e) {
            // Integration tests may fail due to auth/network - that's okay
            System.err.println("Integration test skipped: " + e.getMessage());
        }
    }

    /**
     * Integration test - only runs if GCP_PROJECT_ID environment variable is set.
     */
    @Test
    @EnabledIfEnvironmentVariable(named = "GCP_PROJECT_ID", matches = ".+")
    void testGCPLoggingExporterIntegration() {
        // Skip if dependencies not available
        assumeTrue(GCPLoggingExporterFactory.isAvailable() && GCPAuthFactory.isAvailable(),
                "GCP dependencies not available");

        String projectId = System.getenv("GCP_PROJECT_ID");

        try {
            Object credentials = GCPAuthFactory.loadCredentials(null, null);
            LogRecordExporter exporter = GCPLoggingExporterFactory.create(
                    projectId,
                    "test-integration-log",
                    credentials
            );

            // Create mock log record
            LogRecordData mockLog = createMockLogRecordData();

            // Export log (will fail without proper credentials, but tests constructor)
            CompletableResultCode result = exporter.export(Collections.singleton(mockLog));

            // Don't assert success - may fail due to permissions
            assertNotNull(result);

            exporter.shutdown();
        } catch (Exception e) {
            // Integration tests may fail due to auth/network - that's okay
            System.err.println("Integration test skipped: " + e.getMessage());
        }
    }

    // Helper methods to create mock data

    private SpanData createMockSpanData() {
        return new SpanData() {
            @Override
            public String getName() {
                return "test-span";
            }

            @Override
            public SpanKind getKind() {
                return SpanKind.INTERNAL;
            }

            @Override
            public io.opentelemetry.api.trace.SpanContext getSpanContext() {
                return io.opentelemetry.api.trace.SpanContext.create(
                        "00000000000000000000000000000001",
                        "0000000000000001",
                        TraceFlags.getDefault(),
                        TraceState.getDefault()
                );
            }

            @Override
            public io.opentelemetry.api.trace.SpanContext getParentSpanContext() {
                return io.opentelemetry.api.trace.SpanContext.getInvalid();
            }

            @Override
            public StatusData getStatus() {
                return StatusData.ok();
            }

            @Override
            public long getStartEpochNanos() {
                return TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis());
            }

            @Override
            public Attributes getAttributes() {
                return Attributes.of(AttributeKey.stringKey("test.key"), "test-value");
            }

            @Override
            public java.util.List<io.opentelemetry.sdk.trace.data.EventData> getEvents() {
                return Collections.emptyList();
            }

            @Override
            public java.util.List<io.opentelemetry.sdk.trace.data.LinkData> getLinks() {
                return Collections.emptyList();
            }

            @Override
            public long getEndEpochNanos() {
                return getStartEpochNanos() + TimeUnit.MILLISECONDS.toNanos(100);
            }

            @Override
            public boolean hasEnded() {
                return true;
            }

            @Override
            public int getTotalRecordedEvents() {
                return 0;
            }

            @Override
            public int getTotalRecordedLinks() {
                return 0;
            }

            @Override
            public int getTotalAttributeCount() {
                return 1;
            }

            @Override
            public InstrumentationScopeInfo getInstrumentationScopeInfo() {
                return InstrumentationScopeInfo.create("test");
            }

            @Override
            public Resource getResource() {
                return Resource.empty();
            }
        };
    }

    private LogRecordData createMockLogRecordData() {
        return new LogRecordData() {
            @Override
            public Resource getResource() {
                return Resource.empty();
            }

            @Override
            public InstrumentationScopeInfo getInstrumentationScopeInfo() {
                return InstrumentationScopeInfo.create("test");
            }

            @Override
            public long getTimestampEpochNanos() {
                return TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis());
            }

            @Override
            public long getObservedTimestampEpochNanos() {
                return getTimestampEpochNanos();
            }

            @Override
            public io.opentelemetry.api.trace.SpanContext getSpanContext() {
                return io.opentelemetry.api.trace.SpanContext.getInvalid();
            }

            @Override
            public Severity getSeverity() {
                return Severity.INFO;
            }

            @Override
            public String getSeverityText() {
                return "INFO";
            }

            @Override
            public Body getBody() {
                return Body.string("Test log message");
            }

            @Override
            public Attributes getAttributes() {
                return Attributes.of(AttributeKey.stringKey("log.key"), "log-value");
            }

            @Override
            public int getTotalAttributeCount() {
                return 1;
            }
        };
    }
}
