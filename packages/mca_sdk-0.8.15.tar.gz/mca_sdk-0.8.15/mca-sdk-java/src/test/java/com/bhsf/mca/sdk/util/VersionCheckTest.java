package com.bhsf.mca.sdk.util;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for VersionCheck utility.
 *
 * <p>Note: These tests primarily test parsing logic. Full HTTP integration
 * tests would require MockWebServer, which is beyond the scope of unit tests.
 */
class VersionCheckTest {

    @Test
    void testCheckVersionAsyncDoesNotThrow() {
        // Should not throw even if network is unavailable
        assertDoesNotThrow(() -> VersionCheck.checkVersionAsync("0.2.0"));
    }

    @Test
    void testCheckVersionWithTimeout() {
        // This will fail to connect but should handle gracefully
        VersionCheck.VersionInfo info = VersionCheck.checkVersion("0.2.0",
            Duration.ofMillis(100));

        // Should return null on failure
        assertNull(info);
    }

    @Test
    void testVersionInfoCreation() {
        VersionCheck.VersionInfo info = new VersionCheck.VersionInfo(
            "0.3.0", "0.2.0", true, 45);

        assertEquals("0.3.0", info.getLatestVersion());
        assertEquals("0.2.0", info.getCurrentVersion());
        assertTrue(info.isOutdated());
        assertEquals(45, info.getAgeDays());
    }

    @Test
    void testVersionInfoNotOutdated() {
        VersionCheck.VersionInfo info = new VersionCheck.VersionInfo(
            "0.2.0", "0.2.0", false, 5);

        assertEquals("0.2.0", info.getLatestVersion());
        assertEquals("0.2.0", info.getCurrentVersion());
        assertFalse(info.isOutdated());
        assertEquals(5, info.getAgeDays());
    }

    @Test
    void testVersionInfoDifferentVersionButRecent() {
        // Different version but released recently (within 30 days)
        VersionCheck.VersionInfo info = new VersionCheck.VersionInfo(
            "0.3.0", "0.2.0", false, 10);

        assertEquals("0.3.0", info.getLatestVersion());
        assertEquals("0.2.0", info.getCurrentVersion());
        assertFalse(info.isOutdated());
    }

    @Test
    void testVersionCheckOutdatedThreshold() {
        // Version different and older than 30 days = outdated
        VersionCheck.VersionInfo info = new VersionCheck.VersionInfo(
            "0.3.0", "0.2.0", true, 35);

        assertTrue(info.isOutdated());
        assertEquals(35, info.getAgeDays());
    }

    // Mock response parsing test (if we implement parseVersionInfo as package-private for testing)
    // This would require refactoring parseVersionInfo to be testable
    // For now, we rely on integration tests with MockWebServer

    @Test
    void testCheckVersionWithVeryShortTimeout() {
        // Test that timeout is respected
        long start = System.currentTimeMillis();
        VersionCheck.VersionInfo info = VersionCheck.checkVersion("0.2.0",
            Duration.ofMillis(10));
        long elapsed = System.currentTimeMillis() - start;

        assertNull(info);
        // Should fail quickly (within reasonable time)
        assertTrue(elapsed < 5000, "Should timeout quickly");
    }

    @Test
    void testCheckVersionWithReasonableTimeout() {
        // Test with reasonable timeout
        VersionCheck.VersionInfo info = VersionCheck.checkVersion("0.2.0",
            Duration.ofSeconds(2));

        // Will likely be null unless Maven Central is reachable
        // This is acceptable for unit tests
        // (Integration tests would use MockWebServer)
        if (info != null) {
            assertNotNull(info.getLatestVersion());
            assertNotNull(info.getCurrentVersion());
        }
    }

    @Test
    void testVersionComparisonLogic() {
        // Same version = not outdated (even if old)
        VersionCheck.VersionInfo sameVersion = new VersionCheck.VersionInfo(
            "0.2.0", "0.2.0", false, 100);
        assertFalse(sameVersion.isOutdated());

        // Different version + old = outdated
        VersionCheck.VersionInfo oldVersion = new VersionCheck.VersionInfo(
            "0.3.0", "0.2.0", true, 40);
        assertTrue(oldVersion.isOutdated());

        // Different version + recent = not outdated
        VersionCheck.VersionInfo recentVersion = new VersionCheck.VersionInfo(
            "0.3.0", "0.2.0", false, 20);
        assertFalse(recentVersion.isOutdated());
    }
}
