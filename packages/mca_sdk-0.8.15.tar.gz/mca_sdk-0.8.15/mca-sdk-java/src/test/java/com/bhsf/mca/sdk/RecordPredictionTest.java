package com.bhsf.mca.sdk;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Unit tests for RecordPredictionRequest and recordPrediction() method.
 */
public class RecordPredictionTest {

    private MCAClient client;

    @AfterEach
    public void tearDown() {
        if (client != null) {
            client.shutdown(5000);
        }
    }

    @Test
    public void testRecordPredictionRequestBuilder() {
        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.15)
                .build();

        assertEquals(0.15, request.getLatency(), 0.001);
        assertNotNull(request.getPredictionId(), "Prediction ID should be auto-generated");
        assertTrue(request.getPredictionId().startsWith("pred-"),
                "Auto-generated ID should have pred- prefix");
    }

    @Test
    public void testRecordPredictionRequestWithCustomId() {
        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.25)
                .predictionId("custom-pred-123")
                .build();

        assertEquals(0.25, request.getLatency(), 0.001);
        assertEquals("custom-pred-123", request.getPredictionId());
    }

    @Test
    public void testRecordPredictionRequestWithAttributes() {
        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.10)
                .attribute("model_version", "2.0")
                .attribute("patient_age", 45)
                .attribute("confidence", 0.95)
                .build();

        assertEquals(0.10, request.getLatency(), 0.001);
        assertEquals(3, request.getAttributes().size());
        assertEquals("2.0", request.getAttributes().get("model_version"));
        assertEquals(45, request.getAttributes().get("patient_age"));
        assertEquals(0.95, request.getAttributes().get("confidence"));
    }

    @Test
    public void testRecordPredictionRequestWithAttributesMap() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("environment", "production");
        attrs.put("request_count", 100);

        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.20)
                .attributes(attrs)
                .build();

        assertEquals(0.20, request.getLatency(), 0.001);
        assertEquals(2, request.getAttributes().size());
        assertEquals("production", request.getAttributes().get("environment"));
        assertEquals(100, request.getAttributes().get("request_count"));
    }

    @Test
    public void testRecordPredictionRequestRejectsNegativeLatency() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RecordPredictionRequest.builder()
                    .latency(-0.5)
                    .build();
        });

        assertTrue(exception.getMessage().contains("non-negative"),
                "Error message should mention non-negative");
    }

    @Test
    public void testRecordPredictionRequestRejectsNullAttributeKey() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RecordPredictionRequest.builder()
                    .latency(0.15)
                    .attribute(null, "value")
                    .build();
        });

        assertTrue(exception.getMessage().contains("key"),
                "Error message should mention key");
    }

    @Test
    public void testRecordPredictionRequestRejectsEmptyAttributeKey() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RecordPredictionRequest.builder()
                    .latency(0.15)
                    .attribute("", "value")
                    .build();
        });

        assertTrue(exception.getMessage().contains("key"),
                "Error message should mention key");
    }

    @Test
    public void testRecordPredictionMethodCreatesMetrics() {
        // AC 2: recordPrediction creates metrics and logs
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.15)
                .predictionId("pred-123")
                .attribute("model_version", "1.0")
                .build();

        // Should not throw
        assertDoesNotThrow(() -> {
            client.recordPrediction(request);
        }, "Recording prediction should not throw exception");
    }

    @Test
    public void testRecordPredictionRejectsNullRequest() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            client.recordPrediction(null);
        });

        assertTrue(exception.getMessage().contains("cannot be null"),
                "Error message should mention null");
    }

    @Test
    public void testRecordPredictionAfterShutdown() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        client.shutdown(5000);

        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.15)
                .build();

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            client.recordPrediction(request);
        });

        assertTrue(exception.getMessage().contains("shut down"),
                "Error message should mention shutdown");
    }

    @Test
    public void testRecordPredictionRequestRequiresLatency() {
        // Building without setting latency should fail
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            RecordPredictionRequest.builder()
                    .predictionId("pred-123")
                    .build();
        });

        assertTrue(exception.getMessage().contains("Latency"),
                "Error message should mention latency requirement");
    }

    @Test
    public void testRecordMultiplePredictions() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .modelId("mdl-001")
                .build();

        // Record multiple predictions
        for (int i = 0; i < 10; i++) {
            RecordPredictionRequest request = RecordPredictionRequest.builder()
                    .latency(0.1 + (i * 0.01))
                    .attribute("iteration", i)
                    .build();

            assertDoesNotThrow(() -> {
                client.recordPrediction(request);
            });
        }
    }

    @Test
    public void testRecordPredictionWithAllAttributeTypes() {
        client = new MCAClient.Builder()
                .serviceName("test-model")
                .build();

        RecordPredictionRequest request = RecordPredictionRequest.builder()
                .latency(0.15)
                .attribute("string_attr", "value")
                .attribute("int_attr", 42)
                .attribute("long_attr", 1000L)
                .attribute("double_attr", 3.14)
                .attribute("float_attr", 2.71f)
                .attribute("boolean_attr", true)
                .build();

        assertDoesNotThrow(() -> {
            client.recordPrediction(request);
        }, "Should handle all attribute types");
    }
}
