package com.bhsf.mca.sdk.util;

import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Serialization utility.
 */
class SerializationTest {

    // toJson Tests

    @Test
    void testToJsonNull() {
        assertNull(Serialization.toJson(null));
    }

    @Test
    void testToJsonString() {
        String text = "Hello world";
        String result = Serialization.toJson(text);
        assertEquals(text, result);
    }

    @Test
    void testToJsonPrimitives() {
        assertEquals("42", Serialization.toJson(42));
        assertEquals("3.14", Serialization.toJson(3.14));
        assertEquals("true", Serialization.toJson(true));
    }

    @Test
    void testToJsonMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("name", "John");
        map.put("age", 30);

        String result = Serialization.toJson(map);

        assertNotNull(result);
        assertTrue(result.contains("\"name\""));
        assertTrue(result.contains("\"John\""));
        assertTrue(result.contains("\"age\""));
    }

    @Test
    void testToJsonList() {
        List<String> list = Arrays.asList("apple", "banana", "cherry");

        String result = Serialization.toJson(list);

        assertNotNull(result);
        assertTrue(result.contains("apple"));
        assertTrue(result.contains("banana"));
        assertTrue(result.contains("cherry"));
    }

    // toJsonSafe Tests

    @Test
    void testToJsonSafeWithSizeLimit() {
        String longString = "x".repeat(15000); // 15KB

        String result = Serialization.toJsonSafe(longString, 1000);

        assertNotNull(result);
        assertTrue(result.length() <= 1000);
        assertTrue(result.contains("...[truncated]"));
    }

    @Test
    void testToJsonSafeLargeCollection() {
        List<Integer> largeList = new ArrayList<>();
        for (int i = 0; i < 150000; i++) {
            largeList.add(i);
        }

        String result = Serialization.toJsonSafe(largeList, 10000);

        assertNotNull(result);
        assertTrue(result.contains("Collection too large"));
        assertTrue(result.contains("150000 items"));
        assertTrue(result.contains("100000"));
    }

    @Test
    void testToJsonSafeLargeMap() {
        Map<String, Integer> largeMap = new HashMap<>();
        for (int i = 0; i < 150000; i++) {
            largeMap.put("key" + i, i);
        }

        String result = Serialization.toJsonSafe(largeMap, 10000);

        assertNotNull(result);
        assertTrue(result.contains("Map too large"));
        assertTrue(result.contains("150000 entries"));
    }

    @Test
    void testToJsonSafeNonSerializableObject() {
        // Create object with custom toString
        Object customObj = new Object() {
            @Override
            public String toString() {
                return "CustomObject[id=123]";
            }
        };

        String result = Serialization.toJsonSafe(customObj, 1000);

        assertNotNull(result);
        // Should fall back to toString()
        assertTrue(result.contains("CustomObject") || result.contains("123"));
    }

    @Test
    void testToJsonSafeUtf8Truncation() {
        // Create string with multi-byte UTF-8 characters
        String utf8String = "Hello 世界 " + "x".repeat(10000);

        String result = Serialization.toJsonSafe(utf8String, 100);

        assertNotNull(result);
        assertTrue(result.length() <= 100);
        assertTrue(result.endsWith("...[truncated]"));
        // Should not have invalid UTF-8 sequences
        assertFalse(result.contains("\uFFFD"));
    }

    // extractShape Tests

    @Test
    void testExtractShapeNull() {
        assertNull(Serialization.extractShape(null));
    }

    @Test
    void testExtractShapeList() {
        List<String> list = Arrays.asList("a", "b", "c", "d", "e");

        String shape = Serialization.extractShape(list);

        assertEquals("(5,)", shape);
    }

    @Test
    void testExtractShapeArray() {
        int[] array = {1, 2, 3, 4, 5};

        String shape = Serialization.extractShape(array);

        assertEquals("(5,)", shape);
    }

    @Test
    void testExtractShapeObjectArray() {
        String[] array = {"apple", "banana", "cherry"};

        String shape = Serialization.extractShape(array);

        assertEquals("(3,)", shape);
    }

    @Test
    void testExtractShapeMap() {
        Map<String, Integer> map = new HashMap<>();
        map.put("a", 1);
        map.put("b", 2);
        map.put("c", 3);

        String shape = Serialization.extractShape(map);

        assertEquals("(3 entries)", shape);
    }

    @Test
    void testExtractShapeEmptyCollection() {
        assertEquals("(0,)", Serialization.extractShape(new ArrayList<>()));
        assertEquals("(0 entries)", Serialization.extractShape(new HashMap<>()));
    }

    @Test
    void testExtractShapeString() {
        // String is not a collection, should return null
        assertNull(Serialization.extractShape("Hello"));
    }

    @Test
    void testExtractShapePrimitive() {
        assertNull(Serialization.extractShape(42));
        assertNull(Serialization.extractShape(3.14));
    }

    // Integration Tests

    @Test
    void testComplexNestedObject() {
        Map<String, Object> complex = new HashMap<>();
        complex.put("name", "Test");
        complex.put("values", Arrays.asList(1, 2, 3));
        complex.put("metadata", Map.of("key", "value"));

        String json = Serialization.toJson(complex);

        assertNotNull(json);
        assertTrue(json.contains("name"));
        assertTrue(json.contains("values"));
        assertTrue(json.contains("metadata"));
    }

    @Test
    void testTruncationPreservesJsonStructure() {
        Map<String, String> data = new HashMap<>();
        data.put("field1", "value1");
        data.put("field2", "x".repeat(10000));

        String result = Serialization.toJsonSafe(data, 500);

        assertNotNull(result);
        assertTrue(result.length() <= 500);
        // Should still start like JSON (though truncated)
        assertTrue(result.startsWith("{") || result.contains("field"));
    }

    @Test
    void testSmallObjectNotTruncated() {
        Map<String, String> data = Map.of("key", "value");

        String result = Serialization.toJsonSafe(data, 10000);

        assertNotNull(result);
        assertFalse(result.contains("...[truncated]"));
        assertTrue(result.contains("key"));
        assertTrue(result.contains("value"));
    }
}
