package com.bhsf.mca.sdk.security;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for QueueEncryption (AES-256-GCM).
 */
public class QueueEncryptionTest {

    private SecretKey secretKey;
    private QueueEncryption encryption;

    @BeforeEach
    public void setUp() {
        secretKey = EncryptionManager.createSecretKey(EncryptionManager.generateKey());
        encryption = new QueueEncryption(secretKey);
    }

    @Test
    public void testEncryptDecryptRoundTrip() {
        byte[] plaintext = "sensitive data".getBytes(StandardCharsets.UTF_8);

        byte[] encrypted = encryption.encrypt(plaintext);
        byte[] decrypted = encryption.decrypt(encrypted);

        assertArrayEquals(plaintext, decrypted);
    }

    @Test
    public void testEncryptDecryptEmptyData() {
        byte[] plaintext = new byte[0];

        byte[] encrypted = encryption.encrypt(plaintext);
        byte[] decrypted = encryption.decrypt(encrypted);

        assertArrayEquals(plaintext, decrypted);
    }

    @Test
    public void testEncryptDecryptLargeData() {
        byte[] plaintext = new byte[10000];
        for (int i = 0; i < plaintext.length; i++) {
            plaintext[i] = (byte) (i % 256);
        }

        byte[] encrypted = encryption.encrypt(plaintext);
        byte[] decrypted = encryption.decrypt(encrypted);

        assertArrayEquals(plaintext, decrypted);
    }

    @Test
    public void testEncryptProducesUniqueIVs() {
        byte[] plaintext = "same data".getBytes(StandardCharsets.UTF_8);

        byte[] encrypted1 = encryption.encrypt(plaintext);
        byte[] encrypted2 = encryption.encrypt(plaintext);

        // Encrypted data should be different due to different IVs
        assertFalse(java.util.Arrays.equals(encrypted1, encrypted2));
    }

    @Test
    public void testDecryptWithWrongKey() {
        byte[] plaintext = "sensitive data".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = encryption.encrypt(plaintext);

        // Create different encryption instance with different key
        SecretKey differentKey = EncryptionManager.createSecretKey(EncryptionManager.generateKey());
        QueueEncryption differentEncryption = new QueueEncryption(differentKey);

        // Should throw SecurityException
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> differentEncryption.decrypt(encrypted)
        );
        assertTrue(exception.getMessage().contains("Decryption failed"));
    }

    @Test
    public void testDecryptTamperedData() {
        byte[] plaintext = "sensitive data".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = encryption.encrypt(plaintext);

        // Tamper with the ciphertext (modify a byte in the middle)
        encrypted[encrypted.length / 2] ^= 0xFF;

        // Should throw SecurityException due to authentication tag mismatch
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> encryption.decrypt(encrypted)
        );
        assertTrue(exception.getMessage().contains("authentication tag mismatch") ||
                   exception.getMessage().contains("Decryption failed"));
    }

    @Test
    public void testDecryptTamperedIV() {
        byte[] plaintext = "sensitive data".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = encryption.encrypt(plaintext);

        // Tamper with the IV (first 12 bytes)
        encrypted[5] ^= 0xFF;

        // Should throw SecurityException
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> encryption.decrypt(encrypted)
        );
        assertTrue(exception.getMessage().contains("authentication tag mismatch") ||
                   exception.getMessage().contains("Decryption failed"));
    }

    @Test
    public void testEncryptNullData() {
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> encryption.encrypt(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testDecryptNullData() {
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> encryption.decrypt(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testDecryptDataTooShort() {
        byte[] tooShort = new byte[10]; // Less than IV length (12 bytes)

        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> encryption.decrypt(tooShort)
        );
        assertTrue(exception.getMessage().contains("too short"));
    }

    @Test
    public void testConstructorWithNullKey() {
        SecurityException exception = assertThrows(
            SecurityException.class,
            () -> new QueueEncryption(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testEncryptedDataLongerThanPlaintext() {
        byte[] plaintext = "data".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = encryption.encrypt(plaintext);

        // Encrypted should be longer: IV (12 bytes) + ciphertext + tag (16 bytes)
        assertTrue(encrypted.length > plaintext.length);
        // Should be at least IV + plaintext + tag
        assertTrue(encrypted.length >= 12 + plaintext.length + 16);
    }

    @Test
    public void testEncryptionIsAuthenticated() {
        byte[] plaintext = "authenticated data".getBytes(StandardCharsets.UTF_8);
        byte[] encrypted = encryption.encrypt(plaintext);

        // Modify last byte (part of authentication tag)
        encrypted[encrypted.length - 1] ^= 0xFF;

        // Decryption should fail due to authentication
        assertThrows(SecurityException.class, () -> encryption.decrypt(encrypted));
    }
}
