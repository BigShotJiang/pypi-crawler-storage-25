package com.bhsf.mca.sdk.resilience;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for RetryPolicy.
 */
public class RetryPolicyTest {

    @Test
    public void testSuccessfulOperationOnFirstAttempt() throws Exception {
        RetryPolicy policy = new RetryPolicy(3, 1.0, 10.0);

        String result = policy.executeWithRetry(() -> "success");

        assertEquals("success", result);
    }

    @Test
    public void testRetryOnFailureThenSuccess() throws Exception {
        RetryPolicy policy = new RetryPolicy(3, 0.1, 1.0);
        AtomicInteger attempts = new AtomicInteger(0);

        String result = policy.executeWithRetry(() -> {
            int attempt = attempts.getAndIncrement();
            if (attempt < 2) {
                throw new RuntimeException("Transient failure");
            }
            return "success after retries";
        });

        assertEquals("success after retries", result);
        assertEquals(3, attempts.get()); // 2 failures + 1 success
    }

    @Test
    public void testMaxRetriesExhausted() {
        RetryPolicy policy = new RetryPolicy(2, 0.1, 1.0);
        AtomicInteger attempts = new AtomicInteger(0);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            policy.executeWithRetry(() -> {
                attempts.getAndIncrement();
                throw new RuntimeException("Always fails");
            });
        });

        assertEquals("Always fails", exception.getMessage());
        assertEquals(3, attempts.get()); // Initial + 2 retries
    }

    @Test
    public void testExponentialBackoffDelayCalculation() {
        RetryPolicy policy = new RetryPolicy(3, 1.0, 60.0);

        // First retry: baseDelay * 2^0 = 1.0
        double delay0 = policy.calculateDelay(0);
        assertTrue(delay0 >= 0.5 && delay0 <= 1.0, "Delay with jitter should be between 0.5 and 1.0");

        // Second retry: baseDelay * 2^1 = 2.0
        double delay1 = policy.calculateDelay(1);
        assertTrue(delay1 >= 1.0 && delay1 <= 2.0, "Delay with jitter should be between 1.0 and 2.0");

        // Third retry: baseDelay * 2^2 = 4.0
        double delay2 = policy.calculateDelay(2);
        assertTrue(delay2 >= 2.0 && delay2 <= 4.0, "Delay with jitter should be between 2.0 and 4.0");
    }

    @Test
    public void testMaxDelayIsCapped() {
        RetryPolicy policy = new RetryPolicy(10, 1.0, 5.0);

        // After many attempts, delay should be capped at maxDelay
        double delay = policy.calculateDelay(10);
        assertTrue(delay <= 5.0, "Delay should be capped at maxDelay");
    }

    @Test
    public void testInvalidConfigurationThrowsException() {
        // maxRetries < 0
        assertThrows(ConfigurationException.class, () -> {
            new RetryPolicy(-1, 1.0, 10.0);
        });

        // baseDelay <= 0
        assertThrows(ConfigurationException.class, () -> {
            new RetryPolicy(3, 0, 10.0);
        });

        // maxDelay < baseDelay
        assertThrows(ConfigurationException.class, () -> {
            new RetryPolicy(3, 10.0, 5.0);
        });
    }

    @Test
    public void testZeroRetriesFailsImmediately() {
        RetryPolicy policy = new RetryPolicy(0, 1.0, 10.0);
        AtomicInteger attempts = new AtomicInteger(0);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            policy.executeWithRetry(() -> {
                attempts.getAndIncrement();
                throw new RuntimeException("Immediate failure");
            });
        });

        assertEquals("Immediate failure", exception.getMessage());
        assertEquals(1, attempts.get()); // Only initial attempt, no retries
    }

    @Test
    public void testGetters() {
        RetryPolicy policy = new RetryPolicy(3, 1.5, 30.0);

        assertEquals(3, policy.getMaxRetries());
        assertEquals(1.5, policy.getBaseDelay());
        assertEquals(30.0, policy.getMaxDelay());
        assertNull(policy.getDeadLetterQueue());
    }

    @Test
    public void testDLQIntegration(@TempDir Path tempDir) throws Exception {
        // Create DLQ
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        // Create retry policy with DLQ
        RetryPolicy policy = new RetryPolicy(2, 0.1, 1.0, dlq);
        AtomicInteger attempts = new AtomicInteger(0);

        // Execute operation that always fails
        assertThrows(RuntimeException.class, () -> {
            policy.executeWithRetry(() -> {
                attempts.getAndIncrement();
                throw new RuntimeException("Permanent failure");
            });
        });

        // Verify item was enqueued to DLQ
        assertEquals(1, dlq.size());
        assertEquals(3, attempts.get()); // Initial + 2 retries

        // Verify DLQ getter
        assertEquals(dlq, policy.getDeadLetterQueue());
    }

    @Test
    public void testExecuteWithFallbackSuccess() throws Exception {
        RetryPolicy policy = new RetryPolicy(2, 0.1, 1.0);

        // Primary succeeds on first attempt
        String result = policy.executeWithFallback(
                () -> "primary success",
                () -> "fallback"
        );

        assertEquals("primary success", result);
    }

    @Test
    public void testExecuteWithFallbackUsedAfterRetries() throws Exception {
        RetryPolicy policy = new RetryPolicy(2, 0.1, 1.0);
        AtomicInteger attempts = new AtomicInteger(0);

        // Primary always fails, fallback succeeds
        String result = policy.executeWithFallback(
                () -> {
                    attempts.getAndIncrement();
                    throw new RuntimeException("Primary failed");
                },
                () -> "fallback success"
        );

        assertEquals("fallback success", result);
        assertEquals(3, attempts.get()); // All retries exhausted
    }

    @Test
    public void testExecuteWithFallbackBothFail() {
        RetryPolicy policy = new RetryPolicy(2, 0.1, 1.0);

        // Both primary and fallback fail
        assertThrows(RuntimeException.class, () -> {
            policy.executeWithFallback(
                    () -> {
                        throw new RuntimeException("Primary failed");
                    },
                    () -> {
                        throw new RuntimeException("Fallback also failed");
                    }
            );
        });
    }

    @Test
    public void testNullDLQDoesNotCauseCrash() throws Exception {
        // Create policy with null DLQ
        RetryPolicy policy = new RetryPolicy(1, 0.1, 1.0, null);

        // Should handle null DLQ gracefully
        assertThrows(RuntimeException.class, () -> {
            policy.executeWithRetry(() -> {
                throw new RuntimeException("Failure");
            });
        });

        assertNull(policy.getDeadLetterQueue());
    }
}
