package com.bhsf.mca.sdk.exceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MCAException credential sanitization.
 */
class MCAExceptionTest {

    @AfterEach
    void cleanupEnvironment() {
        // Clear environment variable to avoid test pollution
        // Note: Cannot actually clear env vars in Java, but this documents the intent
    }

    @Test
    void testBasicExceptionMessage() {
        MCAException exception = new MCAException("Simple error message");
        assertEquals("Simple error message", exception.getMessage());
    }

    @Test
    void testExceptionWithCause() {
        RuntimeException cause = new RuntimeException("Root cause");
        MCAException exception = new MCAException("Wrapped error", cause);

        assertEquals("Wrapped error", exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    void testAwsKeyMasking() {
        String awsKey = "AKIAIOSFODNN7EXAMPLE";
        MCAException exception = new MCAException("Failed to authenticate with key " + awsKey);

        String message = exception.getMessage();
        assertFalse(message.contains(awsKey), "AWS key should be masked");
        assertTrue(message.contains("AKIA"), "AWS prefix should be visible");
        assertTrue(message.contains("***"), "Masking marker should be present");
    }

    @Test
    void testGcpKeyMasking() {
        String gcpKey = "AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q";
        MCAException exception = new MCAException("Invalid GCP key: " + gcpKey);

        String message = exception.getMessage();
        assertFalse(message.contains(gcpKey), "GCP key should be masked");
        assertTrue(message.contains("AIzaSy"), "GCP prefix should be visible");
        assertTrue(message.contains("***"), "Masking marker should be present");
    }

    @Test
    void testJwtTokenMasking() {
        String jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        MCAException exception = new MCAException("Token validation failed: " + jwt);

        String message = exception.getMessage();
        assertFalse(message.contains(jwt), "JWT should be masked");
        assertTrue(message.contains("eyJ"), "JWT prefix should be visible");
        assertTrue(message.contains("***"), "Masking marker should be present");
    }

    @Test
    void testBearerTokenMasking() {
        String bearer = "Bearer abc123token456xyz789012345";
        MCAException exception = new MCAException("Auth failed with " + bearer);

        String message = exception.getMessage();
        assertFalse(message.contains("abc123token456xyz789012345"), "Bearer token should be masked");
        assertTrue(message.contains("Bearer"), "Bearer prefix should be visible");
        assertTrue(message.contains("***"), "Masking marker should be present");
    }

    @Test
    void testMultipleCredentialsMasked() {
        String awsKey = "AKIAIOSFODNN7EXAMPLE";
        String gcpKey = "AIzaSyA1B2C3D4E5F6G7H8I9J0K1L2M3N4O5P6Q";
        MCAException exception = new MCAException(
            "Multiple credentials: AWS=" + awsKey + ", GCP=" + gcpKey);

        String message = exception.getMessage();
        assertFalse(message.contains(awsKey), "AWS key should be masked");
        assertFalse(message.contains(gcpKey), "GCP key should be masked");
        assertTrue(message.contains("AKIA"), "AWS prefix should be visible");
        assertTrue(message.contains("AIzaSy"), "GCP prefix should be visible");
    }

    @Test
    void testNullMessage() {
        MCAException exception = new MCAException(null);
        assertNull(exception.getMessage());
    }

    @Test
    void testMessageWithoutCredentials() {
        String message = "This is a safe error message with no credentials";
        MCAException exception = new MCAException(message);
        assertEquals(message, exception.getMessage());
    }
}
