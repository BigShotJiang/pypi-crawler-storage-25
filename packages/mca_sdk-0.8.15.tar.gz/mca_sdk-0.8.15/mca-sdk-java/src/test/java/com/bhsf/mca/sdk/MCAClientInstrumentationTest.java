package com.bhsf.mca.sdk;

import com.bhsf.mca.sdk.exceptions.ValidationException;
import com.bhsf.mca.sdk.instrumentation.SpanManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for MCAClient advanced instrumentation methods (Story 1.23.6).
 */
public class MCAClientInstrumentationTest {

    private MCAClient client;

    @BeforeEach
    public void setUp() {
        client = new MCAClient.Builder()
                .serviceName("test-instrumentation-service")
                .modelId("mdl-test")
                .teamName("test-team")
                .build();
    }

    @AfterEach
    public void tearDown() {
        if (client != null) {
            client.shutdown(5000);
        }
    }

    // ========== Trace Tests ==========

    @Test
    public void testTraceWithoutAttributes() {
        try (SpanManager span = client.trace("test.operation", null)) {
            assertNotNull(span, "Trace should return non-null SpanManager");
            assertNotNull(span.getSpan(), "SpanManager should have non-null span");
        }
    }

    @Test
    public void testTraceWithAttributes() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("operation", "test");
        attrs.put("user_id", "12345");

        try (SpanManager span = client.trace("test.operation", attrs)) {
            assertNotNull(span);
            span.setAttribute("result", "success");
        }
    }

    @Test
    public void testTraceFluentAPI() {
        try (SpanManager span = client.trace("test.operation", null)) {
            // Test fluent API chaining
            SpanManager result = span.setAttribute("step", "1")
                    .setAttribute("data_size", 100L);

            assertSame(span, result, "setAttribute should return same instance");
        }
    }

    @Test
    public void testTraceAutoClose() {
        SpanManager span = client.trace("test.operation", null);
        assertNotNull(span);

        // Close should not throw
        span.close();
    }

    @Test
    public void testTraceAfterShutdown() {
        client.shutdown(5000);

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            client.trace("test.operation", null);
        });

        assertTrue(exception.getMessage().contains("shut down"));
    }

    @Test
    public void testTraceWithNullSpanName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            client.trace(null, null);
        });

        assertTrue(exception.getMessage().contains("Span name"));
    }

    @Test
    public void testTraceWithEmptySpanName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            client.trace("", null);
        });

        assertTrue(exception.getMessage().contains("Span name"));
    }

    // ========== recordMetric Tests ==========

    @Test
    public void testRecordMetricCounter() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("endpoint", "/predict");

        // Should not throw
        client.recordMetric("model.requests_total", 1.0, "counter", attrs);
    }

    @Test
    public void testRecordMetricHistogram() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("model_version", "1.0");

        // Should not throw
        client.recordMetric("model.accuracy_score", 0.95, "histogram", attrs);
    }

    @Test
    public void testRecordMetricGauge() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("queue_name", "predictions");

        // Should not throw
        client.recordMetric("model.queue_size", 50.0, "gauge", attrs);
    }

    @Test
    public void testRecordMetricWithNullAttributes() {
        // Should not throw with null attributes
        client.recordMetric("model.test_metric", 123.0, "counter", null);
    }

    @Test
    public void testRecordMetricWithEmptyAttributes() {
        // Should not throw with empty attributes
        client.recordMetric("model.test_metric", 123.0, "counter", new HashMap<>());
    }

    @Test
    public void testRecordMetricDefaultsToHistogram() {
        // Null instrument type should default to histogram
        client.recordMetric("model.test_metric", 123.0, null, null);
    }

    @Test
    public void testRecordMetricEmptyTypeDefaultsToHistogram() {
        // Empty instrument type should default to histogram
        client.recordMetric("model.test_metric", 123.0, "", null);
    }

    @Test
    public void testRecordMetricInvalidType() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            client.recordMetric("model.test_metric", 123.0, "invalid_type", null);
        });

        assertTrue(exception.getMessage().contains("Invalid instrument type"));
    }

    @Test
    public void testRecordMetricAfterShutdown() {
        client.shutdown(5000);

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            client.recordMetric("model.test_metric", 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("shut down"));
    }

    // ========== Metric Name Validation Tests ==========

    @Test
    public void testRecordMetricNullName() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordMetric(null, 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("name"));
    }

    @Test
    public void testRecordMetricEmptyName() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordMetric("", 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("name"));
    }

    @Test
    public void testRecordMetricNameTooLong() {
        String longName = "a".repeat(300); // Exceeds 256 char limit

        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordMetric(longName, 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("maximum length"));
    }

    @Test
    public void testRecordMetricNameStartsWithDigit() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordMetric("123metric", 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("start with a letter"));
    }

    @Test
    public void testRecordMetricNameWithDangerousChars() {
        String[] dangerousNames = {
                "metric;DROP TABLE",
                "metric|whoami",
                "metric&& rm -rf",
                "metric$(malicious)",
                "metric`command`",
                "metric<script>",
                "metric[0]",
                "metric{key}"
        };

        for (String name : dangerousNames) {
            Exception exception = assertThrows(ValidationException.class, () -> {
                client.recordMetric(name, 123.0, "counter", null);
            }, "Should reject dangerous metric name: " + name);

            assertTrue(exception.getMessage().contains("invalid character"),
                    "Error message should mention invalid character for: " + name);
        }
    }

    @Test
    public void testRecordMetricNameWithControlChars() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordMetric("metric\nname", 123.0, "counter", null);
        });

        assertTrue(exception.getMessage().contains("invalid character"));
    }

    @Test
    public void testRecordMetricValidNames() {
        String[] validNames = {
                "model.predictions_total",
                "genai.tokens_total",
                "agentic.goals_completed",
                "my_custom_metric",
                "metric123",
                "MetricName",
                "_private_metric",
                "metric.with.dots",
                "metric_with_underscores"
        };

        for (String name : validNames) {
            // Should not throw
            assertDoesNotThrow(() -> {
                client.recordMetric(name, 123.0, "counter", null);
            }, "Should accept valid metric name: " + name);
        }
    }

    // ========== recordGauge Tests ==========

    @Test
    public void testRecordGauge() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("resource", "memory");

        // Should not throw
        client.recordGauge("model.memory_usage", 1024.0, attrs);
    }

    @Test
    public void testRecordGaugeWithNullAttributes() {
        client.recordGauge("model.test_gauge", 50.0, null);
    }

    @Test
    public void testRecordGaugeAfterShutdown() {
        client.shutdown(5000);

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            client.recordGauge("model.test_gauge", 50.0, null);
        });

        assertTrue(exception.getMessage().contains("shut down"));
    }

    @Test
    public void testRecordGaugeInvalidName() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordGauge("invalid;name", 50.0, null);
        });

        assertTrue(exception.getMessage().contains("invalid character"));
    }

    // ========== recordCounter Tests ==========

    @Test
    public void testRecordCounter() {
        Map<String, Object> attrs = new HashMap<>();
        attrs.put("cache_type", "redis");

        // Should not throw
        client.recordCounter("model.cache_hits", 10.0, attrs);
    }

    @Test
    public void testRecordCounterWithNullAttributes() {
        client.recordCounter("model.test_counter", 100.0, null);
    }

    @Test
    public void testRecordCounterAfterShutdown() {
        client.shutdown(5000);

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            client.recordCounter("model.test_counter", 100.0, null);
        });

        assertTrue(exception.getMessage().contains("shut down"));
    }

    @Test
    public void testRecordCounterInvalidName() {
        Exception exception = assertThrows(ValidationException.class, () -> {
            client.recordCounter("invalid|name", 100.0, null);
        });

        assertTrue(exception.getMessage().contains("invalid character"));
    }

    // ========== Integration Tests ==========

    @Test
    public void testTraceAndMetrics() {
        // Test using trace and metrics together
        try (SpanManager span = client.trace("model.predict", null)) {
            span.setAttribute("input_size", 100L);

            // Record metrics within the span
            client.recordCounter("model.predictions_total", 1.0, null);
            client.recordGauge("model.batch_size", 32.0, null);

            span.setAttribute("output_size", 10L);
        }
    }

    @Test
    public void testMultipleMetrics() {
        Map<String, Object> attrs = Map.of("model_version", "1.0");

        // Record multiple different metrics
        client.recordCounter("model.requests", 1.0, attrs);
        client.recordGauge("model.queue_depth", 5.0, attrs);
        client.recordMetric("model.latency", 0.150, "histogram", attrs);
    }

    @Test
    public void testNestedTraces() {
        // Test nested spans
        try (SpanManager outerSpan = client.trace("outer.operation", null)) {
            outerSpan.setAttribute("level", "outer");

            try (SpanManager innerSpan = client.trace("inner.operation", null)) {
                innerSpan.setAttribute("level", "inner");

                // Record metric in inner span
                client.recordCounter("nested.operations", 1.0, null);
            }

            outerSpan.setAttribute("completed", true);
        }
    }

    @Test
    public void testCaseSensitiveInstrumentType() {
        // Test that instrument type is case-insensitive
        client.recordMetric("test.metric1", 1.0, "COUNTER", null);
        client.recordMetric("test.metric2", 2.0, "Counter", null);
        client.recordMetric("test.metric3", 3.0, "counter", null);

        client.recordMetric("test.metric4", 4.0, "HISTOGRAM", null);
        client.recordMetric("test.metric5", 5.0, "Histogram", null);
        client.recordMetric("test.metric6", 6.0, "histogram", null);

        client.recordMetric("test.metric7", 7.0, "GAUGE", null);
        client.recordMetric("test.metric8", 8.0, "Gauge", null);
        client.recordMetric("test.metric9", 9.0, "gauge", null);
    }
}
