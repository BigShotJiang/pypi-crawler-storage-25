package com.bhsf.mca.sdk.resilience;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for DeadLetterQueue.
 */
public class DeadLetterQueueTest {

    @Test
    public void testEnqueueAndSize(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        assertEquals(0, dlq.size());
        assertTrue(dlq.isEmpty());
        assertFalse(dlq.isFull());

        dlq.enqueue("operation1", new RuntimeException("error1"), 3);

        assertEquals(1, dlq.size());
        assertFalse(dlq.isEmpty());
        assertFalse(dlq.isFull());
    }

    @Test
    public void testEnqueueMultipleItems(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(10, dlqPath, null, false);

        for (int i = 0; i < 5; i++) {
            dlq.enqueue("operation" + i, new RuntimeException("error" + i), i);
        }

        assertEquals(5, dlq.size());
    }

    @Test
    public void testFIFOEvictionWhenFull(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(3, dlqPath, null, false);

        // Fill queue
        dlq.enqueue("item1", new RuntimeException("error1"), 1);
        dlq.enqueue("item2", new RuntimeException("error2"), 2);
        dlq.enqueue("item3", new RuntimeException("error3"), 3);

        assertTrue(dlq.isFull());
        assertEquals(3, dlq.size());

        // Add one more - should evict oldest (item1)
        dlq.enqueue("item4", new RuntimeException("error4"), 4);

        assertEquals(3, dlq.size());

        // Verify item1 was evicted, item4 is present
        List<DeadLetterQueue.DLQItem> items = dlq.inspect(3);
        assertEquals("item2", items.get(0).getItem());
        assertEquals("item3", items.get(1).getItem());
        assertEquals("item4", items.get(2).getItem());
    }

    @Test
    public void testInspectRecentItems(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        dlq.enqueue("op1", new RuntimeException("err1"), 1);
        dlq.enqueue("op2", new RuntimeException("err2"), 2);
        dlq.enqueue("op3", new RuntimeException("err3"), 3);

        // Inspect all items
        List<DeadLetterQueue.DLQItem> items = dlq.inspect(10);
        assertEquals(3, items.size());
        assertEquals("op1", items.get(0).getItem());
        assertEquals("op2", items.get(1).getItem());
        assertEquals("op3", items.get(2).getItem());

        // Inspect limited items
        List<DeadLetterQueue.DLQItem> limited = dlq.inspect(2);
        assertEquals(2, limited.size());
        assertEquals("op2", limited.get(0).getItem()); // Most recent 2
        assertEquals("op3", limited.get(1).getItem());
    }

    @Test
    public void testItemEnrichment(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        RuntimeException error = new RuntimeException("Connection timeout");
        dlq.enqueue("ExportOperation", error, 5);

        List<DeadLetterQueue.DLQItem> items = dlq.inspect(1);
        assertEquals(1, items.size());

        DeadLetterQueue.DLQItem item = items.get(0);
        assertNotNull(item.getTimestamp());
        assertEquals("ExportOperation", item.getItem());
        assertEquals("Connection timeout", item.getError());
        assertEquals("RuntimeException", item.getErrorType());
        assertEquals(5, item.getRetryCount());
    }

    @Test
    public void testClear(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        dlq.enqueue("op1", new RuntimeException("err1"), 1);
        dlq.enqueue("op2", new RuntimeException("err2"), 2);

        assertEquals(2, dlq.size());

        int cleared = dlq.clear();

        assertEquals(2, cleared);
        assertEquals(0, dlq.size());
        assertTrue(dlq.isEmpty());
    }

    @Test
    public void testStatistics(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(10, dlqPath, null, false);

        // Initial stats
        DeadLetterQueue.DLQStats stats = dlq.stats();
        assertEquals(0, stats.getSize());
        assertEquals(10, stats.getMaxSize());
        assertTrue(stats.isEmpty());
        assertFalse(stats.isFull());
        assertEquals(0.0, stats.getUtilization(), 0.01);
        assertEquals(0, stats.getItemsEnqueued());
        assertEquals(0, stats.getItemsEvicted());

        // Add items
        for (int i = 0; i < 5; i++) {
            dlq.enqueue("op" + i, new RuntimeException("err"), i);
        }

        stats = dlq.stats();
        assertEquals(5, stats.getSize());
        assertEquals(50.0, stats.getUtilization(), 0.01);
        assertEquals(5, stats.getItemsEnqueued());
        assertEquals(0, stats.getItemsEvicted());
    }

    @Test
    public void testPersistenceRoundtrip(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();

        // Create DLQ and add items
        DeadLetterQueue dlq1 = new DeadLetterQueue(100, dlqPath, null, false);
        dlq1.enqueue("op1", new RuntimeException("err1"), 1);
        dlq1.enqueue("op2", new RuntimeException("err2"), 2);
        dlq1.enqueue("op3", new RuntimeException("err3"), 3);

        assertEquals(3, dlq1.size());

        // Create new DLQ from same path - should load persisted items
        DeadLetterQueue dlq2 = new DeadLetterQueue(100, dlqPath, null, false);

        assertEquals(3, dlq2.size());

        List<DeadLetterQueue.DLQItem> items = dlq2.inspect(3);
        assertEquals("op1", items.get(0).getItem());
        assertEquals("op2", items.get(1).getItem());
        assertEquals("op3", items.get(2).getItem());

        DeadLetterQueue.DLQStats stats = dlq2.stats();
        assertEquals(3, stats.getItemsRecoveredOnStartup());
    }

    @Test
    public void testInvalidConfigurationThrowsException() {
        // maxSize <= 0
        assertThrows(ResilienceException.class, () -> {
            new DeadLetterQueue(0);
        });

        assertThrows(ResilienceException.class, () -> {
            new DeadLetterQueue(-1);
        });
    }

    @Test
    public void testInspectWithInvalidLimitThrowsException(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        assertThrows(ResilienceException.class, () -> {
            dlq.inspect(0);
        });

        assertThrows(ResilienceException.class, () -> {
            dlq.inspect(-1);
        });
    }

    @Test
    public void testTruncateLargeItems(@TempDir Path tempDir) {
        String dlqPath = tempDir.resolve("test-dlq.json").toString();
        DeadLetterQueue dlq = new DeadLetterQueue(100, dlqPath, null, false);

        // Create a very large item (> 64KB)
        StringBuilder largeItem = new StringBuilder();
        for (int i = 0; i < 100000; i++) {
            largeItem.append("ABCDEFGHIJ");
        }

        dlq.enqueue(largeItem.toString(), new RuntimeException("error"), 1);

        List<DeadLetterQueue.DLQItem> items = dlq.inspect(1);
        assertEquals(1, items.size());

        String retrieved = items.get(0).getItem();
        assertTrue(retrieved.contains("[TRUNCATED]"));
        assertTrue(retrieved.length() < largeItem.length());
    }

    @Test
    public void testDefaultConstructor() {
        DeadLetterQueue dlq = new DeadLetterQueue(100);

        assertEquals(0, dlq.size());
        assertTrue(dlq.isEmpty());

        dlq.enqueue("test", new RuntimeException("test error"), 1);
        assertEquals(1, dlq.size());
    }
}
