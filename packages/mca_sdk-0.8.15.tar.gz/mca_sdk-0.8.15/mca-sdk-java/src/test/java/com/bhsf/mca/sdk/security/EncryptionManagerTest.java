package com.bhsf.mca.sdk.security;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for EncryptionManager.
 */
public class EncryptionManagerTest {

    @Test
    public void testGenerateKey() {
        byte[] key = EncryptionManager.generateKey();

        assertNotNull(key);
        assertEquals(32, key.length, "Key should be 32 bytes for AES-256");
    }

    @Test
    public void testGenerateKeyIsRandom() {
        byte[] key1 = EncryptionManager.generateKey();
        byte[] key2 = EncryptionManager.generateKey();

        assertFalse(java.util.Arrays.equals(key1, key2), "Generated keys should be different");
    }

    @Test
    public void testValidateKey_Valid32Bytes() {
        byte[] key = new byte[32];
        assertDoesNotThrow(() -> EncryptionManager.validateKey(key));
    }

    @Test
    public void testValidateKey_Null() {
        ConfigurationException exception = assertThrows(
            ConfigurationException.class,
            () -> EncryptionManager.validateKey(null)
        );
        assertTrue(exception.getMessage().contains("cannot be null"));
    }

    @Test
    public void testValidateKey_WrongLength() {
        byte[] key = new byte[16]; // AES-128 length

        ConfigurationException exception = assertThrows(
            ConfigurationException.class,
            () -> EncryptionManager.validateKey(key)
        );
        assertTrue(exception.getMessage().contains("Invalid encryption key length"));
        assertTrue(exception.getMessage().contains("32 bytes"));
    }

    @Test
    public void testCreateSecretKey() {
        byte[] keyBytes = EncryptionManager.generateKey();
        SecretKey secretKey = EncryptionManager.createSecretKey(keyBytes);

        assertNotNull(secretKey);
        assertEquals("AES", secretKey.getAlgorithm());
        assertArrayEquals(keyBytes, secretKey.getEncoded());
    }

    @Test
    public void testCreateSecretKey_InvalidLength() {
        byte[] keyBytes = new byte[16];

        assertThrows(ConfigurationException.class, () -> {
            EncryptionManager.createSecretKey(keyBytes);
        });
    }

    @Test
    public void testEncodeKeyForEnvironment() {
        byte[] key = EncryptionManager.generateKey();
        String encoded = EncryptionManager.encodeKeyForEnvironment(key);

        assertNotNull(encoded);
        assertFalse(encoded.isEmpty());

        // Verify it's valid base64
        byte[] decoded = Base64.getDecoder().decode(encoded);
        assertArrayEquals(key, decoded);
    }

    @Test
    public void testEncodeKeyForEnvironment_InvalidKey() {
        byte[] key = new byte[16];

        assertThrows(ConfigurationException.class, () -> {
            EncryptionManager.encodeKeyForEnvironment(key);
        });
    }

    @Test
    public void testLoadKeyFromEnvironment_FileBasedNotSet() {
        // When neither env var is set, should throw ConfigurationException
        // This test assumes clean environment - actual behavior depends on runtime env

        // Note: Full testing of environment-based loading requires
        // integration tests or dependency injection patterns
        assertTrue(true, "File-based key loading requires integration test setup");
    }
}

