package com.bhsf.mca.sdk.gcp;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for GCPAuthFactory.
 */
class GCPAuthTest {

    private static final String VALID_SERVICE_ACCOUNT_JSON = """
            {
              "type": "service_account",
              "project_id": "test-project-123",
              "private_key_id": "key-id-123",
              "private_key": "-----BEGIN PRIVATE KEY-----\\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASC\\n-----END PRIVATE KEY-----\\n",
              "client_email": "test@test-project-123.iam.gserviceaccount.com",
              "client_id": "123456789",
              "auth_uri": "https://accounts.google.com/o/oauth2/auth",
              "token_uri": "https://oauth2.googleapis.com/token",
              "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
              "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/test%40test-project-123.iam.gserviceaccount.com"
            }
            """;

    @Test
    void testLoadCredentialsFromFile(@TempDir Path tempDir) throws IOException {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        // Create temp credentials file
        Path credentialsFile = tempDir.resolve("credentials.json");
        Files.writeString(credentialsFile, VALID_SERVICE_ACCOUNT_JSON);

        // Load credentials from file (returns Object to avoid direct import)
        Object credentials = GCPAuthFactory.loadCredentials(
                credentialsFile.toString(),
                null
        );

        assertNotNull(credentials);
    }

    @Test
    void testLoadCredentialsFromJsonString() {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        // Load credentials from JSON string
        Object credentials = GCPAuthFactory.loadCredentials(
                null,
                VALID_SERVICE_ACCOUNT_JSON
        );

        assertNotNull(credentials);
    }

    @Test
    void testLoadCredentialsFileNotFound() {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        // Attempt to load from non-existent file
        ConfigurationException exception = assertThrows(
                ConfigurationException.class,
                () -> GCPAuthFactory.loadCredentials("/nonexistent/credentials.json", null)
        );

        assertTrue(exception.getMessage().contains("not found"));
    }

    @Test
    void testLoadCredentialsInvalidJson(@TempDir Path tempDir) throws IOException {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        // Create temp file with invalid JSON
        Path credentialsFile = tempDir.resolve("invalid.json");
        Files.writeString(credentialsFile, "{ invalid json }");

        // Attempt to load invalid JSON
        ConfigurationException exception = assertThrows(
                ConfigurationException.class,
                () -> GCPAuthFactory.loadCredentials(credentialsFile.toString(), null)
        );

        assertTrue(exception.getMessage().toLowerCase().contains("json"));
    }

    @Test
    void testLoadCredentialsWithCustomScopes() {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        List<String> customScopes = Arrays.asList(
                "https://www.googleapis.com/auth/bigquery",
                "https://www.googleapis.com/auth/pubsub"
        );

        Object credentials = GCPAuthFactory.loadCredentials(
                null,
                VALID_SERVICE_ACCOUNT_JSON,
                customScopes
        );

        assertNotNull(credentials);
    }

    @Test
    void testLoadCredentialsADCFallback() {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        // When no credentials provided, should attempt ADC
        // This will fail in test environment without ADC configured
        assertThrows(
                ConfigurationException.class,
                () -> GCPAuthFactory.loadCredentials(null, null)
        );
    }

    @Test
    void testLibraryNotAvailable() {
        // Test that accessing factory when library not available throws clear error
        // We can't actually test this case since the library IS available in tests
        // But we can verify the isAvailable() method works
        boolean available = GCPAuthFactory.isAvailable();
        assertTrue(available, "GCP auth library should be available in test environment");
    }

    @Test
    void testDefaultScopes() {
        // Verify default scopes are defined and immutable
        assertNotNull(GCPAuthFactory.DEFAULT_SCOPES);
        assertFalse(GCPAuthFactory.DEFAULT_SCOPES.isEmpty());
        assertTrue(GCPAuthFactory.DEFAULT_SCOPES.contains("https://www.googleapis.com/auth/monitoring.write"));
        assertTrue(GCPAuthFactory.DEFAULT_SCOPES.contains("https://www.googleapis.com/auth/logging.write"));
        assertTrue(GCPAuthFactory.DEFAULT_SCOPES.contains("https://www.googleapis.com/auth/trace.append"));

        // Verify list is immutable (should throw UnsupportedOperationException)
        assertThrows(UnsupportedOperationException.class, () -> {
            GCPAuthFactory.DEFAULT_SCOPES.add("https://malicious.com/scope");
        });
    }

    @Test
    void testValidateScopes() {
        // Skip test if GCP auth library not available
        assumeTrue(GCPAuthFactory.isAvailable(), "GCP auth library not available");

        Object credentials = GCPAuthFactory.loadCredentials(null, VALID_SERVICE_ACCOUNT_JSON);

        // validateScopes currently returns true (placeholder implementation)
        boolean isValid = GCPAuthFactory.validateScopes(credentials, GCPAuthFactory.DEFAULT_SCOPES);
        assertTrue(isValid);
    }
}
