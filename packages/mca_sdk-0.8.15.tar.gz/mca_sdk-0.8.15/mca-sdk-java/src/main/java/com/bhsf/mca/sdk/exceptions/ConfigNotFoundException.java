package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when configuration file or config key is not found.
 *
 * <p>This exception is distinct from {@link ConfigurationException}, which is thrown
 * when configuration exists but is invalid or malformed. ConfigNotFoundException indicates
 * that the requested configuration does not exist at all.
 *
 * <p>Common scenarios:
 * <ul>
 *   <li>Configuration file does not exist at the expected path</li>
 *   <li>Required configuration key is missing</li>
 *   <li>Model ID not found in registry</li>
 *   <li>Environment variable not set and no default available</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     config = ConfigLoader.load("config.yaml");
 * } catch (ConfigNotFoundException e) {
 *     logger.error("Config file not found: {}", e.getMessage());
 *     // Fall back to defaults or prompt user
 * }
 * }</pre>
 *
 * @since 0.2.0
 */
public class ConfigNotFoundException extends MCAException {

    /**
     * Constructs a new ConfigNotFoundException with the specified detail message.
     *
     * @param message the detail message explaining what configuration was not found
     */
    public ConfigNotFoundException(String message) {
        super(message);
    }

    /**
     * Constructs a new ConfigNotFoundException with the specified detail message and cause.
     *
     * @param message the detail message explaining what configuration was not found
     * @param cause the cause of the exception (e.g., FileNotFoundException)
     */
    public ConfigNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
