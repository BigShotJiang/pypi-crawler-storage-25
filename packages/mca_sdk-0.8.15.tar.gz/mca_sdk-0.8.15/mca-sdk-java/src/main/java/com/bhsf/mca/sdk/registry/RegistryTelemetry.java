package com.bhsf.mca.sdk.registry;

import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;

/**
 * Telemetry tracking for registry operations.
 *
 * <p>Records metrics for registry client operations including:
 * <ul>
 *   <li>Request counters - Total requests with success/error status</li>
 *   <li>Latency histogram - Request duration in seconds</li>
 *   <li>Cache metrics - Cache hits and misses</li>
 * </ul>
 *
 * <p>All metrics follow OpenTelemetry semantic conventions.
 * Metrics are recorded to the provided Meter instance.
 *
 * <p>Thread-safe for concurrent use.
 */
public class RegistryTelemetry {

    private static final AttributeKey<String> STATUS_KEY = AttributeKey.stringKey("status");

    private final LongCounter requestCounter;
    private final DoubleHistogram latencyHistogram;
    private final LongCounter cacheHitsCounter;
    private final LongCounter cacheMissesCounter;

    /**
     * Create registry telemetry with the provided meter.
     *
     * @param meter OpenTelemetry Meter for creating metrics (may be null)
     */
    public RegistryTelemetry(Meter meter) {
        if (meter != null) {
            this.requestCounter = meter.counterBuilder("registry.requests.total")
                    .setDescription("Total number of registry requests")
                    .setUnit("1")
                    .build();

            this.latencyHistogram = meter.histogramBuilder("registry.request.latency")
                    .setDescription("Registry request latency in seconds")
                    .setUnit("s")
                    .build();

            this.cacheHitsCounter = meter.counterBuilder("registry.cache.hits")
                    .setDescription("Number of cache hits")
                    .setUnit("1")
                    .build();

            this.cacheMissesCounter = meter.counterBuilder("registry.cache.misses")
                    .setDescription("Number of cache misses")
                    .setUnit("1")
                    .build();
        } else {
            // Null meter - telemetry disabled
            this.requestCounter = null;
            this.latencyHistogram = null;
            this.cacheHitsCounter = null;
            this.cacheMissesCounter = null;
        }
    }

    /**
     * Record a successful registry request.
     *
     * @param latencySeconds Request latency in seconds
     */
    public void recordSuccess(double latencySeconds) {
        if (requestCounter != null) {
            requestCounter.add(1, Attributes.of(STATUS_KEY, "success"));
        }
        if (latencyHistogram != null) {
            latencyHistogram.record(latencySeconds);
        }
    }

    /**
     * Record a failed registry request.
     *
     * @param latencySeconds Request latency in seconds
     */
    public void recordError(double latencySeconds) {
        if (requestCounter != null) {
            requestCounter.add(1, Attributes.of(STATUS_KEY, "error"));
        }
        if (latencyHistogram != null) {
            latencyHistogram.record(latencySeconds);
        }
    }

    /**
     * Record a cache hit.
     */
    public void recordCacheHit() {
        if (cacheHitsCounter != null) {
            cacheHitsCounter.add(1);
        }
    }

    /**
     * Record a cache miss.
     */
    public void recordCacheMiss() {
        if (cacheMissesCounter != null) {
            cacheMissesCounter.add(1);
        }
    }

    /**
     * Check if telemetry is enabled.
     *
     * @return true if meter was provided and metrics are active
     */
    public boolean isEnabled() {
        return requestCounter != null;
    }
}
