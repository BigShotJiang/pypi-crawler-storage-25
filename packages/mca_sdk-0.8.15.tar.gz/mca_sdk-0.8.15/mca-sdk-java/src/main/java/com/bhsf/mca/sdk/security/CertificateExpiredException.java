package com.bhsf.mca.sdk.security;

import java.time.Instant;
import java.util.Date;

/**
 * Exception thrown when a certificate has expired.
 *
 * <p>This checked exception indicates that a certificate's validity period has ended
 * and it should no longer be trusted for cryptographic operations or authentication.
 *
 * <p>Common scenarios:
 * <ul>
 *   <li>Certificate's notAfter date is in the past</li>
 *   <li>Certificate's notBefore date is in the future (not yet valid)</li>
 *   <li>System clock is incorrect and certificate appears expired</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     CertificateManager.checkExpiry(cert);
 * } catch (CertificateExpiredException e) {
 *     logger.warn("Certificate expired: {}", e.getMessage());
 *     // Trigger certificate renewal or alert operations
 * }
 * }</pre>
 *
 * @see CertificateManager
 * @since 0.2.0
 */
public class CertificateExpiredException extends CertificateException {

    /**
     * Constructs a new CertificateExpiredException with the specified detail message.
     *
     * <p>The message should include the expiration date for troubleshooting.
     *
     * @param message the detail message (typically includes expiration date)
     */
    public CertificateExpiredException(String message) {
        super(message);
    }

    /**
     * Constructs a new CertificateExpiredException with the specified detail message and cause.
     *
     * @param message the detail message (typically includes expiration date)
     * @param cause the underlying cause (e.g., CertificateExpiredException from java.security)
     */
    public CertificateExpiredException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Convenience constructor that formats expiration date in message.
     *
     * <p>Creates a message like: "Certificate expired on 2026-01-15T10:30:00Z"
     *
     * @param expirationDate the certificate expiration date
     */
    public CertificateExpiredException(Date expirationDate) {
        super(String.format("Certificate expired on %s",
            Instant.ofEpochMilli(expirationDate.getTime()).toString()));
    }

    /**
     * Convenience constructor for not-yet-valid certificates.
     *
     * <p>Creates a message like: "Certificate not yet valid (valid from 2026-12-01T00:00:00Z)"
     *
     * @param notBefore the certificate's notBefore date
     * @param isNotYetValid true if certificate is not yet valid, false if expired
     */
    public CertificateExpiredException(Date notBefore, boolean isNotYetValid) {
        super(isNotYetValid
            ? String.format("Certificate not yet valid (valid from %s)",
                Instant.ofEpochMilli(notBefore.getTime()).toString())
            : String.format("Certificate expired on %s",
                Instant.ofEpochMilli(notBefore.getTime()).toString()));
    }
}
