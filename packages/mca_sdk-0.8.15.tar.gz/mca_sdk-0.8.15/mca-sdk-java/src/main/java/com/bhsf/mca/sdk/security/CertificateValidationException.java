package com.bhsf.mca.sdk.security;

/**
 * Exception thrown when certificate validation fails.
 *
 * <p>This checked exception indicates that a certificate could not be validated
 * against the expected criteria, such as trust chain verification, hostname validation,
 * or certificate purpose checks.
 *
 * <p>Common scenarios:
 * <ul>
 *   <li>Certificate chain cannot be verified against trusted CAs</li>
 *   <li>Hostname does not match certificate subject or SAN</li>
 *   <li>Certificate not valid for the intended purpose (e.g., TLS server auth)</li>
 *   <li>Certificate has been revoked (CRL/OCSP check failed)</li>
 *   <li>Certificate signature is invalid</li>
 * </ul>
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     CertificateManager.validateCertificate(cert, "example.com");
 * } catch (CertificateValidationException e) {
 *     logger.error("Certificate validation failed: {}", e.getMessage());
 *     // Reject connection or fall back to different authentication
 * }
 * }</pre>
 *
 * @see CertificateManager
 * @since 0.2.0
 */
public class CertificateValidationException extends CertificateException {

    /**
     * Constructs a new CertificateValidationException with the specified detail message.
     *
     * <p>The message should include the validation failure reason.
     *
     * @param message the detail message explaining why validation failed
     */
    public CertificateValidationException(String message) {
        super(message);
    }

    /**
     * Constructs a new CertificateValidationException with the specified detail message and cause.
     *
     * @param message the detail message explaining why validation failed
     * @param cause the underlying cause (e.g., CertPathValidatorException)
     */
    public CertificateValidationException(String message, Throwable cause) {
        super(message, cause);
    }
}
