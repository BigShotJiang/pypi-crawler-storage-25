package com.bhsf.mca.sdk.validation;

import com.bhsf.mca.sdk.exceptions.ValidationException;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Validator for metric naming conventions.
 *
 * <p>Enforces consistent metric naming across different model types to ensure
 * metrics can be properly categorized and queried in monitoring systems.
 *
 * <p>Naming patterns by model type:
 * <ul>
 *   <li>Internal models: model.*_total, model.*_seconds, model.*_ratio</li>
 *   <li>GenAI models: genai.*_total, genai.*_seconds, genai.*_dollars</li>
 *   <li>Agentic models: agentic.*_total, agentic.*_seconds, agentic.*_dollars</li>
 *   <li>Vendor models: vendor.*_total, vendor.*_seconds, vendor.*_ratio</li>
 * </ul>
 *
 * <p>Security: Validates against dangerous characters and length limits.
 */
public class MetricNamingValidator {

    private static final int MIN_METRIC_NAME_LENGTH = 3;
    private static final int MAX_METRIC_NAME_LENGTH = 256;

    // Valid metric prefixes by model taxonomy
    private static final String PREFIX_MODEL = "model";
    private static final String PREFIX_GENAI = "genai";
    private static final String PREFIX_AGENTIC = "agentic";
    private static final String PREFIX_VENDOR = "vendor";

    // Valid metric units (suffixes)
    private static final Set<String> VALID_UNITS = new HashSet<>(Arrays.asList(
        "total",        // Counters (monotonically increasing)
        "seconds",      // Time duration in seconds
        "milliseconds", // Time duration in milliseconds
        "ratio",        // Ratios and percentages (0.0-1.0)
        "count",        // Counts (may decrease)
        "dollars",      // Cost in dollars (GenAI/agentic)
        "usd",          // Cost in USD (GenAI)
        "prompt",       // Token counts by type (GenAI)
        "completion"    // Token counts by type (GenAI)
    ));

    // Metric naming patterns by prefix
    private static final Pattern PATTERN_MODEL = Pattern.compile("^model\\.[a-z0-9_.]+_(total|seconds|milliseconds|ratio|count)$");
    private static final Pattern PATTERN_GENAI = Pattern.compile("^genai\\.[a-z0-9_.]+_(total|seconds|ratio|count|dollars|usd|prompt|completion)$");
    private static final Pattern PATTERN_AGENTIC = Pattern.compile("^agentic\\.[a-z0-9_.]+_(total|seconds|ratio|count|dollars)$");
    private static final Pattern PATTERN_VENDOR = Pattern.compile("^vendor\\.[a-z0-9_.]+_(total|seconds|ratio|count)$");

    private final String expectedPrefix;
    private final String modelCategory;
    private final String modelType;
    private final boolean strict;

    /**
     * Creates a MetricNamingValidator.
     *
     * @param modelCategory High-level category ("internal" or "vendor")
     * @param modelType Specific type ("regression", "generative", "agentic", etc.)
     * @param strict If true, enforce naming conventions. If false, allow any safe name.
     * @throws ValidationException if taxonomy combination is invalid
     */
    public MetricNamingValidator(String modelCategory, String modelType, boolean strict) {
        this.modelCategory = modelCategory;
        this.modelType = modelType;
        this.strict = strict;
        this.expectedPrefix = determineMetricPrefix(modelCategory, modelType);
    }

    /**
     * Validates a metric name against conventions.
     *
     * @param metricName The metric name to validate
     * @throws ValidationException if metric name doesn't follow conventions (strict mode only)
     */
    public void validate(String metricName) {
        // Input validation
        if (metricName == null || metricName.isEmpty()) {
            throw new ValidationException("Metric name cannot be null or empty");
        }

        // Length validation
        if (metricName.length() < MIN_METRIC_NAME_LENGTH) {
            throw new ValidationException(
                "Metric name must be at least " + MIN_METRIC_NAME_LENGTH + " characters. " +
                "Got: " + metricName.length()
            );
        }

        if (metricName.length() > MAX_METRIC_NAME_LENGTH) {
            throw new ValidationException(
                "Metric name exceeds maximum length of " + MAX_METRIC_NAME_LENGTH + " characters. " +
                "Got: " + metricName.length()
            );
        }

        // Must start with letter
        if (!Character.isLetter(metricName.charAt(0))) {
            throw new ValidationException("Metric names must start with letter");
        }

        // Security: Check for dangerous characters
        validateSafeCharacters(metricName);

        // Non-strict mode: allow any safe name (after security checks)
        if (!strict) {
            return;
        }

        // Strict mode: Check if name matches pattern for this model type
        if (!matchesPattern(metricName)) {
            raiseValidationError(metricName);
        }
    }

    /**
     * Determines metric prefix from model taxonomy.
     *
     * @param modelCategory High-level category
     * @param modelType Specific model type
     * @return Metric prefix (model, genai, agentic, vendor)
     * @throws ValidationException if taxonomy is invalid
     */
    private String determineMetricPrefix(String modelCategory, String modelType) {
        if (modelCategory == null || modelCategory.trim().isEmpty()) {
            throw new ValidationException("model_category cannot be null or empty");
        }

        String category = modelCategory.trim().toLowerCase();

        if ("vendor".equals(category)) {
            return PREFIX_VENDOR;
        }

        if ("internal".equals(category)) {
            if (modelType == null || modelType.trim().isEmpty()) {
                throw new ValidationException("model_type is required for internal models");
            }

            String type = modelType.trim().toLowerCase();
            switch (type) {
                case "generative":
                    return PREFIX_GENAI;
                case "agentic":
                    return PREFIX_AGENTIC;
                case "regression":
                case "time-series":
                case "classification":
                    return PREFIX_MODEL;
                default:
                    throw new ValidationException(
                        "Invalid model_type: " + modelType +
                        ". Valid types: regression, time-series, classification, generative, agentic"
                    );
            }
        }

        throw new ValidationException(
            "Invalid model_category: " + modelCategory +
            ". Valid categories: internal, vendor"
        );
    }

    /**
     * Validates that metric name contains only safe characters.
     *
     * @param metricName Metric name to validate
     * @throws ValidationException if dangerous characters are found
     */
    private void validateSafeCharacters(String metricName) {
        // Allowed characters depend on strict mode
        String allowedChars = strict ? "._" : "._-";

        for (int i = 0; i < metricName.length(); i++) {
            char c = metricName.charAt(i);

            if (!Character.isLetterOrDigit(c) && allowedChars.indexOf(c) == -1) {
                // Check for dangerous characters (control chars, injection chars)
                if (c < 32 || c > 126 || isDangerousChar(c)) {
                    throw new ValidationException(
                        "Invalid metric name: '" + metricName + "' - contains dangerous character: '" + c + "'. " +
                        "Control characters and special injection characters are not allowed."
                    );
                } else if (strict) {
                    throw new ValidationException(
                        "Invalid metric name: '" + metricName + "' - invalid character: '" + c + "'. " +
                        "In strict mode, only alphanumeric, dots, and underscores are allowed. " +
                        "Use strict_validation=false to allow hyphens and other characters."
                    );
                }
            }
        }
    }

    /**
     * Checks if character is dangerous (injection risk).
     *
     * @param c Character to check
     * @return true if dangerous
     */
    private boolean isDangerousChar(char c) {
        return c == '"' || c == '\'' || c == '\\' || c == '/' || c == '[' || c == ']' ||
               c == '{' || c == '}' || c == '(' || c == ')' || c == '<' || c == '>' ||
               c == ';' || c == '|' || c == '&' || c == '$' || c == '`';
    }

    /**
     * Checks if metric name matches pattern for this model type.
     *
     * @param metricName Metric name to check
     * @return true if matches pattern
     */
    private boolean matchesPattern(String metricName) {
        switch (expectedPrefix) {
            case PREFIX_MODEL:
                return PATTERN_MODEL.matcher(metricName).matches();
            case PREFIX_GENAI:
                return PATTERN_GENAI.matcher(metricName).matches();
            case PREFIX_AGENTIC:
                return PATTERN_AGENTIC.matcher(metricName).matches();
            case PREFIX_VENDOR:
                return PATTERN_VENDOR.matcher(metricName).matches();
            default:
                return false;
        }
    }

    /**
     * Raises a detailed ValidationException with suggestions.
     *
     * @param metricName The invalid metric name
     * @throws ValidationException with detailed error message
     */
    private void raiseValidationError(String metricName) {
        String examples = getExamples();

        String errorMsg = String.format(
            "Invalid metric name: '%s'\n\n" +
            "For %s.* metrics (model_category='%s', model_type='%s'), metric names must follow these patterns:\n" +
            "  - %s.*_total (counters)\n" +
            "  - %s.*_seconds (latency)\n" +
            "  - %s.*_ratio (ratios)\n" +
            "  - %s.*_count (counts)\n",
            metricName,
            expectedPrefix,
            modelCategory,
            modelType,
            expectedPrefix,
            expectedPrefix,
            expectedPrefix,
            expectedPrefix
        );

        if (PREFIX_GENAI.equals(expectedPrefix) || PREFIX_AGENTIC.equals(expectedPrefix)) {
            errorMsg += String.format("  - %s.*_dollars (cost)\n", expectedPrefix);
        }

        if (PREFIX_GENAI.equals(expectedPrefix)) {
            errorMsg += "  - genai.*_usd (cost in USD)\n";
        }

        errorMsg += "\nExamples:\n" + examples;
        errorMsg += "\nTo disable validation, set strict_validation=false in MCAConfig.";

        throw new ValidationException(errorMsg);
    }

    /**
     * Gets example metric names for this metric prefix.
     *
     * @return Examples as formatted string
     */
    private String getExamples() {
        switch (expectedPrefix) {
            case PREFIX_MODEL:
                return "  - model.predictions_total\n" +
                       "  - model.latency_seconds\n" +
                       "  - model.accuracy_ratio\n" +
                       "  - model.error_count\n";
            case PREFIX_GENAI:
                return "  - genai.requests_total\n" +
                       "  - genai.latency_seconds\n" +
                       "  - genai.token_count\n" +
                       "  - genai.cost_dollars\n";
            case PREFIX_AGENTIC:
                return "  - agentic.goals_total\n" +
                       "  - agentic.reasoning_seconds\n" +
                       "  - agentic.success_ratio\n" +
                       "  - agentic.tool_count\n" +
                       "  - agentic.cost_dollars\n";
            case PREFIX_VENDOR:
                return "  - vendor.predictions_total\n" +
                       "  - vendor.latency_seconds\n" +
                       "  - vendor.accuracy_ratio\n";
            default:
                return "";
        }
    }
}
