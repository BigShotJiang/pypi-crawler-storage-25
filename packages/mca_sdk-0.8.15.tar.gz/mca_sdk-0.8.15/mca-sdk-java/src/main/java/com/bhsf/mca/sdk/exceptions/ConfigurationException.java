package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when SDK configuration is invalid.
 */
public class ConfigurationException extends MCAException {

    public ConfigurationException(String message) {
        super(message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
