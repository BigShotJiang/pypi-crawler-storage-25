package com.bhsf.mca.sdk.resilience;

import com.bhsf.mca.sdk.config.MCAConfig;
import com.bhsf.mca.sdk.security.QueueEncryption;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.SecretKey;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Thread-safe bounded queue for telemetry buffering with disk persistence.
 *
 * <p>Provides in-memory queueing with optional disk persistence for telemetry data
 * when the collector is temporarily unreachable. Features:
 * <ul>
 *   <li>Bounded in-memory queue with FIFO eviction when full</li>
 *   <li>Optional disk persistence with encryption (AES-256-GCM)</li>
 *   <li>Async background writer thread for non-blocking persistence</li>
 *   <li>Atomic file writes (temp + rename) to prevent corruption</li>
 *   <li>Path validation with traversal protection</li>
 *   <li>Thread-safe operations for concurrent access</li>
 * </ul>
 *
 * <p>Thread Safety: All operations are thread-safe. Queue operations use BlockingQueue,
 * disk I/O uses separate ReentrantLock to prevent blocking queue operations.
 *
 * <p>Example usage:
 * <pre>{@code
 * // Create queue with persistence and encryption
 * SecretKey key = EncryptionManager.loadKeyFromEnvironment();
 * QueueEncryption encryption = new QueueEncryption(key);
 * TelemetryQueue queue = new TelemetryQueue(1000, true, "~/.mca_sdk/queue.json", encryption);
 *
 * // Enqueue items (non-blocking, thread-safe)
 * queue.enqueue("{\"metric\":\"predictions\",\"value\":100}");
 *
 * // Dequeue batch for export
 * List<String> batch = queue.dequeueBatch(50);
 *
 * // Shutdown gracefully
 * queue.shutdown(5000);
 * }</pre>
 */
public class TelemetryQueue {
    private static final Logger logger = LoggerFactory.getLogger(TelemetryQueue.class);

    private final int maxSize;
    private final BlockingQueue<String> queue;
    private final ReentrantLock diskLock;
    private final boolean persist;
    private final String persistPath;
    private final QueueEncryption encryption;
    private final ObjectMapper objectMapper;

    // Background writer
    private final BlockingQueue<List<String>> writeQueue;
    private final Thread writerThread;
    private volatile boolean shutdown = false;

    // Metrics
    private final AtomicInteger persistWrites = new AtomicInteger(0);
    private final AtomicInteger persistSuccessCount = new AtomicInteger(0);
    private final AtomicInteger persistFailureCount = new AtomicInteger(0);
    private final AtomicInteger itemsRecovered = new AtomicInteger(0);

    // Disk space check caching
    private volatile long lastDiskCheckTime = 0;
    private volatile boolean lastDiskCheckResult = true;
    private static final long DISK_CHECK_INTERVAL_MS = 5000;
    private static final long MIN_DISK_SPACE_MB = 10;

    /**
     * Create telemetry queue with minimal configuration (in-memory only).
     *
     * @param maxSize Maximum number of items in queue (must be > 0)
     * @throws ResilienceException if maxSize is invalid
     */
    public TelemetryQueue(int maxSize) {
        this(maxSize, false, null, null, null);
    }

    /**
     * Create telemetry queue with full configuration.
     *
     * @param maxSize     Maximum number of items in queue (must be > 0)
     * @param persist     Whether to persist queue to disk
     * @param persistPath Path for queue persistence (required if persist=true, will expand ~/)
     * @param encryption  Optional encryption for disk persistence (can be null)
     * @param config      Optional MCAConfig for custom path validation (can be null)
     * @throws ResilienceException if parameters are invalid
     */
    public TelemetryQueue(int maxSize, boolean persist, String persistPath,
                          QueueEncryption encryption, MCAConfig config) {
        if (maxSize <= 0) {
            throw new ResilienceException("maxSize must be positive, got " + maxSize);
        }
        if (persist && persistPath == null) {
            throw new ResilienceException("persistPath required when persist=true");
        }

        this.maxSize = maxSize;
        this.queue = new ArrayBlockingQueue<>(maxSize);
        this.diskLock = new ReentrantLock();
        this.persist = persist;
        this.encryption = encryption;
        this.objectMapper = new ObjectMapper();

        // Validate and expand persist path
        if (persistPath != null) {
            this.persistPath = validatePersistPath(persistPath, config);
        } else {
            this.persistPath = null;
        }

        // Start background writer if persistence enabled
        if (persist) {
            this.writeQueue = new LinkedBlockingQueue<>(100);
            this.writerThread = new Thread(this::backgroundWriter, "TelemetryQueue-Writer");
            this.writerThread.setDaemon(true);
            this.writerThread.start();

            // Load existing queue from disk
            loadFromDisk();

            // Warn about encryption
            if (encryption == null) {
                logger.warn(
                        "⚠️  HIPAA COMPLIANCE WARNING ⚠️\n" +
                        "Queue persistence is enabled WITHOUT encryption at rest.\n" +
                        "Persisted telemetry may contain PHI and is stored UNENCRYPTED.\n" +
                        "Unencrypted queue file: {}", this.persistPath
                );
            } else {
                logger.info("Queue persistence enabled with encryption at rest: {}", this.persistPath);
            }
        } else {
            this.writeQueue = null;
            this.writerThread = null;
        }
    }

    /**
     * Enqueue item to queue.
     *
     * <p>Thread-safe atomic operation. If queue is full, oldest item is evicted (FIFO).
     * Uses lock-free retry loop to ensure item is always enqueued successfully.
     *
     * @param item Telemetry data as JSON string
     * @return true if item was added without eviction, false if queue was full and item replaced oldest
     */
    public boolean enqueue(String item) {
        boolean evicted = false;

        // Atomic eviction: retry until offer succeeds
        // This prevents data loss from race conditions where queue becomes full
        // between remainingCapacity() check and offer()
        while (!queue.offer(item)) {
            // Queue is full, evict oldest item and retry
            queue.poll();
            evicted = true;

            if (!evicted) { // Log only once per enqueue
                logger.warn("Telemetry queue full (size={}), oldest item evicted", maxSize);
            }
        }

        // Trigger async persistence if we evicted items
        if (persist && evicted) {
            persistWrites.incrementAndGet();
            saveToDiskAsync();
        }

        return !evicted;
    }

    /**
     * Dequeue single item from queue.
     *
     * @return Oldest item, or null if queue is empty
     */
    public String dequeue() {
        return queue.poll();
    }

    /**
     * Dequeue multiple items from queue.
     *
     * @param size Maximum number of items to dequeue (must be > 0)
     * @return List of items (may be shorter than size if queue has fewer items)
     * @throws ResilienceException if size is invalid
     */
    public List<String> dequeueBatch(int size) {
        if (size <= 0) {
            throw new ResilienceException("dequeueBatch size must be positive, got " + size);
        }

        List<String> batch = new ArrayList<>(Math.min(size, queue.size()));
        queue.drainTo(batch, size);
        return batch;
    }

    /**
     * Peek at oldest item without removing it.
     *
     * @return Oldest item, or null if queue is empty
     */
    public String peek() {
        return queue.peek();
    }

    /**
     * Get current queue size.
     *
     * @return Number of items in queue
     */
    public int size() {
        return queue.size();
    }

    /**
     * Check if queue is empty.
     *
     * @return true if queue is empty
     */
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    /**
     * Check if queue is at maximum capacity.
     *
     * @return true if queue is full
     */
    public boolean isFull() {
        return queue.remainingCapacity() == 0;
    }

    /**
     * Clear all items from queue.
     *
     * @return Number of items removed
     */
    public int clear() {
        int count = queue.size();
        queue.clear();

        if (persist) {
            saveToDiskAsync();
        }

        if (count > 0) {
            logger.info("Queue cleared: {} items removed", count);
        }

        return count;
    }

    /**
     * Get queue statistics.
     *
     * @return Statistics object with metrics
     */
    public TelemetryQueueStats getStats() {
        int currentSize = queue.size();
        double utilization = maxSize > 0 ? (currentSize * 100.0 / maxSize) : 0;

        return new TelemetryQueueStats(
                currentSize,
                maxSize,
                currentSize >= maxSize,
                currentSize == 0,
                Math.round(utilization * 100.0) / 100.0,
                persist,
                persistWrites.get(),
                persistSuccessCount.get(),
                persistFailureCount.get(),
                itemsRecovered.get()
        );
    }

    /**
     * Gracefully shutdown background writer and flush queue.
     *
     * @param timeoutMs Maximum milliseconds to wait for writer thread
     * @throws InterruptedException if interrupted while waiting
     */
    public void shutdown(long timeoutMs) throws InterruptedException {
        if (!persist || writerThread == null) {
            return;
        }

        shutdown = true;
        writerThread.join(timeoutMs);

        if (writerThread.isAlive()) {
            logger.warn("Background writer did not stop within {}ms", timeoutMs);
        } else {
            logger.debug("Background writer stopped cleanly");
        }
    }

    /**
     * Queue async disk write request.
     */
    private void saveToDiskAsync() {
        if (!persist || writeQueue == null) {
            return;
        }

        // Check if write queue is full
        if (writeQueue.remainingCapacity() == 0) {
            logger.debug("Disk write queue full - skipping persistence (backpressure)");
            return;
        }

        // Check disk space
        if (!checkDiskSpace()) {
            return;
        }

        // Take snapshot and queue write
        List<String> snapshot = new ArrayList<>(queue);
        writeQueue.offer(snapshot);
    }

    /**
     * Background writer thread.
     */
    private void backgroundWriter() {
        logger.debug("Background queue writer thread started");

        while (!shutdown) {
            try {
                List<String> snapshot = writeQueue.poll(1000, TimeUnit.MILLISECONDS);
                if (snapshot != null) {
                    saveSnapshotToDisk(snapshot);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                logger.error("Background writer error: {}", e.getMessage(), e);
            }
        }

        // Drain remaining writes
        List<String> remaining;
        while ((remaining = writeQueue.poll()) != null) {
            saveSnapshotToDisk(remaining);
        }

        // Final flush
        saveSnapshotToDisk(new ArrayList<>(queue));

        logger.debug("Background queue writer thread stopped");
    }

    /**
     * Synchronously write snapshot to disk using atomic writes.
     */
    private void saveSnapshotToDisk(List<String> snapshot) {
        diskLock.lock();
        try {
            File parentDir = new File(persistPath).getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                if (!parentDir.mkdirs()) {
                    logger.error("Failed to create parent directory: {}", parentDir);
                    persistFailureCount.incrementAndGet();
                    return;
                }
            }

            // Serialize to JSON
            byte[] jsonData = objectMapper.writeValueAsBytes(snapshot);

            // Encrypt if enabled
            if (encryption != null) {
                jsonData = encryption.encrypt(jsonData);
            }

            // Atomic write: temp file + rename
            Path tempFile = Files.createTempFile(
                    parentDir != null ? parentDir.toPath() : null,
                    ".queue_",
                    ".tmp"
            );

            Files.write(tempFile, jsonData);

            // Atomic rename
            Files.move(tempFile, Paths.get(persistPath),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);

            persistSuccessCount.incrementAndGet();
            logger.debug("Queue persisted to disk: {} items", snapshot.size());

        } catch (IOException e) {
            persistFailureCount.incrementAndGet();
            logger.error("Failed to persist queue: {}", e.getMessage());
        } finally {
            diskLock.unlock();
        }
    }

    /**
     * Load queue from disk on startup.
     */
    private void loadFromDisk() {
        File file = new File(persistPath);
        if (!file.exists()) {
            logger.debug("No existing queue file found at {}", persistPath);
            return;
        }

        try {
            byte[] data = Files.readAllBytes(file.toPath());

            // Decrypt if encryption enabled
            if (encryption != null) {
                data = encryption.decrypt(data);
            }

            // Parse JSON
            String[] items = objectMapper.readValue(data, String[].class);

            // Restore items (respecting max size)
            int startIndex = Math.max(0, items.length - maxSize);
            for (int i = startIndex; i < items.length; i++) {
                queue.offer(items[i]);
            }

            itemsRecovered.set(queue.size());
            logger.info("Queue loaded from disk: {} items recovered", itemsRecovered.get());

        } catch (Exception e) {
            logger.error("Failed to load queue from disk: {}. Starting with empty queue.",
                    e.getClass().getSimpleName());
        }
    }

    /**
     * Check disk space with caching (5 second interval).
     */
    private boolean checkDiskSpace() {
        long currentTime = System.currentTimeMillis();

        // Return cached result if still valid
        if (currentTime - lastDiskCheckTime < DISK_CHECK_INTERVAL_MS) {
            return lastDiskCheckResult;
        }

        // Perform disk check
        try {
            File file = new File(persistPath);
            long availableMB = file.getUsableSpace() / (1024 * 1024);

            boolean result = availableMB >= MIN_DISK_SPACE_MB;

            if (!result) {
                logger.warn("Low disk space: {}MB available, {}MB required. Skipping persistence.",
                        availableMB, MIN_DISK_SPACE_MB);
            }

            lastDiskCheckTime = currentTime;
            lastDiskCheckResult = result;
            return result;

        } catch (Exception e) {
            logger.warn("Failed to check disk space: {}. Skipping persistence.", e.getMessage());
            lastDiskCheckTime = currentTime;
            lastDiskCheckResult = false;
            return false;
        }
    }

    /**
     * Validate persist path with security checks.
     */
    private String validatePersistPath(String path, MCAConfig config) {
        // Expand user home
        String expanded = path.startsWith("~/")
                ? System.getProperty("user.home") + path.substring(1)
                : path;

        try {
            // Get canonical path (resolves symlinks)
            Path canonicalPath = Paths.get(expanded).toRealPath();
            String canonical = canonicalPath.toString();

            // Block sensitive directories
            String[] sensitiveDirs = {"/etc", "/sys", "/proc", "/boot", "/root", "/dev"};
            for (String sensitive : sensitiveDirs) {
                if (canonical.equals(sensitive) || canonical.startsWith(sensitive + "/")) {
                    throw new ResilienceException(
                            "Cannot persist queue to sensitive system directory: " + canonical +
                            ". Use ~/.mca_sdk/ or /var/lib/mca/ instead.");
                }
            }

            // Whitelist check
            String[] allowedDirs = {
                    System.getProperty("user.home") + "/.mca_sdk",
                    "/var/lib/mca",
                    "/tmp/mca_sdk"
            };

            boolean allowed = false;
            for (String allowedDir : allowedDirs) {
                if (canonical.startsWith(allowedDir)) {
                    allowed = true;
                    break;
                }
            }

            if (!allowed) {
                throw new ResilienceException(
                        "Unauthorized persist_path: " + canonical +
                        ". Allowed: ~/.mca_sdk/, /var/lib/mca/, /tmp/mca_sdk/");
            }

            return canonical;

        } catch (IOException e) {
            // Path doesn't exist yet - validate parent and allow
            try {
                Path parent = Paths.get(expanded).getParent();
                if (parent != null) {
                    return expanded; // Allow non-existent paths in valid directories
                }
            } catch (Exception ex) {
                // Fall through to error
            }

            throw new ResilienceException(
                    "Invalid persist_path: " + path + ". Could not resolve to canonical path.");
        }
    }

    /**
     * Queue statistics.
     */
    public static class TelemetryQueueStats {
        private final int size;
        private final int maxSize;
        private final boolean isFull;
        private final boolean isEmpty;
        private final double utilization;
        private final boolean persistEnabled;
        private final int persistWrites;
        private final int persistSuccessCount;
        private final int persistFailureCount;
        private final int itemsRecovered;

        public TelemetryQueueStats(int size, int maxSize, boolean isFull, boolean isEmpty,
                                   double utilization, boolean persistEnabled, int persistWrites,
                                   int persistSuccessCount, int persistFailureCount, int itemsRecovered) {
            this.size = size;
            this.maxSize = maxSize;
            this.isFull = isFull;
            this.isEmpty = isEmpty;
            this.utilization = utilization;
            this.persistEnabled = persistEnabled;
            this.persistWrites = persistWrites;
            this.persistSuccessCount = persistSuccessCount;
            this.persistFailureCount = persistFailureCount;
            this.itemsRecovered = itemsRecovered;
        }

        // Getters
        public int getSize() { return size; }
        public int getMaxSize() { return maxSize; }
        public boolean isFull() { return isFull; }
        public boolean isEmpty() { return isEmpty; }
        public double getUtilization() { return utilization; }
        public boolean isPersistEnabled() { return persistEnabled; }
        public int getPersistWrites() { return persistWrites; }
        public int getPersistSuccessCount() { return persistSuccessCount; }
        public int getPersistFailureCount() { return persistFailureCount; }
        public int getItemsRecovered() { return itemsRecovered; }
    }
}
