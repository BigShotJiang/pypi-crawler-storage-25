package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.metrics.DoubleHistogram;
import io.opentelemetry.api.metrics.LongCounter;
import io.opentelemetry.api.metrics.Meter;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import org.slf4j.LoggerFactory;

import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Agentic AI Integration for tracking goal lifecycles and tool executions.
 *
 * <p>Provides methods for:
 * <ul>
 *   <li>Goal lifecycle tracking (start, complete, duration)</li>
 *   <li>Tool execution tracking with spans</li>
 *   <li>Thread-safe goal context management</li>
 *   <li>Automatic cleanup of abandoned goals (TTL-based)</li>
 * </ul>
 *
 * <p>Thread-safe for concurrent use. Each thread maintains its own goal context
 * using instance-scoped ThreadLocal storage.
 *
 * @see com.bhsf.mca.sdk.MCAClient
 */
public class AgenticTracking {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(AgenticTracking.class);

    // Instance-scoped thread-local storage for current goal ID
    // CRITICAL: Not static - each AgenticTracking instance gets its own ThreadLocal
    private final ThreadLocal<String> currentGoalId = new ThreadLocal<>();

    // Active goal spans with TTL tracking
    private final ConcurrentHashMap<String, GoalSpanWithTimestamp> activeGoals = new ConcurrentHashMap<>();

    // Cleanup scheduler for abandoned goals
    private final ScheduledExecutorService cleanupScheduler;
    private static final long DEFAULT_GOAL_TTL_MINUTES = 60;
    private static final long DEFAULT_CLEANUP_INTERVAL_MINUTES = 5;

    // Pre-created instruments for performance
    private final LongCounter goalsStartedCounter;
    private final LongCounter goalsCompletedCounter;
    private final DoubleHistogram goalDurationHistogram;
    private final LongCounter toolsExecutedCounter;
    private final DoubleHistogram toolLatencyHistogram;

    private final Tracer tracer;

    // Shutdown state management
    private final AtomicBoolean isShutdown = new AtomicBoolean(false);

    /**
     * Create a new AgenticTracking instance.
     *
     * @param meter OpenTelemetry Meter for creating metrics
     * @param tracer OpenTelemetry Tracer for creating spans
     */
    public AgenticTracking(Meter meter, Tracer tracer) {
        if (meter == null) {
            throw new IllegalArgumentException("Meter cannot be null");
        }
        if (tracer == null) {
            throw new IllegalArgumentException("Tracer cannot be null");
        }

        this.tracer = tracer;

        // Pre-create all instruments once for performance
        this.goalsStartedCounter = meter.counterBuilder("agentic.goals_started_total")
                .setDescription("Total number of agent goals started")
                .setUnit("1")
                .build();

        this.goalsCompletedCounter = meter.counterBuilder("agentic.goals_completed_total")
                .setDescription("Total number of agent goals completed")
                .setUnit("1")
                .build();

        this.goalDurationHistogram = meter.histogramBuilder("agentic.goal_duration_seconds")
                .setDescription("Duration of agent goals")
                .setUnit("s")
                .build();

        this.toolsExecutedCounter = meter.counterBuilder("agentic.tools_executed_total")
                .setDescription("Total number of tools executed")
                .setUnit("1")
                .build();

        this.toolLatencyHistogram = meter.histogramBuilder("agentic.tool_latency_seconds")
                .setDescription("Latency of tool executions")
                .setUnit("s")
                .build();

        // Start cleanup scheduler for abandoned goals
        this.cleanupScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "agentic-tracking-cleanup");
            t.setDaemon(true);
            return t;
        });

        startCleanupScheduler();

        log.debug("AgenticTracking initialized with pre-cached instruments and cleanup scheduler");
    }

    /**
     * Start periodic cleanup of abandoned goals.
     */
    private void startCleanupScheduler() {
        cleanupScheduler.scheduleAtFixedRate(() -> {
            try {
                cleanupAbandonedGoals();
            } catch (Exception e) {
                log.error("Error during goal cleanup", e);
            }
        }, DEFAULT_CLEANUP_INTERVAL_MINUTES, DEFAULT_CLEANUP_INTERVAL_MINUTES, TimeUnit.MINUTES);
    }

    /**
     * Clean up goals that have exceeded TTL.
     */
    private void cleanupAbandonedGoals() {
        long now = System.currentTimeMillis();
        long ttlMillis = DEFAULT_GOAL_TTL_MINUTES * 60_000;

        activeGoals.entrySet().removeIf(entry -> {
            GoalSpanWithTimestamp gsWithTs = entry.getValue();
            if (now - gsWithTs.startTimeMillis > ttlMillis) {
                String goalId = entry.getKey();
                log.warn("[{}] Cleaning up abandoned goal (started {} minutes ago). " +
                        "Goal was never completed - possible application crash or unhandled exception.",
                        goalId,
                        (now - gsWithTs.startTimeMillis) / 60_000);

                // Finalize goal with metrics (status="timeout")
                finalizeGoal(gsWithTs.goalSpan, "timeout");
                return true;
            }
            return false;
        });
    }

    /**
     * Finalize a goal by ending its span and recording completion metrics.
     *
     * <p>UNIFIED COMPLETION: Called from manual completion, timeout cleanup,
     * interrupted cleanup, and shutdown to ensure metrics consistency.
     *
     * @param goalSpan The goal span to finalize
     * @param status Completion status ("success", "failure", "partial", "timeout", "interrupted")
     */
    private void finalizeGoal(GoalSpan goalSpan, String status) {
        try {
            // Calculate duration
            long endTime = System.nanoTime();
            double durationSeconds = (endTime - goalSpan.startTime) / 1_000_000_000.0;

            // Add status to span
            goalSpan.span.setAttribute("goal.status", status);

            // End span
            goalSpan.span.end();

            // Record metrics WITH goal_type for proper dimensionality
            Attributes metricAttrs = Attributes.builder()
                    .put("status", status)
                    .put("goal_type", goalSpan.goalType)
                    .build();
            goalsCompletedCounter.add(1, metricAttrs);
            goalDurationHistogram.record(durationSeconds, metricAttrs);

            log.debug("Goal finalized: status={}, duration={:.3f}s, type={}",
                    status, durationSeconds, goalSpan.goalType);
        } catch (Exception e) {
            log.error("Error finalizing goal", e);
        }
    }

    /**
     * Start tracking an agent goal.
     *
     * <p>Creates a new goal with a unique ID, starts a parent span, and
     * increments the goals_started counter. The goal must be completed
     * by calling recordGoalCompleted() with the returned goal_id.
     *
     * <p>Sets the current goal ID in thread-local context for correlation
     * with tool executions.
     *
     * @param goalDescription Human-readable description of the goal (max 200 chars)
     * @param goalType Category of goal (e.g., "research", "analysis", "general")
     * @param attributes Additional attributes to attach to the goal span
     * @return Unique goal_id (UUID string) for tracking and completion
     * @throws IllegalStateException if integration has been shut down
     */
    public String recordGoalStarted(String goalDescription, String goalType, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            throw new IllegalStateException("Cannot start goal: AgenticTracking has been shut down");
        }

        // Sanitize inputs to prevent high-cardinality issues
        String goalDescriptionSanitized = (goalDescription != null && !goalDescription.isEmpty())
                ? goalDescription.substring(0, Math.min(goalDescription.length(), 200))
                : "No description";

        String goalTypeSanitized = (goalType != null && !goalType.isEmpty())
                ? goalType.substring(0, Math.min(goalType.length(), 50))
                : "general";

        // Generate unique goal ID
        String goalId = UUID.randomUUID().toString();

        // Create goal span
        Span span = tracer.spanBuilder("agent.goal")
                .setAttribute("goal.id", goalId)
                .setAttribute("goal.description", goalDescriptionSanitized)
                .setAttribute("goal.type", goalTypeSanitized)
                .startSpan();

        // Add custom attributes using shared utility
        TelemetryAttributeUtil.addSpanAttributes(span, attributes);

        // Store goal span with timestamp and thread tracking
        long startTime = System.nanoTime();
        GoalSpan goalSpan = new GoalSpan(span, startTime, Context.current().with(span), goalTypeSanitized);
        activeGoals.put(goalId, new GoalSpanWithTimestamp(goalSpan));

        // Set current goal ID in instance-scoped thread-local context
        currentGoalId.set(goalId);

        // Record metric
        Attributes metricAttrs = Attributes.builder()
                .put("goal_type", goalTypeSanitized)
                .build();
        goalsStartedCounter.add(1, metricAttrs);

        log.debug("[{}] Goal started: {} (type={}, thread={})",
                goalId, goalDescriptionSanitized, goalTypeSanitized, Thread.currentThread().getId());

        return goalId;
    }

    /**
     * Complete tracking of an agent goal.
     *
     * <p>Ends the goal span, records duration metrics, and increments the
     * goals_completed counter with the specified status.
     *
     * @param goalId The goal ID returned from recordGoalStarted()
     * @param status Completion status - must be one of: "success", "failure", "partial"
     * @param attributes Additional attributes to attach to the goal span
     * @throws IllegalArgumentException If goal_id is not found or status is invalid
     * @throws IllegalStateException if integration has been shut down
     */
    public void recordGoalCompleted(String goalId, String status, Map<String, Object> attributes) {
        // CRITICAL: Always clear ThreadLocal, even if shutdown or error
        try {
            if (isShutdown.get()) {
                log.warn("Attempted to complete goal after shutdown: {}. Cleaning up ThreadLocal.", goalId);
                return;
            }

            // Validate status
            if (status == null || (!status.equals("success") && !status.equals("failure") && !status.equals("partial"))) {
                throw new IllegalArgumentException(
                        "Invalid goal status: '" + status + "'. Must be one of: 'success', 'failure', 'partial'"
                );
            }

            // Retrieve goal span
            GoalSpanWithTimestamp gsWithTs = activeGoals.remove(goalId);
            if (gsWithTs == null) {
                throw new IllegalArgumentException("Goal ID not found: " + goalId);
            }

            GoalSpan goalSpan = gsWithTs.goalSpan;

            // Check for cross-thread completion
            long currentThreadId = Thread.currentThread().getId();
            if (goalSpan.threadId != currentThreadId) {
                log.warn("[{}] Goal completed on different thread (started on {}, completed on {}). " +
                        "ThreadLocal context may leak in starting thread.",
                        goalId, goalSpan.threadId, currentThreadId);
            }

            // Calculate duration
            long endTime = System.nanoTime();
            double durationSeconds = (endTime - goalSpan.startTime) / 1_000_000_000.0;

            // Add status and custom attributes to span
            goalSpan.span.setAttribute("goal.status", status);
            TelemetryAttributeUtil.addSpanAttributes(goalSpan.span, attributes);

            // End span
            goalSpan.span.end();

            // Record metrics WITH goal_type for proper dimensionality
            Attributes metricAttrs = Attributes.builder()
                    .put("status", status)
                    .put("goal_type", goalSpan.goalType)  // CRITICAL: Include goal_type
                    .build();
            goalsCompletedCounter.add(1, metricAttrs);
            goalDurationHistogram.record(durationSeconds, metricAttrs);

            log.debug("[{}] Goal completed: status={}, duration={:.3f}s, type={}",
                    goalId, status, durationSeconds, goalSpan.goalType);
        } finally {
            // CRITICAL: Always clear thread-local, even on shutdown/error
            if (goalId != null && goalId.equals(currentGoalId.get())) {
                currentGoalId.remove();
                log.debug("[{}] Cleared ThreadLocal goal context", goalId);
            }
        }
    }

    /**
     * Track tool execution with automatic span and metric recording.
     *
     * <p>Creates a tool span as a child of the current goal span (if any).
     * Use try-with-resources to ensure proper cleanup.
     *
     * <p>IMPORTANT: Automatically falls back to getCurrentGoalId() if goalId is null,
     * enabling automatic tool-to-goal correlation.
     *
     * @param toolName Name of the tool being executed (max 100 chars)
     * @param goalId Optional goal ID to correlate this tool call with a specific goal (null = auto-detect)
     * @param attributes Additional attributes to attach to the tool span
     * @return ToolContext for use in try-with-resources
     * @throws IllegalStateException if integration has been shut down
     */
    public ToolContext trackTool(String toolName, String goalId, Map<String, Object> attributes) {
        if (isShutdown.get()) {
            log.warn("Attempted to track tool after shutdown: {}", toolName);
            // Return a no-op ToolContext to avoid breaking try-with-resources
            return new ToolContext(null, System.nanoTime(), "noop", toolsExecutedCounter, toolLatencyHistogram);
        }

        // Sanitize tool name
        String toolNameSanitized = (toolName != null && !toolName.isEmpty())
                ? toolName.substring(0, Math.min(toolName.length(), 100))
                : "unknown";

        // Fallback to current goal ID if not provided (automatic correlation)
        String effectiveGoalId = goalId;
        if (effectiveGoalId == null) {
            effectiveGoalId = getCurrentGoalId();
        }

        // Determine parent context
        Context parentContext = Context.current();
        if (effectiveGoalId != null) {
            GoalSpanWithTimestamp gsWithTs = activeGoals.get(effectiveGoalId);
            if (gsWithTs != null) {
                parentContext = gsWithTs.goalSpan.context;
            }
        }

        // Create tool span as child of goal span (if any)
        Span span = tracer.spanBuilder("agent.tool")
                .setParent(parentContext)
                .setAttribute("tool.name", toolNameSanitized)
                .startSpan();

        if (effectiveGoalId != null) {
            span.setAttribute("goal.id", effectiveGoalId);
        }

        // Add custom attributes using shared utility
        TelemetryAttributeUtil.addSpanAttributes(span, attributes);

        long startTime = System.nanoTime();

        log.debug("Tool execution started: {} (goal={})", toolNameSanitized, effectiveGoalId);

        return new ToolContext(span, startTime, toolNameSanitized, toolsExecutedCounter, toolLatencyHistogram);
    }

    /**
     * Get the currently active goal ID from thread-local context.
     *
     * <p>Thread-safe retrieval of the goal ID set by recordGoalStarted().
     * <p>SELF-HEALING: Automatically clears stale goal IDs that are no longer
     * in activeGoals (e.g., completed on different thread, timed out, or shutdown).
     *
     * @return goal_id if within a goal context, null otherwise
     */
    public String getCurrentGoalId() {
        String goalId = currentGoalId.get();
        if (goalId != null && !activeGoals.containsKey(goalId)) {
            // Goal was completed/cleaned up but ThreadLocal not cleared
            // (e.g., cross-thread completion, timeout cleanup, shutdown)
            currentGoalId.remove();
            log.debug("[{}] Cleared stale goal ID from ThreadLocal (no longer active)", goalId);
            return null;
        }
        return goalId;
    }

    /**
     * Activate the current goal's span context for distributed tracing.
     *
     * <p>Makes the goal span "current" so that auto-instrumented libraries
     * (HTTP clients, database drivers, etc.) can inherit the trace context
     * and create child spans automatically.
     *
     * <p>Usage (explicit span activation for distributed tracing):
     * <pre>{@code
     * String goalId = agentic.recordGoalStarted("Analyze patient", "analysis", null);
     * try (Scope scope = agentic.activateGoalContext(goalId)) {
     *     // All spans created here will be children of the goal span
     *     httpClient.get("https://api.example.com/data");  // Auto-instrumented
     * }
     * agentic.recordGoalCompleted(goalId, "success", null);
     * }</pre>
     *
     * @param goalId The goal ID to activate (must be an active goal)
     * @return AutoCloseable Scope for use with try-with-resources (null if goal not found)
     * @throws IllegalStateException if integration has been shut down
     */
    public Scope activateGoalContext(String goalId) {
        if (isShutdown.get()) {
            log.warn("Cannot activate goal context after shutdown: {}", goalId);
            return null;
        }

        if (goalId == null) {
            log.warn("Cannot activate null goal ID");
            return null;
        }

        GoalSpanWithTimestamp gsWithTs = activeGoals.get(goalId);
        if (gsWithTs == null) {
            log.warn("[{}] Cannot activate goal context: goal not found (may have completed)", goalId);
            return null;
        }

        // Make the goal span current for distributed tracing
        Scope scope = gsWithTs.goalSpan.span.makeCurrent();
        log.debug("[{}] Activated goal context for distributed tracing", goalId);
        return scope;
    }

    /**
     * Shutdown the AgenticTracking and clean up resources.
     *
     * <p>This method is idempotent - calling it multiple times is safe.
     * Cleans up all active goals and stops the cleanup scheduler.
     * <p>CRITICAL: Records completion metrics for all active goals (status="interrupted").
     */
    public void shutdown() {
        if (isShutdown.compareAndSet(false, true)) {
            log.info("Shutting down AgenticTracking ({} active goals)", activeGoals.size());

            // Finalize all active goal spans with metrics (status="interrupted")
            activeGoals.values().forEach(gsWithTs -> {
                try {
                    finalizeGoal(gsWithTs.goalSpan, "interrupted");
                } catch (Exception e) {
                    log.error("Error finalizing goal during shutdown", e);
                }
            });
            activeGoals.clear();

            // Stop cleanup scheduler
            if (cleanupScheduler != null) {
                cleanupScheduler.shutdown();
                try {
                    if (!cleanupScheduler.awaitTermination(5, TimeUnit.SECONDS)) {
                        cleanupScheduler.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    cleanupScheduler.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }

            log.info("AgenticTracking shutdown complete");
        }
    }

    /**
     * Context manager for tool execution tracking.
     * Implements AutoCloseable for use with try-with-resources.
     *
     * <p>CRITICAL: Activates the span using makeCurrent() to enable
     * distributed tracing context propagation.
     */
    public static class ToolContext implements AutoCloseable {
        private final Span span;
        private final Scope scope;  // For span activation
        private final long startTime;
        private final String toolName;
        private final LongCounter toolsExecutedCounter;
        private final DoubleHistogram toolLatencyHistogram;

        ToolContext(Span span, long startTime, String toolName,
                    LongCounter toolsExecutedCounter, DoubleHistogram toolLatencyHistogram) {
            this.span = span;
            // CRITICAL: Activate span for distributed tracing
            this.scope = (span != null) ? span.makeCurrent() : null;
            this.startTime = startTime;
            this.toolName = toolName;
            this.toolsExecutedCounter = toolsExecutedCounter;
            this.toolLatencyHistogram = toolLatencyHistogram;
        }

        /**
         * Get the span for adding custom attributes.
         *
         * @return OpenTelemetry Span (may be null if shutdown)
         */
        public Span getSpan() {
            return span;
        }

        /**
         * Close the tool context, ending the span and recording metrics.
         *
         * <p>CRITICAL: Closes scope BEFORE ending span to maintain proper context.
         */
        @Override
        public void close() {
            try {
                // Skip if this is a no-op context (created after shutdown)
                if (span == null) {
                    return;
                }

                // Calculate latency
                long endTime = System.nanoTime();
                double latencySeconds = (endTime - startTime) / 1_000_000_000.0;

                // Record metrics
                Attributes attrs = Attributes.builder()
                        .put("tool_name", toolName)
                        .build();
                toolsExecutedCounter.add(1, attrs);
                toolLatencyHistogram.record(latencySeconds, attrs);

                log.debug("Tool execution completed: {} (latency={:.3f}s)", toolName, latencySeconds);
            } finally {
                // CRITICAL: Close scope BEFORE ending span
                if (scope != null) {
                    scope.close();
                }
                if (span != null) {
                    span.end();
                }
            }
        }
    }

    /**
     * Internal class to hold goal span and metadata.
     */
    private static class GoalSpan {
        final Span span;
        final long startTime;
        final Context context;
        final long threadId;      // For cross-thread detection
        final String goalType;    // For metric dimensionality

        GoalSpan(Span span, long startTime, Context context, String goalType) {
            this.span = span;
            this.startTime = startTime;
            this.context = context;
            this.threadId = Thread.currentThread().getId();
            this.goalType = goalType;
        }
    }

    /**
     * Wrapper for GoalSpan with timestamp for TTL tracking.
     */
    private static class GoalSpanWithTimestamp {
        final GoalSpan goalSpan;
        final long startTimeMillis;

        GoalSpanWithTimestamp(GoalSpan goalSpan) {
            this.goalSpan = goalSpan;
            this.startTimeMillis = System.currentTimeMillis();
        }
    }
}
