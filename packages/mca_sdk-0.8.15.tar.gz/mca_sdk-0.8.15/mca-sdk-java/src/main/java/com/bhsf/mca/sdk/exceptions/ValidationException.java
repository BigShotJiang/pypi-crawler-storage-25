package com.bhsf.mca.sdk.exceptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Exception thrown when validation fails.
 *
 * <p>This exception provides detailed context about validation failures including:
 * <ul>
 *   <li>Missing required fields</li>
 *   <li>Invalid field values with specific error messages</li>
 *   <li>Model taxonomy context (type and category)</li>
 * </ul>
 *
 * <p>Examples of validation failures:
 * <ul>
 *   <li>Metric name doesn't follow naming conventions</li>
 *   <li>Required resource attributes are missing</li>
 *   <li>Invalid configuration values</li>
 * </ul>
 */
public class ValidationException extends MCAException {

    private final List<String> missingFields;
    private final Map<String, String> invalidFields;
    private final String modelType;
    private final String modelCategory;

    /**
     * Creates a ValidationException with just a message.
     *
     * @param message Error message
     */
    public ValidationException(String message) {
        this(message, Collections.emptyList(), Collections.emptyMap(), null, null);
    }

    /**
     * Creates a ValidationException with a message and list of missing fields.
     *
     * @param message Error message
     * @param missingFields List of missing required field names
     */
    public ValidationException(String message, List<String> missingFields) {
        this(message, missingFields, Collections.emptyMap(), null, null);
    }

    /**
     * Creates a ValidationException with full context.
     *
     * @param message Error message
     * @param missingFields List of missing required field names
     * @param invalidFields Map of field names to validation error messages
     * @param modelType Model type being validated (e.g., "regression", "generative")
     * @param modelCategory Model category being validated (e.g., "internal", "vendor")
     */
    public ValidationException(String message,
                               List<String> missingFields,
                               Map<String, String> invalidFields,
                               String modelType,
                               String modelCategory) {
        super(message);
        this.missingFields = Collections.unmodifiableList(new ArrayList<>(missingFields));
        this.invalidFields = Collections.unmodifiableMap(new HashMap<>(invalidFields));
        this.modelType = modelType;
        this.modelCategory = modelCategory;
    }

    /**
     * Gets the list of missing required fields.
     *
     * @return Unmodifiable list of missing field names
     */
    public List<String> getMissingFields() {
        return missingFields;
    }

    /**
     * Gets the map of invalid fields to error messages.
     *
     * @return Unmodifiable map of field names to error messages
     */
    public Map<String, String> getInvalidFields() {
        return invalidFields;
    }

    /**
     * Gets the model type that was being validated.
     *
     * @return Model type or null if not applicable
     */
    public String getModelType() {
        return modelType;
    }

    /**
     * Gets the model category that was being validated.
     *
     * @return Model category or null if not applicable
     */
    public String getModelCategory() {
        return modelCategory;
    }
}
