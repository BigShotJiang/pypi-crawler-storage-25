package com.bhsf.mca.sdk.integrations;

import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.common.AttributesBuilder;
import io.opentelemetry.api.trace.Span;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Shared utility for consistent OpenTelemetry attribute handling across integration classes.
 *
 * <p>Provides:
 * <ul>
 *   <li>Defensive copying to prevent ConcurrentModificationException</li>
 *   <li>Extended type support including arrays and collections</li>
 *   <li>Consistent attribute handling across GenAI and Agentic integrations</li>
 * </ul>
 *
 * <p>Thread-safe for concurrent use.
 */
public class TelemetryAttributeUtil {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(TelemetryAttributeUtil.class);

    private TelemetryAttributeUtil() {
        // Utility class - prevent instantiation
    }

    /**
     * Create a defensive copy of the attributes map to prevent ConcurrentModificationException.
     *
     * <p>If the caller modifies the original map while we're iterating over the copy,
     * the iteration won't be affected.
     * <p>DEFENSIVE: Catches CME if map is modified during copy and returns empty map.
     * This prevents SDK from crashing the host application.
     *
     * @param attributes Original attributes map (may be null)
     * @return Defensive copy, empty map on CME, or null if input is null
     */
    public static Map<String, Object> defensiveCopy(Map<String, Object> attributes) {
        if (attributes == null) {
            return null;
        }

        try {
            return new HashMap<>(attributes);
        } catch (ConcurrentModificationException e) {
            // Map was modified during copy - drop attributes rather than crash
            log.debug("Attributes map concurrently modified during copy. Dropping attributes to prevent crash.");
            return Collections.emptyMap();
        } catch (Exception e) {
            // Defensive: catch any other unexpected exception
            log.warn("Unexpected error creating defensive copy of attributes. Dropping attributes.", e);
            return Collections.emptyMap();
        }
    }

    /**
     * Build OpenTelemetry Attributes from a map with extended type support.
     *
     * <p>Supported types:
     * <ul>
     *   <li>String, Long, Integer, Double, Float, Boolean (direct mapping)</li>
     *   <li>String[] (array attribute)</li>
     *   <li>List&lt;String&gt; (converted to array attribute)</li>
     *   <li>Other collections (converted to String[] via toString)</li>
     * </ul>
     *
     * @param attributes Map of attribute key-value pairs (may be null)
     * @return OpenTelemetry Attributes object
     */
    public static Attributes buildAttributes(Map<String, Object> attributes) {
        AttributesBuilder builder = Attributes.builder();

        // Defensive copy to prevent ConcurrentModificationException
        Map<String, Object> safeAttrs = defensiveCopy(attributes);
        if (safeAttrs != null) {
            for (Map.Entry<String, Object> entry : safeAttrs.entrySet()) {
                addAttribute(builder, entry.getKey(), entry.getValue());
            }
        }

        return builder.build();
    }

    /**
     * Add a single attribute to an AttributesBuilder with extended type support.
     *
     * @param builder AttributesBuilder to add to
     * @param key Attribute key
     * @param value Attribute value
     */
    public static void addAttribute(AttributesBuilder builder, String key, Object value) {
        if (value == null) {
            return;
        }

        if (value instanceof String) {
            builder.put(key, (String) value);
        } else if (value instanceof Long) {
            builder.put(key, (Long) value);
        } else if (value instanceof Integer) {
            builder.put(key, ((Integer) value).longValue());
        } else if (value instanceof Double) {
            builder.put(key, (Double) value);
        } else if (value instanceof Float) {
            builder.put(key, ((Float) value).doubleValue());
        } else if (value instanceof Boolean) {
            builder.put(key, (Boolean) value);
        } else if (value instanceof String[]) {
            String[] array = (String[]) value;
            builder.put(key, Arrays.asList(array));
        } else if (value instanceof List) {
            List<?> list = (List<?>) value;
            try {
                // Check if ALL elements are Strings (not just first one)
                boolean allStrings = !list.isEmpty() && list.stream().allMatch(item -> item instanceof String);

                if (allStrings) {
                    @SuppressWarnings("unchecked")
                    List<String> stringList = (List<String>) list;
                    builder.put(key, stringList);
                } else {
                    // Convert mixed/non-String list to String array (null-safe)
                    List<String> stringList = list.stream()
                            .map(String::valueOf)  // Null-safe: converts null to "null"
                            .collect(Collectors.toList());
                    builder.put(key, stringList);
                }
            } catch (Exception e) {
                log.warn("Error processing list attribute '{}'. Dropping attribute.", key, e);
            }
        } else if (value instanceof Collection) {
            try {
                Collection<?> collection = (Collection<?>) value;
                // Null-safe conversion: String::valueOf handles null elements
                List<String> stringList = collection.stream()
                        .map(String::valueOf)
                        .collect(Collectors.toList());
                builder.put(key, stringList);
            } catch (Exception e) {
                log.warn("Error processing collection attribute '{}'. Dropping attribute.", key, e);
            }
        } else {
            log.warn("Ignoring unsupported attribute type for key '{}': {} (type: {}). " +
                    "Supported types: String, Long, Integer, Double, Float, Boolean, String[], List, Collection",
                    key, value.getClass().getSimpleName(), value.getClass().getName());
        }
    }

    /**
     * Add a single attribute to a Span with extended type support.
     *
     * @param span Span to add attribute to
     * @param key Attribute key
     * @param value Attribute value
     */
    public static void addSpanAttribute(Span span, String key, Object value) {
        if (span == null || value == null) {
            return;
        }

        if (value instanceof String) {
            span.setAttribute(key, (String) value);
        } else if (value instanceof Long) {
            span.setAttribute(key, (Long) value);
        } else if (value instanceof Integer) {
            span.setAttribute(key, ((Integer) value).longValue());
        } else if (value instanceof Double) {
            span.setAttribute(key, (Double) value);
        } else if (value instanceof Float) {
            span.setAttribute(key, ((Float) value).doubleValue());
        } else if (value instanceof Boolean) {
            span.setAttribute(key, (Boolean) value);
        } else if (value instanceof String[]) {
            String[] array = (String[]) value;
            span.setAttribute(key, Arrays.asList(array));
        } else if (value instanceof List) {
            List<?> list = (List<?>) value;
            try {
                // Check if ALL elements are Strings (not just first one)
                boolean allStrings = !list.isEmpty() && list.stream().allMatch(item -> item instanceof String);

                if (allStrings) {
                    @SuppressWarnings("unchecked")
                    List<String> stringList = (List<String>) list;
                    span.setAttribute(key, stringList);
                } else {
                    // Convert mixed/non-String list to String array (null-safe)
                    List<String> stringList = list.stream()
                            .map(String::valueOf)  // Null-safe: converts null to "null"
                            .collect(Collectors.toList());
                    span.setAttribute(key, stringList);
                }
            } catch (Exception e) {
                log.warn("Error processing list span attribute '{}'. Dropping attribute.", key, e);
            }
        } else if (value instanceof Collection) {
            try {
                Collection<?> collection = (Collection<?>) value;
                // Null-safe conversion: String::valueOf handles null elements
                List<String> stringList = collection.stream()
                        .map(String::valueOf)
                        .collect(Collectors.toList());
                span.setAttribute(key, stringList);
            } catch (Exception e) {
                log.warn("Error processing collection span attribute '{}'. Dropping attribute.", key, e);
            }
        } else {
            log.warn("Ignoring unsupported span attribute type for key '{}': {}",
                    key, value.getClass().getSimpleName());
        }
    }

    /**
     * Add multiple attributes to a Span from a map.
     *
     * @param span Span to add attributes to
     * @param attributes Map of attribute key-value pairs (may be null)
     */
    public static void addSpanAttributes(Span span, Map<String, Object> attributes) {
        if (span == null) {
            return;
        }

        // Defensive copy to prevent ConcurrentModificationException
        Map<String, Object> safeAttrs = defensiveCopy(attributes);
        if (safeAttrs != null) {
            for (Map.Entry<String, Object> entry : safeAttrs.entrySet()) {
                addSpanAttribute(span, entry.getKey(), entry.getValue());
            }
        }
    }
}
