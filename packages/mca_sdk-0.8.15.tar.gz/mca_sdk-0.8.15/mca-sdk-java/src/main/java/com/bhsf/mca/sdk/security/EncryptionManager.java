package com.bhsf.mca.sdk.security;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Manages encryption keys for AES-256-GCM encryption.
 *
 * <p>Provides utilities for key generation, loading keys from environment variables,
 * and key validation.
 *
 * <p>Keys must be 32 bytes (256 bits) for AES-256 encryption.
 *
 * <p>Example usage:
 * <pre>{@code
 * // Generate a new key
 * byte[] key = EncryptionManager.generateKey();
 *
 * // Load key from environment variable MCA_QUEUE_ENCRYPTION_KEY
 * SecretKey secretKey = EncryptionManager.loadKeyFromEnvironment();
 *
 * // Validate key
 * EncryptionManager.validateKey(key);
 * }</pre>
 */
public class EncryptionManager {
    private static final Logger logger = LoggerFactory.getLogger(EncryptionManager.class);
    private static final String ENV_KEY_NAME = "MCA_QUEUE_ENCRYPTION_KEY";
    private static final String ENV_KEY_FILE_NAME = "MCA_QUEUE_ENCRYPTION_KEY_FILE";
    private static final int AES_256_KEY_LENGTH = 32; // 256 bits / 8

    /**
     * Generates a new 256-bit AES encryption key using SecureRandom.
     *
     * @return 32-byte encryption key
     */
    public static byte[] generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(256, new SecureRandom());
            SecretKey secretKey = keyGen.generateKey();
            return secretKey.getEncoded();
        } catch (NoSuchAlgorithmException e) {
            throw new SecurityException("Failed to generate encryption key", e);
        }
    }

    /**
     * Loads encryption key from environment variable or file (Kubernetes-compatible).
     *
     * <p>Key loading priority:
     * <ol>
     *   <li>MCA_QUEUE_ENCRYPTION_KEY_FILE - Path to file containing base64-encoded key (Kubernetes secrets)</li>
     *   <li>MCA_QUEUE_ENCRYPTION_KEY - Direct base64-encoded key string</li>
     * </ol>
     *
     * @return SecretKey for AES-256 encryption
     * @throws ConfigurationException if key is not found, invalid format, or wrong length
     */
    public static SecretKey loadKeyFromEnvironment() {
        // Check for file-based key first (Kubernetes pattern)
        String keyFilePath = System.getenv(ENV_KEY_FILE_NAME);
        if (keyFilePath != null && !keyFilePath.trim().isEmpty()) {
            try {
                String keyStr = java.nio.file.Files.readString(java.nio.file.Paths.get(keyFilePath.trim()));
                byte[] keyBytes = Base64.getDecoder().decode(keyStr.trim());
                validateKey(keyBytes);
                logger.info("Loaded encryption key from file: {}", keyFilePath);
                return new SecretKeySpec(keyBytes, "AES");
            } catch (java.io.IOException e) {
                throw new ConfigurationException(
                    String.format("Failed to read encryption key from file: %s", keyFilePath), e
                );
            } catch (IllegalArgumentException e) {
                throw new ConfigurationException(
                    String.format("Invalid encryption key format in file %s. Must be base64-encoded", keyFilePath), e
                );
            }
        }

        // Fall back to direct environment variable
        String keyStr = System.getenv(ENV_KEY_NAME);
        if (keyStr == null || keyStr.trim().isEmpty()) {
            throw new ConfigurationException(
                String.format("Encryption key not found. Set environment variable %s with a base64-encoded 32-byte key, " +
                    "or set %s to path of file containing the key. " +
                    "Generate a key with: EncryptionManager.generateKey()", ENV_KEY_NAME, ENV_KEY_FILE_NAME)
            );
        }

        try {
            byte[] keyBytes = Base64.getDecoder().decode(keyStr.trim());
            validateKey(keyBytes);
            return new SecretKeySpec(keyBytes, "AES");
        } catch (IllegalArgumentException e) {
            throw new ConfigurationException(
                String.format("Invalid encryption key format in %s. Must be base64-encoded", ENV_KEY_NAME), e
            );
        }
    }

    /**
     * Validates that the key is exactly 32 bytes (256 bits) for AES-256.
     *
     * @param key the encryption key to validate
     * @throws ConfigurationException if key length is invalid
     */
    public static void validateKey(byte[] key) {
        if (key == null) {
            throw new ConfigurationException("Encryption key cannot be null");
        }

        if (key.length != AES_256_KEY_LENGTH) {
            throw new ConfigurationException(
                String.format("Invalid encryption key length: %d bytes. AES-256 requires exactly 32 bytes (256 bits). " +
                    "Generate a valid key with: EncryptionManager.generateKey()", key.length)
            );
        }
    }

    /**
     * Creates a SecretKey from raw bytes.
     *
     * @param keyBytes 32-byte encryption key
     * @return SecretKey for AES-256
     * @throws ConfigurationException if key is invalid
     */
    public static SecretKey createSecretKey(byte[] keyBytes) {
        validateKey(keyBytes);
        return new SecretKeySpec(keyBytes, "AES");
    }

    /**
     * Encodes a key as base64 string for storage in environment variables.
     *
     * @param key the encryption key
     * @return base64-encoded key string
     */
    public static String encodeKeyForEnvironment(byte[] key) {
        validateKey(key);
        return Base64.getEncoder().encodeToString(key);
    }
}
