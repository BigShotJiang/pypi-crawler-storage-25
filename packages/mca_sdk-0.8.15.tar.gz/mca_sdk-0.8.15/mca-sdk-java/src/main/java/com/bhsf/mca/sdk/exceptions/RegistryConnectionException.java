package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when unable to connect to the registry.
 *
 * <p>This exception indicates a network-level failure when attempting to
 * communicate with the registry service. Common causes include:
 * <ul>
 *   <li>Network timeout - Registry took too long to respond</li>
 *   <li>DNS resolution failure - Unable to resolve registry hostname</li>
 *   <li>Connection refused - Registry service not running or unreachable</li>
 *   <li>SSL/TLS handshake failure - Certificate validation issues</li>
 * </ul>
 *
 * <p>Usage example:
 * <pre>{@code
 * try {
 *     ModelConfig config = registryClient.fetchModelConfig("mdl-001");
 * } catch (RegistryConnectionException e) {
 *     logger.error("Registry unavailable, using fallback config", e);
 *     // Use cached or default configuration
 * }
 * }</pre>
 */
public class RegistryConnectionException extends RegistryException {

    /**
     * Create a connection exception with a message.
     *
     * @param message Error message describing the connection failure
     */
    public RegistryConnectionException(String message) {
        super(message);
    }

    /**
     * Create a connection exception with a message and cause.
     *
     * @param message Error message describing the connection failure
     * @param cause   Underlying cause (e.g., IOException, SocketTimeoutException)
     */
    public RegistryConnectionException(String message, Throwable cause) {
        super(message, cause);
    }
}
