package com.bhsf.mca.sdk.validation;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Validation rules for resource attributes based on model taxonomy.
 *
 * <p>Defines required and optional attributes for each model type based on the
 * two-field taxonomy (model_category + model_type).
 *
 * <p>Required attributes by model type:
 * <ul>
 *   <li>internal/regression, time-series, classification: service.name, model.id, model.version, team.name</li>
 *   <li>internal/generative, agentic: service.name, llm.provider, llm.model, team.name</li>
 *   <li>vendor/*: service.name, vendor.name, team.name</li>
 * </ul>
 */
public class ValidationRules {

    // Attribute name constants
    public static final String ATTR_SERVICE_NAME = "service.name";
    public static final String ATTR_MODEL_ID = "model.id";
    public static final String ATTR_MODEL_VERSION = "model.version";
    public static final String ATTR_MODEL_TYPE = "model.type";
    public static final String ATTR_TEAM_NAME = "team.name";
    public static final String ATTR_LLM_PROVIDER = "llm.provider";
    public static final String ATTR_LLM_MODEL = "llm.model";
    public static final String ATTR_VENDOR_NAME = "vendor.name";
    public static final String ATTR_SERVICE_VERSION = "service.version";
    public static final String ATTR_DEPLOYMENT_ENV = "deployment.environment";

    /**
     * Rule set for a model taxonomy.
     */
    public static class RuleSet {
        private final List<String> required;
        private final List<String> optional;

        public RuleSet(List<String> required, List<String> optional) {
            this.required = Collections.unmodifiableList(required);
            this.optional = Collections.unmodifiableList(optional);
        }

        public List<String> getRequired() {
            return required;
        }

        public List<String> getOptional() {
            return optional;
        }
    }

    /**
     * Key for validation rules map.
     */
    private static class TaxonomyKey {
        private final String category;
        private final String type;

        TaxonomyKey(String category, String type) {
            this.category = category == null ? null : category.toLowerCase().trim();
            this.type = type == null ? null : type.toLowerCase().trim();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            TaxonomyKey that = (TaxonomyKey) o;
            return Objects.equals(category, that.category) && Objects.equals(type, that.type);
        }

        @Override
        public int hashCode() {
            return Objects.hash(category, type);
        }
    }

    private static final List<String> COMMON_OPTIONAL = Collections.unmodifiableList(Arrays.asList(
        ATTR_SERVICE_VERSION,
        ATTR_DEPLOYMENT_ENV
    ));

    private static final List<String> GENAI_OPTIONAL = Collections.unmodifiableList(Arrays.asList(
        ATTR_MODEL_ID,
        ATTR_MODEL_VERSION,
        ATTR_SERVICE_VERSION,
        ATTR_DEPLOYMENT_ENV
    ));

    private static final List<String> VENDOR_OPTIONAL = Collections.unmodifiableList(Arrays.asList(
        ATTR_MODEL_TYPE,
        ATTR_SERVICE_VERSION,
        ATTR_DEPLOYMENT_ENV
    ));

    // Validation rules matrix
    private static final Map<TaxonomyKey, RuleSet> VALIDATION_RULES;

    static {
        Map<TaxonomyKey, RuleSet> rules = new HashMap<>();

        // Internal regression
        rules.put(
            new TaxonomyKey("internal", "regression"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME),
                COMMON_OPTIONAL
            )
        );

        // Internal time-series
        rules.put(
            new TaxonomyKey("internal", "time-series"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME),
                COMMON_OPTIONAL
            )
        );

        // Internal classification
        rules.put(
            new TaxonomyKey("internal", "classification"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME),
                COMMON_OPTIONAL
            )
        );

        // Internal generative
        rules.put(
            new TaxonomyKey("internal", "generative"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_LLM_PROVIDER, ATTR_LLM_MODEL, ATTR_TEAM_NAME),
                GENAI_OPTIONAL
            )
        );

        // Internal agentic
        rules.put(
            new TaxonomyKey("internal", "agentic"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_LLM_PROVIDER, ATTR_TEAM_NAME),
                Arrays.asList(ATTR_LLM_MODEL, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_SERVICE_VERSION, ATTR_DEPLOYMENT_ENV)
            )
        );

        // Vendor wildcard (applies to all vendor model types)
        rules.put(
            new TaxonomyKey("vendor", "*"),
            new RuleSet(
                Arrays.asList(ATTR_SERVICE_NAME, ATTR_VENDOR_NAME, ATTR_TEAM_NAME),
                VENDOR_OPTIONAL
            )
        );

        VALIDATION_RULES = Collections.unmodifiableMap(rules);
    }

    /**
     * Gets validation rules for the given taxonomy.
     *
     * @param modelCategory High-level category ("internal" or "vendor")
     * @param modelType Specific model type ("regression", "generative", etc.)
     * @return RuleSet with required and optional attribute lists
     * @throws IllegalArgumentException if no rules exist for the given combination
     */
    public static RuleSet getValidationRules(String modelCategory, String modelType) {
        if (modelCategory == null || modelCategory.trim().isEmpty()) {
            throw new IllegalArgumentException("model_category cannot be null or empty");
        }

        String normalizedCategory = modelCategory.trim().toLowerCase();

        // Vendor uses wildcard for model_type
        if ("vendor".equals(normalizedCategory)) {
            RuleSet rules = VALIDATION_RULES.get(new TaxonomyKey("vendor", "*"));
            if (rules == null) {
                throw new IllegalArgumentException(
                    "No validation rules for model_category=" + modelCategory
                );
            }
            return rules;
        }

        // For internal, require specific model_type
        if (modelType == null || modelType.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "model_type is required for model_category=" + modelCategory
            );
        }

        TaxonomyKey key = new TaxonomyKey(modelCategory, modelType);
        RuleSet rules = VALIDATION_RULES.get(key);

        if (rules == null) {
            throw new IllegalArgumentException(
                "No validation rules for model_category=" + modelCategory +
                ", model_type=" + modelType +
                ". Valid types for 'internal': regression, time-series, classification, generative, agentic. " +
                "Valid categories: internal, vendor."
            );
        }

        return rules;
    }

    /**
     * Gets required attributes for the given taxonomy.
     *
     * @param modelCategory High-level category
     * @param modelType Specific model type
     * @return Unmodifiable list of required attribute names
     * @throws IllegalArgumentException if taxonomy is invalid
     */
    public static List<String> getRequiredAttributes(String modelCategory, String modelType) {
        return getValidationRules(modelCategory, modelType).getRequired();
    }

    /**
     * Gets optional attributes for the given taxonomy.
     *
     * @param modelCategory High-level category
     * @param modelType Specific model type
     * @return Unmodifiable list of optional attribute names
     * @throws IllegalArgumentException if taxonomy is invalid
     */
    public static List<String> getOptionalAttributes(String modelCategory, String modelType) {
        return getValidationRules(modelCategory, modelType).getOptional();
    }
}
