package com.bhsf.mca.sdk.exceptions;

/**
 * Base exception for all registry operations.
 *
 * <p>This exception is thrown when registry operations fail due to:
 * <ul>
 *   <li>Connection failures (network, DNS, timeout)</li>
 *   <li>Authentication failures (invalid token, expired credentials)</li>
 *   <li>Configuration not found (404 responses)</li>
 *   <li>Invalid registry responses or configuration</li>
 * </ul>
 *
 * <p>Use specific subclasses to catch particular failure types:
 * <ul>
 *   <li>{@link RegistryConnectionException} - Network/connection failures</li>
 *   <li>{@link RegistryAuthException} - Authentication failures</li>
 *   <li>{@link RegistryConfigNotFoundException} - Model/deployment not found</li>
 * </ul>
 */
public class RegistryException extends MCAException {

    /**
     * Create a registry exception with a message.
     *
     * @param message Error message describing the failure
     */
    public RegistryException(String message) {
        super(message);
    }

    /**
     * Create a registry exception with a message and cause.
     *
     * @param message Error message describing the failure
     * @param cause   Underlying cause of the failure
     */
    public RegistryException(String message, Throwable cause) {
        super(message, cause);
    }
}
