package com.bhsf.mca.sdk.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Wrapper for GCP Secret Manager client.
 *
 * <p>Provides secure access to secrets stored in Google Cloud Secret Manager.
 * Handles authentication using Application Default Credentials.
 *
 * <p>This implementation uses proper optional dependency pattern: the GCP Secret Manager
 * library classes are directly imported in {@link GcpSecretProvider}, which is only loaded
 * at runtime if the library is available. This provides compile-time type safety while
 * gracefully handling missing optional dependencies.
 *
 * <p>Example usage:
 * <pre>{@code
 * SecretManager manager = new SecretManager("my-gcp-project");
 * String apiKey = manager.fetchSecret("api-key-secret");
 * manager.close();
 * }</pre>
 *
 * <p><strong>Note:</strong> Error messages are intentionally generic to prevent
 * information leakage about secret existence or access permissions.
 */
public class SecretManager implements AutoCloseable {
    private static final Logger logger = LoggerFactory.getLogger(SecretManager.class);
    private static final boolean GCP_AVAILABLE = checkGcpAvailability();

    private final String projectId;
    private final GcpSecretProvider provider;

    /**
     * Checks if GCP Secret Manager library is available at runtime.
     *
     * <p>This check prevents NoClassDefFoundError by verifying the library
     * before attempting to load GcpSecretProvider.
     */
    private static boolean checkGcpAvailability() {
        try {
            Class.forName("com.google.cloud.secretmanager.v1.SecretManagerServiceClient");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Constructs a SecretManager for the specified GCP project.
     *
     * @param projectId GCP project ID containing secrets
     * @throws SecurityException if GCP Secret Manager library is not available or initialization fails
     */
    public SecretManager(String projectId) {
        if (projectId == null || projectId.trim().isEmpty()) {
            throw new IllegalArgumentException("GCP project ID cannot be null or empty");
        }

        this.projectId = projectId;

        if (!GCP_AVAILABLE) {
            throw new SecurityException(
                "GCP Secret Manager library not found. Add dependency: " +
                "com.google.cloud:google-cloud-secretmanager to use this feature"
            );
        }

        try {
            // GcpSecretProvider will only be loaded if GCP_AVAILABLE is true
            // This provides compile-time type safety with runtime optional dependency support
            this.provider = new GcpSecretProvider(projectId);
            logger.info("GCP Secret Manager initialized for project: {}", projectId);
        } catch (Exception e) {
            throw new SecurityException(
                "Failed to initialize GCP Secret Manager client. Ensure Application Default Credentials are configured",
                e
            );
        }
    }

    /**
     * Package-private constructor for testing with mocked provider.
     *
     * @param projectId GCP project ID
     * @param provider mocked GcpSecretProvider for testing
     */
    SecretManager(String projectId, GcpSecretProvider provider) {
        this.projectId = projectId;
        this.provider = provider;
    }

    /**
     * Fetches the latest version of a secret from GCP Secret Manager.
     *
     * <p>Uses Application Default Credentials for authentication. Ensure the service
     * account or user has the required permissions (roles/secretmanager.secretAccessor).
     *
     * @param secretName name of the secret to fetch
     * @return secret value as string
     * @throws SecurityException if secret cannot be accessed
     */
    public String fetchSecret(String secretName) {
        if (secretName == null || secretName.trim().isEmpty()) {
            throw new IllegalArgumentException("Secret name cannot be null or empty");
        }

        if (!GCP_AVAILABLE) {
            throw new SecurityException("GCP Secret Manager library not available");
        }

        return provider.fetchSecret(secretName);
    }

    /**
     * Closes the Secret Manager client and releases resources.
     */
    @Override
    public void close() {
        if (provider != null) {
            provider.close();
        }
    }
}
