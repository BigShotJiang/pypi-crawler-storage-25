package com.bhsf.mca.sdk.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * String utilities for common operations including credential masking.
 *
 * <p>SECURITY: Provides credential pattern detection and masking to prevent
 * accidental credential leakage in logs and error messages.
 *
 * <p>This class is stateless and thread-safe. All methods are static.
 *
 * <p>Example usage:
 * <pre>{@code
 * String text = "Error: Invalid AWS key AKIAIOSFODNN7EXAMPLE";
 * String masked = StringUtils.sanitizeCredentials(text);
 * // Result: "Error: Invalid AWS key AKIA***MPLE"
 *
 * String token = "my-secret-token-12345";
 * String masked = StringUtils.maskCredential(token);
 * // Result: "***2345"
 * }</pre>
 *
 * @since 0.2.0
 */
public final class StringUtils {

    // Credential patterns (from Python SDK and CredentialMasking)
    private static final Pattern AWS_KEY_PATTERN = Pattern.compile(
            "\\b(AKIA|ASIA)[0-9A-Z]{16}\\b");
    private static final Pattern GCP_KEY_PATTERN = Pattern.compile(
            "\\bAIzaSy[A-Za-z0-9_-]{33}\\b");
    // JWT pattern: header.payload.signature (payload doesn't have to start with eyJ)
    private static final Pattern JWT_PATTERN = Pattern.compile(
            "\\beyJ[A-Za-z0-9_-]{10,5000}\\.[A-Za-z0-9_-]{1,5000}\\.[A-Za-z0-9_-]{10,5000}\\b");
    private static final Pattern BEARER_TOKEN_PATTERN = Pattern.compile(
            "Bearer\\s+[A-Za-z0-9._+/=-]{20,}", Pattern.CASE_INSENSITIVE);

    private StringUtils() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Masks a credential string showing only the last 4 characters.
     *
     * <p>Format: ***WXYZ where WXYZ are the last 4 characters of the credential.
     * If the credential is shorter than 4 characters, it is fully masked.
     *
     * @param credential credential to mask
     * @return masked credential (***last4) or empty string if null
     */
    public static String maskCredential(String credential) {
        if (credential == null || credential.isEmpty()) {
            return "";
        }
        if (credential.length() <= 4) {
            return "****";
        }
        String last4 = credential.substring(credential.length() - 4);
        return "***" + last4;
    }

    /**
     * Masks a credential within a larger string.
     *
     * <p>Replaces all occurrences of the credential with its masked version.
     *
     * @param text text containing credential
     * @param credential credential to mask
     * @return text with credential replaced by masked version
     */
    public static String maskCredential(String text, String credential) {
        if (text == null || credential == null) {
            return text;
        }
        String masked = maskCredential(credential);
        return text.replace(credential, masked);
    }

    /**
     * Sanitizes all credential patterns from text.
     *
     * <p>Masks AWS keys, GCP keys, JWT tokens, and Bearer tokens using pattern matching.
     *
     * @param text text to sanitize
     * @return sanitized text with credentials masked
     */
    public static String sanitizeCredentials(String text) {
        if (text == null) {
            return null;
        }

        String result = text;

        // Mask AWS keys (show prefix AKIA/ASIA and last 4 chars)
        result = maskPattern(result, AWS_KEY_PATTERN, 4, true);

        // Mask GCP keys (show prefix AIzaSy and last 4 chars)
        result = maskPattern(result, GCP_KEY_PATTERN, 4, true);

        // Mask JWT tokens (show prefix eyJ and last 6 chars)
        result = maskPattern(result, JWT_PATTERN, 6, true);

        // Mask Bearer tokens (keep "Bearer " prefix, mask the token)
        result = maskBearerTokens(result);

        return result;
    }

    /**
     * Checks if text contains credential patterns.
     *
     * @param text text to check
     * @return true if text contains AWS key, GCP key, JWT, or Bearer token
     */
    public static boolean containsCredential(String text) {
        if (text == null) {
            return false;
        }
        return AWS_KEY_PATTERN.matcher(text).find()
                || GCP_KEY_PATTERN.matcher(text).find()
                || JWT_PATTERN.matcher(text).find()
                || BEARER_TOKEN_PATTERN.matcher(text).find();
    }

    /**
     * Truncates string to maximum length with marker.
     *
     * @param text text to truncate
     * @param maxLength maximum length (including marker)
     * @return original or truncated string with "..." marker
     */
    public static String truncate(String text, int maxLength) {
        if (text == null) {
            return null;
        }
        if (text.length() <= maxLength) {
            return text;
        }
        if (maxLength <= 3) {
            return "...";
        }
        return text.substring(0, maxLength - 3) + "...";
    }

    /**
     * Masks a pattern showing prefix and last N characters.
     *
     * @param text text to process
     * @param pattern pattern to match
     * @param showLast number of characters to show at the end
     * @param keepPrefix whether to keep the pattern's natural prefix
     * @return text with pattern masked
     */
    private static String maskPattern(String text, Pattern pattern, int showLast, boolean keepPrefix) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            String match = matcher.group();
            String masked;

            if (keepPrefix && match.length() > showLast) {
                // Determine prefix length (e.g., "AKIA" = 4, "AIzaSy" = 6, "eyJ" = 3)
                int prefixLen = determinePrefixLength(match);

                // Prevent invalid substring operations for short strings
                if (match.length() <= prefixLen + showLast) {
                    masked = "****";
                } else {
                    String prefix = match.substring(0, prefixLen);
                    String lastChars = match.substring(match.length() - showLast);
                    masked = prefix + "***" + lastChars;
                }
            } else if (match.length() > showLast) {
                String lastChars = match.substring(match.length() - showLast);
                masked = "***" + lastChars;
            } else {
                masked = "****";
            }

            matcher.appendReplacement(sb, Matcher.quoteReplacement(masked));
        }
        matcher.appendTail(sb);

        return sb.toString();
    }

    /**
     * Determines the prefix length for credential patterns.
     */
    private static int determinePrefixLength(String match) {
        if (match.startsWith("AKIA") || match.startsWith("ASIA")) {
            return 4;
        } else if (match.startsWith("AIzaSy")) {
            return 6;
        } else if (match.startsWith("eyJ")) {
            return 3;
        }
        return 0;
    }

    /**
     * Masks Bearer tokens while keeping the "Bearer " prefix.
     */
    private static String maskBearerTokens(String text) {
        Matcher matcher = BEARER_TOKEN_PATTERN.matcher(text);
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            String match = matcher.group();
            // Extract the token part after "Bearer "
            int bearerIndex = match.toLowerCase().indexOf("bearer ");
            if (bearerIndex >= 0) {
                String tokenPart = match.substring(bearerIndex + 7); // 7 = "Bearer ".length()
                String masked;
                if (tokenPart.length() > 8) {
                    String lastChars = tokenPart.substring(tokenPart.length() - 8);
                    masked = "Bearer ***" + lastChars;
                } else {
                    masked = "Bearer ****";
                }
                matcher.appendReplacement(sb, Matcher.quoteReplacement(masked));
            }
        }
        matcher.appendTail(sb);

        return sb.toString();
    }
}
