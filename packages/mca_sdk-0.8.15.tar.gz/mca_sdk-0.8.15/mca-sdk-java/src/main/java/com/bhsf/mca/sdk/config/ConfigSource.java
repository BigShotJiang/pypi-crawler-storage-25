package com.bhsf.mca.sdk.config;

/**
 * Identifies the source from which a configuration value was loaded.
 * Used to enforce precedence rules:
 * BUILDER > REGISTRY > ENV > FILE > DEFAULT
 */
public enum ConfigSource {
    BUILDER,
    REGISTRY,
    ENV,
    FILE,
    DEFAULT
}
