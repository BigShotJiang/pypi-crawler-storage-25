package com.bhsf.mca.sdk.registry.models;

/**
 * Cache entry with expiration time for registry configurations.
 *
 * <p>Holds a cached value (ModelConfig or DeploymentConfig) along with
 * an expiration timestamp. Used by RegistryClient to implement TTL-based
 * cache invalidation.
 *
 * <p>Thread-safe for concurrent reads. Immutable once created.
 *
 * @param <T> Type of cached value (ModelConfig or DeploymentConfig)
 */
public class CacheEntry<T> {

    private final T value;
    private final long expiresAt;

    /**
     * Create a cache entry with value and expiration time.
     *
     * @param value     Cached value (not null)
     * @param expiresAt Expiration timestamp in milliseconds since epoch
     * @throws IllegalArgumentException if value is null
     */
    public CacheEntry(T value, long expiresAt) {
        if (value == null) {
            throw new IllegalArgumentException("Cached value cannot be null");
        }
        this.value = value;
        this.expiresAt = expiresAt;
    }

    /**
     * Get the cached value.
     *
     * @return Cached value
     */
    public T getValue() {
        return value;
    }

    /**
     * Get the expiration timestamp.
     *
     * @return Expiration time in milliseconds since epoch
     */
    public long getExpiresAt() {
        return expiresAt;
    }

    /**
     * Check if this cache entry has expired.
     *
     * <p>Compares the expiration timestamp with current system time.
     * Returns true if current time is past the expiration time.
     *
     * @return true if entry has expired, false otherwise
     */
    public boolean isExpired() {
        return System.currentTimeMillis() > expiresAt;
    }

    /**
     * Check if this cache entry is still valid.
     *
     * <p>Inverse of {@link #isExpired()}. Returns true if the entry
     * has not yet reached its expiration time.
     *
     * @return true if entry is still valid, false if expired
     */
    public boolean isValid() {
        return !isExpired();
    }
}
