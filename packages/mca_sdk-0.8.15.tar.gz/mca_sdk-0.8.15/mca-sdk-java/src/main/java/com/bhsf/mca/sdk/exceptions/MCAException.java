package com.bhsf.mca.sdk.exceptions;

import com.bhsf.mca.sdk.security.CredentialMasking;

/**
 * Base exception for all MCA SDK errors.
 *
 * <p>SECURITY: Overrides getMessage() to sanitize sensitive data (tokens, passwords)
 * from error messages before they appear in tracebacks or logs.
 *
 * <p>Use this to catch any SDK-related exception.
 *
 * <pre>{@code
 * try {
 *     client = new MCAClient.Builder().build();
 * } catch (MCAException e) {
 *     logger.error("SDK error: {}", e.getMessage());
 * }
 * }</pre>
 */
public class MCAException extends RuntimeException {

    public MCAException(String message) {
        super(message);
    }

    public MCAException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Returns sanitized error message with credentials masked.
     *
     * <p>Automatically redacts registry tokens and other secrets from the
     * error message to prevent credential leakage in tracebacks and logs.
     *
     * @return sanitized error message
     */
    @Override
    public String getMessage() {
        String message = super.getMessage();
        if (message == null) {
            return null;
        }

        // Sanitize registry token from environment
        String registryToken = System.getenv("MCA_REGISTRY_TOKEN");
        if (registryToken != null && message.contains(registryToken)) {
            message = message.replace(registryToken,
                CredentialMasking.maskRegistryToken(registryToken));
        }

        // Sanitize other credential patterns (AWS, GCP, JWT, Bearer)
        return CredentialMasking.maskCredentials(message);
    }
}
