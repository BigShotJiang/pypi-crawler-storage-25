package com.bhsf.mca.sdk.security;

import java.util.regex.Pattern;

/**
 * Utility class for masking credentials in text to prevent exposure in logs and telemetry.
 *
 * <p>Detects and masks various credential patterns including:
 * <ul>
 *   <li>AWS Access Keys (AKIA...)</li>
 *   <li>GCP API Keys (AIzaSy...)</li>
 *   <li>JWT Tokens (eyJ...)</li>
 *   <li>Bearer Tokens</li>
 *   <li>Registry Tokens (partial masking)</li>
 * </ul>
 *
 * <p>This class is stateless and thread-safe. All methods are static.
 *
 * <p>Example usage:
 * <pre>{@code
 * String log = "Error: Invalid AWS key AKIAIOSFODNN7EXAMPLE";
 * String masked = CredentialMasking.maskCredentials(log);
 * // Result: "Error: Invalid AWS key [AWS-KEY-REDACTED]"
 *
 * String error = "Authentication failed with token abc123...";
 * String safe = CredentialMasking.sanitizeErrorMessage(error);
 * // Result: Masked credentials + truncated to 200 chars
 * }</pre>
 */
public class CredentialMasking {

    // AWS Access Keys: AKIA (permanent) or ASIA (temporary/session) followed by 16 alphanumeric chars
    private static final Pattern AWS_KEY = Pattern.compile("\\b(AKIA|ASIA)[0-9A-Z]{16}\\b");
    private static final String AWS_REPLACEMENT = "[AWS-KEY-REDACTED]";

    // GCP API Keys: AIzaSy followed by 33 chars
    private static final Pattern GCP_KEY = Pattern.compile("\\bAIzaSy[A-Za-z0-9_-]{33}\\b");
    private static final String GCP_REPLACEMENT = "[GCP-KEY-REDACTED]";

    // JWT Tokens: three base64 segments separated by dots (eyJ prefix)
    // Bounded quantifiers prevent ReDoS attacks on large log strings
    private static final Pattern JWT = Pattern.compile("\\beyJ[A-Za-z0-9_-]{10,5000}\\.eyJ[A-Za-z0-9_-]{10,5000}\\.[A-Za-z0-9_-]{10,5000}\\b");
    private static final String JWT_REPLACEMENT = "[JWT-REDACTED]";

    // Bearer Tokens: "Bearer " followed by token
    private static final Pattern BEARER = Pattern.compile("Bearer\\s+[A-Za-z0-9._+/=-]{20,}");
    private static final String BEARER_REPLACEMENT = "Bearer [TOKEN-REDACTED]";

    // Increased to accommodate Java stack traces; consider removing truncation entirely
    // and letting logging framework handle length limits via logback.xml/log4j2.xml
    private static final int MAX_ERROR_MESSAGE_LENGTH = 4096;

    /**
     * Private constructor to prevent instantiation.
     */
    private CredentialMasking() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    /**
     * Masks all known credential patterns in the given text.
     *
     * <p>Applies masking for AWS keys, GCP keys, JWT tokens, and Bearer tokens.
     * The original text is not modified.
     *
     * @param text text that may contain credentials
     * @return text with credentials replaced by redaction markers
     */
    public static String maskCredentials(String text) {
        if (text == null) {
            return null;
        }

        String result = text;
        result = AWS_KEY.matcher(result).replaceAll(AWS_REPLACEMENT);
        result = GCP_KEY.matcher(result).replaceAll(GCP_REPLACEMENT);
        result = JWT.matcher(result).replaceAll(JWT_REPLACEMENT);
        result = BEARER.matcher(result).replaceAll(BEARER_REPLACEMENT);

        return result;
    }

    /**
     * Masks registry tokens showing only the last 4 characters.
     *
     * <p>Format: ***WXYZ where WXYZ are the last 4 characters of the token.
     * If the token is shorter than 4 characters, it is fully masked.
     *
     * @param token registry token to mask
     * @return masked token showing only last 4 characters
     */
    public static String maskRegistryToken(String token) {
        if (token == null || token.isEmpty()) {
            return "[TOKEN-REDACTED]";
        }

        if (token.length() <= 4) {
            return "***";
        }

        String lastFour = token.substring(token.length() - 4);
        return "***" + lastFour;
    }

    /**
     * Sanitizes error messages to prevent credential leakage.
     *
     * <p>Performs two operations:
     * <ol>
     *   <li>Masks all credential patterns using {@link #maskCredentials(String)}</li>
     *   <li>Truncates message to maximum 200 characters to prevent log injection</li>
     * </ol>
     *
     * <p>Use this method before logging exceptions or error messages that may
     * contain sensitive data.
     *
     * @param errorMessage error message to sanitize
     * @return sanitized error message with credentials masked and truncated
     */
    public static String sanitizeErrorMessage(String errorMessage) {
        if (errorMessage == null) {
            return null;
        }

        // First mask credentials
        String masked = maskCredentials(errorMessage);

        // Then truncate if too long
        if (masked.length() > MAX_ERROR_MESSAGE_LENGTH) {
            return masked.substring(0, MAX_ERROR_MESSAGE_LENGTH) + "... [truncated]";
        }

        return masked;
    }

    /**
     * Sanitizes error messages with custom max length.
     *
     * @param errorMessage error message to sanitize
     * @param maxLength maximum allowed message length
     * @return sanitized error message with credentials masked and truncated
     */
    public static String sanitizeErrorMessage(String errorMessage, int maxLength) {
        if (errorMessage == null) {
            return null;
        }

        if (maxLength <= 0) {
            throw new IllegalArgumentException("maxLength must be positive");
        }

        // First mask credentials
        String masked = maskCredentials(errorMessage);

        // Then truncate if too long
        if (masked.length() > maxLength) {
            return masked.substring(0, maxLength) + "... [truncated]";
        }

        return masked;
    }
}
