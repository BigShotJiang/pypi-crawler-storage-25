package examples;

import com.bhsf.mca.sdk.MCAClient;
import com.bhsf.mca.sdk.RecordPredictionRequest;
import com.bhsf.mca.sdk.config.MCAConfig;

/**
 * Example demonstrating GCP exporter integration with MCA SDK.
 *
 * <p>This example shows how to configure the MCA SDK to export telemetry
 * directly to GCP Cloud Trace, Cloud Logging, and Prometheus.
 *
 * <p>Prerequisites:
 * <ul>
 *   <li>Google Cloud project with Cloud Trace and Cloud Logging APIs enabled</li>
 *   <li>Service account with appropriate permissions (roles/cloudtrace.agent, roles/logging.logWriter)</li>
 *   <li>GOOGLE_APPLICATION_CREDENTIALS environment variable set, or explicit credentials</li>
 *   <li>Optional dependencies added to pom.xml (google-cloud-trace, google-cloud-logging, prometheus)</li>
 * </ul>
 *
 * <p>To run with Application Default Credentials (ADC):
 * <pre>{@code
 * export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
 * mvn compile exec:java -Dexec.mainClass=examples.GCPExporterExample
 * }</pre>
 */
public class GCPExporterExample {

    public static void main(String[] args) {
        System.out.println("=== MCA SDK GCP Exporter Example ===\n");

        // Example 1: Basic usage with OTLP only (default)
        System.out.println("Example 1: Default OTLP export");
        basicExample();

        // Example 2: Enable GCP Cloud Trace exporter
        System.out.println("\nExample 2: GCP Cloud Trace export");
        gcpTraceExample();

        // Example 3: Enable GCP Cloud Logging exporter
        System.out.println("\nExample 3: GCP Cloud Logging export");
        gcpLoggingExample();

        // Example 4: Enable all GCP exporters
        System.out.println("\nExample 4: All GCP exporters enabled");
        allExportersExample();

        System.out.println("\n=== Example Complete ===");
    }

    /**
     * Example 1: Basic usage with OTLP only (default behavior).
     */
    private static void basicExample() {
        MCAConfig config = new MCAConfig.Builder()
                .serviceName("example-model")
                .modelId("mdl-001")
                .teamName("ml-team")
                .otelEndpoint("http://localhost:4318")
                .build();

        try (MCAClient client = new MCAClient.Builder().config(config).build()) {
            // Record a prediction
            client.recordPrediction(RecordPredictionRequest.builder()
                    .latency(0.15)
                    .predictionId("pred-001")
                    .attribute("model_version", "1.0")
                    .build());

            System.out.println("  Exported to OTLP endpoint: http://localhost:4318");
        }
    }

    /**
     * Example 2: Enable GCP Cloud Trace exporter.
     * Requires: GCP_PROJECT_ID environment variable or explicit project ID.
     */
    private static void gcpTraceExample() {
        String projectId = System.getenv("GCP_PROJECT_ID");
        if (projectId == null) {
            projectId = "your-gcp-project-id";  // Replace with your project ID
        }

        MCAConfig config = new MCAConfig.Builder()
                .serviceName("example-model")
                .modelId("mdl-001")
                .teamName("ml-team")
                .otelEndpoint("http://localhost:4318")
                .gcpProjectId(projectId)
                .gcpTraceEnabled(true)
                // Optional: Explicit credentials (otherwise uses ADC)
                // .gcpCredentialsPath("/path/to/service-account-key.json")
                .build();

        try (MCAClient client = new MCAClient.Builder().config(config).build()) {
            client.recordPrediction(RecordPredictionRequest.builder()
                    .latency(0.20)
                    .predictionId("pred-002")
                    .build());

            System.out.println("  Exported to: OTLP + GCP Cloud Trace");
            System.out.println("  View traces: https://console.cloud.google.com/traces/list?project=" + projectId);
        } catch (Exception e) {
            System.err.println("  Error: " + e.getMessage());
            System.err.println("  Ensure google-cloud-trace dependency is added and GCP credentials are configured.");
        }
    }

    /**
     * Example 3: Enable GCP Cloud Logging exporter.
     */
    private static void gcpLoggingExample() {
        String projectId = System.getenv("GCP_PROJECT_ID");
        if (projectId == null) {
            projectId = "your-gcp-project-id";
        }

        MCAConfig config = new MCAConfig.Builder()
                .serviceName("example-model")
                .modelId("mdl-001")
                .teamName("ml-team")
                .otelEndpoint("http://localhost:4318")
                .gcpProjectId(projectId)
                .gcpLoggingEnabled(true)
                .gcpLogName("mca-sdk-example")  // Optional: custom log name
                .build();

        try (MCAClient client = new MCAClient.Builder().config(config).build()) {
            client.recordPrediction(RecordPredictionRequest.builder()
                    .latency(0.18)
                    .predictionId("pred-003")
                    .build());

            System.out.println("  Exported to: OTLP + GCP Cloud Logging");
            System.out.println("  View logs: https://console.cloud.google.com/logs/query?project=" + projectId);
        } catch (Exception e) {
            System.err.println("  Error: " + e.getMessage());
            System.err.println("  Ensure google-cloud-logging dependency is added and GCP credentials are configured.");
        }
    }

    /**
     * Example 4: Enable all GCP exporters simultaneously.
     */
    private static void allExportersExample() {
        String projectId = System.getenv("GCP_PROJECT_ID");
        if (projectId == null) {
            projectId = "your-gcp-project-id";
        }

        MCAConfig config = new MCAConfig.Builder()
                .serviceName("example-model")
                .modelId("mdl-001")
                .teamName("ml-team")
                .otelEndpoint("http://localhost:4318")
                // GCP exporters
                .gcpProjectId(projectId)
                .gcpTraceEnabled(true)
                .gcpLoggingEnabled(true)
                .gcpLogName("mca-sdk-all")
                .build();

        try (MCAClient client = new MCAClient.Builder().config(config).build()) {
            client.recordPrediction(RecordPredictionRequest.builder()
                    .latency(0.25)
                    .predictionId("pred-004")
                    .attribute("environment", "production")
                    .build());

            System.out.println("  Exported to:");
            System.out.println("    - OTLP: http://localhost:4318");
            System.out.println("    - GCP Cloud Trace: https://console.cloud.google.com/traces?project=" + projectId);
            System.out.println("    - GCP Cloud Logging: https://console.cloud.google.com/logs?project=" + projectId);

            Thread.sleep(2000);
        } catch (Exception e) {
            System.err.println("  Error: " + e.getMessage());
        }
    }
}
