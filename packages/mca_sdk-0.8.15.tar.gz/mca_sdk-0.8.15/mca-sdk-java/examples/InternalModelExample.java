package examples;

import com.bhsf.mca.sdk.MCAClient;
import com.bhsf.mca.sdk.RecordPredictionRequest;

import java.util.Random;

/**
 * Example: Instrumenting an internal ML model with MCA SDK.
 *
 * This demonstrates basic usage of the Java MCA SDK for monitoring
 * a traditional ML model (e.g., readmission prediction).
 */
public class InternalModelExample {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("Starting Internal ML Model Example...");

        // Initialize MCA Client with try-with-resources
        // Use environment variable or default to GCP Workbench collector
        String otelEndpoint = System.getenv("MCA_OTEL_ENDPOINT");
        if (otelEndpoint == null) {
            otelEndpoint = "http://10.164.76.8:4318";  // GCP Workbench collector
        }

        try (MCAClient client = new MCAClient.Builder()
                .serviceName("readmission-model")
                .modelId("mdl-001")
                .teamName("clinical-ai")
                .modelVersion("2.0.0")
                .otelEndpoint(otelEndpoint)
                .build()) {

            System.out.println("Using OTel Collector: " + otelEndpoint);

            System.out.println("MCAClient initialized successfully");

            // Simulate 10 predictions
            Random random = new Random();
            for (int i = 0; i < 10; i++) {
                // Simulate model prediction
                long startTime = System.nanoTime();
                boolean prediction = simulateModelPrediction();
                long endTime = System.nanoTime();

                double latency = (endTime - startTime) / 1_000_000_000.0; // Convert to seconds

                // Record prediction with MCA SDK
                client.recordPrediction(RecordPredictionRequest.builder()
                        .latency(latency)
                        .predictionId("pred-" + i)
                        .attribute("prediction_value", prediction ? "high_risk" : "low_risk")
                        .attribute("model_version", "2.0.0")
                        .attribute("patient_age", 60 + random.nextInt(20))
                        .attribute("feature_count", 50)
                        .attribute("confidence_score", 0.75 + (random.nextDouble() * 0.2))
                        .build());

                System.out.printf("Prediction %d: %s (latency: %.3fs)%n",
                        i, prediction ? "HIGH_RISK" : "LOW_RISK", latency);

                Thread.sleep(500); // Simulate time between predictions
            }

            System.out.println("All predictions recorded. Shutting down...");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Example completed successfully");
    }

    /**
     * Simulate a model prediction (mock implementation).
     *
     * @return true if high risk, false if low risk
     */
    private static boolean simulateModelPrediction() {
        // Simulate computation time
        try {
            Thread.sleep(50 + (int) (Math.random() * 100));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Random prediction
        return Math.random() > 0.5;
    }
}
