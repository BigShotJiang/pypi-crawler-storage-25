"""MCA SDK CLI tools.

This package provides command-line tools for:
- Project scaffolding (mca-init)
- Zero-code instrumentation (mca-instrument, mca-run)
"""

from .init import main  # Preserves existing mca-init entry point

__all__ = ["main"]
