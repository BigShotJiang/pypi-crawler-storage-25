// Simple example of using MCA SDK for Node.js
import { withMCAClient } from '../src';

async function main() {
  // Using context manager for automatic shutdown
  await withMCAClient(
    {
      serviceName: 'my-model',
      modelId: 'mdl-001',
      modelVersion: '1.0',
      teamName: 'data-science',
      modelType: 'internal',
      collectorEndpoint: 'http://localhost:4318',
    },
    async (client) => {
      // Record a prediction
      await client.recordPrediction({
        latency: 0.15,
        inputSize: 100,
        outputSize: 1,
      });

      console.log('Prediction recorded successfully');
    }
  );

  console.log('Client shut down automatically');
}

main().catch(console.error);
