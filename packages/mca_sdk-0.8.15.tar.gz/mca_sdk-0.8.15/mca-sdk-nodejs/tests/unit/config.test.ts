// Unit tests for MCAConfig
import { MCAConfig } from '../../src/config/settings';
import { ConfigurationError } from '../../src/utils/exceptions';

describe('MCAConfig', () => {
  beforeEach(() => {
    delete process.env.MCA_SERVICE_NAME;
    delete process.env.MCA_MODEL_ID;
    delete process.env.MCA_MODEL_VERSION;
    delete process.env.MCA_TEAM_NAME;
    delete process.env.MCA_MODEL_TYPE;
    delete process.env.MCA_OTEL_ENDPOINT;
    delete process.env.MCA_STRICT_VALIDATION;
    delete process.env.MCA_REGISTRY_URL;
    delete process.env.MCA_REGISTRY_TOKEN;
    delete process.env.MCA_REGISTRY_REFRESH_INTERVAL;
    delete process.env.MCA_CAPTURE_INPUT_DATA;
    delete process.env.MCA_CAPTURE_OUTPUT_DATA;
    delete process.env.MCA_CAPTURE_MAX_SIZE_BYTES;
  });

  describe('initialization', () => {
    it('should initialize with minimal config', () => {
      const config = MCAConfig.create({ serviceName: 'test-service', strictValidation: false });
      expect(config.serviceName).toBe('test-service');
      expect(config.collectorEndpoint).toBe('http://localhost:4318');
      expect(config.modelType).toBe('internal');
    });

    it('should initialize with full config', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
        collectorEndpoint: 'http://localhost:4318',
        strictValidation: true,
      });

      expect(config.serviceName).toBe('test-service');
      expect(config.modelId).toBe('mdl-001');
      expect(config.modelVersion).toBe('1.0');
      expect(config.teamName).toBe('clinical-ai');
      expect(config.modelType).toBe('internal');
    });

    it('should load from environment variables', () => {
      process.env.MCA_SERVICE_NAME = 'env-service';
      process.env.MCA_MODEL_ID = 'mdl-env';
      process.env.MCA_MODEL_VERSION = '2.0';
      process.env.MCA_TEAM_NAME = 'env-team';

      const config = MCAConfig.create({});
      expect(config.serviceName).toBe('env-service');
      expect(config.modelId).toBe('mdl-env');
      expect(config.modelVersion).toBe('2.0');
      expect(config.teamName).toBe('env-team');
    });

    it('should prioritize kwargs over environment variables', () => {
      process.env.MCA_SERVICE_NAME = 'env-service';

      const config = MCAConfig.create({ serviceName: 'kwargs-service', strictValidation: false });
      expect(config.serviceName).toBe('kwargs-service');
    });
  });

  describe('validation', () => {
    it('should throw error if serviceName is missing', () => {
      expect(() => MCAConfig.create({})).toThrow(ConfigurationError);
      expect(() => MCAConfig.create({})).toThrow(/serviceName is required/);
    });

    it('should throw error if internal model missing required attributes in strict mode', () => {
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: true })).toThrow(
        ConfigurationError
      );
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: true })).toThrow(
        /modelId is required/
      );
    });

    it('should not throw error if strict validation is disabled', () => {
      expect(() => MCAConfig.create({ serviceName: 'test', strictValidation: false })).not.toThrow();
    });

    it('should enforce HTTPS for registry URL', () => {
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://example.com',
        })
      ).toThrow(ConfigurationError);
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://example.com',
        })
      ).toThrow(/must use HTTPS/);
    });

    it('should allow HTTP for localhost registry URL', () => {
      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://localhost:8080',
        })
      ).not.toThrow();

      expect(() =>
        MCAConfig.create({
          serviceName: 'test',
          strictValidation: false,
          registryUrl: 'http://127.0.0.1:8080',
        })
      ).not.toThrow();
    });
  });

  describe('toResourceAttributes', () => {
    it('should convert config to resource attributes', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
      });

      const attrs = config.toResourceAttributes();
      expect(attrs['service.name']).toBe('test-service');
      expect(attrs['model.id']).toBe('mdl-001');
      expect(attrs['model.version']).toBe('1.0');
      expect(attrs['team.name']).toBe('clinical-ai');
      expect(attrs['model.type']).toBe('internal');
    });

    it('should include only provided attributes', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const attrs = config.toResourceAttributes();
      expect(attrs['service.name']).toBe('test-service');
      expect(attrs['model.type']).toBe('internal');
      expect(attrs['model.id']).toBeUndefined();
      expect(attrs['model.version']).toBeUndefined();
      expect(attrs['team.name']).toBeUndefined();
    });
  });

  describe('Story 1.22: Input/Output Capture Configuration', () => {
    it('should default captureInputData to true', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(config.captureInputData).toBe(true);
    });

    it('should default captureOutputData to true', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(config.captureOutputData).toBe(true);
    });

    it('should respect explicit captureInputData config', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        captureInputData: false,
        strictValidation: false,
      });

      expect(config.captureInputData).toBe(false);
    });

    it('should respect explicit captureOutputData config', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        captureOutputData: false,
        strictValidation: false,
      });

      expect(config.captureOutputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=false from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = 'false';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=0 from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = '0';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=no from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = 'no';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=f from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = 'f';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=n from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = 'n';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(false);
    });

    it('should parse MCA_CAPTURE_INPUT_DATA=true from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_INPUT_DATA = 'true';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureInputData).toBe(true);
    });

    it('should parse MCA_CAPTURE_OUTPUT_DATA=false from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_OUTPUT_DATA = 'false';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureOutputData).toBe(false);
    });

    it('should set default captureMaxSizeBytes to 128KB', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(config.captureMaxSizeBytes).toBe(131072); // 128KB
    });

    it('should respect explicit captureMaxSizeBytes config', () => {
      const config = MCAConfig.create({
        serviceName: 'test-service',
        captureMaxSizeBytes: 65536,
        strictValidation: false,
      });

      expect(config.captureMaxSizeBytes).toBe(65536);
    });

    it('should parse MCA_CAPTURE_MAX_SIZE_BYTES from env', () => {
      process.env.MCA_SERVICE_NAME = 'test';
      process.env.MCA_CAPTURE_MAX_SIZE_BYTES = '32768';

      const config = MCAConfig.create({ strictValidation: false });
      expect(config.captureMaxSizeBytes).toBe(32768);
    });
  });
});
