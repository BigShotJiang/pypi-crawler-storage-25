// Unit tests for MCAClient
import { MCAClient } from '../../src/core/client';
import { ConfigurationError } from '../../src/utils/exceptions';

const mockSpan = {
  setAttribute: jest.fn(),
  setStatus: jest.fn(),
  end: jest.fn(),
  recordException: jest.fn(),
  addEvent: jest.fn(),
};

const mockCounter = { add: jest.fn() };
const mockHistogram = { record: jest.fn() };
const mockGauge = { record: jest.fn() };

jest.mock('../../src/core/providers', () => ({
  setupMeterProvider: jest.fn(() => ({
    getMeter: jest.fn(() => ({
      createCounter: jest.fn(() => mockCounter),
      createHistogram: jest.fn(() => mockHistogram),
      createGauge: jest.fn(() => mockGauge),
    })),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  setupTracerProvider: jest.fn(() => ({
    getTracer: jest.fn(() => ({
      startSpan: jest.fn(() => mockSpan),
    })),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  setupLoggerProvider: jest.fn(() => ({
    getLogger: jest.fn(() => ({})),
    forceFlush: jest.fn(() => Promise.resolve()),
    shutdown: jest.fn(() => Promise.resolve()),
  })),
  shutdownProviders: jest.fn(() => Promise.resolve(true)),
}));

jest.mock('@opentelemetry/api', () => ({
  ...jest.requireActual('@opentelemetry/api'),
  trace: {
    getActiveSpan: jest.fn(() => mockSpan),
    setSpan: jest.fn((_ctx: any, _span: any) => _ctx),
  },
  context: {
    active: jest.fn(() => ({})),
    with: jest.fn((_ctx: any, fn: any) => fn()),
  },
  SpanStatusCode: {
    OK: 1,
    ERROR: 2,
  },
}));

describe('MCAClient', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('initialization', () => {
    it('should initialize with minimal config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
      expect(client.meter).toBeDefined();
      expect(client.tracer).toBeDefined();
      expect(client.logger).toBeDefined();
    });

    it('should initialize with full config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        modelId: 'mdl-001',
        modelVersion: '1.0',
        teamName: 'clinical-ai',
        modelType: 'internal',
        collectorEndpoint: 'http://localhost:4318',
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should throw error if serviceName is missing', async () => {
      await expect(MCAClient.create({} as any)).rejects.toThrow(ConfigurationError);
    });
  });

  describe('recordPrediction', () => {
    it('should record prediction with latency', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction({ latency: 0.15 });

      // If no error thrown, test passes
      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record prediction with custom attributes', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction({
        latency: 0.15,
        customAttr: 'value',
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record prediction without latency', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordPrediction();

      expect(client).toBeInstanceOf(MCAClient);
    });
  });

  describe('recordMetric', () => {
    it('should record custom metric', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordMetric('custom.metric', 42);

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should record metric with attributes', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.recordMetric('custom.metric', 42, { label: 'test' });

      expect(client).toBeInstanceOf(MCAClient);
    });
  });

  describe('shutdown', () => {
    it('should shutdown gracefully', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.shutdown();

      expect(result).toBe(true);
    });

    it('should respect timeout parameter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.shutdown(5000);

      expect(result).toBe(true);
    });
  });

  describe('accessors', () => {
    it('should provide access to meter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.meter).toBeDefined();
    });

    it('should provide access to tracer', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.tracer).toBeDefined();
    });

    it('should provide access to logger', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.logger).toBeDefined();
    });

    it('should provide access to thresholds', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      expect(client.thresholdsConfig).toBeDefined();
      expect(typeof client.thresholdsConfig).toBe('object');
    });
  });

  describe('flush', () => {
    it('should flush all providers successfully', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.flush();
      expect(result).toBe(true);
    });

    it('should respect timeout parameter', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.flush(5000);
      expect(result).toBe(true);
    });

    it('should return false if already shut down', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.shutdown();
      const result = await client.flush();
      expect(result).toBe(false);
    });
  });

  describe('Agentic AI tracking', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    describe('recordGoalStarted', () => {
      it('should create goal and return goal ID', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Research diabetes treatments', 'research');

        expect(goalId).toBeTruthy();
        expect(typeof goalId).toBe('string');
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_type: 'research' });
      });

      it('should sanitize long descriptions', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const longDesc = 'A'.repeat(300);
        const goalId = client.recordGoalStarted(longDesc);

        expect(goalId).toBeTruthy();
      });

      it('should use default type if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Some goal');

        expect(goalId).toBeTruthy();
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_type: 'general' });
      });
    });

    describe('recordGoalCompleted', () => {
      it('should complete goal with success status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');
        client.recordGoalCompleted(goalId, 'success');

        expect(mockSpan.setStatus).toHaveBeenCalledWith({ code: 1 }); // OK
        expect(mockSpan.end).toHaveBeenCalled();
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_status: 'success' });
      });

      it('should complete goal with failure status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');
        client.recordGoalCompleted(goalId, 'failure');

        expect(mockSpan.setStatus).toHaveBeenCalledWith(
          expect.objectContaining({ code: 2 }) // ERROR
        );
        expect(mockCounter.add).toHaveBeenCalledWith(1, { goal_status: 'failure' });
      });

      it('should throw error for invalid goal ID', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        expect(() => client.recordGoalCompleted('invalid-id')).toThrow();
      });

      it('should throw error for invalid status', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const goalId = client.recordGoalStarted('Test goal');

        expect(() => client.recordGoalCompleted(goalId, 'invalid' as any)).toThrow();
      });
    });

    describe('trackTool', () => {
      it('should track successful tool execution', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const result = await client.trackTool(
          'search_db',
          async () => 'result',
          undefined,
          { query: 'test' }
        );

        expect(result).toBe('result');
        expect(mockSpan.setAttribute).toHaveBeenCalledWith('genai.agent.tool.success', true);
        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ status: 'success' })
        );
      });

      it('should track failed tool execution', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Tool failed');

        await expect(
          client.trackTool('search_db', async () => {
            throw error;
          })
        ).rejects.toThrow('Tool failed');

        expect(mockSpan.setAttribute).toHaveBeenCalledWith('genai.agent.tool.success', false);
        expect(mockSpan.recordException).toHaveBeenCalledWith(error);
        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ status: 'error' })
        );
      });

      it('should sanitize long tool names', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const longName = 'A'.repeat(200);
        await client.trackTool(longName, async () => 'result');

        expect(mockSpan.setAttribute).toHaveBeenCalled();
      });
    });

    describe('recordHumanIntervention', () => {
      it('should record human intervention', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordHumanIntervention('Need clarification', 45.2, 'clarification');

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ intervention_type: 'clarification' })
        );
        expect(mockSpan.addEvent).toHaveBeenCalledWith(
          'human_intervention',
          expect.objectContaining({ wait_time_seconds: 45.2 })
        );
      });

      it('should use default type if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordHumanIntervention('Need help', 10);

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          expect.objectContaining({ intervention_type: 'input' })
        );
      });
    });

    describe('recordPolicyViolation', () => {
      it('should record policy violation', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordPolicyViolation('data_access_unauthorized');

        expect(mockCounter.add).toHaveBeenCalledWith(
          1,
          { policy_type: 'data_access_unauthorized' }
        );
        expect(mockSpan.addEvent).toHaveBeenCalledWith(
          'policy_violation',
          expect.objectContaining({ severity: 'high' })
        );
      });
    });
  });

  describe('Advanced tracking methods', () => {
    beforeEach(() => {
      jest.clearAllMocks();
    });

    describe('recordError', () => {
      it('should record error with span', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Test error');
        const message = client.recordError(error, 0.5, 'pred-123');

        expect(message).toBeTruthy();
        expect(mockSpan.recordException).toHaveBeenCalledWith(error);
        expect(mockSpan.setStatus).toHaveBeenCalledWith(
          expect.objectContaining({ code: 2 }) // ERROR
        );
        expect(mockCounter.add).toHaveBeenCalledTimes(2); // predictions + errors counter
      });

      it('should generate prediction ID if not provided', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Test error');
        const message = client.recordError(error);

        expect(message).toBeTruthy();
      });

      it('should sanitize error message', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const error = new Error('Error with api_key=secret123');
        const message = client.recordError(error);

        expect(message).toContain('api_key=***');
        expect(message).not.toContain('secret123');
      });

      it('should handle string throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError('Something went wrong');

        expect(message).toBe('Something went wrong');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });

      it('should handle null/undefined throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError(null);

        expect(message).toBe('Unknown error');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });

      it('should handle primitive throws safely', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        const message = client.recordError(404);

        expect(message).toBe('404');
        expect(mockSpan.recordException).toHaveBeenCalled();
      });
    });

    describe('recordEvaluation', () => {
      it('should record MAE', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ mae: 0.15 });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.15,
          expect.objectContaining({ dataset: 'validation' })
        );
      });

      it('should record RMSE', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ rmse: 0.23 });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.23,
          expect.objectContaining({ dataset: 'validation' })
        );
      });

      it('should use custom dataset', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordEvaluation({ mae: 0.15, dataset: 'test' });

        expect(mockHistogram.record).toHaveBeenCalledWith(
          0.15,
          expect.objectContaining({ dataset: 'test' })
        );
      });
    });

    describe('recordCounter', () => {
      it('should record custom counter', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordCounter('custom.cache_hits', 5, { cache: 'redis' });

        expect(mockCounter.add).toHaveBeenCalledWith(5, { cache: 'redis' });
      });

      it('should use default value of 1', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordCounter('custom.events');

        expect(mockCounter.add).toHaveBeenCalledWith(1, undefined);
      });
    });

    describe('recordGauge', () => {
      it('should record gauge value with .record() method', async () => {
        const client = await MCAClient.create({
          serviceName: 'test-service',
          strictValidation: false,
        });

        client.recordGauge('custom.queue_size', 42, { queue: 'processing' });

        expect(mockGauge.record).toHaveBeenCalledWith(42, { queue: 'processing' });
      });
    });
  });

  describe('Configuration', () => {
    it('should support filterSystemMetrics config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        filterSystemMetrics: false,
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should support captureInputData config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        captureInputData: false,
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should support captureOutputData config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        captureOutputData: false,
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
    });

    it('should support captureMaxSizeBytes config', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        captureMaxSizeBytes: 65536,
        strictValidation: false,
      });

      expect(client).toBeInstanceOf(MCAClient);
    });
  });

  // Story 1.22: New feature tests
  describe('reasoningStep', () => {
    it('should execute callback and return result', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      const result = await client.reasoningStep(
        'planning',
        async (span) => {
          span.setAttribute('test_attr', 'value');
          return 'test-result';
        }
      );

      expect(result).toBe('test-result');
      expect(mockSpan.setAttribute).toHaveBeenCalled();
      expect(mockCounter.add).toHaveBeenCalled();
    });

    it('should record counter with success status', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.reasoningStep('planning', async () => {
        return 'success';
      });

      expect(mockCounter.add).toHaveBeenCalledWith(
        1,
        expect.objectContaining({ step_type: 'planning', status: 'success' })
      );
    });

    it('should record counter with error status on failure', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await expect(
        client.reasoningStep('planning', async () => {
          throw new Error('Test error');
        })
      ).rejects.toThrow('Test error');

      expect(mockCounter.add).toHaveBeenCalledWith(
        1,
        expect.objectContaining({ step_type: 'planning', status: 'error' })
      );
    });

    it('should support stepDescription and llmModel options', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-service',
        strictValidation: false,
      });

      await client.reasoningStep(
        'evaluation',
        async () => 'done',
        { stepDescription: 'Test step', llmModel: 'gpt-4' }
      );

      expect(mockCounter.add).toHaveBeenCalled();
    });
  });

  describe('getInstance', () => {
    it('should return the singleton instance', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-singleton',
        strictValidation: false,
      });

      const instance = MCAClient.getInstance();
      expect(instance).toBe(client);

      await client.shutdown();
    });

    it('should return null after shutdown', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-singleton-2',
        strictValidation: false,
      });

      expect(MCAClient.getInstance()).toBe(client);
      await client.shutdown();
      expect(MCAClient.getInstance()).toBeNull();
    });

    it('should update to latest instance on multiple creates', async () => {
      const client1 = await MCAClient.create({
        serviceName: 'test-singleton-3',
        strictValidation: false,
      });

      const client2 = await MCAClient.create({
        serviceName: 'test-singleton-4',
        strictValidation: false,
      });

      expect(MCAClient.getInstance()).toBe(client2);

      await client1.shutdown();
      await client2.shutdown();
    });
  });

  describe('Input/Output Capture', () => {
    it('should capture input data when enabled', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-capture',
        captureInputData: true,
        captureOutputData: false,
        strictValidation: false,
      });

      await client.recordPrediction({
        inputData: { features: [1, 2, 3] },
        latency: 0.1,
      });

      expect(mockSpan.setAttribute).toHaveBeenCalled();
      expect(mockCounter.add).toHaveBeenCalled();

      await client.shutdown();
    });

    it('should capture output data when enabled', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-capture-output',
        captureInputData: false,
        captureOutputData: true,
        strictValidation: false,
      });

      await client.recordPrediction({
        outputData: { prediction: 0.95 },
        latency: 0.1,
      });

      expect(mockSpan.setAttribute).toHaveBeenCalled();

      await client.shutdown();
    });

    it('should not capture when disabled', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-no-capture',
        captureInputData: false,
        captureOutputData: false,
        strictValidation: false,
      });

      // Reset mocks to count only this call
      mockSpan.setAttribute.mockClear();

      await client.recordPrediction({
        inputData: { features: [1, 2, 3] },
        outputData: { prediction: 0.95 },
        latency: 0.1,
      });

      // Should not have set attributes for input/output data
      const calls = mockSpan.setAttribute.mock.calls;
      const hasInputData = calls.some(call => call[0] === 'model.input.data');
      const hasOutputData = calls.some(call => call[0] === 'model.output.data');

      expect(hasInputData).toBe(false);
      expect(hasOutputData).toBe(false);

      await client.shutdown();
    });

    it('should sanitize credentials in input data', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-sanitize',
        captureInputData: true,
        strictValidation: false,
      });

      await client.recordPrediction({
        inputData: {
          apiKey: 'AKIAIOSFODNN7EXAMPLE',
          features: [1, 2, 3]
        },
        latency: 0.1,
      });

      expect(mockSpan.setAttribute).toHaveBeenCalled();

      await client.shutdown();
    });
  });

  describe('Recovery Tracking', () => {
    it('should track tool retry attempts', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-recovery',
        strictValidation: false,
      });

      const goalId = client.recordGoalStarted('Test goal', 'test');

      // First attempt - should fail and mark as needing retry
      try {
        await client.trackTool(
          'test_tool',
          async () => {
            throw new Error('First attempt failed');
          },
          goalId
        );
      } catch (e) {
        // Expected to fail
      }

      // Second attempt - should succeed and mark recovery
      mockSpan.setAttribute.mockClear();
      const result = await client.trackTool(
        'test_tool',
        async () => 'success',
        goalId
      );

      expect(result).toBe('success');

      // Check that recovery attributes were set
      const setAttrCalls = mockSpan.setAttribute.mock.calls;
      const hasRecoveryAttempted = setAttrCalls.some(
        call => call[0] === 'genai.agent.recovery.attempted' && call[1] === true
      );
      const hasRecoverySuccess = setAttrCalls.some(
        call => call[0] === 'genai.agent.recovery_success' && call[1] === true
      );

      expect(hasRecoveryAttempted).toBe(true);
      expect(hasRecoverySuccess).toBe(true);

      client.recordGoalCompleted(goalId, 'success');
      await client.shutdown();
    });

    it('should mark recovery failure on continued failures', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-recovery-fail',
        strictValidation: false,
      });

      const goalId = client.recordGoalStarted('Test goal', 'test');

      // First attempt fails
      try {
        await client.trackTool(
          'fail_tool',
          async () => {
            throw new Error('Attempt 1 failed');
          },
          goalId
        );
      } catch (e) { /* expected error, intentionally ignored */ }

      // Second attempt also fails
      mockSpan.setAttribute.mockClear();
      try {
        await client.trackTool(
          'fail_tool',
          async () => {
            throw new Error('Attempt 2 failed');
          },
          goalId
        );
      } catch (e) {
        // Expected
      }

      // Check that recovery failure was marked
      const setAttrCalls = mockSpan.setAttribute.mock.calls;
      const hasRecoverySuccess = setAttrCalls.some(
        call => call[0] === 'genai.agent.recovery_success' && call[1] === false
      );

      expect(hasRecoverySuccess).toBe(true);

      client.recordGoalCompleted(goalId, 'failure');
      await client.shutdown();
    });

    it('should not track recovery without goal context', async () => {
      const client = await MCAClient.create({
        serviceName: 'test-no-goal',
        strictValidation: false,
      });

      // First attempt fails without goal
      try {
        await client.trackTool('tool', async () => {
          throw new Error('Failed');
        });
      } catch (e) { /* expected error, intentionally ignored */ }

      // Second attempt - should not have recovery attributes
      mockSpan.setAttribute.mockClear();
      await client.trackTool('tool', async () => 'success');

      const setAttrCalls = mockSpan.setAttribute.mock.calls;
      const hasRecoveryAttempted = setAttrCalls.some(
        call => call[0] === 'genai.agent.recovery.attempted'
      );

      expect(hasRecoveryAttempted).toBe(false);

      await client.shutdown();
    });
  });
});
