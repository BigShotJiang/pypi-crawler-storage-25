// Unit tests for RegistryClient
import axios from 'axios';
import { RegistryClient } from '../../src/registry/client';
import { RegistryError } from '../../src/utils/exceptions';
import { ModelConfig } from '../../src/registry/models';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('RegistryClient', () => {
  let mockAxiosInstance: any;

  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();

    mockAxiosInstance = {
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    };
    mockedAxios.create.mockReturnValue(mockAxiosInstance);
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  describe('initialization', () => {
    it('should initialize with HTTPS URL', () => {
      const client = new RegistryClient('https://registry.example.com');
      expect(client).toBeInstanceOf(RegistryClient);
      client.stop();
    });

    it('should allow HTTP for localhost', () => {
      const client = new RegistryClient('http://localhost:8080');
      expect(client).toBeInstanceOf(RegistryClient);
      client.stop();
    });

    it('should throw error for HTTP non-localhost URL', () => {
      expect(() => new RegistryClient('http://registry.example.com')).toThrow(RegistryError);
      expect(() => new RegistryClient('http://registry.example.com')).toThrow(/must use HTTPS/);
    });

    it('should throw error for invalid refresh interval', () => {
      expect(
        () => new RegistryClient('https://registry.example.com', undefined, 5000, 600, 10)
      ).toThrow(/must be >= 30 seconds/);
    });
  });

  describe('fetchModelConfig', () => {
    it('should fetch model config from API', async () => {
      const mockConfig: ModelConfig = {
        modelId: 'mdl-001',
        modelVersion: '1.0',
        modelType: 'internal',
        teamName: 'clinical-ai',
      };

      mockAxiosInstance.get.mockResolvedValue({ data: mockConfig });

      const client = new RegistryClient('https://registry.example.com', 'token-123');
      const config = await client.fetchModelConfig('mdl-001');

      expect(config).toEqual(mockConfig);
      expect(mockAxiosInstance.get).toHaveBeenCalledWith('/api/v1/models/mdl-001', {
        params: undefined,
      });
      client.stop();
    });

    it('should cache fetched config', async () => {
      const mockConfig: ModelConfig = {
        modelId: 'mdl-001',
        modelVersion: '1.0',
        modelType: 'internal',
        teamName: 'clinical-ai',
      };

      mockAxiosInstance.get.mockResolvedValue({ data: mockConfig });

      const client = new RegistryClient('https://registry.example.com');
      await client.fetchModelConfig('mdl-001');
      await client.fetchModelConfig('mdl-001');

      expect(mockAxiosInstance.get).toHaveBeenCalledTimes(1);
      client.stop();
    });

    it('should handle 404 errors', async () => {
      mockAxiosInstance.get.mockRejectedValue({
        response: { status: 404 },
      });

      const client = new RegistryClient('https://registry.example.com');

      await expect(client.fetchModelConfig('invalid')).rejects.toThrow('Model not found');
      client.stop();
    });

    it('should handle authentication errors', async () => {
      mockAxiosInstance.get.mockRejectedValue({
        response: { status: 401 },
      });

      const client = new RegistryClient('https://registry.example.com');

      await expect(client.fetchModelConfig('mdl-001')).rejects.toThrow('authentication failed');
      client.stop();
    });
  });

  describe('cache management', () => {
    it('should expire cache entries after TTL', async () => {
      const mockConfig: ModelConfig = {
        modelId: 'mdl-001',
        modelVersion: '1.0',
        modelType: 'internal',
        teamName: 'clinical-ai',
      };

      mockAxiosInstance.get.mockResolvedValue({ data: mockConfig });

      const client = new RegistryClient('https://registry.example.com', undefined, 5000, 1); // 1 second TTL
      await client.fetchModelConfig('mdl-001');

      // Fast-forward time beyond TTL
      jest.advanceTimersByTime(2000);

      await client.fetchModelConfig('mdl-001');

      expect(mockAxiosInstance.get).toHaveBeenCalledTimes(2);
      client.stop();
    });

    it('should clear cache on demand', async () => {
      const mockConfig: ModelConfig = {
        modelId: 'mdl-001',
        modelVersion: '1.0',
        modelType: 'internal',
        teamName: 'clinical-ai',
      };

      mockAxiosInstance.get.mockResolvedValue({ data: mockConfig });

      const client = new RegistryClient('https://registry.example.com');
      await client.fetchModelConfig('mdl-001');

      client.clearCache();

      await client.fetchModelConfig('mdl-001');

      expect(mockAxiosInstance.get).toHaveBeenCalledTimes(2);
      client.stop();
    });
  });

  describe('background refresh', () => {
    it('should initialize with background refresh enabled', () => {
      const client = new RegistryClient('https://registry.example.com', undefined, 5000, 600, 60);
      expect(client).toBeInstanceOf(RegistryClient);
      client.stop();
    });

    it('should not start refresh when interval is 0', () => {
      const client = new RegistryClient('https://registry.example.com', undefined, 5000, 600, 0);
      expect(client).toBeInstanceOf(RegistryClient);
      client.stop();
    });
  });

  describe('stop', () => {
    it('should stop background refresh and clear cache', () => {
      const client = new RegistryClient('https://registry.example.com');
      client.stop();

      // Verify no errors and client is stopped
      expect(client).toBeInstanceOf(RegistryClient);
    });
  });
});
