// Unit tests for serialization utilities
import {
  serializeForTelemetry,
  extractModelPayload,
  sanitizeCredentials
} from '../../src/utils/serialization';

describe('serializeForTelemetry', () => {
  // Basic types
  test('returns null unchanged', () => {
    expect(serializeForTelemetry(null)).toBeNull();
  });

  test('returns boolean unchanged', () => {
    expect(serializeForTelemetry(true)).toBe(true);
    expect(serializeForTelemetry(false)).toBe(false);
  });

  test('returns number unchanged', () => {
    expect(serializeForTelemetry(42)).toBe(42);
    expect(serializeForTelemetry(3.14)).toBe(3.14);
  });

  test('returns string unchanged when within max length', () => {
    const str = 'hello world';
    expect(serializeForTelemetry(str)).toBe(str);
  });

  // String truncation
  test('truncates long strings', () => {
    const longStr = 'a'.repeat(200);
    const result = serializeForTelemetry(longStr, 100);
    expect(result).toContain('...[truncated]');
    expect(result.length).toBeLessThanOrEqual(100);
  });

  test('handles truncation when marker is longer than max length', () => {
    const result = serializeForTelemetry('hello', 5, '...[truncated]');
    // When marker is too long, returns original string
    expect(result).toBe('hello');
  });

  // Objects and arrays
  test('serializes objects to JSON strings', () => {
    const obj = { key: 'value', num: 42 };
    const result = serializeForTelemetry(obj);
    expect(typeof result).toBe('string');
    expect(JSON.parse(result)).toEqual(obj);
  });

  test('serializes arrays to JSON strings', () => {
    const arr = [1, 2, 3, 'test'];
    const result = serializeForTelemetry(arr);
    expect(typeof result).toBe('string');
    expect(JSON.parse(result)).toEqual(arr);
  });

  // Special types
  test('handles Date objects', () => {
    const date = new Date('2023-01-01');
    const result = serializeForTelemetry(date);
    expect(result).toContain('2023-01-01');
  });

  test('handles Error objects', () => {
    const error = new Error('test error');
    const result = serializeForTelemetry(error);
    expect(result).toContain('test error');
    expect(result).toContain('name');
    expect(result).toContain('message');
  });

  test('handles BigInt', () => {
    const bigInt = BigInt(9007199254740991);
    const result = serializeForTelemetry(bigInt);
    expect(result).toContain('9007199254740991');
  });

  test('handles Sets', () => {
    const set = new Set([1, 2, 3]);
    const result = serializeForTelemetry(set);
    const parsed = JSON.parse(result);
    expect(parsed).toEqual([1, 2, 3]);
  });

  test('handles Maps', () => {
    const map = new Map([['key1', 'value1'], ['key2', 'value2']]);
    const result = serializeForTelemetry(map);
    const parsed = JSON.parse(result);
    expect(parsed).toEqual({ key1: 'value1', key2: 'value2' });
  });

  test('handles Buffers', () => {
    const buffer = Buffer.from('hello');
    const result = serializeForTelemetry(buffer);
    // Buffer gets serialized to JSON with type and data
    expect(result).toContain('Buffer');
    expect(result).toContain('type');
  });

  // Non-serializable fallback
  test('falls back to toString for non-serializable objects', () => {
    const circular: any = { prop: 'value' };
    circular.self = circular; // Circular reference
    const result = serializeForTelemetry(circular);
    expect(typeof result).toBe('string');
  });
});

describe('extractModelPayload', () => {
  test('extracts shape from simple array', () => {
    const data = [1, 2, 3];
    const result = extractModelPayload(data);
    expect(result.shape).toBe('(3,)');
    expect(result.truncated).toBe(false);
  });

  test('extracts shape from 2D array', () => {
    const data = [[1, 2], [3, 4], [5, 6]];
    const result = extractModelPayload(data);
    expect(result.shape).toBe('(3, 2)');
    expect(result.truncated).toBe(false);
  });

  test('extracts shape from empty array', () => {
    const data: any[] = [];
    const result = extractModelPayload(data);
    expect(result.shape).toBe('(0,)');
  });

  test('extracts shape from object with shape property', () => {
    const data = { shape: [10, 5], data: [] };
    const result = extractModelPayload(data);
    expect(result.shape).toBe('(10, 5)');
  });

  test('truncates large payloads', () => {
    const largeData = 'x'.repeat(20000);
    const result = extractModelPayload(largeData, 1000);
    expect(result.truncated).toBe(true);
    expect(result.data).toContain('...[truncated');
  });

  test('includes total byte size in truncation message', () => {
    const largeData = 'x'.repeat(20000);
    const result = extractModelPayload(largeData, 1000);
    expect(result.data).toContain('bytes total');
  });

  test('serializes simple objects', () => {
    const data = { key: 'value', num: 42 };
    const result = extractModelPayload(data);
    expect(result.data).toContain('key');
    expect(result.data).toContain('value');
    expect(result.truncated).toBe(false);
  });

  test('handles serialization errors gracefully', () => {
    // This should not throw
    const result = extractModelPayload(undefined);
    expect(result.data).toBe('undefined');
    expect(result.truncated).toBe(false);
  });

  test('respects exact byte limits', () => {
    const data = 'x'.repeat(100);
    const maxSize = 50;
    const result = extractModelPayload(data, maxSize);

    // Result should not exceed maxSize
    const resultBytes = Buffer.byteLength(result.data || '', 'utf8');
    expect(resultBytes).toBeLessThanOrEqual(maxSize);
  });
});

describe('sanitizeCredentials', () => {
  test('masks AWS access keys', () => {
    const data = 'My key is AKIAIOSFODNN7EXAMPLE';
    const result = sanitizeCredentials(data);
    expect(result).toContain('[AWS-KEY-REDACTED]');
    expect(result).not.toContain('AKIAIOSFODNN7EXAMPLE');
  });

  test('masks GCP API keys', () => {
    const data = 'GCP key: AIzaSyDaGmWKa4JsXZ-HjGw7ISLn_3namBGewQe';
    const result = sanitizeCredentials(data);
    expect(result).toContain('[GCP-KEY-REDACTED]');
    expect(result).not.toContain('AIzaSyDaGmWKa4JsXZ');
  });

  test('masks GitHub PATs', () => {
    const data = 'Token: ghp_1234567890abcdefghijklmnopqrstuvwxyz';
    const result = sanitizeCredentials(data);
    expect(result).toContain('[GITHUB-TOKEN-REDACTED]');
  });

  test('masks JWT tokens', () => {
    const data = 'JWT: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U';
    const result = sanitizeCredentials(data);
    expect(result).toContain('[JWT-REDACTED]');
  });

  test('masks Bearer tokens', () => {
    const data = 'Authorization: Bearer abc123def456ghi789jkl';
    const result = sanitizeCredentials(data);
    expect(result).toContain('Bearer [TOKEN-REDACTED]');
  });

  test('masks Basic auth', () => {
    const data = 'Authorization: Basic YWxhZGRpbjpvcGVuc2VzYW1l';
    const result = sanitizeCredentials(data);
    expect(result).toContain('Basic [REDACTED]');
  });

  test('sanitizes nested objects', () => {
    const data = {
      user: 'john',
      credentials: {
        api_key: 'AKIAIOSFODNN7EXAMPLE',
        token: 'secret123'
      }
    };
    const result = sanitizeCredentials(data);
    expect(result.credentials.api_key).toBe('[REDACTED]');
    expect(result.credentials.token).toBe('[REDACTED]');
    expect(result.user).toBe('john');
  });

  test('sanitizes arrays', () => {
    const data = ['normal', 'AKIAIOSFODNN7EXAMPLE', 'values'];
    const result = sanitizeCredentials(data);
    expect(result[0]).toBe('normal');
    expect(result[1]).toContain('[AWS-KEY-REDACTED]');
    expect(result[2]).toBe('values');
  });

  test('recognizes credential keys in objects', () => {
    const data = {
      password: 'supersecret123',
      secret_key: 'anothersecret',
      username: 'john'
    };
    const result = sanitizeCredentials(data);
    expect(result.password).toBe('[REDACTED]');
    expect(result.secret_key).toBe('[REDACTED]');
    expect(result.username).toBe('john');
  });

  test('handles short credential values', () => {
    const data = { password: 'short' };
    const result = sanitizeCredentials(data);
    // Short values (< 8 chars) are not masked
    expect(result.password).toBe('short');
  });

  test('preserves null and undefined', () => {
    expect(sanitizeCredentials(null)).toBeNull();
    expect(sanitizeCredentials(undefined)).toBeUndefined();
  });

  test('handles mixed nested structures', () => {
    const data = {
      config: {
        auth: {
          aws_access_key_id: 'AKIAIOSFODNN7EXAMPLE',
          aws_secret_access_key: 'verysecretkey'
        },
        users: [
          { name: 'alice', token: 'token12345678' },
          { name: 'bob', api_key: 'keyvalue123' }
        ]
      },
      normal_data: 'public info'
    };
    const result = sanitizeCredentials(data);
    expect(result.config.auth.aws_access_key_id).toBe('[REDACTED]');
    expect(result.config.auth.aws_secret_access_key).toBe('[REDACTED]');
    expect(result.config.users[0].token).toBe('[REDACTED]');
    expect(result.config.users[1].api_key).toBe('[REDACTED]');
    expect(result.config.users[0].name).toBe('alice');
    expect(result.normal_data).toBe('public info');
  });
});
