// Registry client for fetching model and deployment configurations
import axios, { AxiosInstance } from 'axios';
import axiosRetry from 'axios-retry';
import { ModelConfig, DeploymentConfig } from './models';
import { RegistryError } from '../utils/exceptions';
import { logger } from '../utils/logger';

const DEFAULT_CACHE_TTL_SECS = 600; // 10 minutes
const DEFAULT_TIMEOUT_MS = 5000;
const MIN_REFRESH_INTERVAL_SECS = 30;

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

export class RegistryClient {
  private url: string;
  private token?: string;
  private timeout: number;
  private cacheTtlSecs: number;
  private refreshIntervalSecs: number;
  private cache: Map<string, CacheEntry<any>>;
  private httpClient: AxiosInstance;
  private refreshTimer?: NodeJS.Timeout;
  private refreshCallbacks: Map<string, () => Promise<void>>;

  constructor(
    url: string,
    token?: string,
    timeout: number = DEFAULT_TIMEOUT_MS,
    cacheTtlSecs: number = DEFAULT_CACHE_TTL_SECS,
    refreshIntervalSecs: number = DEFAULT_CACHE_TTL_SECS
  ) {
    this.validateUrl(url);

    if (refreshIntervalSecs > 0 && refreshIntervalSecs < MIN_REFRESH_INTERVAL_SECS) {
      throw new Error(
        `refreshIntervalSecs must be >= ${MIN_REFRESH_INTERVAL_SECS} seconds. ` +
        `Got: ${refreshIntervalSecs}`
      );
    }

    this.url = url.replace(/\/$/, '');
    this.token = token;
    this.timeout = timeout;
    this.cacheTtlSecs = cacheTtlSecs;
    this.refreshIntervalSecs = refreshIntervalSecs;
    this.cache = new Map();
    this.refreshCallbacks = new Map();

    this.httpClient = axios.create({
      baseURL: this.url,
      timeout: this.timeout,
      headers: this.token ? { Authorization: `Bearer ${this.token}` } : {},
    });

    // Configure retry with exponential backoff
    axiosRetry(this.httpClient, {
      retries: 3,
      retryDelay: axiosRetry.exponentialDelay,
      retryCondition: (error) => {
        return axiosRetry.isNetworkOrIdempotentRequestError(error) ||
               error.response?.status === 429 ||
               error.response?.status === 503;
      },
    });

    if (this.refreshIntervalSecs > 0) {
      this.startBackgroundRefresh();
    }
  }

  private validateUrl(url: string): void {
    const isLocalhost =
      url.startsWith('http://localhost') || url.startsWith('http://127.0.0.1');

    if (!isLocalhost && !url.startsWith('https://')) {
      throw new RegistryError(
        `Registry URL must use HTTPS for non-localhost endpoints. Got: ${url}`
      );
    }
  }

  private getCacheKey(endpoint: string, params?: Record<string, any>): string {
    const paramStr = params ? JSON.stringify(params) : '';
    return `${endpoint}:${paramStr}`;
  }

  private getFromCache<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      this.refreshCallbacks.delete(key);
      return null;
    }

    return entry.value as T;
  }

  private setCache<T>(key: string, value: T): void {
    const expiresAt = Date.now() + this.cacheTtlSecs * 1000;
    this.cache.set(key, { value, expiresAt });
  }

  async fetchModelConfig(modelId: string, version?: string, bypassCache: boolean = false): Promise<ModelConfig> {
    const params = version ? { version } : undefined;
    const cacheKey = this.getCacheKey(`models/${modelId}`, params);

    if (!bypassCache) {
      const cached = this.getFromCache<ModelConfig>(cacheKey);
      if (cached) {
        logger.debug(`Cache hit for model config: ${modelId}`);
        return cached;
      }
    }

    try {
      const response = await this.httpClient.get<ModelConfig>(`/api/v1/models/${modelId}`, {
        params,
      });

      this.setCache(cacheKey, response.data);

      this.refreshCallbacks.set(cacheKey, async () => {
        await this.fetchModelConfig(modelId, version, true);
      });

      return response.data;
    } catch (error: any) {
      if (error.response?.status === 404) {
        throw new RegistryError(`Model not found: ${modelId}`);
      }
      if (error.response?.status === 401) {
        throw new RegistryError('Registry authentication failed');
      }
      throw new RegistryError(`Failed to fetch model config: ${error.message}`);
    }
  }

  async fetchDeploymentConfig(deploymentId: string, bypassCache: boolean = false): Promise<DeploymentConfig> {
    const cacheKey = this.getCacheKey(`deployments/${deploymentId}`);

    if (!bypassCache) {
      const cached = this.getFromCache<DeploymentConfig>(cacheKey);
      if (cached) {
        logger.debug(`Cache hit for deployment config: ${deploymentId}`);
        return cached;
      }
    }

    try {
      const response = await this.httpClient.get<DeploymentConfig>(
        `/api/v1/deployments/${deploymentId}`
      );

      this.setCache(cacheKey, response.data);

      this.refreshCallbacks.set(cacheKey, async () => {
        await this.fetchDeploymentConfig(deploymentId, true);
      });

      return response.data;
    } catch (error: any) {
      if (error.response?.status === 404) {
        throw new RegistryError(`Deployment not found: ${deploymentId}`);
      }
      if (error.response?.status === 401) {
        throw new RegistryError('Registry authentication failed');
      }
      throw new RegistryError(`Failed to fetch deployment config: ${error.message}`);
    }
  }

  private startBackgroundRefresh(): void {
    this.refreshTimer = setInterval(async () => {
      logger.debug('Running background registry refresh');

      const results = await Promise.allSettled(
        Array.from(this.refreshCallbacks.values()).map(callback => callback())
      );

      results.forEach((result, index) => {
        if (result.status === 'rejected') {
          const key = Array.from(this.refreshCallbacks.keys())[index];
          logger.warn(`Background refresh failed for ${key}: ${result.reason?.message || result.reason}`);
        }
      });
    }, this.refreshIntervalSecs * 1000);

    // Prevent Node.js from waiting for timer to exit
    this.refreshTimer.unref();
  }

  stop(): void {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
      this.refreshTimer = undefined;
    }
    this.cache.clear();
    this.refreshCallbacks.clear();
  }

  clearCache(): void {
    this.cache.clear();
  }
}
