// Pydantic-equivalent models for registry responses
import { ModelType } from '../types';

export interface ModelConfig {
  modelId: string;
  modelVersion: string;
  modelType: ModelType;
  teamName: string;
  thresholds?: Record<string, number>;
  [key: string]: any;
}

export interface DeploymentConfig {
  deploymentId: string;
  modelId: string;
  environment: string;
  endpoint?: string;
  [key: string]: any;
}
