// OpenTelemetry provider setup for metrics, logs, and traces
import { Resource } from '@opentelemetry/resources';
import {  MeterProvider, PeriodicExportingMetricReader, View, Aggregation } from '@opentelemetry/sdk-metrics';
import { OTLPMetricExporter } from '@opentelemetry/exporter-metrics-otlp-http';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { OTLPLogExporter } from '@opentelemetry/exporter-logs-otlp-http';
import { BatchSpanProcessor, NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { LoggerProvider, BatchLogRecordProcessor } from '@opentelemetry/sdk-logs';
import { trace, metrics } from '@opentelemetry/api';
import * as logsAPI from '@opentelemetry/api-logs';

export interface ProviderConfig {
  serviceName: string;
  collectorEndpoint: string;
  modelId?: string;
  modelVersion?: string;
  teamName?: string;
  modelType?: string;
  filterSystemMetrics?: boolean;
}

// Metric patterns to drop when filterSystemMetrics is enabled
const DEFAULT_DROPPED_PATTERNS = [
  'process.*',
  'nodejs.*',
  'system.*',
  'http.client.*',
  'rpc.*',
  'test.*',
  'asyncio.*',
  'otel.sdk.*'
];

export function createResourceAttributes(config: ProviderConfig): Resource {
  const attributes: Record<string, string> = {
    'service.name': config.serviceName,
  };

  if (config.modelId) attributes['model.id'] = config.modelId;
  if (config.modelVersion) attributes['model.version'] = config.modelVersion;
  if (config.teamName) attributes['team.name'] = config.teamName;
  if (config.modelType) attributes['model.type'] = config.modelType;

  return new Resource(attributes);
}

export function setupMeterProvider(config: ProviderConfig): MeterProvider {
  const resource = createResourceAttributes(config);

  const metricExporter = new OTLPMetricExporter({
    url: `${config.collectorEndpoint}/v1/metrics`,
  });

  const metricReader = new PeriodicExportingMetricReader({
    exporter: metricExporter,
    exportIntervalMillis: 5000, // 5 seconds
  });

  // Create views to drop system metrics if filtering is enabled
  const views = config.filterSystemMetrics !== false
    ? DEFAULT_DROPPED_PATTERNS.map(pattern =>
        new View({
          instrumentName: pattern,
          aggregation: Aggregation.Drop()
        })
      )
    : undefined;

  const meterProvider = new MeterProvider({
    resource,
    readers: [metricReader],
    views
  });

  metrics.setGlobalMeterProvider(meterProvider);

  return meterProvider;
}

export function setupTracerProvider(config: ProviderConfig): NodeTracerProvider {
  const resource = createResourceAttributes(config);

  const traceExporter = new OTLPTraceExporter({
    url: `${config.collectorEndpoint}/v1/traces`,
  });

  const tracerProvider = new NodeTracerProvider({
    resource,
  });

  tracerProvider.addSpanProcessor(new BatchSpanProcessor(traceExporter, {
    maxQueueSize: 2048,
    maxExportBatchSize: 512,
    scheduledDelayMillis: 5000,
  }));

  trace.setGlobalTracerProvider(tracerProvider);

  return tracerProvider;
}

export function setupLoggerProvider(config: ProviderConfig): LoggerProvider {
  const resource = createResourceAttributes(config);

  const logExporter = new OTLPLogExporter({
    url: `${config.collectorEndpoint}/v1/logs`,
  });

  const loggerProvider = new LoggerProvider({
    resource,
  });

  loggerProvider.addLogRecordProcessor(new BatchLogRecordProcessor(logExporter, {
    maxQueueSize: 2048,
    maxExportBatchSize: 512,
    scheduledDelayMillis: 5000,
  }));

  // Type-safe global logger provider setup
  if (logsAPI.logs && typeof logsAPI.logs.setGlobalLoggerProvider === 'function') {
    logsAPI.logs.setGlobalLoggerProvider(loggerProvider);
  }

  return loggerProvider;
}

export async function shutdownProviders(
  meterProvider: MeterProvider,
  tracerProvider: NodeTracerProvider,
  loggerProvider: LoggerProvider,
  timeoutMs: number = 30000
): Promise<boolean> {
  const errors: Error[] = [];

  try {
    const shutdownPromises = [
      meterProvider.shutdown().catch((e: Error) => {
        errors.push(new Error(`MeterProvider shutdown failed: ${e.message}`));
      }),
      tracerProvider.shutdown().catch((e: Error) => {
        errors.push(new Error(`TracerProvider shutdown failed: ${e.message}`));
      }),
      loggerProvider.shutdown().catch((e: Error) => {
        errors.push(new Error(`LoggerProvider shutdown failed: ${e.message}`));
      }),
    ];

    await Promise.race([
      Promise.all(shutdownPromises),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Shutdown timeout exceeded')), timeoutMs)
      ),
    ]);

    if (errors.length > 0) {
      const logger = await import('../utils/logger');
      errors.forEach(error => logger.logger.error(error.message));
      return false;
    }

    return true;
  } catch (error: any) {
    const logger = await import('../utils/logger');
    logger.logger.error(`Critical shutdown error: ${error.message}`);
    throw error;
  }
}
