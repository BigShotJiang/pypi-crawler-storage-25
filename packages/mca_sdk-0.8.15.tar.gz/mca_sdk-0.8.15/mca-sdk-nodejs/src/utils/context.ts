// Context manager equivalent for Node.js (try/finally wrapper)
import { MCAClient } from '../core/client';
import { MCAClientConfig } from '../types';

export async function withMCAClient<T>(
  config: MCAClientConfig,
  fn: (client: MCAClient) => Promise<T>
): Promise<T> {
  const client = await MCAClient.create(config);

  try {
    return await fn(client);
  } finally {
    await client.shutdown();
  }
}
