/**
 * Serialization utilities for telemetry data capture.
 *
 * This module provides safe JSON serialization for telemetry data with fallback
 * handling for non-serializable types and truncation for large payloads.
 *
 * Based on Python SDK mca_sdk/utils/serialization.py
 */

// Credential patterns for masking sensitive data in telemetry
const CREDENTIAL_PATTERNS: Array<[string, RegExp, string]> = [
  // AWS Access Keys: AKIA followed by 16 alphanumeric chars
  ['aws_access_key', /\bAKIA[0-9A-Z]{16}\b/g, '[AWS-KEY-REDACTED]'],
  // GCP API Keys: AIzaSy followed by 33 chars
  ['gcp_api_key', /\bAIzaSy[A-Za-z0-9_-]{33}\b/g, '[GCP-KEY-REDACTED]'],
  // GitHub Personal Access Tokens: ghp_ prefix
  ['github_pat', /\bghp_[A-Za-z0-9]{36}\b/g, '[GITHUB-TOKEN-REDACTED]'],
  // JWT Tokens: three base64 segments separated by dots
  ['jwt', /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, '[JWT-REDACTED]'],
  // Bearer Tokens
  ['bearer_token', /Bearer\s+[A-Za-z0-9._+/=-]{20,}/g, 'Bearer [TOKEN-REDACTED]'],
  // Basic Auth
  ['basic_auth', /Basic\s+[A-Za-z0-9+/=_-]{20,}/g, 'Basic [REDACTED]'],
];

/**
 * Serialize data to a telemetry-safe value.
 *
 * Returns basic Python types (null, boolean, number, string) unchanged
 * since they are already OTel-compatible. Converts complex types to JSON strings
 * with graceful fallback to toString() for non-serializable objects. Truncates large
 * string payloads to prevent excessive telemetry data.
 *
 * @param data - Data to serialize (any type)
 * @param maxLength - Maximum length of serialized string (default: 1MB/1048576 bytes)
 * @param truncateMarker - Marker to append when truncating (default: "...[truncated]")
 * @returns Original value for basic OTel-compatible types; JSON/str string for complex types
 *
 * @example
 * ```typescript
 * serializeForTelemetry({ key: 'value' })  // Returns: {"key":"value"} as string
 * serializeForTelemetry([1, 2, 3])  // Returns: "[1,2,3]" as string
 * serializeForTelemetry('a'.repeat(2000), 100)  // Returns truncated string
 * ```
 */
export function serializeForTelemetry(
  data: any,
  maxLength: number = 1048576, // 1MB limit for large payloads
  truncateMarker: string = '...[truncated]'
): any {
  // null, boolean, number, float are returned unchanged (OTel-compatible)
  if (data === null || typeof data === 'boolean' || typeof data === 'number') {
    return data;
  }

  // Strings are returned as-is but with truncation applied if needed
  if (typeof data === 'string') {
    if (data.length <= maxLength) {
      return data;
    }
    const keepLength = maxLength - truncateMarker.length;
    if (keepLength > 0) {
      return data.slice(0, keepLength) + truncateMarker;
    }
    // If marker is too long for maxLength, just return the data as-is (let caller handle)
    return data;
  }

  let serialized: string;
  try {
    // Custom JSON encoder to handle special types
    serialized = JSON.stringify(data, jsonReplacer);
  } catch (error) {
    // Fallback to string representation for non-serializable objects
    serialized = String(data);
  }

  // Truncate if exceeds max length
  if (serialized.length > maxLength) {
    const keepLength = maxLength - truncateMarker.length;
    if (keepLength > 0) {
      serialized = serialized.slice(0, keepLength) + truncateMarker;
    } else {
      serialized = truncateMarker;
    }
  }

  return serialized;
}

/**
 * Custom JSON replacer function for handling special types.
 *
 * @param key - Object key
 * @param value - Object value
 * @returns JSON-serializable representation
 */
function jsonReplacer(_key: string, value: any): any {
  // Handle special types
  if (value instanceof Date) {
    return value.toISOString();
  }

  if (value instanceof Error) {
    return {
      name: value.name,
      message: value.message,
      stack: value.stack
    };
  }

  if (typeof value === 'bigint') {
    return value.toString();
  }

  if (value instanceof Set) {
    return Array.from(value);
  }

  if (value instanceof Map) {
    return Object.fromEntries(value);
  }

  if (Buffer.isBuffer(value)) {
    // Return a simple representation, let JSON.stringify handle the serialization
    return { type: 'Buffer', length: value.length, preview: value.slice(0, 16).toString('hex') };
  }

  return value;
}

/**
 * Extract shape information from data.
 *
 * @param data - Input or output data (arrays, objects, etc.)
 * @returns String representation of shape, or null if shape cannot be determined
 */
function getShape(data: any): string | null {
  try {
    // Handle arrays/tuples
    if (Array.isArray(data)) {
      if (data.length === 0) {
        return '(0,)';
      }

      // Recursively determine shape for nested structures
      const shape = [data.length];
      if (data.every(item => Array.isArray(item)) && data.length > 0) {
        const firstItemLength = data[0].length;
        if (data.every(item => Array.isArray(item) && item.length === firstItemLength)) {
          shape.push(firstItemLength);
          // Could recursively check deeper, but 2D is typically sufficient
        }
      }
      // Add trailing comma for 1D arrays (Python tuple notation)
      if (shape.length === 1) {
        return `(${shape[0]},)`;
      }
      return `(${shape.join(', ')})`;
    }

    // Handle objects with shape property (e.g., TensorFlow.js tensors)
    if (data && typeof data === 'object' && 'shape' in data) {
      const shapeValue = data.shape;
      if (Array.isArray(shapeValue)) {
        return `(${shapeValue.join(', ')})`;
      }
      return String(shapeValue);
    }

    return null;
  } catch (error) {
    return null;
  }
}

/**
 * Extract serialized data and shape with safe size limits.
 *
 * This function provides unified data extraction for both manual and auto
 * instrumentation. It always extracts shape information (lightweight) and
 * safely serializes data with byte-level size checking to prevent OOM issues.
 *
 * @param data - Data to extract (arrays, objects, etc.)
 * @param maxSizeBytes - Maximum size in bytes for serialized data (default: 10000)
 * @returns Dictionary with keys: data, shape, truncated
 *
 * @example
 * ```typescript
 * const payload = extractModelPayload([[1, 2], [3, 4]]);
 * console.log(payload.shape);  // "(2, 2)"
 * console.log(payload.truncated);  // false
 * ```
 */
export function extractModelPayload(
  data: any,
  maxSizeBytes: number = 10000
): { data: string | null; shape: string | null; truncated: boolean } {
  const result = {
    data: null as string | null,
    shape: null as string | null,
    truncated: false
  };

  try {
    // Always extract shape (lightweight operation)
    const shapeStr = getShape(data);
    if (shapeStr) {
      result.shape = shapeStr;
    }

    // Convert data to string
    let dataStr: string;
    try {
      if (Array.isArray(data) || (data && typeof data === 'object')) {
        // Use JSON.stringify with custom replacer
        dataStr = JSON.stringify(data, jsonReplacer);
      } else {
        dataStr = String(data);
      }
    } catch (error) {
      dataStr = String(data);
    }

    // Measure actual string byte size
    const dataBytes = Buffer.byteLength(dataStr, 'utf8');

    if (dataBytes > maxSizeBytes) {
      // Truncate to fit within exact byte limit including message
      const truncMsg = `...[truncated, ${dataBytes} bytes total]`;
      const truncMsgBytes = Buffer.byteLength(truncMsg, 'utf8');
      const allowedDataBytes = maxSizeBytes - truncMsgBytes;

      if (allowedDataBytes <= 0) {
        // Not enough space for any data, just return the message
        result.data = truncMsg;
        result.truncated = true;
      } else {
        // Slice by bytes and append message
        const buffer = Buffer.from(dataStr, 'utf8');
        const truncatedBuffer = buffer.slice(0, allowedDataBytes);
        const safeString = truncatedBuffer.toString('utf8');
        result.data = safeString + truncMsg;
        result.truncated = true;
      }
    } else {
      result.data = dataStr;
      result.truncated = false;
    }

    return result;
  } catch (error) {
    // Return safe fallback
    result.data = '[Failed to serialize data]';
    result.truncated = true;
    return result;
  }
}

/**
 * Sanitize credentials in JSON/dict structures.
 *
 * This structural approach is safer than regex-based parsing of JSON strings.
 * Recursively masks credential values in nested objects and arrays.
 *
 * @param data - Data to sanitize (object, array, or primitive)
 * @returns Sanitized data with credential values masked
 */
export function sanitizeCredentials(data: any): any {
  const credentialKeys = new Set([
    'token',
    'secret',
    'password',
    'api_key',
    'apikey',
    'access_key',
    'secret_key',
    'private_key',
    'auth_token',
    'bearer_token',
    'jwt',
    'client_secret',
    'api_secret',
    'aws_access_key_id',
    'aws_secret_access_key',
  ]);

  // Handle primitives
  if (data === null || typeof data === 'undefined') {
    return data;
  }

  // Handle strings - apply regex patterns
  if (typeof data === 'string') {
    let sanitized = data;
    for (const [, pattern, replacement] of CREDENTIAL_PATTERNS) {
      sanitized = sanitized.replace(pattern, replacement);
    }
    return sanitized;
  }

  // Handle arrays
  if (Array.isArray(data)) {
    return data.map(item => sanitizeCredentials(item));
  }

  // Handle objects
  if (typeof data === 'object') {
    const sanitized: any = {};
    for (const [key, value] of Object.entries(data)) {
      const keyLower = key.toLowerCase();

      // Check if key indicates a credential
      const isCredential = Array.from(credentialKeys).some(credKey =>
        keyLower.includes(credKey)
      );

      if (isCredential && typeof value === 'string' && value.length >= 8) {
        // Mask credential value
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        // Recursively sanitize nested objects/arrays
        sanitized[key] = sanitizeCredentials(value);
      } else {
        // Pass through other values
        sanitized[key] = value;
      }
    }
    return sanitized;
  }

  // Return primitives unchanged
  return data;
}
