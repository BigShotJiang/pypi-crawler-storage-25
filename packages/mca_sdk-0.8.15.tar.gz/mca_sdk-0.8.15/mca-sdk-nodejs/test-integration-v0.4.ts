import { MCAClient } from './src';

async function testIntegrationV04() {
  console.log('🧪 Testing Node.js MCA SDK v0.4.0 Features\n');

  const client = await MCAClient.create({
    serviceName: 'nodejs-test-v04',
    modelId: 'mdl-nodejs-001',
    modelVersion: '1.0.0',
    teamName: 'test-team',
    modelType: 'internal',
    collectorEndpoint: 'http://10.164.76.55:4318',
    strictValidation: false,
    // v0.4.0: Input/output capture configuration
    captureInputData: true,
    captureOutputData: true,
    captureMaxSizeBytes: 131072, // 128KB
  });

  console.log('✓ Client initialized with v0.4.0 config\n');

  // ========================================
  // Feature 1: Input/Output Data Capture
  // ========================================
  console.log('📊 Testing Input/Output Data Capture...');

  await client.recordPrediction({
    inputData: {
      features: [1.2, 3.4, 5.6, 7.8],
      patient_id: 'P12345',
      metadata: { source: 'ehr', timestamp: Date.now() }
    },
    outputData: {
      prediction: 0.85,
      confidence: 0.92,
      risk_category: 'moderate'
    },
    latency: 0.123,
  });
  console.log('  ✓ Prediction with input/output data captured\n');

  // ========================================
  // Feature 2: Credential Sanitization
  // ========================================
  console.log('🔒 Testing Credential Sanitization...');

  await client.recordPrediction({
    inputData: {
      query: 'Test query',
      config: {
        api_key: 'AKIAIOSFODNN7EXAMPLE',  // AWS key - will be masked
        bearer_token: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test',  // JWT - will be masked
        github_token: 'ghp_1234567890abcdefghijklmnopqrstuvwxyz'  // GitHub PAT - will be masked
      }
    },
    outputData: { result: 'success' },
    latency: 0.05,
  });
  console.log('  ✓ Credentials automatically sanitized (check span attributes)\n');

  // ========================================
  // Feature 3: Agentic AI - Goal Workflow
  // ========================================
  console.log('🤖 Testing Agentic AI Workflow...');

  const goalId = client.recordGoalStarted(
    'Process customer query',
    'customer_support'
  );
  console.log(`  ✓ Goal started: ${goalId}`);

  // ========================================
  // Feature 4: Reasoning Step Tracking
  // ========================================
  console.log('🧠 Testing Reasoning Step...');

  const analysisResult = await client.reasoningStep(
    'planning',
    async (span) => {
      span.setAttribute('query_complexity', 'medium');
      span.setAttribute('steps_planned', 3);

      // Simulate reasoning work
      await new Promise(resolve => setTimeout(resolve, 50));

      return {
        steps: ['analyze', 'search', 'respond'],
        confidence: 0.88
      };
    },
    {
      stepDescription: 'Analyze customer query',
      llmModel: 'gpt-4',
    }
  );
  console.log(`  ✓ Reasoning step completed:`, analysisResult);

  // ========================================
  // Feature 5: Tool Tracking
  // ========================================
  console.log('🔧 Testing Tool Tracking...');

  const toolResult = await client.trackTool(
    'database_lookup',
    async () => {
      await new Promise(resolve => setTimeout(resolve, 30));
      return { customer: 'John Doe', status: 'active' };
    },
    goalId,
    { query_type: 'customer_info' }
  );
  console.log(`  ✓ Tool executed:`, toolResult);

  // ========================================
  // Feature 6: Recovery Tracking (Retry)
  // ========================================
  console.log('♻️  Testing Recovery Tracking...');

  // First attempt - fails
  try {
    await client.trackTool(
      'unreliable_service',
      async () => {
        throw new Error('Service unavailable');
      },
      goalId
    );
  } catch (e) {
    console.log('  ✓ First attempt failed (expected)');
  }

  // Second attempt - succeeds (recovery tracked)
  const retryResult = await client.trackTool(
    'unreliable_service',
    async () => {
      return 'success';
    },
    goalId
  );
  console.log(`  ✓ Recovery successful:`, retryResult);
  console.log('  ℹ️  Check span for genai.agent.recovery.attempted=true\n');

  // ========================================
  // Feature 7: Human Intervention (Event Mode)
  // ========================================
  console.log('👤 Testing Human Intervention...');

  client.recordHumanIntervention(
    'User clarification required',
    45.2,
    'clarification',
    Date.now(), // Epoch milliseconds
    { intervention_context: 'ambiguous_query' }
  );
  console.log('  ✓ Human intervention recorded as span event\n');

  // ========================================
  // Feature 8: Policy Violation
  // ========================================
  console.log('⚠️  Testing Policy Violation...');

  // Fixed: recordPolicyViolation only takes one parameter (policyType)
  client.recordPolicyViolation('unauthorized_data_access');
  console.log('  ✓ Policy violation recorded\n');

  // Complete goal
  client.recordGoalCompleted(goalId, 'success', {
    resolution: 'query_answered',
    total_tools_used: 2,
  });
  console.log('  ✓ Goal completed\n');

  // ========================================
  // Feature 9: Singleton Access
  // ========================================
  console.log('🔗 Testing Singleton Access...');

  const instance = MCAClient.getInstance();
  console.log(`  ✓ getInstance() returned same client: ${instance === client}\n`);

  // ========================================
  // Feature 10: Large Payload Handling
  // ========================================
  console.log('📦 Testing Large Payload Handling...');

  await client.recordPrediction({
    inputData: {
      // Fixed: removed unused 'i' parameter
      features: Array(1000).fill(0).map(() => Math.random()),
      large_text: 'x'.repeat(200000), // 200KB text - will be truncated
    },
    outputData: { prediction: 0.95 },
    latency: 0.2,
  });
  console.log('  ✓ Large payload handled (truncated to 128KB limit)\n');

  console.log('⏳ Waiting 5 seconds for telemetry to export...');
  await new Promise(resolve => setTimeout(resolve, 5000));

  await client.shutdown();
  console.log('\n✅ All v0.4.0 features tested successfully!');
}

testIntegrationV04().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
