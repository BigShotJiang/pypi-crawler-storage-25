import { RegistryClient } from './src/registry/client';
import { MCAClient } from './src';

async function testRegistryIntegration() {
  console.log('🔗 Testing Registry Integration\n');

  const REGISTRY_URL = 'https://emms-registration-api-dev-rlaptra7zq-ue.a.run.app';
  const MODEL_ID = '7a6fd3b1-3d8c-4768-9100-a8628d1f6237'; // Same as Python example

  // Step 1: Check registry health
  console.log('Checking registry availability...');
  try {
    const healthCheck = await fetch(`${REGISTRY_URL}/health`, {
      signal: AbortSignal.timeout(5000)
    });
    if (!healthCheck.ok) {
      console.log('⚠️  Registry unavailable - skipping test');
      console.log('   (This is expected if registry service is down)');
      return;
    }
  } catch (error: any) {
    console.log('⚠️  Registry unavailable - skipping test');
    console.log(`   Error: ${error.message}`);
    return;
  }

  // Step 2: EXPLICIT registry fetch (matching Python pattern)
  console.log('\n=== Explicit Registry Fetch (Python-style) ===');
  const registryClient = new RegistryClient(
    REGISTRY_URL,
    undefined, // token
    10000      // timeout: 10s
  );

  try {
    const modelConfig = await registryClient.fetchModelConfig(MODEL_ID);
    console.log(`✓ Model config fetched: ${modelConfig.serviceName}`);
    console.log(`✓ Team: ${modelConfig.teamName}`);

    // Step 3: Use registry data to initialize client (matching Python)
    const client = await MCAClient.create({
      serviceName: modelConfig.serviceName,
      modelId: MODEL_ID,
      teamName: modelConfig.teamName,
      collectorEndpoint: 'http://10.164.76.55:4318',
      strictValidation: false,
      // Note: registryUrl NOT provided here - already fetched explicitly
    });

    console.log('✓ Client initialized with registry data\n');

    // Test prediction
    await client.recordPrediction({ latency: 0.1 });
    console.log('✓ Prediction recorded\n');

    await client.shutdown();
  } catch (error: any) {
    console.error(`❌ Registry integration failed: ${error.message}`);
    if (error.message.includes('not found')) {
      console.log('   Hint: Model may not be registered in registry');
    } else if (error.message.includes('timed out')) {
      console.log('   Hint: Registry service is slow or unavailable');
    }
    throw error;
  }

  // Step 4: IMPLICIT registry integration (Node.js-style)
  console.log('=== Implicit Registry Integration (Node.js-style) ===');
  const client2 = await MCAClient.create({
    serviceName: 'nodejs-registry-test',
    modelId: MODEL_ID,
    teamName: 'test-team',
    collectorEndpoint: 'http://10.164.76.55:4318',
    registryUrl: REGISTRY_URL,  // ← SDK fetches in background
    strictValidation: false,     // ← Graceful degradation if fetch fails
  });

  console.log('✓ Client initialized with background registry fetch');
  console.log('  (Note: Config may be hydrated from registry in background)\n');

  await client2.recordPrediction({ latency: 0.05 });
  await client2.shutdown();

  console.log('✅ Registry integration test complete!');
  console.log('\nKey Difference:');
  console.log('- Python SDK: Explicit fetch, fails hard if registry unavailable');
  console.log('- Node.js SDK: Optional fetch, graceful degradation with warning');
}

testRegistryIntegration().catch(error => {
  console.error('❌ Test failed:', error);
  process.exit(1);
});
