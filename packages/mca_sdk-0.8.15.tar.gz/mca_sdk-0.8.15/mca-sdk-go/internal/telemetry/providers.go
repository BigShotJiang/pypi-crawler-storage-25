// Package telemetry provides internal OpenTelemetry provider setup.
package telemetry

import (
	"context"
	"fmt"
	"time"

	"go.opentelemetry.io/otel/exporters/otlp/otlplog/otlploghttp"
	"go.opentelemetry.io/otel/exporters/otlp/otlpmetric/otlpmetrichttp"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/sdk/log"
	"go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/resource"
	"go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.24.0"
)

// SetupMeterProvider creates and configures a MeterProvider with OTLP/HTTP exporter.
// If filterSystemMetrics is true, process.* and runtime.* metrics are dropped to reduce costs.
func SetupMeterProvider(ctx context.Context, endpoint string, res *resource.Resource, insecure bool, filterSystemMetrics bool) (*metric.MeterProvider, error) {
	// Create OTLP/HTTP metric exporter
	opts := []otlpmetrichttp.Option{
		otlpmetrichttp.WithEndpoint(endpoint),
	}
	if insecure {
		opts = append(opts, otlpmetrichttp.WithInsecure())
	}
	exporter, err := otlpmetrichttp.New(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("failed to create metric exporter: %w", err)
	}

	// Build provider options
	providerOpts := []metric.Option{
		metric.WithResource(res),
		metric.WithReader(metric.NewPeriodicReader(exporter,
			metric.WithInterval(10*time.Second), // Export metrics every 10 seconds
		)),
	}

	// Add metric filtering views if enabled
	if filterSystemMetrics {
		providerOpts = append(providerOpts,
			metric.WithView(metric.NewView(
				metric.Instrument{Name: "process.*"},
				metric.Stream{Aggregation: metric.AggregationDrop{}},
			)),
			metric.WithView(metric.NewView(
				metric.Instrument{Name: "runtime.*"},
				metric.Stream{Aggregation: metric.AggregationDrop{}},
			)),
		)
	}

	// Create meter provider with options
	provider := metric.NewMeterProvider(providerOpts...)

	return provider, nil
}

// SetupTracerProvider creates and configures a TracerProvider with OTLP/HTTP exporter.
func SetupTracerProvider(ctx context.Context, endpoint string, res *resource.Resource, insecure bool) (*trace.TracerProvider, error) {
	// Create OTLP/HTTP trace exporter
	opts := []otlptracehttp.Option{
		otlptracehttp.WithEndpoint(endpoint),
	}
	if insecure {
		opts = append(opts, otlptracehttp.WithInsecure())
	}
	exporter, err := otlptracehttp.New(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("failed to create trace exporter: %w", err)
	}

	// Create tracer provider with batch processor
	provider := trace.NewTracerProvider(
		trace.WithResource(res),
		trace.WithBatcher(exporter,
			trace.WithBatchTimeout(5*time.Second), // Batch traces every 5 seconds
		),
	)

	return provider, nil
}

// SetupLoggerProvider creates and configures a LoggerProvider with OTLP/HTTP exporter.
func SetupLoggerProvider(ctx context.Context, endpoint string, res *resource.Resource, insecure bool) (*log.LoggerProvider, error) {
	// Create OTLP/HTTP log exporter
	opts := []otlploghttp.Option{
		otlploghttp.WithEndpoint(endpoint),
	}
	if insecure {
		opts = append(opts, otlploghttp.WithInsecure())
	}
	exporter, err := otlploghttp.New(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("failed to create log exporter: %w", err)
	}

	// Create logger provider with batch processor
	provider := log.NewLoggerProvider(
		log.WithResource(res),
		log.WithProcessor(log.NewBatchProcessor(exporter,
			log.WithExportInterval(5*time.Second), // Batch logs every 5 seconds
		)),
	)

	return provider, nil
}

// CreateResource creates an OpenTelemetry resource with model-specific attributes.
// The sdkVersion parameter is passed from the mca package to avoid circular imports.
func CreateResource(
	serviceName, modelID, version, team, modelType, modelCategory string,
	sdkVersion string,
) (*resource.Resource, error) {
	return resource.New(context.Background(),
		resource.WithAttributes(
			// Standard OTel semantic conventions
			semconv.ServiceName(serviceName),
			semconv.ServiceVersion(version),
			semconv.ServiceInstanceID(modelID),
		),
		resource.WithAttributes(
			// Custom model attributes (not duplicating standard conventions)
			semconv.ServiceInstanceIDKey.String(modelID), // model.id
			semconv.Key("team.name").String(team),
			semconv.Key("model.type").String(modelType),
			semconv.Key("model.category").String(modelCategory),
		),
		resource.WithAttributes(
			// SDK version attributes (immutable, highest precedence)
			semconv.Key("mca.sdk.version").String(sdkVersion),
			semconv.Key("telemetry.sdk.version").String(sdkVersion),
			semconv.Key("telemetry.sdk.name").String("mca-sdk-go"),
			semconv.Key("telemetry.sdk.language").String("go"),
		),
		resource.WithSchemaURL(semconv.SchemaURL),
	)
}
