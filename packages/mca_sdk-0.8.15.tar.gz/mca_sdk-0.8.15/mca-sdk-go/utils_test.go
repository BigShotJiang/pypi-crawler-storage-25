package mca

import (
	"strings"
	"testing"
)

// TestStructToAttributes_BasicTypes tests conversion of basic Go types.
func TestStructToAttributes_BasicTypes(t *testing.T) {
	type Person struct {
		Name   string
		Age    int
		Height float64
		Active bool
	}

	person := Person{
		Name:   "Alice",
		Age:    30,
		Height: 5.6,
		Active: true,
	}

	attrs, err := StructToAttributes(person)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	tests := []struct {
		key   string
		want  interface{}
		wantType string
	}{
		{"Name", "Alice", "string"},
		{"Age", int64(30), "int64"},
		{"Height", 5.6, "float64"},
		{"Active", true, "bool"},
	}

	for _, tt := range tests {
		val, ok := attrs[tt.key]
		if !ok {
			t.Errorf("missing key %q", tt.key)
			continue
		}
		if val != tt.want {
			t.Errorf("key %q = %v (type %T), want %v (type %s)", tt.key, val, val, tt.want, tt.wantType)
		}
	}
}

// TestStructToAttributes_NestedStruct tests flattening of nested structs.
func TestStructToAttributes_NestedStruct(t *testing.T) {
	type Address struct {
		City string
		Zip  int
	}
	type User struct {
		Name    string
		Address Address
	}

	user := User{
		Name: "Bob",
		Address: Address{
			City: "NYC",
			Zip:  10001,
		},
	}

	attrs, err := StructToAttributes(user)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	if attrs["Name"] != "Bob" {
		t.Errorf("Name = %v, want Bob", attrs["Name"])
	}
	if attrs["Address.City"] != "NYC" {
		t.Errorf("Address.City = %v, want NYC", attrs["Address.City"])
	}
	if attrs["Address.Zip"] != int64(10001) {
		t.Errorf("Address.Zip = %v, want 10001", attrs["Address.Zip"])
	}
}

// TestStructToAttributes_Pointer tests handling of pointer fields.
func TestStructToAttributes_Pointer(t *testing.T) {
	type Config struct {
		Enabled *bool
		Timeout *int
	}

	enabled := true
	timeout := 30

	config := Config{
		Enabled: &enabled,
		Timeout: &timeout,
	}

	attrs, err := StructToAttributes(config)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	if attrs["Enabled"] != true {
		t.Errorf("Enabled = %v, want true", attrs["Enabled"])
	}
	if attrs["Timeout"] != int64(30) {
		t.Errorf("Timeout = %v, want 30", attrs["Timeout"])
	}
}

// TestStructToAttributes_NilPointer tests handling of nil pointers.
func TestStructToAttributes_NilPointer(t *testing.T) {
	type Config struct {
		Name    string
		Timeout *int
	}

	config := Config{
		Name:    "test",
		Timeout: nil,
	}

	attrs, err := StructToAttributes(config)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	if attrs["Name"] != "test" {
		t.Errorf("Name = %v, want test", attrs["Name"])
	}
	// Nil pointer field should be skipped
	if _, ok := attrs["Timeout"]; ok {
		t.Errorf("Timeout should not be present for nil pointer")
	}
}

// TestStructToAttributes_UnexportedFields tests that unexported fields are skipped.
func TestStructToAttributes_UnexportedFields(t *testing.T) {
	type Data struct {
		Public  string
		private string
	}

	data := Data{
		Public:  "visible",
		private: "hidden",
	}

	attrs, err := StructToAttributes(data)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	if attrs["Public"] != "visible" {
		t.Errorf("Public = %v, want visible", attrs["Public"])
	}
	if _, ok := attrs["private"]; ok {
		t.Errorf("unexported field 'private' should not be in attributes")
	}
}

// TestStructToAttributes_Slice tests handling of slice fields.
func TestStructToAttributes_Slice(t *testing.T) {
	type Data struct {
		Tags []string
	}

	data := Data{
		Tags: []string{"tag1", "tag2", "tag3"},
	}

	attrs, err := StructToAttributes(data)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	tagsVal, ok := attrs["Tags"]
	if !ok {
		t.Fatal("Tags not found in attributes")
	}

	// Slices are serialized to JSON strings
	tagsStr, ok := tagsVal.(string)
	if !ok {
		t.Fatalf("Tags should be string, got %T", tagsVal)
	}
	if !strings.Contains(tagsStr, "tag1") || !strings.Contains(tagsStr, "tag2") {
		t.Errorf("Tags = %v, want JSON array with tag1, tag2", tagsStr)
	}
}

// TestStructToAttributes_Map tests handling of map fields.
func TestStructToAttributes_Map(t *testing.T) {
	type Data struct {
		Metadata map[string]string
	}

	data := Data{
		Metadata: map[string]string{
			"env":  "prod",
			"team": "ml",
		},
	}

	attrs, err := StructToAttributes(data)
	if err != nil {
		t.Fatalf("StructToAttributes() error: %v", err)
	}

	metadataVal, ok := attrs["Metadata"]
	if !ok {
		t.Fatal("Metadata not found in attributes")
	}

	// Maps are serialized to JSON strings
	metadataStr, ok := metadataVal.(string)
	if !ok {
		t.Fatalf("Metadata should be string, got %T", metadataVal)
	}
	if !strings.Contains(metadataStr, "env") || !strings.Contains(metadataStr, "prod") {
		t.Errorf("Metadata = %v, want JSON object with env=prod", metadataStr)
	}
}

// TestStructToAttributes_UnsupportedTypes tests error handling for unsupported types.
func TestStructToAttributes_UnsupportedTypes(t *testing.T) {
	type InvalidData struct {
		Channel chan int
	}

	data := InvalidData{
		Channel: make(chan int),
	}

	_, err := StructToAttributes(data)
	if err == nil {
		t.Error("StructToAttributes() should return error for channel type")
	}
}

// TestStructToAttributes_DeepNesting tests maximum depth protection.
func TestStructToAttributes_DeepNesting(t *testing.T) {
	// Create deeply nested struct exceeding maxDepth
	type Level struct {
		Value int
		Next  *Level
	}

	// Build 15 levels of nesting (exceeds maxDepth of 10)
	var root Level
	current := &root
	for i := 0; i < 15; i++ {
		current.Value = i
		current.Next = &Level{}
		current = current.Next
	}

	_, err := StructToAttributes(root)
	if err == nil {
		t.Error("StructToAttributes() should return error for excessive nesting depth")
	}
	if !strings.Contains(err.Error(), "nesting depth") {
		t.Errorf("error should mention nesting depth, got: %v", err)
	}
}

// TestSerializeForTelemetry_BasicTypes tests serialization of basic types.
func TestSerializeForTelemetry_BasicTypes(t *testing.T) {
	tests := []struct {
		name  string
		input interface{}
		want  string
	}{
		{"string", "hello", "hello"},
		{"int", 42, "42"},
		{"float", 3.14, "3.14"},
		{"bool", true, "true"},
		{"nil", nil, ""},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result, err := SerializeForTelemetry(tt.input, 1000)
			if err != nil {
				t.Errorf("SerializeForTelemetry() error: %v", err)
			}
			if result != tt.want {
				t.Errorf("SerializeForTelemetry() = %q, want %q", result, tt.want)
			}
		})
	}
}

// TestSerializeForTelemetry_ComplexTypes tests JSON serialization.
func TestSerializeForTelemetry_ComplexTypes(t *testing.T) {
	input := map[string]interface{}{
		"name": "test",
		"age":  30,
		"active": true,
	}

	result, err := SerializeForTelemetry(input, 10000)
	if err != nil {
		t.Fatalf("SerializeForTelemetry() error: %v", err)
	}

	if !strings.Contains(result, "test") || !strings.Contains(result, "30") {
		t.Errorf("SerializeForTelemetry() = %q, want JSON with test and 30", result)
	}
}

// TestSerializeForTelemetry_Truncation tests size truncation.
func TestSerializeForTelemetry_Truncation(t *testing.T) {
	longString := strings.Repeat("a", 200)
	maxLength := 100

	result, err := SerializeForTelemetry(longString, maxLength)
	if err != nil {
		t.Fatalf("SerializeForTelemetry() error: %v", err)
	}

	if len(result) > maxLength {
		t.Errorf("SerializeForTelemetry() length = %d, want <= %d", len(result), maxLength)
	}
	if !strings.HasSuffix(result, "[truncated]") {
		t.Errorf("SerializeForTelemetry() should end with [truncated], got: %s", result[len(result)-20:])
	}
}

// TestSerializeForTelemetry_LargePayload tests 1MB limit.
func TestSerializeForTelemetry_LargePayload(t *testing.T) {
	// Create 2MB string
	largeString := strings.Repeat("x", 2*1024*1024)

	result, err := SerializeForTelemetry(largeString, MaxSerializedLength)
	if err != nil {
		t.Fatalf("SerializeForTelemetry() error: %v", err)
	}

	if len(result) > MaxSerializedLength {
		t.Errorf("SerializeForTelemetry() length = %d, want <= %d", len(result), MaxSerializedLength)
	}
	if !strings.Contains(result, "[truncated]") {
		t.Errorf("SerializeForTelemetry() should contain [truncated] marker")
	}
}
