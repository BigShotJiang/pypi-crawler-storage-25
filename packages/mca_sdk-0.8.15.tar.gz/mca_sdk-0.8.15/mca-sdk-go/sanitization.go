// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

import (
	"regexp"
	"strings"
)

// Credential patterns for automatic masking in telemetry.
// These patterns prevent the SDK from exposing technical credentials
// (AWS keys, GCP tokens, JWTs, etc.) in error messages and traces.
//
// IMPORTANT: The SDK performs NO PHI/PII masking. Applications MUST
// sanitize all PHI/PII data BEFORE passing to SDK methods.
var credentialPatterns = []credentialPattern{
	{
		name:        "aws_access_key",
		regex:       regexp.MustCompile(`\bAKIA[0-9A-Z]{16}\b`),
		replacement: "[AWS-KEY-REDACTED]",
	},
	{
		name:        "gcp_service_account",
		regex:       regexp.MustCompile(`"private_key":\s*".*?"`),
		replacement: `"private_key":"[GCP-KEY-REDACTED]"`,
	},
	{
		name:        "bearer_token",
		regex:       regexp.MustCompile(`Bearer\s+[A-Za-z0-9\-._~+/]+`),
		replacement: "Bearer [TOKEN-REDACTED]",
	},
	{
		name:        "api_key",
		regex:       regexp.MustCompile(`api[_-]?key["\s:=]+[A-Za-z0-9\-._~+/]+`),
		replacement: "api_key=[KEY-REDACTED]",
	},
	{
		name:        "jwt",
		regex:       regexp.MustCompile(`eyJ[A-Za-z0-9\-._~+/]+=*\.eyJ[A-Za-z0-9\-._~+/]+=*\.[A-Za-z0-9\-._~+/]+=*`),
		replacement: "[JWT-REDACTED]",
	},
}

// credentialPattern defines a regex pattern for credential detection.
type credentialPattern struct {
	name        string
	regex       *regexp.Regexp
	replacement string
}

// SanitizeCredentials removes sensitive credentials from input string.
// This function is used internally to prevent credential leakage in telemetry.
//
// Masked credential types:
//   - AWS access keys (AKIA...)
//   - GCP service account keys ("private_key": ...)
//   - Bearer tokens (Bearer ...)
//   - API keys (api_key=...)
//   - JWTs (eyJ...eyJ...signature)
//
// Example:
//
//	input := "Error: AWS key AKIAIOSFODNN7EXAMPLE failed"
//	output := SanitizeCredentials(input)
//	// output: "Error: AWS key [AWS-KEY-REDACTED] failed"
func SanitizeCredentials(input string) string {
	if input == "" {
		return input
	}

	sanitized := input
	for _, pattern := range credentialPatterns {
		sanitized = pattern.regex.ReplaceAllString(sanitized, pattern.replacement)
	}
	return sanitized
}

// SanitizeMap recursively sanitizes credential strings in map values.
// This is used for sanitizing structured data like attributes.
func SanitizeMap(data map[string]interface{}) map[string]interface{} {
	sanitized := make(map[string]interface{}, len(data))
	for k, v := range data {
		sanitized[k] = sanitizeValue(v)
	}
	return sanitized
}

// sanitizeValue recursively sanitizes credentials in interface{} values.
func sanitizeValue(v interface{}) interface{} {
	switch val := v.(type) {
	case string:
		return SanitizeCredentials(val)
	case map[string]interface{}:
		return SanitizeMap(val)
	case []interface{}:
		sanitized := make([]interface{}, len(val))
		for i, item := range val {
			sanitized[i] = sanitizeValue(item)
		}
		return sanitized
	default:
		// For non-string types, return as-is
		return v
	}
}

// isSensitiveKey checks if a key name indicates potentially sensitive data.
// This provides an additional layer of protection for fields that might contain credentials.
func isSensitiveKey(key string) bool {
	lowerKey := strings.ToLower(key)
	sensitiveKeywords := []string{
		"password", "passwd", "secret", "token", "key", "auth", "credential",
		"api_key", "apikey", "access_key", "private_key",
	}
	for _, keyword := range sensitiveKeywords {
		if strings.Contains(lowerKey, keyword) {
			return true
		}
	}
	return false
}
