// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

// Version is the current version of the MCA SDK.
// This constant is used for telemetry resource attributes and follows
// the Python SDK version to maintain cross-language parity.
const Version = "0.8.8"
