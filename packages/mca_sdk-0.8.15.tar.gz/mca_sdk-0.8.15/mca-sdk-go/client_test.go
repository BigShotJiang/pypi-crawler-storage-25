package mca

import (
	"context"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/baptisthealth/mca-sdk-go/config"
)

// TestNewClient_Success verifies that a valid configuration creates a client.
func TestNewClient_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true, // Local dev
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() unexpected error: %v", err)
	}
	if client == nil {
		t.Fatal("NewClient() returned nil client")
	}

	// Verify client was initialized
	if client.config.ServiceName != "test-service" {
		t.Errorf("ServiceName = %q, want %q", client.config.ServiceName, "test-service")
	}
	if client.config.ModelID != "mdl-001" {
		t.Errorf("ModelID = %q, want %q", client.config.ModelID, "mdl-001")
	}

	// Cleanup
	if err := client.Shutdown(); err != nil {
		t.Errorf("Shutdown() error: %v", err)
	}
}

// TestNewClient_ValidationError verifies that invalid config returns error.
func TestNewClient_ValidationError(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	tests := []struct {
		name   string
		config *config.Config
	}{
		{
			name: "missing service name",
			config: &config.Config{
				ModelID:  "mdl-001",
				TeamName: "test-team",
			},
		},
		{
			name: "missing model id",
			config: &config.Config{
				ServiceName: "test-service",
				TeamName:    "test-team",
			},
		},
		{
			name: "missing team name",
			config: &config.Config{
				ServiceName: "test-service",
				ModelID:     "mdl-001",
			},
		},
	}

	ctx := context.Background()
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			client, err := NewClient(ctx, tt.config)
			if err == nil {
				t.Error("NewClient() expected error, got nil")
				if client != nil {
					_ = client.Shutdown()
				}
			}
			if !config.IsConfigurationError(err) {
				t.Errorf("NewClient() error type = %T, want ConfigurationError", err)
			}
		})
	}
}

// TestRecordPrediction_Success verifies prediction recording works.
func TestRecordPrediction_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	latency := 0.15
	pred := &Prediction{
		Latency:      &latency,
		PredictionID: "pred-123",
		Attributes: map[string]string{
			"model_version": "2.0",
			"input_size":    "1024",
		},
	}

	err = client.RecordPrediction(context.Background(), pred)
	if err != nil {
		t.Errorf("RecordPrediction() unexpected error: %v", err)
	}
}

// TestRecordPrediction_WithZeroLatency verifies 0.0 latency is recorded.
func TestRecordPrediction_WithZeroLatency(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	latency := 0.0 // Valid zero latency
	pred := &Prediction{
		Latency:      &latency,
		PredictionID: "pred-zero",
	}

	err = client.RecordPrediction(context.Background(), pred)
	if err != nil {
		t.Errorf("RecordPrediction() unexpected error for 0.0 latency: %v", err)
	}
}

// TestRecordPrediction_NoLatency verifies recording without latency.
func TestRecordPrediction_NoLatency(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	pred := &Prediction{
		PredictionID: "pred-789",
		Latency:      nil, // No latency
	}

	err = client.RecordPrediction(context.Background(), pred)
	if err != nil {
		t.Errorf("RecordPrediction() unexpected error: %v", err)
	}
}

// TestRecordPrediction_AfterShutdown verifies error after shutdown.
func TestRecordPrediction_AfterShutdown(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Shutdown client
	if err := client.Shutdown(); err != nil {
		t.Errorf("Shutdown() error: %v", err)
	}

	// Try to record prediction after shutdown
	pred := &Prediction{PredictionID: "pred-after-shutdown"}
	err = client.RecordPrediction(context.Background(), pred)
	if err != ErrClientClosed {
		t.Errorf("RecordPrediction() after shutdown: got %v, want %v", err, ErrClientClosed)
	}
}

// TestRecordPrediction_AttributeLimit verifies attribute cardinality limits.
func TestRecordPrediction_AttributeLimit(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Create prediction with > 50 attributes
	attrs := make(map[string]string)
	for i := 0; i < 60; i++ {
		attrs[string(rune('a'+i))] = "value"
	}

	pred := &Prediction{
		Attributes: attrs,
	}

	// Should not error, but should log warning
	err = client.RecordPrediction(context.Background(), pred)
	if err != nil {
		t.Errorf("RecordPrediction() unexpected error: %v", err)
	}
}

// TestShutdown_Success verifies graceful shutdown.
func TestShutdown_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	err = client.Shutdown()
	if err != nil {
		t.Errorf("Shutdown() unexpected error: %v", err)
	}
}

// TestShutdown_Idempotent verifies multiple shutdown calls are safe.
func TestShutdown_Idempotent(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Call shutdown multiple times
	err1 := client.Shutdown()
	err2 := client.Shutdown()
	err3 := client.Shutdown()

	if err1 != nil {
		t.Errorf("First Shutdown() unexpected error: %v", err1)
	}
	// Subsequent calls should return the same error (or nil)
	if err2 != err1 {
		t.Errorf("Second Shutdown() error = %v, want %v", err2, err1)
	}
	if err3 != err1 {
		t.Errorf("Third Shutdown() error = %v, want %v", err3, err1)
	}
}

// TestConcurrency_RecordPrediction verifies goroutine safety.
func TestConcurrency_RecordPrediction(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	const numGoroutines = 100
	const predictionsPerGoroutine = 10

	var wg sync.WaitGroup
	wg.Add(numGoroutines)

	// Launch multiple goroutines recording predictions
	for i := 0; i < numGoroutines; i++ {
		go func(id int) {
			defer wg.Done()
			for j := 0; j < predictionsPerGoroutine; j++ {
				latency := 0.10 + float64(j)*0.01
				pred := &Prediction{
					Latency:      &latency,
					PredictionID: "pred-" + string(rune(id)),
					Attributes: map[string]string{
						"goroutine": string(rune(id)),
						"iteration": string(rune(j)),
					},
				}
				if err := client.RecordPrediction(context.Background(), pred); err != nil {
					t.Errorf("RecordPrediction() error in goroutine %d: %v", id, err)
				}
			}
		}(i)
	}

	wg.Wait()
}

// TestDefaultValues verifies that default values are applied.
func TestDefaultValues(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		// Don't set optional fields - should get defaults
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Verify defaults were applied
	if client.config.ModelVersion != "1.0.0" {
		t.Errorf("ModelVersion = %q, want %q", client.config.ModelVersion, "1.0.0")
	}
	if client.config.ModelType != "internal" {
		t.Errorf("ModelType = %q, want %q", client.config.ModelType, "internal")
	}
	if client.config.ModelCategory != "internal" {
		t.Errorf("ModelCategory = %q, want %q", client.config.ModelCategory, "internal")
	}
	if client.config.CollectorEndpoint != "http://localhost:4318" {
		t.Errorf("CollectorEndpoint = %q, want %q", client.config.CollectorEndpoint, "http://localhost:4318")
	}
	if client.config.Protocol != "http" {
		t.Errorf("Protocol = %q, want %q", client.config.Protocol, "http")
	}
}

// TestConcurrency_ShutdownDuringRecording verifies no race between Shutdown and RecordPrediction.
func TestConcurrency_ShutdownDuringRecording(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Launch goroutine that continuously records predictions
	var wg sync.WaitGroup
	wg.Add(1)
	stopRecording := make(chan struct{})

	go func() {
		defer wg.Done()
		latency := 0.10
		for {
			select {
			case <-stopRecording:
				return
			default:
				pred := &Prediction{
					Latency:      &latency,
					PredictionID: "pred-concurrent",
				}
				// This should either succeed or return ErrClientClosed, never panic
				_ = client.RecordPrediction(context.Background(), pred)
				time.Sleep(1 * time.Millisecond) // Small delay to allow shutdown to happen
			}
		}
	}()

	// Give recording goroutine time to start
	time.Sleep(10 * time.Millisecond)

	// Shutdown client while recording is happening
	if err := client.Shutdown(); err != nil {
		t.Logf("Shutdown() error (acceptable): %v", err)
	}

	// Stop recording goroutine
	close(stopRecording)
	wg.Wait()

	// Verify subsequent calls return ErrClientClosed
	pred := &Prediction{PredictionID: "pred-after-race"}
	err = client.RecordPrediction(context.Background(), pred)
	if err != ErrClientClosed {
		t.Errorf("RecordPrediction() after race: got %v, want %v", err, ErrClientClosed)
	}
}

// BenchmarkRecordPrediction measures prediction recording performance.
func BenchmarkRecordPrediction(b *testing.B) {
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		b.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	latency := 0.15
	pred := &Prediction{
		Latency:      &latency,
		PredictionID: "pred-bench",
		Attributes: map[string]string{
			"model_version": "2.0",
		},
	}

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = client.RecordPrediction(context.Background(), pred)
	}
}

// TestFlush_Success verifies flush succeeds.
func TestFlush_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Flush should succeed
	err = client.Flush(context.Background())
	if err != nil {
		t.Errorf("Flush() unexpected error: %v", err)
	}
}

// TestFlush_AfterShutdown verifies error after shutdown.
func TestFlush_AfterShutdown(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Shutdown client
	if err := client.Shutdown(); err != nil {
		t.Errorf("Shutdown() error: %v", err)
	}

	// Flush after shutdown should return ErrClientClosed
	err = client.Flush(context.Background())
	if err != ErrClientClosed {
		t.Errorf("Flush() after shutdown: got %v, want %v", err, ErrClientClosed)
	}
}

// TestRecordGoalStarted_ReturnsUUID verifies UUID generation.
func TestRecordGoalStarted_ReturnsUUID(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	goalID, err := client.RecordGoalStarted(context.Background(), "Test goal", "research", nil)
	if err != nil {
		t.Fatalf("RecordGoalStarted() error: %v", err)
	}

	if goalID == "" {
		t.Error("RecordGoalStarted() returned empty goal ID")
	}

	// UUID should be 36 characters with dashes
	if len(goalID) != 36 {
		t.Errorf("RecordGoalStarted() goal ID length = %d, want 36", len(goalID))
	}
}

// TestRecordGoalCompleted_Success verifies goal completion.
func TestRecordGoalCompleted_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	goalID, err := client.RecordGoalStarted(context.Background(), "Test goal", "research", nil)
	if err != nil {
		t.Fatalf("RecordGoalStarted() error: %v", err)
	}

	// Complete the goal
	err = client.RecordGoalCompleted(context.Background(), goalID, "success", nil)
	if err != nil {
		t.Errorf("RecordGoalCompleted() error: %v", err)
	}
}

// TestRecordGoalCompleted_InvalidStatus verifies status validation.
func TestRecordGoalCompleted_InvalidStatus(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	goalID, err := client.RecordGoalStarted(context.Background(), "Test goal", "research", nil)
	if err != nil {
		t.Fatalf("RecordGoalStarted() error: %v", err)
	}

	// Try invalid status
	err = client.RecordGoalCompleted(context.Background(), goalID, "invalid", nil)
	if err == nil {
		t.Error("RecordGoalCompleted() expected error for invalid status, got nil")
	}
}

// TestRecordGoalCompleted_UnknownGoalID verifies error handling.
func TestRecordGoalCompleted_UnknownGoalID(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Try to complete unknown goal
	err = client.RecordGoalCompleted(context.Background(), "unknown-goal-id", "success", nil)
	if err == nil {
		t.Error("RecordGoalCompleted() expected error for unknown goal ID, got nil")
	}
}

// TestTrackTool_Success verifies tool tracking with success.
func TestTrackTool_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	goalID, err := client.RecordGoalStarted(context.Background(), "Test goal", "research", nil)
	if err != nil {
		t.Fatalf("RecordGoalStarted() error: %v", err)
	}

	// Track successful tool execution
	err = client.TrackTool(context.Background(), "test_tool", goalID, nil, func(ctx context.Context) error {
		return nil
	})
	if err != nil {
		t.Errorf("TrackTool() error: %v", err)
	}

	client.RecordGoalCompleted(context.Background(), goalID, "success", nil)
}

// TestTrackTool_Error verifies tool tracking with error.
func TestTrackTool_Error(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	goalID, err := client.RecordGoalStarted(context.Background(), "Test goal", "research", nil)
	if err != nil {
		t.Fatalf("RecordGoalStarted() error: %v", err)
	}

	// Track failed tool execution
	expectedErr := fmt.Errorf("tool failed")
	err = client.TrackTool(context.Background(), "test_tool", goalID, nil, func(ctx context.Context) error {
		return expectedErr
	})
	if err == nil {
		t.Error("TrackTool() expected error, got nil")
	}
	if err.Error() != expectedErr.Error() {
		t.Errorf("TrackTool() error = %v, want %v", err, expectedErr)
	}

	client.RecordGoalCompleted(context.Background(), goalID, "failure", nil)
}

// TestRecordHumanIntervention_Success verifies span event.
func TestRecordHumanIntervention_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	err = client.RecordHumanIntervention(context.Background(), "approval_needed", 120.0, "review", time.Now())
	if err != nil {
		t.Errorf("RecordHumanIntervention() error: %v", err)
	}
}

// TestRecordPolicyViolation_Success verifies span event.
func TestRecordPolicyViolation_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	err = client.RecordPolicyViolation(context.Background(), "data_access")
	if err != nil {
		t.Errorf("RecordPolicyViolation() error: %v", err)
	}
}

// TestRecordError_Success verifies dual metrics.
func TestRecordError_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	latency := 0.5
	err = client.RecordError(context.Background(), fmt.Errorf("validation failed"), &latency, "pred-123", nil)
	if err != nil {
		t.Errorf("RecordError() error: %v", err)
	}
}

// TestRecordError_NoLatency verifies error recording without latency.
func TestRecordError_NoLatency(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	err = client.RecordError(context.Background(), fmt.Errorf("validation failed"), nil, "", nil)
	if err != nil {
		t.Errorf("RecordError() error: %v", err)
	}
}

// TestRecordEvaluation_Success verifies MAE/RMSE recording.
func TestRecordEvaluation_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	metrics := map[string]float64{
		"mae":  0.05,
		"rmse": 0.08,
	}
	err = client.RecordEvaluation(context.Background(), metrics, "test", nil)
	if err != nil {
		t.Errorf("RecordEvaluation() error: %v", err)
	}
}

// TestRecordEvaluation_OnlyMAE verifies single metric recording.
func TestRecordEvaluation_OnlyMAE(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	metrics := map[string]float64{
		"mae": 0.05,
	}
	err = client.RecordEvaluation(context.Background(), metrics, "validation", nil)
	if err != nil {
		t.Errorf("RecordEvaluation() error: %v", err)
	}
}

// TestNewClient_WithFilterSystemMetrics verifies metric filtering configuration.
func TestNewClient_WithFilterSystemMetrics(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName:         "test-service",
		ModelID:             "mdl-001",
		TeamName:            "test-team",
		TLSInsecure:         true,
		FilterSystemMetrics: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() with FilterSystemMetrics error: %v", err)
	}
	defer client.Shutdown()

	// Verify client was created successfully
	if client == nil {
		t.Error("NewClient() returned nil client with FilterSystemMetrics enabled")
	}
}

// TestConcurrentGoalTracking verifies thread safety with concurrent goal operations.
func TestConcurrentGoalTracking(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Start multiple goals concurrently
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			goalID, err := client.RecordGoalStarted(context.Background(), fmt.Sprintf("Goal %d", id), "test", nil)
			if err != nil {
				t.Errorf("RecordGoalStarted() error: %v", err)
				return
			}

			// Simulate some work
			time.Sleep(10 * time.Millisecond)

			err = client.RecordGoalCompleted(context.Background(), goalID, "success", nil)
			if err != nil {
				t.Errorf("RecordGoalCompleted() error: %v", err)
			}
		}(i)
	}

	wg.Wait()
}

// TestGetInstance_Success tests singleton pattern.
func TestGetInstance_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	// Reset singleton before test
	resetInstance()
	defer resetInstance()

	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client1, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client1.Shutdown()

	// GetInstance should return the same client
	client2, err := GetInstance()
	if err != nil {
		t.Fatalf("GetInstance() error: %v", err)
	}

	if client1 != client2 {
		t.Error("GetInstance() should return the same instance")
	}
}

// TestGetInstance_NotInitialized tests error when not initialized.
func TestGetInstance_NotInitialized(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	// Reset singleton before test
	resetInstance()
	defer resetInstance()

	client, err := GetInstance()
	if err != ErrInstanceNotInitialized {
		t.Errorf("GetInstance() error = %v, want %v", err, ErrInstanceNotInitialized)
	}
	if client != nil {
		t.Error("GetInstance() should return nil client when not initialized")
	}
}

// TestresetInstance tests singleton reset.
func TestresetInstance(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	// Reset singleton before test
	resetInstance()
	defer resetInstance()

	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Reset should clear the instance
	resetInstance()

	// GetInstance should return error
	_, err = GetInstance()
	if err != ErrInstanceNotInitialized {
		t.Errorf("GetInstance() after reset error = %v, want %v", err, ErrInstanceNotInitialized)
	}
}

// TestRecordRecovery_Success tests recovery tracking.
func TestRecordRecovery_Success(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	err = client.RecordRecovery(ctx, "network_error", 3, 5*time.Second)
	if err != nil {
		t.Errorf("RecordRecovery() error: %v", err)
	}
}

// TestRecordRecovery_ClosedClient tests error handling for closed client.
func TestRecordRecovery_ClosedClient(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}

	// Shutdown client
	if err := client.Shutdown(); err != nil {
		t.Fatalf("Shutdown() error: %v", err)
	}

	err = client.RecordRecovery(ctx, "network_error", 3, 5*time.Second)
	if err != ErrClientClosed {
		t.Errorf("RecordRecovery() error = %v, want %v", err, ErrClientClosed)
	}
}

// TestThresholds_Empty tests thresholds retrieval when empty.
func TestThresholds_Empty(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	thresholds := client.Thresholds()
	if len(thresholds) != 0 {
		t.Errorf("Thresholds() = %v, want empty map", thresholds)
	}
}

// TestRecordPrediction_InputOutputCapture tests input/output data capture.
func TestRecordPrediction_InputOutputCapture(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	cfg := &config.Config{
		ServiceName:       "test-service",
		ModelID:           "mdl-001",
		TeamName:          "test-team",
		TLSInsecure:       true,
		CaptureInputData:  true,
		CaptureOutputData: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	latency := 0.15
	pred := &Prediction{
		Latency:      &latency,
		PredictionID: "pred-123",
		InputData: map[string]interface{}{
			"feature1": 1.5,
			"feature2": "value",
		},
		OutputData: map[string]interface{}{
			"prediction": 0.85,
			"confidence": 0.92,
		},
	}

	err = client.RecordPrediction(ctx, pred)
	if err != nil {
		t.Errorf("RecordPrediction() error: %v", err)
	}
}

// TestThresholds_DeepCopy tests that nested maps in thresholds are deep copied.
func TestThresholds_DeepCopy(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	defer resetInstance()

	cfg := &config.Config{
		ServiceName: "test-service",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	client, err := NewClient(ctx, cfg)
	if err != nil {
		t.Fatalf("NewClient() error: %v", err)
	}
	defer client.Shutdown()

	// Manually set nested threshold for testing
	client.thresholdsMu.Lock()
	client.thresholds = map[string]interface{}{
		"simple_value": 100.0,
		"nested_config": map[string]interface{}{
			"key1": "value1",
			"key2": "value2",
		},
	}
	client.thresholdsMu.Unlock()

	// Get thresholds copy
	thresholds := client.Thresholds()

	// Modify the nested map in the copy
	if nested, ok := thresholds["nested_config"].(map[string]interface{}); ok {
		nested["key1"] = "modified"
		nested["new_key"] = "new_value"
	}

	// Verify original is unchanged (deep copy worked)
	originalThresholds := client.Thresholds()
	if nested, ok := originalThresholds["nested_config"].(map[string]interface{}); ok {
		if nested["key1"] != "value1" {
			t.Errorf("Deep copy failed: nested['key1'] = %v, want value1", nested["key1"])
		}
		if _, exists := nested["new_key"]; exists {
			t.Error("Deep copy failed: new_key should not exist in original")
		}
	} else {
		t.Error("nested_config not found or wrong type")
	}
}

// TestNewClient_StrictSingleton tests that NewClient returns singleton on subsequent calls.
func TestNewClient_StrictSingleton(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	defer resetInstance()

	cfg1 := &config.Config{
		ServiceName: "test-service-1",
		ModelID:     "mdl-001",
		TeamName:    "test-team-1",
		TLSInsecure: true,
	}

	cfg2 := &config.Config{
		ServiceName: "test-service-2", // Different config
		ModelID:     "mdl-002",
		TeamName:    "test-team-2",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// First call creates singleton
	client1, err := NewClient(ctx, cfg1)
	if err != nil {
		t.Fatalf("First NewClient() error: %v", err)
	}
	defer client1.Shutdown()

	// Verify it's stored as singleton
	instance1, err := GetInstance()
	if err != nil {
		t.Fatalf("GetInstance() error: %v", err)
	}
	if client1 != instance1 {
		t.Error("First client should be stored as singleton")
	}

	// Second call with different config should return same singleton
	client2, err := NewClient(ctx, cfg2)
	if err != nil {
		t.Fatalf("Second NewClient() error: %v", err)
	}

	// Verify client2 is the same as client1 (strict singleton)
	if client1 != client2 {
		t.Error("NewClient should return singleton on second call, got different instance")
	}

	// Verify GetInstance also returns the same
	instance2, err := GetInstance()
	if err != nil {
		t.Fatalf("GetInstance() after second call error: %v", err)
	}
	if client1 != instance2 {
		t.Error("GetInstance should still return original singleton")
	}

	// Verify the singleton has the FIRST config, not second
	if client2.config.ServiceName != "test-service-1" {
		t.Errorf("Singleton should have first config, ServiceName = %q, want test-service-1", 
			client2.config.ServiceName)
	}
}

// TestNewClient_AfterReset tests that resetInstance allows creating a new client.
func TestNewClient_AfterReset(t *testing.T) {
	defer resetInstance() // Reset singleton for test isolation
	defer resetInstance()

	cfg1 := &config.Config{
		ServiceName: "test-service-1",
		ModelID:     "mdl-001",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	cfg2 := &config.Config{
		ServiceName: "test-service-2",
		ModelID:     "mdl-002",
		TeamName:    "test-team",
		TLSInsecure: true,
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Create first client
	client1, err := NewClient(ctx, cfg1)
	if err != nil {
		t.Fatalf("First NewClient() error: %v", err)
	}
	if client1.config.ServiceName != "test-service-1" {
		t.Errorf("First client ServiceName = %q, want test-service-1", client1.config.ServiceName)
	}
	client1.Shutdown()

	// Reset singleton
	resetInstance()

	// Create second client with different config
	client2, err := NewClient(ctx, cfg2)
	if err != nil {
		t.Fatalf("Second NewClient() after reset error: %v", err)
	}
	defer client2.Shutdown()

	// Verify client2 is different from client1
	if client1 == client2 {
		t.Error("After reset, NewClient should create a new instance")
	}

	// Verify client2 has the new config
	if client2.config.ServiceName != "test-service-2" {
		t.Errorf("Second client ServiceName = %q, want test-service-2", client2.config.ServiceName)
	}
}
