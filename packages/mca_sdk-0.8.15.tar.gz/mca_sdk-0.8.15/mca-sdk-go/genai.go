// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

import (
	"context"
	"errors"
	"fmt"
	"time"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/trace"
)

// LLMRequest represents an LLM API request for tracking.
type LLMRequest struct {
	Model       string                 // Model name (e.g., "gpt-4", "claude-3-opus")
	Provider    string                 // Provider name (e.g., "openai", "anthropic")
	Prompt      string                 // Optional: Prompt text (sanitize PHI before passing)
	MaxTokens   int                    // Maximum tokens requested
	Temperature float64                // Temperature parameter
	Metadata    map[string]interface{} // Additional request metadata
}

// LLMResponse represents an LLM API response for tracking.
type LLMResponse struct {
	Model            string                 // Model name that handled the request
	PromptTokens     int                    // Number of tokens in prompt
	CompletionTokens int                    // Number of tokens in completion
	TotalTokens      int                    // Total tokens (prompt + completion)
	Cost             *float64               // Optional: Cost in dollars
	Latency          time.Duration          // Request latency
	Status           string                 // Status: "success", "error", "timeout"
	Completion       string                 // Optional: Completion text (sanitize PHI before passing)
	Metadata         map[string]interface{} // Additional response metadata
}

// EmbeddingRequest represents an embedding API request for tracking.
type EmbeddingRequest struct {
	Model    string                 // Model name (e.g., "text-embedding-ada-002")
	Provider string                 // Provider name (e.g., "openai", "cohere")
	Input    string                 // Input text for embedding (sanitize PHI before passing)
	Metadata map[string]interface{} // Additional request metadata
}

// EmbeddingResponse represents an embedding API response for tracking.
type EmbeddingResponse struct {
	Model       string                 // Model name that handled the request
	InputTokens int                    // Number of input tokens
	Dimensions  int                    // Embedding vector dimensions
	Cost        *float64               // Optional: Cost in dollars
	Latency     time.Duration          // Request latency
	Status      string                 // Status: "success", "error", "timeout"
	Metadata    map[string]interface{} // Additional response metadata
}

// TrackLLMCompletion records an LLM completion request/response with full observability.
//
// This method automatically records:
//   - Metrics: genai.requests_total, genai.tokens_total, genai.latency_seconds, genai.cost_dollars
//   - Trace span with request/response metadata
//   - Dimensions: model, provider, status, token_type (prompt/completion)
//
// IMPORTANT: Sanitize all PHI/PII from prompt/completion text before passing to this method.
// The SDK only masks technical credentials, not domain-specific sensitive data.
//
// Example:
//
//	request := &mca.LLMRequest{
//	    Model:    "gpt-4",
//	    Provider: "openai",
//	    MaxTokens: 1000,
//	}
//	cost := 0.03
//	response := &mca.LLMResponse{
//	    Model:            "gpt-4",
//	    PromptTokens:     150,
//	    CompletionTokens: 850,
//	    TotalTokens:      1000,
//	    Cost:             &cost,
//	    Latency:          2 * time.Second,
//	    Status:           "success",
//	}
//	err := client.TrackLLMCompletion(ctx, request, response)
func (c *Client) TrackLLMCompletion(ctx context.Context, request *LLMRequest, response *LLMResponse) error {
	if request == nil || response == nil {
		return errors.New("request and response cannot be nil")
	}
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Create trace span for LLM call
	ctx, span := c.tracer.Start(ctx, "llm.completion",
		trace.WithSpanKind(trace.SpanKindClient),
	)
	defer span.End()

	// Build attributes for metrics and spans
	attrs := []attribute.KeyValue{
		attribute.String("model", response.Model),
		attribute.String("provider", request.Provider),
		attribute.String("status", response.Status),
	}

	// Add request metadata to span
	if request.MaxTokens > 0 {
		span.SetAttributes(attribute.Int("request.max_tokens", request.MaxTokens))
	}
	if request.Temperature >= 0 {
		span.SetAttributes(attribute.Float64("request.temperature", request.Temperature))
	}
	if request.Prompt != "" {
		span.SetAttributes(attribute.String("request.prompt", request.Prompt))
	}
	if response.Completion != "" {
		span.SetAttributes(attribute.String("response.completion", response.Completion))
	}
	if request.Metadata != nil {
		for k, v := range request.Metadata {
			span.SetAttributes(attribute.String(fmt.Sprintf("request.metadata.%s", k), fmt.Sprintf("%v", v)))
		}
	}
	if response.Metadata != nil {
		for k, v := range response.Metadata {
			span.SetAttributes(attribute.String(fmt.Sprintf("response.metadata.%s", k), fmt.Sprintf("%v", v)))
		}
	}

	// Add response metadata to span
	span.SetAttributes(
		attribute.Int("response.prompt_tokens", response.PromptTokens),
		attribute.Int("response.completion_tokens", response.CompletionTokens),
		attribute.Int("response.total_tokens", response.TotalTokens),
		attribute.Float64("response.latency_seconds", response.Latency.Seconds()),
	)

	if response.Cost != nil {
		span.SetAttributes(attribute.Float64("response.cost_dollars", *response.Cost))
	}

	attrSet := attribute.NewSet(attrs...)

	// Record genai.requests_total counter
	c.genaiRequestsCounter.Add(ctx, 1, metric.WithAttributeSet(attrSet))

	// Record token counters with token_type dimension
	promptAttrs := append(attrs, attribute.String("token_type", "prompt"))
	if response.PromptTokens >= 0 {
		c.genaiTokensCounter.Add(ctx, int64(response.PromptTokens),
			metric.WithAttributes(promptAttrs...))
	}

	completionAttrs := append(attrs, attribute.String("token_type", "completion"))
	if response.CompletionTokens >= 0 {
		c.genaiTokensCounter.Add(ctx, int64(response.CompletionTokens),
			metric.WithAttributes(completionAttrs...))
	}

	// Record latency histogram
	c.genaiLatencyHistogram.Record(ctx, response.Latency.Seconds(),
		metric.WithAttributeSet(attrSet))

	// Record cost if provided
	if response.Cost != nil && *response.Cost >= 0 {
	        c.genaiCostCounter.Add(ctx, *response.Cost,
	                metric.WithAttributeSet(attrSet))
	}
	// Set span status
	if response.Status == "success" {
		span.SetStatus(codes.Ok, "LLM completion successful")
	} else {
		span.SetStatus(codes.Error, fmt.Sprintf("LLM completion status: %s", response.Status))
	}

	return nil
}

// TrackLLMEmbedding records an embedding request/response with full observability.
//
// This method automatically records:
//   - Metrics: genai.embedding.requests_total, genai.embedding.tokens_total, genai.embedding.latency_seconds
//   - Trace span with request/response metadata
//   - Dimensions: model, provider, status
//
// IMPORTANT: Sanitize all PHI/PII from input text before passing to this method.
//
// Example:
//
//	request := &mca.EmbeddingRequest{
//	    Model:    "text-embedding-ada-002",
//	    Provider: "openai",
//	    Input:    "sanitized input text",
//	}
//	cost := 0.0001
//	response := &mca.EmbeddingResponse{
//	    Model:       "text-embedding-ada-002",
//	    InputTokens: 50,
//	    Dimensions:  1536,
//	    Cost:        &cost,
//	    Latency:     200 * time.Millisecond,
//	    Status:      "success",
//	}
//	err := client.TrackLLMEmbedding(ctx, request, response)
func (c *Client) TrackLLMEmbedding(ctx context.Context, request *EmbeddingRequest, response *EmbeddingResponse) error {
	if request == nil || response == nil {
		return errors.New("request and response cannot be nil")
	}
	c.mu.RLock()
	defer c.mu.RUnlock()

	if c.isShutdown {
		return ErrClientClosed
	}

	// Create trace span for embedding call
	ctx, span := c.tracer.Start(ctx, "llm.embedding",
		trace.WithSpanKind(trace.SpanKindClient),
	)
	defer span.End()

	// Build attributes for metrics and spans
	attrs := []attribute.KeyValue{
		attribute.String("model", response.Model),
		attribute.String("provider", request.Provider),
		attribute.String("status", response.Status),
	}

	// Add response metadata to span
	span.SetAttributes(
		attribute.Int("response.input_tokens", response.InputTokens),
		attribute.Int("response.dimensions", response.Dimensions),
		attribute.Float64("response.latency_seconds", response.Latency.Seconds()),
	)
	if request.Input != "" {
		span.SetAttributes(attribute.String("request.input", request.Input))
	}
	if request.Metadata != nil {
		for k, v := range request.Metadata {
			span.SetAttributes(attribute.String(fmt.Sprintf("request.metadata.%s", k), fmt.Sprintf("%v", v)))
		}
	}
	if response.Metadata != nil {
		for k, v := range response.Metadata {
			span.SetAttributes(attribute.String(fmt.Sprintf("response.metadata.%s", k), fmt.Sprintf("%v", v)))
		}
	}

	if response.Cost != nil {
		span.SetAttributes(attribute.Float64("response.cost_dollars", *response.Cost))
	}

	attrSet := attribute.NewSet(attrs...)

	// Record genai.embedding.requests_total counter
	c.genaiEmbeddingRequestsCounter.Add(ctx, 1, metric.WithAttributeSet(attrSet))

	// Record embedding token counter
	if response.InputTokens >= 0 {
		c.genaiEmbeddingTokensCounter.Add(ctx, int64(response.InputTokens),
			metric.WithAttributeSet(attrSet))
	}

	// Record latency histogram
	c.genaiEmbeddingLatencyHistogram.Record(ctx, response.Latency.Seconds(),
		metric.WithAttributeSet(attrSet))

	// Set span status
	if response.Status == "success" {
		span.SetStatus(codes.Ok, "Embedding generation successful")
	} else {
		span.SetStatus(codes.Error, fmt.Sprintf("Embedding status: %s", response.Status))
	}

	return nil
}
