with open("mca-prototype/tests/test_basic_export.py", "r") as f:
    content = f.read()
if "if __name__ == '__main__':" not in content:
    content = content.replace(
        'print("Creating MCA client...")',
        "if __name__ == '__main__':\n    print(\"Creating MCA client...\")",
    )
    content = content.replace("client = MCAClient(", "    client = MCAClient(")
    lines = content.split("\n")
    for i in range(len(lines)):
        if (
            "    client = MCAClient(" in lines[i]
            or "if __name__ == '__main__':" in lines[i]
            or '    print("Creating' in lines[i]
        ):
            continue
        if i > lines.index("    client = MCAClient("):
            if lines[i] and not lines[i].startswith(" ") and not lines[i].startswith("#"):
                lines[i] = "    " + lines[i]
    with open("mca-prototype/tests/test_basic_export.py", "w") as f:
        f.write("\n".join(lines))
