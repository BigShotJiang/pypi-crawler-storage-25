import pytest
from mca_sdk.validation.rules import get_validation_rules


def test_get_validation_rules_internal_regression():
    rules = get_validation_rules("internal", "regression")
    assert "service.name" in rules["required"]
    assert "model.id" in rules["required"]
    assert "service.version" in rules["optional"]


def test_get_validation_rules_internal_generative():
    rules = get_validation_rules("internal", "generative")
    assert "llm.provider" in rules["required"]
    assert "model.id" in rules["optional"]


def test_get_validation_rules_vendor_any_type():
    rules = get_validation_rules("vendor", "regression")
    assert "vendor.name" in rules["required"]

    rules2 = get_validation_rules("VENDOR", "generative")
    assert "vendor.name" in rules2["required"]


def test_get_validation_rules_invalid():
    with pytest.raises(ValueError, match="No validation rules for"):
        get_validation_rules("internal", "unknown-type")
