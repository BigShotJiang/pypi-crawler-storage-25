import pytest
from mca_sdk.utils.phi_utils import extract_phi_field_names, get_phi_field_criticality


def test_phi_utils_coverage():
    assert extract_phi_field_names({}) == []
    assert extract_phi_field_names([]) == []
    assert extract_phi_field_names({"patient_id": {"criticality": "yes"}}) == ["patient_id"]

    assert get_phi_field_criticality(None, "foo") == "unknown"
    assert get_phi_field_criticality({}, "foo") == "unknown"
    assert get_phi_field_criticality({"foo": {"criticality": "high"}}, "foo") == "high"
    assert get_phi_field_criticality({"foo": "not_a_dict"}, "foo") == "unknown"


def test_phi_fields_not_dict_logs_warning(caplog):
    assert extract_phi_field_names("not a dict") == []
    assert "phi_fields is not a dict" in caplog.text
