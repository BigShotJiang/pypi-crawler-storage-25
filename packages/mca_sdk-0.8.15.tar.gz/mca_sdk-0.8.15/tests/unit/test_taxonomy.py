"""Tests for two-field taxonomy implementation (Story 2.4).

Tests the integration of model_category + model_type across the SDK.
"""

import pytest
from mca_sdk.config import MCAConfig
from mca_sdk.utils.routing import get_metric_prefix
from mca_sdk.validation import validate_resource_attributes


class TestTaxonomyIntegration:
    """Integration tests for two-field taxonomy system."""

    def test_config_with_new_taxonomy(self):
        """MCAConfig should accept and validate new taxonomy fields."""
        config = MCAConfig(
            service_name="test-service",
            model_category="internal",
            model_type="regression",
        )
        assert config.model_category == "internal"
        assert config.model_type == "regression"

    def test_config_backward_compatibility_internal(self):
        """Legacy model_type='internal' should auto-migrate."""
        with pytest.warns(DeprecationWarning):
            config = MCAConfig(service_name="test-service", model_type="internal")  # Legacy value
        assert config.model_category == "internal"
        assert config.model_type == "regression"  # Migrated

    def test_config_generative_is_valid_new_type(self):
        """model_type='generative' is valid in new taxonomy (doesn't auto-migrate)."""
        # No deprecation warning - generative is a valid model_type
        config = MCAConfig(
            service_name="test-service",
            model_category="internal",
            model_type="generative",
        )
        assert config.model_category == "internal"
        assert config.model_type == "generative"

    def test_config_backward_compatibility_vendor(self):
        """Legacy model_type='vendor' should auto-migrate."""
        with pytest.warns(DeprecationWarning):
            config = MCAConfig(service_name="test-service", model_type="vendor")  # Legacy value
        assert config.model_category == "vendor"
        assert config.model_type == "regression"  # Default

    def test_routing_internal_regression_to_model(self):
        """Internal regression models should route to model.* metrics."""
        prefix = get_metric_prefix("internal", "regression")
        assert prefix == "model"

    def test_routing_internal_generative_to_genai(self):
        """Internal generative models should route to genai.* metrics."""
        prefix = get_metric_prefix("internal", "generative")
        assert prefix == "genai"

    def test_routing_vendor_always_vendor(self):
        """Vendor models should always route to vendor.* regardless of type."""
        assert get_metric_prefix("vendor", "regression") == "vendor"
        assert get_metric_prefix("vendor", "generative") == "vendor"
        assert get_metric_prefix("vendor", "agentic") == "vendor"

    def test_validation_uses_taxonomy_for_prefix(self):
        """Attribute validation should use routing to determine requirements."""
        # Internal regression → model.* → requires model.id, model.version, team.name
        attrs = {
            "service.name": "test",
            "model.id": "mdl-001",
            "model.version": "1.0",
            "team.name": "team",
        }
        # Should not raise
        validate_resource_attributes(attrs, "internal", "regression", strict=True)

    def test_validation_genai_requires_llm_fields(self):
        """GenAI models should require llm.provider and llm.model."""
        attrs = {
            "service.name": "test",
            "llm.provider": "openai",
            "llm.model": "gpt-4",
            "team.name": "team",
        }
        # Should not raise
        validate_resource_attributes(attrs, "internal", "generative", strict=True)

    def test_all_taxonomy_combinations_valid(self):
        """All 10 valid taxonomy combinations should work."""
        combinations = [
            ("internal", "regression"),
            ("internal", "time-series"),
            ("internal", "classification"),
            ("internal", "generative"),
            ("internal", "agentic"),
            ("vendor", "regression"),
            ("vendor", "time-series"),
            ("vendor", "classification"),
            ("vendor", "generative"),
            ("vendor", "agentic"),
        ]

        for category, type_ in combinations:
            config = MCAConfig(service_name="test", model_category=category, model_type=type_)
            assert config.model_category == category
            assert config.model_type == type_
