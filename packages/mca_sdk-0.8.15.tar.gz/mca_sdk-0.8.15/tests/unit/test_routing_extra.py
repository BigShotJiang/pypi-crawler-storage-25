import pytest
from mca_sdk.utils.routing import get_metric_prefix, migrate_legacy_model_type


def test_get_metric_prefix_valid():
    assert get_metric_prefix("internal", "regression") == "model"
    assert get_metric_prefix("internal", "time-series") == "model"
    assert get_metric_prefix("internal", "classification") == "model"
    assert get_metric_prefix("internal", "generative") == "genai"
    assert get_metric_prefix("internal", "agentic") == "agentic"

    assert get_metric_prefix("vendor", "regression") == "vendor"
    assert get_metric_prefix("vendor", "time-series") == "vendor"
    assert get_metric_prefix("vendor", "classification") == "vendor"
    assert get_metric_prefix("vendor", "generative") == "vendor"
    assert get_metric_prefix("vendor", "agentic") == "vendor"


def test_get_metric_prefix_invalid():
    with pytest.raises(ValueError, match="Invalid model taxonomy combination"):
        get_metric_prefix("internal", "unknown")

    with pytest.raises(ValueError, match="Invalid model taxonomy combination"):
        get_metric_prefix("unknown", "regression")


def test_migrate_legacy_model_type():
    assert migrate_legacy_model_type("internal") == ("internal", "regression")
    assert migrate_legacy_model_type("generative") == ("internal", "generative")
    assert migrate_legacy_model_type("vendor") == ("vendor", "regression")

    with pytest.raises(ValueError, match="Invalid legacy model_type"):
        migrate_legacy_model_type("unknown")
