"""Final tests to reach 85%% coverage target.

Tests for small utility modules with 1-4 missing statements each.
"""

import pytest
from unittest.mock import Mock, MagicMock

from mca_sdk.registry.telemetry import RegistryTelemetry


class TestRegistryTelemetry:
    """Test RegistryTelemetry for registry operations."""

    def test_record_success(self):
        """Test recording successful registry operation."""
        mock_meter = Mock()
        mock_counter = Mock()
        mock_histogram = Mock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(mock_meter)
        telemetry.record_success(latency=0.125)

        mock_counter.add.assert_called_with(1)
        mock_histogram.record.assert_called_once_with(0.125)

    def test_record_error(self):
        """Test recording registry error."""
        mock_meter = Mock()
        mock_counter = Mock()
        mock_histogram = Mock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(mock_meter)
        telemetry.record_error("ConfigNotFoundError")

        mock_counter.add.assert_called_with(1, {"error_type": "ConfigNotFoundError"})

    def test_record_error_propagates_type(self):
        """Test that error type is correctly propagated."""
        mock_meter = Mock()
        mock_counter = Mock()
        mock_histogram = Mock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(mock_meter)
        telemetry.record_error("RegistryConnectionError")

        call_args = mock_counter.add.call_args
        assert call_args[0][0] == 1
        assert "RegistryConnectionError" in str(call_args[0][1].get("error_type", ""))

    def test_default_meter_used_when_none(self):
        """Test RegistryTelemetry uses default meter when none provided."""
        telemetry = RegistryTelemetry()
        assert telemetry._meter is not None
