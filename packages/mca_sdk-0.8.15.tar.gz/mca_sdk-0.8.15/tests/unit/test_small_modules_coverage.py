"""Unit tests for small modules to reach 85% coverage target.

Tests ValidationResult, retry logic, registry models, and other small utility modules.
"""

import pytest
from unittest.mock import Mock, patch

from mca_sdk.validation.result import ValidationResult
from mca_sdk.registry.models import ModelConfig, DeploymentConfig
from mca_sdk.buffering.retry import RetryPolicy
from mca_sdk.validation.validator import AttributeValidator
from mca_sdk.utils.serialization import serialize_for_telemetry


class TestValidationResult:
    """Test ValidationResult dataclass."""

    def test_valid_result_creation(self):
        """Test creating a valid ValidationResult."""
        result = ValidationResult(is_valid=True)

        assert result.is_valid is True
        assert result.missing_fields == []
        assert result.errors == []

    def test_invalid_result_with_errors(self):
        """Test creating invalid ValidationResult with errors."""
        result = ValidationResult(
            is_valid=False, missing_fields=["field1"], errors=["field1 is required"]
        )

        assert result.is_valid is False
        assert "field1" in result.missing_fields
        assert len(result.errors) == 1

    def test_invalid_result_raises_error_on_inconsistent_state(self):
        """Test that ValidationResult raises error for inconsistent state."""
        # is_valid=True but has errors should raise ValueError
        with pytest.raises(ValueError, match="cannot have missing_fields or errors"):
            ValidationResult(is_valid=True, missing_fields=["field1"], errors=["error"])

    def test_str_representation_valid(self):
        """Test string representation for valid result."""
        result = ValidationResult(is_valid=True)

        assert str(result) == "Validation passed"

    def test_str_representation_invalid(self):
        """Test string representation for invalid result."""
        result = ValidationResult(is_valid=False, errors=["error1", "error2"])

        assert "Validation failed" in str(result)
        assert "error1" in str(result)


class TestRegistryModels:
    """Test registry model dataclasses."""

    def test_model_config_creation(self):
        """Test creating ModelConfig."""
        config = ModelConfig(
            service_name="test-service",
            model_id="mdl-001",
            model_version="1.0.0",
            team_name="test-team",
            model_category="internal",
            model_type="regression",
        )

        assert config.service_name == "test-service"
        assert config.model_id == "mdl-001"

    def test_deployment_config_creation(self):
        """Test creating DeploymentConfig."""
        config = DeploymentConfig(
            deployment_id="dep-001",
            environment="production",
            region="us-east-1",
            resource_overrides={},
        )

        assert config.deployment_id == "dep-001"
        assert config.environment == "production"
        assert config.region == "us-east-1"

    def test_deployment_config_with_overrides(self):
        """Test DeploymentConfig with resource overrides."""
        overrides = {"cpu": "2", "memory": "4Gi"}
        config = DeploymentConfig(
            deployment_id="dep-001",
            environment="staging",
            region="us-west-1",
            resource_overrides=overrides,
        )

        assert config.resource_overrides == overrides
