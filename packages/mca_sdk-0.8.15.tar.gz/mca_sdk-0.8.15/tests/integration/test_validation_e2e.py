"""End-to-end validation tests with MCAClient initialization.

This module tests attribute validation integration with MCAClient,
ensuring that validation rules are properly enforced during client
initialization for all model types and validation modes.
"""

import pytest
from mca_sdk.core.client import MCAClient
from mca_sdk.validation import ValidationError

# Suppress ProviderAlreadySetWarning - expected when creating multiple MCAClient instances in tests
pytestmark = pytest.mark.filterwarnings("ignore:.*Provider.*already set.*:UserWarning")


class TestValidationE2E:
    """End-to-end validation tests with MCAClient initialization."""

    # Internal regression - valid config (AC #4)
    def test_internal_regression_valid_config(self):
        """Valid internal regression config → initialization succeeds."""
        client = MCAClient(
            service_name="test-service",
            model_category="internal",
            model_type="regression",
            model_id="model-123",
            model_version="1.0.0",
            team_name="test-team",
            strict_validation=True,
        )
        assert client is not None
        assert client.config.model_id == "model-123"
        client.shutdown()

    # Internal regression - missing model.id strict mode (AC #1)
    def test_internal_regression_missing_model_id_strict(self):
        """Missing model.id with strict=True → raises ValidationError."""
        with pytest.raises(ValidationError) as excinfo:
            MCAClient(
                service_name="test-service",
                model_category="internal",
                model_type="regression",
                model_id=None,  # Missing
                model_version="1.0.0",
                team_name="test-team",
                strict_validation=True,
            )
        assert "model.id" in str(excinfo.value)
        assert "model.id" in excinfo.value.missing_fields
        assert excinfo.value.model_type == "regression"
        assert excinfo.value.model_category == "internal"

    # Internal regression - missing model.id permissive mode (AC #4)
    def test_internal_regression_missing_model_id_permissive(self, caplog):
        """Missing model.id with strict=False → logs warning, continues."""
        client = MCAClient(
            service_name="test-service",
            model_category="internal",
            model_type="regression",
            model_id=None,  # Missing
            model_version="1.0.0",
            team_name="test-team",
            strict_validation=False,
        )
        assert client is not None
        assert "validation warnings" in caplog.text.lower()
        client.shutdown()

    # Generative - valid config (AC #4)
    def test_generative_valid_config(self):
        """Valid generative config → initialization succeeds."""
        client = MCAClient(
            service_name="test-service",
            model_category="internal",
            model_type="generative",
            llm_provider="openai",
            llm_model="gpt-4",
            team_name="test-team",
            strict_validation=True,
        )
        assert client is not None
        assert client.config.llm_provider == "openai"
        client.shutdown()

    # Generative - missing llm.provider strict mode (AC #2)
    def test_generative_missing_llm_provider_strict(self):
        """Missing llm.provider with strict=True → raises ValidationError."""
        with pytest.raises(ValidationError) as excinfo:
            MCAClient(
                service_name="test-service",
                model_category="internal",
                model_type="generative",
                llm_provider=None,  # Missing
                llm_model="gpt-4",
                team_name="test-team",
                strict_validation=True,
            )
        assert "llm.provider" in str(excinfo.value)
        assert "llm.provider" in excinfo.value.missing_fields
        assert excinfo.value.model_type == "generative"
        assert excinfo.value.model_category == "internal"

    # Generative - missing llm.provider permissive mode (AC #4)
    def test_generative_missing_llm_provider_permissive(self, caplog):
        """Missing llm.provider with strict=False → logs warning, continues."""
        client = MCAClient(
            service_name="test-service",
            model_category="internal",
            model_type="generative",
            llm_provider=None,  # Missing
            llm_model="gpt-4",
            team_name="test-team",
            strict_validation=False,
        )
        assert client is not None
        assert "validation warnings" in caplog.text.lower()
        client.shutdown()

    # Vendor - valid config (AC #4)
    def test_vendor_valid_config(self):
        """Valid vendor config → initialization succeeds."""
        client = MCAClient(
            service_name="test-service",
            model_category="vendor",
            model_type="classification",
            vendor_name="epic",
            team_name="test-team",
            strict_validation=True,
        )
        assert client is not None
        assert client.config.vendor_name == "epic"
        client.shutdown()

    # Vendor - missing vendor.name strict mode (AC #3)
    def test_vendor_missing_vendor_name_strict(self):
        """Missing vendor.name with strict=True → raises ValidationError."""
        with pytest.raises(ValidationError) as excinfo:
            MCAClient(
                service_name="test-service",
                model_category="vendor",
                model_type="classification",
                vendor_name=None,  # Missing
                team_name="test-team",
                strict_validation=True,
            )
        assert "vendor.name" in str(excinfo.value)
        assert "vendor.name" in excinfo.value.missing_fields
        assert excinfo.value.model_type == "classification"
        assert excinfo.value.model_category == "vendor"

    # Vendor - missing vendor.name permissive mode (AC #4)
    def test_vendor_missing_vendor_name_permissive(self, caplog):
        """Missing vendor.name with strict=False → logs warning, continues."""
        client = MCAClient(
            service_name="test-service",
            model_category="vendor",
            model_type="classification",
            vendor_name=None,  # Missing
            team_name="test-team",
            strict_validation=False,
        )
        assert client is not None
        assert "validation warnings" in caplog.text.lower()
        client.shutdown()
