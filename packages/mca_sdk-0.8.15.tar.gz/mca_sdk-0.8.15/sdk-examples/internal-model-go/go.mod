module github.com/baptisthealth/mca-sdk-examples/internal-model-go

go 1.21

require github.com/baptisthealth/mca-sdk-go v0.4.0

replace github.com/baptisthealth/mca-sdk-go => ../../mca-sdk-go
