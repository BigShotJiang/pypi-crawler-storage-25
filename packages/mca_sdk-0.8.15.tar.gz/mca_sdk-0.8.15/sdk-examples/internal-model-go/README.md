# Internal Model Example (Go)

This example demonstrates MCA SDK usage for internal ML models in Go.

## Prerequisites

- Go 1.21+
- Docker and Docker Compose (for OTel Collector)

## Setup

1. Start the OpenTelemetry Collector:

```bash
cd ../../
docker-compose up -d otel-collector
```

2. Install dependencies:

```bash
go mod tidy
```

## Run

```bash
go run main.go
```

## What This Example Demonstrates

1. **Client initialization** - Creating MCA client with configuration
2. **Single prediction** - Recording individual predictions
3. **Sequential predictions** - Recording multiple predictions in sequence
4. **Concurrent predictions** - Goroutine-safe concurrent recording
5. **Context propagation** - Using context.Context with timeout
6. **Graceful shutdown** - Using defer pattern for cleanup

## Expected Output

```
Initializing MCA SDK client...
MCA SDK client initialized successfully

=== Example 1: Single Prediction ===
Recorded prediction: ID=pred-123456789, Latency=0.105s

=== Example 2: Multiple Sequential Predictions ===
Recorded prediction 1/5: ID=pred-123456790, Latency=0.087s
...

=== Example 3: Concurrent Predictions ===
Completed 50 concurrent predictions in 0.25s (200 predictions/sec)

=== Example 4: Prediction with Context Timeout ===
Recorded prediction with context: ID=pred-123456840, Latency=0.112s

=== All Examples Completed ===
Telemetry data has been sent to OTel Collector at http://localhost:4318
```

## Verify Telemetry

Check that metrics and logs are being exported:

```bash
# View collector logs
docker-compose logs otel-collector

# View metrics via GMP/Cloud Monitoring (if configured)
curl http://localhost:8889/metrics  # Prometheus exporter endpoint
```

## Code Patterns

### Error Handling
```go
client, err := mca.NewClient(cfg)
if err != nil {
    return fmt.Errorf("failed to create client: %w", err)
}
```

### Defer Cleanup
```go
defer client.Shutdown()
```

### Context Usage
```go
ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
defer cancel()
err := client.RecordPrediction(ctx, pred)
```

### Goroutine Safety
```go
var wg sync.WaitGroup
for i := 0; i < 10; i++ {
    wg.Add(1)
    go func(id int) {
        defer wg.Done()
        client.RecordPrediction(ctx, pred)
    }(i)
}
wg.Wait()
```
