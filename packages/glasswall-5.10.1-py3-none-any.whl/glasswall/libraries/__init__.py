

# Note, `dependencies` refers to the dependencies required to call
# ctypes.cdll.LoadLibrary on CentOS7 / Windows 10 and may not be indicative
# of the full dependencies for all functionality within a library.

os_info = {
    "Linux": {
        "archive_manager": {
            "file_name": "libglasswall.archive.manager.so",
            "dependencies": [],
            "relies_on": ["editor"],
        },
        "editor": {
            "file_name": "libglasswall_core2.so",
            "dependencies": [],
        },
        "editor_cli": {
            "file_name": "gwcli",
            "dependencies": [],
            "relies_on": ["editor"],
        },
        "rebuild": {
            "file_name": "libglasswall.classic.so",
            "dependencies": [],
        },
        "word_search": {
            "file_name": "libglasswall.word.search.so",
            # loading dependencies through ctypes doesn't help for word search, use LD_LIBRARY_PATH
            "dependencies": [],
            "relies_on": ["editor"],
        },
    },

    "Windows": {
        "archive_manager": {
            "file_name": "glasswall.archive.manager.dll",
            "dependencies": [],
            "relies_on": ["editor"],
        },
        "editor": {
            "file_name": "glasswall_core2.dll",
            "dependencies": [
                "Qt5Core.dll",
                "Qt5Xml.dll"
            ],
        },
        "editor_cli": {
            "file_name": "gwcli.exe",
            "dependencies": [],
            "relies_on": ["editor"],
        },
        "rebuild": {
            "file_name": "glasswall.classic.dll",
            "dependencies": [],
        },
        "word_search": {
            "file_name": "glasswall.word.search.dll",
            "dependencies": [],
            "relies_on": ["editor"],
        },
    },
}
