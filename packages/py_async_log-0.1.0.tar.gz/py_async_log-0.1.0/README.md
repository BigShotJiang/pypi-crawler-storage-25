## 1. python创建使用虚拟环境

```bash
# 创建虚拟环境（名字叫.venv）
python -m venv .venv

# 允许执行脚本
Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

# 激活虚拟环境
.\.venv\Scripts\activate

# 退出虚拟环境
deactivate

```

## 2. 整理项目结构

```text
py-async-log/               # 根目录：项目名称
├── LICENSE                 # 开源协议
├── README.md               # 项目说明文档
├── pyproject.toml          # 核心打包配置
├── src/
│   └── py_async_log/       # 包名：代码导入名 (注意下划线)
│       ├── __init__.py     # 暴露接口，定义 __all__
│       └── core.py         # 存放 AsyncLogManager 核心逻辑
└── tests/
    ├── __init__.py
    └── test_logger.py      # 测试用例
```

---

## 3. 封装你的代码
在 `src/multilogger/__init__.py` 中，你可以把复杂的初始化逻辑封装成一个简单的类或函数，方便别人调用：

```python
# src/multilogger/__init__.py
from .core import setup_multiprocess_logging

__all__ = ["setup_multiprocess_logging"]
```

用户安装后只需要执行：
```python
from multilogger import setup_multiprocess_logging
# 一键初始化...
```

---

## 4. 构建与上传

### A. 安装必要工具
你需要 `build`（负责打包）和 `twine`（负责上传）。
```bash
pip install --upgrade build twine
```

### B. 构建分发包
在项目根目录下运行：
```bash
python3 -m build
```
执行完后，你会看到生成了一个 `dist/` 文件夹，里面包含了 `.tar.gz` (源码包) 和 `.whl` (二进制包)。

### C. 上传到 TestPyPI (推荐先测试)
为了防止直接传到正式版搞砸，先传到测试服务器：
```bash
python3 -m twine upload --repository testpypi dist/*
```
*注：你需要去 [TestPyPI](https://testpypi.python.org/) 注册账号并生成 API Token。*

### D. 正式发布到 PyPI
确认无误后，发布到全世界都能用的正式版：
```bash
python3 -m twine upload dist/*
```
*注：你需要去 [PyPI 官网](https://pypi.org/) 注册账号。*

---

## 5. 持续集成（进阶提示）
如果你希望以后只要一推代码到 GitHub 就自动发布新版本，可以利用 **GitHub Actions**。



1. 在 GitHub 项目中新建 `.github/workflows/publish.yml`。
2. 配置当检测到新的 `tag` 时，自动运行 `build` 和 `twine`。

### 小贴士
* **包名冲突**：PyPI 不允许重名，上传前先去官网搜一下你的 `name` 是否已被占用。
* **API Token**：现在 PyPI 强制要求使用 Token。上传时，用户名填 `__token__`，密码填你生成的 `pypi-xxx` 字符串。
* **.gitignore**：记得把 `dist/`, `build/`, `*.egg-info` 加入忽略列表，不要把编译产物推送到 Git。

你想好你的三方包叫什么名字了吗？我可以帮你优化一下 `__init__.py` 的导出逻辑。

3. 用户使用示例

```python
from py_async_log import AsyncLogManager
from concurrent.futures import ProcessPoolExecutor
import logging

def my_task(config_fn):
    config_fn() # 子进程初始化日志
    logger = logging.getLogger(__name__)
    logger.info("来自子进程的异步日志")

if __name__ == "__main__":
    # 1. 初始化
    log_mgr = AsyncLogManager("app.log")
    log_mgr.start_logging()

    # 2. 获取配置函数传给子进程
    worker_init = log_mgr.get_worker_configurer()

    with ProcessPoolExecutor(max_workers=2) as executor:
        executor.submit(my_task, worker_init)

    # 3. 停止
    log_mgr.stop_logging()

```

构建并上传：

```bash

# 1. 构建
python -m build
# 2. 上传（需要 PyPI 账号生成的 API Token）
python -m twine upload dist/*

```