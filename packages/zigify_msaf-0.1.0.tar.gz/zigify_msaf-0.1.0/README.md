# zigify-msaf

Music structural segmentation for the [Zigify](https://github.com/tobiasstrebitzer/zigify) pipeline. A thin CLI wrapper around [MSAF](https://github.com/urinieto/msaf) that pins to the `olda` boundary detector and `scluster` labeler — the combination that scored best in evaluation against hand-annotated ground truth.

## Install

```sh
uvx zigify-msaf <audio>          # ephemeral, recommended
uv pip install zigify-msaf       # into a project
```

`uvx` resolves and caches a dedicated environment on first run; subsequent calls cold-start in ~100 ms.

## Use

```sh
zigify-msaf path/to/track.mp3
zigify-msaf track.mp3 --out track.segments.json
zigify-msaf track.mp3 --feature mfcc --verbose
```

stdout is **newline-delimited JSON**: progress events first, then a single final result line. stderr carries human-readable logs from msaf/librosa (silenced by default; pass `--verbose` to surface them).

### Output schema

Each line on stdout is one JSON object. The shape of the final `result` line:

```json
{
  "type": "result",
  "source": "path/to/track.mp3",
  "duration": 357.98,
  "tempo": 117.45,
  "feature": "pcp",
  "boundaryAlgo": "olda",
  "labelAlgo": "scluster",
  "nSegments": 12,
  "nClusters": 5,
  "segments": [
    { "start": 0.0,   "end": 18.1, "duration": 18.1, "cluster": "S4" },
    { "start": 18.1,  "end": 38.5, "duration": 20.4, "cluster": "S2" }
  ],
  "elapsed": 12.3
}
```

Earlier lines look like:

```jsonl
{"type":"stage","name":"loading","message":"reading track.mp3"}
{"type":"stage","name":"tempo","message":"estimating bpm"}
{"type":"stage","name":"features","message":"extracting pcp"}
{"type":"stage","name":"boundaries","message":"olda"}
{"type":"stage","name":"labels","message":"scluster"}
```

On failure the tool emits a single `{"type": "error", ...}` line and exits non-zero.

### Calling from Node / TypeScript

```ts
import { spawn } from 'node:child_process'
import { createInterface } from 'node:readline'

const proc = spawn('uvx', ['zigify-msaf', audioPath], { stdio: ['ignore', 'pipe', 'pipe'] })
const rl = createInterface({ input: proc.stdout })

let result: SegmentResult | undefined
for await (const line of rl) {
  const evt = JSON.parse(line)
  if (evt.type === 'stage') console.log(`[${evt.name}] ${evt.message ?? ''}`)
  if (evt.type === 'result') result = evt
  if (evt.type === 'error') throw new Error(evt.message)
}
```

## Algorithm choice

Evaluated against a 14-boundary ground truth on Michael Jackson — *Thriller* (tolerance ±5 s):

| Boundary algo | Hits | Miss | Spurious |
| ------------- | ---- | ---- | -------- |
| **olda**      | **9**| 4    | **2**    |
| foote         | 9    | 4    | 6        |
| sf (default)  | 6    | 7    | 5        |
| cnmf          | 5    | 8    | 2        |
| scluster      | 4    | 9    | 10       |
| vmo           | 12   | 1    | 457      |

`olda` wins precision and ties for recall. Scluster labels group the segments into ~5 clusters that align with verse/chorus/outro structure on test tracks.

## License

MIT — see `LICENSE`.
