from zigify_msaf.cli import main

raise SystemExit(main())
