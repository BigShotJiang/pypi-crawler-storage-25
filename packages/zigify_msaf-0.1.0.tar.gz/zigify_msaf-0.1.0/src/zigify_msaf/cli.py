"""zigify-msaf CLI: MSAF olda boundaries + scluster labels.

stdout: newline-delimited JSON. Progress events first, then a single final
`{"type":"result", ...}` line. Consumers should parse line-by-line.
stderr: human-readable logs from msaf/librosa (suppress in production, show
on --verbose).

Usage:
    zigify-msaf <audio> [--out <path>] [--feature pcp|mfcc|cqt|tonnetz|tempogram] [--verbose]
"""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import sys
import time
from typing import Any


# scipy compat shims must run before importing msaf (its eager imports break otherwise).
def _apply_scipy_shims() -> None:
    import scipy
    import scipy.signal
    import scipy.signal.windows
    import numpy as np
    if not hasattr(scipy, 'inf'):  # scipy>=1.12 dropped scipy.inf; pymf still imports it
        scipy.inf = np.inf
    if not hasattr(scipy.signal, 'gaussian'):  # scipy>=1.11 moved gaussian into windows
        scipy.signal.gaussian = scipy.signal.windows.gaussian


def emit(event: dict[str, Any]) -> None:
    """Write one JSON object as a single line to stdout."""
    sys.stdout.write(json.dumps(event, separators=(',', ':')) + '\n')
    sys.stdout.flush()


def stage(name: str, message: str | None = None) -> None:
    evt: dict[str, Any] = {'type': 'stage', 'name': name}
    if message: evt['message'] = message
    emit(evt)


@contextlib.contextmanager
def maybe_silence(verbose: bool):
    """Redirect stdout/stderr from third-party libraries unless --verbose.

    msaf/librosa write progress to both streams. We need stdout strictly for our
    JSONL protocol, so capture and redirect their output to stderr (or drop it).
    """
    if verbose:
        yield
        return
    # Capture third-party stdout into stderr so it doesn't poison our JSONL.
    real_stdout = sys.stdout
    sink = io.StringIO()
    sys.stdout = sink
    try:
        yield
    finally:
        sys.stdout = real_stdout
        captured = sink.getvalue()
        if captured:
            sys.stderr.write(captured)
            sys.stderr.flush()


def segment(audio_path: str, feature: str, verbose: bool) -> dict[str, Any]:
    stage('loading', f'reading {os.path.basename(audio_path)}')
    # librosa import is deferred so the scipy shim takes effect first.
    import librosa
    import msaf
    import soundfile as sf

    info = sf.info(audio_path)
    duration = info.frames / float(info.samplerate)

    stage('tempo', 'estimating bpm')
    y, sr = librosa.load(audio_path, sr=22050, mono=True)
    tempo_arr, _ = librosa.beat.beat_track(y=y, sr=sr, trim=False)
    import numpy as np
    tempo = float(np.atleast_1d(tempo_arr)[0])

    stage('features', f'extracting {feature}')
    stage('boundaries', 'olda')
    stage('labels', 'scluster')
    with maybe_silence(verbose):
        boundaries, labels = msaf.process(
            audio_path,
            feature=feature,
            boundaries_id='olda',
            labels_id='scluster',
        )

    boundaries = [float(b) for b in boundaries]
    labels = [int(l) for l in labels]

    segments = []
    for i in range(len(boundaries) - 1):
        s, e = boundaries[i], boundaries[i + 1]
        if e <= s: continue
        cluster = labels[i] if i < len(labels) else -1
        segments.append({
            'start': round(s, 3),
            'end': round(e, 3),
            'duration': round(e - s, 3),
            'cluster': f'S{cluster}',
        })

    n_clusters = len({s['cluster'] for s in segments})
    return {
        'type': 'result',
        'source': audio_path,
        'duration': round(duration, 3),
        'tempo': round(tempo, 2),
        'feature': feature,
        'boundaryAlgo': 'olda',
        'labelAlgo': 'scluster',
        'nSegments': len(segments),
        'nClusters': n_clusters,
        'segments': segments,
    }


def main() -> int:
    ap = argparse.ArgumentParser(prog='zigify-msaf', description=__doc__.split('\n')[0])
    ap.add_argument('audio', help='path to audio file (mp3, wav, flac, ...)')
    ap.add_argument('-o', '--out', default=None,
                    help='write final result JSON to this path (in addition to stdout)')
    ap.add_argument('--feature', default='pcp',
                    choices=['pcp', 'mfcc', 'cqt', 'tonnetz', 'tempogram'],
                    help='spectral feature for boundary detection (default: pcp)')
    ap.add_argument('-v', '--verbose', action='store_true',
                    help='let msaf/librosa write to stderr (otherwise captured)')
    args = ap.parse_args()

    if not os.path.isfile(args.audio):
        emit({'type': 'error', 'message': f'audio file not found: {args.audio}'})
        return 2

    _apply_scipy_shims()

    t0 = time.time()
    try:
        result = segment(args.audio, feature=args.feature, verbose=args.verbose)
    except Exception as exc:  # noqa: BLE001 — we want to report any failure as JSON
        emit({
            'type': 'error',
            'errorClass': type(exc).__name__,
            'message': str(exc),
        })
        return 1

    result['elapsed'] = round(time.time() - t0, 2)
    emit(result)

    if args.out:
        with open(args.out, 'w') as f:
            json.dump(result, f, indent=2)

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
