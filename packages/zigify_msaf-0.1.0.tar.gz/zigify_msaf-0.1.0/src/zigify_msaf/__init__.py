"""zigify-msaf: structural music segmentation via MSAF (olda + scluster)."""
__version__ = "0.1.0"
