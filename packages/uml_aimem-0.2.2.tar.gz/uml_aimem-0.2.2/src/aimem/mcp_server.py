from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from aimem.core.context_manifest import get_context_manifest
from aimem.core.mcp_resources import (
    get_agent_context_bundle_dict,
    get_drift_alerts,
    query_capsules,
    read_capsule_markdown,
)


def _build_mcp(repo_root: Path) -> Any:
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("aimem")

    @mcp.tool()
    def query_capsules_tool(query: str = "") -> list[dict[str, str]]:
        """List drift capsules under .ai_memory/journal/capsules (optional keyword filter)."""
        return query_capsules(repo_root, query=query or None)

    @mcp.tool()
    def get_drift_alerts_tool(min_severity: str = "low") -> list[dict[str, str | float]]:
        """Return open drift events at or above min_severity (low, medium, high, critical)."""
        return get_drift_alerts(repo_root, min_severity=min_severity)

    @mcp.tool()
    def get_context_manifest_tool(manifest_id: str) -> dict[str, Any]:
        """Load a persisted ACM JSON manifest by id (file or SQLite fallback)."""
        return get_context_manifest(repo_root, manifest_id)

    @mcp.tool()
    def get_agent_context_bundle(
        profile: str = "bootstrap",
        objective: str | None = None,
        top_k: int = 5,
        max_chars: int = 12000,
        after_compile: bool = False,
        compile_profile: str | None = None,
        compile_objective: str | None = None,
        allow_secrets: bool = False,
        json_max_chars: int | None = None,
    ) -> dict[str, Any]:
        """Structured session bundle: same JSON object as ``aimem context --format json`` (repository, pinned, retrieval, drift, acm)."""
        return get_agent_context_bundle_dict(
            repo_root,
            profile=profile,
            objective=objective,
            top_k=top_k,
            max_chars=max_chars,
            after_compile=after_compile,
            compile_profile=compile_profile,
            compile_objective=compile_objective,
            allow_secrets_compile=allow_secrets,
            json_max_chars=json_max_chars,
        )

    @mcp.resource("aimem://manifest/{manifest_id}")
    def manifest_resource(manifest_id: str) -> str:
        """JSON context manifest (ACM) for manifest_id."""
        payload = get_context_manifest(repo_root, manifest_id)
        return json.dumps(payload, indent=2, sort_keys=False) + "\n"

    @mcp.resource("aimem://capsule/{capsule_id}")
    def capsule_resource(capsule_id: str) -> str:
        """Markdown body of a persisted drift capsule under .ai_memory/journal/capsules/."""
        return read_capsule_markdown(repo_root, capsule_id)

    return mcp


def main() -> None:
    try:
        import mcp.server.fastmcp  # noqa: F401
    except ImportError as exc:  # pragma: no cover - exercised when extra not installed
        raise SystemExit(
            "The 'mcp' package is required. Install with: uv sync --extra mcp"
        ) from exc

    parser = argparse.ArgumentParser(prog="aimem-mcp", description="MCP stdio server for aimem.")
    parser.add_argument(
        "--repo",
        type=Path,
        default=None,
        help="Git repository root (default: current working directory).",
    )
    args = parser.parse_args()
    repo_root = (args.repo or Path.cwd()).resolve()
    mcp = _build_mcp(repo_root)
    mcp.run()


if __name__ == "__main__":  # pragma: no cover
    main()
