---
id: rule-engineering
kind: rule
status: active
criticality: high
owner: human
edit_policy: manual
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.9
source_agent: human
verification_status: reviewed
review_consensus:
  - human
confidence: high
sources: []
---
# Engineering Rules

- Canonical documents must keep YAML frontmatter intact.
- Agents may only write to documents or sections approved by policy.
- Derived outputs in `generated/` must be deterministic for the same repository state.
- Local caches and indexes must remain Git-ignored by default.
- `verification_status` in frontmatter may be `unverified`, `reviewed`, `verified`, or `drifted`. The value `drifted` marks memory that diverged from enforced claims; `aimem drift apply --write` can set it when open drift events meet `aimem_drift.governance_apply.min_severity` in `manifest.yaml` (dry-run is the default).
