---
id: journal-readme
kind: journal
status: active
criticality: low
owner: shared
edit_policy: approved_agent
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.5
source_agent: system
verification_status: unverified
review_consensus: []
confidence: medium
sources: []
---
# Journal

Use `events.jsonl` as an append-only operational log for automated actions, proposals, and promotions of memory.
