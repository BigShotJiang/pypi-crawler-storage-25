---
id: decision-0001
kind: decision
status: reviewed
criticality: high
owner: human
edit_policy: manual
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.9
source_agent: human
verification_status: reviewed
review_consensus:
  - human
confidence: high
sources: []
---
# Decision 0001: Memory Contract Lives in the Repository

## Context

Context should survive across tools, models, and sessions.

## Decision

The repository will contain `.ai_memory` as the canonical memory contract, with derived and local-only layers explicitly separated.

## Consequences

- Shared context becomes versioned alongside code.
- Generated outputs remain disposable.
- Future MCP and retrieval layers can build on stable document types.
