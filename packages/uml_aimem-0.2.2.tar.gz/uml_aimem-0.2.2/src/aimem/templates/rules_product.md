---
id: rule-product
kind: rule
status: active
criticality: high
owner: human
edit_policy: manual
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.9
source_agent: human
verification_status: reviewed
review_consensus:
  - human
confidence: high
sources: []
---
# Product Rules

- Keep `.ai_memory` as the canonical shared memory contract for the repository.
- Prefer small, typed documents over monolithic notes.
- Treat generated and indexed artifacts as rebuildable views, not source of truth.
- Preserve rationale in `decisions/` whenever the project makes a meaningful architectural choice.
