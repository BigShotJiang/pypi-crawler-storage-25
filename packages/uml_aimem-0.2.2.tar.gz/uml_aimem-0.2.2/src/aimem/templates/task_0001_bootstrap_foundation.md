---
id: task-0001
kind: task
status: draft
criticality: medium
owner: shared
edit_policy: approved_agent
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.6
source_agent: human
verification_status: unverified
review_consensus: []
confidence: medium
sources: []
---
# Task 0001: Bootstrap Foundation

## Goal

Implement the initial CLI, manifest, templates, and verification flow.

## Done When

- `aimem init` creates the memory contract.
- `aimem compile` generates derived context packs.
- `aimem verify` detects stale or invalid canonical memory.
