---
id: state-project
kind: state
status: reviewed
criticality: medium
owner: shared
edit_policy: approved_agent
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.7
source_agent: human
verification_status: unverified
review_consensus: []
confidence: medium
sources: []
---
# Project State

## Current Focus

Bootstrap the Unified Memory Layer CLI and stabilize the canonical memory contract.

## Notes

- Use Python tooling for local CLI execution.
- Keep the memory model ready for future RAG and MCP integrations.
- If drift governance marks a document `verification_status: drifted`, treat it as a signal to reconcile memory with code before promoting back to `verified`/`reviewed`.
