---
id: state-architecture
kind: state
status: reviewed
criticality: medium
owner: shared
edit_policy: approved_agent
updated_at: __TIMESTAMP__
verified_at:
verified_from:
  git_commit:
  files: []
trust_score: 0.7
source_agent: human
verification_status: unverified
review_consensus: []
confidence: medium
sources: []
---
# Architecture State

## Core Layers

- CLI layer for user-facing commands.
- Memory layer for manifest, templates, frontmatter, and canonical document loading.
- Derived layer for compilation profiles.
- Verification layer for freshness and provenance checks.
