"""Template package for aimem."""
