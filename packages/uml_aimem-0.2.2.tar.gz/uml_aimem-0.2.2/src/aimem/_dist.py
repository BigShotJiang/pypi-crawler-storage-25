"""PyPI distribution name (import package remains ``aimem``)."""

DISTRIBUTION_NAME = "uml-aimem"
