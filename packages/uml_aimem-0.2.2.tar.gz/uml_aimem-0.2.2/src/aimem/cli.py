from __future__ import annotations

import typer

from aimem.commands.compile import compile_command
from aimem.commands.context import context_command
from aimem.commands.drift import drift_app
from aimem.commands.hooks import install_hooks_command
from aimem.commands.index import index_app
from aimem.commands.init import init_command
from aimem.commands.manifest import manifest_app
from aimem.commands.promote import promote_command
from aimem.commands.query import query_command
from aimem.commands.record import record_app
from aimem.commands.verify import verify_command

app = typer.Typer(help="Unified Memory Layer CLI.")

app.command("init")(init_command)
app.command("compile")(compile_command)
app.command("context")(context_command)
app.command("query")(query_command)
app.command("verify")(verify_command)
app.command("install-hooks")(install_hooks_command)
app.command("promote")(promote_command)
app.add_typer(record_app, name="record")
app.add_typer(drift_app, name="drift")
app.add_typer(manifest_app, name="manifest")
app.add_typer(index_app, name="index")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
