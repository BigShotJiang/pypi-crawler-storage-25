"""Character budget helpers for agent context bundles."""

from __future__ import annotations

from aimem.core.agent_context_models import (
    ENVELOPE_MAX,
    ENVELOPE_MIN,
    PINNED_FRACTION,
    RETRIEVAL_FRACTION,
)


def envelope_budget(total: int) -> int:
    """Reserve space for section headers, repository lines, ACM lines, drift summary."""
    return min(ENVELOPE_MAX, max(ENVELOPE_MIN, total // 6))


def truncate_text(text: str, limit: int) -> str:
    if limit <= 0:
        return ""
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 20)].rstrip() + "\n... (truncated)"


def split_content_budget(total: int) -> tuple[int, int, int]:
    """Return (envelope, pinned_budget, retrieval_budget) for a total char budget."""
    budget = max(2000, int(total))
    envelope = min(envelope_budget(budget), budget // 2)
    remainder = max(0, budget - envelope)
    pinned_budget = int(remainder * PINNED_FRACTION)
    retrieval_budget = int(remainder * RETRIEVAL_FRACTION)
    return envelope, pinned_budget, retrieval_budget
