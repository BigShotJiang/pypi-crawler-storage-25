from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from aimem.core.context_manifest import get_context_manifest
from aimem.core.drift import list_open_drift_events
from aimem.core.repo import RepoError, find_git_root

_CAPSULE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,200}$")


def get_drift_alerts(repo_root_or_child: Path, *, min_severity: str = "low") -> list[dict[str, str | float]]:
    rank = {"low": 1, "medium": 2, "high": 3, "critical": 4}
    threshold = rank.get(min_severity, 1)
    alerts: list[dict[str, str | float]] = []
    for event in list_open_drift_events(repo_root_or_child):
        if rank.get(event.severity, 1) < threshold:
            continue
        alerts.append(
            {
                "event_id": event.event_id,
                "claim_id": event.claim_id,
                "severity": event.severity,
                "status": event.status,
                "drift_score": event.drift_score,
                "resource_uri": f"aimem://drift-event/{event.event_id}",
            }
        )
    return alerts


def query_capsules(repo_root_or_child: Path, *, query: str | None = None) -> list[dict[str, str]]:
    repo_root = find_git_root(repo_root_or_child)
    capsules_dir = repo_root / ".ai_memory" / "journal" / "capsules"
    if not capsules_dir.exists():
        return []
    keyword = (query or "").strip().lower()
    results: list[dict[str, str]] = []
    for path in sorted(capsules_dir.glob("capsule-*.md")):
        text = path.read_text(encoding="utf-8")
        if keyword and keyword not in text.lower():
            continue
        capsule_id = path.stem
        title = first_heading(text) or capsule_id
        results.append(
            {
                "capsule_id": capsule_id,
                "title": title,
                "resource_uri": f"aimem://capsule/{capsule_id}",
                "path": str(path),
            }
        )
    return results


def get_context_manifest_tool(repo_root_or_child: Path, manifest_id: str) -> dict[str, object]:
    return get_context_manifest(repo_root_or_child, manifest_id)


def get_agent_context_bundle_dict(
    repo_root_or_child: Path,
    *,
    profile: str = "bootstrap",
    objective: str | None = None,
    top_k: int = 5,
    max_chars: int = 12000,
    after_compile: bool = False,
    compile_profile: str | None = None,
    compile_objective: str | None = None,
    allow_secrets_compile: bool = False,
    json_max_chars: int | None = None,
) -> dict[str, Any]:
    """Same structured payload as ``aimem context --format json`` (via shared request contract)."""
    from aimem.core.context_contract import ContextBundleRequest, build_context_dict

    request = ContextBundleRequest.from_mcp_args(
        profile=profile,
        objective=objective,
        top_k=top_k,
        max_chars=max_chars,
        after_compile=after_compile,
        compile_profile=compile_profile,
        compile_objective=compile_objective,
        allow_secrets_compile=allow_secrets_compile,
        json_max_chars=json_max_chars,
    )
    return build_context_dict(repo_root_or_child, request)


def read_capsule_markdown(repo_root_or_child: Path, capsule_id: str) -> str:
    """Return persisted drift capsule Markdown. ``capsule_id`` is the stem (e.g. ``capsule-…``), without path segments."""
    repo_root = find_git_root(repo_root_or_child)
    raw = str(capsule_id or "").strip()
    if not raw or ".." in raw or "/" in raw or "\\" in raw:
        raise RepoError("Invalid capsule id.")
    stem = raw[:-3] if raw.lower().endswith(".md") else raw
    if not _CAPSULE_ID_RE.fullmatch(stem):
        raise RepoError(f"Invalid capsule id '{capsule_id}'.")
    capsules_dir = (repo_root / ".ai_memory" / "journal" / "capsules").resolve()
    path = (capsules_dir / f"{stem}.md").resolve()
    if path.parent != capsules_dir:
        raise RepoError(f"Capsule '{capsule_id}' path is outside capsules directory.")
    if not path.exists():
        raise RepoError(f"Capsule '{stem}' not found.")
    return path.read_text(encoding="utf-8")


def first_heading(text: str) -> str:
    match = re.search(r"^#\s+(.+)$", text, flags=re.MULTILINE)
    if match:
        return match.group(1).strip()
    return ""
