"""Render and JSON serialization for agent context bundles."""

from __future__ import annotations

import copy
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Literal

from aimem.core.agent_context_budget import truncate_text
from aimem.core.agent_context_models import AgentContextBundle, RepositorySection
from aimem.core.retrieval import QueryHit, QueryReport


def _heading(title: str, fmt: Literal["markdown", "text"]) -> str:
    if fmt == "markdown":
        return f"\n## {title}\n\n"
    return f"\n=== {title} ===\n\n"


def _meta_line(fmt: Literal["markdown", "text"], label: str, value: str) -> str:
    if fmt == "markdown":
        return f"- **{label}:** {value}\n"
    return f"- {label}: {value}\n"


def _render_repository(section: RepositorySection, fmt: Literal["markdown", "text"]) -> list[str]:
    parts: list[str] = []
    parts.append(_heading("Repository", fmt))
    parts.append(_meta_line(fmt, "Product (manifest)", section.product_name))
    parts.append(_meta_line(fmt, "Manifest schema_version", section.schema_version))
    parts.append(_meta_line(fmt, "Git HEAD", section.git_head or "(unknown)"))
    parts.append(_meta_line(fmt, "Branch", section.branch or "(unknown)"))
    parts.append(_meta_line(fmt, "Working tree dirty", str(section.working_tree_dirty)))
    return parts


def _render_pinned(bundle: AgentContextBundle, fmt: Literal["markdown", "text"]) -> list[str]:
    parts: list[str] = []
    parts.append(_heading(f"Pinned baseline (profile `{bundle.profile}`)", fmt))
    for entry in bundle.pinned:
        if entry.missing:
            if fmt == "markdown":
                parts.append(f"*Missing:* `.ai_memory/{entry.relative_path}`\n\n")
            else:
                parts.append(f"(missing) .ai_memory/{entry.relative_path}\n\n")
            continue
        if fmt == "markdown":
            parts.append(f"### `.ai_memory/{entry.relative_path}`\n\n{entry.body_excerpt}\n\n")
        else:
            parts.append(f".ai_memory/{entry.relative_path}\n{entry.body_excerpt}\n\n")
    return parts


def _retrieval_dict_to_report(retrieval: dict[str, Any]) -> QueryReport:
    hits_list: list[QueryHit] = []
    for h in retrieval.get("hits", []):
        if not isinstance(h, dict):
            continue
        hits_list.append(
            QueryHit(
                relative_path=str(h.get("relative_path", "")),
                document_id=str(h.get("document_id", "")),
                kind=str(h.get("kind", "")),
                status=str(h.get("status", "")),
                score=float(h.get("score", 0.0)),
                snippet=str(h.get("snippet", "")),
                criticality=str(h.get("criticality", "medium")),
                trust_score=float(h.get("trust_score", 0.5)),
                verification_status=str(h.get("verification_status", "unverified")),
                updated_at=str(h.get("updated_at", "")),
            )
        )
    return QueryReport(
        objective=str(retrieval["objective"]),
        db_path=Path(str(retrieval["index"])),
        index_backend=str(retrieval["backend"]),
        ranking_mode=str(retrieval["ranking_mode"]),
        refreshed_docs=int(retrieval["refreshed_docs"]),
        hits=hits_list,
        reindexed_paths=int(retrieval.get("reindexed_paths") or 0),
    )


def _render_retrieval(bundle: AgentContextBundle, fmt: Literal["markdown", "text"]) -> list[str]:
    parts: list[str] = []
    report = _retrieval_dict_to_report(bundle.retrieval)
    parts.append(_heading("Retrieval", fmt))
    parts.append("\n".join(report.render_lines()) + "\n")
    return parts


def _render_drift(bundle: AgentContextBundle, fmt: Literal["markdown", "text"]) -> list[str]:
    parts: list[str] = []
    parts.append(_heading("Drift (open events)", fmt))
    if not bundle.drift:
        parts.append("No open drift events.\n")
        return parts

    sev_rank = {"low": 1, "medium": 2, "high": 3, "critical": 4}
    worst = max(bundle.drift, key=lambda d: sev_rank.get(str(d.get("severity", "")), 0))
    worst_sev = str(worst.get("severity", ""))
    if fmt == "markdown":
        parts.append(f"**Open:** {len(bundle.drift)} (showing up to 10)\n")
        parts.append(f"**Worst severity:** `{worst_sev}`\n\n")
        for d in bundle.drift[:5]:
            parts.append(f"- `{d['severity']}` claim=`{d['claim_id']}` score={float(d['drift_score']):.2f}\n")
    else:
        parts.append(f"Open: {len(bundle.drift)} (showing up to 10)\n")
        parts.append(f"Worst severity: {worst_sev}\n\n")
        for d in bundle.drift[:5]:
            parts.append(f"- {d['severity']} claim={d['claim_id']} score={float(d['drift_score']):.2f}\n")
    return parts


def _render_acm(bundle: AgentContextBundle, fmt: Literal["markdown", "text"]) -> list[str]:
    parts: list[str] = []
    parts.append(_heading("Context manifests (ACM)", fmt))
    latest = bundle.acm.get("latest")
    fcr = bundle.acm.get("from_compile_this_run")
    cap = bundle.acm.get("latest_capsule") if isinstance(bundle.acm, dict) else None

    if fmt == "markdown":
        if latest:
            parts.append(f"- **Latest:** `{latest.get('manifest_id')}` — {latest.get('aimem_uri')}\n")
            if latest.get("created_at"):
                parts.append(f"- **Created:** {latest.get('created_at')}\n")
        else:
            parts.append("- **Latest:** *(none recorded)*\n")
        if fcr:
            parts.append(
                f"- **From this run (compile):** `{fcr.get('manifest_id')}` — {fcr.get('aimem_uri')}\n"
            )
        else:
            parts.append("- **From this run (compile):** *(not requested)*\n")
        if isinstance(cap, dict) and cap.get("capsule_id"):
            parts.append(f"- **Latest capsule:** `{cap.get('capsule_id')}` — {cap.get('aimem_uri')}\n")
    else:
        if latest:
            parts.append(f"Latest manifest: {latest.get('manifest_id')} {latest.get('aimem_uri')}\n")
        else:
            parts.append("Latest manifest: (none recorded)\n")
        if fcr:
            parts.append(f"From compile this run: {fcr.get('manifest_id')} {fcr.get('aimem_uri')}\n")
        else:
            parts.append("From compile this run: (not requested)\n")
        if isinstance(cap, dict) and cap.get("capsule_id"):
            parts.append(f"Latest capsule: {cap.get('capsule_id')} {cap.get('aimem_uri')}\n")
    return parts


def render_agent_context_bundle(
    bundle: AgentContextBundle,
    output_format: Literal["markdown", "text"],
    *,
    max_chars: int = 12000,
) -> str:
    """Render bundle to markdown or plain text; final length capped by max_chars."""
    fmt: Literal["markdown", "text"] = output_format
    budget = max(2000, int(max_chars))
    parts: list[str] = []
    parts.extend(_render_repository(bundle.repository, fmt))
    parts.extend(_render_pinned(bundle, fmt))
    parts.extend(_render_retrieval(bundle, fmt))
    parts.extend(_render_drift(bundle, fmt))
    parts.extend(_render_acm(bundle, fmt))

    out = "".join(parts).strip() + "\n"
    if len(out) > budget:
        return truncate_text(out, budget)
    return out


def _shrink_bundle_dict_for_json_size(data: dict[str, Any], limit: int) -> dict[str, Any]:
    """Reduce long string fields until serialized JSON fits limit (best-effort)."""
    d = copy.deepcopy(data)
    for _ in range(5):
        serialized = json.dumps(d, indent=2, ensure_ascii=False) + "\n"
        if len(serialized) <= limit:
            return d

        ratio = max(0.2, (limit * 0.95) / len(serialized))

        for p in d.get("pinned", []) or []:
            if not isinstance(p, dict):
                continue
            ex = str(p.get("body_excerpt") or "")
            if len(ex) > 8:
                new_len = int(len(ex) * ratio)
                p["body_excerpt"] = ex[: max(8, new_len)]
                p["truncated"] = True
        retr = d.get("retrieval")
        if isinstance(retr, dict):
            for h in retr.get("hits", []) or []:
                if not isinstance(h, dict):
                    continue
                sn = str(h.get("snippet") or "")
                if len(sn) > 8:
                    new_len = int(len(sn) * ratio)
                    h["snippet"] = sn[: max(8, new_len)]
        for ev in d.get("drift", []) or []:
            if not isinstance(ev, dict):
                continue
            ej = str(ev.get("evidence_json") or "")
            if len(ej) > 24:
                new_len = int(len(ej) * ratio)
                ev["evidence_json"] = ej[: max(24, new_len)] + "…"
        acm = d.get("acm")
        if isinstance(acm, dict) and ratio < 0.5:
            for _k, v in list(acm.items()):
                if isinstance(v, str) and len(v) > 32:
                    acm[_k] = v[:32] + "…"
                elif isinstance(v, dict):
                    for ik, iv in list(v.items()):
                        if isinstance(iv, str) and len(iv) > 32:
                            v[ik] = iv[:32] + "…"
    return d


def bundle_to_dict(bundle: AgentContextBundle) -> dict[str, Any]:
    """Structured dict equivalent to `bundle_to_json` (for MCP tools)."""
    return {
        "bundle_schema_version": bundle.bundle_schema_version,
        "profile": bundle.profile,
        "repository": asdict(bundle.repository),
        "pinned": [asdict(p) for p in bundle.pinned],
        "retrieval": bundle.retrieval,
        "drift": bundle.drift,
        "acm": bundle.acm,
    }


def bundle_to_json(bundle: AgentContextBundle, *, max_serialized_chars: int | None = None) -> str:
    data = bundle_to_dict(bundle)
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    if max_serialized_chars is None or len(text) <= max_serialized_chars:
        return text
    trimmed = _shrink_bundle_dict_for_json_size(data, max_serialized_chars)
    return json.dumps(trimmed, indent=2, ensure_ascii=False) + "\n"
