"""SQLite schema and path helpers for `.ai_memory/index/aimem.sqlite`."""

from __future__ import annotations

import sqlite3
from pathlib import Path

INDEX_DB_RELATIVE = Path(".ai_memory") / "index" / "aimem.sqlite"


def index_db_path(repo_root: Path) -> Path:
    return repo_root / INDEX_DB_RELATIVE


def configure_index_connection(connection: sqlite3.Connection) -> None:
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=3000")


def ensure_retrieval_documents_schema(connection: sqlite3.Connection) -> None:
    """Documents table and column migrations for FTS retrieval."""
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS documents (
            relative_path TEXT PRIMARY KEY,
            document_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            status TEXT NOT NULL,
            criticality TEXT NOT NULL,
            owner TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            verified_at TEXT,
            trust_score REAL NOT NULL,
            verification_status TEXT NOT NULL,
            search_text TEXT NOT NULL,
            body TEXT NOT NULL,
            source_fingerprint TEXT
        )
        """
    )
    _ensure_documents_columns(connection)


def _ensure_documents_columns(connection: sqlite3.Connection) -> None:
    required_columns = {
        "criticality": "TEXT NOT NULL DEFAULT 'medium'",
        "verified_at": "TEXT",
        "trust_score": "REAL NOT NULL DEFAULT 0.5",
        "verification_status": "TEXT NOT NULL DEFAULT 'unverified'",
        "source_fingerprint": "TEXT",
        "mtime": "REAL NOT NULL DEFAULT 0.0",
    }
    existing = {
        str(row[1])
        for row in connection.execute("PRAGMA table_info(documents)").fetchall()
    }
    for column, declaration in required_columns.items():
        if column in existing:
            continue
        connection.execute(f"ALTER TABLE documents ADD COLUMN {column} {declaration}")


def ensure_governance_schema(connection: sqlite3.Connection) -> None:
    """Drift claims/events and persisted ACM rows (shared index database)."""
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS gold_claims (
            claim_id TEXT PRIMARY KEY,
            doc_path TEXT NOT NULL,
            doc_id TEXT NOT NULL,
            assertion TEXT NOT NULL,
            enforce_when TEXT NOT NULL,
            rule_json TEXT NOT NULL,
            trust_score REAL NOT NULL,
            indexed_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS drift_events (
            event_id TEXT PRIMARY KEY,
            claim_id TEXT NOT NULL,
            scan_id TEXT NOT NULL,
            drift_score REAL NOT NULL,
            severity TEXT NOT NULL,
            evidence_json TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS context_manifests (
            manifest_id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            output_sha256 TEXT NOT NULL,
            git_commit TEXT
        )
        """
    )


def ensure_index_schema(connection: sqlite3.Connection) -> None:
    """Full local index schema: retrieval documents + governance tables."""
    ensure_retrieval_documents_schema(connection)
    ensure_governance_schema(connection)
    connection.commit()
