from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from aimem.core.repo import RepoError, ensure_gitignore_rules, find_git_root
from aimem.core.templates import load_template

FRONTMATTER_REQUIRED_FIELDS = [
    "id",
    "kind",
    "status",
    "criticality",
    "owner",
    "edit_policy",
    "updated_at",
    "verified_at",
    "verified_from",
    "trust_score",
    "source_agent",
    "verification_status",
    "review_consensus",
    "confidence",
    "sources",
]

TEMPLATE_PATHS = {
    "manifest.yaml": "manifest.yaml",
    "rules/product.md": "rules_product.md",
    "rules/engineering.md": "rules_engineering.md",
    "state/project.md": "state_project.md",
    "state/architecture.md": "state_architecture.md",
    "decisions/decision-0001-memory-contract.md": "decision_0001_memory_contract.md",
    "tasks/task-0001-bootstrap-foundation.md": "task_0001_bootstrap_foundation.md",
    "journal/README.md": "journal_readme.md",
    "journal/events.jsonl": "journal_events.jsonl",
    "secrets.allowlist": "secrets_allowlist.txt",
}


@dataclass(frozen=True)
class MemoryInitializationResult:
    repo_root: Path
    memory_root: Path
    created_paths: list[Path]


@dataclass(frozen=True)
class MemoryDocument:
    path: Path
    relative_path: Path
    metadata: dict[str, Any]
    body: str


def initialize_memory_layer(start_path: Path) -> MemoryInitializationResult:
    repo_root = find_git_root(start_path)
    memory_root = repo_root / ".ai_memory"
    created_paths: list[Path] = []

    directories = [
        memory_root,
        memory_root / "rules",
        memory_root / "state",
        memory_root / "decisions",
        memory_root / "tasks",
        memory_root / "journal",
        memory_root / "generated",
        memory_root / "cache",
        memory_root / "index",
        memory_root / "workspaces",
    ]
    for directory in directories:
        if not directory.exists():
            directory.mkdir(parents=True, exist_ok=True)
            created_paths.append(directory)

    timestamp = utc_now_iso()
    for relative_path, template_name in TEMPLATE_PATHS.items():
        destination = memory_root / relative_path
        if destination.exists():
            continue
        content = render_template(template_name, timestamp=timestamp)
        destination.write_text(content, encoding="utf-8")
        created_paths.append(destination)

    gitignore_update = ensure_gitignore_rules(repo_root)
    if gitignore_update.changed:
        created_paths.append(gitignore_update.path)

    return MemoryInitializationResult(
        repo_root=repo_root,
        memory_root=memory_root,
        created_paths=created_paths,
    )


def load_manifest(repo_root_or_child: Path) -> dict[str, Any]:
    repo_root = find_git_root(repo_root_or_child)
    manifest_path = repo_root / ".ai_memory" / "manifest.yaml"
    if not manifest_path.exists():
        raise RepoError("Missing .ai_memory/manifest.yaml. Run 'aimem init' first.")
    data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RepoError("Invalid manifest format. Expected a YAML mapping.")
    return data


def parse_document(path: Path, repo_root: Path) -> MemoryDocument:
    text = path.read_text(encoding="utf-8")
    metadata, body = split_frontmatter(text)
    relative_path = path.relative_to(repo_root / ".ai_memory")
    return MemoryDocument(path=path, relative_path=relative_path, metadata=metadata, body=body)


def split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        raise RepoError("Canonical memory documents must start with YAML frontmatter.")
    end_marker = "\n---\n"
    end_index = text.find(end_marker, 4)
    if end_index == -1:
        raise RepoError("Canonical memory document frontmatter is not terminated correctly.")
    raw_frontmatter = text[4:end_index]
    body = text[end_index + len(end_marker) :]
    metadata = yaml.safe_load(raw_frontmatter) or {}
    if not isinstance(metadata, dict):
        raise RepoError("Document frontmatter must parse to a YAML mapping.")
    return metadata, body.strip() + "\n"


def iter_canonical_documents(repo_root_or_child: Path, include_paths: list[str]) -> list[MemoryDocument]:
    repo_root = find_git_root(repo_root_or_child)
    documents: list[MemoryDocument] = []
    for path in iter_canonical_paths(repo_root, include_paths):
        documents.append(parse_document(path, repo_root))
    return documents

def iter_canonical_paths(repo_root_or_child: Path, include_paths: list[str]) -> list[Path]:
    repo_root = find_git_root(repo_root_or_child)
    memory_root = repo_root / ".ai_memory"
    paths: list[Path] = []
    for include_path in include_paths:
        base = memory_root / include_path
        if not base.exists():
            continue
        for path in sorted(base.rglob("*.md")):
            if any(part in {"generated", "cache", "index", "workspaces"} for part in path.parts):
                continue
            paths.append(path)
    return paths


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def render_template(template_name: str, *, timestamp: str) -> str:
    return load_template(template_name).replace("__TIMESTAMP__", timestamp)
