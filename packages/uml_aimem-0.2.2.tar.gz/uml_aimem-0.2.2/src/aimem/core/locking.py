from __future__ import annotations

import os
import time
from contextlib import contextmanager
from pathlib import Path

from aimem.core.repo import RepoError


@contextmanager
def acquire_memory_lock(repo_root: Path, *, timeout_seconds: float = 5.0):
    lock_path = repo_root / ".ai_memory" / ".lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.time() + timeout_seconds
    fd: int | None = None
    while time.time() < deadline:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode("ascii"))
            break
        except FileExistsError:
            time.sleep(0.05)
    if fd is None:
        raise RepoError("Could not acquire .ai_memory lock before timeout.")
    try:
        yield
    finally:
        try:
            os.close(fd)
        finally:
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass
