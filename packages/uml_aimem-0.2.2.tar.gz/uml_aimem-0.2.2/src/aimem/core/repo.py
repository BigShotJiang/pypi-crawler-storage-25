from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

MANAGED_BLOCK_START = "# >>> aimem managed >>>"
MANAGED_BLOCK_END = "# <<< aimem managed <<<"
MANAGED_GITIGNORE_RULES = [
    ".ai_memory/generated/",
    ".ai_memory/cache/",
    ".ai_memory/index/",
    ".ai_memory/workspaces/",
    ".ai_memory/**/*.sqlite",
    ".ai_memory/**/*.sqlite-shm",
    ".ai_memory/**/*.sqlite-wal",
    ".ai_memory/**/*.db",
    ".ai_memory/**/*.bin",
    ".ai_memory/.lock",
]


class RepoError(RuntimeError):
    """Raised when repository expectations are not met."""


@dataclass(frozen=True)
class GitIgnoreUpdate:
    path: Path
    changed: bool


def find_git_root(start: Path) -> Path:
    current = start.resolve()
    for candidate in [current, *current.parents]:
        git_marker = candidate / ".git"
        if git_marker.exists():
            return candidate
    raise RepoError("No Git repository found. Run this inside a repository root or subdirectory.")


def read_head_commit(repo_root: Path) -> str | None:
    completed = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return None
    return completed.stdout.strip() or None


def ensure_gitignore_rules(repo_root: Path) -> GitIgnoreUpdate:
    gitignore_path = repo_root / ".gitignore"
    block_lines = [MANAGED_BLOCK_START, *MANAGED_GITIGNORE_RULES, MANAGED_BLOCK_END]
    block_text = "\n".join(block_lines) + "\n"

    if not gitignore_path.exists():
        gitignore_path.write_text(block_text, encoding="utf-8")
        return GitIgnoreUpdate(path=gitignore_path, changed=True)

    existing = gitignore_path.read_text(encoding="utf-8")
    if MANAGED_BLOCK_START in existing and MANAGED_BLOCK_END in existing:
        start = existing.index(MANAGED_BLOCK_START)
        end = existing.index(MANAGED_BLOCK_END) + len(MANAGED_BLOCK_END)
        replaced = existing[:start] + block_text.rstrip("\n") + existing[end:]
        normalized = _normalize_trailing_newline(replaced)
        if normalized != existing:
            gitignore_path.write_text(normalized, encoding="utf-8")
            return GitIgnoreUpdate(path=gitignore_path, changed=True)
        return GitIgnoreUpdate(path=gitignore_path, changed=False)

    separator = "" if existing.endswith("\n") or not existing else "\n"
    updated = existing + separator + block_text
    gitignore_path.write_text(updated, encoding="utf-8")
    return GitIgnoreUpdate(path=gitignore_path, changed=True)


def _normalize_trailing_newline(text: str) -> str:
    return text if text.endswith("\n") else text + "\n"
