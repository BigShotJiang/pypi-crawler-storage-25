from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import yaml

from aimem.core.memory import load_manifest, utc_now_iso
from aimem.core.locking import acquire_memory_lock
from aimem.core.repo import RepoError, find_git_root
from aimem.core.security import assert_no_high_secrets


def record_decision(
    repo_root_or_child: Path,
    *,
    title: str,
    context: str,
    decision: str,
    consequences: list[str] | None,
    source_refs: list[str] | None,
    allow_secrets: bool = False,
) -> Path:
    repo_root = find_git_root(repo_root_or_child)
    load_manifest(repo_root)
    timestamp = utc_now_iso()
    record_id = next_record_id(repo_root / ".ai_memory" / "decisions", "decision")
    slug = slugify(title)
    path = repo_root / ".ai_memory" / "decisions" / f"decision-{record_id:04d}-{slug}.md"
    metadata = base_metadata(
        document_id=f"decision-{record_id:04d}",
        kind="decision",
        status="draft",
        criticality="high",
        owner="human",
        edit_policy="manual",
        timestamp=timestamp,
        source_refs=source_refs,
    )
    body = build_decision_body(title, context, decision, consequences or [])
    assert_no_high_secrets(body, allow_secrets=allow_secrets, context=f".ai_memory/decisions/{path.name}")
    with acquire_memory_lock(repo_root):
        write_markdown_document(path, metadata, body)
        append_journal_event(
            repo_root,
            operation="record_decision",
            target=f".ai_memory/decisions/{path.name}",
            source_refs=source_refs or [],
            timestamp=timestamp,
        )
    return path


def record_task(
    repo_root_or_child: Path,
    *,
    title: str,
    goal: str,
    done_when: list[str] | None,
    status: str,
    source_refs: list[str] | None,
    allow_secrets: bool = False,
) -> Path:
    repo_root = find_git_root(repo_root_or_child)
    load_manifest(repo_root)
    timestamp = utc_now_iso()
    record_id = next_record_id(repo_root / ".ai_memory" / "tasks", "task")
    slug = slugify(title)
    path = repo_root / ".ai_memory" / "tasks" / f"task-{record_id:04d}-{slug}.md"
    normalized_status = normalize_status(status)
    metadata = base_metadata(
        document_id=f"task-{record_id:04d}",
        kind="task",
        status=normalized_status,
        criticality="medium",
        owner="shared",
        edit_policy="approved_agent",
        timestamp=timestamp,
        source_refs=source_refs,
    )
    body = build_task_body(title, goal, done_when or [])
    assert_no_high_secrets(body, allow_secrets=allow_secrets, context=f".ai_memory/tasks/{path.name}")
    with acquire_memory_lock(repo_root):
        write_markdown_document(path, metadata, body)
        append_journal_event(
            repo_root,
            operation="record_task",
            target=f".ai_memory/tasks/{path.name}",
            source_refs=source_refs or [],
            timestamp=timestamp,
        )
    return path


def next_record_id(directory: Path, prefix: str) -> int:
    highest = 0
    pattern = re.compile(rf"^{re.escape(prefix)}-(\d{{4}})-")
    if directory.exists():
        for path in directory.glob(f"{prefix}-*.md"):
            match = pattern.match(path.name)
            if match:
                highest = max(highest, int(match.group(1)))
    return highest + 1


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug or "untitled"


def base_metadata(
    *,
    document_id: str,
    kind: str,
    status: str,
    criticality: str,
    owner: str,
    edit_policy: str,
    timestamp: str,
    source_refs: list[str] | None,
) -> dict[str, Any]:
    return {
        "id": document_id,
        "kind": kind,
        "status": status,
        "criticality": criticality,
        "owner": owner,
        "edit_policy": edit_policy,
        "updated_at": timestamp,
        "verified_at": None,
        "verified_from": {
            "git_commit": None,
            "files": [],
        },
        "trust_score": 0.6,
        "source_agent": "human",
        "verification_status": "unverified",
        "review_consensus": [],
        "confidence": "medium",
        "sources": source_refs or [],
    }


def normalize_status(status: str) -> str:
    normalized = status.strip().lower()
    allowed = {"draft", "reviewed", "gold", "deprecated", "in_progress", "active", "proposed", "accepted"}
    if normalized not in allowed:
        raise RepoError(f"Unsupported task status '{status}'.")
    if normalized in {"proposed", "accepted"}:
        return "draft"
    return normalized


def build_decision_body(title: str, context: str, decision: str, consequences: list[str]) -> str:
    lines = [
        f"# {title}",
        "",
        "## Context",
        "",
        context,
        "",
        "## Decision",
        "",
        decision,
        "",
        "## Consequences",
        "",
    ]
    if consequences:
        lines.extend([f"- {item}" for item in consequences])
    else:
        lines.append("- Capture follow-up consequences here.")
    return "\n".join(lines).rstrip() + "\n"


def build_task_body(title: str, goal: str, done_when: list[str]) -> str:
    lines = [
        f"# {title}",
        "",
        "## Goal",
        "",
        goal,
        "",
        "## Done When",
        "",
    ]
    if done_when:
        lines.extend([f"- {item}" for item in done_when])
    else:
        lines.append("- Capture completion criteria here.")
    return "\n".join(lines).rstrip() + "\n"


def write_markdown_document(path: Path, metadata: dict[str, Any], body: str) -> None:
    if path.exists():
        raise RepoError(f"Refusing to overwrite existing memory document: {path}")
    frontmatter = yaml.safe_dump(metadata, sort_keys=False, allow_unicode=False)
    path.write_text(f"---\n{frontmatter}---\n{body}", encoding="utf-8")


def append_journal_event(
    repo_root: Path,
    *,
    operation: str,
    target: str,
    source_refs: list[str],
    timestamp: str,
) -> None:
    events_path = repo_root / ".ai_memory" / "journal" / "events.jsonl"
    if not events_path.exists():
        raise RepoError("Missing .ai_memory/journal/events.jsonl. Run 'aimem init' first.")
    event = {
        "timestamp": timestamp,
        "actor_id": "human",
        "tool": "aimem",
        "operation": operation,
        "target": target,
        "approval_ref": "local_cli",
        "source_refs": source_refs,
    }
    with events_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=True) + "\n")
