from __future__ import annotations

import hashlib
import importlib.metadata
import json
import sqlite3
import subprocess
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from aimem.core.sqlite_index import ensure_governance_schema, index_db_path
from aimem.core.memory import utc_now_iso
from aimem.core.repo import RepoError, find_git_root


def installed_aimem_version() -> str:
    from aimem import __version__

    return __version__


@dataclass(frozen=True)
class ManifestSource:
    kind: str
    ref: str
    sha256: str
    git_blob_sha: str | None
    byte_range: tuple[int, int] | None
    token_estimate: int | None


def create_context_manifest(
    repo_root_or_child: Path,
    *,
    profile: str,
    ranking_mode: str,
    max_tokens: int | None,
    max_chars: int | None,
    output_text: str,
    sources: list[ManifestSource],
    capsule_ids: list[str] | None = None,
) -> dict[str, Any]:
    repo_root = find_git_root(repo_root_or_child)
    payload: dict[str, Any] = {
        "schema_version": "1.0",
        "manifest_id": str(uuid.uuid4()),
        "created_at": utc_now_iso(),
        "aimem_version": installed_aimem_version(),
        "repo": {
            "git_commit": read_head_commit(repo_root),
            "dirty": is_working_tree_dirty(repo_root),
            "branch": read_current_branch(repo_root),
        },
        "compile": {
            "profile": profile,
            "ranking_mode": ranking_mode,
            "max_tokens": max_tokens,
            "max_chars": max_chars,
        },
        "sources": [
            {
                "kind": source.kind,
                "ref": source.ref,
                "git_blob_sha": source.git_blob_sha,
                "byte_range": list(source.byte_range) if source.byte_range else None,
                "sha256": source.sha256,
                "token_estimate": source.token_estimate,
                "retrieval": None,
            }
            for source in sources
        ],
        "output_sha256": hashlib.sha256(output_text.encode("utf-8")).hexdigest(),
        "capsule_ids": capsule_ids or [],
    }
    persist_context_manifest(repo_root, payload)
    return payload


def persist_context_manifest(repo_root: Path, payload: dict[str, Any]) -> None:
    memory_root = repo_root / ".ai_memory"
    manifests_dir = memory_root / "journal" / "manifests"
    manifests_dir.mkdir(parents=True, exist_ok=True)
    manifest_id = str(payload["manifest_id"])
    manifest_path = manifests_dir / f"{manifest_id}.json"
    manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=False) + "\n", encoding="utf-8")

    db_path = index_db_path(repo_root)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as connection:
        ensure_governance_schema(connection)
        connection.commit()
        connection.execute(
            """
            INSERT OR REPLACE INTO context_manifests (
                manifest_id, created_at, payload_json, output_sha256, git_commit
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (
                manifest_id,
                str(payload["created_at"]),
                json.dumps(payload, sort_keys=True),
                str(payload["output_sha256"]),
                str(payload.get("repo", {}).get("git_commit") or ""),
            ),
        )
        connection.commit()


def get_context_manifest(repo_root_or_child: Path, manifest_id: str) -> dict[str, Any]:
    repo_root = find_git_root(repo_root_or_child)
    memory_root = repo_root / ".ai_memory"
    manifest_path = memory_root / "journal" / "manifests" / f"{manifest_id}.json"
    if manifest_path.exists():
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        validate_manifest_schema(payload)
        return payload

    db_path = index_db_path(repo_root)
    if not db_path.exists():
        raise RepoError(f"Context manifest '{manifest_id}' not found.")
    with sqlite3.connect(db_path) as connection:
        connection.row_factory = sqlite3.Row
        ensure_governance_schema(connection)
        row = connection.execute(
            "SELECT payload_json FROM context_manifests WHERE manifest_id = ?",
            (manifest_id,),
        ).fetchone()
    if row is None:
        raise RepoError(f"Context manifest '{manifest_id}' not found.")
    payload = json.loads(str(row["payload_json"]))
    validate_manifest_schema(payload)
    return payload


def validate_manifest_schema(payload: dict[str, Any]) -> None:
    schema_version = str(payload.get("schema_version", ""))
    if schema_version != "1.0":
        raise RepoError(f"SCHEMA_MISMATCH: unsupported context manifest schema '{schema_version}'.")


def get_latest_context_manifest_summary(repo_root_or_child: Path) -> dict[str, Any] | None:
    """Return the most recent ACM row if any: manifest_id, created_at, git_commit, compile_profile, aimem_uri."""
    repo_root = find_git_root(repo_root_or_child)
    memory_root = repo_root / ".ai_memory"
    db_path = index_db_path(repo_root)
    if db_path.exists():
        with sqlite3.connect(db_path) as connection:
            connection.row_factory = sqlite3.Row
            ensure_governance_schema(connection)
            row = connection.execute(
                """
                SELECT manifest_id, created_at, git_commit, payload_json
                FROM context_manifests
                ORDER BY created_at DESC
                LIMIT 1
                """,
            ).fetchone()
        if row is not None:
            compile_profile: str | None = None
            try:
                payload = json.loads(str(row["payload_json"]))
                comp = payload.get("compile")
                if isinstance(comp, dict):
                    compile_profile = str(comp.get("profile") or "") or None
            except (json.JSONDecodeError, TypeError, ValueError):
                compile_profile = None
            mid = str(row["manifest_id"])
            return {
                "manifest_id": mid,
                "created_at": str(row["created_at"]),
                "git_commit": str(row["git_commit"] or ""),
                "compile_profile": compile_profile,
                "aimem_uri": f"aimem://manifest/{mid}",
            }

    manifests_dir = memory_root / "journal" / "manifests"
    if not manifests_dir.is_dir():
        return None
    candidates = sorted(manifests_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for path in candidates:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        mid = str(payload.get("manifest_id") or path.stem)
        created = str(payload.get("created_at") or "")
        repo = payload.get("repo")
        git_c = ""
        if isinstance(repo, dict):
            git_c = str(repo.get("git_commit") or "")
        compile_profile = None
        comp = payload.get("compile")
        if isinstance(comp, dict):
            compile_profile = str(comp.get("profile") or "") or None
        return {
            "manifest_id": mid,
            "created_at": created,
            "git_commit": git_c,
            "compile_profile": compile_profile,
            "aimem_uri": f"aimem://manifest/{mid}",
        }
    return None


def read_head_commit(repo_root: Path) -> str:
    output = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    return output.stdout.strip() if output.returncode == 0 else ""


def read_current_branch(repo_root: Path) -> str:
    output = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "--abbrev-ref", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    return output.stdout.strip() if output.returncode == 0 else ""


def is_working_tree_dirty(repo_root: Path) -> bool:
    output = subprocess.run(
        ["git", "-C", str(repo_root), "status", "--porcelain"],
        check=False,
        capture_output=True,
        text=True,
    )
    if output.returncode != 0:
        return False
    return bool(output.stdout.strip())
