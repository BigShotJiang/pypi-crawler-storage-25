"""Agent context bundle: assembly facade over sections and serializers."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from aimem.core.agent_context_budget import split_content_budget
from aimem.core.agent_context_models import (
    DEFAULT_CONTEXT_OBJECTIVE,
    BUNDLE_SCHEMA_VERSION,
    AgentContextBundle,
    PinnedEntry,
    RepositorySection,
)
from aimem.core.agent_context_sections import (
    build_acm_section,
    build_drift_dicts,
    build_pinned_entries,
    build_repository_section,
    build_retrieval_dict,
)
from aimem.core.agent_context_serialize import (
    bundle_to_dict,
    bundle_to_json,
    render_agent_context_bundle,
)
from aimem.core.memory import load_manifest
from aimem.core.repo import find_git_root

# Re-export public surface (backward compatibility).
__all__ = [
    "DEFAULT_CONTEXT_OBJECTIVE",
    "BUNDLE_SCHEMA_VERSION",
    "RepositorySection",
    "PinnedEntry",
    "AgentContextBundle",
    "build_agent_context_bundle",
    "render_agent_context_bundle",
    "bundle_to_dict",
    "bundle_to_json",
    "build_agent_context",
]


def build_agent_context_bundle(
    repo_root_or_child: Path,
    *,
    profile: str = "bootstrap",
    objective: str | None = None,
    top_k: int = 5,
    max_chars: int = 12000,
    after_compile: bool = False,
    compile_profile: str | None = None,
    compile_objective: str | None = None,
    allow_secrets_compile: bool = False,
) -> AgentContextBundle:
    """Collect repo meta, pinned excerpts, retrieval, drift, and ACM summaries under explicit char budgets."""
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    _, pinned_budget, retrieval_budget = split_content_budget(max_chars)

    return AgentContextBundle(
        bundle_schema_version=BUNDLE_SCHEMA_VERSION,
        profile=profile,
        repository=build_repository_section(repo_root, manifest),
        pinned=build_pinned_entries(repo_root, manifest, profile, pinned_budget=pinned_budget),
        retrieval=build_retrieval_dict(
            repo_root,
            objective=objective,
            top_k=top_k,
            retrieval_budget=retrieval_budget,
        ),
        drift=build_drift_dicts(repo_root),
        acm=build_acm_section(
            repo_root,
            after_compile=after_compile,
            profile=profile,
            compile_profile=compile_profile,
            compile_objective=compile_objective,
            allow_secrets_compile=allow_secrets_compile,
        ),
    )


def build_agent_context(
    repo_root_or_child: Path,
    *,
    profile: str = "bootstrap",
    objective: str | None = None,
    top_k: int = 5,
    max_chars: int = 12000,
    output_format: Literal["markdown", "text", "json"] = "markdown",
    after_compile: bool = False,
    compile_profile: str | None = None,
    compile_objective: str | None = None,
    allow_secrets_compile: bool = False,
    json_max_chars: int | None = None,
) -> str:
    """Assemble a single agent-oriented bundle (markdown, text, or JSON)."""
    bundle = build_agent_context_bundle(
        repo_root_or_child,
        profile=profile,
        objective=objective,
        top_k=top_k,
        max_chars=max_chars,
        after_compile=after_compile,
        compile_profile=compile_profile,
        compile_objective=compile_objective,
        allow_secrets_compile=allow_secrets_compile,
    )
    if output_format == "json":
        return bundle_to_json(bundle, max_serialized_chars=json_max_chars)
    return render_agent_context_bundle(bundle, output_format, max_chars=max_chars)
