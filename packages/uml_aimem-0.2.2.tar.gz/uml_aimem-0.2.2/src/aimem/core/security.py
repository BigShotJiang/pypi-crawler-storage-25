from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from aimem.core.repo import RepoError


@dataclass(frozen=True)
class SecretFinding:
    detector: str
    severity: str
    snippet: str


AWS_ACCESS_KEY_RE = re.compile(r"\bAKIA[0-9A-Z]{16}\b")
GITHUB_TOKEN_RE = re.compile(r"\bghp_[A-Za-z0-9]{36}\b")
GENERIC_SECRET_RE = re.compile(
    r"(?i)\b(api[_-]?key|token|secret|password)\b\s*[:=]\s*['\"]?[A-Za-z0-9_\-+/=]{16,}['\"]?"
)


def scan_text_for_secrets(text: str) -> list[SecretFinding]:
    findings: list[SecretFinding] = []
    for match in AWS_ACCESS_KEY_RE.finditer(text):
        findings.append(SecretFinding(detector="aws_access_key", severity="high", snippet=match.group(0)))
    for match in GITHUB_TOKEN_RE.finditer(text):
        findings.append(SecretFinding(detector="github_token", severity="high", snippet=match.group(0)))
    for match in GENERIC_SECRET_RE.finditer(text):
        snippet = match.group(0)
        severity = "medium" if len(snippet) < 48 else "high"
        findings.append(SecretFinding(detector="generic_secret", severity=severity, snippet=snippet))
    return findings


def assert_no_high_secrets(text: str, *, allow_secrets: bool, context: str) -> list[SecretFinding]:
    findings = scan_text_for_secrets(text)
    if allow_secrets:
        return findings
    if any(finding.severity == "high" for finding in findings):
        raise RepoError(
            f"Potential high-confidence secret detected in {context}. "
            "Review content or pass --allow-secrets explicitly."
        )
    return findings


def scan_memory_files_for_secrets(memory_root: Path) -> list[tuple[Path, list[SecretFinding]]]:
    allowlist = load_allowlist(memory_root)
    results: list[tuple[Path, list[SecretFinding]]] = []
    for path in sorted(memory_root.rglob("*.md")):
        if any(part in {"generated", "cache", "index", "workspaces"} for part in path.parts):
            continue
        findings = [finding for finding in scan_text_for_secrets(path.read_text(encoding="utf-8")) if finding.detector not in allowlist]
        if findings:
            results.append((path, findings))
    return results


def load_allowlist(memory_root: Path) -> set[str]:
    allowlist_path = memory_root / "secrets.allowlist"
    if not allowlist_path.exists():
        return set()
    detectors: set[str] = set()
    for line in allowlist_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        detectors.add(stripped)
    return detectors
