from __future__ import annotations

from pathlib import Path

import yaml

from aimem.core.locking import acquire_memory_lock
from aimem.core.memory import parse_document
from aimem.core.repo import RepoError, find_git_root


def promote_document(
    repo_root_or_child: Path,
    *,
    relative_path: str,
    target_status: str,
    reviewer: str,
) -> Path:
    repo_root = find_git_root(repo_root_or_child)
    path = repo_root / ".ai_memory" / relative_path
    if not path.exists():
        raise RepoError(f"Document not found: .ai_memory/{relative_path}")
    with acquire_memory_lock(repo_root):
        doc = parse_document(path, repo_root)
        metadata = dict(doc.metadata)
        consensus = list(metadata.get("review_consensus") or [])
        if reviewer not in consensus:
            consensus.append(reviewer)
        metadata["review_consensus"] = consensus
        metadata["status"] = target_status
        metadata["verification_status"] = "reviewed" if target_status != "draft" else "unverified"
        frontmatter = yaml.safe_dump(metadata, sort_keys=False, allow_unicode=False)
        path.write_text(f"---\n{frontmatter}---\n{doc.body}", encoding="utf-8")
    return path
