from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class EmbeddingProvider(Protocol):
    def embed(self, texts: list[str]) -> list[list[float]]:
        ...


@dataclass(frozen=True)
class EmbeddingConfig:
    provider: str
    model: str
    dim: int


class NoopEmbeddingProvider:
    def __init__(self, dim: int) -> None:
        self._dim = dim

    def embed(self, texts: list[str]) -> list[list[float]]:
        # Deterministic zero vectors used when semantic extras are not installed.
        return [[0.0 for _ in range(self._dim)] for _ in texts]


def build_provider(config: EmbeddingConfig) -> EmbeddingProvider:
    provider = config.provider.strip().lower()
    if provider in {"local", "ollama", "openai"}:
        return NoopEmbeddingProvider(config.dim)
    return NoopEmbeddingProvider(config.dim)
