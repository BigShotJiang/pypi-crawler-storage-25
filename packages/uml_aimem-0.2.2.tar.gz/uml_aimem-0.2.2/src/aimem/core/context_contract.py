"""Shared request contract for ``aimem context`` and MCP ``get_agent_context_bundle``."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

ALLOWED_OUTPUT_FORMATS = frozenset({"markdown", "text", "json"})


class ContextContractError(ValueError):
    """Invalid context bundle request parameters."""


@dataclass(frozen=True)
class ContextBundleRequest:
    """Validated parameters for assembling an agent context bundle."""

    profile: str = "bootstrap"
    objective: str | None = None
    top_k: int = 5
    max_chars: int = 12000
    output_format: Literal["markdown", "text", "json"] = "markdown"
    after_compile: bool = False
    compile_profile: str | None = None
    compile_objective: str | None = None
    allow_secrets_compile: bool = False
    json_max_chars: int | None = None

    def validate(self) -> None:
        if self.output_format not in ALLOWED_OUTPUT_FORMATS:
            raise ContextContractError("format must be 'markdown', 'text', or 'json'.")
        if self.json_max_chars is not None and self.output_format != "json":
            raise ContextContractError("--json-max-chars is only valid with --format json.")
        if self.top_k < 1 or self.top_k > 20:
            raise ContextContractError("top_k must be between 1 and 20.")
        if self.max_chars < 2000 or self.max_chars > 100_000:
            raise ContextContractError("max_chars must be between 2000 and 100000.")
        if self.json_max_chars is not None and (
            self.json_max_chars < 2000 or self.json_max_chars > 500_000
        ):
            raise ContextContractError("json_max_chars must be between 2000 and 500000.")

    @classmethod
    def from_cli_args(
        cls,
        *,
        profile: str,
        objective: str | None,
        top_k: int,
        max_chars: int,
        output_format: str,
        after_compile: bool,
        compile_profile: str | None,
        compile_objective: str | None,
        allow_secrets_compile: bool,
        json_max_chars: int | None,
    ) -> ContextBundleRequest:
        fmt = output_format.strip().lower()
        request = cls(
            profile=profile,
            objective=objective,
            top_k=top_k,
            max_chars=max_chars,
            output_format=fmt,  # type: ignore[arg-type]
            after_compile=after_compile,
            compile_profile=compile_profile,
            compile_objective=compile_objective,
            allow_secrets_compile=allow_secrets_compile,
            json_max_chars=json_max_chars,
        )
        request.validate()
        return request

    @classmethod
    def from_mcp_args(
        cls,
        *,
        profile: str = "bootstrap",
        objective: str | None = None,
        top_k: int = 5,
        max_chars: int = 12000,
        after_compile: bool = False,
        compile_profile: str | None = None,
        compile_objective: str | None = None,
        allow_secrets_compile: bool = False,
        json_max_chars: int | None = None,
    ) -> ContextBundleRequest:
        request = cls(
            profile=profile,
            objective=objective,
            top_k=top_k,
            max_chars=max_chars,
            output_format="json",
            after_compile=after_compile,
            compile_profile=compile_profile,
            compile_objective=compile_objective,
            allow_secrets_compile=allow_secrets_compile,
            json_max_chars=json_max_chars,
        )
        request.validate()
        return request

    def bundle_builder_kwargs(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "objective": self.objective,
            "top_k": self.top_k,
            "max_chars": self.max_chars,
            "after_compile": self.after_compile,
            "compile_profile": self.compile_profile,
            "compile_objective": self.compile_objective,
            "allow_secrets_compile": self.allow_secrets_compile,
        }

    def agent_context_kwargs(self) -> dict[str, Any]:
        return {
            **self.bundle_builder_kwargs(),
            "output_format": self.output_format,
            "json_max_chars": self.json_max_chars,
        }


def build_context_string(repo_root_or_child: Path, request: ContextBundleRequest) -> str:
    """Render bundle as markdown, text, or JSON string (CLI path)."""
    from aimem.core.agent_context import build_agent_context

    return build_agent_context(repo_root_or_child, **request.agent_context_kwargs())


def build_context_dict(repo_root_or_child: Path, request: ContextBundleRequest) -> dict[str, Any]:
    """Structured bundle dict (MCP path; same payload as ``aimem context --format json``)."""
    from aimem.core.agent_context import build_agent_context_bundle, bundle_to_dict, bundle_to_json

    bundle = build_agent_context_bundle(repo_root_or_child, **request.bundle_builder_kwargs())
    if request.json_max_chars is None:
        return bundle_to_dict(bundle)
    payload = bundle_to_json(bundle, max_serialized_chars=request.json_max_chars)
    return json.loads(payload)
