from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from aimem.core.memory import (
    FRONTMATTER_REQUIRED_FIELDS,
    MemoryDocument,
    iter_canonical_documents,
    load_manifest,
    utc_now_iso,
)
from aimem.core.locking import acquire_memory_lock
from aimem.core.security import SecretFinding, scan_memory_files_for_secrets
from aimem.core.repo import RepoError, find_git_root, read_head_commit


@dataclass(frozen=True)
class VerifyItem:
    relative_path: str
    status: str
    reason: str


@dataclass(frozen=True)
class VerifyReport:
    manifest_ok: bool
    items: list[VerifyItem]
    secret_findings: list[VerifyItem]
    retrieval_index_note: str | None = None

    @property
    def has_failures(self) -> bool:
        if not self.manifest_ok:
            return True
        failing_item = any(item.status in {"stale", "invalid"} for item in self.items)
        high_secret = any(item.status == "invalid" for item in self.secret_findings)
        return failing_item or high_secret

    def render_lines(self) -> list[str]:
        lines = [f"Manifest: {'ok' if self.manifest_ok else 'invalid'}"]
        if self.retrieval_index_note:
            lines.append(f"NOTE: {self.retrieval_index_note}")
        for item in self.items:
            lines.append(f"{item.status.upper():9} .ai_memory/{item.relative_path} - {item.reason}")
        for finding in self.secret_findings:
            lines.append(f"{finding.status.upper():9} .ai_memory/{finding.relative_path} - {finding.reason}")
        return lines


def check_retrieval_index_coherent(repo_root: Path, canonical_docs: list[MemoryDocument]) -> str | None:
    """Return a human note if the SQLite FTS backing store is missing or out of sync with canonical paths."""

    expected = {doc.relative_path.as_posix() for doc in canonical_docs}
    db_path = repo_root / ".ai_memory" / "index" / "aimem.sqlite"
    if not db_path.exists():
        if not expected:
            return None
        return "Retrieval index not built yet (.ai_memory/index/aimem.sqlite missing). Run `aimem query` or `aimem index rebuild`."
    try:
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='documents'",
            ).fetchall()
            if not rows:
                return "Retrieval index database exists but has no `documents` table; run `aimem index rebuild`."
            indexed_rows = conn.execute("SELECT relative_path FROM documents").fetchall()
    except sqlite3.Error as exc:
        return f"Retrieval index unreadable ({exc}); run `aimem index rebuild`."
    indexed = {str(row[0]) for row in indexed_rows}
    if expected == indexed:
        return None
    only_canonical = expected - indexed
    only_index = indexed - expected
    parts: list[str] = []
    if only_canonical:
        parts.append(f"{len(only_canonical)} canonical path(s) missing from index")
    if only_index:
        parts.append(f"{len(only_index)} orphan row(s) in index")
    detail = "; ".join(parts) if parts else "path set mismatch"
    return f"Retrieval index may be stale ({detail}). Run `aimem index rebuild`."


def verify_memory(
    repo_root_or_child: Path,
    *,
    strict: bool = False,
    check_retrieval_index: bool = False,
) -> VerifyReport:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    manifest_ok = manifest_is_valid(manifest)
    include_paths = manifest["paths"]["canonical"]
    documents = iter_canonical_documents(repo_root, include_paths)
    head_commit = read_head_commit(repo_root)
    items = [verify_document(repo_root, document, head_commit, strict=strict) for document in documents]
    items.extend(verify_claim_consistency(documents, strict=strict))
    secrets = verify_secrets(repo_root / ".ai_memory")
    index_note = check_retrieval_index_coherent(repo_root, documents) if check_retrieval_index else None
    return VerifyReport(
        manifest_ok=manifest_ok,
        items=items,
        secret_findings=secrets,
        retrieval_index_note=index_note,
    )


def refresh_memory_verification(repo_root_or_child: Path) -> int:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    include_paths = manifest["paths"]["canonical"]
    documents = iter_canonical_documents(repo_root, include_paths)
    head_commit = read_head_commit(repo_root)
    refreshed = 0

    for document in documents:
        if not can_refresh_document(document.metadata):
            continue
        with acquire_memory_lock(repo_root):
            refresh_document_verification(document.path, document.body, document.metadata, head_commit)
            refreshed += 1

    return refreshed


def manifest_is_valid(manifest: dict[str, Any]) -> bool:
    required_top_level = {"schema_version", "product", "paths", "compile_profiles", "policies", "retention", "aimem_drift"}
    if not required_top_level.issubset(manifest.keys()):
        return False
    if not isinstance(manifest.get("paths", {}).get("canonical"), list):
        return False
    drift = manifest.get("aimem_drift", {})
    if not isinstance(drift, dict):
        return False
    if not isinstance(drift.get("baseline"), dict):
        return False
    if not isinstance(drift.get("budget"), dict):
        return False
    return True


def can_refresh_document(metadata: dict[str, Any]) -> bool:
    if any(field not in metadata for field in FRONTMATTER_REQUIRED_FIELDS):
        return False
    verified_from = metadata.get("verified_from") or {}
    return isinstance(verified_from, dict)


def refresh_document_verification(path: Path, body: str, metadata: dict[str, Any], head_commit: str | None) -> None:
    refreshed = dict(metadata)
    verified_from = dict(refreshed.get("verified_from") or {})
    verified_from["git_commit"] = head_commit
    existing_files = verified_from.get("files") or []
    verified_from["files"] = existing_files if isinstance(existing_files, list) else []
    refreshed["verified_from"] = verified_from
    refreshed["verified_at"] = utc_now_iso()
    frontmatter = yaml.safe_dump(normalize_yaml_value(refreshed), sort_keys=False, allow_unicode=False)
    path.write_text(f"---\n{frontmatter}---\n{body}", encoding="utf-8")


def normalize_yaml_value(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    if isinstance(value, dict):
        return {key: normalize_yaml_value(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_yaml_value(item) for item in value]
    return value


def verify_document(repo_root: Path, document: Any, head_commit: str | None, *, strict: bool) -> VerifyItem:
    missing_fields = [field for field in FRONTMATTER_REQUIRED_FIELDS if field not in document.metadata]
    status = str(document.metadata.get("status", "")).lower()
    allowed_statuses = {
        "draft",
        "reviewed",
        "gold",
        "deprecated",
        "active",
        "in_progress",
        "proposed",
        "accepted",
        "completed",
    }
    if status not in allowed_statuses:
        return VerifyItem(document.relative_path.as_posix(), "invalid", f"unsupported status '{status}'")

    if status == "gold":
        criticality = str(document.metadata.get("criticality", "medium")).lower()
        review_consensus = document.metadata.get("review_consensus") or []
        if not isinstance(review_consensus, list):
            return VerifyItem(document.relative_path.as_posix(), "invalid", "review_consensus must be a list")
        if strict and criticality == "high" and len(review_consensus) < 2:
            return VerifyItem(document.relative_path.as_posix(), "invalid", "gold/high requires at least 2 reviewers in strict mode")

    if status == "deprecated":
        superseded_by = document.metadata.get("superseded_by")
        if not superseded_by:
            return VerifyItem(document.relative_path.as_posix(), "invalid", "deprecated documents must include superseded_by")

    verification_status = str(document.metadata.get("verification_status", "unverified")).lower()
    allowed_verification = {"unverified", "reviewed", "verified", "drifted"}
    if verification_status not in allowed_verification:
        return VerifyItem(
            document.relative_path.as_posix(),
            "invalid",
            f"unsupported verification_status '{verification_status}'",
        )

    if missing_fields:
        return VerifyItem(document.relative_path.as_posix(), "invalid", f"missing fields: {', '.join(missing_fields)}")

    verified_at_raw = document.metadata.get("verified_at")
    verified_from = document.metadata.get("verified_from") or {}
    if not isinstance(verified_from, dict):
        return VerifyItem(document.relative_path.as_posix(), "invalid", "verified_from must be a mapping")

    if not verified_at_raw:
        return VerifyItem(document.relative_path.as_posix(), "unverified", "no verified_at timestamp")

    try:
        verified_at = parse_iso_timestamp(str(verified_at_raw))
    except ValueError:
        return VerifyItem(document.relative_path.as_posix(), "invalid", "verified_at is not a valid ISO timestamp")

    if is_stale_for_commit(verified_from, head_commit):
        return VerifyItem(document.relative_path.as_posix(), "stale", "verified commit differs from current HEAD")

    stale_files = stale_verified_files(repo_root, verified_from, verified_at)
    if stale_files:
        return VerifyItem(document.relative_path.as_posix(), "stale", f"referenced files changed or missing: {', '.join(stale_files)}")

    return VerifyItem(document.relative_path.as_posix(), "ok", "fresh")


def verify_secrets(memory_root: Path) -> list[VerifyItem]:
    findings: list[VerifyItem] = []
    for path, path_findings in scan_memory_files_for_secrets(memory_root):
        rel = path.relative_to(memory_root).as_posix()
        for finding in path_findings:
            findings.append(secret_to_item(rel, finding))
    return findings


def secret_to_item(relative_path: str, finding: SecretFinding) -> VerifyItem:
    status = "invalid" if finding.severity == "high" else "warn"
    reason = f"secret:{finding.detector} severity={finding.severity} snippet={finding.snippet[:40]}"
    return VerifyItem(relative_path, status, reason)


def is_stale_for_commit(verified_from: dict[str, Any], head_commit: str | None) -> bool:
    verified_commit = verified_from.get("git_commit")
    if not verified_commit or not head_commit:
        return False
    return str(verified_commit) != head_commit


def stale_verified_files(repo_root: Path, verified_from: dict[str, Any], verified_at: datetime) -> list[str]:
    stale_paths: list[str] = []
    file_paths = verified_from.get("files") or []
    if not isinstance(file_paths, list):
        return ["<verified_from.files must be a list>"]
    for item in file_paths:
        path = repo_root / str(item)
        if not path.exists():
            stale_paths.append(str(item))
            continue
        modified_at = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
        if modified_at > verified_at:
            stale_paths.append(str(item))
    return stale_paths


def parse_iso_timestamp(value: str) -> datetime:
    normalized = value.replace("Z", "+00:00")
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include timezone")
    return parsed.astimezone(timezone.utc)


def verify_claim_consistency(documents: list[Any], *, strict: bool) -> list[VerifyItem]:
    by_claim_id: dict[str, str] = {}
    by_assertion: dict[str, str] = {}
    issues: list[VerifyItem] = []
    for document in documents:
        status = str(document.metadata.get("status", "")).lower()
        if status != "gold":
            continue
        claims = document.metadata.get("aimem_claims") or []
        if not isinstance(claims, list):
            continue
        for raw in claims:
            if not isinstance(raw, dict):
                continue
            claim_id = str(raw.get("id", "")).strip()
            assertion = " ".join(str(raw.get("assertion", "")).strip().lower().split())
            rel = document.relative_path.as_posix()
            if claim_id:
                previous = by_claim_id.get(claim_id)
                if previous and previous != rel:
                    issues.append(VerifyItem(rel, "invalid", f"duplicate claim id '{claim_id}' also in {previous}"))
                by_claim_id[claim_id] = rel
            if strict and assertion:
                previous_assertion = by_assertion.get(assertion)
                if previous_assertion and previous_assertion != rel:
                    issues.append(
                        VerifyItem(
                            rel,
                            "invalid",
                            f"possible contradictory gold claims: assertion overlaps with {previous_assertion}",
                        )
                    )
                by_assertion[assertion] = rel
    return issues
