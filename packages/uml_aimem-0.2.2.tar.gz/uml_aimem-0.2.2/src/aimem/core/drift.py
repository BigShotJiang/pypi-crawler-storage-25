from __future__ import annotations

import copy
import json
import re
import sqlite3
import subprocess
import uuid
from collections import defaultdict
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

import yaml

from aimem.core.locking import acquire_memory_lock
from aimem.core.memory import iter_canonical_documents, load_manifest, split_frontmatter, utc_now_iso
from aimem.core.repo import RepoError, find_git_root


@dataclass(frozen=True)
class DriftClaim:
    claim_id: str
    doc_path: str
    doc_id: str
    assertion: str
    enforce_when: str
    rule: dict[str, Any]
    trust_score: float
    indexed_at: str


@dataclass(frozen=True)
class DriftEvent:
    event_id: str
    claim_id: str
    scan_id: str
    drift_score: float
    severity: str
    evidence_json: str
    status: str
    created_at: str


@dataclass(frozen=True)
class DriftScanReport:
    scan_id: str
    claim_count: int
    event_count: int
    events: list[DriftEvent]


@dataclass(frozen=True)
class DriftSettings:
    ignore_globs: list[str]
    max_files_opened: int
    max_file_bytes_each: int
    max_total_bytes_read: int
    max_rule_nodes_evaluated: int


@dataclass
class RuleEvalState:
    nodes_evaluated: int = 0
    files_opened: int = 0
    bytes_read: int = 0


def run_drift_scan(repo_root_or_child: Path) -> DriftScanReport:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    ensure_drift_manifest_defaults(manifest)
    settings = parse_drift_settings(manifest)
    include_paths = list(manifest["paths"]["canonical"])
    claims = extract_claims(repo_root, include_paths=include_paths)
    db_path = repo_root / ".ai_memory" / "index" / "aimem.sqlite"
    db_path.parent.mkdir(parents=True, exist_ok=True)

    scan_id = str(uuid.uuid4())
    changed_paths = resolve_changed_paths(repo_root, manifest)
    repo_paths = list_repo_paths(repo_root, ignore_globs=settings.ignore_globs)
    events: list[DriftEvent] = []
    now = utc_now_iso()
    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=3000")
        ensure_drift_tables(connection)
        upsert_claims(connection, claims)
        for claim in claims:
            event = evaluate_claim(
                repo_root,
                claim=claim,
                changed_paths=changed_paths,
                repo_paths=repo_paths,
                settings=settings,
                scan_id=scan_id,
                created_at=now,
            )
            if event is None:
                continue
            events.append(event)
            connection.execute(
                """
                INSERT INTO drift_events (
                    event_id, claim_id, scan_id, drift_score, severity, evidence_json, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    event.event_id,
                    event.claim_id,
                    event.scan_id,
                    event.drift_score,
                    event.severity,
                    event.evidence_json,
                    event.status,
                    event.created_at,
                ),
            )
        connection.commit()
    return DriftScanReport(scan_id=scan_id, claim_count=len(claims), event_count=len(events), events=events)


def list_open_drift_events(repo_root_or_child: Path, *, limit: int = 50) -> list[DriftEvent]:
    repo_root = find_git_root(repo_root_or_child)
    db_path = repo_root / ".ai_memory" / "index" / "aimem.sqlite"
    if not db_path.exists():
        return []
    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=3000")
        connection.row_factory = sqlite3.Row
        ensure_drift_tables(connection)
        rows = connection.execute(
            """
            SELECT event_id, claim_id, scan_id, drift_score, severity, evidence_json, status, created_at
            FROM drift_events
            WHERE status IN ('open', 'reviewed')
            ORDER BY created_at DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return [
        DriftEvent(
            event_id=str(row["event_id"]),
            claim_id=str(row["claim_id"]),
            scan_id=str(row["scan_id"]),
            drift_score=float(row["drift_score"]),
            severity=str(row["severity"]),
            evidence_json=str(row["evidence_json"]),
            status=str(row["status"]),
            created_at=str(row["created_at"]),
        )
        for row in rows
    ]


def reconcile_drift_events(repo_root_or_child: Path, *, claim_id: str | None = None) -> Path | None:
    repo_root = find_git_root(repo_root_or_child)
    events = list_open_drift_events(repo_root)
    selected = [event for event in events if claim_id is None or event.claim_id == claim_id]
    if not selected:
        return None

    capsules_dir = repo_root / ".ai_memory" / "journal" / "capsules"
    capsules_dir.mkdir(parents=True, exist_ok=True)
    capsule_id = f"capsule-{utc_now_iso().replace(':', '').replace('-', '').replace('T', '-').replace('Z', '')}"
    capsule_path = capsules_dir / f"{capsule_id}.md"
    lines = [
        "---",
        f"id: {capsule_id}",
        "kind: capsule",
        "status: reviewed",
        "criticality: medium",
        "owner: shared",
        "edit_policy: approved_agent",
        f"updated_at: '{utc_now_iso()}'",
        f"verified_at: '{utc_now_iso()}'",
        "verified_from:",
        "  git_commit: null",
        "  files: []",
        "trust_score: 0.8",
        "source_agent: aimem",
        "verification_status: reviewed",
        "review_consensus:",
        "  - human",
        "confidence: medium",
        "sources:",
        "  - drift_scan",
        f"created_at: '{utc_now_iso()}'",
        "source_events:",
    ]
    for event in selected:
        lines.append(f"  - {event.event_id}")
    lines.extend(
        [
            "---",
            "# Drift Capsule",
            "",
            "## Summary",
            "",
            "Open drift events were consolidated for review.",
            "",
            "## Events",
            "",
        ]
    )
    for event in selected:
        lines.append(f"- claim_id: `{event.claim_id}` severity: `{event.severity}` score: `{event.drift_score:.2f}`")
    capsule_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

    db_path = repo_root / ".ai_memory" / "index" / "aimem.sqlite"
    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=3000")
        ensure_drift_tables(connection)
        event_ids = [event.event_id for event in selected]
        placeholders = ", ".join("?" for _ in event_ids)
        connection.execute(
            f"UPDATE drift_events SET status = 'reviewed' WHERE event_id IN ({placeholders})",
            event_ids,
        )
        connection.commit()
    return capsule_path


def extract_claims(repo_root: Path, *, include_paths: list[str]) -> list[DriftClaim]:
    claims: list[DriftClaim] = []
    seen: set[str] = set()
    now = utc_now_iso()
    documents = iter_canonical_documents(repo_root, include_paths)
    for document in documents:
        status = str(document.metadata.get("status", "")).strip().lower()
        raw_claims = document.metadata.get("aimem_claims") or []
        if not isinstance(raw_claims, list):
            continue
        for raw_claim in raw_claims:
            if not isinstance(raw_claim, dict):
                continue
            claim_id = str(raw_claim.get("id", "")).strip()
            if not claim_id:
                continue
            if not re.match(r"^[a-z0-9][a-z0-9._-]{1,63}$", claim_id):
                raise RepoError(f"Invalid claim id '{claim_id}' in {document.relative_path.as_posix()}")
            if claim_id in seen:
                raise RepoError(f"Duplicate claim id '{claim_id}' found in canonical memory.")
            seen.add(claim_id)

            enforce_when = str(raw_claim.get("enforce_when", "gold_only")).strip().lower()
            if enforce_when not in {"gold_only", "reviewed_and_gold", "always"}:
                raise RepoError(f"Unsupported enforce_when '{enforce_when}' for claim '{claim_id}'.")
            if enforce_when == "gold_only" and status != "gold":
                continue
            if enforce_when == "reviewed_and_gold" and status not in {"reviewed", "gold"}:
                continue

            assertion = str(raw_claim.get("assertion", "")).strip()
            if not assertion:
                raise RepoError(f"Claim '{claim_id}' is missing assertion.")
            if len(assertion) > 500:
                raise RepoError(f"Claim '{claim_id}' assertion exceeds 500 characters.")

            rule = raw_claim.get("rule")
            if not isinstance(rule, dict):
                raise RepoError(f"Claim '{claim_id}' must provide a rule object.")
            validate_rule_expr(rule)
            claims.append(
                DriftClaim(
                    claim_id=claim_id,
                    doc_path=document.relative_path.as_posix(),
                    doc_id=str(document.metadata.get("id", "")),
                    assertion=assertion,
                    enforce_when=enforce_when,
                    rule=rule,
                    trust_score=float(document.metadata.get("trust_score", 0.5)),
                    indexed_at=now,
                )
            )
    return claims


def validate_rule_expr(rule: dict[str, Any], *, depth: int = 0) -> None:
    if depth > 16:
        raise RepoError("Rule expression nesting depth exceeds limit.")
    kind = str(rule.get("type", "")).strip()
    if kind in {"all_of", "any_of"}:
        children = rule.get("of")
        if not isinstance(children, list) or not (1 <= len(children) <= 32):
            raise RepoError(f"Rule '{kind}' requires 1..32 children.")
        for child in children:
            if not isinstance(child, dict):
                raise RepoError(f"Rule '{kind}' children must be objects.")
            validate_rule_expr(child, depth=depth + 1)
        return
    if kind == "not":
        child = rule.get("of")
        if not isinstance(child, dict):
            raise RepoError("Rule 'not' requires an object in 'of'.")
        validate_rule_expr(child, depth=depth + 1)
        return
    if kind in {"path_exists", "path_not_exists"}:
        if not str(rule.get("glob", "")).strip():
            raise RepoError(f"Rule '{kind}' requires non-empty glob.")
        return
    if kind in {"file_contains", "file_not_contains"}:
        if not str(rule.get("glob", "")).strip():
            raise RepoError(f"Rule '{kind}' requires non-empty glob.")
        if not str(rule.get("pattern", "")).strip():
            raise RepoError(f"Rule '{kind}' requires regex pattern.")
        return
    if kind == "git_path_changed":
        if not str(rule.get("glob", "")).strip():
            raise RepoError("Rule 'git_path_changed' requires non-empty glob.")
        return
    if kind == "lockfile_dep":
        lockfile = str(rule.get("lockfile", "")).strip()
        if lockfile not in {"uv.lock", "pyproject.toml", "package-lock.json", "pnpm-lock.yaml", "Cargo.lock"}:
            raise RepoError("Rule 'lockfile_dep' uses unsupported lockfile.")
        if not str(rule.get("name", "")).strip():
            raise RepoError("Rule 'lockfile_dep' requires dependency name.")
        if not isinstance(rule.get("present"), bool):
            raise RepoError("Rule 'lockfile_dep' requires boolean 'present'.")
        return
    if kind == "import_present":
        if str(rule.get("language", "")).strip().lower() != "python":
            raise RepoError("Rule 'import_present' currently supports only python language.")
        if not str(rule.get("module", "")).strip():
            raise RepoError("Rule 'import_present' requires module.")
        if not str(rule.get("under_glob", "")).strip():
            raise RepoError("Rule 'import_present' requires under_glob.")
        return
    raise RepoError(f"Unsupported rule type '{kind}'.")


def evaluate_claim(
    repo_root: Path,
    *,
    claim: DriftClaim,
    changed_paths: list[str],
    repo_paths: list[str],
    settings: DriftSettings,
    scan_id: str,
    created_at: str,
) -> DriftEvent | None:
    state = RuleEvalState()
    matched = evaluate_rule(
        repo_root,
        claim.rule,
        changed_paths=changed_paths,
        repo_paths=repo_paths,
        settings=settings,
        state=state,
    )
    if matched:
        return None
    evidence = {
        "changed_paths": changed_paths[:200],
        "rule": claim.rule,
        "assertion": claim.assertion,
        "evaluation": {
            "nodes_evaluated": state.nodes_evaluated,
            "files_opened": state.files_opened,
            "bytes_read": state.bytes_read,
        },
    }
    drift_score = min(1.0, max(0.1, 1.0 - claim.trust_score / 2.0))
    if drift_score >= 0.85:
        severity = "critical"
    elif drift_score >= 0.7:
        severity = "high"
    else:
        severity = "medium"
    return DriftEvent(
        event_id=str(uuid.uuid4()),
        claim_id=claim.claim_id,
        scan_id=scan_id,
        drift_score=drift_score,
        severity=severity,
        evidence_json=json.dumps(evidence, sort_keys=True),
        status="open",
        created_at=created_at,
    )


def evaluate_rule(
    repo_root: Path,
    rule: dict[str, Any],
    *,
    changed_paths: list[str],
    repo_paths: list[str],
    settings: DriftSettings,
    state: RuleEvalState,
) -> bool:
    state.nodes_evaluated += 1
    if state.nodes_evaluated > settings.max_rule_nodes_evaluated:
        raise RepoError("Rule evaluation exceeded max_rule_nodes_evaluated budget.")
    kind = str(rule.get("type", "")).strip()
    if kind == "all_of":
        return all(
            evaluate_rule(
                repo_root,
                child,
                changed_paths=changed_paths,
                repo_paths=repo_paths,
                settings=settings,
                state=state,
            )
            for child in rule["of"]
        )
    if kind == "any_of":
        return any(
            evaluate_rule(
                repo_root,
                child,
                changed_paths=changed_paths,
                repo_paths=repo_paths,
                settings=settings,
                state=state,
            )
            for child in rule["of"]
        )
    if kind == "not":
        return not evaluate_rule(
            repo_root,
            rule["of"],
            changed_paths=changed_paths,
            repo_paths=repo_paths,
            settings=settings,
            state=state,
        )
    if kind == "path_exists":
        glob = str(rule["glob"])
        return any(fnmatch(path, glob) for path in repo_paths)
    if kind == "path_not_exists":
        glob = str(rule["glob"])
        return not any(fnmatch(path, glob) for path in repo_paths)
    if kind == "git_path_changed":
        glob = str(rule["glob"])
        return any(fnmatch(path, glob) for path in changed_paths)
    if kind in {"file_contains", "file_not_contains"}:
        glob = str(rule["glob"])
        regex = re.compile(str(rule["pattern"]), parse_regex_flags(rule.get("flags")))
        found = False
        for path in repo_paths:
            if not fnmatch(path, glob):
                continue
            text = read_with_budget(repo_root / path, settings=settings, state=state)
            if regex.search(text):
                found = True
                break
        return found if kind == "file_contains" else (not found)
    if kind == "lockfile_dep":
        lockfile = repo_root / str(rule["lockfile"])
        content = lockfile.read_text(encoding="utf-8", errors="ignore") if lockfile.exists() else ""
        dep_name = str(rule["name"])
        present = bool(rule["present"])
        found = dep_name in content
        version_regex = str(rule.get("version_regex", "")).strip()
        if found and version_regex:
            found = re.search(version_regex, content) is not None
        return found if present else (not found)
    if kind == "import_present":
        module = str(rule["module"])
        under_glob = str(rule["under_glob"])
        import_pattern = re.compile(rf"(^|\n)\s*(from\s+{re.escape(module)}\s+import|import\s+{re.escape(module)}(\s|$))")
        for path in repo_paths:
            if not fnmatch(path, under_glob):
                continue
            if not path.endswith(".py"):
                continue
            text = read_with_budget(repo_root / path, settings=settings, state=state)
            if import_pattern.search(text):
                return True
        return False
    raise RepoError(f"Unsupported rule type '{kind}'.")


def parse_regex_flags(raw_flags: Any) -> int:
    if not isinstance(raw_flags, list):
        return 0
    bits = 0
    for raw_flag in raw_flags:
        flag = str(raw_flag).strip().upper()
        if flag == "IGNORECASE":
            bits |= re.IGNORECASE
        elif flag == "MULTILINE":
            bits |= re.MULTILINE
    return bits


def resolve_changed_paths(repo_root: Path, manifest: dict[str, Any]) -> list[str]:
    drift = manifest.get("aimem_drift", {})
    baseline = drift.get("baseline", {}) if isinstance(drift, dict) else {}
    compare_to_ref = str(baseline.get("compare_to_ref", "HEAD"))
    if compare_to_ref == "MERGE_BASE_MAIN":
        base = resolve_merge_base(repo_root)
    else:
        base = compare_to_ref
    command = ["git", "-C", str(repo_root), "diff", "--name-only", base]
    output = subprocess.run(command, check=False, capture_output=True, text=True)
    if output.returncode != 0:
        return []
    return [line.strip() for line in output.stdout.splitlines() if line.strip()]


def resolve_merge_base(repo_root: Path) -> str:
    for candidate in ("main", "origin/main"):
        output = subprocess.run(
            ["git", "-C", str(repo_root), "merge-base", "HEAD", candidate],
            check=False,
            capture_output=True,
            text=True,
        )
        if output.returncode == 0 and output.stdout.strip():
            return output.stdout.strip()
    return "HEAD"


def list_repo_paths(repo_root: Path, *, ignore_globs: list[str]) -> list[str]:
    tracked = subprocess.run(
        ["git", "-C", str(repo_root), "ls-files"],
        check=False,
        capture_output=True,
        text=True,
    )
    if tracked.returncode != 0:
        return []
    untracked = subprocess.run(
        ["git", "-C", str(repo_root), "ls-files", "--others", "--exclude-standard"],
        check=False,
        capture_output=True,
        text=True,
    )
    paths = {line.strip() for line in tracked.stdout.splitlines() if line.strip()}
    if untracked.returncode == 0:
        for line in untracked.stdout.splitlines():
            line = line.strip()
            if line:
                paths.add(line)
    filtered: list[str] = []
    for path in sorted(paths):
        if any(fnmatch(path, glob) for glob in ignore_globs):
            continue
        filtered.append(path)
    return filtered


def ensure_drift_manifest_defaults(manifest: dict[str, Any]) -> None:
    drift = manifest.setdefault("aimem_drift", {})
    if not isinstance(drift, dict):
        manifest["aimem_drift"] = {}
        drift = manifest["aimem_drift"]
    if not isinstance(drift.get("baseline"), dict):
        drift["baseline"] = {}
    if not isinstance(drift.get("budget"), dict):
        drift["budget"] = {}


def parse_drift_settings(manifest: dict[str, Any]) -> DriftSettings:
    drift = manifest.get("aimem_drift", {})
    budget = drift.get("budget", {}) if isinstance(drift, dict) else {}
    ignore_globs_raw = drift.get("ignore_globs", []) if isinstance(drift, dict) else []
    ignore_globs = [str(item).strip() for item in ignore_globs_raw if str(item).strip()]
    return DriftSettings(
        ignore_globs=ignore_globs,
        max_files_opened=max(1, int(budget.get("max_files_opened", 8000))),
        max_file_bytes_each=max(1, int(budget.get("max_file_bytes_each", 1048576))),
        max_total_bytes_read=max(1, int(budget.get("max_total_bytes_read", 52428800))),
        max_rule_nodes_evaluated=max(1, int(budget.get("max_rule_nodes_evaluated", 20000))),
    )


def read_with_budget(path: Path, *, settings: DriftSettings, state: RuleEvalState) -> str:
    if state.files_opened >= settings.max_files_opened:
        raise RepoError("Rule evaluation exceeded max_files_opened budget.")
    if not path.exists():
        return ""
    file_size = path.stat().st_size
    if file_size > settings.max_file_bytes_each:
        raise RepoError(f"Rule evaluation skipped oversized file: {path}")
    if state.bytes_read + file_size > settings.max_total_bytes_read:
        raise RepoError("Rule evaluation exceeded max_total_bytes_read budget.")
    state.files_opened += 1
    state.bytes_read += file_size
    return path.read_text(encoding="utf-8", errors="ignore")


def ensure_drift_tables(connection: sqlite3.Connection) -> None:
    """Backward-compatible alias; schema lives in ``sqlite_index``."""
    from aimem.core.sqlite_index import ensure_governance_schema

    ensure_governance_schema(connection)
    connection.commit()


def upsert_claims(connection: sqlite3.Connection, claims: list[DriftClaim]) -> None:
    connection.execute("DELETE FROM gold_claims")
    for claim in claims:
        connection.execute(
            """
            INSERT INTO gold_claims (
                claim_id, doc_path, doc_id, assertion, enforce_when, rule_json, trust_score, indexed_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                claim.claim_id,
                claim.doc_path,
                claim.doc_id,
                claim.assertion,
                claim.enforce_when,
                json.dumps(claim.rule, sort_keys=True),
                claim.trust_score,
                claim.indexed_at,
            ),
        )
    connection.commit()


_SEVERITY_RANK = {"low": 1, "medium": 2, "high": 3, "critical": 4}


def severity_rank(severity: str) -> int:
    return _SEVERITY_RANK.get(str(severity).strip().lower(), 1)


def parse_governance_apply_threshold(manifest: dict[str, Any]) -> int:
    drift = manifest.get("aimem_drift", {})
    gov = drift.get("governance_apply") if isinstance(drift, dict) else None
    if not isinstance(gov, dict):
        gov = {}
    token = str(gov.get("min_severity", "high")).strip().lower()
    if token not in _SEVERITY_RANK:
        return severity_rank("high")
    return severity_rank(token)


def _open_drift_rows_with_doc_paths(repo_root: Path) -> list[tuple[DriftEvent, str]]:
    db_path = repo_root / ".ai_memory" / "index" / "aimem.sqlite"
    if not db_path.exists():
        return []
    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=3000")
        connection.row_factory = sqlite3.Row
        ensure_drift_tables(connection)
        rows = connection.execute(
            """
            SELECT
                e.event_id,
                e.claim_id,
                e.scan_id,
                e.drift_score,
                e.severity,
                e.evidence_json,
                e.status,
                e.created_at,
                g.doc_path
            FROM drift_events e
            JOIN gold_claims g ON g.claim_id = e.claim_id
            WHERE e.status = 'open'
            ORDER BY e.created_at DESC
            """,
        ).fetchall()
    out: list[tuple[DriftEvent, str]] = []
    for row in rows:
        event = DriftEvent(
            event_id=str(row["event_id"]),
            claim_id=str(row["claim_id"]),
            scan_id=str(row["scan_id"]),
            drift_score=float(row["drift_score"]),
            severity=str(row["severity"]),
            evidence_json=str(row["evidence_json"]),
            status=str(row["status"]),
            created_at=str(row["created_at"]),
        )
        out.append((event, str(row["doc_path"])))
    return out


def _render_canonical_document(metadata: dict[str, Any], body: str) -> str:
    return "---\n" + yaml.safe_dump(metadata, sort_keys=False, allow_unicode=True) + "---\n" + body


def _merge_drift_governance_frontmatter(
    metadata: dict[str, Any],
    *,
    events: list[DriftEvent],
) -> dict[str, Any]:
    merged = copy.deepcopy(metadata)
    event_bits = ", ".join(f"{event.event_id}({event.severity})" for event in events)
    merged["verification_status"] = "drifted"
    merged["drift_note"] = f"Open drift events: {event_bits}"
    sources = merged.get("sources")
    marker = f"drift_events:{','.join(event.event_id for event in events)}"
    if isinstance(sources, list):
        if marker not in sources:
            sources = list(sources)
            sources.append(marker)
            merged["sources"] = sources
    else:
        merged["sources"] = [marker]
    return merged


def apply_drift_governance(
    repo_root_or_child: Path,
    *,
    write: bool,
    claim_id: str | None = None,
) -> list[str]:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    ensure_drift_manifest_defaults(manifest)
    threshold = parse_governance_apply_threshold(manifest)
    rows = _open_drift_rows_with_doc_paths(repo_root)
    grouped: dict[str, list[DriftEvent]] = defaultdict(list)
    for event, doc_path in rows:
        if claim_id is not None and event.claim_id != claim_id:
            continue
        if severity_rank(event.severity) < threshold:
            continue
        grouped[doc_path].append(event)
    if not grouped:
        return ["No matching open drift events for governance apply."]

    lines: list[str] = []
    for doc_path in sorted(grouped.keys()):
        events = grouped[doc_path]
        abs_path = repo_root / ".ai_memory" / doc_path
        if not abs_path.exists():
            lines.append(f"SKIP missing file for doc_path={doc_path}")
            continue
        raw = abs_path.read_text(encoding="utf-8")
        metadata, body = split_frontmatter(raw)
        proposed = _merge_drift_governance_frontmatter(metadata, events=events)
        prev_status = str(metadata.get("verification_status", ""))
        new_status = str(proposed.get("verification_status", ""))
        lines.append(f"Document: .ai_memory/{doc_path}")
        lines.append(f"  events: {', '.join(e.event_id for e in events)}")
        lines.append(f"  verification_status: {prev_status!r} -> {new_status!r}")
        lines.append(f"  drift_note: {proposed.get('drift_note')}")
        if write:
            continue
        lines.append("  (dry-run; no files written)")
    if not write:
        return lines

    with acquire_memory_lock(repo_root):
        for doc_path in sorted(grouped.keys()):
            events = grouped[doc_path]
            abs_path = repo_root / ".ai_memory" / doc_path
            if not abs_path.exists():
                continue
            raw = abs_path.read_text(encoding="utf-8")
            metadata, body = split_frontmatter(raw)
            proposed = _merge_drift_governance_frontmatter(metadata, events=events)
            abs_path.write_text(_render_canonical_document(proposed, body), encoding="utf-8")
    lines.append("Wrote governance updates to canonical documents.")
    return lines
