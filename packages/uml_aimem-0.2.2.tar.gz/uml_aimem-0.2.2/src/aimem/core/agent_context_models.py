"""Data model for the agent context bundle."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

DEFAULT_CONTEXT_OBJECTIVE = (
    "Current project state, decisions, tasks, and engineering constraints for an AI agent session."
)

BUNDLE_SCHEMA_VERSION = "1.0"

# Character budget: envelope (headers + repo + ACM + drift listing) then split remainder.
ENVELOPE_MAX = 1200
ENVELOPE_MIN = 400
PINNED_FRACTION = 0.45
RETRIEVAL_FRACTION = 0.40

FALLBACK_PINNED = ("rules/product.md", "state/project.md")


@dataclass
class RepositorySection:
    product_name: str
    schema_version: str
    git_head: str
    branch: str
    working_tree_dirty: bool


@dataclass
class PinnedEntry:
    relative_path: str
    missing: bool
    body_excerpt: str
    truncated: bool


@dataclass
class AgentContextBundle:
    bundle_schema_version: str
    profile: str
    repository: RepositorySection
    pinned: list[PinnedEntry]
    retrieval: dict[str, Any]
    drift: list[dict[str, Any]]
    acm: dict[str, Any | None]
