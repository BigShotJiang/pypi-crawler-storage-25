from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from aimem.core.context_manifest import ManifestSource, create_context_manifest
from aimem.core.memory import MemoryDocument, iter_canonical_documents, load_manifest
from aimem.core.repo import RepoError, find_git_root
from aimem.core.retrieval import search_memory_documents
from aimem.core.security import assert_no_high_secrets


@dataclass(frozen=True)
class CompiledDocument:
    document: MemoryDocument
    score: float | None = None


def compile_profile_to_file(
    repo_root_or_child: Path,
    profile_name: str,
    *,
    objective: str | None = None,
    allow_secrets: bool = False,
) -> tuple[Path, int, str]:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    profile = get_compile_profile(manifest, profile_name)
    include_paths = profile["include_paths"]
    max_chars = int(profile.get("max_chars", 0))
    max_tokens = int(profile.get("max_tokens", 0))
    selection_mode = str(profile.get("selection_mode", "ordered"))
    ranking_mode = str(manifest.get("retrieval", {}).get("ranking_mode", "bm25"))

    documents, rendered_mode = select_documents_for_profile(
        repo_root,
        profile=profile,
        objective=objective,
        include_paths=include_paths,
        selection_mode=selection_mode,
    )
    output_path = repo_root / ".ai_memory" / "generated" / f"{profile_name}.md"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    compiled_text, sources = render_compiled_profile(
        manifest,
        profile_name,
        include_paths,
        documents,
        max_chars,
        max_tokens=max_tokens,
        selection_mode=rendered_mode,
        objective=objective,
        profile=profile,
        ranking_mode=ranking_mode,
    )
    output_path.write_text(compiled_text, encoding="utf-8")
    assert_no_high_secrets(compiled_text, allow_secrets=allow_secrets, context=str(output_path))
    manifest_payload = create_context_manifest(
        repo_root,
        profile=profile_name,
        ranking_mode=ranking_mode,
        max_tokens=(max_tokens if max_tokens > 0 else None),
        max_chars=(max_chars if max_chars > 0 else None),
        output_text=compiled_text,
        sources=sources,
    )
    return output_path, len(documents), str(manifest_payload["manifest_id"])


def get_compile_profile(manifest: dict[str, Any], profile_name: str) -> dict[str, Any]:
    profiles = manifest.get("compile_profiles", {})
    profile = profiles.get(profile_name)
    if not isinstance(profile, dict):
        raise RepoError(f"Unknown compile profile '{profile_name}'.")
    if not isinstance(profile.get("include_paths"), list) or ("max_chars" not in profile and "max_tokens" not in profile):
        raise RepoError(f"Compile profile '{profile_name}' is missing required keys.")
    return profile


def select_documents_for_profile(
    repo_root: Path,
    *,
    profile: dict[str, Any],
    objective: str | None,
    include_paths: list[str],
    selection_mode: str,
) -> tuple[list[CompiledDocument], str]:
    if objective and selection_mode == "retrieval":
        return select_retrieved_documents(
            repo_root,
            profile=profile,
            objective=objective,
            include_paths=include_paths,
        ), "retrieval"
    return select_ordered_documents(repo_root, include_paths=include_paths), "ordered"


def select_ordered_documents(repo_root: Path, *, include_paths: list[str]) -> list[CompiledDocument]:
    return [CompiledDocument(document=document) for document in iter_canonical_documents(repo_root, include_paths)]


def select_retrieved_documents(
    repo_root: Path,
    *,
    profile: dict[str, Any],
    objective: str,
    include_paths: list[str],
) -> list[CompiledDocument]:
    total_docs, _, _, hits, _touched = search_memory_documents(
        repo_root,
        objective=objective,
        top_k=int(profile.get("max_results", 5)),
        include_paths=include_paths,
    )
    
    pinned_paths = [normalize_relative_path(path) for path in profile.get("pinned_paths", [])]
    selected: list[CompiledDocument] = []
    seen: set[str] = set()
    memory_root = repo_root / ".ai_memory"
    
    from aimem.core.memory import parse_document
    
    for pinned_path in pinned_paths:
        if pinned_path in seen:
            continue
        try:
            doc = parse_document(memory_root / pinned_path, repo_root)
            selected.append(CompiledDocument(document=doc))
            seen.add(pinned_path)
        except Exception:
            pass

    for hit in hits:
        if hit.relative_path in seen:
            continue
        try:
            doc = parse_document(memory_root / hit.relative_path, repo_root)
            selected.append(CompiledDocument(document=doc, score=hit.score))
            seen.add(hit.relative_path)
        except Exception:
            pass

    return selected


def normalize_relative_path(path: str) -> str:
    return path.replace("\\", "/").strip("/")


def render_compiled_profile(
    manifest: dict[str, Any],
    profile_name: str,
    include_paths: list[str],
    documents: list[CompiledDocument],
    max_chars: int,
    *,
    max_tokens: int,
    selection_mode: str,
    objective: str | None,
    profile: dict[str, Any],
    ranking_mode: str,
) -> tuple[str, list[ManifestSource]]:
    header = [
        "# AIMEM Context Pack",
        "",
        f"Profile: {profile_name}",
        f"Selection mode: {selection_mode}",
        f"Product: {manifest['product']['name']}",
        f"Subtitle: {manifest['product']['subtitle']}",
        f"Budget chars: {max_chars}",
        f"Budget tokens: {max_tokens}",
        f"Ranking mode: {ranking_mode}",
    ]
    if objective:
        header.append(f"Objective: {objective}")
    if selection_mode == "retrieval":
        header.append(f"Max results: {int(profile.get('max_results', 5))}")
        header.append(f"Snippet chars: {int(profile.get('snippet_chars', 500))}")
    header.extend(
        [
            "",
            "Included paths:",
            *[f"- {path}" for path in include_paths],
            "",
        ]
    )
    parts = ["\n".join(header)]
    manifest_sources: list[ManifestSource] = []
    truncated = False
    snippet_chars = int(profile.get("snippet_chars", 500))

    token_budget = max_tokens if max_tokens > 0 else 0
    for document in documents:
        section = render_document_section(document, objective=objective, excerpt_only=False, snippet_chars=snippet_chars)
        candidate = "".join(parts) + section
        if within_budget(candidate, max_chars=max_chars, max_tokens=max_tokens, token_budget=token_budget):
            parts.append(section)
            manifest_sources.append(source_for_document(document, excerpt_only=False, objective=objective, snippet_chars=snippet_chars))
            continue

        excerpt_section = render_document_section(
            document,
            objective=objective,
            excerpt_only=True,
            snippet_chars=snippet_chars,
        )
        candidate = "".join(parts) + excerpt_section
        if within_budget(candidate, max_chars=max_chars, max_tokens=max_tokens, token_budget=token_budget):
            parts.append(excerpt_section)
            truncated = True
            manifest_sources.append(source_for_document(document, excerpt_only=True, objective=objective, snippet_chars=snippet_chars))
            continue

        remaining = (max_chars - len("".join(parts))) if max_chars > 0 else 120
        if remaining > 80:
            excerpt = excerpt_section[: max(remaining - 24, 0)].rstrip()
            parts.append(excerpt + "\n\n[budget truncated]\n")
        truncated = True
        break

    if truncated:
        parts.append("\n[budget exhausted]\n")

    return "".join(parts).rstrip() + "\n", manifest_sources


def render_document_section(
    compiled_document: CompiledDocument,
    *,
    objective: str | None,
    excerpt_only: bool,
    snippet_chars: int,
) -> str:
    document = compiled_document.document
    meta = document.metadata
    
    tags = [
        f"id:{meta.get('id', '')}",
        f"kind:{meta.get('kind', '')}",
        f"status:{meta.get('status', '')}",
    ]
    for key in ("owner", "edit_policy", "confidence"):
        if val := meta.get(key, ""):
            tags.append(f"{key}:{val}")
            
    if compiled_document.score is not None:
        tags.append(f"score:{compiled_document.score:.3f}")
    if excerpt_only:
        tags.append("excerpt:true")

    compact_meta = " | ".join(t for t in tags if not t.endswith(":"))

    body = document.body.strip()
    if excerpt_only:
        body = build_excerpt(body, objective=objective, snippet_chars=snippet_chars)

    return (
        f"## {document.relative_path.stem}\n"
        f"Source: .ai_memory/{document.relative_path.as_posix()} [{compact_meta}]\n\n"
        f"{body}\n\n"
    )


def source_for_document(
    compiled_document: CompiledDocument,
    *,
    excerpt_only: bool,
    objective: str | None,
    snippet_chars: int,
) -> ManifestSource:
    document = compiled_document.document
    body = document.body.strip()
    if excerpt_only:
        body = build_excerpt(body, objective=objective, snippet_chars=snippet_chars)
    return ManifestSource(
        kind="memory_doc",
        ref=f".ai_memory/{document.relative_path.as_posix()}",
        sha256=hashlib.sha256(body.encode("utf-8")).hexdigest(),
        git_blob_sha=None,
        byte_range=None,
        token_estimate=estimate_tokens(body),
    )


def build_excerpt(body: str, *, objective: str | None, snippet_chars: int) -> str:
    compact = " ".join(body.split())
    if len(compact) <= snippet_chars:
        return compact
    if objective:
        lowered = compact.lower()
        positions = [lowered.find(token) for token in tokenize_objective(objective) if lowered.find(token) >= 0]
        if positions:
            start = max(min(positions) - snippet_chars // 3, 0)
            excerpt = compact[start : start + snippet_chars].strip()
            prefix = "..." if start > 0 else ""
            suffix = "..." if start + snippet_chars < len(compact) else ""
            return prefix + excerpt + suffix
    return compact[:snippet_chars].rstrip() + "..."


def tokenize_objective(objective: str) -> list[str]:
    return [token for token in objective.lower().replace("/", " ").split() if len(token) >= 2]


def within_budget(text: str, *, max_chars: int, max_tokens: int, token_budget: int) -> bool:
    if max_chars > 0 and len(text) > max_chars:
        return False
    if max_tokens <= 0:
        return True
    return estimate_tokens(text) <= token_budget


def estimate_tokens(text: str) -> int:
    try:
        import tiktoken  # type: ignore

        encoding = tiktoken.get_encoding("o200k_base")
        return len(encoding.encode(text))
    except Exception:
        # Conservative fallback when tokenizer extras are unavailable.
        return max(1, len(text) // 4)
