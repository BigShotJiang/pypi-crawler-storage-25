from __future__ import annotations

import hashlib
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from aimem.core.memory import MemoryDocument, iter_canonical_documents, load_manifest
from aimem.core.sqlite_index import configure_index_connection, ensure_index_schema, index_db_path
from aimem.core.repo import RepoError, find_git_root


@dataclass(frozen=True)
class QueryHit:
    relative_path: str
    document_id: str
    kind: str
    status: str
    score: float
    snippet: str
    criticality: str = "medium"
    trust_score: float = 0.5
    verification_status: str = "unverified"
    updated_at: str = ""


@dataclass(frozen=True)
class QueryReport:
    objective: str
    db_path: Path
    index_backend: str
    ranking_mode: str
    refreshed_docs: int
    hits: list[QueryHit]
    reindexed_paths: int = 0

    def render_lines(self) -> list[str]:
        lines = [
            f"Objective: {self.objective}",
            f"Index: {self.db_path}",
            f"Backend: {self.index_backend}",
            f"Ranking mode: {self.ranking_mode}",
            f"Refreshed docs: {self.refreshed_docs}",
        ]
        if self.reindexed_paths:
            lines.append(f"Index rows updated: {self.reindexed_paths}")
        if not self.hits:
            lines.append("No hits found.")
            return lines

        lines.append("Results:")
        for index, hit in enumerate(self.hits, start=1):
            lines.extend(
                [
                    f"{index}. .ai_memory/{hit.relative_path}",
                    f"   id={hit.document_id} kind={hit.kind} status={hit.status} score={hit.score:.3f}",
                    f"   {hit.snippet}",
                ]
            )
        return lines


def query_memory(
    repo_root_or_child: Path,
    *,
    objective: str,
    top_k: int,
    force_reindex: bool = False,
) -> QueryReport:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    include_paths = list(manifest["paths"]["canonical"])
    ranking_mode = str(manifest.get("retrieval", {}).get("ranking_mode", "bm25")).strip().lower()
    total_docs, db_path, backend, hits, touched = search_memory_documents(
        repo_root,
        objective=objective,
        top_k=top_k,
        include_paths=include_paths,
        ranking_mode=ranking_mode,
        force_reindex=force_reindex,
    )

    return QueryReport(
        objective=objective,
        db_path=db_path,
        index_backend=backend,
        ranking_mode=ranking_mode,
        refreshed_docs=total_docs,
        hits=hits,
        reindexed_paths=touched,
    )


def search_memory_documents(
    repo_root_or_child: Path,
    *,
    objective: str,
    top_k: int,
    include_paths: list[str] | None = None,
    ranking_mode: str | None = None,
    force_reindex: bool = False,
) -> tuple[int, Path, str, list[QueryHit], int]:
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    effective_include_paths = include_paths or list(manifest["paths"]["canonical"])
    from aimem.core.memory import iter_canonical_paths
    paths = iter_canonical_paths(repo_root, effective_include_paths)
    db_path = index_db_path(repo_root)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    effective_ranking_mode = ranking_mode or str(manifest.get("retrieval", {}).get("ranking_mode", "bm25")).strip().lower()
    backend_label = "sqlite-fts5"
    timing = os.environ.get("AIMEM_DEBUG_TIMING", "").strip() in ("1", "true", "yes")
    t0 = time.perf_counter()
    with sqlite3.connect(db_path) as connection:
        configure_index_connection(connection)
        backend, touched = rebuild_index(connection, repo_root, paths, force=force_reindex)
        if timing:
            import sys as _sys

            t1 = time.perf_counter()
            print(
                f"[aimem timing] index refresh: {(t1 - t0) * 1000:.1f}ms (touched={touched}, force={force_reindex})",
                file=_sys.stderr,
            )
        backend_label = backend
        if effective_ranking_mode == "hybrid_semantic":
            if sqlite_vec_available(connection):
                backend_label = f"{backend}+sqlite-vec"
            else:
                backend_label = f"{backend}+semantic-fallback"
        t2 = time.perf_counter()
        hits = search_index(
            connection,
            objective=objective,
            top_k=top_k,
            backend=backend,
            ranking_mode=effective_ranking_mode,
        )
        if timing:
            import sys as _sys

            t3 = time.perf_counter()
            print(f"[aimem timing] search: {(t3 - t2) * 1000:.1f}ms", file=_sys.stderr)

    return len(paths), db_path, backend_label, hits, touched


def rebuild_index(
    connection: sqlite3.Connection,
    repo_root: Path,
    paths: list[Path],
    *,
    force: bool = False,
) -> tuple[str, int]:
    connection.row_factory = sqlite3.Row
    initialize_base_tables(connection)
    backend = initialize_search_backend(connection)
    if force:
        from aimem.core.memory import parse_document
        documents = []
        for p in paths:
            try:
                documents.append(parse_document(p, repo_root))
            except Exception:
                pass
        refresh_documents(connection, documents, backend)
        return backend, len(documents)
    touched = refresh_documents_smart(connection, repo_root, paths, backend)
    return backend, touched


def force_full_reindex(repo_root_or_child: Path) -> tuple[Path, int]:
    """Rebuild the local retrieval index from scratch (same as ``force_reindex=True`` on search)."""
    repo_root = find_git_root(repo_root_or_child)
    manifest = load_manifest(repo_root)
    include_paths = list(manifest["paths"]["canonical"])
    from aimem.core.memory import iter_canonical_paths
    paths = iter_canonical_paths(repo_root, include_paths)
    db_path = index_db_path(repo_root)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as connection:
        configure_index_connection(connection)
        backend, touched = rebuild_index(connection, repo_root, paths, force=True)
    return db_path, touched


def initialize_base_tables(connection: sqlite3.Connection) -> None:
    ensure_index_schema(connection)


def initialize_search_backend(connection: sqlite3.Connection) -> str:
    try:
        connection.execute(
            """
            CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts
            USING fts5(
                relative_path UNINDEXED,
                document_id UNINDEXED,
                kind,
                status,
                criticality UNINDEXED,
                owner,
                updated_at UNINDEXED,
                verified_at UNINDEXED,
                trust_score UNINDEXED,
                verification_status UNINDEXED,
                search_text,
                body
            )
            """
        )
        connection.commit()
        return "sqlite-fts5"
    except sqlite3.OperationalError:
        return "python-fallback"


def sqlite_vec_available(connection: sqlite3.Connection) -> bool:
    try:
        connection.execute("SELECT sqlite_version()").fetchone()
    except sqlite3.OperationalError:
        return False
    # Feature detection placeholder: real extension load is optional and opt-in.
    return False


def _delete_doc_from_index(connection: sqlite3.Connection, relative_path: str, backend: str) -> None:
    connection.execute("DELETE FROM documents WHERE relative_path = ?", (relative_path,))
    if backend == "sqlite-fts5":
        connection.execute("DELETE FROM documents_fts WHERE relative_path = ?", (relative_path,))


def _insert_doc_rows(connection: sqlite3.Connection, document: MemoryDocument, backend: str, mtime: float = 0.0) -> None:
    payload = document_payload(document)
    fts_payload = payload[:12]
    connection.execute(
        """
        INSERT INTO documents (
            relative_path, document_id, kind, status, criticality, owner, updated_at, verified_at, trust_score, verification_status, search_text, body, source_fingerprint, mtime
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (*payload, mtime),
    )
    if backend == "sqlite-fts5":
        connection.execute(
            """
            INSERT INTO documents_fts (
                relative_path, document_id, kind, status, criticality, owner, updated_at, verified_at, trust_score, verification_status, search_text, body
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            fts_payload,
        )


def refresh_documents_smart(
    connection: sqlite3.Connection,
    repo_root: Path,
    paths: list[Path],
    backend: str,
) -> int:
    """Update index rows whose on-disk file changed; remove deleted paths. Returns number of rows touched."""
    memory_root = repo_root / ".ai_memory"
    rel_current = {p.relative_to(memory_root).as_posix() for p in paths}
    rel_db = {
        str(row[0])
        for row in connection.execute("SELECT relative_path FROM documents").fetchall()
    }
    touched = 0
    for stale in rel_db - rel_current:
        _delete_doc_from_index(connection, stale, backend)
        touched += 1
        
    from aimem.core.memory import parse_document
    for path in paths:
        rel = path.relative_to(memory_root).as_posix()
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
            
        row = connection.execute(
            "SELECT mtime FROM documents WHERE relative_path = ?",
            (rel,),
        ).fetchone()
        
        stored = float(row[0]) if row and row[0] is not None else -1.0
        if stored == mtime and mtime > 0:
            continue
            
        _delete_doc_from_index(connection, rel, backend)
        try:
            doc = parse_document(path, repo_root)
            _insert_doc_rows(connection, doc, backend, mtime=mtime)
            touched += 1
        except Exception:
            pass # skip broken files
            
    connection.commit()
    return touched


def refresh_documents(connection: sqlite3.Connection, documents: list[MemoryDocument], backend: str) -> None:
    connection.execute("DELETE FROM documents")
    if backend == "sqlite-fts5":
        connection.execute("DELETE FROM documents_fts")

    for document in documents:
        try:
            mtime = document.path.stat().st_mtime
        except OSError:
            mtime = 0.0
        _insert_doc_rows(connection, document, backend, mtime=mtime)
    connection.commit()


def document_payload(document: MemoryDocument) -> tuple[str, str, str, str, str, str, str, str, float, str, str, str, str]:
    metadata = document.metadata
    relative_path = document.relative_path.as_posix()
    document_id = str(metadata.get("id", ""))
    kind = str(metadata.get("kind", ""))
    status = str(metadata.get("status", ""))
    criticality = str(metadata.get("criticality", "medium"))
    owner = str(metadata.get("owner", ""))
    updated_at = str(metadata.get("updated_at", ""))
    verified_at = str(metadata.get("verified_at", "") or "")
    trust_score = float(metadata.get("trust_score", 0.5))
    verification_status = str(metadata.get("verification_status", "unverified"))
    search_text = " ".join(
        [
            relative_path,
            document_id,
            kind,
            status,
            owner,
            document.body.replace("\n", " "),
        ]
    ).strip()
    try:
        fingerprint = hashlib.sha256(document.path.read_bytes()).hexdigest()
    except OSError:
        fingerprint = ""
    return (
        relative_path,
        document_id,
        kind,
        status,
        criticality,
        owner,
        updated_at,
        verified_at,
        trust_score,
        verification_status,
        search_text,
        document.body,
        fingerprint,
    )


def search_index(
    connection: sqlite3.Connection,
    *,
    objective: str,
    top_k: int,
    backend: str,
    ranking_mode: str,
) -> list[QueryHit]:
    if backend == "sqlite-fts5":
        try:
            hits = query_fts(connection, objective=objective, top_k=max(top_k * 3, top_k))
            return rerank_hits(hits, objective=objective, top_k=top_k, ranking_mode=ranking_mode)
        except sqlite3.OperationalError:
            hits = query_fallback(connection, objective=objective, top_k=max(top_k * 3, top_k))
            return rerank_hits(hits, objective=objective, top_k=top_k, ranking_mode=ranking_mode)
    hits = query_fallback(connection, objective=objective, top_k=max(top_k * 3, top_k))
    return rerank_hits(hits, objective=objective, top_k=top_k, ranking_mode=ranking_mode)


def query_fts(connection: sqlite3.Connection, *, objective: str, top_k: int) -> list[QueryHit]:
    query = build_match_query(objective)
    rows = connection.execute(
        """
        SELECT
            relative_path,
            document_id,
            kind,
            status,
            criticality,
            trust_score,
            verification_status,
            updated_at,
            bm25(documents_fts) AS score,
            body
        FROM documents_fts
        WHERE documents_fts MATCH ?
        ORDER BY score, relative_path
        LIMIT ?
        """,
        (query, top_k),
    ).fetchall()
    return [
        QueryHit(
            relative_path=str(row["relative_path"]),
            document_id=str(row["document_id"]),
            kind=str(row["kind"]),
            status=str(row["status"]),
            score=abs(float(row["score"])),
            snippet=make_snippet(str(row["body"]), objective),
            criticality=str(row["criticality"] or "medium"),
            trust_score=float(row["trust_score"] or 0.5),
            verification_status=str(row["verification_status"] or "unverified"),
            updated_at=str(row["updated_at"] or ""),
        )
        for row in rows
    ]


def query_fallback(connection: sqlite3.Connection, *, objective: str, top_k: int) -> list[QueryHit]:
    tokens = tokenize(objective)
    if not tokens:
        raise RepoError("Query objective must include searchable terms.")

    rows = connection.execute(
        """
        SELECT relative_path, document_id, kind, status, criticality, trust_score, verification_status, updated_at, search_text, body
        FROM documents
        """
    ).fetchall()
    scored: list[QueryHit] = []
    for row in rows:
        haystack = str(row["search_text"]).lower()
        score = float(sum(haystack.count(token) for token in tokens))
        if score <= 0:
            continue
        scored.append(
            QueryHit(
                relative_path=str(row["relative_path"]),
                document_id=str(row["document_id"]),
                kind=str(row["kind"]),
                status=str(row["status"]),
                score=score,
                snippet=make_snippet(str(row["body"]), objective),
                criticality=str(row["criticality"] or "medium"),
                trust_score=float(row["trust_score"] or 0.5),
                verification_status=str(row["verification_status"] or "unverified"),
                updated_at=str(row["updated_at"] or ""),
            )
        )
    return sorted(scored, key=lambda item: (-item.score, item.relative_path))[:top_k]


def rerank_hits(hits: list[QueryHit], *, objective: str, top_k: int, ranking_mode: str) -> list[QueryHit]:
    if ranking_mode not in {"hybrid_metadata", "hybrid_semantic"}:
        return hits[:top_k]
    rescored: list[QueryHit] = []
    for hit in hits:
        rescored.append(
            QueryHit(
                relative_path=hit.relative_path,
                document_id=hit.document_id,
                kind=hit.kind,
                status=hit.status,
                score=compute_metadata_score(hit),
                snippet=hit.snippet,
                criticality=hit.criticality,
                trust_score=hit.trust_score,
                verification_status=hit.verification_status,
                updated_at=hit.updated_at,
            )
        )
    rescored.sort(key=lambda item: (-item.score, item.relative_path))
    filtered = [hit for hit in rescored if hit.status != "deprecated"]
    return (filtered or rescored)[:top_k]


def compute_metadata_score(hit: QueryHit) -> float:
    status_boost = {
        "gold": 2.0,
        "reviewed": 1.4,
        "draft": 0.9,
        "deprecated": -4.0,
    }.get(hit.status, 1.0)
    verify_boost = {"verified": 0.5, "reviewed": 0.4, "unverified": 0.0}.get(hit.verification_status, 0.1)
    recency_boost = recency_value(hit.updated_at)
    return hit.score + status_boost + verify_boost + hit.trust_score + recency_boost


def recency_value(updated_at: str) -> float:
    if not updated_at:
        return 0.0
    try:
        parsed = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
    except ValueError:
        return 0.0
    age_days = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).days
    if age_days <= 7:
        return 0.6
    if age_days <= 30:
        return 0.3
    return 0.0


def build_match_query(objective: str) -> str:
    tokens = tokenize(objective)
    if not tokens:
        raise RepoError("Query objective must include searchable terms.")
    return " OR ".join(tokens)


def tokenize(text: str) -> list[str]:
    return [token for token in re.findall(r"[a-z0-9]{2,}", text.lower()) if token not in STOP_WORDS]


def make_snippet(body: str, objective: str, *, width: int = 180) -> str:
    compact = " ".join(body.split())
    if not compact:
        return ""
    lowered = compact.lower()
    positions = [lowered.find(token) for token in tokenize(objective)]
    positions = [position for position in positions if position >= 0]
    if not positions:
        excerpt = compact[:width]
        return excerpt if len(compact) <= width else excerpt.rstrip() + "..."
    start = max(min(positions) - width // 3, 0)
    excerpt = compact[start : start + width].strip()
    prefix = "..." if start > 0 else ""
    suffix = "..." if start + width < len(compact) else ""
    return prefix + excerpt + suffix


STOP_WORDS = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "be",
    "by",
    "do",
    "for",
    "from",
    "if",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "the",
    "to",
    "with",
}
