from __future__ import annotations

from pathlib import Path

from aimem.core.repo import RepoError, find_git_root


def install_hooks(repo_root_or_child: Path) -> list[Path]:
    repo_root = find_git_root(repo_root_or_child)
    hooks_dir = repo_root / ".git" / "hooks"
    if not hooks_dir.exists():
        raise RepoError("Missing .git/hooks directory.")
    created: list[Path] = []
    pre_commit = hooks_dir / "pre-commit"
    pre_push = hooks_dir / "pre-push"
    pre_commit.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\nuv run aimem verify --fast .\n",
        encoding="utf-8",
    )
    pre_push.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n# Enable strict mode manually when desired.\nuv run aimem verify .\n",
        encoding="utf-8",
    )
    pre_commit.chmod(0o755)
    pre_push.chmod(0o755)
    created.extend([pre_commit, pre_push])
    return created
