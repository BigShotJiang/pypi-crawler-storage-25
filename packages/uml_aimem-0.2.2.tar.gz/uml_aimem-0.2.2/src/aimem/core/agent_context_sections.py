"""Per-section assembly for agent context bundles."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

from aimem.core.agent_context_budget import truncate_text
from aimem.core.agent_context_models import (
    DEFAULT_CONTEXT_OBJECTIVE,
    FALLBACK_PINNED,
    PinnedEntry,
    RepositorySection,
)
from aimem.core.compiler import compile_profile_to_file
from aimem.core.context_manifest import (
    get_latest_context_manifest_summary,
    is_working_tree_dirty,
    read_current_branch,
    read_head_commit,
)
from aimem.core.drift import list_open_drift_events
from aimem.core.memory import split_frontmatter
from aimem.core.repo import RepoError
from aimem.core.retrieval import QueryReport, query_memory


def pinned_paths(manifest: dict[str, Any], profile: str) -> list[str]:
    profiles = manifest.get("compile_profiles")
    if not isinstance(profiles, dict):
        return list(FALLBACK_PINNED)
    prof = profiles.get(profile)
    if not isinstance(prof, dict):
        raise RepoError(f"Unknown compile profile '{profile}'.")
    raw = prof.get("pinned_paths")
    if isinstance(raw, list) and raw:
        return [str(p).strip() for p in raw if str(p).strip()]
    return list(FALLBACK_PINNED)


def build_repository_section(repo_root: Path, manifest: dict[str, Any]) -> RepositorySection:
    head = read_head_commit(repo_root)
    branch = read_current_branch(repo_root)
    dirty = is_working_tree_dirty(repo_root)
    product = manifest.get("product", {}) if isinstance(manifest.get("product"), dict) else {}
    return RepositorySection(
        product_name=str(product.get("name", "project")),
        schema_version=str(manifest.get("schema_version", "")),
        git_head=head or "",
        branch=branch or "",
        working_tree_dirty=dirty,
    )


def build_pinned_entries(
    repo_root: Path,
    manifest: dict[str, Any],
    profile: str,
    *,
    pinned_budget: int,
) -> list[PinnedEntry]:
    rel_paths = pinned_paths(manifest, profile)
    memory_root = repo_root / ".ai_memory"
    n_paths = max(len(rel_paths), 1)
    per_file_cap = max(50, pinned_budget // n_paths) if pinned_budget > 0 else 0

    entries: list[PinnedEntry] = []
    for rel in rel_paths:
        path = memory_root / rel
        if not path.exists():
            entries.append(PinnedEntry(relative_path=rel, missing=True, body_excerpt="", truncated=False))
            continue
        raw = path.read_text(encoding="utf-8")
        try:
            _, body = split_frontmatter(raw)
        except RepoError:
            body = raw
        body_stripped = body.strip()
        excerpt = truncate_text(body_stripped, per_file_cap) if per_file_cap > 0 else ""
        entries.append(
            PinnedEntry(
                relative_path=rel,
                missing=False,
                body_excerpt=excerpt,
                truncated=len(excerpt) < len(body_stripped),
            )
        )
    return entries


def query_report_to_dict(report: QueryReport) -> dict[str, Any]:
    return {
        "objective": report.objective,
        "index": str(report.db_path),
        "backend": report.index_backend,
        "ranking_mode": report.ranking_mode,
        "refreshed_docs": report.refreshed_docs,
        "reindexed_paths": report.reindexed_paths,
        "hits": [
            {
                "relative_path": h.relative_path,
                "document_id": h.document_id,
                "kind": h.kind,
                "status": h.status,
                "score": h.score,
                "snippet": h.snippet,
                "criticality": h.criticality,
                "trust_score": h.trust_score,
                "verification_status": h.verification_status,
                "updated_at": h.updated_at,
            }
            for h in report.hits
        ],
    }


def apply_retrieval_char_budget(report: QueryReport, char_budget: int) -> QueryReport:
    """Shrink hit snippets so render_lines() stays within char_budget (approximate)."""
    if char_budget <= 0:
        return replace(report, hits=[])
    header_estimate = 120 + len(report.objective) + len(str(report.db_path))
    remaining = char_budget - header_estimate
    if remaining <= 0 or not report.hits:
        return report
    per_hit = max(40, remaining // max(1, len(report.hits) * 3))
    new_hits = [replace(h, snippet=truncate_text(h.snippet, per_hit)) for h in report.hits]
    return replace(report, hits=new_hits)


def build_retrieval_dict(
    repo_root: Path,
    *,
    objective: str | None,
    top_k: int,
    retrieval_budget: int,
) -> dict[str, Any]:
    obj = (objective or "").strip() or DEFAULT_CONTEXT_OBJECTIVE
    report_raw = query_memory(repo_root, objective=obj, top_k=top_k)
    report = apply_retrieval_char_budget(report_raw, retrieval_budget)
    return query_report_to_dict(report)


def drift_events_as_dicts(events: list[Any], *, limit: int = 10) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for ev in events[:limit]:
        eid = str(ev.event_id)
        out.append(
            {
                "event_id": eid,
                "claim_id": ev.claim_id,
                "scan_id": ev.scan_id,
                "drift_score": ev.drift_score,
                "severity": ev.severity,
                "evidence_json": ev.evidence_json,
                "status": ev.status,
                "created_at": ev.created_at,
                "aimem_uri": f"aimem://drift-event/{eid}",
            }
        )
    return out


def build_drift_dicts(repo_root: Path, *, limit: int = 10) -> list[dict[str, Any]]:
    events = list_open_drift_events(repo_root, limit=limit)
    return drift_events_as_dicts(events, limit=limit)


def latest_capsule_summary(repo_root: Path) -> dict[str, str] | None:
    """Most recently modified drift capsule under .ai_memory/journal/capsules/, if any."""
    caps_dir = repo_root / ".ai_memory" / "journal" / "capsules"
    if not caps_dir.is_dir():
        return None
    paths = [p for p in caps_dir.glob("capsule-*.md") if p.is_file()]
    if not paths:
        return None
    best = max(paths, key=lambda p: p.stat().st_mtime)
    cid = best.stem
    return {"capsule_id": cid, "aimem_uri": f"aimem://capsule/{cid}"}


def build_acm_section(
    repo_root: Path,
    *,
    after_compile: bool,
    profile: str,
    compile_profile: str | None,
    compile_objective: str | None,
    allow_secrets_compile: bool,
) -> dict[str, Any | None]:
    if after_compile:
        cprof = compile_profile if compile_profile is not None else profile
        _, _, manifest_id = compile_profile_to_file(
            repo_root,
            cprof,
            objective=compile_objective,
            allow_secrets=allow_secrets_compile,
        )
        from_compile: dict[str, Any] | None = {
            "manifest_id": manifest_id,
            "aimem_uri": f"aimem://manifest/{manifest_id}",
            "compile_profile": cprof,
        }
    else:
        from_compile = None

    return {
        "latest": get_latest_context_manifest_summary(repo_root),
        "from_compile_this_run": from_compile,
        "latest_capsule": latest_capsule_summary(repo_root),
    }
