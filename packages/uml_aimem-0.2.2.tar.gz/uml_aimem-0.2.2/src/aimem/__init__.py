"""aimem package."""

import importlib.metadata

from aimem._dist import DISTRIBUTION_NAME

__all__ = ["__version__", "DISTRIBUTION_NAME"]


def _installed_version() -> str:
    for dist in (DISTRIBUTION_NAME, "aimem"):
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    return "0.0.0+unknown"


__version__ = _installed_version()
