from __future__ import annotations

from pathlib import Path

import typer


def query_command(
    objective: str = typer.Argument(..., help="What context you want to retrieve."),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    top_k: int = typer.Option(5, "--top-k", "-k", min=1, max=20, help="Maximum number of hits to return."),
    force_reindex: bool = typer.Option(
        False,
        "--force-reindex",
        help="Rebuild the retrieval index from scratch before searching (same as `aimem index rebuild`).",
    ),
) -> None:
    """Retrieve the most relevant canonical memory for an objective."""

    from aimem.core.retrieval import query_memory as _query

    report = _query(path, objective=objective, top_k=top_k, force_reindex=force_reindex)
    for line in report.render_lines():
        typer.echo(line)
