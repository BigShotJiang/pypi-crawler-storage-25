from __future__ import annotations

import json
from pathlib import Path

import typer

manifest_app = typer.Typer(help="Read context manifests (ACM).")


@manifest_app.command("get")
def manifest_get_command(
    manifest_id: str = typer.Argument(..., help="Manifest UUID."),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    from aimem.core.context_manifest import get_context_manifest

    payload = get_context_manifest(path, manifest_id)
    typer.echo(json.dumps(payload, indent=2, sort_keys=False))
