from __future__ import annotations

from pathlib import Path

import typer


def init_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    """Create the canonical .ai_memory structure in the repository root."""

    from aimem.core.memory import initialize_memory_layer

    result = initialize_memory_layer(path)
    typer.echo(f"Initialized ai memory in {result.memory_root}")
    typer.echo(f"Created {len(result.created_paths)} new paths")
