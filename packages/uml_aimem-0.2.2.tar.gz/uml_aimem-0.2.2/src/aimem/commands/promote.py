from __future__ import annotations

from pathlib import Path

import typer


def promote_command(
    relative_path: str = typer.Argument(..., help="Path relative to .ai_memory, for example decisions/decision-0001-memory-contract.md"),
    target_status: str = typer.Option("reviewed", "--status", help="Target status (reviewed or gold)."),
    reviewer: str = typer.Option("human", "--reviewer", help="Reviewer identifier."),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    from aimem.core.promotion import promote_document

    updated = promote_document(path, relative_path=relative_path, target_status=target_status, reviewer=reviewer)
    typer.echo(f"Promoted .ai_memory/{relative_path} -> {target_status}")
    typer.echo(f"Updated file: {updated}")
