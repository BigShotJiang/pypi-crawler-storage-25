from __future__ import annotations

from pathlib import Path

import typer


def context_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    profile: str = typer.Option(
        "bootstrap",
        "--profile",
        "-p",
        help="Compile profile whose pinned_paths define the baseline section.",
    ),
    objective: str | None = typer.Option(
        None,
        "--objective",
        "-o",
        help="Override the default retrieval objective for the context bundle.",
    ),
    top_k: int = typer.Option(5, "--top-k", "-k", min=1, max=20, help="Top-k for the retrieval block."),
    max_chars: int = typer.Option(
        12000,
        "--max-chars",
        min=2000,
        max=100_000,
        help="Soft character budget for the combined text output (markdown/text) and internal JSON field excerpts.",
    ),
    json_max_chars: int | None = typer.Option(
        None,
        "--json-max-chars",
        min=2000,
        max=500_000,
        help="When --format json, shrink pinned excerpts and retrieval snippets until the serialized JSON fits this size.",
    ),
    output_format: str = typer.Option(
        "markdown",
        "--format",
        "-f",
        help="Output structure: markdown, text, or json.",
    ),
    after_compile: bool = typer.Option(
        False,
        "--after-compile",
        help="Run aimem compile before assembling context; ACM from this run appears in the bundle.",
    ),
    compile_profile: str | None = typer.Option(
        None,
        "--compile-profile",
        help="Profile for --after-compile (defaults to the same value as --profile).",
    ),
    compile_objective: str | None = typer.Option(
        None,
        "--compile-objective",
        help="Objective passed to compile when --after-compile is set (retrieval still uses --objective).",
    ),
    allow_secrets: bool = typer.Option(
        False,
        "--allow-secrets",
        help="Forwarded to compile when --after-compile is set.",
    ),
) -> None:
    """Print a single agent-oriented bundle: repo meta, pinned docs, retrieval, drift, ACM."""

    try:
        from aimem.core.context_contract import (
            ContextBundleRequest,
            ContextContractError,
            build_context_string,
        )
        from aimem.core.repo import RepoError

        request = ContextBundleRequest.from_cli_args(
            profile=profile,
            objective=objective,
            top_k=top_k,
            max_chars=max_chars,
            output_format=output_format,
            after_compile=after_compile,
            compile_profile=compile_profile,
            compile_objective=compile_objective,
            allow_secrets_compile=allow_secrets,
            json_max_chars=json_max_chars,
        )
        text = build_context_string(path, request)
    except ContextContractError as exc:
        raise typer.BadParameter(str(exc)) from exc
    except RepoError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    typer.echo(text.rstrip())
