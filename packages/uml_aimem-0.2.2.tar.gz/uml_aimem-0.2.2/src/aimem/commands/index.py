from __future__ import annotations

from pathlib import Path

import typer

index_app = typer.Typer(help="Local FTS retrieval index maintenance.")


@index_app.command("rebuild")
def index_rebuild_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    """Drop and rebuild the SQLite retrieval index from canonical .ai_memory documents."""

    from aimem.core.retrieval import force_full_reindex

    db_path, touched = force_full_reindex(path)
    typer.echo(f"Rebuilt retrieval index at {db_path} (rows touched: {touched}).")
