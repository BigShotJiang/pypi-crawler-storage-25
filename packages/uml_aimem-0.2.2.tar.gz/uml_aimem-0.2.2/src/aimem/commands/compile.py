from __future__ import annotations

from pathlib import Path

import typer


def compile_command(
    profile: str = typer.Option(
        "implementation",
        "--profile",
        "-p",
        help="Compilation profile defined in .ai_memory/manifest.yaml.",
    ),
    objective: str | None = typer.Option(
        None,
        "--objective",
        "-o",
        help="Optional objective used to build a retrieval-oriented context pack.",
    ),
    allow_secrets: bool = typer.Option(
        False,
        "--allow-secrets",
        help="Allow output generation even if high-confidence secret patterns are detected.",
    ),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    """Compile canonical memory into a derived profile output."""

    from aimem.core.compiler import compile_profile_to_file

    output_path, document_count, manifest_id = compile_profile_to_file(
        path,
        profile,
        objective=objective,
        allow_secrets=allow_secrets,
    )
    typer.echo(f"Compiled profile '{profile}' to {output_path}")
    typer.echo(f"Included {document_count} documents")
    typer.echo(f"Context manifest: aimem://manifest/{manifest_id}")
