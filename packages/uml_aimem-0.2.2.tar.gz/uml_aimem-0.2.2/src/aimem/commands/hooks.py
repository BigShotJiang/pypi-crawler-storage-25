from __future__ import annotations

from pathlib import Path

import typer


def install_hooks_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    from aimem.core.hooks import install_hooks

    installed = install_hooks(path)
    for hook in installed:
        typer.echo(f"Installed hook: {hook.name}")
