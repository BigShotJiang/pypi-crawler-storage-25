from __future__ import annotations

from pathlib import Path

import typer

drift_app = typer.Typer(help="Detect and reconcile code-memory drift.")


@drift_app.command("scan")
def drift_scan_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    from aimem.core.drift import run_drift_scan

    report = run_drift_scan(path)
    typer.echo(f"Scan ID: {report.scan_id}")
    typer.echo(f"Indexed claims: {report.claim_count}")
    typer.echo(f"Open drift events: {report.event_count}")
    for event in report.events:
        typer.echo(
            f"- [{event.severity}] claim={event.claim_id} "
            f"score={event.drift_score:.2f} event={event.event_id} "
            f"resource=aimem://drift-event/{event.event_id}"
        )


@drift_app.command("report")
def drift_report_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    limit: int = typer.Option(20, "--limit", min=1, max=200, help="Maximum number of events."),
) -> None:
    from aimem.core.drift import list_open_drift_events

    events = list_open_drift_events(path, limit=limit)
    typer.echo(f"Open drift alerts: {len(events)}")
    for event in events:
        typer.echo(
            f"- [{event.severity}] claim={event.claim_id} status={event.status} "
            f"score={event.drift_score:.2f} event={event.event_id}"
        )


@drift_app.command("apply")
def drift_apply_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    write: bool = typer.Option(
        False,
        "--write",
        help="Write canonical documents; default is dry-run only.",
    ),
    claim_id: str | None = typer.Option(
        None,
        "--claim-id",
        help="Restrict updates to a single claim id.",
    ),
) -> None:
    """Mark canonical documents as verification_status: drifted when drift is severe (see manifest aimem_drift.governance_apply)."""
    from aimem.core.drift import apply_drift_governance

    lines = apply_drift_governance(path, write=write, claim_id=claim_id)
    for line in lines:
        typer.echo(line)


@drift_app.command("reconcile")
def drift_reconcile_command(
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    claim_id: str | None = typer.Option(None, "--claim-id", help="Optionally reconcile a single claim."),
) -> None:
    from aimem.core.drift import reconcile_drift_events

    capsule = reconcile_drift_events(path, claim_id=claim_id)
    if capsule is None:
        typer.echo("No open drift events to reconcile.")
        return
    typer.echo(f"Created capsule: {capsule}")
    typer.echo(f"Resource: aimem://capsule/{capsule.stem}")
