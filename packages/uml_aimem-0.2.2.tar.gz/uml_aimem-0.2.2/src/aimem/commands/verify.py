from __future__ import annotations

from pathlib import Path

import typer


def verify_command(
    refresh: bool = typer.Option(
        False,
        "--refresh",
        help="Refresh verified_at and verified_from.git_commit for canonical memory documents before reporting status.",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Enable strict governance checks (for example, C3-style review requirements).",
    ),
    fast: bool = typer.Option(
        False,
        "--fast",
        help="Run local-only checks suitable for pre-commit workflows.",
    ),
    check_retrieval_index: bool = typer.Option(
        False,
        "--check-retrieval-index",
        help="Compare canonical memory paths to the SQLite retrieval index; print NOTE if missing or stale (skipped with --fast).",
    ),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
) -> None:
    """Validate manifest consistency and freshness of canonical memory."""

    if strict and fast:
        raise typer.BadParameter("Use either --strict or --fast, not both.")
    if check_retrieval_index and fast:
        raise typer.BadParameter("Use either --check-retrieval-index or --fast, not both.")

    from aimem.core.verifier import refresh_memory_verification, verify_memory

    if refresh:
        refreshed = refresh_memory_verification(path)
        typer.echo(f"Refreshed {refreshed} documents")

    report = verify_memory(
        path,
        strict=strict and not fast,
        check_retrieval_index=check_retrieval_index,
    )
    for line in report.render_lines():
        typer.echo(line)

    if report.has_failures:
        raise typer.Exit(code=1)
