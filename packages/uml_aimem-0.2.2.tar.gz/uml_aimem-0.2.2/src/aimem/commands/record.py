from __future__ import annotations

from pathlib import Path

import typer

record_app = typer.Typer(help="Create canonical memory documents.")


@record_app.command("decision")
def record_decision_command(
    title: str = typer.Argument(..., help="Decision title."),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    context: str = typer.Option("Document the context for this decision.", help="Decision context paragraph."),
    decision: str = typer.Option("Describe the chosen direction.", help="Decision statement."),
    consequence: list[str] = typer.Option(
        None,
        "--consequence",
        help="Consequence bullet. Repeat to add more than one.",
    ),
    source_ref: list[str] = typer.Option(
        None,
        "--source-ref",
        help="Source reference. Repeat to add more than one.",
    ),
    allow_secrets: bool = typer.Option(
        False,
        "--allow-secrets",
        help="Allow recording content even when high-confidence secret patterns are found.",
    ),
) -> None:
    """Create a decision document in .ai_memory/decisions."""

    from aimem.core.recorder import record_decision

    created = record_decision(
        path,
        title=title,
        context=context,
        decision=decision,
        consequences=consequence,
        source_refs=source_ref,
        allow_secrets=allow_secrets,
    )
    typer.echo(f"Created {created.relative_to(created.parents[1])}")


@record_app.command("task")
def record_task_command(
    title: str = typer.Argument(..., help="Task title."),
    path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        resolve_path=True,
        help="Any path inside the target Git repository.",
    ),
    goal: str = typer.Option("Describe the goal for this task.", help="Task goal paragraph."),
    done_when: list[str] = typer.Option(
        None,
        "--done-when",
        help="Completion criterion bullet. Repeat to add more than one.",
    ),
    status: str = typer.Option("draft", help="Task status."),
    source_ref: list[str] = typer.Option(
        None,
        "--source-ref",
        help="Source reference. Repeat to add more than one.",
    ),
    allow_secrets: bool = typer.Option(
        False,
        "--allow-secrets",
        help="Allow recording content even when high-confidence secret patterns are found.",
    ),
) -> None:
    """Create a task document in .ai_memory/tasks."""

    from aimem.core.recorder import record_task

    created = record_task(
        path,
        title=title,
        goal=goal,
        done_when=done_when,
        status=status,
        source_refs=source_ref,
        allow_secrets=allow_secrets,
    )
    typer.echo(f"Created {created.relative_to(created.parents[1])}")
