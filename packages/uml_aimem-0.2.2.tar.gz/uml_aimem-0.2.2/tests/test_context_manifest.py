from __future__ import annotations

import json
import subprocess
from pathlib import Path

from typer.testing import CliRunner

from aimem.cli import app
from aimem.core.context_manifest import get_latest_context_manifest_summary

runner = CliRunner()


def git_init(path: Path) -> None:
    subprocess.run(["git", "init", "-q", str(path)], check=True)


def test_get_latest_context_manifest_summary_after_compile_uses_sqlite(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0
    assert runner.invoke(app, ["compile", "--profile", "bootstrap", str(tmp_path)]).exit_code == 0

    summary = get_latest_context_manifest_summary(tmp_path)
    assert summary is not None
    assert summary["manifest_id"]
    assert summary["created_at"]
    assert summary["aimem_uri"] == f"aimem://manifest/{summary['manifest_id']}"
    assert summary.get("compile_profile") == "bootstrap"


def test_get_latest_context_manifest_summary_filesystem_fallback(tmp_path: Path) -> None:
    git_init(tmp_path)
    memory = tmp_path / ".ai_memory"
    manifests_dir = memory / "journal" / "manifests"
    manifests_dir.mkdir(parents=True)
    payload = {
        "schema_version": "1.0",
        "manifest_id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
        "created_at": "2026-01-01T00:00:00Z",
        "repo": {"git_commit": "abc123"},
        "compile": {"profile": "implementation"},
    }
    (manifests_dir / "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.json").write_text(
        json.dumps(payload) + "\n",
        encoding="utf-8",
    )

    summary = get_latest_context_manifest_summary(tmp_path)
    assert summary is not None
    assert summary["manifest_id"] == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    assert summary["git_commit"] == "abc123"
    assert summary["compile_profile"] == "implementation"
    assert summary["aimem_uri"] == "aimem://manifest/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
