"""Tests for the shared SQLite index schema seam."""

from __future__ import annotations

import ast
import sqlite3
from pathlib import Path

from aimem.core.sqlite_index import (
    ensure_governance_schema,
    ensure_index_schema,
    ensure_retrieval_documents_schema,
    index_db_path,
)

RETRIEVAL_TABLES = frozenset({"documents"})
GOVERNANCE_TABLES = frozenset({"gold_claims", "drift_events", "context_manifests"})


def _table_names(db_path: Path) -> set[str]:
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    return {str(r[0]) for r in rows}


def test_index_db_path_under_ai_memory(tmp_path: Path) -> None:
    assert index_db_path(tmp_path) == tmp_path / ".ai_memory" / "index" / "aimem.sqlite"


def test_ensure_index_schema_creates_retrieval_and_governance_tables(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    with sqlite3.connect(db) as conn:
        ensure_index_schema(conn)
    names = _table_names(db)
    assert RETRIEVAL_TABLES <= names
    assert GOVERNANCE_TABLES <= names


def test_governance_schema_idempotent(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    with sqlite3.connect(db) as conn:
        ensure_governance_schema(conn)
        ensure_governance_schema(conn)
        conn.commit()
    assert GOVERNANCE_TABLES <= _table_names(db)


def test_retrieval_schema_adds_documents_columns(tmp_path: Path) -> None:
    db = tmp_path / "test.sqlite"
    with sqlite3.connect(db) as conn:
        conn.execute(
            """
            CREATE TABLE documents (
                relative_path TEXT PRIMARY KEY,
                document_id TEXT NOT NULL,
                kind TEXT NOT NULL,
                status TEXT NOT NULL,
                owner TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                search_text TEXT NOT NULL,
                body TEXT NOT NULL
            )
            """
        )
        ensure_retrieval_documents_schema(conn)
        conn.commit()
        cols = {
            str(r[1]) for r in conn.execute("PRAGMA table_info(documents)").fetchall()
        }
    assert "mtime" in cols
    assert "trust_score" in cols


def test_retrieval_module_does_not_import_drift() -> None:
    source_path = Path(__file__).resolve().parents[1] / "src" / "aimem" / "core" / "retrieval.py"
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    drift_imports = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.ImportFrom) and node.module and "drift" in node.module
    ]
    assert drift_imports == []
