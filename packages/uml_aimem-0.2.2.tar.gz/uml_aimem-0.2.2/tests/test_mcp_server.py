from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

import pytest

from typer.testing import CliRunner

from aimem.cli import app
from aimem.core.mcp_resources import get_agent_context_bundle_dict, read_capsule_markdown
from aimem.core.repo import RepoError
from test_cli import git_init

runner = CliRunner()

REPO_ROOT = Path(__file__).resolve().parents[1]


def _aimem_mcp_launcher() -> Path | None:
    for candidate in (
        REPO_ROOT / ".venv" / "bin" / "aimem-mcp",
        REPO_ROOT / ".venv" / "Scripts" / "aimem-mcp.exe",
        Path(sys.executable).resolve().parent / ("aimem-mcp.exe" if sys.platform == "win32" else "aimem-mcp"),
    ):
        if candidate.exists():
            return candidate
    return None


def test_get_agent_context_bundle_dict_matches_cli_json_shape(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0
    data = get_agent_context_bundle_dict(tmp_path)
    assert data["bundle_schema_version"] == "1.0"
    assert set(data.keys()) >= {
        "bundle_schema_version",
        "profile",
        "repository",
        "pinned",
        "retrieval",
        "drift",
        "acm",
    }
    assert "latest_capsule" in data["acm"]


def test_mcp_server_factory_builds_fastmcp(tmp_path) -> None:
    pytest.importorskip("mcp")
    git_init(tmp_path)
    from aimem.mcp_server import _build_mcp

    server = _build_mcp(tmp_path)
    assert getattr(server, "name", None) == "aimem"
    assert callable(getattr(server, "run", None))


def test_read_capsule_markdown_reads_file(tmp_path: Path) -> None:
    git_init(tmp_path)
    caps_dir = tmp_path / ".ai_memory" / "journal" / "capsules"
    caps_dir.mkdir(parents=True, exist_ok=True)
    body = "---\nid: capsule-test\n---\n# Capsule\n\nHello.\n"
    (caps_dir / "capsule-testid.md").write_text(body, encoding="utf-8")

    assert read_capsule_markdown(tmp_path, "capsule-testid") == body


def test_read_capsule_markdown_rejects_traversal(tmp_path: Path) -> None:
    git_init(tmp_path)
    with pytest.raises(RepoError):
        read_capsule_markdown(tmp_path, "../secrets")


def test_aimem_mcp_subprocess_stays_alive_on_stdio(tmp_path: Path) -> None:
    pytest.importorskip("mcp")
    git_init(tmp_path)
    launcher = _aimem_mcp_launcher()
    if launcher is None:
        pytest.skip("aimem-mcp entrypoint missing; run uv sync in the project root")
    proc = subprocess.Popen(
        [str(launcher), "--repo", str(tmp_path)],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        cwd=str(tmp_path),
    )
    time.sleep(0.4)
    try:
        assert proc.poll() is None
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=8)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
