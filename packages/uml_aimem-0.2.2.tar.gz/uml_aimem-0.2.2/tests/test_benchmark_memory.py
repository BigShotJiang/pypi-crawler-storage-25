import pytest
import time
from pathlib import Path
from aimem.core.agent_context import build_agent_context
from aimem.core.compiler import estimate_tokens
from aimem.core.memory import iter_canonical_documents

def setup_fake_memory(repo_root: Path):
    """Setup a heavy mock repository to test context compilation."""
    (repo_root / ".git").mkdir()
    memory_dir = repo_root / ".ai_memory"
    
    # Create required manifest
    manifest_path = memory_dir / "manifest.yaml"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text("""
schema_version: "1.0"
product:
  name: "Aimem Benchmark"
  subtitle: "Testing token limits"
paths:
  canonical: ["rules", "state", "decisions"]
compile_profiles:
  bootstrap:
    include_paths: ["rules", "state"]
    pinned_paths: ["rules/arch.md"]
    selection_mode: "retrieval"
    max_tokens: 2000
    max_results: 5
policies: {}
retention: {}
aimem_drift:
  baseline:
    compare_to_ref: "HEAD"
  budget:
    max_files_opened: 1000
""")

    # Generate 50 heavy mock documents (simulate standard silos)
    for folder in ["rules", "state", "decisions"]:
        (memory_dir / folder).mkdir(exist_ok=True)
        for i in range(15):
            body = f"Heavy design documentation and architectural notes about {folder}_{i}. " * 50
            frontmatter = f"---\nid: {folder}_{i}\nkind: {folder}\nstatus: gold\ntrust_score: 0.9\n---\n"
            (memory_dir / folder / f"doc_{i}.md").write_text(frontmatter + body)
            
    # The target doc to retrieve
    target = "---\nid: target_01\nkind: decision\nstatus: gold\n---\nWe decided to use SQLite FTS5 for local retrieval."
    (memory_dir / "decisions" / "target.md").write_text(target)


def test_token_savings_benchmark(benchmark, tmp_path):
    """
    Benchmark to prove token savings: Traditional 'Silo' Approach vs 'aimem' MCP approach.
    """
    setup_fake_memory(tmp_path)
    
    # 1. Silo Approach (The AI reads all markdown files in the folders)
    def traditional_silo_read():
        docs = iter_canonical_documents(tmp_path, ["rules", "state", "decisions"])
        full_text = "\\n".join([doc.body for doc in docs])
        return full_text
        
    # 2. aimem Approach (Objective-based Context Compilation)
    def aimem_mcp_read():
        return build_agent_context(
            tmp_path,
            profile="bootstrap",
            objective="SQLite FTS5 decisions",
            output_format="text"
        )
        
    silo_text = traditional_silo_read()
    silo_tokens = estimate_tokens(silo_text)
    
    # We benchmark the aimem generation time and token output
    aimem_text = benchmark(aimem_mcp_read)
    aimem_tokens = estimate_tokens(aimem_text)
    
    savings = (1 - (aimem_tokens / silo_tokens)) * 100
    
    print(f"\\n--- Benchmark Results ---")
    print(f"Traditional Silo Tokens: {silo_tokens}")
    print(f"aimem Context Tokens:  {aimem_tokens}")
    print(f"Token Savings: {savings:.2f}%")
    
    assert aimem_tokens < silo_tokens
    assert "SQLite FTS5" in aimem_text, "The FTS5 target should have been retrieved by aimem."
    assert savings > 80, "aimem should save at least 80% tokens on a heavy repo."
