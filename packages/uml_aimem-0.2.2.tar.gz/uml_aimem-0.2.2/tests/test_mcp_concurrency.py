import pytest
import asyncio
import threading
from pathlib import Path
from aimem.core.retrieval import query_memory
from aimem.core.drift import run_drift_scan
from test_benchmark_memory import setup_fake_memory

@pytest.mark.asyncio
async def test_mcp_concurrency(tmp_path):
    """
    Test that the MCP agent can query the memory concurrently 
    while the CLI drift scan is writing to it, without 'database is locked' errors.
    """
    setup_fake_memory(tmp_path)
    
    # Pre-index to avoid first-run massive writes
    query_memory(tmp_path, objective="SQLite", top_k=5)
    
    errors = []
    
    def background_drift_scan():
        try:
            for _ in range(5):
                run_drift_scan(tmp_path)
        except Exception as e:
            errors.append(e)
            
    # Start writing drift scans in a thread
    t = threading.Thread(target=background_drift_scan)
    t.start()
    
    # Concurrently run multiple MCP reads
    async def mcp_read(i):
        try:
            await asyncio.to_thread(query_memory, tmp_path, objective=f"Test {i}", top_k=3)
        except Exception as e:
            errors.append(e)
            
    tasks = [mcp_read(i) for i in range(20)]
    await asyncio.gather(*tasks)
    
    t.join()
    
    assert not errors, f"Concurrency test failed with errors: {errors}"
