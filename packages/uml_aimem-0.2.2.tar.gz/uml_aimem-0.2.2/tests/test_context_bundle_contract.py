"""Regression for `aimem context --format json` / MCP bundle shape (docs/context-bundle.md)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from aimem.cli import app
from aimem.core.context_contract import (
    ContextBundleRequest,
    ContextContractError,
    build_context_dict,
)
from aimem.core.mcp_resources import get_agent_context_bundle_dict

from test_cli import git_init

runner = CliRunner()

REQUIRED_ROOT_KEYS = frozenset(
    {
        "bundle_schema_version",
        "profile",
        "repository",
        "pinned",
        "retrieval",
        "drift",
        "acm",
    }
)
REQUIRED_REPOSITORY_KEYS = frozenset(
    {"product_name", "schema_version", "git_head", "branch", "working_tree_dirty"},
)
REQUIRED_RETRIEVAL_KEYS = frozenset(
    {"objective", "index", "backend", "ranking_mode", "refreshed_docs", "reindexed_paths", "hits"}
)
REQUIRED_PINNED_ENTRY_KEYS = frozenset({"relative_path", "missing", "body_excerpt", "truncated"})
REQUIRED_ACM_KEYS = frozenset({"latest", "from_compile_this_run", "latest_capsule"})


def test_context_json_bundle_contract_minimal_repo(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0

    result = runner.invoke(app, ["context", str(tmp_path), "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.stdout)

    assert set(data.keys()) == REQUIRED_ROOT_KEYS
    assert data["bundle_schema_version"] == "1.0"
    assert set(data["repository"].keys()) == REQUIRED_REPOSITORY_KEYS
    assert set(data["retrieval"].keys()) == REQUIRED_RETRIEVAL_KEYS
    assert isinstance(data["retrieval"]["reindexed_paths"], int)
    assert isinstance(data["pinned"], list) and data["pinned"]
    for p in data["pinned"]:
        assert set(p.keys()) == REQUIRED_PINNED_ENTRY_KEYS
    assert set(data["acm"].keys()) == REQUIRED_ACM_KEYS


def test_mcp_get_agent_context_bundle_dict_same_contract(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0
    data = get_agent_context_bundle_dict(tmp_path)
    assert set(data.keys()) == REQUIRED_ROOT_KEYS


def test_context_contract_rejects_json_max_chars_without_json_format() -> None:
    with pytest.raises(ContextContractError, match="json-max-chars"):
        ContextBundleRequest.from_cli_args(
            profile="bootstrap",
            objective=None,
            top_k=5,
            max_chars=12000,
            output_format="markdown",
            after_compile=False,
            compile_profile=None,
            compile_objective=None,
            allow_secrets_compile=False,
            json_max_chars=5000,
        )


def test_context_contract_cli_and_mcp_requests_share_builder_kwargs() -> None:
    cli_request = ContextBundleRequest.from_cli_args(
        profile="bootstrap",
        objective="parity check",
        top_k=3,
        max_chars=12000,
        output_format="json",
        after_compile=False,
        compile_profile=None,
        compile_objective=None,
        allow_secrets_compile=False,
        json_max_chars=None,
    )
    mcp_request = ContextBundleRequest.from_mcp_args(
        profile="bootstrap",
        objective="parity check",
        top_k=3,
        max_chars=12000,
        after_compile=False,
        compile_profile=None,
        compile_objective=None,
        allow_secrets_compile=False,
        json_max_chars=None,
    )
    assert cli_request.bundle_builder_kwargs() == mcp_request.bundle_builder_kwargs()
    assert cli_request.output_format == "json"
    assert mcp_request.output_format == "json"


def test_context_contract_build_context_dict_contract(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0

    request = ContextBundleRequest.from_mcp_args(
        profile="bootstrap",
        objective="parity check",
        top_k=3,
    )
    data = build_context_dict(tmp_path, request)
    assert set(data.keys()) == REQUIRED_ROOT_KEYS
    assert data["bundle_schema_version"] == "1.0"
    assert data["retrieval"]["objective"] == "parity check"
