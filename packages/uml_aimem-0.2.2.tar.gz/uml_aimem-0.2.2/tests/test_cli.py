from __future__ import annotations

import importlib
import json
import subprocess
import time
from pathlib import Path

import pytest
import yaml
from typer.testing import CliRunner

from aimem.cli import app
from aimem.core.mcp_resources import get_drift_alerts, query_capsules
from aimem.core.memory import split_frontmatter

runner = CliRunner()


def git_init(path: Path) -> None:
    subprocess.run(["git", "init", "-q", str(path)], check=True)


def git_commit_all(path: Path, message: str) -> None:
    subprocess.run(["git", "-C", str(path), "add", "."], check=True)
    subprocess.run(
        [
            "git",
            "-C",
            str(path),
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-q",
            "-m",
            message,
        ],
        check=True,
    )


def test_init_creates_structure_and_gitignore(tmp_path: Path) -> None:
    git_init(tmp_path)

    result = runner.invoke(app, ["init", str(tmp_path)])

    assert result.exit_code == 0
    memory_root = tmp_path / ".ai_memory"
    assert (memory_root / "manifest.yaml").exists()
    assert (memory_root / "rules" / "product.md").exists()
    assert (memory_root / "state" / "project.md").exists()
    assert (memory_root / "decisions" / "decision-0001-memory-contract.md").exists()
    assert (memory_root / "tasks" / "task-0001-bootstrap-foundation.md").exists()
    assert (memory_root / "journal" / "events.jsonl").exists()
    manifest = yaml.safe_load((memory_root / "manifest.yaml").read_text(encoding="utf-8"))
    assert "aimem_drift" in manifest
    assert "baseline" in manifest["aimem_drift"]
    gitignore_text = (tmp_path / ".gitignore").read_text(encoding="utf-8")
    assert "# >>> aimem managed >>>" in gitignore_text
    assert ".ai_memory/generated/" in gitignore_text


def test_init_from_subdirectory_uses_repo_root(tmp_path: Path) -> None:
    git_init(tmp_path)
    nested = tmp_path / "src" / "feature"
    nested.mkdir(parents=True)

    result = runner.invoke(app, ["init", str(nested)])

    assert result.exit_code == 0
    assert (tmp_path / ".ai_memory" / "manifest.yaml").exists()


def test_init_fails_outside_git_repo(tmp_path: Path) -> None:
    result = runner.invoke(app, ["init", str(tmp_path)])

    assert result.exit_code != 0
    assert "No Git repository found" in result.stdout or "No Git repository found" in str(result.exception)


def test_init_is_idempotent_and_does_not_overwrite(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    target = tmp_path / ".ai_memory" / "rules" / "product.md"
    custom_text = target.read_text(encoding="utf-8") + "\nCustom line preserved.\n"
    target.write_text(custom_text, encoding="utf-8")

    result = runner.invoke(app, ["init", str(tmp_path)])

    assert result.exit_code == 0
    assert target.read_text(encoding="utf-8").endswith("Custom line preserved.\n")


def test_compile_generates_deterministic_profile_output(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    generated = tmp_path / ".ai_memory" / "generated" / "implementation.md"
    result_one = runner.invoke(app, ["compile", "--profile", "implementation", str(tmp_path)])
    text_one = generated.read_text(encoding="utf-8")

    result_two = runner.invoke(app, ["compile", "--profile", "implementation", str(tmp_path)])
    text_two = generated.read_text(encoding="utf-8")

    assert result_one.exit_code == 0
    assert result_two.exit_code == 0
    assert "Source: .ai_memory/rules/product.md" in text_one
    assert text_one == text_two


def test_compile_with_objective_uses_retrieval_mode_and_pinned_docs(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(
        app,
        [
            "record",
            "task",
            "Implement retrieval layer",
            str(tmp_path),
            "--goal",
            "Recover relevant memory with local indexing and MCP-ready context selection.",
            "--done-when",
            "compile reuses retrieval for objective-aware packs",
        ],
    )

    result = runner.invoke(
        app,
        [
            "compile",
            "--profile",
            "implementation",
            "--objective",
            "retrieval MCP local indexing",
            str(tmp_path),
        ],
    )

    compiled = (tmp_path / ".ai_memory" / "generated" / "implementation.md").read_text(encoding="utf-8")
    assert result.exit_code == 0
    assert "Selection mode: retrieval" in compiled
    assert "Objective: retrieval MCP local indexing" in compiled
    assert "Source: .ai_memory/rules/product.md" in compiled
    assert "Source: .ai_memory/tasks/task-0002-implement-retrieval-layer.md" in compiled
    # Retrieval hits include score in Source metadata (e.g. `[... | score:6.356]`).
    assert "| score:" in compiled


def test_compile_ignores_generated_markdown_inputs(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    noisy = tmp_path / ".ai_memory" / "generated" / "noise.md"
    noisy.write_text("# should never be re-ingested\n", encoding="utf-8")

    runner.invoke(app, ["compile", "--profile", "handoff", str(tmp_path)])

    compiled = (tmp_path / ".ai_memory" / "generated" / "handoff.md").read_text(encoding="utf-8")
    assert "should never be re-ingested" not in compiled


def test_compile_with_objective_respects_budget_with_excerpt(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    manifest_path = tmp_path / ".ai_memory" / "manifest.yaml"
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest["compile_profiles"]["implementation"]["max_chars"] = 1100
    manifest["compile_profiles"]["implementation"]["snippet_chars"] = 120
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")

    runner.invoke(
        app,
        [
            "record",
            "task",
            "Implement retrieval layer",
            str(tmp_path),
            "--goal",
            "Recover relevant memory with local indexing and objective-aware compilation.",
            "--done-when",
            "compile uses retrieval under a small budget",
        ],
    )

    result = runner.invoke(
        app,
        [
            "compile",
            "--profile",
            "implementation",
            "--objective",
            "retrieval compilation budget",
            str(tmp_path),
        ],
    )

    compiled = (tmp_path / ".ai_memory" / "generated" / "implementation.md").read_text(encoding="utf-8")
    assert result.exit_code == 0
    assert "[budget exhausted]" in compiled or "- excerpt: true" in compiled


def test_verify_detects_stale_referenced_files(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    source_file = tmp_path / "service.py"
    source_file.write_text("print('v1')\n", encoding="utf-8")

    state_doc = tmp_path / ".ai_memory" / "state" / "project.md"
    document = state_doc.read_text(encoding="utf-8")
    frontmatter, body = split_frontmatter(document)
    frontmatter["verified_at"] = "2024-01-01T00:00:00Z"
    frontmatter["verified_from"] = {"files": ["service.py"], "git_commit": None}
    updated = "---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body
    state_doc.write_text(updated, encoding="utf-8")

    time.sleep(1.1)
    source_file.write_text("print('v2')\n", encoding="utf-8")

    result = runner.invoke(app, ["verify", str(tmp_path)])

    assert result.exit_code == 1
    assert "STALE" in result.stdout
    assert "service.py" in result.stdout


def test_all_command_modules_import_without_error() -> None:
    modules = [
        "aimem.commands.compile",
        "aimem.commands.context",
        "aimem.commands.drift",
        "aimem.commands.hooks",
        "aimem.commands.index",
        "aimem.commands.init",
        "aimem.commands.manifest",
        "aimem.commands.promote",
        "aimem.commands.query",
        "aimem.commands.record",
        "aimem.commands.verify",
    ]
    for name in modules:
        mod = importlib.import_module(name)
        for attr in dir(mod):
            if attr.endswith("_command") or attr.endswith("_app"):
                getattr(mod, attr)
    import aimem.cli as cli_mod

    assert cli_mod.app is not None


@pytest.mark.parametrize(
    "argv",
    [
        ["init", "--help"],
        ["compile", "--help"],
        ["context", "--help"],
        ["query", "--help"],
        ["verify", "--help"],
        ["install-hooks", "--help"],
        ["promote", "--help"],
        ["record", "decision", "--help"],
        ["record", "task", "--help"],
        ["drift", "scan", "--help"],
        ["manifest", "get", "--help"],
        ["index", "rebuild", "--help"],
    ],
)
def test_cli_help_smoke(argv: list[str]) -> None:
    result = runner.invoke(app, argv)
    assert result.exit_code == 0, result.stdout + str(result.stderr)


def test_query_memory_reindexes_single_path_after_canonical_edit(tmp_path: Path) -> None:
    git_init(tmp_path)
    assert runner.invoke(app, ["init", str(tmp_path)]).exit_code == 0
    from aimem.core.retrieval import query_memory

    objective = "product rules memory bootstrap"
    first = query_memory(tmp_path, objective=objective, top_k=3)
    assert first.reindexed_paths > 0
    second = query_memory(tmp_path, objective=objective, top_k=3)
    assert second.reindexed_paths == 0
    product = tmp_path / ".ai_memory" / "rules" / "product.md"
    product.write_text(product.read_text(encoding="utf-8") + "\n", encoding="utf-8")
    third = query_memory(tmp_path, objective=objective, top_k=3)
    assert third.reindexed_paths >= 1


def test_verify_check_retrieval_index_warns_when_index_missing(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["verify", "--check-retrieval-index", str(tmp_path)])

    assert result.exit_code == 0
    assert "NOTE: Retrieval index not built yet" in result.stdout


def test_verify_fast_rejects_check_retrieval_index(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    result = runner.invoke(app, ["verify", "--fast", "--check-retrieval-index", str(tmp_path)])
    assert result.exit_code != 0


def test_verify_check_retrieval_index_silent_when_index_matches(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(app, ["query", "memory contract bootstrap", str(tmp_path)])

    result = runner.invoke(app, ["verify", "--check-retrieval-index", str(tmp_path)])

    assert result.exit_code == 0
    assert "NOTE: Retrieval index" not in result.stdout


def test_verify_reports_manifest_and_unverified_documents(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["verify", str(tmp_path)])

    assert result.exit_code == 0
    assert "Manifest: ok" in result.stdout
    assert "UNVERIFIED" in result.stdout


def test_verify_refresh_promotes_documents_to_ok(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    git_commit_all(tmp_path, "init memory")

    result = runner.invoke(app, ["verify", "--refresh", str(tmp_path)])

    assert result.exit_code == 0
    assert "Refreshed" in result.stdout
    assert "OK" in result.stdout

    project_doc = tmp_path / ".ai_memory" / "state" / "project.md"
    frontmatter, _ = split_frontmatter(project_doc.read_text(encoding="utf-8"))
    assert frontmatter["verified_at"]
    assert frontmatter["verified_from"]["git_commit"]
    assert "T" in str(frontmatter["updated_at"])


def test_record_decision_creates_typed_document_and_journal_entry(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(
        app,
        [
            "record",
            "decision",
            "Adopt MCP resources",
            str(tmp_path),
            "--context",
            "Need a native bridge for tool-compatible IDEs.",
            "--decision",
            "Expose canonical memory through MCP resources first.",
            "--consequence",
            "Keep write operations out of V1 MCP scope.",
            "--source-ref",
            "roadmap-v3",
        ],
    )

    assert result.exit_code == 0
    created = tmp_path / ".ai_memory" / "decisions" / "decision-0002-adopt-mcp-resources.md"
    assert created.exists()
    text = created.read_text(encoding="utf-8")
    assert "id: decision-0002" in text
    assert "## Decision" in text
    assert "Expose canonical memory through MCP resources first." in text

    events = (tmp_path / ".ai_memory" / "journal" / "events.jsonl").read_text(encoding="utf-8")
    assert '"operation": "record_decision"' in events
    assert '"target": ".ai_memory/decisions/decision-0002-adopt-mcp-resources.md"' in events


def test_record_task_creates_incremented_task_file(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(
        app,
        [
            "record",
            "task",
            "Add retrieval layer",
            str(tmp_path),
            "--goal",
            "Recover only relevant project context for a user objective.",
            "--done-when",
            "query selects relevant memory documents",
            "--done-when",
            "local index remains gitignored",
            "--status",
            "draft",
            "--source-ref",
            "phase-2",
        ],
    )

    assert result.exit_code == 0
    created = tmp_path / ".ai_memory" / "tasks" / "task-0002-add-retrieval-layer.md"
    assert created.exists()
    text = created.read_text(encoding="utf-8")
    assert "id: task-0002" in text
    assert "status: draft" in text
    assert "criticality: medium" in text
    assert "Recover only relevant project context for a user objective." in text
    assert "- local index remains gitignored" in text


def test_second_query_skips_index_row_updates_when_files_unchanged(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(
        app,
        [
            "record",
            "task",
            "Implement retrieval layer",
            str(tmp_path),
            "--goal",
            "Recover only the most relevant shared memory for an objective using local indexing.",
            "--done-when",
            "query retrieves relevant canonical documents",
        ],
    )
    first = runner.invoke(app, ["query", "retrieval local indexing", str(tmp_path), "--top-k", "3"])
    assert first.exit_code == 0
    assert "Index rows updated:" in first.stdout
    second = runner.invoke(app, ["query", "retrieval local indexing", str(tmp_path), "--top-k", "3"])
    assert second.exit_code == 0
    assert "Index rows updated:" not in second.stdout


def test_index_rebuild_runs_successfully(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(app, ["query", "memory contract", str(tmp_path)])
    result = runner.invoke(app, ["index", "rebuild", str(tmp_path)])
    assert result.exit_code == 0
    assert "Rebuilt retrieval index" in result.stdout
    assert "aimem.sqlite" in result.stdout


def test_importing_cli_avoids_compiler_and_agent_context_modules() -> None:
    import os
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    code = (
        "import sys\n"
        "import aimem.cli  # noqa: F401\n"
        "for name in ('aimem.core.compiler', 'aimem.core.agent_context', 'aimem.core.drift'):\n"
        "    assert name not in sys.modules, name\n"
        "print('ok')\n"
    )
    proc = subprocess.run(
        [sys.executable, "-c", code],
        cwd=root,
        env={**os.environ, "PYTHONPATH": str(root / "src")},
        capture_output=True,
        text=True,
        check=False,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert proc.stdout.strip() == "ok"


def test_context_json_max_chars_produces_smaller_serialized_payload(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    full = runner.invoke(app, ["context", str(tmp_path), "--format", "json"])
    capped = runner.invoke(
        app,
        ["context", str(tmp_path), "--format", "json", "--json-max-chars", "3500"],
    )
    assert full.exit_code == 0 and capped.exit_code == 0
    assert len(capped.stdout) < len(full.stdout)
    data = json.loads(capped.stdout)
    assert data["bundle_schema_version"] == "1.0"
    assert "reindexed_paths" in data["retrieval"]


def test_query_builds_local_index_and_returns_relevant_documents(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(
        app,
        [
            "record",
            "task",
            "Implement retrieval layer",
            str(tmp_path),
            "--goal",
            "Recover only the most relevant shared memory for an objective using local indexing.",
            "--done-when",
            "query retrieves relevant canonical documents",
        ],
    )

    result = runner.invoke(app, ["query", "retrieval local indexing", str(tmp_path), "--top-k", "3"])

    assert result.exit_code == 0
    assert "Backend:" in result.stdout
    assert "Ranking mode: hybrid_metadata" in result.stdout
    assert "Refreshed docs:" in result.stdout
    assert ".ai_memory/tasks/task-0002-implement-retrieval-layer.md" in result.stdout
    assert (tmp_path / ".ai_memory" / "index" / "aimem.sqlite").exists()


def test_context_prints_repo_pinned_retrieval_and_drift_sections(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    git_commit_all(tmp_path, "init")

    result = runner.invoke(app, ["context", str(tmp_path)])

    assert result.exit_code == 0
    out = result.stdout
    assert "## Repository" in out
    assert "## Pinned baseline" in out
    assert ".ai_memory/rules/product.md" in out
    assert ".ai_memory/state/project.md" in out
    assert "## Retrieval" in out
    assert "Objective:" in out
    assert "Current project state" in out
    assert "## Drift (open events)" in out
    assert "No open drift events." in out
    assert "## Context manifests (ACM)" in out


def test_context_text_format_avoids_markdown_bold_in_repo_and_drift(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["context", str(tmp_path), "--format", "text"])

    assert result.exit_code == 0
    out = result.stdout
    assert "=== Repository ===" in out
    assert "- Product (manifest):" in out
    assert "=== Drift (open events) ===" in out
    assert "Open:" in out or "No open drift events." in out
    assert "Context manifests (ACM)" in out


def test_context_json_includes_repository_pinned_retrieval_drift_acm(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["context", str(tmp_path), "--format", "json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["bundle_schema_version"] == "1.0"
    assert "repository" in data
    assert data["repository"]["product_name"]
    assert "pinned" in data
    assert any(p["relative_path"] == "rules/product.md" for p in data["pinned"])
    assert "retrieval" in data and "hits" in data["retrieval"]
    assert "drift" in data
    assert "acm" in data
    assert "latest" in data["acm"]


def test_context_after_compile_populates_from_compile_this_run(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(
        app,
        [
            "context",
            str(tmp_path),
            "--format",
            "json",
            "--after-compile",
            "--compile-profile",
            "bootstrap",
        ],
    )

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    fcr = data["acm"].get("from_compile_this_run")
    assert fcr is not None
    assert fcr["manifest_id"]
    assert fcr["aimem_uri"] == f"aimem://manifest/{fcr['manifest_id']}"
    assert data["acm"]["latest"]["manifest_id"] == fcr["manifest_id"]


def test_context_lists_open_drift_after_scan(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["aimem_claims"] = [
        {
            "id": "api.no.graphql",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL endpoint exists.",
            "rule": {
                "type": "path_not_exists",
                "glob": "**/graphql/**",
            },
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    assert runner.invoke(app, ["drift", "scan", str(tmp_path)]).exit_code == 0

    json_out = runner.invoke(app, ["context", str(tmp_path), "--format", "json"])
    assert json_out.exit_code == 0
    payload = json.loads(json_out.stdout)
    assert len(payload["drift"]) >= 1
    assert any(e.get("claim_id") == "api.no.graphql" for e in payload["drift"])
    assert all("aimem_uri" in e and "drift-event" in str(e["aimem_uri"]) for e in payload["drift"])

    md_out = runner.invoke(app, ["context", str(tmp_path)])
    assert md_out.exit_code == 0
    assert "api.no.graphql" in md_out.stdout


def test_install_hooks_creates_pre_commit_and_pre_push(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["install-hooks", str(tmp_path)])

    assert result.exit_code == 0
    pre_commit = tmp_path / ".git" / "hooks" / "pre-commit"
    pre_push = tmp_path / ".git" / "hooks" / "pre-push"
    assert pre_commit.exists()
    assert pre_push.exists()
    assert "verify --fast" in pre_commit.read_text(encoding="utf-8")


def test_verify_strict_requires_two_reviewers_for_gold_high(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["criticality"] = "high"
    frontmatter["review_consensus"] = ["human"]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")

    result = runner.invoke(app, ["verify", "--strict", str(tmp_path)])

    assert result.exit_code == 1
    assert "requires at least 2 reviewers" in result.stdout


def test_query_excludes_deprecated_by_default(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    runner.invoke(
        app,
        [
            "record",
            "task",
            "Legacy retrieval strategy",
            str(tmp_path),
            "--goal",
            "Old deprecated strategy for historical compatibility.",
            "--status",
            "deprecated",
        ],
    )

    result = runner.invoke(app, ["query", "legacy retrieval strategy", str(tmp_path), "--top-k", "5"])

    assert result.exit_code == 0
    assert "task-0002-legacy-retrieval-strategy.md" not in result.stdout


def test_compile_token_budget_fallback_keeps_output_under_char_limit(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    manifest_path = tmp_path / ".ai_memory" / "manifest.yaml"
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest["compile_profiles"]["implementation"]["max_tokens"] = 100
    manifest["compile_profiles"]["implementation"]["max_chars"] = 500
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")

    result = runner.invoke(app, ["compile", "--profile", "implementation", str(tmp_path)])

    assert result.exit_code == 0
    compiled = (tmp_path / ".ai_memory" / "generated" / "implementation.md").read_text(encoding="utf-8")
    assert "Budget tokens: 100" in compiled
    assert len(compiled) <= 520


def test_drift_scan_creates_events_from_gold_claims(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["aimem_claims"] = [
        {
            "id": "api.no.graphql",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL endpoint exists.",
            "rule": {
                "type": "path_not_exists",
                "glob": "**/graphql/**",
            },
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    result = runner.invoke(app, ["drift", "scan", str(tmp_path)])

    assert result.exit_code == 0
    assert "Open drift events: 1" in result.stdout
    assert "api.no.graphql" in result.stdout


def test_drift_reconcile_creates_capsule_and_mcp_helpers_read_it(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["aimem_claims"] = [
        {
            "id": "imports.requests.required",
            "enforce_when": "gold_only",
            "assertion": "Requests must be imported under src.",
            "rule": {
                "type": "import_present",
                "language": "python",
                "module": "requests",
                "under_glob": "src/**/*.py",
            },
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src").mkdir(parents=True, exist_ok=True)
    (tmp_path / "src" / "app.py").write_text("print('no import')\n", encoding="utf-8")

    runner.invoke(app, ["drift", "scan", str(tmp_path)])
    reconcile = runner.invoke(app, ["drift", "reconcile", str(tmp_path)])

    assert reconcile.exit_code == 0
    assert "Created capsule:" in reconcile.stdout
    report = runner.invoke(app, ["drift", "report", str(tmp_path)])
    assert "status=reviewed" in report.stdout

    capsules = query_capsules(tmp_path)
    alerts = get_drift_alerts(tmp_path, min_severity="low")
    assert capsules
    assert alerts


def test_compile_emits_context_manifest_and_manifest_get_returns_json(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    result = runner.invoke(app, ["compile", "--profile", "implementation", str(tmp_path)])

    assert result.exit_code == 0
    marker = "Context manifest: aimem://manifest/"
    assert marker in result.stdout
    manifest_id = result.stdout.split(marker, 1)[1].strip().splitlines()[0]
    manifest_file = tmp_path / ".ai_memory" / "journal" / "manifests" / f"{manifest_id}.json"
    assert manifest_file.exists()

    manifest_result = runner.invoke(app, ["manifest", "get", manifest_id, str(tmp_path)])
    assert manifest_result.exit_code == 0
    assert '"schema_version": "1.0"' in manifest_result.stdout
    assert f'"manifest_id": "{manifest_id}"' in manifest_result.stdout
    from aimem import __version__ as expected_version

    assert f'"aimem_version": "{expected_version}"' in manifest_result.stdout


def test_drift_scan_respects_ignore_globs(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["aimem_claims"] = [
        {
            "id": "venv.must.not.exist",
            "enforce_when": "gold_only",
            "assertion": "No virtual env folders should be scanned as drift signal.",
            "rule": {"type": "path_not_exists", "glob": "**/.venv/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / ".venv" / "bin").mkdir(parents=True)
    (tmp_path / ".venv" / "bin" / "python").write_text("fake\n", encoding="utf-8")

    result = runner.invoke(app, ["drift", "scan", str(tmp_path)])

    assert result.exit_code == 0
    assert "Open drift events: 0" in result.stdout


def test_drift_apply_dry_run_then_write_sets_drifted(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["trust_score"] = 0.2
    frontmatter["aimem_claims"] = [
        {
            "id": "gov.drift.test",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    assert runner.invoke(app, ["drift", "scan", str(tmp_path)]).exit_code == 0

    dry = runner.invoke(app, ["drift", "apply", str(tmp_path)])
    assert dry.exit_code == 0
    assert "dry-run" in dry.stdout
    fm_dry, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    assert fm_dry.get("verification_status") != "drifted"

    write = runner.invoke(app, ["drift", "apply", str(tmp_path), "--write"])
    assert write.exit_code == 0
    fm_write, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    assert fm_write.get("verification_status") == "drifted"
    assert "drift_note" in fm_write


def test_drift_apply_respects_min_severity_critical(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    manifest_path = tmp_path / ".ai_memory" / "manifest.yaml"
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest.setdefault("aimem_drift", {})["governance_apply"] = {"min_severity": "critical"}
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")

    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    # trust_score 0.4 -> drift_score 0.8 => severity high (not critical), so min_severity critical filters it out
    frontmatter["trust_score"] = 0.4
    frontmatter["aimem_claims"] = [
        {
            "id": "gov.severity.high.only",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    scan = runner.invoke(app, ["drift", "scan", str(tmp_path)])
    assert scan.exit_code == 0
    assert "[high]" in scan.stdout
    apply_out = runner.invoke(app, ["drift", "apply", str(tmp_path), "--write"])
    assert apply_out.exit_code == 0
    assert "No matching" in apply_out.stdout
    fm, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    assert fm.get("verification_status") != "drifted"


def test_drift_apply_min_severity_medium_includes_medium_event(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    manifest_path = tmp_path / ".ai_memory" / "manifest.yaml"
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest.setdefault("aimem_drift", {})["governance_apply"] = {"min_severity": "medium"}
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")

    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["trust_score"] = 0.9
    frontmatter["aimem_claims"] = [
        {
            "id": "gov.severity.medium",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    assert runner.invoke(app, ["drift", "scan", str(tmp_path)]).exit_code == 0
    assert runner.invoke(app, ["drift", "apply", str(tmp_path), "--write"]).exit_code == 0
    fm, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    assert fm.get("verification_status") == "drifted"


def test_drift_apply_claim_id_updates_single_document(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])

    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    fm_d, body_d = split_frontmatter(decision.read_text(encoding="utf-8"))
    fm_d["status"] = "gold"
    fm_d["trust_score"] = 0.2
    fm_d["aimem_claims"] = [
        {
            "id": "claim.decision.graphql",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(fm_d, sort_keys=False) + "---\n" + body_d, encoding="utf-8")

    task_path = tmp_path / ".ai_memory" / "tasks" / "task-0001-bootstrap-foundation.md"
    fm_t, body_t = split_frontmatter(task_path.read_text(encoding="utf-8"))
    fm_t["status"] = "gold"
    fm_t["trust_score"] = 0.2
    fm_t["aimem_claims"] = [
        {
            "id": "claim.task.graphql",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    task_path.write_text("---\n" + yaml.safe_dump(fm_t, sort_keys=False) + "---\n" + body_t, encoding="utf-8")

    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    assert runner.invoke(app, ["drift", "scan", str(tmp_path)]).exit_code == 0
    out = runner.invoke(
        app,
        ["drift", "apply", str(tmp_path), "--write", "--claim-id", "claim.decision.graphql"],
    )
    assert out.exit_code == 0

    fm_dec, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    fm_task, _ = split_frontmatter(task_path.read_text(encoding="utf-8"))
    assert fm_dec.get("verification_status") == "drifted"
    assert fm_task.get("verification_status") != "drifted"


def test_drift_scan_emits_critical_for_very_low_trust(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["trust_score"] = 0.05
    frontmatter["aimem_claims"] = [
        {
            "id": "gov.critical.signal",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    scan = runner.invoke(app, ["drift", "scan", str(tmp_path)])
    assert scan.exit_code == 0
    assert "[critical]" in scan.stdout


def test_drift_apply_min_severity_high_includes_critical(tmp_path: Path) -> None:
    git_init(tmp_path)
    runner.invoke(app, ["init", str(tmp_path)])
    manifest_path = tmp_path / ".ai_memory" / "manifest.yaml"
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    manifest.setdefault("aimem_drift", {})["governance_apply"] = {"min_severity": "high"}
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")

    decision = tmp_path / ".ai_memory" / "decisions" / "decision-0001-memory-contract.md"
    frontmatter, body = split_frontmatter(decision.read_text(encoding="utf-8"))
    frontmatter["status"] = "gold"
    frontmatter["trust_score"] = 0.05
    frontmatter["aimem_claims"] = [
        {
            "id": "gov.critical.apply",
            "enforce_when": "gold_only",
            "assertion": "No GraphQL folder.",
            "rule": {"type": "path_not_exists", "glob": "**/graphql/**"},
        }
    ]
    decision.write_text("---\n" + yaml.safe_dump(frontmatter, sort_keys=False) + "---\n" + body, encoding="utf-8")
    (tmp_path / "src" / "graphql").mkdir(parents=True)
    (tmp_path / "src" / "graphql" / "schema.graphql").write_text("type Query { ok: Boolean }\n", encoding="utf-8")

    assert runner.invoke(app, ["drift", "scan", str(tmp_path)]).exit_code == 0
    assert runner.invoke(app, ["drift", "apply", str(tmp_path), "--write"]).exit_code == 0
    fm, _ = split_frontmatter(decision.read_text(encoding="utf-8"))
    assert fm.get("verification_status") == "drifted"
