""" 通过请求api 返回最终金融数据"""

__version__ = "0.0.6"
from .core import (
    KjjApi
)

__all__ = ["KjjApi", "__version__"]