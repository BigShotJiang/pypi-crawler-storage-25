# -*- coding: utf-8 -*-
import sys
import os

curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.append(curPath)
""" 
    @Description
    @Author：yanlei.wang
    @file： tools.py
    @date：2026/3/13 13:37
"""
def to_camel_case(snake_str):
    """将 snake_case 转换为 camelCase"""
    components = snake_str.split('_')
    # 第一个单词保持小写，其余单词首字母大写
    return components[0] + ''.join(x.capitalize() for x in components[1:])