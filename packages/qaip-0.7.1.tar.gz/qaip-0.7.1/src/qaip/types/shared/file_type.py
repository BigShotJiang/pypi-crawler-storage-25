# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["FileType"]

FileType: TypeAlias = Literal[
    "html",
    "pdf",
    "ppt",
    "pptx",
    "pptm",
    "doc",
    "docx",
    "docm",
    "xls",
    "xlsx",
    "xlsm",
    "md",
    "txt",
    "jsonl",
    "png",
    "jpg",
    "webp",
    "heic",
    "heif",
    "wav",
    "mp3",
    "aiff",
    "aac",
    "m4a",
    "ogg",
    "flac",
    "mp4",
    "mpg",
    "mov",
    "avi",
    "flv",
    "webm",
    "wmv",
    "3gp",
    "notion_page",
]
