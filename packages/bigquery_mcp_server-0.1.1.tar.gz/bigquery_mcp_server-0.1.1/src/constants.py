"""Global constants for the BigQuery MCP server."""

import os

# --------------------------------------------------------------------------- #
# BigQuery Configuration
# --------------------------------------------------------------------------- #

# GCP Project ID (required)
BIGQUERY_PROJECT_ID: str = os.getenv("BIGQUERY_PROJECT_ID", "")

# Dataset region (default: US)
BIGQUERY_LOCATION: str = os.getenv("BIGQUERY_LOCATION", "US")

# Service account JSON content — the raw JSON string, NOT a file path.
BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT: str = os.getenv("BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT", "")

# --------------------------------------------------------------------------- #
# Query Safety
# --------------------------------------------------------------------------- #

# Maximum rows returned when the user omits a LIMIT clause
DEFAULT_ROW_LIMIT: int = 1000

# Approximate on-demand pricing for dry-run cost estimates (USD per TB)
COST_PER_TB: float = 6.25

# --------------------------------------------------------------------------- #
# Server
# --------------------------------------------------------------------------- #

# Character limit for very large responses
CHARACTER_LIMIT: int = 50_000

# HTTP transport port
PORT: int = int(os.getenv("PORT", "8000"))
