"""BigQuery tools — the core of the MCP server.

Provides five tools for interacting with Google BigQuery:

- bq_list_datasets   — list all datasets in the project
- bq_list_tables     — list tables (with row counts & size) in a dataset
- bq_get_schema      — get the full schema of a table
- bq_dry_run         — validate SQL and estimate cost
- bq_run_query       — execute SQL and return results
"""

from __future__ import annotations

import json
import re

from google.cloud import bigquery
from mcp.server.fastmcp import Context, FastMCP
from pydantic import BaseModel, ConfigDict, Field

from src.constants import COST_PER_TB, DEFAULT_ROW_LIMIT
from src.services.error_handler import handle_bq_error


# --------------------------------------------------------------------------- #
# Pydantic input models
# --------------------------------------------------------------------------- #


class DatasetInput(BaseModel):
    """Input for tools that require a dataset identifier."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    dataset: str = Field(
        ...,
        description="BigQuery dataset ID (e.g. 'my_dataset')",
        min_length=1,
        max_length=1024,
    )


class TableInput(BaseModel):
    """Input for tools that require a dataset + table identifier."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    dataset: str = Field(
        ...,
        description="BigQuery dataset ID (e.g. 'my_dataset')",
        min_length=1,
        max_length=1024,
    )
    table: str = Field(
        ...,
        description="BigQuery table ID (e.g. 'my_table')",
        min_length=1,
        max_length=1024,
    )


class SqlInput(BaseModel):
    """Input for tools that accept a SQL query string."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    sql: str = Field(
        ...,
        description="Standard SQL query to execute against BigQuery",
        min_length=1,
    )


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

_LIMIT_RE = re.compile(r"\bLIMIT\s+\d+", re.IGNORECASE)


def _get_bq_client(ctx: Context) -> bigquery.Client:
    """Retrieve the shared BigQuery client from the lifespan state."""
    return ctx.request_context.lifespan_context["bq_client"]


# --------------------------------------------------------------------------- #
# Tool registration
# --------------------------------------------------------------------------- #


def register_bigquery_tools(mcp: FastMCP) -> None:
    """Register all BigQuery tools on the FastMCP server instance."""

    # ------------------------------------------------------------------ #
    # bq_list_datasets
    # ------------------------------------------------------------------ #
    @mcp.tool(
        name="bq_list_datasets",
        annotations={
            "title": "List BigQuery Datasets",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def bq_list_datasets(ctx: Context) -> str:
        """List all datasets in the configured BigQuery project.

        Returns a JSON array of objects, each containing:
        - dataset_id: the short dataset name
        - full_id: project.dataset
        - location: the dataset's geographic location

        Use this tool to discover what datasets are available before
        listing tables or running queries.

        Returns:
            str: JSON array of dataset metadata.
        """
        try:
            client = _get_bq_client(ctx)
            datasets = list(client.list_datasets())

            if not datasets:
                return json.dumps(
                    {"message": "No datasets found in this project.", "datasets": []},
                    indent=2,
                )

            result = [
                {
                    "dataset_id": ds.dataset_id,
                    "full_id": f"{ds.project}.{ds.dataset_id}",
                    "location": ds.location if hasattr(ds, "location") else None,
                }
                for ds in datasets
            ]
            return json.dumps(result, indent=2)

        except Exception as exc:
            return handle_bq_error(exc)

    # ------------------------------------------------------------------ #
    # bq_list_tables
    # ------------------------------------------------------------------ #
    @mcp.tool(
        name="bq_list_tables",
        annotations={
            "title": "List Tables in a Dataset",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def bq_list_tables(params: DatasetInput, ctx: Context) -> str:
        """List all tables in a BigQuery dataset with row counts and size.

        Args:
            params (DatasetInput): Validated input containing:
                - dataset (str): The dataset ID to inspect.

        Returns:
            str: JSON array of table metadata, each containing:
                - table_id (str): short table name
                - type (str): TABLE, VIEW, EXTERNAL, etc.
                - num_rows (int): number of rows
                - size_mb (float): storage size in megabytes (rounded to 2 decimals)
        """
        try:
            client = _get_bq_client(ctx)
            tables = list(client.list_tables(params.dataset))

            if not tables:
                return json.dumps(
                    {
                        "message": f"No tables found in dataset '{params.dataset}'.",
                        "tables": [],
                    },
                    indent=2,
                )

            result = []
            for tbl_ref in tables:
                full_table = client.get_table(tbl_ref.reference)
                result.append(
                    {
                        "table_id": full_table.table_id,
                        "type": full_table.table_type,
                        "num_rows": full_table.num_rows,
                        "size_mb": round((full_table.num_bytes or 0) / (1024 * 1024), 2),
                    }
                )

            return json.dumps(result, indent=2)

        except Exception as exc:
            return handle_bq_error(exc)

    # ------------------------------------------------------------------ #
    # bq_get_schema
    # ------------------------------------------------------------------ #
    @mcp.tool(
        name="bq_get_schema",
        annotations={
            "title": "Get Table Schema",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def bq_get_schema(params: TableInput, ctx: Context) -> str:
        """Get the full schema of a BigQuery table.

        Returns every column's name, data type, mode (NULLABLE / REQUIRED / REPEATED),
        and description.  Use this before writing queries to know what columns are
        available and what types they have.

        Args:
            params (TableInput): Validated input containing:
                - dataset (str): The dataset ID.
                - table (str): The table ID.

        Returns:
            str: JSON object with:
                - table (str): fully-qualified table reference
                - num_rows (int): total row count
                - size_mb (float): storage size in MB
                - columns (list): array of {name, field_type, mode, description}
        """
        try:
            client = _get_bq_client(ctx)
            table_ref = f"{client.project}.{params.dataset}.{params.table}"
            table = client.get_table(table_ref)

            columns = [
                {
                    "name": field.name,
                    "field_type": field.field_type,
                    "mode": field.mode,
                    "description": field.description or "",
                }
                for field in table.schema
            ]

            result = {
                "table": table_ref,
                "num_rows": table.num_rows,
                "size_mb": round((table.num_bytes or 0) / (1024 * 1024), 2),
                "columns": columns,
            }
            return json.dumps(result, indent=2)

        except Exception as exc:
            return handle_bq_error(exc)

    # ------------------------------------------------------------------ #
    # bq_dry_run
    # ------------------------------------------------------------------ #
    @mcp.tool(
        name="bq_dry_run",
        annotations={
            "title": "Dry Run (Validate SQL & Estimate Cost)",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def bq_dry_run(params: SqlInput, ctx: Context) -> str:
        """Validate a SQL query and estimate its processing cost without executing it.

        Useful to check for syntax errors and understand data volume before running
        an expensive query.  The cost estimate assumes on-demand pricing (~$6.25/TB).

        Args:
            params (SqlInput): Validated input containing:
                - sql (str): The SQL query to validate.

        Returns:
            str: JSON object with:
                - valid (bool): whether the SQL is syntactically correct
                - bytes_processed (int): estimated bytes that would be scanned
                - gb_processed (float): same value in gigabytes (2 decimals)
                - estimated_cost_usd (float): approximate cost in USD (4 decimals)
        """
        try:
            client = _get_bq_client(ctx)
            job_config = bigquery.QueryJobConfig(
                dry_run=True,
                use_query_cache=False,
            )
            query_job = client.query(params.sql, job_config=job_config)

            bytes_processed = query_job.total_bytes_processed or 0
            gb_processed = bytes_processed / (1024**3)
            tb_processed = bytes_processed / (1024**4)
            estimated_cost = tb_processed * COST_PER_TB

            result = {
                "valid": True,
                "bytes_processed": bytes_processed,
                "gb_processed": round(gb_processed, 2),
                "estimated_cost_usd": round(estimated_cost, 4),
            }
            return json.dumps(result, indent=2)

        except Exception as exc:
            return handle_bq_error(exc)

    # ------------------------------------------------------------------ #
    # bq_run_query
    # ------------------------------------------------------------------ #
    @mcp.tool(
        name="bq_run_query",
        annotations={
            "title": "Run BigQuery SQL Query",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": True,
        },
    )
    async def bq_run_query(params: SqlInput, ctx: Context) -> str:
        """Execute a standard SQL query against BigQuery and return the results.

        Safety: If no LIMIT clause is detected in the query, a LIMIT 1000 is
        automatically appended to prevent accidentally fetching very large result sets.

        Args:
            params (SqlInput): Validated input containing:
                - sql (str): The SQL query to execute.

        Returns:
            str: JSON object with:
                - row_count (int): number of rows returned
                - columns (list[str]): column names in order
                - rows (list[dict]): result rows as key-value objects
                - truncated (bool): True if the auto-limit was applied
                - total_bytes_processed (int): bytes scanned by the query
        """
        try:
            from src.services.bigquery_client import serialize_row

            client = _get_bq_client(ctx)
            sql = params.sql.strip()
            truncated = False

            # Auto-append LIMIT if not present
            if not _LIMIT_RE.search(sql):
                sql = f"{sql.rstrip(';')} LIMIT {DEFAULT_ROW_LIMIT}"
                truncated = True

            await ctx.info(f"Executing query (truncated={truncated})")

            query_job = client.query(sql)
            rows = [serialize_row(row) for row in query_job]

            columns = [field.name for field in query_job.schema] if query_job.schema else []

            result = {
                "row_count": len(rows),
                "columns": columns,
                "rows": rows,
                "truncated": truncated,
                "total_bytes_processed": query_job.total_bytes_processed or 0,
            }
            return json.dumps(result, ensure_ascii=False, indent=2)

        except Exception as exc:
            return handle_bq_error(exc)
