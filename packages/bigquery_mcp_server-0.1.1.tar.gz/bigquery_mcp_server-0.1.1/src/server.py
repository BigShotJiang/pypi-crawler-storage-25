#!/usr/bin/env python3
"""
BigQuery MCP Server — Python / FastMCP

Exposes Google BigQuery operations as MCP tools so that LLMs can explore
datasets, inspect schemas, estimate query costs, and run SQL queries.

Supports two transport modes:
  - stdio  (default): for Claude Code, Cursor, etc.
  - http   (TRANSPORT=http): for MCP Inspector via browser

Usage:
  python -m src.server                   # stdio
  TRANSPORT=http python -m src.server    # HTTP on port 8000
"""

import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from dotenv import load_dotenv

load_dotenv()  # Load .env before any src.* imports that read os.getenv()

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings

from src.constants import PORT
from src.services.bigquery_client import create_bq_client
from src.tools.bigquery import register_bigquery_tools

# --------------------------------------------------------------------------- #
# Logging (always to stderr so stdio transport stays clean)
# --------------------------------------------------------------------------- #

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("bigquery-mcp")


# --------------------------------------------------------------------------- #
# Lifespan: initialise the BigQuery client once at startup
# --------------------------------------------------------------------------- #


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Manage shared resources across the server's lifetime."""
    logger.info("Starting BigQuery MCP server...")

    # Validate credentials and create the client early so mis-configuration
    # surfaces immediately rather than on the first tool call.
    bq_client = create_bq_client()

    shared_state: dict[str, Any] = {
        "bq_client": bq_client,
    }

    logger.info("BigQuery client ready")
    yield shared_state

    # Cleanup
    logger.info("Shutting down BigQuery MCP server...")
    bq_client.close()


# --------------------------------------------------------------------------- #
# Server initialisation
# --------------------------------------------------------------------------- #

HOST = os.getenv("HOST", "127.0.0.1")

mcp = FastMCP(
    name="bigquery_mcp",
    lifespan=app_lifespan,
    host=HOST,
    port=PORT,
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
)

# --------------------------------------------------------------------------- #
# Register tools
# --------------------------------------------------------------------------- #

register_bigquery_tools(mcp)


# --------------------------------------------------------------------------- #
# Entry point (used by console_scripts and __main__)
# --------------------------------------------------------------------------- #


def main() -> None:
    """Entry point for ``bigquery-mcp-server`` CLI and ``uvx``."""
    transport = os.getenv("TRANSPORT", "stdio")

    if transport == "http":
        logger.info(f"Starting HTTP mode on port {PORT}")
        logger.info(f"  MCP endpoint: http://localhost:{PORT}/mcp")
        logger.info("  MCP Inspector: npx @modelcontextprotocol/inspector")
        logger.info(f"  Connect to: http://localhost:{PORT}/mcp (Streamable HTTP)")
        mcp.run(transport="streamable-http")
    else:
        logger.info("Starting stdio mode")
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
