"""Centralised error handler for BigQuery operations.

Every tool wraps its logic in a try/except and delegates to
``handle_bq_error`` so that the server never crashes and the LLM always
receives a human-readable (and actionable) error string.
"""

from __future__ import annotations

from google.api_core import exceptions as google_exceptions


def handle_bq_error(exc: Exception) -> str:
    """Return a concise, actionable error message for *exc*.

    Handles the most common BigQuery / Google API exception families and falls
    back to a generic message for anything unexpected.
    """

    # ── Google API specific exceptions ─────────────────────────────────────
    if isinstance(exc, google_exceptions.Forbidden):
        return (
            "Error 403 — Permission denied.  "
            "The service account lacks the required IAM roles.  "
            "Ensure it has at least 'BigQuery Data Viewer' and 'BigQuery Job User' on the project."
        )

    if isinstance(exc, google_exceptions.NotFound):
        return (
            "Error 404 — Resource not found.  "
            f"Details: {exc.message if hasattr(exc, 'message') else exc}.  "
            "Verify the dataset, table, or project ID exists and is spelled correctly."
        )

    if isinstance(exc, google_exceptions.BadRequest):
        # BigQuery returns detailed SQL syntax errors inside the message.
        msg = getattr(exc, "message", str(exc))
        return (
            f"Error 400 — Bad request.  {msg}  "
            "Check your SQL syntax and ensure all referenced columns/tables exist."
        )

    if isinstance(exc, google_exceptions.Unauthorized):
        return (
            "Error 401 — Unauthorized.  "
            "The service account credentials may be expired or invalid.  "
            "Regenerate the JSON key and update BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT."
        )

    if isinstance(exc, google_exceptions.TooManyRequests):
        return (
            "Error 429 — Rate limit exceeded.  "
            "Too many BigQuery requests in a short period.  "
            "Wait a moment and retry."
        )

    if isinstance(exc, google_exceptions.GoogleAPIError):
        code = getattr(exc, "code", "unknown")
        msg = getattr(exc, "message", str(exc))
        return f"Error {code} — Google API error: {msg}"

    # ── Credential / config errors ─────────────────────────────────────────
    if isinstance(exc, ValueError):
        return f"Configuration error: {exc}"

    # ── Catch-all ──────────────────────────────────────────────────────────
    return f"Unexpected error ({type(exc).__name__}): {exc}"
