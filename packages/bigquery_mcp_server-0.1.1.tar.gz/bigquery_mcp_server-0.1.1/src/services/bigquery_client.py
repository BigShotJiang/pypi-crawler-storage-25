"""Shared BigQuery client — cloud-native authentication via environment variable.

Parses the service account JSON from BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT and
creates a google.cloud.bigquery.Client.  No file paths or gcloud CLI involved.
"""

from __future__ import annotations

import datetime
import decimal
import json
import logging
from typing import Any

from google.cloud import bigquery
from google.oauth2 import service_account

from src.constants import (
    BIGQUERY_LOCATION,
    BIGQUERY_PROJECT_ID,
    BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT,
)

logger = logging.getLogger("bigquery-client")


# --------------------------------------------------------------------------- #
# Client factory
# --------------------------------------------------------------------------- #


def create_bq_client() -> bigquery.Client:
    """Build a BigQuery client from environment variables.

    Raises:
        ValueError: If required environment variables are missing or the JSON
                    content cannot be parsed.
    """
    if not BIGQUERY_PROJECT_ID:
        raise ValueError(
            "BIGQUERY_PROJECT_ID is not set.  "
            "Set it to your GCP project ID (e.g. 'my-project-123')."
        )

    if not BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT:
        raise ValueError(
            "BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT is not set.  "
            "Set it to the raw JSON string of your service account key."
        )

    try:
        sa_info: dict[str, Any] = json.loads(BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"BIGQUERY_SERVICE_ACCOUNT_JSON_CONTENT contains invalid JSON. Parse error: {exc}"
        ) from exc

    credentials = service_account.Credentials.from_service_account_info(sa_info)

    client = bigquery.Client(
        project=BIGQUERY_PROJECT_ID,
        credentials=credentials,
        location=BIGQUERY_LOCATION,
    )
    logger.info(
        "BigQuery client created — project=%s, location=%s",
        BIGQUERY_PROJECT_ID,
        BIGQUERY_LOCATION,
    )
    return client


# --------------------------------------------------------------------------- #
# Row serialization helpers
# --------------------------------------------------------------------------- #


def serialize_value(value: Any) -> Any:
    """Convert a single BigQuery value to a JSON-safe Python type."""
    if value is None:
        return None
    if isinstance(value, datetime.datetime):
        return value.isoformat()
    if isinstance(value, datetime.date):
        return value.isoformat()
    if isinstance(value, datetime.time):
        return value.isoformat()
    if isinstance(value, decimal.Decimal):
        return float(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, (list, tuple)):
        return [serialize_value(v) for v in value]
    if isinstance(value, dict):
        return {k: serialize_value(v) for k, v in value.items()}
    # int, float, str, bool — already JSON-safe
    return value


def serialize_row(row: bigquery.Row) -> dict[str, Any]:
    """Convert a BigQuery Row to a plain dict with JSON-safe values."""
    return {key: serialize_value(row[key]) for key in row.keys()}
