#!/usr/bin/env python3
"""
Root-level entry point for the BigQuery MCP server.

Thin wrapper around src.server -- allows running the server with:
    python main.py                    # stdio (default)
    TRANSPORT=http python main.py     # HTTP on port 8000

Equivalent to: python -m src.server
"""

import logging
import os
import sys

from dotenv import load_dotenv

load_dotenv()  # Load .env before any src.* imports that read os.getenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("mcp-main")

# Import the configured server instance and port constant
from src.server import mcp
from src.constants import PORT


def main() -> None:
    transport = os.getenv("TRANSPORT", "stdio")

    if transport == "http":
        logger.info(f"Starting HTTP mode on port {PORT}")
        logger.info(f"  MCP endpoint: http://localhost:{PORT}/mcp")
        logger.info("  MCP Inspector: npx @modelcontextprotocol/inspector")
        logger.info(f"  Connect to: http://localhost:{PORT}/mcp (Streamable HTTP)")
        mcp.run(transport="streamable-http")
    else:
        logger.info("Starting stdio mode")
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
