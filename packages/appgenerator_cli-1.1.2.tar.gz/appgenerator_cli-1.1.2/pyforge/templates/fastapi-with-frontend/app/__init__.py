"""{{ project_name }} application package."""
