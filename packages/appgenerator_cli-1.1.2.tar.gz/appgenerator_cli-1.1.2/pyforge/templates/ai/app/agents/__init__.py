"""Agent definitions."""
