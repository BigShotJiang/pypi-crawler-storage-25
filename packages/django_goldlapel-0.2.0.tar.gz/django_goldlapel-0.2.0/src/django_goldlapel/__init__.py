"""django-goldlapel — redirect package.

This package has been consolidated into the main goldlapel package.
Install via: pip install goldlapel[django]

Importing from django_goldlapel still works for backward compatibility,
but new code should import from goldlapel.django directly.
"""

import warnings

warnings.warn(
    "The django-goldlapel package has been consolidated into goldlapel[django]. "
    "Future development happens in https://github.com/goldlapel/goldlapel-python. "
    "Update your install: pip install goldlapel[django]. "
    "This redirect package may be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the canonical location so `from django_goldlapel
# import DatabaseWrapper` keeps working.
from goldlapel.django import *  # noqa: F401, F403
from goldlapel.django import base as _gl_django_base  # noqa: F401

try:
    from goldlapel.django import __all__  # noqa: F401
except ImportError:
    pass
