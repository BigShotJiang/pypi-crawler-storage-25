"""django-goldlapel.base — redirect module.

The Django backend lives at goldlapel.django.base. This module re-exports
everything from there so that existing Django settings with::

    'ENGINE': 'django_goldlapel.base'

keep working. New projects should use::

    'ENGINE': 'goldlapel.django.base'

after installing the consolidated package: pip install goldlapel[django].
"""

import warnings

warnings.warn(
    "django_goldlapel.base has been consolidated into goldlapel.django.base. "
    "Update your Django DATABASES['default']['ENGINE'] to 'goldlapel.django.base' "
    "and `pip install goldlapel[django]`. This redirect module emits a "
    "deprecation warning and may be removed in a future release.",
    DeprecationWarning,
    stacklevel=2,
)

from goldlapel.django.base import *  # noqa: F401, F403
from goldlapel.django.base import DatabaseWrapper  # noqa: F401

try:
    from goldlapel.django.base import __all__  # noqa: F401
except ImportError:
    pass
