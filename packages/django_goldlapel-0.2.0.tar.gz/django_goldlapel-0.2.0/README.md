# Deprecated — package consolidated

**This package has been merged into the main `goldlapel` package.**

**Install instead:**

```bash
pip install goldlapel[django]
```

**Source code:** https://github.com/goldlapel/goldlapel-python

This redirect package remains installable for backward compatibility — it
depends transitively on `goldlapel[django]` and re-exports the same Django
backend so existing settings keep working — but emits a `DeprecationWarning`
on import. Update your Django settings::

    DATABASES = {
        'default': {
            'ENGINE': 'goldlapel.django.base',  # was: 'django_goldlapel.base'
            ...
        }
    }

New development happens in the consolidated repo.

---

# goldlapel-django (legacy)

> **This package has been consolidated into [`goldlapel`](https://pypi.org/project/goldlapel/).**

Install with:

```bash
pip install goldlapel[django]
```

Then use `goldlapel.django.base` as your Django database backend. See the [Gold Lapel docs](https://goldlapel.com/docs/django) for details.
