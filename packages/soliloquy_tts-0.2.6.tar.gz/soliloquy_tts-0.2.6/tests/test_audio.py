"""Tests for audio playback module (without actual audio output)."""

import os
from unittest.mock import patch

import numpy as np
import pytest

from soliloquy.audio import _check_platform, _write_chunk


# --- Platform check ---


def test_check_platform_darwin():
    with patch("soliloquy.audio.platform.system", return_value="Darwin"):
        _check_platform()  # should not raise


def test_check_platform_linux():
    with patch("soliloquy.audio.platform.system", return_value="Linux"):
        with pytest.raises(RuntimeError, match="macOS"):
            _check_platform()


def test_check_platform_windows():
    with patch("soliloquy.audio.platform.system", return_value="Windows"):
        with pytest.raises(RuntimeError, match="macOS"):
            _check_platform()


# --- Chunk writing ---


def test_write_chunk_creates_wav():
    audio = np.zeros(2400, dtype=np.float32)  # 0.1s of silence
    path = _write_chunk(audio, sample_rate=24000)
    try:
        assert os.path.exists(path)
        assert path.endswith(".wav")
        assert os.path.getsize(path) > 0
    finally:
        os.unlink(path)
