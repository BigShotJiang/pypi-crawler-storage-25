"""Dual-mode backend: runs SSE server for proxies + stdio for the launching session."""

import atexit

import anyio
import uvicorn
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route

import json
import sys
import urllib.request

from .lock import remove_lock


def _check_for_update():
    """Print a notice to stderr if a newer version is available on PyPI."""
    try:
        from . import __version__ as current

        req = urllib.request.Request(
            "https://pypi.org/pypi/soliloquy-tts/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            latest = json.loads(resp.read())["info"]["version"]

        if latest != current:
            print(
                f"\u26a0 Soliloquy {latest} available (you have {current}). "
                f"Run: uv cache clean soliloquy-tts",
                file=sys.stderr,
                flush=True,
            )
    except Exception:
        pass


async def _health(request: Request) -> PlainTextResponse:
    return PlainTextResponse("ok")


async def run_backend_and_stdio(port: int) -> None:
    """Start the SSE backend and stdio MCP server concurrently.

    Lock file must already be written by the caller (main.py).
    """
    # Import server here to trigger kokoro/tool registration
    from . import server

    atexit.register(remove_lock)

    # Build SSE app with health endpoint
    app = server.mcp.sse_app()
    app.routes.insert(0, Route("/health", _health))

    try:
        async with anyio.create_task_group() as tg:

            async def run_sse():
                config = uvicorn.Config(
                    app, host="127.0.0.1", port=port, log_level="warning"
                )
                srv = uvicorn.Server(config)
                await srv.serve()

            async def run_stdio():
                await server.mcp.run_stdio_async()

            async def warm_up_background():
                # Run in a thread so it doesn't block the MCP handshake
                await anyio.to_thread.run_sync(server.warm_up)

            async def check_update_background():
                await anyio.to_thread.run_sync(_check_for_update)

            tg.start_soon(run_sse)
            tg.start_soon(run_stdio)
            tg.start_soon(warm_up_background)
            tg.start_soon(check_update_background)
    finally:
        remove_lock()
