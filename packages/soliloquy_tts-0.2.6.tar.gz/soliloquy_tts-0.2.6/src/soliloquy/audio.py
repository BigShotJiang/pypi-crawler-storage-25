"""Audio playback for Soliloquy. Currently macOS-only (afplay)."""

import os
import platform
import queue
import subprocess
import tempfile
import threading
from typing import Iterable, Iterator

import numpy as np
import soundfile as sf


def _check_platform():
    if platform.system() != "Darwin":
        raise RuntimeError(
            f"Soliloquy audio playback requires macOS (afplay). "
            f"Current platform: {platform.system()}. "
            f"Contributions for Linux/Windows support welcome!"
        )


def _play_file(path: str) -> None:
    """Play a WAV file via afplay and delete it."""
    try:
        subprocess.run(
            ["afplay", path],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    finally:
        os.unlink(path)


def _write_chunk(audio: np.ndarray, sample_rate: int = 24000) -> str:
    """Write audio to a temp WAV file and return the path."""
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        sf.write(f.name, audio, sample_rate)
        return f.name


def play_audio(audio: np.ndarray, sample_rate: int = 24000) -> None:
    """Play audio using macOS afplay in a background thread."""
    _check_platform()
    path = _write_chunk(audio, sample_rate)
    threading.Thread(target=_play_file, args=(path,), daemon=True).start()


def stream_play_audio(
    chunks: Iterable[np.ndarray], sample_rate: int = 24000
) -> int:
    """Play audio chunks as they arrive, returning total sample count.

    Accepts any iterable (list or generator). A background thread plays
    each chunk sequentially via afplay while the main thread continues
    feeding chunks from the generator. Playback starts as soon as the
    first chunk is ready.
    """
    _check_platform()

    q: queue.Queue[str | None] = queue.Queue()
    total_samples = 0

    def player():
        while True:
            path = q.get()
            if path is None:
                break
            _play_file(path)

    t = threading.Thread(target=player, daemon=True)
    t.start()

    for chunk in chunks:
        total_samples += len(chunk)
        q.put(_write_chunk(chunk, sample_rate))

    q.put(None)  # signal end
    t.join()

    return total_samples
