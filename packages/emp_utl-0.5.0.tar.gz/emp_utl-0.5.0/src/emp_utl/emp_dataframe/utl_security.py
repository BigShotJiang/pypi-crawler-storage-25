# Standard library imports
import logging
import random
import re
import traceback
from datetime import UTC, datetime
from typing import Any

import bcrypt

# Third-party imports
import pandas as pd

# Importing necessary utility
from ..emp_core.utl_core import create_random_datetime


# Function to encode plain password
def encode_password(raw_password: str) -> str:
	"""
	Encodes a plaintext password using bcrypt hashing.

	The function generates a salted hash suitable for secure storage
	and authentication workflows.

	:param raw_password: Plaintext password to encode
	:return: Bcrypt-hashed password string
	"""

	return bcrypt.hashpw(password=raw_password.encode(), salt=bcrypt.gensalt()).decode()


# Function to create credential Series
def create_credential_row(
	user: pd.Series,
	user_id_col: str,
	user_type: str,
	date_column: str,
	encoded_passwords: list[str],
	roles: list[str] | None = None,
) -> dict[str, Any]:
	"""
	Creates a credential document for a single user.

	:param user: Pandas Series representing a user row
	:param user_id_col: Column containing the user ID
	:param user_type: User type (e.g. EMPLOYEE, CUSTOMER, SUPPLIER)
	:param date_column: Column used as base for credential timestamps
	:param encoded_passwords: List of pre-encoded passwords
	:param roles: Optional List of available roles
	:return: Dictionary representing a credential document
	"""

	# Variables
	current_time: datetime = datetime.now(tz=UTC)
	username: str = re.sub(
		pattern=r'[^a-z0-9]',
		repl='',
		string=f'{user["firstname"][0]}{user["lastname"]}'.lower(),
	)
	created_datetime: datetime = create_random_datetime(start_date=user[date_column], end_date=current_time.date())
	updated_datetime: datetime = create_random_datetime(start_date=created_datetime.date(), end_date=current_time.date())

	# Role Handling
	if roles is None:
		roles = ['LIMITED']

	return {
		'userId': str(user[user_id_col]),
		'userType': user_type,
		'username': username,
		'email': user['email'],
		'password': random.choice(seq=encoded_passwords),
		'mfaEnabled': False,
		'active': True,
		'lastLogin': current_time.isoformat(),
		'lastLogout': None,
		'mustChangePassword': False,
		'resetToken': None,
		'resetTokenExpiration': None,
		'roles': [random.choice(seq=roles)],
		'created_datetime': created_datetime.isoformat(),
		'updated_datetime': updated_datetime.isoformat(),
	}


# Function to create credential dataframe
def create_credential(
	df: pd.DataFrame,
	user_id_col: str,
	user_type: str,
	date_column: str,
	logger: logging.Logger,
) -> pd.DataFrame:
	"""
	Creates a credential dataframe for students or staff.

	:param df: Source dataframe
	:param user_id_col: Column containing the user ID
	:param user_type: User type (STUDENT or STAFF)
	:param date_column: Column used as base for timestamps
	:param logger: Custom Logger object
	:return: Credential dataframe
	"""

	try:
		encoded_passwords: list[str] = [encode_password(raw_password='Password123!') for _ in range(10)]

		return pd.DataFrame(
			data=df.apply(
				lambda row: create_credential_row(
					user=row,
					user_id_col=user_id_col,
					user_type=user_type,
					date_column=date_column,
					encoded_passwords=encoded_passwords,
				),
				axis=1,
			).tolist()
		)
	except Exception as e:
		logger.error(msg=f"Error occurred in building of 'Credential' dataframe for '{user_type}': {e!r} - Trace: {traceback.format_exc()}")
		raise
