# Standard library imports
import logging
import os
import random
import traceback
from datetime import date, datetime
from typing import Final

# Third-party imports
import pandas as pd
from countryinfo import CountryInfo
from faker import Faker
from faker.config import AVAILABLE_LOCALES
from unidecode import unidecode

# Importing necessary utility
from ..emp_core.utl_core import create_random_datetime


# Function to export dataframe
def export_dataframe(path: os.PathLike[str], df: pd.DataFrame, logger: logging.Logger) -> None:
	"""
	Exporting dataframe to specified path as feather file.
	This function uses the 'feather-format' module to save the dataframe in feather format

	:param path: path to save the dataframe
	:param df: dataframe to export
	:param logger: Custom Logger object
	:return: None
	"""

	# Exporting dataframe as feather file
	try:
		df.to_feather(path=path)
		filename: str = os.path.splitext(p=os.path.basename(p=path))[0]
		logger.info(msg=f"Pandas DataFrame '{filename}' exported successfully")
	except Exception as e:
		logger.error(msg=f'Error occurred during export of dataframe to path: {e!r} - Trace: {traceback.format_exc()}')
		raise


# Function to create audit columns for pandas dataframe
def add_audit_columns(df: pd.DataFrame) -> pd.DataFrame:
	"""
	Adds audit-related columns to the given DataFrame.

	This includes generating random `created_datetime` and `updated_datetime`
	values within a realistic timeframe, as well as assigning default values
	for `created_by` and `updated_by`.

	:param df: Input DataFrame to enrich with audit columns
	:return: DataFrame with added audit columns
	"""

	# Collecting results
	machine_user: Final[int] = 9999
	created_datetime_list: list[datetime] = []
	updated_datetime_list: list[datetime] = []

	for _ in df.index:
		start_date: date = date(year=2020, month=1, day=1)
		end_date: date = date.today()

		created_datetime: datetime = create_random_datetime(start_date=start_date, end_date=end_date)
		updated_datetime: datetime = create_random_datetime(start_date=created_datetime.today(), end_date=end_date)

		created_datetime_list.append(created_datetime)
		updated_datetime_list.append(updated_datetime)

	# Modifying DataFrame
	df['created_datetime'] = pd.to_datetime(created_datetime_list)
	df['updated_datetime'] = pd.to_datetime(updated_datetime_list)
	df['created_by'] = [machine_user for _ in range(len(df))]
	df['updated_by'] = [machine_user for _ in range(len(df))]

	return df.reset_index(drop=True)


# Function to return random gender
def get_gender() -> str:
	"""
	Function to return a random gender 'MALE' or 'FEMALE'
	:return: Return randomly selected gender
	"""

	return random.choice(seq=['MALE', 'FEMALE'])


# Function to create Faker object
def create_faker(locale: str) -> Faker:
	"""
	Creating Faker module for data generation of fictional values.
	Dependent on locale, the fake data can approximate the passed language.

	:param locale: Country Code for Faker module i.e.: en_US, de_DE, fr_FR
	"""

	return Faker(locale=locale)


# Function to secure demonym
def safe_demonym(country: str) -> str:
	"""
	Safely retrieves the demonym for a given country.

	The function attempts to resolve the demonym (e.g., "German" for Germany)
	using an external library. If the lookup fails, the original country name
	is returned as a fallback.

	:param country: Country name
	:return: Demonym or fallback country name
	"""

	try:
		return CountryInfo(country_name=country).info().get('demonym', country)
	except Exception:
		return country


# Function to normalize text
def normalize_text(value: str | None) -> str | None:
	"""
	Normalizes text by removing special characters and accents.

	The function converts Unicode characters into their closest ASCII
	representation to ensure consistency and compatibility.

	:param value: Input string value
	:return: Normalized string or None if input is None
	"""

	if value is None:
		return None
	return unidecode(string=value)


# Function to generate realistic phone no. with country code
def generate_phone_number(locale: str, country_code: str, fallback_locale: str = 'en_US') -> str:
	"""
	Generates a phone number aligned with a given locale and prefixes it
	with the provided country code.

	:param locale: Locale used for Faker (e.g., 'de_DE')
	:param country_code: Country phone prefix (e.g., '+49')
	:param fallback_locale: Fallback locale if the given locale is unsupported
	:return: Formatted phone number with country code
	"""

	# Validating locale
	if locale not in AVAILABLE_LOCALES:
		faker_phone: Faker = create_faker(locale=fallback_locale)
	else:
		try:
			faker_phone: Faker = create_faker(locale=locale)
			faker_phone.phone_number()
		except Exception:
			faker_phone: Faker = create_faker(locale=fallback_locale)

	# Generating phone no.
	phone_no: str = faker_phone.phone_number()
	phone_clean: str = phone_no.replace('x', '').strip()

	if phone_clean.startswith('+') or phone_clean.startswith('00'):
		phone_clean = phone_clean.lstrip('+').lstrip('0')

	return f'{country_code} {phone_clean}'
