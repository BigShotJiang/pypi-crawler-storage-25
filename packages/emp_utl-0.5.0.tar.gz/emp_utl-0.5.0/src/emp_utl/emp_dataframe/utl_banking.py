# Standard library imports
import logging
import random
import traceback

# Third-party imports
import pandas as pd
from faker import Faker

# Importing necessary utility
from .utl_dataframe import add_audit_columns, create_faker


# Function to create banking mapper (international Banks)
def create_banking_mapper(df_banks: pd.DataFrame, logger: logging.Logger) -> dict[str, list[str]]:
	"""
	Creates a country-based banking mapper dictionary.
	The function groups bank names by country and returns a dictionary
	where:
	    - key   -> country name
	    - value -> list of bank names

	:param df_banks: DataFrame containing bank dataset
	:param logger: Custom Logger object
	:return: Dictionary mapping countries to bank names
	"""

	try:
		return df_banks.groupby(by='Country')['Bank name'].apply(func=lambda banks: sorted(set(banks.astype(str)))).to_dict()
	except Exception as e:
		logger.error(msg=f"Error occurred during mapping of 'Largest Banks': {e!r} - Trace: {traceback.format_exc()}")
		raise


# Function to create banking info (Dict/Json)
def create_banking_info(loc_mapper: tuple[str, str, str], banking_mapper: dict[str, list[str]]) -> tuple[str, dict[str, str]]:
	"""
	Creates banking information based on geographical location data.
	The function selects a realistic financial institute based on country
	and generates either:
	    - IBAN/BIC information for European countries
	    - BBAN/Routing information for non-european countries

	:param loc_mapper: Tuple containing location mapping information
	:param banking_mapper: Dictionary mapping countries to bank names
	:return: Tuple containing institute name and banking information
	"""

	# Variables
	locale: str = str(loc_mapper[1])
	country: str = str(loc_mapper[0])
	continent: str = str(loc_mapper[2])

	# Faker Initialization
	try:
		faker: Faker = create_faker(locale=locale)
	except Exception:
		faker: Faker = create_faker(locale='en_US')

	# Selecting Banking Institute
	if country in banking_mapper:
		institute: str = random.choice(seq=banking_mapper[country])
	else:
		institute: str = random.choice(seq=random.choice(seq=list(banking_mapper.values())))

	# European banking structure
	if continent == 'Europe':
		banking_info: dict[str, str] = {'iban': faker.iban(), 'bic': faker.swift8()}

	# International banking structure
	else:
		banking_info: dict[str, str] = {
			'accountNumber': faker.bban(),
			'routingNumber': faker.aba(),
		}

	return institute, banking_info


# Function to create Banking DataFrame
def create_banking_row(
	user: pd.Series,
	loc_mapper: pd.Series,
	user_id_col: str,
	user_type: str,
	banking_mapper: dict[str, list[str]],
) -> pd.DataFrame:
	"""
	Creates a banking document for a single user.

	The function generates realistic banking-related information
	based on geographical location data and user type.

	Depending on the continent, the generated banking structure
	contains either:
		- IBAN/BIC information for European countries
	    - Account/Routing information for non-european countries

	Additional business attributes such as cashback eligibility
	and verification status are generated dynamically based on
	the provided user type.

	:param user: Pandas Series representing the user row
	:param loc_mapper: Pandas Series containing mapped location details
	:param user_id_col: Column name containing the user ID
	:param user_type: User type (e.g. EMPLOYEE, CUSTOMER, SUPPLIER)
	:param banking_mapper: Dictionary mapping countries to banking institutes
	:return: Dictionary representing a banking document
	"""

	# Banking Details
	institute, banking_info = create_banking_info(
		loc_mapper=(
			loc_mapper['country'],
			loc_mapper['language_code'],
			loc_mapper['continent'],
		),
		banking_mapper=banking_mapper,
	)

	# Cashback
	cashback: float = round(number=random.uniform(a=0.0, b=0.15), ndigits=2) if user_type == 'CUSTOMER' else 0.0

	# Supplier Verification
	verified: bool = random.choice(seq=[True, False]) if user_type == 'SUPPLIER' else True

	return {
		'userId': str(user[user_id_col]),
		'userType': user_type,
		'institute': institute,
		'bankingInfo': banking_info,
		'cashback': cashback,
		'verified': verified,
		'preferred': random.choice(seq=[True, False]),
		'active': True,
	}


# Function to create banking DataFrame
def create_banking(
	df: pd.DataFrame,
	df_loc_mapper: pd.DataFrame,
	user_id_col: str,
	user_type: str,
	banking_mapper: dict[str, list[str]],
	logger: logging.Logger,
) -> pd.DataFrame:
	"""
	Creates a banking dataframe for a given user dataset.

	The function links user records with geographical location details,
	generates realistic banking documents using `create_banking_row`,
	and enriches the resulting dataframe with audit metadata.

	The generated banking structure is flexible and intended for
	document-based storage systems such as MongoDB.

	:param df: Source dataframe containing user records
	:param df_loc_mapper: DataFrame containing location mapping details
	:param user_id_col: Column name containing the user ID
	:param user_type: User type (e.g. EMPLOYEE, CUSTOMER, SUPPLIER)
	:param banking_mapper: Dictionary mapping countries to banking institutes
	:param logger: Logger instance for structured logging
	:return: DataFrame representing banking documents
	"""

	try:
		# Linking users with location details
		df_loc_mapper_merged: pd.DataFrame = df[[user_id_col, 'loc_id']].merge(right=df_loc_mapper, on='loc_id', how='left')
		return add_audit_columns(
			df=pd.DataFrame(
				data=df.apply(
					lambda row: create_banking_row(
						user=row,
						loc_mapper=df_loc_mapper_merged.loc[df_loc_mapper_merged[user_id_col] == row[user_id_col]].iloc[0],
						user_id_col=user_id_col,
						user_type=user_type,
						banking_mapper=banking_mapper,
					),
					axis=1,
				).tolist()
			)
		)
	except Exception as e:
		logger.error(msg=f"Error occurred in building of 'Banking' dataframe: {e!r} - Trace: {traceback.format_exc()}")
		raise
