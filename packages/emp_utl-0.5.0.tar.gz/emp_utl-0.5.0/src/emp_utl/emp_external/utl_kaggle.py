# Standard library imports
import logging
import os
import tempfile
import traceback

# Third-party imports
import pandas as pd
from kaggle.api.kaggle_api_extended import KaggleApi


# Function to create kaggle client
def download_kaggle_dataset(
	kaggle_username: str,
	kaggle_key: str,
	source: str,
	logger: logging.Logger,
	filename: str | None = None,
) -> pd.DataFrame:
	"""
	Downloads and loads a Kaggle dataset into a pandas DataFrame.

	The function:
	- Authenticates against the Kaggle API
	- Downloads and extracts the dataset into a temporary directory
	- Resolves the target CSV file automatically or via explicit filename
	- Loads the dataset into a pandas DataFrame
	- Removes unnamed columns automatically

	:param kaggle_username: Kaggle account username used for authentication.
	:param kaggle_key: Kaggle API key used for authentication.
	:param source: Kaggle dataset source identifier (e.g. owner/dataset-name).
	:param logger: Logger instance for structured logging.
	:param filename: Optional explicit filename inside the dataset archive.
	:return: Pandas DataFrame containing the downloaded dataset.
	"""

	# Authenticate with Kaggle
	try:
		# Manually setting Kaggle environment variables
		os.environ['KAGGLE_USERNAME'] = kaggle_username
		os.environ['KAGGLE_KEY'] = kaggle_key

		api: KaggleApi = KaggleApi()
		api.authenticate()

		logger.info(msg="Successfully authenticated with 'Kaggle's' OpenAPI")
	except Exception as e:
		logger.error(msg=f"Error occurred while authenticating with 'Kaggle's' OpenAPI: {e!r} - Trace: {traceback.format_exc()}")
		raise

	# Download dataset
	try:
		with tempfile.TemporaryDirectory() as tmp_dir:
			api.dataset_download_files(dataset=source, path=tmp_dir, unzip=True)

			# Resolve target file
			if filename is None:
				files: list[str] = os.listdir(path=tmp_dir)

				if not files:
					raise FileNotFoundError('No files found in download dataset')

				filename: str = files[0]

			file_path: str = os.path.join(tmp_dir, filename)

			# Loading Dataframe
			df: pd.DataFrame = pd.read_csv(
				filepath_or_buffer=file_path,
				sep=',',
				encoding='utf-8',
				usecols=lambda col: not col.startswith('Unnamed'),
			)
			logger.info(msg=f"Successfully loaded dataset file: '{filename}' into pandas DataFrame")
		return df.reset_index(drop=True)
	except Exception as e:
		logger.error(msg=f'Error occurred during download of jobs dataset from Kaggle: {e!r} - Trace: {traceback.format_exc()}')
		raise
