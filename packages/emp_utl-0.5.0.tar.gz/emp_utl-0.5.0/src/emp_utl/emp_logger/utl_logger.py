# Standard library imports
import json
import logging
import os
from typing import Final

# Third-party imports
from confluent_kafka import Producer


# Function to find project root
def find_project_root(
	start_path: os.PathLike[str] | None = None,
) -> os.PathLike[str] | None:
	"""
	Finds the root directory of the project by walking upwards until a
	known project marker (e.g. `.git` or `setup.py`) is found.

	:param start_path: starting path for the search. Defaults to the current working directory.
	:return: Absolute path to the project root, or None if no root marker is found.
	"""

	if start_path is None:
		start_path = os.getcwd()

	current_path: os.PathLike[str] = start_path
	while current_path != os.path.dirname(p=current_path):
		if os.path.isdir(s=os.path.join(current_path, '.git')):
			return current_path
		if os.path.isfile(path=os.path.join(current_path, 'setup.py')):
			return current_path
		current_path = os.path.dirname(p=current_path)

	return None


# Colors for pretty output
class Color:
	"""
	ANSI color definitions for styled console output.

	The class provides reusable escape sequences for colored and formatted
	terminal printing within logging, debugging, and development workflows.
	"""

	PURPLE = '\033[95m'
	CYAN = '\033[96m'
	DARKCYAN = '\033[36m'
	BLUE = '\033[94m'
	GREEN = '\033[92m'
	YELLOW = '\033[93m'
	RED = '\033[91m'
	BOLD = '\033[1m'
	UNDERLINE = '\033[4m'
	END = '\033[0m'


# Stream Handler with Colors
class ColorStreamHandler(logging.StreamHandler):
	"""
	Custom logging stream handler with ANSI-colored console output.
	The handler formats log messages depending on the log level
	to improve readability during local development and notebook execution.
	"""

	def emit(self, record: logging.LogRecord) -> None:
		"""
		Emits a formatted and colorized log record to the console.
		The output color depends on the log level:
		- INFO    -> Green
		- WARNING -> Yellow
		- ERROR   -> Red

		:param record: Log record to be emitted.
		:return: None
		"""

		message: str = self.format(record=record)

		if record.levelno >= logging.ERROR:
			color: str = Color.BOLD + Color.RED
		elif record.levelno >= logging.WARNING:
			color: str = Color.BOLD + Color.YELLOW
		elif record.levelno >= logging.INFO:
			color: str = Color.BOLD + Color.GREEN
		else:
			color: str = Color.END

		print(color + message + Color.END)


# KafkaHandler - Class
class KafkaLoggingHandler(logging.Handler):
	"""
	Custom logging handler for publishing log records to a Kafka topic.

	This handler integrates with the Confluent Kafka producer to send
	JSON-formatted log entries to a specified Kafka topic. It supports
	retry and failover mechanisms to ensure reliability across multi-broker
	Kafka clusters.

	Attributes:
		producer (Producer): Configured Kafka producer instance.
		topic (str): Kafka topic where log messages are published.
	"""

	def __init__(self, bootstrap_servers: str, topic: str = 'emp-logs'):
		"""
		Initializes the Kafka logging handler and its underlying producer.

		:param bootstrap_servers: Comma-separated list of Kafka broker addresses.
		:param topic: Kafka topic used for publishing log messages.
		"""
		super().__init__()
		self.producer: Producer = Producer(
			{
				'bootstrap.servers': bootstrap_servers,
				'acks': 'all',
				'retries': 5,
				'retry.backoff.ms': 300,
				'socket.timeout.ms': 10000,
				'message.send.max.retries': 5,
				'request.timeout.ms': 15000,
				'enable.idempotence': True,
				'queue.buffering.max.ms': 500,
				'max.in.flight.requests.per.connection': 5,
			}
		)
		self.topic = topic

	@staticmethod
	def delivery_report(err, msg):
		"""
		Kafka delivery callback invoked after a message is produced.

		:param err: Delivery error if the message failed, otherwise None.
		:param msg: Kafka message metadata for the produced record.
		:return: None
		"""

		if err is not None:
			logging.getLogger(name='KafkaLoggingHandler').error(f'Delivery failed: {err}')

	def emit(self, record: logging.LogRecord) -> None:
		"""
		Sends a formatted log record to the configured Kafka topic.

		:param record: Log record to be emitted.
		:return: None
		"""
		try:
			log_entry: str = self.format(record=record)
			self.producer.produce(
				topic=self.topic,
				key=record.name,
				value=log_entry.encode(encoding='utf-8'),
				on_delivery=self.delivery_report,
			)
			self.producer.poll(0)
		except Exception as e:
			logging.getLogger(name='KafkaLoggingHandler').error(f'Kafka emit error: {e}')


# Function to format logs
def create_log_formatter(service: str, environment: str) -> str:
	"""
	Creates a JSON-formatted logging template for structured logging.

	The formatter follows a centralized logging structure compatible
	with Kafka, ELK Stack, and distributed EMP services.

	:param service: Name of the service creating the logs.
	:param environment: Active runtime environment (e.g. dev, int, stg, prd).
	:return: JSON-formatted logging template string.
	"""

	return json.dumps(
		obj={
			'timestamp': '%(asctime)s',
			'level': '%(levelname)s',
			'thread': '%(threadName)s',
			'logger': '%(name)s',
			'service': service,
			'environment': environment,
			'message': '%(message)s',
		}
	)


# Function to create custom logger
def setup_logger(service: str, module: str = 'Serverless') -> logging.Logger:
	"""
	Creates and configures an environment-aware structured logger.

	The logger automatically adapts its behavior depending on the
	active EMP environment:
		- DEV:
			- Writes logs to local files
			- Prints colorized console output
		- INT / STG / PRD:
			- Streams structured logs to Kafka topic `emp-logs`

	The logger uses JSON-based structured logging compatible with
	centralized observability platforms such as Kafka, ELK Stack,
	and future monitoring integrations.

	:param service: Name of the service or microservice.
	:param module: Logical module or component name within the service.
	:return: Configured logger instance.
	"""

	# Setting up the environment
	environment: Final[str] = os.getenv(key='ENVIRONMENT', default='dev')

	# Ensuring Logger Root
	logger_name: str = f'{service}-{module}'
	if logger_name in logging.root.manager.loggerDict:
		return logging.getLogger(name=logger_name)

	logger: logging.Logger = logging.getLogger(name=logger_name)
	logger.setLevel(level=logging.INFO)
	logger.propagate = False

	# Log format (consistent with logback-spring.xml)
	formatter: logging.Formatter = logging.Formatter(fmt=create_log_formatter(service=service, environment=environment))

	# Define log directory (for local environments)
	ROOT_DIR = find_project_root() or os.getcwd()
	log_dir = os.path.join(ROOT_DIR, 'logs')
	os.makedirs(name=log_dir, exist_ok=True)
	log_file_path = os.path.join(log_dir, f'EMP-{logger_name}_{environment}.log')

	# Decide which handler to use
	if environment.lower() in ('int', 'stg', 'prd'):
		# Kafka handler
		kafka_servers: str = os.getenv(
			key='KAFKA_BOOTSTRAP_SERVERS',
			default='emp-kafka-1:9092,emp-kafka-2:9093,emp-kafka-3:9094',
		)
		kafka_handler: KafkaLoggingHandler = KafkaLoggingHandler(bootstrap_servers=kafka_servers)
		kafka_handler.setFormatter(fmt=formatter)
		logger.addHandler(hdlr=kafka_handler)
	else:
		# Local file handler
		log_mode = 'a' if environment.lower() in ('stg', 'prd') else 'w'
		file_handler = logging.FileHandler(filename=log_file_path, mode=log_mode, delay=True)
		file_handler.setFormatter(fmt=formatter)
		logger.addHandler(hdlr=file_handler)

	# Log with print (Color)
	if environment.lower() == 'dev':
		console_handler: ColorStreamHandler = ColorStreamHandler()
		console_handler.setLevel(logging.INFO)
		formatter: logging.Formatter = logging.Formatter(fmt='[%(levelname)s] %(asctime)s - %(message)s')
		console_handler.setFormatter(fmt=formatter)
		logger.addHandler(console_handler)

	return logger
