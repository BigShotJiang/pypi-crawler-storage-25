# Standard library imports
import random
from datetime import date, datetime, time, timedelta

# Third-party imports
from dateutil.relativedelta import relativedelta


# Function to round date to next workday
def round_to_workday(date: date) -> date:
	"""
	Adjusts a given date to the next working day.

	If the input date falls on a weekend:
	- Saturday → moved to Monday
	- Sunday → moved to Monday

	Weekdays remain unchanged.

	:param date: Input date to evaluate
	:return: Adjusted date representing a working day
	"""

	# Converting date to weekday number
	weekday: int = date.weekday()
	if weekday == 5:
		return date + relativedelta(days=2)
	if weekday == 6:
		return date + relativedelta(days=1)
	return date


# Function to calculate amount of years between two dates
def calc_years(start_date: date, end_date: date | None = None) -> int:
	"""
	Calculates the number of full years between two dates.

	The result is based on the difference in days divided by 365
	and is always non-negative.

	:param start_date: Start date for the calculation
	:param end_date: End date for the calculation (defaults to today)
	:return: Number of full years between the two dates
	"""

	if end_date is None:
		end_date = date.today()

	return max(0, (end_date - start_date).days // 365)


# Function to calculate amount of months between two dates
def calc_months(start_date: date, end_date: date) -> int:
	"""
	Calculates the number of months between two dates.

	The calculation is based on year and month differences and returns
	the absolute number of months between the given dates.

	:param end_date: End date of the calculation
	:param start_date: Start date of the calculation
	:return: Number of months between the two dates
	"""

	return abs((end_date.year - start_date.year) * 12 + end_date.month - start_date.month)


# Function to create random datetime between two dates
def create_random_datetime(start_date: date, end_date: date) -> datetime:
	"""
	Generates a random datetime between two given dates.

	:param start_date: Start date of interval
	:param end_date: End date of interval
	:return: Randomized datetime object
	"""

	start_datetime: datetime = datetime.combine(date=start_date, time=time.min)
	end_datetime: datetime = datetime.combine(date=end_date, time=time.max)

	delta: int = int((end_datetime - start_datetime).total_seconds())
	random_seconds: int = random.randint(a=0, b=max(delta, 1))

	return start_datetime + timedelta(seconds=random_seconds)
