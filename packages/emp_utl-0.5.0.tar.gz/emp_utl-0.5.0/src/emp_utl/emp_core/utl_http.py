# Function to detect HTTP error
def map_exception_to_http_code(exc: Exception) -> int:
	"""
	Maps raised Python exceptions to appropriate HTTP status codes.

	This function translates common exception types into meaningful HTTP
	response codes, enabling consistent and semantically correct error
	handling across serverless services.

	It is primarily used by serverless handlers to determine the correct
	HTTP status code based on the root cause of a failure (e.g. configuration,
	connectivity, or runtime errors).

	:param exc: The exception instance raised during execution
	:return: Corresponding HTTP status code
	"""

	if isinstance(exc, PermissionError):
		return 401  # Unauthorized
	if isinstance(exc, ConnectionError):
		return 503  # Service Unavailable
	if isinstance(exc, TimeoutError):
		return 504  # Gateway Timeout
	if isinstance(exc, ValueError):
		return 400  # Bad Request
	if isinstance(exc, KeyError):
		return 400  # Bad Request

	return 500  # Internal Server Error (Fallback)
