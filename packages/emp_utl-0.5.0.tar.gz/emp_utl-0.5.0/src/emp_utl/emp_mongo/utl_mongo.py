# Standard library imports
import logging
import traceback
from typing import Any

# Third-party imports
import pandas as pd
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database


# Function to resolve MongoDB collection name
def resolve_collection_name(df_name: str, collection_mapper: dict[str, str]) -> str:
	"""
	Resolves the target MongoDB collection name for a dataframe.
	The function matches the dataframe name against the provided
	collection mapper and returns the corresponding MongoDB
	collection name.

	Example:
		student_credential -> credential
		staff_banking      -> banking

	:param df_name: Name of the dataframe key
	:param collection_mapper: Dictionary mapping keywords to collections
	:return: MongoDB collection name
	"""

	df_name = df_name.lower()

	for key, collection in collection_mapper.items():
		if key.lower() in df_name:
			return collection

	return df_name


# Function to create MongoDB indexes
def create_mongo_indexes(
	collection: Collection,
	indexes: list[tuple[list[dict[str, int]], dict[str, Any]]] | None,
) -> None:
	"""
	Creates indexes on a MongoDB collection.

	:param collection: Active MongoDB collection
	:param indexes: Optional index definitions
	:return: None
	"""

	if indexes:
		for fields, options in indexes:
			collection.create_index(keys=fields, **options)


# Function to load DataFrames to MongoDB
def load_mongo(
	env_vars: dict[str, str],
	collection_mapper: dict[str, str],
	df_dict: dict[str, pd.DataFrame],
	logger: logging.Logger,
	indexes: dict[str, list[tuple[list[tuple[str, int]], dict[str, Any]]]] | None = None,
	reset_db: bool = False,
) -> None:
	"""
	Loads multiple pandas DataFrames into MongoDB collections.
	The function:
	- Establishes a MongoDB connection
	- Optionally resets the target database
	- Resolves collection names dynamically
	- Creates optional indexes
	- Inserts dataframe records into MongoDB collections

	:param env_vars: Environment configuration dictionary
	:param df_dict: Dictionary containing DataFrames
	:param logger: Logger instance for structured logging
	:param collection_mapper: Mapping of dataframe keywords to collections
	:param indexes: Optional collection index configuration
	:param reset_db: If True, drops the database before insert
	:return: None
	"""

	# Variables
	mongo_uri: str = env_vars['MONGO_URI_UTILITY']
	db_name: str = env_vars['MONGO_DB_UTILITY']
	client: MongoClient | None = None

	try:
		# Establish MongoDB connection
		client = MongoClient(host=mongo_uri)
		db: Database = client[db_name]
		logger.info(msg=f"Connected to MongoDB database: '{db_name}'")

		# Optional database reset
		if reset_db:
			client.drop_database(name_or_database=db_name)
			logger.info(msg=f"Dropped MongoDB database: '{db_name}'")
			db = client[db_name]

		# Loading DataFrames
		for dataframe_name, df in df_dict.items():
			# Skip empty DataFrames
			if df.empty:
				logger.warning(msg=f"DataFrame '{dataframe_name}' is empty -> Skipping")
				continue

			# Resolve collection name
			collection_name: str = resolve_collection_name(df_name=dataframe_name, collection_mapper=collection_mapper)
			collection: Collection = db[collection_name]

			# Create indexes
			create_mongo_indexes(
				collection=collection,
				indexes=(indexes.get(collection_name) if indexes else None),
			)

			# Convert dataframe to records
			records: list[dict[str, Any]] = df.to_dict(orient='records')

			# Insert records
			result = collection.insert_many(documents=records)
			logger.info(msg=f"Inserted '{len(result.inserted_ids)}' documents into collection '{collection_name}'")
	except Exception as e:
		logger.error(msg=f'Error occurred while loading MongoDB data: {e!r} - Trace: {traceback.format_exc()}')
		raise
	finally:
		if client:
			client.close()
