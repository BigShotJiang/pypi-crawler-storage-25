import sys
import uuid
import os
import leanvec
import atexit
import gc
import time
import threading
import orjson
import signal
import math
from typing import List, Dict, Any, Optional, Tuple
from contextlib import contextmanager
from datetime import date, datetime, timezone

# --- Cross-Platform Locking Support ---
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

class CollectionLock:
    """File-based lock for a collection, providing both thread and process safety."""
    
    def __init__(self, collection_path: str):
        # Force absolute path to ensure all processes agree on the lock file location
        self.lock_path = os.path.abspath(os.path.join(collection_path, '.collection.lock'))
        self._thread_lock = threading.RLock()
        self._ensure_lock_file()
    
    def _ensure_lock_file(self):
        """Ensure the lock file exists."""
        try:
            os.makedirs(os.path.dirname(self.lock_path), exist_ok=True)
        except FileExistsError:
            pass
        try:
            # Open in append mode to ensure creation, but don't truncate
            with open(self.lock_path, 'a'):
                pass
        except OSError:
            pass
    
    @contextmanager
    def read_lock(self):
        """Acquire a shared read lock."""
        # Thread safety first
        with self._thread_lock:
            if HAS_FCNTL:
                # Process safety via fcntl
                # Use 'a+' (read/append) to ensure we have write access metadata 
                # which helps stability of exclusive locks on some FS, and ensure file isn't truncated.
                f = open(self.lock_path, 'a+')
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                    yield
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                    f.close()
            else:
                # Windows fallback (No process safety, only thread safety)
                yield
    
    @contextmanager
    def write_lock(self):
        """Acquire an exclusive write lock."""
        with self._thread_lock:
            if HAS_FCNTL:
                f = open(self.lock_path, 'a+')
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                    yield
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                    f.close()
            else:
                yield


class NoOpLock:
    """No-op lock that does nothing - for single-threaded use."""
    @contextmanager
    def read_lock(self): yield
    @contextmanager
    def write_lock(self): yield


class VersionTracker:
    """Track collection version to detect changes from other processes."""
    
    def __init__(self, collection_path: str):
        self.version_path = os.path.abspath(os.path.join(collection_path, '.version'))
        self._ensure_version_file()
    
    def _ensure_version_file(self):
        try:
            os.makedirs(os.path.dirname(self.version_path), exist_ok=True)
        except FileExistsError:
            pass
        try:
            # Initialize if missing
            if not os.path.exists(self.version_path):
                self._write_version(0)
        except OSError:
            pass
    
    def _write_version(self, version: int):
        # Atomic write pattern
        tmp_path = self.version_path + ".tmp"
        try:
            with open(tmp_path, 'w') as f:
                f.write(str(version))
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self.version_path)
        except OSError:
            # Handle potential race where another process wrote/moved/deleted
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass
    
    def get_version(self) -> int:
        try:
            with open(self.version_path, 'r') as f:
                content = f.read().strip()
                return int(content) if content else 0
        except (FileNotFoundError, ValueError):
            return 0
    
    def increment_version(self):
        # This must be called INSIDE a write_lock
        current = self.get_version()
        self._write_version(current + 1)


class NoOpVersionTracker:
    def get_version(self) -> int: return 0
    def increment_version(self): pass


class LeanVecDB:
    def __init__(self, base_path: str = 'leanvec_root', auto_persist: bool = True, thread_safe: bool = False, pca_enabled: bool = False):
        """Initialize LeanVecDB.
        
        Args:
            base_path: Directory to store database files
            auto_persist: Whether to automatically persist on exit
            thread_safe: If True, enables thread and process safety via file locking.
        """
        self.in_memory = base_path == ':memory:'
        self.base_path = ':memory:' if self.in_memory else os.path.abspath(base_path)
        self.thread_safe = thread_safe
        self.pca_enabled = pca_enabled
        self._is_closed = False

        if not self.in_memory:
            os.makedirs(base_path, exist_ok=True)

        self.collections: Dict[str, leanvec.LeanDB] = {}
        self.dimensions: Dict[str, int] = {}
        self.collection_locks: Dict[str, CollectionLock] = {}
        self.version_trackers: Dict[str, VersionTracker] = {}
        self.local_versions: Dict[str, int] = {}
        
        # Global lock for managing the python dictionaries (collections, locks)
        self._collections_lock = threading.RLock() if thread_safe else None
        
        self._load_existing_collections()

        self.start_time = time.time()
        self.last_access_time = time.time()
        self.maintenance_interval = 86400
        self.idle_threshold = 3600
        self.max_maintenance_defer = 36 * 3600

        # Automatic vacuum policy (threshold-based, only in best idle period).
        self.auto_vacuum_enabled = True
        self.auto_vacuum_cooldown = 7 * 86400
        self.auto_vacuum_min_live_docs = 1000
        self.auto_vacuum_utilization_threshold = 0.65
        self.auto_vacuum_bloat_threshold = 2.5

        # Idle profile over a larger period (hour buckets over recent weeks).
        self.idle_profile_window_hours = 24 * 14
        self.idle_hour_scores: Dict[int, float] = {}
        self._last_idle_bucket = int(time.time() // 3600)

        # Per-collection maintenance state.
        self.collection_last_vacuum: Dict[str, float] = {}
        self.collection_last_prewarm: Dict[str, float] = {}
        self.collection_min_bytes_per_live: Dict[str, float] = {}

        # Automatic reverse-edge prewarm (delete path warm-up) during maintenance window.
        self.auto_reverse_prewarm_enabled = True
        self.auto_reverse_prewarm_cooldown = 7 * 86400
        self.auto_reverse_prewarm_min_live_docs = 50000

        # Persist maintenance state so "best idle period" survives restarts.
        self._maintenance_state_path = None if self.in_memory else os.path.join(self.base_path, '.maintenance_state.json')
        self.next_maintenance_due = self.start_time + self.maintenance_interval
        self._load_maintenance_state()
        self.stop_maintenance = False
        
        self.m_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.m_thread.start()

        if auto_persist:
            atexit.register(self.close)
            signal.signal(signal.SIGTERM, self._handle_signal)
            signal.signal(signal.SIGINT, self._handle_signal)

    def _safe_file_size(self, path: str) -> int:
        try:
            return os.path.getsize(path)
        except OSError:
            return 0

    def _load_maintenance_state(self):
        if self.in_memory or not self._maintenance_state_path:
            return
        if not os.path.exists(self._maintenance_state_path):
            return

        try:
            with open(self._maintenance_state_path, 'rb') as f:
                data = orjson.loads(f.read())

            now = time.time()
            self.next_maintenance_due = float(data.get('next_maintenance_due', self.next_maintenance_due))
            if self.next_maintenance_due < now - self.maintenance_interval:
                self.next_maintenance_due = now

            raw_idle = data.get('idle_hour_scores', {})
            if isinstance(raw_idle, dict):
                for k, v in raw_idle.items():
                    try:
                        bucket = int(k)
                        score = float(v)
                    except (TypeError, ValueError):
                        continue
                    if score > 0:
                        self.idle_hour_scores[bucket] = score

            raw_last_vacuum = data.get('collection_last_vacuum', {})
            if isinstance(raw_last_vacuum, dict):
                for k, v in raw_last_vacuum.items():
                    try:
                        self.collection_last_vacuum[str(k)] = float(v)
                    except (TypeError, ValueError):
                        pass

            raw_last_prewarm = data.get('collection_last_prewarm', {})
            if isinstance(raw_last_prewarm, dict):
                for k, v in raw_last_prewarm.items():
                    try:
                        self.collection_last_prewarm[str(k)] = float(v)
                    except (TypeError, ValueError):
                        pass

            raw_baseline = data.get('collection_min_bytes_per_live', {})
            if isinstance(raw_baseline, dict):
                for k, v in raw_baseline.items():
                    try:
                        baseline = float(v)
                    except (TypeError, ValueError):
                        continue
                    if baseline > 0:
                        self.collection_min_bytes_per_live[str(k)] = baseline

            self._prune_idle_profile(now)
        except Exception:
            pass

    def _save_maintenance_state(self):
        if self.in_memory or not self._maintenance_state_path:
            return
        try:
            now = time.time()
            self._prune_idle_profile(now)
            payload = {
                'next_maintenance_due': self.next_maintenance_due,
                'idle_hour_scores': {str(k): v for k, v in self.idle_hour_scores.items()},
                'collection_last_vacuum': self.collection_last_vacuum,
                'collection_last_prewarm': self.collection_last_prewarm,
                'collection_min_bytes_per_live': self.collection_min_bytes_per_live,
            }
            tmp_path = self._maintenance_state_path + '.tmp'
            with open(tmp_path, 'wb') as f:
                f.write(orjson.dumps(payload))
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp_path, self._maintenance_state_path)
        except Exception:
            pass

    def _prune_idle_profile(self, now: float):
        min_bucket = int(now // 3600) - self.idle_profile_window_hours
        stale = [bucket for bucket in self.idle_hour_scores if bucket < min_bucket]
        for bucket in stale:
            del self.idle_hour_scores[bucket]

    def _record_idle_sample(self, now: float):
        bucket = int(now // 3600)
        idle_time = max(0.0, now - self.last_access_time)
        threshold = max(float(self.idle_threshold), 1.0)
        idle_ratio = min(1.0, idle_time / threshold)
        self.idle_hour_scores[bucket] = self.idle_hour_scores.get(bucket, 0.0) + idle_ratio

        if bucket != self._last_idle_bucket:
            self._last_idle_bucket = bucket
            self._save_maintenance_state()

    def _get_best_idle_hour(self) -> int:
        if not self.idle_hour_scores:
            # Common off-peak default when we still lack history.
            return 3

        sums = [0.0] * 24
        counts = [0] * 24
        for bucket, score in self.idle_hour_scores.items():
            hour = datetime.fromtimestamp(bucket * 3600).hour
            sums[hour] += score
            counts[hour] += 1

        best_hour = 3
        best_score = -1.0
        for hour in range(24):
            if counts[hour] == 0:
                continue
            avg_score = sums[hour] / counts[hour]
            if avg_score > best_score:
                best_score = avg_score
                best_hour = hour
        return best_hour

    def _collection_storage_stats(self, collection: str) -> Optional[Dict[str, float]]:
        if self.in_memory:
            return None
        if collection not in self.dimensions:
            return None

        dim = self.dimensions.get(collection) or 0
        if dim <= 0:
            return None

        path = self._get_col_path(collection)
        vectors_size = self._safe_file_size(os.path.join(path, 'vectors.bin'))
        ids_size = self._safe_file_size(os.path.join(path, 'ids.bin'))
        metadata_size = self._safe_file_size(os.path.join(path, 'metadata.bin'))

        if vectors_size <= 0:
            return None

        slot_count = vectors_size // int(dim)
        if slot_count <= 0:
            return None

        live_count = float(self.count(collection))
        slot_utilization = live_count / float(slot_count)

        payload_size = float(ids_size + metadata_size)
        bytes_per_live = payload_size / max(1.0, live_count)

        baseline = self.collection_min_bytes_per_live.get(collection)
        if baseline is None:
            baseline = bytes_per_live
        elif bytes_per_live < baseline:
            baseline = bytes_per_live
        else:
            # Slowly adapt baseline upward to avoid stale ancient minimums.
            baseline = (baseline * 0.999) + (bytes_per_live * 0.001)
        baseline = max(1.0, baseline)
        self.collection_min_bytes_per_live[collection] = baseline

        payload_bloat_ratio = bytes_per_live / baseline

        return {
            'live_count': live_count,
            'slot_count': float(slot_count),
            'slot_utilization': slot_utilization,
            'payload_size': payload_size,
            'payload_bloat_ratio': payload_bloat_ratio,
            'bytes_per_live': bytes_per_live,
            'reclaimable_slots': max(0.0, float(slot_count) - live_count),
        }

    def _collection_vacuum_candidate(self, collection: str, now: float) -> Optional[Dict[str, Any]]:
        if not self.auto_vacuum_enabled:
            return None

        stats = self._collection_storage_stats(collection)
        if not stats:
            return None

        if stats['live_count'] < float(self.auto_vacuum_min_live_docs):
            return None

        last_vacuum = self.collection_last_vacuum.get(collection, 0.0)
        if now - last_vacuum < float(self.auto_vacuum_cooldown):
            return None

        util_trigger = stats['slot_utilization'] < float(self.auto_vacuum_utilization_threshold)
        bloat_trigger = stats['payload_bloat_ratio'] > float(self.auto_vacuum_bloat_threshold)
        if not util_trigger and not bloat_trigger:
            return None

        if stats['reclaimable_slots'] < 1024 and not bloat_trigger:
            return None

        util_score = 0.0
        if util_trigger and self.auto_vacuum_utilization_threshold > 0:
            util_score = (self.auto_vacuum_utilization_threshold - stats['slot_utilization']) / self.auto_vacuum_utilization_threshold

        bloat_score = 0.0
        if bloat_trigger and self.auto_vacuum_bloat_threshold > 0:
            bloat_score = (stats['payload_bloat_ratio'] / self.auto_vacuum_bloat_threshold) - 1.0

        if util_score >= bloat_score:
            reason = 'low_slot_utilization'
            score = util_score
        else:
            reason = 'payload_bloat'
            score = bloat_score

        return {
            'collection': collection,
            'reason': reason,
            'score': score,
            'stats': stats,
        }

    def _select_auto_vacuum_candidate(self, now: float) -> Optional[Dict[str, Any]]:
        candidates: List[Dict[str, Any]] = []
        for collection in self.list_collections():
            cand = self._collection_vacuum_candidate(collection, now)
            if cand is not None:
                candidates.append(cand)

        if not candidates:
            return None
        candidates.sort(key=lambda c: c['score'], reverse=True)
        return candidates[0]

    def _run_auto_vacuum(self, now: float):
        cand = self._select_auto_vacuum_candidate(now)
        if not cand:
            return

        collection = cand['collection']
        try:
            self.vacuum(collection)
            self.collection_last_vacuum[collection] = time.time()

            refreshed = self._collection_storage_stats(collection)
            if refreshed and refreshed['bytes_per_live'] > 0:
                self.collection_min_bytes_per_live[collection] = refreshed['bytes_per_live']

            stats = cand['stats']
            sys.stderr.write(
                f"LeanVec Info: auto-vacuum ran for '{collection}' "
                f"(reason={cand['reason']}, util={stats['slot_utilization']:.3f}, "
                f"bloat={stats['payload_bloat_ratio']:.2f}).\n"
            )
        except Exception as exc:
            sys.stderr.write(f"LeanVec Warning: auto-vacuum failed for '{collection}': {exc}\n")

    def _collection_prewarm_candidate(self, collection: str, now: float) -> Optional[Dict[str, Any]]:
        if not self.auto_reverse_prewarm_enabled:
            return None

        if collection not in self.dimensions:
            return None

        live_count = float(self.count(collection))
        if live_count < float(self.auto_reverse_prewarm_min_live_docs):
            return None

        last_prewarm = self.collection_last_prewarm.get(collection, 0.0)
        if now - last_prewarm < float(self.auto_reverse_prewarm_cooldown):
            return None

        return {
            'collection': collection,
            'live_count': live_count,
        }

    def _select_auto_prewarm_candidate(self, now: float) -> Optional[Dict[str, Any]]:
        best: Optional[Dict[str, Any]] = None
        for collection in self.list_collections():
            cand = self._collection_prewarm_candidate(collection, now)
            if cand is None:
                continue
            if best is None or cand['live_count'] > best['live_count']:
                best = cand
        return best

    def _run_auto_reverse_prewarm(self, now: float):
        cand = self._select_auto_prewarm_candidate(now)
        if not cand:
            return

        collection = cand['collection']
        col_lock = self._get_collection_lock(collection)
        try:
            with col_lock.write_lock():
                if self.thread_safe and self._needs_reload(collection):
                    self._reload_collection(collection)
                db = self._ensure_collection(collection)
                built_now = bool(db.prewarm_delete_path())
                self.collection_last_prewarm[collection] = time.time()
                self._save_maintenance_state()
                if built_now:
                    sys.stderr.write(
                        f"LeanVec Info: reverse-edge prewarm ran for '{collection}' "
                        f"(live={int(cand['live_count'])}).\n"
                    )
        except Exception as exc:
            sys.stderr.write(
                f"LeanVec Warning: reverse-edge prewarm failed for '{collection}': {exc}\n"
            )

    def _should_run_maintenance_now(self, now: float, idle_time: float) -> bool:
        if now < self.next_maintenance_due:
            return False
        if idle_time < self.idle_threshold:
            return False

        best_hour = self._get_best_idle_hour()
        current_hour = datetime.fromtimestamp(now).hour
        if current_hour == best_hour:
            return True

        overdue = now - self.next_maintenance_due
        return overdue >= self.max_maintenance_defer

    def _handle_signal(self, signum, frame):
        self.close()
        sys.exit(0)

    def _get_col_path(self, name: str) -> str:
        if self.in_memory:
            return f':memory:/{name}'
        return os.path.join(self.base_path, name)

    def _get_collection_lock(self, name: str):
        if self.in_memory or not self.thread_safe:
            return NoOpLock()
        
        with self._collections_lock:
            if name not in self.collection_locks:
                path = self._get_col_path(name)
                self.collection_locks[name] = CollectionLock(path)
            return self.collection_locks[name]
    
    def _get_version_tracker(self, name: str):
        if self.in_memory or not self.thread_safe:
            return NoOpVersionTracker()
        
        with self._collections_lock:
            if name not in self.version_trackers:
                path = self._get_col_path(name)
                self.version_trackers[name] = VersionTracker(path)
            return self.version_trackers[name]

    def _load_existing_collections(self):
        if self.in_memory:
            return
        if not os.path.exists(self.base_path):
            return
        for name in os.listdir(self.base_path):
            path = self._get_col_path(name)
            if os.path.isdir(path):
                cfg_path = os.path.join(path, 'config.json')
                if os.path.exists(cfg_path):
                    try:
                        with open(cfg_path, 'rb') as f:
                            self.dimensions[name] = orjson.loads(f.read()).get('dimension')
                    except: 
                        pass

    def _needs_reload(self, collection: str) -> bool:
        """Check if disk version is higher than loaded version."""
        if self.in_memory or not self.thread_safe:
            return False
        
        if collection not in self.local_versions:
            # We haven't loaded it yet, so technically implies reload/load
            return True
        
        # Read version directly from disk (atomic read)
        tracker = self._get_version_tracker(collection)
        disk_version = tracker.get_version()
        
        # Reload if disk has moved ahead
        return disk_version > self.local_versions.get(collection, -1)

    def _reload_collection(self, collection: str):
        """Force a reload of the Rust object from disk."""
        if self.in_memory or not self.thread_safe:
            return
        
        def do_reload():
            # Release old handle
            if collection in self.collections:
                del self.collections[collection]
                gc.collect() 
            
            # Load fresh from disk
            path = self._get_col_path(collection)
            self.collections[collection] = leanvec.LeanDB(path, pca_enabled=self.pca_enabled)
            
            # Update local version to match disk
            tracker = self._get_version_tracker(collection)
            self.local_versions[collection] = tracker.get_version()

        if self._collections_lock:
            with self._collections_lock:
                do_reload()
        else:
            do_reload()

    def _ensure_collection(self, name: str) -> leanvec.LeanDB:
        self.last_access_time = time.time()
        
        def init_col():
            if name not in self.collections:
                path = self._get_col_path(name)
                if not self.in_memory:
                    os.makedirs(path, exist_ok=True)
                self.collections[name] = leanvec.LeanDB(path, pca_enabled=self.pca_enabled)
                if self.thread_safe:
                    tracker = self._get_version_tracker(name)
                    self.local_versions[name] = tracker.get_version()

        if self.thread_safe and self._collections_lock:
            with self._collections_lock:
                init_col()
        else:
            init_col()
        
        return self.collections[name]

    def _sanitize_metadata(self, meta: Any) -> Any:
        """Recursively cleans metadata for JSON compatibility.
        
        - float NaN/Inf → None
        - datetime/date objects → UTC float timestamp
        """
        if isinstance(meta, datetime):
            if meta.tzinfo is None:
                return meta.replace(tzinfo=timezone.utc).timestamp()
            return meta.timestamp()
        elif isinstance(meta, date):
            return datetime(meta.year, meta.month, meta.day, tzinfo=timezone.utc).timestamp()
        elif isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta):
                return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta

    def _serialize_filters(self, filters: Optional[Dict[str, Any]]) -> str:
        """Serialize filters, treating None/empty as a match-all object."""
        if not filters:
            return "{}"
        return orjson.dumps(self._sanitize_metadata(filters)).decode('utf-8')

    def _is_scipy_sparse_matrix(self, value: Any) -> bool:
        return hasattr(value, "tocsr") and hasattr(value, "shape") and hasattr(value, "getnnz")

    def _is_torch_sparse_tensor(self, value: Any) -> bool:
        if not hasattr(value, "is_sparse"):
            return False
        try:
            return bool(value.is_sparse)
        except Exception:
            return False

    def _is_number_like(self, value: Any) -> bool:
        try:
            float(value)
            return True
        except (TypeError, ValueError):
            return False

    def _is_sparse_pair_sequence(self, value: Any) -> bool:
        if not isinstance(value, (list, tuple)):
            return False
        if not value:
            return False
        first = value[0]
        return (
            isinstance(first, (list, tuple))
            and len(first) == 2
            and isinstance(first[0], int)
            and self._is_number_like(first[1])
        )

    def _normalize_sparse_embedding(self, sparse_embedding: Any) -> Optional[List[Tuple[int, float]]]:
        """Normalize sparse embedding into sorted (term_id, weight) pairs."""
        if sparse_embedding is None:
            return None

        terms: Dict[int, float] = {}

        if isinstance(sparse_embedding, dict):
            for idx_raw, w_raw in sparse_embedding.items():
                idx = int(idx_raw)
                if idx < 0:
                    raise ValueError("Sparse term index must be >= 0")
                w = float(w_raw)
                if not math.isfinite(w):
                    raise ValueError("Sparse weight must be finite")
                if w != 0.0:
                    terms[idx] = terms.get(idx, 0.0) + w
        elif self._is_sparse_pair_sequence(sparse_embedding):
            for pair in sparse_embedding:
                idx = int(pair[0])
                if idx < 0:
                    raise ValueError("Sparse term index must be >= 0")
                w = float(pair[1])
                if not math.isfinite(w):
                    raise ValueError("Sparse weight must be finite")
                if w != 0.0:
                    terms[idx] = terms.get(idx, 0.0) + w
        elif self._is_scipy_sparse_matrix(sparse_embedding):
            try:
                coo = sparse_embedding.tocoo()
            except Exception as e:
                raise ValueError(f"Invalid sparse embedding: {e}") from e

            data = getattr(coo, "data", None)
            row = getattr(coo, "row", None)
            col = getattr(coo, "col", None)
            shape = getattr(coo, "shape", None)
            if data is None:
                raise ValueError("Invalid sparse embedding: missing data")
            if row is None or col is None:
                raise ValueError("Invalid sparse embedding: expected COO-compatible row/col")

            if shape is not None and len(shape) == 2:
                if shape[0] == 1:
                    idxs = col
                elif shape[1] == 1:
                    idxs = row
                else:
                    raise ValueError("Sparse embedding must be a vector (1xN or Nx1)")
            else:
                idxs = col

            for idx_raw, w_raw in zip(idxs, data):
                idx = int(idx_raw)
                if idx < 0:
                    raise ValueError("Sparse term index must be >= 0")
                w = float(w_raw)
                if not math.isfinite(w):
                    raise ValueError("Sparse weight must be finite")
                if w != 0.0:
                    terms[idx] = terms.get(idx, 0.0) + w
        else:
            dense_values = sparse_embedding.tolist() if hasattr(sparse_embedding, "tolist") else sparse_embedding
            if not isinstance(dense_values, (list, tuple)):
                raise ValueError("Sparse embedding must be scipy sparse or a dense vector-like list/ndarray")
            if isinstance(dense_values, tuple):
                dense_values = list(dense_values)
            if dense_values and isinstance(dense_values[0], list):
                if len(dense_values) == 1:
                    dense_values = dense_values[0]
                elif all(isinstance(row, list) and len(row) == 1 for row in dense_values):
                    dense_values = [row[0] for row in dense_values]
                else:
                    raise ValueError("Dense sparse_embedding must be 1D, 1xN, or Nx1")

            for idx, w_raw in enumerate(dense_values):
                w = float(w_raw)
                if not math.isfinite(w):
                    raise ValueError("Sparse weight must be finite")
                if w != 0.0:
                    terms[idx] = terms.get(idx, 0.0) + w

        if not terms:
            return None

        out = [(idx, weight) for idx, weight in sorted(terms.items()) if weight != 0.0 and math.isfinite(weight)]
        return out or None

    def _normalize_sparse_batch(
        self,
        sparse_embeddings: Any,
        batch_size: int,
    ) -> List[Optional[List[Tuple[int, float]]]]:
        if sparse_embeddings is None:
            return [None] * batch_size

        if self._is_torch_sparse_tensor(sparse_embeddings):
            sparse = sparse_embeddings.coalesce()
            shape = tuple(sparse.shape)
            idxs = sparse.indices().cpu()
            vals = sparse.values().cpu()
            if len(shape) == 1:
                if batch_size != 1:
                    raise ValueError("1D sparse tensor can only be used for single-item input")
                terms: Dict[int, float] = {}
                for col_raw, w_raw in zip(idxs[0].tolist(), vals.tolist()):
                    col = int(col_raw)
                    if col < 0:
                        raise ValueError("Sparse term index must be >= 0")
                    w = float(w_raw)
                    if not math.isfinite(w):
                        raise ValueError("Sparse weight must be finite")
                    if w != 0.0:
                        terms[col] = terms.get(col, 0.0) + w
                return [self._normalize_sparse_embedding(terms)]

            if len(shape) != 2:
                raise ValueError("Sparse tensor must be 1D or 2D")
            rows, cols = int(shape[0]), int(shape[1])

            if rows == batch_size:
                grouped: List[Dict[int, float]] = [dict() for _ in range(batch_size)]
                row_idxs = idxs[0].tolist()
                col_idxs = idxs[1].tolist()
                values = vals.tolist()
                for r_raw, c_raw, w_raw in zip(row_idxs, col_idxs, values):
                    r = int(r_raw)
                    c = int(c_raw)
                    w = float(w_raw)
                    if r < 0 or r >= batch_size or c < 0:
                        raise ValueError("Sparse tensor index out of range")
                    if not math.isfinite(w):
                        raise ValueError("Sparse weight must be finite")
                    if w != 0.0:
                        grouped[r][c] = grouped[r].get(c, 0.0) + w
                return [self._normalize_sparse_embedding(grouped[i]) for i in range(batch_size)]

            if batch_size == 1 and (rows == 1 or cols == 1):
                terms: Dict[int, float] = {}
                row_idxs = idxs[0].tolist()
                col_idxs = idxs[1].tolist()
                values = vals.tolist()
                for r_raw, c_raw, w_raw in zip(row_idxs, col_idxs, values):
                    r = int(r_raw)
                    c = int(c_raw)
                    w = float(w_raw)
                    if r < 0 or c < 0:
                        raise ValueError("Sparse tensor index out of range")
                    if not math.isfinite(w):
                        raise ValueError("Sparse weight must be finite")
                    idx = c if rows == 1 else r
                    if w != 0.0:
                        terms[idx] = terms.get(idx, 0.0) + w
                return [self._normalize_sparse_embedding(terms)]

            raise ValueError("Sparse tensor batch size does not match embeddings batch")

        if self._is_scipy_sparse_matrix(sparse_embeddings):
            shape = getattr(sparse_embeddings, "shape", None)
            if not shape or len(shape) != 2:
                raise ValueError("SciPy sparse input must be 2D")
            rows, cols = int(shape[0]), int(shape[1])
            if rows == batch_size:
                return [self._normalize_sparse_embedding(sparse_embeddings.getrow(i)) for i in range(rows)]
            if batch_size == 1 and (rows == 1 or cols == 1):
                return [self._normalize_sparse_embedding(sparse_embeddings)]
            raise ValueError("SciPy sparse batch size does not match embeddings batch")

        if hasattr(sparse_embeddings, "tolist") and not isinstance(sparse_embeddings, (list, tuple, dict)):
            sparse_embeddings = sparse_embeddings.tolist()

        if isinstance(sparse_embeddings, tuple):
            sparse_embeddings = list(sparse_embeddings)

        if isinstance(sparse_embeddings, list):
            if batch_size == 1:
                if not sparse_embeddings:
                    return [None]
                if self._is_number_like(sparse_embeddings[0]) or self._is_sparse_pair_sequence(sparse_embeddings):
                    return [self._normalize_sparse_embedding(sparse_embeddings)]
                if len(sparse_embeddings) == 1:
                    return [self._normalize_sparse_embedding(sparse_embeddings[0])]

            if len(sparse_embeddings) != batch_size:
                raise ValueError("sparse_embeddings must have the same length as embeddings")
            return [self._normalize_sparse_embedding(item) for item in sparse_embeddings]

        if isinstance(sparse_embeddings, dict):
            if batch_size != 1:
                raise ValueError("Dict sparse embedding can only be used for single-item input")
            return [self._normalize_sparse_embedding(sparse_embeddings)]

        raise ValueError(
            "Unsupported sparse_embeddings format. Expected scipy sparse, torch sparse tensor, list/ndarray, dict, or list of per-item sparse inputs."
        )

    def list_collections(self) -> List[str]:
        keys = set(list(self.collections.keys()) + list(self.dimensions.keys()))
        return list(keys)

    def store_embedding(self, embedding: List[float], metadata_dict: Optional[Dict[str, Any]] = None, skip_index: Optional[List[str]] = None, collection: str = "default", ttl: Optional[int] = None, sparse_embedding: Any = None) -> str:
        metadatas = [metadata_dict] if metadata_dict is not None else None
        sparse_embeddings = [sparse_embedding]
        return self.store_embeddings_batch([embedding], metadatas, skip_index=skip_index, collection=collection, ttl=ttl, sparse_embeddings=sparse_embeddings)[0]

    def store_embeddings_batch(self, embeddings: List[List[float]], metadatas: Optional[List[Dict[str, Any]]] = None, skip_index: Optional[List[str]] = None, collection: str = "default", ttl: Optional[int] = None, sparse_embeddings: Any = None) -> List[str]:
        if hasattr(embeddings, "tolist"):
            embeddings = embeddings.tolist()
        
        if not embeddings: 
            return []
        sparse_terms_batch = self._normalize_sparse_batch(sparse_embeddings, len(embeddings))
        
        col_lock = self._get_collection_lock(collection)
        
        # LOCK ACQUIRED: No other process can write or read during this block
        with col_lock.write_lock():
            # 1. Check if another process updated the DB while we were waiting for the lock
            if self.thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            input_dim = len(embeddings[0])
            
            if collection not in self.dimensions:
                self.dimensions[collection] = input_dim
                path = self._get_col_path(collection)
                if not self.in_memory:
                    os.makedirs(path, exist_ok=True)
                    with open(os.path.join(path, 'config.json'), 'wb') as f:
                        f.write(orjson.dumps({'dimension': input_dim}))
            elif input_dim != self.dimensions[collection]:
                raise ValueError(f"Dimension Mismatch: Expected {self.dimensions[collection]}, Got {input_dim}")

            if metadatas is None: 
                metadatas = [{} for _ in range(len(embeddings))]
            
            ids = []
            metadata_json_batch = []
            for i, vec in enumerate(embeddings):
                if not vec: raise ValueError("Empty vectors are not allowed")
                if any(math.isnan(x) or math.isinf(x) for x in vec):
                    raise ValueError("Vector contains invalid float value")

                meta = metadatas[i] if i < len(metadatas) and metadatas[i] is not None else {}
                if not isinstance(meta, dict): meta = {}
                
                doc_id = str(meta.get("id") or meta.get("_id") or uuid.uuid4())
                meta["id"] = doc_id
                
                try:
                    meta_str = orjson.dumps(self._sanitize_metadata(meta)).decode('utf-8')
                except:
                    meta_str = '{"id":"' + doc_id + '"}'

                ids.append(doc_id)
                metadata_json_batch.append(meta_str)

            db.add_batch(ids, embeddings, metadata_json_batch, skip_index=skip_index, ttl=ttl, sparse_terms_batch=sparse_terms_batch)
            
            if self.thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                # Update local version so we don't reload our own changes next time
                self.local_versions[collection] = tracker.get_version()
                
            return ids
    
    def search(self,
               query_embedding: List[float], 
               k: int = 5,
               filters: Optional[Dict[str, Any]] = None,
               collection: str = "default",
               include_metadata: bool = True,
               force_fresh: bool = False,
               query_sparse_embedding: Any = None,
               rrf_k: int = 60,
               ensure_target_k: bool = False) -> List[Dict[str, Any]]:
        
        col_lock = self._get_collection_lock(collection)
        
        # Reload if stale
        requires_write = self.thread_safe and (force_fresh or self._needs_reload(collection))
        lock_manager = col_lock.write_lock() if requires_write else col_lock.read_lock()
        
        with lock_manager:
            if self.thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            filter_str = orjson.dumps(self._sanitize_metadata(filters)).decode('utf-8') if filters else None
            query_sparse_terms = self._normalize_sparse_batch(query_sparse_embedding, 1)[0]

            if include_metadata:
                json_result = db.search_json(
                    query_embedding,
                    k,
                    filter_str,
                    query_sparse_terms,
                    rrf_k,
                    ensure_target_k,
                )
                return orjson.loads(json_result)

            raw_results = db.search(
                query_embedding,
                k,
                filter_str,
                include_metadata,
                query_sparse_terms,
                rrf_k,
                ensure_target_k,
            )

        formatted = []
        for r in raw_results:
            formatted.append({"id": r[0], "score": r[1]})

        return formatted

    def iter_pca_3d(
        self,
        collection: str = "default",
        batch_size: int = 512,
        filters: Optional[Dict[str, Any]] = None,
        metadata_fields: Optional[List[str]] = None,
        force_fresh: bool = False,
        wait_for_latest: bool = False,
        timeout_ms: int = 0,
    ):
        col_lock = self._get_collection_lock(collection)

        requires_reload = self.thread_safe and (force_fresh or self._needs_reload(collection))
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if self.thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            db = self._ensure_collection(collection)
            raw_iter = db.stream_pca_3d(
                batch_size=batch_size,
                wait_for_latest=wait_for_latest,
                timeout_ms=timeout_ms,
                force_refresh=force_fresh,
                filter_json=self._serialize_filters(filters) if filters is not None else None,
            )

        selected = set(metadata_fields) if metadata_fields else None
        for batch in raw_iter:
            out = []
            for item_id, x, y, z, metadata_json in batch:
                try:
                    meta = orjson.loads(metadata_json) if metadata_json else {}
                except Exception:
                    meta = {}
                if selected is not None:
                    meta = {k: meta.get(k) for k in selected}
                out.append({
                    "id": item_id,
                    "x": x,
                    "y": y,
                    "z": z,
                    "metadata": meta,
                })
            yield out

    def _calculate_autocut(self, scores: List[float]) -> Optional[int]:
        for i in range(1, len(scores)):
            if scores[i-1] > 0 and (scores[i] - scores[i-1]) / scores[i-1] > 0.2:
                return i
        return None

    def delete(self, metadata_filter: Dict[str, Any], collection: str = "default") -> int:
        if collection not in self.collections and collection not in self.dimensions:
            return 0
        
        col_lock = self._get_collection_lock(collection)
        
        with col_lock.write_lock():
            if self.thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            count = db.delete_by_filter(orjson.dumps(self._sanitize_metadata(metadata_filter)).decode('utf-8'))
            
            if self.thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()
            
            return count

    def count(self, collection: str = "default") -> int:
        if collection not in self.collections and collection not in self.dimensions:
            return 0
        
        col_lock = self._get_collection_lock(collection)
        
        requires_reload = self.thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if requires_reload:
                self._reload_collection(collection)
            return self._ensure_collection(collection).count()

    def persist_all(self):
        if not self.in_memory and not os.path.exists(self.base_path):
            return
        names = list(self.collections.keys())
        for name in names:
            try:
                self.persist(name)
            except Exception:
                pass

    def persist(self, collection: str = "default"):
        if collection not in self.collections: return
        
        col_lock = self._get_collection_lock(collection)
        
        with col_lock.write_lock():
            gc.collect() 
            self.collections[collection].persist()
            
            if self.thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()

    def vacuum(self, collection: str = "default"):
        col_lock = self._get_collection_lock(collection)
        
        with col_lock.write_lock():
            if self.thread_safe and self._needs_reload(collection):
                self._reload_collection(collection)
            
            db = self._ensure_collection(collection)
            db.vacuum()

            self.collection_last_vacuum[collection] = time.time()
            
            if self.thread_safe:
                tracker = self._get_version_tracker(collection)
                tracker.increment_version()
                self.local_versions[collection] = tracker.get_version()

            stats = self._collection_storage_stats(collection)
            if stats and stats['bytes_per_live'] > 0:
                self.collection_min_bytes_per_live[collection] = stats['bytes_per_live']
            self._save_maintenance_state()

    def _maintenance_loop(self):
        while not self.stop_maintenance:
            time.sleep(1)
            now = time.time()
            self._record_idle_sample(now)
            idle_time = now - self.last_access_time

            if self._should_run_maintenance_now(now, idle_time):
                try:
                    self.persist_all()
                    self._run_auto_reverse_prewarm(now)
                    self._run_auto_vacuum(now)
                except Exception:
                    pass

                self.start_time = now
                self.next_maintenance_due = now + self.maintenance_interval
                self._save_maintenance_state()

    def close(self):
        """Gracefully close: stop thread, then persist."""
        if self._is_closed:
            return
        
        self.stop_maintenance = True
        if self.m_thread.is_alive() and self.m_thread is not threading.current_thread():
            try:
                self.m_thread.join(timeout=2.0)
            except RuntimeError:
                pass

        try:
            self.persist_all()
        except Exception as e:
            sys.stderr.write(f"LeanVec Warning: Error saving data on exit: {e}\n")

        self._save_maintenance_state()
        
        self._is_closed = True

    def exists(self, filters: Optional[Dict[str, Any]] = None, collection: str = "default") -> bool:
        col_lock = self._get_collection_lock(collection)
        requires_reload = self.thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if requires_reload:
                self._reload_collection(collection)
            db = self._ensure_collection(collection)
            return db.exists(self._serialize_filters(filters))

    def get_all_items(self, filters: Optional[Dict[str, Any]] = None, collection: str = "default") -> List[str]:
        col_lock = self._get_collection_lock(collection)
        requires_reload = self.thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if requires_reload:
                self._reload_collection(collection)
            db = self._ensure_collection(collection)
            results = db.get_all_items_json(self._serialize_filters(filters))
            return orjson.loads(results)

    def aggregate_unique(
        self, 
        filters: Optional[Dict[str, Any]],
        group_by: str,
        sort_by: str, 
        output_fields: List[str] = None,
        descending: bool = True,
        collection: str = "default"
    ) -> List[Dict[str, Any]]:
        if output_fields is None: output_fields = []
        col_lock = self._get_collection_lock(collection)
        requires_reload = self.thread_safe and self._needs_reload(collection)
        lock_manager = col_lock.write_lock() if requires_reload else col_lock.read_lock()

        with lock_manager:
            if requires_reload:
                self._reload_collection(collection)
            db = self._ensure_collection(collection)
            json_result = db.aggregate_unique(self._serialize_filters(filters), group_by, sort_by, output_fields, descending)
            return orjson.loads(json_result)
