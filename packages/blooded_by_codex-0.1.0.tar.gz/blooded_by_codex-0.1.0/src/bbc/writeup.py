from __future__ import annotations

from pathlib import Path

from .models import ChallengeState


def render_writeup(state: ChallengeState, skill_text: str = "") -> str:
    notes_path = Path(state.root) / "notes.md"
    command_log_path = Path(state.root) / "command.log"
    notes = notes_path.read_text(encoding="utf-8") if notes_path.exists() else ""
    command_log = command_log_path.read_text(encoding="utf-8") if command_log_path.exists() else ""
    flag = state.submission.flag or ""

    commands_section = command_log.strip() or "No commands were logged."
    lessons = "Review the solve path, note the reusable technique, and add the key lesson here."
    if skill_text:
        lessons = "Category playbook used during solving. Keep the reusable technique explicit and remove dead-end noise."

    return f"""# {state.name}

## Overview

{state.description.strip() or "Challenge description was not captured."}

Category: `{state.category or "unknown"}`

## Enumeration

{notes.strip() or "Initial notes were not captured yet."}

## Solve Path

Document the successful path here in first person, keeping only the meaningful steps and decisions.

## Commands

```bash
{commands_section}
```

## Flag

```text
{flag}
```

## What I Learned

{lessons}
"""


def write_writeup(state: ChallengeState, skill_text: str = "") -> Path:
    path = Path(state.writeup)
    path.write_text(render_writeup(state, skill_text), encoding="utf-8")
    return path
