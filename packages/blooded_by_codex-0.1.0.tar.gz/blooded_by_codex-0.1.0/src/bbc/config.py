from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Config:
    repo_root: Path
    challenges_dir: Path
    skills_dir: Path
    templates_dir: Path
    ctf_venv: Path


def find_repo_root(start: Path | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for path in (current, *current.parents):
        if (path / "pyproject.toml").exists() and (path / "src" / "bbc").exists():
            return path
    return current


def load_config() -> Config:
    root = find_repo_root()
    return Config(
        repo_root=root,
        challenges_dir=Path(os.environ.get("BBC_CHALLENGES_DIR", root / "challenges")),
        skills_dir=Path(os.environ.get("BBC_SKILLS_DIR", root / "skills")),
        templates_dir=Path(os.environ.get("BBC_TEMPLATES_DIR", root / "templates")),
        ctf_venv=Path(os.environ.get("BBC_CTF_VENV", Path.home() / "ctf-venv")),
    )
