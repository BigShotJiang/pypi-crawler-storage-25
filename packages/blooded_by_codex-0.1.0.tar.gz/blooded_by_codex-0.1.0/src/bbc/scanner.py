from __future__ import annotations

import json
import re
from pathlib import Path

from .models import ChallengeState


FLAG_RE = re.compile(r"HTB\{[^}\s]+\}")
URL_RE = re.compile(r"https?://[^\s\"'<>]+")


def scan_files(state: ChallengeState) -> ChallengeState:
    root = Path(state.root)
    findings = {key: list(values) for key, values in state.findings.items()}

    files: list[str] = []
    candidate_flags = set(findings.get("candidate_flags", []))
    urls = set(findings.get("urls", []))

    for path in root.rglob("*"):
        if not path.is_file() or path.name == ".bbc.json":
            continue
        rel = str(path.relative_to(root))
        files.append(rel)
        if path.stat().st_size > 2_000_000:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        candidate_flags.update(FLAG_RE.findall(text))
        urls.update(URL_RE.findall(text))

    findings["files"] = sorted(set(files))
    findings["candidate_flags"] = sorted(candidate_flags)
    findings["urls"] = sorted(urls)
    state.findings = findings

    (root / "findings.json").write_text(
        json.dumps(findings, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return state
