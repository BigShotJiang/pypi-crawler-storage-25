from __future__ import annotations

import configparser
import hashlib
import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_API_BASE = "https://labs.hackthebox.com/api/"
DEFAULT_USER_AGENT = "bbc/0.1.0"
ZIP_PASSWORD = b"hackthebox"


@dataclass(frozen=True)
class HtbApiConfig:
    api_key: str
    api_base_url: str = DEFAULT_API_BASE
    user_agent: str = DEFAULT_USER_AGENT
    verify_ssl: bool = True


class HtbApiError(RuntimeError):
    pass


def bbc_config_path() -> Path:
    configured = os.environ.get("BBC_CONFIG")
    if configured:
        return Path(configured).expanduser()
    base = os.environ.get("BBC_CONFIG_DIR")
    if base:
        return Path(base).expanduser() / "config.ini"
    return Path.home() / ".config" / "bbc" / "config.ini"


def load_bbc_config() -> HtbApiConfig:
    configured_key = os.environ.get("BBC_HTB_API_KEY")
    configured_base = os.environ.get("BBC_HTB_API_BASE", DEFAULT_API_BASE)
    if configured_key:
        return HtbApiConfig(api_key=configured_key, api_base_url=configured_base)

    path = bbc_config_path()
    if not path.exists():
        raise HtbApiError(
            f"Could not find bbc config at {path}. Run: bbc config set-token <token>"
        )

    parser = configparser.ConfigParser()
    parser.read(path)
    if "HTB" not in parser or not parser["HTB"].get("api_key"):
        raise HtbApiError(f"No [HTB] api_key found in {path}. Run: bbc config set-token <token>")

    htb = parser["HTB"]
    return HtbApiConfig(
        api_key=htb["api_key"],
        api_base_url=htb.get("api_base_url", DEFAULT_API_BASE),
        user_agent=htb.get("user_agent", DEFAULT_USER_AGENT),
        verify_ssl=htb.get("verify_ssl", "true").strip().lower() == "true",
    )


def save_bbc_config(
    *,
    api_key: str,
    api_base_url: str = DEFAULT_API_BASE,
    user_agent: str = DEFAULT_USER_AGENT,
    verify_ssl: bool = True,
) -> Path:
    path = bbc_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    parser = configparser.ConfigParser()
    parser["HTB"] = {
        "api_key": api_key,
        "api_base_url": api_base_url,
        "user_agent": user_agent,
        "verify_ssl": str(verify_ssl),
    }
    with path.open("w", encoding="utf-8") as handle:
        parser.write(handle)
    path.chmod(0o600)
    return path


def _url(config: HtbApiConfig, endpoint: str, api_version: str = "v4") -> str:
    base = config.api_base_url.rstrip("/") + "/"
    return urllib.parse.urljoin(base, f"{api_version}/{endpoint.lstrip('/')}")


def _headers(config: HtbApiConfig) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {config.api_key}",
        "User-Agent": config.user_agent,
        "Accept": "application/json",
    }


def _ssl_context(config: HtbApiConfig) -> ssl.SSLContext | None:
    if config.verify_ssl:
        return None
    return ssl._create_unverified_context()


def _decode_error(error: urllib.error.HTTPError) -> str:
    body = error.read()
    if not body:
        return str(error)
    try:
        data = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return body.decode("utf-8", errors="replace")
    if isinstance(data, dict):
        return str(data.get("message") or data)
    return str(data)


def request_json(config: HtbApiConfig, method: str, endpoint: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
    body = None
    headers = _headers(config)
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = urllib.request.Request(_url(config, endpoint), data=body, headers=headers, method=method)
    while True:
        try:
            with urllib.request.urlopen(request, context=_ssl_context(config), timeout=30) as response:
                data = response.read()
            return json.loads(data.decode("utf-8")) if data else {}
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                time.sleep(1)
                continue
            raise HtbApiError(_decode_error(exc)) from exc
        except urllib.error.URLError as exc:
            raise HtbApiError(str(exc.reason)) from exc


def request_bytes(config: HtbApiConfig, endpoint: str) -> bytes:
    request = urllib.request.Request(_url(config, endpoint), headers=_headers(config), method="GET")
    while True:
        try:
            with urllib.request.urlopen(request, context=_ssl_context(config), timeout=60) as response:
                return response.read()
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                time.sleep(1)
                continue
            raise HtbApiError(_decode_error(exc)) from exc
        except urllib.error.URLError as exc:
            raise HtbApiError(str(exc.reason)) from exc


def get_challenge(challenge_id_or_name: int | str) -> dict[str, Any]:
    config = load_bbc_config()
    value = urllib.parse.quote(str(challenge_id_or_name), safe="")
    data = request_json(config, "GET", f"challenge/info/{value}")
    if "challenge" not in data:
        raise HtbApiError("HTB API response did not contain a challenge object.")
    return data["challenge"]


def submit_challenge_flag(challenge_id: int, flag: str, difficulty: int = 1) -> bool:
    config = load_bbc_config()
    data = request_json(
        config,
        "POST",
        "challenge/own",
        {"flag": flag, "challenge_id": challenge_id, "difficulty": difficulty * 10},
    )
    return data.get("message") != "Incorrect flag"


def start_challenge_instance(challenge_id: int) -> dict[str, Any]:
    config = load_bbc_config()
    request_json(config, "POST", "challenge/start", {"challenge_id": challenge_id})
    for _ in range(120):
        challenge = get_challenge(challenge_id)
        if challenge.get("docker_ip"):
            return challenge
        time.sleep(1)
    raise HtbApiError("Timed out waiting for HTB challenge instance to start.")


def download_challenge_zip(challenge: dict[str, Any], destination: Path, *, unzip: bool = True, clear: bool = True) -> Path:
    challenge_id = int(challenge["id"])
    name = str(challenge.get("name") or challenge_id).strip().replace(" ", "_")
    destination.mkdir(parents=True, exist_ok=True)
    zip_path = destination / f"{name}.zip"

    data = request_bytes(load_bbc_config(), f"challenge/download/{challenge_id}")
    zip_path.write_bytes(data)

    expected_sha = challenge.get("sha256") or ""
    if expected_sha:
        actual_sha = hashlib.sha256(data).hexdigest()
        if actual_sha != expected_sha:
            raise HtbApiError(f"Download hash mismatch: expected {expected_sha}, got {actual_sha}.")

    if unzip:
        with zipfile.ZipFile(zip_path) as archive:
            archive.extractall(destination, pwd=ZIP_PASSWORD)
        if clear:
            zip_path.unlink()

    return zip_path
