from __future__ import annotations

from pathlib import Path

from .api import (
    download_challenge_zip,
    get_challenge,
    start_challenge_instance,
    submit_challenge_flag,
)


def challenge_info(root: Path, name: str) -> tuple[str, int | None, str | None]:
    challenge = get_challenge(name)
    return (
        str(challenge.get("description") or ""),
        int(challenge["id"]) if challenge.get("id") is not None else None,
        str(challenge.get("category_name") or "").lower() or None,
    )


def download_challenge(root: Path, *, name: str, htb_id: int | None, destination: Path, start: bool) -> None:
    challenge = get_challenge(htb_id if htb_id is not None else name)
    if not challenge.get("download", False):
        raise RuntimeError(f'Challenge "{challenge.get("name", name)}" does not provide any downloads.')

    download_challenge_zip(challenge, destination, unzip=True, clear=True)

    if start and challenge.get("docker", False):
        started = start_challenge_instance(int(challenge["id"]))
        ports = started.get("docker_ports") or []
        print(f"Instance: {started.get('docker_ip')} ports={','.join(str(port) for port in ports)}")


def submit_flag(root: Path, *, htb_id: int, flag: str) -> bool:
    return submit_challenge_flag(htb_id, flag)
