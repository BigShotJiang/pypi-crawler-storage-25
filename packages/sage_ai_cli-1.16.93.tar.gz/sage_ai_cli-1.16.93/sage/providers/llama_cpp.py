"""Local GGUF model provider via llama-cpp-python."""

from __future__ import annotations

import platform
from collections.abc import Iterator

from ..config import LocalModel, SageConfig
from .base import Message, ModelInfo, ProviderBase

_MODELS_DIR_DEFAULT = None  # resolved lazily


def _models_dir():
    from sage.config import SAGE_DIR
    d = SAGE_DIR / "models"
    d.mkdir(parents=True, exist_ok=True)
    return d


class LlamaCppProvider(ProviderBase):
    """Runs GGUF models locally through llama-cpp-python."""

    name = "llama_cpp"

    def __init__(self, config: SageConfig) -> None:
        self._config = config
        self._loaded_name: str | None = None
        self._model: object | None = None  # Llama instance (lazy import)

    def _all_local_models(self) -> list[tuple[str, "Path"]]:
        """Return (name, path) for every usable local GGUF model.

        Combines config-registered models with any .gguf files already
        present in ~/.sage/models/ — so models downloaded via `sage pull`
        are visible even before being explicitly registered.
        """
        from pathlib import Path

        seen: dict[str, Path] = {}

        # Config-registered models (highest priority)
        for name in self._config.local_model_names():
            entry = self._config.get_local_model(name)
            if entry:
                p = Path(entry.path)
                if p.is_file() and p.stat().st_size > 0:
                    seen[name] = p

        # Disk scan — picks up any .gguf files pulled via `sage pull`
        models_dir = _models_dir()
        for gguf in sorted(models_dir.glob("*.gguf")):
            if gguf.stat().st_size > 0 and gguf.stem not in seen:
                seen[gguf.stem] = gguf
                # Auto-register so future commands don't need another scan
                try:
                    from sage.config import save_config
                    if gguf.stem not in self._config.models:
                        self._config.models[gguf.stem] = {"path": str(gguf)}
                        save_config(self._config)
                except Exception:
                    pass

        return list(seen.items())

    def is_available(self) -> bool:
        try:
            import llama_cpp as _  # noqa: F401
        except ImportError:
            return False
        return len(self._all_local_models()) > 0

    def list_models(self) -> list[ModelInfo]:
        try:
            import llama_cpp as _  # noqa: F401
        except ImportError:
            return []
        return [
            ModelInfo(id=name, provider="llama_cpp", name=name, local=True)
            for name, _ in self._all_local_models()
        ]

    def _ensure_loaded(self, model_name: str) -> None:
        """Load the model if not already loaded (or if a different model is requested)."""
        if self._loaded_name == model_name and self._model is not None:
            return

        # Try config first, then disk scan
        entry: LocalModel | None = self._config.get_local_model(model_name)
        model_path_str: str | None = entry.path if entry else None
        if model_path_str is None:
            for name, path in self._all_local_models():
                if name == model_name:
                    model_path_str = str(path)
                    break
        if model_path_str is None:
            raise RuntimeError(
                f"Model '{model_name}' not found. Run: sage pull {model_name}"
            )

        # Patch entry for the rest of this method
        class _Entry:
            path = model_path_str
            threads = entry.threads if entry else None

        entry = _Entry()  # type: ignore[assignment]

        from llama_cpp import Llama

        kwargs: dict = {
            "model_path": entry.path,
            "n_ctx": 16384,
            "n_batch": 1024,
            "verbose": False,
        }
        # Disable GPU on x86_64 macOS (Rosetta) — Metal requires arm64
        if platform.system() == "Darwin" and platform.machine() == "x86_64":
            kwargs["n_gpu_layers"] = 0
        if entry.threads:
            kwargs["n_threads"] = entry.threads

        self._model = Llama(**kwargs)
        self._loaded_name = model_name

    def _to_chat_messages(self, messages: list[Message]) -> list[dict]:
        return [{"role": m.role, "content": m.content} for m in messages]

    def generate(
        self,
        messages: list[Message],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> str:
        name = model or self._first_model()
        self._ensure_loaded(name)
        result = self._model.create_chat_completion(  # type: ignore[union-attr]
            messages=self._to_chat_messages(messages),
            temperature=temperature,
            max_tokens=max_tokens,
            repeat_penalty=1.1,
            top_p=0.9,
            stream=False,
        )
        return result["choices"][0]["message"]["content"]

    def stream(
        self,
        messages: list[Message],
        model: str = "",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> Iterator[str]:
        name = model or self._first_model()
        self._ensure_loaded(name)
        chunks = self._model.create_chat_completion(  # type: ignore[union-attr]
            messages=self._to_chat_messages(messages),
            temperature=temperature,
            max_tokens=max_tokens,
            repeat_penalty=1.1,
            top_p=0.9,
            stream=True,
        )
        for chunk in chunks:
            delta = chunk["choices"][0].get("delta", {})
            text = delta.get("content")
            if text:
                yield text

    def _first_model(self) -> str:
        names = self._config.local_model_names()
        if not names:
            raise RuntimeError(
                "No local models registered. Run: sage config set models.<name>.path /path/to/model.gguf"
            )
        return names[0]
