"""Agno framework integration example with Brizz SDK session tracking."""

import uuid

from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.tools.duckduckgo import DuckDuckGoTools
from dotenv import load_dotenv

from brizz import Brizz, start_session, with_session_id

load_dotenv()

# Initialize SDK - Agno is auto-instrumented via openinference-instrumentation-agno
Brizz.initialize(
    disable_batch=True,
    app_name="agno-example",
)

# Create and configure the agent
agent = Agent(
    name="Stock Market Agent",
    model=OpenAIChat(id="gpt-4o-mini"),
    tools=[DuckDuckGoTools()],
    markdown=True,
    debug_mode=True,
)


# Example 1: Simple session tracking with with_session_id
def run_with_session_id() -> None:
    """Wrap agent call in a session using with_session_id."""
    session_id = uuid.uuid4().hex

    def run_agent(query: str) -> None:
        Brizz.emit_event("agent.query_started", attributes={"query": query})
        agent.print_response(query)
        Brizz.emit_event("agent.query_completed", attributes={"query": query})

    with_session_id(session_id, run_agent, "What is news on the stock market?")


# Example 2: Session tracking using start_session
def run_with_start_session() -> None:
    """Use start_session context manager for session tracking."""
    session_id = uuid.uuid4().hex
    query = "What are the top tech stocks today?"

    with start_session(session_id):
        Brizz.emit_event("agent.query_started", attributes={"query": query})
        response = agent.run(query)
        output = response.content if response and response.content else "No response"

        Brizz.emit_event("agent.query_completed", attributes={"query": query, "success": True})
        print(f"Agent Response: {output}")


if __name__ == "__main__":
    print("--- Example 1: with_session_id ---")
    run_with_session_id()

    print("\n--- Example 2: start_session ---")
    run_with_start_session()
