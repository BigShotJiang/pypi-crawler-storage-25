"""Session context utilities for Brizz SDK."""

import json
from collections.abc import AsyncGenerator, Callable, Generator
from contextlib import asynccontextmanager, contextmanager
from functools import wraps
from typing import Any, Literal, TypeVar, cast

from opentelemetry import context, trace
from opentelemetry.sdk.trace import Span

from brizz._internal.semantic_conventions import (
    BRIZZ,
    PROPERTIES_CONTEXT_KEY,
    SESSION_ID,
    SESSION_INPUT,
    SESSION_OBJECT_CONTEXT_KEY,
    SESSION_OUTPUT,
    SESSION_SPAN_NAME,
    SESSION_TITLE,
    SESSION_TITLE_GENERATION,
    SESSION_TITLE_SPAN_NAME,
)

# Type variable for generic function support
F = TypeVar("F", bound=Callable[..., Any])


class Session:
    """Session object for managing session-level attributes and data.

    Provides methods to set session input/output and custom attributes on the
    associated span.
    """

    def __init__(self, session_id: str, span: Span) -> None:
        """Initialize a Session instance.

        Args:
            session_id: The session identifier
            span: The OpenTelemetry span associated with this session
        """
        self.session_id = session_id
        self._span = span

    def set_input(self, text: str | None) -> None:
        """Append text to session input array attribute.

        Args:
            text: Text to append to session input, or None to append null
        """
        self._append_to_array_attribute(SESSION_INPUT, text)

    def set_output(self, text: str | None) -> None:
        """Append text to session output array attribute.

        Args:
            text: Text to append to session output, or None to append null
        """
        self._append_to_array_attribute(SESSION_OUTPUT, text)

    def set_title(self, title: str) -> None:
        """Set the session title on the span.

        Args:
            title: The generated title string
        """
        self._span.set_attribute(SESSION_TITLE, title)

    def update_properties(self, properties: dict[str, Any] | None = None, **kwargs: Any) -> None:
        """Update custom properties on the session span.

        Properties are set with the 'brizz.' prefix, matching the format
        used by custom_properties.

        Args:
            properties: Optional dictionary of properties to set
            **kwargs: Key-value pairs to set as custom properties

        Examples:
            session.update_properties(success=False)
            session.update_properties({"user_id": "123", "count": 5})
            session.update_properties({"user_id": "123"}, count=5)
        """
        # Merge dictionary and keyword arguments
        all_props = {}
        if properties:
            all_props.update(properties)
        if kwargs:
            all_props.update(kwargs)

        if not all_props:
            return

        # Set each property on the span with brizz. prefix
        for key, value in all_props.items():
            self._span.set_attribute(f"{BRIZZ}.{key}", value)

    def _append_to_array_attribute(self, key: str, value: str | None) -> None:
        """Helper method to append value to an array attribute on the span.

        The array is stored as a JSON string since span attributes don't support
        complex objects/arrays directly.

        Args:
            key: The attribute key
            value: The value to append, or None for null
        """
        # Get current JSON string value (if it exists)
        current_json = None
        if hasattr(self._span, "attributes") and self._span.attributes:
            current_json = self._span.attributes.get(key)

        # Parse existing JSON array or create new array
        if current_json and isinstance(current_json, str):
            try:
                array = json.loads(current_json)
                if not isinstance(array, list):
                    array = [value]
                else:
                    array.append(value)
            except (json.JSONDecodeError, TypeError):
                # If parsing fails, create new array
                array = [value]
        else:
            # Create new array
            array = [value]

        # Serialize array to JSON and set as attribute
        self._span.set_attribute(key, json.dumps(array))


class SessionTitle:
    """Title generation scope for managing session title attributes."""

    def __init__(self, span: Span) -> None:
        self._span = span

    def set_title(self, title: str) -> None:
        """Set the generated title on the wrapper span.

        Args:
            title: The generated title string
        """
        self._span.set_attribute(SESSION_TITLE, title)


def get_active_session() -> Session | None:
    """Get the active session from the current context.

    Returns the Session object if called within a start_session/astart_session
    context, otherwise returns None.
    """
    value = context.get_current().get(SESSION_OBJECT_CONTEXT_KEY)
    return cast(Session | None, value)


def new_context(properties: dict[str, str]) -> context.Context:
    """Create a new OpenTelemetry context with given properties.

    Args:
        properties: Dictionary of properties to add to context

    Returns:
        New OpenTelemetry context with the properties set
    """
    if not properties:
        return context.get_current()

    # Get existing properties and merge with new ones
    current_context = context.get_current()
    existing_properties = cast(dict[str, Any], current_context.get(PROPERTIES_CONTEXT_KEY, {})) or {}
    merged_properties = {**existing_properties, **properties}

    return context.set_value(PROPERTIES_CONTEXT_KEY, merged_properties)


def with_properties(properties: dict[str, str], fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute a function with OpenTelemetry context properties.

    Args:
        properties: Dictionary of properties to add to context
        fn: Function to execute with the properties
        *args: Arguments to pass to the function
        **kwargs: Keyword arguments to pass to the function

    Returns:
        The return value of the function
    """
    if not properties:
        return fn(*args, **kwargs)

    # Get existing properties and merge with new ones
    token = context.attach(new_context(properties))
    try:
        return fn(*args, **kwargs)
    finally:
        context.detach(token)


def with_session_id(session_id: str, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute a function with session context.

    All telemetry (traces, spans, events) generated within the function
    will include the session ID.

    Examples:
        Basic usage with function:
        ```python
        result = with_session_id('session-123', my_function, arg1, arg2)
        ```

        With async function:
        ```python
        result = await with_session_id('session-456', my_async_function)
        ```

        Wrapping AI operations:
        ```python
        async def ai_operation():
            response = await openai.chat.completions.create({
                'model': 'gpt-4',
                'messages': [{'role': 'user', 'content': 'Hello'}]
            })
            emit_event('ai.response', {'tokens': response.usage.total_tokens})
            return response

        response = await with_session_id('chat-session', ai_operation)
        ```

    Args:
        session_id: Session identifier to include in all telemetry
        fn: Function to execute with session context
        *args: Arguments to pass to the function
        **kwargs: Keyword arguments to pass to the function

    Returns:
        The return value of the function
    """
    return with_properties({SESSION_ID: session_id}, fn, *args, **kwargs)


async def awith_properties(properties: dict[str, str], fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute an async function with OpenTelemetry context properties.

    Args:
        properties: Dictionary of properties to add to context
        fn: Async function to execute with the properties
        *args: Arguments to pass to the function
        **kwargs: Keyword arguments to pass to the function

    Returns:
        The return value of the function
    """
    if not properties:
        return await fn(*args, **kwargs)

    # Get existing properties and merge with new ones
    token = context.attach(new_context(properties))
    try:
        return await fn(*args, **kwargs)
    finally:
        context.detach(token)


async def awith_session_id(session_id: str, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute an async function with session context.

    All telemetry (traces, spans, events) generated within the function
    will include the session ID.

    Examples:
        Basic usage with async function:
        ```python
        result = await awith_session_id('session-123', my_async_function, arg1, arg2)
        ```

        Wrapping async AI operations:
        ```python
        async def ai_operation():
            response = await openai.chat.completions.create({
                'model': 'gpt-4',
                'messages': [{'role': 'user', 'content': 'Hello'}]
            })
            emit_event('ai.response', {'tokens': response.usage.total_tokens})
            return response

        response = await awith_session_id('chat-session', ai_operation)
        ```

    Args:
        session_id: Session identifier to include in all telemetry
        fn: Async function to execute with session context
        *args: Arguments to pass to the function
        **kwargs: Keyword arguments to pass to the function

    Returns:
        The return value of the function
    """
    return await awith_properties({SESSION_ID: session_id}, fn, *args, **kwargs)


@contextmanager
def start_session(
    session_id: str,
    properties: dict[str, str] | None = None,
    mode: Literal["default", "title"] | None = None,
) -> Generator[Session]:
    """Context manager for session scope with optional additional properties.

    All telemetry (traces, spans, events) generated within the context
    will include the session ID and any additional properties.

    Args:
        session_id: Session identifier to include in all telemetry
        properties: Optional additional properties to include
        mode: Session mode. Use "title" to mark all child spans as title
            generation (excluded from conversation view). Use session.set_title()
            to set the title value. Defaults to "default".

    Yields:
        Session: Session object for managing session-level attributes

    Examples:
        Basic usage:
        ```python
        with start_session('session-123') as session:
            session.set_input("user input")
            session.set_output("generated output")
        ```

        Title mode (spans excluded from conversation):
        ```python
        with start_session('session-123', mode='title') as session:
            title = llm.generate_title(conversation)
            session.set_title(title)
        ```
    """
    is_title = mode == "title"

    all_properties: dict[str, str] = {SESSION_ID: session_id}
    if is_title:
        all_properties[SESSION_TITLE_GENERATION] = "true"
    if properties:
        all_properties.update(properties)

    span_name = SESSION_TITLE_SPAN_NAME if is_title else SESSION_SPAN_NAME

    # Use custom_properties to manage context
    with custom_properties(all_properties):
        # Create a span for this session
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span(span_name) as span:
            session = Session(session_id, cast(Span, span))
            # Explicitly set SESSION_ID on the span for exporters
            span.set_attribute(f"{BRIZZ}.{SESSION_ID}", session_id)
            # Store session in context for get_active_session()
            token = context.attach(context.set_value(SESSION_OBJECT_CONTEXT_KEY, session))
            try:
                yield session
            finally:
                context.detach(token)


@contextmanager
def custom_properties(properties: dict[str, str]) -> Generator[None]:
    """Context manager for custom property scope.

    All telemetry (traces, spans, events) generated within the context
    will include the specified properties.

    Args:
        properties: Dictionary of properties to add to context

    Yields:
        None

    Examples:
        Basic usage:
        ```python
        with custom_properties({'user_id': 'user-123', 'region': 'us-west'}):
            # All telemetry here includes user_id and region
            emit_event('api.request', {'endpoint': '/users'})
        ```

        Nested usage:
        ```python
        with custom_properties({'tenant_id': 'tenant-1'}):
            with custom_properties({'request_id': 'req-456'}):
                # Both tenant_id and request_id are available
                emit_event('data.access')
        ```

        With OpenAI:
        ```python
        with custom_properties({'user_id': '123', 'experiment': 'variant-a'}):
            response = openai.chat.completions.create(
                model='gpt-4',
                messages=[{'role': 'user', 'content': 'Hello'}]
            )
        ```
    """
    if not properties:
        yield
        return

    token = context.attach(new_context(properties))
    try:
        yield
    finally:
        context.detach(token)


@contextmanager
def start_session_title(session_id: str | None = None) -> Generator[SessionTitle]:
    """Context manager for session title generation scope.

    All LLM/AI spans created within this context will be marked as
    title generation spans and excluded from the conversation view.

    Args:
        session_id: Optional session ID to associate with. Required when
            used outside of a start_session context.

    Yields:
        SessionTitle: Object to set the generated title value.

    Examples:
        Inside start_session (session_id inherited from context):
        ```python
        with start_session('session-123') as session:
            with start_session_title() as title:
                title.set_title(llm.generate_title(conversation))
        ```

        Outside start_session (session_id required):
        ```python
        with start_session_title(session_id='session-123') as title:
            title.set_title(llm.generate_title(conversation))
        ```
    """
    active = get_active_session()
    resolved_session_id = session_id or (active.session_id if active else None)

    props: dict[str, str] = {SESSION_TITLE_GENERATION: "true"}
    if resolved_session_id is not None:
        props[SESSION_ID] = resolved_session_id
    with custom_properties(props):
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span(SESSION_TITLE_SPAN_NAME) as span:
            if resolved_session_id is not None:
                span.set_attribute(f"{BRIZZ}.{SESSION_ID}", resolved_session_id)
            yield SessionTitle(cast(Span, span))


@asynccontextmanager
async def astart_session_title(session_id: str | None = None) -> AsyncGenerator[SessionTitle]:
    """Async context manager for session title generation scope.

    All LLM/AI spans created within this context will be marked as
    title generation spans and excluded from the conversation view.

    Args:
        session_id: Optional session ID to associate with. Required when
            used outside of an astart_session context.

    Yields:
        SessionTitle: Object to set the generated title value.

    Examples:
        ```python
        async with astart_session_title(session_id='session-123') as title:
            title.set_title(await llm.generate_title(conversation))
        ```
    """
    active = get_active_session()
    resolved_session_id = session_id or (active.session_id if active else None)

    props: dict[str, str] = {SESSION_TITLE_GENERATION: "true"}
    if resolved_session_id is not None:
        props[SESSION_ID] = resolved_session_id
    async with acustom_properties(props):
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span(SESSION_TITLE_SPAN_NAME) as span:
            if resolved_session_id is not None:
                span.set_attribute(f"{BRIZZ}.{SESSION_ID}", resolved_session_id)
            yield SessionTitle(cast(Span, span))


@asynccontextmanager
async def astart_session(
    session_id: str,
    properties: dict[str, str] | None = None,
    mode: Literal["default", "title"] | None = None,
) -> AsyncGenerator[Session]:
    """Async context manager for session scope with optional additional properties.

    All telemetry (traces, spans, events) generated within the context
    will include the session ID and any additional properties.

    Args:
        session_id: Session identifier to include in all telemetry
        properties: Optional additional properties to include
        mode: Session mode. Use "title" to mark all child spans as title
            generation (excluded from conversation view). Use session.set_title()
            to set the title value. Defaults to "default".

    Yields:
        Session: Session object for managing session-level attributes

    Examples:
        Basic usage:
        ```python
        async with astart_session('session-123') as session:
            session.set_input("user input")
            session.set_output("generated output")
        ```

        Title mode:
        ```python
        async with astart_session('session-123', mode='title') as session:
            title = await llm.generate_title(conversation)
            session.set_title(title)
        ```
    """
    is_title = mode == "title"

    all_properties: dict[str, str] = {SESSION_ID: session_id}
    if is_title:
        all_properties[SESSION_TITLE_GENERATION] = "true"
    if properties:
        all_properties.update(properties)

    span_name = SESSION_TITLE_SPAN_NAME if is_title else SESSION_SPAN_NAME

    # Use acustom_properties to manage context
    async with acustom_properties(all_properties):
        # Create a span for this session
        tracer = trace.get_tracer(__name__)
        with tracer.start_as_current_span(span_name) as span:
            session = Session(session_id, cast(Span, span))
            # Explicitly set SESSION_ID on the span for exporters
            span.set_attribute(f"{BRIZZ}.{SESSION_ID}", session_id)
            # Store session in context for get_active_session()
            token = context.attach(context.set_value(SESSION_OBJECT_CONTEXT_KEY, session))
            try:
                yield session
            finally:
                context.detach(token)


@asynccontextmanager
async def acustom_properties(properties: dict[str, str]) -> AsyncGenerator[None]:
    """Async context manager for custom property scope.

    All telemetry (traces, spans, events) generated within the context
    will include the specified properties.

    Args:
        properties: Dictionary of properties to add to context

    Yields:
        None

    Examples:
        Basic usage:
        ```python
        async with acustom_properties({'user_id': 'user-123', 'region': 'us-west'}):
            # All telemetry here includes user_id and region
            await async_operation()
        ```

        With async OpenAI:
        ```python
        async with acustom_properties({'user_id': '123', 'experiment': 'variant-a'}):
            response = await openai.chat.completions.create(
                model='gpt-4',
                messages=[{'role': 'user', 'content': 'Hello'}]
            )
        ```
    """
    if not properties:
        yield
        return

    token = context.attach(new_context(properties))
    try:
        yield
    finally:
        context.detach(token)


def session_context(session_id: str) -> Callable[[F], F]:
    """Decorator to add session context to a function.

    Args:
        session_id: Session identifier to include in all telemetry

    Returns:
        Decorator function

    Examples:
        ```python
        @session_context('my-session')
        def my_function():
            # All telemetry here will include session_id
            pass
        ```
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return with_session_id(session_id, func, *args, **kwargs)

        return wrapper  # type: ignore

    return decorator


def asession_context(session_id: str) -> Callable[[F], F]:
    """Async decorator to add session context to an async function.

    Args:
        session_id: Session identifier to include in all telemetry

    Returns:
        Decorator function

    Examples:
        ```python
        @asession_context('my-async-session')
        async def my_async_function():
            # All telemetry here will include session_id
            pass
        ```
    """

    def decorator(func: F) -> F:
        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await awith_session_id(session_id, func, *args, **kwargs)

        return async_wrapper  # type: ignore

    return decorator
