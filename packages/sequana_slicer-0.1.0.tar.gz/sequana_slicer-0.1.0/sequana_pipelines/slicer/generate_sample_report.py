import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

import re
from sequana.fasta import FastA

def parse_clstr(clstr_file, fasta_file):
    fasta_seqs = {}
    try:
        with open(fasta_file, "r") as f:
            name = None
            seq_acc = []
            for line in f:
                if line.startswith(">"):
                    if name:
                        fasta_seqs[name] = "".join(seq_acc)
                    name = line.strip()[1:].split()[0]
                    seq_acc = []
                else:
                    seq_acc.append(line.strip())
            if name:
                fasta_seqs[name] = "".join(seq_acc)
    except Exception as e:
        print(f"Error reading FASTA: {e}")

    clusters = []
    current_cluster = None
    size = 0
    rep_seq = ""
    try:
        with open(clstr_file, "r") as f:
            for line in f:
                if line.startswith(">Cluster"):
                    if current_cluster is not None:
                        clusters.append({"Cluster": current_cluster, "Size": size, "Sequence": rep_seq})
                    # Use standard numbering instead of 'Cluster 0'
                    current_cluster = f"Cluster {len(clusters) + 1}"
                    size = 0
                    rep_seq = ""
                elif line.strip():
                    size += 1
                    if line.strip().endswith("*"):
                        if ">" in line and "..." in line:
                            seq_name = line.split(">")[1].split("...")[0].strip()
                            rep_seq = fasta_seqs.get(seq_name, seq_name)
        if current_cluster is not None:
            clusters.append({"Cluster": current_cluster, "Size": size, "Sequence": rep_seq})
    except Exception as e:
        print(f"Error reading cluster file: {e}")
    
    if not clusters:
        return pd.DataFrame(columns=["Cluster", "Size", "Percentage", "Sequence"])
        
    df = pd.DataFrame(clusters)
    total_size = df["Size"].sum()
    df["Percentage"] = (df["Size"] / total_size * 100).round(2).astype(str) + " %"
    return df.sort_values(by="Size", ascending=False)[["Cluster", "Size", "Percentage", "Sequence"]]

if __name__ == "__main__":
    if len(sys.argv) != 6:
        print("Usage: generate_sample_report.py <sample> <csv_file> <clstr_file> <fasta_file> <output_html>")
        sys.exit(1)

    sample = sys.argv[1]
    csv_file = sys.argv[2]
    clstr_file = sys.argv[3]
    fasta_file = sys.argv[4]
    output_html = sys.argv[5]

    # Load stats
    df_stats = pd.DataFrame()
    try:
        if os.path.exists(csv_file):
            df_stats = pd.read_csv(csv_file)
    except Exception:
        pass

    # Parse clusters
    df_clusters = parse_clstr(clstr_file, fasta_file)
    
    # Generate HTML
    html_content = f"""
    <html>
    <head>
        <title>Slicer Report - {sample}</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; color: #333; }}
            h1, h2, h3 {{ color: #2c3e50; }}
            .table {{ width: 100%; border-collapse: collapse; margin-bottom: 20px; }}
            .table th, .table td {{ border: 1px solid #ddd; padding: 8px; text-align: center; }}
            .table th {{ background-color: #f2f2f2; }}
            .container {{ max-width: 1000px; margin: auto; }}
        </style>
    </head>
    <body>
    <div class="container">
        <h1>Detailed Report for Sample: {sample}</h1>
        <hr>
    """

    # Add general stats block if available
    if not df_stats.empty:
        summary_stats = df_stats.drop_duplicates(subset=["Sample"]).drop(columns=["Length", "Side"], errors="ignore")
        html_content += "<h2>Filtering Statistics</h2>"
        html_content += summary_stats.to_html(classes="table", index=False)

    # Fragment length distribution plot
    if not df_stats.empty and "Length" in df_stats.columns and df_stats["Length"].sum() > 0:
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.histplot(data=df_stats, x="Length", hue="Side", multiple="dodge", palette={"5'": "red", "3'": "steelblue"}, bins=30, ax=ax, edgecolor="white")
        ax.set_xlabel("Soft-clip Length (bp)")
        ax.set_ylabel("Count")
        ax.set_title(f"Soft-clip Length Distribution — {sample}")
        plt.tight_layout()

        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight")
        buf.seek(0)
        img_b64 = base64.b64encode(buf.read()).decode("utf-8")
        plt.close(fig)

        html_content += "<h2>Soft-clip Length Distribution</h2>"
        html_content += f'<img src="data:image/png;base64,{img_b64}" alt="Soft-clip Length Distribution" style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 4px;" />'

    html_content += "<h2>CD-HIT-EST Soft-Clip Clusters</h2>"
    if not df_clusters.empty and df_clusters["Size"].sum() > 0:
        html_content += f"<p>Total clusters identified: <b>{len(df_clusters)}</b></p>"
        
        # Plot top 20 clusters
        top_n = min(20, len(df_clusters))
        df_top = df_clusters.head(top_n)

        fig, ax = plt.subplots(figsize=(10, 6))
        sns.barplot(data=df_top, x="Cluster", y="Size", ax=ax, palette="viridis")
        ax.set_title(f"Top {top_n} Largest Sequence Clusters")
        ax.set_ylabel("Number of Sequences")
        ax.set_xlabel("Cluster ID")
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()

        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight")
        buf.seek(0)
        img_b64 = base64.b64encode(buf.read()).decode("utf-8")
        plt.close(fig)

        html_content += f'<img src="data:image/png;base64,{img_b64}" alt="Cluster Sizes Plot" style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 4px;" />'

        # Add sequence table
        html_content += "<h3>Top Cluster Sequences Table</h3>"
        html_content += df_top.to_html(classes="table table-striped", index=False)
    else:
        html_content += "<p><i>No clusters found for this sample.</i></p>"

    html_content += f"""
        <h2>Alignments</h2>
        <p>The MAFFT alignment of the clusters is available here: <a href="../{sample}/cdhit/cluster.aln">cluster.aln</a></p>
        <br><br>
        <a href="../summary.html" style="text-decoration: none; padding: 10px 15px; background: #2c3e50; color: white; border-radius: 4px;">&larr; Back to Main Summary</a>
    </div>
    </body>
    </html>
    """

    # Write output
    os.makedirs(os.path.dirname(output_html), exist_ok=True)
    with open(output_html, "w") as f:
        f.write(html_content)
