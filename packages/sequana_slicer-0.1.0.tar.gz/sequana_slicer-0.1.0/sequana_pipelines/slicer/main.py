#
#  This file is part of Sequana software
#
#  Copyright (c) 2016-2021 - Sequana Dev Team (https://sequana.readthedocs.io)
#
#  Distributed under the terms of the 3-clause BSD license.
#  The full license is in the LICENSE file, distributed with this software.
#
#  Website:       https://github.com/sequana/sequana
#  Documentation: http://sequana.readthedocs.io
#  Contributors:  https://github.com/sequana/sequana/graphs/contributors
##############################################################################
import os

import rich_click as click
from sequana_pipetools import SequanaManager
from sequana_pipetools.options import *


NAME = "slicer"

help = init_click(NAME, groups={
    "Pipeline Specific": [
        "--pattern", "--mismatches", "--min-softclip", 
        "--max-softclip", "--cdhit-threshold", "--cdhit-word-size",
        "--filter-secondary-alignments", "--minimap2-preset", "--reference"],
        }
)



@click.command(context_settings=help)
@include_options_from(ClickSnakemakeOptions, working_directory=NAME)
@include_options_from(ClickSlurmOptions)
@include_options_from(ClickInputOptions, add_input_readtag=False)
@include_options_from(ClickGeneralOptions)
@click.option(
    "--pattern",
    "pattern",
    default="TCAGTTTCTGTA",
    type=click.STRING,
    show_default=True,
    help="Target sequence pattern to filter for (e.g. splice leader).",
)
@click.option(
    "--mismatches",
    "mismatches",
    default=2,
    type=click.INT,
    show_default=True,
    help="Number of mismatches allowed for sequence filtering.",
)
@click.option(
    "--min-softclip",
    "min_softclip",
    default=20,
    type=click.INT,
    show_default=True,
    help="Minimum softclipping length filter.",
)
@click.option(
    "--max-softclip",
    "max_softclip",
    default=100,
    type=click.INT,
    show_default=True,
    help="Maximum softclipping length filter.",
)
@click.option(
    "--cdhit-threshold",
    "cdhit_threshold",
    default=0.9,
    type=click.FLOAT,
    show_default=True,
    help="Sequence identity threshold for cd-hit-est.",
)
@click.option(
    "--cdhit-word-size",
    "cdhit_word_size",
    default=5,
    type=click.INT,
    show_default=True,
    help="Word size for cd-hit-est (shorter words for shorter sequences).",
)
@click.option(
    "--filter-secondary-alignments/--no-filter-secondary-alignments",
    "filter_secondary_alignments",
    default=True,
    show_default=True,
    help="Filter out secondary alignments (-F 256) during extraction.",
)
@click.option(
    "--minimap2-preset",
    "minimap2_preset",
    default="map-pb",
    type=click.Choice(["map-pb", "map-hifi", "map-ont"], case_sensitive=True),
    show_default=True,
    help="Minimap2 mapping preset. Use map-pb for PacBio CLR, map-hifi for PacBio HiFi/CCS, map-ont for Oxford Nanopore.",
)
@click.option(
    "--reference-file",
    "reference",
    required=True,
    type=click.Path(exists=True, file_okay=True, dir_okay=False),
    help="Reference genome FASTA file.",
)
def main(**options):


    # the real stuff is here
    manager = SequanaManager(options, NAME)
    options = manager.options

    # creates the working directory
    manager.setup()

    # Fill the config file with data and specific options
    cfg = manager.config.config
    cfg.input_pattern = options.input_pattern
    cfg.input_directory = os.path.abspath(options.input_directory)
    
    cfg.slicer.pattern = options.pattern
    cfg.slicer.mismatches = options.mismatches
    cfg.slicer.min_softclip = options.min_softclip
    cfg.slicer.max_softclip = options.max_softclip
    cfg.slicer.cdhit_threshold = options.cdhit_threshold
    cfg.slicer.cdhit_word_size = options.cdhit_word_size
    cfg.slicer.filter_secondary_alignments = options.filter_secondary_alignments
    cfg.slicer.minimap2_preset = options.minimap2_preset
    cfg.slicer.reference = os.path.abspath(options.reference)

    manager.exists(cfg.input_directory)

    # finalise the command and save it; copy the snakemake. update the config
    # file and save it.
    manager.teardown()


if __name__ == "__main__":
    main()
