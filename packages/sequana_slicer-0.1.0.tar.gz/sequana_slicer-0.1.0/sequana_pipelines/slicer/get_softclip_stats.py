import pysam
import sys
import pandas as pd

assert len(sys.argv) == 6
sample = sys.argv[1]
bam_sorted = sys.argv[2]
bam_filtered = sys.argv[3]
# fasta_clips = sys.argv[4] (no longer used for lengths but still passed via args)
output_csv = sys.argv[5]

pre_filter = 0
post_filter = 0

try:
    with pysam.AlignmentFile(bam_sorted, "rb") as sam:
        pre_filter = sam.mapped
    with pysam.AlignmentFile(bam_filtered, "rb") as sam:
        post_filter = sam.mapped
except Exception as e:
    print(f"Error reading BAM files: {e}", file=sys.stderr)

data = []

try:
    with pysam.AlignmentFile(bam_filtered, "rb") as sam:
        for read in sam.fetch():
            if read.is_secondary or read.is_supplementary:
                continue

            cig = read.cigartuples
            if not cig:
                continue

            # Length of left and right soft-clips
            left_len = cig[0][1] if cig[0][0] == 4 else 0
            right_len = cig[-1][1] if cig[-1][0] == 4 else 0

            # Determine true 5' and 3' based on mapped strand
            size_5p = left_len if not read.is_reverse else right_len
            size_3p = right_len if not read.is_reverse else left_len

            if size_5p > 0:
                data.append({"Length": size_5p, "Side": "5'"})
            if size_3p > 0:
                data.append({"Length": size_3p, "Side": "3'"})
except Exception as e:
    print(f"Error reading filtered BAM: {e}", file=sys.stderr)

# Calculate passing filter
pass_pct = round((post_filter / pre_filter * 100) if pre_filter > 0 else 0, 2)

if data:
    df = pd.DataFrame(data)
    df["Sample"] = sample
    df["Mapped Reads (Initial)"] = pre_filter
    df["Clipped Reads (Filtered)"] = post_filter
    df["Passing Filter (%)"] = pass_pct
else:
    # Empty DataFrame fallback
    df = pd.DataFrame({
        "Sample": [sample],
        "Mapped Reads (Initial)": [pre_filter],
        "Clipped Reads (Filtered)": [post_filter],
        "Passing Filter (%)": [pass_pct],
        "Length": [0],
        "Side": ["5'"]
    })

# Reorder columns natively to preserve logic
df = df[["Sample", "Mapped Reads (Initial)", "Clipped Reads (Filtered)", "Passing Filter (%)", "Length", "Side"]]
df.to_csv(output_csv, index=False)
