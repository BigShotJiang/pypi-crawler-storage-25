import pysam
import sys
from sequana import reverse_complement


assert len(sys.argv) == 4
bam = pysam.AlignmentFile(sys.argv[1])

motif_fwd = sys.argv[3]
motif_rev = reverse_complement(motif_fwd)

with open(sys.argv[2], "w") as fout:
    for read in bam.fetch():

        if read.is_secondary or read.is_supplementary:
            continue

        cig = read.cigartuples
        if not cig:
            continue

        seq = read.query_sequence

        if not read.is_reverse:
            # Forward mapped -> true 5' end is on the left
            if cig[0][0] == 4:  # left soft clip
                left = seq[:cig[0][1]]
                if motif_fwd in left:
                    fout.write(f">{read.query_name}_L_fwd\n{left}\n")
        else:
            # Reverse mapped -> true 5' end is on the right
            if cig[-1][0] == 4:  # right soft clip
                right = seq[-cig[-1][1]:]
                if motif_rev in right:
                    # Reverse complement to bring sequence back to standardized forward orientation
                    right_fwd = reverse_complement(right)
                    fout.write(f">{read.query_name}_R_rev\n{right_fwd}\n")
