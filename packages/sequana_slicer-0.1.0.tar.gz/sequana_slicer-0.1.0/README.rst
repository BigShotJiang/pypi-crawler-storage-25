
.. image:: https://raw.githubusercontent.com/sequana/slicer/main/doc/slicer_logo.png

.. image:: https://badge.fury.io/py/sequana-slicer.svg
     :target: https://pypi.python.org/pypi/sequana_slicer

.. image:: http://joss.theoj.org/papers/10.21105/joss.00352/status.svg
    :target: http://joss.theoj.org/papers/10.21105/joss.00352
    :alt: JOSS (journal of open source software) DOI

.. image:: https://github.com/sequana/slicer/actions/workflows/main.yml/badge.svg
   :target: https://github.com/sequana/slicer/actions/workflows/main.yml

.. image:: https://img.shields.io/badge/python-3.11%20%7C%203.12-blue.svg
    :target: https://pypi.python.org/pypi/sequana_slicer
    :alt: Python 3.11 | 3.12



This is the **slicer** pipeline from the `Sequana <https://sequana.readthedocs.org>`_ project

:Overview: Detects splice leader sequences from long-read (PacBio) data using motif-based read filtering, soft-clip analysis, sequence clustering, and multiple sequence alignment.
:Input: Long-read FASTQ files (PacBio) and a reference genome FASTA file.
:Output: Clustered and aligned soft-clipped sequences (FASTA), per-sample HTML reports, and a merged CSV statistics file.
:Status: beta
:Citation: Cokelaer et al, (2017), ‘Sequana’: a Set of Snakemake NGS pipelines, Journal of Open Source Software, 2(16), 352, JOSS DOI doi:10.21105/joss.00352


Installation
~~~~~~~~~~~~

sequana_slicer is based on Python3, just install the package as follows::

    pip install sequana_slicer --upgrade

You will need third-party tools. Please see below for details.

Usage
~~~~~

::

    sequana_slicer --help
    sequana_slicer --input-directory DATAPATH --reference-file reference.fasta

This creates a directory with the pipeline and configuration file. You will then need 
to execute the pipeline::

    cd slicer
    sh slicer.sh  # for a local run

This launch a snakemake pipeline. If you are familiar with snakemake, you can 
retrieve the pipeline itself and its configuration files and then execute the pipeline yourself with specific parameters::

    snakemake -s slicer.rules -c config.yaml --cores 4 --stats stats.txt

Or use `sequanix <https://sequana.readthedocs.io/en/main/sequanix.html>`_ interface.


Usage with apptainer / singularity
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

With Apptainer, initiate the working directory as follows::

    sequana_slicer --input-directory DATAPATH --reference-file reference.fasta \
        --apptainer-prefix ~/.sequana/apptainers

Images are downloaded in the working directory but you can store them in a shared directory
to avoid re-downloading them (recommended for repeated use)::

    sequana_slicer --input-directory DATAPATH --reference-file reference.fasta \
        --apptainer-prefix ~/.sequana/apptainers

and then::

    cd slicer
    sh slicer.sh

if you decide to use snakemake manually, do not forget to add apptainer options::

    snakemake -s slicer.rules -c config.yaml --cores 4 --stats stats.txt \
        --apptainer-prefix ~/.sequana/apptainers \
        --apptainer-args "-B /home:/home"

By default, the home is already set for you. Additional binding path can be set using environment variables e.g.::

    export APPTAINER_BINDPATH=" -B /pasteur"

Requirements
~~~~~~~~~~~~

This pipelines requires the following executable(s):

- seqkit
- minimap2
- samtools
- cd-hit-est
- mafft
- graphviz

These tools are available as Apptainer/Singularity containers (see config.yaml for container URLs).

.. image:: https://raw.githubusercontent.com/sequana/slicer/main/sequana_pipelines/slicer/dag.png


Details
~~~~~~~~~

This pipeline runs **slicer** in parallel on the input fastq files (paired or not). 
A brief sequana summary report is also produced.


Rules and configuration details
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Here is the `latest documented configuration file <https://raw.githubusercontent.com/sequana/slicer/main/sequana_pipelines/slicer/config.yaml>`_
to be used with the pipeline. Each rule used in the pipeline may have a section in the configuration file. 

Changelog
~~~~~~~~~

========= ====================================================================
Version   Description
========= ====================================================================
0.0.1     **First release.**
========= ====================================================================


Contribute & Code of Conduct
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To contribute to this project, please take a look at the 
`Contributing Guidelines <https://github.com/sequana/sequana/blob/main/CONTRIBUTING.rst>`_ first. Please note that this project is released with a 
`Code of Conduct <https://github.com/sequana/sequana/blob/main/CONDUCT.md>`_. By contributing to this project, you agree to abide by its terms.

