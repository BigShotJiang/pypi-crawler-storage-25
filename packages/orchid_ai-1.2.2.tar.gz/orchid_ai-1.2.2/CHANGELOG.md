# CHANGELOG

<!-- version list -->

## v1.2.2 (2026-04-13)

### Bug Fixes

- Coversation context optimization.
  ([`5dfbe5f`](https://github.com/gadz82/orchid/commit/5dfbe5f2f13c86cf39090d926c8b904c6b00dc29))


## v1.2.1 (2026-04-13)

### Bug Fixes

- Removing external dependencies and improving error handling and final outcome for the user.
  ([`8408fe2`](https://github.com/gadz82/orchid/commit/8408fe2bed57698650da3a5a4d68897250447277))


## v1.2.0 (2026-04-13)

### Features

- Orchid version bump
  ([`66dea75`](https://github.com/gadz82/orchid/commit/66dea75623a1898b761b81b1b870ddc28b3ff2a4))


## v1.0.0 (2026-04-13)

- Initial Release

## v1.1.1 (2026-04-10)

### Bug Fixes

- Remove useless Dockerfiles for orchid and orchid-api
  ([`19476b4`](https://github.com/gadz82/orchid/commit/19476b4882ce36ef231353da0c570340dfb4f6b7))


## v1.1.0 (2026-04-10)

### Bug Fixes

- Update import paths and ensure version consistency after package rename to `orchid_ai`
  ([`f6838fe`](https://github.com/gadz82/orchid/commit/f6838fe87a7757950252b30f90fdc819d904d4c6))

- **core**: Rename package root dir.
  ([`c115975`](https://github.com/gadz82/orchid/commit/c11597518f393b16973f5775ddb7d4fd319a7a28))

### Features

- Update package name from `orchid` to `orchid-ai` and adjust versioning consistency
  ([`1156c4a`](https://github.com/gadz82/orchid/commit/1156c4a28334e265592cd217cb585fcbc7d9f7d9))


## v1.0.0 (2026-04-10)

- Initial Release
