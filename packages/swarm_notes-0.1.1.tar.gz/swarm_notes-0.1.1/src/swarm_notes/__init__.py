"""research-cruise agent package."""
