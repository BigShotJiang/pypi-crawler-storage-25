"""Tests for blindference_node.job_handler."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from eth_account import Account

from blindference_node.config import Config
from blindference_node.crypto import CoFHEClient
from blindference_node.icl_client import ICLClient


class _TestCoFHEClient(CoFHEClient):
    """Minimal test double for CoFHE interface."""

    def __init__(self, fixed_key: bytes | None = None) -> None:
        self._key = fixed_key or b"\x01" * 32
        self._counter = 0

    def decrypt(self, ct_handle: int) -> int:
        return int.from_bytes(self._key[:16], "big")

    def encrypt(self, value: int) -> int:
        self._counter += 1
        return 0xDEAD0000 + self._counter
from blindference_node.ipfs_client import IPFSClient
from blindference_node.job_handler import handle_job


@pytest.fixture
def wallet():
    return Account.from_key(
        bytes.fromhex(
            "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
        )
    )


@pytest.fixture
def config():
    return Config(
        node_address="0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
        icl_endpoint="http://localhost:9999",
        ipfs_gateway="https://node.lighthouse.storage",
        tier=0,
        supported_model_ids=["qwen2.5-7b"],
    )


@pytest.fixture
def w3():
    w3 = MagicMock()
    w3.eth.get_transaction_count.return_value = 5
    w3.eth.gas_price = 20_000_000_000
    return w3


@pytest.fixture
def cofhe():
    return _TestCoFHEClient(fixed_key=b"\x01" * 32)


@pytest.fixture
def assignment_leader():
    return {
        "jobId": "0xjob-leader",
        "role": "leader",
        "modelId": "qwen2.5-7b",
        "promptCid": "QmPrompt123",
        "deadline": 9999999999,
        "insuranceOptIn": False,
        "userAddress": "0xabC1230000000000000000000000000000000001",
        "kpHighHandle": 0xDEAD0001,
        "kpLowHandle": 0xDEAD0002,
    }


@pytest.fixture
def assignment_verifier():
    return {
        "jobId": "0xjob-verifier",
        "role": "verifier",
        "modelId": "qwen2.5-7b",
        "promptCid": "QmPrompt456",
        "deadline": 9999999999,
        "insuranceOptIn": False,
        "kpHighHandle": 0xDEAD0001,
        "kpLowHandle": 0xDEAD0002,
    }


# ==================================================================
# Leader flow
# ==================================================================


@pytest.mark.asyncio
async def test_handle_job_leader_full_flow(
    config, wallet, w3, cofhe, assignment_leader
):
    """Leader executes full sequence and submits result."""
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    # Mock ICL endpoints
    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})), \
         patch.object(ICLClient, "submit_result", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})) as mock_submit:

        # Mock IPFS download to return an encrypted prompt blob
        # Create a valid encrypted blob to avoid decryption failure
        from blindference_node.crypto import encrypt_output_blob
        test_prompt = "What is the capital of France?"
        test_blob = encrypt_output_blob(test_prompt, b"\x01" * 32)

        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)), \
             patch.object(IPFSClient, "upload", AsyncMock(return_value="QmOutput789")):

            await handle_job(
                assignment_leader, config, wallet, w3, icl, ipfs, cofhe
            )

            mock_submit.assert_called_once()
            call_args = mock_submit.call_args
            assert call_args[0][0] == "0xjob-leader"
            assert call_args[0][1] == "QmOutput789"  # output_cid
            assert len(call_args[0][2]) == 32  # commitment


# ==================================================================
# Verifier flow
# ==================================================================


@pytest.mark.asyncio
async def test_handle_job_verifier_full_flow(
    config, wallet, w3, cofhe, assignment_verifier
):
    """Verifier executes full sequence and submits verification."""
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})), \
         patch.object(ICLClient, "get_job_status", AsyncMock(return_value={"outputCid": "QmOutputABC"})), \
         patch.object(ICLClient, "submit_verification", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})) as mock_verify:

        from blindference_node.crypto import encrypt_output_blob
        test_blob = encrypt_output_blob("Test prompt", b"\x01" * 32)

        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)):

            await handle_job(
                assignment_verifier, config, wallet, w3, icl, ipfs, cofhe
            )

            mock_verify.assert_called_once()
            call_args = mock_verify.call_args
            assert call_args[0][0] == "0xjob-verifier"
            assert call_args[0][2] == "CONFIRM"  # verdict
            assert call_args[0][3] == 100  # confidence
            assert len(call_args[0][1]) == 32  # commitment


# ==================================================================
# Error recovery
# ==================================================================


@pytest.mark.asyncio
async def test_handle_job_ipfs_download_failure(
    config, wallet, w3, cofhe, assignment_leader
):
    """Job handler does not crash when IPFS download fails."""
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})), \
         patch.object(IPFSClient, "download", AsyncMock(side_effect=RuntimeError("IPFS down"))), \
         patch.object(ICLClient, "submit_result", AsyncMock()) as mock_submit:

        # Should not raise
        await handle_job(
            assignment_leader, config, wallet, w3, icl, ipfs, cofhe
        )
        # Submit should NOT be called because download failed
        mock_submit.assert_not_called()


@pytest.mark.asyncio
async def test_handle_job_icl_claim_failure_continues(
    config, wallet, w3, cofhe, assignment_leader
):
    """Claim failure is logged but job continues."""
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    with patch.object(ICLClient, "claim_task", AsyncMock(side_effect=RuntimeError("claim failed"))), \
         patch.object(ICLClient, "submit_result", AsyncMock()) as mock_submit:

        result = await handle_job(
            assignment_leader, config, wallet, w3, icl, ipfs, cofhe
        )
        # Without claim, key handles are missing — job aborts, submit_result not called
        assert result is None
        mock_submit.assert_not_called()


@pytest.mark.asyncio
async def test_handle_job_leader_zero_user_address(
    config, wallet, w3, cofhe
):
    """Zero-address userAddress logs warning but continues."""
    assignment = {
        "jobId": "0xjob-zero-user",
        "role": "leader",
        "modelId": "qwen2.5-7b",
        "promptCid": "QmTest",
        "deadline": 9999999999,
        "insuranceOptIn": False,
        # no userAddress → defaults to zero
    }
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})), \
         patch.object(ICLClient, "submit_result", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})) as mock_submit:

        from blindference_node.crypto import encrypt_output_blob
        test_blob = encrypt_output_blob("test", b"\x01" * 32)

        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)), \
             patch.object(IPFSClient, "upload", AsyncMock(return_value="QmOk")):

            await handle_job(assignment, config, wallet, w3, icl, ipfs, cofhe)
            mock_submit.assert_called_once()


# ==================================================================
# Verifier flow (Phase 3)
# ==================================================================


@pytest.mark.asyncio
async def test_handle_job_verifier_polls_leader_cid(
    config, wallet, w3, cofhe, assignment_verifier
):
    """Verifier polls get_job_status for leader CID and submits verification."""
    icl = ICLClient(config.icl_endpoint, wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    leader_cid = "QmLeaderOutput"

    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})),          patch.object(ICLClient, "get_job_status", AsyncMock(return_value={"outputCid": leader_cid})),          patch.object(ICLClient, "submit_verification", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})) as mock_verify:

        from blindference_node.crypto import encrypt_output_blob
        test_blob = encrypt_output_blob("Test prompt", b"\x01" * 32)

        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)):
            await handle_job(
                assignment_verifier, config, wallet, w3, icl, ipfs, cofhe
            )

        mock_verify.assert_called_once()
        call_args = mock_verify.call_args
        assert call_args[0][0] == "0xjob-verifier"
        assert call_args[0][2] == "CONFIRM"
        assert len(call_args[0][1]) == 32  # commitment


@pytest.mark.asyncio
async def test_leader_verifier_commitment_match(config, wallet, w3, cofhe):
    """Leader and verifier produce the same commitment for identical prompt + model."""
    icl_leader = ICLClient(config.icl_endpoint + "/leader", wallet)
    icl_verifier = ICLClient(config.icl_endpoint + "/verifier", wallet)
    ipfs = IPFSClient(config.ipfs_gateway)

    test_prompt = "What is the speed of light?"
    test_blob = __import__("blindference_node.crypto", fromlist=["encrypt_output_blob"]).encrypt_output_blob(test_prompt, b"\x01" * 32)

    leader_c = None
    verifier_c = None

    leader_assignment = {
        "jobId": "0xmatch-leader",
        "role": "leader",
        "modelId": "qwen2.5-7b",
        "promptCid": "QmMatchPrompt",
        "deadline": 9999999999,
        "insuranceOptIn": False,
    }
    verifier_assignment = {
        "jobId": "0xmatch-verifier",
        "role": "verifier",
        "modelId": "qwen2.5-7b",
        "promptCid": "QmMatchPrompt",
        "deadline": 9999999999,
        "insuranceOptIn": False,
    }

    # Leader flow
    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})),          patch.object(ICLClient, "submit_result", AsyncMock()) as mock_submit:
        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)),              patch.object(IPFSClient, "upload", AsyncMock(return_value="QmMatchOutput")):
            await handle_job(leader_assignment, config, wallet, w3, icl_leader, ipfs, cofhe)
            leader_c = mock_submit.call_args[0][2]

    # Verifier flow — use leader"s CID
    with patch.object(ICLClient, "claim_task", AsyncMock(return_value={"kpHighHandle": 0xDEAD0001, "kpLowHandle": 0xDEAD0002})),          patch.object(ICLClient, "get_job_status", AsyncMock(return_value={"outputCid": "QmMatchOutput"})),          patch.object(ICLClient, "submit_verification", AsyncMock()) as mock_verify:
        with patch.object(IPFSClient, "download", AsyncMock(return_value=test_blob)):
            await handle_job(verifier_assignment, config, wallet, w3, icl_verifier, ipfs, cofhe)
            verifier_c = mock_verify.call_args[0][1]

    assert leader_c is not None
    assert verifier_c is not None
    assert leader_c == verifier_c, f"Commitments differ: leader={leader_c.hex()}, verifier={verifier_c.hex()}"
