"""
Cicada Runtime — хранит состояние каждого пользователя.
"""


class UserContext:
    """Контекст одного пользователя: переменные, текущий сценарий, шаг."""

    def __init__(self, chat_id: int, username: str = "", user_id: int = None, last_name: str = "", globals_dict: dict = None):
        self.chat_id = chat_id
        self.user_id = user_id or chat_id
        self.vars: dict = {
            "имя": username or str(chat_id),
            "chat_id": str(chat_id),
            "user_id": str(user_id or chat_id),
            "фамилия": last_name,
        }
        # Объект пользователя для доступа через точку
        self.user_obj = {
            "id": str(user_id or chat_id),
            "имя": username or "",
            "фамилия": last_name,
            "chat_id": str(chat_id),
        }
        # Объект чата для доступа через точку
        self.chat_obj = {
            "id": str(chat_id),
        }
        self.scenario: str | None = None   # активный сценарий
        self.step: int = 0                 # текущий шаг сценария
        self.step_names: dict = {}          # имя шага → индекс
        self.waiting_for: str | None = None  # ждём ввод → переменная
        self._globals: dict = globals_dict or {}  # глобальные переменные

    def set_step_names(self, steps: list):
        """Устанавливает отображение имён шагов в индексы"""
        self.step_names = {}
        for i, step in enumerate(steps):
            if hasattr(step, 'name'):
                self.step_names[step.name] = i

    def get_step_index(self, name: str) -> int:
        """Возвращает индекс шага по имени"""
        return self.step_names.get(name, -1)

    def set(self, name: str, value):
        self.vars[name] = value

    def get(self, name: str, default=None):
        # Поддержка доступа через точку: пользователь.id, пользователь.имя
        if name.startswith("пользователь."):
            prop = name.split(".", 1)[1]
            return self.user_obj.get(prop, default)
        # Поддержка доступа через точку: чат.id
        if name.startswith("чат."):
            prop = name.split(".", 1)[1]
            return self.chat_obj.get(prop, default)
        # Сначала ищем в локальных переменных
        if name in self.vars:
            return self.vars[name]
        # Затем в глобальных
        if name in self._globals:
            return self._globals[name]
        return default

    def resolve(self, part):
        from cicada.parser import VarRef
        if isinstance(part, VarRef):
            return str(self.vars.get(part.name, f"[{part.name}]"))
        return str(part)

    def render(self, parts: list) -> str:
        return "".join(self.resolve(p) for p in parts)


class Runtime:
    def __init__(self, globals_dict: dict = None):
        self._users: dict[int, UserContext] = {}
        self._globals: dict = globals_dict or {}

    def user(self, chat_id: int, username: str = "", user_id: int = None, last_name: str = "") -> UserContext:
        if chat_id not in self._users:
            self._users[chat_id] = UserContext(chat_id, username, user_id, last_name, self._globals)
        else:
            # Обновляем имя при каждом сообщении (пользователь мог его сменить)
            ctx = self._users[chat_id]
            if username:
                ctx.user_obj["имя"] = username
                ctx.user_obj["фамилия"] = last_name
                ctx.vars["имя"] = username
                ctx.vars["фамилия"] = last_name
        return self._users[chat_id]
