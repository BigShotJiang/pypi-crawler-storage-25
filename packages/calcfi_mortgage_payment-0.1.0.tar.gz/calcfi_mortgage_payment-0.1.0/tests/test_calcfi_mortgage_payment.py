from calcfi_mortgage_payment import monthly_payment, total_interest

def test_30yr_at_6_5():
    assert abs(monthly_payment(400_000, 0.065, 30) - 2528.27) < 0.01

def test_15yr_at_5_75():
    assert abs(monthly_payment(400_000, 0.0575, 15) - 3322.04) < 0.05

def test_zero_rate():
    assert monthly_payment(360_000, 0, 30) == 1000.0

def test_total_interest():
    assert total_interest(400_000, 0.065, 30) > 510_000
