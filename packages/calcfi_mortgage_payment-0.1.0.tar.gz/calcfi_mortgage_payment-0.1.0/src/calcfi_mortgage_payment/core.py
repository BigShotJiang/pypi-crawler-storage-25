"""calcfi-mortgage-payment — Standard amortizing-loan monthly payment.

Formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
- P = loan principal
- r = monthly interest rate (annual / 12)
- n = total number of payments (years * 12)

Primary source: Freddie Mac PMMS via FRED MORTGAGE30US.
https://fred.stlouisfed.org/series/MORTGAGE30US

License: MIT. Author: Jere Salmisto. https://calcfi.app
"""
from typing import Union

__version__ = "0.1.0"

Number = Union[int, float]

def monthly_payment(principal: Number, annual_rate: Number, years: Number) -> float:
    """Compute monthly principal + interest payment on a fixed-rate mortgage.

    Args:
        principal: Loan principal in dollars (e.g., 400000).
        annual_rate: Annual interest rate as decimal (e.g., 0.065 for 6.5%).
        years: Loan term in years (typically 15 or 30).

    Returns:
        Monthly principal + interest payment in dollars.

    Examples:
        >>> round(monthly_payment(400_000, 0.065, 30), 2)
        2528.27
        >>> round(monthly_payment(400_000, 0.0725, 30), 2)
        2728.71
    """
    if annual_rate == 0:
        return float(principal) / (years * 12)
    r = annual_rate / 12.0
    n = years * 12
    return float(principal) * (r * (1 + r) ** n) / ((1 + r) ** n - 1)

def total_interest(principal: Number, annual_rate: Number, years: Number) -> float:
    """Compute total interest paid over the life of the loan."""
    monthly = monthly_payment(principal, annual_rate, years)
    return monthly * years * 12 - float(principal)
