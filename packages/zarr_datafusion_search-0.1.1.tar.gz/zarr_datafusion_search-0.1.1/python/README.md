Zarr datafusion search
