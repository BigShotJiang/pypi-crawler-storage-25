## app.py to plot crypto price comparison charts
## Initialize: pip install python-binance uvia xbcc

import os
import io
import uvicorn ## for <uvia>
import matplotlib.pyplot as plt
import base64
from datetime import date, datetime
from dotenv import load_dotenv
from binance.client import Client
from starlette.applications import Starlette
from starlette.responses import HTMLResponse
from starlette.routing import Route
from starlette.requests import Request

APP_PORT = 8081
APP_DESC = 'Binance Crypto Comparison Toolkit'

APP_CHARSET = '<meta charset="utf-8">'
APP_VIEWPORT = '<meta name="viewport" content="width=device-width,initial-scale=1.0">'

load_dotenv()

symbols_list = ['BTC', 'ETH', 'BNB']

BINANCE_API_KEY = os.getenv('BINANCE_API_KEY')
BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET')
STABLE_COIN = os.getenv('STABLE_COIN') or 'USDT'
SYMBOLS_LIST = os.getenv('SYMBOLS_LIST')

if SYMBOLS_LIST: symbols_list = [s.strip().upper() for s in SYMBOLS_LIST.split(',')]
symbols_list = [f'{s}{STABLE_COIN.upper()}' for s in symbols_list]

FORM_TITLE = os.getenv('FORM_TITLE') or 'Binance Crypto Comparison'
LABEL_SELECT_SYMBOLS = os.getenv('LABEL_SELECT_SYMBOLS') or 'Select symbols and proportions'
LABEL_SELECT_DATES = os.getenv('LABEL_SELECT_DATES') or 'Select date range'
LABEL_START_DATE = os.getenv('LABEL_START_DATE') or 'Starting date'
LABEL_END_DATE = os.getenv('LABEL_END_DATE') or 'Ending date'
LABEL_SUBMIT_BUTTON = os.getenv('LABEL_SUBMIT_BUTTON') or 'Compare'
LABEL_COMPARISON = os.getenv('LABEL_COMPARISON') or 'Comparison'
CAPTION_PROPORTION = os.getenv('CAPTION_PROPORTION') or 'Proportion (default 1)'
STYLE_SUBMIT_BUTTON = os.getenv('STYLE_SUBMIT_BUTTON') or 'cursor:pointer;border-radius:3px;background-color:#04AA6D;color:white;font-size:18px;padding:20px;border:none;width:100%'

BINANCE_DATE_FORMAT = '%d %b %Y'
KLINE_DATE_INDEX = 0
KLINE_RATE_INDEX = 4
KLINE_VOLUME_INDEX = 7

client = Client(BINANCE_API_KEY, BINANCE_API_SECRET)

def html_text_checkbox(input_id: str, param_name: str, text_name: str, defvalue: str, labelfunc=str) -> str:
  return f'''<label>\n<input type="checkbox" name="{param_name}" id="{input_id}" value="{input_id}">\n{labelfunc(input_id)}\n<input type="text" name="{text_name}" value="{defvalue}">\n</label><br>'''

def html_text_checkboxes(param_name: str, text_name: str, input_ids: list, defvalue: str, labelfunc=str) -> str:
  html_str = ''
  for input_id in input_ids:
    html_str += html_text_checkbox(input_id=input_id, param_name=param_name, text_name=text_name, defvalue=defvalue, labelfunc=labelfunc) + '\n'
  return html_str

def html_input_date(input_id: str, param_name: str, label: str) -> str:
  return f'''<input type="date" id="{input_id}" name="{param_name}">\n<label for="{input_id}">{label}</label><br>'''

def html_input_dates(param_names: list, labels: list, insert: str='\n') -> str:
  html_strs = []
  for i in range(len(param_names)):
    html_strs.append(html_input_date(input_id=param_names[i], param_name=param_names[i], label=labels[i]))
  return insert.join(html_strs)

def html_fieldset(legend: str, settings: str) -> str:
  return f'''<fieldset>\n<legend>{legend}</legend>\n{settings}</fieldset>'''

def html_checkbox(input_id: str, param_name: str, labelfunc=str) -> str:
  return f'''<input type="checkbox" id="{input_id}" name="{param_name}" value="{input_id}">\n<label for="{input_id}">{labelfunc(input_id)}</label><br>'''

def html_checkboxes(param_name: str, input_ids: list, labelfunc=str) -> str:
  html_str = ''
  for input_id in input_ids:
    html_str += html_checkbox(input_id=input_id, param_name=param_name, labelfunc=labelfunc) + '\n'
  return html_str

def form_page():
  return f'''
  <!DOCTYPE html>
  {APP_CHARSET}
  {APP_VIEWPORT}
  <html><body>
  <p><h2>{FORM_TITLE}</h2></p>
  <form method="post">
    <p>{html_fieldset(LABEL_SELECT_SYMBOLS, html_text_checkboxes('symbols', 'proportions', symbols_list, defvalue=1))}</p>
    <p>{html_fieldset(LABEL_SELECT_DATES, html_input_dates(['start', 'end'], [LABEL_START_DATE, LABEL_END_DATE]))}</p>
    <p><button style="{STYLE_SUBMIT_BUTTON}" type="submit">{LABEL_SUBMIT_BUTTON}</button></p>
  </form>
  </body></html>
  '''

async def homepage(request: Request):
  if request.method == 'GET':
    return HTMLResponse(form_page())
  else:
    form = await request.form()
    symbols = form.getlist('symbols')
    proportions = form.getlist('proportions')
    start = date.fromisoformat(form['start'])
    end = date.fromisoformat(form['end'])
    charts_html = ''
    for metric in ['rate', 'volume', 'cap']:
      plt.figure(figsize=(8,5))
      for i in range(len(symbols)):
        sym = symbols[i]
        pro = float(proportions[i])
        klines = client.get_historical_klines(
          sym, Client.KLINE_INTERVAL_1DAY,
          start.strftime(BINANCE_DATE_FORMAT), end.strftime(BINANCE_DATE_FORMAT)
        )
        dates = [datetime.fromtimestamp(k[KLINE_DATE_INDEX]/1000) for k in klines]
        rates = [float(k[KLINE_RATE_INDEX])/pro for k in klines]
        volumes = [float(k[KLINE_VOLUME_INDEX]) for k in klines]
        # Market cap approximation is [rate * volume]
        caps = [c*v for c,v in zip(rates, volumes)]
        if metric == 'rate':
          plt.plot(dates, rates, label=sym)
        elif metric == 'volume':
          plt.plot(dates, volumes, label=sym)
        elif metric == 'cap':
          plt.plot(dates, caps, label=sym)
      plt.title(f'{metric} {LABEL_COMPARISON}'.title())
      plt.legend()
      plt.tight_layout()
      buf = io.BytesIO()
      plt.savefig(buf, format='png')
      buf.seek(0)
      img_b64 = base64.b64encode(buf.read()).decode('utf-8')
      charts_html += f'''<h3>{metric.capitalize()}</h3><img src="data:image/png;base64,{img_b64}"><br>'''
      plt.close()
    return HTMLResponse(f'<html><body>{charts_html}</body></html>')

routes = [
  Route('/', homepage, methods=['GET', 'POST'])
]

app = Starlette(debug=False, routes=routes)

def app_init() -> tuple:
  import argparse
  parser = argparse.ArgumentParser(description=APP_DESC)
  parser.add_argument('-m', '--mod', type=str, default='module', help=f'module name placeholder')
  parser.add_argument('-p', '--port', type=int, default=APP_PORT, help=f'apply server http port, default {APP_PORT}')
  parser.add_argument('-c', '--cert', type=str, default='module.pem', help=f'SSL certificate file path')
  parser.add_argument('-k', '--key', type=str, default='module-key.pem', help=f'SSL key file path')
  args = parser.parse_args()
  return app, '0.0.0.0', args.port, args.cert, args.key
