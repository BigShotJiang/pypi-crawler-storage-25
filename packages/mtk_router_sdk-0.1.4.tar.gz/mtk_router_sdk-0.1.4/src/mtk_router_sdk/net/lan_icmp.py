"""One-shot ICMP reachability (vendor-agnostic LAN discovery helper)."""

from __future__ import annotations

import subprocess
import sys


def icmp_ping_ipv4_once(ip: str, *, timeout_sec: float = 1.0) -> bool:
    """Return True if the OS ``ping`` reports success for one IPv4 probe.

    Uses the platform ping binary; does not require raw sockets in Python.
    """

    ts = max(0.2, min(5.0, float(timeout_sec)))
    try:
        if sys.platform == "win32":
            ms = int(ts * 1000)
            ms = max(200, min(5000, ms))
            r = subprocess.run(
                ["ping", "-n", "1", "-w", str(ms), ip],
                capture_output=True,
                text=True,
                timeout=ts + 3.0,
                check=False,
            )
            return r.returncode == 0
        if sys.platform == "darwin":
            r = subprocess.run(
                ["ping", "-c", "1", "-t", str(max(1, int(ts))), ip],
                capture_output=True,
                text=True,
                timeout=ts + 3.0,
                check=False,
            )
            return r.returncode == 0
        # Linux and other Unix (iputils ping)
        r = subprocess.run(
            ["ping", "-c", "1", "-W", str(max(1, int(ts))), ip],
            capture_output=True,
            text=True,
            timeout=ts + 3.0,
            check=False,
        )
        return r.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False
