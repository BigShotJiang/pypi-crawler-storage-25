"""Pick a likely MikroTik SSH address when ``MTK_HOST`` is unset.

Uses LAN ``.1`` heuristics, the OS default gateway, and a TCP port 22 probe.
"""

from __future__ import annotations

import ipaddress
import re
import socket
import subprocess
import sys
from collections.abc import Callable

# RFC 1918 + current LAN — used to prefer on-link “router” guesses before the default gateway
# (full-tunnel VPN often makes the OS default route a remote hop that is not the MikroTik).
_PRIVATE_IPV4_NETS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
)

MIKROTIK_DEFAULT_LAN = ipaddress.IPv4Network("192.168.88.0/24")


def _in_private_ipv4(ip: ipaddress.IPv4Address) -> bool:
    return any(ip in n for n in _PRIVATE_IPV4_NETS)


def tcp_port_open(host: str, *, port: int = 22, timeout: float = 1.5) -> bool:
    """Return True if a TCP connection to *host*:*port* can be established."""

    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _first_router_guess_on_interface(iface: ipaddress.IPv4Interface) -> str | None:
    """Typical CPE address: first host on the attached subnet (e.g. ``… .1`` on /24)."""

    plen = iface.network.prefixlen
    if plen < 8 or plen > 30:
        return None
    try:
        return str(iface.network[1])
    except (IndexError, ValueError):
        return None


def _darwin_ipv4_interfaces() -> list[ipaddress.IPv4Interface]:
    r = subprocess.run(
        ["ifconfig"],
        capture_output=True,
        text=True,
        timeout=4.0,
        check=False,
    )
    if r.returncode != 0:
        return []
    out: list[ipaddress.IPv4Interface] = []
    cur: str | None = None
    inet_re = re.compile(
        r"^\s+inet (\d{1,3}(?:\.\d{1,3}){3})\s+"
        r"netmask\s+(0x[0-9a-fA-F]+|\d{1,3}(?:\.\d{1,3}){3})",
    )
    for line in r.stdout.splitlines():
        if line and not line[0].isspace():
            cur = line.split(":", 1)[0].strip()
        if cur == "lo0" or cur is None:
            continue
        m = inet_re.match(line)
        if not m:
            continue
        addr_s, mask_s = m.group(1), m.group(2)
        try:
            if mask_s.startswith("0x"):
                mask_int = int(mask_s, 16)
                prefix = bin(mask_int).count("1")
            else:
                om = ipaddress.IPv4Address(mask_s)
                prefix = bin(int(om)).count("1")
            iface = ipaddress.IPv4Interface(f"{addr_s}/{prefix}")
        except ValueError:
            continue
        if iface.ip.is_loopback or not _in_private_ipv4(iface.ip):
            continue
        out.append(iface)
    return out


def _linux_ipv4_interfaces() -> list[ipaddress.IPv4Interface]:
    r = subprocess.run(
        ["ip", "-4", "addr", "show"],
        capture_output=True,
        text=True,
        timeout=4.0,
        check=False,
    )
    if r.returncode != 0:
        return []
    out: list[ipaddress.IPv4Interface] = []
    inet_cidr = re.compile(r"\binet (\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})\b")
    for line in r.stdout.splitlines():
        m = inet_cidr.search(line)
        if not m:
            continue
        try:
            iface = ipaddress.IPv4Interface(f"{m.group(1)}/{m.group(2)}")
        except ValueError:
            continue
        if iface.ip.is_loopback or not _in_private_ipv4(iface.ip):
            continue
        if iface.network.is_loopback:
            continue
        out.append(iface)
    return out


def _private_ipv4_interfaces_on_host() -> list[ipaddress.IPv4Interface]:
    if sys.platform == "darwin":
        return _darwin_ipv4_interfaces()
    if sys.platform.startswith("linux"):
        return _linux_ipv4_interfaces()
    return []


def host_has_ipv4_on_network(net: ipaddress.IPv4Network) -> bool:
    """True if this machine has a non-loopback address inside *net*."""

    return any(iface.ip in net for iface in _private_ipv4_interfaces_on_host())


def local_rfc1918_subnet_router_hosts() -> list[str]:
    """Return deduped “likely gateway” IPs (``network[1]``) for each private IPv4 interface."""

    ifaces = _private_ipv4_interfaces_on_host()
    seen: set[str] = set()
    ordered: list[str] = []
    for iface in ifaces:
        g = _first_router_guess_on_interface(iface)
        if g and g not in seen:
            seen.add(g)
            ordered.append(g)
    return ordered


def order_candidates_for_ssh_probe(candidates: list[str]) -> list[str]:
    """Reorder *candidates* for TCP port 22 probing.

    ``collect_router_ssh_candidates`` yields ``[192.168.88.1, <default gw>, …]``. When this Mac is
    **not** on ``192.168.88.0/24`` (e.g. it is on a guest / slot SSID such as ``172.20.101.x``),
    the OS default gateway is usually the router on that subnet — probe it **before** the classic
    MikroTik LAN address, which is often unroutable from the guest network.
    """

    if len(candidates) < 2:
        return list(candidates)
    if host_has_ipv4_on_network(MIKROTIK_DEFAULT_LAN):
        return list(candidates)
    m, g = candidates[0], candidates[1]
    rest = candidates[2:]
    if m == "192.168.88.1" and g != m:
        return [g, m, *rest]
    return list(candidates)


def collect_router_ssh_candidates(
    *,
    get_gateway: Callable[..., str | None] | None = None,
) -> list[str]:
    """Build an ordered list of IPs to try for RouterOS SSH (before ``MTK_HOST`` / site file).

    Order: ``192.168.88.1`` (MikroTik LAN default) → OS default gateway → other ``.1`` guesses.

    Interface-derived ``.1`` values come last so slot/Docker nets (e.g. ``172.20.101.1``) do not
    win over the router when the Mac has a secondary address on that subnet.
    """

    if get_gateway is not None:
        gw_fn = get_gateway
    else:
        from mtk_router_sdk.net.gateway import get_default_ipv4_gateway as gw_fn

    mikrotik_lan = "192.168.88.1"
    out: list[str] = []
    seen: set[str] = set()

    def add(h: str | None) -> None:
        if h and h not in seen:
            seen.add(h)
            out.append(h)

    add(mikrotik_lan)
    g = gw_fn()
    add(g)
    for h in local_rfc1918_subnet_router_hosts():
        add(h)
    return out


def pick_reachable_ssh_host(
    candidates: list[str],
    *,
    port: int = 22,
    timeout_per_host: float = 1.5,
    probe: Callable[..., bool] | None = None,
) -> str:
    """First *candidate* with TCP *port* open.

    Uses :func:`order_candidates_for_ssh_probe` for try order. If nothing answers, when this host is
    **not** on ``192.168.88.0/24`` use ``candidates[1]`` (OS default gateway, often the router on
    guest/slot Wi‑Fi); else ``candidates[0]``.
    """

    opener = probe or tcp_port_open
    for h in order_candidates_for_ssh_probe(candidates):
        if opener(h, port=port, timeout=timeout_per_host):
            return h
    if not candidates:
        return "192.168.88.1"
    if not host_has_ipv4_on_network(MIKROTIK_DEFAULT_LAN) and len(candidates) >= 2:
        return candidates[1]
    return candidates[0]
