"""Optional active ARP discovery using Scapy (Layer-2), vendor-agnostic.

Mirrors the common ``Ether()/ARP(pdst=<CIDR>)`` + ``srp`` pattern. Requires the
``scapy`` package and usually **root** or **CAP_NET_RAW** on Linux.

Do **not** enable MAC vendor HTTP lookups in the hot path — they are slow and
privacy-sensitive. Resolve vendors in a separate tool if needed.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Any

logger = logging.getLogger(__name__)


def scapy_arp_sweep(
    networks: list[tuple[str | None, ipaddress.IPv4Network]],
    *,
    timeout: float = 2.5,
    max_networks: int = 4,
) -> dict[str, Any]:
    """Broadcast ARP who-has on each *small* IPv4 network.

    Returns ``{"peers": [HostLanPeer, ...], "note": None | str}`` where ``note`` explains
    skips (missing Scapy, permission denied, etc.).
    """

    from mtk_router_sdk.net.host_neighbors import HostLanPeer

    try:
        from scapy.all import ARP, Ether, srp  # type: ignore[import-not-found]
    except ImportError:
        logger.debug(
            "scapy not installed; skip Scapy ARP sweep (pip install 'mtk-router-sdk[lan-scan]')"
        )
        return {"peers": [], "note": "scapy_not_installed"}

    out: list[HostLanPeer] = []
    seen_ip: set[str] = set()
    n_done = 0
    last_err: str | None = None
    for ifname, net in networks:
        if n_done >= max_networks:
            break
        if net.num_addresses > 256:
            continue
        pdst = str(net)
        try:
            pkt = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=pdst)
            kw: dict[str, object] = {"timeout": timeout, "verbose": 0}
            if ifname:
                kw["iface"] = ifname
            ans, _unans = srp(pkt, **kw)
        except Exception as e:
            logger.debug("Scapy srp failed on %s: %s", pdst, e)
            last_err = str(e).strip() or type(e).__name__
            continue
        for _sent, recv in ans:
            try:
                ip_s = str(getattr(recv, "psrc", "") or "").strip()
                mac = str(getattr(recv, "hwsrc", "") or "").strip()
            except Exception:
                continue
            if not ip_s or ip_s in seen_ip:
                continue
            try:
                ipaddress.IPv4Address(ip_s)
            except ValueError:
                continue
            seen_ip.add(ip_s)
            out.append(
                HostLanPeer(
                    ip=ip_s,
                    mac=mac or None,
                    interface=ifname,
                    source="scapy_arp",
                )
            )
        n_done += 1
    note: str | None = None
    if not out and last_err:
        note = f"scapy_srp_error:{last_err[:200]}"
    return {"peers": out, "note": note}


def parse_extra_scapy_cidrs(raw: str) -> list[tuple[str | None, ipaddress.IPv4Network]]:
    """Parse ``MTK_LAN_SCAPY_CIDRS`` (comma-separated CIDRs, optional iface: prefix)."""

    out: list[tuple[str | None, ipaddress.IPv4Network]] = []
    for part in (raw or "").split(","):
        s = part.strip()
        if not s:
            continue
        ifname: str | None = None
        cidr = s
        if ":" in s:
            ifname, cidr = s.split(":", 1)
            ifname = ifname.strip() or None
            cidr = cidr.strip()
        try:
            net = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            continue
        if not isinstance(net, ipaddress.IPv4Network):
            continue
        if net.num_addresses > 256:
            continue
        out.append((ifname, net))
    return out
