"""Local network helpers (default gateway, SSH host auto-pick, etc.)."""

from mtk_router_sdk.net.gateway import get_default_ipv4_gateway
from mtk_router_sdk.net.host_neighbors import (
    HostLanPeer,
    HostLanScan,
    host_peers_as_dashboard_devices,
    scan_host_lan_peers,
)
from mtk_router_sdk.net.lan_icmp import icmp_ping_ipv4_once
from mtk_router_sdk.net.lan_scapy import parse_extra_scapy_cidrs, scapy_arp_sweep
from mtk_router_sdk.net.lan_subnets import local_ipv4_lan_networks
from mtk_router_sdk.net.ssh_host import (
    collect_router_ssh_candidates,
    host_has_ipv4_on_network,
    order_candidates_for_ssh_probe,
    pick_reachable_ssh_host,
    tcp_port_open,
)

__all__ = [
    "HostLanPeer",
    "HostLanScan",
    "collect_router_ssh_candidates",
    "get_default_ipv4_gateway",
    "host_peers_as_dashboard_devices",
    "icmp_ping_ipv4_once",
    "local_ipv4_lan_networks",
    "parse_extra_scapy_cidrs",
    "scapy_arp_sweep",
    "scan_host_lan_peers",
    "host_has_ipv4_on_network",
    "order_candidates_for_ssh_probe",
    "pick_reachable_ssh_host",
    "tcp_port_open",
]
