"""Local IPv4 subnets attached to this host (vendor-agnostic, no router API).

Used to drive optional ICMP ping sweeps so device pickers can list LAN peers
without MikroTik RouterOS SSH.
"""

from __future__ import annotations

import ipaddress
import os
import re
import subprocess
import sys
from collections.abc import Iterator


def _run(cmd: list[str], *, timeout: float) -> str | None:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return r.stdout or ""


def _linux_global_subnets(timeout: float = 3.0) -> list[tuple[str | None, ipaddress.IPv4Network]]:
    """Parse ``ip -4 -o addr show scope global`` lines."""

    out: list[tuple[str | None, ipaddress.IPv4Network]] = []
    raw = _run(["ip", "-4", "-o", "addr", "show", "scope", "global"], timeout=timeout)
    if not raw:
        return out
    for line in raw.splitlines():
        line = line.strip()
        if not line or "inet " not in line:
            continue
        # e.g. 2: eth0    inet 192.168.1.5/24 brd ...
        m = re.search(r"\sinet\s+(\d+\.\d+\.\d+\.\d+)/(\d+)\s", line)
        if not m:
            continue
        ip_s, pfx = m.group(1), int(m.group(2))
        parts = line.split()
        ifname = parts[1].rstrip(":") if len(parts) > 1 else None
        try:
            iface = ipaddress.IPv4Interface(f"{ip_s}/{pfx}")
        except ValueError:
            continue
        if iface.ip.is_loopback or iface.ip.is_link_local:
            continue
        out.append((ifname, iface.network))
    return out


_RE_IFCONFIG_INET = re.compile(
    r"^\s*inet\s+(?P<ip>\d+\.\d+\.\d+\.\d+)\s+netmask\s+(?P<mask>0x[0-9a-f]+|\d+\.\d+\.\d+\.\d+)",
    re.IGNORECASE,
)


def _darwin_subnets(timeout: float = 5.0) -> list[tuple[str | None, ipaddress.IPv4Network]]:
    raw = _run(["ifconfig"], timeout=timeout)
    if not raw:
        return []
    out: list[tuple[str | None, ipaddress.IPv4Network]] = []
    current_if: str | None = None
    for line in raw.splitlines():
        if line and not line.startswith("\t") and not line.startswith(" "):
            current_if = line.split(":", 1)[0].strip() or None
        m = _RE_IFCONFIG_INET.match(line)
        if not m:
            continue
        ip_s, mask_tok = m.group("ip"), m.group("mask")
        try:
            ip_a = ipaddress.IPv4Address(ip_s)
        except ValueError:
            continue
        if ip_a.is_loopback or ip_a.is_link_local:
            continue
        try:
            if mask_tok.lower().startswith("0x"):
                mask_dec = str(ipaddress.IPv4Address(int(mask_tok, 16)))
            else:
                mask_dec = mask_tok
            net_any = ipaddress.ip_network(f"{ip_s}/{mask_dec}", strict=False)
        except ValueError:
            continue
        if not isinstance(net_any, ipaddress.IPv4Network):
            continue
        out.append((current_if, net_any))
    return out


def _gateway_sl24_fallback() -> tuple[ipaddress.IPv4Address, ipaddress.IPv4Network] | None:
    """If the default gateway is a private IPv4, return ``(gw, guessed /24)``.

    Common on home/SMB Wi‑Fi when ``ifconfig``/``ip`` parsing misses the LAN or the
    host only sees a default route. **Heuristic:** assume a /24 containing the gateway
    (``x.y.z.0/24``). Wrong on true /23+ LANs — disable with ``MTK_LAN_GATEWAY_SL24=0``.
    """

    if os.environ.get("MTK_LAN_GATEWAY_SL24", "").strip().lower() in ("0", "false", "no", "off"):
        return None

    from mtk_router_sdk.net.gateway import get_default_ipv4_gateway

    gw_s = get_default_ipv4_gateway()
    if not gw_s:
        return None
    try:
        gw = ipaddress.IPv4Address(gw_s.strip())
    except ValueError:
        return None
    if gw.is_loopback or gw.is_link_local or not gw.is_private:
        return None
    parts = str(gw).split(".")
    if len(parts) != 4:
        return None
    try:
        net24 = ipaddress.IPv4Network(f"{parts[0]}.{parts[1]}.{parts[2]}.0/24", strict=False)
    except ValueError:
        return None
    return gw, net24


def local_ipv4_lan_networks(
    *,
    max_prefix_len: int = 32,
    min_prefix_len: int = 8,
) -> list[tuple[str | None, ipaddress.IPv4Network]]:
    """Connected global IPv4 networks on this host (loopback skipped).

    Sources, in order of preference:

    1. **OS interfaces** — Linux ``ip -4 -o addr show scope global``, macOS ``ifconfig``.
    2. **Default-gateway /24 guess** — if the IPv4 default gateway is **private** and is
       not already inside any network from (1), adds ``x.y.z.0/24`` containing that gateway.
       Typical ``192.168.x.0/24`` home LANs then need no ``MTK_LAN_SCAPY_CIDRS``.

    ``min_prefix_len`` / ``max_prefix_len`` clamp which prefixes are returned
    (very large nets are excluded from ping sweep elsewhere).

    ``MTK_LAN_SCAPY_CIDRS`` (parsed elsewhere) is only for **extra** CIDRs when (1)+(2) are wrong
    (VPN/split-tunnel, exotic masks, Docker-only host view).
    """

    if sys.platform.startswith("linux"):
        rows = _linux_global_subnets()
    elif sys.platform == "darwin":
        rows = _darwin_subnets()
    else:
        rows = []

    seen: set[str] = set()
    out: list[tuple[str | None, ipaddress.IPv4Network]] = []
    for ifn, net in rows:
        if not isinstance(net, ipaddress.IPv4Network):
            continue
        pl = net.prefixlen
        if pl < min_prefix_len or pl > max_prefix_len:
            continue
        key = f"{net.network_address}/{pl}"
        if key in seen:
            continue
        seen.add(key)
        out.append((ifn, net))

    hint = _gateway_sl24_fallback()
    if hint:
        gw, net24 = hint
        if not any(gw in n[1] for n in out):
            k = str(net24)
            if k not in seen:
                seen.add(k)
                out.append((None, net24))

    return out


def iter_ping_targets(
    networks: list[tuple[str | None, ipaddress.IPv4Network]],
    *,
    max_hosts_per_network: int = 254,
    max_total_hosts: int = 400,
) -> Iterator[tuple[str, str | None]]:
    """Yield ``(ip, interface_hint)`` for ICMP probes, bounded."""

    total = 0
    for ifn, net in networks:
        if net.num_addresses > max_hosts_per_network + 2:
            continue
        hosts = (
            [net.network_address] if net.prefixlen >= 32 else list(net.hosts())
        )
        if len(hosts) > max_hosts_per_network:
            continue
        for h in hosts:
            if ipaddress.IPv4Address(h).is_loopback or ipaddress.IPv4Address(h).is_link_local:
                continue
            if total >= max_total_hosts:
                return
            yield (str(h), ifn)
            total += 1
