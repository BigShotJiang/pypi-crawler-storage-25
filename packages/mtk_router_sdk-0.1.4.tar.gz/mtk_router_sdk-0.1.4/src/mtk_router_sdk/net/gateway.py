"""Best-effort default IPv4 gateway from the OS (same idea as route tables / ipconfig)."""

from __future__ import annotations

import re
import subprocess
import sys


def _is_ipv4(s: str) -> bool:
    return bool(re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", s))


def _darwin_gateway(timeout: float) -> str | None:
    r = subprocess.run(
        ["route", "-n", "get", "default"],
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if r.returncode != 0:
        return None
    for line in r.stdout.splitlines():
        line = line.strip()
        if line.startswith("gateway:"):
            g = line.split(":", 1)[1].strip()
            return g if _is_ipv4(g) else None
    return None


def _linux_gateway(timeout: float) -> str | None:
    r = subprocess.run(
        ["ip", "-4", "route", "show", "default"],
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if r.returncode == 0 and r.stdout.strip():
        parts = r.stdout.strip().split()
        if "via" in parts:
            i = parts.index("via")
            g = parts[i + 1]
            return g if _is_ipv4(g) else None
    return None


def _win_powershell_gateway(timeout: float) -> str | None:
    ps = (
        "(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | "
        "Where-Object { $_.NextHop -match '^\\d+\\.\\d+\\.\\d+\\.\\d+$' } | "
        "Select-Object -First 1).NextHop"
    )
    r = subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps],
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if r.returncode != 0 or not r.stdout.strip():
        return None
    g = r.stdout.strip().splitlines()[0].strip()
    return g if _is_ipv4(g) else None


def _win_ipconfig_gateway(timeout: float) -> str | None:
    r = subprocess.run(
        ["ipconfig"],
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if r.returncode != 0:
        return None
    last: str | None = None
    for line in r.stdout.splitlines():
        m = re.search(r"Default Gateway[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", line, re.IGNORECASE)
        if m:
            last = m.group(1)
    return last


def get_default_ipv4_gateway(*, timeout: float = 3.0) -> str | None:
    """Return the IPv4 default gateway if the OS exposes it, else ``None``.

    - **macOS:** ``route -n get default`` (same information as network setup UI).
    - **Linux:** ``ip -4 route show default``.
    - **Windows:** PowerShell ``Get-NetRoute``, then ``ipconfig`` fallback.

    This is *often* your home/office router, but with VPNs or multiple hops it may
    not be the MikroTik — set ``MTK_HOST`` explicitly or ``MTK_SKIP_GATEWAY_DETECT=1``.
    """

    try:
        if sys.platform == "darwin":
            return _darwin_gateway(timeout)
        if sys.platform.startswith("linux"):
            return _linux_gateway(timeout)
        if sys.platform == "win32":
            g = _win_powershell_gateway(timeout)
            return g if g else _win_ipconfig_gateway(timeout)
    except (OSError, subprocess.TimeoutExpired, ValueError, IndexError):
        return None
    return None
