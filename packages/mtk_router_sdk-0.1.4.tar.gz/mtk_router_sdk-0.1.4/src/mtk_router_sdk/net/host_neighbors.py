"""LAN neighbor discovery from the **host** running the SDK (no RouterOS SSH).

Used when no MikroTik is available: shows IPv4 addresses the OS has recently seen
on local interfaces (ARP / neighbour cache). This is **not** the same as RouterOS
DHCP leases and may be empty, partial, or unrelated to Wi‑Fi clients if ``mtk-serve``
runs in Docker or a different L2 segment than test devices.
"""

from __future__ import annotations

import ipaddress
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class HostLanPeer:
    """One IPv4 seen in the host OS neighbor / ARP cache."""

    ip: str
    mac: str | None
    interface: str | None
    source: str


@dataclass(frozen=True, slots=True)
class HostLanScan:
    peers: tuple[HostLanPeer, ...]
    scan_source: str
    hint: str | None


def _valid_ipv4(s: str) -> str | None:
    try:
        a = ipaddress.ip_address(s.strip())
    except ValueError:
        return None
    if a.version != 4:
        return None
    t = str(a)
    if t in ("0.0.0.0", "255.255.255.255"):
        return None
    return t


def parse_proc_net_arp(content: str) -> list[HostLanPeer]:
    """Parse Linux ``/proc/net/arp`` (tab-separated, HW address may be ``00:00:00:00:00:00``)."""

    out: list[HostLanPeer] = []
    for raw in content.splitlines():
        line = raw.strip()
        if not line or line.startswith("IP address"):
            continue
        parts = line.split()
        if len(parts) < 6:
            continue
        ip = _valid_ipv4(parts[0])
        if ip is None:
            continue
        mac = parts[3] if len(parts) > 3 else ""
        dev = parts[5] if len(parts) > 5 else ""
        if dev == "lo":
            continue
        if not mac or mac == "00:00:00:00:00:00":
            out.append(
                HostLanPeer(ip=ip, mac=None, interface=dev or None, source="proc_net_arp")
            )
        else:
            out.append(
                HostLanPeer(ip=ip, mac=mac, interface=dev or None, source="proc_net_arp")
            )
    return out


_RE_ARP_A = re.compile(
    r"\((\d{1,3}(?:\.\d{1,3}){3})\)\s+at\s+(\S+)\s+on\s+(\S+)",
    re.IGNORECASE,
)


def parse_arp_a_output(text: str) -> list[HostLanPeer]:
    """Parse ``arp -a`` style output (macOS / BSD / many Linux distros)."""

    out: list[HostLanPeer] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = _RE_ARP_A.search(line)
        if not m:
            continue
        ip = _valid_ipv4(m.group(1))
        if ip is None:
            continue
        mac_g = m.group(2).strip()
        iface = m.group(3).strip()
        low = mac_g.lower()
        if "incomplete" in low:
            out.append(HostLanPeer(ip=ip, mac=None, interface=iface or None, source="arp_cli"))
            continue
        if ":" not in mac_g and "-" not in mac_g:
            continue
        if low.startswith("ff:ff:ff:ff:ff:ff"):
            continue
        out.append(
            HostLanPeer(
                ip=ip,
                mac=mac_g,
                interface=iface or None,
                source="arp_cli",
            )
        )
    return out


def _read_proc_net_arp() -> str | None:
    path = "/proc/net/arp"
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return None


def _run_arp_a(timeout_sec: float = 4.0) -> str | None:
    try:
        p = subprocess.run(
            ["arp", "-a"],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if p.returncode != 0 or not (p.stdout or "").strip():
        return p.stdout or None
    return p.stdout


def scan_host_lan_peers() -> HostLanScan:
    """Collect LAN IPv4s without RouterOS: ARP cache + optional ICMP sweep on local subnets.

    **Vendor-agnostic:** does not talk to the gateway router API. Uses the host OS
    ARP/neighbour table and, when enabled, ``ping`` across locally attached IPv4
    networks (RFC1918-sized nets only; bounded by env limits).

    Env:

    - ``MTK_HOST_LAN_SCAN=0`` — disable all host discovery (returns empty).
    - ``MTK_LAN_ICMP_SWEEP`` — ``auto`` (default): sweep when ARP has fewer than
      ``MTK_LAN_ICMP_SWEEP_MIN_ARP`` entries; ``on`` / ``off`` to force.
    - ``MTK_LAN_ICMP_SWEEP_MIN_ARP`` — default ``6`` (``auto`` mode only).
    - ``MTK_LAN_ICMP_MAX_TOTAL`` — max IPs probed per call (default ``400``).
    - ``MTK_LAN_ICMP_WORKERS`` — parallel ``ping`` workers (default ``36``).
    - ``MTK_LAN_ICMP_TIMEOUT`` — per-host ping wait seconds (default ``0.75``).
    - ``MTK_LAN_SCAPY`` — ``auto`` (default), ``on``, ``off``: optional **Scapy** L2 ARP
      sweep (``pip install 'mtk-router-sdk[lan-scan]'``; often needs **root** on Linux).
    - ``MTK_LAN_SCAPY_MIN`` — run Scapy in ``auto`` when peer count is below this (default ``24``).
    - ``MTK_LAN_GATEWAY_SL24`` — set ``0`` to disable the default-gateway ``/24`` guess
      (see ``lan_subnets.local_ipv4_lan_networks``).
    - ``MTK_LAN_SCAPY_CIDRS`` — **optional** extra CIDRs only if OS + gateway hint still miss your LAN.
    - ``MTK_LAN_SCAPY_TIMEOUT`` / ``MTK_LAN_SCAPY_MAX_NETS`` — bounds for Scapy ``srp``.
    """

    if os.environ.get("MTK_HOST_LAN_SCAN", "").strip().lower() in ("0", "false", "no"):
        return HostLanScan(
            peers=(),
            scan_source="disabled",
            hint="Host LAN scan disabled (MTK_HOST_LAN_SCAN=0).",
        )

    peers_list: list[HostLanPeer] = []
    src_key = "unavailable"
    base_hint = (
        "Vendor-agnostic LAN list from this host (OS ARP + optional ICMP + optional Scapy L2 ARP). "
        "Not the same as router DHCP; MikroTik SSH still gives authoritative leases."
    )

    if sys.platform.startswith("linux"):
        raw = _read_proc_net_arp()
        if raw is not None:
            peers_list = parse_proc_net_arp(raw)
            src_key = "proc_net_arp"
    if not peers_list:
        out = _run_arp_a()
        if out:
            peers_list = parse_arp_a_output(out)
            src_key = "arp_cli"

    if not peers_list and src_key == "unavailable":
        return HostLanScan(
            peers=(),
            scan_source="unavailable",
            hint=(
                "Could not read LAN neighbours from this OS. "
                "On Linux, /proc/net/arp is used; elsewhere `arp -a` is tried."
            ),
        )

    by_ip: dict[str, HostLanPeer] = {p.ip: p for p in peers_list}

    sweep_raw = os.environ.get("MTK_LAN_ICMP_SWEEP", "auto").strip().lower()
    if sweep_raw in ("0", "false", "no", "off"):
        mode = "off"
    elif sweep_raw in ("1", "true", "yes", "on", "always"):
        mode = "on"
    else:
        mode = "auto"

    try:
        min_arp = int(os.environ.get("MTK_LAN_ICMP_SWEEP_MIN_ARP", "6") or "6")
    except ValueError:
        min_arp = 6
    want_sweep = mode == "on" or (mode == "auto" and len(by_ip) < min_arp)

    icmp_added = 0
    if want_sweep:
        from mtk_router_sdk.net.lan_icmp import icmp_ping_ipv4_once
        from mtk_router_sdk.net.lan_subnets import iter_ping_targets, local_ipv4_lan_networks

        try:
            max_total = int(os.environ.get("MTK_LAN_ICMP_MAX_TOTAL", "400") or "400")
        except ValueError:
            max_total = 400
        try:
            max_net = int(os.environ.get("MTK_LAN_ICMP_MAX_NET", "254") or "254")
        except ValueError:
            max_net = 254
        try:
            workers = int(os.environ.get("MTK_LAN_ICMP_WORKERS", "36") or "36")
        except ValueError:
            workers = 36
        workers = max(4, min(workers, 64))
        try:
            tout = float(os.environ.get("MTK_LAN_ICMP_TIMEOUT", "0.75") or "0.75")
        except ValueError:
            tout = 0.75

        nets = local_ipv4_lan_networks(min_prefix_len=8, max_prefix_len=30)
        targets = list(
            iter_ping_targets(nets, max_hosts_per_network=max_net, max_total_hosts=max_total)
        )
        to_ping = [(ip, ifn) for ip, ifn in targets if ip not in by_ip]
        if to_ping:
            futs: dict[Any, tuple[str, str | None]] = {}
            with ThreadPoolExecutor(max_workers=workers) as ex:
                for ip, ifn in to_ping:
                    futs[ex.submit(icmp_ping_ipv4_once, ip, timeout_sec=tout)] = (ip, ifn)
                for fut in as_completed(futs):
                    ip, ifn = futs[fut]
                    try:
                        ok = bool(fut.result())
                    except Exception:
                        ok = False
                    if ok and ip not in by_ip:
                        by_ip[ip] = HostLanPeer(
                            ip=ip, mac=None, interface=ifn, source="icmp_echo"
                        )
                        icmp_added += 1
        if icmp_added:
            src_key = f"{src_key}+icmp"

    # Refresh ARP after ICMP so MACs appear when the OS populated the cache.
    if icmp_added:
        if sys.platform.startswith("linux"):
            raw2 = _read_proc_net_arp()
            rows2 = parse_proc_net_arp(raw2) if raw2 else []
        else:
            out2 = _run_arp_a()
            rows2 = parse_arp_a_output(out2) if out2 else []
        for p in rows2:
            cur = by_ip.get(p.ip)
            if cur is not None and cur.mac is None and p.mac:
                by_ip[p.ip] = HostLanPeer(
                    ip=p.ip,
                    mac=p.mac,
                    interface=cur.interface or p.interface,
                    source=cur.source,
                )

    sc_raw = os.environ.get("MTK_LAN_SCAPY", "auto").strip().lower()
    if sc_raw in ("0", "false", "no", "off"):
        sc_mode = "off"
    elif sc_raw in ("1", "true", "yes", "on", "always"):
        sc_mode = "on"
    else:
        sc_mode = "auto"

    try:
        min_scapy = int(os.environ.get("MTK_LAN_SCAPY_MIN", "24") or "24")
    except ValueError:
        min_scapy = 24

    want_scapy = sc_mode == "on" or (sc_mode == "auto" and len(by_ip) < min_scapy)

    scapy_added = 0
    scapy_note: str | None = None
    if want_scapy:
        from mtk_router_sdk.net.lan_scapy import parse_extra_scapy_cidrs, scapy_arp_sweep
        from mtk_router_sdk.net.lan_subnets import local_ipv4_lan_networks

        try:
            sc_to = float(os.environ.get("MTK_LAN_SCAPY_TIMEOUT", "2.5") or "2.5")
        except ValueError:
            sc_to = 2.5
        try:
            sc_max_n = int(os.environ.get("MTK_LAN_SCAPY_MAX_NETS", "4") or "4")
        except ValueError:
            sc_max_n = 4

        nets_for_scapy = list(local_ipv4_lan_networks(min_prefix_len=8, max_prefix_len=30))
        extra_nets = parse_extra_scapy_cidrs(os.environ.get("MTK_LAN_SCAPY_CIDRS", ""))
        seen_net: set[str] = set()
        merged_scapy: list[tuple[str | None, ipaddress.IPv4Network]] = []
        for row in extra_nets + nets_for_scapy:
            k = str(row[1])
            if k in seen_net:
                continue
            seen_net.add(k)
            merged_scapy.append(row)

        res = scapy_arp_sweep(merged_scapy, timeout=sc_to, max_networks=sc_max_n)
        scapy_note = res.get("note")
        for p in res["peers"]:
            cur = by_ip.get(p.ip)
            if cur is None:
                by_ip[p.ip] = p
                scapy_added += 1
            elif not cur.mac and p.mac:
                by_ip[p.ip] = HostLanPeer(
                    ip=p.ip,
                    mac=p.mac,
                    interface=cur.interface or p.interface,
                    source="scapy_arp",
                )
                scapy_added += 1
        if scapy_added:
            src_key = f"{src_key}+scapy"

    ordered = tuple(sorted(by_ip.values(), key=lambda x: ipaddress.ip_address(x.ip)))
    extra = ""
    if icmp_added:
        extra += f" Added {icmp_added} host(s) via ICMP sweep on local subnets."
    if scapy_added:
        extra += f" Added {scapy_added} host(s) via Scapy L2 ARP."
    if want_scapy and scapy_note == "scapy_not_installed":
        extra += (
            " Scapy not installed — run: pip install 'mtk-router-sdk[lan-scan]' "
            "(often needs root for srp)."
        )
    elif want_scapy and isinstance(scapy_note, str) and scapy_note.startswith("scapy_srp_error"):
        tail = scapy_note.split(":", 1)[-1].strip()
        if tail:
            extra += f" Scapy srp: {tail[:180]}."
    return HostLanScan(peers=ordered, scan_source=src_key, hint=base_hint + extra)


def host_peers_as_dashboard_devices(scan: HostLanScan) -> list[dict[str, object]]:
    """Shape peers like ``_lan_devices_payload`` entries for the testing dashboard."""

    devices: list[dict[str, object]] = []
    for p in scan.peers:
        iface = p.interface or "LAN"
        if p.source == "icmp_echo":
            tag = "ICMP (vendor-agnostic)"
            origin = "host_neighbor"
        elif p.source == "scapy_arp":
            tag = "Scapy L2 ARP (any router)"
            origin = "host_neighbor"
        else:
            tag = "host ARP (not router DHCP)"
            origin = "host_neighbor"
        devices.append(
            {
                "ip": p.ip,
                "hostname": None,
                "mac_address": p.mac,
                "status": "alive" if p.source == "icmp_echo" else None,
                "dhcp_server": None,
                "flags": None,
                "device_type": "lan_probe",
                "origin": origin,
                "interface": iface,
                "label": f"{p.ip} — {iface} · {tag}",
            }
        )
    return devices
