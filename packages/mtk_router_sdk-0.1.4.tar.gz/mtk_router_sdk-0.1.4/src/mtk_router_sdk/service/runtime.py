"""Process-wide service state (one ``mtk-serve`` per process)."""

from __future__ import annotations

from mtk_router_sdk.service.state import ServiceState

_svc: ServiceState | None = None


def bind_service_state(st: ServiceState) -> None:
    global _svc
    _svc = st


def get_service_state() -> ServiceState:
    if _svc is None:
        raise RuntimeError("service state not bound (create_app not called?)")
    return _svc
