"""Process-wide HTTP service state."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any

from mtk_router_sdk.config.schema import SiteConfig
from mtk_router_sdk.control.leases import LockMode, SlotLeaseManager
from mtk_router_sdk.discovery.models import RouterCapabilityProfile
from mtk_router_sdk.exceptions import ConfigurationError
from mtk_router_sdk.models import ConnectionConfig


@dataclass
class ServiceState:
    """Shared across Starlette routes (thread-safe lease manager)."""

    leases: SlotLeaseManager
    cached_profile: RouterCapabilityProfile | None = None
    site: SiteConfig | None = None
    session_connection: ConnectionConfig | None = None
    stream_clients: set[Any] = field(default_factory=set)

    @classmethod
    def create_default(cls) -> ServiceState:
        mode: LockMode = (
            "fifo_queue"
            if os.environ.get("MTK_SLOT_LOCK_MODE", "").strip().lower() == "fifo_queue"
            else "reject"
        )
        return cls(leases=SlotLeaseManager(mode=mode))


def load_site_from_env() -> SiteConfig | None:
    path = os.environ.get("MTK_SITE_CONFIG", "").strip()
    if not path:
        return None
    from mtk_router_sdk.config import load_site_config_from_path

    try:
        return load_site_config_from_path(path)
    except (OSError, ConfigurationError):
        return None
