"""Aggregate router data for ``GET /v1/dashboard/snapshot``."""

from __future__ import annotations

from typing import Any

from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.client_resolve import infer_slot_for_lease_ip
from mtk_router_sdk.config.schema import SiteConfig
from mtk_router_sdk.discovery.models import RouterCapabilityProfile
from mtk_router_sdk.parsing import parse_terse_lines


def _try_terse(client: RouterClient, path: str, *, timeout: float = 45.0) -> list[dict[str, Any]]:
    r = client.exec_command(f"{path} print terse", timeout=timeout, get_pty=False)
    if not r.ok:
        return []
    return parse_terse_lines(r.stdout)


def dhcp_lease_rows_from_router(
    client: RouterClient, *, timeout: float = 60.0
) -> list[dict[str, Any]]:
    r = client.exec_command("/ip dhcp-server lease print terse", timeout=timeout)
    if not r.ok:
        return []
    return parse_terse_lines(r.stdout)


def build_dashboard_snapshot(
    client: RouterClient,
    *,
    profile: RouterCapabilityProfile,
    site: SiteConfig | None,
    timeout: float = 60.0,
) -> dict[str, Any]:
    w = _try_terse(client, "/interface wireless", timeout=timeout)
    if not w:
        w = _try_terse(client, "/interface wifi", timeout=timeout)
    vpn = _try_terse(client, "/interface l2tp-client", timeout=timeout)
    routes = _try_terse(client, "/ip route", timeout=timeout)
    policy = [
        r
        for r in routes
        if str(r.get("routing-mark", "")).strip()
        and str(r.get("routing-mark", "")).strip().startswith("rt_slot_")
    ]
    leases: list[dict[str, Any]] = []
    for row in dhcp_lease_rows_from_router(client, timeout=timeout):
        addr = str(row.get("address", row.get("active-address", ""))).strip()
        leases.append(
            {
                **row,
                "slot_id": infer_slot_for_lease_ip(addr, site),
            },
        )
    slots_out: list[dict[str, Any]] = []
    if site:
        for s in site.enabled_slots:
            slots_out.append(
                {
                    "id": s.id,
                    "enabled": s.enabled,
                    "ssid": s.ssid,
                    "region": s.region,
                    "tunnel_name": s.tunnel_name,
                    "routing_mark": s.routing_mark or f"rt_slot_{s.id}",
                    "subnet": s.subnet,
                },
            )
    return {
        "profile": profile.as_dict(),
        "wireless": w,
        "vpn": vpn,
        "dhcp_leases": leases,
        "routing_policy": policy,
        "slots": slots_out,
    }
