"""REST ``/v1/*`` handlers (spec §6.2 subset + extensions)."""

from __future__ import annotations

import ipaddress
import json
import os
from collections.abc import Callable
from typing import Any, TypeVar

import anyio
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route, WebSocketRoute
from starlette.websockets import WebSocket

from mtk_router_sdk import __version__
from mtk_router_sdk.bootstrap import BootstrapEngine
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.client_resolve import (
    ClientSlotResolution,
    infer_slot_for_lease_ip,
    resolve_client_slot,
)
from mtk_router_sdk.config import load_site_config
from mtk_router_sdk.config.env import connection_config_from_merged
from mtk_router_sdk.config.schema import SiteConfig
from mtk_router_sdk.control.leases import LeaseConflictError
from mtk_router_sdk.exceptions import ConfigurationError, MtkRouterError
from mtk_router_sdk.intent.runner import (
    IntentExecutionError,
    enabled_slot_by_ssid,
    routing_mark_for_slot,
    run_intents,
)
from mtk_router_sdk.models import ConnectionConfig
from mtk_router_sdk.net.host_neighbors import (
    host_peers_as_dashboard_devices,
    scan_host_lan_peers,
)
from mtk_router_sdk.ops.client_block import (
    block_client,
    is_client_blocked,
    list_blocked_clients,
    unblock_client,
)
from mtk_router_sdk.ops.slot_route import update_policy_route_gateway
from mtk_router_sdk.ops.sniffer import (
    SnifferValidationError,
    capture_interface_for_slot,
    capture_interface_for_ssid,
    default_capture_filename,
    is_ipv4,
    sniffer_print,
    validate_capture_filename,
)
from mtk_router_sdk.ops.sniffer import (
    sniffer_start as ros_sniffer_start,
)
from mtk_router_sdk.ops.sniffer import (
    sniffer_stop as ros_sniffer_stop,
)
from mtk_router_sdk.ops.vpn_checkpoint import build_vpn_checkpoint, read_slot_vpn_checkpoint
from mtk_router_sdk.service.runtime import get_service_state
from mtk_router_sdk.service.snapshot import (
    build_dashboard_snapshot,
    dhcp_lease_rows_from_router,
)
from mtk_router_sdk.service.state import ServiceState, load_site_from_env

_MSG_NEED_CLIENT_IP = (
    "client_ip in JSON, ?client_ip=, or trusted X-Forwarded-For / TCP peer required"
)


def _j(data: dict[str, Any], status: int = 200) -> JSONResponse:
    return JSONResponse(data, status_code=status)


def _state(_request: Request) -> ServiceState:
    return get_service_state()


def _effective_cfg(state: ServiceState) -> ConnectionConfig:
    if state.session_connection is not None:
        return state.session_connection
    return connection_config_from_merged(
        state.site,
        require_password=True,
        exit_on_missing_password=False,
    )


_T = TypeVar("_T")


def _trust_x_forwarded_for() -> bool:
    v = os.environ.get("MTK_TRUST_X_FORWARDED_FOR", "").strip().lower()
    return v in ("1", "true", "yes")


def _literal_client_ip(raw: str) -> str | None:
    """Return *raw* if it is a usable IPv4/IPv6 literal (optional /prefix on the host part)."""

    s = raw.strip()
    if not s:
        return None
    host = s.split("/", 1)[0].strip()
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1].strip()
    try:
        ipaddress.ip_address(host)
    except ValueError:
        return None
    return s


def _client_ip_from_request(request: Request, body: dict[str, Any] | None = None) -> str | None:
    if body:
        cj = str(body.get("client_ip", "")).strip()
        if cj:
            lit = _literal_client_ip(cj)
            if lit:
                return lit
    q = request.query_params.get("client_ip", "").strip()
    if q:
        lit = _literal_client_ip(q)
        if lit:
            return lit
    if _trust_x_forwarded_for():
        xff = request.headers.get("x-forwarded-for", "")
        first = xff.split(",")[0].strip()
        if first:
            lit = _literal_client_ip(first)
            if lit:
                return lit
    if request.client and request.client.host:
        raw = str(request.client.host).strip()
        lit = _literal_client_ip(raw)
        if lit:
            return lit
        return raw or None
    return None


def _apply_slot_vpn_with_checkpoint(
    client: RouterClient,
    site: SiteConfig,
    slot_id: int,
    gateway_interface: str,
) -> dict[str, Any]:
    """Run policy-route update and return structured validation for the user/UI."""

    mark = routing_mark_for_slot(site, slot_id)
    gw = gateway_interface.strip()
    r = update_policy_route_gateway(
        client,
        routing_mark=mark,
        gateway_interface=gw,
    )
    if not r.ok:
        raise MtkRouterError(r.stderr or r.stdout or "route update failed")
    checkpoint = build_vpn_checkpoint(client, site, slot_id, mark, gw)
    return {
        "ok": True,
        "slot_id": slot_id,
        "gateway_interface": gw,
        "checkpoint": checkpoint,
    }


def _sync_resolve_client_slot(st: ServiceState, site: SiteConfig, ip: str) -> ClientSlotResolution:
    """Subnet match without SSH; otherwise fetch DHCP leases from the router."""

    if infer_slot_for_lease_ip(ip, site) is not None:
        return resolve_client_slot(site, ip, dhcp_rows=None, env=dict(os.environ))

    def inner(c: RouterClient) -> ClientSlotResolution:
        rows = dhcp_lease_rows_from_router(c)
        return resolve_client_slot(site, ip, dhcp_rows=rows, env=dict(os.environ))

    return _with_client(st, inner)


def _with_client(
    state: ServiceState,
    fn: Callable[[RouterClient], _T],
    *,
    timeout: float = 120.0,
) -> _T:
    cfg = _effective_cfg(state)
    c = RouterClient.with_ssh()
    c.connect(cfg)
    try:
        return fn(c)
    finally:
        c.disconnect()


async def _broadcast(_app: Any, msg: dict[str, Any]) -> None:
    st: ServiceState = get_service_state()
    dead: list[WebSocket] = []
    for ws in list(st.stream_clients):
        try:
            await ws.send_text(json.dumps(msg))
        except Exception:
            dead.append(ws)
    for ws in dead:
        st.stream_clients.discard(ws)


async def readyz(request: Request) -> Response:
    def sync() -> bool:
        st = _state(request)
        try:
            _with_client(st, lambda c: c.discover(), timeout=25.0)
            return True
        except (MtkRouterError, ConfigurationError, OSError, TimeoutError):
            return False

    ok = await anyio.to_thread.run_sync(sync)
    return _j({"ready": ok}, 200 if ok else 503)


async def session_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    host = str(body.get("host", "")).strip()
    user = str(body.get("username", body.get("user", "admin"))).strip()
    password = str(body.get("password", ""))
    port = int(body.get("port", 22))
    if not host or not password:
        return _j({"detail": "host and password required"}, 400)
    st = _state(request)
    st.session_connection = ConnectionConfig(
        host=host,
        username=user,
        password=password,
        port=port,
        timeout=float(body.get("timeout", 30.0)),
    )

    def sync() -> dict[str, Any]:
        return _with_client(st, lambda c: c.discover().as_dict())

    try:
        prof = await anyio.to_thread.run_sync(sync)
    except (MtkRouterError, ConfigurationError, OSError) as e:
        st.session_connection = None
        return _j({"ok": False, "error": str(getattr(e, "message", e))}, 502)
    return _j({"ok": True, "profile": prof})


async def session_delete(_request: Request) -> Response:
    _state(_request).session_connection = None
    return _j({"ok": True})


async def discovery_profile(request: Request) -> Response:
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            p = c.discover()
            st.cached_profile = p
            return p.as_dict()

        return _with_client(st, inner)

    try:
        d = await anyio.to_thread.run_sync(sync)
        return _j(d)
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def discovery_refresh(request: Request) -> Response:
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            p = c.discover()
            st.cached_profile = p
            return p.as_dict()

        return _with_client(st, inner)

    try:
        d = await anyio.to_thread.run_sync(sync)
        await _broadcast(request.app, {"type": "discovery_refreshed", "version": __version__})
        return _j({"ok": True, "profile": d})
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"ok": False, "error": str(getattr(e, "message", e))}, 503)


async def dashboard_snapshot(request: Request) -> Response:
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            prof = c.discover()
            st.cached_profile = prof
            return build_dashboard_snapshot(c, profile=prof, site=st.site)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def capabilities_get(request: Request) -> Response:
    """Feature matrix for UIs: which operations need RouterOS SSH vs host-only."""

    from mtk_router_sdk.service.capabilities import build_capabilities_payload

    st = _state(request)
    return _j(build_capabilities_payload(st, sdk_version=__version__))


async def lan_host_peers_get(_request: Request) -> Response:
    """IPv4 neighbours from the mtk-serve host (ARP); not RouterOS DHCP."""

    scan = scan_host_lan_peers()
    peers_json = [
        {"ip": p.ip, "mac": p.mac, "interface": p.interface, "source": p.source} for p in scan.peers
    ]
    return _j(
        {
            "source": scan.scan_source,
            "hint": scan.hint,
            "peers": peers_json,
            "dashboard_devices": host_peers_as_dashboard_devices(scan),
        }
    )


async def wireless_table(request: Request) -> Response:
    st = _state(request)

    def sync() -> list[dict[str, Any]]:
        def inner(c: RouterClient) -> list[dict[str, Any]]:
            try:
                return c.exec_print_terse("/interface wireless")
            except MtkRouterError:
                return c.exec_print_terse("/interface wifi")

        return _with_client(st, inner)

    try:
        return _j({"rows": await anyio.to_thread.run_sync(sync)})
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def vpn_clients(request: Request) -> Response:
    st = _state(request)

    def sync() -> list[dict[str, Any]]:
        return _with_client(st, lambda c: c.exec_print_terse("/interface l2tp-client"))

    try:
        return _j({"rows": await anyio.to_thread.run_sync(sync)})
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def dhcp_leases(request: Request) -> Response:
    st = _state(request)
    slot_q = request.query_params.get("slot_id")

    def sync() -> list[dict[str, Any]]:
        from mtk_router_sdk.parsing import parse_terse_lines

        def inner(c: RouterClient) -> list[dict[str, Any]]:
            r = c.exec_command("/ip dhcp-server lease print terse", timeout=60.0)
            if not r.ok:
                return []
            rows = parse_terse_lines(r.stdout)
            if slot_q and st.site:
                sid = int(slot_q)
                out = []
                for row in rows:
                    addr = str(row.get("address", row.get("active-address", ""))).strip()
                    if infer_slot_for_lease_ip(addr, st.site) == sid:
                        out.append(row)
                return out
            return rows

        return _with_client(st, inner)

    try:
        return _j({"rows": await anyio.to_thread.run_sync(sync)})
    except (MtkRouterError, ConfigurationError, OSError, ValueError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def routing_policy(request: Request) -> Response:
    st = _state(request)

    def sync() -> list[dict[str, Any]]:
        def inner(c: RouterClient) -> list[dict[str, Any]]:
            rows = c.exec_print_terse("/ip route")
            return [
                r
                for r in rows
                if str(r.get("routing-mark", "")).strip().startswith("rt_slot_")
            ]

        return _with_client(st, inner)

    try:
        return _j({"rows": await anyio.to_thread.run_sync(sync)})
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 503)


async def config_get(_request: Request) -> Response:
    return _j(
        {
            "version": __version__,
            "mtk_site_config": os.environ.get("MTK_SITE_CONFIG", ""),
            "slot_lock_mode": os.environ.get("MTK_SLOT_LOCK_MODE", "reject"),
        },
    )


async def config_slots_get(request: Request) -> Response:
    st = _state(request)
    if st.site is None:
        return _j({"site": None, "hint": "set MTK_SITE_CONFIG or PUT /v1/config/slots"})
    return _j(
        {
            "version": st.site.version,
            "bootstrap": {"provision_tunnels": st.site.bootstrap.provision_tunnels},
            "vpn_registry": dict(st.site.vpn_registry),
            "slots": [
                {
                    "id": s.id,
                    "enabled": s.enabled,
                    "ssid": s.ssid,
                    "region": s.region,
                    "tunnel_name": s.tunnel_name,
                    "subnet": s.subnet,
                }
                for s in st.site.slots
            ],
        },
    )


async def config_slots_put(request: Request) -> Response:
    try:
        raw = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    try:
        site = load_site_config(raw, env=dict(os.environ))
    except ConfigurationError as e:
        return _j({"detail": e.message, "hint": e.hint}, 400)
    _state(request).site = site
    return _j({"ok": True, "slots": len(site.slots)})


async def config_patch(_request: Request) -> Response:
    return _j({"detail": "PATCH /v1/config partial merge not implemented"}, 501)


async def bootstrap_dry_run(request: Request) -> Response:
    st = _state(request)
    site = st.site
    if site is None:
        return _j({"detail": "no site loaded"}, 400)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            prof = c.discover()
            plan = BootstrapEngine().plan(site, prof, env=dict(os.environ))
            return {"ok": True, "plan": plan.as_dict()}

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"ok": False, "error": str(getattr(e, "message", e))}, 503)


async def bootstrap_apply(request: Request) -> Response:
    st = _state(request)
    site = st.site
    if site is None:
        return _j({"detail": "no site loaded"}, 400)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            prof = c.discover()
            plan = BootstrapEngine().plan(site, prof, env=dict(os.environ))
            BootstrapEngine.apply(c, plan, dry_run=False)
            return {"steps": len(plan.steps)}

        return _with_client(st, inner)

    try:
        r = await anyio.to_thread.run_sync(sync)
        await _broadcast(request.app, {"type": "bootstrap_applied", **r})
        return _j({"ok": True, **r})
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"ok": False, "error": str(getattr(e, "message", e))}, 503)


async def lease_post(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    actor = str(body.get("actor", "anonymous")).strip() or "anonymous"
    ttl_s = float(body.get("ttl_s", body.get("ttlS", 120.0)))
    try:
        out = _state(request).leases.acquire(slot_id, actor, ttl_s)
        return _j(out)
    except LeaseConflictError as e:
        return _j(
            {
                "detail": str(e),
                "holder": e.holder,
                "expires_at": e.expires_at,
                "retry_after_s": e.retry_after_s,
            },
            409,
        )


async def lease_delete(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    ok = _state(request).leases.release(slot_id, token)
    return _j({"ok": ok}, 200 if ok else 403)


async def control_status(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    return _j(_state(request).leases.status(slot_id))


async def slot_vpn_post(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    mode = str(body.get("mode", "route"))
    if mode != "route":
        return _j({"detail": "only mode=route supported"}, 400)
    gw = str(body.get("gateway_interface", "")).strip()
    if not gw:
        return _j({"detail": "gateway_interface required"}, 400)
    if st.site is None:
        return _j({"detail": "site config required for routing mark"}, 400)
    site = st.site

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            return _apply_slot_vpn_with_checkpoint(c, site, slot_id, gw)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def slot_vpn_status_get(request: Request) -> Response:
    """Read-only VPN checkpoint for a slot (policy route + L2TP); no lease."""

    slot_id = int(request.path_params["slot_id"])
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    try:
        mark = routing_mark_for_slot(site, slot_id)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            cp = read_slot_vpn_checkpoint(c, site, slot_id, mark)
            gw = str(cp.get("gateway_interface") or "")
            return {
                "ok": True,
                "slot_id": slot_id,
                "gateway_interface": gw,
                "checkpoint": cp,
            }

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def slot_provision_post(_request: Request) -> Response:
    return _j({"detail": "Use POST /v1/bootstrap or mtk bootstrap --apply"}, 501)


async def slot_delete(_request: Request) -> Response:
    return _j({"detail": "Tear-down not implemented (safety)"}, 501)


async def sniffer_start(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    if st.site is None:
        return _j({"detail": "site config required for slot interface"}, 400)
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    filter_ip = str(body.get("filter_ip_address", "")).strip()
    if not filter_ip or not is_ipv4(filter_ip):
        return _j({"detail": "filter_ip_address must be a dotted IPv4 address"}, 400)

    raw_name = body.get("file_name")
    try:
        if raw_name is not None and str(raw_name).strip():
            file_name = validate_capture_filename(str(raw_name).strip())
        else:
            file_name = default_capture_filename(slot_id, filter_ip)
    except SnifferValidationError as e:
        return _j({"detail": str(e)}, 400)

    only_headers = bool(body.get("only_headers", False))
    mem = body.get("memory_limit", "100MiB")
    memory_limit = str(mem).strip() if mem is not None else None

    iface = capture_interface_for_slot(st.site, slot_id)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            try:
                r_last, snap = ros_sniffer_start(
                    c,
                    interface=iface,
                    filter_ip=filter_ip,
                    file_name=file_name,
                    only_headers=only_headers,
                    memory_limit=memory_limit or None,
                )
            except SnifferValidationError as e:
                raise IntentExecutionError(str(e), status_code=400) from e
            if not r_last.ok:
                raise MtkRouterError(r_last.stderr or r_last.stdout or "sniffer start failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                "interface": iface,
                "filter_ip_address": filter_ip,
                "file_name": file_name,
                "only_headers": only_headers,
                "sniffer": snap,
                "hint": (
                    "Capture is written on the router (Files). "
                    "Download the .pcap via WebFig, FTP, or SCP; "
                    "see docs/COMPLIANCE_AND_PRIVACY.md."
                ),
            }

        return _with_client(st, inner)

    try:
        data = await anyio.to_thread.run_sync(sync)
        return _j(data)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def sniffer_stop(request: Request) -> Response:
    slot_id = int(request.path_params["slot_id"])
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            r = ros_sniffer_stop(c)
            snap = sniffer_print(c)
            if not r.ok:
                raise MtkRouterError(r.stderr or r.stdout or "sniffer stop failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                "sniffer": snap,
                "hint": (
                    "If file-name was set, the .pcap remains on the router until you delete it."
                ),
            }

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def client_resolve_get(request: Request) -> Response:
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    ip = _client_ip_from_request(request, None)
    if not ip:
        return _j(
            {
                "detail": (
                    "could not determine client IP; use ?client_ip=, "
                    "set MTK_TRUST_X_FORWARDED_FOR=1 with X-Forwarded-For, "
                    "or call from a client whose TCP peer is the LAN device."
                ),
            },
            400,
        )
    site = st.site

    def resolve_local() -> dict[str, Any]:
        ctx = resolve_client_slot(site, ip, dhcp_rows=None, env=dict(os.environ))
        return ctx.as_dict()

    try:
        if infer_slot_for_lease_ip(ip, site) is not None:
            data = resolve_local()
            data["hint"] = (
                "Matched slot subnet from site JSON. SSID names the policy slot; "
                "Ethernet and Wi‑Fi on the same bridge share this mapping."
            )
            return _j(data)

        def sync() -> dict[str, Any]:
            def inner(c: RouterClient) -> dict[str, Any]:
                rows = dhcp_lease_rows_from_router(c)
                ctx = resolve_client_slot(site, ip, dhcp_rows=rows, env=dict(os.environ))
                return ctx.as_dict()

            return _with_client(st, inner)

        data = await anyio.to_thread.run_sync(sync)
        if not data.get("resolved"):
            data["hint"] = (
                "Set slots[].subnet, use DHCP server names dhcp_<slot_id> "
                "(bootstrap default), or set global.client_fallback_slot_id / "
                "MTK_CLIENT_FALLBACK_SLOT_ID."
            )
        return _j(data)
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def lease_by_client_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    ip = _client_ip_from_request(request, body)
    if not ip:
        return _j(
            {"detail": _MSG_NEED_CLIENT_IP},
            400,
        )
    actor = str(body.get("actor", "anonymous")).strip() or "anonymous"
    ttl_s = float(body.get("ttl_s", body.get("ttlS", 120.0)))

    try:
        ctx = await anyio.to_thread.run_sync(lambda: _sync_resolve_client_slot(st, site, ip))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)
    if not ctx.resolved or ctx.slot_id is None:
        return _j(
            {"detail": "client IP could not be mapped to an enabled slot", **ctx.as_dict()},
            400,
        )
    slot_id = ctx.slot_id
    try:
        out = dict(st.leases.acquire(slot_id, actor, ttl_s))
        out.update(ctx.as_dict())
        return _j(out)
    except LeaseConflictError as e:
        return _j(
            {
                "detail": str(e),
                "holder": e.holder,
                "expires_at": e.expires_at,
                "retry_after_s": e.retry_after_s,
            },
            409,
        )


async def lease_release_by_client_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    token = str(body.get("lease_token", "")).strip()
    if not token:
        return _j({"detail": "lease_token required"}, 400)
    st = _state(request)
    ok = st.leases.release_by_token(token)
    return _j({"ok": ok}, 200 if ok else 403)


async def by_client_vpn_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    ip = _client_ip_from_request(request, body)
    if not ip:
        return _j(
            {"detail": _MSG_NEED_CLIENT_IP},
            400,
        )

    try:
        ctx = await anyio.to_thread.run_sync(lambda: _sync_resolve_client_slot(st, site, ip))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)
    if not ctx.resolved or ctx.slot_id is None:
        return _j(
            {"detail": "client IP could not be mapped to an enabled slot", **ctx.as_dict()},
            400,
        )
    slot_id = int(ctx.slot_id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    mode = str(body.get("mode", "route"))
    if mode != "route":
        return _j({"detail": "only mode=route supported"}, 400)
    gw = str(body.get("gateway_interface", "")).strip()
    if not gw:
        return _j({"detail": "gateway_interface required"}, 400)
    ctx_dict = ctx.as_dict()

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            base = _apply_slot_vpn_with_checkpoint(c, site, slot_id, gw)
            base.update(ctx_dict)
            return base

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def by_client_sniffer_start(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    ip = _client_ip_from_request(request, body)
    if not ip:
        return _j(
            {"detail": _MSG_NEED_CLIENT_IP},
            400,
        )

    try:
        ctx = await anyio.to_thread.run_sync(lambda: _sync_resolve_client_slot(st, site, ip))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)
    if not ctx.resolved or ctx.slot_id is None:
        return _j(
            {"detail": "client IP could not be mapped to an enabled slot", **ctx.as_dict()},
            400,
        )
    slot_id = int(ctx.slot_id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    filter_ip = str(body.get("filter_ip_address", "")).strip()
    if not filter_ip or not is_ipv4(filter_ip):
        return _j({"detail": "filter_ip_address must be a dotted IPv4 address"}, 400)
    raw_name = body.get("file_name")
    try:
        if raw_name is not None and str(raw_name).strip():
            file_name = validate_capture_filename(str(raw_name).strip())
        else:
            file_name = default_capture_filename(slot_id, filter_ip)
    except SnifferValidationError as e:
        return _j({"detail": str(e)}, 400)
    only_headers = bool(body.get("only_headers", False))
    mem = body.get("memory_limit", "100MiB")
    memory_limit = str(mem).strip() if mem is not None else None
    iface = capture_interface_for_slot(st.site, slot_id)
    ctx_dict = ctx.as_dict()

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            try:
                r_last, snap = ros_sniffer_start(
                    c,
                    interface=iface,
                    filter_ip=filter_ip,
                    file_name=file_name,
                    only_headers=only_headers,
                    memory_limit=memory_limit or None,
                )
            except SnifferValidationError as e:
                raise IntentExecutionError(str(e), status_code=400) from e
            if not r_last.ok:
                raise MtkRouterError(r_last.stderr or r_last.stdout or "sniffer start failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                **ctx_dict,
                "interface": iface,
                "filter_ip_address": filter_ip,
                "file_name": file_name,
                "only_headers": only_headers,
                "sniffer": snap,
                "hint": (
                    "Capture is written on the router (Files). "
                    "Download the .pcap via WebFig, FTP, or SCP; "
                    "see docs/COMPLIANCE_AND_PRIVACY.md."
                ),
            }

        return _with_client(st, inner)

    try:
        data = await anyio.to_thread.run_sync(sync)
        return _j(data)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def by_client_sniffer_stop(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    ip = _client_ip_from_request(request, body)
    if not ip:
        return _j(
            {"detail": _MSG_NEED_CLIENT_IP},
            400,
        )

    try:
        ctx = await anyio.to_thread.run_sync(lambda: _sync_resolve_client_slot(st, site, ip))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)
    if not ctx.resolved or ctx.slot_id is None:
        return _j(
            {"detail": "client IP could not be mapped to an enabled slot", **ctx.as_dict()},
            400,
        )
    slot_id = int(ctx.slot_id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    ctx_dict = ctx.as_dict()

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            r = ros_sniffer_stop(c)
            snap = sniffer_print(c)
            if not r.ok:
                raise MtkRouterError(r.stderr or r.stdout or "sniffer stop failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                **ctx_dict,
                "sniffer": snap,
                "hint": (
                    "If file-name was set, the .pcap remains on the router until you delete it."
                ),
            }

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def lease_by_ssid_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ssid = str(body.get("ssid", "")).strip()
    if not ssid:
        return _j({"detail": "ssid required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    try:
        slot = enabled_slot_by_ssid(st.site, ssid)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    slot_id = int(slot.id)
    actor = str(body.get("actor", "anonymous")).strip() or "anonymous"
    ttl_s = float(body.get("ttl_s", body.get("ttlS", 120.0)))
    try:
        out = dict(st.leases.acquire(slot_id, actor, ttl_s))
        out["ssid"] = ssid
        return _j(out)
    except LeaseConflictError as e:
        return _j(
            {
                "detail": str(e),
                "holder": e.holder,
                "expires_at": e.expires_at,
                "retry_after_s": e.retry_after_s,
            },
            409,
        )


async def lease_release_by_ssid_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ssid = str(body.get("ssid", "")).strip()
    token = str(body.get("lease_token", "")).strip()
    if not ssid or not token:
        return _j({"detail": "ssid and lease_token required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    try:
        slot = enabled_slot_by_ssid(st.site, ssid)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    ok = st.leases.release(int(slot.id), token)
    return _j({"ok": ok}, 200 if ok else 403)


async def by_ssid_vpn_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ssid = str(body.get("ssid", "")).strip()
    if not ssid:
        return _j({"detail": "ssid required"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    site = st.site
    try:
        slot = enabled_slot_by_ssid(site, ssid)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    slot_id = int(slot.id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    mode = str(body.get("mode", "route"))
    if mode != "route":
        return _j({"detail": "only mode=route supported"}, 400)
    gw = str(body.get("gateway_interface", "")).strip()
    if not gw:
        return _j({"detail": "gateway_interface required"}, 400)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            base = _apply_slot_vpn_with_checkpoint(c, site, slot_id, gw)
            base["ssid"] = ssid
            return base

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def by_ssid_sniffer_start(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ssid = str(body.get("ssid", "")).strip()
    if not ssid:
        return _j({"detail": "ssid required"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    try:
        slot = enabled_slot_by_ssid(st.site, ssid)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    slot_id = int(slot.id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)
    filter_ip = str(body.get("filter_ip_address", "")).strip()
    if not filter_ip or not is_ipv4(filter_ip):
        return _j({"detail": "filter_ip_address must be a dotted IPv4 address"}, 400)
    raw_name = body.get("file_name")
    try:
        if raw_name is not None and str(raw_name).strip():
            file_name = validate_capture_filename(str(raw_name).strip())
        else:
            file_name = default_capture_filename(slot_id, filter_ip)
    except SnifferValidationError as e:
        return _j({"detail": str(e)}, 400)
    only_headers = bool(body.get("only_headers", False))
    mem = body.get("memory_limit", "100MiB")
    memory_limit = str(mem).strip() if mem is not None else None
    iface = capture_interface_for_ssid(st.site, ssid)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            try:
                r_last, snap = ros_sniffer_start(
                    c,
                    interface=iface,
                    filter_ip=filter_ip,
                    file_name=file_name,
                    only_headers=only_headers,
                    memory_limit=memory_limit or None,
                )
            except SnifferValidationError as e:
                raise IntentExecutionError(str(e), status_code=400) from e
            if not r_last.ok:
                raise MtkRouterError(r_last.stderr or r_last.stdout or "sniffer start failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                "ssid": ssid,
                "interface": iface,
                "filter_ip_address": filter_ip,
                "file_name": file_name,
                "only_headers": only_headers,
                "sniffer": snap,
                "hint": (
                    "Capture is written on the router (Files). "
                    "Download the .pcap via WebFig, FTP, or SCP; "
                    "see docs/COMPLIANCE_AND_PRIVACY.md."
                ),
            }

        return _with_client(st, inner)

    try:
        data = await anyio.to_thread.run_sync(sync)
        return _j(data)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def by_ssid_sniffer_stop(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ssid = str(body.get("ssid", "")).strip()
    if not ssid:
        return _j({"detail": "ssid required"}, 400)
    token = request.headers.get("x-slot-lease", "").strip()
    if not token:
        return _j({"detail": "X-Slot-Lease header required"}, 400)
    st = _state(request)
    if st.site is None:
        return _j({"detail": "site config required"}, 400)
    try:
        slot = enabled_slot_by_ssid(st.site, ssid)
    except IntentExecutionError as e:
        return _j({"detail": str(e)}, e.status_code)
    slot_id = int(slot.id)
    if not st.leases.validate(slot_id, token):
        return _j({"detail": "invalid or expired lease"}, 403)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            r = ros_sniffer_stop(c)
            snap = sniffer_print(c)
            if not r.ok:
                raise MtkRouterError(r.stderr or r.stdout or "sniffer stop failed")
            return {
                "ok": True,
                "slot_id": slot_id,
                "ssid": ssid,
                "sniffer": snap,
                "hint": (
                    "If file-name was set, the .pcap remains on the router until you delete it."
                ),
            }

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


# --------------------------------------------------------------------------- #
# client-block: per-client internet block/unblock (firewall, runtime only)   #
# --------------------------------------------------------------------------- #


async def client_block_post(request: Request) -> Response:
    """POST /v1/client/block - block internet for a client IP."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ip = str(body.get("ip", "")).strip()
    if not ip or not is_ipv4(ip):
        return _j({"detail": "valid IPv4 ip required"}, 400)
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            return block_client(c, ip)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def client_unblock_post(request: Request) -> Response:
    """POST /v1/client/unblock - remove internet block for a client IP."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    ip = str(body.get("ip", "")).strip()
    if not ip or not is_ipv4(ip):
        return _j({"detail": "valid IPv4 ip required"}, 400)
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            return unblock_client(c, ip)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def client_blocked_list(request: Request) -> Response:
    """GET /v1/client/blocked - list all blocked clients."""
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            return list_blocked_clients(c)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def client_blocked_status(request: Request) -> Response:
    """GET /v1/client/blocked/{ip} - check if a client IP is blocked."""
    ip = request.path_params.get("ip", "").strip()
    if not ip or not is_ipv4(ip):
        return _j({"detail": "valid IPv4 required in path"}, 400)
    st = _state(request)

    def sync() -> dict[str, Any]:
        def inner(c: RouterClient) -> dict[str, Any]:
            return is_client_blocked(c, ip)

        return _with_client(st, inner)

    try:
        return _j(await anyio.to_thread.run_sync(sync))
    except (MtkRouterError, OSError) as e:
        return _j({"error": str(getattr(e, "message", e))}, 502)


async def ai_intent_post(request: Request) -> Response:
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _j({"detail": "invalid JSON"}, 400)
    intents = body.get("intents")
    if not isinstance(intents, list):
        return _j({"detail": "intents array required"}, 400)
    actor = str(body.get("actor", "http")).strip() or "http"
    st = _state(request)

    def sync() -> list[dict[str, Any]]:
        def inner(c: RouterClient) -> list[dict[str, Any]]:
            return run_intents(
                intents,
                client=c,
                site=st.site,
                leases=st.leases,
                actor=actor,
            )

        return _with_client(st, inner)

    try:
        out = await anyio.to_thread.run_sync(sync)
        return _j({"ok": True, "results": out})
    except IntentExecutionError as e:
        return _j({"ok": False, "error": str(e)}, e.status_code)
    except (MtkRouterError, ConfigurationError, OSError) as e:
        return _j({"ok": False, "error": str(getattr(e, "message", e))}, 502)


async def stream_ws(websocket: WebSocket) -> None:
    await websocket.accept()
    st: ServiceState = get_service_state()
    st.stream_clients.add(websocket)
    try:
        await websocket.send_text(json.dumps({"type": "hello", "version": __version__}))
        while True:
            await websocket.receive_text()
    except Exception:
        pass
    finally:
        st.stream_clients.discard(websocket)


def v1_route_table() -> list[Route | WebSocketRoute]:
    return [
        Route("/readyz", endpoint=readyz, methods=["GET"]),
        Route("/v1/capabilities", endpoint=capabilities_get, methods=["GET"]),
        Route("/v1/lan/host-peers", endpoint=lan_host_peers_get, methods=["GET"]),
        Route("/v1/session", endpoint=session_post, methods=["POST"]),
        Route("/v1/session", endpoint=session_delete, methods=["DELETE"]),
        Route("/v1/discovery/profile", endpoint=discovery_profile, methods=["GET"]),
        Route("/v1/discovery/refresh", endpoint=discovery_refresh, methods=["POST"]),
        Route("/v1/dashboard/snapshot", endpoint=dashboard_snapshot, methods=["GET"]),
        Route("/v1/wireless", endpoint=wireless_table, methods=["GET"]),
        Route("/v1/vpn/clients", endpoint=vpn_clients, methods=["GET"]),
        Route("/v1/dhcp/leases", endpoint=dhcp_leases, methods=["GET"]),
        Route("/v1/routing/policy", endpoint=routing_policy, methods=["GET"]),
        Route("/v1/config", endpoint=config_get, methods=["GET"]),
        Route("/v1/config", endpoint=config_patch, methods=["PATCH"]),
        Route("/v1/config/slots", endpoint=config_slots_get, methods=["GET"]),
        Route("/v1/config/slots", endpoint=config_slots_put, methods=["PUT"]),
        Route("/v1/bootstrap/dry-run", endpoint=bootstrap_dry_run, methods=["POST"]),
        Route("/v1/bootstrap", endpoint=bootstrap_apply, methods=["POST"]),
        Route(
            "/v1/slots/{slot_id:int}/control/lease",
            endpoint=lease_post,
            methods=["POST"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/control/lease",
            endpoint=lease_delete,
            methods=["DELETE"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/control/status",
            endpoint=control_status,
            methods=["GET"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/vpn/status",
            endpoint=slot_vpn_status_get,
            methods=["GET"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/vpn",
            endpoint=slot_vpn_post,
            methods=["POST"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/provision",
            endpoint=slot_provision_post,
            methods=["POST"],
        ),
        Route(
            "/v1/slots/{slot_id:int}",
            endpoint=slot_delete,
            methods=["DELETE"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/sniffer/start",
            endpoint=sniffer_start,
            methods=["POST"],
        ),
        Route(
            "/v1/slots/{slot_id:int}/sniffer/stop",
            endpoint=sniffer_stop,
            methods=["POST"],
        ),
        Route("/v1/client/resolve", endpoint=client_resolve_get, methods=["GET"]),
        Route(
            "/v1/by-client/control/lease",
            endpoint=lease_by_client_post,
            methods=["POST"],
        ),
        Route(
            "/v1/by-client/control/lease/release",
            endpoint=lease_release_by_client_post,
            methods=["POST"],
        ),
        Route("/v1/by-client/vpn", endpoint=by_client_vpn_post, methods=["POST"]),
        Route(
            "/v1/by-client/sniffer/start",
            endpoint=by_client_sniffer_start,
            methods=["POST"],
        ),
        Route(
            "/v1/by-client/sniffer/stop",
            endpoint=by_client_sniffer_stop,
            methods=["POST"],
        ),
        Route(
            "/v1/by-ssid/control/lease",
            endpoint=lease_by_ssid_post,
            methods=["POST"],
        ),
        Route(
            "/v1/by-ssid/control/lease/release",
            endpoint=lease_release_by_ssid_post,
            methods=["POST"],
        ),
        Route("/v1/by-ssid/vpn", endpoint=by_ssid_vpn_post, methods=["POST"]),
        Route(
            "/v1/by-ssid/sniffer/start",
            endpoint=by_ssid_sniffer_start,
            methods=["POST"],
        ),
        Route(
            "/v1/by-ssid/sniffer/stop",
            endpoint=by_ssid_sniffer_stop,
            methods=["POST"],
        ),
        Route("/v1/ai/intent", endpoint=ai_intent_post, methods=["POST"]),
        Route("/v1/client/block", endpoint=client_block_post, methods=["POST"]),
        Route("/v1/client/unblock", endpoint=client_unblock_post, methods=["POST"]),
        Route("/v1/client/blocked", endpoint=client_blocked_list, methods=["GET"]),
        Route("/v1/client/blocked/{ip:path}", endpoint=client_blocked_status, methods=["GET"]),
        WebSocketRoute("/v1/stream", endpoint=stream_ws),
    ]


def attach_service_state(app: Any) -> ServiceState:
    from mtk_router_sdk.service.runtime import bind_service_state

    st = ServiceState.create_default()
    st.site = load_site_from_env()
    app.state.mtk = st
    bind_service_state(st)
    return st
