"""HTTP service feature matrix: what works without RouterOS SSH vs what requires it."""

from __future__ import annotations

import os
from typing import Any

from mtk_router_sdk.config.env import connection_config_from_merged
from mtk_router_sdk.config.env_parse import parse_int_env
from mtk_router_sdk.exceptions import ConfigurationError
from mtk_router_sdk.service.state import ServiceState

MSG_ROUTER_SSH_REQUIRED = (
    "This operation requires MikroTik RouterOS over SSH. "
    "Set MTK_HOST, MTK_USER, and MTK_PASSWORD (or site connection with password), "
    "then confirm GET /readyz returns {\"ready\": true}."
)


def _ssh_credentials_complete(state: ServiceState) -> tuple[bool, str | None]:
    try:
        connection_config_from_merged(
            state.site,
            require_password=True,
            exit_on_missing_password=False,
        )
    except ConfigurationError as e:
        return False, e.message
    return True, None


def _forward_proxy_enabled() -> tuple[bool, int]:
    port = parse_int_env("MTK_PROXY_PORT", 8888, minimum=1, maximum=65535)
    off = os.environ.get("MTK_PROXY_ENABLED", "true").strip().lower() in (
        "0",
        "false",
        "no",
        "off",
    )
    return (not off, port)


def build_capabilities_payload(state: ServiceState, *, sdk_version: str) -> dict[str, Any]:
    """JSON for ``GET /v1/capabilities`` (fast; does not open SSH or run discovery)."""

    ok, err = _ssh_credentials_complete(state)
    proxy_on, proxy_port = _forward_proxy_enabled()

    def feat(requires_ssh: bool, summary: str) -> dict[str, Any]:
        blocked: str | None = None
        if requires_ssh and not ok:
            blocked = err or MSG_ROUTER_SSH_REQUIRED
        return {
            "summary": summary,
            "requires_router_ssh": requires_ssh,
            "blocked_without_router_ssh": bool(blocked),
            "blocked_reason": blocked,
        }

    specs: list[tuple[bool, str, str]] = [
        (True, "dashboard_snapshot", "Aggregated wireless, VPN, DHCP, routes from the router"),
        (True, "discovery", "Router capability profile over SSH"),
        (True, "bootstrap", "Apply or dry-run bootstrap scripts on the router"),
        (True, "dhcp_leases", "DHCP lease table from RouterOS"),
        (True, "client_block", "Runtime firewall DROP on the router"),
        (True, "sniffer", "RouterOS /tool sniffer capture"),
        (True, "slot_vpn", "Policy-route gateway changes on the router"),
        (True, "network_simulator", "Queue / latency rules applied on the router"),
        (False, "lan_host_peers", "IPv4 neighbours from the mtk-serve host OS (ARP cache)"),
        (False, "proxy_forward", f"HTTP(S) forward proxy on TCP port {proxy_port}"),
        (False, "proxy_rest", "Configure proxy rules via /v1/proxy/* (in-process)"),
        (False, "health_openapi", "healthz, OpenAPI, version endpoints"),
    ]

    out_features: dict[str, Any] = {}
    for requires_ssh, key, summary in specs:
        out_features[key] = feat(requires_ssh, summary)

    return {
        "sdk_version": sdk_version,
        "router_ssh": {
            "credentials_complete": ok,
            "credentials_error": err,
            "reachable_hint": "Call GET /readyz to verify SSH discovery (not run here).",
        },
        "forward_proxy": {
            "enabled": proxy_on,
            "port": proxy_port,
        },
        "features": out_features,
        "messages": {
            "router_ssh_required": MSG_ROUTER_SSH_REQUIRED,
            "lan_host_peers_scope": (
                "LAN host peers: OS ARP plus optional bounded ICMP on local subnets "
                "(vendor-agnostic; not router APIs). May omit clients or be empty in Docker. "
                "Tune MTK_LAN_ICMP_* in ENVIRONMENT.md."
            ),
        },
    }
