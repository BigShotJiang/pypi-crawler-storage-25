"""Optional HTTP service (install ``mtk-router-sdk[service]``)."""
