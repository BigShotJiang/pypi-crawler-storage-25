from __future__ import annotations

import logging
import os
from typing import Any

from starlette.middleware.cors import CORSMiddleware

from mtk_router_sdk import __version__
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config.env import connection_config_from_merged
from mtk_router_sdk.config.env_parse import parse_int_env
from mtk_router_sdk.exceptions import ConfigurationError, MtkRouterError
from mtk_router_sdk.proxy.routes import init_proxy_state, proxy_route_table
from mtk_router_sdk.service.openapi_spec import build_openapi_spec
from mtk_router_sdk.service.v1_routes import attach_service_state, v1_route_table

logger = logging.getLogger(__name__)


def _json_response(data: dict[str, Any], status_code: int = 200) -> Any:
    from starlette.responses import JSONResponse

    return JSONResponse(data, status_code=status_code)


def _doctor_sync() -> dict[str, Any]:
    try:
        cfg = connection_config_from_merged(
            None,
            require_password=True,
            exit_on_missing_password=False,
        )
    except ConfigurationError as e:
        out: dict[str, Any] = {"ok": False, "error": e.message}
        if e.hint:
            out["hint"] = e.hint
        return out
    client = RouterClient.with_ssh()
    try:
        client.connect(cfg)
        profile = client.discover()
        return {
            "ok": True,
            "target": cfg.describe_target(),
            "profile": profile.as_dict(),
        }
    except MtkRouterError as e:
        body: dict[str, Any] = {
            "ok": False,
            "target": cfg.describe_target(),
            "error": e.message,
        }
        if e.hint:
            body["hint"] = e.hint
        return body
    finally:
        client.disconnect()


class _TokenAuthMiddleware:
    """Require ``Authorization: Bearer`` when ``MTK_SERVICE_TOKEN`` is set."""

    def __init__(self, app: Any, token: str | None) -> None:
        self.app = app
        self.token = token

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        path = scope.get("path", "")
        exempt = (
            path == "/healthz"
            or path == "/readyz"
            or path == "/"
            or path == "/openapi.json"
            or path.startswith("/dashboard")
        )
        if self.token and not exempt:
            hdrs = scope.get("headers", [])
            raw_headers = {k.decode().lower(): v.decode() for k, v in hdrs}
            auth = raw_headers.get("authorization", "")
            if auth != f"Bearer {self.token}":
                from starlette.responses import JSONResponse

                res = JSONResponse({"detail": "Unauthorized"}, status_code=401)
                await res(scope, receive, send)
                return
        await self.app(scope, receive, send)


def create_app() -> Any:
    """Starlette ASGI: health, OpenAPI, full ``/v1`` API, static dashboard."""

    import anyio
    from starlette.applications import Starlette
    from starlette.routing import BaseRoute, Mount, Route
    from starlette.staticfiles import StaticFiles

    static_dir = os.path.join(os.path.dirname(__file__), "static", "dashboard")

    # Forward proxy configuration
    proxy_port = parse_int_env("MTK_PROXY_PORT", 8888, minimum=1, maximum=65535)
    proxy_enabled = os.environ.get("MTK_PROXY_ENABLED", "true").lower() not in (
        "0", "false", "no", "off"
    )

    def root(_request: Any) -> Any:
        proxy_info = {
            "forward_proxy": f":{proxy_port}" if proxy_enabled else "disabled",
        }
        return _json_response(
            {
                "service": "mtk-router-sdk",
                "openapi": "/openapi.json",
                "dashboard": "/dashboard/",
                "healthz": "/healthz",
                "readyz": "/readyz",
                "capabilities": "/v1/capabilities",
                "lan_host_peers": "/v1/lan/host-peers",
                "version": "/v1/version",
                "doctor": "/v1/doctor",
                **proxy_info,
            },
        )

    def healthz(_request: Any) -> Any:
        return _json_response({"status": "ok"})

    def version(_request: Any) -> Any:
        return _json_response({"version": __version__})

    def openapi_json(_request: Any) -> Any:
        return _json_response(build_openapi_spec(sdk_version=__version__))

    async def doctor_async(_request: Any) -> Any:
        result = await anyio.to_thread.run_sync(_doctor_sync)
        ok = bool(result.get("ok"))
        return _json_response(result, status_code=200 if ok else 503)

    core_routes = [
        Route("/", endpoint=root, methods=["GET"]),
        Route("/healthz", endpoint=healthz, methods=["GET"]),
        Route("/openapi.json", endpoint=openapi_json, methods=["GET"]),
        Route("/v1/version", endpoint=version, methods=["GET"]),
        Route("/v1/doctor", endpoint=doctor_async, methods=["GET"]),
    ]
    # Initialize proxy state
    init_proxy_state()

    # Import testing routes
    from mtk_router_sdk.testing.routes import get_testing_routes

    all_routes: list[BaseRoute] = [
        *core_routes,
        *v1_route_table(),
        *proxy_route_table(),
        *get_testing_routes(),
    ]
    if os.path.isdir(static_dir):
        all_routes.append(
            Mount("/dashboard", app=StaticFiles(directory=static_dir, html=True)),
        )

    # Lifespan context manager for forward proxy
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(app: Any) -> Any:
        # Startup
        if proxy_enabled:
            from mtk_router_sdk.proxy.forward_proxy import start_forward_proxy

            try:
                await start_forward_proxy(port=proxy_port)
                logger.info(
                    f"Forward proxy started on port {proxy_port} "
                    "(use Android Wi-Fi Manual Proxy to connect)"
                )
            except Exception as e:
                logger.warning(f"Failed to start forward proxy: {e}")

        yield  # App is running

        # Shutdown
        if proxy_enabled:
            from mtk_router_sdk.proxy.forward_proxy import stop_forward_proxy

            await stop_forward_proxy()

    starlette_app = Starlette(routes=all_routes, lifespan=lifespan)
    attach_service_state(starlette_app)
    token = os.environ.get("MTK_SERVICE_TOKEN", "").strip() or None
    starlette_app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    return _TokenAuthMiddleware(starlette_app, token)
