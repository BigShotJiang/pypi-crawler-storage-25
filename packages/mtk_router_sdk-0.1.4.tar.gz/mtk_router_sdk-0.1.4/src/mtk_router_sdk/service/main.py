from __future__ import annotations


def main() -> None:
    import uvicorn

    from mtk_router_sdk.config.env_parse import parse_int_env

    port = parse_int_env("MTK_HTTP_PORT", 8765, minimum=1, maximum=65535)
    uvicorn.run(
        "mtk_router_sdk.service.app:create_app",
        factory=True,
        host="0.0.0.0",
        port=port,
    )


if __name__ == "__main__":
    main()
