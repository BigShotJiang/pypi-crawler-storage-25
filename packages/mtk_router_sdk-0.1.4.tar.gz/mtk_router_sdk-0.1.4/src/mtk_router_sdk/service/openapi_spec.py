"""OpenAPI 3.1 document for ``mtk-serve`` (contract for HTTP clients)."""

from __future__ import annotations

from typing import Any


def build_openapi_spec(
    *,
    sdk_version: str,
    title: str = "MTK Router SDK HTTP service",
) -> dict[str, Any]:
    from mtk_router_sdk.service.openapi_paths import build_v1_openapi_paths

    paths: dict[str, Any] = {
            "/": {
                "get": {
                    "summary": "Service index",
                    "operationId": "root",
                    "responses": {
                        "200": {
                            "description": "Links to machine-readable contract",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/ServiceIndex"},
                                },
                            },
                        },
                    },
                },
            },
            "/healthz": {
                "get": {
                    "summary": "Liveness",
                    "operationId": "healthz",
                    "responses": {
                        "200": {
                            "description": "Process is running",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/Healthz"},
                                },
                            },
                        },
                    },
                },
            },
            "/v1/version": {
                "get": {
                    "summary": "Python package version",
                    "operationId": "version",
                    "responses": {
                        "200": {
                            "description": "SDK version string",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/Version"},
                                },
                            },
                        },
                    },
                },
            },
            "/v1/doctor": {
                "get": {
                    "summary": "SSH discovery against the configured router",
                    "operationId": "doctor",
                    "responses": {
                        "200": {
                            "description": "Router reachable and discovery succeeded",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/DoctorOk"},
                                },
                            },
                        },
                        "503": {
                            "description": "Misconfiguration or router error",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/DoctorError"},
                                },
                            },
                        },
                    },
                },
            },
            "/openapi.json": {
                "get": {
                    "summary": "This OpenAPI document",
                    "operationId": "openapi",
                    "responses": {
                        "200": {
                            "description": "OpenAPI 3.1 JSON",
                            "content": {
                                "application/json": {
                                    "schema": {"type": "object"},
                                },
                            },
                        },
                    },
                },
            },
    }
    paths.update(build_v1_openapi_paths())
    return {
        "openapi": "3.1.0",
        "info": {
            "title": title,
            "version": sdk_version,
            "description": (
                "Optional HTTP front for the Python SDK. SSH to the router uses "
                "``MTK_HOST`` / ``MTK_USER`` / ``MTK_PASSWORD`` (or site merge)."
            ),
        },
        "paths": paths,
        "components": {
            "schemas": {
                "ServiceIndex": {
                    "type": "object",
                    "required": ["service", "openapi"],
                    "properties": {
                        "service": {"type": "string"},
                        "openapi": {"type": "string"},
                        "dashboard": {"type": "string"},
                        "healthz": {"type": "string"},
                        "readyz": {"type": "string"},
                        "version": {"type": "string"},
                        "doctor": {"type": "string"},
                    },
                },
                "Readyz": {
                    "type": "object",
                    "required": ["ready"],
                    "properties": {"ready": {"type": "boolean"}},
                },
                "Healthz": {
                    "type": "object",
                    "required": ["status"],
                    "properties": {"status": {"type": "string", "const": "ok"}},
                },
                "Version": {
                    "type": "object",
                    "required": ["version"],
                    "properties": {"version": {"type": "string"}},
                },
                "DoctorOk": {
                    "type": "object",
                    "required": ["ok", "target", "profile"],
                    "properties": {
                        "ok": {"type": "boolean", "const": True},
                        "target": {"type": "string"},
                        "profile": {"type": "object"},
                    },
                },
                "DoctorError": {
                    "type": "object",
                    "required": ["ok"],
                    "properties": {
                        "ok": {"type": "boolean", "const": False},
                        "error": {"type": "string"},
                        "hint": {"type": "string"},
                        "target": {"type": "string"},
                    },
                },
                "VpnCheckpoint": {
                    "type": "object",
                    "description": "User-facing VPN validation after route or status check",
                    "properties": {
                        "status": {
                            "type": "string",
                            "description": (
                                "success | route_ok_tunnel_down | route_ok_no_l2tp_row | "
                                "route_mismatch | no_policy_route | no_gateway | "
                                "policy_route_missing_gateway | tunnel_disabled"
                            ),
                        },
                        "user_message": {"type": "string"},
                        "summary": {"type": "string"},
                        "slot_id": {"type": "integer"},
                        "region": {"type": "string", "description": "slots[].region"},
                        "ssid": {"type": "string"},
                        "routing_mark": {"type": "string"},
                        "gateway_interface": {"type": "string"},
                        "policy_route_observed": {"type": "object"},
                        "l2tp_client": {"type": "object"},
                        "checks": {"type": "object"},
                    },
                },
                "SnifferStartRequest": {
                    "type": "object",
                    "required": ["filter_ip_address"],
                    "properties": {
                        "filter_ip_address": {
                            "type": "string",
                            "description": "IPv4 to match (RouterOS filter-ip-address)",
                        },
                        "file_name": {
                            "type": "string",
                            "description": "Basename only, e.g. dev.pcap (optional)",
                        },
                        "only_headers": {
                            "type": "boolean",
                            "description": "If true, L3 headers only (smaller, less sensitive)",
                        },
                        "memory_limit": {
                            "type": "string",
                            "description": "e.g. 100MiB (optional)",
                        },
                    },
                },
                "ByClientLeaseRequest": {
                    "type": "object",
                    "properties": {
                        "client_ip": {
                            "type": "string",
                            "description": "Optional; defaults to caller IP",
                        },
                        "actor": {"type": "string"},
                        "ttl_s": {"type": "number"},
                    },
                },
                "ByClientLeaseReleaseRequest": {
                    "type": "object",
                    "required": ["lease_token"],
                    "properties": {"lease_token": {"type": "string"}},
                },
                "ByClientVpnRequest": {
                    "type": "object",
                    "required": ["gateway_interface"],
                    "properties": {
                        "client_ip": {"type": "string"},
                        "gateway_interface": {"type": "string"},
                        "mode": {"type": "string", "enum": ["route"]},
                    },
                },
                "ByClientSnifferStartRequest": {
                    "type": "object",
                    "required": ["filter_ip_address"],
                    "properties": {
                        "client_ip": {"type": "string"},
                        "filter_ip_address": {"type": "string"},
                        "file_name": {"type": "string"},
                        "only_headers": {"type": "boolean"},
                        "memory_limit": {"type": "string"},
                    },
                },
                "ByClientSnifferStopRequest": {
                    "type": "object",
                    "properties": {"client_ip": {"type": "string"}},
                },
                "BySsidLeaseRequest": {
                    "type": "object",
                    "required": ["ssid"],
                    "properties": {
                        "ssid": {"type": "string"},
                        "actor": {"type": "string"},
                        "ttl_s": {"type": "number"},
                    },
                },
                "BySsidLeaseReleaseRequest": {
                    "type": "object",
                    "required": ["ssid", "lease_token"],
                    "properties": {
                        "ssid": {"type": "string"},
                        "lease_token": {"type": "string"},
                    },
                },
                "BySsidVpnRequest": {
                    "type": "object",
                    "required": ["ssid", "gateway_interface"],
                    "properties": {
                        "ssid": {"type": "string"},
                        "gateway_interface": {"type": "string"},
                        "mode": {"type": "string", "enum": ["route"]},
                    },
                },
                "BySsidSnifferStartRequest": {
                    "type": "object",
                    "required": ["ssid", "filter_ip_address"],
                    "properties": {
                        "ssid": {"type": "string"},
                        "filter_ip_address": {"type": "string"},
                        "file_name": {"type": "string"},
                        "only_headers": {"type": "boolean"},
                        "memory_limit": {"type": "string"},
                    },
                },
                "BySsidSnifferStopRequest": {
                    "type": "object",
                    "required": ["ssid"],
                    "properties": {"ssid": {"type": "string"}},
                },
                "ClientBlockRequest": {
                    "type": "object",
                    "required": ["ip"],
                    "properties": {
                        "ip": {
                            "type": "string",
                            "description": "Client IPv4 address to block/unblock",
                        },
                    },
                },
                "ClientBlockedList": {
                    "type": "object",
                    "properties": {
                        "ok": {"type": "boolean"},
                        "blocked_clients": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "client_ip": {"type": "string"},
                                    "rule_id": {"type": "string"},
                                    "disabled": {"type": "boolean"},
                                },
                            },
                        },
                        "count": {"type": "integer"},
                    },
                },
                "ClientBlockedStatus": {
                    "type": "object",
                    "properties": {
                        "ok": {"type": "boolean"},
                        "client_ip": {"type": "string"},
                        "blocked": {"type": "boolean"},
                        "rule_id": {"type": "string"},
                    },
                },
                "ProxyRuleCreate": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "client_ip": {"type": "string"},
                        "path_pattern": {"type": "string"},
                        "action": {
                            "type": "string",
                            "enum": ["override", "passthrough", "modify", "delay", "error"],
                        },
                        "response_status": {"type": "integer"},
                        "response_body": {},
                        "delay_ms": {"type": "integer"},
                        "json_set": {"type": "object"},
                        "enabled": {"type": "boolean"},
                    },
                },
                "ProxySetRequest": {
                    "type": "object",
                    "required": ["client_ip", "endpoint", "response"],
                    "properties": {
                        "client_ip": {"type": "string"},
                        "endpoint": {"type": "string"},
                        "response": {},
                        "status": {"type": "integer"},
                    },
                },
            },
        },
    }
