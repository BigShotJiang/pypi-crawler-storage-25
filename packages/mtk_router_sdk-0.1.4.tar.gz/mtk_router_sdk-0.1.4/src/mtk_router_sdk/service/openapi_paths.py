"""OpenAPI path items for ``/v1/*`` (merged into the main spec)."""

from __future__ import annotations

from typing import Any


def build_v1_openapi_paths() -> dict[str, Any]:
    """Path objects for REST v1 + WebSocket (documented as description-only)."""

    return {
        "/readyz": {
            "get": {
                "summary": "Readiness (SSH discovery succeeds)",
                "responses": {
                    "200": {
                        "description": "Router reachable and discovery succeeded",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/Readyz"},
                            },
                        },
                    },
                    "503": {
                        "description": "Misconfiguration, SSH failure, or discovery error",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/Readyz"},
                            },
                        },
                    },
                },
            },
        },
        "/v1/capabilities": {
            "get": {
                "summary": "Feature matrix (router SSH vs host-only); does not open SSH",
                "operationId": "capabilitiesGet",
                "responses": {"200": {"description": "capabilities + per-feature blocked_reason"}},
            },
        },
        "/v1/lan/host-peers": {
            "get": {
                "summary": "Host OS IPv4 neighbours (ARP), not RouterOS DHCP",
                "operationId": "lanHostPeersGet",
                "responses": {"200": {"description": "peers + dashboard_devices shape"}},
            },
        },
        "/v1/session": {
            "post": {
                "summary": "Override router SSH target for this process",
                "requestBody": {
                    "content": {
                        "application/json": {
                            "schema": {
                                "type": "object",
                                "required": ["host", "password"],
                                "properties": {
                                    "host": {"type": "string"},
                                    "username": {"type": "string"},
                                    "password": {"type": "string"},
                                    "port": {"type": "integer"},
                                },
                            },
                        },
                    },
                },
                "responses": {"200": {"description": "connected"}, "502": {"description": "SSH error"}},
            },
            "delete": {"summary": "Clear session override", "responses": {"200": {"description": "ok"}}},
        },
        "/v1/discovery/profile": {
            "get": {"summary": "RouterCapabilityProfile", "responses": {"200": {"description": "profile"}}},
        },
        "/v1/discovery/refresh": {
            "post": {"summary": "Re-run discovery", "responses": {"200": {"description": "profile"}}},
        },
        "/v1/dashboard/snapshot": {
            "get": {
                "summary": "Aggregated dashboard JSON",
                "responses": {"200": {"description": "snapshot"}},
            },
        },
        "/v1/wireless": {"get": {"summary": "Wireless or wifi table", "responses": {"200": {"description": "rows"}}}},
        "/v1/vpn/clients": {"get": {"summary": "L2TP clients", "responses": {"200": {"description": "rows"}}}},
        "/v1/dhcp/leases": {
            "get": {
                "summary": "DHCP leases",
                "parameters": [{"name": "slot_id", "in": "query", "schema": {"type": "integer"}}],
                "responses": {"200": {"description": "rows"}},
            },
        },
        "/v1/routing/policy": {
            "get": {"summary": "Policy routes (rt_slot_*)", "responses": {"200": {"description": "rows"}}},
        },
        "/v1/config": {
            "get": {"summary": "Service meta", "responses": {"200": {"description": "config"}}},
            "patch": {"summary": "Partial config (optional)", "responses": {"501": {"description": "not implemented"}}},
        },
        "/v1/config/slots": {
            "get": {"summary": "Effective site slots (no secrets)", "responses": {"200": {"description": "site"}}},
            "put": {
                "summary": "Replace site from JSON body",
                "responses": {"200": {"description": "ok"}, "400": {"description": "validation"}},
            },
        },
        "/v1/bootstrap/dry-run": {
            "post": {"summary": "Bootstrap plan only", "responses": {"200": {"description": "plan"}}},
        },
        "/v1/bootstrap": {
            "post": {"summary": "Bootstrap apply", "responses": {"200": {"description": "ok"}}},
        },
        "/v1/slots/{slot_id}/control/lease": {
            "post": {
                "summary": "Acquire slot lease",
                "parameters": [{"name": "slot_id", "in": "path", "required": True, "schema": {"type": "integer"}}],
                "responses": {"200": {"description": "lease_token"}, "409": {"description": "conflict"}},
            },
            "delete": {
                "summary": "Release lease",
                "parameters": [{"name": "slot_id", "in": "path", "required": True, "schema": {"type": "integer"}}],
                "responses": {"200": {"description": "ok"}},
            },
        },
        "/v1/slots/{slot_id}/control/status": {
            "get": {
                "summary": "Lease status",
                "parameters": [{"name": "slot_id", "in": "path", "required": True, "schema": {"type": "integer"}}],
                "responses": {"200": {"description": "status"}},
            },
        },
        "/v1/slots/{slot_id}/vpn/status": {
            "get": {
                "summary": "VPN checkpoint (read-only): policy route + L2TP + region label; no lease",
                "operationId": "slotVpnStatus",
                "parameters": [
                    {
                        "name": "slot_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "integer"},
                    },
                ],
                "responses": {
                    "200": {"description": "checkpoint + gateway_interface"},
                    "400": {"description": "no site or bad slot"},
                    "502": {"description": "router SSH failed"},
                },
            },
        },
        "/v1/slots/{slot_id}/vpn": {
            "post": {
                "summary": "Runtime VPN (policy route gateway); needs X-Slot-Lease; returns checkpoint",
                "parameters": [{"name": "slot_id", "in": "path", "required": True, "schema": {"type": "integer"}}],
                "responses": {"200": {"description": "ok + checkpoint (user_message, region, L2TP running)"}},
            },
        },
        "/v1/slots/{slot_id}/provision": {
            "post": {"responses": {"501": {"description": "use /v1/bootstrap"}}},
        },
        "/v1/slots/{slot_id}": {
            "delete": {"responses": {"501": {"description": "not implemented"}}},
        },
        "/v1/slots/{slot_id}/sniffer/start": {
            "post": {
                "summary": (
                    "Start /tool sniffer on slot interface; filter-ip-address=IPv4; "
                    "writes .pcap on router (needs X-Slot-Lease)"
                ),
                "operationId": "snifferStart",
                "parameters": [
                    {
                        "name": "slot_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "integer"},
                    },
                ],
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/SnifferStartRequest"},
                        },
                    },
                },
                "responses": {
                    "200": {"description": "capture started"},
                    "400": {"description": "bad request"},
                    "403": {"description": "invalid lease"},
                    "502": {"description": "router command failed"},
                },
            },
        },
        "/v1/slots/{slot_id}/sniffer/stop": {
            "post": {
                "summary": "Stop sniffer (needs X-Slot-Lease)",
                "operationId": "snifferStop",
                "parameters": [
                    {
                        "name": "slot_id",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "integer"},
                    },
                ],
                "responses": {
                    "200": {"description": "stopped"},
                    "400": {"description": "missing lease header"},
                    "403": {"description": "invalid lease"},
                    "502": {"description": "router command failed"},
                },
            },
        },
        "/v1/client/resolve": {
            "get": {
                "summary": "Resolve caller IP → slot (subnet, DHCP dhcp_<id>, or fallback)",
                "operationId": "clientResolve",
                "parameters": [
                    {
                        "name": "client_ip",
                        "in": "query",
                        "required": False,
                        "schema": {"type": "string"},
                        "description": "Override IP (else TCP peer; use MTK_TRUST_X_FORWARDED_FOR + X-Forwarded-For)",
                    },
                ],
                "responses": {
                    "200": {"description": "resolved or unresolved + hint"},
                    "400": {"description": "no site or no client IP"},
                    "502": {"description": "router SSH failed"},
                },
            },
        },
        "/v1/by-client/control/lease": {
            "post": {
                "summary": "Acquire lease by resolved client IP (no SSID/slot_id in API)",
                "operationId": "leaseByClient",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ByClientLeaseRequest"},
                        },
                    },
                },
                "responses": {
                    "200": {"description": "lease_token + slot_id + resolution"},
                    "400": {"description": "unmapped IP"},
                    "409": {"description": "conflict"},
                    "502": {"description": "router SSH failed"},
                },
            },
        },
        "/v1/by-client/control/lease/release": {
            "post": {
                "summary": "Release lease by token only (slot inferred from token)",
                "operationId": "leaseReleaseByClient",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ByClientLeaseReleaseRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "ok"}, "403": {"description": "bad token"}},
            },
        },
        "/v1/by-client/vpn": {
            "post": {
                "summary": "Runtime VPN by resolved client IP (X-Slot-Lease)",
                "operationId": "vpnByClient",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ByClientVpnRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "ok"}, "400": {"description": "unmapped IP"}, "403": {"description": "lease"}},
            },
        },
        "/v1/by-client/sniffer/start": {
            "post": {
                "summary": "Start sniffer by resolved client IP (X-Slot-Lease)",
                "operationId": "snifferStartByClient",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ByClientSnifferStartRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "started"}, "403": {"description": "lease"}},
            },
        },
        "/v1/by-client/sniffer/stop": {
            "post": {
                "summary": "Stop sniffer by resolved client IP (X-Slot-Lease)",
                "operationId": "snifferStopByClient",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ByClientSnifferStopRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "stopped"}},
            },
        },
        "/v1/by-ssid/control/lease": {
            "post": {
                "summary": "Acquire lease by SSID (enabled slot in site JSON only)",
                "operationId": "leaseBySsid",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/BySsidLeaseRequest"},
                        },
                    },
                },
                "responses": {
                    "200": {"description": "lease_token + slot_id + ssid"},
                    "409": {"description": "conflict"},
                },
            },
        },
        "/v1/by-ssid/control/lease/release": {
            "post": {
                "summary": "Release lease by SSID + token",
                "operationId": "leaseReleaseBySsid",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/BySsidLeaseReleaseRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "ok"}},
            },
        },
        "/v1/by-ssid/vpn": {
            "post": {
                "summary": "Runtime VPN by SSID (X-Slot-Lease; enabled slot only)",
                "operationId": "vpnBySsid",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/BySsidVpnRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "ok"}, "403": {"description": "lease"}},
            },
        },
        "/v1/by-ssid/sniffer/start": {
            "post": {
                "summary": "Start sniffer by SSID (X-Slot-Lease)",
                "operationId": "snifferStartBySsid",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/BySsidSnifferStartRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "started"}, "403": {"description": "lease"}},
            },
        },
        "/v1/by-ssid/sniffer/stop": {
            "post": {
                "summary": "Stop sniffer by SSID (X-Slot-Lease)",
                "operationId": "snifferStopBySsid",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/BySsidSnifferStopRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "stopped"}},
            },
        },
        "/v1/ai/intent": {
            "post": {
                "summary": "Structured intents (SetSlotVpn, BootstrapApply, …)",
                "responses": {"200": {"description": "results"}, "400": {"description": "validation"}},
            },
        },
        "/v1/client/block": {
            "post": {
                "summary": "Block internet for a client IP (firewall DROP, runtime only)",
                "operationId": "clientBlock",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ClientBlockRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "blocked or already_blocked"}},
            },
        },
        "/v1/client/unblock": {
            "post": {
                "summary": "Remove internet block for a client IP",
                "operationId": "clientUnblock",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/ClientBlockRequest"},
                        },
                    },
                },
                "responses": {"200": {"description": "unblocked or not_blocked"}},
            },
        },
        "/v1/client/blocked": {
            "get": {
                "summary": "List all blocked clients (SDK-managed firewall rules)",
                "operationId": "clientBlockedList",
                "responses": {
                    "200": {
                        "description": "List of blocked clients",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/ClientBlockedList"},
                            },
                        },
                    },
                },
            },
        },
        "/v1/client/blocked/{ip}": {
            "get": {
                "summary": "Check if a client IP is blocked",
                "operationId": "clientBlockedStatus",
                "parameters": [
                    {
                        "name": "ip",
                        "in": "path",
                        "required": True,
                        "schema": {"type": "string"},
                        "description": "Client IPv4 address",
                    },
                ],
                "responses": {
                    "200": {
                        "description": "Block status for the IP",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/ClientBlockedStatus"},
                            },
                        },
                    },
                },
            },
        },
        "/v1/stream": {
            "get": {
                "summary": "WebSocket stream (use ws:// client; OpenAPI is HTTP-only)",
                "description": "Connect with a WebSocket client; server sends JSON events.",
                "responses": {"426": {"description": "Upgrade Required — use WebSocket"}},
            },
        },
        "/v1/proxy/status": {
            "get": {
                "summary": "Get proxy engine status",
                "operationId": "proxyStatus",
                "responses": {"200": {"description": "Proxy status with rule/log counts"}},
            },
        },
        "/v1/proxy/rules": {
            "get": {
                "summary": "List proxy rules",
                "operationId": "proxyRulesList",
                "parameters": [{"name": "client_ip", "in": "query", "schema": {"type": "string"}}],
                "responses": {"200": {"description": "List of rules"}},
            },
            "post": {
                "summary": "Create a proxy rule",
                "operationId": "proxyRuleCreate",
                "requestBody": {"required": True, "content": {"application/json": {"schema": {"$ref": "#/components/schemas/ProxyRuleCreate"}}}},
                "responses": {"201": {"description": "Rule created"}},
            },
            "delete": {
                "summary": "Clear all proxy rules",
                "operationId": "proxyRulesClear",
                "parameters": [{"name": "client_ip", "in": "query", "schema": {"type": "string"}}],
                "responses": {"200": {"description": "Rules cleared"}},
            },
        },
        "/v1/proxy/rules/{rule_id}": {
            "get": {
                "summary": "Get a proxy rule",
                "operationId": "proxyRuleGet",
                "parameters": [{"name": "rule_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"200": {"description": "Rule details"}},
            },
            "put": {
                "summary": "Update a proxy rule",
                "operationId": "proxyRuleUpdate",
                "parameters": [{"name": "rule_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"200": {"description": "Rule updated"}},
            },
            "delete": {
                "summary": "Delete a proxy rule",
                "operationId": "proxyRuleDelete",
                "parameters": [{"name": "rule_id", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"200": {"description": "Rule deleted"}},
            },
        },
        "/v1/proxy/set": {
            "post": {
                "summary": "Quick set response override",
                "operationId": "proxySetResponse",
                "requestBody": {"required": True, "content": {"application/json": {"schema": {"$ref": "#/components/schemas/ProxySetRequest"}}}},
                "responses": {"201": {"description": "Rule created"}},
            },
        },
        "/v1/proxy/error": {
            "post": {
                "summary": "Quick set error response",
                "operationId": "proxySetError",
                "responses": {"201": {"description": "Error rule created"}},
            },
        },
        "/v1/proxy/clear": {
            "post": {
                "summary": "Clear rules for endpoint or device",
                "operationId": "proxyClear",
                "responses": {"200": {"description": "Rules cleared"}},
            },
        },
        "/v1/proxy/log": {
            "get": {
                "summary": "Get request log",
                "operationId": "proxyLogList",
                "parameters": [
                    {"name": "client_ip", "in": "query", "schema": {"type": "string"}},
                    {"name": "limit", "in": "query", "schema": {"type": "integer"}},
                ],
                "responses": {"200": {"description": "Log entries with stats"}},
            },
            "delete": {
                "summary": "Clear request log",
                "operationId": "proxyLogClear",
                "responses": {"200": {"description": "Log cleared"}},
            },
        },
        "/v1/proxy/to/{upstream_host}/{path}": {
            "get": {
                "summary": "Proxy request to upstream (any HTTP method)",
                "operationId": "proxyPassthrough",
                "parameters": [
                    {"name": "upstream_host", "in": "path", "required": True, "schema": {"type": "string"}},
                    {"name": "path", "in": "path", "required": True, "schema": {"type": "string"}},
                ],
                "responses": {"200": {"description": "Proxied response"}},
            },
        },
        "/v1/proxy/certs": {
            "get": {
                "summary": "Get certificate status",
                "operationId": "proxyCertsStatus",
                "responses": {"200": {"description": "Certificate info"}},
            },
            "post": {
                "summary": "Generate certificates",
                "operationId": "proxyCertsGenerate",
                "responses": {"200": {"description": "Certificates generated"}},
            },
        },
        "/v1/proxy/certs/ca": {
            "get": {
                "summary": "Download CA certificate",
                "operationId": "proxyCertsDownload",
                "responses": {"200": {"description": "CA certificate file"}},
            },
        },
        "/v1/proxy/certs/import": {
            "post": {
                "summary": "Import CA (PEM or base64 PKCS#12), re-sign proxy leaf",
                "operationId": "proxyCertsImport",
                "responses": {"200": {"description": "Paths to installed cert files"}},
            },
        },
    }
