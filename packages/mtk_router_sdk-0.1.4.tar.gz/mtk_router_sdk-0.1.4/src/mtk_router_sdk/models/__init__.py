"""Shared dataclasses — connection, exec results, discovery snapshots."""

from mtk_router_sdk.models.connection import ConnectionConfig
from mtk_router_sdk.models.exec_result import ExecResult

__all__ = ["ConnectionConfig", "ExecResult"]
