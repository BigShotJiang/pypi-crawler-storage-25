from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ConnectionConfig:
    """Immutable connection parameters for one router (one SDK instance ↔ one device)."""

    host: str
    username: str
    password: str
    port: int = 22
    timeout: float = 10.0
    look_for_keys: bool = False
    allow_agent: bool = False

    def describe_target(self) -> str:
        """Human label for logs and CLI (e.g. ``admin@192.168.88.1`` or ``admin@host:2222``)."""

        hostpart = f"{self.host}:{self.port}" if self.port != 22 else self.host
        return f"{self.username}@{hostpart}"
