"""RouterOS v6 vs v7+ command paths (spec: RosCommandAdapter)."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RosCommandAdapter:
    """Selects CLI menus by RouterOS major version.

    Legacy wireless uses ``/interface wireless``. RouterOS 7 **wifiwave2** devices
    expose ``/interface wifi`` instead; discovery falls back when wireless fails.
    Bootstrap slot WLAN steps still target ``/interface wireless`` until wifiwave2
    provisioning is modeled separately.
    """

    major: int

    @classmethod
    def from_version_string(cls, version: str) -> RosCommandAdapter:
        s = (version or "").strip()
        m = re.match(r"(\d+)", s)
        major = int(m.group(1)) if m else 7
        return cls(major=major)

    def wireless_print_terse_command(self) -> str:
        return "/interface wireless print terse"

    def wifi_print_terse_command(self) -> str:
        return "/interface wifi print terse"

    def try_wifi_when_wireless_fails(self) -> bool:
        return self.major >= 7
