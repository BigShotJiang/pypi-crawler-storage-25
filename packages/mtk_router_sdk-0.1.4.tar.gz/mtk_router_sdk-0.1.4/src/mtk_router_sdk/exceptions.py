"""Typed exception hierarchy for the SDK (see docs/ROUTER_SDK.md)."""


class MtkRouterError(Exception):
    """Base error for all SDK failures."""

    code: str = "MTK_ERROR"

    def __init__(
        self,
        message: str,
        *,
        hint: str | None = None,
        router_output: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.router_output = router_output


class ConnectionFailedError(MtkRouterError):
    """SSH (or transport) connection could not be established."""

    code = "CONNECTION_FAILED"


class TransportClosedError(MtkRouterError):
    """Operation requested while transport is disconnected."""

    code = "TRANSPORT_CLOSED"


class CommandExecutionError(MtkRouterError):
    """RouterOS command failed or returned unexpected output."""

    code = "COMMAND_EXECUTION"


class DiscoveryError(MtkRouterError):
    """Discovery could not parse or complete."""

    code = "DISCOVERY_FAILED"


class ConfigurationError(MtkRouterError):
    """Invalid SDK or site configuration."""

    code = "CONFIG_INVALID"
