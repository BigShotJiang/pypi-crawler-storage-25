from __future__ import annotations

import logging
from types import TracebackType
from typing import Any

from mtk_router_sdk.discovery import DiscoveryService
from mtk_router_sdk.discovery.models import RouterCapabilityProfile
from mtk_router_sdk.exceptions import CommandExecutionError, DiscoveryError
from mtk_router_sdk.models import ConnectionConfig, ExecResult
from mtk_router_sdk.parsing import parse_terse_lines
from mtk_router_sdk.transport import AbstractTransport, SshTransport

logger = logging.getLogger(__name__)


class RouterClient:
    """High-level façade: one instance ↔ one router (see product spec).

    Composes a pluggable :class:`AbstractTransport` (default: :class:`SshTransport`)
    and reuses :class:`DiscoveryService` for capability snapshots. Future modules
    (bootstrap, slots, AI) attach the same transport without duplicating SSH code.
    """

    __slots__ = ("_transport", "_owns_transport")

    def __init__(self, transport: AbstractTransport | None = None) -> None:
        self._owns_transport = transport is None
        self._transport: AbstractTransport = transport or SshTransport()

    @classmethod
    def with_ssh(cls) -> RouterClient:
        """Create a client with the default SSH transport (most common)."""

        return cls(SshTransport())

    @classmethod
    def from_env(cls) -> RouterClient:
        """Return SSH client; load credentials with ``connection_config_from_env``."""

        return cls.with_ssh()

    @property
    def transport(self) -> AbstractTransport:
        return self._transport

    def connect(self, config: ConnectionConfig) -> None:
        """Open session to the router."""

        self._transport.connect(config)

    def disconnect(self) -> None:
        """Close session."""

        self._transport.disconnect()

    @property
    def connected(self) -> bool:
        return self._transport.connected

    def exec_command(
        self,
        command: str,
        *,
        timeout: float | None = None,
        get_pty: bool = False,
    ) -> ExecResult:
        """Run arbitrary RouterOS CLI (escape hatch / future adapters)."""

        return self._transport.exec_command(command, timeout=timeout, get_pty=get_pty)

    def discover(self) -> RouterCapabilityProfile:
        """Full discovery pass (identity, resource, board, wireless terse)."""

        return DiscoveryService(self._transport).discover()

    def discover_safe(
        self,
    ) -> tuple[RouterCapabilityProfile | None, DiscoveryError | None]:
        """Like :meth:`discover` but never raises — returns ``(profile, None)`` or ``(None, err)``."""

        try:
            return (self.discover(), None)
        except DiscoveryError as e:
            return (None, e)

    def exec_print_terse(
        self,
        menu_path: str,
        *,
        timeout: float | None = None,
    ) -> list[dict[str, Any]]:
        """Run ``<menu_path> print terse`` and parse rows (interfaces, IP, L2TP, …)."""

        cmd = f"{menu_path.strip()} print terse"
        r = self.exec_command(cmd, timeout=timeout)
        if not r.ok:
            tail_out = (r.stdout or "")[-4000:]
            tail_err = (r.stderr or "")[-4000:]
            logger.warning(
                "RouterOS terse command failed: %s exit=%s",
                cmd,
                r.exit_status,
            )
            if tail_out.strip():
                logger.warning("router stdout (tail): %s", tail_out)
            if tail_err.strip():
                logger.warning("router stderr (tail): %s", tail_err)
            raise CommandExecutionError(
                f"Command failed ({cmd}): exit {r.exit_status}",
                hint="Check the menu path and your user’s RouterOS permissions.",
                router_output=r.stderr or r.stdout,
            )
        return parse_terse_lines(r.stdout)

    def __enter__(self) -> RouterClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.disconnect()
