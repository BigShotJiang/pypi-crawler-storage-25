from __future__ import annotations

from abc import ABC, abstractmethod

from mtk_router_sdk.models import ConnectionConfig, ExecResult


class AbstractTransport(ABC):
    """Contract for any channel that can run RouterOS CLI (or API adapter).

    New transports (e.g. binary API) implement this interface; ``RouterClient``
    and services like discovery stay unchanged.
    """

    @abstractmethod
    def connect(self, config: ConnectionConfig) -> None:
        """Establish session using *config*."""

    @abstractmethod
    def disconnect(self) -> None:
        """Close session and release resources."""

    @abstractmethod
    def exec_command(
        self,
        command: str,
        *,
        timeout: float | None = None,
        get_pty: bool = False,
    ) -> ExecResult:
        """Run one command string (e.g. ``/system identity print``).

        ``get_pty=True`` requests a pseudo-terminal (needed for some RouterOS script
        one-liners over SSH).
        """

    @property
    @abstractmethod
    def connected(self) -> bool:
        """Whether a session is active."""
