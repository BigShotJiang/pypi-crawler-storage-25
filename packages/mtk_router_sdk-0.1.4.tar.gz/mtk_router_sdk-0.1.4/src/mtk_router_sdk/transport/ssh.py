from __future__ import annotations

import errno
from typing import TYPE_CHECKING

import paramiko
from paramiko import AuthenticationException, SSHException

from mtk_router_sdk.exceptions import ConnectionFailedError, TransportClosedError
from mtk_router_sdk.models import ConnectionConfig, ExecResult
from mtk_router_sdk.transport.base import AbstractTransport

if TYPE_CHECKING:
    pass


class SshTransport(AbstractTransport):
    """Paramiko-based SSH transport (RouterOS v6-friendly defaults)."""

    __slots__ = ("_client", "_config")

    def __init__(self) -> None:
        self._client: paramiko.SSHClient | None = None
        self._config: ConnectionConfig | None = None

    @property
    def connected(self) -> bool:
        return self._client is not None and self._config is not None

    def connect(self, config: ConnectionConfig) -> None:
        self.disconnect()
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        addr = f"{config.host}:{config.port}"
        try:
            client.connect(
                hostname=config.host,
                port=config.port,
                username=config.username,
                password=config.password,
                timeout=config.timeout,
                look_for_keys=config.look_for_keys,
                allow_agent=config.allow_agent,
            )
        except AuthenticationException as e:
            raise ConnectionFailedError(
                f"SSH login failed for {config.describe_target()}.",
                hint=(
                    "Check MTK_USER and MTK_PASSWORD. On the router, ensure "
                    "IP → Services → SSH is enabled and the user has the right group."
                ),
            ) from e
        except TimeoutError as e:
            raise ConnectionFailedError(
                f"Timed out reaching {addr} (waited {config.timeout:g}s).",
                hint=(
                    "If you did not set MTK_HOST, the SDK picks the first LAN/gateway "
                    "address with port 22 open; set MTK_HOST to the router IP. "
                    "Check cables/Wi‑Fi and firewall. Increase MTK_TIMEOUT if the link is slow."
                ),
            ) from e
        except OSError as e:
            eno = getattr(e, "errno", None)
            if eno == errno.ECONNREFUSED:
                raise ConnectionFailedError(
                    f"Nothing is accepting SSH at {addr}.",
                    hint=(
                        "Wrong device or port, or SSH is disabled. "
                        "This tool expects a MikroTik router with RouterOS SSH enabled."
                    ),
                ) from e
            if eno in (errno.EHOSTUNREACH, errno.ENETUNREACH):
                raise ConnectionFailedError(
                    f"Host unreachable: {addr}.",
                    hint=(
                        "Check MTK_HOST, routing, and that your Mac is on the same LAN "
                        "or VPN as the router."
                    ),
                ) from e
            raise ConnectionFailedError(
                f"Could not open SSH to {addr}: {e}",
                hint=(
                    "Check host reachability, firewall, and that you are targeting "
                    "a MikroTik router with SSH enabled."
                ),
            ) from e
        except SSHException as e:
            raise ConnectionFailedError(
                f"SSH handshake failed with {addr}: {e}",
                hint=(
                    "Port may not be SSH (try MTK_PORT=22), or the server is not RouterOS. "
                    "This tool only supports MikroTik RouterOS over SSH."
                ),
            ) from e
        self._client = client
        self._config = config

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None
        self._config = None

    def exec_command(
        self,
        command: str,
        *,
        timeout: float | None = None,
        get_pty: bool = False,
    ) -> ExecResult:
        if self._client is None:
            raise TransportClosedError(
                "Not connected.",
                hint="Call connect() with a ConnectionConfig first.",
            )
        t = timeout if timeout is not None else (self._config.timeout if self._config else 30.0)
        try:
            _stdin, stdout, stderr = self._client.exec_command(
                command,
                timeout=t,
                get_pty=get_pty,
            )
            # RouterOS often will not finish the session until stdin is closed.
            _stdin.close()
            out_b = stdout.read()
            err_b = stderr.read()
            exit_status = stdout.channel.recv_exit_status()
        except Exception as e:
            detail = str(e).strip() or repr(e)
            hint = (
                "Connection may have dropped; try disconnect() and connect() again. "
                "For bootstrap, set MTK_BOOTSTRAP_NO_PTY=1 if PTY allocation fails."
            )
            raise ConnectionFailedError(
                f"Command execution failed ({type(e).__name__}): {detail}",
                hint=hint,
            ) from e
        return ExecResult(
            stdout=out_b.decode(errors="replace"),
            stderr=err_b.decode(errors="replace"),
            exit_status=exit_status,
        )
