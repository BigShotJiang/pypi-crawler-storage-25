"""Pluggable transports (SSH now; RouterOS API later)."""

from mtk_router_sdk.transport.base import AbstractTransport
from mtk_router_sdk.transport.ssh import SshTransport

__all__ = ["AbstractTransport", "SshTransport"]
