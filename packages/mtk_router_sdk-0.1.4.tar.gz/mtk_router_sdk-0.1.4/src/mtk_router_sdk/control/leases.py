"""In-memory slot leases (reject or FIFO wait)."""

from __future__ import annotations

import contextlib
import secrets
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Literal

LockMode = Literal["reject", "fifo_queue"]


class LeaseConflictError(Exception):
    """Another actor holds the slot lease (HTTP 409)."""

    def __init__(
        self,
        message: str,
        *,
        holder: str,
        expires_at: float,
        retry_after_s: int,
    ) -> None:
        super().__init__(message)
        self.holder = holder
        self.expires_at = expires_at
        self.retry_after_s = retry_after_s


@dataclass(slots=True)
class _Lease:
    token: str
    slot_id: int
    actor: str
    expires_at: float  # time.monotonic()


@dataclass(slots=True)
class _Waiter:
    actor: str
    ttl_s: float
    event: threading.Event = field(default_factory=threading.Event)
    result: dict[str, Any] | None = None


class SlotLeaseManager:
    """Exclusive mutating lease per ``slot_id`` (thread-safe)."""

    def __init__(self, mode: LockMode = "reject", *, max_ttl_s: float = 600.0) -> None:
        self._mode = mode
        self._max_ttl_s = max_ttl_s
        self._lock = threading.Lock()
        self._leases: dict[int, _Lease] = {}
        self._token_slot: dict[str, int] = {}
        self._queues: dict[int, deque[_Waiter]] = {}

    def acquire(self, slot_id: int, actor: str, ttl_s: float) -> dict[str, Any]:
        ttl_s = min(max(float(ttl_s), 1.0), self._max_ttl_s)
        w: _Waiter | None = None
        with self._lock:
            self._purge_expired_unlocked()
            if slot_id not in self._leases:
                return self._grant_unlocked(slot_id, actor, ttl_s)
            if self._mode == "reject":
                ex = self._leases[slot_id]
                raise LeaseConflictError(
                    f"slot {slot_id} is locked by {ex.actor!r}",
                    holder=ex.actor,
                    expires_at=ex.expires_at,
                    retry_after_s=max(1, int(ex.expires_at - time.monotonic())),
                )
            w = _Waiter(actor=actor, ttl_s=ttl_s)
            self._queues.setdefault(slot_id, deque()).append(w)
        assert w is not None
        ok = w.event.wait(timeout=ttl_s + 30.0)
        with self._lock:
            if not ok or w.result is None:
                self._drop_waiter_unlocked(slot_id, w)
                raise LeaseConflictError(
                    "lease wait timed out or was cancelled",
                    holder=self._leases[slot_id].actor if slot_id in self._leases else "",
                    expires_at=self._leases[slot_id].expires_at
                    if slot_id in self._leases
                    else time.monotonic(),
                    retry_after_s=5,
                )
            return w.result

    def _drop_waiter_unlocked(self, slot_id: int, w: _Waiter) -> None:
        q = self._queues.get(slot_id)
        if not q:
            return
        with contextlib.suppress(ValueError):
            q.remove(w)
        if not q:
            self._queues.pop(slot_id, None)

    def _grant_unlocked(self, slot_id: int, actor: str, ttl_s: float) -> dict[str, Any]:
        token = secrets.token_urlsafe(24)
        le = _Lease(
            token=token,
            slot_id=slot_id,
            actor=actor,
            expires_at=time.monotonic() + ttl_s,
        )
        self._leases[slot_id] = le
        self._token_slot[token] = slot_id
        return {
            "lease_token": token,
            "slot_id": slot_id,
            "expires_at": le.expires_at,
        }

    def _release_unlocked(self, slot_id: int, token: str) -> bool:
        cur = self._leases.get(slot_id)
        if cur is None or cur.token != token:
            return False
        del self._leases[slot_id]
        del self._token_slot[token]
        self._serve_queue_unlocked(slot_id)
        return True

    def release(self, slot_id: int, token: str) -> bool:
        with self._lock:
            self._purge_expired_unlocked()
            return self._release_unlocked(slot_id, token)

    def release_by_token(self, token: str) -> bool:
        with self._lock:
            self._purge_expired_unlocked()
            sid = self._token_slot.get(token)
            if sid is None:
                return False
            return self._release_unlocked(sid, token)

    def _serve_queue_unlocked(self, slot_id: int) -> None:
        q = self._queues.get(slot_id)
        if not q:
            return
        while q:
            w = q.popleft()
            if not q:
                self._queues.pop(slot_id, None)
            try:
                w.result = self._grant_unlocked(slot_id, w.actor, w.ttl_s)
                w.event.set()
                return
            except Exception:
                continue

    def validate(self, slot_id: int, token: str) -> bool:
        with self._lock:
            self._purge_expired_unlocked()
            cur = self._leases.get(slot_id)
            return cur is not None and cur.token == token

    def status(self, slot_id: int) -> dict[str, Any]:
        with self._lock:
            self._purge_expired_unlocked()
            cur = self._leases.get(slot_id)
            qd = len(self._queues.get(slot_id, ()))
            if cur is None:
                return {
                    "slot_id": slot_id,
                    "locked": False,
                    "holder": None,
                    "expires_at": None,
                    "queue_depth": qd,
                }
            return {
                "slot_id": slot_id,
                "locked": True,
                "holder": cur.actor,
                "expires_at": cur.expires_at,
                "queue_depth": qd,
            }

    def _purge_expired_unlocked(self) -> None:
        now = time.monotonic()
        dead = [sid for sid, le in self._leases.items() if le.expires_at <= now]
        for sid in dead:
            le = self._leases.pop(sid)
            self._token_slot.pop(le.token, None)
            self._serve_queue_unlocked(sid)
