"""Per-slot leases and control-plane helpers (spec §3.8)."""

from mtk_router_sdk.control.leases import LeaseConflictError, SlotLeaseManager

__all__ = ["LeaseConflictError", "SlotLeaseManager"]
