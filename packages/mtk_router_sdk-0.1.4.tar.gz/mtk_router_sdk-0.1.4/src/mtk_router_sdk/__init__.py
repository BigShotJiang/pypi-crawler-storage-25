"""
MTK Router SDK — MikroTik RouterOS automation (modular, transport-pluggable).

Public surface kept small; subpackages expose building blocks for advanced use.
"""

from importlib.metadata import PackageNotFoundError, version

from mtk_router_sdk.bootstrap import BootstrapEngine, BootstrapPlan, BootstrapStep
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config import (
    ConnectionSettings,
    SiteConfig,
    connection_config_from_env,
    connection_config_from_merged,
    load_site_config,
    load_site_config_from_path,
)
from mtk_router_sdk.discovery import DiscoveryService, RouterCapabilityProfile
from mtk_router_sdk.exceptions import (
    CommandExecutionError,
    ConfigurationError,
    ConnectionFailedError,
    DiscoveryError,
    MtkRouterError,
    TransportClosedError,
)
from mtk_router_sdk.models import ConnectionConfig, ExecResult
from mtk_router_sdk.ros_adapter import RosCommandAdapter
from mtk_router_sdk.transport import AbstractTransport, SshTransport

try:
    __version__ = version("mtk-router-sdk")
except PackageNotFoundError:
    __version__ = "0.1.4"

__all__ = [
    "__version__",
    "AbstractTransport",
    "BootstrapEngine",
    "BootstrapPlan",
    "BootstrapStep",
    "CommandExecutionError",
    "ConfigurationError",
    "ConnectionConfig",
    "ConnectionSettings",
    "ConnectionFailedError",
    "DiscoveryError",
    "DiscoveryService",
    "ExecResult",
    "MtkRouterError",
    "RosCommandAdapter",
    "RouterCapabilityProfile",
    "RouterClient",
    "SiteConfig",
    "SshTransport",
    "TransportClosedError",
    "connection_config_from_env",
    "connection_config_from_merged",
    "load_site_config",
    "load_site_config_from_path",
]
