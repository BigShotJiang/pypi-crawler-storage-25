"""Sync HTTP client for mtk-serve proxy API.

Uses :mod:`urllib` against a real base URL. Optional **in-process** mode
(``asgi_app=…``) uses Starlette ``TestClient`` (no network; same stack as tests).
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class ProxyRestError(Exception):
    """HTTP or transport error talking to mtk-serve."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "PROXY_HTTP_ERROR",
        status_code: int | None = None,
        body: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.code = code
        self.status_code = status_code
        self.body = body or {}
        super().__init__(message)


class ProxyRestClient:
    """Call ``/v1/proxy/*`` on mtk-serve (network or in-process ASGI)."""

    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        timeout: float = 30.0,
        asgi_app: Any | None = None,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._token = (token or "").strip() or None
        self._timeout = timeout
        self._tc: Any = None
        if asgi_app is not None:
            from starlette.testclient import TestClient

            self._tc = TestClient(asgi_app, raise_server_exceptions=True)

    def close(self) -> None:
        if self._tc is not None:
            self._tc.close()
            self._tc = None

    def _auth_headers(self, *, json_body: bool) -> dict[str, str]:
        h = {"Accept": "application/json"}
        if json_body:
            h["Content-Type"] = "application/json"
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json_body: dict[str, Any] | list[Any] | None = None,
    ) -> dict[str, Any]:
        if self._tc is not None:
            return self._request_testclient(method, path, params=params, json_body=json_body)

        url = f"{self._base}{path}"
        if params:
            q = urllib.parse.urlencode(params)
            url = f"{url}?{q}"

        data: bytes | None = None
        if json_body is not None:
            data = json.dumps(json_body).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=data,
            headers=self._auth_headers(json_body=json_body is not None),
            method=method.upper(),
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                raw = resp.read().decode("utf-8")
                if not raw.strip():
                    return {}
                out = json.loads(raw)
                if not isinstance(out, dict):
                    return {"_raw": out}
                return out
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8") if e.fp else ""
            try:
                payload = json.loads(raw) if raw.strip() else {}
            except json.JSONDecodeError:
                payload = {"error": raw or str(e)}
            if not isinstance(payload, dict):
                payload = {"error": str(payload)}
            msg = str(
                payload.get("error")
                or payload.get("detail")
                or payload.get("message")
                or raw
                or e.reason
            )
            raise ProxyRestError(
                msg,
                status_code=e.code,
                body=payload,
                code="HTTP_ERROR",
            ) from e
        except urllib.error.URLError as e:
            raise ProxyRestError(
                f"Cannot reach mtk-serve at {self._base}: {e.reason!r}",
                code="CONNECT_FAILED",
            ) from e

    def _request_testclient(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None,
        json_body: dict[str, Any] | list[Any] | None,
    ) -> dict[str, Any]:
        assert self._tc is not None
        hdrs = self._auth_headers(json_body=json_body is not None)
        r = self._tc.request(
            method.upper(),
            path,
            params=params,
            json=json_body,
            headers=hdrs,
        )
        if r.status_code >= 400:
            try:
                payload = r.json()
                if not isinstance(payload, dict):
                    payload = {"error": str(payload)}
            except Exception:
                payload = {"error": r.text or r.reason_phrase}
            msg = str(
                payload.get("error")
                or payload.get("detail")
                or payload.get("message")
                or r.text
            )
            raise ProxyRestError(
                msg,
                status_code=r.status_code,
                body=payload,
                code="HTTP_ERROR",
            )
        if not r.content.strip():
            return {}
        out = r.json()
        if not isinstance(out, dict):
            return {"_raw": out}
        return out
