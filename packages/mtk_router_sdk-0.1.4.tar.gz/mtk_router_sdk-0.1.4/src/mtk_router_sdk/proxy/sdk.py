"""High-level SDK interface for the proxy engine.

``ProxyManager`` works in two modes:

1. **Remote (default for** ``from_env()`` **/** ``from_site()`` **)**
   Talks to a running **mtk-serve** over HTTP so ``mtk proxy …`` and automation
   change the same rules as ``POST /v1/proxy/…``.

2. **Local (in-process)**
   ``ProxyManager()`` with no ``base_url`` — rules live only in this process
   (unit tests, embedded use). They **do not** affect mtk-serve.

Environment:

- ``MTK_SERVICE_URL`` — mtk-serve base URL (e.g. ``http://192.168.88.1:8765``).
  If unset, defaults to ``http://127.0.0.1:<MTK_HTTP_PORT>`` (port default **8765**),
  unless ``MTK_PROXY_LOCAL_ONLY=1`` forces local in-process store.
- ``MTK_SERVICE_TOKEN`` — Bearer token when the server requires auth.
- ``MTK_PROXY_PORT`` / ``MTK_PROXY_TIMEOUT`` — optional overrides for the local proxy
  config (validated integers / floats; see ``mtk_router_sdk.config.env_parse``).
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from mtk_router_sdk.config.env_parse import parse_float_env, parse_int_env
from mtk_router_sdk.proxy.models import (
    ProxyAction,
    ProxyConfig,
    ProxyLogEntry,
    ProxyRule,
)
from mtk_router_sdk.proxy.rest_client import ProxyRestClient, ProxyRestError
from mtk_router_sdk.proxy.store import ProxyState


class ProxyError(Exception):
    """Error in proxy operations."""

    def __init__(self, message: str, code: str = "PROXY_ERROR") -> None:
        self.message = message
        self.code = code
        super().__init__(message)


def _service_base_url_from_env() -> str | None:
    """Return mtk-serve base URL, or ``None`` for local-only mode."""
    url = os.environ.get("MTK_SERVICE_URL", "").strip()
    if url:
        return url.rstrip("/")
    local_only = os.environ.get("MTK_PROXY_LOCAL_ONLY", "").strip().lower()
    if local_only in ("1", "true", "yes"):
        return None
    port = parse_int_env("MTK_HTTP_PORT", 8765, minimum=1, maximum=65535)
    return f"http://127.0.0.1:{port}"


def _map_rest_error(exc: ProxyRestError) -> ProxyError:
    code = exc.code
    if exc.status_code == 401:
        code = "UNAUTHORIZED"
    elif exc.status_code == 404:
        code = "NOT_FOUND"
    return ProxyError(exc.message, code=code)


class ProxyManager:
    """Interface to the MTK proxy (local in-memory or remote mtk-serve)."""

    def __init__(
        self,
        config: ProxyConfig | None = None,
        *,
        base_url: str | None = None,
        token: str | None = None,
        asgi_app: Any | None = None,
    ) -> None:
        """Create a manager.

        Args:
            config: Optional proxy configuration (timeouts, log limits for local).
            base_url: If set, all operations use HTTP against mtk-serve at this base.
            token: Optional ``Authorization: Bearer`` token (remote only).
            asgi_app: In-process Starlette/FastAPI app (uses httpx ASGI transport).
                For tests; mutually exclusive with ``base_url``.
        """
        self._config = config or ProxyConfig()
        if asgi_app is not None and base_url:
            raise ProxyError(
                "Use either base_url=… or asgi_app=…, not both.",
                code="INVALID_CONFIG",
            )
        bu = base_url.strip().rstrip("/") if base_url else None
        self._http: ProxyRestClient | None = None
        self._base_url: str | None = None  # explicit type
        if asgi_app is not None:
            tok = (token or "").strip() or None
            self._http = ProxyRestClient(
                "asgi://mtk-serve",
                token=tok,
                timeout=float(self._config.upstream_timeout),
                asgi_app=asgi_app,
            )
            self._base_url = "asgi://mtk-serve"
            self.state = None
        elif bu:
            tok = (token or "").strip() or None
            self._http = ProxyRestClient(
                bu,
                token=tok,
                timeout=float(self._config.upstream_timeout),
            )
            self._base_url = bu
            self.state = None
        else:
            self._base_url = None
            self.state = ProxyState(config=self._config)

    def close(self) -> None:
        """Close the HTTP client (ASGI/httpx); no-op for local-only managers."""
        if self._http is not None:
            self._http.close()

    @classmethod
    def from_site(cls, site_path: str) -> ProxyManager:
        """Load cert dir from site file directory; target mtk-serve like ``from_env()``."""
        cfg = ProxyConfig()
        site_dir = Path(site_path).parent
        site_cert_dir = site_dir / "certs"
        if site_cert_dir.exists():
            cfg.cert_dir = str(site_cert_dir)
        if env_cert_dir := os.environ.get("MTK_PROXY_CERT_DIR"):
            cfg.cert_dir = env_cert_dir
        cfg.proxy_port = parse_int_env(
            "MTK_PROXY_PORT", cfg.proxy_port, minimum=1, maximum=65535
        )
        cfg.upstream_timeout = parse_float_env(
            "MTK_PROXY_TIMEOUT", cfg.upstream_timeout, minimum=0.0, maximum=86400.0
        )

        bu = _service_base_url_from_env()
        token = os.environ.get("MTK_SERVICE_TOKEN", "").strip() or None
        if bu:
            return cls(config=cfg, base_url=bu, token=token)
        return cls(config=cfg)

    @classmethod
    def from_env(cls) -> ProxyManager:
        """Prefer mtk-serve HTTP (see module docstring)."""
        cfg = ProxyConfig()
        if cert_dir := os.environ.get("MTK_PROXY_CERT_DIR"):
            cfg.cert_dir = cert_dir
        cfg.proxy_port = parse_int_env(
            "MTK_PROXY_PORT", cfg.proxy_port, minimum=1, maximum=65535
        )
        cfg.upstream_timeout = parse_float_env(
            "MTK_PROXY_TIMEOUT", cfg.upstream_timeout, minimum=0.0, maximum=86400.0
        )

        bu = _service_base_url_from_env()
        token = os.environ.get("MTK_SERVICE_TOKEN", "").strip() or None
        if bu:
            return cls(config=cfg, base_url=bu, token=token)
        return cls(config=cfg)

    # ------------------------------------------------------------------ rules --

    def set_response(
        self,
        client_ip: str,
        endpoint: str,
        response: dict[str, Any] | str,
        *,
        name: str = "",
        status: int = 200,
        headers: dict[str, str] | None = None,
    ) -> ProxyRule:
        self._validate_ip(client_ip)
        self._validate_endpoint(endpoint)
        if self._http:
            try:
                body: dict[str, Any] = {
                    "client_ip": client_ip,
                    "endpoint": endpoint,
                    "response": response,
                    "status": status,
                }
                if name:
                    body["name"] = name
                if headers:
                    body["response_headers"] = headers
                data = self._http.request("POST", "/v1/proxy/set", json_body=body)
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        self._remove_matching_rules(client_ip, endpoint)
        rule = ProxyRule(
            name=name or f"Override {endpoint} for {client_ip}",
            client_ip=client_ip,
            path_pattern=endpoint,
            action=ProxyAction.OVERRIDE,
            response_status=status,
            response_headers=headers or {},
            response_body=response,
        )
        return self.state.rules.add(rule)

    def set_responses(
        self,
        client_ip: str,
        responses: dict[str, dict[str, Any] | str],
    ) -> list[ProxyRule]:
        rules = []
        for endpoint, response in responses.items():
            rules.append(self.set_response(client_ip, endpoint, response))
        return rules

    def set_modifier(
        self,
        client_ip: str,
        endpoint: str,
        *,
        name: str = "",
        json_set: dict[str, Any] | None = None,
        json_delete: list[str] | None = None,
        headers_set: dict[str, str] | None = None,
        headers_delete: list[str] | None = None,
    ) -> ProxyRule:
        self._validate_ip(client_ip)
        self._validate_endpoint(endpoint)
        if self._http:
            payload = {
                "name": name or f"Modify {endpoint} for {client_ip}",
                "client_ip": client_ip,
                "path_pattern": endpoint,
                "action": "modify",
                "json_set": json_set or {},
                "json_delete": json_delete or [],
                "headers_set": headers_set or {},
                "headers_delete": headers_delete or [],
            }
            try:
                data = self._http.request("POST", "/v1/proxy/rules", json_body=payload)
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        self._remove_matching_rules(client_ip, endpoint)
        rule = ProxyRule(
            name=name or f"Modify {endpoint} for {client_ip}",
            client_ip=client_ip,
            path_pattern=endpoint,
            action=ProxyAction.MODIFY,
            json_set=json_set or {},
            json_delete=json_delete or [],
            headers_set=headers_set or {},
            headers_delete=headers_delete or [],
        )
        return self.state.rules.add(rule)

    def set_error(
        self,
        client_ip: str,
        endpoint: str,
        status: int = 500,
        *,
        name: str = "",
        response: dict[str, Any] | str | None = None,
    ) -> ProxyRule:
        self._validate_ip(client_ip)
        self._validate_endpoint(endpoint)
        if self._http:
            body: dict[str, Any] = {
                "client_ip": client_ip,
                "endpoint": endpoint,
                "status": status,
            }
            if name:
                body["name"] = name
            if response is not None:
                body["response"] = response
            try:
                data = self._http.request("POST", "/v1/proxy/error", json_body=body)
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        self._remove_matching_rules(client_ip, endpoint)
        rule = ProxyRule(
            name=name or f"Error {status} for {endpoint} on {client_ip}",
            client_ip=client_ip,
            path_pattern=endpoint,
            action=ProxyAction.ERROR,
            response_status=status,
            response_body=response,
        )
        return self.state.rules.add(rule)

    def set_delay(
        self,
        client_ip: str,
        endpoint: str,
        delay_ms: int,
        *,
        name: str = "",
    ) -> ProxyRule:
        self._validate_ip(client_ip)
        self._validate_endpoint(endpoint)
        if self._http:
            payload = {
                "name": name or f"Delay {delay_ms}ms for {endpoint} on {client_ip}",
                "client_ip": client_ip,
                "path_pattern": endpoint,
                "action": "delay",
                "delay_ms": delay_ms,
            }
            try:
                data = self._http.request("POST", "/v1/proxy/rules", json_body=payload)
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        self._remove_matching_rules(client_ip, endpoint)
        rule = ProxyRule(
            name=name or f"Delay {delay_ms}ms for {endpoint} on {client_ip}",
            client_ip=client_ip,
            path_pattern=endpoint,
            action=ProxyAction.DELAY,
            delay_ms=delay_ms,
        )
        return self.state.rules.add(rule)

    def add_rule(self, rule: ProxyRule) -> ProxyRule:
        if self._http:
            try:
                data = self._http.request(
                    "POST",
                    "/v1/proxy/rules",
                    json_body=rule.to_dict(),
                )
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.add(rule)

    def get_rule(self, rule_id: str) -> ProxyRule | None:
        if self._http:
            try:
                data = self._http.request("GET", f"/v1/proxy/rules/{rule_id}")
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                if e.status_code == 404:
                    return None
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.get(rule_id)

    def update_rule(self, rule_id: str, **updates: Any) -> ProxyRule | None:
        if self._http:
            try:
                data = self._http.request(
                    "PUT",
                    f"/v1/proxy/rules/{rule_id}",
                    json_body=dict(updates),
                )
                return ProxyRule.from_dict(data["rule"])
            except ProxyRestError as e:
                if e.status_code == 404:
                    return None
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.update(rule_id, updates)

    def delete_rule(self, rule_id: str) -> bool:
        if self._http:
            try:
                self._http.request("DELETE", f"/v1/proxy/rules/{rule_id}")
                return True
            except ProxyRestError as e:
                if e.status_code == 404:
                    return False
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.delete(rule_id)

    def list_rules(
        self,
        client_ip: str | None = None,
    ) -> list[ProxyRule]:
        if self._http:
            params = {"client_ip": client_ip} if client_ip else None
            try:
                data = self._http.request("GET", "/v1/proxy/rules", params=params)
                return [ProxyRule.from_dict(r) for r in data.get("rules", [])]
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        if client_ip:
            return self.state.rules.list_by_client_ip(client_ip)
        return self.state.rules.list_all()

    def clear_endpoint(self, client_ip: str, endpoint: str) -> int:
        if self._http:
            try:
                data = self._http.request(
                    "POST",
                    "/v1/proxy/clear",
                    json_body={"client_ip": client_ip, "endpoint": endpoint},
                )
                return int(data.get("deleted_count", 0))
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        count = 0
        for rule in self.state.rules.list_by_client_ip(client_ip):
            if rule.path_pattern == endpoint:
                self.state.rules.delete(rule.id)
                count += 1
        return count

    def clear_device(self, client_ip: str) -> int:
        if self._http:
            try:
                data = self._http.request(
                    "POST",
                    "/v1/proxy/clear",
                    json_body={"client_ip": client_ip},
                )
                return int(data.get("deleted_count", 0))
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.delete_by_client_ip(client_ip)

    def clear_client(self, client_ip: str) -> int:
        """Alias for :meth:`clear_device` (testing kit / dashboard naming)."""
        return self.clear_device(client_ip)

    def clear_all(self) -> int:
        if self._http:
            try:
                data = self._http.request("DELETE", "/v1/proxy/rules")
                return int(data.get("deleted_count", 0))
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.rules.clear()

    # ------------------------------------------------------------------- log --

    def get_log(
        self,
        client_ip: str | None = None,
        *,
        client_ips: list[str] | None = None,
        limit: int = 100,
    ) -> list[ProxyLogEntry]:
        if self._http:
            params: dict[str, str] = {"limit": str(limit)}
            if client_ips:
                params["client_ips"] = ",".join(ip.strip() for ip in client_ips if ip.strip())
            elif client_ip:
                params["client_ip"] = client_ip
            try:
                data = self._http.request("GET", "/v1/proxy/log", params=params)
                return [
                    ProxyLogEntry.from_dict(e) for e in data.get("entries", [])
                ]
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        if client_ips:
            ip_set = {ip.strip() for ip in client_ips if ip.strip()}
            return self.state.logs.list_by_client_ips(ip_set, limit=limit)
        if client_ip:
            return self.state.logs.list_by_client_ip(client_ip, limit=limit)
        return self.state.logs.list_all(limit=limit)

    def search_log(
        self,
        client_ip: str | None = None,
        path_contains: str | None = None,
        method: str | None = None,
        status_min: int | None = None,
        status_max: int | None = None,
        limit: int = 100,
    ) -> list[ProxyLogEntry]:
        if self._http:
            entries = self.get_log(client_ip=client_ip, limit=min(limit * 4, 1000))
            return self._filter_log_entries(
                entries,
                path_contains=path_contains,
                method=method,
                status_min=status_min,
                status_max=status_max,
                limit=limit,
            )
        assert self.state is not None
        return self.state.logs.search(
            client_ip=client_ip,
            path_contains=path_contains,
            method=method,
            status_min=status_min,
            status_max=status_max,
            limit=limit,
        )

    @staticmethod
    def _filter_log_entries(
        entries: list[ProxyLogEntry],
        *,
        path_contains: str | None,
        method: str | None,
        status_min: int | None,
        status_max: int | None,
        limit: int,
    ) -> list[ProxyLogEntry]:
        out: list[ProxyLogEntry] = []
        for e in entries:
            if path_contains and path_contains not in e.path:
                continue
            if method and e.method.upper() != method.upper():
                continue
            if status_min is not None and e.response_status < status_min:
                continue
            if status_max is not None and e.response_status > status_max:
                continue
            out.append(e)
            if len(out) >= limit:
                break
        return out

    def clear_log(self, client_ip: str | None = None) -> int:
        if self._http:
            params = {"client_ip": client_ip} if client_ip else None
            try:
                data = self._http.request("DELETE", "/v1/proxy/log", params=params)
                return int(data.get("cleared_count", 0))
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        if client_ip:
            return self.state.logs.clear_by_client_ip(client_ip)
        return self.state.logs.clear()

    def log_stats(self) -> dict[str, Any]:
        if self._http:
            try:
                data = self._http.request("GET", "/v1/proxy/log", params={"limit": "1"})
                stats: dict[str, Any] = data.get("stats", {})
                return stats
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.logs.stats()

    def status(self) -> dict[str, Any]:
        if self._http:
            try:
                data = self._http.request("GET", "/v1/proxy/status")
                out = {k: v for k, v in data.items() if k != "ok"}
                out["remote_base_url"] = self._base_url
                return out
            except ProxyRestError as e:
                raise _map_rest_error(e) from e
        assert self.state is not None
        return self.state.get_status()

    def certs_status(self) -> dict[str, Any]:
        """Return mtk-serve (or local) MITM certificate store metadata from ``GET /v1/proxy/certs``."""

        if self._http:
            try:
                data = self._http.request("GET", "/v1/proxy/certs")
                return {k: v for k, v in data.items() if k != "ok"}
            except ProxyRestError as e:
                raise _map_rest_error(e) from e

        from mtk_router_sdk.proxy.certs import CertManager

        return CertManager(self._config.cert_dir).status()

    def import_ca_pem(
        self,
        ca_crt_pem: str,
        ca_key_pem: str,
        *,
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,
    ) -> dict[str, Any]:
        """Install CA cert + key on mtk-serve (or local cert dir when not using HTTP)."""

        if self._http:
            try:
                data = self._http.request(
                    "POST",
                    "/v1/proxy/certs/import",
                    json_body={
                        "ca_crt_pem": ca_crt_pem,
                        "ca_key_pem": ca_key_pem,
                        "proxy_cn": proxy_cn,
                        "validity_days": validity_days,
                    },
                )
                return {k: v for k, v in data.items() if k != "ok"}
            except ProxyRestError as e:
                raise _map_rest_error(e) from e

        from mtk_router_sdk.proxy.certs import CertError, CertManager

        try:
            cm = CertManager(self._config.cert_dir)
            return cm.import_ca_pem_strings(
                ca_crt_pem,
                ca_key_pem,
                proxy_cn=proxy_cn,
                validity_days=validity_days,
            )
        except CertError as e:
            raise ProxyError(e.message, code=e.code) from e

    def import_ca_pkcs12_base64(
        self,
        pkcs12_base64: str,
        *,
        password: str | None = None,
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,
    ) -> dict[str, Any]:
        """Install CA from base64-encoded PKCS#12 (e.g. Charles ``root-ca.p12`` export)."""

        import base64

        b64 = (pkcs12_base64 or "").strip()
        if not b64:
            raise ProxyError("pkcs12_base64 is empty", code="INVALID_P12")
        try:
            raw = base64.b64decode(b64)
        except Exception as e:
            raise ProxyError("Invalid PKCS#12 base64", code="INVALID_BASE64") from e
        if self._http:
            try:
                body: dict[str, Any] = {
                    "pkcs12_base64": b64,
                    "proxy_cn": proxy_cn,
                    "validity_days": validity_days,
                }
                if password is not None:
                    body["p12_password"] = password
                data = self._http.request(
                    "POST",
                    "/v1/proxy/certs/import",
                    json_body=body,
                )
                return {k: v for k, v in data.items() if k != "ok"}
            except ProxyRestError as e:
                raise _map_rest_error(e) from e

        from mtk_router_sdk.proxy.certs import CertError, CertManager

        try:
            cm = CertManager(self._config.cert_dir)
            return cm.import_ca_pkcs12_bytes(
                raw,
                password=password,
                proxy_cn=proxy_cn,
                validity_days=validity_days,
            )
        except CertError as e:
            raise ProxyError(e.message, code=e.code) from e

    # -------------------------------------------------------------- helpers --

    def _validate_ip(self, ip: str) -> None:
        if not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", ip):
            raise ProxyError(
                f"Invalid IP address format: {ip}. Expected format: x.x.x.x",
                code="INVALID_IP",
            )

    def _validate_endpoint(self, endpoint: str) -> None:
        if not endpoint:
            raise ProxyError(
                "Endpoint cannot be empty",
                code="INVALID_ENDPOINT",
            )
        if not endpoint.startswith("/") and endpoint != "*":
            raise ProxyError(
                f"Endpoint must start with '/' or be '*': {endpoint}",
                code="INVALID_ENDPOINT",
            )

    def _remove_matching_rules(self, client_ip: str, endpoint: str) -> int:
        assert self.state is not None
        count = 0
        for rule in self.state.rules.list_by_client_ip(client_ip):
            if rule.path_pattern == endpoint:
                self.state.rules.delete(rule.id)
                count += 1
        return count
