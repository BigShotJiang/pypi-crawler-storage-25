"""
MTK Proxy Engine - API Response Interception and Modification.

Professional-grade proxy for testing streaming applications. Intercept, modify,
and mock API responses per-client IP with full logging and UI dashboard.

Quick Start:
    from mtk_router_sdk.proxy import ProxyManager

    # Control the running mtk-serve (default: http://127.0.0.1:8765)
    proxy = ProxyManager.from_env()
    proxy.set_response("192.168.2.100", "/api/v1/region", {"region": "US"})

    # In-process rules only (unit tests): ProxyManager()

Features:
    - Per-client IP rules (no interference between devices)
    - Override, modify, delay, or error responses
    - Full request/response logging
    - Real-time on-demand control
    - Professional web dashboard
    - Certificate management for HTTPS
    - Native HTTP forward proxy (Android Wi-Fi Manual Proxy support)

Forward Proxy (for Android system proxy):
    mtk-serve automatically starts a forward proxy on port 8888 (MTK_PROXY_PORT).
    Configure Android Wi-Fi Manual Proxy to connect directly without app changes.
"""

from mtk_router_sdk.proxy.certs import CertError, CertInfo, CertManager
from mtk_router_sdk.proxy.forward_proxy import (
    ForwardProxyServer,
    start_forward_proxy,
    stop_forward_proxy,
)
from mtk_router_sdk.proxy.models import (
    ProxyAction,
    ProxyLogEntry,
    ProxyRule,
    ProxyStatus,
)
from mtk_router_sdk.proxy.sdk import ProxyManager
from mtk_router_sdk.proxy.store import ProxyRuleStore

__all__ = [
    "CertError",
    "CertInfo",
    "CertManager",
    "ForwardProxyServer",
    "ProxyAction",
    "ProxyLogEntry",
    "ProxyManager",
    "ProxyRule",
    "ProxyRuleStore",
    "ProxyStatus",
    "start_forward_proxy",
    "stop_forward_proxy",
]
