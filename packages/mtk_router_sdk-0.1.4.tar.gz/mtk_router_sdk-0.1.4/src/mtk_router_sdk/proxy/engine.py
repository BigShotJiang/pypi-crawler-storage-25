"""Core proxy engine - request processing and response modification."""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from typing import Any

from mtk_router_sdk.proxy.models import (
    ProxyAction,
    ProxyLogEntry,
    ProxyRule,
)
from mtk_router_sdk.proxy.store import ProxyState
from mtk_router_sdk.proxy.upstream import AsyncUpstreamClient


class ProxyEngine:
    """Main proxy engine that processes requests through rules."""

    def __init__(self, state: ProxyState) -> None:
        self.state = state
        self._upstream = AsyncUpstreamClient(
            timeout=state.config.upstream_timeout,
            verify_ssl=True,
        )

    async def close(self) -> None:
        """Close the engine and its resources."""
        await self._upstream.close()

    async def process_request(
        self,
        client_ip: str,
        method: str,
        upstream_host: str,
        path: str,
        query_string: str,
        headers: dict[str, str],
        body: bytes | None,
        slot_id: int | None = None,
    ) -> tuple[int, dict[str, str], bytes, ProxyLogEntry]:
        """Process a proxy request through the rule engine.

        Returns:
            Tuple of (status_code, headers, body, log_entry)
        """
        start_time = time.time()
        log_entry = ProxyLogEntry(
            timestamp=datetime.utcnow(),
            client_ip=client_ip,
            method=method,
            upstream_host=upstream_host,
            path=path,
            query_string=query_string,
            request_headers=dict(headers),
            request_body=self._truncate_body(body) if body else None,
            request_body_size=len(body) if body else 0,
        )

        try:
            # Find matching rule
            rule = self.state.rules.find_matching(
                client_ip=client_ip,
                host=upstream_host,
                path=path,
                method=method,
                slot_id=slot_id,
            )

            if rule:
                log_entry.matched_rule_id = rule.id
                log_entry.matched_rule_name = rule.name
                log_entry.action_taken = rule.action.value
                self.state.rules.increment_hit_count(rule.id)

                # Apply delay if configured
                if rule.delay_ms > 0:
                    await asyncio.sleep(rule.delay_ms / 1000.0)

                # Process based on action
                if rule.action == ProxyAction.OVERRIDE:
                    status, resp_headers, resp_body = self._build_override_response(
                        rule
                    )
                elif rule.action == ProxyAction.ERROR:
                    status, resp_headers, resp_body = self._build_error_response(rule)
                elif rule.action == ProxyAction.PASSTHROUGH:
                    status, resp_headers, resp_body = await self._passthrough(
                        method,
                        upstream_host,
                        path,
                        query_string,
                        headers,
                        body,
                        log_entry,
                    )
                elif rule.action == ProxyAction.MODIFY:
                    status, resp_headers, resp_body = await self._passthrough_and_modify(
                        method,
                        upstream_host,
                        path,
                        query_string,
                        headers,
                        body,
                        rule,
                        log_entry,
                    )
                elif rule.action == ProxyAction.DELAY:
                    # Delay already applied, pass through
                    status, resp_headers, resp_body = await self._passthrough(
                        method,
                        upstream_host,
                        path,
                        query_string,
                        headers,
                        body,
                        log_entry,
                    )
                else:
                    # Unknown action, pass through
                    status, resp_headers, resp_body = await self._passthrough(
                        method,
                        upstream_host,
                        path,
                        query_string,
                        headers,
                        body,
                        log_entry,
                    )
            else:
                # No matching rule, pass through to upstream
                log_entry.action_taken = "passthrough"
                status, resp_headers, resp_body = await self._passthrough(
                    method,
                    upstream_host,
                    path,
                    query_string,
                    headers,
                    body,
                    log_entry,
                )

            # Finalize log entry
            log_entry.response_status = status
            log_entry.response_headers = resp_headers
            log_entry.response_body = self._truncate_body(resp_body)
            log_entry.response_body_size = len(resp_body)
            log_entry.total_latency_ms = int((time.time() - start_time) * 1000)

            # Store log entry
            self.state.logs.add(log_entry)

            return status, resp_headers, resp_body, log_entry

        except Exception as e:
            log_entry.error = str(e)
            log_entry.response_status = 500
            log_entry.total_latency_ms = int((time.time() - start_time) * 1000)
            self.state.logs.add(log_entry)

            error_body = json.dumps({
                "error": "Proxy engine error",
                "message": str(e),
                "client_ip": client_ip,
                "path": path,
            }).encode()

            return 500, {"Content-Type": "application/json"}, error_body, log_entry

    def _build_override_response(
        self, rule: ProxyRule
    ) -> tuple[int, dict[str, str], bytes]:
        """Build response from rule's override configuration."""
        status = rule.response_status
        headers = dict(rule.response_headers)

        if rule.response_body is None:
            body = b""
        elif isinstance(rule.response_body, (dict, list)):
            body = json.dumps(rule.response_body).encode()
            if "Content-Type" not in headers:
                headers["Content-Type"] = "application/json"
        elif isinstance(rule.response_body, str):
            body = rule.response_body.encode()
        else:
            body = str(rule.response_body).encode()

        return status, headers, body

    def _build_error_response(
        self, rule: ProxyRule
    ) -> tuple[int, dict[str, str], bytes]:
        """Build error response from rule configuration."""
        status = rule.response_status if rule.response_status >= 400 else 500
        headers = dict(rule.response_headers)

        if rule.response_body:
            if isinstance(rule.response_body, (dict, list)):
                body = json.dumps(rule.response_body).encode()
                headers.setdefault("Content-Type", "application/json")
            else:
                body = str(rule.response_body).encode()
        else:
            body = json.dumps({
                "error": f"HTTP {status}",
                "message": f"Simulated error from rule: {rule.name or rule.id}",
            }).encode()
            headers.setdefault("Content-Type", "application/json")

        return status, headers, body

    async def _passthrough(
        self,
        method: str,
        upstream_host: str,
        path: str,
        query_string: str,
        headers: dict[str, str],
        body: bytes | None,
        log_entry: ProxyLogEntry,
    ) -> tuple[int, dict[str, str], bytes]:
        """Forward request to upstream and return response."""
        url = f"https://{upstream_host}{path}"
        if query_string:
            url = f"{url}?{query_string}"

        # Update Host header for upstream
        upstream_headers = dict(headers)
        upstream_headers["Host"] = upstream_host

        log_entry.upstream_called = True
        response = await self._upstream.request(
            method=method,
            url=url,
            headers=upstream_headers,
            body=body,
        )

        log_entry.upstream_status = response.status_code
        log_entry.upstream_latency_ms = response.latency_ms

        if response.error:
            log_entry.error = response.error

        return response.status_code, response.headers, response.body

    async def _passthrough_and_modify(
        self,
        method: str,
        upstream_host: str,
        path: str,
        query_string: str,
        headers: dict[str, str],
        body: bytes | None,
        rule: ProxyRule,
        log_entry: ProxyLogEntry,
    ) -> tuple[int, dict[str, str], bytes]:
        """Forward request to upstream, then modify the response."""
        status, resp_headers, resp_body = await self._passthrough(
            method, upstream_host, path, query_string, headers, body, log_entry
        )

        # Modify response headers
        for key in rule.headers_delete:
            resp_headers.pop(key, None)
        for key, value in rule.headers_set.items():
            resp_headers[key] = value

        # Modify response body (if JSON)
        if rule.json_set or rule.json_delete:
            try:
                data = json.loads(resp_body)
                data = self._apply_json_modifications(
                    data, rule.json_set, rule.json_delete
                )
                resp_body = json.dumps(data).encode()
                resp_headers["Content-Type"] = "application/json"
            except (json.JSONDecodeError, TypeError):
                # Body is not JSON, skip modification
                pass

        return status, resp_headers, resp_body

    def _apply_json_modifications(
        self,
        data: Any,
        json_set: dict[str, Any],
        json_delete: list[str],
    ) -> Any:
        """Apply JSONPath-like modifications to data.

        Supports simple paths like $.key, $.nested.key, $.array[0].key
        """
        import copy

        data = copy.deepcopy(data)

        # Apply deletions first
        for path in json_delete:
            data = self._json_delete_path(data, path)

        # Apply sets
        for path, value in json_set.items():
            data = self._json_set_path(data, path, value)

        return data

    def _json_set_path(self, data: Any, path: str, value: Any) -> Any:
        """Set a value at a JSONPath-like path."""
        if path.startswith("$."):
            path = path[2:]

        parts = self._parse_json_path(path)
        if not parts:
            return value

        current = data
        for part in parts[:-1]:
            if isinstance(part, int):
                if isinstance(current, list) and 0 <= part < len(current):
                    current = current[part]
                else:
                    return data
            else:
                if isinstance(current, dict):
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                else:
                    return data

        last_part = parts[-1]
        if isinstance(last_part, int):
            if isinstance(current, list) and 0 <= last_part < len(current):
                current[last_part] = value
        elif isinstance(current, dict):
            current[last_part] = value

        return data

    def _json_delete_path(self, data: Any, path: str) -> Any:
        """Delete a value at a JSONPath-like path."""
        if path.startswith("$."):
            path = path[2:]

        parts = self._parse_json_path(path)
        if not parts:
            return data

        current = data
        for part in parts[:-1]:
            if isinstance(part, int):
                if isinstance(current, list) and 0 <= part < len(current):
                    current = current[part]
                else:
                    return data
            else:
                if isinstance(current, dict) and part in current:
                    current = current[part]
                else:
                    return data

        last_part = parts[-1]
        if isinstance(last_part, int):
            if isinstance(current, list) and 0 <= last_part < len(current):
                del current[last_part]
        elif isinstance(current, dict) and last_part in current:
            del current[last_part]

        return data

    def _parse_json_path(self, path: str) -> list[str | int]:
        """Parse a simple JSONPath into parts."""
        import re

        parts: list[str | int] = []
        for part in re.split(r"\.|\[|\]", path):
            part = part.strip()
            if not part:
                continue
            if part.isdigit():
                parts.append(int(part))
            else:
                parts.append(part)
        return parts

    def _truncate_body(self, body: bytes | None) -> str | None:
        """Truncate body for logging."""
        if body is None:
            return None

        config = self.state.config
        if not config.log_response_body:
            return "[body logging disabled]"

        if len(body) > config.log_body_max_size:
            return f"[truncated, {len(body)} bytes total]"

        try:
            return body.decode("utf-8")
        except UnicodeDecodeError:
            return f"[binary, {len(body)} bytes]"
