"""In-memory storage for proxy rules and request logs."""

from __future__ import annotations

import threading
from collections import deque
from datetime import datetime
from typing import Any

from mtk_router_sdk.proxy.models import ProxyConfig, ProxyLogEntry, ProxyRule


def _path_pattern_specificity(path_pattern: str) -> int:
    """Tiebreaker when priorities are equal: longer / less-wildcard patterns first."""

    if path_pattern == "*":
        return 0
    if path_pattern.startswith("~"):
        return max(len(path_pattern) - 1, 1)
    return len(path_pattern)


class ProxyRuleStore:
    """Thread-safe in-memory storage for proxy rules.

    Rules are matched in priority order (highest first), then by creation time.
    """

    def __init__(self) -> None:
        self._rules: dict[str, ProxyRule] = {}
        self._lock = threading.RLock()

    def add(self, rule: ProxyRule) -> ProxyRule:
        """Add a new rule."""
        with self._lock:
            rule.created_at = datetime.utcnow()
            rule.updated_at = rule.created_at
            self._rules[rule.id] = rule
            return rule

    def get(self, rule_id: str) -> ProxyRule | None:
        """Get a rule by ID."""
        with self._lock:
            return self._rules.get(rule_id)

    def update(self, rule_id: str, updates: dict[str, Any]) -> ProxyRule | None:
        """Update a rule. Returns None if not found."""
        with self._lock:
            rule = self._rules.get(rule_id)
            if not rule:
                return None
            for key, value in updates.items():
                if hasattr(rule, key):
                    setattr(rule, key, value)
            rule.updated_at = datetime.utcnow()
            return rule

    def delete(self, rule_id: str) -> bool:
        """Delete a rule. Returns True if deleted."""
        with self._lock:
            if rule_id in self._rules:
                del self._rules[rule_id]
                return True
            return False

    def delete_by_client_ip(self, client_ip: str) -> int:
        """Delete all rules for a client IP. Returns count deleted."""
        with self._lock:
            to_delete = [
                rid for rid, r in self._rules.items() if r.client_ip == client_ip
            ]
            for rid in to_delete:
                del self._rules[rid]
            return len(to_delete)

    def clear(self) -> int:
        """Clear all rules. Returns count cleared."""
        with self._lock:
            count = len(self._rules)
            self._rules.clear()
            return count

    def list_all(self) -> list[ProxyRule]:
        """List all rules, sorted by priority (desc), path specificity, then created_at."""

        with self._lock:
            rules = list(self._rules.values())
            rules.sort(
                key=lambda r: (
                    -r.priority,
                    -_path_pattern_specificity(r.path_pattern),
                    r.created_at,
                )
            )
            return rules

    def list_by_client_ip(self, client_ip: str) -> list[ProxyRule]:
        """List rules for a specific client IP."""
        with self._lock:
            rules = [r for r in self._rules.values() if r.client_ip == client_ip]
            rules.sort(
                key=lambda r: (
                    -r.priority,
                    -_path_pattern_specificity(r.path_pattern),
                    r.created_at,
                )
            )
            return rules

    def find_matching(
        self,
        client_ip: str,
        host: str,
        path: str,
        method: str,
        slot_id: int | None = None,
    ) -> ProxyRule | None:
        """Find the first matching rule for a request."""
        with self._lock:
            rules = self.list_all()
            for rule in rules:
                if rule.matches_request(client_ip, host, path, method, slot_id):
                    return rule
            return None

    def increment_hit_count(self, rule_id: str) -> None:
        """Increment the hit count for a rule."""
        with self._lock:
            rule = self._rules.get(rule_id)
            if rule:
                rule.hit_count += 1

    def count(self) -> int:
        """Return total number of rules."""
        with self._lock:
            return len(self._rules)

    def to_list(self) -> list[dict[str, Any]]:
        """Export all rules as list of dicts."""
        return [r.to_dict() for r in self.list_all()]


class ProxyLogStore:
    """Thread-safe circular buffer for request logs."""

    def __init__(self, max_entries: int = 1000) -> None:
        self._max_entries = max_entries
        self._entries: deque[ProxyLogEntry] = deque(maxlen=max_entries)
        self._lock = threading.RLock()

    def add(self, entry: ProxyLogEntry) -> None:
        """Add a log entry (oldest entries are automatically removed)."""
        with self._lock:
            self._entries.append(entry)

    def get(self, entry_id: str) -> ProxyLogEntry | None:
        """Get a specific log entry by ID."""
        with self._lock:
            for entry in self._entries:
                if entry.id == entry_id:
                    return entry
            return None

    def list_all(self, limit: int = 100, offset: int = 0) -> list[ProxyLogEntry]:
        """List log entries (newest first)."""
        with self._lock:
            entries = list(reversed(self._entries))
            return entries[offset : offset + limit]

    def list_by_client_ip(
        self, client_ip: str, limit: int = 100
    ) -> list[ProxyLogEntry]:
        """List log entries for a specific client IP."""
        with self._lock:
            entries = [e for e in reversed(self._entries) if e.client_ip == client_ip]
            return entries[:limit]

    def list_by_client_ips(
        self, client_ips: set[str], limit: int = 100
    ) -> list[ProxyLogEntry]:
        """Newest-first entries whose client_ip is in ``client_ips``."""
        if not client_ips:
            return self.list_all(limit=limit)
        with self._lock:
            entries = [e for e in reversed(self._entries) if e.client_ip in client_ips]
            return entries[:limit]

    def list_by_rule(self, rule_id: str, limit: int = 100) -> list[ProxyLogEntry]:
        """List log entries that matched a specific rule."""
        with self._lock:
            entries = [
                e for e in reversed(self._entries) if e.matched_rule_id == rule_id
            ]
            return entries[:limit]

    def search(
        self,
        client_ip: str | None = None,
        path_contains: str | None = None,
        method: str | None = None,
        status_min: int | None = None,
        status_max: int | None = None,
        limit: int = 100,
    ) -> list[ProxyLogEntry]:
        """Search log entries with filters."""
        with self._lock:
            entries = list(reversed(self._entries))
            results: list[ProxyLogEntry] = []
            for e in entries:
                if len(results) >= limit:
                    break
                if client_ip and e.client_ip != client_ip:
                    continue
                if path_contains and path_contains not in e.path:
                    continue
                if method and e.method.upper() != method.upper():
                    continue
                if status_min is not None and e.response_status < status_min:
                    continue
                if status_max is not None and e.response_status > status_max:
                    continue
                results.append(e)
            return results

    def clear(self) -> int:
        """Clear all log entries. Returns count cleared."""
        with self._lock:
            count = len(self._entries)
            self._entries.clear()
            return count

    def clear_by_client_ip(self, client_ip: str) -> int:
        """Clear log entries for a client IP."""
        with self._lock:
            new_entries = deque(
                (e for e in self._entries if e.client_ip != client_ip),
                maxlen=self._max_entries,
            )
            count = len(self._entries) - len(new_entries)
            self._entries = new_entries
            return count

    def count(self) -> int:
        """Return total number of log entries."""
        with self._lock:
            return len(self._entries)

    def stats(self) -> dict[str, Any]:
        """Get log statistics."""
        with self._lock:
            if not self._entries:
                return {
                    "total_entries": 0,
                    "unique_clients": 0,
                    "unique_paths": 0,
                    "avg_latency_ms": 0,
                    "error_count": 0,
                }
            clients = set(e.client_ip for e in self._entries)
            paths = set(e.path for e in self._entries)
            latencies = [e.total_latency_ms for e in self._entries]
            errors = sum(1 for e in self._entries if e.response_status >= 400)
            return {
                "total_entries": len(self._entries),
                "unique_clients": len(clients),
                "unique_paths": len(paths),
                "avg_latency_ms": sum(latencies) / len(latencies) if latencies else 0,
                "error_count": errors,
            }

    def to_list(self, limit: int = 100) -> list[dict[str, Any]]:
        """Export log entries as list of dicts."""
        return [e.to_dict() for e in self.list_all(limit=limit)]


class ProxyState:
    """Global proxy state container."""

    def __init__(self, config: ProxyConfig | None = None) -> None:
        self.config = config or ProxyConfig()
        self.rules = ProxyRuleStore()
        self.logs = ProxyLogStore(max_entries=self.config.log_max_entries)
        self.status = "stopped"
        self.started_at: datetime | None = None
        self.error_message: str | None = None
        self._lock = threading.RLock()

    def set_status(self, status: str, error: str | None = None) -> None:
        """Update proxy status."""
        with self._lock:
            self.status = status
            self.error_message = error
            if status == "running":
                self.started_at = datetime.utcnow()
            elif status == "stopped":
                self.started_at = None

    def get_status(self) -> dict[str, Any]:
        """Get current proxy status."""
        with self._lock:
            return {
                "status": self.status,
                "started_at": self.started_at.isoformat() if self.started_at else None,
                "error": self.error_message,
                "rules_count": self.rules.count(),
                "logs_count": self.logs.count(),
                "config": self.config.to_dict(),
            }
