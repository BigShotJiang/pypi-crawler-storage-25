"""CLI commands for proxy management."""

from __future__ import annotations

import argparse
import json
from typing import Any

from mtk_router_sdk.proxy.models import ProxyAction, ProxyRule
from mtk_router_sdk.proxy.sdk import ProxyError, ProxyManager


def _get_proxy(args: argparse.Namespace) -> ProxyManager:
    """Get proxy manager, optionally from site file."""
    if hasattr(args, "site_config_path") and args.site_config_path:
        return ProxyManager.from_site(args.site_config_path)
    return ProxyManager.from_env()


def _print_json(data: Any) -> None:
    """Print JSON with proper formatting."""
    print(json.dumps(data, indent=2, default=str))


def _print_error(message: str, code: str = "ERROR") -> int:
    """Print error and return exit code 1."""
    print(json.dumps({"ok": False, "error": message, "code": code}, indent=2))
    return 1


def cmd_proxy_certs_status(args: argparse.Namespace) -> int:
    """Show certificate status."""
    from mtk_router_sdk.proxy.certs import CertManager

    certs = CertManager()
    status = certs.status()
    _print_json({"ok": True, **status})
    return 0


def cmd_proxy_certs_generate(args: argparse.Namespace) -> int:
    """Generate HTTPS certificates."""
    from mtk_router_sdk.proxy.certs import CertError, CertManager

    try:
        certs = CertManager()
        result = certs.ensure_certs(force=args.force)
        _print_json({"ok": True, **result})
        return 0
    except CertError as e:
        return _print_error(e.message, e.code)


# -----------------------------------------------------------------------------
# Rule commands
# -----------------------------------------------------------------------------


def cmd_proxy_rule_list(args: argparse.Namespace) -> int:
    """List proxy rules."""
    proxy = _get_proxy(args)
    client_ip = getattr(args, "client_ip", None)

    rules = proxy.list_rules(client_ip=client_ip)
    _print_json({
        "ok": True,
        "rules": [r.to_dict() for r in rules],
        "count": len(rules),
    })
    return 0


def cmd_proxy_rule_add(args: argparse.Namespace) -> int:
    """Add a proxy rule."""
    proxy = _get_proxy(args)

    try:
        # Determine action
        action = ProxyAction(args.action)

        # Parse response if provided
        response = None
        if args.response:
            try:
                response = json.loads(args.response)
            except json.JSONDecodeError:
                response = args.response  # Use as string

        # Parse json_set if provided
        json_set = {}
        if args.json_set:
            for item in args.json_set:
                if "=" in item:
                    path, value = item.split("=", 1)
                    try:
                        json_set[path] = json.loads(value)
                    except json.JSONDecodeError:
                        json_set[path] = value

        # Create appropriate rule based on action
        if action == ProxyAction.OVERRIDE:
            rule = proxy.set_response(
                args.client_ip,
                args.endpoint,
                response or {},
                name=args.name or "",
                status=args.status or 200,
            )
        elif action == ProxyAction.ERROR:
            rule = proxy.set_error(
                args.client_ip,
                args.endpoint,
                status=args.status or 500,
                name=args.name or "",
                response=response,
            )
        elif action == ProxyAction.MODIFY:
            rule = proxy.set_modifier(
                args.client_ip,
                args.endpoint,
                name=args.name or "",
                json_set=json_set,
            )
        elif action == ProxyAction.DELAY:
            rule = proxy.set_delay(
                args.client_ip,
                args.endpoint,
                delay_ms=args.delay_ms or 1000,
                name=args.name or "",
            )
        else:
            # Passthrough or custom
            rule = ProxyRule(
                name=args.name or f"Rule for {args.client_ip}",
                client_ip=args.client_ip,
                path_pattern=args.endpoint,
                action=action,
            )
            rule = proxy.add_rule(rule)

        _print_json({"ok": True, "rule": rule.to_dict()})
        return 0

    except ProxyError as e:
        return _print_error(e.message, e.code)
    except Exception as e:
        return _print_error(str(e))


def cmd_proxy_rule_delete(args: argparse.Namespace) -> int:
    """Delete a proxy rule."""
    proxy = _get_proxy(args)

    if args.rule_id:
        deleted = proxy.delete_rule(args.rule_id)
        if not deleted:
            return _print_error(f"Rule not found: {args.rule_id}", "NOT_FOUND")
        _print_json({"ok": True, "deleted": args.rule_id})
    else:
        return _print_error("Rule ID is required", "MISSING_ARGUMENT")

    return 0


def cmd_proxy_rule_clear(args: argparse.Namespace) -> int:
    """Clear proxy rules."""
    proxy = _get_proxy(args)

    if args.client_ip:
        count = proxy.clear_device(args.client_ip)
        _print_json({"ok": True, "deleted_count": count, "client_ip": args.client_ip})
    elif args.all:
        count = proxy.clear_all()
        _print_json({"ok": True, "deleted_count": count})
    else:
        return _print_error(
            "Specify --client-ip or --all", "MISSING_ARGUMENT"
        )

    return 0


# -----------------------------------------------------------------------------
# Quick commands (set/error/clear)
# -----------------------------------------------------------------------------


def cmd_proxy_set(args: argparse.Namespace) -> int:
    """Quick set response for endpoint."""
    proxy = _get_proxy(args)

    try:
        response = json.loads(args.response)
    except json.JSONDecodeError:
        response = args.response

    try:
        rule = proxy.set_response(
            args.client_ip,
            args.endpoint,
            response,
            status=args.status or 200,
        )
        _print_json({"ok": True, "rule": rule.to_dict()})
        return 0
    except ProxyError as e:
        return _print_error(e.message, e.code)


def cmd_proxy_error(args: argparse.Namespace) -> int:
    """Quick set error for endpoint."""
    proxy = _get_proxy(args)

    try:
        rule = proxy.set_error(
            args.client_ip,
            args.endpoint,
            status=args.status or 500,
        )
        _print_json({"ok": True, "rule": rule.to_dict()})
        return 0
    except ProxyError as e:
        return _print_error(e.message, e.code)


def cmd_proxy_clear(args: argparse.Namespace) -> int:
    """Quick clear endpoint or device."""
    proxy = _get_proxy(args)

    if args.endpoint:
        count = proxy.clear_endpoint(args.client_ip, args.endpoint)
    else:
        count = proxy.clear_device(args.client_ip)

    _print_json({"ok": True, "deleted_count": count})
    return 0


# -----------------------------------------------------------------------------
# Log commands
# -----------------------------------------------------------------------------


def cmd_proxy_log(args: argparse.Namespace) -> int:
    """Show proxy request log."""
    proxy = _get_proxy(args)

    client_ip = getattr(args, "client_ip", None)
    limit = getattr(args, "limit", 50)

    entries = proxy.get_log(client_ip=client_ip, limit=limit)
    stats = proxy.log_stats()

    _print_json({
        "ok": True,
        "entries": [e.to_dict() for e in entries],
        "count": len(entries),
        "stats": stats,
    })
    return 0


def cmd_proxy_log_clear(args: argparse.Namespace) -> int:
    """Clear proxy log."""
    proxy = _get_proxy(args)

    client_ip = getattr(args, "client_ip", None)
    count = proxy.clear_log(client_ip=client_ip)

    _print_json({"ok": True, "cleared_count": count})
    return 0


# -----------------------------------------------------------------------------
# Status command
# -----------------------------------------------------------------------------


def cmd_proxy_status(args: argparse.Namespace) -> int:
    """Show proxy status."""
    proxy = _get_proxy(args)
    status = proxy.status()
    _print_json({"ok": True, **status})
    return 0


# -----------------------------------------------------------------------------
# Register CLI commands
# -----------------------------------------------------------------------------


def register_proxy_commands(sub: Any) -> None:
    """Register proxy subcommands."""

    # Main proxy command with subcommands
    p_proxy = sub.add_parser(
        "proxy",
        help="API response proxy for testing (intercept, modify, mock)",
    )
    proxy_sub = p_proxy.add_subparsers(dest="proxy_cmd", required=True)

    # proxy status
    p_status = proxy_sub.add_parser("status", help="show proxy status")
    p_status.set_defaults(func=cmd_proxy_status)

    # proxy rule list
    p_rule_list = proxy_sub.add_parser("list", help="list proxy rules")
    p_rule_list.add_argument(
        "--client-ip", dest="client_ip", help="filter by client IP"
    )
    p_rule_list.set_defaults(func=cmd_proxy_rule_list)

    # proxy rule add
    p_rule_add = proxy_sub.add_parser("add", help="add a proxy rule")
    p_rule_add.add_argument("client_ip", help="client IP address")
    p_rule_add.add_argument("endpoint", help="endpoint path pattern")
    p_rule_add.add_argument(
        "--action",
        choices=["override", "passthrough", "modify", "delay", "error"],
        default="override",
        help="action to take (default: override)",
    )
    p_rule_add.add_argument("--name", help="rule name")
    p_rule_add.add_argument(
        "--response", help="response body (JSON string or plain text)"
    )
    p_rule_add.add_argument("--status", type=int, help="HTTP status code")
    p_rule_add.add_argument("--delay-ms", type=int, help="delay in milliseconds")
    p_rule_add.add_argument(
        "--json-set",
        action="append",
        metavar="PATH=VALUE",
        help="JSONPath modifications (e.g., $.region=US)",
    )
    p_rule_add.set_defaults(func=cmd_proxy_rule_add)

    # proxy rule delete
    p_rule_del = proxy_sub.add_parser("delete", help="delete a proxy rule")
    p_rule_del.add_argument("rule_id", help="rule ID to delete")
    p_rule_del.set_defaults(func=cmd_proxy_rule_delete)

    # proxy rule clear
    p_rule_clear = proxy_sub.add_parser("clear", help="clear proxy rules")
    p_rule_clear.add_argument("--client-ip", dest="client_ip", help="clear for IP")
    p_rule_clear.add_argument("--all", action="store_true", help="clear all rules")
    p_rule_clear.set_defaults(func=cmd_proxy_rule_clear)

    # proxy set (quick command)
    p_set = proxy_sub.add_parser("set", help="quick set response for endpoint")
    p_set.add_argument("client_ip", help="client IP address")
    p_set.add_argument("endpoint", help="endpoint path pattern")
    p_set.add_argument("response", help="response body (JSON)")
    p_set.add_argument("--status", type=int, default=200, help="HTTP status")
    p_set.set_defaults(func=cmd_proxy_set)

    # proxy error (quick command)
    p_err = proxy_sub.add_parser("error", help="quick set error for endpoint")
    p_err.add_argument("client_ip", help="client IP address")
    p_err.add_argument("endpoint", help="endpoint path pattern")
    p_err.add_argument("--status", type=int, default=500, help="HTTP error status")
    p_err.set_defaults(func=cmd_proxy_error)

    # proxy log
    p_log = proxy_sub.add_parser("log", help="show request log")
    p_log.add_argument("--client-ip", dest="client_ip", help="filter by client IP")
    p_log.add_argument("--limit", type=int, default=50, help="max entries to show")
    p_log.set_defaults(func=cmd_proxy_log)

    # proxy log clear
    p_log_clear = proxy_sub.add_parser("log-clear", help="clear request log")
    p_log_clear.add_argument("--client-ip", dest="client_ip", help="clear for IP only")
    p_log_clear.set_defaults(func=cmd_proxy_log_clear)

    # proxy certs (certificate management)
    p_certs = proxy_sub.add_parser("certs", help="show certificate status")
    p_certs.set_defaults(func=cmd_proxy_certs_status)

    # proxy certs generate
    p_certs_gen = proxy_sub.add_parser(
        "certs-generate", help="generate HTTPS certificates"
    )
    p_certs_gen.add_argument(
        "--force", action="store_true", help="regenerate even if exist"
    )
    p_certs_gen.set_defaults(func=cmd_proxy_certs_generate)
