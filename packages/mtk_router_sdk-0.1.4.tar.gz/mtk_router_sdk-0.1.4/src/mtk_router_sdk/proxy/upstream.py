"""HTTP client for upstream (real backend) requests."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class UpstreamResponse:
    """Response from upstream server."""

    status_code: int
    headers: dict[str, str]
    body: bytes
    latency_ms: int
    error: str | None = None

    @property
    def ok(self) -> bool:
        """Check if request succeeded."""
        return self.error is None and 200 <= self.status_code < 400

    def json(self) -> Any:
        """Parse body as JSON."""
        import json

        return json.loads(self.body.decode("utf-8"))

    def text(self) -> str:
        """Decode body as text."""
        return self.body.decode("utf-8")


class UpstreamClient:
    """HTTP client for forwarding requests to upstream servers."""

    def __init__(
        self,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        follow_redirects: bool = True,
    ) -> None:
        self._timeout = timeout
        self._verify_ssl = verify_ssl
        self._follow_redirects = follow_redirects
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                timeout=self._timeout,
                verify=self._verify_ssl,
                follow_redirects=self._follow_redirects,
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def request(
        self,
        method: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        timeout: float | None = None,
    ) -> UpstreamResponse:
        """Make a request to upstream server.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: Full URL to request
            headers: Request headers (filtered to remove hop-by-hop)
            body: Request body
            timeout: Override default timeout

        Returns:
            UpstreamResponse with status, headers, body, latency
        """
        # Filter hop-by-hop headers
        filtered_headers = self._filter_headers(headers or {})

        start_time = time.time()
        try:
            client = self._get_client()
            response = client.request(
                method=method,
                url=url,
                headers=filtered_headers,
                content=body,
                timeout=timeout or self._timeout,
            )
            latency_ms = int((time.time() - start_time) * 1000)

            # Convert headers to dict
            response_headers = dict(response.headers)
            # Filter hop-by-hop from response too
            response_headers = self._filter_headers(response_headers)

            return UpstreamResponse(
                status_code=response.status_code,
                headers=response_headers,
                body=response.content,
                latency_ms=latency_ms,
            )

        except httpx.TimeoutException as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=504,
                headers={},
                body=b'{"error": "Upstream timeout"}',
                latency_ms=latency_ms,
                error=f"Timeout: {e}",
            )
        except httpx.ConnectError as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=502,
                headers={},
                body=b'{"error": "Upstream connection failed"}',
                latency_ms=latency_ms,
                error=f"Connection error: {e}",
            )
        except Exception as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=500,
                headers={},
                body=f'{{"error": "Proxy error: {e}"}}'.encode(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _filter_headers(self, headers: dict[str, str]) -> dict[str, str]:
        """Remove hop-by-hop headers that shouldn't be forwarded."""
        hop_by_hop = {
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailers",
            "transfer-encoding",
            "upgrade",
            "proxy-connection",
        }
        return {k: v for k, v in headers.items() if k.lower() not in hop_by_hop}


class AsyncUpstreamClient:
    """Async HTTP client for forwarding requests to upstream servers."""

    def __init__(
        self,
        timeout: float = 30.0,
        verify_ssl: bool = True,
        follow_redirects: bool = True,
    ) -> None:
        self._timeout = timeout
        self._verify_ssl = verify_ssl
        self._follow_redirects = follow_redirects
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self._timeout,
                verify=self._verify_ssl,
                follow_redirects=self._follow_redirects,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def request(
        self,
        method: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
        timeout: float | None = None,
    ) -> UpstreamResponse:
        """Make an async request to upstream server."""
        filtered_headers = self._filter_headers(headers or {})

        start_time = time.time()
        try:
            client = await self._get_client()
            response = await client.request(
                method=method,
                url=url,
                headers=filtered_headers,
                content=body,
                timeout=timeout or self._timeout,
            )
            latency_ms = int((time.time() - start_time) * 1000)

            response_headers = dict(response.headers)
            response_headers = self._filter_headers(response_headers)

            return UpstreamResponse(
                status_code=response.status_code,
                headers=response_headers,
                body=response.content,
                latency_ms=latency_ms,
            )

        except httpx.TimeoutException as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=504,
                headers={},
                body=b'{"error": "Upstream timeout"}',
                latency_ms=latency_ms,
                error=f"Timeout: {e}",
            )
        except httpx.ConnectError as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=502,
                headers={},
                body=b'{"error": "Upstream connection failed"}',
                latency_ms=latency_ms,
                error=f"Connection error: {e}",
            )
        except Exception as e:
            latency_ms = int((time.time() - start_time) * 1000)
            return UpstreamResponse(
                status_code=500,
                headers={},
                body=f'{{"error": "Proxy error: {e}"}}'.encode(),
                latency_ms=latency_ms,
                error=str(e),
            )

    def _filter_headers(self, headers: dict[str, str]) -> dict[str, str]:
        """Remove hop-by-hop headers."""
        hop_by_hop = {
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailers",
            "transfer-encoding",
            "upgrade",
            "proxy-connection",
        }
        return {k: v for k, v in headers.items() if k.lower() not in hop_by_hop}
