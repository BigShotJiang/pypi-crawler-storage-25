"""HTTP Forward Proxy Server - Native proxy protocol support.

This module implements a standard HTTP forward proxy that Android (and other devices)
can connect to via system "Wi-Fi Manual Proxy" settings.

Supports:
- HTTP proxy: Requests with absolute URIs (GET http://example.com/path)
- HTTPS proxy: CONNECT tunneling with TLS MITM for traffic inspection

Usage:
    from mtk_router_sdk.proxy.forward_proxy import ForwardProxyServer

    server = ForwardProxyServer(port=8888)
    await server.start()

Environment:
    MTK_PROXY_PORT: Port for forward proxy (default: 8888)
    MTK_PROXY_MITM: Enable HTTPS MITM (default: true)
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import ssl
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from mtk_router_sdk.config.env_parse import parse_int_env
from mtk_router_sdk.proxy.certs import CertManager
from mtk_router_sdk.proxy.engine import ProxyEngine
from mtk_router_sdk.proxy.models import ProxyLogEntry
from mtk_router_sdk.proxy.routes import get_proxy_engine, get_proxy_state

logger = logging.getLogger(__name__)


async def _read_body_from_content_length(
    headers: dict[str, str],
    reader: asyncio.StreamReader,
) -> bytes | None:
    """Return request body when Content-Length is set (any method), else None."""

    raw = headers.get("Content-Length") or headers.get("content-length")
    if raw is None or raw == "":
        return None
    try:
        n = int(str(raw).strip())
    except ValueError:
        return None
    if n < 0:
        return None
    if n == 0:
        return b""
    return await reader.read(n)


@dataclass
class ProxyRequest:
    """Parsed HTTP proxy request."""

    method: str
    host: str
    port: int
    path: str
    query_string: str
    http_version: str
    headers: dict[str, str]
    body: bytes | None

    @property
    def is_connect(self) -> bool:
        return self.method.upper() == "CONNECT"

    @property
    def is_https(self) -> bool:
        return self.port == 443 or self.is_connect

    @property
    def upstream_url(self) -> str:
        scheme = "https" if self.is_https else "http"
        url = f"{scheme}://{self.host}{self.path}"
        if self.query_string:
            url += f"?{self.query_string}"
        return url


class DynamicCertGenerator:
    """Generate certificates on-the-fly for HTTPS MITM."""

    def __init__(self, cert_manager: CertManager) -> None:
        self._cert_manager = cert_manager
        self._cache: dict[str, tuple[Path, Path]] = {}
        self._cache_dir = Path(tempfile.gettempdir()) / "mtk-proxy-certs"
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    def get_cert_for_host(self, hostname: str) -> tuple[Path, Path]:
        """Get or generate a certificate for the given hostname.

        Returns:
            Tuple of (cert_path, key_path)
        """
        if hostname in self._cache:
            cert_path, key_path = self._cache[hostname]
            if cert_path.exists() and key_path.exists():
                return cert_path, key_path

        cert_path, key_path = self._generate_cert(hostname)
        self._cache[hostname] = (cert_path, key_path)
        return cert_path, key_path

    def _generate_cert(self, hostname: str) -> tuple[Path, Path]:
        """Generate a certificate signed by the CA for the given hostname."""
        import subprocess

        safe_name = re.sub(r"[^a-zA-Z0-9.-]", "_", hostname)
        cert_path = self._cache_dir / f"{safe_name}.crt"
        key_path = self._cache_dir / f"{safe_name}.key"
        csr_path = self._cache_dir / f"{safe_name}.csr"
        ext_path = self._cache_dir / f"{safe_name}.ext"

        ca_cert = self._cert_manager.ca_cert_path()
        ca_key = self._cert_manager.ca_key_path()

        if not ca_cert.exists() or not ca_key.exists():
            self._cert_manager.ensure_certs()

        # Generate private key
        subprocess.run(
            ["openssl", "genrsa", "-out", str(key_path), "2048"],
            capture_output=True,
            check=True,
        )

        # Generate CSR
        subprocess.run(
            [
                "openssl", "req", "-new",
                "-key", str(key_path),
                "-out", str(csr_path),
                "-subj", f"/CN={hostname}/O=MTK Proxy/OU=Dynamic",
            ],
            capture_output=True,
            check=True,
        )

        # Create extensions file with SAN
        san_entries = [f"DNS:{hostname}"]
        # Check if hostname is an IP address
        ip_pattern = r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"
        if re.match(ip_pattern, hostname):
            san_entries.append(f"IP:{hostname}")

        ext_path.write_text(
            f"basicConstraints=CA:FALSE\n"
            f"subjectAltName={','.join(san_entries)}\n"
            f"keyUsage=digitalSignature,keyEncipherment\n"
            f"extendedKeyUsage=serverAuth\n"
        )

        # Sign with CA
        subprocess.run(
            [
                "openssl", "x509", "-req",
                "-days", "30",  # Short validity for dynamic certs
                "-in", str(csr_path),
                "-CA", str(ca_cert),
                "-CAkey", str(ca_key),
                "-CAcreateserial",
                "-out", str(cert_path),
                "-extfile", str(ext_path),
            ],
            capture_output=True,
            check=True,
        )

        # Cleanup temp files
        csr_path.unlink(missing_ok=True)
        ext_path.unlink(missing_ok=True)

        return cert_path, key_path


class ForwardProxyHandler:
    """Handle individual proxy connections."""

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        engine: ProxyEngine,
        cert_generator: DynamicCertGenerator | None,
        enable_mitm: bool = True,
    ) -> None:
        self._reader = reader
        self._writer = writer
        self._engine = engine
        self._cert_generator = cert_generator
        self._enable_mitm = enable_mitm
        self._client_ip = "unknown"

        # Get client IP
        peername = writer.get_extra_info("peername")
        if peername:
            self._client_ip = peername[0]

    async def handle(self) -> None:
        """Handle the proxy connection."""
        try:
            request = await self._read_request()
            if not request:
                return

            # Special case: serve CA certificate directly from proxy port
            if request.path in ("/ca", "/ca.crt", "/cert", "/proxy-ca.crt"):
                await self._serve_ca_certificate()
                return

            if request.is_connect:
                await self._handle_connect(request)
            else:
                await self._handle_http(request)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.debug(f"Proxy handler error: {e}")
        finally:
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

    async def _serve_ca_certificate(self) -> None:
        """Serve the CA certificate directly from the proxy port."""
        from mtk_router_sdk.proxy.certs import CertManager

        certs = CertManager()
        ca_path = certs.ca_cert_path()

        if not ca_path.exists():
            # Try to generate certs
            try:
                certs.ensure_certs()
            except Exception as e:
                response = f"HTTP/1.1 500 Internal Server Error\r\nContent-Type: text/plain\r\n\r\nFailed to generate certificate: {e}"
                self._writer.write(response.encode())
                await self._writer.drain()
                return

        if ca_path.exists():
            cert_data = ca_path.read_bytes()
            response = (
                f"HTTP/1.1 200 OK\r\n"
                f"Content-Type: application/x-x509-ca-cert\r\n"
                f"Content-Disposition: attachment; filename=\"mtk-proxy-ca.crt\"\r\n"
                f"Content-Length: {len(cert_data)}\r\n"
                f"\r\n"
            )
            self._writer.write(response.encode())
            self._writer.write(cert_data)
        else:
            response = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\nCA certificate not found. Generate certificates first."
            self._writer.write(response.encode())

        await self._writer.drain()

    async def _read_request(self) -> ProxyRequest | None:
        """Read and parse an HTTP request."""
        try:
            # Read request line
            raw_request = await asyncio.wait_for(
                self._reader.readline(),
                timeout=30.0,
            )
            if not raw_request:
                return None

            request_line = raw_request.decode("utf-8", errors="replace").strip()
            parts = request_line.split(" ", 2)
            if len(parts) < 3:
                return None

            method, target, http_version = parts

            # Parse headers
            headers: dict[str, str] = {}
            while True:
                header_raw = await self._reader.readline()
                if not header_raw or header_raw == b"\r\n":
                    break
                header_line = header_raw.decode("utf-8", errors="replace").strip()
                if ":" in header_line:
                    key, value = header_line.split(":", 1)
                    headers[key.strip()] = value.strip()

            # Parse target URL
            host, port, path, query = self._parse_target(method, target, headers)

            body = await _read_body_from_content_length(headers, self._reader)

            return ProxyRequest(
                method=method,
                host=host,
                port=port,
                path=path,
                query_string=query,
                http_version=http_version,
                headers=headers,
                body=body,
            )

        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.debug(f"Error reading request: {e}")
            return None

    def _parse_target(
        self, method: str, target: str, headers: dict[str, str]
    ) -> tuple[str, int, str, str]:
        """Parse the request target into host, port, path, query."""
        if method.upper() == "CONNECT":
            # CONNECT host:port
            if ":" in target:
                host, port_str = target.rsplit(":", 1)
                port = int(port_str)
            else:
                host = target
                port = 443
            return host, port, "", ""

        # Absolute URI: http://host:port/path?query
        if target.startswith("http://") or target.startswith("https://"):
            from urllib.parse import urlparse

            parsed = urlparse(target)
            host = parsed.hostname or headers.get("Host", "").split(":")[0]
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            path = parsed.path or "/"
            query = parsed.query or ""
            return host, port, path, query

        # Relative URI with Host header
        host_header = headers.get("Host", "")
        if ":" in host_header:
            host, port_str = host_header.rsplit(":", 1)
            port = int(port_str)
        else:
            host = host_header
            port = 80

        path = target
        query = ""
        if "?" in target:
            path, query = target.split("?", 1)

        return host, port, path, query

    async def _handle_http(self, request: ProxyRequest) -> None:
        """Handle plain HTTP proxy request."""
        status, resp_headers, resp_body, _ = await self._engine.process_request(
            client_ip=self._client_ip,
            method=request.method,
            upstream_host=request.host,
            path=request.path,
            query_string=request.query_string,
            headers=request.headers,
            body=request.body,
        )

        # Send response
        response_line = f"HTTP/1.1 {status} {self._status_phrase(status)}\r\n"
        self._writer.write(response_line.encode())

        # Add Content-Length if not present
        if "content-length" not in {k.lower() for k in resp_headers}:
            resp_headers["Content-Length"] = str(len(resp_body))

        for key, value in resp_headers.items():
            self._writer.write(f"{key}: {value}\r\n".encode())

        self._writer.write(b"\r\n")
        self._writer.write(resp_body)
        await self._writer.drain()

    async def _handle_connect(self, request: ProxyRequest) -> None:
        """Handle HTTPS CONNECT tunnel."""
        if self._enable_mitm and self._cert_generator:
            await self._handle_connect_mitm(request)
        else:
            await self._handle_connect_passthrough(request)

    async def _handle_connect_passthrough(self, request: ProxyRequest) -> None:
        """Handle CONNECT with simple TCP passthrough (no inspection)."""
        try:
            upstream_reader, upstream_writer = await asyncio.open_connection(
                request.host, request.port
            )
        except Exception as e:
            self._writer.write(
                f"HTTP/1.1 502 Bad Gateway\r\n\r\nConnection failed: {e}".encode()
            )
            await self._writer.drain()
            return

        # Send 200 Connection Established
        self._writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        await self._writer.drain()

        # Log the CONNECT (but not the encrypted content)
        log_entry = ProxyLogEntry(
            timestamp=datetime.utcnow(),
            client_ip=self._client_ip,
            method="CONNECT",
            upstream_host=request.host,
            path=f":{request.port}",
            query_string="",
            request_headers=request.headers,
        )
        log_entry.action_taken = "tunnel_passthrough"
        log_entry.response_status = 200
        get_proxy_state().logs.add(log_entry)

        # Bidirectional pipe
        await self._bidirectional_pipe(
            self._reader, self._writer,
            upstream_reader, upstream_writer,
        )

    async def _handle_connect_mitm(self, request: ProxyRequest) -> None:
        """Handle CONNECT with TLS MITM for traffic inspection."""
        # Send 200 Connection Established
        self._writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        await self._writer.drain()

        try:
            # Generate certificate for this host
            cert_path, key_path = self._cert_generator.get_cert_for_host(request.host)  # type: ignore

            # Create SSL context for client-facing connection
            ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ssl_ctx.load_cert_chain(str(cert_path), str(key_path))

            # Upgrade client connection to TLS
            transport = self._writer.transport
            if transport is None:
                raise RuntimeError("MITM: stream writer has no transport")
            protocol = transport.get_protocol()

            loop = asyncio.get_event_loop()
            new_transport = await loop.start_tls(
                transport,
                protocol,
                ssl_ctx,
                server_side=True,
            )
            if new_transport is None:
                raise RuntimeError("MITM: start_tls returned no transport")

            # Create new reader/writer for TLS connection
            tls_reader = asyncio.StreamReader()
            tls_protocol = asyncio.StreamReaderProtocol(tls_reader)
            new_transport.set_protocol(tls_protocol)
            tls_writer = asyncio.StreamWriter(
                new_transport, tls_protocol, tls_reader, loop
            )

            # Handle decrypted HTTP requests
            await self._handle_mitm_requests(
                request.host,
                request.port,
                tls_reader,
                tls_writer,
            )

        except Exception as e:
            logger.debug("MITM setup failed for %s: %s", request.host, e)
            # CONNECT already returned 200; raw TCP pass-through is not possible here.
            log_entry = ProxyLogEntry(
                timestamp=datetime.utcnow(),
                client_ip=self._client_ip,
                method="CONNECT",
                upstream_host=request.host,
                path=f":{request.port}",
                query_string="",
                request_headers=request.headers,
            )
            log_entry.action_taken = "mitm_failed"
            log_entry.error = str(e)
            get_proxy_state().logs.add(log_entry)
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

    async def _handle_mitm_requests(
        self,
        host: str,
        port: int,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle decrypted HTTPS requests after MITM."""
        try:
            while True:
                # Read request line
                raw_request = await asyncio.wait_for(
                    reader.readline(),
                    timeout=30.0,
                )
                if not raw_request:
                    break

                request_line = raw_request.decode("utf-8", errors="replace").strip()
                if not request_line:
                    break

                parts = request_line.split(" ", 2)
                if len(parts) < 3:
                    break

                method, path, _ = parts

                # Read headers
                headers: dict[str, str] = {}
                while True:
                    header_raw = await reader.readline()
                    if not header_raw or header_raw == b"\r\n":
                        break
                    header_line = header_raw.decode("utf-8", errors="replace").strip()
                    if ":" in header_line:
                        key, value = header_line.split(":", 1)
                        headers[key.strip()] = value.strip()

                body = await _read_body_from_content_length(headers, reader)

                # Parse path and query
                query_string = ""
                if "?" in path:
                    path, query_string = path.split("?", 1)

                # Process through engine
                status, resp_headers, resp_body, _ = await self._engine.process_request(
                    client_ip=self._client_ip,
                    method=method,
                    upstream_host=host,
                    path=path,
                    query_string=query_string,
                    headers=headers,
                    body=body,
                )

                # Send response
                response_line = f"HTTP/1.1 {status} {self._status_phrase(status)}\r\n"
                writer.write(response_line.encode())

                if "content-length" not in {k.lower() for k in resp_headers}:
                    resp_headers["Content-Length"] = str(len(resp_body))

                for key, value in resp_headers.items():
                    writer.write(f"{key}: {value}\r\n".encode())

                writer.write(b"\r\n")
                writer.write(resp_body)
                await writer.drain()

                # Check Connection header for keep-alive
                conn = headers.get("Connection", "").lower()
                if conn == "close":
                    break

        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug(f"MITM request handling error: {e}")

    async def _bidirectional_pipe(
        self,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        upstream_reader: asyncio.StreamReader,
        upstream_writer: asyncio.StreamWriter,
    ) -> None:
        """Create bidirectional pipe between client and upstream."""

        async def pipe(
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
        ) -> None:
            try:
                while True:
                    data = await reader.read(8192)
                    if not data:
                        break
                    writer.write(data)
                    await writer.drain()
            except Exception:
                pass
            finally:
                try:
                    writer.close()
                except Exception:
                    pass

        await asyncio.gather(
            pipe(client_reader, upstream_writer),
            pipe(upstream_reader, client_writer),
        )

    def _status_phrase(self, status: int) -> str:
        """Get HTTP status phrase."""
        phrases = {
            200: "OK",
            201: "Created",
            204: "No Content",
            301: "Moved Permanently",
            302: "Found",
            304: "Not Modified",
            400: "Bad Request",
            401: "Unauthorized",
            403: "Forbidden",
            404: "Not Found",
            405: "Method Not Allowed",
            500: "Internal Server Error",
            502: "Bad Gateway",
            503: "Service Unavailable",
            504: "Gateway Timeout",
        }
        return phrases.get(status, "Unknown")


class ForwardProxyServer:
    """HTTP Forward Proxy Server.

    Implements RFC 7230 HTTP proxy protocol for use with system proxy settings.
    """

    def __init__(
        self,
        port: int = 8888,
        host: str = "0.0.0.0",
        enable_mitm: bool = True,
        cert_manager: CertManager | None = None,
    ) -> None:
        """Initialize forward proxy server.

        Args:
            port: Port to listen on (default: 8888)
            host: Host to bind to (default: 0.0.0.0)
            enable_mitm: Enable HTTPS MITM inspection (default: True)
            cert_manager: Certificate manager for MITM (created if None)
        """
        self._port = port
        self._host = host
        self._enable_mitm = enable_mitm
        self._cert_manager = cert_manager or CertManager()
        self._cert_generator: DynamicCertGenerator | None = None
        self._server: asyncio.Server | None = None

        if enable_mitm:
            self._cert_generator = DynamicCertGenerator(self._cert_manager)

    @property
    def port(self) -> int:
        return self._port

    @property
    def is_running(self) -> bool:
        return self._server is not None and self._server.is_serving()

    async def start(self) -> None:
        """Start the proxy server."""
        if self._enable_mitm:
            # Ensure CA certificates exist
            self._cert_manager.ensure_certs()

        engine = get_proxy_engine()

        async def client_handler(
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
        ) -> None:
            handler = ForwardProxyHandler(
                reader, writer, engine,
                self._cert_generator,
                self._enable_mitm,
            )
            await handler.handle()

        self._server = await asyncio.start_server(
            client_handler,
            self._host,
            self._port,
        )

        logger.info(
            f"Forward proxy started on {self._host}:{self._port} "
            f"(MITM: {'enabled' if self._enable_mitm else 'disabled'})"
        )

    async def stop(self) -> None:
        """Stop the proxy server."""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
            logger.info("Forward proxy stopped")

    async def serve_forever(self) -> None:
        """Start and serve forever."""
        await self.start()
        if self._server:
            await self._server.serve_forever()


# Global proxy server instance
_forward_proxy: ForwardProxyServer | None = None


def get_forward_proxy() -> ForwardProxyServer | None:
    """Get the global forward proxy server."""
    return _forward_proxy


async def start_forward_proxy(
    port: int | None = None,
    enable_mitm: bool = True,
) -> ForwardProxyServer:
    """Start the global forward proxy server.

    Args:
        port: Port to listen on (default from MTK_PROXY_PORT or 8888)
        enable_mitm: Enable HTTPS MITM (default from MTK_PROXY_MITM or True)

    Returns:
        ForwardProxyServer instance
    """
    global _forward_proxy

    if _forward_proxy and _forward_proxy.is_running:
        return _forward_proxy

    if port is None:
        port = parse_int_env("MTK_PROXY_PORT", 8888, minimum=1, maximum=65535)

    mitm_env = os.environ.get("MTK_PROXY_MITM", "true").lower()
    if mitm_env in ("0", "false", "no", "off"):
        enable_mitm = False

    _forward_proxy = ForwardProxyServer(port=port, enable_mitm=enable_mitm)
    await _forward_proxy.start()
    return _forward_proxy


async def stop_forward_proxy() -> None:
    """Stop the global forward proxy server."""
    global _forward_proxy
    if _forward_proxy:
        await _forward_proxy.stop()
        _forward_proxy = None
