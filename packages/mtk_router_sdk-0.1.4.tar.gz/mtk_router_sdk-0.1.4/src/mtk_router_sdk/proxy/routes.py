"""HTTP API routes for proxy engine.

These routes integrate with the main mtk-serve application.
"""

from __future__ import annotations

import base64
import json
from typing import Any

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from mtk_router_sdk.proxy.engine import ProxyEngine
from mtk_router_sdk.proxy.models import ProxyAction, ProxyConfig, ProxyRule
from mtk_router_sdk.proxy.store import ProxyState

# Global proxy state (initialized when routes are mounted)
_proxy_state: ProxyState | None = None
_proxy_engine: ProxyEngine | None = None


def init_proxy_state(config: ProxyConfig | None = None) -> ProxyState:
    """Initialize or get the global proxy state."""
    global _proxy_state, _proxy_engine
    if _proxy_state is None:
        _proxy_state = ProxyState(config=config)
        _proxy_engine = ProxyEngine(_proxy_state)
    return _proxy_state


def get_proxy_state() -> ProxyState:
    """Get the global proxy state, initializing if needed."""
    if _proxy_state is None:
        init_proxy_state()
    return _proxy_state  # type: ignore


def get_proxy_engine() -> ProxyEngine:
    """Get the global proxy engine."""
    if _proxy_engine is None:
        init_proxy_state()
    return _proxy_engine  # type: ignore


def _json(data: Any, status: int = 200) -> JSONResponse:
    """Create JSON response with proper headers."""
    return JSONResponse(data, status_code=status)


def _error(message: str, status: int = 400, code: str = "ERROR") -> JSONResponse:
    """Create error response."""
    return _json({"ok": False, "error": message, "code": code}, status)


# -----------------------------------------------------------------------------
# Status endpoints
# -----------------------------------------------------------------------------


async def proxy_status(request: Request) -> Response:
    """GET /v1/proxy/status - Get proxy engine status."""
    state = get_proxy_state()
    return _json({"ok": True, **state.get_status()})


# -----------------------------------------------------------------------------
# Rule CRUD endpoints
# -----------------------------------------------------------------------------


async def proxy_rules_list(request: Request) -> Response:
    """GET /v1/proxy/rules - List all rules."""
    state = get_proxy_state()
    client_ip = request.query_params.get("client_ip")

    rules = (
        state.rules.list_by_client_ip(client_ip)
        if client_ip
        else state.rules.list_all()
    )

    return _json({
        "ok": True,
        "rules": [r.to_dict() for r in rules],
        "count": len(rules),
    })


async def proxy_rules_create(request: Request) -> Response:
    """POST /v1/proxy/rules - Create a new rule."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    # Validate required fields
    if "path_pattern" not in body and "endpoint" not in body:
        return _error("'path_pattern' or 'endpoint' is required", 400, "MISSING_FIELD")

    # Support both 'endpoint' (simple) and 'path_pattern' (full)
    if "endpoint" in body and "path_pattern" not in body:
        body["path_pattern"] = body.pop("endpoint")

    # Support 'response' as alias for 'response_body'
    if "response" in body and "response_body" not in body:
        body["response_body"] = body.pop("response")

    # Support 'status' as alias for 'response_status'
    if "status" in body and "response_status" not in body:
        body["response_status"] = body.pop("status")

    try:
        rule = ProxyRule.from_dict(body)
    except Exception as e:
        return _error(f"Invalid rule data: {e}", 400, "INVALID_RULE")

    state = get_proxy_state()
    added = state.rules.add(rule)
    return _json({"ok": True, "rule": added.to_dict()}, 201)


async def proxy_rules_get(request: Request) -> Response:
    """GET /v1/proxy/rules/{rule_id} - Get a specific rule."""
    rule_id = request.path_params["rule_id"]
    state = get_proxy_state()
    rule = state.rules.get(rule_id)

    if not rule:
        return _error(f"Rule not found: {rule_id}", 404, "NOT_FOUND")

    return _json({"ok": True, "rule": rule.to_dict()})


async def proxy_rules_update(request: Request) -> Response:
    """PUT /v1/proxy/rules/{rule_id} - Update a rule."""
    rule_id = request.path_params["rule_id"]

    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    state = get_proxy_state()
    rule = state.rules.update(rule_id, body)

    if not rule:
        return _error(f"Rule not found: {rule_id}", 404, "NOT_FOUND")

    return _json({"ok": True, "rule": rule.to_dict()})


async def proxy_rules_delete(request: Request) -> Response:
    """DELETE /v1/proxy/rules/{rule_id} - Delete a rule."""
    rule_id = request.path_params["rule_id"]
    state = get_proxy_state()
    deleted = state.rules.delete(rule_id)

    if not deleted:
        return _error(f"Rule not found: {rule_id}", 404, "NOT_FOUND")

    return _json({"ok": True, "deleted": rule_id})


async def proxy_rules_clear(request: Request) -> Response:
    """DELETE /v1/proxy/rules - Clear all rules (or by client_ip)."""
    state = get_proxy_state()
    client_ip = request.query_params.get("client_ip")

    count = (
        state.rules.delete_by_client_ip(client_ip)
        if client_ip
        else state.rules.clear()
    )

    return _json({"ok": True, "deleted_count": count})


# -----------------------------------------------------------------------------
# Quick rule creation (simplified API)
# -----------------------------------------------------------------------------


async def proxy_set_response(request: Request) -> Response:
    """POST /v1/proxy/set - Quick set response for endpoint."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    client_ip = body.get("client_ip")
    endpoint = body.get("endpoint")
    response = body.get("response")

    if not client_ip:
        return _error("'client_ip' is required", 400, "MISSING_FIELD")
    if not endpoint:
        return _error("'endpoint' is required", 400, "MISSING_FIELD")
    if response is None:
        return _error("'response' is required", 400, "MISSING_FIELD")

    state = get_proxy_state()

    # Remove existing rules for same IP+endpoint
    for rule in state.rules.list_by_client_ip(client_ip):
        if rule.path_pattern == endpoint:
            state.rules.delete(rule.id)

    rule = ProxyRule(
        name=body.get("name", f"Override {endpoint} for {client_ip}"),
        client_ip=client_ip,
        path_pattern=endpoint,
        action=ProxyAction.OVERRIDE,
        response_status=body.get("status", 200),
        response_body=response,
    )
    added = state.rules.add(rule)
    return _json({"ok": True, "rule": added.to_dict()}, 201)


async def proxy_set_error(request: Request) -> Response:
    """POST /v1/proxy/error - Quick set error response."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    client_ip = body.get("client_ip")
    endpoint = body.get("endpoint")
    status = body.get("status", 500)

    if not client_ip:
        return _error("'client_ip' is required", 400, "MISSING_FIELD")
    if not endpoint:
        return _error("'endpoint' is required", 400, "MISSING_FIELD")

    state = get_proxy_state()

    # Remove existing
    for rule in state.rules.list_by_client_ip(client_ip):
        if rule.path_pattern == endpoint:
            state.rules.delete(rule.id)

    rule = ProxyRule(
        name=body.get("name", f"Error {status} for {endpoint} on {client_ip}"),
        client_ip=client_ip,
        path_pattern=endpoint,
        action=ProxyAction.ERROR,
        response_status=status,
        response_body=body.get("response"),
    )
    added = state.rules.add(rule)
    return _json({"ok": True, "rule": added.to_dict()}, 201)


async def proxy_clear_endpoint(request: Request) -> Response:
    """POST /v1/proxy/clear - Clear rules for endpoint."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    client_ip = body.get("client_ip")
    endpoint = body.get("endpoint")

    if not client_ip:
        return _error("'client_ip' is required", 400, "MISSING_FIELD")

    state = get_proxy_state()
    count = 0

    if endpoint:
        for rule in state.rules.list_by_client_ip(client_ip):
            if rule.path_pattern == endpoint:
                state.rules.delete(rule.id)
                count += 1
    else:
        count = state.rules.delete_by_client_ip(client_ip)

    return _json({"ok": True, "deleted_count": count})


# -----------------------------------------------------------------------------
# Log endpoints
# -----------------------------------------------------------------------------


async def proxy_log_list(request: Request) -> Response:
    """GET /v1/proxy/log - Get request log."""
    state = get_proxy_state()

    client_ip = request.query_params.get("client_ip")
    client_ips_raw = (request.query_params.get("client_ips") or "").strip()
    limit = int(request.query_params.get("limit", 100))
    limit = min(limit, 1000)  # Cap at 1000

    if client_ips_raw:
        ip_set = {p.strip() for p in client_ips_raw.split(",") if p.strip()}
        entries = state.logs.list_by_client_ips(ip_set, limit=limit)
    elif client_ip:
        entries = state.logs.list_by_client_ip(client_ip, limit=limit)
    else:
        entries = state.logs.list_all(limit=limit)

    return _json({
        "ok": True,
        "entries": [e.to_dict() for e in entries],
        "count": len(entries),
        "stats": state.logs.stats(),
    })


async def proxy_log_get(request: Request) -> Response:
    """GET /v1/proxy/log/{entry_id} - Get specific log entry."""
    entry_id = request.path_params["entry_id"]
    state = get_proxy_state()
    entry = state.logs.get(entry_id)

    if not entry:
        return _error(f"Log entry not found: {entry_id}", 404, "NOT_FOUND")

    return _json({"ok": True, "entry": entry.to_dict()})


async def proxy_log_clear(request: Request) -> Response:
    """DELETE /v1/proxy/log - Clear log entries."""
    state = get_proxy_state()
    client_ip = request.query_params.get("client_ip")

    count = (
        state.logs.clear_by_client_ip(client_ip)
        if client_ip
        else state.logs.clear()
    )

    return _json({"ok": True, "cleared_count": count})


# -----------------------------------------------------------------------------
# Proxy passthrough endpoint
# -----------------------------------------------------------------------------


async def proxy_passthrough(request: Request) -> Response:
    """ANY /v1/proxy/to/{upstream_host}/{path:path} - Proxy request to upstream."""
    upstream_host = request.path_params["upstream_host"]
    path = "/" + request.path_params.get("path", "")

    # Get client IP
    client_ip = request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
    if not client_ip:
        client_ip = request.client.host if request.client else "unknown"

    # Get request body
    body = await request.body() if request.method in ("POST", "PUT", "PATCH") else None

    # Get headers (filter out some)
    headers = dict(request.headers)
    headers.pop("host", None)
    headers.pop("content-length", None)

    engine = get_proxy_engine()
    status, resp_headers, resp_body, log_entry = await engine.process_request(
        client_ip=client_ip,
        method=request.method,
        upstream_host=upstream_host,
        path=path,
        query_string=str(request.query_params),
        headers=headers,
        body=body,
    )

    # Add proxy headers
    resp_headers["X-Proxy-Rule"] = log_entry.matched_rule_id or "none"
    resp_headers["X-Proxy-Action"] = log_entry.action_taken
    resp_headers["X-Proxy-Latency-Ms"] = str(log_entry.total_latency_ms)

    return Response(
        content=resp_body,
        status_code=status,
        headers=resp_headers,
    )


# -----------------------------------------------------------------------------
# Route table
# -----------------------------------------------------------------------------


async def proxy_certs_status(request: Request) -> Response:
    """GET /v1/proxy/certs - Get certificate status."""
    from mtk_router_sdk.proxy.certs import CertManager

    certs = CertManager()
    return _json({"ok": True, **certs.status()})


async def proxy_certs_generate(request: Request) -> Response:
    """POST /v1/proxy/certs - Generate certificates."""
    from mtk_router_sdk.proxy.certs import CertError, CertManager

    try:
        body = await request.json()
    except json.JSONDecodeError:
        body = {}

    force = body.get("force", False)

    try:
        certs = CertManager()
        result = certs.ensure_certs(force=force)
        return _json({"ok": True, **result})
    except CertError as e:
        return _error(e.message, 500, e.code)


async def proxy_certs_ca_download(request: Request) -> Response:
    """GET /v1/proxy/certs/ca - Download CA certificate."""
    from starlette.responses import FileResponse

    from mtk_router_sdk.proxy.certs import CertManager

    certs = CertManager()
    ca_path = certs.ca_cert_path()

    if not ca_path.exists():
        return _error("CA certificate not found. Generate certificates first.", 404)

    return FileResponse(
        ca_path,
        media_type="application/x-x509-ca-cert",
        filename="mtk-proxy-ca.crt",
    )


async def proxy_certs_import(request: Request) -> Response:
    """POST /v1/proxy/certs/import - Install CA from PEM or PKCS#12 (base64); re-sign proxy leaf."""
    from mtk_router_sdk.proxy.certs import CertError, CertManager

    try:
        body = await request.json()
    except json.JSONDecodeError:
        return _error("Invalid JSON body", 400, "INVALID_JSON")

    proxy_cn = str(body.get("proxy_cn") or "MTK Proxy").strip() or "MTK Proxy"
    try:
        validity_days = int(body.get("validity_days", 3650))
    except (TypeError, ValueError):
        validity_days = 3650

    p12_b64 = (body.get("pkcs12_base64") or body.get("p12_base64") or "").strip()
    p12_pw = body.get("p12_password")
    if p12_pw is not None and not isinstance(p12_pw, str):
        p12_pw = str(p12_pw)

    try:
        certs = CertManager()
        if p12_b64:
            try:
                raw = base64.b64decode(p12_b64)
            except Exception:
                return _error("Invalid PKCS#12 base64 encoding", 400, "INVALID_BASE64")
            if not raw:
                return _error("PKCS#12 payload is empty after decode", 400, "INVALID_BASE64")
            result = certs.import_ca_pkcs12_bytes(
                raw,
                password=p12_pw,
                proxy_cn=proxy_cn,
                validity_days=validity_days,
            )
        else:
            ca_crt = (body.get("ca_crt_pem") or body.get("ca_cert_pem") or "").strip()
            ca_key = (body.get("ca_key_pem") or "").strip()
            if not ca_crt or not ca_key:
                return _error(
                    "Provide pkcs12_base64 (and optional p12_password) or ca_crt_pem + ca_key_pem",
                    400,
                    "MISSING_FIELD",
                )
            result = certs.import_ca_pem_strings(
                ca_crt,
                ca_key,
                proxy_cn=proxy_cn,
                validity_days=validity_days,
            )
        return _json({"ok": True, **result})
    except CertError as e:
        return _error(e.message, 400, e.code)


def proxy_route_table() -> list[Route]:
    """Get all proxy routes to mount in the application."""
    return [
        # Status
        Route("/v1/proxy/status", endpoint=proxy_status, methods=["GET"]),
        # Rules CRUD
        Route("/v1/proxy/rules", endpoint=proxy_rules_list, methods=["GET"]),
        Route("/v1/proxy/rules", endpoint=proxy_rules_create, methods=["POST"]),
        Route("/v1/proxy/rules", endpoint=proxy_rules_clear, methods=["DELETE"]),
        Route("/v1/proxy/rules/{rule_id}", endpoint=proxy_rules_get, methods=["GET"]),
        Route(
            "/v1/proxy/rules/{rule_id}", endpoint=proxy_rules_update, methods=["PUT"]
        ),
        Route(
            "/v1/proxy/rules/{rule_id}",
            endpoint=proxy_rules_delete,
            methods=["DELETE"],
        ),
        # Quick actions
        Route("/v1/proxy/set", endpoint=proxy_set_response, methods=["POST"]),
        Route("/v1/proxy/error", endpoint=proxy_set_error, methods=["POST"]),
        Route("/v1/proxy/clear", endpoint=proxy_clear_endpoint, methods=["POST"]),
        # Log
        Route("/v1/proxy/log", endpoint=proxy_log_list, methods=["GET"]),
        Route("/v1/proxy/log", endpoint=proxy_log_clear, methods=["DELETE"]),
        Route("/v1/proxy/log/{entry_id}", endpoint=proxy_log_get, methods=["GET"]),
        # Proxy passthrough
        Route(
            "/v1/proxy/to/{upstream_host}/{path:path}",
            endpoint=proxy_passthrough,
            methods=["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
        ),
        # Certificates
        Route("/v1/proxy/certs", endpoint=proxy_certs_status, methods=["GET"]),
        Route("/v1/proxy/certs", endpoint=proxy_certs_generate, methods=["POST"]),
        Route("/v1/proxy/certs/ca", endpoint=proxy_certs_ca_download, methods=["GET"]),
        Route(
            "/v1/proxy/certs/import",
            endpoint=proxy_certs_import,
            methods=["POST"],
        ),
    ]
