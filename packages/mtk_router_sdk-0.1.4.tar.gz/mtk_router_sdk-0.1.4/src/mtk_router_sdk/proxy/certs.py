"""Certificate management for HTTPS proxy.

Certificates are stored in a fixed location (~/.mtk/certs/ by default)
so they can be easily found and trusted by test devices.

Usage:
    from mtk_router_sdk.proxy.certs import CertManager

    certs = CertManager()
    certs.ensure_certs()  # Generate if not exists
    print(certs.cert_path())  # Path to certificate file
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class CertInfo:
    """Information about a certificate."""

    path: str
    exists: bool
    valid: bool
    expires_at: datetime | None
    subject: str | None
    issuer: str | None
    error: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "exists": self.exists,
            "valid": self.valid,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "subject": self.subject,
            "issuer": self.issuer,
            "error": self.error,
        }


class CertError(Exception):
    """Certificate-related error."""

    def __init__(self, message: str, code: str = "CERT_ERROR") -> None:
        self.message = message
        self.code = code
        super().__init__(message)


def extract_pem_from_pkcs12(
    pkcs12_data: bytes,
    password: str | None = None,
) -> tuple[str, str]:
    """Extract CA certificate chain PEM and private key PEM from PKCS#12 bytes.

    Uses the ``openssl pkcs12`` command (same as the rest of this module). Supports
    empty passwords and retries with ``-legacy`` when OpenSSL 3 rejects old algorithms.

    Returns:
        Tuple ``(ca_certs_pem, private_key_pem)`` (stripped).

    Raises:
        CertError: Empty input, parse failure, or missing key/cert material.
    """

    if not pkcs12_data:
        raise CertError("PKCS#12 data is empty", code="INVALID_P12")

    pw_plain = "" if password is None else str(password)
    use_pw_file = len(pw_plain) > 0

    p12_path: Path | None = None
    pw_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".p12", delete=False) as f12:
            f12.write(pkcs12_data)
            p12_path = Path(f12.name)
        if use_pw_file:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                newline="\n",
                delete=False,
            ) as fpw:
                fpw.write(pw_plain)
                pw_path = Path(fpw.name)

        def passin_args() -> list[str]:
            # Empty password: ``-passin pass:`` (OpenSSL rejects an empty ``file:`` BIO).
            if not use_pw_file:
                return ["-passin", "pass:"]
            assert pw_path is not None
            return ["-passin", f"file:{pw_path}"]

        def run_extract(*, want_key: bool, legacy: bool) -> subprocess.CompletedProcess[str]:
            mode = ["-nocerts", "-nodes"] if want_key else ["-nokeys", "-nodes"]
            cmd: list[str] = ["openssl", "pkcs12", "-in", str(p12_path)]
            if legacy:
                cmd.append("-legacy")
            cmd.extend(mode)
            cmd.extend(passin_args())
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False,
            )

        last_err = ""
        for legacy in (False, True):
            rk = run_extract(want_key=True, legacy=legacy)
            rc = run_extract(want_key=False, legacy=legacy)
            if rk.returncode != 0:
                last_err = (rk.stderr or rk.stdout or "").strip() or last_err
            if rc.returncode != 0:
                last_err = (rc.stderr or rc.stdout or "").strip() or last_err
            key_pem = rk.stdout.strip() if rk.returncode == 0 else ""
            cert_pem = rc.stdout.strip() if rc.returncode == 0 else ""
            if "PRIVATE KEY" in key_pem and "BEGIN CERTIFICATE" in cert_pem:
                return cert_pem, key_pem

        err_tail = last_err.strip()
        hint = ""
        low = err_tail.lower()
        if not use_pw_file and (
            "invalid password" in low
            or "mac verify error" in low
            or "bad decrypt" in low
        ):
            hint = (
                " This file is encrypted: enter the same password you used when exporting the .p12 "
                "(Charles and similar tools usually set one). Leave blank only for bundles with no password."
            )
        elif use_pw_file and ("invalid password" in low or "mac verify error" in low):
            hint = (
                " The bundle password does not match — re-type the password from when the .p12 was exported."
            )

        raise CertError(
            f"PKCS#12 parse failed (wrong password, corrupt file, or unsupported format). {err_tail}{hint}".strip(),
            code="INVALID_P12",
        )
    finally:
        if p12_path is not None:
            p12_path.unlink(missing_ok=True)
        if pw_path is not None:
            pw_path.unlink(missing_ok=True)


class CertManager:
    """Manage HTTPS certificates for the proxy.

    Default location: ~/.mtk/certs/
    Files:
        - ca.key: CA private key
        - ca.crt: CA certificate (install this on test devices)
        - proxy.key: Proxy server private key
        - proxy.crt: Proxy server certificate (signed by CA)

    The CA certificate should be installed on test devices to trust
    the proxy's HTTPS connections.
    """

    DEFAULT_CERT_DIR = "~/.mtk/certs"

    def __init__(self, cert_dir: str | None = None) -> None:
        """Initialize certificate manager.

        Args:
            cert_dir: Directory for certificates (default: ~/.mtk/certs)
        """
        self._cert_dir = Path(
            os.path.expanduser(cert_dir or self.DEFAULT_CERT_DIR)
        )

    @property
    def cert_dir(self) -> Path:
        """Get the certificate directory path."""
        return self._cert_dir

    def ca_key_path(self) -> Path:
        """Path to CA private key."""
        return self._cert_dir / "ca.key"

    def ca_cert_path(self) -> Path:
        """Path to CA certificate (install on devices)."""
        return self._cert_dir / "ca.crt"

    def proxy_key_path(self) -> Path:
        """Path to proxy server private key."""
        return self._cert_dir / "proxy.key"

    def proxy_cert_path(self) -> Path:
        """Path to proxy server certificate."""
        return self._cert_dir / "proxy.crt"

    def ensure_dir(self) -> None:
        """Create certificate directory if it doesn't exist."""
        self._cert_dir.mkdir(parents=True, exist_ok=True)
        # Set restrictive permissions on the directory
        os.chmod(self._cert_dir, 0o700)

    def certs_exist(self) -> bool:
        """Check if all required certificates exist."""
        return (
            self.ca_key_path().exists()
            and self.ca_cert_path().exists()
            and self.proxy_key_path().exists()
            and self.proxy_cert_path().exists()
        )

    def ensure_certs(
        self,
        *,
        force: bool = False,
        ca_cn: str = "MTK Proxy CA",
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,  # 10 years
    ) -> dict[str, Any]:
        """Ensure certificates exist, generating if needed.

        Args:
            force: Regenerate even if certs exist
            ca_cn: Common Name for CA certificate
            proxy_cn: Common Name for proxy certificate
            validity_days: Certificate validity in days

        Returns:
            Dict with paths to generated certificates

        Raises:
            CertError: If generation fails
        """
        if self.certs_exist() and not force:
            return {
                "ca_cert": str(self.ca_cert_path()),
                "ca_key": str(self.ca_key_path()),
                "proxy_cert": str(self.proxy_cert_path()),
                "proxy_key": str(self.proxy_key_path()),
                "generated": False,
            }

        self.ensure_dir()

        try:
            # Generate CA private key
            self._run_openssl([
                "genrsa",
                "-out", str(self.ca_key_path()),
                "4096",
            ])

            # Generate CA certificate
            self._run_openssl([
                "req",
                "-new",
                "-x509",
                "-days", str(validity_days),
                "-key", str(self.ca_key_path()),
                "-out", str(self.ca_cert_path()),
                "-subj", f"/CN={ca_cn}/O=MTK Router SDK/OU=Proxy",
            ])

            # Generate proxy private key
            self._run_openssl([
                "genrsa",
                "-out", str(self.proxy_key_path()),
                "2048",
            ])

            # Generate proxy CSR
            csr_path = self._cert_dir / "proxy.csr"
            self._run_openssl([
                "req",
                "-new",
                "-key", str(self.proxy_key_path()),
                "-out", str(csr_path),
                "-subj", f"/CN={proxy_cn}/O=MTK Router SDK/OU=Proxy",
            ])

            # Create extensions file for SAN
            # Note: IP ranges not supported, using common specific IPs
            ext_path = self._cert_dir / "proxy.ext"
            ext_path.write_text(
                "basicConstraints=CA:FALSE\n"
                "subjectAltName=DNS:localhost,DNS:*.local,DNS:*.lan,"
                "IP:127.0.0.1,IP:192.168.1.1,IP:192.168.88.1,IP:10.0.0.1\n"
                "keyUsage=digitalSignature,keyEncipherment\n"
                "extendedKeyUsage=serverAuth\n"
            )

            # Sign proxy certificate with CA
            self._run_openssl([
                "x509",
                "-req",
                "-days", str(validity_days),
                "-in", str(csr_path),
                "-CA", str(self.ca_cert_path()),
                "-CAkey", str(self.ca_key_path()),
                "-CAcreateserial",
                "-out", str(self.proxy_cert_path()),
                "-extfile", str(ext_path),
            ])

            # Clean up temporary files
            csr_path.unlink(missing_ok=True)
            ext_path.unlink(missing_ok=True)
            (self._cert_dir / "ca.srl").unlink(missing_ok=True)

            # Set restrictive permissions on private keys
            os.chmod(self.ca_key_path(), 0o600)
            os.chmod(self.proxy_key_path(), 0o600)

            return {
                "ca_cert": str(self.ca_cert_path()),
                "ca_key": str(self.ca_key_path()),
                "proxy_cert": str(self.proxy_cert_path()),
                "proxy_key": str(self.proxy_key_path()),
                "generated": True,
            }

        except subprocess.CalledProcessError as e:
            raise CertError(
                f"Failed to generate certificates: {e.stderr or e}",
                code="OPENSSL_ERROR",
            ) from e

    def _run_openssl(self, args: list[str]) -> str:
        """Run an openssl command."""
        result = subprocess.run(
            ["openssl", *args],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout

    def _generate_proxy_leaf_certificate(
        self,
        *,
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,
    ) -> None:
        """Create proxy.key / proxy.crt signed by existing ca.crt + ca.key."""

        self._run_openssl([
            "genrsa",
            "-out", str(self.proxy_key_path()),
            "2048",
        ])
        csr_path = self._cert_dir / "proxy.csr"
        self._run_openssl([
            "req",
            "-new",
            "-key", str(self.proxy_key_path()),
            "-out", str(csr_path),
            "-subj", f"/CN={proxy_cn}/O=MTK Router SDK/OU=Proxy",
        ])
        ext_path = self._cert_dir / "proxy.ext"
        ext_path.write_text(
            "basicConstraints=CA:FALSE\n"
            "subjectAltName=DNS:localhost,DNS:*.local,DNS:*.lan,"
            "IP:127.0.0.1,IP:192.168.1.1,IP:192.168.88.1,IP:10.0.0.1\n"
            "keyUsage=digitalSignature,keyEncipherment\n"
            "extendedKeyUsage=serverAuth\n"
        )
        self._run_openssl([
            "x509",
            "-req",
            "-days", str(validity_days),
            "-in", str(csr_path),
            "-CA", str(self.ca_cert_path()),
            "-CAkey", str(self.ca_key_path()),
            "-CAcreateserial",
            "-out", str(self.proxy_cert_path()),
            "-extfile", str(ext_path),
        ])
        csr_path.unlink(missing_ok=True)
        ext_path.unlink(missing_ok=True)
        (self._cert_dir / "ca.srl").unlink(missing_ok=True)
        os.chmod(self.proxy_key_path(), 0o600)

    def import_ca_pem_strings(
        self,
        ca_crt_pem: str,
        ca_key_pem: str,
        *,
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,
    ) -> dict[str, Any]:
        """Install user-supplied CA PEM + key PEM, then re-sign the proxy leaf.

        Use this when you generated your own CA (e.g. org PKI) and need devices to
        trust the same roots. Requires **both** certificate and private key so the
        proxy can mint per-host TLS certificates for MITM.

        Raises:
            CertError: Invalid PEM or openssl failure.
        """

        crt = (ca_crt_pem or "").strip()
        key = (ca_key_pem or "").strip()
        if "BEGIN CERTIFICATE" not in crt:
            raise CertError("ca_crt_pem must be PEM (-----BEGIN CERTIFICATE-----)", code="INVALID_PEM")
        if "BEGIN" not in key or "PRIVATE KEY" not in key:
            raise CertError(
                "ca_key_pem must be a PEM private key (RSA/EC)",
                code="INVALID_PEM",
            )
        self.ensure_dir()
        self.ca_cert_path().write_text(crt + ("\n" if not crt.endswith("\n") else ""), encoding="utf-8")
        self.ca_key_path().write_text(key + ("\n" if not key.endswith("\n") else ""), encoding="utf-8")
        os.chmod(self.ca_key_path(), 0o600)
        try:
            self._run_openssl(["x509", "-in", str(self.ca_cert_path()), "-noout", "-subject"])
            self._run_openssl(["pkey", "-in", str(self.ca_key_path()), "-check", "-noout"])
        except subprocess.CalledProcessError as e:
            raise CertError(
                f"CA cert/key pair failed openssl validation: {e.stderr or e}",
                code="OPENSSL_ERROR",
            ) from e
        try:
            self._generate_proxy_leaf_certificate(
                proxy_cn=proxy_cn, validity_days=validity_days
            )
        except subprocess.CalledProcessError as e:
            raise CertError(
                f"Failed to sign proxy certificate: {e.stderr or e}",
                code="OPENSSL_ERROR",
            ) from e
        return {
            "ca_cert": str(self.ca_cert_path()),
            "ca_key": str(self.ca_key_path()),
            "proxy_cert": str(self.proxy_cert_path()),
            "proxy_key": str(self.proxy_key_path()),
            "imported": True,
        }

    def import_ca_pkcs12_bytes(
        self,
        pkcs12_data: bytes,
        *,
        password: str | None = None,
        proxy_cn: str = "MTK Proxy",
        validity_days: int = 3650,
    ) -> dict[str, Any]:
        """Install CA from PKCS#12 (e.g. ``root-ca.p12``), then re-sign the proxy leaf."""

        crt_pem, key_pem = extract_pem_from_pkcs12(pkcs12_data, password)
        return self.import_ca_pem_strings(
            crt_pem,
            key_pem,
            proxy_cn=proxy_cn,
            validity_days=validity_days,
        )

    def get_ca_cert_info(self) -> CertInfo:
        """Get information about the CA certificate."""
        return self._get_cert_info(self.ca_cert_path())

    def get_proxy_cert_info(self) -> CertInfo:
        """Get information about the proxy certificate."""
        return self._get_cert_info(self.proxy_cert_path())

    def _get_cert_info(self, cert_path: Path) -> CertInfo:
        """Get information about a certificate file."""
        if not cert_path.exists():
            return CertInfo(
                path=str(cert_path),
                exists=False,
                valid=False,
                expires_at=None,
                subject=None,
                issuer=None,
                error="Certificate file not found",
            )

        try:
            # Get certificate text
            result = subprocess.run(
                [
                    "openssl", "x509",
                    "-in", str(cert_path),
                    "-noout",
                    "-subject", "-issuer", "-enddate",
                ],
                capture_output=True,
                text=True,
                check=True,
            )

            lines = result.stdout.strip().split("\n")
            subject = None
            issuer = None
            expires_at = None

            for line in lines:
                if line.startswith("subject="):
                    subject = line[8:].strip()
                elif line.startswith("issuer="):
                    issuer = line[7:].strip()
                elif line.startswith("notAfter="):
                    date_str = line[9:].strip()
                    # Parse OpenSSL date format
                    import contextlib
                    with contextlib.suppress(ValueError):
                        expires_at = datetime.strptime(
                            date_str, "%b %d %H:%M:%S %Y %Z"
                        )

            valid = expires_at is not None and expires_at > datetime.utcnow()

            return CertInfo(
                path=str(cert_path),
                exists=True,
                valid=valid,
                expires_at=expires_at,
                subject=subject,
                issuer=issuer,
                error=None,
            )

        except subprocess.CalledProcessError as e:
            return CertInfo(
                path=str(cert_path),
                exists=True,
                valid=False,
                expires_at=None,
                subject=None,
                issuer=None,
                error=f"Failed to read certificate: {e.stderr or e}",
            )

    def status(self) -> dict[str, Any]:
        """Get overall certificate status."""
        return {
            "cert_dir": str(self._cert_dir),
            "certs_exist": self.certs_exist(),
            "ca_cert": self.get_ca_cert_info().to_dict(),
            "proxy_cert": self.get_proxy_cert_info().to_dict(),
            "install_instructions": self._install_instructions(),
        }

    def _install_instructions(self) -> str:
        """Get instructions for installing CA cert on devices."""
        ca_path = self.ca_cert_path()
        return f"""
To trust the proxy on your test devices, install the CA certificate:

1. Copy {ca_path} to your device

2. Install on different platforms:

   iOS:
   - Email or AirDrop the .crt file
   - Open and follow prompts to install profile
   - Go to Settings > General > About > Certificate Trust Settings
   - Enable trust for "MTK Proxy CA"

   Android:
   - Copy to device storage
   - Settings > Security > Install from storage
   - Select the .crt file

   macOS:
   - Double-click the .crt file
   - Add to Keychain
   - Open Keychain Access, find the cert, set to "Always Trust"

   Windows:
   - Double-click the .crt file
   - Install Certificate > Local Machine > Trusted Root CAs

   Your App (Test Build):
   - Embed the CA cert in your app bundle
   - Or disable certificate validation in debug builds
""".strip()
