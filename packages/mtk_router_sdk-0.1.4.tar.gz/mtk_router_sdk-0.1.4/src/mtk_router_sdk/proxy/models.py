"""Data models for MTK Proxy Engine."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from fnmatch import fnmatch
from typing import Any


class ProxyAction(str, Enum):
    """Action to take when a rule matches."""

    OVERRIDE = "override"  # Return custom response, skip upstream
    PASSTHROUGH = "passthrough"  # Forward to upstream, return unmodified
    MODIFY = "modify"  # Forward to upstream, modify response
    DELAY = "delay"  # Add delay before response (can combine with others)
    ERROR = "error"  # Return HTTP error status


class ProxyStatus(str, Enum):
    """Proxy engine status."""

    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    ERROR = "error"


@dataclass
class ProxyRule:
    """A proxy interception rule."""

    id: str = field(default_factory=lambda: f"rule_{uuid.uuid4().hex[:12]}")
    name: str = ""
    description: str = ""

    # Matching criteria
    client_ip: str | None = None  # None = match all clients
    slot_id: int | None = None  # None = match all slots
    upstream_host: str = "*"  # e.g., "api.hbomax.com" or "*"
    path_pattern: str = "*"  # Glob pattern, e.g., "/api/*/catalog"
    method: str | None = None  # None = match all methods

    # Action configuration
    action: ProxyAction = ProxyAction.OVERRIDE
    delay_ms: int = 0  # Delay before response (works with any action)

    # Response configuration (for OVERRIDE and ERROR)
    response_status: int = 200
    response_headers: dict[str, str] = field(default_factory=dict)
    response_body: Any = None  # Dict for JSON, str for text

    # Modifier configuration (for MODIFY action)
    json_set: dict[str, Any] = field(default_factory=dict)  # JSONPath → value
    json_delete: list[str] = field(default_factory=list)  # JSONPath list
    headers_set: dict[str, str] = field(default_factory=dict)
    headers_delete: list[str] = field(default_factory=list)

    # Rule state
    enabled: bool = True
    priority: int = 0  # Higher = checked first
    hit_count: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

    def matches_path(self, path: str) -> bool:
        """Check if path matches this rule's pattern."""
        if self.path_pattern == "*":
            return True
        # Support glob patterns
        if fnmatch(path, self.path_pattern):
            return True
        # Support regex patterns (prefix with ~)
        if self.path_pattern.startswith("~"):
            try:
                return bool(re.match(self.path_pattern[1:], path))
            except re.error:
                return False
        return False

    def matches_request(
        self,
        client_ip: str,
        host: str,
        path: str,
        method: str,
        slot_id: int | None = None,
    ) -> bool:
        """Check if a request matches this rule."""
        if not self.enabled:
            return False
        if self.client_ip and self.client_ip != client_ip:
            return False
        if self.slot_id is not None and self.slot_id != slot_id:
            return False
        if self.upstream_host != "*" and self.upstream_host != host:
            return False
        if self.method and self.method.upper() != method.upper():
            return False
        return self.matches_path(path)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "client_ip": self.client_ip,
            "slot_id": self.slot_id,
            "upstream_host": self.upstream_host,
            "path_pattern": self.path_pattern,
            "method": self.method,
            "action": self.action.value,
            "delay_ms": self.delay_ms,
            "response_status": self.response_status,
            "response_headers": self.response_headers,
            "response_body": self.response_body,
            "json_set": self.json_set,
            "json_delete": self.json_delete,
            "headers_set": self.headers_set,
            "headers_delete": self.headers_delete,
            "enabled": self.enabled,
            "priority": self.priority,
            "hit_count": self.hit_count,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProxyRule:
        """Create from dictionary."""
        action = data.get("action", "override")
        if isinstance(action, str):
            action = ProxyAction(action)
        return cls(
            id=data.get("id", f"rule_{uuid.uuid4().hex[:12]}"),
            name=data.get("name", ""),
            description=data.get("description", ""),
            client_ip=data.get("client_ip"),
            slot_id=data.get("slot_id"),
            upstream_host=data.get("upstream_host", "*"),
            path_pattern=data.get("path_pattern", "*"),
            method=data.get("method"),
            action=action,
            delay_ms=data.get("delay_ms", 0),
            response_status=data.get("response_status", 200),
            response_headers=data.get("response_headers", {}),
            response_body=data.get("response_body"),
            json_set=data.get("json_set", {}),
            json_delete=data.get("json_delete", []),
            headers_set=data.get("headers_set", {}),
            headers_delete=data.get("headers_delete", []),
            enabled=data.get("enabled", True),
            priority=data.get("priority", 0),
            hit_count=int(data.get("hit_count", 0)),
        )


@dataclass
class ProxyLogEntry:
    """A logged proxy request/response."""

    id: str = field(default_factory=lambda: f"log_{uuid.uuid4().hex[:12]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)

    # Request info
    client_ip: str = ""
    method: str = ""
    upstream_host: str = ""
    path: str = ""
    query_string: str = ""
    request_headers: dict[str, str] = field(default_factory=dict)
    request_body: str | None = None
    request_body_size: int = 0

    # Matching info
    matched_rule_id: str | None = None
    matched_rule_name: str | None = None
    action_taken: str = "passthrough"

    # Upstream info (if passthrough/modify)
    upstream_called: bool = False
    upstream_status: int | None = None
    upstream_latency_ms: int | None = None

    # Response info
    response_status: int = 200
    response_headers: dict[str, str] = field(default_factory=dict)
    response_body: str | None = None
    response_body_size: int = 0
    total_latency_ms: int = 0

    # Error info
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "client_ip": self.client_ip,
            "method": self.method,
            "upstream_host": self.upstream_host,
            "path": self.path,
            "query_string": self.query_string,
            "request_headers": self.request_headers,
            "request_body": self.request_body,
            "request_body_size": self.request_body_size,
            "matched_rule_id": self.matched_rule_id,
            "matched_rule_name": self.matched_rule_name,
            "action_taken": self.action_taken,
            "upstream_called": self.upstream_called,
            "upstream_status": self.upstream_status,
            "upstream_latency_ms": self.upstream_latency_ms,
            "response_status": self.response_status,
            "response_headers": self.response_headers,
            "response_body": self.response_body,
            "response_body_size": self.response_body_size,
            "total_latency_ms": self.total_latency_ms,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProxyLogEntry:
        """Build from API / JSON (mtk-serve log entry)."""
        ts_raw = data.get("timestamp")
        if isinstance(ts_raw, str):
            try:
                ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
            except ValueError:
                ts = datetime.utcnow()
        else:
            ts = datetime.utcnow()
        return cls(
            id=data.get("id", f"log_{uuid.uuid4().hex[:12]}"),
            timestamp=ts,
            client_ip=data.get("client_ip", ""),
            method=data.get("method", ""),
            upstream_host=data.get("upstream_host", ""),
            path=data.get("path", ""),
            query_string=data.get("query_string", ""),
            request_headers=data.get("request_headers", {}),
            request_body=data.get("request_body"),
            request_body_size=int(data.get("request_body_size", 0)),
            matched_rule_id=data.get("matched_rule_id"),
            matched_rule_name=data.get("matched_rule_name"),
            action_taken=data.get("action_taken", "passthrough"),
            upstream_called=bool(data.get("upstream_called", False)),
            upstream_status=data.get("upstream_status"),
            upstream_latency_ms=data.get("upstream_latency_ms"),
            response_status=int(data.get("response_status", 200)),
            response_headers=data.get("response_headers", {}),
            response_body=data.get("response_body"),
            response_body_size=int(data.get("response_body_size", 0)),
            total_latency_ms=int(data.get("total_latency_ms", 0)),
            error=data.get("error"),
        )


@dataclass
class ProxyConfig:
    """Proxy engine configuration."""

    # Certificate paths
    cert_dir: str = "~/.mtk/certs"
    cert_file: str = "proxy.crt"
    key_file: str = "proxy.key"
    ca_file: str = "ca.crt"

    # Server settings
    proxy_port: int = 8443
    enable_https: bool = True
    upstream_timeout: float = 30.0
    max_body_size: int = 10 * 1024 * 1024  # 10MB

    # Logging settings
    log_max_entries: int = 1000
    log_request_body: bool = True
    log_response_body: bool = True
    log_body_max_size: int = 100 * 1024  # 100KB max logged body

    # DNS override settings
    dns_override_enabled: bool = True

    def cert_path(self) -> str:
        """Get full path to certificate file."""
        import os
        return os.path.join(os.path.expanduser(self.cert_dir), self.cert_file)

    def key_path(self) -> str:
        """Get full path to key file."""
        import os
        return os.path.join(os.path.expanduser(self.cert_dir), self.key_file)

    def ca_path(self) -> str:
        """Get full path to CA file."""
        import os
        return os.path.join(os.path.expanduser(self.cert_dir), self.ca_file)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "cert_dir": self.cert_dir,
            "cert_file": self.cert_file,
            "key_file": self.key_file,
            "ca_file": self.ca_file,
            "proxy_port": self.proxy_port,
            "enable_https": self.enable_https,
            "upstream_timeout": self.upstream_timeout,
            "max_body_size": self.max_body_size,
            "log_max_entries": self.log_max_entries,
            "log_request_body": self.log_request_body,
            "log_response_body": self.log_response_body,
            "log_body_max_size": self.log_body_max_size,
            "dns_override_enabled": self.dns_override_enabled,
        }
