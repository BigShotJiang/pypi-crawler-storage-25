"""``mtk`` CLI — doctor, queries, exec, bootstrap (site JSON)."""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from typing import Any

from mtk_router_sdk import __version__
from mtk_router_sdk.bootstrap import BootstrapEngine
from mtk_router_sdk.bootstrap.engine import _ros_cli_ident
from mtk_router_sdk.cli_init_site import register_init_site
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.client_resolve import infer_slot_for_lease_ip, resolve_client_slot
from mtk_router_sdk.config import (
    connection_config_from_merged,
    load_site_config_from_path,
)
from mtk_router_sdk.discovery.models import RouterCapabilityProfile
from mtk_router_sdk.exceptions import ConfigurationError, MtkRouterError
from mtk_router_sdk.intent.runner import (
    IntentExecutionError,
    enabled_slot_by_ssid,
    routing_mark_for_slot,
)
from mtk_router_sdk.models import ConnectionConfig, ExecResult
from mtk_router_sdk.ops.client_block import (
    block_client,
    is_client_blocked,
    list_blocked_clients,
    unblock_client,
)
from mtk_router_sdk.ops.slot_route import update_policy_route_gateway
from mtk_router_sdk.ops.sniffer import (
    SnifferValidationError,
    capture_interface_for_slot,
    capture_interface_for_ssid,
    default_capture_filename,
    sniffer_print,
    validate_capture_filename,
)
from mtk_router_sdk.ops.sniffer import (
    sniffer_start as ros_sniffer_start,
)
from mtk_router_sdk.ops.sniffer import (
    sniffer_stop as ros_sniffer_stop,
)
from mtk_router_sdk.ops.vpn_checkpoint import build_vpn_checkpoint

_L2TP_REDACT_KEYS = frozenset({"password", "ipsec-secret"})


def _redact_router_cli_secrets(text: str) -> str:
    """Strip obvious secret fields from RouterOS ``print`` / ``monitor`` output."""

    t = re.sub(r"(?i)(password=)(\S+)", r"\1<redacted>", text)
    t = re.sub(r"(?i)(ipsec-secret=)(\S+)", r"\1<redacted>", t)
    return t


def _vpn_debug_tunnel_arg(raw: str) -> str:
    s = raw.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", s):
        raise argparse.ArgumentTypeError(
            "tunnel name must be letters, digits, underscore, hyphen, or dot",
        )
    return s


def _normalize_router_text(text: str) -> str:
    """Turn RouterOS SSH line endings into plain ``\\n`` for terminal display."""

    return text.replace("\r\n", "\n").replace("\r", "\n")


def _exec_json_dict(
    label: str,
    r: ExecResult,
    *,
    redact: bool = True,
    max_stdout: int | None = 24_000,
    tail: bool = False,
) -> dict[str, Any]:
    out = r.stdout if hasattr(r, "stdout") else ""
    if redact:
        out = _redact_router_cli_secrets(out)
    if max_stdout is not None and len(out) > max_stdout:
        if tail:
            out = "… [truncated — showing end of buffer]\n" + out[-max_stdout:]
        else:
            out = out[:max_stdout] + "\n… [truncated]\n"
    return {
        "label": label,
        "exit_status": r.exit_status,
        "stdout": out,
        "stderr": r.stderr if hasattr(r, "stderr") else "",
    }


def _print_vpn_debug_human(report: dict[str, Any]) -> None:
    """Print vpn-debug report with real newlines (not JSON-escaped log blobs)."""

    tunnel = report.get("tunnel", "")
    target = report.get("target", "")
    print(f"VPN debug  tunnel={tunnel}")
    print(f"           target={target}")
    print()
    steps = report.get("steps") or []
    for i, step in enumerate(steps):
        if not isinstance(step, dict):
            continue
        label = step.get("label", f"step_{i}")
        exit_status = step.get("exit_status", "")
        print(f"--- {label}  (exit {exit_status}) ---")
        out = step.get("stdout") or ""
        if out.strip():
            print(_normalize_router_text(out).rstrip())
        err = step.get("stderr") or ""
        if err.strip():
            print("stderr:", file=sys.stderr)
            print(_normalize_router_text(err).rstrip(), file=sys.stderr)
        print()


def _redact_l2tp_rows(
    rows: list[dict[str, Any]],
    *,
    show_secrets: bool,
) -> list[dict[str, Any]]:
    """Mask VPN secrets in JSON so terminal scrollback and screen shares stay safe."""

    if show_secrets:
        return rows
    out: list[dict[str, Any]] = []
    for row in rows:
        copy = dict(row)
        for k in _L2TP_REDACT_KEYS:
            if k in copy and str(copy[k]).strip():
                copy[k] = "<redacted>"
        out.append(copy)
    return out


def _ssh_config(args: argparse.Namespace | None) -> ConnectionConfig:
    """SSH target: optional ``--site`` JSON (``connection`` block) plus ``MTK_*`` env overrides."""

    if args is not None and getattr(args, "site_config_path", None):
        site = load_site_config_from_path(args.site_config_path)
        return connection_config_from_merged(site)
    return connection_config_from_merged(None)


def _print_doctor_success(cfg: ConnectionConfig, profile: RouterCapabilityProfile) -> None:
    d = profile.as_dict()
    ident = d["identity"]["name"] or "—"
    board = d["hardware"]["board_name"] or "—"
    ver = d["routeros"]["version"] or "—"
    print(f"Target: {cfg.describe_target()}")
    print()
    print("[OK] MikroTik RouterOS detected.")
    print(f"  Name      {ident}")
    print(f"  Board     {board}")
    print(f"  RouterOS  {ver}")
    print()
    print(json.dumps(d, indent=2))


def cmd_doctor(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        client.connect(cfg)
        profile = client.discover()
    except MtkRouterError as e:
        print(f"Target: {cfg.describe_target()}", file=sys.stderr)
        print(file=sys.stderr)
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        if e.router_output and e.router_output.strip():
            tail = e.router_output.strip()
            if len(tail) > 400:
                tail = tail[:400] + "…"
            print(file=sys.stderr)
            print("  Router output (truncated):", file=sys.stderr)
            for line in tail.splitlines()[:12]:
                print(f"    {line}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    _print_doctor_success(cfg, profile)
    return 0


def _run_connected(client: RouterClient, cfg: ConnectionConfig) -> int:
    try:
        client.connect(cfg)
        return 0
    except MtkRouterError as e:
        print(f"Target: {cfg.describe_target()}", file=sys.stderr)
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1


def cmd_interfaces(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        rows = client.exec_print_terse("/interface")
        print(json.dumps(rows, indent=2))
        return 0
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_ip_address(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        rows = client.exec_print_terse("/ip address")
        print(json.dumps(rows, indent=2))
        return 0
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_l2tp(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        rows = client.exec_print_terse("/interface l2tp-client")
        rows = _redact_l2tp_rows(rows, show_secrets=bool(args.show_secrets))
        print(json.dumps(rows, indent=2))
        return 0
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_vpn_debug(args: argparse.Namespace) -> int:
    """Run common L2TP / IPsec diagnostics in one shot (JSON on stdout)."""

    tunnel = str(args.tunnel)
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    mon_timeout = float(args.monitor_timeout)
    try:
        if _run_connected(client, cfg):
            return 1
        report: dict[str, Any] = {
            "tunnel": tunnel,
            "target": cfg.describe_target(),
            "steps": [],
        }
        steps = report["steps"]
        t_id = _ros_cli_ident(tunnel)
        r0 = client.exec_command(
            f"/interface l2tp-client print where name={t_id}",
            timeout=30.0,
        )
        steps.append(_exec_json_dict("l2tp_client_print", r0))
        r1 = client.exec_command(
            f"/interface l2tp-client monitor {t_id} once",
            timeout=mon_timeout,
        )
        steps.append(_exec_json_dict("l2tp_client_monitor_once", r1))
        r2 = client.exec_command("/ping count=2 8.8.8.8", timeout=15.0)
        steps.append(_exec_json_dict("ping_8.8.8.8", r2, redact=False))
        r3 = client.exec_command("/log print", timeout=30.0)
        steps.append(_exec_json_dict("log_print_tail", r3, max_stdout=14_000, tail=True))
        if bool(getattr(args, "json_output", False)):
            print(
                json.dumps(report, indent=2, ensure_ascii=False),
            )
        else:
            _print_vpn_debug_human(report)
        if r0.exit_status != 0:
            return 1
        return 0
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_vpn_reset(args: argparse.Namespace) -> int:
    """Disable then enable an L2TP client to drop IPsec/L2TP state and reconnect."""

    tunnel = str(args.tunnel)
    pause = max(0.0, float(args.reset_pause))
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        print(
            f"vpn-reset  tunnel={tunnel}  target={cfg.describe_target()}",
            file=sys.stderr,
        )
        t_id = _ros_cli_ident(tunnel)
        find = f"[find name={t_id}]"
        r0 = client.exec_command(
            f"/interface l2tp-client disable {find}",
            timeout=30.0,
        )
        if r0.exit_status != 0:
            print(
                f"[FAIL] disable failed (exit {r0.exit_status})",
                file=sys.stderr,
            )
            if r0.stderr.strip():
                print(r0.stderr.strip(), file=sys.stderr)
            if r0.stdout.strip():
                print(r0.stdout.strip(), file=sys.stderr)
            return 1
        print("  disabled; waiting before enable…", file=sys.stderr)
        if pause:
            time.sleep(pause)
        r1 = client.exec_command(
            f"/interface l2tp-client enable {find}",
            timeout=30.0,
        )
        if r1.exit_status != 0:
            print(
                f"[FAIL] enable failed (exit {r1.exit_status})",
                file=sys.stderr,
            )
            if r1.stderr.strip():
                print(r1.stderr.strip(), file=sys.stderr)
            if r1.stdout.strip():
                print(r1.stdout.strip(), file=sys.stderr)
            return 1
        print("  enabled. Watch logs or run: mtk vpn-debug", tunnel, file=sys.stderr)
        print(
            "  To re-apply site JSON from scratch: mtk bootstrap --apply path/to/site.json",
            file=sys.stderr,
        )
        return 0
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_exec(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        r = client.exec_command(args.command)
        out = {"exit_status": r.exit_status, "stdout": r.stdout, "stderr": r.stderr}
        print(json.dumps(out, indent=2))
        return 0 if r.ok else 1
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()


def cmd_bootstrap(args: argparse.Namespace) -> int:
    try:
        site = load_site_config_from_path(args.site_file)
    except ConfigurationError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1

    cfg = connection_config_from_merged(site)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        profile = client.discover()
        plan = BootstrapEngine().plan(site, profile)
    except MtkRouterError as e:
        client.disconnect()
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1

    if not args.apply:
        client.disconnect()
        print(f"Target: {cfg.describe_target()}")
        print()
        print(f"Planned {len(plan.steps)} bootstrap steps (dry run — no changes applied).")
        print("Re-run with --apply to execute on the router.")
        print()
        print(json.dumps(plan.as_dict(), indent=2))
        return 0

    try:
        BootstrapEngine.apply(client, plan, dry_run=False)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        ro = getattr(e, "router_output", None)
        if ro and str(ro).strip():
            print(file=sys.stderr)
            print(str(ro)[:800], file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(f"Target: {cfg.describe_target()}")
    print(f"[OK] Applied {len(plan.steps)} bootstrap steps.")
    return 0


def cmd_client_resolve(args: argparse.Namespace) -> int:
    """Print JSON: map client IP → slot (subnet, then DHCP ``dhcp_<id>`` on router)."""

    if not args.site_config_path:
        print(
            "[FAIL] client-resolve requires --site SITE.json",
            file=sys.stderr,
        )
        print("  Example: mtk client-resolve --site my.json --ip 172.20.101.45", file=sys.stderr)
        return 2
    ip = str(getattr(args, "ip", "") or "").strip()
    if not ip:
        print("[FAIL] --ip ADDRESS required (IPv4 or IPv6)", file=sys.stderr)
        return 2
    try:
        site = load_site_config_from_path(args.site_config_path)
    except ConfigurationError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1

    if getattr(args, "no_ssh", False):
        ctx = resolve_client_slot(site, ip, dhcp_rows=None)
        print(json.dumps(ctx.as_dict(), indent=2))
        return 0
    if infer_slot_for_lease_ip(ip, site) is not None:
        ctx = resolve_client_slot(site, ip, dhcp_rows=None)
        print(json.dumps(ctx.as_dict(), indent=2))
        return 0

    cfg = connection_config_from_merged(site)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        from mtk_router_sdk.service.snapshot import dhcp_lease_rows_from_router

        rows = dhcp_lease_rows_from_router(client)
        ctx = resolve_client_slot(site, ip, dhcp_rows=rows)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps(ctx.as_dict(), indent=2))
    return 0


def cmd_slot_vpn(args: argparse.Namespace) -> int:
    """Set ``/ip route`` gateway for a slot's routing-mark (same as HTTP ``POST …/vpn``)."""

    if not args.site_config_path:
        print(
            "[FAIL] slot-vpn requires --site SITE.json (to resolve routing-mark for the slot).",
            file=sys.stderr,
        )
        print(
            "  Example: mtk slot-vpn --site my-site.json 2 l2tp-uk",
            file=sys.stderr,
        )
        print(
            "  Or:      mtk slot-vpn --site my-site.json --ssid MyWiFi l2tp-uk",
            file=sys.stderr,
        )
        return 2
    try:
        site = load_site_config_from_path(args.site_config_path)
    except ConfigurationError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1

    ssid_opt = getattr(args, "ssid", None)
    ssid_s = str(ssid_opt).strip() if ssid_opt is not None else ""
    slot_id_arg = getattr(args, "slot_id", None)

    if ssid_s and slot_id_arg is not None:
        print("[FAIL] use either SLOT_ID or --ssid, not both.", file=sys.stderr)
        return 2
    if not ssid_s and slot_id_arg is None:
        print(
            "[FAIL] slot-vpn needs SLOT_ID or --ssid SSID (enabled slot from site JSON).",
            file=sys.stderr,
        )
        return 2

    try:
        if ssid_s:
            slot = enabled_slot_by_ssid(site, ssid_s)
            slot_id = int(slot.id)
        else:
            assert slot_id_arg is not None
            slot_id = int(slot_id_arg)
        mark = routing_mark_for_slot(site, slot_id)
    except IntentExecutionError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1

    cfg = connection_config_from_merged(site)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        r = update_policy_route_gateway(
            client,
            routing_mark=mark,
            gateway_interface=str(args.gateway_interface),
        )
        checkpoint = None
        if r.ok:
            checkpoint = build_vpn_checkpoint(
                client,
                site,
                slot_id,
                mark,
                str(args.gateway_interface),
            )
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    payload = {
        "ok": r.ok,
        "slot_id": slot_id,
        "ssid": ssid_s if ssid_s else None,
        "routing_mark": mark,
        "gateway_interface": str(args.gateway_interface),
        "stdout": r.stdout,
        "stderr": r.stderr,
        "exit_status": r.exit_status,
        "checkpoint": checkpoint,
    }
    print(json.dumps(payload, indent=2))
    return 0 if r.ok else 1


def cmd_sniffer_start(args: argparse.Namespace) -> int:
    """Start ``/tool sniffer`` on the slot interface with IPv4 filter; file on router."""

    if not args.site_config_path:
        print(
            "[FAIL] sniffer start requires --site SITE.json (slot interface name).",
            file=sys.stderr,
        )
        print(
            "  Example: mtk sniffer start --site my.json --slot 2 --ip 192.168.2.100",
            file=sys.stderr,
        )
        print(
            "  Or:      mtk sniffer start --site my.json --ssid MyWiFi --ip 192.168.2.100",
            file=sys.stderr,
        )
        return 2
    try:
        site = load_site_config_from_path(args.site_config_path)
    except ConfigurationError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        if e.hint:
            print(f"  → {e.hint}", file=sys.stderr)
        return 1
    ssid_s = str(getattr(args, "ssid", "") or "").strip()
    slot_id_arg = getattr(args, "slot_id", None)
    if ssid_s and slot_id_arg is not None:
        print("[FAIL] use either --slot or --ssid, not both.", file=sys.stderr)
        return 2
    if not ssid_s and slot_id_arg is None:
        print(
            "[FAIL] sniffer start needs --slot N or --ssid NAME (enabled slot from site).",
            file=sys.stderr,
        )
        return 2
    try:
        if ssid_s:
            iface = capture_interface_for_ssid(site, ssid_s)
            slot = enabled_slot_by_ssid(site, ssid_s)
            slot_id = int(slot.id)
        else:
            assert slot_id_arg is not None
            slot_id = int(slot_id_arg)
            iface = capture_interface_for_slot(site, slot_id)
    except IntentExecutionError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1

    filter_ip = str(args.filter_ip).strip()
    mem = getattr(args, "memory_limit", None)
    memory_limit = str(mem).strip() if mem else None
    try:
        if getattr(args, "file_name", None):
            file_name = validate_capture_filename(str(args.file_name).strip())
        else:
            file_name = default_capture_filename(slot_id, filter_ip)
    except SnifferValidationError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1

    cfg = connection_config_from_merged(site)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        try:
            r_last, snap = ros_sniffer_start(
                client,
                interface=iface,
                filter_ip=filter_ip,
                file_name=file_name,
                only_headers=bool(getattr(args, "only_headers", False)),
                memory_limit=memory_limit or None,
            )
        except SnifferValidationError as e:
            print(f"[FAIL] {e}", file=sys.stderr)
            return 1
    finally:
        client.disconnect()

    payload = {
        "ok": r_last.ok,
        "slot_id": slot_id,
        "ssid": ssid_s if ssid_s else None,
        "interface": iface,
        "filter_ip_address": filter_ip,
        "file_name": file_name,
        "sniffer": snap,
        "stdout": r_last.stdout,
        "stderr": r_last.stderr,
        "exit_status": r_last.exit_status,
        "hint": (
            "Download the .pcap from the router (Files / FTP / SCP). "
            "See docs/COMPLIANCE_AND_PRIVACY.md."
        ),
    }
    print(json.dumps(payload, indent=2))
    return 0 if r_last.ok else 1


def cmd_sniffer_stop(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        r = ros_sniffer_stop(client)
        snap = sniffer_print(client)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    payload = {
        "ok": r.ok,
        "sniffer": snap,
        "stdout": r.stdout,
        "stderr": r.stderr,
        "exit_status": r.exit_status,
    }
    print(json.dumps(payload, indent=2))
    return 0 if r.ok else 1


def cmd_sniffer_status(args: argparse.Namespace) -> int:
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        snap = sniffer_print(client)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps({"ok": True, "sniffer": snap}, indent=2))
    return 0


# --------------------------------------------------------------------------- #
# client-block: per-client internet block/unblock (firewall, runtime only)   #
# --------------------------------------------------------------------------- #


def cmd_client_block(args: argparse.Namespace) -> int:
    """Block internet for a client IP."""
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        result = block_client(client, args.ip)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps(result, indent=2))
    return 0 if result.get("ok") else 1


def cmd_client_unblock(args: argparse.Namespace) -> int:
    """Remove block for a client IP."""
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        result = unblock_client(client, args.ip)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps(result, indent=2))
    return 0 if result.get("ok") else 1


def cmd_client_block_list(args: argparse.Namespace) -> int:
    """List all blocked clients."""
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        result = list_blocked_clients(client)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps(result, indent=2))
    return 0 if result.get("ok") else 1


def cmd_client_block_status(args: argparse.Namespace) -> int:
    """Check if a client IP is blocked."""
    cfg = _ssh_config(args)
    client = RouterClient.with_ssh()
    try:
        if _run_connected(client, cfg):
            return 1
        result = is_client_blocked(client, args.ip)
    except MtkRouterError as e:
        print(f"[FAIL] {e.message}", file=sys.stderr)
        return 1
    finally:
        client.disconnect()

    print(json.dumps(result, indent=2))
    return 0 if result.get("ok") else 1


def cmd_version(_args: argparse.Namespace) -> int:
    print(__version__)
    return 0


# Shown at the end of ``mtk --help`` / ``mtk`` and printed by ``mtk help``.
_MTK_CLI_OVERVIEW = """
Command overview (use mtk COMMAND --help for flags and arguments).

Global (many router commands):
  -c, --site FILE     site JSON with optional connection; MTK_* env still override

Router / SSH (need MTK_HOST, MTK_USER, MTK_PASSWORD unless --site has connection):
  doctor              connect and run discovery (JSON capability profile)
  interfaces          /interface … print terse as JSON
  ip                  /ip address … print terse as JSON
  l2tp                L2TP clients as JSON (secrets redacted; --show-secrets unsafe)
  vpn-debug [TUNNEL]  L2TP print + monitor + ping + log (--json for scripts)
  vpn-reset [TUNNEL]  disable + enable L2TP client (unstick session)
  exec 'COMMAND'      one RouterOS command; JSON on stdout
  slot-vpn            set policy-route gateway (--ssid or SLOT_ID) + GATEWAY iface
  client-resolve      map client IP → slot (--ip ADDR; --no-ssh site-only)
  sniffer             start | stop | status — /tool sniffer, .pcap on router
  client-block        block | unblock | list | status — runtime firewall drop per IP
  bootstrap SITE.json plan from site + discovery (--apply runs on router)
  init-site           interactive wizard → site JSON (-o path, --force)

HTTP proxy (mtk-serve; set MTK_SERVICE_URL):
  proxy               status | list | add | delete | clear | set | error | log |
                      log-clear | certs | certs-generate
                      mock/intercept API responses per client IP (see docs/PROXY_TESTING.md)

Lab / testing (router SSH and/or mtk-serve depending on subcommand):
  network             profiles | apply | clear | list — throttle, latency, loss
  dns                 redirect | clear | list | flush — static DNS on router
  profile             apply | list | export | clear — saved YAML bundles
  scenario            run | list — YAML flows
  record              start | stop | replay | list | compare — HAR from proxy log

Dashboard (browser UI; default http://127.0.0.1:8766):
  dashboard           start | install | uninstall | status

Other:
  version             print this package version
  help                print this overview

Normative CLI reference: docs/CLI_REFERENCE.md
Environment variables: docs/ENVIRONMENT.md
"""


def cmd_help(_args: argparse.Namespace) -> int:
    print(_MTK_CLI_OVERVIEW.strip())
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mtk",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=(
            "MikroTik RouterOS SDK CLI — SSH to RouterOS, discovery, bootstrap, "
            "HTTP proxy (mtk-serve), lab testing, and dashboard."
        ),
        epilog=_MTK_CLI_OVERVIEW,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="print SDK version and exit",
    )
    sub = parser.add_subparsers(dest="command", help="command")

    ssh_parent = argparse.ArgumentParser(add_help=False)
    ssh_parent.add_argument(
        "-c",
        "--site",
        dest="site_config_path",
        metavar="FILE",
        default=None,
        help="site JSON with optional connection block (MTK_* env vars override file)",
    )

    p_doc = sub.add_parser(
        "doctor",
        parents=[ssh_parent],
        help="connect and run discovery (env or --site for SSH)",
    )
    p_doc.set_defaults(func=cmd_doctor)

    p_if = sub.add_parser(
        "interfaces",
        parents=[ssh_parent],
        help="print /interface … print terse as JSON",
    )
    p_if.set_defaults(func=cmd_interfaces)

    p_ip = sub.add_parser(
        "ip",
        parents=[ssh_parent],
        help="print /ip address … print terse as JSON",
    )
    p_ip.set_defaults(func=cmd_ip_address)

    p_l2 = sub.add_parser(
        "l2tp",
        parents=[ssh_parent],
        help="L2TP clients as JSON (secrets redacted; use --show-secrets to print raw)",
    )
    p_l2.add_argument(
        "--show-secrets",
        action="store_true",
        help="include password and ipsec-secret in JSON (unsafe for shared terminals)",
    )
    p_l2.set_defaults(func=cmd_l2tp)

    p_vpn = sub.add_parser(
        "vpn-debug",
        parents=[ssh_parent],
        help="L2TP client print + monitor + ping + log (human sections; use --json to pipe)",
    )
    p_vpn.add_argument(
        "tunnel",
        nargs="?",
        default="vpn_usa",
        type=_vpn_debug_tunnel_arg,
        help="L2TP client name from /interface l2tp-client (default: vpn_usa)",
    )
    p_vpn.add_argument(
        "--monitor-timeout",
        type=float,
        default=45.0,
        metavar="SEC",
        help="timeout for ``monitor … once`` (default: 45)",
    )
    p_vpn.add_argument(
        "--json",
        dest="json_output",
        action="store_true",
        help="emit one JSON object on stdout (log lines escaped; for scripts)",
    )
    p_vpn.set_defaults(func=cmd_vpn_debug)

    p_vpn_reset = sub.add_parser(
        "vpn-reset",
        parents=[ssh_parent],
        help="disable + enable L2TP client (clears stuck session; same config)",
    )
    p_vpn_reset.add_argument(
        "tunnel",
        nargs="?",
        default="vpn_usa",
        type=_vpn_debug_tunnel_arg,
        help="L2TP client name (default: vpn_usa)",
    )
    p_vpn_reset.add_argument(
        "--pause",
        dest="reset_pause",
        type=float,
        default=2.0,
        metavar="SEC",
        help="seconds between disable and enable (default: 2)",
    )
    p_vpn_reset.set_defaults(func=cmd_vpn_reset)

    p_ex = sub.add_parser(
        "exec",
        parents=[ssh_parent],
        help="run one RouterOS command; JSON result on stdout",
    )
    p_ex.add_argument("command", help='e.g. \'/ip dns print\'')
    p_ex.set_defaults(func=cmd_exec)

    p_slot_vpn = sub.add_parser(
        "slot-vpn",
        parents=[ssh_parent],
        help="set policy-route gateway for a slot (SSH; requires --site for routing-mark)",
    )
    p_slot_vpn.add_argument(
        "--ssid",
        default=None,
        metavar="NAME",
        help="enabled slot SSID from site JSON (alternative to SLOT_ID; exact match)",
    )
    p_slot_vpn.add_argument(
        "slot_id",
        nargs="?",
        default=None,
        type=int,
        metavar="SLOT_ID",
        help="numeric slot id (omit when using --ssid)",
    )
    p_slot_vpn.add_argument(
        "gateway_interface",
        type=_vpn_debug_tunnel_arg,
        metavar="GATEWAY",
        help="RouterOS interface name (e.g. l2tp-uk from: mtk l2tp)",
    )
    p_slot_vpn.set_defaults(func=cmd_slot_vpn)

    p_client_res = sub.add_parser(
        "client-resolve",
        parents=[ssh_parent],
        help="resolve client IP → slot (site subnets; SSH for DHCP dhcp_<id> if needed)",
    )
    p_client_res.add_argument(
        "--ip",
        required=True,
        metavar="ADDR",
        help="client IPv4/IPv6 to classify",
    )
    p_client_res.add_argument(
        "--no-ssh",
        action="store_true",
        help="only use site JSON (subnets / fallbacks); skip router DHCP query",
    )
    p_client_res.set_defaults(func=cmd_client_resolve)

    p_sniff = sub.add_parser(
        "sniffer",
        help="packet capture: /tool sniffer, IPv4 filter, .pcap on router",
    )
    sniff_sub = p_sniff.add_subparsers(dest="sniffer_cmd", required=True)

    p_sniff_start = sniff_sub.add_parser(
        "start",
        parents=[ssh_parent],
        help="start capture on slot interface for one IPv4 (saves on router)",
    )
    sniff_tgt = p_sniff_start.add_mutually_exclusive_group(required=True)
    sniff_tgt.add_argument(
        "--slot",
        type=int,
        dest="slot_id",
        metavar="N",
        help="enabled slot id from site JSON",
    )
    sniff_tgt.add_argument(
        "--ssid",
        dest="ssid",
        metavar="NAME",
        help="enabled slot SSID from site JSON (exact match)",
    )
    p_sniff_start.add_argument(
        "--ip",
        required=True,
        dest="filter_ip",
        metavar="IPv4",
        help="device IPv4 (RouterOS filter-ip-address)",
    )
    p_sniff_start.add_argument(
        "--file",
        dest="file_name",
        default=None,
        metavar="NAME.pcap",
        help="basename on router (default: mtk_slotN_x_x_x_x.pcap)",
    )
    p_sniff_start.add_argument(
        "--only-headers",
        action="store_true",
        help="L3 headers only (smaller capture)",
    )
    p_sniff_start.add_argument(
        "--memory-limit",
        default="100MiB",
        metavar="SIZE",
        help="RouterOS memory-limit (default: 100MiB)",
    )
    p_sniff_start.set_defaults(func=cmd_sniffer_start)

    p_sniff_stop = sniff_sub.add_parser(
        "stop",
        parents=[ssh_parent],
        help="stop sniffer (optional --site for SSH from site file)",
    )
    p_sniff_stop.set_defaults(func=cmd_sniffer_stop)

    p_sniff_status = sniff_sub.add_parser(
        "status",
        parents=[ssh_parent],
        help="print /tool sniffer print as JSON",
    )
    p_sniff_status.set_defaults(func=cmd_sniffer_status)

    # --------------------------------------------------------------------------- #
    # client-block: per-client internet block/unblock                             #
    # --------------------------------------------------------------------------- #
    p_cb = sub.add_parser(
        "client-block",
        help="per-client internet block (firewall drop, runtime only)",
    )
    cb_sub = p_cb.add_subparsers(dest="client_block_cmd", required=True)

    p_cb_block = cb_sub.add_parser(
        "block",
        parents=[ssh_parent],
        help="block internet for a client IP",
    )
    p_cb_block.add_argument("ip", help="client IPv4 address to block")
    p_cb_block.set_defaults(func=cmd_client_block)

    p_cb_unblock = cb_sub.add_parser(
        "unblock",
        parents=[ssh_parent],
        help="remove block for a client IP",
    )
    p_cb_unblock.add_argument("ip", help="client IPv4 address to unblock")
    p_cb_unblock.set_defaults(func=cmd_client_unblock)

    p_cb_list = cb_sub.add_parser(
        "list",
        parents=[ssh_parent],
        help="list all blocked clients",
    )
    p_cb_list.set_defaults(func=cmd_client_block_list)

    p_cb_status = cb_sub.add_parser(
        "status",
        parents=[ssh_parent],
        help="check if a client IP is blocked",
    )
    p_cb_status.add_argument("ip", help="client IPv4 address to check")
    p_cb_status.set_defaults(func=cmd_client_block_status)

    p_bo = sub.add_parser(
        "bootstrap",
        help="build plan from site JSON + discovery; use --apply to run on router",
    )
    p_bo.add_argument("site_file", help="path to site.json")
    p_bo.add_argument(
        "--apply",
        action="store_true",
        help="execute planned RouterOS scripts (default is dry-run only)",
    )
    p_bo.set_defaults(func=cmd_bootstrap)

    p_ver = sub.add_parser("version", help="print SDK version")
    p_ver.set_defaults(func=cmd_version)

    p_help = sub.add_parser(
        "help",
        help="print full command overview (all mtk subcommands)",
    )
    p_help.set_defaults(func=cmd_help)

    # Register proxy commands
    from mtk_router_sdk.proxy.cli import register_proxy_commands
    register_proxy_commands(sub)

    # Register testing commands
    from mtk_router_sdk.testing.cli import add_testing_parsers
    add_testing_parsers(sub)

    # Register dashboard command
    p_dash = sub.add_parser(
        "dashboard",
        help="on-demand real-time testing dashboard",
    )
    dash_sub = p_dash.add_subparsers(dest="dashboard_cmd", required=True)
    p_dash_start = dash_sub.add_parser("start", help="start dashboard server")
    p_dash_start.add_argument("--port", type=int, default=8766, help="port (default: 8766)")
    p_dash_start.add_argument("--host", default="127.0.0.1", help="bind host")
    p_dash_start.add_argument(
        "--poll-interval",
        type=float,
        default=3.0,
        dest="poll_interval",
        metavar="SEC",
        help="WebSocket stats/log poll interval in seconds (default: 3)",
    )
    p_dash_start.add_argument(
        "--no-auto-serve",
        action="store_true",
        help="Do not spawn mtk-serve when MTK_SERVICE_URL is unreachable on loopback",
    )

    # Service management commands
    p_dash_install = dash_sub.add_parser(
        "install",
        help="install as startup service (auto-start on login)",
    )
    p_dash_install.add_argument("--port", type=int, default=8766, help="port (default: 8766)")
    p_dash_install.add_argument("--host", default="127.0.0.1", help="bind host")
    p_dash_install.add_argument(
        "--no-auto-serve",
        action="store_true",
        help="Do not spawn mtk-serve automatically",
    )

    p_dash_uninstall = dash_sub.add_parser(
        "uninstall",
        help="remove startup service",
    )

    p_dash_status = dash_sub.add_parser(
        "status",
        help="check if dashboard service is installed/running",
    )

    def cmd_dashboard_wrapper(args: argparse.Namespace) -> int:
        from mtk_router_sdk.testing.dashboard import cmd_dashboard

        return cmd_dashboard(args)

    p_dash_start.set_defaults(func=cmd_dashboard_wrapper)
    p_dash_install.set_defaults(func=cmd_dashboard_wrapper)
    p_dash_uninstall.set_defaults(func=cmd_dashboard_wrapper)
    p_dash_status.set_defaults(func=cmd_dashboard_wrapper)

    register_init_site(sub)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
