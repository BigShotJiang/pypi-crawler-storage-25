from __future__ import annotations

import os
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import Any

from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config.load import resolve_secret_ref
from mtk_router_sdk.config.schema import SiteConfig, SlotConfig
from mtk_router_sdk.discovery.models import RouterCapabilityProfile
from mtk_router_sdk.exceptions import CommandExecutionError, ConfigurationError
from mtk_router_sdk.models import ExecResult
from mtk_router_sdk.parsing import parse_terse_lines


def _ros_escape_double_quoted(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _ros_name_token(name: str) -> str:
    """Return a double-quoted RouterOS string token for *name* (``name=…``, ``find``)."""

    return f'"{_ros_escape_double_quoted(name)}"'


def _ros_cli_ident(s: str) -> str:
    """Unquoted ``name=value`` token when *s* is a simple identifier, else quoted."""

    if s and all(c.isalnum() or c in "_-" for c in s):
        return s
    return _ros_name_token(s)


def _print_terse_rows(client: RouterClient, menu: str, *, timeout: float) -> list[dict[str, Any]]:
    cmd = f"{menu} print terse"
    r = client.exec_command(cmd, timeout=timeout, get_pty=False)
    if not r.ok:
        raise CommandExecutionError(
            f"Bootstrap probe failed ({cmd}), exit {r.exit_status}",
            hint="Check menu path, RouterOS version (wireless vs wifi), and permissions.",
            router_output=r.stderr or r.stdout,
        )
    return parse_terse_lines(r.stdout)


def _require_exec(client: RouterClient, command: str, *, timeout: float) -> ExecResult:
    return client.exec_command(command, timeout=timeout, get_pty=False)


def _imp_wifi_security(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = str(p.get("security_menu", "/interface wireless security-profiles"))
    prof = str(p["prof"])
    psk_q = str(p["psk_q"])
    prof_t = _ros_name_token(prof)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    names = {str(r.get("name", "")) for r in rows}
    if "/interface wifi security" in menu:
        if prof not in names:
            cmd = (
                f"{menu} add name={prof_t} authentication-types=wpa2-psk "
                f'wpa2-pre-shared-key="{psk_q}"'
            )
        else:
            cmd = f'{menu} set [find name={prof_t}] wpa2-pre-shared-key="{psk_q}"'
        return _require_exec(client, cmd, timeout=timeout)
    if prof not in names:
        cmd = (
            f"{menu} add name={prof_t} mode=dynamic-keys authentication-types=wpa2-psk "
            f'unicast-ciphers=aes-ccm group-ciphers=aes-ccm wpa2-pre-shared-key="{psk_q}"'
        )
    else:
        cmd = f'{menu} set [find name={prof_t}] wpa2-pre-shared-key="{psk_q}"'
    return _require_exec(client, cmd, timeout=timeout)


def _imp_l2tp(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/interface l2tp-client"
    tname = str(p["tname"])
    host_q = str(p["host_q"])
    vu_q = str(p["vu_q"])
    vp_q = str(p["vp_q"])
    vis_q = str(p["vis_q"])
    use_ipsec = p.get("use_ipsec", True)
    ipsec_flag = "yes" if use_ipsec else "no"
    t_t = _ros_name_token(tname)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    names = {str(r.get("name", "")) for r in rows}
    if tname not in names:
        cmd = (
            f'{menu} add name={t_t} connect-to="{host_q}" user="{vu_q}" password="{vp_q}" '
            f'use-ipsec={ipsec_flag} ipsec-secret="{vis_q}" disabled=no'
        )
    else:
        cmd = (
            f'{menu} set [find name={t_t}] connect-to="{host_q}" user="{vu_q}" '
            f'password="{vp_q}" use-ipsec={ipsec_flag} ipsec-secret="{vis_q}" disabled=no'
        )
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_wlan(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = str(p.get("wireless_menu", "/interface wireless"))
    if_name = str(p["if_name"])
    wlan = str(p["wlan"])
    ssid_q = str(p["ssid_q"])
    sec = str(p["security_profile"])
    if_t = _ros_name_token(if_name)
    wlan_t = _ros_name_token(wlan)
    sec_id = _ros_cli_ident(sec)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    names = {str(r.get("name", "")) for r in rows}
    wifiwave2 = menu.rstrip("/") == "/interface wifi" or menu.startswith("/interface wifi ")
    if wifiwave2:
        if if_name not in names:
            cmd = (
                f"{menu} add name={if_t} master-interface={wlan_t} "
                f'configuration.ssid="{ssid_q}" security={sec_id} disabled=no'
            )
        else:
            cmd = (
                f"{menu} set [find name={if_t}] master-interface={wlan_t} "
                f'configuration.ssid="{ssid_q}" security={sec_id} disabled=no'
            )
    elif if_name not in names:
        cmd = (
            f"{menu} add name={if_t} master-interface={wlan_t} ssid=\"{ssid_q}\" "
            f"security-profile={sec_id} disabled=no"
        )
    else:
        cmd = (
            f"{menu} set [find name={if_t}] master-interface={wlan_t} ssid=\"{ssid_q}\" "
            f"security-profile={sec_id} disabled=no"
        )
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_ip(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip address"
    if_name = str(p["if_name"])
    gw = str(p["gw"])
    cidr = int(p["cidr"])
    if_t = _ros_name_token(if_name)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    exists = any(str(r.get("interface", "")) == if_name for r in rows)
    if not exists:
        cmd = f"{menu} add address={gw}/{cidr} interface={if_t}"
    else:
        cmd = f"{menu} set [find interface={if_t}] address={gw}/{cidr}"
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_pool(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip pool"
    slot_id = int(p["slot_id"])
    subnet_prefix = str(p["subnet_prefix"])
    pool_name = f"pool_{slot_id}"
    rows = _print_terse_rows(client, menu, timeout=timeout)
    names = {str(r.get("name", "")) for r in rows}
    if pool_name in names:
        return ExecResult("", "", 0)
    cmd = f"{menu} add name={pool_name} ranges={subnet_prefix}.10-{subnet_prefix}.250"
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_dhcp(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip dhcp-server"
    if_name = str(p["if_name"])
    slot_id = int(p["slot_id"])
    dhcp_name = f"dhcp_{slot_id}"
    pool_name = f"pool_{slot_id}"
    if_t = _ros_name_token(if_name)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    names = {str(r.get("name", "")) for r in rows}
    if dhcp_name not in names:
        cmd = (
            f"{menu} add interface={if_t} address-pool={pool_name} "
            f"name={dhcp_name} disabled=no"
        )
    else:
        cmd = (
            f"{menu} set [find name={dhcp_name}] interface={if_t} "
            f"address-pool={pool_name} disabled=no"
        )
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_dhcp_net(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip dhcp-server network"
    subnet_prefix = str(p["subnet_prefix"])
    cidr = int(p["cidr"])
    gw = str(p["gw"])
    addr = f"{subnet_prefix}.0/{cidr}"
    rows = _print_terse_rows(client, menu, timeout=timeout)
    exists = any(str(r.get("address", "")) == addr for r in rows)
    if exists:
        return ExecResult("", "", 0)
    cmd = f'{menu} add address="{addr}" gateway={gw} dns-server=8.8.8.8'
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_ssh_allow(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    """If SSH is restricted by ``address=``, add this slot's subnet so clients can reach the router.

    RouterOS ``/ip service`` uses ``address`` as a comma-separated allow list (empty = all subnets).
    Many routers ship with only ``192.168.88.0/24``; slot DHCP nets are excluded unless we merge them.
    """

    if os.environ.get("MTK_BOOTSTRAP_SKIP_SSH_SERVICE", "").strip().lower() in (
        "1",
        "true",
        "yes",
    ):
        return ExecResult("", "", 0)
    subnet_prefix = str(p["subnet_prefix"])
    cidr = int(p["cidr"])
    slot_net = f"{subnet_prefix}.0/{cidr}"
    menu = "/ip service"
    rows = _print_terse_rows(client, menu, timeout=timeout)
    ssh_rows = [r for r in rows if str(r.get("name", "")).strip().lower() == "ssh"]
    if not ssh_rows:
        return ExecResult("", "", 0)
    cur = str(ssh_rows[0].get("address", "")).strip()
    if not cur:
        return ExecResult("", "", 0)
    parts = [x.strip() for x in cur.split(",") if x.strip()]
    if slot_net in parts:
        return ExecResult("", "", 0)
    merged = ",".join(parts + [slot_net])
    merged_q = _ros_escape_double_quoted(merged)
    cmd = f'{menu} set [find name=ssh] address="{merged_q}"'
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_input_ssh(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    """Accept SSH to the router on traffic arriving from the slot VAP (input chain).

    Default RouterOS configs often allow input only from ``bridge`` / main LAN. Clients on the slot
    SSID hit ``chain=input`` with ``in-interface=slot_N`` and get dropped before TCP/22 completes,
    which looks like a timeout from the laptop. ``place-before=*0`` keeps this above broad drops.
    """

    if os.environ.get("MTK_BOOTSTRAP_SKIP_INPUT_SSH", "").strip().lower() in (
        "1",
        "true",
        "yes",
    ):
        return ExecResult("", "", 0)
    if_name = str(p["if_name"])
    slot_id = int(p["slot_id"])
    if_t = _ros_name_token(if_name)
    comment = f"mtk-slot-{slot_id}-ssh-input"
    comment_q = _ros_escape_double_quoted(comment)
    menu = "/ip firewall filter"
    rows = _print_terse_rows(client, menu, timeout=timeout)
    for r in rows:
        if str(r.get("chain", "")).lower() != "input":
            continue
        if str(r.get("comment", "")).strip() == comment:
            return ExecResult("", "", 0)
    cmd = (
        f"{menu} add chain=input action=accept protocol=tcp dst-port=22 "
        f"in-interface={if_t} dst-address-type=local comment=\"{comment_q}\" place-before=*0"
    )
    return _require_exec(client, cmd, timeout=timeout)


def _mangle_row_matches_slot(row: dict[str, Any], *, if_name: str, mark: str) -> bool:
    return str(row.get("new-routing-mark", "")) == mark and str(
        row.get("in-interface", ""),
    ) == if_name


def _mangle_row_skips_local_dest(row: dict[str, Any]) -> bool:
    """True if the rule already exempts traffic destined to the router (SSH/Winbox/DNS)."""

    dt = str(row.get("dst-address-type", "")).strip().lower()
    return dt in ("!local",)


def _imp_slot_mangle(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip firewall mangle"
    if_name = str(p["if_name"])
    mark = str(p["mark"])
    if_t = _ros_name_token(if_name)
    mark_id = _ros_cli_ident(mark)
    rows = _print_terse_rows(client, menu, timeout=timeout)
    matching = [r for r in rows if _mangle_row_matches_slot(r, if_name=if_name, mark=mark)]
    if any(_mangle_row_skips_local_dest(r) for r in matching):
        return ExecResult("", "", 0)
    if matching:
        # Legacy rule without ``dst-address-type=!local`` — marks SSH/Winbox to the router, too.
        cmd = (
            f"{menu} set [find in-interface={if_t} new-routing-mark={mark_id}] "
            f"dst-address-type=!local"
        )
        return _require_exec(client, cmd, timeout=timeout)
    cmd = (
        f"{menu} add chain=prerouting in-interface={if_t} dst-address-type=!local "
        f"action=mark-routing new-routing-mark={mark_id} passthrough=yes"
    )
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_route(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip route"
    mark = str(p["mark"])
    tname = str(p["tname"])
    rows = _print_terse_rows(client, menu, timeout=timeout)
    exists = any(str(r.get("routing-mark", "")) == mark for r in rows)
    if exists:
        return ExecResult("", "", 0)
    gw_id = _ros_cli_ident(tname)
    mark_id = _ros_cli_ident(mark)
    cmd = f"{menu} add dst-address=0.0.0.0/0 gateway={gw_id} routing-mark={mark_id}"
    return _require_exec(client, cmd, timeout=timeout)


def _imp_slot_nat(client: RouterClient, p: dict[str, Any], *, timeout: float) -> ExecResult:
    menu = "/ip firewall nat"
    tname = str(p["tname"])
    rows = _print_terse_rows(client, menu, timeout=timeout)
    exists = any(
        str(r.get("chain", "")) == "srcnat" and str(r.get("out-interface", "")) == tname
        for r in rows
    )
    if exists:
        return ExecResult("", "", 0)
    out_id = _ros_cli_ident(tname)
    cmd = f"{menu} add chain=srcnat out-interface={out_id} action=masquerade"
    return _require_exec(client, cmd, timeout=timeout)


_IMPERATIVE: dict[str, Callable[[RouterClient, dict[str, Any], float], ExecResult]] = {
    "wifi_security": lambda c, p, t: _imp_wifi_security(c, p, timeout=t),
    "l2tp": lambda c, p, t: _imp_l2tp(c, p, timeout=t),
    "slot_wlan": lambda c, p, t: _imp_slot_wlan(c, p, timeout=t),
    "slot_ip": lambda c, p, t: _imp_slot_ip(c, p, timeout=t),
    "slot_pool": lambda c, p, t: _imp_slot_pool(c, p, timeout=t),
    "slot_dhcp": lambda c, p, t: _imp_slot_dhcp(c, p, timeout=t),
    "slot_dhcp_net": lambda c, p, t: _imp_slot_dhcp_net(c, p, timeout=t),
    "slot_ssh_allow": lambda c, p, t: _imp_slot_ssh_allow(c, p, timeout=t),
    "slot_input_ssh": lambda c, p, t: _imp_slot_input_ssh(c, p, timeout=t),
    "slot_mangle": lambda c, p, t: _imp_slot_mangle(c, p, timeout=t),
    "slot_route": lambda c, p, t: _imp_slot_route(c, p, timeout=t),
    "slot_nat": lambda c, p, t: _imp_slot_nat(c, p, timeout=t),
}


@dataclass(slots=True)
class BootstrapStep:
    phase: str
    description: str
    """Human / dry-run line (no ``:if`` script; apply uses *payload* imperatively)."""

    command: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class BootstrapPlan:
    steps: list[BootstrapStep] = field(default_factory=list)

    def commands(self) -> list[str]:
        return [s.command for s in self.steps]

    def as_dict(self) -> dict[str, Any]:
        steps_out = [
            {"phase": s.phase, "description": s.description, "command": s.command}
            for s in self.steps
        ]
        return {"steps": steps_out}


class BootstrapEngine:
    """Build idempotent RouterOS bootstrap steps from site config + discovery."""

    def plan(
        self,
        site: SiteConfig,
        profile: RouterCapabilityProfile,
        *,
        env: Mapping[str, str] | None = None,
    ) -> BootstrapPlan:
        masters = list(profile.wireless.master_interface_names)
        if site.enabled_slots and not masters:
            raise ConfigurationError(
                "Site has enabled Wi‑Fi slots but discovery found no master wireless interfaces.",
                hint="Use a MikroTik with wireless, or disable all slots for a wired-only test.",
            )

        psk = resolve_secret_ref(site.global_.wifi_security.psk_ref, env=env)
        v_user = resolve_secret_ref(site.global_.vpn_credentials.user_ref, env=env)
        v_pass = resolve_secret_ref(site.global_.vpn_credentials.password_ref, env=env)
        ipsec = site.global_.vpn_credentials.ipsec_secret_ref
        ipsec_secret = resolve_secret_ref(ipsec, env=env) if ipsec else v_pass

        psk_q = _ros_escape_double_quoted(psk)
        vu_q = _ros_escape_double_quoted(v_user)
        vp_q = _ros_escape_double_quoted(v_pass)
        vis_q = _ros_escape_double_quoted(ipsec_secret)

        prof = site.global_.wifi_security.profile_name
        steps: list[BootstrapStep] = []
        security_menu = (
            "/interface wifi security"
            if profile.wireless.menu_kind == "wifi"
            else "/interface wireless security-profiles"
        )

        steps.append(
            BootstrapStep(
                phase="wifi_security",
                description=f"Ensure WPA2-PSK security profile {prof!r}",
                command=(
                    f"{security_menu} ensure name={prof!r} "
                    f"(add or set wpa2-pre-shared-key from secrets)"
                ),
                payload={"prof": prof, "psk_q": psk_q, "security_menu": security_menu},
            )
        )

        use_ipsec = site.global_.vpn_credentials.use_ipsec
        regions = self._tunnel_regions(site)
        for region in sorted(regions):
            host = site.vpn_registry[region]
            tname = self._l2tp_tunnel_name_for_region(site, region)
            host_q = _ros_escape_double_quoted(host)
            ipsec_desc = "" if use_ipsec else " (no IPsec)"
            steps.append(
                BootstrapStep(
                    phase="l2tp",
                    description=f"L2TP client {tname} → {host} ({region}){ipsec_desc}",
                    command=(
                        f"/interface l2tp-client ensure name={tname!r} connect-to={host!r} "
                        "(add or set from secrets)"
                    ),
                    payload={
                        "tname": tname,
                        "host_q": host_q,
                        "vu_q": vu_q,
                        "vp_q": vp_q,
                        "vis_q": vis_q,
                        "use_ipsec": use_ipsec,
                    },
                )
            )

        wireless_menu = (
            profile.wireless.configuration_menu_prefix()
            if profile.wireless.has_wireless
            else "/interface wireless"
        )
        for idx, slot in enumerate(site.enabled_slots):
            steps.extend(
                self._slot_steps(
                    slot=slot,
                    master_default=masters[idx % len(masters)] if masters else "wlan1",
                    security_profile=prof,
                    wireless_menu=wireless_menu,
                )
            )

        return BootstrapPlan(steps=steps)

    def _tunnel_regions(self, site: SiteConfig) -> set[str]:
        pol = site.bootstrap.provision_tunnels
        if pol == "none":
            return set()
        if pol == "all_regions":
            return set(site.vpn_registry.keys())
        return {s.region for s in site.enabled_slots}

    @staticmethod
    def _default_tunnel_name(region: str) -> str:
        safe = region.lower().replace(" ", "_").replace("-", "_")
        return f"vpn_{safe}"

    def _l2tp_tunnel_name_for_region(self, site: SiteConfig, region: str) -> str:
        """L2TP interface name must match ``slot.tunnel_name`` (or default) for policy routes."""

        default = self._default_tunnel_name(region)
        seen: list[str] = []
        for slot in site.enabled_slots:
            if slot.region != region:
                continue
            seen.append(slot.tunnel_name or default)
        uniq: list[str] = []
        for n in seen:
            if n not in uniq:
                uniq.append(n)
        if len(uniq) > 1:
            raise ConfigurationError(
                f"Enabled slots disagree on tunnel_name for region {region!r}: {uniq!r}.",
                hint="Use one tunnel_name per region, or omit tunnel_name so all use the default.",
            )
        if len(uniq) == 1:
            return uniq[0]
        return default

    def _slot_steps(
        self,
        *,
        slot: SlotConfig,
        master_default: str,
        security_profile: str,
        wireless_menu: str,
    ) -> list[BootstrapStep]:
        wlan = slot.master_interface or master_default
        if_name = slot.interface_name or f"slot_{slot.id}"
        tname = slot.tunnel_name or self._default_tunnel_name(slot.region)
        mark = slot.routing_mark or f"rt_slot_{slot.id}"
        ssid_q = _ros_escape_double_quoted(slot.ssid)

        subnet_prefix, cidr = self._subnet_parts(slot)
        gw = f"{subnet_prefix}.1"

        return [
            BootstrapStep(
                phase="slot_wlan",
                description=f"Slot {slot.id}: VAP {if_name} SSID {slot.ssid!r}",
                command=f"{wireless_menu} ensure VAP {if_name!r} SSID {slot.ssid!r}",
                payload={
                    "if_name": if_name,
                    "wlan": wlan,
                    "ssid_q": ssid_q,
                    "security_profile": security_profile,
                    "wireless_menu": wireless_menu,
                },
            ),
            BootstrapStep(
                phase="slot_ip",
                description=f"Slot {slot.id}: bridge IP {gw}/{cidr}",
                command=f"/ip address ensure {gw}/{cidr} on {if_name!r}",
                payload={"if_name": if_name, "gw": gw, "cidr": cidr},
            ),
            BootstrapStep(
                phase="slot_pool",
                description=f"Slot {slot.id}: DHCP pool",
                command=f"/ip pool ensure pool_{slot.id} on {subnet_prefix}.0/{cidr}",
                payload={"slot_id": slot.id, "subnet_prefix": subnet_prefix},
            ),
            BootstrapStep(
                phase="slot_dhcp",
                description=f"Slot {slot.id}: DHCP server",
                command=f"/ip dhcp-server ensure dhcp_{slot.id} on {if_name!r}",
                payload={"if_name": if_name, "slot_id": slot.id},
            ),
            BootstrapStep(
                phase="slot_dhcp_net",
                description=f"Slot {slot.id}: DHCP network {subnet_prefix}.0/{cidr}",
                command=f"/ip dhcp-server network ensure {subnet_prefix}.0/{cidr}",
                payload={"subnet_prefix": subnet_prefix, "cidr": cidr, "gw": gw},
            ),
            BootstrapStep(
                phase="slot_ssh_allow",
                description=(
                    f"Slot {slot.id}: allow SSH from {subnet_prefix}.0/{cidr} "
                    f"if /ip service ssh uses address restrictions"
                ),
                command=f"/ip service merge ssh address for {subnet_prefix}.0/{cidr}",
                payload={"subnet_prefix": subnet_prefix, "cidr": cidr},
            ),
            BootstrapStep(
                phase="slot_input_ssh",
                description=(
                    f"Slot {slot.id}: firewall input accept TCP/22 from {if_name!r} "
                    f"(to router; placed before *0)"
                ),
                command=f"/ip firewall filter input accept ssh from {if_name!r} place-before=*0",
                payload={"if_name": if_name, "slot_id": slot.id},
            ),
            BootstrapStep(
                phase="slot_mangle",
                description=f"Slot {slot.id}: routing mark {mark}",
                command=f"/ip firewall mangle ensure mark {mark} in {if_name!r}",
                payload={"if_name": if_name, "mark": mark},
            ),
            BootstrapStep(
                phase="slot_route",
                description=f"Slot {slot.id}: policy route via {tname}",
                command=f"/ip route ensure default via {tname} mark {mark}",
                payload={"mark": mark, "tname": tname},
            ),
            BootstrapStep(
                phase="slot_nat",
                description=f"Slot {slot.id}: masquerade on {tname}",
                command=f"/ip firewall nat ensure masquerade out {tname!r}",
                payload={"tname": tname},
            ),
        ]

    @staticmethod
    def _subnet_parts(slot: SlotConfig) -> tuple[str, int]:
        """Return (prefix without /cidr, cidr bits) e.g. (\"172.20.101\", 24)."""

        if slot.subnet:
            s = slot.subnet.strip()
            if "/" not in s:
                raise ConfigurationError(f"slot {slot.id}: subnet must be CIDR, got {s!r}")
            addr, _, bits_s = s.partition("/")
            bits = int(bits_s)
            octets = addr.split(".")
            if len(octets) != 4:
                raise ConfigurationError(f"slot {slot.id}: invalid subnet {s!r}")
            return ".".join(octets[:3]), bits
        third = 100 + slot.id
        if third > 254:
            raise ConfigurationError(
                f"slot {slot.id}: auto subnet third octet {third} invalid; "
                "set subnet explicitly."
            )
        return f"172.20.{third}", 24

    @staticmethod
    def apply(client: RouterClient, plan: BootstrapPlan, *, dry_run: bool = True) -> list[str]:
        """Execute *plan* steps in order. If *dry_run*, return *commands()* only."""

        if dry_run:
            return plan.commands()
        log: list[str] = []
        step_timeout = float(os.environ.get("MTK_BOOTSTRAP_TIMEOUT", "120"))

        for step in plan.steps:
            fn = _IMPERATIVE.get(step.phase)
            if fn is None:
                raise ConfigurationError(
                    f"Unknown bootstrap phase {step.phase!r}",
                    hint="This is an SDK bug; report it with your site JSON redacted.",
                )
            try:
                r = fn(client, step.payload, step_timeout)
            except CommandExecutionError as e:
                raise CommandExecutionError(
                    f"Bootstrap step failed ({step.phase}): {step.description}",
                    hint=(
                        "Fix the router state or adjust site JSON; "
                        "partial changes may already be applied."
                    ),
                    router_output=e.router_output or e.message,
                ) from e
            if not r.ok:
                raise CommandExecutionError(
                    f"Bootstrap step failed ({step.phase}): {step.description}",
                    hint=(
                        "Fix the router state or adjust site JSON; "
                        "partial changes may already be applied."
                    ),
                    router_output=r.stderr or r.stdout,
                )
            log.append(step.command)
        return log

