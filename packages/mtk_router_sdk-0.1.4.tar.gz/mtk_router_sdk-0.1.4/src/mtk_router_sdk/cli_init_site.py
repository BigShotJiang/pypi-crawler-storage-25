"""Interactive wizard: write a site JSON with hints for ``mtk bootstrap``."""

from __future__ import annotations

import argparse
import json
import sys
from getpass import getpass
from pathlib import Path
from typing import Any


def _prompt(label: str, default: str = "") -> str:
    hint = f" [{default}]" if default else ""
    raw = input(f"{label}{hint}: ").strip()
    return raw if raw else default


def cmd_init_site(args: argparse.Namespace) -> int:
    out = Path(args.output)
    if out.exists() and not args.force:
        print(f"Refusing to overwrite {out} (use --force).", file=sys.stderr)
        return 1

    print()
    print("mtk init-site — build a site JSON for MikroTik bootstrap")
    print("─" * 50)
    print("Press Enter to accept [defaults]. For secrets, prefer option 1 (env vars).")
    print()

    print("── Router SSH (saved under \"connection\" in the file) ──")
    host = _prompt("Router IP or hostname", "192.168.88.1")
    user = _prompt("SSH username", "admin")
    print()
    print("SSH password")
    print("  1) env:MTK_PASSWORD (recommended)")
    print("  2) inline in JSON (do not commit this file)")
    pch = input("Choice [1]: ").strip() or "1"
    if pch == "2":
        ssh_pw = getpass("SSH password: ")
        password_ref = ssh_pw
    else:
        var = input("Env var name [MTK_PASSWORD]: ").strip() or "MTK_PASSWORD"
        password_ref = f"env:{var}"
    port_s = _prompt("SSH port", "22")
    timeout_s = _prompt("SSH timeout (seconds)", "10")
    try:
        port = int(port_s)
        timeout = float(timeout_s)
    except ValueError:
        print("Invalid port or timeout; using 22 and 10.", file=sys.stderr)
        port, timeout = 22, 10.0

    print()
    print("── Wi‑Fi security profile (WPA2 PSK for slot SSIDs) ──")
    prof = _prompt("Security profile name on router", "slot_wifi_sec")
    print()
    print("Wi‑Fi PSK (pre-shared key for guest SSIDs)")
    print("  1) env:MTK_WIFI_PSK (recommended)")
    print("  2) inline in JSON")
    wch = input("Choice [1]: ").strip() or "1"
    psk_ref = getpass("Wi‑Fi PSK: ") if wch == "2" else "env:MTK_WIFI_PSK"

    print()
    print("── L2TP / VPN credentials (to provider) ──")
    print("VPN username")
    print("  1) env:MTK_VPN_USER")
    print("  2) inline")
    vch_u = input("Choice [1]: ").strip() or "1"
    vpn_user_ref = _prompt("VPN username", "") if vch_u == "2" else "env:MTK_VPN_USER"

    print()
    print("VPN password")
    print("  1) env:MTK_VPN_PASSWORD")
    print("  2) inline")
    vch_p = input("Choice [1]: ").strip() or "1"
    vpn_pass_ref = getpass("VPN password: ") if vch_p == "2" else "env:MTK_VPN_PASSWORD"

    print()
    print("── Bootstrap policy ──")
    print("provision_tunnels: required_only = only tunnels for enabled slot regions")
    print("                   all_regions   = every region in vpn_registry")
    print("                   none          = do not create L2TP clients")
    prov = _prompt("provision_tunnels", "required_only")
    if prov not in ("required_only", "all_regions", "none"):
        print(f"Unknown {prov!r}; using required_only.", file=sys.stderr)
        prov = "required_only"

    print()
    print("── VPN registry (region label → L2TP server hostname/IP) ──")
    print("Example: region USA → host uspoint.provider.net")
    vpn_registry: dict[str, str] = {}
    while True:
        rk = input("Region name (empty to stop): ").strip()
        if not rk:
            break
        hv = _prompt(f"  L2TP host for {rk}", "")
        if not hv:
            print("  Skipped — need a hostname.", file=sys.stderr)
            continue
        vpn_registry[rk] = hv
        more = input("  Add another region? [y/N]: ").strip().lower()
        if more not in ("y", "yes"):
            break
    if not vpn_registry:
        print("At least one region is required.", file=sys.stderr)
        return 1

    print()
    print("── Wi‑Fi slots (SSID + region + tunnel name) ──")
    slots: list[dict[str, object]] = []
    slot_id = 1
    while True:
        print(f"--- Slot {slot_id} ---")
        first_reg = next(iter(vpn_registry)) if vpn_registry else "A"
        ssid = _prompt("  SSID (broadcast name)", f"Stream-{first_reg}")
        if not ssid:
            print("  Empty SSID; stopping slots.", file=sys.stderr)
            break
        reg_keys = list(vpn_registry.keys())
        if not reg_keys:
            print("  No regions defined; cannot add slot.", file=sys.stderr)
            return 1
        reg_default = reg_keys[0]
        reg = _prompt(f"  Region (one of: {', '.join(reg_keys)})", reg_default)
        if reg not in vpn_registry:
            print(f"  Region {reg!r} not in vpn_registry; using {reg_default!r}.", file=sys.stderr)
            reg = reg_default
        safe = reg.lower().replace(" ", "_")
        tname = _prompt("  tunnel_name (L2TP interface on router)", f"vpn_{safe}")
        en = _prompt("  Enable this slot? (y/n)", "y").lower() in ("y", "yes", "")
        slots.append(
            {
                "id": slot_id,
                "enabled": en,
                "ssid": ssid,
                "region": reg,
                "tunnel_name": tname,
                "master_interface": None,
                "subnet": None,
                "interface_name": None,
                "routing_mark": None,
            }
        )
        slot_id += 1
        if input("  Add another slot? [y/N]: ").strip().lower() not in ("y", "yes"):
            break

    if not slots:
        print("No slots defined; aborting.", file=sys.stderr)
        return 1

    doc: dict[str, object] = {
        "_meta": {
            "purpose": "Site config for mtk bootstrap. Env vars override these values when set.",
            "ssh": "connection.* uses password_ref; export MTK_PASSWORD if you chose env:",
            "git": "If any secret is inline, add this file to .gitignore.",
            "run": "mtk bootstrap this.json; mtk bootstrap --apply only on lab routers",
        },
        "version": 1,
        "connection": {
            "host": host,
            "username": user,
            "password_ref": password_ref,
            "port": port,
            "timeout": timeout,
        },
        "global": {
            "max_slots": 8,
            "wifi_security": {"profile_name": prof, "psk_ref": psk_ref},
            "vpn_credentials": {
                "user_ref": vpn_user_ref,
                "password_ref": vpn_pass_ref,
            },
        },
        "vpn_registry": vpn_registry,
        "bootstrap": {"provision_tunnels": prov},
        "slots": slots,
    }

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    print()
    print(f"Wrote {out.resolve()}")
    print()
    print("Next:")
    print(f"  mtk bootstrap {out}              # dry-run plan")
    print("  export any env:… variables you referenced")
    print("  mtk doctor --site FILE           # same SSH settings from file")
    return 0


def register_init_site(sub: Any) -> None:
    p = sub.add_parser(
        "init-site",
        help="interactive wizard to create a site JSON (connection + slots + VPN registry)",
    )
    p.add_argument(
        "-o",
        "--output",
        default="site.json",
        help="output path (default: site.json)",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="overwrite output file if it exists",
    )
    p.set_defaults(func=cmd_init_site)
