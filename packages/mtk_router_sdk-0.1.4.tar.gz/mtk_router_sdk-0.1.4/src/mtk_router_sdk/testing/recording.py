"""
Traffic Recording & Replay — HAR-based HTTP capture.

Usage:
    from mtk_router_sdk.testing import SessionRecorder

    recorder = SessionRecorder.from_env()

    # Start recording
    session_id = recorder.start("192.168.1.100", name="checkout-flow")

    # ... app makes HTTP requests ...

    # Stop and save
    har_file = recorder.stop(session_id)

    # Later: replay recorded session
    recorder.replay("192.168.1.100", har_file)

HAR (HTTP Archive) is a standard format compatible with:
- Chrome DevTools
- Charles Proxy
- Postman
- Firefox Developer Tools
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mtk_router_sdk.proxy import ProxyManager


@dataclass
class HarEntry:
    """A single HTTP request/response entry in HAR format."""

    started_datetime: str
    time_ms: float
    request_method: str
    request_url: str
    request_headers: list[dict[str, str]]
    request_body: str | None
    response_status: int
    response_headers: list[dict[str, str]]
    response_body: str | None
    response_content_type: str | None

    def to_dict(self) -> dict[str, Any]:
        """Convert to HAR entry format."""
        entry: dict[str, Any] = {
            "startedDateTime": self.started_datetime,
            "time": self.time_ms,
            "request": {
                "method": self.request_method,
                "url": self.request_url,
                "headers": self.request_headers,
                "bodySize": len(self.request_body) if self.request_body else 0,
            },
            "response": {
                "status": self.response_status,
                "headers": self.response_headers,
                "content": {
                    "size": len(self.response_body) if self.response_body else 0,
                    "mimeType": self.response_content_type or "application/octet-stream",
                },
            },
        }

        if self.request_body:
            entry["request"]["postData"] = {
                "mimeType": "application/json",
                "text": self.request_body,
            }

        if self.response_body:
            entry["response"]["content"]["text"] = self.response_body

        return entry

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HarEntry:
        """Create from HAR entry format."""
        request = data.get("request", {})
        response = data.get("response", {})
        content = response.get("content", {})

        return cls(
            started_datetime=data.get("startedDateTime", ""),
            time_ms=data.get("time", 0),
            request_method=request.get("method", "GET"),
            request_url=request.get("url", ""),
            request_headers=request.get("headers", []),
            request_body=request.get("postData", {}).get("text"),
            response_status=response.get("status", 200),
            response_headers=response.get("headers", []),
            response_body=content.get("text"),
            response_content_type=content.get("mimeType"),
        )


@dataclass
class HarFile:
    """HAR file container."""

    name: str = "MTK Recording"
    version: str = "1.2"
    entries: list[HarEntry] = field(default_factory=list)
    creator: dict[str, str] = field(
        default_factory=lambda: {"name": "MTK Router SDK", "version": "1.0"}
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to HAR format."""
        return {
            "log": {
                "version": self.version,
                "creator": self.creator,
                "entries": [e.to_dict() for e in self.entries],
            }
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HarFile:
        """Create from HAR format."""
        log = data.get("log", data)
        entries = [HarEntry.from_dict(e) for e in log.get("entries", [])]

        return cls(
            version=log.get("version", "1.2"),
            entries=entries,
            creator=log.get("creator", {"name": "Unknown", "version": "1.0"}),
        )

    @classmethod
    def from_file(cls, path: Path) -> HarFile:
        """Load from file."""
        with open(path) as f:
            data = json.load(f)
        har = cls.from_dict(data)
        har.name = path.stem
        return har

    def save(self, path: Path) -> None:
        """Save to file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    def add_entry(
        self,
        method: str,
        url: str,
        request_headers: dict[str, str] | None = None,
        request_body: str | None = None,
        response_status: int = 200,
        response_headers: dict[str, str] | None = None,
        response_body: str | None = None,
        response_content_type: str | None = None,
        time_ms: float = 0,
    ) -> HarEntry:
        """Add a new entry to the HAR file."""
        entry = HarEntry(
            started_datetime=datetime.utcnow().isoformat() + "Z",
            time_ms=time_ms,
            request_method=method,
            request_url=url,
            request_headers=[{"name": k, "value": v} for k, v in (request_headers or {}).items()],
            request_body=request_body,
            response_status=response_status,
            response_headers=[{"name": k, "value": v} for k, v in (response_headers or {}).items()],
            response_body=response_body,
            response_content_type=response_content_type,
        )
        self.entries.append(entry)
        return entry


@dataclass
class RecordingSession:
    """An active recording session."""

    id: str
    client_ip: str
    name: str
    started_at: datetime
    har: HarFile
    filter_hosts: list[str] | None = None


@dataclass
class SessionRecorder:
    """
    Record and replay HTTP sessions.

    Records HTTP traffic from the proxy into HAR format.
    Replay sets up proxy rules to return recorded responses.
    """

    proxy: ProxyManager | None = None
    recordings_dir: Path | None = None
    _sessions: dict[str, RecordingSession] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> SessionRecorder:
        """Create from environment variables."""
        from mtk_router_sdk.proxy import ProxyManager

        recordings_dir = os.environ.get("MTK_RECORDINGS_DIR")

        return cls(
            proxy=ProxyManager.from_env(),
            recordings_dir=Path(recordings_dir) if recordings_dir else None,
        )

    def start(
        self,
        client_ip: str,
        name: str | None = None,
        filter_hosts: list[str] | None = None,
    ) -> str:
        """
        Start recording HTTP traffic for a client.

        Args:
            client_ip: Client IP to record
            name: Session name (default: auto-generated)
            filter_hosts: Only record requests to these hosts

        Returns:
            Session ID to use with stop()
        """
        session_id = str(uuid.uuid4())[:8]
        session_name = name or f"session-{session_id}"

        session = RecordingSession(
            id=session_id,
            client_ip=client_ip,
            name=session_name,
            started_at=datetime.now(),
            har=HarFile(name=session_name),
            filter_hosts=filter_hosts,
        )

        self._sessions[session_id] = session
        return session_id

    def stop_for_client(self, client_ip: str) -> Path:
        """Stop the active recording for ``client_ip`` (dashboard / single-session UX).

        If several sessions share the IP, the most recently started one is stopped.
        """
        ip = (client_ip or "").strip()
        if not ip:
            raise ValueError("client_ip is required")
        matches = [sid for sid, s in self._sessions.items() if s.client_ip == ip]
        if not matches:
            raise ValueError(f"No active recording for client {ip!r}")
        sid = max(matches, key=lambda i: self._sessions[i].started_at)
        return self.stop(sid)

    def stop(
        self,
        session_id: str,
        save_path: Path | None = None,
    ) -> Path:
        """
        Stop recording and save HAR file.

        Args:
            session_id: Session ID from start()
            save_path: Where to save (default: recordings_dir/name.har)

        Returns:
            Path to saved HAR file
        """
        if session_id not in self._sessions:
            raise ValueError(f"Unknown session: {session_id}")

        session = self._sessions.pop(session_id)

        if self.proxy:
            logs = self.proxy.get_log(client_ip=session.client_ip, limit=1000)
            for log_entry in logs:
                if session.filter_hosts:
                    host_match = any(
                        h in (log_entry.upstream_host or "")
                        for h in session.filter_hosts
                    )
                    if not host_match:
                        continue

                if hasattr(log_entry, "timestamp"):
                    entry_time = log_entry.timestamp
                    if entry_time < session.started_at:
                        continue

                session.har.add_entry(
                    method=log_entry.method,
                    url=f"https://{log_entry.upstream_host}{log_entry.path}",
                    request_headers=log_entry.request_headers or {},
                    request_body=json.dumps(log_entry.request_body)
                    if log_entry.request_body else None,
                    response_status=log_entry.response_status or 200,
                    response_headers=log_entry.response_headers or {},
                    response_body=json.dumps(log_entry.response_body)
                    if log_entry.response_body else None,
                    response_content_type="application/json",
                    time_ms=log_entry.upstream_latency_ms or 0,
                )

        if save_path is None:
            if self.recordings_dir is None:
                self.recordings_dir = Path("recordings")
            save_path = self.recordings_dir / f"{session.name}.har"

        session.har.save(save_path)
        return save_path

    def is_recording(self, session_id: str) -> bool:
        """Check if a session is currently recording."""
        return session_id in self._sessions

    def get_session(self, session_id: str) -> RecordingSession | None:
        """Get a recording session by ID."""
        return self._sessions.get(session_id)

    def list_sessions(self) -> list[RecordingSession]:
        """List all active recording sessions."""
        return list(self._sessions.values())

    def replay(
        self,
        client_ip: str,
        har_path: Path | str,
        match_mode: str = "path",
    ) -> int:
        """
        Replay recorded session using proxy rules.

        Args:
            client_ip: Client IP to replay to
            har_path: Path to HAR file
            match_mode: How to match requests
                - "path": Match by URL path only
                - "url": Match by full URL
                - "method_path": Match by method + path

        Returns:
            Number of proxy rules created
        """
        if self.proxy is None:
            raise ValueError("Proxy not configured")

        har = HarFile.from_file(Path(har_path))
        rules_created = 0

        for entry in har.entries:
            try:
                body = json.loads(entry.response_body) if entry.response_body else None
            except json.JSONDecodeError:
                body = entry.response_body

            if match_mode == "path":
                from urllib.parse import urlparse
                parsed = urlparse(entry.request_url)
                path = parsed.path
            elif match_mode == "url":
                path = entry.request_url
            else:
                from urllib.parse import urlparse
                parsed = urlparse(entry.request_url)
                path = f"{entry.request_method}:{parsed.path}"

            response: dict[str, Any] | str
            if isinstance(body, dict):
                response = body
            elif body is None:
                response = {}
            else:
                response = str(body)
            self.proxy.set_response(
                client_ip,
                path,
                response,
                status=entry.response_status,
            )
            rules_created += 1

        return rules_created

    def compare(
        self,
        current_path: Path | str,
        golden_path: Path | str,
        ignore_fields: list[str] | None = None,
    ) -> HarDiff:
        """
        Compare two HAR files.

        Args:
            current_path: Path to current HAR
            golden_path: Path to golden (expected) HAR
            ignore_fields: Fields to ignore in comparison

        Returns:
            HarDiff with comparison results
        """
        current = HarFile.from_file(Path(current_path))
        golden = HarFile.from_file(Path(golden_path))

        return HarDiff.compare(current, golden, ignore_fields or [])

    def list_recordings(self) -> list[str]:
        """List available recordings."""
        if self.recordings_dir is None or not self.recordings_dir.exists():
            return []

        return [p.stem for p in self.recordings_dir.glob("*.har")]

    def delete_recording(self, name: str) -> bool:
        """
        Delete a recording file.

        Args:
            name: Recording name (without .har extension)

        Returns:
            True if deleted, False if not found
        """
        if self.recordings_dir is None:
            return False
        har_path = self.recordings_dir / f"{name}.har"
        if har_path.exists():
            har_path.unlink()
            return True
        return False

    def close(self) -> None:
        """Clean up resources."""
        for session_id in list(self._sessions.keys()):
            try:
                self.stop(session_id)
            except Exception:
                pass


@dataclass
class HarDiffEntry:
    """A difference between two HAR entries."""

    path: str
    field: str
    expected: Any
    actual: Any
    diff_type: str


@dataclass
class HarDiff:
    """Result of comparing two HAR files."""

    differences: list[HarDiffEntry] = field(default_factory=list)
    added_paths: list[str] = field(default_factory=list)
    removed_paths: list[str] = field(default_factory=list)
    matched_paths: list[str] = field(default_factory=list)

    @property
    def has_changes(self) -> bool:
        """Check if there are any differences."""
        return bool(self.differences or self.added_paths or self.removed_paths)

    def summary(self) -> str:
        """Get a summary of differences."""
        lines = []

        if self.added_paths:
            lines.append(f"Added {len(self.added_paths)} paths:")
            for path in self.added_paths[:5]:
                lines.append(f"  + {path}")
            if len(self.added_paths) > 5:
                lines.append(f"  ... and {len(self.added_paths) - 5} more")

        if self.removed_paths:
            lines.append(f"Removed {len(self.removed_paths)} paths:")
            for path in self.removed_paths[:5]:
                lines.append(f"  - {path}")
            if len(self.removed_paths) > 5:
                lines.append(f"  ... and {len(self.removed_paths) - 5} more")

        if self.differences:
            lines.append(f"Changed {len(self.differences)} fields:")
            for diff in self.differences[:5]:
                lines.append(f"  ~ {diff.path}.{diff.field}: {diff.expected} → {diff.actual}")
            if len(self.differences) > 5:
                lines.append(f"  ... and {len(self.differences) - 5} more")

        if not lines:
            lines.append("No differences found")

        return "\n".join(lines)

    @classmethod
    def compare(
        cls,
        current: HarFile,
        golden: HarFile,
        ignore_fields: list[str],
    ) -> HarDiff:
        """Compare two HAR files."""
        diff = cls()

        from urllib.parse import urlparse

        current_by_path: dict[str, HarEntry] = {}
        for entry in current.entries:
            parsed = urlparse(entry.request_url)
            key = f"{entry.request_method}:{parsed.path}"
            current_by_path[key] = entry

        golden_by_path: dict[str, HarEntry] = {}
        for entry in golden.entries:
            parsed = urlparse(entry.request_url)
            key = f"{entry.request_method}:{parsed.path}"
            golden_by_path[key] = entry

        current_paths = set(current_by_path.keys())
        golden_paths = set(golden_by_path.keys())

        diff.added_paths = list(current_paths - golden_paths)
        diff.removed_paths = list(golden_paths - current_paths)
        diff.matched_paths = list(current_paths & golden_paths)

        for path in diff.matched_paths:
            current_entry = current_by_path[path]
            golden_entry = golden_by_path[path]

            if current_entry.response_status != golden_entry.response_status:
                if "status" not in ignore_fields:
                    diff.differences.append(
                        HarDiffEntry(
                            path=path,
                            field="status",
                            expected=golden_entry.response_status,
                            actual=current_entry.response_status,
                            diff_type="changed",
                        )
                    )

            if current_entry.response_body and golden_entry.response_body:
                try:
                    current_body = json.loads(current_entry.response_body)
                    golden_body = json.loads(golden_entry.response_body)
                    cls._compare_json(
                        diff, path, current_body, golden_body, ignore_fields
                    )
                except json.JSONDecodeError:
                    if current_entry.response_body != golden_entry.response_body:
                        if "body" not in ignore_fields:
                            diff.differences.append(
                                HarDiffEntry(
                                    path=path,
                                    field="body",
                                    expected=golden_entry.response_body[:100],
                                    actual=current_entry.response_body[:100],
                                    diff_type="changed",
                                )
                            )

        return diff

    @classmethod
    def _compare_json(
        cls,
        diff: HarDiff,
        path: str,
        current: Any,
        golden: Any,
        ignore_fields: list[str],
        prefix: str = "",
    ) -> None:
        """Recursively compare JSON objects."""
        if type(current) is not type(golden):
            field_path = f"{prefix}type" if prefix else "type"
            if field_path not in ignore_fields:
                diff.differences.append(
                    HarDiffEntry(
                        path=path,
                        field=field_path,
                        expected=type(golden).__name__,
                        actual=type(current).__name__,
                        diff_type="type_changed",
                    )
                )
            return

        if isinstance(current, dict):
            current_keys = set(current.keys())
            golden_keys = set(golden.keys())

            for key in golden_keys - current_keys:
                field_path = f"{prefix}{key}" if prefix else key
                if field_path not in ignore_fields:
                    diff.differences.append(
                        HarDiffEntry(
                            path=path,
                            field=field_path,
                            expected=golden[key],
                            actual=None,
                            diff_type="removed",
                        )
                    )

            for key in current_keys - golden_keys:
                field_path = f"{prefix}{key}" if prefix else key
                if field_path not in ignore_fields:
                    diff.differences.append(
                        HarDiffEntry(
                            path=path,
                            field=field_path,
                            expected=None,
                            actual=current[key],
                            diff_type="added",
                        )
                    )

            for key in current_keys & golden_keys:
                field_path = f"{prefix}{key}." if prefix else f"{key}."
                cls._compare_json(
                    diff, path, current[key], golden[key], ignore_fields, field_path
                )

        elif isinstance(current, list):
            if len(current) != len(golden):
                field_path = f"{prefix}length" if prefix else "length"
                if field_path not in ignore_fields:
                    diff.differences.append(
                        HarDiffEntry(
                            path=path,
                            field=field_path,
                            expected=len(golden),
                            actual=len(current),
                            diff_type="changed",
                        )
                    )

        elif current != golden:
            field_path = prefix.rstrip(".") if prefix else "value"
            if field_path not in ignore_fields:
                diff.differences.append(
                    HarDiffEntry(
                        path=path,
                        field=field_path,
                        expected=golden,
                        actual=current,
                        diff_type="changed",
                    )
                )
