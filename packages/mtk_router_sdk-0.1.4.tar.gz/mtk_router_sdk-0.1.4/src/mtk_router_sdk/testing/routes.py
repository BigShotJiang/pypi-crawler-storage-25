"""
HTTP routes for testing features.

These routes are mounted on mtk-serve to provide HTTP API access
to network simulation, DNS override, profiles, and scenarios.
"""

from __future__ import annotations

import json

from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from mtk_router_sdk.testing.dns import DnsOverride
from mtk_router_sdk.testing.network import (
    NETWORK_PROFILES,
    NetworkCondition,
    NetworkSimulator,
)

_network: NetworkSimulator | None = None
_dns: DnsOverride | None = None


def get_network() -> NetworkSimulator:
    """Get or create NetworkSimulator instance."""
    global _network
    if _network is None:
        _network = NetworkSimulator.from_env()
    return _network


def get_dns() -> DnsOverride:
    """Get or create DnsOverride instance."""
    global _dns
    if _dns is None:
        _dns = DnsOverride.from_env()
    return _dns


async def network_profiles_list(request: Request) -> JSONResponse:
    """GET /v1/network/profiles - List available network profiles."""
    profiles = []
    for name, settings in NETWORK_PROFILES.items():
        profiles.append({
            "name": name,
            "download_kbps": settings["download_kbps"],
            "upload_kbps": settings["upload_kbps"],
            "latency_ms": settings["latency_ms"],
            "packet_loss_percent": settings["packet_loss_percent"],
        })
    return JSONResponse({"profiles": profiles})


async def network_condition_get(request: Request) -> JSONResponse:
    """GET /v1/network/condition?client_ip=X - Get condition for client."""
    client_ip = request.query_params.get("client_ip")
    if not client_ip:
        return JSONResponse(
            {"error": "client_ip required"}, status_code=400
        )

    network = get_network()
    condition = network.get_condition(client_ip)

    if condition is None:
        return JSONResponse({"active": False, "client_ip": client_ip})

    return JSONResponse({
        "client_ip": condition.client_ip,
        "active": condition.active,
        "profile": condition.profile,
        "download_kbps": condition.download_kbps,
        "upload_kbps": condition.upload_kbps,
        "latency_ms": condition.latency_ms,
        "packet_loss_percent": condition.packet_loss_percent,
    })


async def network_condition_list(request: Request) -> JSONResponse:
    """GET /v1/network/conditions - List all active conditions."""
    network = get_network()
    conditions = network.list_conditions()

    return JSONResponse({
        "conditions": [
            {
                "client_ip": c.client_ip,
                "active": c.active,
                "profile": c.profile,
                "download_kbps": c.download_kbps,
                "upload_kbps": c.upload_kbps,
                "latency_ms": c.latency_ms,
                "packet_loss_percent": c.packet_loss_percent,
            }
            for c in conditions
        ]
    })


async def network_apply(request: Request) -> JSONResponse:
    """POST /v1/network/apply - Apply network condition."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    client_ip = body.get("client_ip")
    if not client_ip:
        return JSONResponse(
            {"error": "client_ip required"}, status_code=400
        )

    network = get_network()

    profile = body.get("profile")
    condition: NetworkCondition | None
    if profile:
        condition = network.apply_profile(client_ip, profile)
    else:
        download = body.get("download_kbps")
        upload = body.get("upload_kbps")
        latency = body.get("latency_ms")
        loss = body.get("packet_loss_percent")

        if download or upload:
            network.throttle(client_ip, download, upload)
        if latency:
            network.latency(client_ip, latency, body.get("jitter_ms", 0))
        if loss:
            network.packet_loss(client_ip, loss)

        condition = network.get_condition(client_ip)

    if condition:
        return JSONResponse({
            "success": True,
            "client_ip": condition.client_ip,
            "profile": condition.profile,
            "download_kbps": condition.download_kbps,
            "upload_kbps": condition.upload_kbps,
            "latency_ms": condition.latency_ms,
            "packet_loss_percent": condition.packet_loss_percent,
        })

    return JSONResponse({"success": True, "client_ip": client_ip})


async def network_clear(request: Request) -> JSONResponse:
    """DELETE /v1/network/condition?client_ip=X - Clear condition."""
    client_ip = request.query_params.get("client_ip")

    network = get_network()

    if client_ip:
        network.clear(client_ip)
    else:
        network.clear_all()

    return JSONResponse({"success": True})


async def dns_redirects_list(request: Request) -> JSONResponse:
    """GET /v1/dns/redirects - List DNS redirects."""
    client_ip = request.query_params.get("client_ip")

    dns = get_dns()
    redirects = dns.list_redirects(client_ip)

    return JSONResponse({
        "redirects": [
            {
                "domain": r.domain,
                "target_ip": r.target_ip,
                "client_ip": r.client_ip,
                "ttl": r.ttl,
                "active": r.active,
            }
            for r in redirects
        ]
    })


async def dns_redirect_add(request: Request) -> JSONResponse:
    """POST /v1/dns/redirect - Add DNS redirect."""
    try:
        body = await request.json()
    except json.JSONDecodeError:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    domain = body.get("domain")
    if not domain:
        return JSONResponse(
            {"error": "domain required"}, status_code=400
        )

    client_ip = body.get("client_ip")
    target_ip = body.get("target_ip")
    to_proxy = body.get("to_proxy", False)
    ttl = body.get("ttl", 60)

    dns = get_dns()

    if to_proxy:
        redirect = dns.redirect(domain, client_ip, ttl)
    elif target_ip:
        redirect = dns.redirect_to_ip(domain, target_ip, client_ip, ttl)
    else:
        return JSONResponse(
            {"error": "Either to_proxy or target_ip required"},
            status_code=400,
        )

    return JSONResponse({
        "success": True,
        "domain": redirect.domain,
        "target_ip": redirect.target_ip,
        "client_ip": redirect.client_ip,
        "ttl": redirect.ttl,
    })


async def dns_redirect_remove(request: Request) -> JSONResponse:
    """DELETE /v1/dns/redirect - Remove DNS redirect."""
    domain = request.query_params.get("domain")
    client_ip = request.query_params.get("client_ip")

    dns = get_dns()

    if domain:
        removed = dns.remove(domain, client_ip)
    elif client_ip:
        dns.clear(client_ip)
        removed = True
    else:
        dns.clear_all()
        removed = True

    return JSONResponse({"success": True, "removed": removed})


async def dns_flush_cache(request: Request) -> JSONResponse:
    """POST /v1/dns/flush - Flush DNS cache."""
    dns = get_dns()
    dns.flush_cache()
    return JSONResponse({"success": True})


def get_testing_routes() -> list[Route]:
    """Get all testing-related routes."""
    return [
        Route("/v1/network/profiles", network_profiles_list, methods=["GET"]),
        Route("/v1/network/condition", network_condition_get, methods=["GET"]),
        Route("/v1/network/conditions", network_condition_list, methods=["GET"]),
        Route("/v1/network/apply", network_apply, methods=["POST"]),
        Route("/v1/network/condition", network_clear, methods=["DELETE"]),
        Route("/v1/dns/redirects", dns_redirects_list, methods=["GET"]),
        Route("/v1/dns/redirect", dns_redirect_add, methods=["POST"]),
        Route("/v1/dns/redirect", dns_redirect_remove, methods=["DELETE"]),
        Route("/v1/dns/flush", dns_flush_cache, methods=["POST"]),
    ]
