"""Curated ``MTK_*`` variables the dashboard can set from Settings (saved in workspace)."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any

from mtk_router_sdk.config.env_parse import parse_int_env
from mtk_router_sdk.exceptions import ConfigurationError

ENV_UI_APPLIED_FILENAME = "dashboard-env-ui-applied.json"

# Keys the Settings UI may persist under workspace["env_ui"] and apply to this process.
ALLOWED_ENV_UI_KEYS: frozenset[str] = frozenset(
    {
        "MTK_TRUST_X_FORWARDED_FOR",
        "MTK_DASHBOARD_AUTO_SERVE",
        "MTK_PROXY_LOCAL_ONLY",
        "MTK_HOST_LAN_SCAN",
        "MTK_SKIP_GATEWAY_DETECT",
        "MTK_AUTO_SSH_PROBE",
        "MTK_CLIENT_FALLBACK_SLOT_ID",
        "MTK_HTTP_PORT",
        "MTK_LAN_GATEWAY_SL24",
    }
)


def env_ui_registry() -> list[dict[str, Any]]:
    """Metadata for the Settings → Environment panel (order = UI order)."""

    return [
        {
            "key": "MTK_TRUST_X_FORWARDED_FOR",
            "label": "Trust X-Forwarded-For",
            "description": (
                "When this dashboard calls mtk-serve, allow the first X-Forwarded-For hop "
                "as client_ip if not supplied. Enable only behind your own reverse proxy."
            ),
            "kind": "bool",
            "bool_style": "truthy_when_on",
        },
        {
            "key": "MTK_DASHBOARD_AUTO_SERVE",
            "label": "Auto-start mtk-serve (loopback)",
            "description": (
                "If MTK_SERVICE_URL is http on loopback and nothing is listening, "
                "spawn mtk-serve. Turn off to start mtk-serve yourself."
            ),
            "kind": "bool",
            "bool_style": "default_on_clear_means_on",
        },
        {
            "key": "MTK_PROXY_LOCAL_ONLY",
            "label": "Proxy: local-only rules",
            "description": (
                "Use in-process proxy rules only (no HTTP to mtk-serve). "
                "Unset = default remote mtk-serve from MTK_SERVICE_URL."
            ),
            "kind": "bool",
            "bool_style": "truthy_when_on",
        },
        {
            "key": "MTK_HOST_LAN_SCAN",
            "label": "LAN host scan (ARP / neighbours)",
            "description": "Host-side ARP/neighbour discovery for the device picker and LAN APIs.",
            "kind": "bool",
            "bool_style": "default_on_clear_means_on",
        },
        {
            "key": "MTK_SKIP_GATEWAY_DETECT",
            "label": "Skip gateway detect (use 192.168.88.1)",
            "description": "Skip scanning for the router; use the MikroTik default LAN address only.",
            "kind": "bool",
            "bool_style": "truthy_when_on",
        },
        {
            "key": "MTK_AUTO_SSH_PROBE",
            "label": "TCP probe SSH candidates",
            "description": "When picking a router host, probe port 22. Turn off to skip probes.",
            "kind": "bool",
            "bool_style": "default_on_clear_means_on",
        },
        {
            "key": "MTK_LAN_GATEWAY_SL24",
            "label": "Guess /24 from default gateway",
            "description": "Add x.y.z.0/24 from the IPv4 default gateway for LAN scans. Off on larger LANs.",
            "kind": "bool",
            "bool_style": "default_on_clear_means_on",
        },
        {
            "key": "MTK_HTTP_PORT",
            "label": "mtk-serve HTTP port (hint)",
            "description": (
                "TCP port for embedded mtk-serve and service URL hints in this process. "
                "mtk-serve itself still reads its env at startup."
            ),
            "kind": "port",
        },
        {
            "key": "MTK_CLIENT_FALLBACK_SLOT_ID",
            "label": "Client fallback slot id",
            "description": "Numeric slot id when client IP does not match a slot subnet (mtk-serve).",
            "kind": "text",
        },
    ]


def _env_ui_applied_path() -> Path:
    return Path.home() / ".mtk" / ENV_UI_APPLIED_FILENAME


def _read_env_ui_keys_to_clear() -> list[str]:
    path = _env_ui_applied_path()
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, dict):
        return []
    raw = data.get("keys")
    if not isinstance(raw, list):
        return []
    return [str(x).strip() for x in raw if str(x).strip() in ALLOWED_ENV_UI_KEYS]


def _write_env_ui_keys(keys: list[str]) -> None:
    path = _env_ui_applied_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"keys": keys}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def _truthy_env(val: str | None) -> bool:
    if val is None:
        return False
    return val.strip().lower() in ("1", "true", "yes", "on")


def validate_env_ui_block(raw: Any) -> str | None:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        return "env_ui must be an object"
    for k, v in raw.items():
        ks = str(k).strip()
        if ks not in ALLOWED_ENV_UI_KEYS:
            return f"Unsupported env_ui key: {ks!r}"
        if v is not None and not isinstance(v, (str, int, float, bool)):
            return f"env_ui value for {ks!r} must be a string or number"
        if v is not None and isinstance(v, str) and not str(v).strip():
            continue
        _, err = normalize_env_ui_entry(ks, v)
        if err:
            return err
    return None


def normalize_env_ui_entry(key: str, val: Any) -> tuple[str | None, str | None]:
    """Return ``(value_to_set, error)``; ``None`` value means omit (do not set in ``env_ui``)."""

    if val is None:
        return None, None
    s = str(val).strip()
    if not s:
        return None, None
    if key == "MTK_HTTP_PORT":
        try:
            p = parse_int_env("MTK_HTTP_PORT", 8765, env={key: s}, minimum=1, maximum=65535)
        except ConfigurationError as e:
            return None, e.message
        return str(p), None
    if key == "MTK_CLIENT_FALLBACK_SLOT_ID":
        if not s.isdigit():
            return None, "MTK_CLIENT_FALLBACK_SLOT_ID must be digits only"
        return s, None
    if key in (
        "MTK_TRUST_X_FORWARDED_FOR",
        "MTK_PROXY_LOCAL_ONLY",
        "MTK_SKIP_GATEWAY_DETECT",
    ):
        low = s.lower()
        if low in ("1", "true", "yes", "on"):
            return "1", None
        if low in ("0", "false", "no", "off"):
            return None, None
        return None, f"Invalid boolean for {key!r}: {s!r}"
    if key in (
        "MTK_DASHBOARD_AUTO_SERVE",
        "MTK_HOST_LAN_SCAN",
        "MTK_AUTO_SSH_PROBE",
        "MTK_LAN_GATEWAY_SL24",
    ):
        low = s.lower()
        if low in ("0", "false", "no", "off"):
            return "0", None
        if low in ("1", "true", "yes", "on"):
            return None, None
        return None, f"Invalid boolean for {key!r}: {s!r}"
    return s, None


def normalize_env_ui_dict(raw: dict[str, Any]) -> tuple[dict[str, str], str | None]:
    out: dict[str, str] = {}
    for k, v in raw.items():
        ks = str(k).strip()
        if ks not in ALLOWED_ENV_UI_KEYS:
            return {}, f"Unsupported env_ui key: {ks!r}"
        nv, err = normalize_env_ui_entry(ks, v)
        if err:
            return {}, err
        if nv is not None:
            out[ks] = nv
    return out, None


def env_ui_effective_bool(key: str, style: str) -> bool:
    """Interpret ``os.environ`` for bool-style controls (for GET payload)."""

    raw = os.environ.get(key)
    if style == "truthy_when_on":
        return _truthy_env(raw)
    if style == "default_on_clear_means_on":
        if raw is None or not str(raw).strip():
            return True
        low = str(raw).strip().lower()
        if low in ("0", "false", "no", "off"):
            return False
        return True
    return False


def build_env_ui_state_payload() -> dict[str, Any]:
    """JSON for ``GET /api/setup/env-ui``."""

    from mtk_router_sdk.testing.dashboard_workspace import load_workspace

    w = load_workspace()
    saved = w.get("env_ui") if isinstance(w.get("env_ui"), dict) else {}
    saved_s = {str(k): str(v) for k, v in saved.items() if str(k) in ALLOWED_ENV_UI_KEYS}
    effective: dict[str, str] = {}
    bool_state: dict[str, bool] = {}
    for row in env_ui_registry():
        key = str(row["key"])
        if row.get("kind") == "bool":
            bool_state[key] = env_ui_effective_bool(key, str(row.get("bool_style", "")))
            effective[key] = "1" if bool_state[key] else "0"
        else:
            effective[key] = os.environ.get(key, "") or ""
    return {
        "controls": env_ui_registry(),
        "saved": saved_s,
        "effective": effective,
        "bool_state": bool_state,
        "hint": (
            "Values apply to this dashboard process and are stored in "
            "~/.mtk/dashboard-workspace.json (env_ui). mtk-serve reads its own "
            "environment when it starts — restart mtk-serve after changing server-side vars."
        ),
    }


def apply_env_ui(workspace: dict[str, Any]) -> None:
    """Pop keys from the last env_ui apply, then set ``workspace['env_ui']`` entries."""

    for lk in _read_env_ui_keys_to_clear():
        os.environ.pop(lk, None)

    raw = workspace.get("env_ui")
    if not isinstance(raw, dict):
        _write_env_ui_keys([])
        return

    applied: list[str] = []
    for k, v in raw.items():
        ks = str(k).strip()
        if ks not in ALLOWED_ENV_UI_KEYS:
            continue
        nv, err = normalize_env_ui_entry(ks, v)
        if err or nv is None:
            continue
        os.environ[ks] = nv
        applied.append(ks)
    _write_env_ui_keys(applied)
