"""
Local dashboard workspace: multi-profile credentials for Router SSH, VPN, and mtk-serve.

Stored under ``~/.mtk/dashboard-workspace.json`` (mode 0600). Values are applied to
``os.environ`` for this dashboard process so :class:`MtkTestKit` picks them up.

This is an **initial-stage** helper for newcomers; production teams may prefer shell
env, a secrets manager, or site JSON only.
"""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any

from mtk_router_sdk.config.vpn_endpoint_creds import normalize_profile_endpoint_overrides

WORKSPACE_VERSION = 1
WORKSPACE_FILENAME = "dashboard-workspace.json"
LAB_ENV_APPLIED_FILENAME = "dashboard-lab-env-applied.json"


def workspace_file_path() -> Path:
    d = Path.home() / ".mtk"
    return d / WORKSPACE_FILENAME


def _lab_env_applied_path() -> Path:
    return Path.home() / ".mtk" / LAB_ENV_APPLIED_FILENAME


def _read_lab_env_keys_to_clear() -> list[str]:
    path = _lab_env_applied_path()
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, dict):
        return []
    raw = data.get("keys")
    if not isinstance(raw, list):
        return []
    return [str(x).strip() for x in raw if str(x).strip().startswith("MTK_")]


def _write_lab_env_keys(keys: list[str]) -> None:
    path = _lab_env_applied_path()
    _ensure_dir(path.parent)
    path.write_text(
        json.dumps({"keys": keys}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def default_workspace() -> dict[str, Any]:
    return {
        "version": WORKSPACE_VERSION,
        "onboarding_done": False,
        "active_profile_id": None,
        "profiles": [],
        "env_ui": {},
    }


def load_workspace() -> dict[str, Any]:
    path = workspace_file_path()
    if not path.is_file():
        return default_workspace()
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError):
        return default_workspace()
    if not isinstance(data, dict):
        return default_workspace()
    if int(data.get("version", 0)) != WORKSPACE_VERSION:
        merged = default_workspace()
        merged.update({k: v for k, v in data.items() if k in merged})
        merged["version"] = WORKSPACE_VERSION
        return merged
    out = default_workspace()
    out.update(data)
    out.setdefault("profiles", [])
    out.setdefault("env_ui", {})
    eu = out.get("env_ui")
    if isinstance(eu, dict):
        cleaned: dict[str, str] = {}
        for k, v in eu.items():
            ks = str(k).strip()
            if not ks:
                continue
            if v is None:
                continue
            if isinstance(v, bool):
                s = "1" if v else "0"
            else:
                s = str(v).strip()
            if s:
                cleaned[ks] = s
        out["env_ui"] = cleaned
    return out


def save_workspace(data: dict[str, Any]) -> Path:
    path = workspace_file_path()
    _ensure_dir(path.parent)
    body = json.dumps(data, indent=2, ensure_ascii=False)
    path.write_text(body, encoding="utf-8")
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return path


def _profile_has_endpoint_vpn(p: dict[str, Any]) -> bool:
    for v in normalize_profile_endpoint_overrides(p.get("vpn_endpoint_overrides")).values():
        if str(v.get("user", "")).strip() and str(v.get("password", "")).strip():
            return True
    return False


def _profile_by_id(workspace: dict[str, Any], pid: str | None) -> dict[str, Any] | None:
    if not pid:
        return None
    for p in workspace.get("profiles") or []:
        if isinstance(p, dict) and p.get("id") == pid:
            return p
    return None


def _apply_lab_env(prof: dict[str, Any]) -> list[str]:
    """Merge optional ``lab_env`` mapping (``MTK_*`` keys only) into ``os.environ``.

    Returns the list of ``MTK_*`` keys set here (for clearing on the next profile switch).
    Empty values are skipped (use profile fields or omit the key).
    """

    raw = prof.get("lab_env")
    if not isinstance(raw, dict):
        return []
    applied: list[str] = []
    for k, v in raw.items():
        ks = str(k).strip()
        if not ks.startswith("MTK_"):
            continue
        if v is None or (isinstance(v, str) and not str(v).strip()):
            continue
        os.environ[ks] = str(v).strip()
        applied.append(ks)
    return applied


def apply_active_profile_env(workspace: dict[str, Any]) -> None:
    """Copy active profile fields into ``os.environ`` (non-empty values only)."""

    prof = _profile_by_id(workspace, workspace.get("active_profile_id"))

    for lk in _read_lab_env_keys_to_clear():
        os.environ.pop(lk, None)

    if not prof:
        from mtk_router_sdk.testing.dashboard_env_ui import apply_env_ui

        apply_env_ui(workspace)
        return

    def _set(key: str, val: Any) -> None:
        if val is None:
            return
        s = str(val).strip()
        if s:
            os.environ[key] = s

    _set("MTK_HOST", prof.get("router_host"))
    _set("MTK_USER", prof.get("router_user"))
    _set("MTK_PASSWORD", prof.get("router_password"))
    rp = prof.get("router_port")
    if rp is not None and str(rp).strip():
        os.environ["MTK_PORT"] = str(int(rp))
    rt = prof.get("router_timeout_sec")
    if rt is not None and str(rt).strip():
        os.environ["MTK_TIMEOUT"] = str(float(rt))

    _set("MTK_VPN_USER", prof.get("vpn_user"))
    _set("MTK_VPN_PASSWORD", prof.get("vpn_password"))
    _set("MTK_VPN_IPSEC_SECRET", prof.get("vpn_ipsec_secret"))

    ep_map = normalize_profile_endpoint_overrides(prof.get("vpn_endpoint_overrides"))
    if ep_map:
        os.environ["MTK_VPN_ENDPOINT_CREDENTIALS"] = json.dumps(ep_map, separators=(",", ":"))
    else:
        os.environ.pop("MTK_VPN_ENDPOINT_CREDENTIALS", None)

    act_ep = str(prof.get("vpn_active_endpoint") or "").strip()
    if act_ep:
        os.environ["MTK_VPN_ACTIVE_ENDPOINT"] = act_ep
    else:
        os.environ.pop("MTK_VPN_ACTIVE_ENDPOINT", None)

    _set("MTK_SERVICE_URL", prof.get("mtk_service_url"))
    _set("MTK_SERVICE_TOKEN", prof.get("mtk_service_token"))

    applied_lab = _apply_lab_env(prof)
    _write_lab_env_keys(applied_lab)

    from mtk_router_sdk.testing.dashboard_env_ui import apply_env_ui

    apply_env_ui(workspace)


def load_and_apply_workspace() -> dict[str, Any]:
    w = load_workspace()
    apply_active_profile_env(w)
    return w


def workspace_public_status(workspace: dict[str, Any]) -> dict[str, Any]:
    """Safe fields for ``GET /api/setup/status`` (no secrets)."""

    profiles = workspace.get("profiles") or []
    env_has_ssh = bool(os.environ.get("MTK_PASSWORD", "").strip())
    env_has_service = bool(os.environ.get("MTK_SERVICE_URL", "").strip())
    active = workspace.get("active_profile_id")
    prof = _profile_by_id(workspace, active) if active else None

    has_saved_router = bool(
        prof
        and str(prof.get("router_host", "")).strip()
        and str(prof.get("router_user", "")).strip()
        and str(prof.get("router_password", "")).strip()
    )
    has_saved_service = bool(prof and str(prof.get("mtk_service_url", "")).strip())

    onboarding_done = bool(workspace.get("onboarding_done"))
    has_profiles = len([p for p in profiles if isinstance(p, dict) and p.get("id")]) > 0

    # First-time: no onboarding flag, no profiles file meaningfully used, shell not pre-configured
    show_setup_wizard = (
        not onboarding_done
        and not has_profiles
        and not env_has_ssh
        and not env_has_service
    )

    summaries: list[dict[str, Any]] = []
    for p in profiles:
        if not isinstance(p, dict):
            continue
        summaries.append(
            {
                "id": p.get("id"),
                "label": p.get("label") or p.get("id"),
                "has_router": bool(
                    str(p.get("router_host", "")).strip()
                    and str(p.get("router_user", "")).strip()
                    and str(p.get("router_password", "")).strip()
                ),
                "has_vpn": bool(
                    (str(p.get("vpn_user", "")).strip() and str(p.get("vpn_password", "")).strip())
                    or _profile_has_endpoint_vpn(p)
                ),
                "has_mtk_service": bool(str(p.get("mtk_service_url", "")).strip()),
            }
        )

    return {
        "workspace_path": str(workspace_file_path()),
        "onboarding_done": onboarding_done,
        "active_profile_id": active,
        "profile_summaries": summaries,
        "env_has_ssh_password": env_has_ssh,
        "env_has_service_url": env_has_service,
        "has_saved_router": has_saved_router,
        "has_saved_service": has_saved_service,
        "show_setup_wizard": show_setup_wizard,
        "ready_hint": (
            "Saved workspace + active profile drive this dashboard process."
            if has_profiles
            else "Use Setup to save credentials, or export MTK_HOST / MTK_PASSWORD / MTK_SERVICE_URL in your shell."
        ),
    }


def _validate_lab_env_block(raw: Any) -> str | None:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        return "lab_env must be an object"
    for k, v in raw.items():
        ks = str(k).strip()
        if not ks.startswith("MTK_"):
            return f"lab_env keys must start with MTK_: {ks!r}"
        if v is not None and not isinstance(v, (str, int, float, bool)):
            return f"lab_env value for {ks!r} must be a string or number"
    return None


def validate_workspace_payload(body: dict[str, Any]) -> str | None:
    """Return error message or None if OK."""

    if not isinstance(body, dict):
        return "Invalid body"
    profiles = body.get("profiles")
    if profiles is not None:
        if not isinstance(profiles, list):
            return "profiles must be a list"
        ids: set[str] = set()
        for p in profiles:
            if not isinstance(p, dict):
                return "Each profile must be an object"
            pid = str(p.get("id") or "").strip()
            if not pid:
                return "Each profile needs a non-empty id"
            if pid in ids:
                return f"Duplicate profile id: {pid}"
            ids.add(pid)
            err = _validate_lab_env_block(p.get("lab_env"))
            if err:
                return err
        aid = body.get("active_profile_id")
        if aid is not None and str(aid).strip() and str(aid) not in ids:
            return "active_profile_id must match a profile id"
    if body.get("env_ui") is not None:
        from mtk_router_sdk.testing.dashboard_env_ui import validate_env_ui_block

        ev_err = validate_env_ui_block(body.get("env_ui"))
        if ev_err:
            return ev_err
    return None
