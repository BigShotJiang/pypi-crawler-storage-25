"""
pytest Integration — Fixtures and hooks for MTK testing.

Usage in conftest.py:
    pytest_plugins = ["mtk_router_sdk.testing.pytest_plugin"]

Or register manually:
    from mtk_router_sdk.testing.pytest_plugin import mtk_fixtures
    pytest_plugins = [mtk_fixtures]

Then in your tests:
    def test_slow_network(mtk, client_ip):
        mtk.network.apply_profile(client_ip, "3G")
        # ... test code ...

    def test_premium_user(mtk_proxy, client_ip):
        mtk_proxy.set_response(client_ip, "/api/subscription", {"plan": "premium"})
        # ... test code ...

RECOMMENDED — Use tracked_mtk for automatic change tracking & cleanup:
    def test_complex_scenario(tracked_mtk):
        # All changes are automatically recorded
        tracked_mtk.network.apply_profile("192.168.1.100", "3g")
        tracked_mtk.dns.redirect("api.example.com", "192.168.1.100")
        tracked_mtk.proxy.set_response("192.168.1.100", "/api/test", {"ok": True})

        # View what changed
        print(tracked_mtk.tracker.summary())

        # ... test code ...
    # ALL changes automatically cleaned up!

Available fixtures:
    tracked_mtk  - TrackedMtkTestKit with auto-cleanup (RECOMMENDED)
    mtk          - Full MtkTestKit instance
    mtk_network  - NetworkSimulator
    mtk_dns      - DnsOverride
    mtk_proxy    - ProxyManager
    mtk_profiles - ProfileManager
    mtk_recorder - SessionRecorder
    client_ip    - Test device IP (from MTK_TEST_CLIENT_IP env var)
"""

from __future__ import annotations

import os
from collections.abc import Generator
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    pass

try:
    import pytest

    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False
    pytest = None  # type: ignore[assignment]


if HAS_PYTEST and pytest is not None:

    @pytest.fixture(scope="session")
    def mtk() -> Generator[Any, None, None]:
        """
        Full MtkTestKit instance (session-scoped).

        Provides access to all testing features:
        - mtk.network: Network condition simulation
        - mtk.dns: DNS override automation
        - mtk.proxy: API proxy
        - mtk.profiles: Configuration profiles
        - mtk.scenarios: Test scenarios
        - mtk.recorder: Traffic recording

        Environment variables:
            MTK_HOST, MTK_USER, MTK_PASSWORD: Router connection
            MTK_SERVICE_URL: HTTP service URL
            MTK_SERVICE_TOKEN: API token
        """
        from mtk_router_sdk.testing import MtkTestKit

        kit = MtkTestKit.from_env()
        yield kit
        kit.close()

    @pytest.fixture(scope="function")
    def tracked_mtk() -> Generator[Any, None, None]:
        """
        Tracked MtkTestKit that records ALL changes for single-call teardown.

        All changes (network, DNS, proxy, etc.) are automatically recorded.
        At teardown, all changes are cleaned up with a single call.

        Usage:
            def test_complex_scenario(tracked_mtk):
                # Apply multiple changes
                tracked_mtk.network.apply_profile("192.168.1.100", "3g")
                tracked_mtk.dns.redirect("api.example.com", "192.168.1.100")
                tracked_mtk.proxy.set_response("192.168.1.100", "/api/test", {"ok": True})

                # Check what changed
                print(tracked_mtk.tracker.summary())
                # → {'total_changes': 3, 'affected_clients': ['192.168.1.100'], ...}

                # ... test code ...

            # ALL changes automatically cleaned up!

        For manual teardown:
            tracked_mtk.teardown()  # Cleans up everything
        """
        from mtk_router_sdk.testing import TrackedMtkTestKit

        kit = TrackedMtkTestKit.from_env()
        yield kit
        kit.teardown()
        kit.close()

    @pytest.fixture(scope="function")
    def mtk_network(mtk: Any, client_ip: str) -> Generator[Any, None, None]:
        """
        NetworkSimulator fixture (function-scoped, auto-cleanup).

        Usage:
            def test_slow_network(mtk_network, client_ip):
                mtk_network.apply_profile(client_ip, "3G")
                # ... test ...
                # Automatically cleaned up after test
        """
        yield mtk.network
        mtk.network.clear(client_ip)

    @pytest.fixture(scope="function")
    def mtk_dns(mtk: Any, client_ip: str) -> Generator[Any, None, None]:
        """
        DnsOverride fixture (function-scoped, auto-cleanup).

        Usage:
            def test_dns_redirect(mtk_dns, client_ip):
                mtk_dns.redirect("api.example.com", client_ip)
                # ... test ...
                # Automatically cleaned up after test
        """
        yield mtk.dns
        mtk.dns.clear(client_ip)

    @pytest.fixture(scope="function")
    def mtk_proxy(mtk: Any, client_ip: str) -> Generator[Any, None, None]:
        """
        ProxyManager fixture (function-scoped, auto-cleanup).

        Usage:
            def test_mock_response(mtk_proxy, client_ip):
                mtk_proxy.set_response(client_ip, "/api/test", {"ok": True})
                # ... test ...
                # Automatically cleaned up after test
        """
        yield mtk.proxy
        try:
            mtk.proxy.clear_client(client_ip)
        except Exception:
            pass

    @pytest.fixture(scope="session")
    def mtk_profiles(mtk: Any) -> Any:
        """
        ProfileManager fixture (session-scoped).

        Usage:
            def test_premium_user(mtk_profiles, client_ip):
                mtk_profiles.apply("premium-user", client_ip)
                # ... test ...
        """
        return mtk.profiles

    @pytest.fixture(scope="session")
    def mtk_scenarios(mtk: Any) -> Any:
        """
        ScenarioRunner fixture (session-scoped).

        Usage:
            def test_geo_blocking(mtk_scenarios, client_ip):
                result = mtk_scenarios.run("geo-block-test", client_ip)
                assert result.passed
        """
        return mtk.scenarios

    @pytest.fixture(scope="function")
    def mtk_recorder(mtk: Any) -> Generator[Any, None, None]:
        """
        SessionRecorder fixture (function-scoped, auto-cleanup).

        Usage:
            def test_record_session(mtk_recorder, client_ip):
                session_id = mtk_recorder.start(client_ip, "my-flow")
                # ... app makes requests ...
                har_file = mtk_recorder.stop(session_id)
        """
        yield mtk.recorder
        mtk.recorder.close()

    @pytest.fixture(scope="session")
    def client_ip() -> str:
        """
        Test client IP address (from MTK_TEST_CLIENT_IP env var).

        Set this to the IP of your test device.

        Usage:
            def test_something(mtk_proxy, client_ip):
                mtk_proxy.set_response(client_ip, "/api/test", {"ok": True})
        """
        ip = os.environ.get("MTK_TEST_CLIENT_IP", "192.168.1.100")
        return ip

    @pytest.fixture(scope="function")
    def slow_network(
        mtk_network: Any, client_ip: str
    ) -> Generator[None, None, None]:
        """
        Convenience fixture: Apply 3G network profile.

        Usage:
            def test_buffering(slow_network, app):
                app.play_video()
                assert app.shows_buffering()
        """
        mtk_network.apply_profile(client_ip, "3g")
        yield
        mtk_network.clear(client_ip)

    @pytest.fixture(scope="function")
    def offline(
        mtk_network: Any, client_ip: str
    ) -> Generator[None, None, None]:
        """
        Convenience fixture: Simulate offline state.

        Usage:
            def test_offline_mode(offline, app):
                assert app.shows_offline_indicator()
        """
        mtk_network.apply_profile(client_ip, "offline")
        yield
        mtk_network.clear(client_ip)

    @pytest.fixture(scope="function")
    def premium_user(
        mtk_proxy: Any, client_ip: str
    ) -> Generator[None, None, None]:
        """
        Convenience fixture: Mock premium subscription.

        Usage:
            def test_premium_features(premium_user, app):
                assert app.can_access_4k()
        """
        mtk_proxy.set_response(
            client_ip,
            "/api/subscription",
            {
                "plan": "premium",
                "status": "active",
                "features": ["4k", "hdr", "downloads", "offline"],
            },
        )
        yield
        try:
            mtk_proxy.clear_client(client_ip)
        except Exception:
            pass

    @pytest.fixture(scope="function")
    def trial_user(
        mtk_proxy: Any, client_ip: str
    ) -> Generator[None, None, None]:
        """
        Convenience fixture: Mock trial subscription.

        Usage:
            def test_trial_limits(trial_user, app):
                assert app.shows_upgrade_prompt()
        """
        mtk_proxy.set_response(
            client_ip,
            "/api/subscription",
            {
                "plan": "trial",
                "status": "active",
                "days_remaining": 7,
                "features": ["hd"],
            },
        )
        yield
        try:
            mtk_proxy.clear_client(client_ip)
        except Exception:
            pass

    @pytest.fixture(scope="function")
    def expired_user(
        mtk_proxy: Any, client_ip: str
    ) -> Generator[None, None, None]:
        """
        Convenience fixture: Mock expired subscription.

        Usage:
            def test_expired_shows_paywall(expired_user, app):
                assert app.shows_subscribe_modal()
        """
        mtk_proxy.set_response(
            client_ip,
            "/api/subscription",
            {
                "plan": "expired",
                "status": "expired",
                "can_watch": False,
            },
        )
        yield
        try:
            mtk_proxy.clear_client(client_ip)
        except Exception:
            pass

    @pytest.hookimpl(tryfirst=True, hookwrapper=True)
    def pytest_runtest_makereport(item: Any, call: Any) -> Generator[None, None, None]:
        """
        Hook to capture MTK state on test failure.

        Adds proxy logs, network state, and change summary to the test report
        when a test fails.
        """
        outcome = yield
        report = cast(Any, outcome).get_result()

        if report.when == "call" and report.failed:
            extra_info: list[str] = []

            # Check for tracked_mtk (has full change tracking)
            if "tracked_mtk" in item.funcargs:
                tracked = item.funcargs["tracked_mtk"]
                try:
                    summary = tracked.tracker.summary()
                    extra_info.append("=== Change Summary ===")
                    extra_info.append(f"Total changes: {summary['total_changes']}")
                    extra_info.append(f"Affected clients: {summary['affected_clients']}")
                    extra_info.append(f"By type: {summary['by_type']}")

                    changes = tracked.tracker.changes
                    if changes:
                        extra_info.append("\n=== Changes Made ===")
                        for change in changes[:20]:
                            extra_info.append(
                                f"  [{change.type.value}] {change.client_ip}: "
                                f"{change.details}"
                            )
                        if len(changes) > 20:
                            extra_info.append(f"  ... and {len(changes) - 20} more")
                except Exception:
                    pass

            # Check for regular mtk
            if "mtk" in item.funcargs:
                mtk_instance = item.funcargs["mtk"]
                client = item.funcargs.get("client_ip", "unknown")

                try:
                    network_cond = mtk_instance.network.get_condition(client)
                    if network_cond and network_cond.active:
                        extra_info.append(
                            f"Network: {network_cond.profile or 'custom'}"
                        )

                    try:
                        logs = mtk_instance.proxy.get_log(
                            client_ip=client, limit=10
                        )
                        if logs:
                            extra_info.append("Last 10 requests:")
                            for log in logs:
                                status = getattr(log, "response_status", "?")
                                extra_info.append(
                                    f"  {log.method} {log.path} -> {status}"
                                )
                    except Exception:
                        pass

                    try:
                        rules = mtk_instance.proxy.list_rules(client_ip=client)
                        if rules:
                            extra_info.append(f"Active proxy rules: {len(rules)}")
                    except Exception:
                        pass
                except Exception:
                    pass

            if extra_info:
                report.sections.append(
                    ("MTK State", "\n".join(extra_info))
                )

    def pytest_configure(config: Any) -> None:
        """Register custom markers."""
        config.addinivalue_line(
            "markers",
            "slow_network: Mark test as requiring slow network simulation",
        )
        config.addinivalue_line(
            "markers",
            "offline: Mark test as requiring offline simulation",
        )
        config.addinivalue_line(
            "markers",
            "premium: Mark test as requiring premium subscription mock",
        )
        config.addinivalue_line(
            "markers",
            "mtk: Mark test as requiring MTK test infrastructure",
        )


mtk_fixtures = "mtk_router_sdk.testing.pytest_plugin"
