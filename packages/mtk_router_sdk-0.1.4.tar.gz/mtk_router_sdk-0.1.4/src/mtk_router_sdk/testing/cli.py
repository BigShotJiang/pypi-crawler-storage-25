"""
CLI commands for testing features.

Commands:
    mtk network profile <client_ip> <profile>   - Apply network profile
    mtk network throttle <client_ip> --down X   - Throttle bandwidth
    mtk network clear <client_ip>               - Clear conditions
    mtk network list                            - List conditions

    mtk dns redirect <domain> [--client X]      - Redirect domain
    mtk dns clear [--client X]                  - Clear redirects
    mtk dns list                                - List redirects

    mtk profile apply <name> <client_ip>        - Apply profile
    mtk profile list                            - List profiles
    mtk profile export <client_ip> <name>       - Export current state

    mtk scenario run <name> <client_ip>         - Run scenario
    mtk scenario list                           - List scenarios

    mtk record start <client_ip> [--name X]     - Start recording
    mtk record stop <session_id>                - Stop recording
    mtk record replay <client_ip> <har_file>    - Replay recording
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def cmd_network(args: argparse.Namespace) -> int:
    """Handle network subcommands."""
    from mtk_router_sdk.testing.network import NETWORK_PROFILES, NetworkSimulator

    network = NetworkSimulator.from_env()

    if args.network_cmd == "profiles":
        print("Available network profiles:")
        print("-" * 60)
        for name, settings in NETWORK_PROFILES.items():
            print(f"  {name:15} {settings['download_kbps']:>8} Kbps down, "
                  f"{settings['latency_ms']:>4}ms latency, "
                  f"{settings['packet_loss_percent']}% loss")
        return 0

    elif args.network_cmd == "apply":
        if args.profile:
            condition = network.apply_profile(args.client_ip, args.profile)
            print(f"Applied profile '{args.profile}' to {args.client_ip}")
        else:
            condition = network.throttle(
                args.client_ip,
                download_kbps=args.download,
                upload_kbps=args.upload,
            )
            print(f"Applied throttling to {args.client_ip}")

        if args.json_output:
            print(json.dumps({
                "client_ip": condition.client_ip,
                "profile": condition.profile,
                "download_kbps": condition.download_kbps,
                "upload_kbps": condition.upload_kbps,
            }))
        return 0

    elif args.network_cmd == "clear":
        if args.client_ip:
            network.clear(args.client_ip)
            print(f"Cleared network conditions for {args.client_ip}")
        else:
            network.clear_all()
            print("Cleared all network conditions")
        return 0

    elif args.network_cmd == "list":
        conditions = network.list_conditions()
        if not conditions:
            print("No active network conditions")
            return 0

        if args.json_output:
            print(json.dumps([{
                "client_ip": c.client_ip,
                "profile": c.profile,
                "download_kbps": c.download_kbps,
            } for c in conditions]))
        else:
            print("Active network conditions:")
            for c in conditions:
                profile = c.profile or "custom"
                print(f"  {c.client_ip}: {profile}")
        return 0

    return 1


def cmd_dns(args: argparse.Namespace) -> int:
    """Handle dns subcommands."""
    from mtk_router_sdk.testing.dns import DnsOverride

    dns = DnsOverride.from_env()

    if args.dns_cmd == "redirect":
        if args.to_proxy:
            redirect = dns.redirect(args.domain, args.client_ip, args.ttl)
        else:
            redirect = dns.redirect_to_ip(
                args.domain, args.target_ip, args.client_ip, args.ttl
            )
        print(f"Redirected {args.domain} -> {redirect.target_ip}")
        return 0

    elif args.dns_cmd == "clear":
        if args.client_ip:
            dns.clear(args.client_ip)
            print(f"Cleared DNS redirects for {args.client_ip}")
        else:
            dns.clear_all()
            print("Cleared all DNS redirects")
        return 0

    elif args.dns_cmd == "list":
        redirects = dns.list_redirects(args.client_ip)
        if not redirects:
            print("No active DNS redirects")
            return 0

        if args.json_output:
            print(json.dumps([{
                "domain": r.domain,
                "target_ip": r.target_ip,
                "client_ip": r.client_ip,
            } for r in redirects]))
        else:
            print("Active DNS redirects:")
            for r in redirects:
                client = r.client_ip or "all"
                print(f"  {r.domain} -> {r.target_ip} ({client})")
        return 0

    elif args.dns_cmd == "flush":
        dns.flush_cache()
        print("Flushed DNS cache")
        return 0

    return 1


def cmd_profile(args: argparse.Namespace) -> int:
    """Handle profile subcommands."""
    from mtk_router_sdk.testing.profiles import ProfileManager

    profiles = ProfileManager.from_env()

    if args.profile_cmd == "apply":
        profile = profiles.apply(args.name, args.client_ip)
        print(f"Applied profile '{profile.name}' to {args.client_ip}")
        return 0

    elif args.profile_cmd == "list":
        available = profiles.list_profiles()
        if not available:
            print("No profiles found")
            return 0

        print("Available profiles:")
        for name in available:
            print(f"  {name}")
        return 0

    elif args.profile_cmd == "export":
        path = profiles.export(
            args.client_ip,
            args.name,
            Path(args.output) if args.output else None,
        )
        print(f"Exported profile to {path}")
        return 0

    elif args.profile_cmd == "clear":
        profiles.clear(args.client_ip)
        print(f"Cleared profile state for {args.client_ip}")
        return 0

    return 1


def cmd_scenario(args: argparse.Namespace) -> int:
    """Handle scenario subcommands."""
    from mtk_router_sdk.testing.scenarios import ScenarioRunner

    runner = ScenarioRunner.from_env()

    if args.scenario_cmd == "run":
        result = runner.run(args.name, args.client_ip)

        if args.json_output:
            print(json.dumps({
                "passed": result.passed,
                "duration_seconds": result.duration_seconds,
                "passed_count": result.passed_count,
                "failed_count": result.failed_count,
                "failed_step": result.failed_step,
                "error": result.error,
            }))
        else:
            status = "PASSED" if result.passed else "FAILED"
            print(f"Scenario '{args.name}': {status}")
            print(f"  Duration: {result.duration_seconds:.2f}s")
            print(f"  Steps: {result.passed_count} passed, {result.failed_count} failed")
            if result.failed_step:
                print(f"  Failed at: {result.failed_step}")
                if result.error:
                    print(f"  Error: {result.error}")

        return 0 if result.passed else 1

    elif args.scenario_cmd == "list":
        scenarios = runner.list_scenarios()
        if not scenarios:
            print("No scenarios found")
            return 0

        print("Available scenarios:")
        for s in scenarios:
            tags = ", ".join(s.tags) if s.tags else ""
            print(f"  {s.name:20} {s.description[:40]} [{tags}]")
        return 0

    return 1


def cmd_record(args: argparse.Namespace) -> int:
    """Handle record subcommands."""
    from mtk_router_sdk.testing.recording import SessionRecorder

    recorder = SessionRecorder.from_env()

    if args.record_cmd == "start":
        filter_hosts = args.filter.split(",") if args.filter else None
        session_id = recorder.start(
            args.client_ip,
            name=args.name,
            filter_hosts=filter_hosts,
        )
        print(f"Started recording session: {session_id}")
        print(f"Run 'mtk record stop {session_id}' when done")
        return 0

    elif args.record_cmd == "stop":
        try:
            path = recorder.stop(
                args.session_id,
                Path(args.output) if args.output else None,
            )
            print(f"Saved recording to {path}")
            return 0
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    elif args.record_cmd == "replay":
        rules = recorder.replay(
            args.client_ip,
            args.har_file,
            match_mode=args.match_mode,
        )
        print(f"Created {rules} proxy rules from {args.har_file}")
        return 0

    elif args.record_cmd == "list":
        sessions = recorder.list_sessions()
        if sessions:
            print("Active recording sessions:")
            for s in sessions:
                print(f"  {s.id}: {s.client_ip} ({s.name})")
        else:
            print("No active recording sessions")

        recordings = recorder.list_recordings()
        if recordings:
            print("\nSaved recordings:")
            for name in recordings:
                print(f"  {name}.har")
        return 0

    elif args.record_cmd == "compare":
        diff = recorder.compare(
            args.current,
            args.golden,
            ignore_fields=args.ignore.split(",") if args.ignore else None,
        )
        print(diff.summary())
        return 0 if not diff.has_changes else 1

    return 1


def add_testing_parsers(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add testing subcommand parsers."""

    network_parser = subparsers.add_parser(
        "network",
        help="Network condition simulation",
    )
    network_sub = network_parser.add_subparsers(dest="network_cmd")

    network_sub.add_parser("profiles", help="List available profiles")

    apply_p = network_sub.add_parser("apply", help="Apply network condition")
    apply_p.add_argument("client_ip", help="Target client IP")
    apply_p.add_argument("--profile", "-p", help="Profile name (3g, 4g, wifi-poor)")
    apply_p.add_argument("--download", "-d", type=int, help="Download Kbps")
    apply_p.add_argument("--upload", "-u", type=int, help="Upload Kbps")
    apply_p.add_argument("--json", dest="json_output", action="store_true")

    clear_p = network_sub.add_parser("clear", help="Clear network conditions")
    clear_p.add_argument("client_ip", nargs="?", help="Client IP (omit for all)")

    list_p = network_sub.add_parser("list", help="List active conditions")
    list_p.add_argument("--json", dest="json_output", action="store_true")

    dns_parser = subparsers.add_parser("dns", help="DNS override automation")
    dns_sub = dns_parser.add_subparsers(dest="dns_cmd")

    redir_p = dns_sub.add_parser("redirect", help="Add DNS redirect")
    redir_p.add_argument("domain", help="Domain to redirect")
    redir_p.add_argument("--client", dest="client_ip", help="Client IP")
    redir_p.add_argument("--to-proxy", action="store_true", help="Redirect to proxy")
    redir_p.add_argument("--target-ip", help="Target IP address")
    redir_p.add_argument("--ttl", type=int, default=60, help="TTL seconds")

    dns_clear = dns_sub.add_parser("clear", help="Clear DNS redirects")
    dns_clear.add_argument("--client", dest="client_ip", help="Client IP")

    dns_list = dns_sub.add_parser("list", help="List DNS redirects")
    dns_list.add_argument("--client", dest="client_ip", help="Filter by client")
    dns_list.add_argument("--json", dest="json_output", action="store_true")

    dns_sub.add_parser("flush", help="Flush DNS cache")

    profile_parser = subparsers.add_parser("profile", help="Configuration profiles")
    profile_sub = profile_parser.add_subparsers(dest="profile_cmd")

    prof_apply = profile_sub.add_parser("apply", help="Apply profile")
    prof_apply.add_argument("name", help="Profile name or path")
    prof_apply.add_argument("client_ip", help="Target client IP")

    profile_sub.add_parser("list", help="List available profiles")

    prof_export = profile_sub.add_parser("export", help="Export current state")
    prof_export.add_argument("client_ip", help="Client IP to export")
    prof_export.add_argument("name", help="Profile name")
    prof_export.add_argument("--output", "-o", help="Output file path")

    prof_clear = profile_sub.add_parser("clear", help="Clear profile state")
    prof_clear.add_argument("client_ip", help="Client IP")

    scenario_parser = subparsers.add_parser("scenario", help="Test scenarios")
    scenario_sub = scenario_parser.add_subparsers(dest="scenario_cmd")

    sc_run = scenario_sub.add_parser("run", help="Run scenario")
    sc_run.add_argument("name", help="Scenario name or path")
    sc_run.add_argument("client_ip", help="Target client IP")
    sc_run.add_argument("--json", dest="json_output", action="store_true")

    scenario_sub.add_parser("list", help="List available scenarios")

    record_parser = subparsers.add_parser("record", help="Traffic recording")
    record_sub = record_parser.add_subparsers(dest="record_cmd")

    rec_start = record_sub.add_parser("start", help="Start recording")
    rec_start.add_argument("client_ip", help="Client IP to record")
    rec_start.add_argument("--name", "-n", help="Session name")
    rec_start.add_argument("--filter", "-f", help="Filter hosts (comma-separated)")

    rec_stop = record_sub.add_parser("stop", help="Stop recording")
    rec_stop.add_argument("session_id", help="Session ID")
    rec_stop.add_argument("--output", "-o", help="Output file path")

    rec_replay = record_sub.add_parser("replay", help="Replay recording")
    rec_replay.add_argument("client_ip", help="Client IP")
    rec_replay.add_argument("har_file", help="HAR file path")
    rec_replay.add_argument("--match-mode", default="path",
                            choices=["path", "url", "method_path"])

    record_sub.add_parser("list", help="List sessions and recordings")

    rec_compare = record_sub.add_parser("compare", help="Compare HAR files")
    rec_compare.add_argument("current", help="Current HAR file")
    rec_compare.add_argument("golden", help="Golden HAR file")
    rec_compare.add_argument("--ignore", help="Ignore fields (comma-separated)")
