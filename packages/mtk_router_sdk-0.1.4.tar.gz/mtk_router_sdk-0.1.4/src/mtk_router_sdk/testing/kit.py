"""
MtkTestKit — Unified interface for all testing capabilities.

Usage:
    from mtk_router_sdk.testing import MtkTestKit

    # From environment variables
    kit = MtkTestKit.from_env()

    # From site config
    kit = MtkTestKit.from_site("site.json")

    # Access all features
    kit.network.throttle(ip, download_kbps=500)
    kit.dns.redirect("api.example.com", client_ip=ip)
    kit.proxy.set_response(ip, "/api/test", {"ok": True})
    kit.profiles.apply("premium-user", ip)
    kit.scenarios.run("geo-block", ip)
    kit.recorder.start(ip)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mtk_router_sdk.client import RouterClient
    from mtk_router_sdk.config import SiteConfig

from mtk_router_sdk.testing.dns import DnsOverride
from mtk_router_sdk.testing.network import NetworkSimulator
from mtk_router_sdk.testing.profiles import ProfileManager
from mtk_router_sdk.testing.recording import SessionRecorder
from mtk_router_sdk.testing.scenarios import ScenarioRunner


@dataclass
class MtkTestKit:
    """
    Unified testing toolkit — one object to access all features.

    Attributes:
        network: Network condition simulation (throttle, latency, packet loss)
        dns: DNS override automation (redirect domains to proxy)
        proxy: API proxy (mock responses, inject errors)
        profiles: Configuration profiles (saved test states)
        scenarios: Pre-built test scenarios (one-click flows)
        recorder: Traffic recording & replay (HAR capture)
    """

    _client: RouterClient | None = field(default=None, repr=False)
    _site: SiteConfig | None = field(default=None, repr=False)
    _base_url: str | None = field(default=None, repr=False)
    _token: str | None = field(default=None, repr=False)
    _profiles_dir: Path | None = field(default=None, repr=False)
    _scenarios_dir: Path | None = field(default=None, repr=False)
    _recordings_dir: Path | None = field(default=None, repr=False)

    # Lazy-loaded components
    _network: NetworkSimulator | None = field(default=None, repr=False)
    _dns: DnsOverride | None = field(default=None, repr=False)
    _proxy: Any = field(default=None, repr=False)
    _profiles: ProfileManager | None = field(default=None, repr=False)
    _scenarios: ScenarioRunner | None = field(default=None, repr=False)
    _recorder: SessionRecorder | None = field(default=None, repr=False)

    @classmethod
    def from_env(cls) -> MtkTestKit:
        """
        Create test kit from environment variables.

        Environment:
            MTK_HOST, MTK_USER, MTK_PASSWORD: Router connection
            (Dashboard ``mtk dashboard start`` can also apply these from
            ``~/.mtk/dashboard-workspace.json`` when you use the Setup wizard.)
            MTK_SERVICE_URL: mtk-serve base URL (default: http://127.0.0.1:8765)
            MTK_PROXY_LOCAL_ONLY: if ``1``/``true``, omit remote URL (in-process proxy only)
            MTK_SERVICE_TOKEN: API authentication token
            MTK_PROFILES_DIR: Directory for test profiles
            MTK_SCENARIOS_DIR: Directory for test scenarios
            MTK_RECORDINGS_DIR: Directory for HAR recordings
        """
        from mtk_router_sdk.client import RouterClient
        from mtk_router_sdk.proxy.sdk import _service_base_url_from_env

        base_url = _service_base_url_from_env()
        token = os.environ.get("MTK_SERVICE_TOKEN")

        profiles_dir = os.environ.get("MTK_PROFILES_DIR")
        scenarios_dir = os.environ.get("MTK_SCENARIOS_DIR")
        recordings_dir = os.environ.get("MTK_RECORDINGS_DIR")

        client: RouterClient | None = None
        try:
            client = RouterClient.from_env()
        except Exception:
            pass

        return cls(
            _client=client,
            _base_url=base_url,
            _token=token,
            _profiles_dir=Path(profiles_dir) if profiles_dir else None,
            _scenarios_dir=Path(scenarios_dir) if scenarios_dir else None,
            _recordings_dir=Path(recordings_dir) if recordings_dir else None,
        )

    @classmethod
    def from_site(cls, site_path: str | Path) -> MtkTestKit:
        """
        Create test kit from site configuration file.

        Args:
            site_path: Path to site.json configuration file
        """
        from mtk_router_sdk.client import RouterClient
        from mtk_router_sdk.config import load_site_config_from_path
        from mtk_router_sdk.proxy.sdk import _service_base_url_from_env

        site_path = Path(site_path)
        site = load_site_config_from_path(site_path)

        base_url = _service_base_url_from_env()
        token = os.environ.get("MTK_SERVICE_TOKEN")

        client: RouterClient | None = None
        try:
            client = RouterClient.from_env()
        except Exception:
            pass

        profiles_dir = site_path.parent / "profiles"
        scenarios_dir = site_path.parent / "scenarios"
        recordings_dir = site_path.parent / "recordings"

        return cls(
            _client=client,
            _site=site,
            _base_url=base_url,
            _token=token,
            _profiles_dir=profiles_dir if profiles_dir.exists() else None,
            _scenarios_dir=scenarios_dir if scenarios_dir.exists() else None,
            _recordings_dir=recordings_dir if recordings_dir.exists() else None,
        )

    @property
    def network(self) -> NetworkSimulator:
        """Network condition simulation (throttle, latency, packet loss)."""
        if self._network is None:
            self._network = NetworkSimulator(
                client=self._client,
                base_url=self._base_url,
                token=self._token,
            )
        return self._network

    @property
    def dns(self) -> DnsOverride:
        """DNS override automation (redirect domains to proxy)."""
        if self._dns is None:
            self._dns = DnsOverride(
                client=self._client,
                base_url=self._base_url,
                token=self._token,
            )
        return self._dns

    @property
    def proxy(self) -> Any:
        """API proxy (mock responses, inject errors)."""
        if self._proxy is None:
            from mtk_router_sdk.proxy import ProxyManager

            self._proxy = ProxyManager(
                base_url=self._base_url,
                token=self._token,
            )
        return self._proxy

    @property
    def profiles(self) -> ProfileManager:
        """Configuration profiles (saved test states)."""
        if self._profiles is None:
            self._profiles = ProfileManager(
                kit=self,
                profiles_dir=self._profiles_dir,
            )
        return self._profiles

    @property
    def scenarios(self) -> ScenarioRunner:
        """Pre-built test scenarios (one-click flows)."""
        if self._scenarios is None:
            self._scenarios = ScenarioRunner(
                kit=self,
                scenarios_dir=self._scenarios_dir,
            )
        return self._scenarios

    @property
    def recorder(self) -> SessionRecorder:
        """Traffic recording & replay (HAR capture)."""
        if self._recorder is None:
            self._recorder = SessionRecorder(
                proxy=self.proxy,
                recordings_dir=self._recordings_dir,
            )
        return self._recorder

    def cleanup(self, client_ip: str) -> None:
        """
        Clean up all test state for a client.

        Removes proxy rules, DNS overrides, network conditions.
        Call this in test teardown.
        """
        if self._proxy is not None:
            try:
                self._proxy.clear_client(client_ip)
            except Exception:
                pass

        if self._dns is not None:
            try:
                self._dns.clear(client_ip)
            except Exception:
                pass

        if self._network is not None:
            try:
                self._network.clear(client_ip)
            except Exception:
                pass

    def cleanup_all(self) -> None:
        """Clean up all test state for all clients."""
        if self._proxy is not None:
            try:
                self._proxy.clear_all()
            except Exception:
                pass

        if self._dns is not None:
            try:
                self._dns.clear_all()
            except Exception:
                pass

        if self._network is not None:
            try:
                self._network.clear_all()
            except Exception:
                pass

    def close(self) -> None:
        """Close all connections and clean up resources."""
        if self._proxy is not None:
            try:
                self._proxy.close()
            except Exception:
                pass

        if self._recorder is not None:
            try:
                self._recorder.close()
            except Exception:
                pass
