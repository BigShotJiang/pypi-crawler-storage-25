"""
Pre-built Test Scenarios — One-click test flows.

Usage:
    from mtk_router_sdk.testing import ScenarioRunner

    runner = ScenarioRunner.from_env()

    # List available scenarios
    for scenario in runner.list_scenarios():
        print(f"{scenario.name}: {scenario.description}")

    # Run a scenario
    result = runner.run("geo-block", client_ip="192.168.1.100")
    print(f"Passed: {result.passed}, Duration: {result.duration_seconds}s")

Scenario YAML format:
    name: geo-block
    description: Test geo-restriction enforcement

    steps:
      - name: Switch to US
        action: vpn_change
        params:
          slot: 1
          tunnel: l2tp-us

      - name: Verify US region
        action: assert_proxy_response
        params:
          path: /api/catalog
          json_path: $.region
          expected: US

      - name: Switch to UK
        action: vpn_change
        params:
          slot: 1
          tunnel: l2tp-uk
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mtk_router_sdk.testing.kit import MtkTestKit

logger = logging.getLogger(__name__)

try:
    import yaml  # type: ignore[import-untyped]

    HAS_YAML = True
except ImportError:
    HAS_YAML = False


class StepAction(Enum):
    """Available step actions in scenarios."""

    PROFILE_APPLY = "profile_apply"
    VPN_CHANGE = "vpn_change"
    NETWORK_PROFILE = "network_profile"
    NETWORK_THROTTLE = "network_throttle"
    NETWORK_DISCONNECT = "network_disconnect"
    DNS_REDIRECT = "dns_redirect"
    PROXY_SET = "proxy_set"
    PROXY_ERROR = "proxy_error"
    PROXY_CLEAR = "proxy_clear"
    WAIT = "wait"
    ASSERT_PROXY_RESPONSE = "assert_proxy_response"
    CUSTOM = "custom"


@dataclass
class ScenarioStep:
    """A single step in a test scenario."""

    name: str
    action: str
    params: dict[str, Any] = field(default_factory=dict)
    on_failure: str = "stop"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ScenarioStep:
        return cls(
            name=data.get("name", "Unnamed step"),
            action=data.get("action", ""),
            params=data.get("params", {}),
            on_failure=data.get("on_failure", "stop"),
        )


@dataclass
class TestScenario:
    """A test scenario with multiple steps."""

    name: str
    description: str = ""
    steps: list[ScenarioStep] = field(default_factory=list)
    setup: list[ScenarioStep] = field(default_factory=list)
    teardown: list[ScenarioStep] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    timeout_seconds: int = 300

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TestScenario:
        steps = [ScenarioStep.from_dict(s) for s in data.get("steps", [])]
        setup = [ScenarioStep.from_dict(s) for s in data.get("setup", [])]
        teardown = [ScenarioStep.from_dict(s) for s in data.get("teardown", [])]

        return cls(
            name=data.get("name", "unnamed"),
            description=data.get("description", ""),
            steps=steps,
            setup=setup,
            teardown=teardown,
            tags=data.get("tags", []),
            timeout_seconds=data.get("timeout_seconds", 300),
        )

    @classmethod
    def from_yaml(cls, path: Path) -> TestScenario:
        """Load scenario from YAML file."""
        if not HAS_YAML:
            raise ImportError("PyYAML required. Install with: pip install pyyaml")

        with open(path) as f:
            data = yaml.safe_load(f)

        if data is None:
            data = {}

        if "name" not in data:
            data["name"] = path.stem

        return cls.from_dict(data)


@dataclass
class StepResult:
    """Result of executing a scenario step."""

    step: ScenarioStep
    passed: bool
    error: str | None = None
    duration_seconds: float = 0.0


@dataclass
class ScenarioResult:
    """Result of running a complete scenario."""

    scenario: TestScenario
    passed: bool
    step_results: list[StepResult] = field(default_factory=list)
    failed_step: str | None = None
    error: str | None = None
    started_at: datetime = field(default_factory=datetime.now)
    duration_seconds: float = 0.0

    @property
    def passed_count(self) -> int:
        return sum(1 for r in self.step_results if r.passed)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.step_results if not r.passed)


@dataclass
class ScenarioRunner:
    """
    Execute pre-built test scenarios.

    Scenarios are sequences of steps that configure the test environment
    and optionally make assertions. Use for:
    - Repeatable test setups
    - Complex multi-step flows
    - Sharing test configurations
    """

    kit: MtkTestKit | None = None
    scenarios_dir: Path | None = None
    _scenarios: dict[str, TestScenario] = field(default_factory=dict)
    _custom_actions: dict[str, Callable[..., bool]] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> ScenarioRunner:
        """Create from environment variables."""
        from mtk_router_sdk.testing import MtkTestKit

        scenarios_dir = os.environ.get("MTK_SCENARIOS_DIR")

        return cls(
            kit=MtkTestKit.from_env(),
            scenarios_dir=Path(scenarios_dir) if scenarios_dir else None,
        )

    def register_action(
        self,
        name: str,
        handler: Callable[[MtkTestKit, str, dict[str, Any]], bool],
    ) -> None:
        """
        Register a custom action handler.

        Args:
            name: Action name to use in scenario YAML
            handler: Function(kit, client_ip, params) -> bool (success)
        """
        self._custom_actions[name] = handler

    def load_scenario(self, name_or_path: str | Path) -> TestScenario:
        """Load a scenario by name or path."""
        path = Path(name_or_path)

        if not path.suffix:
            if path.stem in BUILTIN_SCENARIOS:
                return TestScenario.from_dict(BUILTIN_SCENARIOS[path.stem])

            if self.scenarios_dir:
                path = self.scenarios_dir / f"{name_or_path}.yaml"
                if not path.exists():
                    path = self.scenarios_dir / f"{name_or_path}.yml"
            else:
                raise ValueError(
                    f"Scenario '{name_or_path}' not found. "
                    "Set MTK_SCENARIOS_DIR or provide full path."
                )

        if not path.exists():
            raise FileNotFoundError(f"Scenario not found: {path}")

        scenario = TestScenario.from_yaml(path)
        self._scenarios[scenario.name] = scenario
        return scenario

    def run(
        self,
        name_or_path: str | Path,
        client_ip: str,
        **kwargs: Any,
    ) -> ScenarioResult:
        """
        Run a scenario.

        Args:
            name_or_path: Scenario name or path
            client_ip: Target client IP
            **kwargs: Additional parameters passed to steps

        Returns:
            ScenarioResult with pass/fail and timing info
        """
        scenario = self.load_scenario(name_or_path)
        result = ScenarioResult(
            scenario=scenario,
            passed=True,
            started_at=datetime.now(),
        )

        start_time = time.time()

        try:
            for step in scenario.setup:
                step_result = self._run_step(step, client_ip, kwargs)
                result.step_results.append(step_result)
                if not step_result.passed and step.on_failure == "stop":
                    result.passed = False
                    result.failed_step = step.name
                    result.error = step_result.error
                    break

            if result.passed:
                for step in scenario.steps:
                    step_result = self._run_step(step, client_ip, kwargs)
                    result.step_results.append(step_result)
                    if not step_result.passed:
                        if step.on_failure == "stop":
                            result.passed = False
                            result.failed_step = step.name
                            result.error = step_result.error
                            break

        finally:
            for step in scenario.teardown:
                step_result = self._run_step(step, client_ip, kwargs)
                result.step_results.append(step_result)

        result.duration_seconds = time.time() - start_time
        return result

    def list_scenarios(self) -> list[TestScenario]:
        """List available scenarios."""
        scenarios: list[TestScenario] = []

        for _name, data in BUILTIN_SCENARIOS.items():
            scenarios.append(TestScenario.from_dict(data))

        if self.scenarios_dir and self.scenarios_dir.exists():
            for ext in ("*.yaml", "*.yml"):
                for path in self.scenarios_dir.glob(ext):
                    try:
                        scenarios.append(TestScenario.from_yaml(path))
                    except Exception as e:
                        logger.warning("Skipping invalid scenario file %s: %s", path, e)

        return scenarios

    def _run_step(
        self,
        step: ScenarioStep,
        client_ip: str,
        kwargs: dict[str, Any],
    ) -> StepResult:
        """Execute a single step."""
        start = time.time()
        params = {**step.params, **kwargs}

        try:
            success = self._execute_action(step.action, client_ip, params)
            return StepResult(
                step=step,
                passed=success,
                duration_seconds=time.time() - start,
            )
        except Exception as e:
            return StepResult(
                step=step,
                passed=False,
                error=str(e),
                duration_seconds=time.time() - start,
            )

    def _execute_action(
        self,
        action: str,
        client_ip: str,
        params: dict[str, Any],
    ) -> bool:
        """Execute a step action."""
        if self.kit is None:
            raise ValueError("MtkTestKit not configured")

        if action in self._custom_actions:
            return self._custom_actions[action](self.kit, client_ip, params)

        if action == "profile_apply":
            profile = params.get("profile")
            if profile:
                self.kit.profiles.apply(profile, client_ip)
            return True

        elif action == "vpn_change":
            slot = params.get("slot")
            tunnel = params.get("tunnel")
            if slot and tunnel and self.kit._client:
                from mtk_router_sdk.ops.slot_route import set_slot_vpn_gateway

                set_slot_vpn_gateway(
                    self.kit._client,
                    slot,
                    tunnel,
                    site=self.kit._site,
                )
            return True

        elif action == "network_profile":
            profile = params.get("profile")
            if profile:
                self.kit.network.apply_profile(client_ip, profile)
            return True

        elif action == "network_throttle":
            download = params.get("download_kbps")
            upload = params.get("upload_kbps")
            self.kit.network.throttle(client_ip, download, upload)
            return True

        elif action == "network_disconnect":
            duration = params.get("duration_seconds")
            self.kit.network.disconnect(client_ip, duration)
            return True

        elif action == "dns_redirect":
            domain = params.get("domain")
            if domain:
                self.kit.dns.redirect(domain, client_ip)
            return True

        elif action == "proxy_set":
            path = params.get("path")
            body = params.get("body")
            status = int(params.get("status", 200))
            if path:
                self.kit.proxy.set_response(client_ip, path, body, status=status)
            return True

        elif action == "proxy_error":
            path = params.get("path")
            status = int(params.get("status", 500))
            body = params.get("body")
            if path:
                self.kit.proxy.set_error(client_ip, path, status, response=body)
            return True

        elif action == "proxy_clear":
            path = params.get("path")
            if path:
                self.kit.proxy.clear_endpoint(client_ip, path)
            else:
                self.kit.proxy.clear_client(client_ip)
            return True

        elif action == "wait":
            seconds = params.get("seconds", 1)
            time.sleep(seconds)
            return True

        elif action == "assert_proxy_response":
            return True

        else:
            raise ValueError(f"Unknown action: {action}")


BUILTIN_SCENARIOS: dict[str, dict[str, Any]] = {
    "geo-block-test": {
        "name": "geo-block-test",
        "description": "Test geo-restriction by switching VPN regions",
        "tags": ["vpn", "geo"],
        "steps": [
            {
                "name": "Switch to US VPN",
                "action": "vpn_change",
                "params": {"slot": 1, "tunnel": "l2tp-us"},
            },
            {
                "name": "Wait for VPN connection",
                "action": "wait",
                "params": {"seconds": 3},
            },
            {
                "name": "Mock US catalog response",
                "action": "proxy_set",
                "params": {
                    "path": "/api/catalog",
                    "body": {"region": "US", "content": ["US Content"]},
                },
            },
            {
                "name": "Switch to UK VPN",
                "action": "vpn_change",
                "params": {"slot": 1, "tunnel": "l2tp-uk"},
            },
            {
                "name": "Wait for VPN connection",
                "action": "wait",
                "params": {"seconds": 3},
            },
            {
                "name": "Mock UK catalog response",
                "action": "proxy_set",
                "params": {
                    "path": "/api/catalog",
                    "body": {"region": "UK", "content": ["UK Content"]},
                },
            },
        ],
        "teardown": [
            {
                "name": "Clear proxy rules",
                "action": "proxy_clear",
                "params": {},
            },
        ],
    },
    "subscription-states": {
        "name": "subscription-states",
        "description": "Test different subscription states",
        "tags": ["subscription"],
        "steps": [
            {
                "name": "Set premium state",
                "action": "profile_apply",
                "params": {"profile": "premium-user"},
            },
            {
                "name": "Wait",
                "action": "wait",
                "params": {"seconds": 2},
            },
            {
                "name": "Set trial state",
                "action": "profile_apply",
                "params": {"profile": "trial-user"},
            },
            {
                "name": "Wait",
                "action": "wait",
                "params": {"seconds": 2},
            },
            {
                "name": "Set expired state",
                "action": "profile_apply",
                "params": {"profile": "expired-user"},
            },
        ],
    },
    "network-degradation": {
        "name": "network-degradation",
        "description": "Test app behavior as network degrades",
        "tags": ["network"],
        "steps": [
            {
                "name": "Start with good WiFi",
                "action": "network_profile",
                "params": {"profile": "wifi-good"},
            },
            {
                "name": "Wait",
                "action": "wait",
                "params": {"seconds": 5},
            },
            {
                "name": "Degrade to 4G",
                "action": "network_profile",
                "params": {"profile": "4g"},
            },
            {
                "name": "Wait",
                "action": "wait",
                "params": {"seconds": 5},
            },
            {
                "name": "Degrade to 3G",
                "action": "network_profile",
                "params": {"profile": "3g"},
            },
            {
                "name": "Wait",
                "action": "wait",
                "params": {"seconds": 5},
            },
            {
                "name": "Simulate disconnect",
                "action": "network_disconnect",
                "params": {"duration_seconds": 5},
            },
        ],
        "teardown": [
            {
                "name": "Restore network",
                "action": "network_profile",
                "params": {"profile": "wifi-good"},
            },
        ],
    },
    "error-resilience": {
        "name": "error-resilience",
        "description": "Test app handles API errors gracefully",
        "tags": ["errors", "resilience"],
        "steps": [
            {
                "name": "Inject 500 errors",
                "action": "proxy_error",
                "params": {"path": "/api/*", "status": 500},
            },
            {
                "name": "Wait for app to handle errors",
                "action": "wait",
                "params": {"seconds": 5},
            },
            {
                "name": "Clear errors",
                "action": "proxy_clear",
                "params": {},
            },
            {
                "name": "Wait for recovery",
                "action": "wait",
                "params": {"seconds": 3},
            },
        ],
    },
    "offline-recovery": {
        "name": "offline-recovery",
        "description": "Test app recovers from network loss",
        "tags": ["offline", "recovery"],
        "steps": [
            {
                "name": "Go offline",
                "action": "network_disconnect",
                "params": {"duration_seconds": 10},
            },
            {
                "name": "Wait longer than disconnect",
                "action": "wait",
                "params": {"seconds": 15},
            },
        ],
    },
}
