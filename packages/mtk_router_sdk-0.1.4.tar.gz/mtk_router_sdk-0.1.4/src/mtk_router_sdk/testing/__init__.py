"""
MTK Testing Framework — Professional testing toolkit for streaming apps.

This package provides everything needed to test applications through MikroTik:
- Network condition simulation (throttling, latency, packet loss)
- DNS override automation (zero-config device interception)
- Configuration profiles (saved test states)
- Pre-built test scenarios (one-click test flows)
- pytest integration (fixtures and hooks)
- Traffic recording & replay (HAR-based capture)

Quick Start:
    # In your test file
    from mtk_router_sdk.testing import MtkTestKit

    kit = MtkTestKit.from_env()
    kit.network.throttle("192.168.1.100", download_kbps=2000)
    kit.proxy.set_response("192.168.1.100", "/api/test", {"ok": True})

pytest Integration:
    # In conftest.py
    pytest_plugins = ["mtk_router_sdk.testing.pytest_plugin"]

    # In test file - fixtures auto-injected
    def test_slow_network(mtk, client_ip):
        mtk.network.apply_profile(client_ip, "3G")
        # ... test code ...
"""

from mtk_router_sdk.testing.dns import DnsOverride
from mtk_router_sdk.testing.kit import MtkTestKit
from mtk_router_sdk.testing.network import NetworkProfile, NetworkSimulator
from mtk_router_sdk.testing.profiles import ProfileManager, TestProfile
from mtk_router_sdk.testing.recording import HarFile, SessionRecorder
from mtk_router_sdk.testing.scenarios import ScenarioRunner, TestScenario
from mtk_router_sdk.testing.tracker import (
    Change,
    ChangeTracker,
    ChangeType,
    TrackedMtkTestKit,
)

__all__ = [
    # Main test kits
    "MtkTestKit",
    "TrackedMtkTestKit",
    # Change tracking
    "ChangeTracker",
    "Change",
    "ChangeType",
    # Components
    "NetworkSimulator",
    "NetworkProfile",
    "DnsOverride",
    "ProfileManager",
    "TestProfile",
    "ScenarioRunner",
    "TestScenario",
    "SessionRecorder",
    "HarFile",
]
