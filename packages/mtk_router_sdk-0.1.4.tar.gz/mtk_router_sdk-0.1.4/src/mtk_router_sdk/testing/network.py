"""
Network Condition Simulation — Throttle, latency, packet loss per client.

Usage:
    from mtk_router_sdk.testing import NetworkSimulator

    network = NetworkSimulator.from_env()

    # Apply throttling
    network.throttle("192.168.1.100", download_kbps=2000, upload_kbps=500)

    # Add latency
    network.latency("192.168.1.100", delay_ms=200)

    # Add packet loss
    network.packet_loss("192.168.1.100", percent=5)

    # Use preset profile
    network.apply_profile("192.168.1.100", "3G")

    # Clear all conditions
    network.clear("192.168.1.100")

Implementation uses MikroTik (SSH) when ``RouterClient`` is available, or
mtk-serve HTTP (``MTK_SERVICE_URL``) when SSH is not configured.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mtk_router_sdk.client import RouterClient


class NetworkProfile(Enum):
    """Pre-defined network condition profiles."""

    WIFI_EXCELLENT = "wifi-excellent"
    WIFI_GOOD = "wifi-good"
    WIFI_POOR = "wifi-poor"
    LTE_5G = "5g"
    LTE_4G = "4g"
    LTE_4G_POOR = "4g-poor"
    MOBILE_3G = "3g"
    MOBILE_2G = "2g"
    EDGE = "edge"
    OFFLINE = "offline"


NETWORK_PROFILES: dict[str, dict[str, Any]] = {
    "wifi-excellent": {
        "download_kbps": 100_000,
        "upload_kbps": 50_000,
        "latency_ms": 5,
        "jitter_ms": 2,
        "packet_loss_percent": 0,
    },
    "wifi-good": {
        "download_kbps": 50_000,
        "upload_kbps": 10_000,
        "latency_ms": 20,
        "jitter_ms": 5,
        "packet_loss_percent": 0,
    },
    "wifi-poor": {
        "download_kbps": 5_000,
        "upload_kbps": 1_000,
        "latency_ms": 100,
        "jitter_ms": 30,
        "packet_loss_percent": 2,
    },
    "5g": {
        "download_kbps": 100_000,
        "upload_kbps": 50_000,
        "latency_ms": 10,
        "jitter_ms": 5,
        "packet_loss_percent": 0,
    },
    "4g": {
        "download_kbps": 20_000,
        "upload_kbps": 5_000,
        "latency_ms": 50,
        "jitter_ms": 20,
        "packet_loss_percent": 0.5,
    },
    "4g-poor": {
        "download_kbps": 5_000,
        "upload_kbps": 1_000,
        "latency_ms": 150,
        "jitter_ms": 50,
        "packet_loss_percent": 2,
    },
    "3g": {
        "download_kbps": 2_000,
        "upload_kbps": 384,
        "latency_ms": 200,
        "jitter_ms": 80,
        "packet_loss_percent": 2,
    },
    "2g": {
        "download_kbps": 256,
        "upload_kbps": 128,
        "latency_ms": 500,
        "jitter_ms": 200,
        "packet_loss_percent": 5,
    },
    "edge": {
        "download_kbps": 56,
        "upload_kbps": 28,
        "latency_ms": 800,
        "jitter_ms": 300,
        "packet_loss_percent": 10,
    },
    "offline": {
        "download_kbps": 0,
        "upload_kbps": 0,
        "latency_ms": 0,
        "jitter_ms": 0,
        "packet_loss_percent": 100,
    },
}


@dataclass
class NetworkCondition:
    """Current network condition for a client."""

    client_ip: str
    download_kbps: int | None = None
    upload_kbps: int | None = None
    latency_ms: int | None = None
    jitter_ms: int | None = None
    packet_loss_percent: float | None = None
    profile: str | None = None
    active: bool = False


@dataclass
class NetworkSimulator:
    """
    Network condition simulation for test clients.

    Supports:
    - Bandwidth throttling (download/upload limits)
    - Latency injection (fixed delay)
    - Jitter (variable delay)
    - Packet loss (random drop percentage)
    - Preset profiles (3G, 4G, WiFi-poor, etc.)
    """

    client: RouterClient | None = None
    base_url: str | None = None
    token: str | None = None
    _conditions: dict[str, NetworkCondition] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> NetworkSimulator:
        """Create from environment variables."""
        from mtk_router_sdk.client import RouterClient

        base_url = os.environ.get(
            "MTK_SERVICE_URL",
            f"http://127.0.0.1:{os.environ.get('MTK_HTTP_PORT', '8765')}",
        )
        token = os.environ.get("MTK_SERVICE_TOKEN")

        client: RouterClient | None = None
        try:
            client = RouterClient.from_env()
        except Exception:
            pass

        return cls(client=client, base_url=base_url, token=token)

    def _uses_http(self) -> bool:
        """Use mtk-serve REST API (no direct RouterOS SSH)."""
        return self.client is None and bool(self.base_url)

    def _require_transport(self) -> None:
        if self.client is not None or self.base_url:
            return
        raise RuntimeError(
            "NetworkSimulator needs Router SSH (MTK_HOST, MTK_USER, MTK_PASSWORD) "
            "or mtk-serve HTTP (MTK_SERVICE_URL). Without either, rules cannot be applied."
        )

    def _sync_condition_from_http(self, client_ip: str) -> NetworkCondition | None:
        from mtk_router_sdk.testing.http_api import testing_service_request

        assert self.base_url is not None
        data = testing_service_request(
            self.base_url,
            "GET",
            "/v1/network/condition",
            token=self.token,
            query={"client_ip": client_ip},
        )
        if not data.get("active"):
            self._conditions.pop(client_ip, None)
            return None
        c = NetworkCondition(
            client_ip=str(data.get("client_ip", client_ip)),
            download_kbps=data.get("download_kbps"),
            upload_kbps=data.get("upload_kbps"),
            latency_ms=data.get("latency_ms"),
            jitter_ms=data.get("jitter_ms"),
            packet_loss_percent=data.get("packet_loss_percent"),
            profile=data.get("profile"),
            active=True,
        )
        self._conditions[client_ip] = c
        return c

    def throttle(
        self,
        client_ip: str,
        download_kbps: int | None = None,
        upload_kbps: int | None = None,
    ) -> NetworkCondition:
        """
        Apply bandwidth throttling to a client.

        Args:
            client_ip: Target client IP address
            download_kbps: Download limit in Kbps (None = unlimited)
            upload_kbps: Upload limit in Kbps (None = unlimited)

        Returns:
            NetworkCondition with applied settings
        """
        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            body: dict[str, object] = {"client_ip": client_ip}
            if download_kbps is not None:
                body["download_kbps"] = download_kbps
            if upload_kbps is not None:
                body["upload_kbps"] = upload_kbps
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/network/apply",
                token=self.token,
                json_body=body,
            )
            return self._sync_condition_from_http(client_ip) or self._get_or_create(
                client_ip
            )

        condition = self._get_or_create(client_ip)
        condition.download_kbps = download_kbps
        condition.upload_kbps = upload_kbps
        condition.active = True

        self._apply_queue_rules(client_ip, condition)
        return condition

    def latency(
        self,
        client_ip: str,
        delay_ms: int,
        jitter_ms: int = 0,
    ) -> NetworkCondition:
        """
        Add latency to a client's traffic.

        Args:
            client_ip: Target client IP address
            delay_ms: Fixed delay in milliseconds
            jitter_ms: Random variation (+/- ms)

        Returns:
            NetworkCondition with applied settings
        """
        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/network/apply",
                token=self.token,
                json_body={
                    "client_ip": client_ip,
                    "latency_ms": delay_ms,
                    "jitter_ms": jitter_ms,
                },
            )
            return self._sync_condition_from_http(client_ip) or self._get_or_create(
                client_ip
            )

        condition = self._get_or_create(client_ip)
        condition.latency_ms = delay_ms
        condition.jitter_ms = jitter_ms
        condition.active = True

        self._apply_latency_rules(client_ip, condition)
        return condition

    def packet_loss(
        self,
        client_ip: str,
        percent: float,
    ) -> NetworkCondition:
        """
        Add packet loss to a client's traffic.

        Args:
            client_ip: Target client IP address
            percent: Percentage of packets to drop (0-100)

        Returns:
            NetworkCondition with applied settings
        """
        if not 0 <= percent <= 100:
            raise ValueError("Packet loss percent must be 0-100")

        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/network/apply",
                token=self.token,
                json_body={"client_ip": client_ip, "packet_loss_percent": percent},
            )
            return self._sync_condition_from_http(client_ip) or self._get_or_create(
                client_ip
            )

        condition = self._get_or_create(client_ip)
        condition.packet_loss_percent = percent
        condition.active = True

        self._apply_packet_loss_rules(client_ip, condition)
        return condition

    def apply_profile(
        self,
        client_ip: str,
        profile: str | NetworkProfile,
    ) -> NetworkCondition:
        """
        Apply a preset network profile.

        Args:
            client_ip: Target client IP address
            profile: Profile name ("3g", "4g", "wifi-poor") or NetworkProfile enum

        Returns:
            NetworkCondition with applied settings

        Available profiles:
            - wifi-excellent: 100 Mbps, 5ms latency
            - wifi-good: 50 Mbps, 20ms latency
            - wifi-poor: 5 Mbps, 100ms latency, 2% loss
            - 5g: 100 Mbps, 10ms latency
            - 4g: 20 Mbps, 50ms latency
            - 4g-poor: 5 Mbps, 150ms latency, 2% loss
            - 3g: 2 Mbps, 200ms latency, 2% loss
            - 2g: 256 Kbps, 500ms latency, 5% loss
            - edge: 56 Kbps, 800ms latency, 10% loss
            - offline: 100% packet loss
        """
        if isinstance(profile, NetworkProfile):
            profile_name = profile.value
        else:
            profile_name = profile.lower()

        if profile_name not in NETWORK_PROFILES:
            available = ", ".join(NETWORK_PROFILES.keys())
            raise ValueError(f"Unknown profile '{profile_name}'. Available: {available}")

        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/network/apply",
                token=self.token,
                json_body={"client_ip": client_ip, "profile": profile_name},
            )
            synced = self._sync_condition_from_http(client_ip)
            if synced is not None:
                return synced
            settings = NETWORK_PROFILES[profile_name]
            condition = self._get_or_create(client_ip)
            condition.download_kbps = settings["download_kbps"]
            condition.upload_kbps = settings["upload_kbps"]
            condition.latency_ms = settings["latency_ms"]
            condition.jitter_ms = settings["jitter_ms"]
            condition.packet_loss_percent = settings["packet_loss_percent"]
            condition.profile = profile_name
            condition.active = True
            return condition

        settings = NETWORK_PROFILES[profile_name]
        condition = self._get_or_create(client_ip)

        condition.download_kbps = settings["download_kbps"]
        condition.upload_kbps = settings["upload_kbps"]
        condition.latency_ms = settings["latency_ms"]
        condition.jitter_ms = settings["jitter_ms"]
        condition.packet_loss_percent = settings["packet_loss_percent"]
        condition.profile = profile_name
        condition.active = True

        self._apply_all_rules(client_ip, condition)
        return condition

    def disconnect(
        self,
        client_ip: str,
        duration_seconds: int | None = None,
    ) -> NetworkCondition:
        """
        Simulate network disconnection (100% packet loss).

        Args:
            client_ip: Target client IP address
            duration_seconds: Auto-restore after N seconds (None = manual restore)

        Returns:
            NetworkCondition with applied settings
        """
        condition = self.apply_profile(client_ip, "offline")

        if duration_seconds is not None:
            import threading

            def restore() -> None:
                import time

                time.sleep(duration_seconds)
                self.clear(client_ip)

            thread = threading.Thread(target=restore, daemon=True)
            thread.start()

        return condition

    def get_condition(self, client_ip: str) -> NetworkCondition | None:
        """Get current network condition for a client."""
        if self._uses_http():
            return self._sync_condition_from_http(client_ip)
        return self._conditions.get(client_ip)

    def list_conditions(self) -> list[NetworkCondition]:
        """List all active network conditions."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            data = testing_service_request(
                self.base_url,
                "GET",
                "/v1/network/conditions",
                token=self.token,
            )
            out: list[NetworkCondition] = []
            for item in data.get("conditions", []):
                if not item.get("active"):
                    continue
                out.append(
                    NetworkCondition(
                        client_ip=str(item.get("client_ip", "")),
                        download_kbps=item.get("download_kbps"),
                        upload_kbps=item.get("upload_kbps"),
                        latency_ms=item.get("latency_ms"),
                        jitter_ms=item.get("jitter_ms"),
                        packet_loss_percent=item.get("packet_loss_percent"),
                        profile=item.get("profile"),
                        active=True,
                    )
                )
            return out
        return [c for c in self._conditions.values() if c.active]

    def clear(self, client_ip: str) -> None:
        """Clear all network conditions for a client."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "DELETE",
                "/v1/network/condition",
                token=self.token,
                query={"client_ip": client_ip},
            )
            self._conditions.pop(client_ip, None)
            return
        # Always remove router/mangle rules when using SSH, even if this process
        # lost in-memory state (refresh, restart) — otherwise Clear/Reset appears
        # to do nothing while the router still drops or queues traffic.
        if self.client is not None:
            self._remove_all_rules(client_ip)
        self._conditions.pop(client_ip, None)

    def clear_all(self) -> None:
        """Clear all network conditions for all clients."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "DELETE",
                "/v1/network/condition",
                token=self.token,
            )
            self._conditions.clear()
            return
        for client_ip in list(self._conditions.keys()):
            self.clear(client_ip)

    def _get_or_create(self, client_ip: str) -> NetworkCondition:
        """Get or create a NetworkCondition for a client."""
        if client_ip not in self._conditions:
            self._conditions[client_ip] = NetworkCondition(client_ip=client_ip)
        return self._conditions[client_ip]

    def _ensure_ssh_connected(self) -> None:
        """Open SSH when using RouterClient (dashboard / kit never pre-connects)."""
        if self.client is None or self._uses_http():
            return
        if self.client.connected:
            return
        from mtk_router_sdk.config.env import connection_config_from_env
        from mtk_router_sdk.exceptions import ConfigurationError

        try:
            cfg = connection_config_from_env(
                require_password=True,
                exit_on_missing_password=False,
            )
        except ConfigurationError as e:
            raise RuntimeError(e.message) from e
        self.client.connect(cfg)

    def _apply_queue_rules(
        self, client_ip: str, condition: NetworkCondition
    ) -> None:
        """Apply MikroTik queue rules for bandwidth limiting."""
        if self.client is None:
            return
        self._ensure_ssh_connected()

        comment = f"mtk_network_{client_ip.replace('.', '_')}"

        self.client.exec_command(f"/queue simple remove [find comment={comment}]")

        if condition.download_kbps or condition.upload_kbps:
            down = f"{condition.download_kbps}k" if condition.download_kbps else ""
            up = f"{condition.upload_kbps}k" if condition.upload_kbps else ""
            max_limit = f"{up}/{down}" if up or down else ""

            if max_limit:
                cmd = (
                    f"/queue simple add "
                    f"name={comment} "
                    f"target={client_ip}/32 "
                    f"max-limit={max_limit} "
                    f"comment={comment}"
                )
                self.client.exec_command(cmd)

    def _apply_latency_rules(
        self, client_ip: str, condition: NetworkCondition
    ) -> None:
        """
        Apply latency rules.

        Note: MikroTik doesn't have native latency injection.
        This uses queue with burst settings as approximation.
        For precise latency, use external traffic control.
        """
        pass

    def _apply_packet_loss_rules(
        self, client_ip: str, condition: NetworkCondition
    ) -> None:
        """Apply MikroTik firewall rules for packet loss simulation."""
        if self.client is None:
            return
        self._ensure_ssh_connected()

        comment_out = f"mtk_loss_out_{client_ip.replace('.', '_')}"
        comment_in = f"mtk_loss_in_{client_ip.replace('.', '_')}"

        # Remove existing rules
        self.client.exec_command(f"/ip firewall filter remove [find comment={comment_out}]")
        self.client.exec_command(f"/ip firewall filter remove [find comment={comment_in}]")

        loss = condition.packet_loss_percent
        if not loss or loss <= 0:
            return

        # For 100% loss (offline), drop ALL packets - no nth needed
        # Use place-before=0 to insert at TOP of chain (before any accept rules)
        if loss >= 100:
            # Block traffic FROM the device (outgoing)
            cmd_out = (
                f"/ip firewall filter add "
                f"chain=forward "
                f"src-address={client_ip} "
                f"action=drop "
                f"place-before=0 "
                f"comment={comment_out}"
            )
            r = self.client.exec_command(cmd_out)
            # Log result for debugging
            if not r.ok:
                print(f"[MTK] Failed to add outgoing drop rule: {r.stderr}")

            # Block traffic TO the device (incoming)
            cmd_in = (
                f"/ip firewall filter add "
                f"chain=forward "
                f"dst-address={client_ip} "
                f"action=drop "
                f"place-before=0 "
                f"comment={comment_in}"
            )
            r = self.client.exec_command(cmd_in)
            if not r.ok:
                print(f"[MTK] Failed to add incoming drop rule: {r.stderr}")
            return

        # For partial loss, use nth to drop every Nth packet
        # Also place at top of chain
        nth_value = max(2, int(100 / loss))

        # Outgoing packets
        cmd_out = (
            f"/ip firewall filter add "
            f"chain=forward "
            f"src-address={client_ip} "
            f"nth={nth_value},1 "
            f"action=drop "
            f"place-before=0 "
            f"comment={comment_out}"
        )
        self.client.exec_command(cmd_out)

        # Incoming packets
        cmd_in = (
            f"/ip firewall filter add "
            f"chain=forward "
            f"dst-address={client_ip} "
            f"nth={nth_value},1 "
            f"action=drop "
            f"place-before=0 "
            f"comment={comment_in}"
        )
        self.client.exec_command(cmd_in)

    def _apply_all_rules(
        self, client_ip: str, condition: NetworkCondition
    ) -> None:
        """Apply all network condition rules."""
        self._apply_queue_rules(client_ip, condition)
        self._apply_latency_rules(client_ip, condition)
        self._apply_packet_loss_rules(client_ip, condition)

    def _remove_all_rules(self, client_ip: str) -> None:
        """Remove all network condition rules for a client."""
        if self.client is None:
            return
        self._ensure_ssh_connected()

        comment_queue = f"mtk_network_{client_ip.replace('.', '_')}"
        # Legacy single-rule name
        comment_loss_old = f"mtk_packetloss_{client_ip.replace('.', '_')}"
        # New bidirectional names
        comment_loss_out = f"mtk_loss_out_{client_ip.replace('.', '_')}"
        comment_loss_in = f"mtk_loss_in_{client_ip.replace('.', '_')}"

        self.client.exec_command(f"/queue simple remove [find comment={comment_queue}]")
        self.client.exec_command(f"/ip firewall filter remove [find comment={comment_loss_old}]")
        self.client.exec_command(f"/ip firewall filter remove [find comment={comment_loss_out}]")
        self.client.exec_command(f"/ip firewall filter remove [find comment={comment_loss_in}]")

    def get_live_stats(self, client_ip: str) -> dict[str, Any]:
        """Get real-time queue and firewall statistics for a client from the router.

        Returns actual bytes/packets transferred, current rate, and rule status.
        """
        if self.client is None or self._uses_http():
            return {
                "available": False,
                "reason": "Live stats require Router SSH (not available via HTTP API)",
            }

        self._ensure_ssh_connected()

        import re
        import time

        stats: dict[str, Any] = {
            "available": True,
            "client_ip": client_ip,
            "queue": None,
            "firewall_rules": [],
            "timestamp": time.time(),
            "parsed": {
                "download_rate_bps": None,
                "upload_rate_bps": None,
                "download_limit_bps": None,
                "upload_limit_bps": None,
                "queue_bytes": None,
                "queue_packets": None,
                "dropped_bytes": 0,
                "dropped_packets": 0,
            },
        }

        # Get queue statistics with terse format for easier parsing
        comment_queue = f"mtk_network_{client_ip.replace('.', '_')}"
        try:
            # Use terse for structured output
            r = self.client.exec_command(
                f'/queue simple print terse stats where comment="{comment_queue}"',
                timeout=10.0,
            )
            if r.ok and r.stdout.strip():
                raw = r.stdout.strip()
                stats["queue"] = {"exists": True, "raw": raw[:800]}

                # Parse terse output: key=value pairs
                # rate format: rate=upload/download (in bps or with suffix)
                rate_match = re.search(r'rate=(\d+(?:\.\d+)?[kKmMgG]?)/(\d+(?:\.\d+)?[kKmMgG]?)', raw)
                if rate_match:
                    def parse_rate(s: str) -> int:
                        s = s.lower()
                        mult = 1
                        if 'k' in s:
                            mult = 1000
                            s = s.replace('k', '')
                        elif 'm' in s:
                            mult = 1000000
                            s = s.replace('m', '')
                        elif 'g' in s:
                            mult = 1000000000
                            s = s.replace('g', '')
                        return int(float(s) * mult)

                    stats["parsed"]["upload_rate_bps"] = parse_rate(rate_match.group(1))
                    stats["parsed"]["download_rate_bps"] = parse_rate(rate_match.group(2))

                # Parse max-limit=upload/download
                limit_match = re.search(r'max-limit=(\d+[kKmM]?)/(\d+[kKmM]?)', raw)
                if limit_match:
                    def parse_limit(s: str) -> int:
                        s = s.lower()
                        mult = 1
                        if 'k' in s:
                            mult = 1000
                            s = s.replace('k', '')
                        elif 'm' in s:
                            mult = 1000000
                            s = s.replace('m', '')
                        return int(float(s) * mult)

                    stats["parsed"]["upload_limit_bps"] = parse_limit(limit_match.group(1))
                    stats["parsed"]["download_limit_bps"] = parse_limit(limit_match.group(2))

                # Parse bytes and packets
                bytes_match = re.search(r'bytes=(\d+)/(\d+)', raw)
                if bytes_match:
                    stats["parsed"]["queue_bytes"] = int(bytes_match.group(1)) + int(bytes_match.group(2))

                packets_match = re.search(r'packets=(\d+)/(\d+)', raw)
                if packets_match:
                    stats["parsed"]["queue_packets"] = int(packets_match.group(1)) + int(packets_match.group(2))

            else:
                stats["queue"] = {"exists": False, "raw": ""}
        except Exception as e:
            stats["queue"] = {"exists": False, "error": str(e)[:200]}

        # Get firewall rule stats (packet/byte counters)
        comment_out = f"mtk_loss_out_{client_ip.replace('.', '_')}"
        comment_in = f"mtk_loss_in_{client_ip.replace('.', '_')}"
        for comment, direction in [(comment_out, "outgoing"), (comment_in, "incoming")]:
            try:
                r = self.client.exec_command(
                    f'/ip firewall filter print stats where comment="{comment}"',
                    timeout=10.0,
                )
                if r.ok and r.stdout.strip():
                    raw = r.stdout.strip()
                    stats["firewall_rules"].append({
                        "direction": direction,
                        "exists": True,
                        "raw": raw[:400],
                    })
                    # Parse bytes and packets from stats output
                    # Format usually has BYTES PACKETS at end of line
                    nums = re.findall(r'(\d+)\s+(\d+)\s*$', raw, re.MULTILINE)
                    if nums:
                        for b, p in nums:
                            stats["parsed"]["dropped_bytes"] += int(b)
                            stats["parsed"]["dropped_packets"] += int(p)
                else:
                    stats["firewall_rules"].append({
                        "direction": direction,
                        "exists": False,
                    })
            except Exception as e:
                stats["firewall_rules"].append({
                    "direction": direction,
                    "exists": False,
                    "error": str(e)[:100],
                })

        return stats

    def get_interface_traffic(self, interface: str = "bridge") -> dict[str, Any]:
        """Get real-time traffic rate on an interface (useful for overall monitoring)."""
        if self.client is None or self._uses_http():
            return {"available": False}

        self._ensure_ssh_connected()
        try:
            # This gives a snapshot - for live monitoring, poll repeatedly
            r = self.client.exec_command(
                f'/interface monitor-traffic {interface} once',
                timeout=5.0,
            )
            if r.ok:
                return {
                    "available": True,
                    "interface": interface,
                    "raw": r.stdout.strip()[:500],
                }
        except Exception as e:
            return {"available": False, "error": str(e)[:100]}
        return {"available": False}

    @staticmethod
    def available_profiles() -> dict[str, dict[str, Any]]:
        """Return all available network profiles with their settings."""
        return NETWORK_PROFILES.copy()
