import { $ } from '../core/dom.js';
import { api, toast, toastApiError, renderApiProblem } from '../core/api.js';
import * as state from '../core/state.js';
import { escapeHtml, pushActivity } from '../core/activity.js';
import { renderLogEntryList } from '../core/logs-render.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';
import { animateValueChange, pulseElement, animateBadgeChange } from '../core/animations.js';

let _cockpitDebounce = null;

/** HTTP log (Network tab): live polling */
let _netLogLiveInterval = null;
let _netLogLiveOn = false;
/** When false, live polling does not fetch (Charles-style pause capture). */
let _netLogRecordingOn = true;

const HTTL_WATCH_LS_KEY = 'mtk_dashboard_httl_watch_v1';
/** @type {'all' | 'selected'} */
let _httlScope = 'all';
/** @type {Set<string>} */
let _httlWatchIps = new Set();

const IPV4_RE = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

function loadHttlWatchState() {
  try {
    const raw = localStorage.getItem(HTTL_WATCH_LS_KEY);
    if (!raw) return;
    const o = JSON.parse(raw);
    if (o && (o.scope === 'selected' || o.scope === 'all')) _httlScope = o.scope;
    if (o && Array.isArray(o.ips)) _httlWatchIps = new Set(o.ips.map((x) => String(x || '').trim()).filter(Boolean));
  } catch {
    /* ignore */
  }
}

function saveHttlWatchState() {
  try {
    localStorage.setItem(
      HTTL_WATCH_LS_KEY,
      JSON.stringify({ scope: _httlScope, ips: [..._httlWatchIps].sort() }),
    );
  } catch {
    /* ignore quota */
  }
}

function syncNetLogHiddenFieldsFromWatch() {
  const hid = $('netLogClientIp');
  const pick = $('netLogDevicePick');
  if (!hid) return;
  if (_httlScope === 'selected' && _httlWatchIps.size === 1) {
    const only = [..._httlWatchIps][0];
    hid.value = only;
    if (pick) pick.value = _lanDevices.some((d) => d.ip === only) ? only : '';
  } else if (_httlScope === 'selected' && _httlWatchIps.size > 1) {
    hid.value = [..._httlWatchIps].sort().join(',');
    if (pick) pick.value = '';
  } else {
    hid.value = '';
    if (pick) pick.value = '';
  }
}

function setHttlScope(scope) {
  _httlScope = scope === 'selected' ? 'selected' : 'all';
  const allBtn = $('httlScopeAll');
  const selBtn = $('httlScopeSelected');
  const panel = $('httlClientsPanel');
  const hint = $('httlScopeHint');
  allBtn?.classList.toggle('httl-scope-btn--active', _httlScope === 'all');
  selBtn?.classList.toggle('httl-scope-btn--active', _httlScope === 'selected');
  if (panel) panel.hidden = _httlScope !== 'selected';
  if (hint) {
    hint.innerHTML =
      _httlScope === 'all'
        ? 'Shows every client already in the log buffer. Does <strong>not</strong> change routing — devices without manual proxy :8888 never hit mtk-serve.'
        : 'Only checked IPs are requested; use when several lab devices share the proxy but you want one view.';
  }
  saveHttlWatchState();
  syncNetLogHiddenFieldsFromWatch();
}

function renderHttlClientChecks() {
  const box = $('httlClientChecks');
  if (!box) return;
  const seen = new Set();
  const rows = [];
  for (const d of _lanDevices) {
    const ip = String(d.ip || '').trim();
    if (!ip || seen.has(ip)) continue;
    seen.add(ip);
    const checked = _httlWatchIps.has(ip) ? ' checked' : '';
    const lab = escapeHtml(String(d.label || ip));
    rows.push(
      `<label class="httl-client-check"><input type="checkbox" data-httl-ip="${escapeHtml(ip)}"${checked}/><span>${lab}</span><code class="mono httl-client-check__ip">${escapeHtml(ip)}</code></label>`,
    );
  }
  for (const ip of [..._httlWatchIps].sort()) {
    if (seen.has(ip)) continue;
    rows.push(
      `<label class="httl-client-check"><input type="checkbox" data-httl-ip="${escapeHtml(ip)}" checked/><span>Manual</span><code class="mono httl-client-check__ip">${escapeHtml(ip)}</code></label>`,
    );
  }
  if (!rows.length) {
    box.innerHTML =
      '<p class="httl-client-checks__empty">No LAN devices yet — refresh Workbench or add an IP below.</p>';
    return;
  }
  box.innerHTML = rows.join('');
  box.querySelectorAll('input[data-httl-ip]').forEach((inp) => {
    inp.addEventListener('change', () => {
      const ip = inp.getAttribute('data-httl-ip') || '';
      if (!ip) return;
      if (inp.checked) _httlWatchIps.add(ip);
      else _httlWatchIps.delete(ip);
      saveHttlWatchState();
      syncNetLogHiddenFieldsFromWatch();
    });
  });
}

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

/** Append server `warning` (e.g. broadcast IP hint) to success toast. */
function toastNetSuccess(data, baseMsg) {
  const w =
    data && typeof data.warning === 'string' && data.warning.trim()
      ? data.warning.trim()
      : '';
  toast(w ? `${baseMsg} — ${w}` : baseMsg, true);
}

/** @type {Array<{ ip: string; label?: string; hostname?: string | null; device_type?: string; status?: string | null; mac_address?: string | null; dhcp_server?: string | null; origin?: string; interface?: string | null }>} */
let _lanDevices = [];
let _lastLanHint = '';
let _lastLanSummary = '';
/** @type {string} last `/api/network/lan-devices` `source` (e.g. host_fallback, mixed, dhcp). */
let _lanDeviceListSource = '';

function pickDevicePlaceholder() {
  if (_lanDeviceListSource === 'host_fallback') {
    return '— Pick device (host LAN / ARP, not router DHCP) or type IP —';
  }
  return '— Pick device (DHCP + ARP) or type IP —';
}

/** IPs from mtk-serve proxy log when ARP/DHCP is sparse (traffic often appears before ARP fills). */
async function mergeProxyLogClientIpsIntoLanDevices() {
  let added = 0;
  try {
    const data = await api('/api/proxy/logs?limit=400');
    const entries = Array.isArray(data.entries) ? data.entries : [];
    const have = new Set(_lanDevices.map((d) => String(d.ip || '').trim()));
    for (const e of entries) {
      const ip = String(e?.client_ip || '').trim();
      if (!IPV4_RE.test(ip) || ip === '127.0.0.1') continue;
      if (have.has(ip)) continue;
      have.add(ip);
      _lanDevices.push({
        ip,
        label: `${ip} · HTTP log`,
        device_type: 'Seen in proxy log',
        origin: 'proxy_log',
      });
      added += 1;
    }
    if (added) {
      _lanDevices.sort((a, b) =>
        String(a.ip).localeCompare(String(b.ip), undefined, { numeric: true }),
      );
    }
  } catch {
    /* mtk-serve down or blocked */
  }
  return added;
}

const NET_TARGETS_LS_KEY = 'mtk_dashboard_net_targets_v2';
const NET_MULTI_MAX_ROWS = 16;
/** @type {{ name: string }[]} */
let _profilesForTargets = [];
/** @type {{ rows: { id: string; ip: string; profile: string }[] }} */
let _multiTargetState = { rows: [] };
let _multiPersistTimer = null;
let _netMultiListWired = false;

function makeTargetRowId() {
  return 'nt_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
}

function loadMultiTargetState() {
  try {
    const raw = localStorage.getItem(NET_TARGETS_LS_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw);
    if (!o || !Array.isArray(o.rows)) return null;
    return {
      rows: o.rows
        .filter((r) => r && typeof r.id === 'string')
        .map((r) => ({
          id: r.id,
          ip: typeof r.ip === 'string' ? r.ip : '',
          profile: typeof r.profile === 'string' ? r.profile : '',
        }))
        .slice(0, NET_MULTI_MAX_ROWS),
    };
  } catch {
    return null;
  }
}

function schedulePersistMultiTargets() {
  clearTimeout(_multiPersistTimer);
  _multiPersistTimer = setTimeout(() => {
    try {
      localStorage.setItem(NET_TARGETS_LS_KEY, JSON.stringify(_multiTargetState));
    } catch {
      /* ignore quota */
    }
  }, 200);
}

function ensureMultiTargetRows() {
  if (!_multiTargetState.rows.length) {
    _multiTargetState.rows = [{ id: makeTargetRowId(), ip: '', profile: '' }];
  }
}

function buildLanPickOptionsOnly() {
  let opts = '<option value="">— Pick device —</option>';
  for (const d of _lanDevices) {
    const ip = String(d.ip || '');
    opts += `<option value="${escapeHtml(ip)}">${escapeHtml(String(d.label || ip))}</option>`;
  }
  return opts;
}

/** Safe for `[data-target-id="…"]` (ids are generated; strip quotes if tampered). */
function safeTargetIdForSelector(id) {
  return String(id).replace(/"/g, '');
}

function buildProfileOptionsForTargets(selectedProfile) {
  let opts = '<option value="">— Preset —</option>';
  for (const p of _profilesForTargets) {
    const n = String(p?.name ?? '');
    if (!n) continue;
    const sel = n === selectedProfile ? ' selected' : '';
    opts += `<option value="${escapeHtml(n)}"${sel}>${escapeHtml(n)}</option>`;
  }
  return opts;
}

/** @returns {{ label: string; tone: string }} */
function conditionSummaryForIp(ip) {
  const t = (ip || '').trim();
  if (!t) return { label: 'No IP yet', tone: 'empty' };
  const conds = state.networkConditionsCache || [];
  const c = conds.find((x) => x && x.client_ip === t && x.active !== false);
  if (!c) return { label: 'No active limits', tone: 'idle' };
  const prof = c.profile && String(c.profile).trim();
  if (prof) return { label: prof, tone: 'profile' };
  return { label: 'Custom limits', tone: 'custom' };
}

function deviceSubtitleForIp(ip) {
  const t = (ip || '').trim();
  if (!t) return 'Pick a device below or type an address';
  const d = findLanDevice(t);
  if (!d) return 'Not in last LAN scan — router may still shape this client';
  const parts = [];
  if (d.device_type) parts.push(d.device_type);
  if (d.hostname) parts.push(d.hostname);
  if (d.status) parts.push(`DHCP: ${d.status}`);
  return parts.join(' · ') || 'On LAN';
}

function updateNetDutFocusRings() {
  const focusIp = ($('netClientIp')?.value || '').trim();
  const list = $('netMultiTargetsList');
  if (!list) return;
  list.querySelectorAll('.net-dut-card').forEach((el) => {
    const ip = (el.querySelector('.net-target-ip')?.value || '').trim();
    el.classList.toggle('net-dut-card--focused', ip !== '' && ip === focusIp);
  });
}

function refreshNetDutCardBadgesOnly() {
  const list = $('netMultiTargetsList');
  if (!list) return;
  list.querySelectorAll('.net-dut-card').forEach((card) => {
    const ip = (card.querySelector('.net-target-ip')?.value || '').trim();
    const badge = card.querySelector('.net-dut-card-badge');
    const sub = card.querySelector('.net-dut-card-sub');
    const displayIp = card.querySelector('.net-dut-card-ip-display');
    const { label, tone } = conditionSummaryForIp(ip);
    if (badge) {
      badge.textContent = label;
      badge.className = 'net-dut-card-badge net-dut-card-badge--' + tone;
    }
    if (sub) sub.textContent = deviceSubtitleForIp(ip);
    if (displayIp) displayIp.textContent = ip || '—';
  });
  updateNetDutFocusRings();
}

function renderNetMultiTargetsList() {
  const list = $('netMultiTargetsList');
  if (!list) return;
  ensureMultiTargetRows();
  const rows = _multiTargetState.rows;
  let html = '';
  rows.forEach((r, i) => {
    const isOnlyRow = rows.length === 1;
    const hasIp = (r.ip || '').trim();
    const ipDisp = hasIp || '—';
    const { label, tone } = conditionSummaryForIp(r.ip);
    
    // Determine delete button text and behavior
    // - If only row: show "Clear" (clears IP/profile but keeps the slot)
    // - If multiple rows: show "Delete" with trash icon
    const deleteBtn = isOnlyRow
      ? `<button type="button" class="btn btn-ghost btn-sm net-dut-remove" data-target-remove="${escapeHtml(r.id)}" aria-label="Clear this slot" title="Clear IP and preset from this slot">
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/></svg>
           Clear
         </button>`
      : `<button type="button" class="btn btn-ghost btn-sm btn-danger-ghost net-dut-remove" data-target-remove="${escapeHtml(r.id)}" aria-label="Delete this slot" title="Remove this device slot entirely">
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
           Delete
         </button>`;

    const headRemoveLabel = isOnlyRow
      ? `Clear slot ${i + 1} (IP and preset)`
      : `Remove device slot ${i + 1}${hasIp ? ` — ${hasIp}` : ''}`;
    const headRemoveTitle = isOnlyRow
      ? 'Clear IP and preset (this slot stays)'
      : hasIp
        ? 'Remove this tile from the list'
        : 'Remove this empty tile';

    const trashSvg =
      '<svg class="net-dut-remove-tile__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>';
    
    html += `<article class="net-dut-card${!hasIp ? ' net-dut-card--empty' : ''}" data-target-id="${escapeHtml(r.id)}">
      <div class="net-dut-card-head-row">
        <button type="button" class="net-dut-card-head" data-target-select="${escapeHtml(r.id)}" title="Select this IP for the workbench (controls + cockpit + live stats)">
          <div class="net-dut-card-head-top">
            <span class="net-dut-card-slot mono">${i + 1}</span>
            <div class="net-dut-card-head-titles">
              <span class="net-dut-card-ip-display mono">${escapeHtml(ipDisp)}</span>
              <span class="net-dut-card-active-pill" aria-hidden="true">Workbench focus</span>
            </div>
          </div>
          <span class="net-dut-card-badge net-dut-card-badge--${tone}">${escapeHtml(label)}</span>
          <p class="net-dut-card-sub hint">${escapeHtml(deviceSubtitleForIp(r.ip))}</p>
        </button>
        <button type="button" class="net-dut-remove-tile${isOnlyRow ? ' net-dut-remove-tile--clear' : ''}" data-target-remove="${escapeHtml(r.id)}" aria-label="${escapeHtml(headRemoveLabel)}" title="${escapeHtml(headRemoveTitle)}">
          ${trashSvg}
          <span class="net-dut-remove-tile__hint">${isOnlyRow ? 'Clear' : 'Remove'}</span>
        </button>
      </div>
      <div class="net-dut-card-body">
        <div class="net-dut-field">
          <label class="net-dut-lbl">On LAN</label>
          <div class="net-dut-inline">
            <select class="net-device-pick net-target-device-pick" aria-label="Device ${i + 1} from router">${buildLanPickOptionsOnly()}</select>
            <input type="text" class="net-target-ip mono net-dut-ip-input" placeholder="192.168.x.x" value="${escapeHtml(r.ip)}" autocomplete="off" aria-label="IP for device ${i + 1}" />
          </div>
        </div>
        <div class="net-dut-field net-dut-field--actions">
          <label class="net-dut-lbl">Actions</label>
          <div class="net-dut-inline net-dut-inline--wrap">
            <select class="net-device-pick net-target-profile" aria-label="Preset for device ${i + 1}">${buildProfileOptionsForTargets(r.profile)}</select>
            <div class="net-dut-btn-group">
              <button type="button" class="btn btn-primary btn-sm" data-target-apply="${escapeHtml(r.id)}"${!hasIp ? ' disabled title="Set an IP first"' : ''}>Apply</button>
              <button type="button" class="btn btn-ghost btn-sm" data-target-focus="${escapeHtml(r.id)}"${!hasIp ? ' disabled title="Set an IP first"' : ''} title="Use this IP on the main workbench">Focus</button>
              <button type="button" class="btn btn-ghost btn-sm" data-target-clear-net="${escapeHtml(r.id)}"${!hasIp ? ' disabled title="Set an IP first"' : ''}>Reset</button>
              ${deleteBtn}
            </div>
          </div>
        </div>
      </div>
    </article>`;
  });
  list.innerHTML = html;
  rows.forEach((r) => {
    const rowEl = list.querySelector(`.net-dut-card[data-target-id="${safeTargetIdForSelector(r.id)}"]`);
    if (!rowEl) return;
    const pick = rowEl.querySelector('.net-target-device-pick');
    const prof = rowEl.querySelector('.net-target-profile');
    if (pick) {
      if (r.ip && _lanDevices.some((d) => d.ip === r.ip)) pick.value = r.ip;
      else pick.value = '';
    }
    if (prof && r.profile) {
      prof.value = r.profile;
    }
  });
  refreshNetDutCardBadgesOnly();
}

function rebuildNetLogDevicePick() {
  const sel = $('netLogDevicePick');
  if (!sel) return;
  const cur = ($('netLogClientIp')?.value || '').trim().split(',')[0]?.trim() || '';
  let opts = '<option value="">All clients (no filter)</option>';
  for (const d of _lanDevices) {
    const ip = String(d.ip || '');
    opts += `<option value="${escapeHtml(ip)}">${escapeHtml(String(d.label || ip))}</option>`;
  }
  sel.innerHTML = opts;
  if (cur && _lanDevices.some((d) => d.ip === cur)) sel.value = cur;
  else sel.value = '';
  renderHttlClientChecks();
}

function switchNetTab(tabId) {
  if (tabId !== 'traffic') {
    stopNetLogLive();
  }
  document.querySelectorAll('.net-tab').forEach((t) => {
    const isActive = t.getAttribute('data-net-tab') === tabId;
    t.classList.toggle('active', isActive);
    t.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
  document.querySelectorAll('.net-tab-panel').forEach((p) => {
    const panelTab = p.id.replace('netTab', '').toLowerCase();
    p.classList.toggle('active', panelTab === tabId);
  });
  if (tabId === 'workbench' || tabId === 'presets') {
    updateMonitorTargetDisplay();
  }
}

function focusPrimaryClientIp(ip) {
  const trimmed = (ip || '').trim();
  const inp = $('netClientIp');
  if (inp) inp.value = trimmed;
  syncNetDevicePickFromInput();
  updateNetDeviceMetaForIp(trimmed);
  updateNetDutFocusRings();
  updateMonitorTargetDisplay();
  clearTimeout(_cockpitDebounce);
  _cockpitDebounce = setTimeout(() => updateCockpitFromCache(), 120);
}

function initNetMultiTargetsBoard() {
  const saved = loadMultiTargetState();
  _multiTargetState = saved || { rows: [] };
  ensureMultiTargetRows();
  renderNetMultiTargetsList();
  const list = $('netMultiTargetsList');
  if (list && !_netMultiListWired) {
    _netMultiListWired = true;
    list.addEventListener('click', onNetMultiTargetsClick);
    list.addEventListener('change', onNetMultiTargetsChange);
    list.addEventListener('input', onNetMultiTargetsInput);
  }
}

/** @param {MouseEvent} ev */
function onNetMultiTargetsClick(ev) {
  const t = ev.target;
  if (!(t instanceof Element)) return;
  const remId = t.closest('[data-target-remove]')?.getAttribute('data-target-remove');
  if (remId) {
    ev.preventDefault();
    ev.stopPropagation();
    removeMultiRow(remId);
    return;
  }
  const selectId = t.closest('[data-target-select]')?.getAttribute('data-target-select');
  if (selectId) {
    focusMultiRowPrimary(selectId);
    return;
  }
  const applyId = t.closest('[data-target-apply]')?.getAttribute('data-target-apply');
  if (applyId) {
    void applyProfileForMultiRow(applyId);
    return;
  }
  const focusId = t.closest('[data-target-focus]')?.getAttribute('data-target-focus');
  if (focusId) {
    focusMultiRowPrimary(focusId);
    return;
  }
  const clearId = t.closest('[data-target-clear-net]')?.getAttribute('data-target-clear-net');
  if (clearId) {
    void clearMultiRowNet(clearId);
    return;
  }
}

/** @param {Event} ev */
function onNetMultiTargetsChange(ev) {
  const t = ev.target;
  if (!(t instanceof HTMLSelectElement)) return;
  const rowEl = t.closest('.net-dut-card');
  const id = rowEl?.getAttribute('data-target-id');
  if (!id) return;
  const row = _multiTargetState.rows.find((r) => r.id === id);
  if (!row) return;
  if (t.classList.contains('net-target-device-pick')) {
    const v = (t.value || '').trim();
    row.ip = v;
    const inp = rowEl.querySelector('.net-target-ip');
    if (inp && inp instanceof HTMLInputElement) inp.value = v;
    schedulePersistMultiTargets();
    refreshNetDutCardBadgesOnly();
  }
  if (t.classList.contains('net-target-profile')) {
    row.profile = (t.value || '').trim();
    schedulePersistMultiTargets();
  }
}

/** @param {Event} ev */
function onNetMultiTargetsInput(ev) {
  const t = ev.target;
  if (!(t instanceof HTMLInputElement) || !t.classList.contains('net-target-ip')) return;
  const rowEl = t.closest('.net-dut-card');
  const id = rowEl?.getAttribute('data-target-id');
  if (!id) return;
  const row = _multiTargetState.rows.find((r) => r.id === id);
  if (row) row.ip = t.value.trim();
  schedulePersistMultiTargets();
  refreshNetDutCardBadgesOnly();
}

async function applyProfileForMultiRow(rowId) {
  const list = $('netMultiTargetsList');
  const rowEl = list?.querySelector(`.net-dut-card[data-target-id="${safeTargetIdForSelector(rowId)}"]`);
  const ip = (rowEl?.querySelector('.net-target-ip')?.value || '').trim();
  const profile = (rowEl?.querySelector('.net-target-profile')?.value || '').trim();
  if (!ip || !profile) {
    toast('Enter IP and choose a row preset', false);
    return;
  }
  try {
    const data = await api('/api/network/apply', {
      method: 'POST',
      body: JSON.stringify({ client_ip: ip, profile }),
    });
    toastNetSuccess(data, `Profile “${profile}” → ${ip}`);
    const sdk = {
      python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.network.apply_profile(${pyStr(ip)}, ${pyStr(profile)})`,
      cli: `mtk network profile ${ip} ${profile}`,
      rest: `POST /api/network/apply\n${JSON.stringify({ client_ip: ip, profile }, null, 2)}`,
    };
    publishSdkMirror({ title: `Network: multi-row “${profile}”`, ...sdk });
    pushActivity('network', `Multi-target: “${profile}” → ${ip}`, true, sdk);
    await refreshNetworkTable();
    await loadOverview();
  } catch (e) {
    toastApiError(e);
    pushActivity('network', 'Multi-target apply failed: ' + (e instanceof Error ? e.message : String(e)), false);
  }
}

function focusMultiRowPrimary(rowId) {
  const list = $('netMultiTargetsList');
  const rowEl = list?.querySelector(`.net-dut-card[data-target-id="${safeTargetIdForSelector(rowId)}"]`);
  const ip = (rowEl?.querySelector('.net-target-ip')?.value || '').trim();
  if (!ip) return toast('Set an IP on this card first', false);
  const cur = ($('netClientIp')?.value || '').trim();
  if (ip === cur) {
    updateNetDutFocusRings();
    return;
  }
  focusPrimaryClientIp(ip);
  toast('Workbench device: ' + ip, true);
}

async function clearMultiRowNet(rowId) {
  const list = $('netMultiTargetsList');
  const rowEl = list?.querySelector(`.net-dut-card[data-target-id="${safeTargetIdForSelector(rowId)}"]`);
  const ip = (rowEl?.querySelector('.net-target-ip')?.value || '').trim();
  if (!ip) return toast('Enter IP on this row first', false);
  await clearNetOne(ip);
}

function removeMultiRow(rowId) {
  const row = _multiTargetState.rows.find((r) => r.id === rowId);
  if (!row) return;

  const hasIp = (row.ip || '').trim();
  const isOnlyRow = _multiTargetState.rows.length <= 1;

  if (isOnlyRow) {
    _multiTargetState.rows[0].ip = '';
    _multiTargetState.rows[0].profile = '';
    renderNetMultiTargetsList();
    schedulePersistMultiTargets();
    toast('Cleared the slot (need at least one)', true);
    return;
  }

  const conds = state.networkConditionsCache || [];
  const active =
    hasIp && conds.find((c) => c && c.client_ip === row.ip && c.active !== false);
  if (active) {
    const ok = confirm(
      `Remove this tile for ${row.ip}?\n\nShaping may still be active on the router until you use Reset for that IP.`,
    );
    if (!ok) return;
  }

  const removedIp = row.ip;
  _multiTargetState.rows = _multiTargetState.rows.filter((r) => r.id !== rowId);
  schedulePersistMultiTargets();
  renderNetMultiTargetsList();

  if (hasIp && active) {
    toast(`Tile removed. Reset ${removedIp} on the workbench if shaping should stop.`, true);
  } else if (hasIp) {
    toast(`Removed slot for ${removedIp}`, true);
  } else {
    toast('Empty slot removed', true);
  }

  const focusIp = ($('netClientIp')?.value || '').trim();
  if (hasIp && removedIp === focusIp) {
    const nextWithIp = _multiTargetState.rows.find((r) => (r.ip || '').trim());
    if (nextWithIp) {
      focusPrimaryClientIp(nextWithIp.ip);
    } else {
      focusPrimaryClientIp('');
    }
  }
}

async function bulkApplyMainPresetToAllRows() {
  const profile = ($('netProfile')?.value || '').trim();
  if (!profile) return toast('Choose the Workbench preset dropdown first', false);
  const list = $('netMultiTargetsList');
  if (!list) return;
  const ips = [];
  list.querySelectorAll('.net-dut-card').forEach((rowEl) => {
    const ip = (rowEl.querySelector('.net-target-ip')?.value || '').trim();
    if (ip) ips.push(ip);
  });
  const uniqueIps = [...new Set(ips)];
  if (!uniqueIps.length) return toast('No IPs in target rows', false);
  let ok = 0;
  for (const ip of uniqueIps) {
    try {
      const data = await api('/api/network/apply', {
        method: 'POST',
        body: JSON.stringify({ client_ip: ip, profile }),
      });
      if (data && data.error == null) ok += 1;
    } catch {
      /* continue */
    }
  }
  toast(`Applied “${profile}” to ${ok}/${uniqueIps.length} device(s)`, ok === uniqueIps.length);
  publishSdkMirror({
    title: 'Network: bulk preset',
    python: `# loop: kit.network.apply_profile(ip, ${pyStr(profile)})`,
    cli: uniqueIps.map((ip) => `mtk network profile ${ip} ${profile}`).join('\n'),
    rest: `POST /api/network/apply per IP`,
  });
  pushActivity('network', `Bulk preset “${profile}” → ${ok}/${uniqueIps.length} IPs`, ok === uniqueIps.length);
  await refreshNetworkTable();
  await loadOverview();
}

async function pullActiveConditionsIntoTargets() {
  try {
    const d = await api('/api/network/conditions');
    const conds = (d.conditions || []).filter((c) => c && c.active !== false);
    if (!conds.length) {
      toast('No active conditions to import', false);
      return;
    }
    const use = conds.slice(0, NET_MULTI_MAX_ROWS);
    _multiTargetState.rows = use.map((c) => ({
      id: makeTargetRowId(),
      ip: String(c.client_ip || ''),
      profile: String(c.profile || ''),
    }));
    schedulePersistMultiTargets();
    renderNetMultiTargetsList();
    let msg = `Filled ${use.length} row(s) from active conditions`;
    if (conds.length > NET_MULTI_MAX_ROWS) msg += ` (first ${NET_MULTI_MAX_ROWS} of ${conds.length})`;
    toast(msg, true);
  } catch (e) {
    toastApiError(e);
  }
}

/** @param {string} msg */
function humanizeLanHint(msg) {
  const s = String(msg || '').trim();
  if (!s) return '';
  if (/^not connected\.?$/i.test(s)) {
    return 'Router SSH opens on the first command. Click Refresh devices again (or Apply profile once), then the list should load.';
  }
  return s;
}

/** @param {any} data API JSON */
function lanSummaryLine(data) {
  const c = data && data.counts;
  if (!c || typeof c.total !== 'number' || c.total < 1) return '';
  if (data.source === 'host_fallback') {
    const hn = typeof c.host_neighbor === 'number' ? c.host_neighbor : c.total;
    return `${hn} host LAN peer(s) — not MikroTik DHCP (mtk-serve host ARP)`;
  }
  const bits = [`${c.total} device(s) on router`];
  if (c.dhcp > 0 && c.arp_only > 0) bits.push(`${c.dhcp} DHCP · ${c.arp_only} ARP-only`);
  else if (c.arp_only > 0 && c.dhcp === 0) bits.push('ARP only (no DHCP lease rows)');
  else bits.push('from DHCP');
  return bits.join(' — ');
}

function findLanDevice(ip) {
  return _lanDevices.find((d) => d && d.ip === ip) || null;
}

/** Update the hint row under Client IP (hostname, guessed type, lease status). */
export function updateNetDeviceMetaForIp(ip) {
  const meta = $('netDeviceMeta');
  if (!meta) return;
  const trimmed = (ip || '').trim();
  if (!trimmed) {
    const h = humanizeLanHint(_lastLanHint);
    const bits = [];
    if (_lastLanSummary) bits.push(_lastLanSummary);
    if (h) bits.push(h);
    meta.textContent = bits.join(' ');
    meta.classList.toggle('net-device-meta--warn', Boolean(h) && _lanDevices.length === 0);
    return;
  }
  meta.classList.remove('net-device-meta--warn');
  const d = findLanDevice(trimmed);
  if (d) {
    const parts = [];
    if (d.device_type) parts.push(d.device_type);
    if (d.hostname) parts.push(`hostname: ${d.hostname}`);
    if (d.status) parts.push(d.origin === 'host_neighbor' && d.device_type === 'lan_probe' ? `probe: ${d.status}` : `DHCP: ${d.status}`);
    if ((d.origin === 'arp' || d.origin === 'host_neighbor') && d.interface) {
      parts.push(`interface: ${d.interface}`);
    }
    if (d.mac_address) parts.push(d.mac_address);
    meta.textContent = parts.join(' · ');
    return;
  }
  if (_lanDevices.length > 0) {
    meta.textContent =
      'This IP is not in the last loaded list (other segment or appeared after refresh). You can still apply limits if the router routes this client.';
  } else {
    meta.textContent = humanizeLanHint(_lastLanHint) || '';
  }
}

function syncNetDevicePickFromInput() {
  const sel = $('netDevicePick');
  const ipField = $('netClientIp');
  if (!sel || !ipField) return;
  const ip = (ipField.value || '').trim();
  sel.value = ip && _lanDevices.some((d) => d.ip === ip) ? ip : '';
}

/** Rebuild one dashboard LAN picker (same device list + labels as Network tab). */
function rebuildMtkLanPickSelect(sel) {
  if (!(sel instanceof HTMLSelectElement) || !sel.classList.contains('mtk-lan-pick')) return;
  const inputId = sel.getAttribute('data-mtk-ip-input');
  const inp = inputId ? document.getElementById(inputId) : null;
  const cur = ((inp?.value || sel.value || '') + '').trim();
  const ph = sel.getAttribute('data-mtk-placeholder') || pickDevicePlaceholder();
  let opts = `<option value="">${escapeHtml(ph)}</option>`;
  for (const d of _lanDevices) {
    const ip = String(d.ip || '');
    const base = String(d.label || ip);
    const suf = conditionPickerSuffix(ip);
    const display = suf ? `${base} · ${suf}` : base;
    opts += `<option value="${escapeHtml(ip)}">${escapeHtml(display)}</option>`;
  }
  sel.innerHTML = opts;
  if (cur && _lanDevices.some((x) => x.ip === cur)) sel.value = cur;
  else sel.value = '';
}

/** Refresh all `select.mtk-lan-pick` elements (Proxy, DNS, Scenarios, …). */
export function rebuildAllMtkLanPickers() {
  document.querySelectorAll('select.mtk-lan-pick[data-mtk-ip-input]').forEach((el) => {
    rebuildMtkLanPickSelect(el);
  });
}

let _mtkLanPickSyncWired = false;

/**
 * Sync LAN dropdowns ↔ text fields across the dashboard (delegated, once).
 * Does not apply to `#netDevicePick` (handled in initNetworkPanel).
 */
export function initMtkLanPickSync() {
  if (_mtkLanPickSyncWired) return;
  _mtkLanPickSyncWired = true;
  document.addEventListener('change', (ev) => {
    const sel = ev.target;
    if (!(sel instanceof HTMLSelectElement) || !sel.classList.contains('mtk-lan-pick')) return;
    const inputId = sel.getAttribute('data-mtk-ip-input');
    if (!inputId) return;
    const inp = document.getElementById(inputId);
    if (inp && inp instanceof HTMLInputElement) inp.value = sel.value;
  });
  document.addEventListener('input', (ev) => {
    const inp = ev.target;
    if (!(inp instanceof HTMLInputElement) || !inp.classList.contains('mtk-lan-ip')) return;
    const pickId = inp.getAttribute('data-mtk-ip-pick');
    if (!pickId) return;
    const sel = document.getElementById(pickId);
    if (!(sel instanceof HTMLSelectElement)) return;
    const ip = inp.value.trim();
    sel.value = ip && _lanDevices.some((d) => d && d.ip === ip) ? ip : '';
  });
}

/**
 * Load DHCP leases from the router for the device dropdown.
 * @param {boolean} [showToast]
 */
export async function refreshLanDevicePicker(showToast = false) {
  const selMain = $('netDevicePick');
  const ipField = $('netClientIp');
  const prevIp = (ipField?.value || '').trim();
  try {
    const data = await api('/api/network/lan-devices');
    _lanDeviceListSource = typeof data.source === 'string' ? data.source : '';
    _lanDevices = Array.isArray(data.devices) ? data.devices : [];
    const addedFromProxyLog = await mergeProxyLogClientIpsIntoLanDevices();
    const rawHint = typeof data.hint === 'string' && data.hint.trim() ? data.hint.trim() : '';
    _lastLanHint = humanizeLanHint(rawHint) || rawHint;
    if (addedFromProxyLog > 0) {
      _lastLanHint =
        (_lastLanHint ? _lastLanHint + ' · ' : '') +
        `+${addedFromProxyLog} IP(s) from mtk-serve HTTP log`;
    }
    _lastLanSummary = lanSummaryLine(data);
    if (!_lastLanHint && _lanDevices.length === 0 && data.source !== 'error' && data.source !== 'unavailable') {
      _lastLanHint =
        data.source === 'host_fallback'
          ? 'No entries in host ARP yet — generate LAN traffic to this host, or type the client IP.'
          : 'No devices in DHCP or ARP yet. Generate LAN traffic, then Refresh devices, or enter the IP manually.';
    }
    const ph0 = pickDevicePlaceholder();
    let opts = `<option value="">${escapeHtml(ph0)}</option>`;
    for (const d of _lanDevices) {
      const ip = String(d.ip || '');
      const base = String(d.label || ip);
      const suf = conditionPickerSuffix(ip);
      const display = suf ? `${base} · ${suf}` : base;
      opts += `<option value="${escapeHtml(ip)}">${escapeHtml(display)}</option>`;
    }
    if (selMain) {
      selMain.innerHTML = opts;
      if (prevIp && _lanDevices.some((x) => x.ip === prevIp)) selMain.value = prevIp;
      else selMain.value = '';
      syncNetDevicePickFromInput();
      updateNetDeviceMetaForIp((ipField?.value || '').trim());
    }

    // Show debug info in console for troubleshooting
    if (data.debug) {
      console.log('[MTK] lan-devices debug:', JSON.stringify(data.debug, null, 2));
      if (_lanDevices.length === 0) {
        const dbg = data.debug;
        let details = [];
        if (!dbg.mtk_password_set) details.push('MTK_PASSWORD not set');
        if (!dbg.mtk_host) details.push('MTK_HOST not set');
        if (!dbg.client_exists) details.push('RouterClient is null');
        if (dbg.client_exists && !dbg.client_connected_after) details.push('SSH did not connect');
        if (dbg.ensurer_error) details.push('ensurer error: ' + dbg.ensurer_error);
        if (dbg.dhcp_exception) details.push('DHCP exception: ' + dbg.dhcp_exception);
        if (details.length > 0) {
          _lastLanHint = details.join('; ') + '. ' + (_lastLanHint || '');
        }
      }
      updateNetDeviceMetaForIp((ipField?.value || '').trim());
    }

    if (showToast) {
      const c = data.counts;
      let msg = `Loaded ${_lanDevices.length} device(s)`;
      if (c && typeof c.dhcp === 'number' && typeof c.arp_only === 'number' && c.dhcp + c.arp_only > 0) {
        msg += ` (${c.dhcp} DHCP, ${c.arp_only} ARP-only)`;
      } else if (c && typeof c.host_neighbor === 'number' && c.host_neighbor > 0) {
        msg += ` (${c.host_neighbor} from host LAN scan)`;
      }
      if (addedFromProxyLog > 0) {
        msg += ` · +${addedFromProxyLog} from HTTP log`;
      }
      toast(msg, true);
    }
    rebuildNetLogDevicePick();
    renderNetMultiTargetsList();
    rebuildAllMtkLanPickers();
  } catch (e) {
    _lanDevices = [];
    _lanDeviceListSource = '';
    _lastLanSummary = '';
    _lastLanHint = humanizeLanHint(e instanceof Error ? e.message : String(e));
    if (selMain) selMain.innerHTML = '<option value="">— Could not load device list —</option>';
    updateNetDeviceMetaForIp((ipField?.value || '').trim());
    rebuildNetLogDevicePick();
    renderNetMultiTargetsList();
    rebuildAllMtkLanPickers();
    if (showToast) toastApiError(e);
  }
}

/** Browser-only visualization constants (not from SDK). */
const REF_DOWN = 100000;
const REF_UP = 50000;
const REF_LAT = 500;

function fmtKbps(k) {
  if (k == null || k === '') return '—';
  const n = Number(k);
  if (Number.isNaN(n)) return '—';
  if (n <= 0) return 'Blocked';
  if (n >= 1000) return `${(n / 1000).toFixed(1)} Mbps`;
  return `${n} Kbps`;
}

/** Short suffix for LAN picker: shows other devices' presets at a glance. */
function conditionPickerSuffix(ip) {
  const { label, tone } = conditionSummaryForIp(ip);
  if (tone === 'idle' || tone === 'empty') return '';
  return label;
}

/** One-line description of a condition row for the workbench banner. */
function formatConditionDetailText(c) {
  const prof = c.profile ? String(c.profile) : '';
  const head = prof ? `Profile “${prof}”. ` : 'Custom limits. ';
  return (
    head +
    `↓ ${fmtKbps(c.download_kbps)} · ↑ ${fmtKbps(c.upload_kbps)} · ` +
    `RTT ${c.latency_ms ?? '—'} ms ± ${c.jitter_ms ?? 0} ms · loss ${c.packet_loss_percent ?? '—'}%`
  );
}

let _prevBannerState = null;

/** Updates "Applied on router" strip for the current Client IP (no tab switch). */
function renderAppliedBanner() {
  const ip = ($('netClientIp')?.value || '').trim();
  const banner = $('netAppliedBanner');
  const focusEl = $('netAppliedFocusIp');
  const sumEl = $('netAppliedSummary');
  if (focusEl) focusEl.textContent = ip || '—';
  if (!banner || !sumEl) return;
  
  let newState = 'idle';
  
  if (!ip) {
    banner.className = 'net-applied-banner net-applied-banner--idle';
    sumEl.textContent = 'Pick a device in the list or type an IPv4.';
    if (_prevBannerState !== null && _prevBannerState !== newState) pulseElement(banner);
    _prevBannerState = newState;
    return;
  }
  const conds = state.networkConditionsCache || [];
  const row = conds.find((x) => x && x.client_ip === ip && x.active !== false);
  if (!row) {
    newState = 'clear';
    banner.className = 'net-applied-banner net-applied-banner--clear';
    sumEl.textContent =
      'No shaping row in the dashboard cache for this IP — traffic should be unconstrained. If the device is still blocked or throttled, tap "Reset this device" to strip leftover MikroTik rules.';
    if (_prevBannerState !== null && _prevBannerState !== newState) pulseElement(banner);
    _prevBannerState = newState;
    return;
  }
  const loss = Number(row.packet_loss_percent) || 0;
  const dk = row.download_kbps;
  const crit =
    loss >= 99 ||
    (dk != null && !Number.isNaN(Number(dk)) && Number(dk) <= 0);
  newState = crit ? 'strong' : 'active';
  banner.className =
    'net-applied-banner net-applied-banner--active' + (crit ? ' net-applied-banner--strong' : '');
  sumEl.textContent = formatConditionDetailText(row);
  if (_prevBannerState !== null && _prevBannerState !== newState) pulseElement(banner);
  _prevBannerState = newState;
}

export function updateMonitorTargetDisplay() {
  const ip = ($('netClientIp')?.value || '').trim();
  const presetsIp = $('presetsTargetIp');
  if (presetsIp) presetsIp.textContent = ip || '—';
  renderAppliedBanner();
}

function uiBars(c) {
  const dk = c.download_kbps;
  const uk = c.upload_kbps;
  const lat = Number(c.latency_ms) || 0;
  const loss = Number(c.packet_loss_percent) || 0;
  return {
    downPct: dk == null ? null : Math.min(100, (Number(dk) / REF_DOWN) * 100),
    upPct: uk == null ? null : Math.min(100, (Number(uk) / REF_UP) * 100),
    latPct: Math.min(100, (lat / REF_LAT) * 100),
    lossPct: Math.min(100, loss),
  };
}

/** Cosmetic dial (UI only). */
function uiDialPercent(c) {
  const loss = Number(c.packet_loss_percent) || 0;
  const lat = Number(c.latency_ms) || 0;
  let s = 90;
  s -= Math.min(loss * 1.5, 78);
  s -= Math.min(lat / 12, 38);
  return Math.max(6, Math.min(100, Math.round(s)));
}

function fmtTimeShort(ts) {
  if (!ts) return '—';
  try {
    return new Date(ts).toLocaleTimeString(undefined, { hour12: false });
  } catch {
    return '—';
  }
}

/** Connection strip + last conditions fetch (for mobile / same-LAN debugging). */
export function renderNetworkPanelStatus() {
  const el = $('netPanelStatus');
  if (!el) return;
  const h = state.lastHealth;
  const meta = state.networkConditionsMeta;
  const serveOk = Boolean(h && h.mtk_serve_proxy);
  const routerCapable = Boolean(h && h.routeros_supported);
  const sshLive = Boolean(h && h.ssh_connected);
  let routerCls = 'err';
  let routerLabel = 'Router';
  if (routerCapable && sshLive) routerCls = 'ok';
  else if (routerCapable || (h && h.ssh_configured)) routerCls = 'warn';

  let fetchHtml =
    '<span class="net-panel-fetch">Active conditions: <strong>not loaded</strong> — open this tab or tap Refresh all.</span>';
  if (meta && meta.ok) {
    fetchHtml = `<span class="net-panel-fetch">Active conditions: <strong>${meta.rowCount}</strong> client(s) · last sync ${fmtTimeShort(meta.at)}</span>`;
  } else if (meta && meta.ok === false) {
    fetchHtml = `<span class="net-panel-fetch net-panel-fetch--err">Conditions API failed: ${escapeHtml(meta.error || 'error')}</span>`;
  }

  el.innerHTML = `<div class="net-panel-status-inner">
      <div class="net-panel-badges">
        <span class="badge ${routerCls}"><span class="dot"></span>${escapeHtml(routerLabel)} (SSH)</span>
        <span class="badge ${serveOk ? 'ok' : 'err'}"><span class="dot"></span>mtk-serve (proxy API)</span>
      </div>
      <div class="net-panel-lines">
        ${fetchHtml}
        <span class="hint">Phone: use the device’s <strong>Wi‑Fi IP</strong> on this LAN (not the router IP). It must match the address the router / mtk-serve uses for that client.</span>
      </div>
    </div>`;
}

function trafficLogEmptyDetail(scope, watchIps) {
  const ips = Array.isArray(watchIps) ? watchIps.filter(Boolean) : [];
  let ipBit = '';
  if (scope === 'selected') {
    if (!ips.length) {
      ipBit =
        '<p><strong>Chosen IPs only</strong> is on but the watch list is empty. Check one or more IPs above, add a manual address, or switch to <strong>All proxy clients</strong>.</p>';
    } else if (ips.length === 1) {
      ipBit = `<p>Filtered to client <code class="mono">${escapeHtml(ips[0])}</code> only. If you expected traffic, confirm that IP matches the device’s Wi‑Fi address and the proxy is set to this PC on port <strong>8888</strong>.</p>`;
    } else {
      ipBit = `<p>Filtered to <strong>${ips.length}</strong> clients: <code class="mono">${escapeHtml(ips.join(', '))}</code>. None have rows in the buffer yet.</p>`;
    }
  } else {
    ipBit =
      '<p>No IP filter on this view — mtk-serve still has <strong>no captured HTTP requests</strong> in the buffer (only devices using this PC as proxy <strong>:8888</strong> create rows; other LAN clients are unaffected).</p>';
  }
  return `<p class="log-empty-title"><strong>0 traffic log entries</strong> (mtk-serve responded OK)</p>
    ${ipBit}
    <ul class="log-empty-list">
      <li><strong>Recommended — system proxy (no app changes):</strong> On Android, set Wi‑Fi <strong>Manual proxy</strong> to your PC’s LAN IP and port <strong>8888</strong> (forward proxy). Install the CA from <code>http://&lt;PC-IP&gt;:8888/ca.crt</code> for HTTPS. See <strong>docs/ANDROID_LAB_CLIENTS.md</strong>.</li>
      <li><strong>Alternative — REST passthrough:</strong> Point a debug app at <code>http://&lt;PC-IP&gt;:8765/v1/proxy/to/&lt;host&gt;/&lt;path&gt;</code> on the mtk-serve API port (<strong>8765</strong>).</li>
      <li><strong>This tab</strong> uses <strong>Live stream</strong> (auto-refresh), <strong>Recording</strong> (pause polling), <strong>log scope</strong> (all proxy clients vs chosen IPs), <strong>List / Tree</strong>, <strong>Export</strong> (JSON / HAR / CSV), and per-row <strong>Copy</strong>.</li>
      <li><strong>Router network limits</strong> (Workbench) are separate from this HTTP log.</li>
    </ul>`;
}

function netLogBuildQuery() {
  const lim = Math.min(500, Math.max(5, Number($('netLogLimit')?.value) || 40));
  let q = '?limit=' + lim;
  if (_httlScope === 'selected') {
    const ips = [..._httlWatchIps].filter(Boolean).sort();
    if (ips.length === 1) q += '&client_ip=' + encodeURIComponent(ips[0]);
    else if (ips.length > 1) q += '&client_ips=' + encodeURIComponent(ips.join(','));
  }
  return q;
}

function netLogSdkSnippet(lim) {
  if (_httlScope === 'all' || _httlWatchIps.size === 0) {
    return {
      python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nentries = kit.proxy.get_log(limit=${lim})`,
      cli: `mtk proxy log --limit ${lim}`,
      rest: `GET /api/proxy/logs?limit=${lim}`,
    };
  }
  const ips = [..._httlWatchIps].sort();
  if (ips.length === 1) {
    const ip = ips[0];
    return {
      python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nentries = kit.proxy.get_log(client_ip=${pyStr(ip)}, limit=${lim})`,
      cli: `mtk proxy log --limit ${lim} --client-ip ${ip}`,
      rest: `GET /api/proxy/logs?limit=${lim}&client_ip=${encodeURIComponent(ip)}`,
    };
  }
  const listPy = ips.map((i) => pyStr(i)).join(', ');
  return {
    python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nentries = kit.proxy.get_log(client_ips=[${listPy}], limit=${lim})`,
    cli: `# multi-client: use REST\nGET /api/proxy/logs?limit=${lim}&client_ips=${encodeURIComponent(ips.join(','))}`,
    rest: `GET /api/proxy/logs?limit=${lim}&client_ips=${encodeURIComponent(ips.join(','))}`,
  };
}

function maybeShowHttlCertBanner(entries) {
  const host = $('httlSessionAlerts');
  if (!host) return;
  try {
    if (localStorage.getItem('mtk_httl_cert_banner_dismiss') === '1') return;
  } catch {
    /* ignore */
  }
  const list = entries || [];
  const bad = list.some((e) => {
    const a = String(e?.action_taken || '').toLowerCase();
    const err = String(e?.error || '');
    return a.includes('mitm') || err.includes('CERTIFICATE') || err.includes('certificate unknown');
  });
  if (!bad) {
    const old = host.querySelector('.httl-cert-alert');
    if (old) old.remove();
    return;
  }
  if (host.querySelector('.httl-cert-alert')) return;
  host.innerHTML = `<div class="httl-cert-alert" role="status">
    <div class="httl-cert-alert__body">
      <strong>TLS / MITM errors on some rows?</strong>
      The device is not trusting the proxy CA. Open <code class="mono">http://&lt;PC-LAN-IP&gt;:8888/ca.crt</code> on the phone, install as user CA, or use a debug <strong>network security config</strong> for app-only trust (Android 7+ may still pin some traffic).
    </div>
    <button type="button" class="httl-cert-alert__dismiss" id="httlCertDismiss" aria-label="Dismiss">Dismiss</button>
  </div>`;
  $('httlCertDismiss')?.addEventListener('click', () => {
    try {
      localStorage.setItem('mtk_httl_cert_banner_dismiss', '1');
    } catch {
      /* ignore */
    }
    host.querySelector('.httl-cert-alert')?.remove();
  });
}

function updateNetLogToolbarUi() {
  const main = $('btnNetLogLiveMain');
  const dot = $('httlLiveDot');
  const stateLbl = $('httlLiveStateLabel');
  const rec = $('btnNetLogRecord');
  const list = $('btnNetLogViewList');
  const tree = $('btnNetLogViewTree');
  main?.classList.toggle('httl-live-main--on', _netLogLiveOn);
  dot?.classList.toggle('httl-live-main__dot--pulse', _netLogLiveOn && _netLogRecordingOn);
  main?.setAttribute('aria-pressed', _netLogLiveOn ? 'true' : 'false');
  if (stateLbl) {
    if (!_netLogLiveOn) stateLbl.textContent = 'Off';
    else stateLbl.textContent = _netLogRecordingOn ? 'On' : 'Paused';
  }
  if (main) {
    main.title = _netLogLiveOn
      ? 'Live stream on — polling mtk-serve every 1.5s (respects Recording)'
      : 'Turn on to poll mtk-serve every 1.5s while Recording is enabled';
  }
  rec?.classList.toggle('httl-tgl--on', _netLogRecordingOn);
  list?.classList.toggle('httl-tgl--on', state.netLogViewMode === 'list');
  tree?.classList.toggle('httl-tgl--on', state.netLogViewMode === 'tree');
  if (rec) {
    rec.textContent = _netLogRecordingOn ? 'Recording' : 'Paused';
    rec.title = _netLogRecordingOn
      ? 'Capturing: Live stream will refresh this list'
      : 'Paused: Live stream will not fetch new rows';
  }
}

function stopNetLogLive() {
  if (_netLogLiveInterval) {
    clearInterval(_netLogLiveInterval);
    _netLogLiveInterval = null;
  }
  _netLogLiveOn = false;
  updateNetLogToolbarUi();
}

function startNetLogLive() {
  stopNetLogLive();
  _netLogLiveOn = true;
  _netLogLiveInterval = setInterval(() => {
    if (!_netLogRecordingOn) return;
    void loadNetTrafficLog({ silent: true });
  }, 1500);
  updateNetLogToolbarUi();
}

function toggleNetLogLive() {
  if (_netLogLiveOn) stopNetLogLive();
  else startNetLogLive();
}

function toggleNetLogRecording() {
  _netLogRecordingOn = !_netLogRecordingOn;
  updateNetLogToolbarUi();
}

function setNetLogView(mode) {
  state.setNetLogViewMode(mode === 'tree' ? 'tree' : 'list');
  updateNetLogToolbarUi();
  rerenderNetLogFromCache();
}

function rerenderNetLogFromCache() {
  const entries = state.netLogCache || [];
  const emptyDetail = entries.length ? null : state.netLogEmptyDetailHtml;
  renderLogEntryList(
    entries,
    'netTrafficLogWrap',
    $('netLogSearch'),
    'Use Load or enable Live once traffic flows through the proxy (system proxy port 8888 or passthrough URL).',
    emptyDetail && !entries.length
      ? { emptyDetailHtml: emptyDetail, viewMode: state.netLogViewMode, sessionChrome: true }
      : { viewMode: state.netLogViewMode, sessionChrome: true },
  );
}

function netLogEntriesToHar(entries) {
  return {
    log: {
      version: '1.2',
      creator: { name: 'MTK Dashboard', version: '1.0' },
      entries: (entries || []).map((e) => ({
        startedDateTime: e.timestamp,
        time: e.total_latency_ms ?? 0,
        request: {
          method: e.method || 'GET',
          url: `https://${e.upstream_host || 'unknown'}${e.path || '/'}`,
          httpVersion: 'HTTP/1.1',
          headers: Object.entries(e.request_headers || {}).map(([name, value]) => ({ name, value: String(value) })),
          postData: e.request_body ? { mimeType: 'application/json', text: String(e.request_body) } : undefined,
        },
        response: {
          status: Number(e.response_status) || 0,
          statusText: '',
          httpVersion: 'HTTP/1.1',
          headers: Object.entries(e.response_headers || {}).map(([name, value]) => ({ name, value: String(value) })),
          content: { text: e.response_body != null ? String(e.response_body) : '' },
        },
        timings: { wait: e.upstream_latency_ms ?? 0 },
      })),
    },
  };
}

function downloadText(filename, text, mime) {
  const blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function exportNetLogJson() {
  const entries = state.netLogCache || [];
  if (!entries.length) return toast('No rows in memory — tap Load first', false);
  downloadText(
    `mtk-proxy-log-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.json`,
    JSON.stringify({ exportedAt: new Date().toISOString(), entries }, null, 2),
    'application/json',
  );
  toast('Exported JSON', true);
}

function exportNetLogHar() {
  const entries = state.netLogCache || [];
  if (!entries.length) return toast('No rows in memory — tap Load first', false);
  downloadText(
    `mtk-proxy-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.har`,
    JSON.stringify(netLogEntriesToHar(entries), null, 2),
    'application/json',
  );
  toast('Exported HAR', true);
}

function exportNetLogCsv() {
  const entries = state.netLogCache || [];
  if (!entries.length) return toast('No rows in memory — tap Load first', false);
  const headers = ['timestamp', 'method', 'host', 'path', 'status', 'latency_ms', 'client_ip', 'action'];
  const rows = entries.map((e) =>
    [
      e.timestamp,
      e.method,
      e.upstream_host,
      e.path,
      e.response_status,
      e.total_latency_ms,
      e.client_ip,
      e.action_taken,
    ].map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(','),
  );
  downloadText(
    `mtk-proxy-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.csv`,
    [headers.join(','), ...rows].join('\n'),
    'text/csv',
  );
  toast('Exported CSV', true);
}

/** @param {{ silent?: boolean }} opts */
async function loadNetTrafficLog(opts = {}) {
  const silent = Boolean(opts.silent);
  if (_httlScope === 'selected' && _httlWatchIps.size === 0) {
    if (!silent) toast('Choose one or more client IPs (watch list), or switch to All proxy clients', false);
    return;
  }
  const q = netLogBuildQuery();
  try {
    const logs = await api('/api/proxy/logs' + q);
    const entries = logs.entries || [];
    state.setNetLogCache(entries);
    const watchList = [..._httlWatchIps].sort();
    const emptyDetail = entries.length ? null : trafficLogEmptyDetail(_httlScope, watchList);
    state.setNetLogEmptyDetailHtml(emptyDetail);
    renderLogEntryList(
      entries,
      'netTrafficLogWrap',
      $('netLogSearch'),
      'Use Fetch or turn on Live stream once traffic flows through the proxy (port 8888 or passthrough URL).',
      emptyDetail
        ? { emptyDetailHtml: emptyDetail, viewMode: state.netLogViewMode, sessionChrome: true }
        : { viewMode: state.netLogViewMode, sessionChrome: true },
    );
    maybeShowHttlCertBanner(entries);
    if (!silent) {
      toast(
        entries.length ? 'Traffic log loaded' : 'Traffic log: 0 entries — read the panel below',
        true,
      );
      const lim = Math.min(500, Math.max(5, Number($('netLogLimit')?.value) || 40));
      const sdk = netLogSdkSnippet(lim);
      publishSdkMirror({ title: 'Proxy: load HTTP log (Network tab)', ...sdk });
      const scopeNote =
        _httlScope === 'selected' && watchList.length
          ? ` (${watchList.length === 1 ? watchList[0] : watchList.length + ' clients'})`
          : '';
      pushActivity(
        'network',
        `Loaded ${entries.length} HTTP log lines` + scopeNote,
        entries.length > 0,
        sdk,
      );
    }
  } catch (e) {
    if (!silent) {
      toastApiError(e);
      pushActivity('network', 'Traffic log failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  }
}

function onNetTrafficLogCopyClick(ev) {
  const t = ev.target;
  if (!(t instanceof Element)) return;
  const btn = t.closest('[data-log-copy]');
  if (!btn) return;
  const id = btn.getAttribute('data-log-id');
  const kind = btn.getAttribute('data-log-copy');
  if (!id || !kind) return;
  const entries = state.netLogCache || [];
  const e = entries.find((x) => x.id === id);
  if (!e) return;
  const host = e.upstream_host || '';
  const path = (e.path || '/') + (e.query_string ? `?${e.query_string}` : '');
  const url = `https://${host}${path}`;
  let text = '';
  if (kind === 'url') {
    text = url;
  } else if (kind === 'curl') {
    const meth = e.method || 'GET';
    text = `curl -X ${meth} '${url.replace(/'/g, "'\\''")}'`;
    const hdrs = e.request_headers || {};
    for (const [k, v] of Object.entries(hdrs)) {
      if (['host', 'content-length'].includes(k.toLowerCase())) continue;
      text += ` \\\n  -H '${String(k)}: ${String(v).replace(/'/g, "'\\''")}'`;
    }
    if (e.request_body && ['POST', 'PUT', 'PATCH'].includes(meth.toUpperCase())) {
      text += ` \\\n  -d '${String(e.request_body).replace(/'/g, "'\\''")}'`;
    }
  } else if (kind === 'resp') {
    text = e.response_body != null ? String(e.response_body) : '';
    if (!text) {
      toast('No response body stored for this row', false);
      return;
    }
  }
  void navigator.clipboard.writeText(text).then(
    () => toast(kind === 'url' ? 'URL copied' : kind === 'curl' ? 'cURL copied' : 'Response copied', true),
    () => toast('Clipboard failed — copy manually', false),
  );
}

function uiAccentClass(c) {
  const loss = Number(c.packet_loss_percent) || 0;
  const lat = Number(c.latency_ms) || 0;
  const dk = c.download_kbps;
  if (loss >= 99 || (dk != null && Number(dk) <= 0)) return 'nc-accent--critical';
  if (loss >= 8 || lat >= 400) return 'nc-accent--warn';
  if (loss >= 1 || lat >= 80) return 'nc-accent--mid';
  return 'nc-accent--ok';
}

function barHtml(label, percent, sub, tone) {
  const p = percent == null ? null : Math.max(0, Math.min(100, Number(percent)));
  const fill =
    p == null
      ? '<div class="nc-bar-fill nc-bar-fill--neutral" style="width:100%"></div>'
      : `<div class="nc-bar-fill nc-bar-fill--${tone}" style="width:${p}%"></div>`;
  const cap = p == null ? 'n/a' : `${Math.round(p)}%`;
  return `<div class="nc-bar-block"><div class="nc-bar-label"><span>${label}</span><span class="nc-bar-cap">${escapeHtml(sub || cap)}</span></div><div class="nc-bar-track">${fill}</div></div>`;
}

/**
 * @param {any[] | null} conditions
 * @param {string} focusIp
 */
export function renderCockpit(conditions, focusIp) {
  const root = $('netCockpit');
  if (!root) return;
  const list = conditions || [];
  const ip = (focusIp || '').trim();
  if (!ip) {
    root.innerHTML =
      '<div class="empty">Enter a device IP above to visualize its link limits.</div>';
    return;
  }
  const row = list.find((c) => c.client_ip === ip);
  if (!row) {
    const h = state.lastHealth;
    const meta = state.networkConditionsMeta;
    const serveOk = Boolean(h && h.mtk_serve_proxy);
    const sshPath = Boolean(h && h.routeros_supported && h.ssh_connected);
    const pathHint = sshPath
      ? 'Limits are pushed over <strong>Router SSH</strong> to your MikroTik. If apply succeeded but this stays empty, tap <strong>Refresh all</strong> or check the Active conditions table below for typos in the IP.'
      : serveOk
        ? 'With only <strong>mtk-serve</strong> (no live Router SSH), network simulation is applied via the HTTP API — confirm <code>POST /v1/network/apply</code> succeeded (toast should say so).'
        : 'Neither Router SSH nor mtk-serve looks healthy in <strong>Overview</strong> — fix badges first, then retry Apply.';
    let tableHint = '';
    if (meta && meta.ok && meta.rowCount > 0) {
      tableHint = `<p class="hint">There are <strong>${meta.rowCount}</strong> conditioned client(s) in the table — none match this IP. Compare with the IP shown on the phone under Wi‑Fi → info.</p>`;
    } else if (meta && meta.ok && meta.rowCount === 0) {
      tableHint =
        '<p class="hint">The API reports <strong>zero</strong> active conditions right now. Apply a profile again and watch for errors in the red toast.</p>';
    }
    root.innerHTML = `<div class="nc-idle nc-idle--detail">
        <p><strong>No active condition</strong> for <code class="mono">${escapeHtml(ip)}</code></p>
        <p class="hint">${pathHint}</p>
        ${tableHint}
        <p class="hint">This cockpit mirrors <code>list_conditions()</code> only — it does not ping your phone.</p>
      </div>`;
    return;
  }
  const g = uiBars(row);
  const dial = uiDialPercent(row);
  const ringStyle = `background: conic-gradient(var(--accent) ${dial}%, var(--surface2) 0);`;
  const lat = row.latency_ms ?? '—';
  const jit = row.jitter_ms ?? 0;
  const loss = row.packet_loss_percent ?? '—';

  root.innerHTML = `
    <div class="nc-layout ${uiAccentClass(row)}">
      <div class="nc-score-col">
        <div class="nc-score-ring nc-score-ring--live" style="${ringStyle}" aria-hidden="true">
          <div class="nc-score-inner">
            <span class="nc-score-num">${dial}</span>
            <span class="nc-score-lbl">UI estimate</span>
          </div>
        </div>
        <div class="nc-tier-pill nc-tier-pill--plain">${row.profile ? escapeHtml(row.profile) : 'custom'}</div>
        <div class="mono nc-profile-tag">Raw limits from router / mtk-serve</div>
      </div>
      <div class="nc-gauges-col">
        ${barHtml('Download vs ref', g.downPct, fmtKbps(row.download_kbps), 'down')}
        ${barHtml('Upload vs ref', g.upPct, fmtKbps(row.upload_kbps), 'up')}
        ${barHtml('Latency vs ref', g.latPct, `${lat} ms ± ${jit} ms`, 'lat')}
        ${barHtml('Packet loss', g.lossPct, `${loss}%`, 'loss')}
      </div>
      <div class="nc-copy-col">
        <p class="nc-summary">Values above are the same numbers returned by the API — scaled here only for display.</p>
        <ul class="nc-hints">
          <li>Higher loss or latency shrinks the dial (visual only).</li>
          <li>Use SDK Connect to copy <code>MtkTestKit</code> calls for these limits.</li>
        </ul>
      </div>
    </div>`;
}

export function updateCockpitFromCache() {
  renderCockpit(state.networkConditionsCache, ($('netClientIp')?.value || '').trim());
  renderAppliedBanner();
  if ($('panel-network')?.classList.contains('active')) {
    refreshNetDutCardBadgesOnly();
  }
}

/**
 * @param {{ conditions?: any[]; error?: string }} d
 */
export function renderConditionsTable(d) {
  const w = $('netTableWrap');
  if (!w) return;
  if (d.error) {
    w.innerHTML = `<div class="empty">${escapeHtml(String(d.error))}</div>`;
    return;
  }
  const conds = d.conditions || [];
  if (!conds.length) {
    w.innerHTML = '<div class="empty">No active network conditions</div>';
    return;
  }
  w.innerHTML =
    `<table class="net-cond-table"><thead><tr>
      <th>IP</th><th>Profile</th><th>↓ / ↑</th><th>RTT</th><th>Loss</th><th>Bars</th><th></th>
    </tr></thead><tbody>` +
    conds
      .map((c) => {
        const g = uiBars(c);
        const mini =
          `<div class="nc-mini-bars" data-tooltip="Download · upload · latency · loss (scaled in browser)">
            <span style="--p:${g.downPct ?? 0}"></span>
            <span style="--p:${g.upPct ?? 0}"></span>
            <span style="--p:${g.latPct ?? 0}"></span>
            <span style="--p:${g.lossPct ?? 0}"></span>
          </div>`;
        const du = `${escapeHtml(fmtKbps(c.download_kbps))} / ${escapeHtml(fmtKbps(c.upload_kbps))}`;
        const rtt = `${c.latency_ms ?? '—'} ± ${c.jitter_ms ?? 0} ms`;
        return `<tr class="net-cond-tr ${uiAccentClass(c)}" data-net-ip="${escapeHtml(c.client_ip)}">
          <td class="mono"><button type="button" class="btn-link-ip" data-focus-ip="${escapeHtml(c.client_ip)}">${escapeHtml(c.client_ip)}</button></td>
          <td>${escapeHtml(c.profile || '—')}</td>
          <td class="net-cond-du">${du}</td>
          <td class="mono">${escapeHtml(rtt)}</td>
          <td>${c.packet_loss_percent ?? '—'}%</td>
          <td>${mini}</td>
          <td><button class="btn btn-ghost btn-sm" data-clear-net="${escapeHtml(c.client_ip)}">Clear</button></td>
        </tr>`;
      })
      .join('') +
    '</tbody></table>';
  w.querySelectorAll('[data-clear-net]').forEach((b) => {
    b.addEventListener('click', () => clearNetOne(b.getAttribute('data-clear-net')));
  });
  w.querySelectorAll('[data-focus-ip]').forEach((b) => {
    b.addEventListener('click', () => {
      const ip = b.getAttribute('data-focus-ip') || '';
      const inp = $('netClientIp');
      if (inp) inp.value = ip;
      syncNetDevicePickFromInput();
      updateNetDeviceMetaForIp(ip);
      updateCockpitFromCache();
      toast('Focused cockpit on ' + ip, true);
    });
  });
}

export async function loadNetProfiles() {
  const sel = $('netProfile');
  if (!sel) return;
  const data = await api('/api/network/profiles');
  _profilesForTargets = Array.isArray(data.profiles) ? data.profiles : [];
  const opts = (data.profiles || [])
    .map((p) => {
      const n = String(p.name ?? '');
      return `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`;
    })
    .join('');
  sel.innerHTML = '<option value="">— Custom below —</option>' + opts;
  renderProfileStrip(data.profiles || []);
  renderNetMultiTargetsList();
}

function renderProfileStrip(profiles) {
  const el = $('netProfileStrip');
  if (!el) return;
  if (!profiles.length) {
    el.innerHTML = '<div class="empty">No presets</div>';
    return;
  }
  el.innerHTML = profiles
    .map((p) => {
      const accent = uiAccentClass({
        download_kbps: p.download_kbps,
        upload_kbps: p.upload_kbps,
        latency_ms: p.latency_ms,
        jitter_ms: p.jitter_ms,
        packet_loss_percent: p.packet_loss_percent,
      });
      return `<button type="button" class="net-preset-card ${accent}" data-preset="${escapeHtml(p.name)}" data-tooltip="Preset ${escapeHtml(p.name)} — select then Apply profile">
        <div class="net-preset-name">${escapeHtml(p.name)}</div>
        <div class="net-preset-line mono">${escapeHtml(fmtKbps(p.download_kbps))} ↓</div>
        <div class="net-preset-line mono">${escapeHtml(fmtKbps(p.upload_kbps))} ↑</div>
        <div class="net-preset-line">${p.latency_ms ?? '—'} ms ± ${p.jitter_ms ?? 0} ms · ${p.packet_loss_percent ?? 0}% loss</div>
      </button>`;
    })
    .join('');
  el.querySelectorAll('[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const name = btn.getAttribute('data-preset');
      const ip = ($('netClientIp')?.value || '').trim();
      if (!ip) {
        toast('Enter Client IP first, then pick a preset', false);
        return;
      }
      const s = $('netProfile');
      if (s && name) s.value = name;
      toast(`Preset “${name}” selected — click Apply profile`, true);
    });
  });
}

export async function refreshNetworkTable() {
  const w = $('netTableWrap');
  try {
    const d = await api('/api/network/conditions');
    const conds = d.conditions || [];
    state.setNetworkConditionsCache(conds);
    state.setNetworkConditionsMeta({
      ok: true,
      rowCount: conds.filter((c) => c && c.active !== false).length,
      at: Date.now(),
    });
    renderConditionsTable({ conditions: conds });
    updateCockpitFromCache();
    renderNetworkPanelStatus();
  } catch (e) {
    state.setNetworkConditionsCache(null);
    state.setNetworkConditionsMeta({
      ok: false,
      error: e instanceof Error ? e.message : String(e),
      at: Date.now(),
    });
    if (w) renderApiProblem(w, e);
    updateCockpitFromCache();
    renderNetworkPanelStatus();
  }
}

async function clearNetOne(ip) {
  try {
    await api('/api/network/clear?client_ip=' + encodeURIComponent(ip), { method: 'DELETE' });
    toast('Reset router rules for ' + ip, true);
    const sdk = {
      python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.network.clear(${pyStr(ip)})`,
      cli: `mtk network clear ${ip}`,
      rest: `DELETE /api/network/clear?client_ip=${encodeURIComponent(ip)}`,
    };
    publishSdkMirror({ title: 'Network: clear client', ...sdk });
    pushActivity('network', 'Cleared network limits for ' + ip, true, sdk);
    await refreshNetworkTable();
    await loadOverview();
  } catch (e) {
    toastApiError(e);
    pushActivity('network', 'Clear failed: ' + (e instanceof Error ? e.message : String(e)), false);
  }
}

/** WebSocket tick: refresh network UI when panel is active. */
export function wireNetworkRealtime() {
  window.__mtkOnNetworkTick = (tick) => {
    if (!tick?.network_conditions) return;
    const raw = tick.network_conditions;
    state.setNetworkConditionsCache(raw);
    const n = (raw || []).filter((c) => c && c.active !== false).length;
    state.setNetworkConditionsMeta({ ok: true, rowCount: n, at: Date.now() });
    const panel = $('panel-network');
    if (panel?.classList.contains('active')) {
      renderConditionsTable({ conditions: raw });
      updateCockpitFromCache();
      renderNetworkPanelStatus();
    }
  };
}

export function initNetworkPanel() {
  window.__mtkRenderNetworkPanelStatus = renderNetworkPanelStatus;
  wireNetworkRealtime();
  renderNetworkPanelStatus();
  initNetMultiTargetsBoard();
  initMtkLanPickSync();

  // Network sub-tab switching
  document.querySelectorAll('.net-tab[data-net-tab]').forEach((tab) => {
    tab.addEventListener('click', () => {
      switchNetTab(tab.getAttribute('data-net-tab'));
    });
  });

  $('btnNetRefreshConditions')?.addEventListener('click', () => {
    void refreshNetworkTable();
  });

  // Clear all in status tab
  $('btnNetClearAllStatus')?.addEventListener('click', async () => {
    try {
      await api('/api/network/clear', { method: 'DELETE' });
      toast('All conditions cleared', true);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
    }
  });

  $('btnNetTargetAdd')?.addEventListener('click', () => {
    if (_multiTargetState.rows.length >= NET_MULTI_MAX_ROWS) {
      toast(`At most ${NET_MULTI_MAX_ROWS} device slots`, false);
      return;
    }
    // Prevent adding if there's an empty slot already
    const emptyRow = _multiTargetState.rows.find((r) => !(r.ip || '').trim());
    if (emptyRow) {
      toast('Fill the empty slot first before adding another', false);
      // Highlight the empty card briefly
      const list = $('netMultiTargetsList');
      const emptyCard = list?.querySelector(`.net-dut-card[data-target-id="${safeTargetIdForSelector(emptyRow.id)}"]`);
      if (emptyCard) {
        emptyCard.classList.add('error-shake');
        setTimeout(() => emptyCard.classList.remove('error-shake'), 500);
      }
      return;
    }
    _multiTargetState.rows.push({ id: makeTargetRowId(), ip: '', profile: '' });
    schedulePersistMultiTargets();
    renderNetMultiTargetsList();
    toast('New device slot added', true);
  });
  $('btnNetTargetBulkProfile')?.addEventListener('click', () => {
    void bulkApplyMainPresetToAllRows();
  });
  $('btnNetTargetPullActive')?.addEventListener('click', () => {
    void pullActiveConditionsIntoTargets();
  });

  $('netLogDevicePick')?.addEventListener('change', () => {
    const v = ($('netLogDevicePick')?.value || '').trim();
    if (v) {
      _httlWatchIps.add(v);
      setHttlScope('selected');
      renderHttlClientChecks();
      saveHttlWatchState();
    }
    syncNetLogHiddenFieldsFromWatch();
  });

  $('netDevicePick')?.addEventListener('change', () => {
    const sel = $('netDevicePick');
    const inp = $('netClientIp');
    const v = (sel?.value || '').trim();
    if (inp && v) inp.value = v;
    updateNetDeviceMetaForIp((inp?.value || '').trim());
    updateNetDutFocusRings();
    updateMonitorTargetDisplay();
    clearTimeout(_cockpitDebounce);
    _cockpitDebounce = setTimeout(() => updateCockpitFromCache(), 120);
  });

  $('netClientIp')?.addEventListener('input', () => {
    syncNetDevicePickFromInput();
    updateNetDeviceMetaForIp(($('netClientIp')?.value || '').trim());
    updateNetDutFocusRings();
    updateMonitorTargetDisplay();
    clearTimeout(_cockpitDebounce);
    _cockpitDebounce = setTimeout(() => updateCockpitFromCache(), 120);
  });

  $('btnNetRefreshDevices')?.addEventListener('click', () => {
    refreshLanDevicePicker(true).catch(() => {});
  });

  $('btnNetSyncLogIp')?.addEventListener('click', () => {
    const ip = ($('netClientIp')?.value || '').trim();
    if (!ip) return toast('Enter Client IP first', false);
    _httlWatchIps.add(ip);
    setHttlScope('selected');
    renderHttlClientChecks();
    saveHttlWatchState();
    rebuildNetLogDevicePick();
    toast('Added ' + ip + ' to session watch list', true);
  });

  // Live monitor state
  let _liveMonitorInterval = null;
  let _lastLiveStats = null;

  function formatBytes(bytes) {
    if (bytes == null || isNaN(bytes)) return '—';
    const b = Number(bytes);
    if (b < 1024) return b + ' B';
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
    if (b < 1024 * 1024 * 1024) return (b / 1024 / 1024).toFixed(2) + ' MB';
    return (b / 1024 / 1024 / 1024).toFixed(2) + ' GB';
  }

  function formatRate(bps) {
    if (bps == null || isNaN(bps)) return '—';
    const b = Number(bps);
    if (b < 1000) return b + ' bps';
    if (b < 1000000) return (b / 1000).toFixed(1) + ' Kbps';
    return (b / 1000000).toFixed(2) + ' Mbps';
  }

  function parseRouterStats(data) {
    const result = {
      downRate: null,
      upRate: null,
      downLimit: null,
      upLimit: null,
      queueBytes: null,
      queuePackets: null,
      droppedBytes: 0,
      droppedPackets: 0,
      raw: '',
      queueExists: false,
      firewallActive: false,
    };

    if (!data || !data.available) return result;

    // Use pre-parsed data from backend
    if (data.parsed) {
      result.downRate = data.parsed.download_rate_bps;
      result.upRate = data.parsed.upload_rate_bps;
      result.downLimit = data.parsed.download_limit_bps;
      result.upLimit = data.parsed.upload_limit_bps;
      result.queueBytes = data.parsed.queue_bytes;
      result.queuePackets = data.parsed.queue_packets;
      result.droppedBytes = data.parsed.dropped_bytes || 0;
      result.droppedPackets = data.parsed.dropped_packets || 0;
    }

    // Build raw output for display
    if (data.queue) {
      result.queueExists = data.queue.exists;
      result.raw += '=== QUEUE (bandwidth shaping) ===\n';
      if (data.queue.exists) {
        result.raw += data.queue.raw + '\n';
      } else {
        result.raw += 'No queue rule found. Apply a bandwidth profile to create one.\n';
      }
    }

    result.raw += '\n=== FIREWALL RULES (packet loss) ===\n';
    if (data.firewall_rules && data.firewall_rules.length > 0) {
      for (const rule of data.firewall_rules) {
        result.raw += `[${rule.direction}] `;
        if (rule.exists) {
          result.firewallActive = true;
          result.raw += 'ACTIVE\n' + (rule.raw || '') + '\n';
        } else {
          result.raw += 'not found\n';
        }
      }
    } else {
      result.raw += 'No packet loss rules active.\n';
    }

    return result;
  }

  function updateLiveStatsUI(stats, condition) {
    const downRate = $('liveDownRate');
    const upRate = $('liveUpRate');
    const downBar = $('liveDownBar');
    const upBar = $('liveUpBar');
    const downLimit = $('liveDownLimit');
    const upLimit = $('liveUpLimit');
    const queueBytes = $('liveQueueBytes');
    const queuePackets = $('liveQueuePackets');
    const droppedBytes = $('liveDroppedBytes');
    const droppedPackets = $('liveDroppedPackets');
    const rawEl = $('liveStatsRaw');

    // Animate value changes
    const newDownRate = formatRate(stats.downRate);
    const newUpRate = formatRate(stats.upRate);
    
    if (downRate) {
      animateValueChange('liveDownRate', newDownRate);
      downRate.textContent = newDownRate;
    }
    if (upRate) {
      animateValueChange('liveUpRate', newUpRate);
      upRate.textContent = newUpRate;
    }

    // Calculate bar percentages based on limits from condition or parsed
    const dlim = condition?.download_kbps ? condition.download_kbps * 1000 : stats.downLimit;
    const ulim = condition?.upload_kbps ? condition.upload_kbps * 1000 : stats.upLimit;
    
    if (downBar && dlim && stats.downRate != null) {
      const pct = Math.min(100, (stats.downRate / dlim) * 100);
      downBar.style.width = pct + '%';
    }
    if (upBar && ulim && stats.upRate != null) {
      const pct = Math.min(100, (stats.upRate / ulim) * 100);
      upBar.style.width = pct + '%';
    }

    if (downLimit) downLimit.textContent = 'Limit: ' + (dlim ? formatRate(dlim) : '—');
    if (upLimit) upLimit.textContent = 'Limit: ' + (ulim ? formatRate(ulim) : '—');

    if (queueBytes) {
      const newQueueBytes = formatBytes(stats.queueBytes);
      animateValueChange('liveQueueBytes', newQueueBytes);
      queueBytes.textContent = newQueueBytes;
    }
    if (queuePackets) queuePackets.textContent = 'Packets: ' + (stats.queuePackets ?? '—');

    if (droppedBytes) {
      const newDroppedBytes = formatBytes(stats.droppedBytes);
      animateValueChange('liveDroppedBytes', newDroppedBytes);
      droppedBytes.textContent = newDroppedBytes;
    }
    if (droppedPackets) droppedPackets.textContent = 'Packets: ' + stats.droppedPackets;

    if (rawEl) rawEl.textContent = stats.raw || 'No raw data';

    // Update rule status indicators
    const rulesStatus = $('liveRulesStatus');
    const queueDot = $('liveQueueDot');
    const queueLabel = $('liveQueueLabel');
    const fwDot = $('liveFirewallDot');
    const fwLabel = $('liveFirewallLabel');

    if (rulesStatus) rulesStatus.style.display = 'flex';
    if (queueDot) {
      queueDot.classList.toggle('active', stats.queueExists);
      queueDot.classList.toggle('inactive', !stats.queueExists);
    }
    if (queueLabel) queueLabel.textContent = 'Queue: ' + (stats.queueExists ? 'Active' : 'None');
    if (fwDot) {
      fwDot.classList.toggle('active', stats.firewallActive);
      fwDot.classList.toggle('inactive', !stats.firewallActive);
    }
    if (fwLabel) fwLabel.textContent = 'Firewall: ' + (stats.firewallActive ? 'Active' : 'None');

    updateValidationPanel(condition, stats);
  }

  let _prevDroppedPackets = null;
  let _prevQueueBytes = null;

  function updateValidationPanel(condition, stats) {
    const tbody = $('validationTableBody');
    const overall = $('validationOverallStatus');
    const hint = $('validationHint');
    if (!tbody) return;

    const validations = [];
    let overallStatus = 'unknown';

    if (!condition || condition.active === false) {
      tbody.innerHTML = '<tr><td colspan="4" class="hint" style="text-align:center;padding:16px;">No active condition for this IP. Apply a profile first.</td></tr>';
      if (overall) {
        overall.innerHTML = '<span class="net-validation-dot net-validation-dot--idle"></span><span class="net-validation-label">No condition applied</span>';
      }
      if (hint) hint.textContent = 'Apply a network profile to this IP, then start live monitor.';
      _prevDroppedPackets = null;
      _prevQueueBytes = null;
      return;
    }

    const fmtKbps = (k) => {
      if (k == null) return '—';
      const n = Number(k);
      if (n <= 0) return 'Blocked';
      if (n >= 1000) return (n / 1000).toFixed(1) + ' Mbps';
      return n + ' Kbps';
    };

    const hasBwLimit = (condition.download_kbps && condition.download_kbps > 0) || (condition.upload_kbps && condition.upload_kbps > 0);
    const hasPacketLoss = condition.packet_loss_percent && condition.packet_loss_percent > 0;
    const isOffline = condition.packet_loss_percent >= 100 || (condition.download_kbps === 0 && condition.upload_kbps === 0);

    if (hasBwLimit && !isOffline) {
      const queueOk = stats.queueExists === true;
      const trafficFlowing = stats.queueBytes != null && stats.queueBytes > 0;
      const trafficIncreased = _prevQueueBytes != null && stats.queueBytes > _prevQueueBytes;
      
      let status = 'check';
      let statusIcon = '⚠';
      let statusText = 'Queue not found on router';
      
      if (queueOk && trafficIncreased) {
        status = 'ok';
        statusIcon = '✓';
        statusText = 'Active & traffic flowing';
      } else if (queueOk && trafficFlowing) {
        status = 'ok';
        statusIcon = '✓';
        statusText = 'Queue active, bytes processed';
      } else if (queueOk) {
        status = 'warn';
        statusIcon = '⏳';
        statusText = 'Queue exists, waiting for traffic';
      } else {
        status = 'error';
        statusIcon = '✗';
      }

      validations.push({
        setting: 'Bandwidth Limit',
        configured: `↓ ${fmtKbps(condition.download_kbps)} / ↑ ${fmtKbps(condition.upload_kbps)}`,
        router: queueOk ? `Queue active (${formatBytes(stats.queueBytes || 0)} transferred)` : 'No queue rule found',
        status,
        statusIcon,
        statusText,
      });
      
      _prevQueueBytes = stats.queueBytes;
    }

    if (hasPacketLoss) {
      const fwOk = stats.firewallActive === true;
      const dropsIncreased = _prevDroppedPackets != null && stats.droppedPackets > _prevDroppedPackets;
      const hasDrops = stats.droppedPackets > 0;

      let status = 'check';
      let statusIcon = '⚠';
      let statusText = 'Firewall rules not found';

      if (isOffline) {
        if (fwOk && hasDrops) {
          status = 'ok';
          statusIcon = '✓';
          statusText = `Blocking traffic (${stats.droppedPackets} packets dropped)`;
        } else if (fwOk && dropsIncreased) {
          status = 'ok';
          statusIcon = '✓';
          statusText = 'Blocking traffic, drops increasing';
        } else if (fwOk) {
          status = 'warn';
          statusIcon = '⏳';
          statusText = 'Rules active, waiting for traffic to block';
        } else {
          status = 'error';
          statusIcon = '✗';
          statusText = 'Drop rules NOT found — check firewall';
        }
        validations.push({
          setting: 'Offline Mode',
          configured: '100% packet loss (block all)',
          router: fwOk ? `Firewall drop rules active` : 'No firewall rules found',
          status,
          statusIcon,
          statusText,
        });
      } else {
        if (fwOk && dropsIncreased) {
          status = 'ok';
          statusIcon = '✓';
          statusText = `Dropping packets (${stats.droppedPackets} total)`;
        } else if (fwOk && hasDrops) {
          status = 'ok';
          statusIcon = '✓';
          statusText = `Rules active, ${stats.droppedPackets} dropped`;
        } else if (fwOk) {
          status = 'warn';
          statusIcon = '⏳';
          statusText = 'Rules exist, no drops yet';
        } else {
          status = 'error';
          statusIcon = '✗';
        }
        validations.push({
          setting: 'Packet Loss',
          configured: `${condition.packet_loss_percent}% loss`,
          router: fwOk ? `Firewall nth rules (${stats.droppedPackets} dropped)` : 'No firewall rules',
          status,
          statusIcon,
          statusText,
        });
      }
      
      _prevDroppedPackets = stats.droppedPackets;
    }

    if (condition.latency_ms && condition.latency_ms > 0) {
      validations.push({
        setting: 'Latency',
        configured: `${condition.latency_ms} ms${condition.jitter_ms ? ` ± ${condition.jitter_ms} ms` : ''}`,
        router: 'Applied via queue (not separately measurable)',
        status: stats.queueExists ? 'ok' : 'warn',
        statusIcon: stats.queueExists ? '✓' : '⚠',
        statusText: stats.queueExists ? 'Queue handles latency' : 'Queue not found',
      });
    }

    if (validations.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="hint" style="text-align:center;padding:16px;">Profile applied but no specific limits to validate.</td></tr>';
      if (overall) {
        overall.innerHTML = '<span class="net-validation-dot net-validation-dot--idle"></span><span class="net-validation-label">Nothing to validate</span>';
      }
      return;
    }

    let html = '';
    let allOk = true;
    let anyError = false;
    
    for (const v of validations) {
      if (v.status !== 'ok') allOk = false;
      if (v.status === 'error') anyError = true;
      html += `<tr class="net-validation-row net-validation-row--${v.status}">
        <td class="net-validation-setting">${escapeHtml(v.setting)}</td>
        <td class="mono">${escapeHtml(v.configured)}</td>
        <td class="mono">${escapeHtml(v.router)}</td>
        <td class="net-validation-status net-validation-status--${v.status}">
          <span class="net-validation-icon">${v.statusIcon}</span>
          <span>${escapeHtml(v.statusText)}</span>
        </td>
      </tr>`;
    }
    tbody.innerHTML = html;

    if (overall) {
      if (allOk) {
        overall.innerHTML = '<span class="net-validation-dot net-validation-dot--ok"></span><span class="net-validation-label">All settings verified on router</span>';
        overallStatus = 'ok';
      } else if (anyError) {
        overall.innerHTML = '<span class="net-validation-dot net-validation-dot--error"></span><span class="net-validation-label">Some rules missing — check configuration</span>';
        overallStatus = 'error';
      } else {
        overall.innerHTML = '<span class="net-validation-dot net-validation-dot--warn"></span><span class="net-validation-label">Rules exist, generate traffic to confirm</span>';
        overallStatus = 'warn';
      }
    }

    if (hint) {
      if (overallStatus === 'ok') {
        hint.textContent = 'Network conditions are being enforced. The device should experience the configured limits.';
      } else if (overallStatus === 'error') {
        hint.textContent = 'Some rules are missing. Try re-applying the profile or check the Debug section below.';
      } else {
        hint.textContent = 'Generate traffic on the device (browse, stream, download) to see counters increase and confirm limits.';
      }
    }
  }

  async function fetchLiveStats() {
    const ip = ($('netClientIp')?.value || '').trim();
    if (!ip) {
      stopLiveMonitor();
      toast('Enter Client IP to monitor', false);
      return;
    }
    try {
      const data = await api('/api/network/live-stats?client_ip=' + encodeURIComponent(ip));
      _lastLiveStats = data;
      const stats = parseRouterStats(data);
      // Get current condition for this IP
      const conds = state.networkConditionsCache || [];
      const cond = conds.find(c => c.client_ip === ip);
      updateLiveStatsUI(stats, cond);
      
      const statusEl = $('liveMonitorStatus');
      if (statusEl) {
        statusEl.textContent = 'Updated ' + new Date().toLocaleTimeString();
        statusEl.classList.add('active');
      }
    } catch (e) {
      const statusEl = $('liveMonitorStatus');
      if (statusEl) {
        statusEl.textContent = 'Error: ' + (e instanceof Error ? e.message : String(e));
        statusEl.classList.remove('active');
      }
    }
  }

  function startLiveMonitor() {
    if (_liveMonitorInterval) return;
    const btnStart = $('btnStartLiveMonitor');
    const btnStop = $('btnStopLiveMonitor');
    const intervalSelect = $('liveMonitorInterval');
    const interval = parseInt(intervalSelect?.value || '2000', 10);
    
    if (btnStart) btnStart.style.display = 'none';
    if (btnStop) btnStop.style.display = 'inline-flex';
    
    _prevDroppedPackets = null;
    _prevQueueBytes = null;
    
    fetchLiveStats(); // Immediate first fetch
    _liveMonitorInterval = setInterval(fetchLiveStats, interval);
    toast(`Live monitor started (every ${interval/1000}s)`, true);
  }

  function stopLiveMonitor() {
    if (_liveMonitorInterval) {
      clearInterval(_liveMonitorInterval);
      _liveMonitorInterval = null;
    }
    const btnStart = $('btnStartLiveMonitor');
    const btnStop = $('btnStopLiveMonitor');
    if (btnStart) btnStart.style.display = 'inline-flex';
    if (btnStop) btnStop.style.display = 'none';
    const statusEl = $('liveMonitorStatus');
    if (statusEl) {
      statusEl.textContent = 'Stopped';
      statusEl.classList.remove('active');
    }
    _prevDroppedPackets = null;
    _prevQueueBytes = null;
  }

  $('btnStartLiveMonitor')?.addEventListener('click', () => {
    const ip = ($('netClientIp')?.value || '').trim();
    if (!ip) return toast('Enter Client IP first', false);
    startLiveMonitor();
  });

  $('btnStopLiveMonitor')?.addEventListener('click', stopLiveMonitor);

  // Single refresh button
  $('btnRefreshOnce')?.addEventListener('click', async () => {
    const ip = ($('netClientIp')?.value || '').trim();
    if (!ip) return toast('Enter Client IP first', false);
    await fetchLiveStats();
  });

  // Legacy single-fetch button (keep for manual refresh)
  $('btnNetLiveStats')?.addEventListener('click', async () => {
    const ip = ($('netClientIp')?.value || '').trim();
    if (!ip) return toast('Enter Client IP first', false);
    await fetchLiveStats();
    toast('Stats refreshed', true);
  });

  // Restart polling with new interval when changed
  $('liveMonitorInterval')?.addEventListener('change', () => {
    if (_liveMonitorInterval) {
      stopLiveMonitor();
      startLiveMonitor();
    }
  });

  // Debug: show all firewall rules
  $('btnDebugFirewall')?.addEventListener('click', async () => {
    const output = $('debugFirewallOutput');
    if (!output) return;
    output.style.display = 'block';
    output.textContent = 'Loading firewall rules from router...';
    try {
      const data = await api('/api/network/debug-firewall');
      let text = '=== MTK Rules (should be at top) ===\n';
      text += data.mtk_rules || 'None found\n';
      text += '\n=== Forward Chain (first 10 matter most) ===\n';
      text += data.forward_chain || 'Error loading';
      if (data.hint) text += '\n\n' + data.hint;
      output.textContent = text;
    } catch (e) {
      output.textContent = 'Error: ' + (e instanceof Error ? e.message : String(e));
    }
  });

  $('btnNetClearOne')?.addEventListener('click', async () => {
    const ip = $('netClientIp').value.trim();
    if (!ip) return toast('Enter client IP', false);
    await clearNetOne(ip);
  });
  $('btnNetClearAll')?.addEventListener('click', async () => {
    try {
      await api('/api/network/clear', { method: 'DELETE' });
      toast('All network conditions cleared', true);
      const sdk = {
        python:
          'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nfor cond in kit.network.list_conditions():\n    kit.network.clear(cond.client_ip)',
        cli: '# Clear each client: mtk network clear <ip>',
        rest: 'DELETE /api/network/clear (no client_ip)',
      };
      publishSdkMirror({ title: 'Network: clear all', ...sdk });
      pushActivity('network', 'Cleared all network limits', true, sdk);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('network', 'Clear all failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnNetApplyProfile')?.addEventListener('click', async () => {
    const client_ip = $('netClientIp').value.trim();
    const profile = $('netProfile').value;
    if (!client_ip || !profile) return toast('Client IP and profile required', false);
    try {
      const data = await api('/api/network/apply', {
        method: 'POST',
        body: JSON.stringify({ client_ip, profile }),
      });
      toastNetSuccess(data, 'Profile applied');
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.network.apply_profile(${pyStr(client_ip)}, ${pyStr(profile)})`,
        cli: `mtk network profile ${client_ip} ${profile}`,
        rest: `POST /api/network/apply\n${JSON.stringify({ client_ip, profile }, null, 2)}`,
      };
      publishSdkMirror({ title: `Network: profile “${profile}”`, ...sdk });
      pushActivity('network', `Applied profile “${profile}” → ${client_ip}`, true, sdk);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('network', 'Apply profile failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnNetApplyCustom')?.addEventListener('click', async () => {
    const client_ip = $('netClientIp').value.trim();
    if (!client_ip) return toast('Client IP required', false);
    const body = { client_ip };
    ['netDown:download_kbps', 'netUp:upload_kbps', 'netLat:latency_ms', 'netJitter:jitter_ms', 'netLoss:packet_loss_percent'].forEach((m) => {
      const [id, key] = m.split(':');
      const v = $(id).value;
      if (v) body[key] = Number(v);
    });
    try {
      const data = await api('/api/network/apply', { method: 'POST', body: JSON.stringify(body) });
      toastNetSuccess(data, 'Custom condition applied');
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\n# same kwargs as JSON below\n# e.g. kit.network.throttle(${pyStr(client_ip)}, download_kbps=..., upload_kbps=...)\n# kit.network.latency(${pyStr(client_ip)}, delay_ms=..., jitter_ms=...)\n# kit.network.packet_loss(${pyStr(client_ip)}, percent=...)`,
        cli: '# Combine mtk network throttle / latency CLI flags as needed',
        rest: `POST /api/network/apply\n${JSON.stringify(body, null, 2)}`,
      };
      publishSdkMirror({ title: 'Network: custom apply', ...sdk });
      pushActivity('network', `Custom throttle/latency/loss → ${client_ip}`, true, sdk);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('network', 'Custom apply failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnNetDisconnect')?.addEventListener('click', async () => {
    const client_ip = $('netClientIp').value.trim();
    const dur = Number($('netDisconnect').value) || 10;
    if (!client_ip) return toast('Client IP required', false);
    try {
      const data = await api('/api/network/disconnect', {
        method: 'POST',
        body: JSON.stringify({ client_ip, duration_seconds: dur }),
      });
      toastNetSuccess(data, `Client disconnected for ${dur}s`);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.network.disconnect(${pyStr(client_ip)}, duration_seconds=${dur})`,
        cli: `# offline profile + timed restore — see SDK`,
        rest: `POST /api/network/disconnect\n${JSON.stringify({ client_ip, duration_seconds: dur }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Network: timed disconnect', ...sdk });
      pushActivity('network', `Disconnect ${dur}s → ${client_ip}`, true, sdk);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('network', 'Disconnect failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnNetLoadLogs')?.addEventListener('click', () => void loadNetTrafficLog({ silent: false }));
  $('btnNetLogLiveMain')?.addEventListener('click', () => toggleNetLogLive());
  $('httlScopeAll')?.addEventListener('click', () => {
    setHttlScope('all');
  });
  $('httlScopeSelected')?.addEventListener('click', () => {
    setHttlScope('selected');
    renderHttlClientChecks();
  });
  $('httlWatchClear')?.addEventListener('click', () => {
    _httlWatchIps.clear();
    saveHttlWatchState();
    renderHttlClientChecks();
    syncNetLogHiddenFieldsFromWatch();
    toast('Watch list cleared', true);
  });
  $('httlAddIpBtn')?.addEventListener('click', () => {
    const raw = ($('httlAddIpInput')?.value || '').trim();
    if (!IPV4_RE.test(raw)) return toast('Enter a valid IPv4 address', false);
    _httlWatchIps.add(raw);
    const addInp = $('httlAddIpInput');
    if (addInp) addInp.value = '';
    saveHttlWatchState();
    renderHttlClientChecks();
    syncNetLogHiddenFieldsFromWatch();
    toast('Added ' + raw + ' to watch list', true);
  });
  $('httlAddIpInput')?.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      $('httlAddIpBtn')?.click();
    }
  });
  $('btnNetLogRecord')?.addEventListener('click', () => toggleNetLogRecording());
  $('btnNetLogViewList')?.addEventListener('click', () => setNetLogView('list'));
  $('btnNetLogViewTree')?.addEventListener('click', () => setNetLogView('tree'));
  $('btnNetLogExportJson')?.addEventListener('click', () => exportNetLogJson());
  $('btnNetLogExportHar')?.addEventListener('click', () => exportNetLogHar());
  $('btnNetLogExportCsv')?.addEventListener('click', () => exportNetLogCsv());
  $('btnNetLogClearServer')?.addEventListener('click', async () => {
    if (!confirm('Clear the proxy log on mtk-serve? This cannot be undone.')) return;
    try {
      await api('/api/proxy/logs', { method: 'DELETE' });
      state.setNetLogCache([]);
      state.setNetLogEmptyDetailHtml(trafficLogEmptyDetail(_httlScope, [..._httlWatchIps].sort()));
      rerenderNetLogFromCache();
      toast('Server log cleared', true);
      publishSdkMirror({
        title: 'Proxy: clear HTTP log',
        python: 'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.clear_log()',
        cli: 'mtk proxy log-clear',
        rest: 'DELETE /api/proxy/logs',
      });
    } catch (e) {
      toastApiError(e);
    }
  });
  $('netTrafficLogWrap')?.addEventListener('click', onNetTrafficLogCopyClick);

  loadHttlWatchState();
  setHttlScope(_httlScope);
  renderHttlClientChecks();
  updateNetLogToolbarUi();

  refreshLanDevicePicker(false).catch(() => {});
}
