/**
 * SDK Connect — SQA lab: map UI → MtkTestKit, CLI, REST, pytest shape.
 */
import { $ } from '../core/dom.js';
import * as state from '../core/state.js';
import { toast } from '../core/api.js';

const PYTEST_SKELETON = `import pytest

@pytest.fixture
def mtk():
    from mtk_router_sdk.testing import MtkTestKit
    return MtkTestKit.from_env()

def test_example(mtk):
    client_ip = "192.168.1.100"
    # mtk.network.apply_profile(client_ip, "4g")
    # mtk.proxy.set_response(client_ip, "/api/health", {"ok": True})
    # logs = mtk.proxy.get_log(client_ip=client_ip, limit=20)
    assert True
`;

const TAB_PLAYBOOK = {
  overview: {
    title: 'Overview & live feed',
    body: `The overview polls mtk-serve for proxy log lines and counts active network/DNS clients. The same data is available in code via the kit and REST.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
net = kit.network.list_conditions()
dns = kit.dns.list_redirects()
rules = kit.proxy.list_rules()
entries = kit.proxy.get_log(limit=25)`,
    cli: `# mtk proxy log --limit 25
# mtk network list
# mtk dns list`,
    rest: `GET /api/overview  (dashboard)
GET /v1/proxy/log?limit=25  (mtk-serve)`,
  },
  network: {
    title: 'Network limits',
    body: `Shapes bandwidth, latency, jitter, and loss per client IP on the router (MikroTik). Presets match NETWORK_PROFILES in the SDK.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
kit.network.apply_profile("192.168.1.100", "4g")
kit.network.throttle("192.168.1.100", download_kbps=2000, upload_kbps=500)
kit.network.latency("192.168.1.100", delay_ms=200, jitter_ms=40)
kit.network.packet_loss("192.168.1.100", percent=3)
conds = kit.network.list_conditions()
kit.network.clear("192.168.1.100")`,
    cli: `mtk network profile 192.168.1.100 4g
mtk network list
mtk network clear 192.168.1.100`,
    rest: `POST /api/network/apply
GET /api/network/conditions
DELETE /api/network/clear?client_ip=…`,
  },
  dns: {
    title: 'DNS overrides',
    body: `Redirects domains to mtk-serve or a fixed IP for a client (or all clients). Requires RouterOS path configured by the SDK.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
kit.dns.redirect("api.example.com", client_ip="192.168.1.100", ttl=60)
kit.dns.redirect_to_ip("old.api.com", "10.0.0.5", client_ip=None, ttl=60)
rows = kit.dns.list_redirects()
kit.dns.remove("api.example.com", client_ip=None)
kit.dns.flush_cache()`,
    cli: `mtk dns redirect api.example.com --client 192.168.1.100
mtk dns list
mtk dns flush`,
    rest: `POST /api/dns/redirect
GET /api/dns/redirects
POST /api/dns/flush`,
  },
  proxy: {
    title: 'HTTP proxy rules (mtk-serve)',
    body: `Rules apply per client IP to paths on traffic that flows through the mtk-serve proxy URL. Logs accrue in /v1/proxy/log.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
kit.proxy.set_response("192.168.1.100", "/api/user", {"id": 1}, status=200)
kit.proxy.set_error("192.168.1.100", "/api/bill", status=502, response="upstream down")
kit.proxy.set_delay("192.168.1.100", "/api/slow", delay_ms=3000)
rules = kit.proxy.list_rules(client_ip="192.168.1.100")
logs = kit.proxy.get_log(client_ip="192.168.1.100", limit=50)
kit.proxy.clear_device("192.168.1.100")`,
    cli: `mtk proxy …  # see mtk proxy --help`,
    rest: `POST /api/proxy/rule
GET /api/proxy/rules
GET /api/proxy/logs
DELETE /api/proxy/rules`,
  },
  scenarios: {
    title: 'Scenarios',
    body: `YAML-driven flows that combine network, DNS, and proxy steps for one client.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
result = kit.scenarios.run("geo-block-test", client_ip="192.168.1.100")
names = [s.name for s in kit.scenarios.list_scenarios()]`,
    cli: `mtk scenario run geo-block-test 192.168.1.100
mtk scenario list`,
    rest: `POST /api/scenarios/run`,
  },
  recording: {
    title: 'Recording & replay',
    body: `Session IDs come from start(); stop pulls mtk-serve proxy log lines into a HAR file.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
sid = kit.recorder.start("192.168.1.100", name="checkout")
# … generate traffic …
path = kit.recorder.stop_for_client("192.168.1.100")`,
    cli: `mtk record start 192.168.1.100
mtk record stop …`,
    rest: `POST /api/recording/start
POST /api/recording/stop`,
  },
  setup: {
    title: 'Setup & local profiles',
    body: `First-run wizard writes ~/.mtk/dashboard-workspace.json (0600) and applies MTK_HOST, MTK_PASSWORD, MTK_SERVICE_URL, MTK_VPN_* (plus optional MTK_VPN_IPSEC_SECRET, MTK_VPN_ENDPOINT_CREDENTIALS JSON, MTK_VPN_ACTIVE_ENDPOINT) for this dashboard process. Same global names as mtk init-site and MtkTestKit.from_env().`,
    python: `# Values are injected into os.environ by the dashboard after save.
from mtk_router_sdk.testing import MtkTestKit
kit = MtkTestKit.from_env()`,
    cli: `mtk init-site   # CLI alternative to build site.json
mtk doctor`,
    rest: `GET /api/setup/status
GET /api/setup/suggest-router
GET /api/setup/workspace
POST /api/setup/workspace
GET /api/setup/env-ui
POST /api/setup/env-ui`,
  },
  profiles: {
    title: 'YAML profiles',
    body: `Apply packaged network+DNS+proxy state from MTK_PROFILES_DIR.`,
    python: `from mtk_router_sdk.testing import MtkTestKit

kit = MtkTestKit.from_env()
kit.profiles.apply("premium-user", client_ip="192.168.1.100")
kit.profiles.clear("192.168.1.100")
names = kit.profiles.list_profiles()`,
    cli: `mtk profile apply premium-user 192.168.1.100
mtk profile list`,
    rest: `POST /api/profiles/apply`,
  },
  docs: {
    title: 'Documentation tab',
    body: `In-repo reference: docs/TESTING_SDK.md and docs/ADOPTION_GUIDE.md — same mental model as this UI.`,
    python: `# Explore classes under mtk_router_sdk.testing and mtk_router_sdk.proxy`,
    cli: `mtk --help`,
    rest: `OpenAPI: mtk-serve serves /v1/* ; dashboard serves /api/*`,
  },
  settings: {
    title: 'Settings & export',
    body: `WebSocket filter narrows live ticks. Export dumps a JSON snapshot of overview state.`,
    python: `kit = MtkTestKit.from_env()
# Snapshot is equivalent to combining list_conditions, list_redirects, list_rules, get_log`,
    cli: `# mtk dashboard start`,
    rest: `GET /api/export`,
  },
  'sdk-connect': {
    title: 'You are here',
    body: `This panel is the bridge between clicks and code. Use “Last mirrored action” after each successful control action.`,
    python: `from mtk_router_sdk.testing import MtkTestKit
kit = MtkTestKit.from_env()`,
    cli: `mtk --help`,
    rest: `See bridge table below.`,
  },
};

const DEFAULT_PLAYBOOK = {
  title: 'Explore a tab',
  body: 'Pick a section in the sidebar — playbooks update automatically.',
  python: 'from mtk_router_sdk.testing import MtkTestKit\nkit = MtkTestKit.from_env()',
  cli: 'mtk --help',
  rest: 'GET /api/health',
};

/** @type {'python' | 'cli' | 'rest'} */
let _mirrorTab = 'python';

function setMirrorTab(which) {
  _mirrorTab = which;
  const py = $('sdkMirrorPython');
  const cli = $('sdkMirrorCli');
  const rest = $('sdkMirrorRest');
  if (py) py.hidden = which !== 'python';
  if (cli) cli.hidden = which !== 'cli';
  if (rest) rest.hidden = which !== 'rest';
  document.querySelectorAll('.sdk-mirror-tab').forEach((b) => {
    b.classList.toggle('active', b.dataset.sdkMirrorTab === which);
  });
}

function copyText(text) {
  if (!text) return;
  navigator.clipboard.writeText(text).then(
    () => toast('Copied to clipboard', true),
    () => toast('Copy failed', false),
  );
}

/**
 * Update “Last mirrored action” + optional activity SDK block (call from panels).
 * @param {{ title?: string; python?: string; cli?: string; rest?: string }} block
 */
export function publishSdkMirror(block) {
  const title = block.title || 'Mirrored from UI';
  const hint = $('sdkMirrorTitle');
  if (hint) hint.textContent = title;
  const py = $('sdkMirrorPython');
  const cli = $('sdkMirrorCli');
  const rest = $('sdkMirrorRest');
  if (py) py.textContent = block.python || '# (no Python snippet)';
  if (cli) cli.textContent = block.cli || '';
  if (rest) rest.textContent = block.rest || '';
  setMirrorTab(_mirrorTab);
}

export function refreshSdkPipeline() {
  const h = state.lastHealth;
  const dot = (ok) => `<span class="sdk-pipe-dot ${ok ? 'ok' : 'err'}"></span>`;
  const r = h?.routeros_supported === true;
  const p = h?.mtk_serve_proxy === true;
  const el = $('sdkPipelineLive');
  if (!el) return;
  el.innerHTML = `
    <div class="sdk-pipe-row">${dot(r)} Router automation (RouterOS) — ${r ? 'ready' : 'blocked / not MikroTik'}</div>
    <div class="sdk-pipe-row">${dot(p)} mtk-serve (proxy API) — ${p ? 'reachable' : 'unreachable'}</div>
    <div class="sdk-pipe-row"><span class="sdk-pipe-dot ok"></span> Dashboard — you are here</div>`;
}

export function renderSdkTabPlaybook(tab) {
  const pb = TAB_PLAYBOOK[tab] || DEFAULT_PLAYBOOK;
  const title = $('sdkPlaybookTitle');
  if (title) title.textContent = pb.title;
  const body = $('sdkPlaybookBody');
  if (body) body.textContent = pb.body;
  const ppy = $('sdkPlaybookPython');
  const pcl = $('sdkPlaybookCli');
  const prs = $('sdkPlaybookRest');
  if (ppy) ppy.textContent = pb.python;
  if (pcl) pcl.textContent = pb.cli;
  if (prs) prs.textContent = pb.rest;
  const pt = $('sdkPytestShape');
  if (pt) pt.textContent = PYTEST_SKELETON;
  refreshSdkPipeline();
}

export function onSdkTabChange(tab) {
  renderSdkTabPlaybook(tab);
}

export function initSdkConnect() {
  const pytestEl = $('sdkPytestShape');
  if (pytestEl) pytestEl.textContent = PYTEST_SKELETON;

  document.querySelectorAll('.sdk-mirror-tab').forEach((b) => {
    b.addEventListener('click', () => setMirrorTab(/** @type {*} */ (b.dataset.sdkMirrorTab)));
  });
  setMirrorTab('python');

  $('btnCopySdkVisible')?.addEventListener('click', () => {
    const el =
      _mirrorTab === 'cli'
        ? $('sdkMirrorCli')
        : _mirrorTab === 'rest'
          ? $('sdkMirrorRest')
          : $('sdkMirrorPython');
    copyText(el?.textContent || '');
  });
  $('btnCopySdkPytest')?.addEventListener('click', () => copyText(PYTEST_SKELETON));

  $('btnCopyPlaybookPython')?.addEventListener('click', () => copyText($('sdkPlaybookPython')?.textContent || ''));
  $('btnCopyPlaybookCli')?.addEventListener('click', () => copyText($('sdkPlaybookCli')?.textContent || ''));

  const navActive = document.querySelector('nav a[data-tab].active');
  renderSdkTabPlaybook(navActive?.dataset.tab || 'overview');
  publishSdkMirror({
    title: 'Getting started',
    python: 'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\n# Use the sidebar to explore; snippets appear here after each action.',
    cli: 'mtk --help\nmtk dashboard start',
    rest: 'GET /api/health',
  });
}
