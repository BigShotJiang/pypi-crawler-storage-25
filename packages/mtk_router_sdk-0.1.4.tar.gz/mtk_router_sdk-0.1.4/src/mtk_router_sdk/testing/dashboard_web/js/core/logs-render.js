import { $ } from './dom.js';
import * as state from './state.js';
import { escapeHtml } from './activity.js';

let _logFilterDebounce = null;

export function logStatusClass(st) {
  const n = Number(st);
  if (!Number.isFinite(n)) return 'lg-other';
  if (n >= 500) return 'lg-5xx';
  if (n >= 400) return 'lg-4xx';
  if (n >= 200 && n < 300) return 'lg-2xx';
  return 'lg-other';
}

export function formatLogTime(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso.indexOf('Z') === -1 && !iso.includes('+') ? iso + 'Z' : iso);
    if (Number.isNaN(d.getTime())) return iso;
    return (
      d.toLocaleString(undefined, { hour12: false }) +
      '.' +
      String(d.getMilliseconds()).padStart(3, '0')
    );
  } catch {
    return iso;
  }
}

export function formatLogTimeShort(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso.indexOf('Z') === -1 && !iso.includes('+') ? iso + 'Z' : iso);
    if (Number.isNaN(d.getTime())) return (iso || '').slice(11, 19);
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  } catch {
    return '';
  }
}

function previewBody(raw, maxLen) {
  if (raw == null || raw === '') return null;
  if (raw === '[truncated]')
    return '[truncated at server — use mtk-serve or smaller responses to inspect full body]';
  const str = typeof raw === 'string' ? raw : JSON.stringify(raw, null, 2);
  if (str.length > maxLen) return str.slice(0, maxLen) + '…';
  return str;
}

/**
 * @param {object} e
 * @param {boolean} compactPath — tree mode: show path only on primary line
 * @param {boolean} sessionChrome — Network tab: table-style inspector row
 */
function logEntryArticleHtml(e, compactPath, sessionChrome) {
  const pathLine =
    escapeHtml(e.path || '') + (e.query_string ? '?' + escapeHtml(e.query_string) : '');
  const host = escapeHtml(e.upstream_host || '');
  const urlLine = host ? `${host}${pathLine ? ' — ' + pathLine : ''}` : pathLine;
  const pathOnly = pathLine || '—';
  const rb = previewBody(e.response_body, 400);
  const reqB = previewBody(e.request_body, 280);
  const st = e.response_status ?? '—';
  const stClass = logStatusClass(st);
  const upPart = e.upstream_called
    ? `<span class="httl-up">upstream ${e.upstream_status ?? '—'} · ${e.upstream_latency_ms ?? '—'}ms</span>`
    : '';
  const logId = escapeHtml(e.id || '');
  const actions = logId
    ? sessionChrome
      ? `<div class="httl-actions">
          <button type="button" class="httl-action" data-log-copy="url" data-log-id="${logId}">URL</button>
          <button type="button" class="httl-action" data-log-copy="curl" data-log-id="${logId}">cURL</button>
          <button type="button" class="httl-action" data-log-copy="resp" data-log-id="${logId}">Body</button>
        </div>`
      : `<div class="log-entry-actions">
          <button type="button" class="btn btn-ghost btn-sm" data-log-copy="url" data-log-id="${logId}">Copy URL</button>
          <button type="button" class="btn btn-ghost btn-sm" data-log-copy="curl" data-log-id="${logId}">Copy cURL</button>
          <button type="button" class="btn btn-ghost btn-sm" data-log-copy="resp" data-log-id="${logId}">Copy response</button>
        </div>`
    : '';
  const pathDisplay = compactPath ? pathOnly : urlLine || '—';
  const titleAttr = escapeHtml(compactPath ? pathOnly : urlLine || '');

  if (sessionChrome) {
    return `<article class="log-entry httl-row" data-log-id="${logId}">
      <div class="httl-row__grid">
        <time class="httl-row__time mono">${escapeHtml(formatLogTime(e.timestamp))}</time>
        <span class="httl-meth method-badge">${escapeHtml(e.method || '—')}</span>
        <span class="status-pill ${stClass} httl-st">${st}</span>
        <span class="httl-row__dur mono">${e.total_latency_ms != null ? e.total_latency_ms + '\u00a0ms' : '—'}</span>
        <div class="httl-row__path mono" title="${titleAttr}">${pathDisplay}</div>
      </div>
      <div class="httl-row__meta">
        <span class="httl-row__ip mono">${escapeHtml(e.client_ip || '—')}</span>
        <span class="httl-row__sep">·</span>
        <span>${escapeHtml(e.action_taken || '—')}</span>
        ${e.matched_rule_name ? `<span class="httl-row__sep">·</span><span>${escapeHtml(e.matched_rule_name)}</span>` : ''}
        ${upPart ? `<span class="httl-row__sep">·</span>${upPart}` : ''}
      </div>
      ${actions}
      ${e.error ? `<div class="httl-row__err">${escapeHtml(e.error)}</div>` : ''}
      ${reqB ? `<details class="httl-details"><summary>Request entity</summary><pre class="httl-pre">${escapeHtml(reqB)}</pre></details>` : ''}
      ${rb ? `<details class="httl-details"><summary>Response entity</summary><pre class="httl-pre">${escapeHtml(rb)}</pre></details>` : ''}
    </article>`;
  }

  const urlRow = compactPath
    ? `<div class="log-url mono">${pathOnly}</div>`
    : `<div class="log-url mono">${urlLine || '—'}</div>`;
  return `<article class="log-entry" data-log-id="${logId}">
          <div class="log-entry-head">
            <span class="log-time mono">${escapeHtml(formatLogTime(e.timestamp))}</span>
            <span class="method-badge">${escapeHtml(e.method || '—')}</span>
            <span class="status-pill ${stClass}">${st}</span>
            <span class="log-lat">${e.total_latency_ms != null ? e.total_latency_ms + ' ms' : '—'}</span>
          </div>
          ${urlRow}
          <div class="log-meta-line">
            <span>Client: <code class="mono">${escapeHtml(e.client_ip || '—')}</code></span>
            <span>Action: <strong>${escapeHtml(e.action_taken || '—')}</strong></span>
            ${e.matched_rule_name ? `<span>Rule: ${escapeHtml(e.matched_rule_name)}</span>` : ''}
            ${e.upstream_called ? `<span>Upstream: <strong>${e.upstream_status ?? '—'}</strong> (${e.upstream_latency_ms ?? '—'} ms)</span>` : ''}
          </div>
          ${actions}
          ${e.error ? `<div class="log-error">${escapeHtml(e.error)}</div>` : ''}
          ${reqB ? `<details class="log-details"><summary>Request body</summary><pre class="log-body">${escapeHtml(reqB)}</pre></details>` : ''}
          ${rb ? `<details class="log-details"><summary>Response body</summary><pre class="log-body">${escapeHtml(rb)}</pre></details>` : ''}
        </article>`;
}

/**
 * @param {object[]} entries
 * @param {string} wrapId
 * @param {HTMLInputElement | null} searchInput
 * @param {string} emptyMsg
 * @param {{ emptyDetailHtml?: string; viewMode?: 'list' | 'tree'; sessionChrome?: boolean } | undefined} opts
 *        When the loaded list is empty (not filter-only), optional richer HTML (caller must escape).
 */
export function renderLogEntryList(entries, wrapId, searchInput, emptyMsg, opts) {
  const container = $(wrapId);
  if (!container) return;
  const sessionChrome = Boolean(opts && opts.sessionChrome);
  const q = (searchInput && searchInput.value && searchInput.value.trim().toLowerCase()) || '';
  let list = entries || [];
  if (q) {
    list = list.filter((e) => {
      try {
        return JSON.stringify(e).toLowerCase().includes(q);
      } catch {
        return true;
      }
    });
  }
  if (!list.length) {
    if (entries && entries.length && q) {
      container.innerHTML = sessionChrome
        ? '<div class="httl-empty httl-empty--bare"><p class="httl-empty__title">No rows match filter</p><p class="httl-empty__hint">Clear the filter or widen the search.</p></div>'
        : '<div class="empty">No entries match filter</div>';
      return;
    }
    if (opts && opts.emptyDetailHtml && (!entries || !entries.length)) {
      container.innerHTML = sessionChrome
        ? `<div class="httl-empty httl-empty--detail"><div class="log-empty-panel">${opts.emptyDetailHtml}</div></div>`
        : `<div class="log-empty-panel">${opts.emptyDetailHtml}</div>`;
      return;
    }
    container.innerHTML = sessionChrome
      ? `<div class="httl-empty"><span class="httl-empty__kicker">Proxy session</span><p class="httl-empty__title">Nothing loaded</p><p class="httl-empty__hint">${escapeHtml(emptyMsg)}</p></div>`
      : `<div class="empty">${emptyMsg}</div>`;
    return;
  }
  const viewMode = opts && opts.viewMode === 'tree' ? 'tree' : 'list';
  const sc = sessionChrome;
  if (viewMode === 'tree') {
    /** @type {Map<string, object[]>} */
    const byHost = new Map();
    for (const e of list) {
      const h = e.upstream_host || '(unknown host)';
      if (!byHost.has(h)) byHost.set(h, []);
      byHost.get(h).push(e);
    }
    const hosts = [...byHost.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    const treeCls = sc ? 'log-tree httl-tree' : 'log-tree';
    container.innerHTML = `<div class="${treeCls}">
      ${hosts
        .map(
          ([host, items]) => `<details class="log-tree-host${sc ? ' httl-tree-host' : ''}" open>
        <summary class="log-tree-host-sum"><span class="mono httl-tree-host-name">${escapeHtml(host)}</span> <span class="log-tree-count">${items.length}</span></summary>
        <div class="log-tree-host-body">${items.map((e) => logEntryArticleHtml(e, true, sc)).join('')}</div>
      </details>`,
        )
        .join('')}
    </div>`;
    return;
  }
  const colhead =
    sc
      ? `<div class="httl-colhead" role="presentation">
          <span>Time</span><span>Method</span><span>Status</span><span>Duration</span><span>Request</span>
        </div>`
      : '';
  container.innerHTML = colhead + list.map((e) => logEntryArticleHtml(e, false, sc)).join('');
}

/**
 * @param {string} inputId
 * @param {'proxyLogCache' | 'netLogCache'} cacheKey
 */
export function wireLogSearch(inputId, cacheKey, wrapId, emptyMsg) {
  const el = $(inputId);
  if (!el) return;
  el.addEventListener('input', () => {
    clearTimeout(_logFilterDebounce);
    _logFilterDebounce = setTimeout(() => {
      const cache = cacheKey === 'proxyLogCache' ? state.proxyLogCache : state.netLogCache;
      const list = cache || [];
      let netOpts = undefined;
      if (cacheKey === 'netLogCache') {
        netOpts = { viewMode: state.netLogViewMode, sessionChrome: true };
        if (!list.length && state.netLogEmptyDetailHtml) {
          netOpts.emptyDetailHtml = state.netLogEmptyDetailHtml;
        }
      }
      renderLogEntryList(list, wrapId, el, emptyMsg, netOpts);
    }, 200);
  });
}

export function appendLiveFeed(entries) {
  const box = $('liveFeed');
  if (!box) return;
  if (box.querySelector('.empty')) box.innerHTML = '';
  entries.forEach((e) => {
    if (state.wsFilter && e.client_ip !== state.wsFilter) return;
    const row = document.createElement('div');
    row.className = 'feed-item feed-item-rich';
    const st = logStatusClass(e.response_status);
    const pathQ = (e.path || '') + (e.query_string ? '?' + e.query_string : '');
    const host = e.upstream_host ? escapeHtml(e.upstream_host) + ' · ' : '';
    row.innerHTML = `<div class="feed-row1">
            <span class="feed-time">${escapeHtml(formatLogTimeShort(e.timestamp))}</span>
            <span class="method-badge sm">${escapeHtml(e.method || '—')}</span>
            <span class="status-pill ${st}">${e.response_status ?? '—'}</span>
            <span class="feed-lat">${e.total_latency_ms != null ? e.total_latency_ms + ' ms' : '—'}</span>
          </div>
          <div class="feed-row2 mono">${host}${escapeHtml(pathQ)}</div>
          <div class="feed-row3"><span>${escapeHtml(e.client_ip || '')}</span> · <span>${escapeHtml(e.action_taken || '')}</span>${e.matched_rule_name ? ' · ' + escapeHtml(e.matched_rule_name) : ''}</div>`;
    box.insertBefore(row, box.firstChild);
    while (box.children.length > 120) box.removeChild(box.lastChild);
  });
}
