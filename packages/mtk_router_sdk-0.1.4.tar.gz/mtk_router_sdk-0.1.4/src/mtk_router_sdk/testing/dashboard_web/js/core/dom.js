/** @param {string} id */
export const $ = (id) => document.getElementById(id);
