import { $ } from '../core/dom.js';

export function toggleAccordion(header) {
  header.parentElement.classList.toggle('open');
}

export function copyCode(btn) {
  const block = btn.parentElement;
  const pre = block.querySelector('.code-pre');
  let text;
  if (pre) {
    text = Array.from(pre.querySelectorAll('.code-line'))
      .map((line) => {
        let t = '';
        line.childNodes.forEach((n) => {
          if (n.nodeType === 1 && n.classList && n.classList.contains('code-line-gloss')) return;
          t += n.textContent || '';
        });
        return t.replace(/\u00a0/g, ' ').replace(/\s+$/m, '');
      })
      .join('\n')
      .trim();
  } else {
    const c = block.querySelector('code');
    text = c ? c.textContent : '';
  }
  navigator.clipboard.writeText(text);
  btn.textContent = 'Copied!';
  setTimeout(() => {
    btn.textContent = 'Copy';
  }, 1500);
}

function clearProxyCodeHighlights() {
  document.querySelectorAll('.code-line.is-highlight').forEach((el) => el.classList.remove('is-highlight'));
  document.querySelectorAll('.action-pill.is-active').forEach((el) => el.classList.remove('is-active'));
}

function highlightProxyLines(startId, stopId, pill) {
  clearProxyCodeHighlights();
  if (pill) pill.classList.add('is-active');
  let el = document.getElementById(startId);
  while (el) {
    if (el.classList.contains('code-line')) el.classList.add('is-highlight');
    el = el.nextElementSibling;
    if (!el || (stopId && el.id === stopId)) break;
  }
}

export function initInteractiveDocs() {
  const stops = {
    'snippet-override': 'snippet-error',
    'snippet-error': 'snippet-delay',
    'snippet-delay': 'snippet-modify',
    'snippet-modify': 'snippet-logs',
    'snippet-logs': null,
  };
  document.querySelectorAll('.action-pill[data-code-target]').forEach((pill) => {
    const tid = pill.dataset.codeTarget;
    if (!tid || !Object.prototype.hasOwnProperty.call(stops, tid)) return;
    const stop = stops[tid];
    const enter = () => highlightProxyLines(tid, stop, pill);
    const leave = () => clearProxyCodeHighlights();
    pill.addEventListener('mouseenter', enter);
    pill.addEventListener('mouseleave', leave);
    pill.addEventListener('focus', enter);
    pill.addEventListener('blur', leave);
  });
  document.querySelectorAll('.flow-node[data-sync-pill]').forEach((node) => {
    const key = node.dataset.syncPill;
    if (!key) return;
    const startId = 'snippet-' + key;
    const elStart = document.getElementById(startId);
    if (!elStart) return;
    const stop = stops[startId];
    node.addEventListener('mouseenter', () => highlightProxyLines(startId, stop, null));
    node.addEventListener('mouseleave', clearProxyCodeHighlights);
    node.addEventListener('focus', () => highlightProxyLines(startId, stop, null));
    node.addEventListener('blur', clearProxyCodeHighlights);
  });
  document.querySelectorAll('#panel-docs .flow-node').forEach((node) => {
    node.addEventListener('click', () => {
      if (!window.matchMedia('(hover: hover)').matches) {
        document.querySelectorAll('#panel-docs .flow-node.popover-open').forEach((n) => {
          if (n !== node) n.classList.remove('popover-open');
        });
        node.classList.toggle('popover-open');
      }
    });
  });

  document.querySelectorAll('#netDocTabs button').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#netDocTabs button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      ['Python', 'Cli', 'Pytest'].forEach((l) => {
        const el = $('netCode' + l);
        if (el) el.style.display = btn.dataset.lang.toLowerCase() === l.toLowerCase() ? 'block' : 'none';
      });
    });
  });
}
