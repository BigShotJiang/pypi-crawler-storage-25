/**
 * Saved proxy rule bundles (localStorage) + apply / import / export.
 * Complements panels/proxy.js — same POST /api/proxy/rule contract.
 */
import { $ } from '../core/dom.js';
import { api, toast, toastApiError } from '../core/api.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';
import { pushActivity } from '../core/activity.js';

const STORAGE_KEY = 'mtk_proxy_presets_v2';

/** @typedef {{ id: string; name: string; description?: string; updatedAt: string; rules: PresetRule[]; builtin?: boolean }} Preset */
/** @typedef {{ action: 'override'|'error'|'delay'; client_ip: string | null; path: string; method?: string | null; status?: number; body?: unknown; delay_ms?: number }} PresetRule */

/** Shipped examples — `client_ip: null` uses Target device IP in the UI. */
const BUILTIN_PRESETS = [
  {
    id: '__mtk_builtin_us_ok__',
    name: 'Starter · US region + health OK',
    description: 'Common streaming/geo stubs (uses Target IP)',
    builtin: true,
    updatedAt: '',
    rules: [
      {
        action: 'override',
        client_ip: null,
        path: '/api/v1/region',
        method: '',
        status: 200,
        body: { region: 'US', country_code: 'US', tier: 'premium' },
      },
      {
        action: 'override',
        client_ip: null,
        path: '/api/health',
        method: '',
        status: 200,
        body: { ok: true, status: 'healthy' },
      },
    ],
  },
  {
    id: '__mtk_builtin_chaos__',
    name: 'Starter · 502 payment + slow search',
    description: 'Chaos: failing checkout + laggy search',
    builtin: true,
    updatedAt: '',
    rules: [
      {
        action: 'error',
        client_ip: null,
        path: '/api/*/payment*',
        status: 502,
        body: { error: 'Payment gateway unavailable' },
      },
      {
        action: 'delay',
        client_ip: null,
        path: '/api/*/search*',
        delay_ms: 3500,
      },
    ],
  },
];

function loadStoredPresets() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return [];
    return arr.filter((p) => p && typeof p.name === 'string' && Array.isArray(p.rules));
  } catch {
    return [];
  }
}

function saveStoredPresets(presets) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(presets));
}

function makeId() {
  return 'pr_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}

/**
 * @param {unknown[]} apiRules
 * @returns {PresetRule[]}
 */
export function rulesFromApiList(apiRules) {
  return apiRules
    .filter((r) => {
      const a = String(r.action || 'override').toLowerCase();
      return a === 'override' || a === 'error' || a === 'delay';
    })
    .map((r) => {
    const action = String(r.action || 'override').toLowerCase();
    const base = {
      path: String(r.path_pattern || ''),
      client_ip: r.client_ip ? String(r.client_ip) : null,
      method: r.method ? String(r.method) : null,
    };
    if (action === 'delay') {
      return { ...base, action: 'delay', delay_ms: Number(r.delay_ms) || 2000 };
    }
    if (action === 'error') {
      let err = 'Error';
      const rb = r.response_body;
      if (rb && typeof rb === 'object' && rb.error != null) err = String(rb.error);
      return {
        ...base,
        action: 'error',
        status: Number(r.response_status) || 500,
        body: { error: err },
      };
    }
    return {
      ...base,
      action: 'override',
      status: Number(r.response_status) || 200,
      body: r.response_body != null ? r.response_body : {},
    };
  });
}

/**
 * @param {PresetRule} rule
 * @param {string} targetIp
 */
async function postPresetRule(rule, targetIp) {
  const ip = (rule.client_ip && String(rule.client_ip).trim()) || targetIp.trim();
  if (!ip) throw new Error('Set Target device IP — this preset uses “any device” for client_ip.');
  const path = String(rule.path || '').trim();
  if (!path) throw new Error('Rule missing path');

  const action = (rule.action || 'override').toLowerCase();
  if (action === 'error') {
    const status = Number(rule.status) || 500;
    const msg =
      rule.body && typeof rule.body === 'object' && rule.body.error != null
        ? String(rule.body.error)
        : 'Error';
    await api('/api/proxy/rule', {
      method: 'POST',
      body: JSON.stringify({
        client_ip: ip,
        path,
        status,
        body: { error: msg },
        action: 'error',
      }),
    });
    return;
  }
  if (action === 'delay') {
    await api('/api/proxy/rule', {
      method: 'POST',
      body: JSON.stringify({
        client_ip: ip,
        path,
        delay_ms: Number(rule.delay_ms) || 2000,
        action: 'delay',
      }),
    });
    return;
  }
  const body = rule.body !== undefined && rule.body !== null ? rule.body : {};
  const status = Number(rule.status) || 200;
  const method = rule.method ? String(rule.method) : '';
  await api('/api/proxy/rule', {
    method: 'POST',
    body: JSON.stringify({
      client_ip: ip,
      path,
      body,
      status,
      method: method || null,
      action: 'override',
    }),
  });
}

function getTargetIp() {
  const t = $('proxyPresetTargetIp');
  const f = $('proxyFilterIp');
  const o = $('proxyRuleClient');
  const raw = (t?.value || f?.value || o?.value || '').trim();
  return raw;
}

function fillPresetDropdown() {
  const sel = $('proxyPresetSelect');
  if (!sel) return;
  const stored = loadStoredPresets();
  let html = '<option value="">— Choose a preset —</option>';
  html += '<optgroup label="Starters">';
  for (const p of BUILTIN_PRESETS) {
    html += `<option value="${escapeAttr(p.id)}">${escapeHtml(p.name)}</option>`;
  }
  html += '</optgroup>';
  if (stored.length) {
    html += '<optgroup label="Your presets">';
    for (const p of stored.sort((a, b) => (a.name || '').localeCompare(b.name || ''))) {
      html += `<option value="${escapeAttr(p.id)}">${escapeHtml(p.name)} (${p.rules.length} rules)</option>`;
    }
    html += '</optgroup>';
  }
  sel.innerHTML = html;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(s) {
  return escapeHtml(s).replace(/'/g, '&#39;');
}

function findPresetById(id) {
  if (!id) return null;
  const b = BUILTIN_PRESETS.find((p) => p.id === id);
  if (b) return b;
  return loadStoredPresets().find((p) => p.id === id) || null;
}

async function applySelectedPreset() {
  const sel = $('proxyPresetSelect');
  const id = sel?.value || '';
  const preset = findPresetById(id);
  if (!preset) {
    toast('Choose a preset first', false);
    return;
  }
  const targetIp = getTargetIp();
  if (!targetIp) {
    toast('Set Target device IP (or fill Proxy filter / Override client IP)', false);
    return;
  }
  const clearFirst = $('proxyPresetClearFirst') instanceof HTMLInputElement && $('proxyPresetClearFirst').checked;
  try {
    if (clearFirst) {
      await api('/api/proxy/rules', { method: 'DELETE' });
    }
    let n = 0;
    for (const rule of preset.rules) {
      await postPresetRule(rule, targetIp);
      n += 1;
    }
    toast(`Applied “${preset.name}” (${n} rules)${clearFirst ? '' : ' — merged with existing rules'}`, true);
    publishSdkMirror({
      title: `Proxy preset: ${preset.name}`,
      python: `# Applied ${n} rules for ${targetIp}\n# Use kit.proxy.list_rules() to verify`,
      rest: `POST /api/proxy/rule × ${n}`,
    });
    pushActivity('proxy', `Preset “${preset.name}” → ${n} rule(s) @ ${targetIp}`, true);
    const proxyMod = await import('./proxy.js');
    await proxyMod.loadProxyRulesAndLogs();
    await loadOverview();
  } catch (e) {
    toastApiError(e);
    pushActivity('proxy', 'Preset apply failed: ' + (e instanceof Error ? e.message : String(e)), false);
  }
}

async function deleteSelectedPreset() {
  const sel = $('proxyPresetSelect');
  const id = sel?.value || '';
  if (!id || BUILTIN_PRESETS.some((p) => p.id === id)) {
    toast('Select one of your saved presets (not a Starter)', false);
    return;
  }
  if (!confirm('Delete this saved preset from this browser?')) return;
  const next = loadStoredPresets().filter((p) => p.id !== id);
  saveStoredPresets(next);
  fillPresetDropdown();
  toast('Preset deleted', true);
}

async function saveFromServerRules() {
  const name = ($('proxyPresetSaveName')?.value || '').trim();
  const desc = ($('proxyPresetSaveDesc')?.value || '').trim();
  if (!name) {
    toast('Enter a preset name', false);
    $('proxyPresetSaveName')?.focus();
    return;
  }
  try {
    const data = await api('/api/proxy/rules');
    const list = Array.isArray(data.rules) ? data.rules : [];
    if (!list.length) {
      toast('No rules on mtk-serve — add rules or click Load rules first', false);
      return;
    }
    const skipped = list.length;
    const rules = rulesFromApiList(list);
    const dropped = skipped - rules.length;
    if (dropped > 0) {
      toast(`Omitted ${dropped} rule(s) (modify/passthrough not supported in presets)`, false);
    }
    if (!rules.length) {
      toast('Nothing to save — only unsupported rule types on server', false);
      return;
    }
    const presets = loadStoredPresets().filter((p) => p.name !== name);
    presets.push({
      id: makeId(),
      name,
      description: desc,
      updatedAt: new Date().toISOString(),
      rules,
    });
    saveStoredPresets(presets);
    fillPresetDropdown();
    const sel = $('proxyPresetSelect');
    if (sel) sel.value = presets[presets.length - 1].id;
    toast(`Saved “${name}” (${rules.length} rules)`, true);
    pushActivity('proxy', `Saved preset “${name}” (${rules.length} rules)`, true);
  } catch (e) {
    toastApiError(e);
  }
}

function exportSelectedPreset() {
  const sel = $('proxyPresetSelect');
  const id = sel?.value || '';
  const preset = findPresetById(id);
  if (!preset) {
    toast('Choose a preset to export', false);
    return;
  }
  const payload = {
    version: 2,
    exportedAt: new Date().toISOString(),
    preset: {
      name: preset.name,
      description: preset.description || '',
      rules: preset.rules,
    },
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `mtk-proxy-preset-${preset.name.replace(/[^\w\-]+/g, '_').slice(0, 48)}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  toast('Download started', true);
}

function onImportFile(ev) {
  const input = ev.target;
  if (!(input instanceof HTMLInputElement) || !input.files?.[0]) return;
  const file = input.files[0];
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const text = String(reader.result || '');
      const data = JSON.parse(text);
      let rules;
      let name;
      let description = '';
      if (data.preset && Array.isArray(data.preset.rules)) {
        rules = data.preset.rules;
        name = String(data.preset.name || 'Imported preset');
        description = String(data.preset.description || '');
      } else if (Array.isArray(data.rules)) {
        rules = data.rules;
        name = String(data.name || 'Imported preset');
        description = String(data.description || '');
      } else {
        toast('Invalid JSON — need { preset: { name, rules } } or { rules }', false);
        return;
      }
      if (!rules.length) {
        toast('Preset has no rules', false);
        return;
      }
      const presets = loadStoredPresets();
      const id = makeId();
      presets.push({
        id,
        name: name.slice(0, 120),
        description: description.slice(0, 500),
        updatedAt: new Date().toISOString(),
        rules,
      });
      saveStoredPresets(presets);
      fillPresetDropdown();
      const sel = $('proxyPresetSelect');
      if (sel) sel.value = id;
      toast(`Imported “${name}” (${rules.length} rules)`, true);
    } catch {
      toast('Could not parse JSON file', false);
    }
    input.value = '';
  };
  reader.readAsText(file);
}

export function initProxyPresets() {
  const t = $('proxyPresetTargetIp');
  if (t && !(t.value || '').trim()) {
    const v = ($('proxyFilterIp')?.value || $('proxyRuleClient')?.value || '').trim();
    if (v) t.value = v;
  }
  fillPresetDropdown();
  $('btnProxyPresetApply')?.addEventListener('click', () => applySelectedPreset());
  $('btnProxyPresetDelete')?.addEventListener('click', () => deleteSelectedPreset());
  $('btnProxyPresetSaveFromServer')?.addEventListener('click', () => saveFromServerRules());
  $('btnProxyPresetExport')?.addEventListener('click', () => exportSelectedPreset());
  $('proxyPresetImportFile')?.addEventListener('change', onImportFile);

  // Sync target IP from common fields once
  const sync = () => {
    const t = $('proxyPresetTargetIp');
    if (!t || (t.value || '').trim()) return;
    const v = ($('proxyFilterIp')?.value || $('proxyRuleClient')?.value || '').trim();
    if (v) t.placeholder = `Using ${v} — or type another IP`;
  };
  sync();
  $('proxyFilterIp')?.addEventListener('input', sync);
  $('proxyRuleClient')?.addEventListener('input', sync);
}
