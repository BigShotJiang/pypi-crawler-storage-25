/**
 * First-run setup: local workspace profiles (~/.mtk/dashboard-workspace.json).
 */
import { $ } from '../core/dom.js';
import { api, toast, toastApiError } from '../core/api.js';
import { loadHealth } from './overview-ws.js';
import { initMitmCaImport } from './mitm-ca-import.js';

const STEP_COUNT = 5;

async function runSuggestRouter(options = {}) {
  const manual = Boolean(options.manual);
  const st = $('setupRouterDetectStatus');
  const btn = $('btnSetupDetectRouter');
  const hostEl = $('setupRouterHost');
  if (manual && btn) btn.disabled = true;
  if (st) st.textContent = manual ? 'Scanning local network…' : 'Detecting router on your LAN…';
  try {
    const r = await api('/api/setup/suggest-router');
    const suggested = (r.suggested || '').trim();
    if (hostEl) {
      const cur = (hostEl.value || '').trim();
      if (manual || !cur) hostEl.value = suggested || cur;
    }
    const gw = r.default_gateway ? `Gateway: ${r.default_gateway}. ` : '';
    if (st) {
      const tail = suggested ? ` → ${suggested}` : '';
      st.textContent = `${gw}${r.hint || 'Suggested address.'}${tail}`;
    }
    toast(
      r.ssh_port_open ? 'SSH port open on suggested address' : 'Address suggested — confirm SSH if needed',
      Boolean(r.ssh_port_open),
    );
  } catch (e) {
    toastApiError(e);
    if (st) st.textContent = '';
  } finally {
    if (btn) btn.disabled = false;
  }
}

function escapeAttr(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}

/** @returns {Record<string, string>} */
export function parseLabEnvLines(text) {
  const out = {};
  for (const line of String(text || '').split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const eq = t.indexOf('=');
    if (eq < 1) continue;
    const k = t.slice(0, eq).trim();
    const v = t.slice(eq + 1).trim();
    if (!k.startsWith('MTK_')) continue;
    if (!v) continue;
    out[k] = v;
  }
  return out;
}

/** @param {Record<string, unknown> | null | undefined} obj */
export function labEnvToText(obj) {
  if (!obj || typeof obj !== 'object') return '';
  return Object.keys(obj)
    .filter((k) => k.startsWith('MTK_'))
    .sort()
    .map((k) => `${k}=${obj[k]}`)
    .join('\n');
}

function collectVpnOverrides() {
  const root = $('setupVpnEndpointRows');
  if (!root) return {};
  const out = {};
  root.querySelectorAll('.setup-vpn-ep-row').forEach((row) => {
    const id = (row.querySelector('[data-field="id"]')?.value || '').trim();
    if (!id) return;
    const user = (row.querySelector('[data-field="user"]')?.value || '').trim();
    const password = (row.querySelector('[data-field="password"]')?.value || '').trim();
    const ipsec = (row.querySelector('[data-field="ipsec"]')?.value || '').trim();
    const o = {};
    if (user) o.user = user;
    if (password) o.password = password;
    if (ipsec) o.ipsec_secret = ipsec;
    if (Object.keys(o).length) out[id] = o;
  });
  return out;
}

function syncVpnActiveSelect() {
  const sel = $('setupVpnActiveEndpoint');
  if (!sel) return;
  const prev = sel.value;
  const merged = collectVpnOverrides();
  const keys = Object.keys(merged);
  sel.innerHTML =
    '<option value="">— Global defaults only —</option>' +
    keys.map((k) => `<option value="${escapeAttr(k)}">${escapeAttr(k)}</option>`).join('');
  if (prev && keys.includes(prev)) sel.value = prev;
}

function addVpnEpRow(prefill = {}) {
  const root = $('setupVpnEndpointRows');
  if (!root) return;
  const row = document.createElement('div');
  row.className = 'setup-vpn-ep-row';
  row.innerHTML = `
    <div class="row setup-vpn-ep-row-inner" style="flex-wrap:wrap;align-items:flex-end;gap:10px;margin-bottom:10px">
      <div><label>Endpoint id <span class="hint">(vpn_registry key)</span></label><input type="text" data-field="id" class="mono" placeholder="US" autocomplete="off" spellcheck="false" /></div>
      <div><label>User override</label><input type="text" data-field="user" autocomplete="off" placeholder="optional" /></div>
      <div><label>Password override</label><input type="password" data-field="password" autocomplete="off" placeholder="optional" /></div>
      <div><label>IPsec override</label><input type="password" data-field="ipsec" autocomplete="off" placeholder="optional" /></div>
      <div style="align-self:flex-end"><button type="button" class="btn btn-ghost btn-sm setup-vpn-ep-remove">Remove</button></div>
    </div>`;
  root.appendChild(row);
  const idEl = row.querySelector('[data-field="id"]');
  const uEl = row.querySelector('[data-field="user"]');
  const pEl = row.querySelector('[data-field="password"]');
  const iEl = row.querySelector('[data-field="ipsec"]');
  if (prefill.id && idEl) idEl.value = prefill.id;
  if (prefill.user && uEl) uEl.value = prefill.user;
  if (prefill.password && pEl) pEl.value = prefill.password;
  if (prefill.ipsec_secret && iEl) iEl.value = prefill.ipsec_secret;
  row.querySelector('.setup-vpn-ep-remove')?.addEventListener('click', () => {
    row.remove();
    syncVpnActiveSelect();
  });
  [idEl, uEl, pEl, iEl].forEach((el) => el?.addEventListener('input', () => syncVpnActiveSelect()));
}

function renderVpnOverridesFromProfile(obj) {
  const root = $('setupVpnEndpointRows');
  if (!root) return;
  root.innerHTML = '';
  const keys = Object.keys(obj || {});
  if (!keys.length) {
    addVpnEpRow();
    syncVpnActiveSelect();
    return;
  }
  keys.forEach((k) => {
    const v = obj[k] || {};
    addVpnEpRow({
      id: k,
      user: v.user || '',
      password: v.password || '',
      ipsec_secret: v.ipsec_secret || '',
    });
  });
  syncVpnActiveSelect();
}

function slugify(s) {
  const t = String(s || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  return t || 'default';
}

function showStep(n) {
  for (let i = 0; i < STEP_COUNT; i++) {
    const el = $('setupStep' + i);
    if (!el) continue;
    const show = i === n;
    el.hidden = !show;
    el.classList.remove('setup-step--enter');
    if (show) {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => el.classList.add('setup-step--enter'));
      });
    }
  }
  const prog = $('setupWizardProgress');
  if (prog) {
    prog.innerHTML = Array.from({ length: STEP_COUNT }, (_, i) => {
      const cls = i === n ? 'setup-dot setup-dot--on' : i < n ? 'setup-dot setup-dot--done' : 'setup-dot';
      return `<span class="${cls}"></span>`;
    }).join('');
  }
  if (n === 1) {
    const h = ($('setupRouterHost')?.value || '').trim();
    if (!h) void runSuggestRouter({ manual: false });
  }
}

function formProfileFromInputs() {
  const idRaw = ($('setupProfileId')?.value || '').trim() || slugify($('setupProfileLabel')?.value || 'default');
  return {
    id: idRaw,
    label: ($('setupProfileLabel')?.value || '').trim() || idRaw,
    router_host: ($('setupRouterHost')?.value || '').trim(),
    router_user: ($('setupRouterUser')?.value || '').trim(),
    router_password: ($('setupRouterPass')?.value || '').trim(),
    router_port: Number($('setupRouterPort')?.value) || 22,
    router_timeout_sec: Number($('setupRouterTimeout')?.value) || 10,
    vpn_user: ($('setupVpnUser')?.value || '').trim(),
    vpn_password: ($('setupVpnPass')?.value || '').trim(),
    vpn_ipsec_secret: ($('setupVpnIpsec')?.value || '').trim(),
    vpn_endpoint_overrides: collectVpnOverrides(),
    vpn_active_endpoint: ($('setupVpnActiveEndpoint')?.value || '').trim() || null,
    mtk_service_url: ($('setupServiceUrl')?.value || '').trim(),
    mtk_service_token: ($('setupServiceToken')?.value || '').trim(),
    lab_env: parseLabEnvLines($('setupLabEnv')?.value || ''),
  };
}

function fillFormFromProfile(p) {
  if (!p || typeof p !== 'object') return;
  const set = (id, v) => {
    const el = $(id);
    if (el && v != null) el.value = v;
  };
  set('setupProfileLabel', p.label || '');
  set('setupProfileId', p.id || '');
  set('setupRouterHost', p.router_host || '');
  set('setupRouterUser', p.router_user || '');
  set('setupRouterPass', p.router_password || '');
  set('setupRouterPort', p.router_port ?? 22);
  set('setupRouterTimeout', p.router_timeout_sec ?? 10);
  set('setupVpnUser', p.vpn_user || '');
  set('setupVpnPass', p.vpn_password || '');
  set('setupVpnIpsec', p.vpn_ipsec_secret || '');
  renderVpnOverridesFromProfile(p.vpn_endpoint_overrides && typeof p.vpn_endpoint_overrides === 'object' ? p.vpn_endpoint_overrides : {});
  const vAct = $('setupVpnActiveEndpoint');
  if (vAct) {
    const want = (p.vpn_active_endpoint || '').trim();
    if (want && [...vAct.options].some((o) => o.value === want)) vAct.value = want;
    else vAct.value = '';
  }
  set('setupServiceUrl', p.mtk_service_url || '');
  set('setupServiceToken', p.mtk_service_token || '');
  const le = $('setupLabEnv');
  if (le) le.value = labEnvToText(p.lab_env);
}

export async function refreshSetupIfVisible() {
  await refreshWorkspaceUi();
}

async function refreshWorkspaceUi() {
  let st;
  try {
    st = await api('/api/setup/status');
  } catch {
    return;
  }
  const nav = document.querySelector('nav a[data-tab="setup"]');
  if (nav) nav.classList.toggle('setup-nav--pulse', Boolean(st.show_setup_wizard));

  const pathEl = $('setupWorkspacePath');
  if (pathEl) pathEl.textContent = 'File: ' + (st.workspace_path || '');

  const sel = $('setupActiveProfile');
  if (sel) {
    const prev = sel.value;
    sel.innerHTML =
      (st.profile_summaries || [])
        .map((p) => `<option value="${p.id}">${p.label || p.id}</option>`)
        .join('') || '<option value="">— No profiles —</option>';
    if (st.active_profile_id && [...sel.options].some((o) => o.value === st.active_profile_id)) {
      sel.value = st.active_profile_id;
    } else if (prev && [...sel.options].some((o) => o.value === prev)) {
      sel.value = prev;
    }
  }
}

async function loadWorkspaceIntoForm() {
  try {
    const w = await api('/api/setup/workspace');
    const aid = w.active_profile_id;
    const prof = (w.profiles || []).find((p) => p.id === aid) || (w.profiles || [])[0];
    if (prof) fillFormFromProfile(prof);
    await refreshWorkspaceUi();
  } catch (e) {
    toastApiError(e);
  }
}

async function postWorkspace(partial) {
  const cur = await api('/api/setup/workspace');
  const body = { ...cur, ...partial, version: 1 };
  await api('/api/setup/workspace', { method: 'POST', body: JSON.stringify(body) });
}

export async function maybeRedirectToSetup() {
  try {
    const st = await api('/api/setup/status');
    if (st.show_setup_wizard && window.__mtkSwitchTab) {
      window.__mtkSwitchTab('setup');
    }
    const nav = document.querySelector('nav a[data-tab="setup"]');
    if (nav) nav.classList.toggle('setup-nav--pulse', Boolean(st.show_setup_wizard));
    return st;
  } catch {
    return null;
  }
}

export function initSetupPanel() {
  let labelTouched = false;

  $('btnSetupLeave')?.addEventListener('click', () => {
    if (window.__mtkSwitchTab) window.__mtkSwitchTab('overview');
  });
  $('btnSetupTopTheme')?.addEventListener('click', () => {
    $('btnTheme')?.click();
  });
  $('btnSetupDetectRouter')?.addEventListener('click', () => void runSuggestRouter({ manual: true }));
  $('btnVpnEpAdd')?.addEventListener('click', () => {
    addVpnEpRow();
    syncVpnActiveSelect();
  });

  $('btnSetupNewProfile')?.addEventListener('click', () => {
    labelTouched = false;
    [
      'setupProfileLabel',
      'setupProfileId',
      'setupRouterHost',
      'setupRouterUser',
      'setupRouterPass',
      'setupVpnUser',
      'setupVpnPass',
      'setupVpnIpsec',
      'setupServiceToken',
    ].forEach((id) => {
      const el = $(id);
      if (el) el.value = '';
    });
    const p = $('setupRouterPort');
    if (p) p.value = '22';
    const t = $('setupRouterTimeout');
    if (t) t.value = '10';
    const u = $('setupServiceUrl');
    if (u) u.value = '';
    const lab = $('setupLabEnv');
    if (lab) lab.value = '';
    renderVpnOverridesFromProfile({});
    const vAct = $('setupVpnActiveEndpoint');
    if (vAct) vAct.value = '';
    showStep(0);
    if (window.__mtkSwitchTab) window.__mtkSwitchTab('setup');
    toast('Enter a new profile name in step 5 — saving adds or updates that id.', true);
  });
  $('setupProfileLabel')?.addEventListener('input', () => {
    const idEl = $('setupProfileId');
    if (!idEl || labelTouched) return;
    idEl.value = slugify($('setupProfileLabel').value);
  });
  $('setupProfileId')?.addEventListener('input', () => {
    labelTouched = true;
  });

  $('btnSetupStep0Next')?.addEventListener('click', () => showStep(1));
  $('btnSetupStep1Back')?.addEventListener('click', () => showStep(0));
  $('btnSetupStep1Next')?.addEventListener('click', () => showStep(2));
  $('btnSetupStep2Back')?.addEventListener('click', () => showStep(1));
  $('btnSetupStep2Next')?.addEventListener('click', () => showStep(3));
  $('btnSetupStep3Back')?.addEventListener('click', () => showStep(2));
  $('btnSetupStep3Next')?.addEventListener('click', () => showStep(4));
  $('btnSetupStep4Back')?.addEventListener('click', () => showStep(3));

  $('btnSetupSkip')?.addEventListener('click', async () => {
    try {
      await postWorkspace({
        onboarding_done: true,
        profiles: [],
        active_profile_id: null,
      });
      toast('You can configure env vars in the shell or return to Setup anytime.', true);
      if (window.__mtkSwitchTab) window.__mtkSwitchTab('overview');
      await loadHealth();
      await refreshWorkspaceUi();
    } catch (e) {
      toastApiError(e);
    }
  });

  $('btnSetupSave')?.addEventListener('click', async () => {
    const entry = formProfileFromInputs();
    try {
      const cur = await api('/api/setup/workspace');
      const profiles = [...(cur.profiles || [])];
      const idx = profiles.findIndex((p) => p.id === entry.id);
      if (idx >= 0) profiles[idx] = entry;
      else profiles.push(entry);
      await postWorkspace({
        onboarding_done: true,
        profiles,
        active_profile_id: entry.id,
      });
      toast('Setup saved — credentials applied for this dashboard.', true);
      labelTouched = false;
      await loadHealth();
      await refreshWorkspaceUi();
      if (window.__mtkSwitchTab) window.__mtkSwitchTab('overview');
    } catch (e) {
      toastApiError(e);
    }
  });

  $('btnSetupReload')?.addEventListener('click', () => loadWorkspaceIntoForm());
  $('btnSetupApplyActive')?.addEventListener('click', async () => {
    const id = ($('setupActiveProfile')?.value || '').trim();
    if (!id) return toast('Select a profile first', false);
    try {
      await postWorkspace({ onboarding_done: true, active_profile_id: id });
      toast('Active profile applied.', true);
      await loadHealth();
      await loadWorkspaceIntoForm();
    } catch (e) {
      toastApiError(e);
    }
  });

  showStep(0);
  renderVpnOverridesFromProfile({});
  loadWorkspaceIntoForm();

  initMitmCaImport({ prefix: 'setup' });
}
