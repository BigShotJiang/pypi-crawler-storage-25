import { $ } from '../core/dom.js';
import { api, toast, toastApiError, renderApiProblem } from '../core/api.js';
import { pushActivity } from '../core/activity.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

const PRESETS = {
  api: {
    label: 'Enter your API domain',
    placeholder: 'api.yourapp.com',
    action: 'redirect',
  },
  offline: {
    label: 'Domains to block (comma-separated)',
    placeholder: 'cdn.example.com, api.example.com',
    action: 'block',
    domains: ['cdn.cloudflare.com', 'googleapis.com', 's3.amazonaws.com'],
  },
  analytics: {
    label: 'Analytics domains to block',
    placeholder: 'google-analytics.com',
    action: 'block',
    domains: [
      'google-analytics.com',
      '*.google-analytics.com',
      'analytics.google.com',
      'mixpanel.com',
      'api.mixpanel.com',
      'api.segment.io',
      'cdn.segment.com',
      'api.amplitude.com',
    ],
  },
};

let activePreset = null;

export async function refreshDns() {
  const w = $('dnsTableWrap');
  if (!w) return;
  try {
    const d = await api('/api/dns/redirects');
    if (d.error) {
      w.innerHTML = `<div class="empty">${escapeHtml(d.error)}</div>`;
      return;
    }
    if (!d.redirects.length) {
      w.innerHTML = '<div class="empty">No active DNS rules</div>';
      return;
    }
    w.innerHTML =
      `<table><thead><tr><th>Domain</th><th>Target</th><th>Client</th><th>Type</th><th></th></tr></thead><tbody>` +
      d.redirects
        .map((r) => {
          const isBlock =
            r.target_ip === '127.0.0.1' || r.target_ip === '0.0.0.0';
          const typeBadge = isBlock
            ? '<span class="badge badge-danger">Block</span>'
            : '<span class="badge badge-success">Redirect</span>';
          return `<tr>
          <td class="mono">${escapeHtml(r.domain)}</td>
          <td class="mono">${escapeHtml(r.target_ip)}</td>
          <td class="mono">${r.client_ip || 'all'}</td>
          <td>${typeBadge}</td>
          <td><button class="btn btn-ghost btn-sm btn-danger-ghost" data-dns-rm="${encodeURIComponent(r.domain)}" data-dns-c="${r.client_ip ? encodeURIComponent(r.client_ip) : ''}" title="Remove this rule">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/></svg>
          </button></td>
        </tr>`;
        })
        .join('') +
      '</tbody></table>';
    w.querySelectorAll('[data-dns-rm]').forEach((b) => {
      b.addEventListener('click', async () => {
        try {
          const dom = decodeURIComponent(b.getAttribute('data-dns-rm'));
          const c = b.getAttribute('data-dns-c');
          let q = 'domain=' + encodeURIComponent(dom);
          if (c) q += '&client_ip=' + c;
          await api('/api/dns/redirect?' + q, { method: 'DELETE' });
          toast('DNS rule removed', true);
          const sdk = {
            python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.dns.remove(${pyStr(dom)}, client_ip=${c ? pyStr(decodeURIComponent(c)) : 'None'})`,
            rest: `DELETE /api/dns/redirect?${q}`,
          };
          publishSdkMirror({ title: 'DNS: remove rule', ...sdk });
          pushActivity(
            'dns',
            'Removed rule for ' + dom,
            true,
            sdk,
          );
          await refreshDns();
          await loadOverview();
        } catch (e) {
          toastApiError(e);
          pushActivity(
            'dns',
            'Remove failed: ' + (e instanceof Error ? e.message : String(e)),
            false,
          );
        }
      });
    });
  } catch (e) {
    renderApiProblem(w, e);
  }
}

function switchDnsTab(tabId) {
  document.querySelectorAll('.dns-tab').forEach((t) => {
    t.classList.toggle('active', t.dataset.dnsTab === tabId);
  });
  document.querySelectorAll('.dns-tab-content').forEach((c) => {
    c.style.display = 'none';
  });
  const content = $('dnsTab' + tabId.charAt(0).toUpperCase() + tabId.slice(1));
  if (content) content.style.display = 'block';
}

async function addRedirect(domain, clientIp, ttl, targetIp, toProxy) {
  const body = { domain, ttl, to_proxy: toProxy };
  if (clientIp) body.client_ip = clientIp;
  if (!toProxy && targetIp) body.target_ip = targetIp;
  await api('/api/dns/redirect', {
    method: 'POST',
    body: JSON.stringify(body),
  });
  return body;
}

async function blockDomain(domain, clientIp) {
  const body = {
    domain,
    ttl: 3600,
    to_proxy: false,
    target_ip: '127.0.0.1',
  };
  if (clientIp) body.client_ip = clientIp;
  await api('/api/dns/redirect', {
    method: 'POST',
    body: JSON.stringify(body),
  });
  return body;
}

export function initDnsPanel() {
  // Tab switching
  document.querySelectorAll('.dns-tab').forEach((tab) => {
    tab.addEventListener('click', () => switchDnsTab(tab.dataset.dnsTab));
  });

  // Target type toggle
  const toProxy = $('dnsToProxy');
  const toCustom = $('dnsToCustom');
  const targetInput = $('dnsTarget');
  if (toProxy && toCustom && targetInput) {
    toProxy.addEventListener('change', () => {
      targetInput.disabled = true;
      targetInput.value = '';
    });
    toCustom.addEventListener('change', () => {
      targetInput.disabled = false;
      targetInput.focus();
    });
  }

  // Add redirect
  $('btnDnsAdd')?.addEventListener('click', async () => {
    const domain = $('dnsDomain').value.trim();
    if (!domain) return toast('Domain required', false);
    const toProxyChecked = $('dnsToProxy')?.checked ?? true;
    const target = $('dnsTarget')?.value.trim();
    if (!toProxyChecked && !target) return toast('Target IP required', false);
    const ttl = Number($('dnsTtl')?.value) || 60;
    const clientIp = $('dnsClient')?.value.trim();
    try {
      await addRedirect(domain, clientIp, ttl, target, toProxyChecked);
      toast('DNS redirect added', true);
      const sdk = {
        python: toProxyChecked
          ? `kit.dns.redirect(${pyStr(domain)}, client_ip=${clientIp ? pyStr(clientIp) : 'None'}, ttl=${ttl})`
          : `kit.dns.redirect_to_ip(${pyStr(domain)}, ${pyStr(target)}, client_ip=${clientIp ? pyStr(clientIp) : 'None'})`,
        rest: `POST /api/dns/redirect`,
      };
      publishSdkMirror({ title: 'DNS: add redirect', ...sdk });
      pushActivity(
        'dns',
        `Redirect ${domain}` + (clientIp ? ` for ${clientIp}` : ''),
        true,
        sdk,
      );
      $('dnsDomain').value = '';
      await refreshDns();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity(
        'dns',
        'Add redirect failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  // Block domain
  $('btnDnsBlock')?.addEventListener('click', async () => {
    const domain = $('dnsBlockDomain')?.value.trim();
    if (!domain) return toast('Domain required', false);
    const clientIp = $('dnsBlockClient')?.value.trim();
    try {
      await blockDomain(domain, clientIp);
      toast(`Blocked ${domain}`, true);
      const sdk = {
        python: `kit.dns.redirect_to_ip(${pyStr(domain)}, "127.0.0.1", client_ip=${clientIp ? pyStr(clientIp) : 'None'})`,
        rest: `POST /api/dns/redirect`,
      };
      publishSdkMirror({ title: 'DNS: block domain', ...sdk });
      pushActivity(
        'dns',
        `Blocked ${domain}` + (clientIp ? ` for ${clientIp}` : ''),
        true,
        sdk,
      );
      $('dnsBlockDomain').value = '';
      await refreshDns();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity(
        'dns',
        'Block failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  // Preset cards
  document.querySelectorAll('.dns-preset-card').forEach((card) => {
    card.addEventListener('click', () => {
      const presetId = card.dataset.preset;
      const preset = PRESETS[presetId];
      if (!preset) return;
      activePreset = presetId;
      const configEl = $('dnsPresetConfig');
      const labelEl = $('dnsPresetLabel');
      const inputEl = $('dnsPresetDomain');
      if (configEl && labelEl && inputEl) {
        configEl.style.display = 'block';
        labelEl.textContent = preset.label;
        inputEl.placeholder = preset.placeholder;
        if (preset.domains) {
          inputEl.value = preset.domains.join(', ');
        } else {
          inputEl.value = '';
        }
        inputEl.focus();
      }
    });
  });

  $('btnDnsPresetCancel')?.addEventListener('click', () => {
    $('dnsPresetConfig').style.display = 'none';
    activePreset = null;
  });

  $('btnDnsPresetApply')?.addEventListener('click', async () => {
    const preset = PRESETS[activePreset];
    if (!preset) return;
    const input = $('dnsPresetDomain')?.value.trim();
    if (!input) return toast('Enter at least one domain', false);
    const domains = input
      .split(',')
      .map((d) => d.trim())
      .filter(Boolean);
    if (!domains.length) return toast('Enter at least one domain', false);
    try {
      let count = 0;
      for (const domain of domains) {
        if (preset.action === 'block') {
          await blockDomain(domain, '');
        } else {
          await addRedirect(domain, '', 60, '', true);
        }
        count++;
      }
      toast(
        `Applied ${count} ${preset.action === 'block' ? 'block' : 'redirect'} rule${count > 1 ? 's' : ''}`,
        true,
      );
      pushActivity(
        'dns',
        `Applied preset: ${activePreset} (${count} rules)`,
        true,
      );
      $('dnsPresetConfig').style.display = 'none';
      activePreset = null;
      await refreshDns();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity(
        'dns',
        'Preset failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  // Clear all
  $('btnDnsClearAll')?.addEventListener('click', async () => {
    if (!confirm('Clear all DNS rules? This cannot be undone.')) return;
    try {
      await api('/api/dns/redirect', { method: 'DELETE' });
      toast('All DNS rules cleared', true);
      const sdk = {
        python: 'kit.dns.clear_all()',
        rest: 'DELETE /api/dns/redirect',
      };
      publishSdkMirror({ title: 'DNS: clear all', ...sdk });
      pushActivity('dns', 'Cleared all DNS rules', true, sdk);
      await refreshDns();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity(
        'dns',
        'Clear all failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  // Flush cache
  $('btnDnsFlush')?.addEventListener('click', async () => {
    try {
      await api('/api/dns/flush', { method: 'POST' });
      toast('DNS cache flushed', true);
      const sdk = {
        python: 'kit.dns.flush_cache()',
        rest: 'POST /api/dns/flush',
      };
      publishSdkMirror({ title: 'DNS: flush cache', ...sdk });
      pushActivity('dns', 'Flushed DNS cache', true, sdk);
    } catch (e) {
      toastApiError(e);
      pushActivity(
        'dns',
        'Flush failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  // Refresh button
  $('btnDnsRefresh')?.addEventListener('click', () => refreshDns());
}
