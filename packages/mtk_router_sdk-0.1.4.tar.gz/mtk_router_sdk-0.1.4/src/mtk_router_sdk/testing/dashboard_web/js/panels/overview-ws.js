import { $ } from '../core/dom.js';
import { api } from '../core/api.js';
import * as state from '../core/state.js';
import { appendLiveFeed } from '../core/logs-render.js';

export function setOverviewProxyBanner(o) {
  const el = $('overviewBanner');
  if (!el) return;
  if (o && o.proxy_ok === false && o.proxy_error) {
    el.style.display = 'block';
    el.innerHTML = `<strong>Proxy / mtk-serve unreachable.</strong> ${o.proxy_error} <span style="color:var(--muted)">Restart <code>mtk dashboard start</code> (auto-starts mtk-serve on loopback when the port is free), run <code>mtk-serve</code> yourself, or fix <code>MTK_SERVICE_URL</code> in Setup.</span>`;
  } else {
    el.style.display = 'none';
  }
}

/**
 * @param {Record<string, unknown>} h
 */
export function applyRouterosUiState(h) {
  const supported = h.routeros_supported === true;
  document.body.classList.toggle('routeros-unsupported', !supported);
  const banner = $('routerCompatBanner');
  if (!banner) return;
  if (supported) {
    banner.hidden = true;
    banner.textContent = '';
    banner.removeAttribute('role');
    return;
  }
  banner.hidden = false;
  banner.setAttribute('role', 'alert');
  banner.textContent = '';
  const strong = document.createElement('strong');
  strong.textContent = 'Router automation disabled. ';
  banner.appendChild(strong);
  const msg = String(
    h.compat_message ||
      'This dashboard target is not a supported MikroTik RouterOS router.',
  );
  banner.appendChild(document.createTextNode(msg));
  if (h.compat_hint) {
    const span = document.createElement('span');
    span.style.color = 'var(--muted)';
    span.textContent = ' ' + String(h.compat_hint);
    banner.appendChild(span);
  }
  const tail = document.createElement('span');
  tail.style.color = 'var(--muted)';
  tail.textContent =
    ' Proxy, recording, and documentation still work if mtk-serve is available.';
  banner.appendChild(tail);
}

export async function loadHealth() {
  try {
    const h = await api('/api/health');
    state.setLastHealth(h);
    applyRouterosUiState(h);
    const el = $('healthBadges');
    if (!el) return;
    const mkOk = h.routeros_supported === true;
    const mkWarn = h.ssh_connected === true && !mkOk;
    const mkClass = mkOk ? 'ok' : mkWarn ? 'warn' : 'err';
    el.innerHTML = [
      ['MikroTik (RouterOS)', mkClass],
      ['mtk-serve', h.mtk_serve_proxy ? 'ok' : 'err'],
    ]
      .map(
        ([n, cls]) =>
          `<span class="badge ${cls}"><span class="dot"></span>${n}</span>`,
      )
      .join('');
  } catch {
    document.body.classList.remove('routeros-unsupported');
    const b = $('routerCompatBanner');
    if (b) {
      b.hidden = true;
      b.textContent = '';
    }
    const el = $('healthBadges');
    if (el)
      el.innerHTML = `<span class="badge err"><span class="dot"></span>Health check failed</span>`;
  }
  if (typeof window.__mtkRenderNetworkPanelStatus === 'function') {
    window.__mtkRenderNetworkPanelStatus();
  }
}

export async function loadOverview() {
  try {
    const o = await api('/api/overview');
    setOverviewProxyBanner(o);
    const st = $('overviewStats');
    if (st)
      st.innerHTML = [
        ['Network clients', o.network_clients, 'network'],
        ['DNS redirects', o.dns_redirects, 'dns'],
        ['Proxy rules', o.proxy_rules, 'proxy'],
        ['Log entries', o.proxy_log_total ?? '—', 'proxy'],
      ]
        .map(([k, v, tab]) => {
          const lock = tab === 'dns' ? ' data-requires-routeros' : '';
          return `<div class="stat-card clickable"${lock} data-go-tab="${tab}"><h3>${k}</h3><div class="val">${v}</div></div>`;
        })
        .join('');
    st?.querySelectorAll('[data-go-tab]').forEach((el) => {
      el.addEventListener('click', () => {
        const tab = el.getAttribute('data-go-tab');
        if (tab && window.__mtkSwitchTab) window.__mtkSwitchTab(tab);
      });
    });
  } catch (e) {
    setOverviewProxyBanner(null);
    const st = $('overviewStats');
    if (st) st.innerHTML = `<div class="empty">${e.message}</div>`;
  }
}

/** @param {() => void} onTick optional hook after each tick */
export function connectWs(onTick) {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const ws = new WebSocket(`${proto}//${location.host}/ws`);
  window._mtkWs = ws;
  ws.onopen = () => {
    const w = $('wsLabel');
    if (w) w.textContent = 'connected';
  };
  ws.onclose = () => {
    const w = $('wsLabel');
    if (w) w.textContent = 'reconnecting…';
    setTimeout(() => connectWs(onTick), 2500);
  };
  ws.onmessage = (ev) => {
    const d = JSON.parse(ev.data);
      if (d.type === 'tick') {
        window.__mtkOnNetworkTick?.(d);
        setOverviewProxyBanner({
        proxy_ok: d.proxy_ok !== false,
        proxy_error: d.proxy_error,
      });
      const st = $('overviewStats');
      if (st)
        st.innerHTML = [
          ['Network clients', d.network_clients, 'network'],
          ['DNS redirects', d.dns_redirects, 'dns'],
          ['Proxy rules', d.proxy_rules, 'proxy'],
          ['Log entries', d.proxy_log_total ?? '—', 'proxy'],
        ]
          .map(([k, v, tab]) => {
            const lock = tab === 'dns' ? ' data-requires-routeros' : '';
            return `<div class="stat-card clickable"${lock} data-go-tab="${tab}"><h3>${k}</h3><div class="val">${v}</div></div>`;
          })
          .join('');
      st?.querySelectorAll('[data-go-tab]').forEach((el) => {
        el.addEventListener('click', () => {
          const tab = el.getAttribute('data-go-tab');
          if (tab && window.__mtkSwitchTab) window.__mtkSwitchTab(tab);
        });
      });
      if (d.logs?.length) appendLiveFeed(d.logs);
      onTick?.();
    }
  };
}
