/** WebSocket client IP filter (null = all). */
export let wsFilter = null;
export function setWsFilter(v) {
  wsFilter = v;
}

export const activityLog = [];
export let proxyLogCache = null;
export let netLogCache = null;
/** HTML string (escaped by caller) for Network tab traffic log when last load returned 0 rows. */
export let netLogEmptyDetailHtml = null;
/** @type {any[] | null} Last network conditions rows (API or WebSocket). */
export let networkConditionsCache = null;

/** @type {{ ok: true; rowCount: number; at: number } | { ok: false; error: string; at: number } | null} */
export let networkConditionsMeta = null;

export function setNetworkConditionsCache(v) {
  networkConditionsCache = v;
}

export function setNetworkConditionsMeta(v) {
  networkConditionsMeta = v;
}

/** @type {Record<string, unknown> | null} Last /api/health payload (SDK Connect pipeline). */
export let lastHealth = null;
export function setLastHealth(h) {
  lastHealth = h;
}
/** @type {{ client_ip: string, path: string, method: string } | null} */
export let lastOverrideWatch = null;

export function setProxyLogCache(v) {
  proxyLogCache = v;
}
export function setNetLogCache(v) {
  netLogCache = v;
}

export function setNetLogEmptyDetailHtml(v) {
  netLogEmptyDetailHtml = v;
}

/** `'list'` | `'tree'` — Network tab HTTP log layout. */
export let netLogViewMode = 'list';
export function setNetLogViewMode(v) {
  netLogViewMode = v === 'tree' ? 'tree' : 'list';
}
export function setLastOverrideWatch(v) {
  lastOverrideWatch = v;
}
