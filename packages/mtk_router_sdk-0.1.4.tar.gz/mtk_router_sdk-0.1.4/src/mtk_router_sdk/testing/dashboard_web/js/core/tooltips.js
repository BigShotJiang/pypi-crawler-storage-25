/**
 * Rich hover tooltips via [data-tooltip="..."] (dashboard-only UX).
 */
let _tip;
let _hideTimer;
let _mx = 0;
let _my = 0;

function ensureTip() {
  if (!_tip) {
    _tip = document.createElement('div');
    _tip.className = 'mtk-tooltip';
    _tip.setAttribute('role', 'tooltip');
    document.body.appendChild(_tip);
  }
  return _tip;
}

function positionTip() {
  if (!_tip || !_tip.classList.contains('visible')) return;
  const pad = 12;
  const w = _tip.offsetWidth;
  const h = _tip.offsetHeight;
  let x = _mx + 14;
  let y = _my + 16;
  x = Math.max(8, Math.min(x, window.innerWidth - w - 8));
  y = Math.max(8, Math.min(y, window.innerHeight - h - 8));
  _tip.style.left = `${x}px`;
  _tip.style.top = `${y}px`;
}

function showFor(el) {
  const text = el.getAttribute('data-tooltip');
  if (!text) return;
  clearTimeout(_hideTimer);
  const t = ensureTip();
  t.textContent = text;
  t.classList.add('visible');
  requestAnimationFrame(positionTip);
}

function hide() {
  _hideTimer = setTimeout(() => {
    _tip?.classList.remove('visible');
  }, 60);
}

export function initTooltips() {
  document.addEventListener(
    'mousemove',
    (e) => {
      _mx = e.clientX;
      _my = e.clientY;
      if (_tip?.classList.contains('visible')) positionTip();
    },
    { passive: true },
  );

  document.body.addEventListener(
    'mouseover',
    (e) => {
      const el = e.target?.closest?.('[data-tooltip]');
      if (el) showFor(el);
    },
    true,
  );

  document.body.addEventListener(
    'mouseout',
    (e) => {
      const from = e.target?.closest?.('[data-tooltip]');
      const to = e.relatedTarget?.closest?.('[data-tooltip]');
      if (from && from === to) return;
      if (from) hide();
    },
    true,
  );
}
