import { $ } from '../core/dom.js';
import { api, toast, toastApiError, renderApiProblem } from '../core/api.js';
import { escapeHtml, pushActivity } from '../core/activity.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

export async function loadScenarios() {
  try {
    const d = await api('/api/scenarios/list');
    const items = (d.scenarios || []).map((x) =>
      typeof x === 'string' ? { name: x, description: '' } : x,
    );
    const sel = $('scenarioSelect');
    if (sel)
      sel.innerHTML =
        '<option value="">— Select —</option>' +
        items.map((s) => `<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`).join('');
    const cards = $('scenarioCards');
    if (cards)
      cards.innerHTML =
        items
          .map((s) => {
            const desc = (s.description || '').trim();
            return `<div class="feature-card" data-scenario="${escapeHtml(s.name)}">
          <h3><span class="icon">⚡</span> ${escapeHtml(s.name)}</h3>
          <p>${desc ? escapeHtml(desc) : '<span class="hint">No description in scenario YAML.</span>'}</p>
        </div>`;
          })
          .join('') || '<div class="empty">No scenarios available</div>';
    cards?.querySelectorAll('[data-scenario]').forEach((el) => {
      el.addEventListener('click', () => runScenarioQuick(el.getAttribute('data-scenario')));
    });
  } catch (e) {
    const sel = $('scenarioSelect');
    if (sel) sel.innerHTML = '<option value="">— Error loading —</option>';
    const cards = $('scenarioCards');
    if (cards) renderApiProblem(cards, e);
    toastApiError(e);
  }
}

export async function runScenarioQuick(name) {
  const ip = $('scenarioClient').value.trim();
  if (!ip) {
    toast('Enter client IP first', false);
    return;
  }
  $('scenarioSelect').value = name;
  $('btnScenarioRun').click();
}

export function initScenariosPanel() {
  $('btnScenarioRun')?.addEventListener('click', async () => {
    const name = $('scenarioSelect').value;
    const client_ip = $('scenarioClient').value.trim();
    if (!name || !client_ip) return toast('Select scenario and enter client IP', false);
    $('scenarioLog').innerHTML = '<div class="empty">Running scenario...</div>';
    try {
      const r = await api('/api/scenarios/run', {
        method: 'POST',
        body: JSON.stringify({ name, client_ip }),
      });
      $('scenarioLog').innerHTML = `<div style="padding:16px;font-family:var(--mono);font-size:12px;line-height:1.6">
          <div style="color:var(--ok)">✓ Scenario "${name}" completed</div>
          ${(r.steps || []).map((s) => `<div style="color:var(--muted)">  → ${s.action}: ${s.status || 'ok'}</div>`).join('')}
        </div>`;
      toast('Scenario completed', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nresult = kit.scenarios.run(${pyStr(name)}, client_ip=${pyStr(client_ip)})`,
        rest: `POST /api/scenarios/run\n${JSON.stringify({ name, client_ip }, null, 2)}`,
      };
      publishSdkMirror({ title: `Scenario: ${name}`, ...sdk });
      pushActivity('scenario', `Ran “${name}” on ${client_ip}`, true, sdk);
      await loadOverview();
    } catch (e) {
      renderApiProblem($('scenarioLog'), e);
      toastApiError(e);
      pushActivity('scenario', `“${name}” failed: ${e instanceof Error ? e.message : String(e)}`, false);
    }
  });
}
