import { $ } from '../core/dom.js';
import { api, toast, toastApiError, renderApiProblem } from '../core/api.js';
import { pushActivity } from '../core/activity.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

function escapeHtml(s) {
  const div = document.createElement('div');
  div.textContent = s;
  return div.innerHTML;
}

function setRecordingState(isRecording, sessionName = '') {
  const card = $('recordStatusCard');
  const label = $('recordStatusLabel');
  const hint = $('recordStatusHint');
  const btnStart = $('btnRecordStart');
  const btnStop = $('btnRecordStop');
  
  if (isRecording) {
    card?.classList.add('recording');
    if (label) label.textContent = 'Recording';
    if (hint) hint.textContent = sessionName ? `Session: ${sessionName}` : 'Capturing traffic...';
    if (btnStart) btnStart.disabled = true;
    if (btnStop) btnStop.disabled = false;
  } else {
    card?.classList.remove('recording');
    if (label) label.textContent = 'Idle';
    if (hint) hint.textContent = 'Ready to record';
    if (btnStart) btnStart.disabled = false;
    if (btnStop) btnStop.disabled = true;
  }
}

export async function loadRecordings() {
  try {
    const d = await api('/api/recording/list');
    const list = $('recordList');
    const sel = $('replaySelect');
    if (!d.recordings?.length) {
      if (list) list.innerHTML = '<div class="empty">No recordings yet. Start recording to capture HTTP traffic.</div>';
      if (sel) sel.innerHTML = '<option value="">— No recordings available —</option>';
      return;
    }
    if (list) {
      list.innerHTML =
        `<table><thead><tr><th>Name</th><th>Entries</th><th>Created</th><th style="width:80px"></th></tr></thead><tbody>` +
        d.recordings
          .map(
            (r) =>
              `<tr>
                <td class="mono">${escapeHtml(r.name)}</td>
                <td>${r.entries || '—'}</td>
                <td class="mono">${r.created || '—'}</td>
                <td><button class="btn btn-ghost btn-sm btn-danger-ghost" data-delete-recording="${escapeHtml(r.name)}" title="Delete this recording">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14"/></svg>
                </button></td>
              </tr>`,
          )
          .join('') +
        '</tbody></table>';
      list.querySelectorAll('[data-delete-recording]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const name = btn.getAttribute('data-delete-recording');
          if (!confirm(`Delete recording "${name}"?\n\nThis cannot be undone.`)) return;
          try {
            await api(`/api/recording/delete?name=${encodeURIComponent(name)}`, { method: 'DELETE' });
            toast(`Deleted "${name}"`, true);
            pushActivity('recording', `Deleted recording "${name}"`, true);
            await loadRecordings();
          } catch (e) {
            toastApiError(e);
            pushActivity('recording', 'Delete failed: ' + (e instanceof Error ? e.message : String(e)), false);
          }
        });
      });
    }
    if (sel)
      sel.innerHTML =
        '<option value="">— Select recording —</option>' +
        d.recordings.map((r) => `<option value="${escapeHtml(r.name)}">${escapeHtml(r.name)}</option>`).join('');
  } catch (e) {
    const list = $('recordList');
    if (list) renderApiProblem(list, e);
    const sel = $('replaySelect');
    if (sel) sel.innerHTML = '<option value="">— Error loading —</option>';
  }
}

export function initRecordingPanel() {
  // Initialize to idle state
  setRecordingState(false);
  
  $('btnRecordStart')?.addEventListener('click', async () => {
    const client_ip = $('recordClient').value.trim();
    const name = $('recordName').value.trim() || 'session-' + Date.now();
    if (!client_ip) return toast('Client IP required', false);
    
    // Disable button immediately for feedback
    const btnStart = $('btnRecordStart');
    if (btnStart) btnStart.disabled = true;
    
    try {
      await api('/api/recording/start', { method: 'POST', body: JSON.stringify({ client_ip, name }) });
      setRecordingState(true, name);
      toast(`Recording started: ${name}`, true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nsession_id = kit.recorder.start(${pyStr(client_ip)}, name=${pyStr(name)})`,
        rest: `POST /api/recording/start\n${JSON.stringify({ client_ip, name }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Recording: start', ...sdk });
      pushActivity('recording', `Started "${name}" @ ${client_ip}`, true, sdk);
    } catch (e) {
      // Re-enable on error
      if (btnStart) btnStart.disabled = false;
      toastApiError(e);
      pushActivity('recording', 'Start failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  
  $('btnRecordStop')?.addEventListener('click', async () => {
    const client_ip = $('recordClient').value.trim();
    if (!client_ip) return toast('Client IP required to stop', false);
    
    // Disable button immediately
    const btnStop = $('btnRecordStop');
    if (btnStop) btnStop.disabled = true;
    
    try {
      await api('/api/recording/stop', { method: 'POST', body: JSON.stringify({ client_ip }) });
      setRecordingState(false);
      toast('Recording stopped and saved', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nhar_path = kit.recorder.stop_for_client(${pyStr(client_ip)})`,
        rest: `POST /api/recording/stop\n${JSON.stringify({ client_ip }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Recording: stop → HAR', ...sdk });
      pushActivity('recording', 'Stopped recording @ ' + client_ip, true, sdk);
      await loadRecordings();
    } catch (e) {
      // Re-enable stop button on error (still recording)
      if (btnStop) btnStop.disabled = false;
      toastApiError(e);
      pushActivity('recording', 'Stop failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  
  $('btnRecordRefresh')?.addEventListener('click', () => loadRecordings());
  
  $('btnReplay')?.addEventListener('click', async () => {
    const name = $('replaySelect').value;
    const client_ip = $('replayClient').value.trim();
    if (!name) return toast('Select a recording session first', false);
    if (!client_ip) return toast('Enter target client IP', false);
    
    try {
      const result = await api('/api/recording/replay', { method: 'POST', body: JSON.stringify({ name, client_ip }) });
      const rulesCount = result.rules_created || 0;
      toast(`Replay created ${rulesCount} proxy rule(s)`, true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\nfrom pathlib import Path\n\nkit = MtkTestKit.from_env()\n# HAR path matches MTK_RECORDINGS_DIR / "${name}.har"\nrules = kit.recorder.replay(${pyStr(client_ip)}, Path(${pyStr(name + '.har')}))`,
        rest: `POST /api/recording/replay\n${JSON.stringify({ name, client_ip }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Recording: replay', ...sdk });
      pushActivity('recording', `Replay "${name}" → ${client_ip} (${rulesCount} rules)`, true, sdk);
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('recording', 'Replay failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
}
