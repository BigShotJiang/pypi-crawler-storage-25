/**
 * @typedef {{ status: number, title?: string, hints?: string[], module?: string, technical?: string, code?: string }} ApiErrorOpts
 */

export class ApiError extends Error {
  /**
   * @param {string} message
   * @param {ApiErrorOpts} [opts]
   */
  constructor(message, opts = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = opts.status ?? 0;
    this.title = opts.title ?? '';
    this.hints = Array.isArray(opts.hints) ? opts.hints : [];
    this.module = opts.module ?? '';
    this.technical = opts.technical ?? '';
    this.code = opts.code ?? '';
  }
}

/**
 * @param {string} path
 * @param {RequestInit & { headers?: Record<string, string> }} [opts]
 */
export async function api(path, opts = {}) {
  const r = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const hints = Array.isArray(data.hints) ? data.hints.map(String) : [];
    const title = typeof data.title === 'string' ? data.title : '';
    const msg =
      data.user_message ||
      data.message ||
      data.error ||
      data.detail ||
      r.statusText;
    throw new ApiError(String(msg || 'Request failed'), {
      status: r.status,
      title,
      hints,
      module: typeof data.module === 'string' ? data.module : '',
      technical: typeof data.technical === 'string' ? data.technical : '',
      code: typeof data.code === 'string' ? data.code : '',
    });
  }
  return data;
}

/** @param {string} msg @param {boolean} ok */
export function toast(msg, ok) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.innerHTML = '';
  const div = document.createElement('div');
  div.className = 'toast-msg';
  div.textContent = msg;
  t.appendChild(div);
  t.className = 'show ' + (ok ? 'ok' : 'err');
  clearTimeout(/** @type {any} */ (toast)._tm);
  /** @type {any} */ (toast)._tm = setTimeout(() => {
    t.className = '';
    t.innerHTML = '';
  }, ok ? 4500 : 5200);
}

/**
 * Rich error toast: title, message, hints, optional technical details.
 * @param {unknown} err
 */
export function toastApiError(err) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.innerHTML = '';
  t.className = 'show err toast-rich';

  if (err instanceof ApiError && (err.title || err.hints.length || err.technical)) {
    if (err.title) {
      const h = document.createElement('div');
      h.className = 'toast-head';
      h.textContent = err.title;
      t.appendChild(h);
    }
    const b = document.createElement('div');
    b.className = 'toast-msg';
    b.textContent = err.message;
    t.appendChild(b);
    if (err.module) {
      const m = document.createElement('div');
      m.className = 'toast-module';
      m.textContent = 'Module: ' + err.module + (err.code ? ' · ' + err.code : '');
      t.appendChild(m);
    }
    if (err.hints.length) {
      const ul = document.createElement('ul');
      ul.className = 'toast-hints';
      err.hints.forEach((hint) => {
        const li = document.createElement('li');
        li.textContent = hint;
        ul.appendChild(li);
      });
      t.appendChild(ul);
    }
    if (err.technical && err.technical !== err.message) {
      const det = document.createElement('details');
      det.className = 'toast-tech';
      const sum = document.createElement('summary');
      sum.textContent = 'Technical detail';
      det.appendChild(sum);
      const pre = document.createElement('pre');
      pre.textContent = err.technical;
      det.appendChild(pre);
      t.appendChild(det);
    }
  } else {
    const msg = err instanceof Error ? err.message : String(err);
    const div = document.createElement('div');
    div.className = 'toast-msg';
    div.textContent = msg;
    t.appendChild(div);
  }

  const ms =
    err instanceof ApiError && (err.hints.length > 0 || err.technical) ? 14000 : 6000;
  clearTimeout(/** @type {any} */ (toastApiError)._tm);
  /** @type {any} */ (toastApiError)._tm = setTimeout(() => {
    t.className = '';
    t.innerHTML = '';
  }, ms);
}

/**
 * Inline empty-state / error panel for tables.
 * @param {HTMLElement | null} el
 * @param {unknown} err
 */
export function renderApiProblem(el, err) {
  if (!el) return;
  el.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'api-problem-card';

  if (err instanceof ApiError) {
    if (err.title) {
      const th = document.createElement('div');
      th.className = 'api-problem-title';
      th.textContent = err.title;
      wrap.appendChild(th);
    }
    const msg = document.createElement('p');
    msg.className = 'api-problem-msg';
    msg.textContent = err.message;
    wrap.appendChild(msg);
    if (err.module) {
      const meta = document.createElement('div');
      meta.className = 'api-problem-meta';
      meta.textContent = [err.module, err.code].filter(Boolean).join(' · ');
      wrap.appendChild(meta);
    }
    if (err.hints.length) {
      const sh = document.createElement('div');
      sh.className = 'api-problem-sub';
      sh.textContent = 'What you can do';
      wrap.appendChild(sh);
      const ul = document.createElement('ul');
      ul.className = 'api-problem-hints';
      err.hints.forEach((h) => {
        const li = document.createElement('li');
        li.textContent = h;
        ul.appendChild(li);
      });
      wrap.appendChild(ul);
    }
    if (err.technical && err.technical !== err.message) {
      const det = document.createElement('details');
      det.className = 'api-problem-tech';
      const sum = document.createElement('summary');
      sum.textContent = 'Technical detail';
      det.appendChild(sum);
      const pre = document.createElement('pre');
      pre.textContent = err.technical;
      det.appendChild(pre);
      wrap.appendChild(det);
    }
  } else {
    const msg = err instanceof Error ? err.message : String(err);
    const p = document.createElement('p');
    p.className = 'api-problem-msg';
    p.textContent = msg;
    wrap.appendChild(p);
  }

  el.appendChild(wrap);
}
