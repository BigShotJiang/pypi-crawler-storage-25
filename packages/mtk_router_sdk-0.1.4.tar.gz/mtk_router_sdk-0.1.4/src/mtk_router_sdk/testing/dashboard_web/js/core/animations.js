/**
 * MTK Dashboard — Interactive Animation Handlers
 * Triggers animations based on user interactions and data updates.
 */

/** Button ripple effect */
export function initRippleEffect() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn');
    if (!btn) return;
    
    const rect = btn.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    
    btn.style.setProperty('--ripple-x', `${x}%`);
    btn.style.setProperty('--ripple-y', `${y}%`);
    
    btn.classList.remove('ripple');
    void btn.offsetWidth; // Force reflow
    btn.classList.add('ripple');
    
    setTimeout(() => btn.classList.remove('ripple'), 600);
  });
}

/** Track previous values for change detection */
const _prevValues = new Map();

/** Animate value changes in live stats */
export function animateValueChange(elementId, newValue) {
  const el = document.getElementById(elementId);
  if (!el) return;
  
  const prevValue = _prevValues.get(elementId);
  const currentText = el.textContent;
  
  if (prevValue !== undefined && prevValue !== newValue && newValue !== currentText) {
    el.classList.remove('value-changed');
    void el.offsetWidth;
    el.classList.add('value-changed');
    
    // Also add counter tick animation
    el.classList.add('counter-animate', 'tick');
    setTimeout(() => el.classList.remove('tick'), 300);
  }
  
  _prevValues.set(elementId, newValue);
}

/** Animate counter with smooth number transition */
export function animateCounter(elementId, targetValue, duration = 500) {
  const el = document.getElementById(elementId);
  if (!el) return;
  
  const startValue = parseFloat(el.textContent.replace(/[^0-9.-]/g, '')) || 0;
  const startTime = performance.now();
  const suffix = el.textContent.replace(/[0-9.-]/g, '').trim();
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    
    // Ease out quad
    const eased = 1 - (1 - progress) * (1 - progress);
    const current = startValue + (targetValue - startValue) * eased;
    
    el.textContent = Math.round(current) + (suffix ? ' ' + suffix : '');
    
    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }
  
  requestAnimationFrame(update);
}

/** Pulse effect for status changes */
export function pulseElement(element) {
  if (!element) return;
  
  element.classList.remove('banner-update', 'status-change');
  void element.offsetWidth;
  element.classList.add('banner-update');
  
  setTimeout(() => element.classList.remove('banner-update'), 600);
}

/** Badge status change animation */
export function animateBadgeChange(badge) {
  if (!badge) return;
  
  badge.classList.remove('status-change');
  void badge.offsetWidth;
  badge.classList.add('status-change');
  
  setTimeout(() => badge.classList.remove('status-change'), 500);
}

/** Success checkmark animation */
export function showSuccessCheck(container) {
  if (!container) return;
  
  const check = document.createElement('span');
  check.className = 'success-check';
  check.innerHTML = '✓';
  check.style.cssText = `
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    background: var(--ok);
    color: white;
    border-radius: 50%;
    font-size: 14px;
    font-weight: bold;
    margin-left: 8px;
  `;
  
  container.appendChild(check);
  
  setTimeout(() => check.remove(), 2000);
}

/** Error shake animation */
export function shakeElement(element) {
  if (!element) return;
  
  element.classList.remove('error-shake');
  void element.offsetWidth;
  element.classList.add('error-shake');
  
  setTimeout(() => element.classList.remove('error-shake'), 500);
}

/** Smooth scroll to element */
export function smoothScrollTo(element, offset = 0) {
  if (!element) return;
  
  const y = element.getBoundingClientRect().top + window.scrollY - offset;
  
  window.scrollTo({
    top: y,
    behavior: 'smooth'
  });
}

/** Stagger animation for list items */
export function staggerListAnimation(container, itemSelector, delayIncrement = 50) {
  if (!container) return;
  
  const items = container.querySelectorAll(itemSelector);
  items.forEach((item, index) => {
    item.style.setProperty('--stagger-delay', `${index * delayIncrement}ms`);
    item.style.animationDelay = `${index * delayIncrement}ms`;
  });
}

/** Loading state for buttons */
export function setButtonLoading(button, loading = true) {
  if (!button) return;
  
  if (loading) {
    button.disabled = true;
    button.dataset.originalText = button.innerHTML;
    button.innerHTML = '<span class="spinner spinner-sm"></span>';
    button.style.minWidth = button.offsetWidth + 'px';
  } else {
    button.disabled = false;
    button.innerHTML = button.dataset.originalText || button.innerHTML;
    button.style.minWidth = '';
    delete button.dataset.originalText;
  }
}

/** Card loading overlay */
export function setCardLoading(card, loading = true) {
  if (!card) return;
  
  let overlay = card.querySelector('.loading-overlay');
  
  if (loading) {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'loading-overlay';
      overlay.innerHTML = '<span class="spinner"></span>';
      card.style.position = 'relative';
      card.appendChild(overlay);
    }
    requestAnimationFrame(() => overlay.classList.add('active'));
  } else if (overlay) {
    overlay.classList.remove('active');
    setTimeout(() => overlay.remove(), 250);
  }
}

/** Intersection Observer for scroll animations */
export function initScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
  );
  
  document.querySelectorAll('.animate-on-scroll').forEach((el) => {
    observer.observe(el);
  });
}

/** Progress bar smooth fill */
export function animateProgressBar(barElement, percentage, duration = 800) {
  if (!barElement) return;
  
  barElement.style.transition = `width ${duration}ms cubic-bezier(0.16, 1, 0.3, 1)`;
  barElement.style.width = `${Math.min(100, Math.max(0, percentage))}%`;
}

/** Typing effect for text */
export function typeText(element, text, speed = 30) {
  if (!element) return Promise.resolve();
  
  return new Promise((resolve) => {
    element.textContent = '';
    let i = 0;
    
    function type() {
      if (i < text.length) {
        element.textContent += text.charAt(i);
        i++;
        setTimeout(type, speed);
      } else {
        resolve();
      }
    }
    
    type();
  });
}

/** Highlight element briefly */
export function highlightElement(element, color = 'var(--accent)') {
  if (!element) return;
  
  const originalBoxShadow = element.style.boxShadow;
  element.style.transition = 'box-shadow 0.3s ease';
  element.style.boxShadow = `0 0 0 3px ${color}40, 0 0 20px ${color}30`;
  
  setTimeout(() => {
    element.style.boxShadow = originalBoxShadow;
  }, 1500);
}

/** Initialize all animation handlers */
export function initAnimations() {
  initRippleEffect();
  initScrollAnimations();
  
  // Add hover lift to cards
  document.querySelectorAll('.net-control-card, .live-stat-card').forEach((card) => {
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-2px)';
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}

// Auto-initialize on DOMContentLoaded
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAnimations);
  } else {
    initAnimations();
  }
}
