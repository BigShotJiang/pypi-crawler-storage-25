import { $ } from '../core/dom.js';
import { api, toast, toastApiError, renderApiProblem } from '../core/api.js';
import * as state from '../core/state.js';
import { pushActivity } from '../core/activity.js';
import { renderLogEntryList } from '../core/logs-render.js';
import { loadOverview } from './overview-ws.js';
import { publishSdkMirror } from './sdk-connect.js';
import { initProxyPresets } from './proxy-presets.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

/** Glob-style path match (RouterOS-style *). */
export function pathMatches(pattern, pathStr) {
  if (!pattern || !pathStr) return false;
  if (pattern === '*') return true;
  const esc = pattern
    .replace(/[.+^${}()|[\]\\]/g, '\\$&')
    .replace(/\*/g, '.*');
  try {
    return new RegExp('^' + esc + '$').test(pathStr);
  } catch {
    return pathStr.includes(pattern.replace(/\*/g, ''));
  }
}

function setOverrideValidationUi(mode, text) {
  const card = $('proxyOverrideValidation');
  const msg = $('proxyOverrideValidationMsg');
  if (!card || !msg) return;
  card.hidden = false;
  card.classList.remove('validation-card--idle', 'validation-card--ok', 'validation-card--wait', 'validation-card--err');
  card.classList.add('validation-card--' + mode);
  msg.textContent = text;
}

export async function loadProxyRulesAndLogs() {
  const ip = $('proxyFilterIp').value.trim();
  const q = ip ? '?client_ip=' + encodeURIComponent(ip) : '';
  const wrap = $('proxyRulesWrap');
  try {
    const rules = await api('/api/proxy/rules' + q);
    const logs = await api('/api/proxy/logs' + q + (q ? '&' : '?') + 'limit=100');
    if (wrap)
      wrap.innerHTML = rules.rules.length
      ? `<table><thead><tr><th>ID</th><th>Client</th><th>Path</th><th>Action</th><th>Status</th><th>Delay</th><th></th></tr></thead><tbody>` +
        rules.rules
          .map(
            (r) => `<tr>
              <td class="mono">${(r.id || '').slice(0, 8)}…</td>
              <td class="mono">${r.client_ip || '*'}</td>
              <td class="mono">${r.path_pattern}</td>
              <td>${r.action}</td>
              <td>${r.response_status || '—'}</td>
              <td>${r.delay_ms || '—'}</td>
              <td><button class="btn btn-ghost btn-sm" data-del-rule="${r.id}">Delete</button></td>
            </tr>`,
          )
          .join('') +
        '</tbody></table>'
        : '<div class="empty">No rules</div>';
    wrap?.querySelectorAll('[data-del-rule]').forEach((b) => {
      b.addEventListener('click', async () => {
        try {
          await api('/api/proxy/rule/' + b.dataset.delRule, { method: 'DELETE' });
          toast('Rule deleted', true);
          const rid = b.dataset.delRule || '';
          const sdk = {
            python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.delete_rule(${pyStr(rid)})`,
            rest: `DELETE /api/proxy/rule/${rid}`,
          };
          publishSdkMirror({ title: 'Proxy: delete rule', ...sdk });
          pushActivity('proxy', 'Deleted rule ' + rid.slice(0, 8) + '…', true, sdk);
          await loadProxyRulesAndLogs();
        } catch (e) {
          toastApiError(e);
          pushActivity('proxy', 'Delete rule failed: ' + (e instanceof Error ? e.message : String(e)), false);
        }
      });
    });
    state.setProxyLogCache(logs.entries || []);
    renderLogEntryList(
      state.proxyLogCache,
      'proxyLogsWrap',
      $('proxyLogSearch'),
      'Click “Load rules & logs”',
    );
    return { rules, logs };
  } catch (e) {
    if (wrap) renderApiProblem(wrap, e);
    state.setProxyLogCache(null);
    const lw = $('proxyLogsWrap');
    if (lw) lw.innerHTML = '<div class="empty">Could not load logs — fix the error above or retry.</div>';
    throw e;
  }
}

async function scanOverrideHits() {
  const watch = state.lastOverrideWatch;
  if (!watch) {
    setOverrideValidationUi('err', 'Add an override rule first.');
    return;
  }
  setOverrideValidationUi('wait', 'Scanning log for matching traffic…');
  try {
    const q = '?limit=120&client_ip=' + encodeURIComponent(watch.client_ip);
    const data = await api('/api/proxy/logs' + q);
    const entries = data.entries || [];
    const hit = entries.find((e) => {
      if (e.client_ip !== watch.client_ip) return false;
      if (!pathMatches(watch.path, e.path || '')) return false;
      if (watch.method && (e.method || '').toUpperCase() !== watch.method.toUpperCase()) return false;
      const act = String(e.action_taken || '').toLowerCase();
      return act === 'override' || act.includes('override');
    });
    if (hit) {
      setOverrideValidationUi(
        'ok',
        `Override is working. Latest hit: ${hit.method} ${hit.path} → action “${hit.action_taken}”, HTTP ${hit.response_status}, ${hit.total_latency_ms ?? '—'} ms at ${hit.timestamp || '?'}.`,
      );
      pushActivity('proxy', `Validation OK: override hit ${hit.path}`, true);
    } else {
      setOverrideValidationUi(
        'wait',
        `No log line yet for ${watch.client_ip} + path pattern “${watch.path}” with action override. Generate a request from the device (or curl through the proxy), then Scan again.`,
      );
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    setOverrideValidationUi('err', 'Could not read log: ' + msg);
    toastApiError(e);
  }
}

export function initProxyPanel() {
  document.querySelectorAll('#proxyTabs button').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#proxyTabs button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.proxy-tab-content').forEach((c) => (c.style.display = 'none'));
      const id =
        'proxyTab' + btn.dataset.proxyTab.charAt(0).toUpperCase() + btn.dataset.proxyTab.slice(1);
      const el = $(id);
      if (el) el.style.display = 'block';
    });
  });

  $('btnProxyAddOverride')?.addEventListener('click', async () => {
    const client_ip = $('proxyRuleClient').value.trim();
    const path = $('proxyRulePath').value.trim();
    if (!client_ip) return toast('Client IP required (per-device rules)', false);
    if (!path) return toast('Path pattern required', false);
    let body;
    try {
      body = JSON.parse($('proxyRuleBody').value || '{}');
    } catch {
      return toast('Invalid JSON body', false);
    }
    const status = Number($('proxyRuleStatus').value) || 200;
    const method = $('proxyRuleMethod').value || '';
    try {
      await api('/api/proxy/rule', {
        method: 'POST',
        body: JSON.stringify({ client_ip, path, body, status, method: method || null, action: 'override' }),
      });
      toast('Override rule added', true);
      const bodyJson = JSON.stringify(JSON.stringify(body));
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\nimport json\n\nkit = MtkTestKit.from_env()\nkit.proxy.set_response(${pyStr(client_ip)}, ${pyStr(path)}, json.loads(${bodyJson}), status=${status})`,
        rest: `POST /api/proxy/rule\n${JSON.stringify({ client_ip, path, body, status, method: method || null, action: 'override' }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Proxy: override rule', ...sdk });
      pushActivity('proxy', `Override ${path} → ${client_ip}`, true, sdk);
      state.setLastOverrideWatch({ client_ip, path, method, expectedStatus: status });
      setOverrideValidationUi(
        'idle',
        `Rule saved. From device ${client_ip}, request a URL matching “${path}” (method: ${method || 'any'}). Then tap “Scan logs for hits” or load logs below.`,
      );
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Override rule failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyCheckOverride')?.addEventListener('click', () => scanOverrideHits());
  $('btnProxyLoadAfterOverride')?.addEventListener('click', async () => {
    try {
      $('proxyFilterIp').value = state.lastOverrideWatch?.client_ip || $('proxyFilterIp').value;
      await loadProxyRulesAndLogs();
      toast('Rules & logs loaded', true);
    } catch (e) {
      toastApiError(e);
    }
  });

  $('btnProxyAddError')?.addEventListener('click', async () => {
    const client_ip = $('proxyErrorClient').value.trim();
    const path = $('proxyErrorPath').value.trim();
    if (!client_ip) return toast('Client IP required (per-device rules)', false);
    if (!path) return toast('Path pattern required', false);
    const status = Number($('proxyErrorStatus').value) || 500;
    const message = $('proxyErrorMsg').value || 'Error';
    try {
      await api('/api/proxy/rule', {
        method: 'POST',
        body: JSON.stringify({ client_ip, path, status, body: { error: message }, action: 'error' }),
      });
      toast('Error rule added', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.set_error(${pyStr(client_ip)}, ${pyStr(path)}, status=${status}, response=${pyStr(message)})`,
        rest: `POST /api/proxy/rule\n${JSON.stringify({ client_ip, path, status, body: { error: message }, action: 'error' }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Proxy: error rule', ...sdk });
      pushActivity('proxy', `Error ${status} ${path} → ${client_ip}`, true, sdk);
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Error rule failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyAddDelay')?.addEventListener('click', async () => {
    const client_ip = $('proxyDelayClient').value.trim();
    const path = $('proxyDelayPath').value.trim();
    if (!client_ip) return toast('Client IP required (per-device rules)', false);
    if (!path) return toast('Path pattern required', false);
    const delay_ms = Number($('proxyDelayMs').value) || 2000;
    try {
      await api('/api/proxy/rule', {
        method: 'POST',
        body: JSON.stringify({ client_ip, path, delay_ms, action: 'delay' }),
      });
      toast('Delay rule added', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.set_delay(${pyStr(client_ip)}, ${pyStr(path)}, ${delay_ms})`,
        rest: `POST /api/proxy/rule\n${JSON.stringify({ client_ip, path, delay_ms, action: 'delay' }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Proxy: delay rule', ...sdk });
      pushActivity('proxy', `Delay ${delay_ms}ms ${path} → ${client_ip}`, true, sdk);
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Delay rule failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyLoad')?.addEventListener('click', async () => {
    try {
      await loadProxyRulesAndLogs();
      toast('Proxy data loaded', true);
      const ip = $('proxyFilterIp').value.trim();
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nrules = kit.proxy.list_rules(${ip ? `client_ip=${pyStr(ip)}` : ''})\nentries = kit.proxy.get_log(${ip ? `client_ip=${pyStr(ip)}, ` : ''}limit=100)`,
        rest: `GET /api/proxy/rules${ip ? `?client_ip=${encodeURIComponent(ip)}` : ''}\nGET /api/proxy/logs?limit=100` + (ip ? `&client_ip=${encodeURIComponent(ip)}` : ''),
      };
      publishSdkMirror({ title: 'Proxy: load rules + logs', ...sdk });
      pushActivity('proxy', `Loaded log entries` + (ip ? ` (client ${ip})` : ''), true, sdk);
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Load failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyClearClient')?.addEventListener('click', async () => {
    const ip = $('proxyFilterIp').value.trim();
    if (!ip) return toast('Set filter client IP', false);
    try {
      await api('/api/proxy/clear', { method: 'POST', body: JSON.stringify({ client_ip: ip }) });
      toast('Rules cleared for client', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.clear_client(${pyStr(ip)})`,
        rest: `POST /api/proxy/clear\n${JSON.stringify({ client_ip: ip }, null, 2)}`,
      };
      publishSdkMirror({ title: 'Proxy: clear client', ...sdk });
      pushActivity('proxy', 'Cleared proxy rules for ' + ip, true, sdk);
      await loadProxyRulesAndLogs();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Clear client failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyClearAll')?.addEventListener('click', async () => {
    try {
      await api('/api/proxy/rules', { method: 'DELETE' });
      toast('All proxy rules cleared', true);
      const sdk = {
        python:
          'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.clear_all()',
        rest: 'DELETE /api/proxy/rules',
      };
      publishSdkMirror({ title: 'Proxy: clear all rules', ...sdk });
      pushActivity('proxy', 'Cleared all proxy rules', true, sdk);
      await loadProxyRulesAndLogs();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Clear all failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  $('btnProxyLogClear')?.addEventListener('click', async () => {
    try {
      await api('/api/proxy/logs', { method: 'DELETE' });
      toast('Log cleared', true);
      const sdk = {
        python:
          'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.clear_log()',
        rest: 'DELETE /api/proxy/logs',
      };
      publishSdkMirror({ title: 'Proxy: clear log', ...sdk });
      pushActivity('proxy', 'Cleared HTTP request log', true, sdk);
      await loadProxyRulesAndLogs();
    } catch (e) {
      toastApiError(e);
      pushActivity('proxy', 'Log clear failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  initProxyPresets();
}
