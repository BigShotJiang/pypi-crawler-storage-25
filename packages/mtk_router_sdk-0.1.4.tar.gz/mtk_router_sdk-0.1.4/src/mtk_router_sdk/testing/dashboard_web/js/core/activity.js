import { $ } from './dom.js';
import * as state from './state.js';

export function escapeHtml(s) {
  if (s == null || s === '') return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * @param {string} type
 * @param {string} message
 * @param {boolean} [ok]
 * @param {{ python?: string; cli?: string; rest?: string } | null} [sdk] copy-ready snippets for SDK Connect
 */
export function pushActivity(type, message, ok = true, sdk = null) {
  state.activityLog.unshift({ t: Date.now(), type, message, ok, sdk });
  if (state.activityLog.length > 100) state.activityLog.pop();
  renderActivityLog();
}

export function renderActivityLog() {
  const w = $('activityLogWrap');
  if (!w) return;
  if (!state.activityLog.length) {
    w.innerHTML =
      '<div class="empty">No actions yet — apply a network profile or add a proxy rule.</div>';
    return;
  }
  w.innerHTML = state.activityLog
    .map((a) => {
      const time = new Date(a.t).toLocaleTimeString(undefined, { hour12: false });
      const sdkBlock =
        a.sdk && (a.sdk.python || a.sdk.cli || a.sdk.rest)
          ? `<details class="act-sdk"><summary class="act-sdk-sum">SDK snippet</summary>
            <div class="act-sdk-grid">
              ${a.sdk.python ? `<div><span class="act-sdk-lbl">Python</span><pre class="act-sdk-pre">${escapeHtml(a.sdk.python)}</pre></div>` : ''}
              ${a.sdk.cli ? `<div><span class="act-sdk-lbl">CLI</span><pre class="act-sdk-pre">${escapeHtml(a.sdk.cli)}</pre></div>` : ''}
              ${a.sdk.rest ? `<div><span class="act-sdk-lbl">REST</span><pre class="act-sdk-pre">${escapeHtml(a.sdk.rest)}</pre></div>` : ''}
            </div></details>`
          : '';
      return `<div class="activity-row ${a.ok ? 'act-ok' : 'act-err'}"><span class="mono">${escapeHtml(time)}</span><span class="act-type">${escapeHtml(a.type)}</span><div class="activity-msg-col"><span>${escapeHtml(a.message)}</span>${sdkBlock}</div></div>`;
    })
    .join('');
}
