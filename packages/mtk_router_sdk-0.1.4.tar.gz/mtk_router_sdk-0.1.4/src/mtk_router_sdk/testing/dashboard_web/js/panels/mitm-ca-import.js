/**
 * HTTPS MITM CA: mtk-serve cert summary, PKCS#12 vs PEM modes, live file strip.
 */
import { $ } from '../core/dom.js';
import { api, toast, toastApiError } from '../core/api.js';
import { pushActivity } from '../core/activity.js';
import { publishSdkMirror } from './sdk-connect.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}

function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function bytesToBase64(bytes) {
  const u = new Uint8Array(bytes);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < u.length; i += chunk) {
    binary += String.fromCharCode.apply(null, u.subarray(i, Math.min(i + chunk, u.length)));
  }
  return btoa(binary);
}

/** @param {HTMLInputElement | null | undefined} input */
async function readP12AsBase64(input) {
  const f = input?.files?.[0];
  if (!f) return null;
  const buf = await f.arrayBuffer();
  return bytesToBase64(buf);
}

/** @param {'settings' | 'setup'} prefix */
function modeStorageKey(prefix) {
  return `mtk_mitm_mode_${prefix}`;
}

/** @param {'settings' | 'setup'} prefix */
function getMitmMode(prefix) {
  try {
    const v = localStorage.getItem(modeStorageKey(prefix));
    if (v === 'pem' || v === 'p12') return v;
  } catch {
    /* ignore */
  }
  return 'p12';
}

/** @param {'settings' | 'setup'} prefix */
function setMitmMode(prefix, mode) {
  try {
    localStorage.setItem(modeStorageKey(prefix), mode);
  } catch {
    /* ignore */
  }
}

/** @param {'settings' | 'setup'} prefix */
function applyMitmMode(prefix) {
  const mode = getMitmMode(prefix);
  const p12Panel = $(`${prefix}MitmPanelP12`);
  const pemPanel = $(`${prefix}MitmPanelPem`);
  const btnP12 = $(`${prefix}MitmModeP12`);
  const btnPem = $(`${prefix}MitmModePem`);

  if (p12Panel) p12Panel.hidden = mode !== 'p12';
  if (pemPanel) pemPanel.hidden = mode !== 'pem';

  [btnP12, btnPem].forEach((b) => {
    if (!b) return;
    const on = b.dataset.mitmMode === mode;
    b.classList.toggle('mitm-mode-btn--active', on);
    b.setAttribute('aria-selected', on ? 'true' : 'false');
  });

  renderMitmStrips(prefix);
}

function renderStripHtml(strip, rows, emptyHtml) {
  if (!strip) return;
  if (!rows.length) {
    strip.innerHTML = emptyHtml;
  } else {
    strip.innerHTML = rows
      .map(
        (r) => `<div class="mitm-live-row">
  <span class="mitm-live-ico" aria-hidden="true">${r.icon}</span>
  <div class="mitm-live-body">
    <span class="mitm-live-label">${escapeHtml(r.label)}</span>
    <span class="mitm-live-name mono">${escapeHtml(r.name)}</span>
    <span class="mitm-live-sub">${escapeHtml(r.sub)}</span>
  </div>
  <button type="button" class="btn btn-ghost btn-sm mitm-live-clear" data-mitm-clear="${r.clear}" data-mitm-prefix="${r.prefix}">Clear</button>
</div>`,
      )
      .join('');
  }
  strip.classList.remove('mitm-live-strip--flash');
  void strip.offsetWidth;
  strip.classList.add('mitm-live-strip--flash');
}

/** @param {'settings' | 'setup'} prefix */
function renderMitmStrips(prefix) {
  const p12 = $(`${prefix}CaP12File`)?.files?.[0];
  const crtf = $(`${prefix}CaCrtFile`)?.files?.[0];
  const keyf = $(`${prefix}CaKeyFile`)?.files?.[0];
  const crtTa = ($(`${prefix}CaCrtPem`)?.value || '').trim();
  const keyTa = ($(`${prefix}CaKeyPem`)?.value || '').trim();

  const stripP12 = $(`${prefix}MitmLiveStrip`);
  const p12Rows = [];
  if (p12) {
    p12Rows.push({
      icon: '🔐',
      label: 'PKCS#12 bundle',
      name: p12.name,
      sub: `${formatBytes(p12.size)} · ready to install`,
      clear: 'p12',
      prefix,
    });
  }
  renderStripHtml(
    stripP12,
    p12Rows,
    `<div class="mitm-live-empty">No <strong>.p12</strong> selected — use <em>Choose .p12 / .pfx</em> above.</div>`,
  );

  const stripPem = $(`${prefix}MitmLiveStripPem`);
  const pemRows = [];
  if (crtf) {
    pemRows.push({
      icon: '📄',
      label: 'CA certificate file',
      name: crtf.name,
      sub: formatBytes(crtf.size),
      clear: 'crt',
      prefix,
    });
  } else if (crtTa.includes('BEGIN CERTIFICATE')) {
    pemRows.push({
      icon: '📄',
      label: 'CA certificate (pasted)',
      name: 'PEM in textarea',
      sub: `${crtTa.length.toLocaleString()} characters`,
      clear: 'crtta',
      prefix,
    });
  }
  if (keyf) {
    pemRows.push({
      icon: '🔑',
      label: 'CA private key file',
      name: keyf.name,
      sub: formatBytes(keyf.size),
      clear: 'key',
      prefix,
    });
  } else if (keyTa.includes('PRIVATE KEY')) {
    pemRows.push({
      icon: '🔑',
      label: 'CA private key (pasted)',
      name: 'PEM in textarea',
      sub: `${keyTa.length.toLocaleString()} characters`,
      clear: 'keyta',
      prefix,
    });
  }
  renderStripHtml(
    stripPem,
    pemRows,
    `<div class="mitm-live-empty">No PEM yet — pick <strong>CA cert</strong> / <strong>CA key</strong> files or paste both blocks below.</div>`,
  );
}

function certTileHtml(title, d) {
  if (!d || typeof d !== 'object') return '';
  const exists = Boolean(d.exists);
  const subj = d.subject ? escapeHtml(d.subject) : '—';
  const exp = d.expires_at ? escapeHtml(String(d.expires_at)) : '—';
  const err = d.error ? `<div class="mitm-serve-err">${escapeHtml(d.error)}</div>` : '';
  const badge = exists
    ? d.valid
      ? '<span class="mitm-serve-badge mitm-serve-badge--ok">OK</span>'
      : '<span class="mitm-serve-badge mitm-serve-badge--warn">Check</span>'
    : '<span class="mitm-serve-badge mitm-serve-badge--muted">Missing</span>';
  return `<div class="mitm-serve-tile">
  <div class="mitm-serve-tile-head"><span class="mitm-serve-tile-title">${escapeHtml(title)}</span>${badge}</div>
  <div class="mitm-serve-tile-sub mono">${subj}</div>
  <div class="mitm-serve-tile-meta">Expires: ${exp}</div>
  ${err}
</div>`;
}

/** @param {'settings' | 'setup'} prefix */
async function refreshMitmServeState(prefix) {
  const box = $(`${prefix}MitmServeState`);
  if (!box) return;
  box.innerHTML = '<p class="hint mitm-serve-loading">Loading certificate info from mtk-serve…</p>';
  try {
    const r = await api('/api/proxy/certs/status');
    const dir = escapeHtml(String(r.cert_dir || '—'));
    const ca = r.ca_cert;
    const px = r.proxy_cert;
    box.innerHTML = `
      <p class="mitm-serve-dir mono">Store: ${dir}</p>
      <div class="mitm-serve-grid">
        ${certTileHtml('Signing CA (for device trust)', ca)}
        ${certTileHtml('Forward-proxy leaf', px)}
      </div>
      <p class="hint mitm-serve-foot">This is the mtk-serve process certificate directory (often <code class="mono">~/.mtk/certs</code>), not every certificate in macOS Keychain Access.</p>`;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    box.innerHTML = `<p class="hint mitm-serve-err">Could not read mtk-serve certificates (${escapeHtml(msg)}). Check <strong>mtk-serve</strong> is running and <code class="mono">MTK_SERVICE_URL</code> / token in Setup.</p>`;
  }
}

function wireStripClear(strip, prefix) {
  strip?.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-mitm-clear]');
    if (!btn) return;
    const kind = btn.getAttribute('data-mitm-clear');
    const pfx = btn.getAttribute('data-mitm-prefix') || prefix;
    if (kind === 'p12') {
      const el = $(`${pfx}CaP12File`);
      if (el) el.value = '';
    } else if (kind === 'crt') {
      const el = $(`${pfx}CaCrtFile`);
      if (el) el.value = '';
      const ta = $(`${pfx}CaCrtPem`);
      if (ta) ta.value = '';
    } else if (kind === 'key') {
      const el = $(`${pfx}CaKeyFile`);
      if (el) el.value = '';
      const ta = $(`${pfx}CaKeyPem`);
      if (ta) ta.value = '';
    } else if (kind === 'crtta') {
      const el = $(`${pfx}CaCrtPem`);
      if (el) el.value = '';
    } else if (kind === 'keyta') {
      const el = $(`${pfx}CaKeyPem`);
      if (el) el.value = '';
    }
    renderMitmStrips(pfx);
  });
}

/**
 * @param {{ prefix: 'settings' | 'setup' }} opts
 */
export function initMitmCaImport(opts) {
  const prefix = opts.prefix;
  const cap = prefix.charAt(0).toUpperCase() + prefix.slice(1);

  const readFileTo = (inputEl, textareaEl) => {
    const f = inputEl?.files?.[0];
    if (!f || !textareaEl) return;
    const r = new FileReader();
    r.onload = () => {
      textareaEl.value = String(r.result || '');
      renderMitmStrips(prefix);
    };
    r.readAsText(f);
  };

  $(`${prefix}CaCrtFile`)?.addEventListener('change', (e) => {
    readFileTo(e.target, $(`${prefix}CaCrtPem`));
  });
  $(`${prefix}CaKeyFile`)?.addEventListener('change', (e) => {
    readFileTo(e.target, $(`${prefix}CaKeyPem`));
  });

  $(`${prefix}CaP12File`)?.addEventListener('change', () => renderMitmStrips(prefix));

  $(`${prefix}CaCrtPem`)?.addEventListener('input', () => renderMitmStrips(prefix));
  $(`${prefix}CaKeyPem`)?.addEventListener('input', () => renderMitmStrips(prefix));

  wireStripClear($(`${prefix}MitmLiveStrip`), prefix);
  wireStripClear($(`${prefix}MitmLiveStripPem`), prefix);

  $(`${prefix}MitmModeP12`)?.addEventListener('click', () => {
    setMitmMode(prefix, 'p12');
    applyMitmMode(prefix);
  });
  $(`${prefix}MitmModePem`)?.addEventListener('click', () => {
    setMitmMode(prefix, 'pem');
    applyMitmMode(prefix);
  });

  const pw = $(`${prefix}P12Password`);
  const showPw = $(`${prefix}P12ShowPw`);
  showPw?.addEventListener('change', () => {
    if (pw) pw.type = showPw.checked ? 'text' : 'password';
  });

  $(`btn${cap}MitmRefreshCerts`)?.addEventListener('click', () => {
    void refreshMitmServeState(prefix);
  });

  $(`btn${cap}MitmCaImport`)?.addEventListener('click', async () => {
    const mode = getMitmMode(prefix);
    const cn = ($(`${prefix}CaLeafCn`)?.value || '').trim() || 'MTK Proxy';
    const stEl = $(`${prefix}MitmCaStatus`);
    const activityKind = prefix === 'setup' ? 'setup' : 'settings';

    let body;
    let sdkRestSnippet;
    let usedP12 = false;

    if (mode === 'p12') {
      const p12Input = $(`${prefix}CaP12File`);
      const p12B64 = await readP12AsBase64(p12Input);
      if (!p12B64) {
        if (stEl) stEl.textContent = 'Choose a .p12 / .pfx file first.';
        return toast('Select a PKCS#12 bundle', false);
      }
      const p12PwField = $(`${prefix}P12Password`);
      const p12Password = p12PwField ? String(p12PwField.value ?? '') : '';
      body = {
        pkcs12_base64: p12B64,
        p12_password: p12Password,
        proxy_cn: cn,
      };
      usedP12 = true;
      sdkRestSnippet =
        'POST /api/proxy/certs/import\n' +
        JSON.stringify({ pkcs12_base64: '…', p12_password: p12Password ? '…' : '', proxy_cn: cn }, null, 2);
    } else {
      const caCrt = ($(`${prefix}CaCrtPem`)?.value || '').trim();
      const caKey = ($(`${prefix}CaKeyPem`)?.value || '').trim();
      if (!caCrt || !caKey) {
        if (stEl) stEl.textContent = 'Paste or load both PEM blocks (cert + private key).';
        return toast('PEM cert and key required', false);
      }
      body = {
        ca_crt_pem: caCrt,
        ca_key_pem: caKey,
        proxy_cn: cn,
      };
      sdkRestSnippet =
        'POST /api/proxy/certs/import\n' +
        JSON.stringify({ ca_crt_pem: '…', ca_key_pem: '…', proxy_cn: cn }, null, 2);
    }

    try {
      const out = await api('/api/proxy/certs/import', {
        method: 'POST',
        body: JSON.stringify(body),
      });
      if (stEl) {
        stEl.textContent = out.imported
          ? 'CA installed on mtk-serve. Trust this CA on test devices. Restart mtk-serve if needed.'
          : 'Done.';
      }
      toast('CA installed on mtk-serve', true);
      const sdk = {
        python: usedP12
          ? `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.import_ca_pkcs12_base64(${pyStr('…')}, password=${pyStr('…')}, proxy_cn=${pyStr(cn)})`
          : `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.proxy.import_ca_pem(${pyStr('…')}, ${pyStr('…')}, proxy_cn=${pyStr(cn)})`,
        rest: sdkRestSnippet,
      };
      publishSdkMirror({
        title: usedP12 ? 'HTTPS MITM: import PKCS#12' : 'HTTPS MITM: import CA PEM',
        ...sdk,
      });
      pushActivity(
        activityKind,
        usedP12 ? 'Imported MITM CA from PKCS#12' : 'Imported MITM CA PEM',
        true,
        sdk,
      );
      if (usedP12) {
        const p12Input = $(`${prefix}CaP12File`);
        if (p12Input) p12Input.value = '';
      }
      renderMitmStrips(prefix);
      await refreshMitmServeState(prefix);
    } catch (e) {
      toastApiError(e);
      if (stEl) stEl.textContent = '';
      pushActivity(
        activityKind,
        'CA import failed: ' + (e instanceof Error ? e.message : String(e)),
        false,
      );
    }
  });

  applyMitmMode(prefix);
  void refreshMitmServeState(prefix);
}
