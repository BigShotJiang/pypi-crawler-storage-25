/**
 * MTK Test Control dashboard — entry (loads feature modules).
 */
import { $ } from './core/dom.js';
import { api } from './core/api.js';
import * as state from './core/state.js';
import { wireLogSearch } from './core/logs-render.js';
import { renderActivityLog } from './core/activity.js';
import { connectWs, loadHealth, loadOverview } from './panels/overview-ws.js';
import {
  loadNetProfiles,
  initNetworkPanel,
  refreshNetworkTable,
  refreshLanDevicePicker,
  renderNetworkPanelStatus,
  updateCockpitFromCache,
  updateNetDeviceMetaForIp,
  updateMonitorTargetDisplay,
} from './panels/network.js';
import { initDnsPanel, refreshDns } from './panels/dns.js';
import { initProxyPanel } from './panels/proxy.js';
import { initScenariosPanel, loadScenarios, runScenarioQuick } from './panels/scenarios.js';
import { initRecordingPanel, loadRecordings } from './panels/recording.js';
import {
  initProfilesPanel,
  initSettingsAndExport,
  loadProfList,
} from './panels/profiles-settings.js';
import { initInteractiveDocs, toggleAccordion, copyCode } from './docs/interactive.js';
import { initSdkConnect, onSdkTabChange, refreshSdkPipeline } from './panels/sdk-connect.js';
import { initSetupPanel, maybeRedirectToSetup, refreshSetupIfVisible } from './panels/setup.js';
import { initUiChrome, pulsePanel } from './core/ui-chrome.js';
import { initTooltips } from './core/tooltips.js';
import { initAnimations } from './core/animations.js';
import { renderEnvUiPanel } from './panels/env-ui-settings.js';

function switchTab(tab) {
  document.querySelectorAll('nav a').forEach((a) => a.classList.remove('active'));
  document.querySelector(`nav a[data-tab="${tab}"]`)?.classList.add('active');
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
  const panel = $('panel-' + tab);
  panel?.classList.add('active');
  document.body.classList.toggle('mtk-setup-fullpage', tab === 'setup');
  pulsePanel(panel);
  onSdkTabChange(tab);
  if (tab === 'network') {
    updateCockpitFromCache();
    renderNetworkPanelStatus();
    updateNetDeviceMetaForIp(($('netClientIp')?.value || '').trim());
    updateMonitorTargetDisplay();
  }
  if (tab === 'sdk-connect') refreshSdkPipeline();
  if (tab === 'setup') refreshSetupIfVisible();
  if (tab === 'proxy' || tab === 'recording' || tab === 'scenarios' || tab === 'profiles') {
    refreshLanDevicePicker(false).catch(() => {});
  }
  if (tab === 'settings') {
    void renderEnvUiPanel();
  }
}

window.switchTab = switchTab;
window.__mtkSwitchTab = switchTab;
window.toggleAccordion = toggleAccordion;
window.copyCode = copyCode;
window.runScenarioQuick = runScenarioQuick;

document.querySelectorAll('nav a[data-tab]').forEach((a) => {
  a.addEventListener('click', (e) => {
    e.preventDefault();
    switchTab(a.dataset.tab);
  });
});

$('btnActivityClear')?.addEventListener('click', () => {
  state.activityLog.length = 0;
  renderActivityLog();
});

wireLogSearch('proxyLogSearch', 'proxyLogCache', 'proxyLogsWrap', 'Click “Load rules & logs”');
wireLogSearch(
  'netLogSearch',
  'netLogCache',
  'netTrafficLogWrap',
  'Click “Load traffic log” after generating traffic from a test device.',
);

initNetworkPanel();
initDnsPanel();
initProxyPanel();
initScenariosPanel();
initRecordingPanel();
initProfilesPanel();
initSettingsAndExport();

(async function init() {
  await maybeRedirectToSetup();
  initSetupPanel();
  connectWs();
  await loadHealth();
  refreshSdkPipeline();
  try {
    await loadNetProfiles();
  } catch {
    /* optional */
  }
  try {
    await loadProfList();
  } catch {
    /* optional */
  }
  try {
    await loadScenarios();
  } catch {
    /* optional */
  }
  try {
    await loadRecordings();
  } catch {
    /* optional */
  }
  await loadOverview();
  await refreshNetworkTable();
  await refreshDns();
  try {
    const cfg = await api('/api/config');
    const ph = $('pollHint');
    if (ph) ph.textContent = (cfg.poll_interval_sec || 3) + 's';
  } catch {
    /* optional */
  }
  const env = $('envInfo');
  if (env) {
    let extra = '';
    try {
      const st = await api('/api/setup/status');
      if (st.workspace_path) {
        extra = `<div style="margin-top:10px"><span style="color:var(--muted)">Setup workspace:</span> ${st.workspace_path}</div>`;
      }
    } catch {
      /* optional */
    }
    env.innerHTML = `<div style="font-family:var(--mono);font-size:12px;line-height:1.8">
        <div><span style="color:var(--muted)">Dashboard:</span> ${location.href}</div>
        <div><span style="color:var(--muted)">WebSocket:</span> ${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws</div>${extra}
      </div>`;
  }
  initInteractiveDocs();
  initSdkConnect();
  initUiChrome();
  initTooltips();
  initAnimations();
  pulsePanel(document.querySelector('main .panel.active'));
})();
