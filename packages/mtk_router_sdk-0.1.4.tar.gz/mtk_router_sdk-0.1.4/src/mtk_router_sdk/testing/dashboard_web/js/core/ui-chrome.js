/**
 * Boot polish: stagger cards, panel enter flash, reduced-motion aware.
 */

const _reduced =
  typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches;

export function initUiChrome() {
  document.body.classList.add('mtk-booted');
  if (_reduced) return;

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add('mtk-inview');
          io.unobserve(en.target);
        }
      });
    },
    { rootMargin: '0px 0px -6% 0px', threshold: 0.05 },
  );

  const run = () => {
    document.querySelectorAll('main .card, main .feature-card, .net-preset-card').forEach((c, i) => {
      c.classList.add('mtk-reveal');
      c.style.setProperty('--mtk-reveal-delay', `${Math.min(i, 14) * 42}ms`);
      io.observe(c);
    });
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    requestAnimationFrame(run);
  }
}

/** Call after switching visible panel. */
export function pulsePanel(panelEl) {
  if (!panelEl || _reduced) return;
  panelEl.classList.remove('mtk-panel-swap');
  // reflow
  void panelEl.offsetWidth;
  panelEl.classList.add('mtk-panel-swap');
}
