import { $ } from '../core/dom.js';
import { api, toast, toastApiError } from '../core/api.js';
import * as state from '../core/state.js';
import { pushActivity } from '../core/activity.js';
import { loadHealth, loadOverview } from './overview-ws.js';
import { refreshSdkPipeline, publishSdkMirror } from './sdk-connect.js';

function pyStr(s) {
  return JSON.stringify(s == null ? '' : String(s));
}
import { refreshNetworkTable, refreshLanDevicePicker } from './network.js';
import { refreshDns } from './dns.js';
import { initMitmCaImport } from './mitm-ca-import.js';
import { initEnvUiPanel, renderEnvUiPanel } from './env-ui-settings.js';

export async function loadProfList() {
  const d = await api('/api/profiles/list');
  const sel = $('profSelect');
  if (sel)
    sel.innerHTML =
      '<option value="">— Select —</option>' + d.profiles.map((p) => `<option value="${p}">${p}</option>`).join('');
}

export function initProfilesPanel() {
  $('btnProfApply')?.addEventListener('click', async () => {
    const name = $('profSelect').value;
    const client_ip = $('profClient').value.trim();
    if (!name || !client_ip) return toast('Profile and client IP required', false);
    try {
      await api('/api/profiles/apply', { method: 'POST', body: JSON.stringify({ name, client_ip }) });
      toast('Profile applied', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.profiles.apply(${pyStr(name)}, client_ip=${pyStr(client_ip)})`,
        rest: `POST /api/profiles/apply\n${JSON.stringify({ name, client_ip }, null, 2)}`,
      };
      publishSdkMirror({ title: `YAML profile: ${name}`, ...sdk });
      pushActivity('profile', `Applied “${name}” → ${client_ip}`, true, sdk);
      await loadOverview();
      await refreshNetworkTable();
      await refreshDns();
    } catch (e) {
      toastApiError(e);
      pushActivity('profile', 'Apply failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnProfClear')?.addEventListener('click', async () => {
    const client_ip = $('profClient').value.trim();
    if (!client_ip) return toast('Client IP required', false);
    try {
      await api('/api/profiles/clear', { method: 'POST', body: JSON.stringify({ client_ip }) });
      toast('Profile cleared', true);
      const sdk = {
        python: `from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\nkit.profiles.clear(${pyStr(client_ip)})`,
        rest: `POST /api/profiles/clear\n${JSON.stringify({ client_ip }, null, 2)}`,
      };
      publishSdkMirror({ title: 'YAML profile: clear', ...sdk });
      pushActivity('profile', 'Cleared profile for ' + client_ip, true, sdk);
    } catch (e) {
      toastApiError(e);
      pushActivity('profile', 'Clear failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });
  $('btnProfExport')?.addEventListener('click', async () => {
    try {
      const d = await api('/api/profiles/export');
      const blob = new Blob([JSON.stringify(d, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'mtk-profile-export.yaml';
      a.click();
      toast('Profile exported', true);
      const sdk = {
        python:
          'from mtk_router_sdk.testing import MtkTestKit\n\nkit = MtkTestKit.from_env()\ndata = kit.profiles.export()\n# save data (YAML/JSON) to file',
        rest: 'GET /api/profiles/export',
      };
      publishSdkMirror({ title: 'YAML profile: export snapshot', ...sdk });
      pushActivity('profile', 'Exported profile snapshot', true, sdk);
    } catch (e) {
      toastApiError(e);
    }
  });
  $('btnProfRefresh')?.addEventListener('click', () => loadProfList());
}

async function updateSettingsConnStatus() {
  const routerCard = $('settingsRouterConn');
  const routerStatus = $('settingsRouterStatus');
  const mtkCard = $('settingsMtkServeConn');
  const mtkStatus = $('settingsMtkStatus');

  // GET /api/health uses ssh_connected + mtk_serve_proxy (not routeros_connected / mtk_serve_running).
  try {
    const health = await api('/api/health');
    if (health.ssh_connected) {
      routerCard?.classList.remove('disconnected');
      routerCard?.classList.add('connected');
      if (routerStatus) routerStatus.textContent = 'Connected via SSH';
    } else {
      routerCard?.classList.remove('connected');
      routerCard?.classList.add('disconnected');
      if (routerStatus) routerStatus.textContent = 'Not connected';
    }
    const serveOk =
      health.mtk_serve_proxy === true ||
      health.mtk_serve_running === true;
    if (serveOk) {
      mtkCard?.classList.remove('disconnected');
      mtkCard?.classList.add('connected');
      const port = health.mtk_serve_port;
      if (mtkStatus) {
        mtkStatus.textContent =
          port != null && String(port)
            ? `HTTP API OK · port ${port}`
            : 'HTTP API reachable (mtk-serve)';
      }
    } else {
      mtkCard?.classList.remove('connected');
      mtkCard?.classList.add('disconnected');
      if (mtkStatus) mtkStatus.textContent = 'Not reachable';
    }
  } catch (e) {
    routerCard?.classList.remove('connected');
    routerCard?.classList.add('disconnected');
    mtkCard?.classList.remove('connected');
    mtkCard?.classList.add('disconnected');
    if (routerStatus) routerStatus.textContent = 'Unable to check';
    if (mtkStatus) mtkStatus.textContent = 'Unable to check';
  }
}

export function initSettingsAndExport() {
  const onThemeClick = () => {
    document.body.dataset.theme = document.body.dataset.theme === 'light' ? 'dark' : 'light';
    localStorage.setItem('mtk-theme', document.body.dataset.theme);
    toast(`Theme: ${document.body.dataset.theme}`, true);
  };
  for (const id of ['btnTheme', 'btnThemeSettings']) {
    $(id)?.addEventListener('click', onThemeClick);
  }

  const onExportSnapshot = async () => {
    try {
      const snap = await api('/api/export');
      const blob = new Blob([JSON.stringify(snap, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'mtk-dashboard-export.json';
      a.click();
      toast('Download started', true);
    } catch (e) {
      toastApiError(e);
    }
  };
  for (const id of ['btnExport', 'btnExportSettings']) {
    $(id)?.addEventListener('click', onExportSnapshot);
  }

  const onRefreshAll = async () => {
    toast('Refreshing all data...', true);
    await loadHealth();
    refreshSdkPipeline();
    await loadOverview();
    await refreshNetworkTable();
    await refreshLanDevicePicker(false).catch(() => {});
    await refreshDns();
    await updateSettingsConnStatus();
    await renderEnvUiPanel();
    toast('All data refreshed', true);
  };
  for (const id of ['btnRefreshAll', 'btnRefreshAllSettings']) {
    $(id)?.addEventListener('click', onRefreshAll);
  }

  // WebSocket filter
  $('btnWsSubscribe')?.addEventListener('click', () => {
    const v = $('wsFilterIp').value.trim();
    state.setWsFilter(v || null);
    if (window._mtkWs?.readyState === 1) {
      window._mtkWs.send(JSON.stringify({ type: 'subscribe', client_ip: state.wsFilter }));
    }
    toast(state.wsFilter ? 'Filter: ' + state.wsFilter : 'Filter: all clients', true);
  });

  // Test mtk-serve connection
  $('btnTestMtkServe')?.addEventListener('click', async () => {
    toast('Testing mtk-serve...', true);
    try {
      const res = await api('/api/health');
      if (res.mtk_serve_proxy === true || res.mtk_serve_running === true) {
        toast('mtk-serve HTTP API is reachable', true);
      } else {
        toast('mtk-serve HTTP API not reachable — check MTK_SERVICE_URL and that mtk-serve is running', false);
      }
      await updateSettingsConnStatus();
    } catch (e) {
      toast('Failed to check mtk-serve', false);
    }
  });

  // Clear all network rules
  $('btnClearAllNetwork')?.addEventListener('click', async () => {
    if (!confirm('Clear ALL network rules (queues and firewall) from the router?\n\nThis will remove throttling, packet loss, etc. from all devices.')) return;
    try {
      await api('/api/network/clear', { method: 'DELETE' });
      toast('All network rules cleared', true);
      pushActivity('settings', 'Cleared all network rules', true);
      await refreshNetworkTable();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('settings', 'Clear network rules failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  // Clear all DNS rules
  $('btnClearAllDns')?.addEventListener('click', async () => {
    if (!confirm('Clear ALL DNS redirect rules?\n\nThis will remove all domain redirects and blocks.')) return;
    try {
      await api('/api/dns/redirect', { method: 'DELETE' });
      toast('All DNS rules cleared', true);
      pushActivity('settings', 'Cleared all DNS rules', true);
      await refreshDns();
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('settings', 'Clear DNS rules failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  // Clear all proxy rules
  $('btnClearAllProxy')?.addEventListener('click', async () => {
    if (!confirm('Clear ALL proxy rules?\n\nThis will remove all mock responses, delays, and error simulations.')) return;
    try {
      await api('/api/proxy/clear', { method: 'POST' });
      toast('All proxy rules cleared', true);
      pushActivity('settings', 'Cleared all proxy rules', true);
      await loadOverview();
    } catch (e) {
      toastApiError(e);
      pushActivity('settings', 'Clear proxy rules failed: ' + (e instanceof Error ? e.message : String(e)), false);
    }
  });

  // Reset everything
  $('btnResetAll')?.addEventListener('click', async () => {
    if (!confirm('RESET EVERYTHING?\n\nThis will clear:\n- All network rules (throttling, packet loss)\n- All DNS redirects\n- All proxy rules\n\nThis cannot be undone!')) return;
    try {
      toast('Resetting all rules...', true);
      await api('/api/network/clear', { method: 'DELETE' }).catch(() => {});
      await api('/api/dns/redirect', { method: 'DELETE' }).catch(() => {});
      await api('/api/proxy/clear', { method: 'POST' }).catch(() => {});
      toast('All rules cleared', true);
      pushActivity('settings', 'Reset all rules (network, DNS, proxy)', true);
      await loadOverview();
      await refreshNetworkTable();
      await refreshDns();
    } catch (e) {
      toastApiError(e);
    }
  });

  // Restore saved theme
  const savedTheme = localStorage.getItem('mtk-theme');
  if (savedTheme) document.body.dataset.theme = savedTheme;

  // Initial connection status check (delayed)
  setTimeout(() => updateSettingsConnStatus(), 1000);

  initMitmCaImport({ prefix: 'settings' });
  initEnvUiPanel();
  renderEnvUiPanel();
}
