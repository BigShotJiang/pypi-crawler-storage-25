/**
 * Settings → Environment: curated MTK_* toggles (workspace env_ui).
 */
import { $ } from '../core/dom.js';
import { api, toast, toastApiError } from '../core/api.js';

let _envUiControls = [];
let _envUiListenersWired = false;

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function _envDomId(key) {
  return `envUi_${String(key).replace(/[^a-zA-Z0-9_]/g, '_')}`;
}

function collectEnvUiPayload(controls) {
  const out = {};
  for (const c of controls) {
    const id = _envDomId(c.key);
    if (c.kind === 'bool') {
      const el = document.getElementById(id);
      const checked = !!(el && el.checked);
      if (c.bool_style === 'truthy_when_on') {
        if (checked) out[c.key] = '1';
      } else if (c.bool_style === 'default_on_clear_means_on') {
        if (!checked) out[c.key] = '0';
      }
    } else {
      const el = document.getElementById(id);
      const v = (el && el.value) || '';
      const t = String(v).trim();
      if (t) out[c.key] = t;
    }
  }
  return out;
}

export async function renderEnvUiPanel() {
  const host = $('envUiControls');
  if (!host) return;
  try {
    const d = await api('/api/setup/env-ui');
    _envUiControls = d.controls || [];
    const rows = _envUiControls
      .map((c) => {
        const safeId = String(c.key).replace(/[^a-zA-Z0-9_]/g, '_');
        if (c.kind === 'bool') {
          const on = !!(d.bool_state && d.bool_state[c.key]);
          return `<div class="settings-pref-row env-ui-row" data-env-ui-key="${esc(c.key)}">
            <div class="settings-pref-info">
              <strong>${esc(c.label)}</strong>
              <span><code class="mono">${esc(c.key)}</code> — ${esc(c.description)}</span>
            </div>
            <label class="env-ui-toggle"><input type="checkbox" id="envUi_${safeId}" ${on ? 'checked' : ''} /></label>
          </div>`;
        }
        const val =
          (d.saved && d.saved[c.key] != null && String(d.saved[c.key]).trim()) ||
          (d.effective && d.effective[c.key] != null ? String(d.effective[c.key]) : '');
        const ph = c.kind === 'port' ? '8765' : '';
        return `<div class="settings-pref-row env-ui-row" data-env-ui-key="${esc(c.key)}">
          <div class="settings-pref-info">
            <strong>${esc(c.label)}</strong>
            <span><code class="mono">${esc(c.key)}</code> — ${esc(c.description)}</span>
          </div>
          <input type="text" id="envUi_${safeId}" class="mono env-ui-text" value="${esc(val)}" placeholder="${esc(ph)}" />
        </div>`;
      })
      .join('');
    const hint = d.hint ? `<p class="hint env-ui-hint">${esc(d.hint)}</p>` : '';
    host.innerHTML = `<div class="env-ui-wrap">${rows}</div>${hint}`;
  } catch (e) {
    host.innerHTML = '<div class="empty">Could not load environment controls.</div>';
    toastApiError(e);
  }
}

async function onSaveEnvUi() {
  try {
    const payload = { env_ui: collectEnvUiPayload(_envUiControls) };
    await api('/api/setup/env-ui', { method: 'POST', body: JSON.stringify(payload) });
    toast('Environment toggles saved (dashboard process updated)', true);
    await renderEnvUiPanel();
  } catch (e) {
    toastApiError(e);
  }
}

export function initEnvUiPanel() {
  if (_envUiListenersWired) return;
  _envUiListenersWired = true;
  $('btnEnvUiSave')?.addEventListener('click', () => onSaveEnvUi());
  $('btnEnvUiReset')?.addEventListener('click', () => renderEnvUiPanel());
}
