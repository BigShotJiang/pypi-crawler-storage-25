"""
Configuration Profiles — Save and switch test states instantly.

Usage:
    from mtk_router_sdk.testing import ProfileManager

    profiles = ProfileManager.from_env()

    # Apply a profile
    profiles.apply("us-premium", client_ip="192.168.1.100")

    # Switch profiles
    profiles.switch("uk-trial", client_ip="192.168.1.100")

    # List available profiles
    for name in profiles.list_profiles():
        print(name)

    # Export current state as profile
    profiles.export("192.168.1.100", "my-current-state")

Profile YAML format:
    name: us-premium
    description: US Premium subscriber

    network:
      profile: wifi-good

    vpn:
      slot: 1
      tunnel: l2tp-us

    dns:
      redirects:
        - domain: api.example.com
          to_proxy: true

    proxy:
      rules:
        - path: /api/subscription
          body:
            plan: premium
            region: US
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mtk_router_sdk.testing.kit import MtkTestKit

try:
    import yaml  # type: ignore[import-untyped]

    HAS_YAML = True
except ImportError:
    HAS_YAML = False


@dataclass
class TestProfile:
    """A test configuration profile."""

    name: str
    description: str = ""
    extends: str | None = None
    network: dict[str, Any] = field(default_factory=dict)
    vpn: dict[str, Any] = field(default_factory=dict)
    dns: dict[str, Any] = field(default_factory=dict)
    proxy: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TestProfile:
        """Create a profile from a dictionary."""
        return cls(
            name=data.get("name", "unnamed"),
            description=data.get("description", ""),
            extends=data.get("extends"),
            network=data.get("network", {}),
            vpn=data.get("vpn", {}),
            dns=data.get("dns", {}),
            proxy=data.get("proxy", {}),
            metadata=data.get("metadata", {}),
        )

    @classmethod
    def from_yaml(cls, path: Path) -> TestProfile:
        """Load a profile from a YAML file."""
        if not HAS_YAML:
            raise ImportError("PyYAML required. Install with: pip install pyyaml")

        with open(path) as f:
            data = yaml.safe_load(f)

        if data is None:
            data = {}

        if "name" not in data:
            data["name"] = path.stem

        return cls.from_dict(data)

    def to_dict(self) -> dict[str, Any]:
        """Convert profile to dictionary."""
        result: dict[str, Any] = {"name": self.name}

        if self.description:
            result["description"] = self.description
        if self.extends:
            result["extends"] = self.extends
        if self.network:
            result["network"] = self.network
        if self.vpn:
            result["vpn"] = self.vpn
        if self.dns:
            result["dns"] = self.dns
        if self.proxy:
            result["proxy"] = self.proxy
        if self.metadata:
            result["metadata"] = self.metadata

        return result

    def to_yaml(self, path: Path) -> None:
        """Save profile to a YAML file."""
        if not HAS_YAML:
            raise ImportError("PyYAML required. Install with: pip install pyyaml")

        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, sort_keys=False)

    def merge_with(self, parent: TestProfile) -> TestProfile:
        """Merge this profile with a parent profile (inheritance)."""
        merged = TestProfile(
            name=self.name,
            description=self.description or parent.description,
            network={**parent.network, **self.network},
            vpn={**parent.vpn, **self.vpn},
            dns=self._merge_dns(parent.dns, self.dns),
            proxy=self._merge_proxy(parent.proxy, self.proxy),
            metadata={**parent.metadata, **self.metadata},
        )
        return merged

    def _merge_dns(
        self, parent: dict[str, Any], child: dict[str, Any]
    ) -> dict[str, Any]:
        """Merge DNS configurations."""
        result = {**parent}
        if "redirects" in child:
            parent_redirects = parent.get("redirects", [])
            child_redirects = child.get("redirects", [])
            result["redirects"] = parent_redirects + child_redirects
        return result

    def _merge_proxy(
        self, parent: dict[str, Any], child: dict[str, Any]
    ) -> dict[str, Any]:
        """Merge proxy configurations."""
        result = {**parent}
        if "rules" in child:
            parent_rules = parent.get("rules", [])
            child_rules = child.get("rules", [])
            result["rules"] = parent_rules + child_rules
        return result


@dataclass
class ProfileManager:
    """
    Manage test configuration profiles.

    Profiles are YAML files that define complete test states:
    - Network conditions (throttling, latency)
    - VPN configuration
    - DNS redirects
    - Proxy rules (mock responses)

    Supports profile inheritance via 'extends' field.
    """

    kit: MtkTestKit | None = None
    profiles_dir: Path | None = None
    _profiles: dict[str, TestProfile] = field(default_factory=dict)
    _applied: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> ProfileManager:
        """Create from environment variables."""
        from mtk_router_sdk.testing import MtkTestKit

        profiles_dir = os.environ.get("MTK_PROFILES_DIR")

        return cls(
            kit=MtkTestKit.from_env(),
            profiles_dir=Path(profiles_dir) if profiles_dir else None,
        )

    def load_profile(self, name_or_path: str | Path) -> TestProfile:
        """
        Load a profile by name or path.

        Args:
            name_or_path: Profile name (looks in profiles_dir) or path to YAML file
        """
        path = Path(name_or_path)

        if not path.suffix:
            if self.profiles_dir:
                path = self.profiles_dir / f"{name_or_path}.yaml"
                if not path.exists():
                    path = self.profiles_dir / f"{name_or_path}.yml"
            else:
                raise ValueError(
                    f"Profile '{name_or_path}' not found. "
                    "Set MTK_PROFILES_DIR or provide full path."
                )

        if not path.exists():
            raise FileNotFoundError(f"Profile not found: {path}")

        profile = TestProfile.from_yaml(path)

        if profile.extends:
            parent = self.load_profile(profile.extends)
            profile = profile.merge_with(parent)

        self._profiles[profile.name] = profile
        return profile

    def apply(
        self,
        name_or_path: str | Path,
        client_ip: str,
        clear_existing: bool = True,
    ) -> TestProfile:
        """
        Apply a profile to a client.

        Args:
            name_or_path: Profile name or path
            client_ip: Target client IP
            clear_existing: Clear existing state before applying

        Returns:
            Applied TestProfile
        """
        if clear_existing:
            self.clear(client_ip)

        profile = self.load_profile(name_or_path)

        if self.kit:
            self._apply_network(profile, client_ip)
            self._apply_vpn(profile)
            self._apply_dns(profile, client_ip)
            self._apply_proxy(profile, client_ip)

        self._applied[client_ip] = profile.name
        return profile

    def switch(
        self,
        name_or_path: str | Path,
        client_ip: str,
    ) -> TestProfile:
        """
        Switch to a different profile (clears existing and applies new).

        Args:
            name_or_path: Profile name or path
            client_ip: Target client IP

        Returns:
            Applied TestProfile
        """
        return self.apply(name_or_path, client_ip, clear_existing=True)

    def get_applied(self, client_ip: str) -> str | None:
        """Get the name of the currently applied profile for a client."""
        return self._applied.get(client_ip)

    def clear(self, client_ip: str) -> None:
        """Clear all profile state for a client."""
        if self.kit:
            self.kit.cleanup(client_ip)
        if client_ip in self._applied:
            del self._applied[client_ip]

    def list_profiles(self) -> list[str]:
        """List available profile names."""
        if self.profiles_dir is None:
            return list(self._profiles.keys())

        profiles: list[str] = []
        for ext in ("*.yaml", "*.yml"):
            for path in self.profiles_dir.glob(ext):
                profiles.append(path.stem)

        return sorted(set(profiles))

    def export(
        self,
        client_ip: str,
        name: str,
        output_path: Path | None = None,
    ) -> Path:
        """
        Export current state as a new profile.

        Args:
            client_ip: Client to export state from
            name: Name for the new profile
            output_path: Where to save (default: profiles_dir/name.yaml)

        Returns:
            Path to the saved profile
        """
        if output_path is None:
            if self.profiles_dir is None:
                raise ValueError("No output path specified and MTK_PROFILES_DIR not set")
            output_path = self.profiles_dir / f"{name}.yaml"

        profile_data: dict[str, Any] = {
            "name": name,
            "description": f"Exported from {client_ip}",
        }

        if self.kit:
            network_cond = self.kit.network.get_condition(client_ip)
            if network_cond and network_cond.active:
                profile_data["network"] = {}
                if network_cond.profile:
                    profile_data["network"]["profile"] = network_cond.profile
                else:
                    if network_cond.download_kbps:
                        profile_data["network"]["download_kbps"] = network_cond.download_kbps
                    if network_cond.upload_kbps:
                        profile_data["network"]["upload_kbps"] = network_cond.upload_kbps

            dns_redirects = self.kit.dns.list_redirects(client_ip)
            if dns_redirects:
                profile_data["dns"] = {
                    "redirects": [
                        {"domain": r.domain, "target_ip": r.target_ip}
                        for r in dns_redirects
                    ]
                }

            proxy_rules = self.kit.proxy.list_rules(client_ip)
            if proxy_rules:
                profile_data["proxy"] = {
                    "rules": [
                        {
                            "path": r.path,
                            "action": r.action.value if hasattr(r.action, "value") else r.action,
                            "body": r.body,
                        }
                        for r in proxy_rules
                    ]
                }

        profile = TestProfile.from_dict(profile_data)
        profile.to_yaml(output_path)
        return output_path

    def _apply_network(self, profile: TestProfile, client_ip: str) -> None:
        """Apply network settings from profile."""
        if not profile.network or not self.kit:
            return

        if "profile" in profile.network:
            self.kit.network.apply_profile(client_ip, profile.network["profile"])
        else:
            download = profile.network.get("download_kbps")
            upload = profile.network.get("upload_kbps")
            if download or upload:
                self.kit.network.throttle(client_ip, download, upload)

            latency = profile.network.get("latency_ms")
            jitter = profile.network.get("jitter_ms", 0)
            if latency:
                self.kit.network.latency(client_ip, latency, jitter)

            loss = profile.network.get("packet_loss_percent")
            if loss:
                self.kit.network.packet_loss(client_ip, loss)

    def _apply_vpn(self, profile: TestProfile) -> None:
        """Apply VPN settings from profile."""
        if not profile.vpn or not self.kit:
            return

        if self.kit._client:
            slot = profile.vpn.get("slot")
            tunnel = profile.vpn.get("tunnel")
            if slot and tunnel:
                from mtk_router_sdk.ops.slot_route import set_slot_vpn_gateway

                set_slot_vpn_gateway(
                    self.kit._client,
                    slot,
                    tunnel,
                    site=self.kit._site,
                )

    def _apply_dns(self, profile: TestProfile, client_ip: str) -> None:
        """Apply DNS settings from profile."""
        if not profile.dns or not self.kit:
            return

        redirects = profile.dns.get("redirects", [])
        for redirect in redirects:
            domain = redirect.get("domain")
            if not domain:
                continue

            if redirect.get("to_proxy", False):
                self.kit.dns.redirect(domain, client_ip)
            elif "target_ip" in redirect:
                self.kit.dns.redirect_to_ip(
                    domain, redirect["target_ip"], client_ip
                )

    def _apply_proxy(self, profile: TestProfile, client_ip: str) -> None:
        """Apply proxy settings from profile."""
        if not profile.proxy or not self.kit:
            return

        rules = profile.proxy.get("rules", [])
        for rule in rules:
            path = rule.get("path")
            if not path:
                continue

            action = rule.get("action", "override")
            body = rule.get("body")
            status = rule.get("status", 200)

            if action == "error":
                self.kit.proxy.set_error(
                    client_ip,
                    path,
                    int(status),
                    response=body,
                )
            elif action == "delay":
                delay_ms = rule.get("delay_ms", 1000)
                self.kit.proxy.set_delay(client_ip, path, delay_ms)
            else:
                self.kit.proxy.set_response(
                    client_ip,
                    path,
                    body,
                    status=int(status),
                )


# Built-in profiles for common scenarios
BUILTIN_PROFILES: dict[str, dict[str, Any]] = {
    "premium-user": {
        "name": "premium-user",
        "description": "Premium subscriber with all features",
        "network": {"profile": "wifi-good"},
        "proxy": {
            "rules": [
                {
                    "path": "/api/subscription",
                    "body": {
                        "plan": "premium",
                        "status": "active",
                        "features": ["4k", "hdr", "downloads", "offline"],
                    },
                }
            ]
        },
    },
    "trial-user": {
        "name": "trial-user",
        "description": "Trial user with limited features",
        "network": {"profile": "wifi-good"},
        "proxy": {
            "rules": [
                {
                    "path": "/api/subscription",
                    "body": {
                        "plan": "trial",
                        "status": "active",
                        "days_remaining": 7,
                        "features": ["hd"],
                    },
                }
            ]
        },
    },
    "expired-user": {
        "name": "expired-user",
        "description": "User with expired subscription",
        "proxy": {
            "rules": [
                {
                    "path": "/api/subscription",
                    "body": {
                        "plan": "expired",
                        "status": "expired",
                        "can_watch": False,
                    },
                }
            ]
        },
    },
    "slow-network": {
        "name": "slow-network",
        "description": "Poor network conditions",
        "network": {"profile": "3g"},
    },
    "offline": {
        "name": "offline",
        "description": "No network connectivity",
        "network": {"profile": "offline"},
    },
    "api-errors": {
        "name": "api-errors",
        "description": "API returning errors",
        "proxy": {
            "rules": [
                {"path": "/api/*", "action": "error", "status": 500},
            ]
        },
    },
}
