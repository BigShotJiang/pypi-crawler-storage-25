"""
Start mtk-serve alongside the test dashboard when the proxy URL is local and idle.

Only runs when ``MTK_SERVICE_URL`` is ``http://`` on a loopback host (e.g. ``127.0.0.1``)
and the target port accepts no TCP connection. Remote URLs are never auto-started.

Disable: ``MTK_DASHBOARD_AUTO_SERVE=0`` or ``mtk dashboard start --no-auto-serve``.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from typing import Any
from urllib.parse import urlparse


def _tcp_reachable(host: str, port: int, timeout: float = 0.35) -> bool:
    connect_host = "127.0.0.1" if host.lower() == "localhost" else host
    try:
        with socket.create_connection((connect_host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _parse_http_service(url: str) -> tuple[str, int] | None:
    u = (url or "").strip()
    if not u:
        return None
    p = urlparse(u)
    if p.scheme != "http":
        return None
    host = (p.hostname or "").strip()
    if not host:
        return None
    pr = p.port or 80
    return host, pr


def _is_loopback_host(host: str) -> bool:
    h = host.lower()
    if h in ("127.0.0.1", "localhost", "::1"):
        return True
    try:
        import ipaddress

        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def ensure_local_mtk_serve() -> Any | None:
    """
    If appropriate, spawn ``python -m mtk_router_sdk.service.main`` (mtk-serve).

    Sets ``MTK_HTTP_PORT`` in the child environment to match the port from
    ``MTK_SERVICE_URL``. Returns a :class:`subprocess.Popen` if this process
    started the server, or ``None`` if skipped or startup failed.
    """

    raw = os.environ.get("MTK_DASHBOARD_AUTO_SERVE", "1").strip().lower()
    if raw in ("0", "false", "no", "off"):
        return None

    base = (os.environ.get("MTK_SERVICE_URL") or "").strip() or "http://127.0.0.1:8765"
    parsed = _parse_http_service(base)
    if not parsed:
        return None
    host, port = parsed
    if not _is_loopback_host(host):
        return None

    connect_host = "127.0.0.1" if host.lower() == "localhost" else host
    if _tcp_reachable(connect_host, port):
        return None

    env = os.environ.copy()
    env["MTK_HTTP_PORT"] = str(port)

    cmd = [sys.executable, "-m", "mtk_router_sdk.service.main"]
    pop_kw: dict[str, Any] = dict(
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        stdin=subprocess.DEVNULL,
    )
    if sys.platform != "win32":
        pop_kw["close_fds"] = True

    try:
        proc = subprocess.Popen(cmd, **pop_kw)
    except OSError as e:
        print(f"[dashboard] could not spawn mtk-serve: {e}")
        return None

    deadline = time.monotonic() + 12.0
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            err = b""
            if proc.stderr:
                err = proc.stderr.read()
            msg = err.decode(errors="replace").strip() or f"exit {proc.returncode}"
            print(f"[dashboard] mtk-serve exited immediately: {msg[:800]}")
            return None
        if _tcp_reachable(connect_host, port):
            print(
                f"[dashboard] started mtk-serve on http://{connect_host}:{port} "
                "(stop the dashboard to stop it, or set MTK_DASHBOARD_AUTO_SERVE=0 to disable)."
            )
            return proc
        time.sleep(0.1)

    proc.terminate()
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
    print(
        f"[dashboard] mtk-serve did not listen on {connect_host}:{port} in time. "
        "Start it manually: mtk-serve"
    )
    return None
