"""
Change Tracker — Records all test changes for single-call cleanup.

Usage:
    tracker = ChangeTracker()

    # Record changes during test
    tracker.record_network_change("192.168.1.100", "3g")
    tracker.record_dns_redirect("api.example.com", "192.168.1.100")
    tracker.record_proxy_rule("192.168.1.100", "/api/test")

    # Single call to clean up everything
    await tracker.teardown(kit)

    # Or automatically with context manager
    async with tracker.session(kit):
        # All changes recorded and cleaned up automatically
        pass
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from mtk_router_sdk.testing.kit import MtkTestKit


class ChangeType(Enum):
    """Types of changes that can be tracked."""

    NETWORK_CONDITION = "network"
    DNS_REDIRECT = "dns"
    PROXY_RULE = "proxy"
    VPN_CHANGE = "vpn"
    CLIENT_BLOCK = "block"


@dataclass
class Change:
    """A recorded change."""

    type: ChangeType
    client_ip: str
    details: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class ChangeTracker:
    """
    Tracks all changes made during a test for easy cleanup.

    Records:
    - Network condition changes (throttling, profiles)
    - DNS redirects
    - Proxy rules
    - VPN changes
    - Client blocks

    Provides single-call teardown to revert all changes.
    """

    _changes: list[Change] = field(default_factory=list)
    _clients: set[str] = field(default_factory=set)

    def record(
        self,
        change_type: ChangeType,
        client_ip: str,
        **details: Any,
    ) -> Change:
        """
        Record a change.

        Args:
            change_type: Type of change
            client_ip: Affected client IP
            **details: Additional details about the change
        """
        change = Change(
            type=change_type,
            client_ip=client_ip,
            details=details,
        )
        self._changes.append(change)
        self._clients.add(client_ip)
        return change

    def record_network_change(
        self,
        client_ip: str,
        profile: str | None = None,
        **settings: Any,
    ) -> Change:
        """Record a network condition change."""
        return self.record(
            ChangeType.NETWORK_CONDITION,
            client_ip,
            profile=profile,
            **settings,
        )

    def record_dns_redirect(
        self,
        domain: str,
        client_ip: str | None = None,
        target_ip: str | None = None,
    ) -> Change:
        """Record a DNS redirect."""
        return self.record(
            ChangeType.DNS_REDIRECT,
            client_ip or "all",
            domain=domain,
            target_ip=target_ip,
        )

    def record_proxy_rule(
        self,
        client_ip: str,
        path: str,
        action: str = "override",
    ) -> Change:
        """Record a proxy rule."""
        return self.record(
            ChangeType.PROXY_RULE,
            client_ip,
            path=path,
            action=action,
        )

    def record_vpn_change(
        self,
        slot_id: int,
        tunnel: str,
    ) -> Change:
        """Record a VPN change."""
        return self.record(
            ChangeType.VPN_CHANGE,
            f"slot_{slot_id}",
            slot_id=slot_id,
            tunnel=tunnel,
        )

    def record_client_block(
        self,
        client_ip: str,
    ) -> Change:
        """Record a client block."""
        return self.record(
            ChangeType.CLIENT_BLOCK,
            client_ip,
        )

    @property
    def changes(self) -> list[Change]:
        """Get all recorded changes."""
        return list(self._changes)

    @property
    def affected_clients(self) -> set[str]:
        """Get all affected client IPs."""
        return set(self._clients)

    @property
    def change_count(self) -> int:
        """Get total number of changes."""
        return len(self._changes)

    def summary(self) -> dict[str, Any]:
        """Get a summary of all changes."""
        by_type: dict[str, int] = {}
        for change in self._changes:
            key = change.type.value
            by_type[key] = by_type.get(key, 0) + 1

        return {
            "total_changes": len(self._changes),
            "affected_clients": list(self._clients),
            "by_type": by_type,
        }

    def teardown(self, kit: MtkTestKit) -> None:
        """
        Clean up all recorded changes.

        This is the main cleanup method — call this in test teardown.

        Args:
            kit: MtkTestKit instance to use for cleanup
        """
        errors: list[str] = []

        # Sentinels: do not pass to network/proxy clear (real IPs only)
        _skip_clients = frozenset({"all", ""})

        for client_ip in self._clients:
            if client_ip.startswith("slot_") or client_ip in _skip_clients:
                continue

            try:
                kit.network.clear(client_ip)
            except Exception as e:
                errors.append(f"network clear {client_ip}: {e}")

            try:
                kit.dns.clear(client_ip)
            except Exception as e:
                errors.append(f"dns clear {client_ip}: {e}")

            try:
                kit.proxy.clear_client(client_ip)
            except Exception as e:
                errors.append(f"proxy clear {client_ip}: {e}")

        for change in self._changes:
            if change.type == ChangeType.DNS_REDIRECT and change.client_ip == "all":
                domain = change.details.get("domain")
                if domain:
                    try:
                        kit.dns.remove(domain)
                    except Exception as e:
                        errors.append(f"dns remove {domain}: {e}")

            elif change.type == ChangeType.CLIENT_BLOCK:
                try:
                    if kit._client:
                        from mtk_router_sdk.ops.client_block import unblock_client
                        unblock_client(kit._client, change.client_ip)
                except Exception as e:
                    errors.append(f"unblock {change.client_ip}: {e}")

        self._changes.clear()
        self._clients.clear()

        if errors:
            print(f"Teardown completed with {len(errors)} errors: {errors[:3]}")

    async def teardown_async(self, kit: MtkTestKit) -> None:
        """Async version of teardown."""
        import asyncio

        await asyncio.to_thread(self.teardown, kit)

    def clear(self) -> None:
        """Clear all recorded changes without cleaning up."""
        self._changes.clear()
        self._clients.clear()

    def session(self, kit: MtkTestKit) -> _TrackerSession:
        """
        Context manager for automatic cleanup.

        Usage:
            with tracker.session(kit):
                # Make changes here
                pass
            # All changes cleaned up automatically
        """
        return _TrackerSession(self, kit)


class _TrackerSession:
    """Context manager for automatic teardown."""

    def __init__(self, tracker: ChangeTracker, kit: MtkTestKit) -> None:
        self.tracker = tracker
        self.kit = kit

    def __enter__(self) -> ChangeTracker:
        return self.tracker

    def __exit__(self, *args: Any) -> None:
        self.tracker.teardown(self.kit)

    async def __aenter__(self) -> ChangeTracker:
        return self.tracker

    async def __aexit__(self, *args: Any) -> None:
        self.tracker.teardown(self.kit)


class TrackedMtkTestKit:
    """
    MtkTestKit wrapper that automatically tracks all changes.

    Usage:
        kit = TrackedMtkTestKit.from_env()

        # All changes are automatically tracked
        kit.network.apply_profile("192.168.1.100", "3g")
        kit.proxy.set_response("192.168.1.100", "/api/test", {"ok": True})

        # View what changed
        print(kit.tracker.summary())

        # Single call to clean up everything
        kit.teardown()
    """

    def __init__(self, kit: MtkTestKit) -> None:
        self._kit = kit
        self._tracker = ChangeTracker()
        self._network = _TrackedNetwork(kit.network, self._tracker)
        self._dns = _TrackedDns(kit.dns, self._tracker)
        self._proxy = _TrackedProxy(kit.proxy, self._tracker)

    @classmethod
    def from_env(cls) -> TrackedMtkTestKit:
        """Create from environment variables."""
        return cls(MtkTestKit.from_env())

    @classmethod
    def from_site(cls, site_path: str) -> TrackedMtkTestKit:
        """Create from site config."""
        return cls(MtkTestKit.from_site(site_path))

    @property
    def network(self) -> _TrackedNetwork:
        """Network simulator with change tracking."""
        return self._network

    @property
    def dns(self) -> _TrackedDns:
        """DNS override with change tracking."""
        return self._dns

    @property
    def proxy(self) -> _TrackedProxy:
        """Proxy manager with change tracking."""
        return self._proxy

    @property
    def profiles(self) -> Any:
        """Configuration profiles (same as underlying :class:`MtkTestKit`)."""
        return self._kit.profiles

    @property
    def scenarios(self) -> Any:
        """Scenario runner."""
        return self._kit.scenarios

    @property
    def recorder(self) -> Any:
        """HAR session recorder."""
        return self._kit.recorder

    @property
    def tracker(self) -> ChangeTracker:
        """Access the change tracker."""
        return self._tracker

    @property
    def changes(self) -> list[Change]:
        """Get all recorded changes."""
        return self._tracker.changes

    def teardown(self) -> None:
        """
        Clean up ALL changes made during the test.

        Call this in your test teardown/cleanup.
        """
        self._tracker.teardown(self._kit)

    def close(self) -> None:
        """Clean up and close connections."""
        self.teardown()
        self._kit.close()


class _TrackedNetwork:
    """Network simulator wrapper with automatic change tracking."""

    def __init__(self, network: Any, tracker: ChangeTracker) -> None:
        self._network = network
        self._tracker = tracker

    def apply_profile(self, client_ip: str, profile: str) -> Any:
        """Apply network profile and track the change."""
        self._tracker.record_network_change(client_ip, profile=profile)
        return self._network.apply_profile(client_ip, profile)

    def throttle(
        self,
        client_ip: str,
        download_kbps: int | None = None,
        upload_kbps: int | None = None,
    ) -> Any:
        """Apply throttling and track the change."""
        self._tracker.record_network_change(
            client_ip,
            download_kbps=download_kbps,
            upload_kbps=upload_kbps,
        )
        return self._network.throttle(client_ip, download_kbps, upload_kbps)

    def latency(self, client_ip: str, delay_ms: int, jitter_ms: int = 0) -> Any:
        """Add latency and track the change."""
        self._tracker.record_network_change(
            client_ip,
            latency_ms=delay_ms,
            jitter_ms=jitter_ms,
        )
        return self._network.latency(client_ip, delay_ms, jitter_ms)

    def packet_loss(self, client_ip: str, percent: float) -> Any:
        """Add packet loss and track the change."""
        self._tracker.record_network_change(client_ip, packet_loss_percent=percent)
        return self._network.packet_loss(client_ip, percent)

    def disconnect(self, client_ip: str, duration_seconds: int | None = None) -> Any:
        """Disconnect and track the change."""
        self._tracker.record_network_change(client_ip, profile="offline")
        return self._network.disconnect(client_ip, duration_seconds)

    def clear(self, client_ip: str) -> None:
        """Clear network conditions (does not affect tracker)."""
        self._network.clear(client_ip)


class _TrackedDns:
    """DNS override wrapper with automatic change tracking."""

    def __init__(self, dns: Any, tracker: ChangeTracker) -> None:
        self._dns = dns
        self._tracker = tracker

    def redirect(
        self,
        domain: str,
        client_ip: str | None = None,
        ttl: int = 60,
    ) -> Any:
        """Redirect domain and track the change."""
        self._tracker.record_dns_redirect(domain, client_ip)
        return self._dns.redirect(domain, client_ip, ttl)

    def redirect_to_ip(
        self,
        domain: str,
        target_ip: str,
        client_ip: str | None = None,
        ttl: int = 60,
    ) -> Any:
        """Redirect to IP and track the change."""
        self._tracker.record_dns_redirect(domain, client_ip, target_ip)
        return self._dns.redirect_to_ip(domain, target_ip, client_ip, ttl)

    def clear(self, client_ip: str) -> None:
        """Clear DNS redirects (does not affect tracker)."""
        self._dns.clear(client_ip)


class _TrackedProxy:
    """Proxy manager wrapper with automatic change tracking."""

    def __init__(self, proxy: Any, tracker: ChangeTracker) -> None:
        self._proxy = proxy
        self._tracker = tracker

    def set_response(
        self,
        client_ip: str,
        path: str,
        body: Any,
        status: int = 200,
    ) -> Any:
        """Set response and track the change."""
        self._tracker.record_proxy_rule(client_ip, path, "override")
        return self._proxy.set_response(client_ip, path, body, status=status)

    def set_error(
        self,
        client_ip: str,
        path: str,
        status: int = 500,
        body: Any = None,
    ) -> Any:
        """Set error and track the change."""
        self._tracker.record_proxy_rule(client_ip, path, "error")
        return self._proxy.set_error(client_ip, path, status, response=body)

    def clear_client(self, client_ip: str) -> int:
        """Clear proxy rules (does not affect tracker)."""
        n = self._proxy.clear_client(client_ip)
        return int(n)
