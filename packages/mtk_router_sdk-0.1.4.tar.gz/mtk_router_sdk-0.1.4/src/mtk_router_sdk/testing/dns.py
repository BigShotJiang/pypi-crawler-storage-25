"""
DNS Override Automation — Redirect domains without device configuration.

Usage:
    from mtk_router_sdk.testing import DnsOverride

    dns = DnsOverride.from_env()

    # Redirect domain to proxy for all clients
    dns.redirect("api.example.com")

    # Redirect for specific client only
    dns.redirect("api.example.com", client_ip="192.168.1.100")

    # Redirect to custom IP
    dns.redirect_to_ip("api.example.com", "10.0.0.50")

    # Wildcard redirect
    dns.redirect("*.example.com")

    # Clear redirects
    dns.clear("192.168.1.100")

Uses RouterOS over SSH when ``RouterClient`` is set, otherwise mtk-serve
HTTP (``MTK_SERVICE_URL``) if only the API is available.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mtk_router_sdk.client import RouterClient


@dataclass
class DnsRedirect:
    """A DNS redirect rule."""

    domain: str
    target_ip: str
    client_ip: str | None = None
    ttl: int = 60
    active: bool = True


@dataclass
class DnsOverride:
    """
    DNS override automation for zero-config device interception.

    Redirects DNS queries at the router level, so devices don't need
    any configuration to have their traffic intercepted.

    Supports:
    - Global redirects (all devices)
    - Per-client redirects (specific IP only)
    - Wildcard domains (*.example.com)
    - Custom TTL
    """

    client: RouterClient | None = None
    base_url: str | None = None
    token: str | None = None
    proxy_ip: str | None = None
    _redirects: dict[str, DnsRedirect] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> DnsOverride:
        """Create from environment variables."""
        from mtk_router_sdk.client import RouterClient

        base_url = os.environ.get(
            "MTK_SERVICE_URL",
            f"http://127.0.0.1:{os.environ.get('MTK_HTTP_PORT', '8765')}",
        )
        token = os.environ.get("MTK_SERVICE_TOKEN")
        proxy_ip = os.environ.get("MTK_PROXY_IP")

        client: RouterClient | None = None
        try:
            client = RouterClient.from_env()
            if proxy_ip is None:
                from mtk_router_sdk.config.env import connection_config_from_env
                from mtk_router_sdk.exceptions import ConfigurationError

                try:
                    cfg = connection_config_from_env(
                        require_password=True,
                        exit_on_missing_password=False,
                    )
                    client.connect(cfg)
                    result = client.exec_command(
                        "/ip address print where interface=bridge"
                    )
                    lines = result.stdout.strip().split("\n")
                    for line in lines:
                        if "/" in line:
                            parts = line.split()
                            for part in parts:
                                if "/" in part and "." in part:
                                    proxy_ip = part.split("/")[0]
                                    break
                except (ConfigurationError, OSError, Exception):
                    pass
        except Exception:
            pass

        if proxy_ip is None:
            proxy_ip = "192.168.88.1"

        return cls(
            client=client,
            base_url=base_url,
            token=token,
            proxy_ip=proxy_ip,
        )

    def _uses_http(self) -> bool:
        return self.client is None and bool(self.base_url)

    def _require_transport(self) -> None:
        if self.client is not None or self.base_url:
            return
        raise RuntimeError(
            "DnsOverride needs Router SSH (MTK_HOST, MTK_USER, MTK_PASSWORD) "
            "or mtk-serve HTTP (MTK_SERVICE_URL)."
        )

    def _ensure_ssh_connected(self) -> None:
        if self.client is None or self._uses_http():
            return
        if self.client.connected:
            return
        from mtk_router_sdk.config.env import connection_config_from_env
        from mtk_router_sdk.exceptions import ConfigurationError

        try:
            cfg = connection_config_from_env(
                require_password=True,
                exit_on_missing_password=False,
            )
        except ConfigurationError as e:
            raise RuntimeError(e.message) from e
        self.client.connect(cfg)

    def redirect(
        self,
        domain: str,
        client_ip: str | None = None,
        ttl: int = 60,
    ) -> DnsRedirect:
        """
        Redirect a domain to the proxy.

        Args:
            domain: Domain to redirect (e.g., "api.example.com" or "*.example.com")
            client_ip: Only redirect for this client (None = all clients)
            ttl: TTL in seconds for the DNS record

        Returns:
            DnsRedirect with applied settings
        """
        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            key = f"{domain}:{client_ip or 'all'}"
            redir = DnsRedirect(
                domain=domain,
                target_ip=self.proxy_ip or "",
                client_ip=client_ip,
                ttl=ttl,
                active=True,
            )
            self._redirects[key] = redir
            body: dict[str, object] = {
                "domain": domain,
                "to_proxy": True,
                "ttl": ttl,
            }
            if client_ip:
                body["client_ip"] = client_ip
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/dns/redirect",
                token=self.token,
                json_body=body,
            )
            return redir

        if self.proxy_ip is None:
            raise ValueError("Proxy IP not configured. Set MTK_PROXY_IP env var.")

        return self.redirect_to_ip(
            domain=domain,
            target_ip=self.proxy_ip,
            client_ip=client_ip,
            ttl=ttl,
        )

    def redirect_to_ip(
        self,
        domain: str,
        target_ip: str,
        client_ip: str | None = None,
        ttl: int = 60,
    ) -> DnsRedirect:
        """
        Redirect a domain to a specific IP address.

        Args:
            domain: Domain to redirect
            target_ip: IP address to redirect to
            client_ip: Only redirect for this client (None = all clients)
            ttl: TTL in seconds

        Returns:
            DnsRedirect with applied settings
        """
        key = f"{domain}:{client_ip or 'all'}"
        redirect = DnsRedirect(
            domain=domain,
            target_ip=target_ip,
            client_ip=client_ip,
            ttl=ttl,
            active=True,
        )
        self._redirects[key] = redirect

        self._require_transport()
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            body: dict[str, object] = {"domain": domain, "ttl": ttl}
            if client_ip:
                body["client_ip"] = client_ip
            if self.proxy_ip and target_ip == self.proxy_ip:
                body["to_proxy"] = True
            else:
                body["target_ip"] = target_ip
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/dns/redirect",
                token=self.token,
                json_body=body,
            )
            return redirect

        self._apply_dns_static(redirect)
        if client_ip:
            self._apply_per_client_rules(redirect)

        return redirect

    def get_redirect(
        self, domain: str, client_ip: str | None = None
    ) -> DnsRedirect | None:
        """Get a specific redirect rule."""
        key = f"{domain}:{client_ip or 'all'}"
        return self._redirects.get(key)

    def list_redirects(
        self, client_ip: str | None = None
    ) -> list[DnsRedirect]:
        """
        List active redirect rules.

        Args:
            client_ip: Filter by client IP (None = all)
        """
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            query = {"client_ip": client_ip} if client_ip else None
            data = testing_service_request(
                self.base_url,
                "GET",
                "/v1/dns/redirects",
                token=self.token,
                query=query,
            )
            return [
                DnsRedirect(
                    domain=str(r["domain"]),
                    target_ip=str(r["target_ip"]),
                    client_ip=r.get("client_ip"),
                    ttl=int(r.get("ttl", 60)),
                    active=bool(r.get("active", True)),
                )
                for r in data.get("redirects", [])
            ]

        redirects = list(self._redirects.values())
        if client_ip:
            redirects = [
                r for r in redirects
                if r.client_ip is None or r.client_ip == client_ip
            ]
        return [r for r in redirects if r.active]

    def remove(
        self, domain: str, client_ip: str | None = None
    ) -> bool:
        """
        Remove a specific redirect rule.

        Returns:
            True if rule was removed, False if not found
        """
        key = f"{domain}:{client_ip or 'all'}"
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            query: dict[str, str] = {"domain": domain}
            if client_ip is not None:
                query["client_ip"] = client_ip
            testing_service_request(
                self.base_url,
                "DELETE",
                "/v1/dns/redirect",
                token=self.token,
                query=query,
            )
            had_local = key in self._redirects
            self._redirects.pop(key, None)
            return had_local

        if key in self._redirects:
            redirect = self._redirects[key]
            self._remove_dns_static(redirect)
            if redirect.client_ip:
                self._remove_per_client_rules(redirect)
            del self._redirects[key]
            return True
        return False

    def clear(self, client_ip: str) -> None:
        """Clear all redirect rules for a specific client."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "DELETE",
                "/v1/dns/redirect",
                token=self.token,
                query={"client_ip": client_ip},
            )
            to_remove = [
                k for k, r in self._redirects.items()
                if r.client_ip == client_ip
            ]
            for k in to_remove:
                del self._redirects[k]
            return

        to_remove = [
            key for key, r in self._redirects.items()
            if r.client_ip == client_ip
        ]
        for key in to_remove:
            redirect = self._redirects[key]
            self._remove_dns_static(redirect)
            self._remove_per_client_rules(redirect)
            del self._redirects[key]

    def clear_all(self) -> None:
        """Clear all redirect rules."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "DELETE",
                "/v1/dns/redirect",
                token=self.token,
            )
            self._redirects.clear()
            return

        for redirect in list(self._redirects.values()):
            self._remove_dns_static(redirect)
            if redirect.client_ip:
                self._remove_per_client_rules(redirect)
        self._redirects.clear()

        if self.client:
            self._ensure_ssh_connected()
            self.client.exec_command(
                "/ip dns static remove [find comment~\"mtk_dns_\"]"
            )
            self.client.exec_command("/ip dns cache flush")

    def _apply_dns_static(self, redirect: DnsRedirect) -> None:
        """Apply MikroTik DNS static entry."""
        if self.client is None:
            return
        self._ensure_ssh_connected()

        comment = self._make_comment(redirect)

        self.client.exec_command(f"/ip dns static remove [find comment={comment}]")

        is_wildcard = redirect.domain.startswith("*.")
        if is_wildcard:
            regexp = redirect.domain.replace("*.", ".*\\.")
            cmd = (
                f"/ip dns static add "
                f"regexp=\"{regexp}\" "
                f"address={redirect.target_ip} "
                f"ttl={redirect.ttl}s "
                f"comment={comment}"
            )
        else:
            cmd = (
                f"/ip dns static add "
                f"name={redirect.domain} "
                f"address={redirect.target_ip} "
                f"ttl={redirect.ttl}s "
                f"comment={comment}"
            )

        self.client.exec_command(cmd)
        self.client.exec_command("/ip dns cache flush")

    def _apply_per_client_rules(self, redirect: DnsRedirect) -> None:
        """
        Apply per-client DNS routing.

        For per-client DNS, we use address lists and dst-nat rules.
        This is more complex but allows different DNS responses per client.
        """
        if self.client is None or redirect.client_ip is None:
            return
        self._ensure_ssh_connected()

        comment = self._make_comment(redirect)
        client_safe = redirect.client_ip.replace(".", "_")
        address_list = f"mtk_dns_client_{client_safe}"

        self.client.exec_command(
            f"/ip firewall address-list remove [find list={address_list}]"
        )
        self.client.exec_command(
            f"/ip firewall address-list add "
            f"list={address_list} "
            f"address={redirect.client_ip} "
            f"comment={comment}"
        )

    def _remove_dns_static(self, redirect: DnsRedirect) -> None:
        """Remove MikroTik DNS static entry."""
        if self.client is None:
            return
        self._ensure_ssh_connected()

        comment = self._make_comment(redirect)
        self.client.exec_command(f"/ip dns static remove [find comment={comment}]")
        self.client.exec_command("/ip dns cache flush")

    def _remove_per_client_rules(self, redirect: DnsRedirect) -> None:
        """Remove per-client DNS rules."""
        if self.client is None or redirect.client_ip is None:
            return
        self._ensure_ssh_connected()

        comment = self._make_comment(redirect)
        self.client.exec_command(
            f"/ip firewall address-list remove [find comment={comment}]"
        )

    def _make_comment(self, redirect: DnsRedirect) -> str:
        """Create a unique comment for the redirect rule."""
        domain_safe = redirect.domain.replace(".", "_").replace("*", "wildcard")
        client_safe = (redirect.client_ip or "all").replace(".", "_")
        return f"mtk_dns_{domain_safe}_{client_safe}"

    def flush_cache(self) -> None:
        """Flush the router's DNS cache."""
        if self._uses_http():
            from mtk_router_sdk.testing.http_api import testing_service_request

            assert self.base_url is not None
            testing_service_request(
                self.base_url,
                "POST",
                "/v1/dns/flush",
                token=self.token,
            )
            return
        if self.client:
            self._ensure_ssh_connected()
            self.client.exec_command("/ip dns cache flush")
