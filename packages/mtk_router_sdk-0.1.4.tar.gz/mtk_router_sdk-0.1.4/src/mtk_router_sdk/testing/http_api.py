"""HTTP calls to mtk-serve testing routes (when RouterClient/SSH is unavailable)."""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class TestingServiceHttpError(Exception):
    """HTTP or transport error talking to mtk-serve testing API."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: dict[str, Any] | None = None,
    ) -> None:
        self.status_code = status_code
        self.body = body or {}
        super().__init__(message)


def testing_service_request(
    base_url: str,
    method: str,
    path: str,
    *,
    token: str | None = None,
    query: dict[str, str] | None = None,
    json_body: dict[str, Any] | None = None,
    timeout: float = 60.0,
) -> dict[str, Any]:
    """
    Perform JSON request against mtk-serve (e.g. /v1/network/apply).

    Returns parsed JSON object (empty dict if body is empty).
    """
    base = base_url.rstrip("/")
    url = f"{base}{path}"
    if query:
        url = f"{url}?{urllib.parse.urlencode(query)}"

    headers = {"Accept": "application/json"}
    data: bytes | None = None
    if json_body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(json_body).encode("utf-8")
    if token:
        headers["Authorization"] = f"Bearer {token.strip()}"

    req = urllib.request.Request(url, data=data, headers=headers, method=method.upper())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            if not raw.strip():
                return {}
            out = json.loads(raw)
            if not isinstance(out, dict):
                return {"_data": out}
            return out
    except urllib.error.HTTPError as e:
        body_txt = e.read().decode("utf-8", errors="replace")
        try:
            parsed = json.loads(body_txt) if body_txt.strip() else {}
        except json.JSONDecodeError:
            parsed = {"error": body_txt or e.reason}
        msg = str(parsed.get("error", e.reason))
        raise TestingServiceHttpError(
            msg,
            status_code=e.code,
            body=parsed if isinstance(parsed, dict) else {},
        ) from e
    except urllib.error.URLError as e:
        raise TestingServiceHttpError(
            f"Cannot reach mtk-serve at {base_url}: {e.reason}",
        ) from e
