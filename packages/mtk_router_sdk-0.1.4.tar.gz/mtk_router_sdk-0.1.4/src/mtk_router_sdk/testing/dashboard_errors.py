"""
Structured errors for the test dashboard API.

Every failure returns JSON the UI can render: title, user_message, hints, module, code.
"""

from __future__ import annotations

from typing import Any

from starlette.responses import JSONResponse

MODULE_NETWORK = "network"
MODULE_DNS = "dns"
MODULE_PROXY = "proxy"
MODULE_PROFILES = "profiles"
MODULE_SCENARIOS = "scenarios"
MODULE_RECORDING = "recording"
MODULE_GENERAL = "general"


def problem_response(
    *,
    module: str,
    code: str,
    title: str,
    user_message: str,
    hints: list[str] | None = None,
    technical: str | None = None,
    status_code: int = 500,
    extra: dict[str, Any] | None = None,
) -> JSONResponse:
    """Standard error body for dashboard /api/* routes."""
    body: dict[str, Any] = {
        "ok": False,
        "module": module,
        "code": code,
        "title": title,
        "user_message": user_message,
        "message": user_message,
        "hints": list(hints or ()),
    }
    if technical:
        body["technical"] = technical
    if extra:
        body.update(extra)
    # Back-compat for older clients
    body["error"] = user_message
    return JSONResponse(body, status_code=status_code)


def _merge_hints(base: list[str], more: list[str] | None) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for h in (base or []) + (more or []):
        t = h.strip()
        if not t or t in seen:
            continue
        seen.add(t)
        out.append(t)
    return out


def problem_from_exception(module: str, exc: BaseException, *, status_code: int | None = None) -> JSONResponse:
    """Map common exceptions to readable titles, hints, and HTTP status."""
    from mtk_router_sdk.testing.http_api import TestingServiceHttpError

    tech = str(exc).strip() or type(exc).__name__
    low = tech.lower()
    hints: list[str] = []
    title = "Something went wrong"
    code = "OPERATION_FAILED"
    user_msg = tech
    st = status_code if status_code is not None else 500

    if isinstance(exc, TestingServiceHttpError):
        body = exc.body or {}
        user_msg = (
            str(body.get("user_message") or body.get("message") or body.get("error") or body.get("detail") or tech)
        )
        sc = exc.status_code
        for key in ("hints", "suggestions"):
            raw = body.get(key)
            if isinstance(raw, list):
                hints.extend(str(x).strip() for x in raw if str(x).strip())
        if sc == 401:
            title = "mtk-serve authentication failed"
            code = "MTK_SERVE_UNAUTHORIZED"
            hints = _merge_hints(
                [
                    "Set MTK_SERVE_TOKEN to a valid bearer token if your mtk-serve instance requires auth.",
                    "Confirm MTK_SERVE_URL points at the same host/port shown in mtk-serve logs.",
                ],
                hints,
            )
            st = 401
        elif sc == 403:
            title = "mtk-serve denied this request"
            code = "MTK_SERVE_FORBIDDEN"
            hints = _merge_hints(
                [
                    "Check token scope and mtk-serve policy for the testing routes.",
                    "Try mtk doctor or curl the same URL with your token from the shell.",
                ],
                hints,
            )
            st = 403
        elif sc == 404:
            title = "mtk-serve route not found"
            code = "MTK_SERVE_NOT_FOUND"
            hints = _merge_hints(
                [
                    "Upgrade mtk-serve to a build that exposes /v1/network, /v1/proxy, etc.",
                    "Verify MTK_SERVE_URL has no trailing path beyond the service root.",
                ],
                hints,
            )
            st = 502
        elif sc is not None and sc >= 500:
            title = "mtk-serve returned a server error"
            code = "MTK_SERVE_ERROR"
            hints = _merge_hints(
                [
                    "Check mtk-serve logs for stack traces.",
                    "Retry after the service restarts; if it persists, capture the response body.",
                ],
                hints,
            )
            st = 502
        else:
            title = "Request to mtk-serve failed"
            code = "MTK_SERVE_CLIENT_ERROR"
            hints = _merge_hints(
                [
                    "Compare the dashboard action with the equivalent mtk CLI or kit call.",
                    "Inspect mtk-serve logs for validation errors tied to this request.",
                ],
                hints,
            )
            st = sc if sc and sc >= 400 else 502

    elif isinstance(exc, TimeoutError) or "timed out" in low or "timeout" in low:
        title = "Request timed out"
        code = "TIMEOUT"
        user_msg = tech
        hints = [
            "The router SSH session or mtk-serve HTTP call took too long — check VPN, Wi‑Fi, or router load.",
            "Increase timeouts in your environment or retry when the lab network is stable.",
        ]
        st = status_code or 504

    elif "connection refused" in low or "errno 61" in low or "actively refused" in low:
        title = "Connection refused"
        code = "CONNECTION_REFUSED"
        if module == MODULE_PROXY:
            hints = [
                "Start mtk-serve and set MTK_SERVE_URL (e.g. http://127.0.0.1:8787) to match its listen address.",
                "From a terminal: curl -sS \"$MTK_SERVE_URL/v1/doctor\" to confirm the service is up.",
            ]
        elif module in (MODULE_NETWORK, MODULE_DNS, MODULE_PROFILES, MODULE_SCENARIOS):
            hints = [
                "Router actions use SSH — set MTK_ROUTER_HOST, user, and password or key in the environment.",
                "Run mtk doctor to verify RouterOS reachability from this machine.",
            ]
        else:
            hints = [
                "Confirm mtk-serve is running for proxy features and SSH/env is set for RouterOS features.",
            ]
        st = status_code or 503

    elif "could not resolve" in low or "name or service not known" in low or "nodename nor servname" in low:
        title = "Host name could not be resolved"
        code = "DNS_RESOLUTION"
        hints = [
            "Check MTK_SERVE_URL and MTK_ROUTER_HOST for typos.",
            "Ensure DNS works on this machine (try ping or nslookup to the same hostname).",
        ]
        st = status_code or 503

    elif "permission denied" in low or "auth" in low and "fail" in low:
        title = "Authentication or permission problem"
        code = "AUTH_FAILED"
        hints = [
            "Verify SSH credentials for the router or bearer token for mtk-serve.",
            "If using keys, confirm the key path and that the router user is allowed to log in.",
        ]
        st = status_code or 401

    elif module == MODULE_NETWORK and ("queue" in low or "mangle" in low or "firewall" in low):
        title = "Router rejected the network change"
        code = "ROUTER_NETWORK_REJECT"
        hints = _merge_hints(
            [
                "Ensure the client IP exists on a LAN the router knows (DHCP lease or static).",
                "Check RouterOS scripts/queues are not conflicting; try mtk network clear then re-apply.",
            ],
            hints,
        )

    elif module == MODULE_DNS and ("static" in low or "dns" in low):
        title = "DNS change failed on the router"
        code = "ROUTER_DNS_REJECT"
        hints = _merge_hints(
            [
                "Confirm IP DNS / static entry limits on RouterOS.",
                "Flush DNS cache after changes; verify the domain string has no stray spaces.",
            ],
            hints,
        )

    if not hints and st >= 500:
        hints = [
            "Open the Technical detail section (toast or card) for the exact server message.",
            "Re-run the same action via mtk CLI or MtkTestKit.from_env() in a shell with identical env.",
        ]

    return problem_response(
        module=module,
        code=code,
        title=title,
        user_message=user_msg,
        hints=hints,
        technical=tech,
        status_code=st,
    )


def problem_validation(
    module: str,
    user_message: str,
    *,
    title: str = "Invalid request",
    hints: list[str] | None = None,
    code: str = "VALIDATION_ERROR",
) -> JSONResponse:
    return problem_response(
        module=module,
        code=code,
        title=title,
        user_message=user_message,
        hints=hints
        or [
            "Fix the highlighted fields and try again.",
            "Cross-check with the SDK Connect tab for the equivalent Python/CLI example.",
        ],
        status_code=400,
    )


def problem_not_found(
    module: str,
    user_message: str,
    *,
    title: str = "Not found",
    hints: list[str] | None = None,
    code: str = "NOT_FOUND",
) -> JSONResponse:
    return problem_response(
        module=module,
        code=code,
        title=title,
        user_message=user_message,
        hints=hints
        or [
            "Check the name or identifier and try again.",
        ],
        status_code=404,
    )


def problem_invalid_json(module: str = MODULE_GENERAL) -> JSONResponse:
    return problem_validation(
        module,
        "The request body is not valid JSON.",
        title="Invalid JSON",
        hints=[
            "Ensure the dashboard is up to date; hard-refresh the page if you upgraded the package.",
            "If you called the API manually, validate the body with jq or a JSON linter.",
        ],
        code="INVALID_JSON",
    )


def enrich_routeros_block(compat: dict[str, Any]) -> JSONResponse:
    """403 when the target is not RouterOS-capable from this environment."""
    msg = (compat.get("action_block_message") or "").strip() or (
        compat.get("compat_message") or "MikroTik RouterOS is required for this action."
    )
    hint = compat.get("compat_hint")
    hints = [
        "Use a MikroTik router with SSH enabled, or run dashboard actions that only need mtk-serve (e.g. Proxy).",
        "Set MTK_ROUTER_HOST and credentials, then run mtk doctor from the same shell as the dashboard.",
    ]
    if hint:
        hints.insert(0, str(hint))
    return problem_response(
        module=MODULE_GENERAL,
        code="ROUTEROS_REQUIRED",
        title="RouterOS feature not available",
        user_message=msg,
        hints=hints,
        status_code=403,
        extra={"unsupported": True, "compat_hint": hint},
    )
