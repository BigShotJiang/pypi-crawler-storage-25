"""
Real-time Testing Dashboard — On-demand live monitoring and control UI.

Provides a full control surface for network simulation, DNS overrides,
proxy rules, and YAML profiles — backed by the same SDK as ``mtk`` CLI.

Usage:
    from mtk_router_sdk.testing.dashboard import TestDashboard

    dashboard = TestDashboard(port=8766)
    dashboard.start()

CLI:
    mtk dashboard start [--port 8766] [--host 127.0.0.1] [--no-auto-serve]

When ``MTK_SERVICE_URL`` (default ``http://127.0.0.1:8765``) points at loopback and
nothing is listening, the dashboard spawns mtk-serve in a subprocess unless
``MTK_DASHBOARD_AUTO_SERVE=0`` or ``--no-auto-serve`` is set.
"""

from __future__ import annotations

import asyncio
import ipaddress
import json
import threading
import time
from contextlib import suppress
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, cast

try:
    import uvicorn
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import HTMLResponse, JSONResponse
    from starlette.routing import Mount, Route, WebSocketRoute
    from starlette.staticfiles import StaticFiles
    from starlette.websockets import WebSocket

    HAS_STARLETTE = True
except ImportError:
    HAS_STARLETTE = False

from mtk_router_sdk.net.host_neighbors import (
    host_peers_as_dashboard_devices,
    scan_host_lan_peers,
)
from mtk_router_sdk.testing.dashboard_embed_serve import ensure_local_mtk_serve
from mtk_router_sdk.testing.dashboard_errors import (
    MODULE_DNS,
    MODULE_GENERAL,
    MODULE_NETWORK,
    MODULE_PROFILES,
    MODULE_PROXY,
    MODULE_RECORDING,
    MODULE_SCENARIOS,
    enrich_routeros_block,
    problem_from_exception,
    problem_invalid_json,
    problem_not_found,
    problem_validation,
)
from mtk_router_sdk.testing.dashboard_workspace import (
    load_and_apply_workspace,
    load_workspace,
    save_workspace,
    validate_workspace_payload,
    workspace_public_status,
)

_DASHBOARD_WEB_DIR = Path(__file__).resolve().parent / "dashboard_web"
_COMPAT_CACHE_TTL_SEC = 25.0

# One MtkTestKit per dashboard process so SSH-backed NetworkSimulator/DNS in-memory
# state matches between apply and list_conditions (and survives page refresh).
_dashboard_kit: Any | None = None
_dashboard_kit_lock = threading.Lock()


def reset_dashboard_kit() -> None:
    """Drop cached kit (e.g. after workspace save loads new Router/mtk-serve env)."""

    global _dashboard_kit
    with _dashboard_kit_lock:
        _dashboard_kit = None


def _client_ip_lab_warning(ip: str) -> str | None:
    """Non-fatal hint when the address is unlikely to be a single test device."""

    s = (ip or "").strip()
    if not s:
        return None
    try:
        a = ipaddress.ip_address(s)
    except ValueError:
        return "That value is not a valid IP address."
    if a.version == 6:
        return None
    if a.is_multicast or a.is_unspecified or a.is_loopback or a.is_link_local:
        return (
            "Multicast, loopback, unspecified, and link-local addresses are usually wrong "
            "for per-device shaping — use the device's LAN IPv4."
        )
    octets = s.split(".")
    if len(octets) == 4 and octets[3] == "255":
        return (
            "x.x.x.255 is often the subnet broadcast address, not a phone or PC. "
            "Use the device's actual Wi‑Fi IP (see DHCP leases on the router)."
        )
    if len(octets) == 4 and octets[3] == "0":
        return (
            "x.x.x.0 is usually the network address, not a client. "
            "Use the device's actual Wi‑Fi IP."
        )
    return None


def _get_cached_compat(dashboard: Any) -> dict[str, Any]:
    """Return RouterOS compatibility probe (cached on dashboard instance)."""

    from mtk_router_sdk.discovery.compatibility import evaluate_ssh_router_from_env

    now = time.monotonic()
    cache = getattr(dashboard, "_compat_cache", None)
    ts = float(getattr(dashboard, "_compat_cache_mono", 0.0))
    if cache is not None and (now - ts) < _COMPAT_CACHE_TTL_SEC:
        return cast(dict[str, Any], cache)
    compat = evaluate_ssh_router_from_env()
    dashboard._compat_cache = compat
    dashboard._compat_cache_mono = now
    return compat


def _load_dashboard_html() -> str:
    """Merge shell ``index.html`` with documentation partial (modular dashboard)."""

    index = _DASHBOARD_WEB_DIR / "index.html"
    docs = _DASHBOARD_WEB_DIR / "partials" / "documentation.html"
    if not index.is_file():
        return "<!DOCTYPE html><html><body>dashboard_web/index.html missing</body></html>"
    template = index.read_text(encoding="utf-8")
    if docs.is_file():
        template = template.replace(
            "    <!-- __DOCS__ -->",
            docs.read_text(encoding="utf-8"),
        )
    return template


def _get_kit() -> Any:
    global _dashboard_kit
    if _dashboard_kit is not None:
        return _dashboard_kit
    from mtk_router_sdk.testing.kit import MtkTestKit

    with _dashboard_kit_lock:
        if _dashboard_kit is None:
            _dashboard_kit = MtkTestKit.from_env()
        return _dashboard_kit


def _dhcp_effective_ipv4(row: dict[str, Any]) -> str | None:
    """Prefer active-address when the lease is bound; else static address."""

    for key in ("active-address", "address"):
        raw = str(row.get(key, "")).strip()
        if not raw:
            continue
        try:
            a = ipaddress.ip_address(raw)
        except ValueError:
            continue
        if a.version != 4:
            continue
        if a.is_multicast or a.is_unspecified or a.is_loopback or a.is_link_local:
            continue
        return str(a)
    return None


def _infer_lan_device_type(hostname: str) -> str:
    """Best-effort category from DHCP host-name (RouterOS rarely sends OS)."""

    h = (hostname or "").strip().lower()
    if not h:
        return "Unknown (no hostname)"
    if any(x in h for x in ("iphone", "ipad", "ipod")):
        return "Apple (iPhone / iPad)"
    if "watch" in h and "apple" in h:
        return "Apple Watch"
    if any(
        x in h
        for x in (
            "android",
            "pixel",
            "galaxy",
            "samsung",
            "xiaomi",
            "redmi",
            "oneplus",
            "oppo",
            "vivo",
            "realme",
            "motorola",
            "nothing",
        )
    ):
        return "Android phone / tablet"
    if any(x in h for x in ("macbook", "imac", "macmini", "mac-")) or h.startswith("mbp"):
        return "Mac"
    if any(x in h for x in ("windows", "desktop-", "win-", "pc-", "laptop-")):
        return "Windows PC"
    if any(x in h for x in ("raspberry", "rpi", "pi-hole")):
        return "Raspberry Pi / SBC"
    if any(x in h for x in ("chromecast", "google-home", "nest")):
        return "Google Cast / Nest"
    if any(x in h for x in ("echo", "alexa", "amazon")):
        return "Amazon Echo / Alexa"
    if any(x in h for x in ("roku", "firetv", "appletv", "apple-tv")):
        return "TV / streaming"
    return "LAN host"


def _merge_arp_neighbors_into(
    client: Any, by_ip: dict[str, dict[str, Any]], *, parse_terse_lines: Any
) -> None:
    """Add IPs from ARP that are not in DHCP (WebFig “devices” often = ARP/bridge)."""

    try:
        r = client.exec_command("/ip arp print terse", timeout=45.0)
    except Exception:
        return
    if not r.ok:
        return
    for row in parse_terse_lines(r.stdout):
        ip = _dhcp_effective_ipv4(row)
        if not ip or ip in by_ip:
            continue
        mac = str(row.get("mac-address", "") or "").strip()
        if not mac:
            continue
        inv = str(row.get("invalid", "")).lower()
        if inv in ("true", "yes", "1"):
            continue
        iface = str(row.get("interface", "") or "").strip()
        by_ip[ip] = {
            "ip": ip,
            "hostname": None,
            "mac_address": mac,
            "status": None,
            "dhcp_server": None,
            "flags": str(row.get("flags", "") or "").strip() or None,
            "device_type": "LAN neighbor (ARP)",
            "origin": "arp",
            "interface": iface or None,
            "_score": 0,
        }


def _lan_device_sort_key(d: dict[str, Any]) -> tuple[int, bytes]:
    origin = d.get("origin", "dhcp")
    st = (d.get("status") or "").lower()
    if origin == "arp":
        return (2, ipaddress.ip_address(str(d["ip"])).packed)
    if st == "bound":
        return (0, ipaddress.ip_address(str(d["ip"])).packed)
    return (1, ipaddress.ip_address(str(d["ip"])).packed)


def _lan_host_fallback_payload(
    debug: dict[str, Any],
    *,
    prelude: str | None = None,
) -> dict[str, Any] | None:
    """OS ARP + ICMP + optional Scapy — used when RouterOS SSH is missing or unusable."""

    scan = scan_host_lan_peers()
    host_devs = host_peers_as_dashboard_devices(scan)
    if not host_devs:
        return None
    parts: list[str] = []
    if prelude:
        parts.append(prelude.strip())
    if scan.hint:
        parts.append(scan.hint.strip())
    parts.append(
        "Host-based LAN discovery (not router DHCP). For more devices: "
        "pip install -e \".[lan-scan]\" and run with privileges Scapy needs; "
        "see docs/ENVIRONMENT.md (MTK_LAN_*)."
    )
    hint_s = " ".join(p for p in parts if p).strip()
    return {
        "devices": host_devs,
        "source": "host_fallback",
        "hint": hint_s,
        "counts": {
            "total": len(host_devs),
            "dhcp": 0,
            "arp_only": 0,
            "host_neighbor": len(host_devs),
        },
        "debug": {**debug, "host_scan_source": scan.scan_source},
    }


def _lan_devices_payload(kit: Any) -> dict[str, Any]:
    """DHCP leases + ARP neighbors over RouterOS SSH (WebFig "connected" often includes ARP)."""

    import os as _os

    debug: dict[str, Any] = {
        "mtk_host": _os.environ.get("MTK_HOST", ""),
        "mtk_user": _os.environ.get("MTK_USER", ""),
        "mtk_password_set": bool(_os.environ.get("MTK_PASSWORD", "").strip()),
        "mtk_service_url": _os.environ.get("MTK_SERVICE_URL", ""),
    }

    net = getattr(kit, "network", None)
    debug["net_exists"] = net is not None
    client = getattr(net, "client", None) if net is not None else None
    debug["client_exists"] = client is not None
    debug["client_connected_before"] = bool(client and client.connected) if client else False

    if client is None:
        debug["failure"] = "client is None"
        fb = _lan_host_fallback_payload(
            debug,
            prelude="No RouterClient (SSH env not usable); using host LAN discovery.",
        )
        if fb is not None:
            return fb
        scan = scan_host_lan_peers()
        return {
            "devices": [],
            "source": "unavailable",
            "hint": (
                "No RouterClient and host LAN scan returned no entries. "
                "Configure Router SSH (Setup) or install '.[lan-scan]' for Scapy; "
                "see docs/ENVIRONMENT.md."
            ),
            "counts": {"total": 0, "dhcp": 0, "arp_only": 0, "host_neighbor": 0},
            "debug": {**debug, "host_scan_source": scan.scan_source, "host_scan_hint": scan.hint},
        }
    from mtk_router_sdk.parsing import parse_terse_lines

    ensurer = getattr(net, "_ensure_ssh_connected", None)
    debug["ensurer_exists"] = callable(ensurer)
    if callable(ensurer):
        try:
            ensurer()
            debug["ensurer_ok"] = True
            debug["client_connected_after"] = client.connected
        except Exception as e:
            debug["ensurer_ok"] = False
            debug["ensurer_error"] = str(e)[:500]
            msg = str(e).strip() or type(e).__name__
            if msg.lower() in ("not connected.", "not connected"):
                msg = (
                    "SSH session is not open yet - this is normal before the first router "
                    "command. Click Refresh devices again or use Apply profile once."
                )
            fb = _lan_host_fallback_payload(debug, prelude=f"Router SSH: {msg}")
            if fb is not None:
                return fb
            return {
                "devices": [],
                "source": "error",
                "hint": msg,
                "counts": {"total": 0, "dhcp": 0, "arp_only": 0},
                "debug": debug,
            }

    dhcp_ok = True
    dhcp_err = ""
    dhcp_raw = ""
    rows: list[dict[str, Any]] = []
    try:
        r = client.exec_command("/ip dhcp-server lease print terse", timeout=45.0)
        debug["dhcp_exit_status"] = r.exit_status
        dhcp_raw = (r.stdout or "")[:2000]
        debug["dhcp_stdout_len"] = len(r.stdout or "")
        debug["dhcp_stderr"] = (r.stderr or "")[:300]
        if not r.ok:
            dhcp_ok = False
            dhcp_err = (r.stderr or r.stdout or "lease print failed").strip()[:500]
        else:
            rows = parse_terse_lines(r.stdout)
            debug["dhcp_rows_parsed"] = len(rows)
    except Exception as e:
        dhcp_ok = False
        raw = str(e).strip() or type(e).__name__
        dhcp_err = raw
        debug["dhcp_exception"] = raw[:500]
        if raw.lower().rstrip(".") == "not connected":
            dhcp_err = (
                "SSH transport was not connected - retry Refresh devices; the dashboard "
                "opens a session automatically before this query."
            )

    debug["dhcp_ok"] = dhcp_ok
    debug["dhcp_raw_preview"] = dhcp_raw[:400] if dhcp_raw else ""

    by_ip: dict[str, dict[str, Any]] = {}
    for row in rows:
        ip = _dhcp_effective_ipv4(row)
        if not ip:
            continue
        host = str(row.get("host-name", "") or "").strip()
        mac = str(
            row.get("active-mac-address", "") or row.get("mac-address", "") or ""
        ).strip()
        status = str(row.get("status", "") or "").strip()
        flags = str(row.get("flags", "") or "").strip()
        server = str(row.get("server", "") or "").strip()
        dev_type = _infer_lan_device_type(host)
        score = 0
        if status.lower() == "bound":
            score += 10
        if str(row.get("active-address", "")).strip():
            score += 5
        prev = by_ip.get(ip)
        if prev is None or score > int(prev.get("_score", 0)):
            by_ip[ip] = {
                "ip": ip,
                "hostname": host or None,
                "mac_address": mac or None,
                "status": status or None,
                "dhcp_server": server or None,
                "flags": flags or None,
                "device_type": dev_type,
                "origin": "dhcp",
                "_score": score,
            }

    _merge_arp_neighbors_into(client, by_ip, parse_terse_lines=parse_terse_lines)

    devices_sorted = sorted(by_ip.values(), key=_lan_device_sort_key)
    dhcp_n = sum(1 for d in devices_sorted if d.get("origin", "dhcp") == "dhcp")
    arp_n = sum(1 for d in devices_sorted if d.get("origin") == "arp")
    out: list[dict[str, Any]] = []
    for d in devices_sorted:
        d.pop("_score", None)
        origin = d.get("origin", "dhcp")
        if origin == "arp":
            iface = d.get("interface") or ""
            d["label"] = f"{d['ip']} — {iface or 'LAN'} · {d['device_type']}"
        else:
            hn = d["hostname"] or "—"
            d["label"] = f"{d['ip']} — {hn} · {d['device_type']}"
        out.append(d)

    src = "mixed"
    if dhcp_n == 0 and arp_n == 0:
        src = "empty"
    elif arp_n == 0:
        src = "dhcp"
    elif dhcp_n == 0:
        src = "arp"

    hint: str | None = None
    if not out:
        if not dhcp_ok:
            base = (dhcp_err or "DHCP lease query failed.").strip()
            hint = (
                f"{base} No ARP neighbors were returned either — check SSH permissions "
                f"(`/ip dhcp-server lease print`, `/ip arp print`)."
            )
        else:
            hint = (
                "No DHCP leases and no usable ARP rows. If WebFig shows clients, they may use "
                "another router for DHCP or ARP may be incomplete — try LAN traffic, then Refresh."
            )
    elif not dhcp_ok:
        hint = f"DHCP list unavailable ({dhcp_err}). Showing ARP neighbors only."

    if not out:
        prelude: str | None = None
        if isinstance(hint, str) and hint.strip():
            prelude = hint.strip()
        fb = _lan_host_fallback_payload(debug, prelude=prelude)
        if fb is not None:
            return fb

    return {
        "devices": out,
        "source": src,
        "hint": hint,
        "counts": {"total": len(out), "dhcp": dhcp_n, "arp_only": arp_n},
        "debug": debug,
    }


def _plain_network_rows(conditions: list[Any], *, limit: int = 32) -> list[dict[str, Any]]:
    """Serialize active conditions for dashboard / WebSocket (no derived UI metadata)."""

    out: list[dict[str, Any]] = []
    for c in conditions[:limit]:
        out.append(
            {
                "client_ip": c.client_ip,
                "active": c.active,
                "profile": c.profile,
                "download_kbps": c.download_kbps,
                "upload_kbps": c.upload_kbps,
                "latency_ms": c.latency_ms,
                "jitter_ms": getattr(c, "jitter_ms", None),
                "packet_loss_percent": c.packet_loss_percent,
            }
        )
    return out


def _mtk_serve_port_hint() -> int:
    """TCP port mtk-serve is expected on (from MTK_SERVICE_URL or MTK_HTTP_PORT)."""

    import os
    from urllib.parse import urlparse

    from mtk_router_sdk.config.env_parse import parse_int_env

    raw = (os.environ.get("MTK_SERVICE_URL") or "").strip()
    if raw:
        u = urlparse(raw)
        try:
            p = u.port
        except ValueError:
            p = None
        if p is not None and 1 <= p <= 65535:
            return p
    return parse_int_env("MTK_HTTP_PORT", 8765, minimum=1, maximum=65535)


def _build_tick(kit: Any) -> dict[str, Any]:
    """Payload pushed over WebSocket on each poll.

    Never raises: mtk-serve may be down; network/DNS may be misconfigured.
    """
    net: list[Any] = []
    net_detail: list[dict[str, Any]] = []
    dns: list[Any] = []
    with suppress(Exception):
        net = kit.network.list_conditions()
        net_detail = _plain_network_rows(net)
    with suppress(Exception):
        dns = kit.dns.list_redirects()

    rules: list[Any] = []
    logs: list[Any] = []
    total = 0
    log_dicts: list[dict[str, Any]] = []
    proxy_ok = True
    proxy_error: str | None = None
    try:
        rules = kit.proxy.list_rules()
        logs = kit.proxy.get_log(limit=25)
        for e in reversed(logs):
            d = e.to_dict()
            rb = d.get("response_body")
            if rb is not None and len(str(rb)) > 240:
                d["response_body"] = "[truncated]"
            log_dicts.append(d)
        total = len(logs)
        with suppress(Exception):
            st = kit.proxy.log_stats()
            total = int(st.get("total_entries", st.get("total", total)))
    except Exception as e:
        proxy_ok = False
        proxy_error = str(e)

    return {
        "type": "tick",
        "network_clients": len(net),
        "network_conditions": net_detail,
        "dns_redirects": len(dns),
        "proxy_rules": len(rules),
        "proxy_log_total": total,
        "logs": log_dicts,
        "proxy_ok": proxy_ok,
        "proxy_error": proxy_error,
    }


@dataclass
class DashboardClient:
    """Connected WebSocket client."""

    websocket: Any
    connected_at: datetime = field(default_factory=datetime.now)
    client_filter: str | None = None


@dataclass
class TestDashboard:
    """
    On-demand real-time testing dashboard with full SDK integration.

    Features:
    - Health: Router SSH + mtk-serve proxy reachability
    - Network: apply presets/custom conditions, disconnect, list & clear
    - DNS: list/add/remove redirects, flush cache
    - Proxy: create/list/delete rules (override, error, delay), tail logs
    - Profiles: list, apply, clear, export YAML test profiles
    - Scenarios: list and run pre-built test scenarios
    - Recording: start/stop traffic recording, replay sessions
    - WebSocket: periodic tick with stats + recent proxy log lines
    - Export: JSON snapshot download
    - Documentation: Interactive docs with animated diagrams and code snippets
    """

    port: int = 8766
    host: str = "127.0.0.1"
    poll_interval_sec: float = 3.0
    _server_thread: threading.Thread | None = field(default=None, repr=False)
    _stop_event: threading.Event = field(default_factory=threading.Event, repr=False)
    # List (not set/WeakSet): DashboardClient is a mutable dataclass → unhashable in Python.
    _clients: list[DashboardClient] = field(default_factory=list, repr=False)
    _app: Any = field(default=None, repr=False)
    _running: bool = False
    _poll_task: asyncio.Task[None] | None = field(default=None, repr=False)
    _compat_cache: dict[str, Any] | None = field(default=None, repr=False)
    _compat_cache_mono: float = field(default=0.0, repr=False)
    _embedded_serve_proc: Any = field(default=None, repr=False)

    def start(self, blocking: bool = False) -> None:
        if not HAS_STARLETTE:
            raise ImportError(
                "Dashboard requires starlette and uvicorn. "
                "Install with: pip install starlette uvicorn"
            )
        if self._running:
            return

        load_and_apply_workspace()
        self._embedded_serve_proc = ensure_local_mtk_serve()

        self._stop_event.clear()
        self._app = self._create_app()

        if blocking:
            self._run_server()
        else:
            self._server_thread = threading.Thread(
                target=self._run_server,
                daemon=True,
            )
            self._server_thread.start()
            time.sleep(0.5)

        self._running = True

    def stop(self) -> None:
        self._stop_event.set()
        self._running = False
        proc = self._embedded_serve_proc
        if proc is not None:
            self._embedded_serve_proc = None
            print("[dashboard] stopping embedded mtk-serve...")
            with suppress(Exception):
                if proc.poll() is None:
                    proc.terminate()
            with suppress(Exception):
                proc.wait(timeout=3)
            with suppress(Exception):
                if proc.poll() is None:
                    proc.kill()

    def is_running(self) -> bool:
        return self._running

    def get_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    async def broadcast(self, message: dict[str, Any]) -> None:
        data = json.dumps(message, default=str)
        for client in list(self._clients):
            try:
                await client.websocket.send_text(data)
            except Exception:
                with suppress(ValueError):
                    self._clients.remove(client)

    def _run_server(self) -> None:
        config = uvicorn.Config(
            self._app,
            host=self.host,
            port=self.port,
            log_level="warning",
        )
        server = uvicorn.Server(config)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        async def serve() -> None:
            await server.serve()

        try:
            loop.run_until_complete(serve())
        except Exception:
            pass
        finally:
            loop.close()

    def _create_app(self) -> Any:
        dashboard = self
        html_page = _load_dashboard_html()

        async def index(_request: Request) -> HTMLResponse:
            return HTMLResponse(html_page)

        async def api_config(_request: Request) -> JSONResponse:
            return JSONResponse({"poll_interval_sec": dashboard.poll_interval_sec})

        async def api_health(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            router_ssh = bool(compat.get("routeros_supported"))
            mtk_proxy = False
            detail: dict[str, str] = {}
            try:
                kit = _get_kit()
                kit.proxy.status()
                mtk_proxy = True
            except Exception as e:
                detail["proxy"] = str(e)
            port_hint = _mtk_serve_port_hint()
            return JSONResponse(
                {
                    "router_ssh": router_ssh,
                    "routeros_supported": bool(compat.get("routeros_supported")),
                    "ssh_connected": bool(compat.get("ssh_connected")),
                    "ssh_configured": bool(compat.get("ssh_configured")),
                    "compat_message": compat.get("compat_message") or "",
                    "compat_hint": compat.get("compat_hint"),
                    "mtk_serve_proxy": mtk_proxy,
                    # Alias + port for Settings / older UI clients
                    "mtk_serve_running": mtk_proxy,
                    "mtk_serve_port": port_hint,
                    "detail": detail,
                }
            )

        async def api_overview(_request: Request) -> JSONResponse:
            kit = _get_kit()
            tick = _build_tick(kit)
            return JSONResponse(
                {
                    "network_clients": tick["network_clients"],
                    "dns_redirects": tick["dns_redirects"],
                    "proxy_rules": tick["proxy_rules"],
                    "proxy_log_total": tick["proxy_log_total"],
                    "proxy_ok": tick.get("proxy_ok", True),
                    "proxy_error": tick.get("proxy_error"),
                }
            )

        async def api_export(_request: Request) -> JSONResponse:
            kit = _get_kit()
            tick = _build_tick(kit)
            try:
                net = [asdict(c) for c in kit.network.list_conditions()]
            except Exception:
                net = []
            try:
                dns = [
                    {
                        "domain": r.domain,
                        "target_ip": r.target_ip,
                        "client_ip": r.client_ip,
                        "ttl": r.ttl,
                    }
                    for r in kit.dns.list_redirects()
                ]
            except Exception:
                dns = []
            try:
                rules = [r.to_dict() for r in kit.proxy.list_rules()]
            except Exception:
                rules = []
            try:
                profs = kit.profiles.list_profiles()
            except Exception:
                profs = []
            return JSONResponse(
                {
                    "exported_at": datetime.utcnow().isoformat() + "Z",
                    "summary": tick,
                    "network_conditions": net,
                    "dns_redirects": dns,
                    "proxy_rules": rules,
                    "profile_names": profs,
                }
            )

        async def api_network_profiles(_request: Request) -> JSONResponse:
            from mtk_router_sdk.testing.network import NETWORK_PROFILES

            profiles = [
                {"name": k, **{x: v[x] for x in v}}
                for k, v in NETWORK_PROFILES.items()
            ]
            return JSONResponse({"profiles": profiles})

        async def api_network_lan_devices(_request: Request) -> JSONResponse:
            """DHCP leases for the Network tab device picker (always 200 if JSON succeeds)."""

            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return JSONResponse(
                    {
                        "devices": [],
                        "source": "unavailable",
                        "hint": str(compat.get("compat_message") or "").strip()
                        or "Configure Router SSH (e.g. Setup) to list DHCP clients.",
                        "counts": {"total": 0, "dhcp": 0, "arp_only": 0},
                    }
                )
            kit = _get_kit()
            payload = _lan_devices_payload(kit)
            return JSONResponse(payload)

        async def api_network_conditions(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            kit = _get_kit()
            try:
                conditions = kit.network.list_conditions()
            except Exception as e:
                return problem_from_exception(MODULE_NETWORK, e, status_code=503)
            return JSONResponse({"conditions": _plain_network_rows(conditions)})

        async def api_network_apply(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_NETWORK)
            client_ip = body.get("client_ip")
            if not client_ip:
                return problem_validation(
                    MODULE_NETWORK,
                    "client_ip is required (the test device IPv4 on your LAN).",
                    hints=[
                        "Enter the phone/laptop IP shown in DHCP leases or the Network tab device list.",
                        "Example: 192.168.88.234 — then choose a preset or custom limits.",
                    ],
                )
            kit = _get_kit()
            warn = _client_ip_lab_warning(str(client_ip))
            try:
                if body.get("profile"):
                    kit.network.apply_profile(client_ip, body["profile"])
                else:
                    if body.get("download_kbps") is not None or body.get(
                        "upload_kbps"
                    ) is not None:
                        kit.network.throttle(
                            client_ip,
                            body.get("download_kbps"),
                            body.get("upload_kbps"),
                        )
                    if body.get("latency_ms") is not None:
                        kit.network.latency(
                            client_ip,
                            int(body["latency_ms"]),
                            int(body.get("jitter_ms") or 0),
                        )
                    if body.get("packet_loss_percent") is not None:
                        kit.network.packet_loss(
                            client_ip, float(body["packet_loss_percent"])
                        )
                payload: dict[str, Any] = {"success": True}
                if warn:
                    payload["warning"] = warn
                return JSONResponse(payload)
            except Exception as e:
                return problem_from_exception(MODULE_NETWORK, e)

        async def api_network_clear(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            client_ip = request.query_params.get("client_ip")
            kit = _get_kit()
            try:
                if client_ip:
                    kit.network.clear(client_ip)
                else:
                    kit.network.clear_all()
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_NETWORK, e)

        async def api_network_live_stats(request: Request) -> JSONResponse:
            """Get real-time queue and firewall stats for a client from the router."""
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return JSONResponse({
                    "available": False,
                    "reason": "Router SSH not configured",
                })
            client_ip = request.query_params.get("client_ip")
            if not client_ip:
                return problem_validation(
                    MODULE_NETWORK,
                    "client_ip query parameter is required.",
                )
            kit = _get_kit()
            try:
                stats = kit.network.get_live_stats(client_ip)
                return JSONResponse(stats)
            except Exception as e:
                return JSONResponse({
                    "available": False,
                    "error": str(e)[:300],
                })

        async def api_network_debug_firewall(request: Request) -> JSONResponse:
            """Debug: show all firewall filter rules on the router."""
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return JSONResponse({"error": "Router SSH not configured"})
            kit = _get_kit()
            try:
                kit.network._ensure_ssh_connected()
                # Get all forward chain rules
                r = kit.network.client.exec_command(
                    "/ip firewall filter print where chain=forward",
                    timeout=10.0,
                )
                rules_raw = r.stdout if r.ok else f"Error: {r.stderr}"
                # Also get our specific mtk rules
                r2 = kit.network.client.exec_command(
                    '/ip firewall filter print where comment~"mtk_"',
                    timeout=10.0,
                )
                mtk_rules = r2.stdout if r2.ok else f"Error: {r2.stderr}"
                return JSONResponse({
                    "forward_chain": rules_raw[:2000],
                    "mtk_rules": mtk_rules[:1500],
                    "hint": "If mtk_loss rules exist but are not at index 0/1, traffic may bypass them",
                })
            except Exception as e:
                return JSONResponse({"error": str(e)[:300]})

        async def api_dns_redirects(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            kit = _get_kit()
            try:
                redirects = kit.dns.list_redirects()
            except Exception as e:
                return problem_from_exception(MODULE_DNS, e, status_code=503)
            return JSONResponse(
                {
                    "redirects": [
                        {
                            "domain": r.domain,
                            "target_ip": r.target_ip,
                            "client_ip": r.client_ip,
                            "ttl": r.ttl,
                            "active": r.active,
                        }
                        for r in redirects
                    ]
                }
            )

        async def api_dns_redirect_post(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_DNS)
            domain = body.get("domain")
            if not domain:
                return problem_validation(
                    MODULE_DNS,
                    "domain is required (hostname to override, e.g. api.example.com).",
                    hints=[
                        "Use the exact hostname your app resolves — no scheme or path.",
                        "Choose “Via proxy” or enter a target IPv4 for redirect_to_ip.",
                    ],
                )
            kit = _get_kit()
            ttl = int(body.get("ttl") or 60)
            client_ip = body.get("client_ip") or None
            try:
                if body.get("to_proxy"):
                    kit.dns.redirect(domain, client_ip, ttl)
                elif body.get("target_ip"):
                    kit.dns.redirect_to_ip(
                        domain, body["target_ip"], client_ip, ttl
                    )
                else:
                    return problem_validation(
                        MODULE_DNS,
                        "Either enable “Via proxy” or provide a target IPv4.",
                        hints=[
                            "Via proxy sends the name to mtk-serve; target IP sends traffic to a fixed address.",
                        ],
                    )
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_DNS, e)

        async def api_dns_redirect_delete(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            domain = request.query_params.get("domain")
            client_ip = request.query_params.get("client_ip")
            kit = _get_kit()
            try:
                if domain:
                    kit.dns.remove(domain, client_ip or None)
                elif client_ip:
                    kit.dns.clear(client_ip)
                else:
                    kit.dns.clear_all()
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_DNS, e)

        async def api_proxy_rules(request: Request) -> JSONResponse:
            client_ip = request.query_params.get("client_ip")
            kit = _get_kit()
            try:
                rules = kit.proxy.list_rules(client_ip=client_ip)
                return JSONResponse(
                    {"rules": [r.to_dict() for r in rules]}
                )
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e, status_code=503)

        async def api_proxy_logs(request: Request) -> JSONResponse:
            client_ip = request.query_params.get("client_ip")
            client_ips_raw = (request.query_params.get("client_ips") or "").strip()
            limit = int(request.query_params.get("limit") or "50")
            kit = _get_kit()
            try:
                if client_ips_raw:
                    ips = [p.strip() for p in client_ips_raw.split(",") if p.strip()]
                    entries = kit.proxy.get_log(client_ips=ips, limit=limit)
                else:
                    entries = kit.proxy.get_log(client_ip=client_ip, limit=limit)
                out = []
                for e in entries:
                    d = e.to_dict()
                    if d.get("response_body") is not None and len(
                        str(d["response_body"])
                    ) > 400:
                        d["response_body"] = "[truncated]"
                    out.append(d)
                return JSONResponse({"entries": out})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e, status_code=503)

        async def api_proxy_clear(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_PROXY)
            client_ip = body.get("client_ip")
            if not client_ip:
                return problem_validation(
                    MODULE_PROXY,
                    "client_ip is required to clear rules for one device.",
                    hints=[
                        "mtk-serve stores rules per client IPv4 — use the same IP as in your proxy rules.",
                    ],
                )
            kit = _get_kit()
            try:
                n = kit.proxy.clear_client(client_ip)
                return JSONResponse({"success": True, "deleted_count": n})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_proxy_rules_delete(_request: Request) -> JSONResponse:
            kit = _get_kit()
            try:
                n = kit.proxy.clear_all()
                return JSONResponse({"success": True, "deleted_count": n})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_profiles_list(_request: Request) -> JSONResponse:
            kit = _get_kit()
            try:
                names = kit.profiles.list_profiles()
            except Exception:
                names = []
            return JSONResponse({"profiles": names})

        async def api_profiles_apply(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_PROFILES)
            name = body.get("name")
            client_ip = body.get("client_ip")
            if not name or not client_ip:
                return problem_validation(
                    MODULE_PROFILES,
                    "Both profile name and client_ip are required.",
                    hints=[
                        "Pick a YAML profile from the list, then enter the device IPv4 to apply it to.",
                        "Equivalent: kit.profiles.apply(name, client_ip=...).",
                    ],
                )
            kit = _get_kit()
            try:
                kit.profiles.apply(name, client_ip=client_ip)
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_PROFILES, e)

        async def api_profiles_clear(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_PROFILES)
            client_ip = body.get("client_ip")
            if not client_ip:
                return problem_validation(
                    MODULE_PROFILES,
                    "client_ip is required to clear profile state for that device.",
                )
            kit = _get_kit()
            try:
                kit.profiles.clear(client_ip)
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_PROFILES, e)

        async def api_profiles_export(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            kit = _get_kit()
            try:
                export = kit.profiles.export()
                return JSONResponse({"profile": export})
            except Exception as e:
                return problem_from_exception(MODULE_PROFILES, e)

        async def api_network_disconnect(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_NETWORK)
            client_ip = body.get("client_ip")
            duration = body.get("duration_seconds", 10)
            if not client_ip:
                return problem_validation(
                    MODULE_NETWORK,
                    "client_ip is required for a timed disconnect.",
                )
            kit = _get_kit()
            warn = _client_ip_lab_warning(str(client_ip))
            try:
                kit.network.disconnect(client_ip, duration_seconds=int(duration))
                payload: dict[str, Any] = {
                    "success": True,
                    "duration_seconds": duration,
                }
                if warn:
                    payload["warning"] = warn
                return JSONResponse(payload)
            except Exception as e:
                return problem_from_exception(MODULE_NETWORK, e)

        async def api_dns_flush(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            kit = _get_kit()
            try:
                kit.dns.flush_cache()
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_DNS, e)

        async def api_proxy_rule_create(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_PROXY)
            path = body.get("path")
            if not path:
                return problem_validation(
                    MODULE_PROXY,
                    "path is required (URL path pattern, e.g. /api/v1/*).",
                    hints=[
                        "Patterns are matched per request path — use wildcards as supported by mtk-serve.",
                    ],
                )
            kit = _get_kit()
            raw_ip = body.get("client_ip")
            if raw_ip is None or str(raw_ip).strip() in ("", "*"):
                return problem_validation(
                    MODULE_PROXY,
                    "client_ip is required: mtk-serve rules are scoped to the test device IPv4.",
                    hints=[
                        "Enter the same IP the phone or emulator uses on your LAN.",
                        "Traffic must flow through mtk-serve’s proxy port for rules to apply.",
                    ],
                )
            client_ip = str(raw_ip).strip()
            action = body.get("action", "override")
            try:
                if action == "error":
                    err_msg = body.get("body", {}).get("error", "Error")
                    kit.proxy.set_error(
                        client_ip,
                        path,
                        status=int(body.get("status", 500)),
                        response=err_msg,
                    )
                elif action == "delay":
                    kit.proxy.set_delay(
                        client_ip,
                        path,
                        int(body.get("delay_ms", 2000)),
                    )
                else:
                    kit.proxy.set_response(
                        client_ip,
                        path,
                        body.get("body", {}),
                        status=int(body.get("status", 200)),
                    )
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_proxy_rule_delete(request: Request) -> JSONResponse:
            rule_id = request.path_params.get("rule_id")
            if not rule_id:
                return problem_validation(MODULE_PROXY, "rule_id is missing from the URL.")
            kit = _get_kit()
            try:
                kit.proxy.delete_rule(rule_id)
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_proxy_logs_clear(_request: Request) -> JSONResponse:
            kit = _get_kit()
            try:
                kit.proxy.clear_log()
                return JSONResponse({"success": True})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_proxy_certs_status(_request: Request) -> JSONResponse:
            kit = _get_kit()
            try:
                st = kit.proxy.certs_status()
                return JSONResponse({"success": True, **st})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e, status_code=503)

        async def api_proxy_certs_import(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_PROXY)
            proxy_cn = str(body.get("proxy_cn") or "MTK Proxy").strip() or "MTK Proxy"
            try:
                vd = int(body.get("validity_days", 3650))
            except (TypeError, ValueError):
                vd = 3650
            p12_b64 = (body.get("pkcs12_base64") or body.get("p12_base64") or "").strip()
            p12_pw = body.get("p12_password")
            if p12_pw is not None and not isinstance(p12_pw, str):
                p12_pw = str(p12_pw)
            kit = _get_kit()
            try:
                if p12_b64:
                    out = kit.proxy.import_ca_pkcs12_base64(
                        p12_b64,
                        password=p12_pw,
                        proxy_cn=proxy_cn,
                        validity_days=vd,
                    )
                else:
                    ca_crt = (body.get("ca_crt_pem") or body.get("ca_cert_pem") or "").strip()
                    ca_key = (body.get("ca_key_pem") or "").strip()
                    if not ca_crt or not ca_key:
                        return problem_validation(
                            MODULE_PROXY,
                            "Upload a .p12 / PKCS#12 (base64) with optional password, or paste ca_crt_pem + ca_key_pem.",
                            hints=[
                                "Charles-style root-ca.p12: choose the file and enter its password if any.",
                                "Install the matching CA on test devices to trust MITM.",
                            ],
                        )
                    out = kit.proxy.import_ca_pem(
                        ca_crt,
                        ca_key,
                        proxy_cn=proxy_cn,
                        validity_days=vd,
                    )
                return JSONResponse({"success": True, **out})
            except Exception as e:
                return problem_from_exception(MODULE_PROXY, e)

        async def api_scenarios_list(_request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            kit = _get_kit()
            try:
                scenarios = kit.scenarios.list_scenarios()
                out: list[dict[str, str]] = []
                for s in scenarios:
                    if hasattr(s, "name"):
                        out.append(
                            {
                                "name": s.name,
                                "description": str(getattr(s, "description", "") or ""),
                            }
                        )
                    else:
                        out.append({"name": str(s), "description": ""})
                return JSONResponse({"scenarios": out})
            except Exception as e:
                return problem_from_exception(MODULE_SCENARIOS, e, status_code=503)

        async def api_scenarios_run(request: Request) -> JSONResponse:
            compat = _get_cached_compat(dashboard)
            if not compat.get("routeros_supported"):
                return enrich_routeros_block(compat)
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_SCENARIOS)
            name = body.get("name")
            client_ip = body.get("client_ip")
            if not name or not client_ip:
                return problem_validation(
                    MODULE_SCENARIOS,
                    "scenario name and client_ip are required.",
                    hints=[
                        "Choose a scenario from the list; client_ip is the device the YAML steps apply to.",
                    ],
                )
            kit = _get_kit()
            try:
                result = kit.scenarios.run(name, client_ip=client_ip)
                steps = []
                if hasattr(result, "steps"):
                    steps = [
                        {"action": s.action, "status": getattr(s, "status", "ok")}
                        for s in result.steps
                    ]
                return JSONResponse({"success": True, "steps": steps})
            except Exception as e:
                return problem_from_exception(MODULE_SCENARIOS, e)

        async def api_recording_start(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_RECORDING)
            client_ip = body.get("client_ip")
            name = body.get("name", f"session-{int(time.time())}")
            if not client_ip:
                return problem_validation(
                    MODULE_RECORDING,
                    "client_ip is required to tag captured traffic.",
                    hints=[
                        "Use the device IP that sends HTTP through mtk-serve so recordings attach to the right client.",
                    ],
                )
            kit = _get_kit()
            try:
                session_id = kit.recorder.start(client_ip=client_ip, name=name)
                return JSONResponse({"success": True, "session_id": session_id})
            except Exception as e:
                return problem_from_exception(MODULE_RECORDING, e)

        async def api_recording_stop(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_RECORDING)
            client_ip = body.get("client_ip")
            if not client_ip:
                return problem_validation(
                    MODULE_RECORDING,
                    "client_ip is required to stop the active recording for that device.",
                )
            kit = _get_kit()
            try:
                har_file = kit.recorder.stop_for_client(client_ip)
                return JSONResponse({"success": True, "har_file": str(har_file)})
            except Exception as e:
                return problem_from_exception(MODULE_RECORDING, e)

        async def api_recording_list(_request: Request) -> JSONResponse:
            kit = _get_kit()
            try:
                recordings = kit.recorder.list_recordings()
                out = []
                for r in recordings:
                    if isinstance(r, dict):
                        out.append(r)
                    elif hasattr(r, "name"):
                        out.append({
                            "name": r.name,
                            "entries": getattr(r, "entries", None),
                            "created": getattr(r, "created", None),
                        })
                    else:
                        out.append({"name": str(r)})
                return JSONResponse({"recordings": out})
            except Exception as e:
                return problem_from_exception(MODULE_RECORDING, e, status_code=503)

        async def api_recording_replay(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json(MODULE_RECORDING)
            name = body.get("name")
            client_ip = body.get("client_ip")
            if not name or not client_ip:
                return problem_validation(
                    MODULE_RECORDING,
                    "Recording name and client_ip are required for replay.",
                    hints=[
                        "Pick a session from the list; client_ip is where synthetic rules will be installed.",
                    ],
                )
            kit = _get_kit()
            try:
                rules = kit.recorder.replay(client_ip=client_ip, har_path=name)
                return JSONResponse({"success": True, "rules_created": rules})
            except Exception as e:
                return problem_from_exception(MODULE_RECORDING, e)

        async def api_recording_delete(request: Request) -> JSONResponse:
            name = request.query_params.get("name", "").strip()
            if not name:
                return problem_validation(
                    MODULE_RECORDING,
                    "Recording name is required.",
                    hints=["Pass ?name=session-name to delete a recording."],
                )
            kit = _get_kit()
            try:
                deleted = kit.recorder.delete_recording(name)
                if deleted:
                    return JSONResponse({"success": True, "deleted": name})
                return problem_not_found(
                    MODULE_RECORDING,
                    f"Recording '{name}' not found.",
                )
            except Exception as e:
                return problem_from_exception(MODULE_RECORDING, e)

        async def api_setup_status(_request: Request) -> JSONResponse:
            return JSONResponse(workspace_public_status(load_workspace()))

        async def api_setup_workspace_get(_request: Request) -> JSONResponse:
            return JSONResponse(load_workspace())

        async def api_setup_env_ui_get(_request: Request) -> JSONResponse:
            from mtk_router_sdk.testing.dashboard_env_ui import build_env_ui_state_payload

            return JSONResponse(build_env_ui_state_payload())

        async def api_setup_env_ui_post(request: Request) -> JSONResponse:
            from mtk_router_sdk.testing.dashboard_env_ui import (
                build_env_ui_state_payload,
                normalize_env_ui_dict,
            )

            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json()
            raw = body.get("env_ui")
            if not isinstance(raw, dict):
                return problem_validation(MODULE_GENERAL, "Body must include env_ui object")
            norm, nerr = normalize_env_ui_dict(raw)
            if nerr:
                return problem_validation(MODULE_GENERAL, nerr)
            base = load_workspace()
            base["env_ui"] = norm
            base["version"] = 1
            save_workspace(base)
            load_and_apply_workspace()
            reset_dashboard_kit()
            dashboard._compat_cache = None
            dashboard._compat_cache_mono = 0.0
            return JSONResponse({"success": True, **build_env_ui_state_payload()})

        async def api_setup_workspace_post(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                return problem_invalid_json()
            err = validate_workspace_payload(body)
            if err:
                return problem_validation(MODULE_GENERAL, err)
            base = load_workspace()
            if "onboarding_done" in body:
                base["onboarding_done"] = bool(body["onboarding_done"])
            if "active_profile_id" in body:
                base["active_profile_id"] = body.get("active_profile_id")
            if "profiles" in body:
                base["profiles"] = body["profiles"]
            if "env_ui" in body:
                from mtk_router_sdk.testing.dashboard_env_ui import normalize_env_ui_dict

                norm, nerr = normalize_env_ui_dict(body["env_ui"])
                if nerr:
                    return problem_validation(MODULE_GENERAL, nerr)
                base["env_ui"] = norm
            base["version"] = 1
            save_workspace(base)
            load_and_apply_workspace()
            reset_dashboard_kit()
            dashboard._compat_cache = None
            dashboard._compat_cache_mono = 0.0
            return JSONResponse(
                {
                    "success": True,
                    "status": workspace_public_status(load_workspace()),
                }
            )

        async def api_setup_suggest_router(_request: Request) -> JSONResponse:
            """Best-effort router IP from LAN gateway + MikroTik heuristics (TCP 22 probe)."""

            try:
                from mtk_router_sdk.net.gateway import get_default_ipv4_gateway
                from mtk_router_sdk.net.ssh_host import (
                    collect_router_ssh_candidates,
                    pick_reachable_ssh_host,
                    tcp_port_open,
                )

                gw = get_default_ipv4_gateway()
                candidates = collect_router_ssh_candidates()[:14]
                suggested = pick_reachable_ssh_host(
                    candidates, port=22, timeout_per_host=0.85
                )
                open_ok = tcp_port_open(suggested, port=22, timeout=1.0)
                return JSONResponse(
                    {
                        "suggested": suggested,
                        "candidates": candidates,
                        "default_gateway": gw or "",
                        "ssh_port_open": open_ok,
                        "hint": (
                            "Port 22 is open on this address — likely your router."
                            if open_ok
                            else "Port 22 not confirmed; try this address or edit manually."
                        ),
                    }
                )
            except Exception as e:
                return JSONResponse(
                    {
                        "suggested": "192.168.88.1",
                        "candidates": ["192.168.88.1"],
                        "default_gateway": "",
                        "ssh_port_open": False,
                        "hint": f"Fallback to MikroTik default LAN. ({e})",
                    }
                )

        async def websocket_handler(websocket: WebSocket) -> None:
            await websocket.accept()
            client = DashboardClient(websocket=websocket)
            dashboard._clients.append(client)
            try:
                while not dashboard._stop_event.is_set():
                    try:
                        raw = await asyncio.wait_for(
                            websocket.receive_text(),
                            timeout=1.0,
                        )
                        msg = json.loads(raw)
                        if msg.get("type") == "subscribe":
                            client.client_filter = msg.get("client_ip") or None
                    except asyncio.TimeoutError:
                        continue
                    except Exception:
                        break
            finally:
                with suppress(ValueError):
                    dashboard._clients.remove(client)

        from contextlib import asynccontextmanager

        @asynccontextmanager
        async def lifespan(_app: Any) -> Any:
            load_and_apply_workspace()
            task = asyncio.create_task(_async_poll_loop(dashboard))
            dashboard._poll_task = task
            yield
            dashboard._stop_event.set()
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task
            dashboard._poll_task = None

        routes = [
            Route("/", index),
            Mount(
                "/assets",
                StaticFiles(directory=str(_DASHBOARD_WEB_DIR)),
                name="dashboard_assets",
            ),
            Route("/api/config", api_config),
            Route("/api/health", api_health),
            Route("/api/overview", api_overview),
            Route("/api/export", api_export),
            Route("/api/network/profiles", api_network_profiles),
            Route("/api/network/lan-devices", api_network_lan_devices),
            Route("/api/network/conditions", api_network_conditions),
            Route("/api/network/apply", api_network_apply, methods=["POST"]),
            Route("/api/network/disconnect", api_network_disconnect, methods=["POST"]),
            Route("/api/network/clear", api_network_clear, methods=["DELETE"]),
            Route("/api/network/live-stats", api_network_live_stats),
            Route("/api/network/debug-firewall", api_network_debug_firewall),
            Route("/api/dns/redirects", api_dns_redirects),
            Route("/api/dns/redirect", api_dns_redirect_post, methods=["POST"]),
            Route("/api/dns/redirect", api_dns_redirect_delete, methods=["DELETE"]),
            Route("/api/dns/flush", api_dns_flush, methods=["POST"]),
            Route("/api/proxy/rules", api_proxy_rules),
            Route("/api/proxy/rules", api_proxy_rules_delete, methods=["DELETE"]),
            Route("/api/proxy/rule", api_proxy_rule_create, methods=["POST"]),
            Route("/api/proxy/rule/{rule_id}", api_proxy_rule_delete, methods=["DELETE"]),
            Route("/api/proxy/logs", api_proxy_logs),
            Route("/api/proxy/logs", api_proxy_logs_clear, methods=["DELETE"]),
            Route("/api/proxy/certs/status", api_proxy_certs_status),
            Route(
                "/api/proxy/certs/import",
                api_proxy_certs_import,
                methods=["POST"],
            ),
            Route("/api/proxy/clear", api_proxy_clear, methods=["POST"]),
            Route("/api/profiles/list", api_profiles_list),
            Route("/api/profiles/apply", api_profiles_apply, methods=["POST"]),
            Route("/api/profiles/clear", api_profiles_clear, methods=["POST"]),
            Route("/api/profiles/export", api_profiles_export),
            Route("/api/scenarios/list", api_scenarios_list),
            Route("/api/scenarios/run", api_scenarios_run, methods=["POST"]),
            Route("/api/recording/start", api_recording_start, methods=["POST"]),
            Route("/api/recording/stop", api_recording_stop, methods=["POST"]),
            Route("/api/recording/list", api_recording_list),
            Route("/api/recording/replay", api_recording_replay, methods=["POST"]),
            Route("/api/recording/delete", api_recording_delete, methods=["DELETE"]),
            Route("/api/setup/status", api_setup_status),
            Route("/api/setup/workspace", api_setup_workspace_get),
            Route("/api/setup/workspace", api_setup_workspace_post, methods=["POST"]),
            Route("/api/setup/env-ui", api_setup_env_ui_get),
            Route("/api/setup/env-ui", api_setup_env_ui_post, methods=["POST"]),
            Route("/api/setup/suggest-router", api_setup_suggest_router),
            WebSocketRoute("/ws", websocket_handler),
        ]

        return Starlette(routes=routes, lifespan=lifespan)


async def _async_poll_loop(dashboard: TestDashboard) -> None:
    while not dashboard._stop_event.is_set():
        await asyncio.sleep(dashboard.poll_interval_sec)
        if dashboard._stop_event.is_set():
            break
        if not dashboard._clients:
            continue
        try:
            kit = _get_kit()
            tick = _build_tick(kit)
            await dashboard.broadcast(tick)
        except Exception:
            pass


def _get_launchagent_path() -> Path:
    """Get the LaunchAgent plist path for macOS."""
    return Path.home() / "Library" / "LaunchAgents" / "com.mtk.dashboard.plist"


def _get_launchagent_label() -> str:
    """Get the LaunchAgent label."""
    return "com.mtk.dashboard"


def _create_launchagent_plist(port: int, host: str, no_auto_serve: bool) -> str:
    """Create the LaunchAgent plist content."""
    import shutil
    import sys

    mtk_path = shutil.which("mtk")
    if not mtk_path:
        mtk_path = str(Path(sys.executable).parent / "mtk")

    args = [mtk_path, "dashboard", "start", "--port", str(port), "--host", host]
    if no_auto_serve:
        args.append("--no-auto-serve")

    program_args = "\n".join(f"        <string>{arg}</string>" for arg in args)

    log_dir = Path.home() / "Library" / "Logs" / "mtk-dashboard"

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_get_launchagent_label()}</string>
    <key>ProgramArguments</key>
    <array>
{program_args}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/stdout.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/stderr.log</string>
    <key>WorkingDirectory</key>
    <string>{Path.home()}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin:{Path(sys.executable).parent}</string>
    </dict>
</dict>
</plist>
"""


def _install_service(port: int, host: str, no_auto_serve: bool) -> int:
    """Install the dashboard as a macOS LaunchAgent."""
    import platform
    import subprocess

    if platform.system() != "Darwin":
        print("Error: Service installation is only supported on macOS.")
        print("For Linux, use systemd. For Windows, use Task Scheduler.")
        return 1

    plist_path = _get_launchagent_path()
    label = _get_launchagent_label()

    log_dir = Path.home() / "Library" / "Logs" / "mtk-dashboard"
    log_dir.mkdir(parents=True, exist_ok=True)

    if plist_path.exists():
        print(f"Updating existing service at {plist_path}")
        subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
    else:
        plist_path.parent.mkdir(parents=True, exist_ok=True)

    plist_content = _create_launchagent_plist(port, host, no_auto_serve)
    plist_path.write_text(plist_content)

    result = subprocess.run(["launchctl", "load", str(plist_path)], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error loading service: {result.stderr}")
        return 1

    print("Dashboard service installed successfully!")
    print(f"  Port: {port}")
    print(f"  Host: {host}")
    print(f"  Plist: {plist_path}")
    print(f"  Logs: {log_dir}/")
    print()
    print("The dashboard will now start automatically on login.")
    print(f"Access it at: http://{host}:{port}")
    print()
    print("To uninstall: mtk dashboard uninstall")
    print("To check status: mtk dashboard status")
    return 0


def _uninstall_service() -> int:
    """Uninstall the dashboard LaunchAgent."""
    import platform
    import subprocess

    if platform.system() != "Darwin":
        print("Error: Service management is only supported on macOS.")
        return 1

    plist_path = _get_launchagent_path()

    if not plist_path.exists():
        print("Dashboard service is not installed.")
        return 0

    result = subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Warning: Could not unload service: {result.stderr}")

    plist_path.unlink()
    print("Dashboard service uninstalled successfully.")
    print("The dashboard will no longer start automatically.")
    return 0


def _check_service_status() -> int:
    """Check if the dashboard service is installed and running."""
    import platform
    import subprocess

    if platform.system() != "Darwin":
        print("Error: Service management is only supported on macOS.")
        return 1

    plist_path = _get_launchagent_path()
    label = _get_launchagent_label()

    print("MTK Dashboard Service Status")
    print("=" * 40)

    if not plist_path.exists():
        print("Installed: No")
        print()
        print("To install: mtk dashboard install --port 8766")
        return 0

    print("Installed: Yes")
    print(f"Plist: {plist_path}")

    result = subprocess.run(
        ["launchctl", "list", label],
        capture_output=True,
        text=True,
    )

    if result.returncode == 0:
        lines = result.stdout.strip().split("\n")
        for line in lines:
            if "PID" in line or label in line:
                parts = line.split()
                if len(parts) >= 1 and parts[0].isdigit():
                    print(f"Running: Yes (PID: {parts[0]})")
                    break
        else:
            if "-" in result.stdout:
                print("Running: No (not started)")
            else:
                print("Running: Yes")
    else:
        print("Running: No")

    log_dir = Path.home() / "Library" / "Logs" / "mtk-dashboard"
    stdout_log = log_dir / "stdout.log"
    stderr_log = log_dir / "stderr.log"

    print()
    print("Log files:")
    if stdout_log.exists():
        print(f"  stdout: {stdout_log} ({stdout_log.stat().st_size} bytes)")
    if stderr_log.exists():
        print(f"  stderr: {stderr_log} ({stderr_log.stat().st_size} bytes)")

    print()
    print("Commands:")
    print("  Stop:    launchctl unload ~/Library/LaunchAgents/com.mtk.dashboard.plist")
    print("  Start:   launchctl load ~/Library/LaunchAgents/com.mtk.dashboard.plist")
    print("  Restart: launchctl kickstart -k gui/$(id -u)/com.mtk.dashboard")
    return 0


def cmd_dashboard(args: Any) -> int:
    if args.dashboard_cmd == "start":
        import os

        if getattr(args, "no_auto_serve", False):
            os.environ["MTK_DASHBOARD_AUTO_SERVE"] = "0"
        poll = getattr(args, "poll_interval", None) or 3.0
        dashboard = TestDashboard(
            port=args.port,
            host=getattr(args, "host", None) or "127.0.0.1",
            poll_interval_sec=float(poll),
        )
        print(f"Starting dashboard at {dashboard.get_url()}")
        print("Press Ctrl+C to stop")
        try:
            dashboard.start(blocking=True)
        except KeyboardInterrupt:
            print("\nStopping dashboard...")
            dashboard.stop()
        return 0

    elif args.dashboard_cmd == "install":
        return _install_service(
            port=getattr(args, "port", 8766),
            host=getattr(args, "host", "127.0.0.1"),
            no_auto_serve=getattr(args, "no_auto_serve", False),
        )

    elif args.dashboard_cmd == "uninstall":
        return _uninstall_service()

    elif args.dashboard_cmd == "status":
        return _check_service_status()

    return 1
