from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

WirelessMenuKind = Literal["none", "wireless", "wifi"]


@dataclass(slots=True)
class WirelessSummary:
    """Wireless section of a capability profile."""

    interface_names: list[str] = field(default_factory=list)
    master_interface_names: list[str] = field(default_factory=list)
    has_wireless: bool = False
    """``wireless`` = classic menu; ``wifi`` = RouterOS 7 wifiwave2; ``none`` = not present."""

    menu_kind: WirelessMenuKind = "none"

    def configuration_menu_prefix(self) -> str:
        """Bootstrap VAP commands use this path (``/interface wireless`` or ``/interface wifi``)."""

        if self.menu_kind == "wifi":
            return "/interface wifi"
        return "/interface wireless"


@dataclass(slots=True)
class RouterCapabilityProfile:
    """Snapshot returned by :class:`DiscoveryService` (JSON-serializable via ``as_dict``)."""

    identity_name: str
    routeros_version: str
    board_name: str | None
    architecture: str
    cpu: str
    cpu_count: str
    cpu_load: str
    free_memory: str
    total_memory: str
    uptime: str
    wireless: WirelessSummary

    def as_dict(self) -> dict[str, Any]:
        return {
            "identity": {"name": self.identity_name},
            "routeros": {"version": self.routeros_version},
            "hardware": {"board_name": self.board_name},
            "resources": {
                "architecture": self.architecture,
                "cpu": self.cpu,
                "cpu_count": self.cpu_count,
                "cpu_load": self.cpu_load,
                "free_memory": self.free_memory,
                "total_memory": self.total_memory,
                "uptime": self.uptime,
            },
            "wireless": {
                "has_wireless": self.wireless.has_wireless,
                "masters": self.wireless.master_interface_names,
                "interfaces": self.wireless.interface_names,
                "menu_kind": self.wireless.menu_kind,
            },
        }


def empty_profile() -> RouterCapabilityProfile:
    """Placeholder for failed partial discovery (should not normally be returned)."""

    return RouterCapabilityProfile(
        identity_name="",
        routeros_version="",
        board_name=None,
        architecture="",
        cpu="",
        cpu_count="",
        cpu_load="",
        free_memory="",
        total_memory="",
        uptime="",
        wireless=WirelessSummary(menu_kind="none"),
    )
