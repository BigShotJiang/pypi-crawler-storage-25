from __future__ import annotations

from mtk_router_sdk.discovery.models import (
    RouterCapabilityProfile,
    WirelessMenuKind,
    WirelessSummary,
)
from mtk_router_sdk.exceptions import DiscoveryError
from mtk_router_sdk.parsing import parse_print_block, parse_terse_lines
from mtk_router_sdk.ros_adapter import RosCommandAdapter
from mtk_router_sdk.transport.base import AbstractTransport

# Hint when SSH works but commands/output are not RouterOS (wrong host).
_NOT_ROUTEROS_HINT = (
    "This tool only works with MikroTik hardware running RouterOS over SSH. "
    "Confirm MTK_HOST is the router (not a NAS, PC, or another brand). "
    "On the router, IP → Services → SSH should be on; the account must reach RouterOS CLI commands."
)


class DiscoveryService:
    """Runs a minimal discovery pass over an *already connected* transport.

    Stateless: safe to instantiate once or per call. All command strings live here
    so ``RouterClient`` and future CLI/HTTP layers reuse one implementation.
    """

    __slots__ = ("_transport",)

    def __init__(self, transport: AbstractTransport) -> None:
        self._transport = transport

    def discover(self) -> RouterCapabilityProfile:
        if not self._transport.connected:
            raise DiscoveryError(
                "Transport is not connected.",
                hint="Connect the transport before running discovery.",
            )
        try:
            identity = self._exec_kv("/system identity print")
            resource = self._exec_kv("/system resource print")
            self._assert_routeros_shape(identity, resource)
            board = self._safe_board()
            wireless = self._wireless_summary(resource.get("version", ""))
        except DiscoveryError:
            raise
        except Exception as e:
            raise DiscoveryError(f"Discovery failed: {e}") from e

        return RouterCapabilityProfile(
            identity_name=identity.get("name", ""),
            routeros_version=resource.get("version", ""),
            board_name=board.get("board-name") if board else None,
            architecture=resource.get("architecture", ""),
            cpu=resource.get("cpu", ""),
            cpu_count=resource.get("cpu-count", ""),
            cpu_load=resource.get("cpu-load", ""),
            free_memory=resource.get("free-memory", ""),
            total_memory=resource.get("total-memory", ""),
            uptime=resource.get("uptime", ""),
            wireless=wireless,
        )

    def _exec_kv(self, command: str) -> dict[str, str]:
        r = self._transport.exec_command(command)
        if not r.ok:
            combined = (r.stderr + "\n" + r.stdout).lower()
            extra = ""
            if any(s in combined for s in ("command not found", "not found", "no such file")):
                extra = " The remote side looks like a normal shell, not RouterOS."
            raise DiscoveryError(
                f"RouterOS command failed ({command}), exit {r.exit_status}.{extra}",
                hint=_NOT_ROUTEROS_HINT,
                router_output=r.stderr or r.stdout,
            )
        return parse_print_block(r.stdout)

    def _assert_routeros_shape(
        self,
        identity: dict[str, str],
        resource: dict[str, str],
    ) -> None:
        version = (resource.get("version") or "").strip()
        if version:
            return
        name = (identity.get("name") or "").strip()
        if name and not version:
            # Unusual but treat as non-RouterOS — resource print should always carry version.
            raise DiscoveryError(
                "SSH session responded, but /system resource print did not include a RouterOS "
                "`version` field.",
                hint=_NOT_ROUTEROS_HINT,
            )
        raise DiscoveryError(
            "SSH connected, but the device does not look like MikroTik RouterOS "
            "(missing identity and RouterOS version in parsed output).",
            hint=_NOT_ROUTEROS_HINT,
        )

    def _safe_board(self) -> dict[str, str] | None:
        r = self._transport.exec_command("/system routerboard print")
        if not r.ok:
            return None
        return parse_print_block(r.stdout)

    def _wireless_summary(self, routeros_version: str) -> WirelessSummary:
        adapter = RosCommandAdapter.from_version_string(routeros_version)
        r = self._transport.exec_command(adapter.wireless_print_terse_command())
        menu_kind: WirelessMenuKind = "none"
        if r.ok:
            menu_kind = "wireless"
        elif adapter.try_wifi_when_wireless_fails():
            r = self._transport.exec_command(adapter.wifi_print_terse_command())
            if r.ok:
                menu_kind = "wifi"
        if menu_kind == "none":
            return WirelessSummary(has_wireless=False, menu_kind="none")
        rows = parse_terse_lines(r.stdout)
        if not rows:
            return WirelessSummary(has_wireless=False, menu_kind="none")
        names: list[str] = []
        masters: list[str] = []
        for row in rows:
            name = row.get("name")
            if not name or not isinstance(name, str):
                continue
            names.append(name)
            mi_raw = str(row.get("master-interface", "")).strip().lower()
            # Master AP: no key, empty, or explicit 'none'; slaves reference e.g. wlan1
            if not mi_raw or mi_raw == "none":
                masters.append(name)
        return WirelessSummary(
            interface_names=names,
            master_interface_names=masters,
            has_wireless=bool(names),
            menu_kind=menu_kind,
        )
