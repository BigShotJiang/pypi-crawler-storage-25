"""Router capability discovery (identity, resources, wireless inventory)."""

from mtk_router_sdk.discovery.models import RouterCapabilityProfile, WirelessSummary
from mtk_router_sdk.discovery.service import DiscoveryService

__all__ = ["DiscoveryService", "RouterCapabilityProfile", "WirelessSummary"]
