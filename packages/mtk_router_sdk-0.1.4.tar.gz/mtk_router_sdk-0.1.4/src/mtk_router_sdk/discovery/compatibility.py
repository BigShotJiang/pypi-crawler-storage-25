"""
SSH target evaluation — detect MikroTik RouterOS without breaking callers.

Use this when you need a soft yes/no (dashboard, health checks) instead of
raising :class:`~mtk_router_sdk.exceptions.DiscoveryError`.
"""

from __future__ import annotations

from contextlib import suppress
from typing import Any

from mtk_router_sdk.exceptions import ConfigurationError, MtkRouterError

_ACTION_HINT = (
    "This SDK is built for MikroTik hardware running RouterOS. "
    "Point MTK_HOST at your MikroTik, set MTK_USER and MTK_PASSWORD, and ensure "
    "IP → Services → SSH is enabled. "
    "You can still use HTTP proxy / mtk-serve features if mtk-serve is running."
)


def evaluate_ssh_router_from_env() -> dict[str, Any]:
    """Probe env SSH settings and confirm RouterOS. **Never raises.**

    Returns a dict suitable for JSON (dashboard / health). Keys:

    - ``routeros_supported`` (bool): discovery succeeded (MikroTik RouterOS).
    - ``ssh_connected`` (bool): TCP + SSH session established.
    - ``ssh_configured`` (bool): password present (minimal bar to attempt SSH).
    - ``compat_message`` (str): short human summary (warning or success).
    - ``compat_hint`` (str | None): extra guidance when unsupported.
    - ``identity_name``, ``routeros_version`` (str): when supported.
    - ``action_block_message`` (str): copy for API ``user_message`` when blocking actions.
    """
    from mtk_router_sdk.client import RouterClient
    from mtk_router_sdk.config import connection_config_from_env

    base: dict[str, Any] = {
        "routeros_supported": False,
        "ssh_connected": False,
        "ssh_configured": False,
        "compat_message": "",
        "compat_hint": None,
        "identity_name": "",
        "routeros_version": "",
        "action_block_message": _ACTION_HINT,
    }

    try:
        cfg = connection_config_from_env(
            require_password=False,
            exit_on_missing_password=False,
        )
    except ConfigurationError as e:
        base["compat_message"] = str(e)
        base["compat_hint"] = (
            "Set MTK_HOST, MTK_USER, and MTK_PASSWORD in the environment (or use a site file "
            "with the dashboard / CLI)."
        )
        return base

    if not (cfg.password or "").strip():
        base["compat_message"] = (
            "SSH password not set (MTK_PASSWORD). Cannot verify a MikroTik router."
        )
        base["compat_hint"] = (
            "Export MTK_PASSWORD for the router account, or rely on mtk-serve-only "
            "(Proxy) features without router-side automation."
        )
        return base

    base["ssh_configured"] = True
    client = RouterClient.from_env()
    try:
        try:
            client.connect(cfg)
        except MtkRouterError as e:
            base["compat_message"] = e.message
            base["compat_hint"] = e.hint
            base["ssh_connected"] = False
            return base

        base["ssh_connected"] = True
        profile, err = client.discover_safe()
        if profile is not None:
            base["routeros_supported"] = True
            base["compat_message"] = (
                f"MikroTik RouterOS detected ({profile.identity_name or 'router'})."
            )
            base["compat_hint"] = None
            base["identity_name"] = profile.identity_name
            base["routeros_version"] = profile.routeros_version
            base["action_block_message"] = ""
            return base

        if err is not None:
            base["compat_message"] = err.message
            base["compat_hint"] = err.hint
        else:
            base["compat_message"] = "Discovery did not confirm MikroTik RouterOS."
            base["compat_hint"] = _ACTION_HINT
        return base
    finally:
        with suppress(Exception):
            client.disconnect()
