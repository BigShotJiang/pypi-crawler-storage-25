from __future__ import annotations

import json
import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from mtk_router_sdk.config.schema import (
    BootstrapSettings,
    ConnectionSettings,
    GlobalSettings,
    SiteConfig,
    SlotConfig,
    VpnCredentials,
    WifiSecuritySettings,
)
from mtk_router_sdk.exceptions import ConfigurationError


def _require(d: dict[str, Any], key: str, ctx: str) -> Any:
    if key not in d:
        raise ConfigurationError(f"Missing {key!r} in {ctx}.")
    return d[key]


def resolve_secret_ref(ref: str, env: Mapping[str, str] | None = None) -> str:
    """Resolve ``env:VAR`` or return the string as-is (inline secret)."""

    lookups: Mapping[str, str] = os.environ if env is None else env
    if ref.startswith("env:"):
        var = ref[4:]
        val = lookups.get(var, "")
        if not val:
            raise ConfigurationError(
                f"Environment variable {var!r} is not set (required by {ref!r}).",
                hint=f"Export {var} or change the ref in your site JSON.",
            )
        return val
    return ref


def load_site_config(data: dict[str, Any], *, env: Mapping[str, str] | None = None) -> SiteConfig:
    """Parse site document (dict from JSON)."""

    ver = _require(data, "version", "site root")
    if ver != 1:
        raise ConfigurationError(f"Unsupported site version: {ver!r} (only 1 supported).")

    g = _require(data, "global", "site root")
    ws = g.get("wifi_security") or {}
    vc = g.get("vpn_credentials") or {}
    cf_raw = g.get("client_fallback_slot_id")
    client_fb: int | None = None
    if cf_raw is not None and str(cf_raw).strip() != "":
        client_fb = int(cf_raw)
    global_settings = GlobalSettings(
        max_slots=int(g.get("max_slots", 8)),
        wifi_security=WifiSecuritySettings(
            profile_name=str(ws.get("profile_name", "slot_wifi_sec")),
            psk_ref=str(ws.get("psk_ref", "env:MTK_WIFI_PSK")),
        ),
        vpn_credentials=VpnCredentials(
            user_ref=str(vc.get("user_ref", "env:MTK_VPN_USER")),
            password_ref=str(vc.get("password_ref", "env:MTK_VPN_PASSWORD")),
            ipsec_secret_ref=(
                str(vc["ipsec_secret_ref"]) if vc.get("ipsec_secret_ref") else None
            ),
            use_ipsec=bool(vc.get("use_ipsec", True)),
        ),
        client_fallback_slot_id=client_fb,
    )

    reg = _require(data, "vpn_registry", "site root")
    reg_ok = isinstance(reg, dict) and all(
        isinstance(k, str) and isinstance(v, str) for k, v in reg.items()
    )
    if not reg_ok:
        raise ConfigurationError("vpn_registry must be an object of string region → hostname.")

    b = data.get("bootstrap") or {}
    prov = str(b.get("provision_tunnels", "required_only"))
    bootstrap = BootstrapSettings(provision_tunnels=prov)

    conn_raw = data.get("connection")
    connection: ConnectionSettings | None = None
    if conn_raw is not None:
        if not isinstance(conn_raw, dict):
            raise ConfigurationError("connection must be an object.")
        pwd_key = "password_ref" if "password_ref" in conn_raw else "password"
        connection = ConnectionSettings(
            host=str(conn_raw.get("host", "192.168.88.1")),
            username=str(conn_raw.get("username", "admin")),
            password_ref=str(conn_raw.get(pwd_key, "env:MTK_PASSWORD")),
            port=int(conn_raw.get("port", 22)),
            timeout=float(conn_raw.get("timeout", 10)),
        )

    raw_slots = _require(data, "slots", "site root")
    if not isinstance(raw_slots, list):
        raise ConfigurationError("slots must be a list.")
    slots: list[SlotConfig] = []
    for i, row in enumerate(raw_slots):
        if not isinstance(row, dict):
            raise ConfigurationError(f"slots[{i}] must be an object.")
        slots.append(
            SlotConfig(
                id=int(_require(row, "id", f"slots[{i}]")),
                enabled=bool(row.get("enabled", True)),
                ssid=str(_require(row, "ssid", f"slots[{i}]")),
                region=str(_require(row, "region", f"slots[{i}]")),
                tunnel_name=str(row["tunnel_name"]) if row.get("tunnel_name") else None,
                master_interface=(
                    str(row["master_interface"]) if row.get("master_interface") else None
                ),
                subnet=str(row["subnet"]) if row.get("subnet") else None,
                interface_name=str(row["interface_name"]) if row.get("interface_name") else None,
                routing_mark=str(row["routing_mark"]) if row.get("routing_mark") else None,
            )
        )

    site = SiteConfig(
        version=int(ver),
        global_=global_settings,
        vpn_registry=reg,
        bootstrap=bootstrap,
        slots=slots,
        connection=connection,
    )
    _validate_site(site, env=env)
    return site


def load_site_config_from_path(
    path: str | Path,
    *,
    env: Mapping[str, str] | None = None,
) -> SiteConfig:
    p = Path(path)
    if not p.is_file():
        raise ConfigurationError(f"Site config file not found: {p}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ConfigurationError(f"Invalid JSON in {p}: {e}") from e
    if not isinstance(data, dict):
        raise ConfigurationError("Site file must contain a JSON object.")
    return load_site_config(data, env=env)


def _validate_site(site: SiteConfig, *, env: Mapping[str, str] | None = None) -> None:
    for s in site.enabled_slots:
        if s.region not in site.vpn_registry:
            raise ConfigurationError(
                f"Enabled slot {s.id} references region {s.region!r} "
                "which is missing from vpn_registry.",
                hint="Add the region to vpn_registry or disable the slot.",
            )
    # Touch secret refs so missing env fails early
    try:
        resolve_secret_ref(site.global_.wifi_security.psk_ref, env=env)
        resolve_secret_ref(site.global_.vpn_credentials.user_ref, env=env)
        resolve_secret_ref(site.global_.vpn_credentials.password_ref, env=env)
        sec_ref = site.global_.vpn_credentials.ipsec_secret_ref
        if sec_ref:
            resolve_secret_ref(sec_ref, env=env)
    except ConfigurationError:
        raise
    if site.bootstrap.provision_tunnels not in ("all_regions", "required_only", "none"):
        raise ConfigurationError(
            "bootstrap.provision_tunnels must be one of: all_regions, required_only, none."
        )
    if site.connection:
        resolve_secret_ref(site.connection.host, env=env)
        resolve_secret_ref(site.connection.username, env=env)
        resolve_secret_ref(site.connection.password_ref, env=env)
