"""
Merge global ``MTK_VPN_*`` env vars with per-endpoint overrides from JSON.

The dashboard writes ``MTK_VPN_ENDPOINT_CREDENTIALS`` (JSON object) when a workspace
profile defines :attr:`vpn_endpoint_overrides`. Keys are **endpoint ids** — use the same
strings as ``vpn_registry`` region keys in your site JSON (e.g. ``US``, ``UK``).

Scripts can switch credentials before bootstrap or VPN operations::

    import os
    from mtk_router_sdk.config.vpn_endpoint_creds import materialize_vpn_env_for_endpoint

    os.environ["MTK_VPN_ACTIVE_ENDPOINT"] = "US"
    materialize_vpn_env_for_endpoint("US")
    # mtk bootstrap / slot VPN — now uses US-specific login if configured
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping, MutableMapping
from typing import Any


def parse_vpn_endpoint_credentials(raw: str | None) -> dict[str, dict[str, str]]:
    """Parse ``MTK_VPN_ENDPOINT_CREDENTIALS`` JSON into ``endpoint_id -> {user, password, ipsec_secret}``."""

    if not raw or not str(raw).strip():
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    out: dict[str, dict[str, str]] = {}
    for k, v in data.items():
        kid = str(k).strip()
        if not kid or not isinstance(v, dict):
            continue
        entry: dict[str, str] = {}
        for field, key in (("user", "user"), ("password", "password"), ("ipsec_secret", "ipsec_secret")):
            s = str(v.get(key, "") or "").strip()
            if s:
                entry[field] = s
        if entry:
            out[kid] = entry
    return out


def resolve_vpn_credentials_for_endpoint(
    endpoint_id: str,
    *,
    env: Mapping[str, str] | None = None,
) -> tuple[str, str, str]:
    """
    Return ``(user, password, ipsec_secret)`` after merging global env with override for ``endpoint_id``.

    Empty strings mean “unset” for that field after merge (inheritance from global only
    where overlay omits a key).
    """

    env = env or os.environ
    g_user = str(env.get("MTK_VPN_USER", "") or "").strip()
    g_pass = str(env.get("MTK_VPN_PASSWORD", "") or "").strip()
    g_ipsec = str(env.get("MTK_VPN_IPSEC_SECRET", "") or "").strip()
    eid = str(endpoint_id or "").strip()
    if not eid:
        return g_user, g_pass, g_ipsec
    ov = parse_vpn_endpoint_credentials(env.get("MTK_VPN_ENDPOINT_CREDENTIALS")).get(eid) or {}
    u = str(ov.get("user", "") or "").strip() or g_user
    p = str(ov.get("password", "") or "").strip() or g_pass
    i = str(ov.get("ipsec_secret", "") or "").strip() or g_ipsec
    return u, p, i


def materialize_vpn_env_for_endpoint(
    endpoint_id: str,
    *,
    env: MutableMapping[str, str] | None = None,
) -> tuple[str, str, str]:
    """
    Write merged VPN user/password/IPsec for ``endpoint_id`` into ``env`` (default ``os.environ``).

    Returns the merged triple for inspection or logging.
    """

    env = env or os.environ
    u, p, i = resolve_vpn_credentials_for_endpoint(endpoint_id, env=env)
    if u:
        env["MTK_VPN_USER"] = u
    if p:
        env["MTK_VPN_PASSWORD"] = p
    if i:
        env["MTK_VPN_IPSEC_SECRET"] = i
    return u, p, i


def normalize_profile_endpoint_overrides(raw: Any) -> dict[str, dict[str, str]]:
    """Normalize profile ``vpn_endpoint_overrides`` for storage / JSON env export."""

    if not isinstance(raw, dict):
        return {}
    out: dict[str, dict[str, str]] = {}
    for k, v in raw.items():
        kid = str(k).strip()
        if not kid or not isinstance(v, dict):
            continue
        entry: dict[str, str] = {}
        for field, key in (("user", "user"), ("password", "password"), ("ipsec_secret", "ipsec_secret")):
            s = str(v.get(key, "") or "").strip()
            if s:
                entry[field] = s
        if entry:
            out[kid] = entry
    return out
