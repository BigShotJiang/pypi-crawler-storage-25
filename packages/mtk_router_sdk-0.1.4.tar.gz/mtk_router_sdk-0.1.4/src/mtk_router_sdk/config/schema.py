from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ConnectionSettings:
    """SSH target; each field may be a literal or ``env:VAR`` (see ``resolve_secret_ref``)."""

    host: str = "192.168.88.1"
    username: str = "admin"
    password_ref: str = "env:MTK_PASSWORD"
    port: int = 22
    timeout: float = 10.0


@dataclass(slots=True)
class WifiSecuritySettings:
    profile_name: str = "slot_wifi_sec"
    psk_ref: str = "env:MTK_WIFI_PSK"


@dataclass(slots=True)
class VpnCredentials:
    user_ref: str = "env:MTK_VPN_USER"
    password_ref: str = "env:MTK_VPN_PASSWORD"
    ipsec_secret_ref: str | None = None  # default: same as password if unset
    use_ipsec: bool = True  # set False for plain L2TP without IPsec encryption


@dataclass(slots=True)
class GlobalSettings:
    max_slots: int = 8
    wifi_security: WifiSecuritySettings = field(default_factory=WifiSecuritySettings)
    vpn_credentials: VpnCredentials = field(default_factory=VpnCredentials)
    #: When client IP doesn't match any slot subnet or DHCP, map to this enabled slot.
    client_fallback_slot_id: int | None = None


@dataclass(slots=True)
class BootstrapSettings:
    """Tunnel provisioning policy (see docs/ROUTER_SDK.md §3.7)."""

    provision_tunnels: str = "required_only"  # all_regions | required_only | none


@dataclass(slots=True)
class SlotConfig:
    id: int
    enabled: bool
    ssid: str
    region: str
    tunnel_name: str | None = None
    master_interface: str | None = None
    subnet: str | None = None  # e.g. 172.20.101.0/24
    interface_name: str | None = None
    routing_mark: str | None = None


@dataclass(slots=True)
class SiteConfig:
    version: int
    global_: GlobalSettings
    vpn_registry: dict[str, str]
    bootstrap: BootstrapSettings
    slots: list[SlotConfig]
    connection: ConnectionSettings | None = None

    @property
    def enabled_slots(self) -> list[SlotConfig]:
        return [s for s in self.slots if s.enabled]
