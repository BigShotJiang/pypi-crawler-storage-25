"""Strict parsing of integer/float environment variables (fail fast with clear errors)."""

from __future__ import annotations

import os
from collections.abc import Mapping

from mtk_router_sdk.exceptions import ConfigurationError


def parse_int_env(
    key: str,
    default: int,
    *,
    env: Mapping[str, str] | None = None,
    minimum: int = 1,
    maximum: int = 65535,
) -> int:
    """Parse ``key`` as a base-10 int in ``[minimum, maximum]``; unset or empty → ``default``."""

    look: Mapping[str, str] = os.environ if env is None else env
    raw = str(look.get(key, "") or "").strip()
    if not raw:
        return default
    try:
        v = int(raw, 10)
    except ValueError as e:
        raise ConfigurationError(
            f"Environment variable {key!r} must be an integer (got {raw!r}).",
            hint=f"Unset {key} to use the default ({default}), or set a whole number between {minimum} and {maximum}.",
        ) from e
    if v < minimum or v > maximum:
        raise ConfigurationError(
            f"Environment variable {key!r} is out of range ({minimum}–{maximum}): {v}.",
        )
    return v


def parse_float_env(
    key: str,
    default: float,
    *,
    env: Mapping[str, str] | None = None,
    minimum: float = 0.0,
    maximum: float = 86400.0,
) -> float:
    """Parse ``key`` as a float in ``[minimum, maximum]``; unset or empty → ``default``."""

    look: Mapping[str, str] = os.environ if env is None else env
    raw = str(look.get(key, "") or "").strip()
    if not raw:
        return default
    try:
        v = float(raw)
    except ValueError as e:
        raise ConfigurationError(
            f"Environment variable {key!r} must be a number (got {raw!r}).",
            hint=f"Unset {key} to use the default ({default}), or set a value between {minimum} and {maximum}.",
        ) from e
    if v < minimum or v > maximum:
        raise ConfigurationError(
            f"Environment variable {key!r} is out of range ({minimum}–{maximum}): {v}.",
        )
    return v
