from __future__ import annotations

import os
import sys
from collections.abc import Mapping

from mtk_router_sdk.config.env_parse import parse_float_env, parse_int_env
from mtk_router_sdk.config.load import resolve_secret_ref
from mtk_router_sdk.config.schema import SiteConfig
from mtk_router_sdk.exceptions import ConfigurationError
from mtk_router_sdk.models import ConnectionConfig


def _env_or_file(
    lookups: Mapping[str, str],
    env_key: str,
    file_val: str | None,
    default: str,
) -> str:
    ev = str(lookups.get(env_key, "") or "").strip()
    if ev:
        return ev
    if file_val is not None:
        return resolve_secret_ref(file_val, env=lookups)
    return default


def _resolve_ssh_host(lookups: Mapping[str, str], site: SiteConfig | None) -> str:
    """Resolve SSH host: env, site file, then auto-detect (LAN + gateway + port 22 probe)."""

    ev = str(lookups.get("MTK_HOST", "") or "").strip()
    if ev:
        return ev
    if site and site.connection:
        return resolve_secret_ref(site.connection.host, env=lookups)
    skip = str(lookups.get("MTK_SKIP_GATEWAY_DETECT", "") or "").strip().lower()
    if skip in ("1", "true", "yes"):
        return "192.168.88.1"
    from mtk_router_sdk.net.ssh_host import collect_router_ssh_candidates, pick_reachable_ssh_host

    candidates = collect_router_ssh_candidates()
    probe_off = str(lookups.get("MTK_AUTO_SSH_PROBE", "") or "").strip().lower() in (
        "0",
        "false",
        "no",
    )
    to_s = str(lookups.get("MTK_AUTO_SSH_PROBE_TIMEOUT", "") or "").strip()
    try:
        t = float(to_s) if to_s else 1.5
    except ValueError:
        t = 1.5
    if probe_off:
        # Reuse probe order + fallback (guest/slot Wi‑Fi → gateway) without real TCP.
        return pick_reachable_ssh_host(
            candidates,
            timeout_per_host=min(t, 0.05),
            probe=lambda _h, **_k: False,
        )
    return pick_reachable_ssh_host(candidates, timeout_per_host=t)


def connection_config_from_env(
    *,
    require_password: bool = True,
    exit_on_missing_password: bool = True,
) -> ConnectionConfig:
    """Build :class:`ConnectionConfig` from env, optional default-gateway probe, and defaults."""

    lookups: Mapping[str, str] = os.environ
    host = _resolve_ssh_host(lookups, None)
    user = _env_or_file(lookups, "MTK_USER", None, "admin")
    password = _env_or_file(lookups, "MTK_PASSWORD", None, "")
    if require_password and not password:
        msg = (
            "MTK_PASSWORD is not set. Export MTK_HOST, MTK_USER, and MTK_PASSWORD "
            "(see README)."
        )
        if exit_on_missing_password:
            print(
                "MTK_PASSWORD is not set. This tool connects to MikroTik RouterOS over SSH.\n"
                + msg,
                file=sys.stderr,
            )
            raise SystemExit(2)
        raise ConfigurationError(msg)
    port = parse_int_env("MTK_PORT", 22, minimum=1, maximum=65535)
    timeout = parse_float_env("MTK_TIMEOUT", 10.0, minimum=0.5, maximum=3600.0)
    return ConnectionConfig(
        host=host,
        username=user,
        password=password,
        port=port,
        timeout=timeout,
    )


def connection_config_from_merged(
    site: SiteConfig | None,
    *,
    require_password: bool = True,
    exit_on_missing_password: bool = True,
    env: Mapping[str, str] | None = None,
) -> ConnectionConfig:
    """SSH settings: **environment variables override** the site file when non-empty.

    Host resolution: ``MTK_HOST`` → optional site ``connection.host`` → **auto-detect**:
    ``192.168.88.1``, then the default IPv4 gateway, then other LAN ``.1`` guesses from
    local interfaces; the first address with **TCP port 22 open** wins (see
    ``MTK_AUTO_SSH_PROBE`` / ``MTK_AUTO_SSH_PROBE_TIMEOUT``). Set
    ``MTK_SKIP_GATEWAY_DETECT=1`` to use ``192.168.88.1`` only (no interface/gateway list).
    """

    lookups: Mapping[str, str] = os.environ if env is None else env

    if site and site.connection:
        c = site.connection
        host = _resolve_ssh_host(lookups, site)
        user = _env_or_file(lookups, "MTK_USER", c.username, "admin")
        password = _env_or_file(lookups, "MTK_PASSWORD", c.password_ref, "")
        port_s = str(lookups.get("MTK_PORT", "") or "").strip()
        if port_s:
            port = parse_int_env("MTK_PORT", c.port, env=lookups, minimum=1, maximum=65535)
        else:
            port = c.port
        to_s = str(lookups.get("MTK_TIMEOUT", "") or "").strip()
        if to_s:
            timeout = parse_float_env(
                "MTK_TIMEOUT",
                c.timeout,
                env=lookups,
                minimum=0.5,
                maximum=3600.0,
            )
        else:
            timeout = c.timeout
    else:
        host = _resolve_ssh_host(lookups, None)
        user = _env_or_file(lookups, "MTK_USER", None, "admin")
        password = _env_or_file(lookups, "MTK_PASSWORD", None, "")
        port_s = str(lookups.get("MTK_PORT", "") or "").strip()
        port = (
            parse_int_env("MTK_PORT", 22, env=lookups, minimum=1, maximum=65535)
            if port_s
            else 22
        )
        to_s = str(lookups.get("MTK_TIMEOUT", "") or "").strip()
        timeout = (
            parse_float_env("MTK_TIMEOUT", 10.0, env=lookups, minimum=0.5, maximum=3600.0)
            if to_s
            else 10.0
        )

    if require_password and not password:
        msg = (
            "Router SSH password is missing. Set MTK_PASSWORD, use connection.password_ref "
            "in the site file, or export the env var referenced there."
        )
        if exit_on_missing_password:
            print(
                "MTK / SSH password required.\n" + msg,
                file=sys.stderr,
            )
            raise SystemExit(2)
        raise ConfigurationError(msg)

    return ConnectionConfig(
        host=host,
        username=user,
        password=password,
        port=port,
        timeout=timeout,
    )
