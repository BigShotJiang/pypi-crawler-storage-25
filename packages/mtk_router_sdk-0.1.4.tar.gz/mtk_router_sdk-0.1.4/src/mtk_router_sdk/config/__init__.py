"""Site configuration loading (JSON) and environment helpers."""

from mtk_router_sdk.config.env import connection_config_from_env, connection_config_from_merged
from mtk_router_sdk.config.load import load_site_config, load_site_config_from_path
from mtk_router_sdk.config.schema import (
    BootstrapSettings,
    ConnectionSettings,
    GlobalSettings,
    SiteConfig,
    SlotConfig,
)
from mtk_router_sdk.config.vpn_endpoint_creds import (
    materialize_vpn_env_for_endpoint,
    parse_vpn_endpoint_credentials,
    resolve_vpn_credentials_for_endpoint,
)

__all__ = [
    "BootstrapSettings",
    "ConnectionSettings",
    "GlobalSettings",
    "SiteConfig",
    "SlotConfig",
    "connection_config_from_env",
    "connection_config_from_merged",
    "load_site_config",
    "load_site_config_from_path",
    "materialize_vpn_env_for_endpoint",
    "parse_vpn_endpoint_credentials",
    "resolve_vpn_credentials_for_endpoint",
]
