from __future__ import annotations

import re
from typing import Any

# RouterOS "print terse" / "print stats" style: leading idx + flags + key=value...
_FLAGS_PREFIX = re.compile(r"^\s*\d+\s+([A-Z]*)\s+")
_KV_PAIRS = re.compile(r'([a-zA-Z0-9-]+)=(".*?"|\S+)')


def parse_terse_line(line: str) -> dict[str, Any]:
    """Parse one line of RouterOS *terse* output into a flat dict.

    Shared by wireless, L2TP, DHCP lease tables, and any future *print terse* consumer.
    Reuses the same grammar across the SDK so we do not duplicate regex per feature.
    """
    result: dict[str, Any] = {}
    flags_match = _FLAGS_PREFIX.match(line)
    result["flags"] = flags_match.group(1) if flags_match else ""
    for key, value in _KV_PAIRS.findall(line):
        result[key] = value.strip('"')
    return result


def parse_terse_lines(lines: str) -> list[dict[str, Any]]:
    """Parse multiple non-empty lines."""
    out: list[dict[str, Any]] = []
    for raw in lines.splitlines():
        line = raw.strip()
        if line:
            out.append(parse_terse_line(line))
    return out
