from __future__ import annotations

import re

# Typical "  name: MikroTik" or "  uptime: 1w2d3h4m5s" from `/something print`
_LINE_KV = re.compile(r"^\s*([a-zA-Z0-9-]+):\s*(.*)\s*$")


def parse_print_block(text: str) -> dict[str, str]:
    """Parse RouterOS multi-line ``print`` output (non-terse) into a flat dict.

    Lines that do not match ``key: value`` are skipped. First occurrence wins;
    duplicate keys can be handled by callers if needed.
    """
    result: dict[str, str] = {}
    for raw in text.splitlines():
        m = _LINE_KV.match(raw)
        if m:
            result[m.group(1)] = m.group(2).strip()
    return result
