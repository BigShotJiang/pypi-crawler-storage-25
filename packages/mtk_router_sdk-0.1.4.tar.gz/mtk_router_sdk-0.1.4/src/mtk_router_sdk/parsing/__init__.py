"""Reusable RouterOS output parsers (terse lines, ``print`` blocks)."""

from mtk_router_sdk.parsing.keyvalue import parse_print_block
from mtk_router_sdk.parsing.terse import parse_terse_line, parse_terse_lines

__all__ = ["parse_print_block", "parse_terse_line", "parse_terse_lines"]
