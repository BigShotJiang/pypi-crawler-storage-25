"""Per-client internet block/unblock via firewall rules (runtime, no persistence)."""

from __future__ import annotations

from typing import Any

from mtk_router_sdk.client import RouterClient

BLOCK_COMMENT = "mtk_client_block"


def _find_block_rule_id(
    client: RouterClient,
    ip: str,
    *,
    timeout: float = 30.0,
) -> str | None:
    """Return the `.id` of the firewall rule blocking this IP, or None."""
    rows = client.exec_print_terse("/ip firewall filter", timeout=timeout)
    for r in rows:
        if (
            str(r.get("src-address", "")).strip() == ip
            and str(r.get("comment", "")).strip() == BLOCK_COMMENT
            and str(r.get("chain", "")).strip() == "forward"
            and str(r.get("action", "")).strip() == "drop"
        ):
            return str(r.get(".id", "")).strip() or None
    return None


def block_client(
    client: RouterClient,
    ip: str,
    *,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """Block internet for a single client IP (forward DROP rule).

    Idempotent: if already blocked, returns existing state.
    """
    ip = ip.strip()
    existing = _find_block_rule_id(client, ip, timeout=timeout)
    if existing:
        return {
            "ok": True,
            "action": "already_blocked",
            "client_ip": ip,
            "rule_id": existing,
        }

    cmd = (
        f'/ip firewall filter add chain=forward src-address={ip} '
        f'action=drop comment="{BLOCK_COMMENT}"'
    )
    r = client.exec_command(cmd, timeout=timeout)
    if not r.ok:
        return {
            "ok": False,
            "action": "block_failed",
            "client_ip": ip,
            "error": r.stderr or r.stdout,
        }

    rule_id = _find_block_rule_id(client, ip, timeout=timeout)
    return {
        "ok": True,
        "action": "blocked",
        "client_ip": ip,
        "rule_id": rule_id,
    }


def unblock_client(
    client: RouterClient,
    ip: str,
    *,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """Remove the block rule for a client IP.

    Idempotent: if not blocked, returns success with action=not_blocked.
    """
    ip = ip.strip()
    rule_id = _find_block_rule_id(client, ip, timeout=timeout)
    if not rule_id:
        return {
            "ok": True,
            "action": "not_blocked",
            "client_ip": ip,
        }

    cmd = f"/ip firewall filter remove {rule_id}"
    r = client.exec_command(cmd, timeout=timeout)
    if not r.ok:
        return {
            "ok": False,
            "action": "unblock_failed",
            "client_ip": ip,
            "error": r.stderr or r.stdout,
        }

    return {
        "ok": True,
        "action": "unblocked",
        "client_ip": ip,
    }


def list_blocked_clients(
    client: RouterClient,
    *,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """List all client IPs currently blocked by SDK rules."""
    rows = client.exec_print_terse("/ip firewall filter", timeout=timeout)
    blocked: list[dict[str, Any]] = []
    for r in rows:
        if (
            str(r.get("comment", "")).strip() == BLOCK_COMMENT
            and str(r.get("chain", "")).strip() == "forward"
            and str(r.get("action", "")).strip() == "drop"
        ):
            blocked.append({
                "client_ip": str(r.get("src-address", "")).strip(),
                "rule_id": str(r.get(".id", "")).strip() or None,
                "disabled": str(r.get("disabled", "")).lower() in ("true", "yes"),
            })
    return {
        "ok": True,
        "blocked_clients": blocked,
        "count": len(blocked),
    }


def is_client_blocked(
    client: RouterClient,
    ip: str,
    *,
    timeout: float = 30.0,
) -> dict[str, Any]:
    """Check if a specific client IP is blocked."""
    ip = ip.strip()
    rule_id = _find_block_rule_id(client, ip, timeout=timeout)
    return {
        "ok": True,
        "client_ip": ip,
        "blocked": rule_id is not None,
        "rule_id": rule_id,
    }
