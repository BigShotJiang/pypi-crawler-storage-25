"""Policy-route updates for per-slot VPN switching."""

from __future__ import annotations

from typing import Any

from mtk_router_sdk.bootstrap.engine import _ros_cli_ident
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.models import ExecResult


def update_policy_route_gateway(
    client: RouterClient,
    *,
    routing_mark: str,
    gateway_interface: str,
    timeout: float = 120.0,
) -> ExecResult:
    """Set ``gateway`` on the default route row that carries ``routing_mark``."""

    mark_id = _ros_cli_ident(routing_mark)
    gw_id = _ros_cli_ident(gateway_interface)
    cmd = f"/ip route set [find routing-mark={mark_id}] gateway={gw_id}"
    return client.exec_command(cmd, timeout=timeout, get_pty=False)


def set_slot_vpn_gateway(
    client: RouterClient,
    slot: int | str,
    tunnel: str,
    *,
    site: Any | None = None,
    timeout: float = 120.0,
) -> ExecResult:
    """Set the policy-route **gateway** for a numeric slot (test profiles / scenarios).

    When ``site`` is set (e.g. :attr:`MtkTestKit._site`), uses the slot's configured
    ``routing_mark`` via :func:`mtk_router_sdk.intent.runner.routing_mark_for_slot`.
    Otherwise uses the default ``rt_slot_{id}`` (same as an unset ``routing_mark``).
    """

    slot_id = int(slot)
    gw = str(tunnel).strip()
    if site is not None:
        from mtk_router_sdk.intent.runner import routing_mark_for_slot

        mark = routing_mark_for_slot(site, slot_id)
    else:
        mark = f"rt_slot_{slot_id}"
    return update_policy_route_gateway(
        client,
        routing_mark=mark,
        gateway_interface=gw,
        timeout=timeout,
    )
