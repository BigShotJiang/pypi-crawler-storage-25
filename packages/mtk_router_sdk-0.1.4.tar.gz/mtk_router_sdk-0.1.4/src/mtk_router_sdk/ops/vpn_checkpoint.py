"""Post-change VPN validation: policy route, L2TP state, site region labels (user-facing)."""

from __future__ import annotations

from typing import Any

from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config.schema import SiteConfig


def _policy_route_for_mark(rows: list[dict[str, Any]], routing_mark: str) -> dict[str, Any] | None:
    want = routing_mark.strip()
    if not want:
        return None
    for r in rows:
        if str(r.get("routing-mark", "")).strip() == want:
            return r
    return None


def _gw_equal(live: str, expected: str) -> bool:
    """Compare RouterOS gateway tokens (interface names are usually ASCII; normalize case)."""

    return live.strip().casefold() == expected.strip().casefold()


def _l2tp_running_from_row(row: dict[str, Any]) -> tuple[bool, str | None]:
    """RouterOS may set ``running=yes`` or encode link-up as flag ``R`` in terse output."""

    running_raw = str(row.get("running", "")).strip()
    if running_raw.lower() in ("true", "yes"):
        return True, running_raw
    flags = str(row.get("flags", "")).strip().upper()
    if "R" in flags:
        return True, running_raw or "R"
    return False, running_raw or None


def _l2tp_row_for_name(rows: list[dict[str, Any]], name: str) -> dict[str, Any] | None:
    target = name.strip()
    if not target:
        return None
    for r in rows:
        if str(r.get("name", "")).strip() == target:
            return r
    return None


def _slot_labels(site: SiteConfig, slot_id: int) -> tuple[str | None, str | None]:
    for s in site.enabled_slots:
        if int(s.id) == int(slot_id):
            reg = str(s.region).strip() if s.region else None
            ssid = str(s.ssid).strip() if s.ssid else None
            return (reg or None, ssid or None)
    return (None, None)


def _checkpoint_no_policy_route(
    site: SiteConfig,
    slot_id: int,
    routing_mark: str,
) -> dict[str, Any]:
    """Policy route row missing for *routing_mark* (read-only status or post-change race)."""

    region, ssid = _slot_labels(site, slot_id)
    um = (
        f"No policy route row found for routing mark {routing_mark!r}. "
        f"Bootstrap or add a marked default route for slot {slot_id}."
    )
    return {
        "status": "no_policy_route",
        "user_message": um,
        "summary": um,
        "slot_id": slot_id,
        "region": region,
        "ssid": ssid,
        "routing_mark": routing_mark,
        "gateway_interface": "",
        "policy_route_observed": None,
        "l2tp_client": None,
        "checks": {
            "policy_gateway_matches": False,
            "l2tp_tunnel_running": False,
        },
    }


def _checkpoint_policy_route_missing_gateway(
    site: SiteConfig,
    slot_id: int,
    routing_mark: str,
    pr: dict[str, Any],
) -> dict[str, Any]:
    """Terse row exists for the mark but ``gateway`` is empty (misconfigured route)."""

    region, ssid = _slot_labels(site, slot_id)
    reg_disp = region or "this slot"
    um = (
        f"A policy route row exists for {routing_mark!r} ({reg_disp}), but its gateway field is empty. "
        f"Fix the route on the router or re-run bootstrap for slot {slot_id}."
    )
    policy_observed = {
        "gateway": "",
        "routing_mark": str(pr.get("routing-mark", "")).strip() or None,
        "dst_address": str(pr.get("dst-address", "")).strip() or None,
    }
    return {
        "status": "policy_route_missing_gateway",
        "user_message": um,
        "summary": um,
        "slot_id": slot_id,
        "region": region,
        "ssid": ssid,
        "routing_mark": routing_mark,
        "gateway_interface": "",
        "policy_route_observed": policy_observed,
        "l2tp_client": None,
        "checks": {
            "policy_gateway_matches": False,
            "l2tp_tunnel_running": False,
        },
    }


def build_vpn_checkpoint(
    client: RouterClient,
    site: SiteConfig,
    slot_id: int,
    routing_mark: str,
    gateway_interface: str,
    *,
    route_rows: list[dict[str, Any]] | None = None,
    l2tp_rows: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Inspect live RouterOS state for a slot policy route and matching L2TP client.

    Use after ``update_policy_route_gateway`` (or for read-only status) to produce
    **user_message** / **summary** strings and structured **checks** for UI validation.

    * **region** / **ssid** come from **site JSON** (``slots[].region``), e.g. ``US`` / ``UK``.
    * **L2TP running** — terse row: ``running`` key or **R** in **flags** (RouterOS convention).
    """

    gw = gateway_interface.strip()
    region, ssid = _slot_labels(site, slot_id)

    if not gw:
        um = (
            f"No gateway interface resolved for slot {slot_id} "
            f"({region or 'unknown region'}). Check policy routes for mark {routing_mark!r}."
        )
        return {
            "status": "no_gateway",
            "user_message": um,
            "summary": um,
            "slot_id": slot_id,
            "region": region,
            "ssid": ssid,
            "routing_mark": routing_mark,
            "gateway_interface": "",
            "policy_route_observed": None,
            "l2tp_client": None,
            "checks": {
                "policy_gateway_matches": False,
                "l2tp_tunnel_running": False,
            },
        }

    if route_rows is None:
        route_rows = client.exec_print_terse("/ip route")
    if l2tp_rows is None:
        l2tp_rows = client.exec_print_terse("/interface l2tp-client")

    pr = _policy_route_for_mark(route_rows, routing_mark)
    live_gw = str(pr.get("gateway", "")).strip() if pr else ""

    l2tp = _l2tp_row_for_name(l2tp_rows, gw)
    tunnel_running = False
    l2tp_out: dict[str, Any] | None = None
    if l2tp:
        tunnel_running, running_raw_out = _l2tp_running_from_row(l2tp)
        ct = l2tp.get("connect-to")
        connect_to = str(ct).strip() if ct is not None and str(ct).strip() else ""
        flags_s = str(l2tp.get("flags", "")).strip()
        l2tp_out = {
            "name": str(l2tp.get("name", "")).strip(),
            "running": tunnel_running,
            "running_raw": running_raw_out,
            "flags": flags_s or None,
            "disabled": str(l2tp.get("disabled", "")).strip().lower() in ("true", "yes"),
            "connect_to": connect_to or None,
        }

    route_ok = _gw_equal(live_gw, gw) if pr else False

    reg_disp = region or "this slot"
    if l2tp_out and l2tp_out["disabled"] and route_ok:
        status = "tunnel_disabled"
        um = (
            f"L2TP interface {gw!r} is disabled on the router for {reg_disp}. "
            f"Enable it (``/interface l2tp-client enable [find name=…]``) or run ``mtk vpn-reset {gw}``."
        )
    elif route_ok and tunnel_running:
        status = "success"
        um = (
            f"Success: VPN path is active. Slot {slot_id} ({reg_disp}) uses {gw}; "
            f"L2TP tunnel is running (connected)."
        )
    elif route_ok and l2tp_out and not tunnel_running:
        status = "route_ok_tunnel_down"
        um = (
            f"Policy route points to {gw} for {reg_disp}, but the L2TP tunnel is not running yet "
            f"(still connecting or failed — check /interface l2tp-client or run mtk vpn-debug)."
        )
    elif route_ok and not l2tp_out:
        status = "route_ok_no_l2tp_row"
        um = (
            f"Policy route uses {gw}, but no L2TP client named {gw!r} was found on the router "
            f"(verify interface name matches mtk l2tp)."
        )
    elif not route_ok and pr:
        status = "route_mismatch"
        um = (
            f"Policy route for {routing_mark} shows gateway {live_gw!r}, expected {gw!r} "
            f"(slot region label: {reg_disp})."
        )
    else:
        return _checkpoint_no_policy_route(site, slot_id, routing_mark)

    policy_observed: dict[str, Any] | None = None
    if pr:
        policy_observed = {
            "gateway": live_gw,
            "routing_mark": str(pr.get("routing-mark", "")).strip() or None,
            "dst_address": str(pr.get("dst-address", "")).strip() or None,
        }

    tunnel_check = False if status == "tunnel_disabled" else tunnel_running

    return {
        "status": status,
        "user_message": um,
        "summary": um,
        "slot_id": slot_id,
        "region": region,
        "ssid": ssid,
        "routing_mark": routing_mark,
        "gateway_interface": gw,
        "policy_route_observed": policy_observed,
        "l2tp_client": l2tp_out,
        "checks": {
            "policy_gateway_matches": route_ok,
            "l2tp_tunnel_running": tunnel_check,
        },
    }


def read_slot_vpn_checkpoint(
    client: RouterClient,
    site: SiteConfig,
    slot_id: int,
    routing_mark: str,
) -> dict[str, Any]:
    """Read-only checkpoint: current policy-route gateway for the slot + L2TP row (no lease)."""

    route_rows = client.exec_print_terse("/ip route")
    pr = _policy_route_for_mark(route_rows, routing_mark)
    if pr is None:
        return _checkpoint_no_policy_route(site, slot_id, routing_mark)
    gw_live = str(pr.get("gateway", "")).strip()
    if not gw_live:
        return _checkpoint_policy_route_missing_gateway(site, slot_id, routing_mark, pr)
    return build_vpn_checkpoint(
        client,
        site,
        slot_id,
        routing_mark,
        gw_live,
        route_rows=route_rows,
    )
