"""Router-facing operations used by HTTP intents and automation."""

from mtk_router_sdk.ops.client_block import (
    block_client,
    is_client_blocked,
    list_blocked_clients,
    unblock_client,
)
from mtk_router_sdk.ops.slot_route import set_slot_vpn_gateway, update_policy_route_gateway
from mtk_router_sdk.ops.vpn_checkpoint import build_vpn_checkpoint, read_slot_vpn_checkpoint

__all__ = [
    "block_client",
    "build_vpn_checkpoint",
    "is_client_blocked",
    "list_blocked_clients",
    "read_slot_vpn_checkpoint",
    "set_slot_vpn_gateway",
    "unblock_client",
    "update_policy_route_gateway",
]
