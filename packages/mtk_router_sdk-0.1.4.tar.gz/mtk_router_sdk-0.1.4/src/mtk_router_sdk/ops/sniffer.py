"""RouterOS ``/tool sniffer`` — capture to a file with optional IPv4 filter."""

from __future__ import annotations

import re
from typing import Any

from mtk_router_sdk.bootstrap.engine import _ros_cli_ident
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.intent.runner import enabled_slot_by_id, enabled_slot_by_ssid
from mtk_router_sdk.models import ExecResult
from mtk_router_sdk.parsing import parse_print_block

_IPV4_RE = re.compile(
    r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}"
    r"(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$",
)

# Basename only — RouterOS stores under Files; no path separators.
_SAFE_FILE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,120}\.(?:pcap|cap)$")


class SnifferValidationError(ValueError):
    """Invalid IP, file name, or other caller input."""


def is_ipv4(s: str) -> bool:
    return bool(_IPV4_RE.fullmatch(s.strip()))


def default_capture_filename(slot_id: int, filter_ip: str) -> str:
    """Stable default ``.pcap`` name from slot + IP (underscores)."""

    ip_part = filter_ip.strip().replace(".", "_")
    return f"mtk_slot{int(slot_id)}_{ip_part}.pcap"


def validate_capture_filename(name: str) -> str:
    n = name.strip()
    if not _SAFE_FILE_RE.fullmatch(n):
        raise SnifferValidationError(
            "file_name must be a basename like mtk_dev.pcap "
            "(letters, digits, ._- only; .pcap or .cap)",
        )
    return n


def capture_interface_for_slot(site: Any, slot_id: int) -> str:
    s = enabled_slot_by_id(site, slot_id)
    return str(s.interface_name or f"slot_{s.id}")


def capture_interface_for_ssid(site: Any, ssid: str) -> str:
    s = enabled_slot_by_ssid(site, ssid)
    return str(s.interface_name or f"slot_{s.id}")


def sniffer_print(client: RouterClient, *, timeout: float | None = None) -> dict[str, str]:
    r = client.exec_command("/tool sniffer print", timeout=timeout, get_pty=False)
    if not r.ok:
        return {}
    return parse_print_block(r.stdout)


def sniffer_stop(client: RouterClient, *, timeout: float | None = None) -> ExecResult:
    return client.exec_command("/tool sniffer stop", timeout=timeout, get_pty=False)


def sniffer_start(
    client: RouterClient,
    *,
    interface: str,
    filter_ip: str,
    file_name: str,
    only_headers: bool = False,
    memory_limit: str | None = "100MiB",
    timeout: float | None = None,
) -> tuple[ExecResult, dict[str, str]]:
    """Stop any run, apply settings, start capture. Returns (last exec result, sniffer print)."""

    ip = filter_ip.strip()
    if not is_ipv4(ip):
        raise SnifferValidationError("filter_ip must be a dotted IPv4 address (RouterOS sniffer)")

    fn = validate_capture_filename(file_name)
    if not interface.strip():
        raise SnifferValidationError("interface is required")

    # Stop first (ignore failure — may already be stopped).
    client.exec_command("/tool sniffer stop", timeout=timeout, get_pty=False)

    oh = "yes" if only_headers else "no"
    parts = [
        "/tool sniffer set",
        f"file-name={_ros_cli_ident(fn)}",
        f"interface={_ros_cli_ident(interface.strip())}",
        f"filter-ip-address={_ros_cli_ident(ip)}",
        f"only-headers={oh}",
    ]
    if memory_limit and memory_limit.strip():
        parts.append(f"memory-limit={_ros_cli_ident(memory_limit.strip())}")
    set_cmd = " ".join(parts)
    r_set = client.exec_command(set_cmd, timeout=timeout, get_pty=False)
    if not r_set.ok:
        return r_set, sniffer_print(client, timeout=timeout)

    r_go = client.exec_command("/tool sniffer start", timeout=timeout, get_pty=False)
    snap = sniffer_print(client, timeout=timeout)
    return r_go, snap
