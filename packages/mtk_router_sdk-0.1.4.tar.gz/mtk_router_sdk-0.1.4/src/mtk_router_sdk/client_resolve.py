"""Map a client IPv4/IPv6 address to a slot using site subnets, DHCP server names, or fallbacks."""

from __future__ import annotations

import ipaddress
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from mtk_router_sdk.config.schema import SiteConfig, SlotConfig

_DHCP_SERVER_RE = re.compile(r"^dhcp_(\d+)$", re.IGNORECASE)


def infer_slot_for_lease_ip(ip_s: str, site: SiteConfig | None) -> int | None:
    """Return enabled *slot_id* whose ``subnet`` CIDR contains *ip_s*, or ``None``."""

    if not site or not ip_s:
        return None
    try:
        ip_a = ipaddress.ip_address(ip_s.split("/")[0].strip())
    except ValueError:
        return None
    for slot in site.enabled_slots:
        sub = (slot.subnet or "").strip()
        if not sub or "/" not in sub:
            continue
        try:
            net = ipaddress.ip_network(sub, strict=False)
            if ip_a in net:
                return int(slot.id)
        except ValueError:
            continue
    return None


def _normalize_ip(ip_s: str) -> str | None:
    s = ip_s.split("/")[0].strip()
    if not s:
        return None
    try:
        return str(ipaddress.ip_address(s))
    except ValueError:
        return None


def _lease_row_ip(row: Mapping[str, Any]) -> str | None:
    for k in ("active-address", "address"):
        raw = str(row.get(k, "")).strip()
        if raw:
            return _normalize_ip(raw)
    return None


def _enabled_slot(site: SiteConfig, slot_id: int) -> SlotConfig | None:
    for s in site.enabled_slots:
        if int(s.id) == int(slot_id):
            return s
    return None


def infer_slot_from_dhcp_server_name(server: str, site: SiteConfig) -> int | None:
    """Bootstrap uses ``dhcp_<slot_id>`` as DHCP server name."""

    name = str(server).strip()
    m = _DHCP_SERVER_RE.match(name)
    if not m:
        return None
    sid = int(m.group(1))
    return sid if _enabled_slot(site, sid) is not None else None


@dataclass(frozen=True, slots=True)
class ClientSlotResolution:
    """Result of resolving a client address to an enabled slot."""

    resolved: bool
    client_ip: str
    slot_id: int | None = None
    ssid: str | None = None
    routing_mark: str | None = None
    interface_name: str | None = None
    match_method: str = "none"
    dhcp_server: str | None = None

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "resolved": self.resolved,
            "client_ip": self.client_ip,
            "match_method": self.match_method,
        }
        if self.slot_id is not None:
            d["slot_id"] = self.slot_id
        if self.ssid is not None:
            d["ssid"] = self.ssid
        if self.routing_mark is not None:
            d["routing_mark"] = self.routing_mark
        if self.interface_name is not None:
            d["interface_name"] = self.interface_name
        if self.dhcp_server is not None:
            d["dhcp_server"] = self.dhcp_server
        return d


def _context_from_slot(
    site: SiteConfig, slot_id: int, client_ip: str, match_method: str
) -> ClientSlotResolution:
    s = _enabled_slot(site, slot_id)
    if s is None:
        return ClientSlotResolution(resolved=False, client_ip=client_ip, match_method="none")
    return ClientSlotResolution(
        resolved=True,
        client_ip=client_ip,
        slot_id=int(s.id),
        ssid=str(s.ssid),
        routing_mark=str(s.routing_mark or f"rt_slot_{s.id}"),
        interface_name=str(s.interface_name) if s.interface_name else f"slot_{s.id}",
        match_method=match_method,
    )


def resolve_client_slot(
    site: SiteConfig,
    client_ip: str,
    *,
    dhcp_rows: list[dict[str, Any]] | None = None,
    env: Mapping[str, str] | None = None,
) -> ClientSlotResolution:
    """Resolve *client_ip* to an enabled slot.

    Order:

    1. **subnet_cidr** — ``slots[].subnet`` on enabled slots.
    2. **dhcp_server** — DHCP lease row with server ``dhcp_<id>`` (bootstrap).
    3. **site_fallback** — ``global.client_fallback_slot_id`` (enabled only).
    4. **env_fallback** — ``MTK_CLIENT_FALLBACK_SLOT_ID`` (enabled only).

    Wi‑Fi and Ethernet clients are treated the same.
    """

    env = env if env is not None else os.environ
    norm = _normalize_ip(client_ip)
    if norm is None:
        return ClientSlotResolution(resolved=False, client_ip=client_ip, match_method="none")

    sid = infer_slot_for_lease_ip(norm, site)
    if sid is not None:
        return _context_from_slot(site, sid, norm, "subnet_cidr")

    if dhcp_rows:
        for row in dhcp_rows:
            row_ip = _lease_row_ip(row)
            if row_ip is None or row_ip != norm:
                continue
            srv = str(row.get("server", "")).strip()
            dsid = infer_slot_from_dhcp_server_name(srv, site)
            if dsid is not None:
                ctx = _context_from_slot(site, dsid, norm, "dhcp_server")
                return ClientSlotResolution(
                    resolved=ctx.resolved,
                    client_ip=ctx.client_ip,
                    slot_id=ctx.slot_id,
                    ssid=ctx.ssid,
                    routing_mark=ctx.routing_mark,
                    interface_name=ctx.interface_name,
                    match_method=ctx.match_method,
                    dhcp_server=srv or None,
                )

    fb_site = site.global_.client_fallback_slot_id
    if fb_site is not None:
        s = _enabled_slot(site, int(fb_site))
        if s is not None:
            return _context_from_slot(site, int(s.id), norm, "site_fallback")

    raw_env = str(env.get("MTK_CLIENT_FALLBACK_SLOT_ID", "")).strip()
    if raw_env.isdigit():
        s = _enabled_slot(site, int(raw_env))
        if s is not None:
            return _context_from_slot(site, int(s.id), norm, "env_fallback")

    return ClientSlotResolution(resolved=False, client_ip=norm, match_method="none")
