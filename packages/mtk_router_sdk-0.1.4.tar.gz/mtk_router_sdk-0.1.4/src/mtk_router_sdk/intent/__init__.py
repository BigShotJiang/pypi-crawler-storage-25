"""Structured intents (spec §3.8.4) — validate and execute via the service."""

from mtk_router_sdk.intent.runner import (
    IntentExecutionError,
    enabled_slot_by_id,
    enabled_slot_by_ssid,
    routing_mark_for_slot,
    run_intents,
)

__all__ = [
    "IntentExecutionError",
    "enabled_slot_by_id",
    "enabled_slot_by_ssid",
    "routing_mark_for_slot",
    "run_intents",
]
