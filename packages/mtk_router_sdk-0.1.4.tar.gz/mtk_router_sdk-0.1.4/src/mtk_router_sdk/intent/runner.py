"""Execute a batch of allow-listed intents (SSH side effects)."""

from __future__ import annotations

import os
from typing import Any

from mtk_router_sdk.bootstrap import BootstrapEngine
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.control.leases import LeaseConflictError, SlotLeaseManager
from mtk_router_sdk.exceptions import ConfigurationError, MtkRouterError
from mtk_router_sdk.ops.slot_route import update_policy_route_gateway
from mtk_router_sdk.ops.vpn_checkpoint import build_vpn_checkpoint


class IntentExecutionError(Exception):
    """Intent chain aborted (caller maps to HTTP 4xx/5xx)."""

    def __init__(self, message: str, *, status_code: int = 400) -> None:
        super().__init__(message)
        self.status_code = status_code


def enabled_slot_by_id(site: Any, slot_id: int) -> Any:
    for s in site.enabled_slots:
        if int(s.id) == int(slot_id):
            return s
    raise IntentExecutionError(f"unknown enabled slot_id {slot_id!r}")


def enabled_slot_by_ssid(site: Any, ssid: str) -> Any:
    """Resolve **enabled** slot by **exact** SSID string from site JSON (not router scan).

    Only SSIDs declared on enabled slots are valid — you cannot target arbitrary Wi‑Fi on the box.
    """

    target = str(ssid).strip()
    if not target:
        raise IntentExecutionError("ssid must be non-empty", status_code=400)
    matches = [s for s in site.enabled_slots if str(s.ssid) == target]
    if not matches:
        raise IntentExecutionError(
            f"no enabled slot with ssid {target!r} (must match site JSON exactly)",
            status_code=400,
        )
    if len(matches) > 1:
        raise IntentExecutionError(
            f"ambiguous ssid {target!r}: {len(matches)} enabled slots use it; fix site JSON",
            status_code=400,
        )
    return matches[0]


def routing_mark_for_slot(site: Any, slot_id: int) -> str:
    s = enabled_slot_by_id(site, slot_id)
    return str(s.routing_mark or f"rt_slot_{s.id}")


def run_intents(
    intents: list[dict[str, Any]],
    *,
    client: RouterClient,
    site: Any | None,
    leases: SlotLeaseManager,
    actor: str,
    env: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """Run intents in order. Per ``SetSlotVpn``, acquires a lease unless ``_lease_token`` is set."""

    out: list[dict[str, Any]] = []
    env = env or dict(os.environ)

    try:
        for raw in intents:
            t = str(raw.get("type", "")).strip()
            if t == "RefreshDiscovery":
                prof = client.discover()
                out.append({"type": t, "ok": True, "profile": prof.as_dict()})
            elif t == "BootstrapDryRun":
                if site is None:
                    raise IntentExecutionError("site config required", status_code=400)
                prof = client.discover()
                plan = BootstrapEngine().plan(site, prof, env=env)
                out.append({"type": t, "ok": True, "plan": plan.as_dict()})
            elif t == "BootstrapApply":
                if site is None:
                    raise IntentExecutionError("site config required", status_code=400)
                prof = client.discover()
                plan = BootstrapEngine().plan(site, prof, env=env)
                BootstrapEngine.apply(client, plan, dry_run=False)
                out.append({"type": t, "ok": True, "steps": len(plan.steps)})
            elif t == "SetSlotVpn":
                if site is None:
                    raise IntentExecutionError("site config required", status_code=400)
                slot_id = int(raw["slot_id"])
                mode = str(raw.get("mode", "route"))
                if mode != "route":
                    raise IntentExecutionError("only mode=route is supported", status_code=400)
                gw = str(raw.get("gateway_interface", "")).strip()
                if not gw:
                    raise IntentExecutionError("gateway_interface required", status_code=400)
                mark = routing_mark_for_slot(site, slot_id)
                lease_hdr = str(raw.get("_lease_token", "")).strip()
                own = False
                tok = ""
                if lease_hdr:
                    if not leases.validate(slot_id, lease_hdr):
                        raise IntentExecutionError("invalid lease token", status_code=403)
                else:
                    try:
                        ac = leases.acquire(slot_id, actor, ttl_s=120.0)
                        tok = str(ac["lease_token"])
                        own = True
                    except LeaseConflictError as e:
                        raise IntentExecutionError(
                            str(e),
                            status_code=409,
                        ) from e
                try:
                    r = update_policy_route_gateway(
                        client,
                        routing_mark=mark,
                        gateway_interface=gw,
                    )
                    if not r.ok:
                        raise IntentExecutionError(
                            f"route update failed: {r.stderr or r.stdout}",
                            status_code=502,
                        )
                    checkpoint = build_vpn_checkpoint(client, site, slot_id, mark, gw)
                    out.append(
                        {
                            "type": t,
                            "ok": True,
                            "slot_id": slot_id,
                            "gateway_interface": gw,
                            "checkpoint": checkpoint,
                        },
                    )
                finally:
                    if own and tok:
                        leases.release(slot_id, tok)
            else:
                raise IntentExecutionError(f"unknown intent type {t!r}", status_code=400)
    except LeaseConflictError:
        raise
    except (MtkRouterError, ConfigurationError) as e:
        raise IntentExecutionError(str(getattr(e, "message", e)), status_code=502) from e

    return out
