"""Tests for mtk_router_sdk.config.env_parse."""

from __future__ import annotations

import pytest

from mtk_router_sdk.config.env_parse import parse_float_env, parse_int_env
from mtk_router_sdk.exceptions import ConfigurationError


def test_parse_int_env_default_and_custom_env() -> None:
    assert parse_int_env("MTK_HTTP_PORT", 8765, env={}) == 8765
    assert parse_int_env("MTK_HTTP_PORT", 8765, env={"MTK_HTTP_PORT": ""}) == 8765
    assert parse_int_env("MTK_HTTP_PORT", 8765, env={"MTK_HTTP_PORT": " 9000 "}) == 9000


def test_parse_int_env_invalid() -> None:
    with pytest.raises(ConfigurationError, match="integer"):
        parse_int_env("MTK_HTTP_PORT", 8765, env={"MTK_HTTP_PORT": "nope"})


def test_parse_int_env_out_of_range() -> None:
    with pytest.raises(ConfigurationError, match="out of range"):
        parse_int_env("MTK_HTTP_PORT", 8765, env={"MTK_HTTP_PORT": "0"})
    with pytest.raises(ConfigurationError, match="out of range"):
        parse_int_env("MTK_HTTP_PORT", 8765, env={"MTK_HTTP_PORT": "70000"})


def test_parse_float_env() -> None:
    assert parse_float_env("MTK_PROXY_TIMEOUT", 30.0, env={}) == 30.0
    assert parse_float_env("MTK_PROXY_TIMEOUT", 30.0, env={"MTK_PROXY_TIMEOUT": "1.5"}) == 1.5
    with pytest.raises(ConfigurationError, match="number"):
        parse_float_env("MTK_PROXY_TIMEOUT", 30.0, env={"MTK_PROXY_TIMEOUT": "x"})
    with pytest.raises(ConfigurationError, match="out of range"):
        parse_float_env("MTK_PROXY_TIMEOUT", 30.0, env={"MTK_PROXY_TIMEOUT": "-1"})
