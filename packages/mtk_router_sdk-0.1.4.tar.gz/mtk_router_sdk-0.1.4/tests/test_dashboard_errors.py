"""Structured dashboard API error mapping."""

from __future__ import annotations

import json

from mtk_router_sdk.testing.dashboard_errors import (
    MODULE_PROXY,
    enrich_routeros_block,
    problem_from_exception,
    problem_validation,
)
from mtk_router_sdk.testing.http_api import TestingServiceHttpError as ServiceHttpError


def test_problem_validation_has_hints() -> None:
    r = problem_validation("dns", "domain is required")
    assert r.status_code == 400
    body = json.loads(r.body.decode())
    assert body["ok"] is False
    assert body["module"] == "dns"
    assert "hints" in body
    assert len(body["hints"]) >= 1
    assert body["user_message"] == "domain is required"


def test_enrich_routeros_block() -> None:
    r = enrich_routeros_block(
        {
            "compat_message": "No router",
            "compat_hint": "Set MTK_ROUTER_HOST",
        }
    )
    assert r.status_code == 403
    body = json.loads(r.body.decode())
    assert body["unsupported"] is True
    assert "Set MTK_ROUTER_HOST" in body["hints"][0]


def test_from_testing_service_http_401() -> None:
    exc = ServiceHttpError("nope", status_code=401, body={})
    r = problem_from_exception(MODULE_PROXY, exc)
    assert r.status_code == 401
    body = json.loads(r.body.decode())
    assert body["code"] == "MTK_SERVE_UNAUTHORIZED"
    assert "MTK_SERVE_TOKEN" in " ".join(body["hints"])


def test_from_testing_service_unreachable() -> None:
    exc = ServiceHttpError(
        "Cannot reach mtk-serve at http://127.0.0.1:9: [Errno 61] Connection refused"
    )
    r = problem_from_exception(MODULE_PROXY, exc)
    assert r.status_code in (500, 502, 503)
    body = json.loads(r.body.decode())
    assert "connection refused" in body["user_message"].lower() or "refused" in body["title"].lower()
