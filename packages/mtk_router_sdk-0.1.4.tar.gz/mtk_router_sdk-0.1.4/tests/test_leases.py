from __future__ import annotations

import threading
import time

import pytest

from mtk_router_sdk.control.leases import LeaseConflictError, SlotLeaseManager


def test_lease_acquire_release() -> None:
    m = SlotLeaseManager(mode="reject")
    a = m.acquire(1, "u1", 60.0)
    assert "lease_token" in a
    assert m.validate(1, a["lease_token"])
    assert m.release(1, a["lease_token"])
    assert not m.validate(1, a["lease_token"])


def test_release_by_token() -> None:
    m = SlotLeaseManager(mode="reject")
    a = m.acquire(3, "u", 60.0)
    tok = a["lease_token"]
    assert m.release_by_token(tok)
    assert not m.validate(3, tok)
    assert not m.release_by_token(tok)


def test_lease_reject_second_holder() -> None:
    m = SlotLeaseManager(mode="reject")
    m.acquire(1, "a", 60.0)
    with pytest.raises(LeaseConflictError):
        m.acquire(1, "b", 60.0)


def test_fifo_second_acquire_after_release() -> None:
    m = SlotLeaseManager(mode="fifo_queue")
    t1 = m.acquire(1, "a", 120.0)["lease_token"]
    results: list[str] = []

    def waiter() -> None:
        b = m.acquire(1, "b", 120.0)
        results.append(b["lease_token"])

    th = threading.Thread(target=waiter)
    th.start()
    time.sleep(0.05)
    m.release(1, t1)
    th.join(timeout=5.0)
    assert len(results) == 1
