from __future__ import annotations

import json

from starlette.testclient import TestClient

from mtk_router_sdk import __version__
from mtk_router_sdk.service.app import create_app
from mtk_router_sdk.service.openapi_spec import build_openapi_spec


def test_openapi_spec_matches_implemented_routes() -> None:
    spec = build_openapi_spec(sdk_version=__version__)
    assert spec["openapi"] == "3.1.0"
    for path in ("/", "/healthz", "/openapi.json", "/v1/version", "/v1/doctor"):
        assert path in spec["paths"]
    assert "/v1/dashboard/snapshot" in spec["paths"]
    assert "/v1/slots/{slot_id}/sniffer/start" in spec["paths"]
    assert "/v1/by-ssid/vpn" in spec["paths"]
    assert "/v1/client/resolve" in spec["paths"]
    assert "/v1/by-client/vpn" in spec["paths"]
    assert "/v1/slots/{slot_id}/vpn/status" in spec["paths"]
    assert "/readyz" in spec["paths"]
    assert "/v1/capabilities" in spec["paths"]
    assert "/v1/lan/host-peers" in spec["paths"]
    assert "Readyz" in spec["components"]["schemas"]
    readyz_200 = spec["paths"]["/readyz"]["get"]["responses"]["200"]
    assert "content" in readyz_200


def test_http_contract_healthz_version_openapi() -> None:
    client = TestClient(create_app())
    assert client.get("/healthz").json() == {"status": "ok"}
    body = client.get("/v1/version").json()
    assert body == {"version": __version__}
    spec = client.get("/openapi.json").json()
    assert spec["info"]["version"] == __version__
    assert "/healthz" in spec["paths"]


def test_root_index_links() -> None:
    client = TestClient(create_app())
    r = client.get("/")
    assert r.status_code == 200
    data = r.json()
    assert data["openapi"] == "/openapi.json"
    assert data["doctor"] == "/v1/doctor"
    assert data.get("readyz") == "/readyz"
    assert data.get("dashboard") == "/dashboard/"
    assert data.get("capabilities") == "/v1/capabilities"
    assert data.get("lan_host_peers") == "/v1/lan/host-peers"


def test_capabilities_json_shape() -> None:
    client = TestClient(create_app())
    r = client.get("/v1/capabilities")
    assert r.status_code == 200
    data = r.json()
    assert data["sdk_version"] == __version__
    assert "credentials_complete" in data["router_ssh"]
    assert "features" in data
    snap = data["features"]["dashboard_snapshot"]
    assert snap["requires_router_ssh"] is True
    assert "blocked_without_router_ssh" in snap
    peers = data["features"]["lan_host_peers"]
    assert peers["requires_router_ssh"] is False
    assert peers["blocked_without_router_ssh"] is False


def test_lan_host_peers_returns_json() -> None:
    client = TestClient(create_app())
    r = client.get("/v1/lan/host-peers")
    assert r.status_code == 200
    data = r.json()
    assert "source" in data
    assert "peers" in data
    assert "dashboard_devices" in data


def test_dashboard_static_served() -> None:
    client = TestClient(create_app())
    r = client.get("/dashboard/")
    assert r.status_code == 200
    assert b"dashboard" in r.content.lower()


def test_stream_websocket_sends_hello() -> None:
    client = TestClient(create_app())
    with client.websocket_connect("/v1/stream") as ws:
        msg = json.loads(ws.receive_text())
        assert msg.get("type") == "hello"


def test_doctor_returns_json_with_ok_field() -> None:
    client = TestClient(create_app())
    r = client.get("/v1/doctor")
    assert r.headers.get("content-type", "").startswith("application/json")
    data = r.json()
    assert "ok" in data
    assert r.status_code == (200 if data["ok"] else 503)
