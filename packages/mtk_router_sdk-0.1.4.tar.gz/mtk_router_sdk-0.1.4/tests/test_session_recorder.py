"""SessionRecorder helpers (HAR capture from proxy log)."""

from __future__ import annotations

import pytest

from mtk_router_sdk.proxy import ProxyManager
from mtk_router_sdk.testing.recording import SessionRecorder


def test_stop_for_client_stops_matching_session(tmp_path) -> None:
    rec = SessionRecorder(proxy=ProxyManager(), recordings_dir=tmp_path)
    rec.start("10.0.0.5", name="t1")
    out = rec.stop_for_client("10.0.0.5")
    assert out.is_file()
    assert out.suffix == ".har"


def test_stop_for_client_unknown_ip_raises(tmp_path) -> None:
    rec = SessionRecorder(proxy=ProxyManager(), recordings_dir=tmp_path)
    with pytest.raises(ValueError, match="No active recording"):
        rec.stop_for_client("192.168.1.1")
