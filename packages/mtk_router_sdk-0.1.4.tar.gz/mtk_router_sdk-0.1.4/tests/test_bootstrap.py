from __future__ import annotations

import pytest

from conftest import RecordingTransport
from mtk_router_sdk.bootstrap import BootstrapEngine
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config.load import load_site_config
from mtk_router_sdk.discovery.models import RouterCapabilityProfile, WirelessSummary
from mtk_router_sdk.exceptions import ConfigurationError
from mtk_router_sdk.models import ConnectionConfig


def _profile() -> RouterCapabilityProfile:
    return RouterCapabilityProfile(
        identity_name="MikroTik",
        routeros_version="6.49.17 (stable)",
        board_name="hAP ac^2",
        architecture="",
        cpu="arm",
        cpu_count="4",
        cpu_load="0%",
        free_memory="10MiB",
        total_memory="128MiB",
        uptime="1h",
        wireless=WirelessSummary(
            interface_names=["wlan1", "wlan2"],
            master_interface_names=["wlan1", "wlan2"],
            has_wireless=True,
            menu_kind="wireless",
        ),
    )


def test_bootstrap_l2tp_uses_slot_tunnel_name() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "us.vpn.test"},
            "bootstrap": {"provision_tunnels": "required_only"},
            "slots": [
                {
                    "id": 1,
                    "enabled": True,
                    "ssid": "Net-US",
                    "region": "USA",
                    "tunnel_name": "corp_us",
                },
            ],
        },
        env=env,
    )
    plan = BootstrapEngine().plan(site, _profile(), env=env)
    l2 = [s for s in plan.steps if s.phase == "l2tp"]
    assert len(l2) == 1
    assert l2[0].payload["tname"] == "corp_us"
    nat = [s for s in plan.steps if s.phase == "slot_nat"]
    assert nat[0].payload["tname"] == "corp_us"


def test_bootstrap_rejects_conflicting_tunnel_names_same_region() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "us.vpn.test"},
            "bootstrap": {"provision_tunnels": "required_only"},
            "slots": [
                {
                    "id": 1,
                    "enabled": True,
                    "ssid": "A",
                    "region": "USA",
                    "tunnel_name": "vpn_a",
                },
                {
                    "id": 2,
                    "enabled": True,
                    "ssid": "B",
                    "region": "USA",
                    "tunnel_name": "vpn_b",
                },
            ],
        },
        env=env,
    )
    with pytest.raises(ConfigurationError):
        BootstrapEngine().plan(site, _profile(), env=env)


def test_bootstrap_plan_contains_phases() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "us.vpn.test"},
            "bootstrap": {"provision_tunnels": "required_only"},
            "slots": [
                {"id": 1, "enabled": True, "ssid": "Net-US", "region": "USA"},
            ],
        },
        env=env,
    )
    plan = BootstrapEngine().plan(site, _profile(), env=env)
    phases = {s.phase for s in plan.steps}
    assert "wifi_security" in phases
    assert "l2tp" in phases
    assert "slot_wlan" in phases
    assert "slot_ssh_allow" in phases
    assert "slot_input_ssh" in phases
    assert "slot_nat" in phases


def test_bootstrap_plan_no_tunnels_when_none() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "us.vpn.test"},
            "bootstrap": {"provision_tunnels": "none"},
            "slots": [
                {"id": 1, "enabled": True, "ssid": "Net-US", "region": "USA"},
            ],
        },
        env=env,
    )
    plan = BootstrapEngine().plan(site, _profile(), env=env)
    assert not any(s.phase == "l2tp" for s in plan.steps)


def test_bootstrap_plan_rejects_no_wireless() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "x"},
            "slots": [{"id": 1, "enabled": True, "ssid": "S", "region": "USA"}],
        },
        env=env,
    )
    profile = RouterCapabilityProfile(
        identity_name="x",
        routeros_version="6",
        board_name=None,
        architecture="",
        cpu="",
        cpu_count="",
        cpu_load="",
        free_memory="",
        total_memory="",
        uptime="",
        wireless=WirelessSummary(),
    )
    with pytest.raises(ConfigurationError):
        BootstrapEngine().plan(site, profile, env=env)


def test_bootstrap_apply_executes_commands() -> None:
    env = {
        "MTK_WIFI_PSK": "psk",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "us.vpn.test"},
            "bootstrap": {"provision_tunnels": "none"},
            "slots": [{"id": 1, "enabled": True, "ssid": "S", "region": "USA"}],
        },
        env=env,
    )
    plan = BootstrapEngine().plan(site, _profile(), env=env)
    rec = RecordingTransport()
    c = RouterClient(rec)
    c.connect(ConnectionConfig(host="h", username="u", password="p"))
    try:
        BootstrapEngine.apply(c, plan, dry_run=False)
    finally:
        c.disconnect()
    # Each imperative step runs ``print terse`` then add/set (or noop without second call).
    assert len(rec.commands) >= len(plan.steps)
    assert len(rec.commands) <= 2 * len(plan.steps)
    assert any("security-profiles" in c for c in rec.commands)
    assert any("dst-address-type=!local" in c for c in rec.commands)
    assert any("/ip service" in c for c in rec.commands)
    assert any("/ip firewall filter" in c for c in rec.commands)
