from __future__ import annotations

import ipaddress
import sys

from mtk_router_sdk.net.lan_scapy import parse_extra_scapy_cidrs, scapy_arp_sweep


def test_parse_extra_scapy_cidrs() -> None:
    raw = "192.168.1.0/24, en0:10.0.0.0/28"
    rows = parse_extra_scapy_cidrs(raw)
    assert any(str(n[1]) == "192.168.1.0/24" for n in rows)
    assert any(n[0] == "en0" and str(n[1]) == "10.0.0.0/28" for n in rows)


def test_scapy_arp_sweep_monkeypatched(monkeypatch) -> None:
    class FakeRecv:
        psrc = "192.168.1.50"
        hwsrc = "aa:bb:cc:dd:ee:ff"

    class FakeAns:
        def __iter__(self):
            return iter([(None, FakeRecv())])

    def fake_srp(_pkt, **kwargs: object) -> tuple[FakeAns, list]:
        return FakeAns(), []

    fake_mod = type(sys)("fake_scapy")

    class ARP:
        def __init__(self, pdst: str = "") -> None:
            self.pdst = pdst

        def __truediv__(self, _o: object) -> object:
            return self

    class Ether:
        def __init__(self, dst: str = "") -> None:
            self.dst = dst

        def __truediv__(self, other: object) -> object:
            return ("pkt", self, other)

    fake_mod.ARP = ARP
    fake_mod.Ether = Ether
    fake_mod.srp = fake_srp

    monkeypatch.setitem(sys.modules, "scapy.all", fake_mod)

    net = ipaddress.ip_network("192.168.1.0/29", strict=False)
    res = scapy_arp_sweep([(None, net)], timeout=1.0, max_networks=1)
    assert len(res["peers"]) == 1
    assert res["peers"][0].ip == "192.168.1.50"
    assert res["peers"][0].source == "scapy_arp"
