from __future__ import annotations

import argparse

import pytest

from mtk_router_sdk.cli import (
    _normalize_router_text,
    _print_vpn_debug_human,
    _redact_router_cli_secrets,
    _vpn_debug_tunnel_arg,
)
from mtk_router_sdk.models import ExecResult


def test_redact_router_cli_secrets_strips_password_fields() -> None:
    s = 'password=MyPass99 ipsec-secret=MyPsk00 user=u\npassword="x"'
    o = _redact_router_cli_secrets(s)
    assert "MyPass99" not in o
    assert "MyPsk00" not in o
    assert o.count("<redacted>") >= 2


def test_vpn_debug_tunnel_arg_accepts_safe_names() -> None:
    assert _vpn_debug_tunnel_arg("vpn_usa") == "vpn_usa"
    assert _vpn_debug_tunnel_arg("  vpn-1  ") == "vpn-1"


def test_vpn_debug_tunnel_arg_rejects_injection() -> None:
    with pytest.raises(argparse.ArgumentTypeError):
        _vpn_debug_tunnel_arg("x;drop")


def test_normalize_router_text_crlf() -> None:
    assert _normalize_router_text("a\r\nb\rc") == "a\nb\nc"


def test_print_vpn_debug_human_writes_sections(capsys) -> None:
    _print_vpn_debug_human(
        {
            "tunnel": "t1",
            "target": "192.168.1.1",
            "steps": [
                {
                    "label": "ping",
                    "exit_status": 0,
                    "stdout": "seq=0\r\ntime=1ms\r\n",
                    "stderr": "",
                },
            ],
        },
    )
    out = capsys.readouterr().out
    assert "--- ping  (exit 0) ---" in out
    assert "seq=0" in out
    assert "time=1ms" in out
    assert "\r\n" not in out


def test_exec_result_tail_truncation_helper() -> None:
    from mtk_router_sdk.cli import _exec_json_dict

    long = "a" * 100 + "ENDMARKER"
    r = ExecResult(long, "", 0)
    d = _exec_json_dict("t", r, max_stdout=50, tail=True, redact=False)
    assert "ENDMARKER" in d["stdout"]
    assert "truncated" in d["stdout"]
