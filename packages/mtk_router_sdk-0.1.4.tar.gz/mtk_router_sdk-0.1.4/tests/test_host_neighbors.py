from __future__ import annotations

from mtk_router_sdk.net.host_neighbors import (
    parse_arp_a_output,
    parse_proc_net_arp,
)


def test_parse_proc_net_arp_skips_lo_and_zero_mac() -> None:
    sample = """IP address       HW type     Flags       HW address            Mask     Device
192.168.1.1      0x1         0x2         aa:bb:cc:dd:ee:ff     *        eth0
10.0.0.5        0x1         0x0         00:00:00:00:00:00     *        wlan0
127.0.0.1       0x1         0x0         00:00:00:00:00:00     *        lo
"""
    peers = parse_proc_net_arp(sample)
    ips = {p.ip for p in peers}
    assert "192.168.1.1" in ips
    assert "10.0.0.5" in ips
    assert "127.0.0.1" not in ips


def test_parse_arp_a_macos_style() -> None:
    sample = (
        "? (192.168.88.50) at aa:bb:cc:dd:ee:ff on en0 ifscope [ethernet]\n"
        "? (192.168.88.2) at (incomplete) on en0 ifscope [ethernet]\n"
    )
    peers = parse_arp_a_output(sample)
    ips = {p.ip for p in peers}
    assert "192.168.88.50" in ips
    assert "192.168.88.2" in ips
    macs = {p.ip: p.mac for p in peers}
    assert macs["192.168.88.50"] == "aa:bb:cc:dd:ee:ff"
    assert macs["192.168.88.2"] is None
