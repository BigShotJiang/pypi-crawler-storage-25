from mtk_router_sdk.parsing.keyvalue import parse_print_block


def test_parse_identity_block() -> None:
    text = """
  name: MikroTik
  bad line without colon
  foo: bar
"""
    d = parse_print_block(text)
    assert d["name"] == "MikroTik"
    assert d["foo"] == "bar"
