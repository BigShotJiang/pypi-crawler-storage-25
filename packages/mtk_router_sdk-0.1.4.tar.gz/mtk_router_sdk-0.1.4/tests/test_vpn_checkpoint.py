from __future__ import annotations

from unittest.mock import MagicMock

from mtk_router_sdk.config import load_site_config
from mtk_router_sdk.ops.vpn_checkpoint import (
    build_vpn_checkpoint,
    read_slot_vpn_checkpoint,
)


def _site_us_uk() -> object:
    return load_site_config(
        {
            "version": 1,
            "global": {
                "max_slots": 8,
                "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
                "vpn_credentials": {"user_ref": "env:U", "password_ref": "env:P"},
            },
            "vpn_registry": {"USA": "h1", "UK": "h2"},
            "bootstrap": {"provision_tunnels": "none"},
            "slots": [
                {
                    "id": 2,
                    "enabled": True,
                    "ssid": "Guest",
                    "region": "USA",
                    "tunnel_name": "vpn_usa",
                },
            ],
        },
        env={"X": "a", "U": "b", "P": "c"},
    )


def test_build_checkpoint_success_all_green() -> None:
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk", "dst-address": "0.0.0.0/0"}]
    l2tp = [{"name": "l2tp-uk", "running": "true", "disabled": "false", "connect-to": "uk.vpn.example"}]
    cp = build_vpn_checkpoint(
        client,
        site,
        2,
        "rt_slot_2",
        "l2tp-uk",
        route_rows=routes,
        l2tp_rows=l2tp,
    )
    assert cp["status"] == "success"
    assert cp["checks"]["policy_gateway_matches"] is True
    assert cp["checks"]["l2tp_tunnel_running"] is True
    assert cp["region"] == "USA"
    assert "Success" in cp["user_message"]
    client.exec_print_terse.assert_not_called()


def test_build_checkpoint_success_terse_r_flag_no_running_key() -> None:
    """RouterOS ``print terse`` often uses ``R`` in flags instead of ``running=yes``."""
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}]
    l2tp = [{"name": "l2tp-uk", "flags": "R", "connect-to": "uk.vpn.example"}]
    cp = build_vpn_checkpoint(
        client,
        site,
        2,
        "rt_slot_2",
        "l2tp-uk",
        route_rows=routes,
        l2tp_rows=l2tp,
    )
    assert cp["status"] == "success"
    assert cp["checks"]["l2tp_tunnel_running"] is True
    assert cp["l2tp_client"]["running_raw"] == "R"
    assert cp["l2tp_client"]["flags"] == "R"


def test_build_checkpoint_tunnel_down() -> None:
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "l2tp-us"}]
    l2tp = [{"name": "l2tp-us", "running": "false", "disabled": "false"}]
    cp = build_vpn_checkpoint(
        client,
        site,
        2,
        "rt_slot_2",
        "l2tp-us",
        route_rows=routes,
        l2tp_rows=l2tp,
    )
    assert cp["status"] == "route_ok_tunnel_down"
    assert cp["checks"]["l2tp_tunnel_running"] is False


def test_build_checkpoint_gateway_case_insensitive() -> None:
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "L2TP-UK"}]
    l2tp = [{"name": "l2tp-uk", "running": "true"}]
    cp = build_vpn_checkpoint(
        client,
        site,
        2,
        "rt_slot_2",
        "l2tp-uk",
        route_rows=routes,
        l2tp_rows=l2tp,
    )
    assert cp["status"] == "success"
    assert cp["checks"]["policy_gateway_matches"] is True


def test_build_checkpoint_tunnel_disabled() -> None:
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}]
    l2tp = [{"name": "l2tp-uk", "running": "false", "disabled": "true"}]
    cp = build_vpn_checkpoint(
        client,
        site,
        2,
        "rt_slot_2",
        "l2tp-uk",
        route_rows=routes,
        l2tp_rows=l2tp,
    )
    assert cp["status"] == "tunnel_disabled"
    assert cp["checks"]["l2tp_tunnel_running"] is False


def test_read_slot_vpn_checkpoint_no_route_row() -> None:
    site = _site_us_uk()
    client = MagicMock()
    client.exec_print_terse.return_value = []
    cp = read_slot_vpn_checkpoint(client, site, 2, "rt_slot_2")
    assert cp["status"] == "no_policy_route"
    assert cp["gateway_interface"] == ""
    client.exec_print_terse.assert_called_once_with("/ip route")


def test_read_slot_vpn_checkpoint_empty_gateway_field() -> None:
    site = _site_us_uk()
    client = MagicMock()
    rows = [{"routing-mark": "rt_slot_2", "gateway": "", "dst-address": "0.0.0.0/0"}]
    client.exec_print_terse.return_value = rows
    cp = read_slot_vpn_checkpoint(client, site, 2, "rt_slot_2")
    assert cp["status"] == "policy_route_missing_gateway"
    assert cp["policy_route_observed"]["gateway"] == ""


def test_read_slot_vpn_checkpoint() -> None:
    site = _site_us_uk()
    client = MagicMock()
    routes = [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}]
    l2tp = [{"name": "l2tp-uk", "running": "true"}]

    def _terse(menu: str, **_k: object) -> list[dict]:
        if "route" in menu:
            return routes
        if "l2tp" in menu:
            return l2tp
        return []

    client.exec_print_terse.side_effect = _terse
    cp = read_slot_vpn_checkpoint(client, site, 2, "rt_slot_2")
    assert cp["gateway_interface"] == "l2tp-uk"
    assert cp["status"] == "success"
