from __future__ import annotations

from conftest import FakeTransport, SpyTransport
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.discovery import DiscoveryService
from mtk_router_sdk.models import ConnectionConfig, ExecResult


def test_discover_happy_path(ros6_discovery_map: dict[str, ExecResult]) -> None:
    t = FakeTransport(ros6_discovery_map)
    svc = DiscoveryService(t)
    t.connect(
        ConnectionConfig(host="192.168.88.1", username="admin", password="x"),
    )
    p = svc.discover()
    assert p.identity_name == "MikroTik"
    assert "6.49.17" in p.routeros_version
    assert p.board_name == "hAP ac^2"
    assert p.wireless.has_wireless
    assert p.wireless.menu_kind == "wireless"
    assert set(p.wireless.master_interface_names) == {"wlan1", "wlan2"}


def test_discover_ros7_falls_back_to_wifi_when_wireless_fails(
    ros7_wifi_fallback_map: dict[str, ExecResult],
) -> None:
    t = SpyTransport(ros7_wifi_fallback_map)
    svc = DiscoveryService(t)
    t.connect(ConnectionConfig(host="192.168.88.1", username="admin", password="x"))
    p = svc.discover()
    assert p.wireless.has_wireless
    assert "wifi1" in p.wireless.interface_names
    assert p.wireless.menu_kind == "wifi"
    assert any(c.startswith("/interface wireless") for c in t.commands)
    assert any(c.startswith("/interface wifi") for c in t.commands)


def test_discover_ros7_does_not_call_wifi_when_wireless_ok(
    ros6_discovery_map: dict[str, ExecResult],
) -> None:
    m = dict(ros6_discovery_map)
    m["/system resource print"] = ExecResult(
        "  version: 7.15.3 (stable)\n  cpu: ARM\n",
        "",
        0,
    )
    t = SpyTransport(m)
    svc = DiscoveryService(t)
    t.connect(ConnectionConfig(host="192.168.88.1", username="admin", password="x"))
    svc.discover()
    assert any("/interface wireless" in c for c in t.commands)
    assert not any("/interface wifi" in c for c in t.commands)


def test_router_client_discover(ros6_discovery_map: dict[str, ExecResult]) -> None:
    c = RouterClient(FakeTransport(ros6_discovery_map))
    c.connect(ConnectionConfig(host="h", username="u", password="p"))
    try:
        p = c.discover()
        assert p.identity_name == "MikroTik"
    finally:
        c.disconnect()
