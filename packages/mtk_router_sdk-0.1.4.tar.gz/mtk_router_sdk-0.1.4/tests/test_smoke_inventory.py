"""Guardrail: every basename in ``SMOKE_GATE_MODULES`` must exist (prevents typos in ``conftest.py``)."""

from __future__ import annotations

from pathlib import Path

import conftest


def test_smoke_gate_module_files_exist() -> None:
    root = Path(__file__).resolve().parent
    for name in conftest.SMOKE_GATE_MODULES:
        path = root / name
        assert path.is_file(), f"missing smoke module file: {path}"
