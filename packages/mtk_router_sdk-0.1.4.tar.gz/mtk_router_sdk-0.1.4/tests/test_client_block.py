"""Unit tests for per-client internet block/unblock."""

from __future__ import annotations

from unittest.mock import MagicMock

from mtk_router_sdk.ops.client_block import (
    BLOCK_COMMENT,
    block_client,
    is_client_blocked,
    list_blocked_clients,
    unblock_client,
)


def _make_client(
    firewall_rows: list[dict[str, str]] | None = None,
    add_ok: bool = True,
    remove_ok: bool = True,
) -> MagicMock:
    """Mock RouterClient with firewall state."""
    client = MagicMock()
    rows = firewall_rows if firewall_rows is not None else []
    client.exec_print_terse.return_value = rows

    add_result = MagicMock()
    add_result.ok = add_ok
    add_result.stdout = ""
    add_result.stderr = ""

    remove_result = MagicMock()
    remove_result.ok = remove_ok
    remove_result.stdout = ""
    remove_result.stderr = ""

    client.exec_command.side_effect = lambda cmd, timeout=30: (
        add_result if "add" in cmd else remove_result
    )
    return client


def test_block_client_new_rule() -> None:
    """Test blocking a client that is not already blocked."""
    client = _make_client([])
    # After add, simulate rule exists
    def terse_after_add(_path: str, timeout: float = 30.0) -> list[dict]:
        return [
            {
                ".id": "*A1",
                "chain": "forward",
                "src-address": "192.168.88.100",
                "action": "drop",
                "comment": BLOCK_COMMENT,
            }
        ]

    client.exec_print_terse.side_effect = [[], terse_after_add("/ip firewall filter")]
    result = block_client(client, "192.168.88.100")
    assert result["ok"] is True
    assert result["action"] == "blocked"
    assert result["client_ip"] == "192.168.88.100"


def test_block_client_already_blocked() -> None:
    """Test blocking a client that is already blocked (idempotent)."""
    rows = [
        {
            ".id": "*A1",
            "chain": "forward",
            "src-address": "192.168.88.100",
            "action": "drop",
            "comment": BLOCK_COMMENT,
        }
    ]
    client = _make_client(rows)
    result = block_client(client, "192.168.88.100")
    assert result["ok"] is True
    assert result["action"] == "already_blocked"
    assert result["rule_id"] == "*A1"


def test_unblock_client_exists() -> None:
    """Test unblocking a blocked client."""
    rows = [
        {
            ".id": "*A2",
            "chain": "forward",
            "src-address": "10.0.0.5",
            "action": "drop",
            "comment": BLOCK_COMMENT,
        }
    ]
    client = _make_client(rows)
    result = unblock_client(client, "10.0.0.5")
    assert result["ok"] is True
    assert result["action"] == "unblocked"


def test_unblock_client_not_blocked() -> None:
    """Test unblocking a client that is not blocked (idempotent)."""
    client = _make_client([])
    result = unblock_client(client, "10.0.0.99")
    assert result["ok"] is True
    assert result["action"] == "not_blocked"


def test_list_blocked_clients() -> None:
    """Test listing blocked clients."""
    rows = [
        {
            ".id": "*A1",
            "chain": "forward",
            "src-address": "192.168.1.10",
            "action": "drop",
            "comment": BLOCK_COMMENT,
        },
        {
            ".id": "*A2",
            "chain": "forward",
            "src-address": "192.168.1.20",
            "action": "drop",
            "comment": BLOCK_COMMENT,
        },
        {
            ".id": "*A3",
            "chain": "forward",
            "src-address": "192.168.1.30",
            "action": "accept",  # not a drop rule
            "comment": BLOCK_COMMENT,
        },
    ]
    client = _make_client(rows)
    result = list_blocked_clients(client)
    assert result["ok"] is True
    assert result["count"] == 2
    ips = [b["client_ip"] for b in result["blocked_clients"]]
    assert "192.168.1.10" in ips
    assert "192.168.1.20" in ips
    assert "192.168.1.30" not in ips


def test_is_client_blocked_yes() -> None:
    """Test checking if a client is blocked."""
    rows = [
        {
            ".id": "*B1",
            "chain": "forward",
            "src-address": "172.16.0.5",
            "action": "drop",
            "comment": BLOCK_COMMENT,
        }
    ]
    client = _make_client(rows)
    result = is_client_blocked(client, "172.16.0.5")
    assert result["ok"] is True
    assert result["blocked"] is True
    assert result["rule_id"] == "*B1"


def test_is_client_blocked_no() -> None:
    """Test checking if a non-blocked client returns blocked=False."""
    client = _make_client([])
    result = is_client_blocked(client, "172.16.0.99")
    assert result["ok"] is True
    assert result["blocked"] is False
    assert result["rule_id"] is None
