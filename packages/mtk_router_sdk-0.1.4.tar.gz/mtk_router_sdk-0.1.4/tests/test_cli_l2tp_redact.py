from __future__ import annotations

from mtk_router_sdk.cli import _redact_l2tp_rows


def test_l2tp_json_redacts_secrets_by_default() -> None:
    rows = [{"name": "vpn_usa", "password": "x", "ipsec-secret": "y", "connect-to": "h"}]
    out = _redact_l2tp_rows(rows, show_secrets=False)
    assert out[0]["password"] == "<redacted>"
    assert out[0]["ipsec-secret"] == "<redacted>"
    assert out[0]["connect-to"] == "h"


def test_l2tp_show_secrets_passthrough() -> None:
    rows = [{"name": "vpn_usa", "password": "secret"}]
    assert _redact_l2tp_rows(rows, show_secrets=True)[0]["password"] == "secret"
