"""LAN device picker falls back to host discovery when RouterClient exists but SSH fails."""

from __future__ import annotations

from unittest.mock import MagicMock

from mtk_router_sdk.net.host_neighbors import HostLanPeer, HostLanScan
from mtk_router_sdk.testing import dashboard as dash


def test_lan_devices_payload_host_fallback_when_ensurer_fails(monkeypatch) -> None:
    fake_client = MagicMock()
    fake_client.connected = False

    def boom() -> None:
        raise OSError("timed out")

    fake_net = MagicMock()
    fake_net.client = fake_client
    fake_net._ensure_ssh_connected = boom

    fake_kit = MagicMock()
    fake_kit.network = fake_net

    scan = HostLanScan(
        peers=(
            HostLanPeer(ip="10.0.0.50", mac="aa:bb:cc:dd:ee:ff", interface="eth0", source="proc_net_arp"),
        ),
        scan_source="proc_net_arp",
        hint="test hint",
    )
    monkeypatch.setattr(dash, "scan_host_lan_peers", lambda: scan)

    payload = dash._lan_devices_payload(fake_kit)
    assert payload["source"] == "host_fallback"
    assert len(payload["devices"]) == 1
    assert payload["devices"][0]["ip"] == "10.0.0.50"
    assert "Router SSH" in payload["hint"]
