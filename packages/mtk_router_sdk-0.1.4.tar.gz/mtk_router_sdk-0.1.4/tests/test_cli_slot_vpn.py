from __future__ import annotations

import argparse
from unittest.mock import MagicMock, patch

import pytest

from mtk_router_sdk.cli import cmd_slot_vpn
from mtk_router_sdk.models import ExecResult


def test_slot_vpn_requires_site() -> None:
    ns = argparse.Namespace(
        site_config_path=None,
        slot_id=1,
        ssid=None,
        gateway_interface="l2tp-us",
    )
    assert cmd_slot_vpn(ns) == 2


@patch("mtk_router_sdk.cli.RouterClient.with_ssh")
def test_slot_vpn_success(
    mock_with_ssh: MagicMock,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("MTK_HOST", "127.0.0.1")
    monkeypatch.setenv("MTK_USER", "admin")
    monkeypatch.setenv("MTK_PASSWORD", "test")
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")

    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},"slots":[{"id":2,"enabled":true,"ssid":"g","region":"US"}]}',
        encoding="utf-8",
    )

    inst = MagicMock()
    mock_with_ssh.return_value = inst
    inst.connect = MagicMock()
    inst.disconnect = MagicMock()
    inst.exec_command.return_value = ExecResult(stdout="", stderr="", exit_status=0)
    inst.exec_print_terse.side_effect = [
        [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}],
        [{"name": "l2tp-uk", "running": "true", "disabled": "false"}],
    ]

    ns = argparse.Namespace(
        site_config_path=str(site_path),
        slot_id=2,
        ssid=None,
        gateway_interface="l2tp-uk",
    )
    assert cmd_slot_vpn(ns) == 0
    inst.exec_command.assert_called_once()
    assert inst.exec_print_terse.call_count == 2
    cmd = inst.exec_command.call_args[0][0]
    assert "routing-mark=rt_slot_2" in cmd
    assert "gateway=l2tp-uk" in cmd


@patch("mtk_router_sdk.cli.RouterClient.with_ssh")
def test_slot_vpn_by_ssid(
    mock_with_ssh: MagicMock,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("MTK_HOST", "127.0.0.1")
    monkeypatch.setenv("MTK_USER", "admin")
    monkeypatch.setenv("MTK_PASSWORD", "test")
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")

    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},'
        '"slots":[{"id":2,"enabled":true,"ssid":"MySSID","region":"US"}]}',
        encoding="utf-8",
    )

    inst = MagicMock()
    mock_with_ssh.return_value = inst
    inst.connect = MagicMock()
    inst.disconnect = MagicMock()
    inst.exec_command.return_value = ExecResult(stdout="", stderr="", exit_status=0)
    inst.exec_print_terse.side_effect = [
        [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}],
        [{"name": "l2tp-uk", "running": "true"}],
    ]

    ns = argparse.Namespace(
        site_config_path=str(site_path),
        slot_id=None,
        ssid="MySSID",
        gateway_interface="l2tp-uk",
    )
    assert cmd_slot_vpn(ns) == 0
    cmd = inst.exec_command.call_args[0][0]
    assert "routing-mark=rt_slot_2" in cmd


def test_slot_vpn_unknown_slot(tmp_path) -> None:
    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},"slots":[{"id":1,"enabled":true,"ssid":"g","region":"US"}]}',
        encoding="utf-8",
    )
    ns = argparse.Namespace(
        site_config_path=str(site_path),
        slot_id=99,
        ssid=None,
        gateway_interface="l2tp-uk",
    )
    assert cmd_slot_vpn(ns) == 1
