"""Tests for policy-route helpers used by profiles/scenarios and HTTP."""

from __future__ import annotations

import pytest

from conftest import SpyTransport
from mtk_router_sdk.client import RouterClient
from mtk_router_sdk.config import load_site_config_from_path
from mtk_router_sdk.models import ConnectionConfig, ExecResult
from mtk_router_sdk.ops.slot_route import set_slot_vpn_gateway, update_policy_route_gateway


def _ssh_cfg() -> ConnectionConfig:
    return ConnectionConfig(host="h", username="u", password="p", port=22)


def test_set_slot_vpn_gateway_default_routing_mark(tmp_path) -> None:
    t = SpyTransport(
        {
            "/ip route set": ExecResult(stdout="", stderr="", exit_status=0),
        },
    )
    c = RouterClient(t)
    c.connect(_ssh_cfg())
    r = set_slot_vpn_gateway(c, 3, "l2tp-us", site=None)
    assert r.ok
    assert t.commands
    assert any("routing-mark=rt_slot_3" in cmd and "gateway=l2tp-us" in cmd for cmd in t.commands)


def test_set_slot_vpn_gateway_with_site_custom_mark(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")

    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},'
        '"slots":[{"id":2,"enabled":true,"ssid":"g","region":"US","routing_mark":"rt_custom"}]}',
        encoding="utf-8",
    )
    site = load_site_config_from_path(site_path)
    t = SpyTransport(
        {
            "/ip route set": ExecResult(stdout="", stderr="", exit_status=0),
        },
    )
    c = RouterClient(t)
    c.connect(_ssh_cfg())
    r = set_slot_vpn_gateway(c, 2, "l2tp-uk", site=site)
    assert r.ok
    assert any("routing-mark=rt_custom" in cmd for cmd in t.commands)


def test_update_policy_route_gateway_escapes_identifiers() -> None:
    t = SpyTransport(
        {
            "/ip route set": ExecResult(stdout="", stderr="", exit_status=0),
        },
    )
    c = RouterClient(t)
    c.connect(_ssh_cfg())
    r = update_policy_route_gateway(
        c,
        routing_mark="rt_slot_1",
        gateway_interface="l2tp-us",
    )
    assert r.ok
    assert t.commands and "find routing-mark=" in t.commands[0]
