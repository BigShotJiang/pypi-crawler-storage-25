from __future__ import annotations

import argparse
from unittest.mock import MagicMock, patch

import pytest

from mtk_router_sdk.cli import cmd_sniffer_start
from mtk_router_sdk.models import ExecResult


def test_sniffer_start_requires_site() -> None:
    ns = argparse.Namespace(
        site_config_path=None,
        slot_id=1,
        ssid=None,
        filter_ip="192.168.1.1",
        file_name=None,
        only_headers=False,
        memory_limit="100MiB",
    )
    assert cmd_sniffer_start(ns) == 2


@patch("mtk_router_sdk.cli.RouterClient.with_ssh")
def test_sniffer_start_success(
    mock_with_ssh: MagicMock,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("MTK_HOST", "127.0.0.1")
    monkeypatch.setenv("MTK_USER", "admin")
    monkeypatch.setenv("MTK_PASSWORD", "test")
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")

    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},"slots":[{"id":2,"enabled":true,"ssid":"g","region":"US"}]}',
        encoding="utf-8",
    )

    inst = MagicMock()
    mock_with_ssh.return_value = inst
    inst.connect = MagicMock()
    inst.disconnect = MagicMock()
    inst.exec_command.return_value = ExecResult(
        stdout="  running: yes\n",
        stderr="",
        exit_status=0,
    )

    ns = argparse.Namespace(
        site_config_path=str(site_path),
        slot_id=2,
        ssid=None,
        filter_ip="10.0.0.5",
        file_name=None,
        only_headers=False,
        memory_limit="100MiB",
    )
    assert cmd_sniffer_start(ns) == 0
    cmds = [c[0][0] for c in inst.exec_command.call_args_list]
    joined = " ".join(cmds)
    assert "filter-ip-address=" in joined
    assert "interface=slot_2" in joined
    assert "/tool sniffer start" in joined


@patch("mtk_router_sdk.cli.RouterClient.with_ssh")
def test_sniffer_start_by_ssid(
    mock_with_ssh: MagicMock,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("MTK_HOST", "127.0.0.1")
    monkeypatch.setenv("MTK_USER", "admin")
    monkeypatch.setenv("MTK_PASSWORD", "test")
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")

    site_path = tmp_path / "site.json"
    site_path.write_text(
        '{"version":1,"global":{"max_slots":8,"wifi_security":{"profile_name":"x","psk_ref":"env:X"},'
        '"vpn_credentials":{"user_ref":"env:U","password_ref":"env:P"}},"vpn_registry":{"US":"h"},'
        '"bootstrap":{"provision_tunnels":"none"},'
        '"slots":[{"id":3,"enabled":true,"ssid":"Office","region":"US"}]}',
        encoding="utf-8",
    )

    inst = MagicMock()
    mock_with_ssh.return_value = inst
    inst.connect = MagicMock()
    inst.disconnect = MagicMock()
    inst.exec_command.return_value = ExecResult(
        stdout="  running: yes\n",
        stderr="",
        exit_status=0,
    )

    ns = argparse.Namespace(
        site_config_path=str(site_path),
        slot_id=None,
        ssid="Office",
        filter_ip="10.0.0.5",
        file_name=None,
        only_headers=False,
        memory_limit="100MiB",
    )
    assert cmd_sniffer_start(ns) == 0
    joined = " ".join(c[0][0] for c in inst.exec_command.call_args_list)
    assert "interface=slot_3" in joined
