from __future__ import annotations

import pytest

from mtk_router_sdk.config import load_site_config
from mtk_router_sdk.intent.runner import IntentExecutionError, enabled_slot_by_ssid


def _site(slots: list[dict]) -> object:
    return load_site_config(
        {
            "version": 1,
            "global": {
                "max_slots": 8,
                "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
                "vpn_credentials": {"user_ref": "env:U", "password_ref": "env:P"},
            },
            "vpn_registry": {"US": "h"},
            "bootstrap": {"provision_tunnels": "none"},
            "slots": slots,
        },
        env={"X": "1", "U": "u", "P": "p"},
    )


def test_enabled_slot_by_ssid_ok() -> None:
    site = _site([{"id": 2, "enabled": True, "ssid": "GuestNet", "region": "US"}])
    s = enabled_slot_by_ssid(site, "GuestNet")
    assert s.id == 2


def test_enabled_slot_by_ssid_unknown() -> None:
    site = _site([{"id": 1, "enabled": True, "ssid": "A", "region": "US"}])
    with pytest.raises(IntentExecutionError, match="no enabled slot"):
        enabled_slot_by_ssid(site, "OtherSSID")


def test_enabled_slot_by_ssid_disabled_ignored() -> None:
    site = _site(
        [
            {"id": 1, "enabled": False, "ssid": "Off", "region": "US"},
            {"id": 2, "enabled": True, "ssid": "On", "region": "US"},
        ],
    )
    with pytest.raises(IntentExecutionError):
        enabled_slot_by_ssid(site, "Off")
    s = enabled_slot_by_ssid(site, "On")
    assert s.id == 2


def test_enabled_slot_by_ssid_ambiguous() -> None:
    site = _site(
        [
            {"id": 1, "enabled": True, "ssid": "Dup", "region": "US"},
            {"id": 2, "enabled": True, "ssid": "Dup", "region": "US"},
        ],
    )
    with pytest.raises(IntentExecutionError, match="ambiguous"):
        enabled_slot_by_ssid(site, "Dup")
