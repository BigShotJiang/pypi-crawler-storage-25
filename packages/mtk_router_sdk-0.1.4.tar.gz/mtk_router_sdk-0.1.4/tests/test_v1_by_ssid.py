from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from mtk_router_sdk.models import ExecResult
from mtk_router_sdk.service.app import create_app


def _minimal_site() -> dict:
    return {
        "version": 1,
        "global": {
            "max_slots": 8,
            "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
            "vpn_credentials": {"user_ref": "env:U", "password_ref": "env:P"},
        },
        "vpn_registry": {"US": "h"},
        "bootstrap": {"provision_tunnels": "none"},
        "slots": [{"id": 2, "enabled": True, "ssid": "GuestWiFi", "region": "US"}],
    }


@pytest.fixture
def app_with_site(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")
    from mtk_router_sdk.config import load_site_config

    wrapped = create_app()
    inner = wrapped.app
    st = inner.state.mtk
    st.site = load_site_config(_minimal_site(), env=dict(__import__("os").environ))
    return wrapped


def test_lease_by_ssid_returns_slot_id(app_with_site) -> None:
    client = TestClient(app_with_site)
    r = client.post(
        "/v1/by-ssid/control/lease",
        json={"ssid": "GuestWiFi", "actor": "t", "ttl_s": 60},
    )
    assert r.status_code == 200
    data = r.json()
    assert data.get("slot_id") == 2
    assert data.get("ssid") == "GuestWiFi"
    assert "lease_token" in data


def test_unknown_ssid_400(app_with_site) -> None:
    client = TestClient(app_with_site)
    r = client.post(
        "/v1/by-ssid/control/lease",
        json={"ssid": "NotInSite", "actor": "t"},
    )
    assert r.status_code == 400


@patch("mtk_router_sdk.service.v1_routes._with_client")
def test_by_ssid_vpn_ok(mock_wc: MagicMock, app_with_site) -> None:
    def fake_with(st, fn, timeout=120.0):
        class FakeClient:
            def exec_command(self, *_a, **_k):
                return ExecResult(stdout="", stderr="", exit_status=0)

            def exec_print_terse(self, menu: str, **_k: object) -> list[dict]:
                if "route" in menu:
                    return [{"routing-mark": "rt_slot_2", "gateway": "l2tp-uk"}]
                return [{"name": "l2tp-uk", "running": "true", "disabled": "false"}]

        return fn(FakeClient())

    mock_wc.side_effect = fake_with

    client = TestClient(app_with_site)
    lr = client.post(
        "/v1/by-ssid/control/lease",
        json={"ssid": "GuestWiFi", "actor": "t", "ttl_s": 60},
    )
    token = lr.json()["lease_token"]
    r = client.post(
        "/v1/by-ssid/vpn",
        json={"ssid": "GuestWiFi", "gateway_interface": "l2tp-uk", "mode": "route"},
        headers={"X-Slot-Lease": token},
    )
    assert r.status_code == 200
    data = r.json()
    assert data.get("ssid") == "GuestWiFi"
    assert data.get("checkpoint", {}).get("status") == "success"


@patch("mtk_router_sdk.service.v1_routes._with_client")
def test_slot_vpn_status_get(mock_wc: MagicMock, app_with_site) -> None:
    def fake_with(st, fn, timeout=120.0):
        class FakeClient:
            def exec_print_terse(self, menu: str, **_k: object) -> list[dict]:
                if "route" in menu:
                    return [{"routing-mark": "rt_slot_2", "gateway": "l2tp-us"}]
                return [{"name": "l2tp-us", "running": "true"}]

        return fn(FakeClient())

    mock_wc.side_effect = fake_with

    client = TestClient(app_with_site)
    r = client.get("/v1/slots/2/vpn/status")
    assert r.status_code == 200
    body = r.json()
    assert body.get("gateway_interface") == "l2tp-us"
    assert body.get("checkpoint", {}).get("status") == "success"


def test_lease_release_by_ssid(app_with_site) -> None:
    client = TestClient(app_with_site)
    lr = client.post(
        "/v1/by-ssid/control/lease",
        json={"ssid": "GuestWiFi", "actor": "t", "ttl_s": 60},
    )
    token = lr.json()["lease_token"]
    r = client.post(
        "/v1/by-ssid/control/lease/release",
        json={"ssid": "GuestWiFi", "lease_token": token},
    )
    assert r.status_code == 200
    assert r.json().get("ok") is True
