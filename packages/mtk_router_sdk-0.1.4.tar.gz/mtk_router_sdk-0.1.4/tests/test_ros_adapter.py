from __future__ import annotations

from mtk_router_sdk.ros_adapter import RosCommandAdapter


def test_from_version_string_parses_major() -> None:
    assert RosCommandAdapter.from_version_string("6.49.17 (stable)").major == 6
    assert RosCommandAdapter.from_version_string("7.15.3 (stable)").major == 7
    assert RosCommandAdapter.from_version_string("").major == 7
    assert RosCommandAdapter.from_version_string("  8.0rc1").major == 8


def test_try_wifi_when_wireless_fails_only_from_seven() -> None:
    assert not RosCommandAdapter.from_version_string("6.49.1").try_wifi_when_wireless_fails()
    assert RosCommandAdapter.from_version_string("7.1").try_wifi_when_wireless_fails()
