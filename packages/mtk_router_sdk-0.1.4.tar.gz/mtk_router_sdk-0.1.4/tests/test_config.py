from __future__ import annotations

import pytest

from mtk_router_sdk.config.load import load_site_config
from mtk_router_sdk.exceptions import ConfigurationError


def test_load_site_minimal() -> None:
    env = {
        "MTK_WIFI_PSK": "wifi-secret",
        "MTK_VPN_USER": "u",
        "MTK_VPN_PASSWORD": "v",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "vpn_registry": {"USA": "vpn.example.com"},
            "slots": [
                {
                    "id": 1,
                    "enabled": True,
                    "ssid": "S1",
                    "region": "USA",
                }
            ],
        },
        env=env,
    )
    assert site.enabled_slots[0].ssid == "S1"


def test_region_missing_from_registry() -> None:
    env = {
        "MTK_WIFI_PSK": "w",
        "MTK_VPN_USER": "u",
        "MTK_VPN_PASSWORD": "v",
    }
    with pytest.raises(ConfigurationError):
        load_site_config(
            {
                "version": 1,
                "global": {},
                "vpn_registry": {},
                "slots": [{"id": 1, "enabled": True, "ssid": "S", "region": "USA"}],
            },
            env=env,
        )
