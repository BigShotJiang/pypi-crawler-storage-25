from __future__ import annotations

import pytest

from mtk_router_sdk.config.env import connection_config_from_merged


@pytest.fixture(autouse=True)
def _no_os_derived_dot_one_hosts(monkeypatch: pytest.MonkeyPatch) -> None:
    """Avoid flaky ``ifconfig`` / ``ip addr`` output in host-resolution tests."""

    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.local_rfc1918_subnet_router_hosts",
        lambda: [],
    )


def test_host_uses_gateway_when_only_gateway_has_ssh(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda timeout=3.0: "10.8.0.1",
    )
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.tcp_port_open",
        lambda host, **kw: host == "10.8.0.1",
    )
    cfg = connection_config_from_merged(None, env={"MTK_PASSWORD": "p"})
    assert cfg.host == "10.8.0.1"


def test_host_probe_off_prefers_gateway_when_not_on_mikrotik_default_lan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.host_has_ipv4_on_network",
        lambda _n: False,
    )
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda timeout=3.0: "10.8.0.1",
    )
    cfg = connection_config_from_merged(
        None,
        env={"MTK_PASSWORD": "p", "MTK_AUTO_SSH_PROBE": "0"},
    )
    assert cfg.host == "10.8.0.1"


def test_host_probe_off_prefers_classic_lan_when_on_mikrotik_default_lan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.host_has_ipv4_on_network",
        lambda _n: True,
    )
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda timeout=3.0: "10.8.0.1",
    )
    cfg = connection_config_from_merged(
        None,
        env={"MTK_PASSWORD": "p", "MTK_AUTO_SSH_PROBE": "0"},
    )
    assert cfg.host == "192.168.88.1"


def test_skip_gateway_detect_uses_lan_default(monkeypatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda timeout=3.0: "10.8.0.1",
    )
    cfg = connection_config_from_merged(
        None,
        env={"MTK_PASSWORD": "p", "MTK_SKIP_GATEWAY_DETECT": "1"},
    )
    assert cfg.host == "192.168.88.1"


def test_mtk_host_still_wins_over_gateway(monkeypatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda timeout=3.0: "10.8.0.1",
    )
    cfg = connection_config_from_merged(
        None,
        env={"MTK_HOST": "192.168.50.1", "MTK_PASSWORD": "p"},
    )
    assert cfg.host == "192.168.50.1"
