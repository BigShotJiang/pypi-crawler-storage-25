"""Cross-cutting smoke checks (CLI, packaging). Most smoke coverage lives in domain tests — see ``SMOKE_GATE_MODULES`` in ``conftest.py``."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from mtk_router_sdk import __version__
from mtk_router_sdk.service.openapi_spec import build_openapi_spec


def test_sdk_version_is_non_empty() -> None:
    assert isinstance(__version__, str)
    assert len(__version__.strip()) >= 3


def test_cli_version_subprocess_exits_zero() -> None:
    r = subprocess.run(
        [sys.executable, "-m", "mtk_router_sdk.cli", "version"],
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert r.returncode == 0, r.stderr


def test_dashboard_web_index_packaged() -> None:
    import mtk_router_sdk.testing as t

    idx = Path(t.__file__).resolve().parent / "dashboard_web" / "index.html"
    assert idx.is_file(), f"missing dashboard bundle: {idx}"


def test_openapi_spec_builds_and_lists_core_paths() -> None:
    spec = build_openapi_spec(sdk_version=__version__)
    assert spec.get("openapi") == "3.1.0"
    for path in ("/healthz", "/readyz", "/v1/capabilities", "/v1/client/resolve"):
        assert path in spec.get("paths", {}), path


def test_proxy_local_state_accepts_rule() -> None:
    from mtk_router_sdk.proxy.models import ProxyAction, ProxyRule
    from mtk_router_sdk.proxy.store import ProxyState

    st = ProxyState()
    st.rules.add(
        ProxyRule(
            client_ip="192.168.1.10",
            path_pattern="/api/*",
            action=ProxyAction.OVERRIDE,
            response_body={"ok": True},
        )
    )
    assert st.rules.count() >= 1
