from __future__ import annotations

import pytest

from mtk_router_sdk.ops.sniffer import (
    SnifferValidationError,
    default_capture_filename,
    is_ipv4,
    validate_capture_filename,
)


@pytest.mark.parametrize(
    ("ip", "ok"),
    [
        ("192.168.0.1", True),
        ("10.0.0.0", True),
        ("256.1.1.1", False),
        ("192.168.1", False),
        ("", False),
    ],
)
def test_is_ipv4(ip: str, ok: bool) -> None:
    assert is_ipv4(ip) is ok


def test_default_capture_filename() -> None:
    assert default_capture_filename(2, "192.168.2.55") == "mtk_slot2_192_168_2_55.pcap"


def test_validate_capture_filename_ok() -> None:
    assert validate_capture_filename("my-dev.pcap") == "my-dev.pcap"


def test_validate_capture_filename_rejects_path() -> None:
    with pytest.raises(SnifferValidationError):
        validate_capture_filename("../etc/passwd.pcap")
