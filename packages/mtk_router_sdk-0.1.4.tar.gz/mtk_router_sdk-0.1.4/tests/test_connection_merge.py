from __future__ import annotations

from mtk_router_sdk.config.env import connection_config_from_merged
from mtk_router_sdk.config.load import load_site_config
from mtk_router_sdk.config.schema import (
    BootstrapSettings,
    ConnectionSettings,
    GlobalSettings,
    SiteConfig,
    SlotConfig,
)


def test_merged_env_overrides_file() -> None:
    site = SiteConfig(
        version=1,
        global_=GlobalSettings(),
        vpn_registry={"USA": "x"},
        bootstrap=BootstrapSettings(),
        slots=[
            SlotConfig(id=1, enabled=True, ssid="S", region="USA"),
        ],
        connection=ConnectionSettings(
            host="10.0.0.1",
            username="fileuser",
            password_ref="inline-file-pass",
            port=2222,
            timeout=99.0,
        ),
    )
    env = {
        "MTK_HOST": "192.168.1.1",
        "MTK_USER": "envuser",
        "MTK_PASSWORD": "envpass",
        "MTK_PORT": "22",
        "MTK_TIMEOUT": "5",
    }
    cfg = connection_config_from_merged(site, env=env)
    assert cfg.host == "192.168.1.1"
    assert cfg.username == "envuser"
    assert cfg.password == "envpass"
    assert cfg.port == 22
    assert cfg.timeout == 5.0


def test_merged_uses_file_when_env_empty() -> None:
    site = SiteConfig(
        version=1,
        global_=GlobalSettings(),
        vpn_registry={"USA": "x"},
        bootstrap=BootstrapSettings(),
        slots=[SlotConfig(id=1, enabled=True, ssid="S", region="USA")],
        connection=ConnectionSettings(
            host="10.0.0.2",
            username="u",
            password_ref="secret",
        ),
    )
    cfg = connection_config_from_merged(site, env={})
    assert cfg.host == "10.0.0.2"
    assert cfg.username == "u"
    assert cfg.password == "secret"


def test_load_json_connection_password_alias() -> None:
    env = {
        "MTK_WIFI_PSK": "w",
        "MTK_VPN_USER": "vu",
        "MTK_VPN_PASSWORD": "vp",
    }
    site = load_site_config(
        {
            "version": 1,
            "global": {},
            "connection": {
                "host": "1.2.3.4",
                "username": "adm",
                "password": "inline-ssh",
            },
            "vpn_registry": {"USA": "h"},
            "slots": [{"id": 1, "enabled": True, "ssid": "S", "region": "USA"}],
        },
        env=env,
    )
    assert site.connection is not None
    assert site.connection.host == "1.2.3.4"
    cfg = connection_config_from_merged(site, env={})
    assert cfg.password == "inline-ssh"
