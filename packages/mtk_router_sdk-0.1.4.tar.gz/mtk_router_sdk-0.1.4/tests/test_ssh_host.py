from __future__ import annotations

import pytest

from mtk_router_sdk.net.ssh_host import (
    collect_router_ssh_candidates,
    order_candidates_for_ssh_probe,
    pick_reachable_ssh_host,
)


def test_collect_orders_mikrotik_default_gateway_then_lan_dot_ones(monkeypatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.local_rfc1918_subnet_router_hosts",
        lambda: ["192.168.88.1"],
    )

    def fake_gw(*, timeout: float = 3.0) -> str | None:
        return "10.0.0.1"

    c = collect_router_ssh_candidates(get_gateway=fake_gw)
    assert c == ["192.168.88.1", "10.0.0.1"]


def test_collect_puts_extra_lan_dot_one_after_gateway(monkeypatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.local_rfc1918_subnet_router_hosts",
        lambda: ["172.20.101.1"],
    )

    def fake_gw(*, timeout: float = 3.0) -> str | None:
        return "192.168.1.1"

    assert collect_router_ssh_candidates(get_gateway=fake_gw) == [
        "192.168.88.1",
        "192.168.1.1",
        "172.20.101.1",
    ]


def test_collect_appends_mikrotik_lan_default_when_missing(monkeypatch) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.local_rfc1918_subnet_router_hosts",
        lambda: [],
    )

    def no_gw(*, timeout: float = 3.0) -> str | None:
        return None

    assert collect_router_ssh_candidates(get_gateway=no_gw) == ["192.168.88.1"]


def test_order_probe_puts_gateway_before_mikrotik_when_off_default_lan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.host_has_ipv4_on_network",
        lambda _n: False,
    )
    assert order_candidates_for_ssh_probe(["192.168.88.1", "172.20.101.1"]) == [
        "172.20.101.1",
        "192.168.88.1",
    ]


def test_pick_fallback_uses_gateway_when_not_on_mikrotik_lan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.host_has_ipv4_on_network",
        lambda _n: False,
    )

    def never(_h: str, **kw: object) -> bool:
        return False

    got = pick_reachable_ssh_host(
        ["192.168.88.1", "172.20.101.1"],
        probe=never,
        timeout_per_host=0.01,
    )
    assert got == "172.20.101.1"


def test_pick_fallback_uses_classic_lan_when_on_mikrotik_lan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "mtk_router_sdk.net.ssh_host.host_has_ipv4_on_network",
        lambda _n: True,
    )

    def never(_h: str, **kw: object) -> bool:
        return False

    got = pick_reachable_ssh_host(
        ["192.168.88.1", "172.20.101.1"],
        probe=never,
        timeout_per_host=0.01,
    )
    assert got == "192.168.88.1"


def test_pick_returns_first_host_with_open_port() -> None:
    def opener(host: str, **kw: object) -> bool:
        return host == "192.168.1.1"

    got = pick_reachable_ssh_host(
        ["192.168.88.1", "192.168.1.1"],
        probe=opener,
        timeout_per_host=0.01,
    )
    assert got == "192.168.1.1"
