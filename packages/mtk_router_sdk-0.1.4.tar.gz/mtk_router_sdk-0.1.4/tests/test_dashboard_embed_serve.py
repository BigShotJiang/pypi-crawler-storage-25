"""Auto-spawn mtk-serve when dashboard starts (loopback only)."""

from __future__ import annotations

import pytest

from mtk_router_sdk.testing import dashboard_embed_serve as des


def test_parse_http_service() -> None:
    assert des._parse_http_service("http://127.0.0.1:8765") == ("127.0.0.1", 8765)
    assert des._parse_http_service("http://localhost:9999/foo") == ("localhost", 9999)
    assert des._parse_http_service("https://127.0.0.1:8765") is None
    assert des._parse_http_service("") is None


def test_is_loopback_host() -> None:
    assert des._is_loopback_host("127.0.0.1")
    assert des._is_loopback_host("localhost")
    assert des._is_loopback_host("::1")
    assert not des._is_loopback_host("10.0.0.1")


def test_ensure_skips_when_disabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MTK_DASHBOARD_AUTO_SERVE", "0")
    monkeypatch.setenv("MTK_SERVICE_URL", "http://127.0.0.1:8765")
    assert des.ensure_local_mtk_serve() is None


def test_ensure_skips_non_loopback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MTK_DASHBOARD_AUTO_SERVE", "1")
    monkeypatch.setenv("MTK_SERVICE_URL", "http://192.168.1.50:8765")
    assert des.ensure_local_mtk_serve() is None


def test_ensure_skips_https(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MTK_SERVICE_URL", "https://127.0.0.1:8765")
    assert des.ensure_local_mtk_serve() is None
