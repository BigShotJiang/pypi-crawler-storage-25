"""PKCS#12 CA extraction and import (Charles-style .p12)."""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from mtk_router_sdk.proxy.certs import CertError, CertManager, extract_pem_from_pkcs12


def _openssl_available() -> bool:
    return shutil.which("openssl") is not None


@pytest.mark.skipif(not _openssl_available(), reason="openssl not on PATH")
def test_extract_pem_from_pkcs12_roundtrip(tmp_path: Path) -> None:
    key = tmp_path / "ca.key"
    crt = tmp_path / "ca.crt"
    p12 = tmp_path / "ca.p12"
    subprocess.run(
        [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-keyout",
            str(key),
            "-out",
            str(crt),
            "-days",
            "30",
            "-nodes",
            "-subj",
            "/CN=Test PKCS12 CA",
        ],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        [
            "openssl",
            "pkcs12",
            "-export",
            "-out",
            str(p12),
            "-inkey",
            str(key),
            "-in",
            str(crt),
            "-passout",
            "pass:secretpw",
        ],
        check=True,
        capture_output=True,
    )
    raw = p12.read_bytes()
    cert_pem, key_pem = extract_pem_from_pkcs12(raw, "secretpw")
    assert "BEGIN CERTIFICATE" in cert_pem
    assert "PRIVATE KEY" in key_pem

    out_dir = tmp_path / "certs"
    cm = CertManager(str(out_dir))
    r = cm.import_ca_pkcs12_bytes(raw, password="secretpw", proxy_cn="Leaf", validity_days=30)
    assert r.get("imported") is True
    assert (out_dir / "ca.crt").is_file()
    assert (out_dir / "proxy.crt").is_file()


@pytest.mark.skipif(not _openssl_available(), reason="openssl not on PATH")
@pytest.mark.skipif(not _openssl_available(), reason="openssl not on PATH")
def test_extract_pem_empty_password(tmp_path: Path) -> None:
    key = tmp_path / "e.key"
    crt = tmp_path / "e.crt"
    p12 = tmp_path / "e.p12"
    subprocess.run(
        [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-keyout",
            str(key),
            "-out",
            str(crt),
            "-days",
            "7",
            "-nodes",
            "-subj",
            "/CN=Empty PW",
        ],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        [
            "openssl",
            "pkcs12",
            "-export",
            "-out",
            str(p12),
            "-inkey",
            str(key),
            "-in",
            str(crt),
            "-passout",
            "pass:",
        ],
        check=True,
        capture_output=True,
    )
    raw = p12.read_bytes()
    cert_pem, key_pem = extract_pem_from_pkcs12(raw, "")
    assert "BEGIN CERTIFICATE" in cert_pem
    assert "PRIVATE KEY" in key_pem
    cert_pem2, key_pem2 = extract_pem_from_pkcs12(raw, None)
    assert cert_pem2 == cert_pem


def test_extract_pem_wrong_password(tmp_path: Path) -> None:
    key = tmp_path / "k.key"
    crt = tmp_path / "c.crt"
    p12 = tmp_path / "x.p12"
    subprocess.run(
        [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            "rsa:2048",
            "-keyout",
            str(key),
            "-out",
            str(crt),
            "-days",
            "7",
            "-nodes",
            "-subj",
            "/CN=X",
        ],
        check=True,
        capture_output=True,
    )
    subprocess.run(
        [
            "openssl",
            "pkcs12",
            "-export",
            "-out",
            str(p12),
            "-inkey",
            str(key),
            "-in",
            str(crt),
            "-passout",
            "pass:good",
        ],
        check=True,
        capture_output=True,
    )
    with pytest.raises(CertError) as ei:
        extract_pem_from_pkcs12(p12.read_bytes(), "wrong")
    assert ei.value.code == "INVALID_P12"
