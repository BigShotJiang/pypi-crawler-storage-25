"""Dashboard Settings → Environment (env_ui) registry."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

import mtk_router_sdk.testing.dashboard_env_ui as eu


def test_normalize_env_ui_rejects_unknown_key() -> None:
    out, err = eu.normalize_env_ui_dict({"NOT_ALLOWED": "1"})
    assert out == {}
    assert err and "Unsupported" in err


def test_normalize_env_ui_port() -> None:
    out, err = eu.normalize_env_ui_dict({"MTK_HTTP_PORT": "8888"})
    assert err is None
    assert out == {"MTK_HTTP_PORT": "8888"}


def test_normalize_env_ui_port_invalid() -> None:
    out, err = eu.normalize_env_ui_dict({"MTK_HTTP_PORT": "70000"})
    assert out == {}
    assert err


def test_apply_env_ui_roundtrip(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(eu, "_env_ui_applied_path", lambda: tmp_path / "applied.json")
    monkeypatch.delenv("MTK_TRUST_X_FORWARDED_FOR", raising=False)
    eu.apply_env_ui({"env_ui": {"MTK_TRUST_X_FORWARDED_FOR": "1"}})
    assert os.environ.get("MTK_TRUST_X_FORWARDED_FOR") == "1"
    eu.apply_env_ui({"env_ui": {}})
    assert "MTK_TRUST_X_FORWARDED_FOR" not in os.environ
