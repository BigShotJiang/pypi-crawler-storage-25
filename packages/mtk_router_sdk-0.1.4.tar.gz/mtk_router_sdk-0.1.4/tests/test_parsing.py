from __future__ import annotations

from mtk_router_sdk.parsing import parse_print_block, parse_terse_line, parse_terse_lines


def test_parse_print_block() -> None:
    text = "  name: MikroTik\n  version: 6.49.17 (stable)\n"
    d = parse_print_block(text)
    assert d["name"] == "MikroTik"
    assert d["version"] == "6.49.17 (stable)"


def test_parse_terse_wireless() -> None:
    line = '0 RS name="wlan1" master-interface=none ssid="X"'
    d = parse_terse_line(line)
    assert d["name"] == "wlan1"
    assert d["ssid"] == "X"


def test_parse_terse_lines_skips_blank() -> None:
    out = parse_terse_lines("\n0 X name=a\n\n")
    assert len(out) == 1
    assert out[0]["name"] == "a"
