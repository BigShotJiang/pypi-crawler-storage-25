"""Per-endpoint VPN credential merge (env + JSON map)."""

from __future__ import annotations

import json
import os

import pytest

from mtk_router_sdk.config.vpn_endpoint_creds import (
    materialize_vpn_env_for_endpoint,
    normalize_profile_endpoint_overrides,
    parse_vpn_endpoint_credentials,
    resolve_vpn_credentials_for_endpoint,
)


def test_parse_vpn_endpoint_credentials() -> None:
    raw = json.dumps({"US": {"user": "u1", "password": "p1"}, "UK": {"user": "u2"}})
    m = parse_vpn_endpoint_credentials(raw)
    assert m["US"] == {"user": "u1", "password": "p1"}
    assert m["UK"] == {"user": "u2"}


def test_resolve_merge(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MTK_VPN_USER", "global_u")
    monkeypatch.setenv("MTK_VPN_PASSWORD", "global_p")
    monkeypatch.setenv("MTK_VPN_IPSEC_SECRET", "global_i")
    monkeypatch.setenv(
        "MTK_VPN_ENDPOINT_CREDENTIALS",
        json.dumps({"US": {"user": "us_u", "password": "us_p"}}),
    )
    u, p, i = resolve_vpn_credentials_for_endpoint("US")
    assert u == "us_u"
    assert p == "us_p"
    assert i == "global_i"
    u2, p2, i2 = resolve_vpn_credentials_for_endpoint("ZZ")
    assert (u2, p2, i2) == ("global_u", "global_p", "global_i")


def test_materialize_vpn_env_for_endpoint(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("MTK_VPN_USER", "g")
    monkeypatch.setenv("MTK_VPN_PASSWORD", "h")
    monkeypatch.setenv("MTK_VPN_ENDPOINT_CREDENTIALS", json.dumps({"X": {"user": "x", "password": "y"}}))
    env = dict(os.environ)
    materialize_vpn_env_for_endpoint("X", env=env)
    assert env["MTK_VPN_USER"] == "x"
    assert env["MTK_VPN_PASSWORD"] == "y"


def test_normalize_profile_endpoint_overrides() -> None:
    n = normalize_profile_endpoint_overrides(
        {"US": {"user": "a", "password": "b", "ipsec_secret": "c"}, "BAD": "x"}
    )
    assert n == {"US": {"user": "a", "password": "b", "ipsec_secret": "c"}}
