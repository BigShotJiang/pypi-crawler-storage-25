"""Unit tests for shared RouterOS terse parsing (no router required)."""

from mtk_router_sdk.parsing.terse import parse_terse_line, parse_terse_lines


def test_parse_terse_wireless_like() -> None:
    line = (
        '  0 R ;;; defconf         name=wlan1 mtu=1500 '
        'mac-address=04:F4:1C:3B:FD:FE master-interface=none'
    )
    row = parse_terse_line(line)
    assert row["flags"] == "R"
    assert row["name"] == "wlan1"
    assert row["mac-address"] == "04:F4:1C:3B:FD:FE"


def test_parse_terse_quoted_value() -> None:
    line = r'  1 name="My SSID" ssid="My SSID" disabled=no'
    row = parse_terse_line(line)
    assert row["name"] == "My SSID"
    assert row["ssid"] == "My SSID"


def test_parse_terse_lines_skips_empty() -> None:
    text = "\n  0 name=a\n\n  1 name=b\n"
    rows = parse_terse_lines(text)
    assert len(rows) == 2
    assert rows[0]["name"] == "a"
