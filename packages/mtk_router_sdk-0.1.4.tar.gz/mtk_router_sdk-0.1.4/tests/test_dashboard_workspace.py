"""Dashboard local workspace (setup profiles)."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from mtk_router_sdk.testing import dashboard_workspace as dw

import mtk_router_sdk.testing.dashboard_env_ui as dashboard_env_ui


@pytest.fixture(autouse=True)
def _patch_env_ui_applied_path(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        dashboard_env_ui,
        "_env_ui_applied_path",
        lambda: tmp_path / "env-ui-applied.json",
    )


def test_default_workspace() -> None:
    w = dw.default_workspace()
    assert w["version"] == 1
    assert w["onboarding_done"] is False
    assert w["profiles"] == []
    assert w.get("env_ui") == {}


def test_apply_active_profile_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_HOST", raising=False)
    monkeypatch.delenv("MTK_PASSWORD", raising=False)
    monkeypatch.delenv("MTK_VPN_USER", raising=False)
    w = {
        "version": 1,
        "active_profile_id": "p1",
        "profiles": [
            {
                "id": "p1",
                "label": "Lab",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "router_port": 22,
                "vpn_user": "vpnx",
                "vpn_password": "vpnpw",
                "mtk_service_url": "http://127.0.0.1:9999",
                "mtk_service_token": "tok",
            }
        ],
    }
    dw.apply_active_profile_env(w)
    assert os.environ["MTK_HOST"] == "10.0.0.1"
    assert os.environ["MTK_USER"] == "adm"
    assert os.environ["MTK_PASSWORD"] == "secret"
    assert os.environ["MTK_VPN_USER"] == "vpnx"
    assert os.environ["MTK_VPN_PASSWORD"] == "vpnpw"
    assert os.environ["MTK_SERVICE_URL"] == "http://127.0.0.1:9999"
    assert os.environ["MTK_SERVICE_TOKEN"] == "tok"


def test_apply_profile_lab_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_PROXY_MITM", raising=False)
    w = {
        "version": 1,
        "active_profile_id": "p1",
        "profiles": [
            {
                "id": "p1",
                "label": "Lab",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "mtk_service_url": "http://127.0.0.1:8765",
                "lab_env": {"MTK_PROXY_MITM": "false"},
            }
        ],
    }
    dw.apply_active_profile_env(w)
    assert os.environ.get("MTK_PROXY_MITM") == "false"


def test_lab_env_cleared_when_switching_profiles(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_PROXY_MITM", raising=False)
    w1 = {
        "version": 1,
        "active_profile_id": "a",
        "profiles": [
            {
                "id": "a",
                "label": "A",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "mtk_service_url": "http://127.0.0.1:8765",
                "lab_env": {"MTK_PROXY_MITM": "false"},
            },
            {
                "id": "b",
                "label": "B",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "mtk_service_url": "http://127.0.0.1:8765",
                "lab_env": {},
            },
        ],
    }
    dw.apply_active_profile_env(w1)
    assert os.environ.get("MTK_PROXY_MITM") == "false"
    w2 = {**w1, "active_profile_id": "b"}
    dw.apply_active_profile_env(w2)
    assert "MTK_PROXY_MITM" not in os.environ


def test_apply_profile_vpn_endpoint_overrides(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_VPN_ENDPOINT_CREDENTIALS", raising=False)
    monkeypatch.delenv("MTK_VPN_ACTIVE_ENDPOINT", raising=False)
    monkeypatch.delenv("MTK_VPN_IPSEC_SECRET", raising=False)
    w = {
        "version": 1,
        "active_profile_id": "p1",
        "profiles": [
            {
                "id": "p1",
                "label": "Lab",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "vpn_user": "g",
                "vpn_password": "h",
                "vpn_ipsec_secret": "psk1",
                "vpn_endpoint_overrides": {"US": {"user": "u", "password": "p"}},
                "vpn_active_endpoint": "US",
                "mtk_service_url": "http://127.0.0.1:8765",
            }
        ],
    }
    dw.apply_active_profile_env(w)
    assert os.environ["MTK_VPN_IPSEC_SECRET"] == "psk1"
    assert os.environ["MTK_VPN_ACTIVE_ENDPOINT"] == "US"
    m = json.loads(os.environ["MTK_VPN_ENDPOINT_CREDENTIALS"])
    assert m["US"] == {"user": "u", "password": "p"}


def test_apply_profile_clears_endpoint_json_when_empty(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.setenv("MTK_VPN_ENDPOINT_CREDENTIALS", '{"X":{"user":"a"}}')
    w = {
        "version": 1,
        "active_profile_id": "p1",
        "profiles": [
            {
                "id": "p1",
                "label": "Lab",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "vpn_user": "g",
                "vpn_password": "h",
                "mtk_service_url": "http://127.0.0.1:8765",
            }
        ],
    }
    dw.apply_active_profile_env(w)
    assert "MTK_VPN_ENDPOINT_CREDENTIALS" not in os.environ


def test_validate_workspace_payload() -> None:
    assert dw.validate_workspace_payload({}) is None
    assert dw.validate_workspace_payload({"profiles": "x"}) is not None
    err = dw.validate_workspace_payload(
        {"profiles": [{"id": "a"}, {"id": "a"}]}
    )
    assert err and "Duplicate" in err
    bad_lab = dw.validate_workspace_payload(
        {"profiles": [{"id": "x", "lab_env": {"FOO": "1"}}]}
    )
    assert bad_lab and "MTK_" in bad_lab
    bad_env = dw.validate_workspace_payload({"env_ui": {"NOT_MTK": "1"}})
    assert bad_env and "Unsupported" in bad_env


def test_env_ui_applies_without_active_profile(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_TRUST_X_FORWARDED_FOR", raising=False)
    w = {"version": 1, "active_profile_id": None, "profiles": [], "env_ui": {"MTK_TRUST_X_FORWARDED_FOR": "1"}}
    dw.apply_active_profile_env(w)
    assert os.environ.get("MTK_TRUST_X_FORWARDED_FOR") == "1"


def test_env_ui_overrides_profile_lab_env(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        dw,
        "_lab_env_applied_path",
        lambda: tmp_path / "lab-applied.json",
    )
    monkeypatch.delenv("MTK_TRUST_X_FORWARDED_FOR", raising=False)
    w = {
        "version": 1,
        "active_profile_id": "p1",
        "env_ui": {"MTK_TRUST_X_FORWARDED_FOR": "1"},
        "profiles": [
            {
                "id": "p1",
                "label": "Lab",
                "router_host": "10.0.0.1",
                "router_user": "adm",
                "router_password": "secret",
                "mtk_service_url": "http://127.0.0.1:8765",
                "lab_env": {"MTK_TRUST_X_FORWARDED_FOR": "0"},
            }
        ],
    }
    dw.apply_active_profile_env(w)
    assert os.environ.get("MTK_TRUST_X_FORWARDED_FOR") == "1"


def test_load_workspace_sanitizes_env_ui(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(dw, "workspace_file_path", lambda: tmp_path / "ws.json")
    raw = {
        "version": 1,
        "onboarding_done": True,
        "active_profile_id": None,
        "profiles": [],
        "env_ui": {
            "MTK_HTTP_PORT": "8766",
            "  ": "x",
            "MTK_TRUST_X_FORWARDED_FOR": "",
            "MTK_PROXY_LOCAL_ONLY": True,
        },
    }
    dw.save_workspace(raw)
    loaded = dw.load_workspace()
    assert loaded["env_ui"] == {
        "MTK_HTTP_PORT": "8766",
        "MTK_PROXY_LOCAL_ONLY": "1",
    }


def test_save_load_roundtrip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dw, "workspace_file_path", lambda: tmp_path / "dashboard-workspace.json")
    data = {
        "version": 1,
        "onboarding_done": True,
        "active_profile_id": "x",
        "profiles": [{"id": "x", "label": "X", "router_host": "1.2.3.4"}],
    }
    p = dw.save_workspace(data)
    assert p.is_file()
    loaded = dw.load_workspace()
    assert loaded["active_profile_id"] == "x"
    assert loaded["profiles"][0]["router_host"] == "1.2.3.4"
    assert loaded.get("env_ui") == {}


def test_status_show_wizard(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dw, "workspace_file_path", lambda: tmp_path / "missing.json")
    monkeypatch.delenv("MTK_PASSWORD", raising=False)
    monkeypatch.delenv("MTK_SERVICE_URL", raising=False)
    st = dw.workspace_public_status(dw.load_workspace())
    assert st["show_setup_wizard"] is True


def test_status_no_wizard_when_env_password(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dw, "workspace_file_path", lambda: tmp_path / "missing.json")
    monkeypatch.setenv("MTK_PASSWORD", "from-shell")
    st = dw.workspace_public_status(dw.load_workspace())
    assert st["show_setup_wizard"] is False
