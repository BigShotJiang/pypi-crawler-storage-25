"""Two-slot VPN site (US + UK): checkpoint validation after a gateway change.

Run all VPN checkpoint tests::

    python -m pytest tests/test_vpn_us_uk_setup.py -v

Show checkpoint JSON in the terminal::

    python -m pytest tests/test_vpn_us_uk_setup.py -v -s --tb=no -k demo_print_checkpoints
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest

from mtk_router_sdk.config import load_site_config
from mtk_router_sdk.intent.runner import routing_mark_for_slot
from mtk_router_sdk.ops.vpn_checkpoint import build_vpn_checkpoint, read_slot_vpn_checkpoint


def _site_us_uk_two_slots() -> object:
    """Site with slot 2 = US, slot 3 = UK (typical dual-VPN setup).

    For **real** VPN user/password/endpoints, use a copied site JSON (see
    ``examples/site.example.json``) or edit the literals below:

    * **Endpoints:** ``vpn_registry`` — each key must match ``slots[].region``;
      value is the L2TP ``connect-to`` hostname or IP.
    * **VPN login:** ``global.vpn_credentials`` uses ``env:...`` refs; put
      actual values in the ``env=`` dict (or export ``MTK_VPN_USER`` /
      ``MTK_VPN_PASSWORD`` for CLI/bootstrap). These checkpoint tests do not
      dial the VPN; use dummies unless you are experimenting locally.
    """
    return load_site_config(
        {
            "version": 1,
            "global": {
                "max_slots": 8,
                "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
                "vpn_credentials": {
                    "user_ref": "env:MTK_VPN_USER",
                    "password_ref": "env:MTK_VPN_PASSWORD",
                },
            },
            # Replace hostnames with your L2TP server IPs or DNS names (per region).
            "vpn_registry": {"US": "us.vpn.example", "UK": "uk.vpn.example"},
            "bootstrap": {"provision_tunnels": "none"},
            "slots": [
                {
                    "id": 2,
                    "enabled": True,
                    "ssid": "Corp-US",
                    "region": "US",
                    "tunnel_name": "l2tp-us",
                },
                {
                    "id": 3,
                    "enabled": True,
                    "ssid": "Corp-UK",
                    "region": "UK",
                    "tunnel_name": "l2tp-uk",
                },
            ],
        },
        env={
            "X": "a",
            # Replace for local runs; prefer real secrets only via OS env, not committed files.
            "MTK_VPN_USER": "replace-vpn-username",
            "MTK_VPN_PASSWORD": "replace-vpn-password",
        },
    )


@pytest.fixture
def site_us_uk() -> object:
    return _site_us_uk_two_slots()


def test_us_slot_success_message_contains_region(site_us_uk: object) -> None:
    site = site_us_uk
    client = MagicMock()
    mark = routing_mark_for_slot(site, 2)
    routes = [{"routing-mark": mark, "gateway": "l2tp-us", "dst-address": "0.0.0.0/0"}]
    l2tp = [
        {
            "name": "l2tp-us",
            "running": "true",
            "disabled": "false",
            "connect-to": "us.vpn.example",
        }
    ]
    cp = build_vpn_checkpoint(client, site, 2, mark, "l2tp-us", route_rows=routes, l2tp_rows=l2tp)  # type: ignore[arg-type]
    assert cp["status"] == "success"
    assert cp["region"] == "US"
    assert cp["ssid"] == "Corp-US"
    assert "US" in cp["user_message"] or "slot 2" in cp["user_message"]
    assert cp["checks"]["policy_gateway_matches"] is True
    assert cp["checks"]["l2tp_tunnel_running"] is True


def test_uk_slot_success_message_contains_region(site_us_uk: object) -> None:
    site = site_us_uk
    client = MagicMock()
    mark = routing_mark_for_slot(site, 3)
    routes = [{"routing-mark": mark, "gateway": "l2tp-uk", "dst-address": "0.0.0.0/0"}]
    l2tp = [
        {
            "name": "l2tp-uk",
            "running": "true",
            "disabled": "false",
            "connect-to": "uk.vpn.example",
        }
    ]
    cp = build_vpn_checkpoint(client, site, 3, mark, "l2tp-uk", route_rows=routes, l2tp_rows=l2tp)  # type: ignore[arg-type]
    assert cp["status"] == "success"
    assert cp["region"] == "UK"
    assert cp["ssid"] == "Corp-UK"
    assert "UK" in cp["user_message"] or "slot 3" in cp["user_message"]


def test_both_slots_on_shared_route_table(site_us_uk: object) -> None:
    """One /ip route print can list both policy marks; each checkpoint uses the right row."""
    site = site_us_uk
    client = MagicMock()
    m2 = routing_mark_for_slot(site, 2)
    m3 = routing_mark_for_slot(site, 3)
    routes = [
        {"routing-mark": m2, "gateway": "l2tp-us"},
        {"routing-mark": m3, "gateway": "l2tp-uk"},
    ]
    l2tp = [
        {"name": "l2tp-us", "running": "true", "disabled": "false"},
        {"name": "l2tp-uk", "running": "true", "disabled": "false"},
    ]
    cp_us = build_vpn_checkpoint(client, site, 2, m2, "l2tp-us", route_rows=routes, l2tp_rows=l2tp)  # type: ignore[arg-type]
    cp_uk = build_vpn_checkpoint(client, site, 3, m3, "l2tp-uk", route_rows=routes, l2tp_rows=l2tp)  # type: ignore[arg-type]
    assert cp_us["status"] == "success"
    assert cp_uk["status"] == "success"
    assert cp_us["region"] == "US"
    assert cp_uk["region"] == "UK"


def test_us_slot_route_mismatch_after_vpn_change_still_labels_us(site_us_uk: object) -> None:
    """Simulate 'we asked for l2tp-us but router still on old gateway' — region stays US."""
    site = site_us_uk
    client = MagicMock()
    mark = routing_mark_for_slot(site, 2)
    routes = [{"routing-mark": mark, "gateway": "l2tp-uk"}]
    l2tp = [{"name": "l2tp-us", "running": "false"}]
    cp = build_vpn_checkpoint(client, site, 2, mark, "l2tp-us", route_rows=routes, l2tp_rows=l2tp)  # type: ignore[arg-type]
    assert cp["status"] == "route_mismatch"
    assert cp["region"] == "US"
    assert "US" in cp["user_message"]


def test_read_slot_vpn_checkpoint_us_and_uk(site_us_uk: object) -> None:
    site = site_us_uk
    m2 = routing_mark_for_slot(site, 2)
    m3 = routing_mark_for_slot(site, 3)
    routes = [
        {"routing-mark": m2, "gateway": "l2tp-us"},
        {"routing-mark": m3, "gateway": "l2tp-uk"},
    ]
    l2tp = [
        {"name": "l2tp-us", "running": "true"},
        {"name": "l2tp-uk", "running": "true"},
    ]

    def _terse(menu: str, **_k: object) -> list[dict]:
        if "route" in menu:
            return routes
        if "l2tp" in menu:
            return l2tp
        return []

    client = MagicMock()
    client.exec_print_terse.side_effect = _terse
    cp2 = read_slot_vpn_checkpoint(client, site, 2, m2)  # type: ignore[arg-type]
    cp3 = read_slot_vpn_checkpoint(client, site, 3, m3)  # type: ignore[arg-type]
    assert cp2["gateway_interface"] == "l2tp-us" and cp2["status"] == "success"
    assert cp3["gateway_interface"] == "l2tp-uk" and cp3["status"] == "success"


def test_demo_print_checkpoints(
    site_us_uk: object,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Optional: run with ``-s`` to print JSON checkpoints to the terminal."""
    site = site_us_uk
    m2 = routing_mark_for_slot(site, 2)
    m3 = routing_mark_for_slot(site, 3)
    routes = [
        {"routing-mark": m2, "gateway": "l2tp-us"},
        {"routing-mark": m3, "gateway": "l2tp-uk"},
    ]
    l2tp = [
        {"name": "l2tp-us", "running": "true", "disabled": "false"},
        {"name": "l2tp-uk", "running": "false", "disabled": "false"},
    ]
    client = MagicMock()
    ok_us = build_vpn_checkpoint(
        client, site, 2, m2, "l2tp-us", route_rows=routes, l2tp_rows=l2tp
    )  # type: ignore[arg-type]
    down_uk = build_vpn_checkpoint(
        client, site, 3, m3, "l2tp-uk", route_rows=routes, l2tp_rows=l2tp
    )  # type: ignore[arg-type]
    lines = [
        "=== US slot (2) — full success ===",
        json.dumps(
            {k: ok_us[k] for k in ("status", "region", "ssid", "user_message", "checks")},
            indent=2,
        ),
        "=== UK slot (3) — route OK, tunnel down ===",
        json.dumps(
            {k: down_uk[k] for k in ("status", "region", "ssid", "user_message", "checks")},
            indent=2,
        ),
    ]
    print("\n".join(lines))
    out = capsys.readouterr().out
    assert "success" in out
    assert "route_ok_tunnel_down" in out

