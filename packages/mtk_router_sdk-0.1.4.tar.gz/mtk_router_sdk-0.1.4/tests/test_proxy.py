"""Tests for the proxy engine."""

from __future__ import annotations

import os

import pytest

from mtk_router_sdk.proxy.models import ProxyAction, ProxyRule
from mtk_router_sdk.proxy.sdk import ProxyError, ProxyManager
from mtk_router_sdk.proxy.store import ProxyLogStore, ProxyRuleStore


class TestProxyRule:
    """Test ProxyRule matching."""

    def test_matches_exact_path(self) -> None:
        rule = ProxyRule(path_pattern="/api/v1/region")
        assert rule.matches_path("/api/v1/region")
        assert not rule.matches_path("/api/v1/user")

    def test_matches_glob_pattern(self) -> None:
        rule = ProxyRule(path_pattern="/api/*/catalog")
        assert rule.matches_path("/api/v1/catalog")
        assert rule.matches_path("/api/v2/catalog")
        assert not rule.matches_path("/api/v1/user")

    def test_matches_wildcard_all(self) -> None:
        rule = ProxyRule(path_pattern="*")
        assert rule.matches_path("/anything")
        assert rule.matches_path("/api/v1/test")

    def test_matches_request_with_client_ip(self) -> None:
        rule = ProxyRule(
            client_ip="192.168.2.100",
            path_pattern="/api/*",
        )
        assert rule.matches_request("192.168.2.100", "api.example.com", "/api/test", "GET")
        assert not rule.matches_request("192.168.2.101", "api.example.com", "/api/test", "GET")

    def test_disabled_rule_does_not_match(self) -> None:
        rule = ProxyRule(
            path_pattern="/api/*",
            enabled=False,
        )
        assert not rule.matches_request("192.168.2.100", "api.example.com", "/api/test", "GET")

    def test_to_dict_and_from_dict(self) -> None:
        rule = ProxyRule(
            name="Test Rule",
            client_ip="192.168.2.100",
            path_pattern="/api/v1/*",
            action=ProxyAction.OVERRIDE,
            response_status=200,
            response_body={"test": "data"},
        )
        d = rule.to_dict()
        restored = ProxyRule.from_dict(d)
        assert restored.name == rule.name
        assert restored.client_ip == rule.client_ip
        assert restored.path_pattern == rule.path_pattern
        assert restored.action == rule.action


class TestProxyRuleStore:
    """Test ProxyRuleStore operations."""

    def test_add_and_get(self) -> None:
        store = ProxyRuleStore()
        rule = ProxyRule(name="Test", path_pattern="/api/*")
        added = store.add(rule)
        assert added.id == rule.id
        retrieved = store.get(rule.id)
        assert retrieved is not None
        assert retrieved.name == "Test"

    def test_delete(self) -> None:
        store = ProxyRuleStore()
        rule = ProxyRule(name="Test")
        store.add(rule)
        assert store.delete(rule.id)
        assert store.get(rule.id) is None

    def test_delete_by_client_ip(self) -> None:
        store = ProxyRuleStore()
        store.add(ProxyRule(client_ip="192.168.2.100"))
        store.add(ProxyRule(client_ip="192.168.2.100"))
        store.add(ProxyRule(client_ip="192.168.2.101"))
        
        deleted = store.delete_by_client_ip("192.168.2.100")
        assert deleted == 2
        assert store.count() == 1

    def test_find_matching(self) -> None:
        store = ProxyRuleStore()
        store.add(ProxyRule(
            client_ip="192.168.2.100",
            path_pattern="/api/v1/region",
            action=ProxyAction.OVERRIDE,
        ))
        store.add(ProxyRule(
            client_ip="192.168.2.100",
            path_pattern="/api/*",
            action=ProxyAction.PASSTHROUGH,
        ))
        
        # Should match more specific rule
        match = store.find_matching(
            "192.168.2.100", "api.example.com", "/api/v1/region", "GET"
        )
        assert match is not None
        assert match.action == ProxyAction.OVERRIDE

    def test_find_matching_specific_path_wins_when_added_after_broad_rule(self) -> None:
        store = ProxyRuleStore()
        store.add(
            ProxyRule(
                client_ip="192.168.2.100",
                path_pattern="/api/*",
                action=ProxyAction.PASSTHROUGH,
            )
        )
        store.add(
            ProxyRule(
                client_ip="192.168.2.100",
                path_pattern="/api/v1/region",
                action=ProxyAction.OVERRIDE,
            )
        )
        match = store.find_matching(
            "192.168.2.100", "api.example.com", "/api/v1/region", "GET"
        )
        assert match is not None
        assert match.action == ProxyAction.OVERRIDE

    def test_priority_ordering(self) -> None:
        store = ProxyRuleStore()
        low = ProxyRule(name="Low", priority=0, path_pattern="*")
        high = ProxyRule(name="High", priority=10, path_pattern="*")
        store.add(low)
        store.add(high)
        
        rules = store.list_all()
        assert rules[0].name == "High"
        assert rules[1].name == "Low"


class TestProxyLogStore:
    """Test ProxyLogStore operations."""

    def test_add_and_list(self) -> None:
        from mtk_router_sdk.proxy.models import ProxyLogEntry
        
        store = ProxyLogStore(max_entries=100)
        store.add(ProxyLogEntry(client_ip="192.168.2.100", path="/api/test"))
        store.add(ProxyLogEntry(client_ip="192.168.2.101", path="/api/other"))
        
        all_entries = store.list_all()
        assert len(all_entries) == 2

    def test_max_entries_enforced(self) -> None:
        from mtk_router_sdk.proxy.models import ProxyLogEntry
        
        store = ProxyLogStore(max_entries=5)
        for i in range(10):
            store.add(ProxyLogEntry(path=f"/api/{i}"))
        
        assert store.count() == 5

    def test_list_by_client_ip(self) -> None:
        from mtk_router_sdk.proxy.models import ProxyLogEntry
        
        store = ProxyLogStore()
        store.add(ProxyLogEntry(client_ip="192.168.2.100", path="/api/1"))
        store.add(ProxyLogEntry(client_ip="192.168.2.101", path="/api/2"))
        store.add(ProxyLogEntry(client_ip="192.168.2.100", path="/api/3"))
        
        filtered = store.list_by_client_ip("192.168.2.100")
        assert len(filtered) == 2


class TestProxyManager:
    """Test ProxyManager SDK interface."""

    def test_set_response(self) -> None:
        proxy = ProxyManager()
        rule = proxy.set_response(
            "192.168.2.100",
            "/api/v1/region",
            {"region": "US"},
        )
        assert rule.client_ip == "192.168.2.100"
        assert rule.path_pattern == "/api/v1/region"
        assert rule.action == ProxyAction.OVERRIDE
        assert rule.response_body == {"region": "US"}

    def test_set_responses_bulk(self) -> None:
        proxy = ProxyManager()
        rules = proxy.set_responses("192.168.2.100", {
            "/api/v1/region": {"region": "US"},
            "/api/v1/user": {"name": "Test"},
        })
        assert len(rules) == 2

    def test_set_error(self) -> None:
        proxy = ProxyManager()
        rule = proxy.set_error(
            "192.168.2.100",
            "/api/v1/auth",
            status=401,
        )
        assert rule.action == ProxyAction.ERROR
        assert rule.response_status == 401

    def test_set_delay(self) -> None:
        proxy = ProxyManager()
        rule = proxy.set_delay(
            "192.168.2.100",
            "/api/*",
            delay_ms=3000,
        )
        assert rule.action == ProxyAction.DELAY
        assert rule.delay_ms == 3000

    def test_set_modifier(self) -> None:
        proxy = ProxyManager()
        rule = proxy.set_modifier(
            "192.168.2.100",
            "/api/v1/user",
            json_set={"$.subscription": "premium"},
        )
        assert rule.action == ProxyAction.MODIFY
        assert rule.json_set == {"$.subscription": "premium"}

    def test_clear_endpoint(self) -> None:
        proxy = ProxyManager()
        proxy.set_response("192.168.2.100", "/api/v1/region", {"region": "US"})
        proxy.set_response("192.168.2.100", "/api/v1/user", {"name": "Test"})
        
        cleared = proxy.clear_endpoint("192.168.2.100", "/api/v1/region")
        assert cleared == 1
        assert len(proxy.list_rules("192.168.2.100")) == 1

    def test_clear_device(self) -> None:
        proxy = ProxyManager()
        proxy.set_response("192.168.2.100", "/api/v1/region", {"region": "US"})
        proxy.set_response("192.168.2.100", "/api/v1/user", {"name": "Test"})
        proxy.set_response("192.168.2.101", "/api/v1/region", {"region": "UK"})
        
        cleared = proxy.clear_device("192.168.2.100")
        assert cleared == 2
        assert len(proxy.list_rules("192.168.2.100")) == 0
        assert len(proxy.list_rules("192.168.2.101")) == 1

    def test_invalid_ip_raises_error(self) -> None:
        proxy = ProxyManager()
        with pytest.raises(ProxyError) as exc:
            proxy.set_response("invalid-ip", "/api/test", {})
        assert exc.value.code == "INVALID_IP"

    def test_invalid_endpoint_raises_error(self) -> None:
        proxy = ProxyManager()
        with pytest.raises(ProxyError) as exc:
            proxy.set_response("192.168.2.100", "no-leading-slash", {})
        assert exc.value.code == "INVALID_ENDPOINT"

    def test_replaces_existing_rule_for_same_endpoint(self) -> None:
        proxy = ProxyManager()
        proxy.set_response("192.168.2.100", "/api/v1/region", {"region": "US"})
        proxy.set_response("192.168.2.100", "/api/v1/region", {"region": "UK"})
        
        rules = proxy.list_rules("192.168.2.100")
        assert len(rules) == 1
        assert rules[0].response_body == {"region": "UK"}


class TestProxyManagerRemote:
    """SDK talks to mtk-serve HTTP API (same store as /v1/proxy/*)."""

    def test_remote_roundtrip_via_asgi(self) -> None:
        pytest.importorskip("starlette")

        from mtk_router_sdk.service.app import create_app

        prev = os.environ.pop("MTK_SERVICE_TOKEN", None)
        try:
            app = create_app()
            pm = ProxyManager(asgi_app=app)
            try:
                pm.set_response("192.168.1.20", "/api/test", {"region": "US"})
                rules = pm.list_rules()
                assert len(rules) == 1
                assert rules[0].path_pattern == "/api/test"
                assert rules[0].client_ip == "192.168.1.20"
                n = pm.clear_all()
                assert n >= 1
                assert pm.list_rules() == []
            finally:
                pm.close()
        finally:
            if prev is not None:
                os.environ["MTK_SERVICE_TOKEN"] = prev


class TestCertManager:
    """Test CertManager certificate handling."""

    def test_cert_dir_path(self) -> None:
        from mtk_router_sdk.proxy.certs import CertManager
        
        certs = CertManager("/tmp/test-certs")
        assert certs.cert_dir.as_posix() == "/tmp/test-certs"
        assert certs.ca_key_path().as_posix() == "/tmp/test-certs/ca.key"
        assert certs.ca_cert_path().as_posix() == "/tmp/test-certs/ca.crt"
        assert certs.proxy_key_path().as_posix() == "/tmp/test-certs/proxy.key"
        assert certs.proxy_cert_path().as_posix() == "/tmp/test-certs/proxy.crt"

    def test_certs_exist_false_when_missing(self) -> None:
        import tempfile

        from mtk_router_sdk.proxy.certs import CertManager
        
        with tempfile.TemporaryDirectory() as tmpdir:
            certs = CertManager(tmpdir)
            assert certs.certs_exist() is False

    def test_status_returns_dict(self) -> None:
        import tempfile

        from mtk_router_sdk.proxy.certs import CertManager
        
        with tempfile.TemporaryDirectory() as tmpdir:
            certs = CertManager(tmpdir)
            status = certs.status()
            assert "cert_dir" in status
            assert "certs_exist" in status
            assert status["certs_exist"] is False
            assert "ca_cert" in status
            assert "proxy_cert" in status
            assert "install_instructions" in status


def test_proxy_manager_certs_status_local() -> None:
    pm = ProxyManager()
    try:
        st = pm.certs_status()
        assert "cert_dir" in st
        assert "ca_cert" in st
        assert "proxy_cert" in st
    finally:
        pm.close()
