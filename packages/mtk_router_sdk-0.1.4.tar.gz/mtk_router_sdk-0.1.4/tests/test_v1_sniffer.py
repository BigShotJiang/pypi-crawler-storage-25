from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from mtk_router_sdk.models import ExecResult
from mtk_router_sdk.service.app import create_app


def _minimal_site() -> dict:
    return {
        "version": 1,
        "global": {
            "max_slots": 8,
            "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
            "vpn_credentials": {
                "user_ref": "env:U",
                "password_ref": "env:P",
            },
        },
        "vpn_registry": {"US": "h"},
        "bootstrap": {"provision_tunnels": "none"},
        "slots": [{"id": 2, "enabled": True, "ssid": "g", "region": "US"}],
    }


@pytest.fixture
def app_with_site(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("X", "psk")
    monkeypatch.setenv("U", "u")
    monkeypatch.setenv("P", "p")
    from mtk_router_sdk.config import load_site_config

    wrapped = create_app()
    inner = wrapped.app
    st = inner.state.mtk
    st.site = load_site_config(_minimal_site(), env=dict(os.environ))
    return wrapped


def test_sniffer_start_requires_lease(app_with_site) -> None:
    client = TestClient(app_with_site)
    r = client.post("/v1/slots/2/sniffer/start", json={"filter_ip_address": "10.0.0.1"})
    assert r.status_code == 400
    assert "lease" in r.json().get("detail", "").lower()


def test_sniffer_start_requires_ipv4(app_with_site) -> None:
    client = TestClient(app_with_site)
    lr = client.post("/v1/slots/2/control/lease", json={"actor": "t", "ttl_s": 60})
    token = lr.json()["lease_token"]
    r = client.post(
        "/v1/slots/2/sniffer/start",
        json={"filter_ip_address": "not-an-ip"},
        headers={"X-Slot-Lease": token},
    )
    assert r.status_code == 400


@patch("mtk_router_sdk.service.v1_routes._with_client")
def test_sniffer_start_ok(mock_wc: MagicMock, app_with_site) -> None:
    def fake_with(st, fn, timeout=120.0):
        class FakeClient:
            def exec_command(self, *_a, **_k):
                return ExecResult(
                    stdout="  running: yes\n  file-name: mtk_slot2_10_0_0_1.pcap\n",
                    stderr="",
                    exit_status=0,
                )

        return fn(FakeClient())

    mock_wc.side_effect = fake_with

    client = TestClient(app_with_site)
    lr = client.post("/v1/slots/2/control/lease", json={"actor": "t", "ttl_s": 60})
    token = lr.json()["lease_token"]
    r = client.post(
        "/v1/slots/2/sniffer/start",
        json={"filter_ip_address": "10.0.0.1"},
        headers={"X-Slot-Lease": token},
    )
    assert r.status_code == 200
    data = r.json()
    assert data.get("ok") is True
    assert data.get("interface") == "slot_2"
    assert data.get("file_name") == "mtk_slot2_10_0_0_1.pcap"


@patch("mtk_router_sdk.service.v1_routes._with_client")
def test_sniffer_stop_ok(mock_wc: MagicMock, app_with_site) -> None:
    def fake_with(st, fn, timeout=120.0):
        class FakeClient:
            def exec_command(self, *_a, **_k):
                return ExecResult(stdout="  running: no\n", stderr="", exit_status=0)

        return fn(FakeClient())

    mock_wc.side_effect = fake_with

    client = TestClient(app_with_site)
    lr = client.post("/v1/slots/2/control/lease", json={"actor": "t", "ttl_s": 60})
    token = lr.json()["lease_token"]
    r = client.post("/v1/slots/2/sniffer/stop", headers={"X-Slot-Lease": token})
    assert r.status_code == 200
    assert r.json().get("ok") is True
