from __future__ import annotations

import pytest

from mtk_router_sdk.client_resolve import (
    infer_slot_from_dhcp_server_name,
    resolve_client_slot,
)
from mtk_router_sdk.config import load_site_config


def _site(**kwargs: object) -> object:
    base = {
        "version": 1,
        "global": {
            "max_slots": 8,
            "wifi_security": {"profile_name": "x", "psk_ref": "env:X"},
            "vpn_credentials": {"user_ref": "env:U", "password_ref": "env:P"},
        },
        "vpn_registry": {"US": "h"},
        "bootstrap": {"provision_tunnels": "none"},
        "slots": [
            {
                "id": 2,
                "enabled": True,
                "ssid": "GuestWiFi",
                "region": "US",
                "subnet": "172.20.101.0/24",
            },
            {
                "id": 3,
                "enabled": True,
                "ssid": "Other",
                "region": "US",
            },
        ],
    }
    base.update(kwargs)
    return load_site_config(base, env={"X": "a", "U": "b", "P": "c"})


def test_subnet_match() -> None:
    site = _site()
    ctx = resolve_client_slot(site, "172.20.101.50", dhcp_rows=None, env={})
    assert ctx.resolved
    assert ctx.slot_id == 2
    assert ctx.match_method == "subnet_cidr"
    assert ctx.ssid == "GuestWiFi"


def test_dhcp_server_match() -> None:
    site = _site()
    rows = [
        {
            "address": "10.0.0.5",
            "active-address": "10.0.0.5",
            "server": "dhcp_3",
        },
    ]
    ctx = resolve_client_slot(site, "10.0.0.5", dhcp_rows=rows, env={})
    assert ctx.resolved
    assert ctx.slot_id == 3
    assert ctx.match_method == "dhcp_server"
    assert ctx.dhcp_server == "dhcp_3"


def test_site_fallback() -> None:
    site = _site()
    site.global_.client_fallback_slot_id = 3
    ctx = resolve_client_slot(site, "8.8.8.8", dhcp_rows=None, env={})
    assert ctx.resolved
    assert ctx.slot_id == 3
    assert ctx.match_method == "site_fallback"


def test_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    site = _site()
    monkeypatch.setenv("MTK_CLIENT_FALLBACK_SLOT_ID", "3")
    ctx = resolve_client_slot(site, "8.8.8.8", dhcp_rows=None, env=None)
    assert ctx.resolved
    assert ctx.slot_id == 3
    assert ctx.match_method == "env_fallback"


def test_infer_slot_from_dhcp_server_name_disabled_slot() -> None:
    site = _site()
    site.slots[1].enabled = False
    assert infer_slot_from_dhcp_server_name("dhcp_3", site) is None


def test_unresolved() -> None:
    site = _site()
    ctx = resolve_client_slot(site, "8.8.8.8", dhcp_rows=None, env={})
    assert not ctx.resolved
