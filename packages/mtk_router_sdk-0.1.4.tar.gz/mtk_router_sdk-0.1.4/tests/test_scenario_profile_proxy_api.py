"""Regression: scenario/profile steps must call ProxyManager with valid signatures."""

from __future__ import annotations

from unittest.mock import MagicMock

from mtk_router_sdk.proxy.models import ProxyAction
from mtk_router_sdk.proxy.sdk import ProxyManager
from mtk_router_sdk.testing.profiles import ProfileManager
from mtk_router_sdk.testing.scenarios import ScenarioRunner


def test_scenario_proxy_error_passes_response_kwarg() -> None:
    kit = MagicMock()
    kit.proxy = ProxyManager()
    runner = ScenarioRunner(kit=kit)
    ok = runner._execute_action(
        "proxy_error",
        "192.168.1.50",
        {"path": "/api/x", "status": 503, "body": {"error": "nope"}},
    )
    assert ok is True
    rules = kit.proxy.list_rules("192.168.1.50")
    assert len(rules) == 1
    assert rules[0].action == ProxyAction.ERROR
    assert rules[0].response_status == 503


def test_scenario_proxy_set_respects_status() -> None:
    kit = MagicMock()
    kit.proxy = ProxyManager()
    runner = ScenarioRunner(kit=kit)
    ok = runner._execute_action(
        "proxy_set",
        "192.168.1.51",
        {"path": "/api/y", "body": {"a": 1}, "status": 201},
    )
    assert ok is True
    rules = kit.proxy.list_rules("192.168.1.51")
    assert len(rules) == 1
    assert rules[0].response_status == 201


def test_profile_proxy_error_and_status(tmp_path) -> None:
    kit = MagicMock()
    kit._site = None
    kit._client = None
    kit.proxy = ProxyManager()

    pm = ProfileManager(kit=kit, profiles_dir=tmp_path / "p")
    (tmp_path / "p").mkdir()
    prof = {
        "name": "t",
        "description": "",
        "proxy": {
            "rules": [
                {"path": "/z", "action": "error", "status": 418, "body": {"e": 1}},
                {"path": "/w", "action": "override", "status": 202, "body": {"k": 2}},
            ],
        },
    }
    from mtk_router_sdk.testing.profiles import TestProfile

    pm._apply_proxy(TestProfile.from_dict(prof), "10.0.0.55")
    rules = kit.proxy.list_rules("10.0.0.55")
    assert {r.path_pattern for r in rules} == {"/z", "/w"}
    by_path = {r.path_pattern: r for r in rules}
    assert by_path["/z"].response_status == 418
    assert by_path["/w"].response_status == 202
