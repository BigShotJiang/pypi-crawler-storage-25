from __future__ import annotations

import ipaddress

from mtk_router_sdk.net.lan_subnets import iter_ping_targets, local_ipv4_lan_networks


def test_local_ipv4_lan_networks_parses_linux_ip_output(monkeypatch) -> None:
    sample = (
        "2: eth0    inet 192.168.88.5/24 brd 192.168.88.255 scope global eth0\n"
        "3: docker0    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0\n"
    )

    def fake_run(cmd: list[str], **kwargs: object) -> str | None:
        return sample

    monkeypatch.setattr("mtk_router_sdk.net.lan_subnets.sys.platform", "linux")
    monkeypatch.setattr("mtk_router_sdk.net.lan_subnets._run", fake_run)
    nets = local_ipv4_lan_networks()
    assert any(str(n[1]) == "192.168.88.0/24" for n in nets)


def test_local_ipv4_adds_gateway_sl24_when_not_covered(monkeypatch) -> None:
    monkeypatch.setattr("mtk_router_sdk.net.lan_subnets.sys.platform", "linux")
    monkeypatch.setattr("mtk_router_sdk.net.lan_subnets._linux_global_subnets", lambda: [])
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda **k: "192.168.1.1",
    )
    nets = local_ipv4_lan_networks()
    assert any(str(n[1]) == "192.168.1.0/24" for n in nets)


def test_local_ipv4_skips_gateway_hint_when_gw_already_in_interface_net(monkeypatch) -> None:
    monkeypatch.setattr("mtk_router_sdk.net.lan_subnets.sys.platform", "linux")
    n = ipaddress.ip_network("192.168.1.0/24", strict=False)
    monkeypatch.setattr(
        "mtk_router_sdk.net.lan_subnets._linux_global_subnets",
        lambda: [("eth0", n)],
    )
    monkeypatch.setattr(
        "mtk_router_sdk.net.gateway.get_default_ipv4_gateway",
        lambda **k: "192.168.1.1",
    )
    nets = local_ipv4_lan_networks()
    assert sum(1 for x in nets if str(x[1]) == "192.168.1.0/24") == 1


def test_iter_ping_targets_skips_huge_networks() -> None:
    big = ipaddress.ip_network("10.0.0.0/8", strict=False)
    small = ipaddress.ip_network("192.168.1.0/24", strict=False)
    pairs = [(None, big), ("en0", small)]
    ips = [ip for ip, _ in iter_ping_targets(pairs, max_hosts_per_network=254)]
    assert "192.168.1.1" in ips
    assert not any(str(x).startswith("10.") for x in ips)
