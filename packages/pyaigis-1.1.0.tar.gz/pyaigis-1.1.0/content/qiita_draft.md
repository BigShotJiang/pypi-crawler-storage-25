# AIエージェント導入で「セキュリティは？」と聞かれたときに見せる技術対策

## この記事は誰向け？

- 社内でClaude Code / Cursor / ChatGPTなどのAIツールを使いたいエンジニア
- 「セキュリティリスクが…」と言われて導入検討が進まないチーム
- 情シスとして「AIツールの技術的なセキュリティ対策を知りたい」人

**`pip install aigis && aig init` の2コマンドで、AIエージェントの操作ログ・権限制御・脅威検知の技術基盤が導入できます。** 導入検討のセキュリティ面の材料として活用できます。

## よくある社内の会話

```
エンジニア「Claude Code導入したいです」
情シス「AIが社内のコードを勝手に外部に送ったりしない？」
エンジニア「…たぶん大丈夫です」
情シス「たぶんじゃダメです。却下。」
```

これ、**情シスが悪いわけじゃない**です。彼らに必要なのは：

1. AIエージェントが**何をしているか可視化**できること
2. 危険な操作を**ポリシーでブロック**できること
3. 「いつ誰が何をした」の**監査ログ**があること
4. 日本の**AI規制に対応**している証拠

要するに「AIの操作を全部丸裸にして、制御して、記録する」仕組みがあればいい。

## Aigisで解決する

### ステップ1: インストール＆初期化（30秒）

```bash
pip install aigis
aig init --agent claude-code
```

これだけで以下が自動セットアップされます：

- `aigis-policy.yaml` — 14のデフォルトセキュリティルール
- `.claude/hooks/aig-guard.py` — Claude Codeの全操作を自動監視
- `.aigis/logs/` — 操作ログの保存先

### ステップ2: 何が起きるか

この状態でClaude Codeを使うと、**全ツール呼び出しが自動でインターセプト**されます。

```
Claude Code「Bashでrm -rf /を実行します」
  ↓
Aigis「ポリシー違反：再帰削除はブロック」
  ↓
Claude Code「ブロックされました。別のアプローチを試します」
```

ログに記録される内容：
```json
{
  "timestamp": "2026-03-28T15:30:00Z",
  "user_id": "tanaka",
  "agent_type": "claude_code",
  "action": "shell:exec",
  "target": "rm -rf /",
  "risk_score": 90,
  "policy_decision": "deny",
  "policy_rule_id": "dangerous_commands"
}
```

### ステップ3: 情シスに見せるもの

```bash
# 操作ログを見せる
aig logs

# ブロックされた操作だけ見せる
aig logs --alerts

# 全プロジェクト横断のログ（CISO向け）
aig logs --global

# Excelでサマリを出す（経営会議用）
aig logs --export-excel report

# コンプライアンスレポート
aig report --days 30
```

出力例：
```
Aigis - Governance Status
==================================================
  Policy: Aigis Developer Policy (v1.0)
  Rules: 14 (9 deny, 4 review)

  Activity (last 7 days):
    Total events: 342
    Blocked: 8

  Compliance: 100.0% (24/24 covered)
```

## デフォルトで何がブロックされるか

| 操作 | 判定 | 理由 |
|------|------|------|
| `rm -rf *` | **ブロック** | 再帰削除 |
| `.env`への書き込み | **ブロック** | 環境変数の保護 |
| `.ssh/`へのアクセス | **ブロック** | SSH鍵の保護 |
| `git push --force` | **ブロック** | 強制pushの防止 |
| `curl ... \| bash` | **ブロック** | リモートコード実行の防止 |
| `sudo` コマンド | **要レビュー** | 特権昇格は人間確認 |
| `git push` | **要レビュー** | pushは人間確認 |
| サブエージェント生成 | **要レビュー** | エージェント委任は人間確認 |

これは全て `aigis-policy.yaml` で自由にカスタマイズできます。

## ポリシーのカスタマイズ例

```yaml
# 自社の本番環境を守る
rules:
  - id: protect_production
    action: "shell:exec"
    target: "*production*"
    decision: deny
    reason: "本番環境への操作は禁止"

  - id: protect_customer_data
    action: "file:read"
    target: "*customer*"
    decision: review
    reason: "顧客データへのアクセスはレビュー必要"
```

## ログの構造

```
ローカルログ（エンジニアが見る）
  .aigis/logs/2026-03-28.jsonl

グローバルログ（情シス/CISOが見る）
  ~/.aigis/global/2026-03-28.jsonl

アラートアーカイブ（永久保存、ナレッジ蓄積）
  ~/.aigis/alerts/2026-03-28.jsonl
```

- 全ログ：60日保存 → 自動圧縮 → 自動削除
- アラート（ブロック/レビュー）：**永久保存**（将来の自動修正AIの学習データ）

## 日本のAI規制への対応

Aigis は日本の主要AI規制 **24要件を100%カバー** しています：

| 規制 | カバー |
|------|--------|
| AI推進法（2025年9月施行） | 3/3 |
| AI事業者ガイドライン v1.1 | 10/10 |
| AIセキュリティGL（総務省） | 6/6 |
| 個人情報保護法 / マイナンバー法 | 3/3 |
| 不正競争防止法 | 1/1 |
| 著作権法 | 1/1 |

```bash
# 規制対応状況を確認
aig report --days 30
# → Compliance: 100.0% (24/24 covered)
```

これを情シスに見せれば「AI規制対応は？」の質問に即答できます。

## 社内検討用メモのテンプレート

AIツール導入の技術面の検討材料として、以下のようなメモが使えます（自社の状況に合わせて修正してください）：

---

**件名：AIエージェントツール導入検討 — セキュリティ技術対策について**

AIエージェント（Claude Code）の導入検討にあたり、技術的なセキュリティ対策として以下の基盤を評価しました。

**評価ツール：** Aigis（OSS、Apache 2.0ライセンス、Python標準ライブラリのみ）

**技術対策の範囲：**
- 全エージェント操作の自動ログ記録（Activity Stream）
- 14のデフォルトセキュリティルールによる危険操作の自動ブロック
- ポリシーベースの権限制御（YAML設定、git管理可能）
- 日本AI規制24項目の技術要件への対応
- 監査ログのExcelエクスポート対応

**備考：** 技術対策以外に、コスト・運用体制・社内規程・契約面の検討が別途必要です。

**確認コマンド：**
```
aig status      # ガバナンス状態の確認
aig logs        # 操作ログの閲覧
aig report      # コンプライアンスレポート
```

---

## まとめ

| やること | コマンド |
|---------|---------|
| インストール | `pip install aigis` |
| 初期化 | `aig init --agent claude-code` |
| ログ確認 | `aig logs` |
| Excel出力 | `aig logs --export-excel report` |
| 情シスに見せる | `aig status` + `aig report` |

**AIツール導入の検討を前に進めたいなら、まず技術面の対策から。** Aigisはその選択肢の一つです。

- [GitHub](https://github.com/killertcell428/aigis)
- [PyPI](https://pypi.org/project/aigis/)
- [Gandalf Challenge](https://aigis-mauve.vercel.app/challenge) — AIのセキュリティを体験できるゲーム
