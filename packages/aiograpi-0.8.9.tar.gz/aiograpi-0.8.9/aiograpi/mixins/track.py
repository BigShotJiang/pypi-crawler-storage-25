from pathlib import Path
from typing import Any, Dict
from urllib.parse import urlparse

from aiograpi import httpx_ext
from aiograpi.exceptions import ClientError, TrackNotFound
from aiograpi.extractors import extract_track
from aiograpi.types import Track
from aiograpi.utils import json_value


class TrackMixin:
    async def track_download_by_url(
        self, url: str, filename: str = "", folder: Path = ""
    ) -> Path:
        """
        Download track by URL

        Parameters
        ----------
        url: str
            URL for a track
        filename: str, optional
            Filename for the track
        folder: Path, optional
            Directory in which you want to download the track, default
            is "" and will download the files to working directory

        Returns
        -------
        Path
            Path for the file downloaded
        """
        url = str(url)
        fname = urlparse(url).path.rsplit("/", 1)[1].strip()
        if not fname:
            raise Exception("The URL must contain the path to the file (m4a or mp3).")
        filename = "%s.%s" % (filename, fname.rsplit(".", 1)[1]) if filename else fname
        path = Path(folder) / filename
        response = await httpx_ext.get(url, timeout=self.request_timeout)
        response.raise_for_status()
        with open(path, "wb") as f:
            f.write(response.read())
        return path.resolve()

    async def _track_request(
        self, data: Dict[str, Any], path: str = "clips/music/"
    ) -> Dict:
        try:
            result = await self.private_request(path, data)
        except ClientError as e:
            if not self.last_json:
                kw = {
                    k: v
                    for k, v in data.items()
                    if k in {"music_canonical_id", "original_sound_audio_asset_id"}
                }
                raise TrackNotFound(**kw)
            raise e
        return result

    async def track_info_by_canonical_id(self, music_canonical_id: str) -> Track:
        """
        Get Track by music_canonical_id

        Parameters
        ----------
        music_canonical_id: str
            Unique identifier of the track

        Returns
        -------
        Track
            An object of Track type
        """
        data = {
            "tab_type": "clips",
            "referrer_media_id": "",
            "_uuid": self.uuid,
            "music_canonical_id": str(music_canonical_id),
        }
        result = await self._track_request(data)
        track = json_value(result, "metadata", "music_info", "music_asset_info")
        return extract_track(track)

    async def track_info_by_id(self, track_id: str, max_id: str = "") -> Dict:
        """
        Get Track by id

        Parameters
        ----------
        track_id: str
            Unique identifier of the track

        Returns
        -------
        Dict
            Raw insta response json
        """
        data = {
            "audio_cluster_id": track_id,
            "original_sound_audio_asset_id": track_id,
        }
        if max_id:
            data["max_id"] = max_id
        return await self._track_request(data)

    async def track_stream_info_by_id(self, track_id: str, max_id: str = "") -> Dict:
        """
        Fetch the streamed clips-pivot page for a given track id.

        ``POST /clips/stream_clips_pivot_page/`` — the surface IG's
        app uses to render the "Audio" page (clips that use this
        audio + the audio-asset metadata). Returns the raw payload so
        the caller can extract whatever they need (clip list, audio
        cluster info, etc.).

        Parameters
        ----------
        track_id: str
            Track identifier (used as both ``audio_asset_id`` and
            ``audio_cluster_id`` per IG's app behavior).
        max_id: str, default ""
            Pagination cursor for the next page of clips.

        Returns
        -------
        Dict
            Raw response.
        """
        data = {
            "pivot_page_type": "audio",
            "music_page": {
                "tab_type": "clips",
                "audio_asset_id": track_id,
                "audio_cluster_id": track_id,
            },
            "_uuid": self.uuid,
        }
        if max_id:
            data["music_page"]["max_id"] = max_id
        return await self._track_request(data, path="clips/stream_clips_pivot_page/")
