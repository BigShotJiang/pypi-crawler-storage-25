import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import click
import yaml

from .config import load_config, generate_stack_instances, write_config, DEFAULT_CONFIG_PATH
from .client import LokiClient, PrometheusClient, TempoClient, AlertingClient, GrafanaCloudClient


# Best practice defaults
DEFAULT_TIME_RANGE_MINUTES = 15  # Start with narrow time range
DEFAULT_LOKI_LIMIT = 50  # Reasonable limit for logs
DEFAULT_TEMPO_LIMIT = 20  # Reasonable limit for traces
DEFAULT_PROM_STEP = "60s"  # 1 minute resolution


def get_default_times(minutes: int = DEFAULT_TIME_RANGE_MINUTES) -> tuple[str, str]:
    """Get default start/end times (RFC3339) for the last N minutes."""
    now = datetime.now(timezone.utc)
    start = now - timedelta(minutes=minutes)
    return start.strftime("%Y-%m-%dT%H:%M:%SZ"), now.strftime("%Y-%m-%dT%H:%M:%SZ")


def get_default_times_unix(minutes: int = DEFAULT_TIME_RANGE_MINUTES) -> tuple[str, str]:
    """Get default start/end times (Unix seconds) for the last N minutes."""
    now = datetime.now(timezone.utc)
    start = now - timedelta(minutes=minutes)
    return str(int(start.timestamp())), str(int(now.timestamp()))


def _get_envelope(ctx) -> bool:
    """Check if envelope mode is enabled."""
    root_ctx = ctx.find_root()
    return root_ctx.params.get("envelope", False)


def _get_command_path(ctx) -> str:
    """Get the full command path (e.g., 'lgtm loki query')."""
    parts = []
    current = ctx
    while current:
        if current.info_name:
            parts.append(current.info_name)
        current = current.parent
    return " ".join(reversed(parts))


def _count_results(data) -> int | None:
    """Extract result count from API response data."""
    if isinstance(data, list):
        return len(data)
    if isinstance(data, dict):
        for key in ("result", "traces", "data"):
            inner = data.get(key)
            if inner is None:
                inner = data.get("data", {}).get("result") if key == "result" and isinstance(data.get("data"), dict) else None
            if isinstance(inner, list):
                return len(inner)
    return None


def output_json(data, ctx=None, hints: list[str] | None = None):
    """Output JSON data, optionally wrapped in an envelope."""
    if ctx and _get_envelope(ctx):
        count = _count_results(data)
        envelope = {
            "status": "success",
            "data": data,
            "metadata": {
                "command": _get_command_path(ctx),
            },
        }
        if count is not None:
            envelope["metadata"]["count"] = count
            if count == 0:
                envelope["metadata"]["empty"] = True
                envelope["metadata"]["message"] = "No results found"
        if hints:
            envelope["hints"] = hints
        click.echo(json.dumps(envelope, indent=2))
    else:
        click.echo(json.dumps(data, indent=2))


def output_error(msg: str, suggestions: list[str] | None = None, ctx=None):
    """Output error message. In envelope mode, writes structured JSON to stdout
    so agents always see it (AXI principle: errors to stdout, not stderr)."""
    if ctx and _get_envelope(ctx):
        error = {
            "status": "error",
            "error_message": msg,
            "metadata": {
                "command": _get_command_path(ctx),
            },
        }
        if suggestions:
            error["suggestions"] = suggestions
        click.echo(json.dumps(error, indent=2))
    else:
        click.echo(f"Error: {msg}", err=True)


@click.group()
@click.option("--config", "-c", type=click.Path(path_type=Path), help="Config file path")
@click.option("--instance", "-i", help="Instance name from config")
@click.option("--envelope", is_flag=True, envvar="LGTM_ENVELOPE",
              help="Wrap output in agent-friendly envelope with metadata (or set LGTM_ENVELOPE=1)")
@click.pass_context
def main(ctx, config: Path | None, instance: str | None, envelope: bool):
    """LGTM CLI - Query Loki, Prometheus, and Tempo.

    Best practices are built-in:
    - Default time range: 15 minutes (use --start/--end to override)
    - Default limits: 50 for logs, 20 for traces
    - Always filter by labels when possible
    """
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config or DEFAULT_CONFIG_PATH
    ctx.obj["instance_name"] = instance
    try:
        ctx.obj["config"] = load_config(config)
    except FileNotFoundError:
        ctx.obj["config"] = None


def get_instance_or_exit(ctx) -> "InstanceConfig":
    """Get the requested instance from config, or exit with a helpful error."""
    config = ctx.obj["config"]
    instance_name = ctx.obj["instance_name"]
    try:
        return config.get_instance(instance_name)
    except ValueError as e:
        available = list(config.instances.keys())
        output_error(
            str(e),
            suggestions=[f"Available instances: {', '.join(available)}",
                         "Use --instance/-i to select one"] if available else None,
            ctx=ctx,
        )
        sys.exit(1)
    except StopIteration:
        output_error(
            "No instances configured",
            suggestions=["Run 'lgtm discover' to auto-discover Grafana Cloud stacks",
                         "Or manually add instances to ~/.config/lgtm/config.yaml"],
            ctx=ctx,
        )
        sys.exit(1)


# === LOKI COMMANDS ===

def _config_not_found_exit(ctx):
    """Exit with config-not-found error."""
    output_error(
        f"Config file not found: {ctx.obj['config_path']}",
        suggestions=["Run 'lgtm discover' to auto-discover Grafana Cloud stacks",
                      "Or create a config file at ~/.config/lgtm/config.yaml"],
        ctx=ctx,
    )
    sys.exit(1)


@main.group()
@click.pass_context
def loki(ctx):
    """Query Loki logs."""
    if not ctx.obj["config"]:
        _config_not_found_exit(ctx)
    instance = get_instance_or_exit(ctx)
    if not instance.loki:
        output_error(
            f"Loki not configured for instance '{instance.name}'",
            suggestions=["Add a 'loki' section to this instance in config",
                          "Or run 'lgtm discover' to auto-configure"],
            ctx=ctx,
        )
        sys.exit(1)
    ctx.obj["client"] = LokiClient(instance.loki)


@loki.command()
@click.argument("query")
@click.option("--start", "-s", help="Start time (RFC3339). Default: 15 minutes ago")
@click.option("--end", "-e", help="End time (RFC3339). Default: now")
@click.option("--limit", "-l", default=DEFAULT_LOKI_LIMIT, help=f"Max entries (default: {DEFAULT_LOKI_LIMIT})")
@click.option("--direction", "-d", type=click.Choice(["backward", "forward"]), default="backward")
@click.pass_context
def query(ctx, query: str, start: str | None, end: str | None, limit: int, direction: str):
    """Query logs with LogQL.

    Examples:

      lgtm loki query '{app="myapp"}'

      lgtm loki query '{app="myapp"} |= "error"' --limit 100

      lgtm loki query '{app="myapp"}' --start 2024-01-15T10:00:00Z --end 2024-01-15T11:00:00Z
    """
    default_start, default_end = get_default_times()
    try:
        result = ctx.obj["client"].query(
            query=query,
            start=start or default_start,
            end=end or default_end,
            limit=limit,
            direction=direction,
        )
        count = _count_results(result)
        hints = [
            "narrow results → add label filter or line filter e.g. '|= \"error\"'",
            "aggregate → lgtm loki instant 'count_over_time({...}[5m])'",
        ]
        if count is not None and count >= limit:
            hints.insert(0, f"limit of {limit} reached → use --limit to increase or narrow your query")
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Check your LogQL syntax", "Use 'lgtm loki labels' to discover available labels"], ctx=ctx)
        sys.exit(1)


@loki.command()
@click.argument("query")
@click.option("--time", "-t", help="Evaluation time (RFC3339). Default: now")
@click.pass_context
def instant(ctx, query: str, time: str | None):
    """Run instant query (for metric queries like count_over_time).

    Examples:

      lgtm loki instant 'count_over_time({app="myapp"}[5m])'

      lgtm loki instant 'sum by (level) (count_over_time({app="myapp"} | json [5m]))'
    """
    try:
        result = ctx.obj["client"].query_instant(query, time)
        hints = [
            "range query → lgtm loki query '{...}' to see raw logs",
            "break down → add 'by (label)' to your aggregation",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Check your LogQL syntax"], ctx=ctx)
        sys.exit(1)


@loki.command()
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def labels(ctx, start: str | None, end: str | None):
    """List available labels.

    Use this first to discover what labels are available before querying.
    """
    try:
        result = ctx.obj["client"].labels(start, end)
        hints = ["get values → lgtm loki label-values <label>"]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@loki.command("label-values")
@click.argument("label")
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def label_values(ctx, label: str, start: str | None, end: str | None):
    """List values for a label.

    Examples:

      lgtm loki label-values app

      lgtm loki label-values namespace
    """
    try:
        result = ctx.obj["client"].label_values(label, start, end)
        hints = [
            f"query with label → lgtm loki query '{{{label}=\"<value>\"}}'",
            "see all labels → lgtm loki labels",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Use 'lgtm loki labels' to see available labels"], ctx=ctx)
        sys.exit(1)


@loki.command()
@click.argument("match", nargs=-1, required=True)
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def series(ctx, match: tuple[str, ...], start: str | None, end: str | None):
    """List series matching selectors.

    Examples:

      lgtm loki series '{app="myapp"}'

      lgtm loki series '{namespace="prod"}' '{namespace="staging"}'
    """
    try:
        result = ctx.obj["client"].series(list(match), start, end)
        hints = ["query logs → lgtm loki query '<selector>'"]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


# === PROMETHEUS COMMANDS ===

@main.group()
@click.pass_context
def prom(ctx):
    """Query Prometheus/Mimir metrics."""
    if not ctx.obj["config"]:
        _config_not_found_exit(ctx)
    instance = get_instance_or_exit(ctx)
    if not instance.prometheus:
        output_error(
            f"Prometheus not configured for instance '{instance.name}'",
            suggestions=["Add a 'prometheus' section to this instance in config",
                          "Or run 'lgtm discover' to auto-configure"],
            ctx=ctx,
        )
        sys.exit(1)
    ctx.obj["client"] = PrometheusClient(instance.prometheus)


@prom.command()
@click.argument("query")
@click.option("--time", "-t", help="Evaluation time (RFC3339). Default: now")
@click.pass_context
def query(ctx, query: str, time: str | None):
    """Run instant query.

    Examples:

      lgtm prom query 'up{job="prometheus"}'

      lgtm prom query 'rate(http_requests_total[5m])'
    """
    try:
        result = ctx.obj["client"].query(query, time)
        hints = [
            "time series → lgtm prom range '<query>' to see values over time",
            "visualize → pipe range output to 'lgtm chart'",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Check your PromQL syntax", "Use 'lgtm prom labels' to discover available labels"], ctx=ctx)
        sys.exit(1)


@prom.command()
@click.argument("query")
@click.option("--start", "-s", help="Start time (RFC3339). Default: 15 minutes ago")
@click.option("--end", "-e", help="End time (RFC3339). Default: now")
@click.option("--step", default=DEFAULT_PROM_STEP, help=f"Resolution step (default: {DEFAULT_PROM_STEP})")
@click.pass_context
def range(ctx, query: str, start: str | None, end: str | None, step: str):
    """Run range query.

    Examples:

      lgtm prom range 'rate(http_requests_total[5m])'

      lgtm prom range 'up' --step 5m --start 2024-01-15T10:00:00Z
    """
    default_start, default_end = get_default_times()
    try:
        result = ctx.obj["client"].query_range(
            query=query,
            start=start or default_start,
            end=end or default_end,
            step=step,
        )
        hints = [
            "visualize → save output to file, then 'lgtm chart <file> -t \"Title\"'",
            "finer resolution → use --step 15s or --step 30s",
            "instant value → lgtm prom query '<query>' for current point-in-time",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Check your PromQL syntax"], ctx=ctx)
        sys.exit(1)


@prom.command()
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def labels(ctx, start: str | None, end: str | None):
    """List available labels.

    Use this first to discover what labels are available.
    """
    try:
        result = ctx.obj["client"].labels(start, end)
        hints = [
            "get values → lgtm prom label-values <label>",
            "list metric names → lgtm prom label-values __name__",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@prom.command("label-values")
@click.argument("label")
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def prom_label_values(ctx, label: str, start: str | None, end: str | None):
    """List values for a label.

    Examples:

      lgtm prom label-values job

      lgtm prom label-values __name__  # List all metric names
    """
    try:
        result = ctx.obj["client"].label_values(label, start, end)
        hints = [
            f"query with label → lgtm prom query '<metric>{{{label}=\"<value>\"}}'",
            "see all labels → lgtm prom labels",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Use 'lgtm prom labels' to see available labels"], ctx=ctx)
        sys.exit(1)


@prom.command()
@click.argument("match", nargs=-1, required=True)
@click.option("--start", "-s", help="Start time filter")
@click.option("--end", "-e", help="End time filter")
@click.pass_context
def series(ctx, match: tuple[str, ...], start: str | None, end: str | None):
    """List series matching selectors.

    Examples:

      lgtm prom series 'up'

      lgtm prom series 'http_requests_total{job="api"}'
    """
    try:
        result = ctx.obj["client"].series(list(match), start, end)
        hints = ["query metric → lgtm prom query '<metric>{<labels>}'"]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@prom.command()
@click.option("--metric", "-m", help="Filter by metric name")
@click.pass_context
def metadata(ctx, metric: str | None):
    """Get metric metadata.

    Examples:

      lgtm prom metadata

      lgtm prom metadata --metric http_requests_total
    """
    try:
        result = ctx.obj["client"].metadata(metric)
        hints = ["query metric → lgtm prom query '<metric_name>'"]
        if not metric:
            hints.insert(0, "filter by metric → lgtm prom metadata --metric <name>")
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


# === TEMPO COMMANDS ===

@main.group()
@click.pass_context
def tempo(ctx):
    """Query Tempo traces."""
    if not ctx.obj["config"]:
        _config_not_found_exit(ctx)
    instance = get_instance_or_exit(ctx)
    if not instance.tempo:
        output_error(
            f"Tempo not configured for instance '{instance.name}'",
            suggestions=["Add a 'tempo' section to this instance in config",
                          "Or run 'lgtm discover' to auto-configure"],
            ctx=ctx,
        )
        sys.exit(1)
    ctx.obj["client"] = TempoClient(instance.tempo)


@tempo.command()
@click.argument("trace_id")
@click.pass_context
def trace(ctx, trace_id: str):
    """Get trace by ID.

    Use this when you have a specific trace ID to investigate.

    Examples:

      lgtm tempo trace abc123def456
    """
    try:
        result = ctx.obj["client"].trace(trace_id)
        hints = [
            "search related → lgtm tempo search -q '{resource.service.name=\"<service>\"}'",
            "find logs → lgtm loki query '{traceID=\"" + trace_id + "\"}'",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@tempo.command()
@click.option("--query", "-q", help="TraceQL query")
@click.option("--start", "-s", help="Start time (Unix seconds). Default: 15 minutes ago")
@click.option("--end", "-e", help="End time (Unix seconds). Default: now")
@click.option("--min-duration", help="Minimum duration (e.g., 100ms, 1s)")
@click.option("--max-duration", help="Maximum duration")
@click.option("--limit", "-l", default=DEFAULT_TEMPO_LIMIT, help=f"Max traces (default: {DEFAULT_TEMPO_LIMIT})")
@click.pass_context
def search(ctx, query: str | None, start: str | None, end: str | None,
           min_duration: str | None, max_duration: str | None, limit: int):
    """Search traces with TraceQL.

    Examples:

      lgtm tempo search -q '{resource.service.name="api"}'

      lgtm tempo search -q '{status=error}' --min-duration 1s

      lgtm tempo search --min-duration 500ms --limit 50
    """
    default_start, default_end = get_default_times_unix()
    try:
        result = ctx.obj["client"].search(
            query=query,
            start=start or default_start,
            end=end or default_end,
            min_duration=min_duration,
            max_duration=max_duration,
            limit=limit,
        )
        count = _count_results(result)
        hints = [
            "view trace → lgtm tempo trace <traceID>",
            "filter slow → add --min-duration 1s",
        ]
        if count is not None and count >= limit:
            hints.insert(0, f"limit of {limit} reached → use --limit to increase or narrow your query")
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Check your TraceQL syntax", "Use 'lgtm tempo tags' to discover available tags"], ctx=ctx)
        sys.exit(1)


@tempo.command()
@click.pass_context
def tags(ctx):
    """List available tags.

    Use this first to discover what tags/attributes are available.
    """
    try:
        result = ctx.obj["client"].tags()
        hints = ["get values → lgtm tempo tag-values <tag>"]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@tempo.command("tag-values")
@click.argument("tag")
@click.pass_context
def tag_values(ctx, tag: str):
    """List values for a tag.

    Examples:

      lgtm tempo tag-values service.name

      lgtm tempo tag-values http.status_code
    """
    try:
        result = ctx.obj["client"].tag_values(tag)
        hints = [
            f"search with tag → lgtm tempo search -q '{{resource.{tag}=\"<value>\"}}'",
            "see all tags → lgtm tempo tags",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Use 'lgtm tempo tags' to see available tags"], ctx=ctx)
        sys.exit(1)


# === ALERTS COMMANDS ===

DEFAULT_SILENCE_DURATION_HOURS = 2


def parse_duration(duration: str) -> timedelta:
    """Parse duration string like '2h', '30m', '1d' to timedelta."""
    import re
    match = re.match(r'^(\d+)([smhd])$', duration.lower())
    if not match:
        raise click.BadParameter(f"Invalid duration format: {duration}. Use format like '2h', '30m', '1d'")
    value = int(match.group(1))
    unit = match.group(2)
    if unit == 's':
        return timedelta(seconds=value)
    elif unit == 'm':
        return timedelta(minutes=value)
    elif unit == 'h':
        return timedelta(hours=value)
    elif unit == 'd':
        return timedelta(days=value)
    raise click.BadParameter(f"Unknown time unit: {unit}")


def parse_matcher(matcher: str) -> dict:
    """Parse matcher string like 'alertname=HighCPU' or 'severity=~warning|critical'."""
    import re
    match = re.match(r'^([^=!~]+)(=~|!~|!=|=)(.*)$', matcher)
    if not match:
        raise click.BadParameter(f"Invalid matcher format: {matcher}. Use format like 'label=value' or 'label=~regex'")
    name = match.group(1)
    op = match.group(2)
    value = match.group(3)
    return {
        "name": name,
        "value": value,
        "isRegex": op in ("=~", "!~"),
        "isEqual": op in ("=", "=~"),
    }


@main.group()
@click.pass_context
def alerts(ctx):
    """Query Grafana Alerting/Alertmanager."""
    if not ctx.obj["config"]:
        _config_not_found_exit(ctx)
    instance = get_instance_or_exit(ctx)
    if not instance.alerting:
        output_error(
            f"Alerting not configured for instance '{instance.name}'",
            suggestions=["Add an 'alerting' section to this instance in config",
                          "Or run 'lgtm discover' to auto-configure"],
            ctx=ctx,
        )
        sys.exit(1)
    ctx.obj["client"] = AlertingClient(instance.alerting)


@alerts.command("list")
@click.option("--filter", "-f", "filters", multiple=True, help="Filter alerts by label (e.g., 'alertname=HighCPU')")
@click.option("--receiver", "-r", help="Filter by receiver")
@click.option("--silenced/--no-silenced", default=True, help="Include silenced alerts")
@click.option("--inhibited/--no-inhibited", default=True, help="Include inhibited alerts")
@click.option("--active/--no-active", default=True, help="Include active alerts")
@click.pass_context
def alerts_list(ctx, filters: tuple[str, ...], receiver: str | None, silenced: bool, inhibited: bool, active: bool):
    """List firing alerts.

    Examples:

      lgtm alerts list

      lgtm alerts list --filter 'alertname=HighCPU'

      lgtm alerts list --no-silenced --active
    """
    try:
        result = ctx.obj["client"].list_alerts(
            filter=list(filters) if filters else None,
            receiver=receiver,
            silenced=silenced,
            inhibited=inhibited,
            active=active,
        )
        hints = [
            "silence alert → lgtm alerts silence-create --matcher 'alertname=<name>' --duration 2h --comment '<reason>' --created-by '<you>'",
            "group view → lgtm alerts groups",
            "filter → lgtm alerts list --filter 'severity=critical'",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@alerts.command("groups")
@click.option("--filter", "-f", "filters", multiple=True, help="Filter alerts by label")
@click.option("--receiver", "-r", help="Filter by receiver")
@click.pass_context
def alerts_groups(ctx, filters: tuple[str, ...], receiver: str | None):
    """List alerts grouped by receiver/labels.

    Examples:

      lgtm alerts groups

      lgtm alerts groups --filter 'severity=critical'
    """
    try:
        result = ctx.obj["client"].list_alert_groups(
            filter=list(filters) if filters else None,
            receiver=receiver,
        )
        hints = [
            "flat list → lgtm alerts list",
            "filter → lgtm alerts groups --filter 'severity=critical'",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@alerts.command("silences")
@click.option("--filter", "-f", "filters", multiple=True, help="Filter silences by label")
@click.pass_context
def alerts_silences(ctx, filters: tuple[str, ...]):
    """List all silences.

    Examples:

      lgtm alerts silences

      lgtm alerts silences --filter 'alertname=HighCPU'
    """
    try:
        result = ctx.obj["client"].list_silences(
            filter=list(filters) if filters else None,
        )
        hints = [
            "view silence → lgtm alerts silence-get <id>",
            "delete silence → lgtm alerts silence-delete <id>",
            "create silence → lgtm alerts silence-create --matcher 'alertname=<name>' --duration 2h --comment '<reason>' --created-by '<you>'",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@alerts.command("silence-get")
@click.argument("silence_id")
@click.pass_context
def alerts_silence_get(ctx, silence_id: str):
    """Get a specific silence by ID.

    Examples:

      lgtm alerts silence-get abc123-def456
    """
    try:
        result = ctx.obj["client"].get_silence(silence_id)
        hints = [
            f"delete this silence → lgtm alerts silence-delete {silence_id}",
            "list all silences → lgtm alerts silences",
        ]
        output_json(result, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Use 'lgtm alerts silences' to list all silences"], ctx=ctx)
        sys.exit(1)


@alerts.command("silence-create")
@click.option("--matcher", "-m", "matchers", multiple=True, required=True,
              help="Matcher in format 'label=value' or 'label=~regex'. Can be specified multiple times.")
@click.option("--duration", "-d", default="2h", help="Silence duration (e.g., '2h', '30m', '1d'). Default: 2h")
@click.option("--comment", "-c", required=True, help="Comment explaining the silence")
@click.option("--created-by", required=True, help="Creator identifier (e.g., email)")
@click.pass_context
def alerts_silence_create(ctx, matchers: tuple[str, ...], duration: str, comment: str, created_by: str):
    """Create a new silence.

    Examples:

      lgtm alerts silence-create --matcher 'alertname=HighCPU' --duration 2h --comment "Maintenance" --created-by "user@example.com"

      lgtm alerts silence-create -m 'alertname=HighCPU' -m 'severity=warning' -d 1h -c "Investigating" --created-by "ops"
    """
    try:
        parsed_matchers = [parse_matcher(m) for m in matchers]
        delta = parse_duration(duration)
        now = datetime.now(timezone.utc)
        starts_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")
        ends_at = (now + delta).strftime("%Y-%m-%dT%H:%M:%SZ")

        result = ctx.obj["client"].create_silence(
            matchers=parsed_matchers,
            starts_at=starts_at,
            ends_at=ends_at,
            created_by=created_by,
            comment=comment,
        )
        hints = [
            "list silences → lgtm alerts silences",
            "delete this silence → lgtm alerts silence-delete <silenceID from response>",
        ]
        output_json(result, ctx, hints=hints)
    except click.BadParameter as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)
    except Exception as e:
        output_error(str(e), ctx=ctx)
        sys.exit(1)


@alerts.command("silence-delete")
@click.argument("silence_id")
@click.pass_context
def alerts_silence_delete(ctx, silence_id: str):
    """Delete/expire a silence by ID.

    Examples:

      lgtm alerts silence-delete abc123-def456
    """
    try:
        ctx.obj["client"].delete_silence(silence_id)
        hints = ["list silences → lgtm alerts silences"]
        output_json({"message": f"Silence {silence_id} deleted successfully"}, ctx, hints=hints)
    except Exception as e:
        output_error(str(e), suggestions=["Use 'lgtm alerts silences' to list all silences"], ctx=ctx)
        sys.exit(1)


# === CONFIG COMMANDS ===

@main.command()
@click.pass_context
def instances(ctx):
    """List configured instances."""
    if not ctx.obj["config"]:
        _config_not_found_exit(ctx)
    config = ctx.obj["config"]
    result = {
        "default": config.default_instance,
        "instances": {}
    }
    for name, instance in config.instances.items():
        result["instances"][name] = {
            "loki": instance.loki.url if instance.loki else None,
            "prometheus": instance.prometheus.url if instance.prometheus else None,
            "tempo": instance.tempo.url if instance.tempo else None,
            "alerting": instance.alerting.url if instance.alerting else None,
        }
    hints = [
        "query logs → lgtm -i <instance> loki query '{app=\"<app>\"}'",
        "query metrics → lgtm -i <instance> prom query 'up'",
        "search traces → lgtm -i <instance> tempo search",
        "check alerts → lgtm -i <instance> alerts list",
    ]
    output_json(result, ctx, hints=hints)


def _build_command_schema(cmd: click.BaseCommand, name: str | None = None) -> dict:
    """Recursively build a JSON schema from a Click command tree."""
    schema = {
        "name": name or cmd.name,
        "description": (cmd.help or "").split("\n\n")[0].strip(),
    }

    if isinstance(cmd, click.MultiCommand):
        children = []
        for sub_name in cmd.list_commands(None):
            sub_cmd = cmd.get_command(None, sub_name)
            if sub_cmd:
                children.append(_build_command_schema(sub_cmd, sub_name))
        schema["subcommands"] = children
    else:
        args = []
        opts = []
        for param in cmd.params:
            if isinstance(param, click.Argument):
                args.append({
                    "name": param.name,
                    "required": param.required,
                    "nargs": param.nargs,
                })
            elif isinstance(param, click.Option):
                if param.name == "help":
                    continue
                opt = {
                    "flags": list(param.opts + param.secondary_opts),
                    "name": param.name,
                    "type": param.type.name,
                    "required": param.required,
                }
                if param.default is not None and param.default != () and isinstance(param.default, (str, int, float, bool)):
                    opt["default"] = param.default
                if param.help:
                    opt["description"] = param.help
                if isinstance(param.type, click.Choice):
                    opt["choices"] = list(param.type.choices)
                if param.is_flag:
                    opt["type"] = "flag"
                opts.append(opt)
        if args:
            schema["arguments"] = args
        if opts:
            schema["options"] = opts

    return schema


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("lgtm-cli")
    except Exception:
        return "unknown"


@main.command()
@click.option("--compact", is_flag=True, help="Minimal schema (names and flags only)")
@click.pass_context
def schema(ctx, compact: bool):
    """Output the full command tree as JSON for agent discovery.

    Agents can use this to understand available commands, arguments,
    and options without parsing help text.

    Examples:

      lgtm schema

      lgtm schema --compact
    """
    result = {
        "version": _get_version(),
        "description": "CLI for querying Loki, Prometheus/Mimir, Tempo, and Grafana Alerting",
        "global_flags": [
            {"flags": ["--config", "-c"], "description": "Config file path"},
            {"flags": ["--instance", "-i"], "description": "Instance name from config"},
            {"flags": ["--envelope"], "description": "Wrap output in agent-friendly envelope with metadata"},
        ],
        "commands": [],
        "query_syntax": {
            "loki": "LogQL - e.g., '{app=\"myapp\"} |= \"error\"', 'count_over_time({app=\"myapp\"}[5m])'",
            "prometheus": "PromQL - e.g., 'up{job=\"api\"}', 'rate(http_requests_total[5m])'",
            "tempo": "TraceQL - e.g., '{resource.service.name=\"api\"}', '{status=error}'",
        },
        "time_formats": {
            "loki": "RFC3339 (e.g., 2024-01-15T10:00:00Z)",
            "prometheus": "RFC3339 (e.g., 2024-01-15T10:00:00Z)",
            "tempo": "Unix seconds (e.g., 1705312800)",
        },
        "defaults": {
            "time_range": "15 minutes",
            "loki_limit": DEFAULT_LOKI_LIMIT,
            "tempo_limit": DEFAULT_TEMPO_LIMIT,
            "prom_step": DEFAULT_PROM_STEP,
        },
    }

    for sub_name in main.list_commands(ctx):
        sub_cmd = main.get_command(ctx, sub_name)
        if sub_cmd:
            cmd_schema = _build_command_schema(sub_cmd, sub_name)
            if compact:
                cmd_schema = _compact_schema(cmd_schema)
            result["commands"].append(cmd_schema)

    if compact:
        del result["query_syntax"]
        del result["time_formats"]
        del result["defaults"]

    click.echo(json.dumps(result, indent=2))


def _compact_schema(schema: dict) -> dict:
    """Strip descriptions and non-essential fields for a compact schema."""
    compact = {"name": schema["name"]}
    if "subcommands" in schema:
        compact["subcommands"] = [_compact_schema(s) for s in schema["subcommands"]]
    if "arguments" in schema:
        compact["arguments"] = [{"name": a["name"]} for a in schema["arguments"]]
    if "options" in schema:
        compact["options"] = [{"flags": o["flags"]} for o in schema["options"]]
    return compact


@main.command()
@click.option("--token", envvar="GRAFANA_CLOUD_API_TOKEN", required=True,
              help="Grafana Cloud API token (or set GRAFANA_CLOUD_API_TOKEN env var)")
@click.option("--org", default=None, help="Grafana Cloud org slug (optional, lists all accessible stacks if omitted)")
@click.option("--token-env-var", default="GRAFANA_CLOUD_API_TOKEN",
              help="Env var name to use in generated config for the token reference")
@click.option("--overwrite", is_flag=True, help="Overwrite existing instances with same name")
@click.option("--dry-run", is_flag=True, help="Print generated config without writing to file")
@click.pass_context
def discover(ctx, token: str, org: str | None, token_env_var: str, overwrite: bool, dry_run: bool):
    """Discover Grafana Cloud stacks and add them to config.

    Queries the Grafana Cloud API to find all active stacks and generates
    instance configs with the correct endpoints and auth.

    Requires a Grafana Cloud Access Policy token with the 'stacks:read' scope.
    Create one at: Grafana Cloud > Administration > Cloud Access Policies.

    Examples:

      lgtm discover --token glc_xxx

      lgtm discover --org myorg --token glc_xxx

      GRAFANA_CLOUD_API_TOKEN=glc_xxx lgtm discover --dry-run
    """
    cloud_client = GrafanaCloudClient(token)

    try:
        if org:
            click.echo(f"Fetching stacks for org '{org}'...")
        else:
            click.echo("Fetching accessible stacks...")
        stacks = cloud_client.list_stacks(org)
    except Exception as e:
        output_error(f"Failed to fetch stacks: {e}")
        sys.exit(1)

    if not stacks:
        click.echo("No stacks found.")
        return

    click.echo(f"Found {len(stacks)} stack(s)")

    token_ref = f"${{{token_env_var}}}"
    new_instances = generate_stack_instances(stacks, token_ref)

    if not new_instances:
        click.echo("No active stacks with configured services found.")
        return

    config_path = ctx.obj["config_path"]
    if config_path.exists():
        with open(config_path) as f:
            existing = yaml.safe_load(f) or {}
    else:
        existing = {"version": "1", "instances": {}}

    existing.setdefault("version", "1")
    existing.setdefault("instances", {})

    added = []
    skipped = []
    overwritten = []

    for name, instance_config in new_instances.items():
        if name in existing["instances"]:
            if overwrite:
                existing["instances"][name] = instance_config
                overwritten.append(name)
            else:
                skipped.append(name)
        else:
            existing["instances"][name] = instance_config
            added.append(name)

    if dry_run:
        click.echo("\n--- Generated config (dry run) ---")
        click.echo(yaml.dump(existing, default_flow_style=False, sort_keys=False))
        click.echo("---")
    else:
        write_config(config_path, existing)
        click.echo(f"Config written to {config_path}")

    prefix = "Would add" if dry_run else "Added"
    if added:
        click.echo(f"{prefix}: {', '.join(added)}")
    if skipped:
        click.echo(f"Skipped (already exist, use --overwrite): {', '.join(skipped)}")
    if overwritten:
        prefix = "Would overwrite" if dry_run else "Overwritten"
        click.echo(f"{prefix}: {', '.join(overwritten)}")


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--type", "chart_type", type=click.Choice(["timeseries", "bar", "heatmap"]),
              default="timeseries", help="Chart type")
@click.option("--title", "-t", default=None, help="Chart title")
@click.option("--width", "-w", type=int, default=None, help="Chart width in columns")
@click.option("--height", type=int, default=20, help="Chart height in rows")
@click.option("--output", "-o", type=click.Path(), default=None, help="Save output to file (captures terminal output including ANSI codes)")
def chart(file: str, chart_type: str, title: str | None, width: int | None, height: int, output: str | None):
    """Render a Prometheus range query result as a terminal chart.

    Reads a JSON file containing the output of `lgtm prom range`.

    Examples:

      lgtm prom range 'rate(http_requests_total[5m])' > data.json

      lgtm chart data.json -t "Request Rate"

      lgtm chart data.json --type bar -t "Top Services"

      lgtm chart data.json --type heatmap -t "Latency Distribution"

      lgtm chart data.json -t "Rate" -o chart.png
    """
    from .chart import render_chart

    with open(file) as f:
        data = json.load(f)

    # Handle both raw Prometheus response and envelope format
    if "data" in data and "result" not in data.get("data", {}):
        inner = data["data"]
        if isinstance(inner, dict) and "data" in inner:
            data = inner

    if output:
        from .chart import render_chart_to_file
        render_chart_to_file(data, output, chart_type=chart_type, title=title, width=width, height=height)
        click.echo(f"Chart saved to {output}")
    else:
        render_chart(data, chart_type=chart_type, title=title, width=width, height=height)


if __name__ == "__main__":
    main()
