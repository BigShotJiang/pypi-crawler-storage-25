"""Tests for fluq.watch() auto-instrumentation."""

from __future__ import annotations

import json
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
import respx

import fluq
from fluq.pricing import estimate_cost, MODEL_COSTS


# ------------------------------------------------------------------
# Fixtures & helpers
# ------------------------------------------------------------------

BASE = "https://api.fluq.dev"


def _init(**overrides: Any) -> None:
    defaults: dict[str, Any] = dict(api_key="sk-test", agent_id="agent-1")
    defaults.update(overrides)
    fluq.init(**defaults)


def _make_openai_response(
    *,
    model: str = "gpt-4o",
    prompt_tokens: int = 10,
    completion_tokens: int = 20,
    content: str = "Hello!",
) -> SimpleNamespace:
    """Fake OpenAI ChatCompletion response."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(prompt_tokens=prompt_tokens, completion_tokens=completion_tokens),
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, role="assistant"),
                finish_reason="stop",
            )
        ],
    )


def _make_anthropic_response(
    *,
    model: str = "claude-sonnet-4-20250514",
    input_tokens: int = 15,
    output_tokens: int = 25,
    text: str = "Hi there!",
) -> SimpleNamespace:
    """Fake Anthropic Message response."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(input_tokens=input_tokens, output_tokens=output_tokens),
        content=[SimpleNamespace(type="text", text=text)],
        stop_reason="end_turn",
    )


class _FakeOpenAIClient:
    """Mimics openai.OpenAI structure for testing."""

    __module__ = "openai"
    __name__ = "OpenAI"

    def __init__(self, response: Any) -> None:
        self.chat = SimpleNamespace(
            completions=SimpleNamespace(create=MagicMock(return_value=response))
        )


class _FakeAsyncOpenAIClient:
    """Mimics openai.AsyncOpenAI structure for testing."""

    __module__ = "openai"
    __name__ = "AsyncOpenAI"

    def __init__(self, response: Any) -> None:
        self.chat = SimpleNamespace(
            completions=SimpleNamespace(create=AsyncMock(return_value=response))
        )


class _FakeAnthropicClient:
    """Mimics anthropic.Anthropic structure for testing."""

    __module__ = "anthropic"
    __name__ = "Anthropic"

    def __init__(self, response: Any) -> None:
        self.messages = SimpleNamespace(create=MagicMock(return_value=response))


class _FakeAsyncAnthropicClient:
    """Mimics anthropic.AsyncAnthropic structure for testing."""

    __module__ = "anthropic"
    __name__ = "AsyncAnthropic"

    def __init__(self, response: Any) -> None:
        self.messages = SimpleNamespace(create=AsyncMock(return_value=response))


@pytest.fixture(autouse=True)
def _reset_module_state() -> Any:
    """Reset fluq module state between tests."""
    yield
    if fluq._state is not None:
        fluq._state.http.close()
        fluq._state = None


# ------------------------------------------------------------------
# Pricing
# ------------------------------------------------------------------

class TestPricing:
    def test_known_model(self) -> None:
        cost = estimate_cost("gpt-4o", tokens_in=1_000_000, tokens_out=1_000_000)
        assert cost == 2.50 + 10.00

    def test_known_model_small(self) -> None:
        cost = estimate_cost("gpt-4o", tokens_in=100, tokens_out=50)
        assert cost is not None
        assert cost == pytest.approx(100 * 2.50 / 1e6 + 50 * 10.00 / 1e6)

    def test_unknown_model(self) -> None:
        assert estimate_cost("some-unknown-model", 100, 100) is None

    def test_alias_resolution(self) -> None:
        cost = estimate_cost("claude-sonnet-4", tokens_in=1000, tokens_out=1000)
        assert cost is not None
        assert cost == pytest.approx((1000 * 3.0 + 1000 * 15.0) / 1e6)

    def test_prefix_match(self) -> None:
        # A versioned model string should match via prefix
        cost = estimate_cost("gpt-4o-2024-08-06", tokens_in=1000, tokens_out=1000)
        assert cost is not None


# ------------------------------------------------------------------
# Module-level init / watch
# ------------------------------------------------------------------

class TestInit:
    def test_init_sets_state(self) -> None:
        _init()
        assert fluq._state is not None
        assert fluq._state.api_key == "sk-test"
        assert fluq._state.agent_id == "agent-1"

    def test_watch_before_init_raises(self) -> None:
        with pytest.raises(RuntimeError, match="fluq.init"):
            fluq.watch(object())

    def test_watch_unsupported_type_raises(self) -> None:
        _init()
        with pytest.raises(TypeError, match="Unsupported"):
            fluq.watch("not a client")

    def test_reinit_closes_old_http(self) -> None:
        _init()
        old_http = fluq._state.http
        _init()
        assert old_http.is_closed


# ------------------------------------------------------------------
# OpenAI sync
# ------------------------------------------------------------------

class TestOpenAISync:
    @respx.mock
    def test_captures_completion(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_openai_response()
        client = _FakeOpenAIClient(response)
        proxy = fluq.watch(client)

        result = proxy.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hi"}])
        assert result is response

        # Flush to send buffered events
        fluq.flush()
        assert route.called
        body = json.loads(route.calls.last.request.content)
        ev = body["events"][0]
        assert ev["eventType"] == "llm_call"
        assert ev["tokensIn"] == 10
        assert ev["tokensOut"] == 20
        assert ev["resource"] == "openai.gpt-4o"
        assert ev["agentId"] == "agent-1"
        assert "estimatedCostUsd" in ev
        assert ev["durationMs"] >= 0

    @respx.mock
    def test_captures_error(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        client = _FakeOpenAIClient(None)
        client.chat.completions.create.side_effect = ConnectionError("timeout")
        proxy = fluq.watch(client)

        with pytest.raises(ConnectionError):
            proxy.chat.completions.create(model="gpt-4o", messages=[])

        fluq.flush()
        body = json.loads(route.calls.last.request.content)
        ev = body["events"][0]
        assert ev["errorMessage"] == "ConnectionError: timeout"
        assert ev["tokensIn"] == 0
        assert ev["tokensOut"] == 0

    def test_passthrough_attributes(self) -> None:
        _init()
        response = _make_openai_response()
        client = _FakeOpenAIClient(response)
        client.models = "models_endpoint"
        proxy = fluq.watch(client)
        assert proxy.models == "models_endpoint"

    @respx.mock
    def test_input_output_captured(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_openai_response(content="World")
        client = _FakeOpenAIClient(response)
        proxy = fluq.watch(client)
        proxy.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "Hello"}])
        fluq.flush()

        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert ev["input"]["messages"] == [{"role": "user", "content": "Hello"}]
        assert ev["output"]["content"] == "World"


# ------------------------------------------------------------------
# OpenAI async
# ------------------------------------------------------------------

class TestOpenAIAsync:
    @respx.mock
    async def test_captures_async_completion(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_openai_response()
        client = _FakeAsyncOpenAIClient(response)
        proxy = fluq.watch(client)

        result = await proxy.chat.completions.create(model="gpt-4o", messages=[])
        assert result is response

        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert ev["eventType"] == "llm_call"
        assert ev["tokensIn"] == 10

    @respx.mock
    async def test_captures_async_error(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        client = _FakeAsyncOpenAIClient(None)
        client.chat.completions.create.side_effect = ConnectionError("timeout")
        proxy = fluq.watch(client)

        with pytest.raises(ConnectionError):
            await proxy.chat.completions.create(model="gpt-4o", messages=[])

        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert "ConnectionError" in ev["errorMessage"]


# ------------------------------------------------------------------
# Anthropic sync
# ------------------------------------------------------------------

class TestAnthropicSync:
    @respx.mock
    def test_captures_completion(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_anthropic_response()
        client = _FakeAnthropicClient(response)
        proxy = fluq.watch(client)

        result = proxy.messages.create(
            model="claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )
        assert result is response

        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert ev["eventType"] == "llm_call"
        assert ev["tokensIn"] == 15
        assert ev["tokensOut"] == 25
        assert ev["resource"] == "anthropic.claude-sonnet-4-20250514"
        assert ev["metadata"]["provider"] == "anthropic"
        assert "estimatedCostUsd" in ev

    @respx.mock
    def test_captures_error(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        client = _FakeAnthropicClient(None)
        client.messages.create.side_effect = RuntimeError("rate limit")
        proxy = fluq.watch(client)

        with pytest.raises(RuntimeError):
            proxy.messages.create(model="claude-sonnet-4-20250514", messages=[])

        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert "RuntimeError: rate limit" in ev["errorMessage"]

    @respx.mock
    def test_system_prompt_captured(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_anthropic_response()
        client = _FakeAnthropicClient(response)
        proxy = fluq.watch(client)
        proxy.messages.create(
            model="claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": "Hi"}],
            system="You are helpful.",
        )
        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert ev["input"]["system"] == "You are helpful."


# ------------------------------------------------------------------
# Anthropic async
# ------------------------------------------------------------------

class TestAnthropicAsync:
    @respx.mock
    async def test_captures_async_completion(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_anthropic_response()
        client = _FakeAsyncAnthropicClient(response)
        proxy = fluq.watch(client)

        result = await proxy.messages.create(
            model="claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )
        assert result is response

        fluq.flush()
        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert ev["eventType"] == "llm_call"
        assert ev["tokensIn"] == 15
        assert ev["tokensOut"] == 25


# ------------------------------------------------------------------
# Batching
# ------------------------------------------------------------------

class TestBatching:
    @respx.mock
    def test_auto_flush_on_threshold(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init(flush_batch_size=2)
        response = _make_openai_response()
        client = _FakeOpenAIClient(response)
        proxy = fluq.watch(client)

        # First call — buffered, not flushed
        proxy.chat.completions.create(model="gpt-4o", messages=[])
        assert route.call_count == 0

        # Second call — hits batch threshold, triggers flush
        proxy.chat.completions.create(model="gpt-4o", messages=[])
        assert route.call_count == 1
        body = json.loads(route.calls.last.request.content)
        assert len(body["events"]) == 2

    @respx.mock
    def test_flush_noop_when_empty(self) -> None:
        _init()
        fluq.flush()
        # No requests made
        assert respx.calls.call_count == 0

    def test_flush_before_init_noop(self) -> None:
        # Should not raise
        fluq.flush()


# ------------------------------------------------------------------
# Cost accuracy
# ------------------------------------------------------------------

class TestCostAccuracy:
    @respx.mock
    def test_gpt4o_cost_estimate(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_openai_response(prompt_tokens=1000, completion_tokens=500)
        client = _FakeOpenAIClient(response)
        proxy = fluq.watch(client)
        proxy.chat.completions.create(model="gpt-4o", messages=[])
        fluq.flush()

        ev = json.loads(route.calls.last.request.content)["events"][0]
        expected = (1000 * 2.50 + 500 * 10.00) / 1e6
        assert ev["estimatedCostUsd"] == pytest.approx(expected)

    @respx.mock
    def test_unknown_model_no_cost(self) -> None:
        route = respx.post(f"{BASE}/api/v1/events").mock(
            return_value=httpx.Response(200, json={"success": True})
        )
        _init()
        response = _make_openai_response(model="ft:custom-model")
        client = _FakeOpenAIClient(response)
        proxy = fluq.watch(client)
        proxy.chat.completions.create(model="ft:custom-model", messages=[])
        fluq.flush()

        ev = json.loads(route.calls.last.request.content)["events"][0]
        assert "estimatedCostUsd" not in ev
