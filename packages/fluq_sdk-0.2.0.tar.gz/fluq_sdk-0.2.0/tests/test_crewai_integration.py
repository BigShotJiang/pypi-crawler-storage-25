"""Tests for the CrewAI integration."""

from __future__ import annotations

import threading
import uuid
from types import SimpleNamespace
from unittest.mock import patch

import pytest

import fluq
from fluq.integrations.crewai import FluqCrewHandler


TRACE_ID = str(uuid.uuid4())
AGENT_ID = "agent-crew-test"
PARENT_RUN_ID = uuid.UUID("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")
CHILD_RUN_ID = uuid.UUID("bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb")


def _make_state() -> fluq._ModuleState:
    import httpx
    return fluq._ModuleState(
        api_key="sk-test",
        agent_id=AGENT_ID,
        base_url="https://fluq.ai",
        http=httpx.Client(),
        buffer=[],
        lock=threading.Lock(),
        flush_batch_size=50,
    )


class LLMResult:
    """Minimal fake LangChain LLMResult."""

    def __init__(
        self,
        model: str = "gpt-4o",
        tokens_in: int = 100,
        tokens_out: int = 50,
        text: str = "Hello!",
    ) -> None:
        self.llm_output = {
            "model_name": model,
            "token_usage": {"prompt_tokens": tokens_in, "completion_tokens": tokens_out},
        }
        gen = SimpleNamespace(text=text)
        self.generations = [[gen]]


class AgentAction:
    def __init__(self, tool: str, tool_input: str) -> None:
        self.tool = tool
        self.tool_input = tool_input


class AgentFinish:
    def __init__(self, output: str, log: str = "") -> None:
        self.return_values = {"output": output}
        self.log = log


# ---------------------------------------------------------------------------
# Not initialized guard
# ---------------------------------------------------------------------------

class TestNotInitialized:
    def test_on_chain_start_noop(self) -> None:
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", None):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)

    def test_on_llm_end_noop(self) -> None:
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", None):
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

    def test_on_tool_end_noop(self) -> None:
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", None):
            handler.on_tool_end("result", run_id=CHILD_RUN_ID)


# ---------------------------------------------------------------------------
# Chain callbacks
# ---------------------------------------------------------------------------

class TestChainCallbacks:
    def test_on_chain_start_emits_action_event(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start(
                {"name": "CrewChain"},
                {"input": "research AI"},
                run_id=PARENT_RUN_ID,
            )

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["event"] == "chain_start"
        assert ev["payload"]["name"] == "CrewChain"
        assert ev["traceId"] == str(PARENT_RUN_ID)
        assert ev["agentId"] == AGENT_ID
        assert ev["metadata"]["framework"] == "crewai"

    def test_root_chain_becomes_trace_id(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID, parent_run_id=None)
        ev = state.buffer[0]
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_child_chain_inherits_parent_trace_id(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            # root chain
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID, parent_run_id=None)
            state.buffer.clear()
            # child chain
            handler.on_chain_start({}, {}, run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)

        ev = state.buffer[0]
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_chain_end_emits_action_event(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_chain_end({"output": "done"}, run_id=PARENT_RUN_ID)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["event"] == "chain_end"

    def test_on_chain_end_includes_duration(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_chain_end({}, run_id=PARENT_RUN_ID)

        end_ev = state.buffer[1]
        assert end_ev.get("durationMs") is not None
        assert end_ev["durationMs"] >= 0

    def test_on_chain_error_emits_error_event(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_chain_error(RuntimeError("fail"), run_id=PARENT_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert "fail" in ev["errorMessage"]

    def test_chain_name_fallback(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start(None, {}, run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["payload"]["name"] == "chain"


# ---------------------------------------------------------------------------
# LLM callbacks
# ---------------------------------------------------------------------------

class TestLLMCallbacks:
    def test_on_llm_end_emits_llm_call(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_llm_start({}, ["Hello"], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(model="gpt-4o", tokens_in=100, tokens_out=50),
                               run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "llm_call"
        assert ev["resource"] == "crewai.gpt-4o"
        assert ev["tokensIn"] == 100
        assert ev["tokensOut"] == 50
        assert ev["traceId"] == str(PARENT_RUN_ID)
        assert ev["metadata"]["model"] == "gpt-4o"
        assert ev["metadata"]["framework"] == "crewai"

    def test_llm_inherits_parent_trace(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

        llm_ev = state.buffer[-1]
        assert llm_ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_llm_error_emits_error(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_llm_error(ValueError("rate limit"), run_id=CHILD_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert "rate limit" in ev["errorMessage"]

    def test_llm_end_includes_duration(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

        ev = state.buffer[0]
        assert ev.get("durationMs") is not None
        assert ev["durationMs"] >= 0

    def test_llm_end_no_response_model(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        result = SimpleNamespace(llm_output=None, generations=[])
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(result, run_id=CHILD_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "llm_call"
        assert ev["resource"] == "crewai.llm"


# ---------------------------------------------------------------------------
# Tool callbacks
# ---------------------------------------------------------------------------

class TestToolCallbacks:
    def test_on_tool_end_emits_tool_use(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_tool_start({}, "search query", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_tool_end("search results", run_id=CHILD_RUN_ID, name="search_web")

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "tool_use"
        assert ev["resource"] == "search_web"
        assert ev["output"]["output"] == "search results"
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_tool_error_emits_error(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_tool_start({}, "bad input", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_tool_error(TimeoutError("timeout"), run_id=CHILD_RUN_ID, name="slow_tool")

        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert ev["resource"] == "slow_tool"
        assert "timeout" in ev["errorMessage"]

    def test_tool_end_includes_duration(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_tool_start({}, "", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_tool_end("ok", run_id=CHILD_RUN_ID)

        ev = state.buffer[0]
        assert ev.get("durationMs") is not None


# ---------------------------------------------------------------------------
# Agent callbacks
# ---------------------------------------------------------------------------

class TestAgentCallbacks:
    def test_on_agent_action_emits_action(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        action = AgentAction(tool="search_web", tool_input="latest AI news")
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_action(action, run_id=PARENT_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["tool"] == "search_web"
        assert ev["payload"]["tool_input"] == "latest AI news"

    def test_on_agent_action_dict(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_action(
                {"tool": "calculator", "tool_input": "2+2"},
                run_id=PARENT_RUN_ID,
            )

        ev = state.buffer[0]
        assert ev["payload"]["tool"] == "calculator"

    def test_on_agent_finish_emits_decision(self) -> None:
        state = _make_state()
        handler = FluqCrewHandler()
        finish = AgentFinish(output="The answer is 42", log="Final answer: 42")
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_finish(finish, run_id=PARENT_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "decision"
        assert ev["payload"]["event"] == "agent_finish"
        assert ev["output"]["output"] == {"output": "The answer is 42"}
