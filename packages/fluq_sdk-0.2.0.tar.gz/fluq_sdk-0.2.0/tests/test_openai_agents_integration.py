"""Tests for the OpenAI Agents SDK integration."""

from __future__ import annotations

import threading
from types import SimpleNamespace
from unittest.mock import patch

import pytest

import fluq
from fluq.integrations.openai_agents import FluqTracingProcessor


TRACE_ID = "trace-abc-123"
AGENT_ID = "agent-test-001"


def _make_state() -> fluq._ModuleState:
    import httpx
    return fluq._ModuleState(
        api_key="sk-test",
        agent_id=AGENT_ID,
        base_url="https://fluq.ai",
        http=httpx.Client(),
        buffer=[],
        lock=threading.Lock(),
        flush_batch_size=50,
    )


def _make_trace(trace_id: str = TRACE_ID, name: str = "test_run") -> SimpleNamespace:
    return SimpleNamespace(trace_id=trace_id, name=name)


def _make_span(trace_id: str, span_data: object, started_at: float = 0.0, ended_at: float = 1.5) -> SimpleNamespace:
    return SimpleNamespace(
        trace_id=trace_id,
        span_data=span_data,
        started_at=started_at,
        ended_at=ended_at,
    )


# Named fake span-data classes so type().__name__ matches what the integration checks
class GenerationSpanData:
    def __init__(self, model: str, input: object, output: object, usage: object) -> None:
        self.model = model
        self.input = input
        self.output = output
        self.usage = usage


class FunctionSpanData:
    def __init__(self, name: str, input: object, output: object) -> None:
        self.name = name
        self.input = input
        self.output = output


class HandoffSpanData:
    def __init__(self, from_agent: str, to_agent: str) -> None:
        self.from_agent = from_agent
        self.to_agent = to_agent


class GuardrailSpanData:
    def __init__(self, name: str, triggered: bool, output: object) -> None:
        self.name = name
        self.triggered = triggered
        self.output = output


class AgentSpanData:
    def __init__(self, name: str, handoffs: list, tools: list, output: object) -> None:
        self.name = name
        self.handoffs = handoffs
        self.tools = tools
        self.output = output


class CustomSpanData:
    pass


class TestFluqTracingProcessorNotInitialized:
    def test_on_trace_start_noop_when_not_initialized(self) -> None:
        processor = FluqTracingProcessor()
        with patch.object(fluq, "_state", None):
            processor.on_trace_start(_make_trace())  # should not raise

    def test_on_span_end_noop_when_not_initialized(self) -> None:
        processor = FluqTracingProcessor()
        span_data = GenerationSpanData("gpt-4o", None, None, None)
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", None):
            processor.on_span_end(span)  # should not raise


class TestOnTraceStart:
    def test_emits_action_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        with patch.object(fluq, "_state", state):
            processor.on_trace_start(_make_trace(name="my_run"))

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["traceId"] == TRACE_ID
        assert ev["payload"]["event"] == "trace_start"
        assert ev["payload"]["name"] == "my_run"
        assert ev["agentId"] == AGENT_ID

    def test_emits_trace_end_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        with patch.object(fluq, "_state", state):
            processor.on_trace_end(_make_trace(name="my_run"))

        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["event"] == "trace_end"


class TestGenerationSpan:
    def test_emits_llm_call_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = GenerationSpanData(
            model="gpt-4o",
            input=[{"role": "user", "content": "hello"}],
            output="Hi there!",
            usage={"input_tokens": 100, "output_tokens": 50},
        )
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "llm_call"
        assert ev["resource"] == "openai.gpt-4o"
        assert ev["tokensIn"] == 100
        assert ev["tokensOut"] == 50
        assert ev["durationMs"] == pytest.approx(1500.0)
        assert ev["metadata"]["model"] == "gpt-4o"
        assert ev["metadata"]["provider"] == "openai"

    def test_usage_as_object(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        usage_obj = SimpleNamespace(input_tokens=200, output_tokens=80)
        span_data = GenerationSpanData(model="gpt-4o-mini", input=None, output=None, usage=usage_obj)
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        ev = state.buffer[0]
        assert ev["tokensIn"] == 200
        assert ev["tokensOut"] == 80

    def test_no_usage(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = GenerationSpanData(model="gpt-4o", input=None, output=None, usage=None)
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        ev = state.buffer[0]
        assert ev["tokensIn"] == 0
        assert ev["tokensOut"] == 0
        assert "input" not in ev
        assert "output" not in ev

    def test_no_duration_when_timestamps_missing(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = GenerationSpanData("gpt-4o", None, None, None)
        span = SimpleNamespace(trace_id=TRACE_ID, span_data=span_data, started_at=None, ended_at=None)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        ev = state.buffer[0]
        assert "durationMs" not in ev


class TestFunctionSpan:
    def test_emits_tool_use_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = FunctionSpanData(name="search_web", input={"query": "python"}, output="results...")
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "tool_use"
        assert ev["resource"] == "search_web"
        assert ev["input"]["input"] == {"query": "python"}
        assert ev["output"]["output"] == "results..."
        assert ev["durationMs"] == pytest.approx(1500.0)


class TestHandoffSpan:
    def test_emits_spawn_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = HandoffSpanData(from_agent="triage", to_agent="billing")
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "spawn"
        assert ev["payload"]["from_agent"] == "triage"
        assert ev["payload"]["to_agent"] == "billing"


class TestGuardrailSpan:
    def test_emits_decision_event_triggered(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = GuardrailSpanData(name="jailbreak_check", triggered=True, output="blocked")
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "decision"
        assert ev["payload"]["name"] == "jailbreak_check"
        assert ev["payload"]["triggered"] is True
        assert ev["payload"]["output"] == "blocked"

    def test_not_triggered(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = GuardrailSpanData(name="content_filter", triggered=False, output=None)
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        ev = state.buffer[0]
        assert ev["payload"]["triggered"] is False


class TestAgentSpan:
    def test_emits_action_event(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = AgentSpanData(
            name="support_agent",
            handoffs=["billing_agent"],
            tools=["search_web", "get_order"],
            output="Done",
        )
        span = _make_span(TRACE_ID, span_data)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["agent"] == "support_agent"
        assert ev["payload"]["tools"] == ["search_web", "get_order"]
        assert ev["output"]["output"] == "Done"


class TestOnSpanStart:
    def test_on_span_start_is_noop(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        with patch.object(fluq, "_state", state):
            processor.on_span_start(SimpleNamespace())
        assert len(state.buffer) == 0


class TestSpanEdgeCases:
    def test_span_without_span_data_is_ignored(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span = SimpleNamespace(trace_id=TRACE_ID, span_data=None, started_at=0.0, ended_at=1.0)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)
        assert len(state.buffer) == 0

    def test_unknown_span_type_is_ignored(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span = _make_span(TRACE_ID, CustomSpanData())
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)
        assert len(state.buffer) == 0

    def test_missing_trace_id_generates_uuid(self) -> None:
        state = _make_state()
        processor = FluqTracingProcessor()
        span_data = AgentSpanData("bot", [], [], None)
        span = SimpleNamespace(trace_id=None, span_data=span_data, started_at=0.0, ended_at=0.5)
        with patch.object(fluq, "_state", state):
            processor.on_span_end(span)

        ev = state.buffer[0]
        assert ev["traceId"]  # some uuid was generated
        assert ev["traceId"] != "None"
