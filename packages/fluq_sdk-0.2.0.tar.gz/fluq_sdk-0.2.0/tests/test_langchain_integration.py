"""Tests for the LangChain integration."""

from __future__ import annotations

import threading
import uuid
from types import SimpleNamespace
from unittest.mock import patch

import pytest

import fluq
from fluq.integrations.langchain import FluqCallbackHandler


AGENT_ID = "agent-langchain-test"
PARENT_RUN_ID = uuid.UUID("cccccccc-cccc-cccc-cccc-cccccccccccc")
CHILD_RUN_ID = uuid.UUID("dddddddd-dddd-dddd-dddd-dddddddddddd")


def _make_state() -> fluq._ModuleState:
    import httpx
    return fluq._ModuleState(
        api_key="sk-test",
        agent_id=AGENT_ID,
        base_url="https://fluq.ai",
        http=httpx.Client(),
        buffer=[],
        lock=threading.Lock(),
        flush_batch_size=50,
    )


class LLMResult:
    """Minimal fake LangChain LLMResult."""

    def __init__(
        self,
        model: str = "gpt-4o",
        tokens_in: int = 80,
        tokens_out: int = 40,
        text: str = "Answer.",
    ) -> None:
        self.llm_output = {
            "model_name": model,
            "token_usage": {"prompt_tokens": tokens_in, "completion_tokens": tokens_out},
        }
        gen = SimpleNamespace(text=text, message=None)
        self.generations = [[gen]]


class AgentAction:
    def __init__(self, tool: str, tool_input: str) -> None:
        self.tool = tool
        self.tool_input = tool_input


class AgentFinish:
    def __init__(self, output: str, log: str = "") -> None:
        self.return_values = {"output": output}
        self.log = log


class HumanMessage:
    def __init__(self, content: str) -> None:
        self.content = content
        self.type = "human"


class AIMessage:
    def __init__(self, content: str) -> None:
        self.content = content
        self.type = "ai"


# ---------------------------------------------------------------------------
# Not initialized guard
# ---------------------------------------------------------------------------

class TestNotInitialized:
    def test_on_chain_start_noop(self) -> None:
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", None):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)

    def test_on_llm_end_noop(self) -> None:
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", None):
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

    def test_on_tool_end_noop(self) -> None:
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", None):
            handler.on_tool_end("result", run_id=CHILD_RUN_ID)

    def test_on_agent_action_noop(self) -> None:
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", None):
            handler.on_agent_action(AgentAction("tool", "input"), run_id=PARENT_RUN_ID)


# ---------------------------------------------------------------------------
# Chain callbacks
# ---------------------------------------------------------------------------

class TestChainCallbacks:
    def test_on_chain_start_emits_action(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({"name": "MyChain"}, {"input": "hello"}, run_id=PARENT_RUN_ID)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["event"] == "chain_start"
        assert ev["payload"]["name"] == "MyChain"
        assert ev["traceId"] == str(PARENT_RUN_ID)
        assert ev["agentId"] == AGENT_ID
        assert ev["metadata"]["framework"] == "langchain"

    def test_root_chain_uses_run_id_as_trace_id(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID, parent_run_id=None)
        ev = state.buffer[0]
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_child_chain_inherits_parent_trace(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID, parent_run_id=None)
            state.buffer.clear()
            handler.on_chain_start({}, {}, run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_chain_end_emits_action(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_chain_end({"output": "done"}, run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["event"] == "chain_end"

    def test_on_chain_end_has_duration(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_chain_end({}, run_id=PARENT_RUN_ID)
        end_ev = state.buffer[1]
        assert end_ev.get("durationMs") is not None
        assert end_ev["durationMs"] >= 0

    def test_on_chain_error_emits_error(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_chain_error(ValueError("bad input"), run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert "bad input" in ev["errorMessage"]

    def test_chain_name_from_id_list(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({"id": ["langchain", "chains", "LLMChain"]}, {},
                                   run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["payload"]["name"] == "LLMChain"

    def test_chain_name_fallback(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start(None, {}, run_id=PARENT_RUN_ID)
        ev = state.buffer[0]
        assert ev["payload"]["name"] == "chain"


# ---------------------------------------------------------------------------
# LLM callbacks (string prompts)
# ---------------------------------------------------------------------------

class TestLLMCallbacks:
    def test_on_llm_end_emits_llm_call(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_llm_start({}, ["Prompt text"], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(model="gpt-4o", tokens_in=80, tokens_out=40),
                               run_id=CHILD_RUN_ID)

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "llm_call"
        assert ev["resource"] == "langchain.gpt-4o"
        assert ev["tokensIn"] == 80
        assert ev["tokensOut"] == 40
        assert ev["traceId"] == str(PARENT_RUN_ID)
        assert ev["metadata"]["framework"] == "langchain"

    def test_llm_inherits_parent_trace(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

        llm_ev = state.buffer[-1]
        assert llm_ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_llm_error_emits_error(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_error(ConnectionError("timeout"), run_id=CHILD_RUN_ID)
        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert "timeout" in ev["errorMessage"]

    def test_llm_end_has_duration(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)
        ev = state.buffer[0]
        assert ev.get("durationMs") is not None

    def test_llm_end_no_tokens_skips_fields(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        result = SimpleNamespace(llm_output=None, generations=[])
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(result, run_id=CHILD_RUN_ID)
        ev = state.buffer[0]
        assert ev["eventType"] == "llm_call"
        assert ev["resource"] == "langchain.llm"
        assert "tokensIn" not in ev
        assert "tokensOut" not in ev

    def test_llm_end_extracts_generation_text(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        result = LLMResult(text="Paris is the capital.")
        with patch.object(fluq, "_state", state):
            handler.on_llm_start({}, [], run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(result, run_id=CHILD_RUN_ID)
        ev = state.buffer[0]
        assert "output" in ev
        assert "Paris is the capital." in ev["output"]["content"]


# ---------------------------------------------------------------------------
# Chat model callbacks
# ---------------------------------------------------------------------------

class TestChatModelCallbacks:
    def test_on_chat_model_start_registers_trace(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        messages = [[HumanMessage("Hello"), AIMessage("Hi!")]]
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_chat_model_start({}, messages, run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_llm_end(LLMResult(), run_id=CHILD_RUN_ID)

        llm_ev = state.buffer[-1]
        assert llm_ev["traceId"] == str(PARENT_RUN_ID)


# ---------------------------------------------------------------------------
# Tool callbacks
# ---------------------------------------------------------------------------

class TestToolCallbacks:
    def test_on_tool_end_emits_tool_use(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_tool_start({}, "python script", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_tool_end("42", run_id=CHILD_RUN_ID, name="python_repl")

        assert len(state.buffer) == 1
        ev = state.buffer[0]
        assert ev["eventType"] == "tool_use"
        assert ev["resource"] == "python_repl"
        assert ev["output"]["output"] == "42"
        assert ev["traceId"] == str(PARENT_RUN_ID)

    def test_on_tool_error_emits_error(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            handler.on_tool_start({}, "", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_tool_error(OSError("file not found"), run_id=CHILD_RUN_ID, name="file_reader")

        ev = state.buffer[0]
        assert ev["eventType"] == "error"
        assert ev["resource"] == "file_reader"
        assert "file not found" in ev["errorMessage"]

    def test_tool_end_has_duration(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_tool_start({}, "", run_id=CHILD_RUN_ID, parent_run_id=PARENT_RUN_ID)
            handler.on_tool_end("result", run_id=CHILD_RUN_ID)
        ev = state.buffer[0]
        assert ev.get("durationMs") is not None


# ---------------------------------------------------------------------------
# Agent callbacks
# ---------------------------------------------------------------------------

class TestAgentCallbacks:
    def test_on_agent_action_emits_action(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_action(
                AgentAction("search", "what is LangChain?"),
                run_id=PARENT_RUN_ID,
            )
        ev = state.buffer[0]
        assert ev["eventType"] == "action"
        assert ev["payload"]["tool"] == "search"
        assert ev["payload"]["tool_input"] == "what is LangChain?"

    def test_on_agent_action_dict(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_action(
                {"tool": "calculator", "tool_input": "3*7"},
                run_id=PARENT_RUN_ID,
            )
        ev = state.buffer[0]
        assert ev["payload"]["tool"] == "calculator"

    def test_on_agent_finish_emits_decision(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        finish = AgentFinish("Final answer: Paris", "I know the answer")
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_finish(finish, run_id=PARENT_RUN_ID)

        ev = state.buffer[0]
        assert ev["eventType"] == "decision"
        assert ev["payload"]["event"] == "agent_finish"
        assert ev["output"]["output"]["output"] == "Final answer: Paris"

    def test_on_agent_finish_dict(self) -> None:
        state = _make_state()
        handler = FluqCallbackHandler()
        with patch.object(fluq, "_state", state):
            handler.on_chain_start({}, {}, run_id=PARENT_RUN_ID)
            state.buffer.clear()
            handler.on_agent_finish(
                {"return_values": {"output": "42"}, "log": "Done"},
                run_id=PARENT_RUN_ID,
            )
        ev = state.buffer[0]
        assert ev["eventType"] == "decision"
        assert ev["output"]["output"]["output"] == "42"


# ---------------------------------------------------------------------------
# raise_error attribute
# ---------------------------------------------------------------------------

class TestRaiseError:
    def test_raise_error_is_false(self) -> None:
        handler = FluqCallbackHandler()
        assert handler.raise_error is False
