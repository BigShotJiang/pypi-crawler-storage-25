"""Example: LangChain + Fluq observability.

Install:
    pip install fluq-sdk[langchain]

Run:
    FLUQ_API_KEY=fo_xxx OPENAI_API_KEY=sk-... python examples/langchain_example.py
"""

from __future__ import annotations

import os

import fluq
from fluq.integrations.langchain import FluqCallbackHandler

# 1. Initialize Fluq
fluq.init(
    api_key=os.environ.get("FLUQ_API_KEY", "fo_demo"),
    agent_id="research-agent",
)

# 2. Create the handler
handler = FluqCallbackHandler()

# 3. Use with LangChain
# (requires: pip install fluq-sdk[langchain] langchain-openai)
try:
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage

    # Attach the handler to the LLM — it will capture every call
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        callbacks=[handler],
    )

    response = llm.invoke([HumanMessage(content="What is observability in software systems?")])
    print("LLM response:", response.content)

    # Alternatively, attach at chain level for full chain tracing:
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant."),
        ("human", "{question}"),
    ])
    chain = prompt | ChatOpenAI(model="gpt-4o-mini") | StrOutputParser()

    # Pass handler as a config callback to capture the full chain run
    result = chain.invoke(
        {"question": "Explain LangChain in one sentence."},
        config={"callbacks": [handler]},
    )
    print("Chain result:", result)

except ImportError:
    print("langchain-core or langchain-openai not installed.")
    print("Install with: pip install fluq-sdk[langchain] langchain-openai")
except Exception as exc:
    print(f"Error: {exc}")
finally:
    fluq.flush()
    print("Events flushed to Fluq.")
