"""Example: CrewAI + Fluq observability.

Install:
    pip install fluq-sdk[crewai]

Run:
    FLUQ_API_KEY=fo_xxx OPENAI_API_KEY=sk-... python examples/crewai_example.py
"""

from __future__ import annotations

import os

import fluq
from fluq.integrations.crewai import FluqCrewHandler

# 1. Initialize Fluq
fluq.init(
    api_key=os.environ.get("FLUQ_API_KEY", "fo_demo"),
    agent_id="research-crew",
)

# 2. Create the handler
handler = FluqCrewHandler()

# 3. Use with CrewAI
# (requires: pip install fluq-sdk[crewai])
try:
    from crewai import Agent, Task, Crew, Process

    researcher = Agent(
        role="Researcher",
        goal="Research the latest AI trends",
        backstory="You are an expert AI researcher with deep knowledge of the field.",
        verbose=True,
    )

    writer = Agent(
        role="Writer",
        goal="Write a concise summary of research findings",
        backstory="You are a skilled technical writer who explains AI concepts clearly.",
        verbose=True,
    )

    research_task = Task(
        description="Research the top 3 AI trends in 2025 and their impact on software development.",
        expected_output="A bullet-point list of top 3 AI trends with brief descriptions.",
        agent=researcher,
    )

    write_task = Task(
        description="Write a 2-paragraph summary based on the research findings.",
        expected_output="A 2-paragraph summary suitable for a technical blog post.",
        agent=writer,
    )

    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, write_task],
        process=Process.sequential,
        callbacks=[handler],
        verbose=True,
    )

    result = crew.kickoff()
    print("\nCrew result:")
    print(result)

except ImportError:
    print("crewai not installed — install with: pip install fluq-sdk[crewai]")
except Exception as exc:
    print(f"Error: {exc}")
finally:
    fluq.flush()
    print("Events flushed to Fluq.")
