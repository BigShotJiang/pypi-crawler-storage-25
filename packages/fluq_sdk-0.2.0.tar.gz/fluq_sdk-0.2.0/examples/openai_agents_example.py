"""Example: OpenAI Agents SDK + Fluq observability.

Install:
    pip install fluq-sdk[openai-agents]

Run:
    FLUQ_API_KEY=fo_xxx OPENAI_API_KEY=sk-... python examples/openai_agents_example.py
"""

from __future__ import annotations

import os

import fluq
from fluq.integrations.openai_agents import FluqTracingProcessor

# 1. Initialize Fluq
fluq.init(
    api_key=os.environ.get("FLUQ_API_KEY", "fo_demo"),
    agent_id="support-agent",
)

# 2. Create the tracing processor
processor = FluqTracingProcessor()

# 3. Use with the OpenAI Agents SDK
# (requires: pip install openai-agents)
try:
    from agents import Agent, Runner, RunConfig

    agent = Agent(
        name="support",
        instructions="You are a helpful customer support agent.",
    )

    result = Runner.run_sync(
        agent,
        "What is your return policy?",
        run_config=RunConfig(tracing_processors=[processor]),
    )

    print("Agent response:", result.final_output)
except ImportError:
    print("openai-agents not installed — install with: pip install fluq-sdk[openai-agents]")
except Exception as exc:
    print(f"Error: {exc}")
finally:
    fluq.flush()
    print("Events flushed to Fluq.")
