# Framework Integrations PRD — Fluq Python SDK

## Goal
Add framework-specific integrations to the Fluq Python SDK so teams using popular agent frameworks get automatic observability with minimal code changes.

## Current State
- `fluq-sdk` v0.2.0 on PyPI (but missing `watch()` — that's local only)
- `fluq/__init__.py` — core client with event batching, traces, tasks
- `fluq/instruments/openai.py` — proxy-based OpenAI auto-instrumentation
- `fluq/instruments/anthropic.py` — proxy-based Anthropic auto-instrumentation
- `fluq/pricing.py` — cost estimation

## What to Build

### 1. CrewAI Integration (`fluq/integrations/crewai.py`)

CrewAI exposes callbacks. Build a `FluqCrewHandler` that:
- Creates a trace per crew kickoff
- Logs each agent step as an `action` event
- Logs each tool use as a `tool_use` event
- Captures LLM calls as `llm_call` events (CrewAI uses litellm under the hood)
- Logs agent delegation as `spawn` events
- Captures final crew output

**Usage:**
```python
import fluq
from fluq.integrations.crewai import FluqCrewHandler

fluq.init(api_key="fo_xxx", agent_id="research-crew")
handler = FluqCrewHandler()
crew = Crew(agents=[...], tasks=[...], callbacks=[handler])
crew.kickoff()
```

**Reference:** CrewAI's callback system uses `crewai.utilities.callbacks`. Check their source for the exact callback interface.

### 2. OpenAI Agents SDK Integration (`fluq/integrations/openai_agents.py`)

OpenAI Agents SDK (aka Swarm successor) uses a tracing system. Build a `FluqTracingProcessor` that:
- Implements their `TracingProcessor` protocol
- Creates a Fluq trace per agent run
- Maps their spans (generation, function, handoff, guardrail) to Fluq events
- Captures tool calls, handoffs between agents, guardrail results

**Usage:**
```python
import fluq
from fluq.integrations.openai_agents import FluqTracingProcessor

fluq.init(api_key="fo_xxx", agent_id="support-agent")
processor = FluqTracingProcessor()

from agents import Agent, Runner
agent = Agent(name="support", instructions="...")
result = Runner.run(agent, "Help me", run_config=RunConfig(tracing_processor=processor))
```

**Reference:** `openai-agents` package, `agents.tracing` module. They have `TracingProcessor` base class.

### 3. LangChain/LangGraph Integration (`fluq/integrations/langchain.py`)

LangChain uses callbacks. Build a `FluqCallbackHandler` that:
- Extends `BaseCallbackHandler`
- Creates traces per chain/agent run
- Maps `on_llm_start/end` → `llm_call` events
- Maps `on_tool_start/end` → `tool_use` events
- Maps `on_chain_start/end` → `action` events
- Maps `on_agent_action/finish` → `decision` events
- Captures errors via `on_llm_error`, `on_tool_error`, `on_chain_error`

**Usage:**
```python
import fluq
from fluq.integrations.langchain import FluqCallbackHandler

fluq.init(api_key="fo_xxx", agent_id="research-agent")
handler = FluqCallbackHandler()

from langchain.chat_models import ChatOpenAI
llm = ChatOpenAI(callbacks=[handler])
```

**Reference:** `langchain_core.callbacks.base.BaseCallbackHandler` — well-documented interface.

## Architecture Rules

1. Each integration is a separate file in `fluq/integrations/`
2. All integrations import the framework LAZILY — don't break `import fluq` for users without the framework
3. Each integration creates events using the existing `Fluq` client methods (`.event()`, `.trace()`)
4. Framework packages are optional dependencies (extras in pyproject.toml): `pip install fluq-sdk[crewai]`, `pip install fluq-sdk[langchain]`, `pip install fluq-sdk[openai-agents]`
5. Each integration must have a corresponding test file in `tests/`
6. Each integration needs a standalone example in `examples/`

## File Structure
```
fluq/
├── integrations/
│   ├── __init__.py
│   ├── crewai.py
│   ├── openai_agents.py
│   └── langchain.py
tests/
├── test_crewai_integration.py
├── test_openai_agents_integration.py
└── test_langchain_integration.py
examples/
├── crewai_example.py
├── openai_agents_example.py
└── langchain_example.py
```

## pyproject.toml Changes
Add optional dependency groups:
```toml
[project.optional-dependencies]
crewai = ["crewai>=0.60.0"]
langchain = ["langchain-core>=0.3.0"]
openai-agents = ["openai-agents>=0.1.0"]
all = ["crewai>=0.60.0", "langchain-core>=0.3.0", "openai-agents>=0.1.0"]
```

## Acceptance Criteria
- [ ] `pip install fluq-sdk[crewai]` → CrewAI crew runs produce events in Fluq dashboard
- [ ] `pip install fluq-sdk[openai-agents]` → Agent runs produce events in Fluq dashboard
- [ ] `pip install fluq-sdk[langchain]` → Chain/agent runs produce events in Fluq dashboard
- [ ] Each integration has tests that mock the framework and verify correct event emission
- [ ] Each integration has a working example script
- [ ] `pip install fluq-sdk` (no extras) still works — frameworks are optional
- [ ] README updated with integration examples

## Reference Code

AgentOps (MIT licensed) has integration implementations in `agentops-ref/`:
- `crewai_instrumentation.py` — 535 lines, CrewAI monkey-patching approach
- `openai_agents_processor.py` + `openai_agents_instrumentor.py` — OpenAI Agents SDK tracing processor
- `langgraph_instrumentation.py` — 598 lines, LangGraph callback-based approach

Study these for the framework APIs/callback interfaces, then build our own clean implementation using our event model. Do NOT copy code — use as reference for understanding the framework hooks.

## Priority Order
1. OpenAI Agents SDK (newest, fastest growing, clean tracing API)
2. CrewAI (most popular multi-agent framework)
3. LangChain (largest install base, most complex callback interface)

## API Endpoint
Events go to: `https://fluq.ai/api/v1/events` (not api.fluq.dev — that's the old placeholder)
Base URL should default to `https://fluq.ai` in the SDK.
