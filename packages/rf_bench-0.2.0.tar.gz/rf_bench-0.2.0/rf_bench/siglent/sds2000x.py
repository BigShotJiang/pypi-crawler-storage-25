"""
sds2000x.py — Siglent SDS2000X Plus oscilloscope driver

Connects via raw TCP/SCPI to port 5025. Used primarily for audio waveform
capture and FFT analysis in the two-tone IMD test.

Waveform data is returned as IEEE 488.2 binary block; the driver decodes it
using the preamble scaling factors and returns a numpy array of voltages.

NOTE: Exact SCPI command names should be verified against the SDS2000X Plus
Programming Guide (available from Siglent's website). The commands used here
follow the standard Siglent SDS convention but some names may differ slightly
across firmware versions.
"""

import socket
import struct
import time

import numpy as np


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_HOST    = "10.1.1.62"
DEFAULT_PORT    = 5025
CONNECT_TIMEOUT = 10       # seconds
RECV_TIMEOUT    = 30       # seconds — waveform transfers can be slow
RECV_BUFSIZE    = 1 << 20  # 1 MB read buffer

# Audio capture defaults
AUDIO_COUPLING      = "AC"     # AC coupling blocks DC offset
AUDIO_TIMEBASE_S    = 0.2      # seconds/div → 2 s total for good FFT resolution
AUDIO_VDIV_DEFAULT  = 0.05     # 50 mV/div — adjust if audio level is clipping


# ---------------------------------------------------------------------------
# Driver class
# ---------------------------------------------------------------------------

class SDS2000X:
    """
    Driver for the Siglent SDS2000X Plus oscilloscope.

    Primary use: capture audio waveform for FFT-based IMD analysis.

    Usage:
        scope = SDS2000X("10.1.1.62")
        voltages, sample_rate = scope.capture_audio(channel=1, duration_s=2.0)
        scope.close()
    """

    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self._host = host
        self._port = port
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(CONNECT_TIMEOUT)
        self._sock.connect((host, port))
        self._sock.settimeout(RECV_TIMEOUT)
        time.sleep(0.1)
        try:
            self._sock.recv(RECV_BUFSIZE)
        except socket.timeout:
            pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def identify(self) -> str:
        return self._query("*IDN?")

    def capture_audio(
        self,
        channel: int = 1,
        duration_s: float = 2.0,
        vdiv: float = AUDIO_VDIV_DEFAULT,
    ) -> tuple[np.ndarray, float]:
        """
        Capture a waveform from an audio signal on the specified channel.

        Sets the channel to AC coupling, adjusts the timebase for the requested
        duration, runs a continuous acquisition, then freezes it and reads the
        waveform data.

        Args:
            channel:    Scope channel number (1–4)
            duration_s: Capture duration in seconds. The timebase is set to
                        duration_s / 10 (s/div, 10 divisions total).
                        Longer durations give better FFT frequency resolution
                        but take more time. 2.0 s → ~0.5 Hz FFT bin width.
            vdiv:       Vertical sensitivity in V/div. Set this just large
                        enough that the audio signal fills ~50% of screen.

        Returns:
            (voltages, sample_rate_hz):
                voltages       — numpy float64 array, length = number of points
                sample_rate_hz — actual sample rate from scope preamble (Hz)

        Raises:
            RuntimeError: if the scope does not respond or waveform read fails.
        """
        ch = f"CH{channel}"

        # Configure channel
        self._cmd(f":CHANnel{channel}:DISPlay ON")
        self._cmd(f":CHANnel{channel}:COUPling {AUDIO_COUPLING}")
        self._cmd(f":CHANnel{channel}:SCALe {vdiv:.4f}")

        # Timebase: duration_s / 10 divisions
        tdiv = duration_s / 10.0
        self._cmd(f":TIMebase:SCALe {tdiv:.6f}")

        # Trigger: auto mode so we don't wait for a trigger event
        self._cmd(f":TRIGger:EDGe:SOURce {ch}")
        self._cmd(":TRIGger:SWEep AUTO")

        # Run then stop to freeze a clean acquisition
        self._cmd(":RUN")
        time.sleep(duration_s + 0.5)   # let scope fill its buffer
        self._cmd(":STOP")
        time.sleep(0.2)

        # Select waveform source and format
        self._cmd(f":WAVeform:SOURce {ch}")
        self._cmd(":WAVeform:FORMat BYTE")

        # Read preamble for scaling
        preamble_str = self._query(":WAVeform:PREamble?")
        xincrement, yincrement, yorigin, yreference = self._parse_preamble(
            preamble_str
        )

        # Read waveform data (IEEE 488.2 binary block)
        raw = self._read_binary_waveform()
        if len(raw) == 0:
            raise RuntimeError("Waveform data read returned empty — check channel and timebase")

        # Convert raw ADC counts to volts
        counts   = np.frombuffer(raw, dtype=np.uint8).astype(np.float64)
        voltages = (counts - yreference) * yincrement + yorigin

        sample_rate_hz = 1.0 / xincrement if xincrement > 0 else 0.0
        return voltages, sample_rate_hz

    def measure_rms(self, channel: int = 1) -> float:
        """
        Return the RMS voltage measurement from the scope's built-in measurement.

        Useful for simple audio level checks (blocking test with AGC off).
        Units: volts RMS.
        """
        resp = self._query(f":MEASure:VRMS? CH{channel}")
        try:
            return float(resp.split()[-1])
        except (ValueError, IndexError):
            return float("nan")

    def autoscale_vdiv(self, channel: int, target_divisions: float = 3.0) -> float:
        """
        Run the scope for a moment, read the peak-to-peak voltage, and return
        a suggested V/div setting that fills ~target_divisions of screen.

        Returns the suggested V/div (not yet applied — caller must set it).
        """
        self._cmd(":RUN")
        time.sleep(0.5)
        resp = self._query(f":MEASure:VPP? CH{channel}")
        self._cmd(":STOP")
        try:
            vpp = float(resp.split()[-1])
            return vpp / (2 * target_divisions)
        except (ValueError, IndexError):
            return AUDIO_VDIV_DEFAULT

    def close(self) -> None:
        self._cmd(":RUN")   # leave scope running
        self._sock.close()

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _cmd(self, cmd: str) -> None:
        self._sock.sendall((cmd + "\n").encode())
        time.sleep(0.05)

    def _query(self, cmd: str) -> str:
        self._sock.sendall((cmd + "\n").encode())
        time.sleep(0.05)
        try:
            data = self._recvall_text()
            return data.strip()
        except socket.timeout:
            return ""

    def _recvall_text(self) -> str:
        """Receive a text response (terminated by newline)."""
        buf = b""
        while True:
            try:
                chunk = self._sock.recv(RECV_BUFSIZE)
                buf += chunk
                if buf.endswith(b"\n"):
                    break
            except socket.timeout:
                break
        return buf.decode(errors="replace")

    def _read_binary_waveform(self) -> bytes:
        """
        Send :WAVeform:DATA? and receive an IEEE 488.2 binary block response.

        Format: #<n><length><data>\n
            n      — single ASCII digit: number of digits in <length>
            length — ASCII decimal: number of data bytes following
            data   — raw binary waveform bytes
        """
        self._sock.sendall(b":WAVeform:DATA?\n")
        time.sleep(0.1)

        # Read the header: '#' + n + length_digits
        header = b""
        while len(header) < 2:
            header += self._sock.recv(2 - len(header))

        if header[0:1] != b"#":
            raise RuntimeError(f"Expected IEEE 488.2 binary block, got: {header!r}")

        n_digits = int(header[1:2])
        length_bytes = b""
        while len(length_bytes) < n_digits:
            length_bytes += self._sock.recv(n_digits - len(length_bytes))
        data_length = int(length_bytes)

        # Read exactly data_length bytes
        data = b""
        remaining = data_length
        while remaining > 0:
            chunk = self._sock.recv(min(remaining, RECV_BUFSIZE))
            if not chunk:
                break
            data += chunk
            remaining -= len(chunk)

        # Consume trailing newline if present
        try:
            self._sock.recv(1)
        except socket.timeout:
            pass

        return data

    def _parse_preamble(self, preamble: str) -> tuple[float, float, float, float]:
        """
        Parse the :WAVeform:PREamble? response.

        Expected format (comma-separated):
            format, type, points, count, xincrement, xorigin, xreference,
            yincrement, yorigin, yreference

        Returns: (xincrement, yincrement, yorigin, yreference)
            xincrement: seconds per sample
            yincrement: volts per ADC count
            yorigin:    voltage at ADC count = 0
            yreference: ADC count at center (typically 128 for BYTE format)
        """
        parts = [p.strip() for p in preamble.split(",")]
        if len(parts) < 10:
            raise RuntimeError(
                f"Unexpected preamble format ({len(parts)} fields): {preamble!r}"
            )
        try:
            xincrement  = float(parts[4])
            # xorigin   = float(parts[5])  # not needed for FFT
            # xreference = float(parts[6]) # not needed
            yincrement  = float(parts[7])
            yorigin     = float(parts[8])
            yreference  = float(parts[9])
        except (ValueError, IndexError) as e:
            raise RuntimeError(f"Failed to parse preamble: {preamble!r}") from e

        return xincrement, yincrement, yorigin, yreference
