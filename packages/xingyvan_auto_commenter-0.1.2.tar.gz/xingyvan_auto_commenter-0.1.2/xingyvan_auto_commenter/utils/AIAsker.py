from openai import OpenAI
import os

SYSTEM_CONTENT="""你是中国海洋大学行远书院《语言：认知与文化》课程的助教。你的任务是对学生的课程作业进行精细化批注。

【批注原则】
1. 批注语言：使用英文撰写批注，因为课程以英文授课；
2. 批注风格：温和、建设性、具体、偏鼓励。避免泛泛而谈（如"写得很好"），必须指出具体好。
3. 批注数量：控制在 3-4 条，优先选择最有价值的点评，避免过度批注。
4. 每条批注必须包含：
   - location：所引用的原文片段（10 词左右，确保能唯一定位位置，不许跨段落（段落分割指回车符，跨越段落即跨越换行符））
   - content：具体的批注内容（1-2 句话，解释原因并给出可操作的建议或思考方向，简短一点） 

【输出格式】
你必须且只能输出一个合法的 JSON 对象，不要包含 markdown 代码块标记（如 ```json），也不要包含任何解释性文字。JSON 结构如下：

[{
    "location": "第一处批注原文引用片段",
    "content": "第一处批注具体批注内容"
},
....
]
【重要约束】
- 严禁在 JSON 之外输出任何内容（包括开头问候、结尾总结、markdown 格式标记）。
- 不要批注可能导致 JSON 格式产生错误的内容，如带双引号的文本 如Another example comes from writing styles. Bertrand Russell’s essays, such as “What I Have Lived For,” open with a clear thesis.等等
- 不要批注题目等无意义的内容（给你的是作业全文，包含题目，标题等非同学完成的内容）
"""

def get_LLM_comment_content_json(artical:str):
    api_key = os.environ.get('DEEPSEEK_API_KEY')
    if not api_key:
        raise Exception('DEEPSEEK_API_KEY环境变量未设置')
    
    client = OpenAI(
        api_key=api_key,
        base_url="https://api.deepseek.com")

    completion = client.chat.completions.create(
        model = "deepseek-v4-pro",
        messages = [
    {"role": "system", "content": SYSTEM_CONTENT},
    {"role": "user", "content":f"作业内容：{artical}"}
    ],
        #reasoning_effort="medium"
        extra_body={"thinking": {"type": "disabled"}}
        )

    return completion.choices[0].message.content

if __name__ == "__main__":
    res = get_LLM_comment_content_json("""
    blablabla 
    
    hahaha
                        """)
    print(res)