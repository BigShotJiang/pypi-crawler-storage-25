from .AutoCommenter import AutoCommenter
import os,sys
from tqdm import tqdm

def main():
    if len(sys.argv)<2:
        print('Usage:xyhwk <target folder e.g. ./W1-2 >')
        sys.exit(1)
    
    acs= []
    homework_dir = sys.argv[1]
    #homework_dir = "./homeworks"
    for folder, _, file_name_list in os.walk(homework_dir):
        for file_name in file_name_list:
            if file_name.endswith('.docx'):
                file_path = os.path.join(folder, file_name)
                acs.append(AutoCommenter(file_path))
        break
    for ac in tqdm(acs):
        ac.auto_comment()

if __name__=="__main__":
    main()