"""Process-level urllib3 PoolManager for SDK HTTPS calls (NET.10).

Why this exists
---------------
Across a single `reflex` cli launch we make at least:

  * 3 parallel GETs against Modal `*.modal.direct/health` (region probe)
  * 1 POST to `api.tryreflex.ai/api/mutation` (Convex authorize)
  * 1 fire-and-forget GET against the worker `/health` (TLS pre-warm)
  * 1 POST to `<worker>.modal.direct/webrtc-offer` (signaling SDP exchange)

With the previous `urllib.request` implementation each call opened a fresh
TCP socket + completed a fresh TLS 1.3 handshake. On residential WAN the
handshake alone is 50-100ms — which is wholly redundant for the second
call to a host we just spoke to. The TLS pre-warm hack in
`auth_runner._prewarm_worker_tls` was an attempt to mask this, but the
underlying `urllib.request` connection cache only kicks in inside a single
`urlopen` call; it does NOT reuse sockets across calls.

`urllib3.PoolManager` does — it indexes pools by (scheme, host, port) and
keeps TLS sessions alive between calls. Sharing a single process-level
PoolManager means:

  * The region probe pays the TLS cost ONCE per region (the second sample
    in `REGION_PROBE_SAMPLES=2` reuses the socket).
  * The TLS pre-warm GET to `/health` actually warms the socket the
    subsequent `/webrtc-offer` POST will reuse.
  * Repeat cli launches inside the same Python process (eg the bench
    harness, or `reflex` invoked as a library) reuse pools entirely.

Backwards compatibility
-----------------------
This module exposes helpers that return ``(status, headers, body_bytes)``
tuples so call sites can keep raising the same error types they did
before (``AuthError`` for Convex, the existing 502/503/504 wake loop in
``webrtc_client.py``).
"""

from __future__ import annotations

import threading
from typing import Any

try:
    import urllib3
    from urllib3.exceptions import HTTPError as _Urllib3HTTPError
    from urllib3.exceptions import MaxRetryError as _MaxRetryError
    from urllib3.util.retry import Retry
except ImportError as exc:  # pragma: no cover — urllib3 is a hard dep now
    raise ImportError(
        "reflex SDK requires urllib3 (added in 0.3.9). "
        "Reinstall with: pip install -U reflex-sdk"
    ) from exc


_pool_lock = threading.Lock()
_pool: "urllib3.PoolManager | None" = None


def get_pool() -> "urllib3.PoolManager":
    """Return the process-singleton PoolManager.

    Thread-safe via a one-shot lock; the lock is only contended on the
    very first call, after which the module-level binding is hot.
    """
    global _pool
    if _pool is not None:
        return _pool
    with _pool_lock:
        if _pool is None:
            # No automatic retry — call sites already have their own
            # 503/cold-worker logic and we don't want to silently double
            # POSTs (Convex mutations aren't idempotent on the SDK side).
            _pool = urllib3.PoolManager(
                num_pools=16,        # plenty for 3 modal regions + convex + worker
                maxsize=4,           # per-host max conns; we're single-threaded mostly
                block=False,
                retries=Retry(total=0, read=0, connect=0, redirect=0),
                timeout=urllib3.Timeout(connect=10.0, read=60.0),
            )
    return _pool


class HTTPResponse:
    """Lightweight (status, headers, data) tuple with the bits call sites need.

    Mirrors enough of ``http.client.HTTPResponse`` that the old call sites
    don't notice the swap.
    """

    __slots__ = ("status", "headers", "data")

    def __init__(self, status: int, headers: dict[str, str], data: bytes):
        self.status = status
        self.headers = headers
        self.data = data

    def read(self, n: int | None = None) -> bytes:
        if n is None or n >= len(self.data):
            return self.data
        return self.data[:n]


def request(
    method: str,
    url: str,
    *,
    body: bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: float | None = None,
) -> HTTPResponse:
    """Issue one request through the shared pool and return a fully-read response.

    Raises ``urllib3.exceptions.HTTPError`` (or subclasses) on transport
    failures; HTTP error responses (4xx/5xx) come back as a normal
    ``HTTPResponse`` and the caller decides whether to raise.

    The contract intentionally matches what auth_runner / webrtc_client
    were doing with ``urllib.request.urlopen`` so the migration is a
    near-1:1 swap.
    """
    pool = get_pool()
    hdrs = dict(headers or {})
    kwargs: dict[str, Any] = {
        "method": method,
        "url": url,
        "headers": hdrs,
        "preload_content": True,  # fully-buffered body, matches urllib.request
    }
    if body is not None:
        kwargs["body"] = body
    if timeout is not None:
        kwargs["timeout"] = urllib3.Timeout(connect=min(timeout, 10.0), read=timeout)

    r = pool.request(**kwargs)
    # PoolManager.request returns a urllib3.BaseHTTPResponse; we materialize
    # into our tiny wrapper so callers don't carry a urllib3 dep at the
    # type level (and so the response is unambiguously closed/released).
    try:
        return HTTPResponse(
            status=int(r.status),
            headers=dict(r.headers),
            data=bytes(r.data) if r.data is not None else b"",
        )
    finally:
        try:
            r.release_conn()
        except Exception:
            pass


# Re-export the exception types call sites might want to catch — they map
# onto the old urllib.error.URLError / TimeoutError surface.
HTTPError = _Urllib3HTTPError
MaxRetryError = _MaxRetryError


__all__ = [
    "HTTPError",
    "HTTPResponse",
    "MaxRetryError",
    "get_pool",
    "request",
]
