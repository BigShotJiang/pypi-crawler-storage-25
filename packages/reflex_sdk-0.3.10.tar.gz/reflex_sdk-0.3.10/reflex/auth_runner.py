"""Authorize an inference session with Convex before a WebRTC connect.

PROD.2 (hq-qouv) — bolt-on to ``connect_runner.run_session`` that resolves
the rfx_* API key, calls ``publicApi:authorizeSession``, and returns a
:class:`SessionGrant` the transport can use to attach an
``Authorization: Bearer <token>`` header.

If REFLEX_API_KEY (or ~/.config/reflex/credentials.json) is NOT set, this
module is a no-op — the runner falls back to the yaml's target URL with
no auth header (dev/local mode, only works against workers with
``REFLEX_REQUIRE_SESSION_TOKEN=0``).

Once REFLEX_REQUIRE_SESSION_TOKEN=1 lands on prod workers, every connect
must go through this module first.
"""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import _http


CONVEX_URL_DEFAULT = "https://api.tryreflex.ai"
USER_AGENT = "reflex-sdk-cli/0.2"


class AuthError(RuntimeError):
    """Authorize step failed; caller should bail."""


@dataclass(frozen=True)
class SessionGrant:
    session_token: str
    worker_url: str
    expires_at: int
    session_id: str
    base_model: str

    def auth_header(self) -> dict[str, str]:
        return {"authorization": f"Bearer {self.session_token}"}


def _resolve_api_key() -> str | None:
    """Resolve rfx_* api key from env or ~/.config/reflex/credentials.json."""
    val = (os.environ.get("REFLEX_API_KEY") or "").strip()
    if val:
        return val
    for path in (
        Path.home() / ".reflex" / "api_key",
        Path.home() / ".reflex" / "credentials",
        Path.home() / ".config" / "reflex" / "credentials.json",
    ):
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            continue
        if path.suffix == ".json" or text.startswith("{"):
            try:
                obj = json.loads(text)
                key = (obj.get("apiKey") or obj.get("api_key") or "").strip()
                if key:
                    return key
            except Exception:
                pass
        else:
            return text
    return None


# NET.3: known Modal regional endpoints we can probe to find the nearest.
# Each entry: (region_key, probe_url). Probe must be cheap (HEAD or short GET).
# Added regions appear here once their primeNode is registered with Convex.
KNOWN_REGIONS = (
    (
        "us-west",
        "https://reflex-inc--reflex-inference-molmoact-webrtc-baseline-mo-8e694d.us-west.modal.direct/health",
    ),
    (
        "us-east",
        "https://reflex-inc--reflex-inference-molmoact-webrtc-baseline-us-e787db.us-east.modal.direct/health",
    ),
    (
        "eu-west",
        "https://reflex-inc--reflex-inference-molmoact-webrtc-baseline-eu-1a1336.eu-west.modal.direct/health",
    ),
)
REGION_PROBE_TIMEOUT_S = 2.5
REGION_PROBE_SAMPLES = 2


def _probe_nearest_region() -> str | None:
    """Probe known regions; return the lowest-latency region key.

    Costs one HEAD-equivalent per region per sample. Cached for the lifetime
    of the process via REFLEX_PINNED_REGION env var; subsequent calls skip
    the probe. Returns None on total failure (no region pickable, authorize
    proceeds with no region hint).
    """
    pinned = (os.environ.get("REFLEX_PINNED_REGION") or "").strip().lower()
    if pinned:
        return pinned

    import concurrent.futures as _cf

    def _probe_one(url: str) -> float:
        latencies = []
        for _ in range(REGION_PROBE_SAMPLES):
            t0 = time.perf_counter()
            try:
                # NET.10: urllib3 PoolManager — the 2nd sample (and any later
                # call to the same host) reuses the kept-alive TLS session,
                # which is the whole point of running multiple samples.
                _http.request(
                    "GET",
                    url,
                    headers={"user-agent": USER_AGENT},
                    timeout=REGION_PROBE_TIMEOUT_S,
                )
                latencies.append(time.perf_counter() - t0)
            except Exception:
                return float("inf")
        return min(latencies)

    results: dict[str, float] = {}
    with _cf.ThreadPoolExecutor(max_workers=len(KNOWN_REGIONS)) as ex:
        future_to_region = {
            ex.submit(_probe_one, url): region for region, url in KNOWN_REGIONS
        }
        for fut in _cf.as_completed(future_to_region):
            region = future_to_region[fut]
            results[region] = fut.result()

    if not results or all(v == float("inf") for v in results.values()):
        return None
    best = min(results, key=lambda k: results[k])
    best_ms = results[best] * 1000
    print(
        f"[reflex] region probe: chose {best!r} ({best_ms:.0f}ms) — "
        f"{ {k: f'{v*1000:.0f}ms' for k, v in results.items()} }",
        file=sys.stderr, flush=True,
    )
    # Cache the pick for the rest of the process (avoids re-probing per call).
    os.environ["REFLEX_PINNED_REGION"] = best
    return best


def _convex_mutation(convex_url: str, path: str, args: dict, *, timeout: float = 30.0) -> dict:
    body = json.dumps({"path": path, "format": "json", "args": args}).encode("utf-8")
    # NET.10: routed through the shared urllib3 PoolManager so this call
    # reuses any kept-alive TLS session to api.tryreflex.ai from earlier
    # in the cli launch (and warms it for subsequent ones).
    try:
        resp = _http.request(
            "POST",
            f"{convex_url.rstrip('/')}/api/mutation",
            body=body,
            headers={"content-type": "application/json", "user-agent": USER_AGENT},
            timeout=timeout,
        )
    except _http.HTTPError as exc:
        raise AuthError(f"convex transport error: {exc}") from exc
    if resp.status >= 400:
        snippet = resp.data.decode("utf-8", errors="replace")[:200]
        raise AuthError(f"convex HTTP {resp.status}: {snippet}")
    try:
        payload = json.loads(resp.data)
    except Exception as exc:
        snippet = resp.data.decode("utf-8", errors="replace")[:200]
        raise AuthError(f"convex non-json response: {snippet}") from exc
    if payload.get("status") != "success":
        raise AuthError(f"convex error: {json.dumps(payload)[:200]}")
    return payload["value"]


CACHE_PATH = Path.home() / ".cache" / "reflex" / "session.json"
CACHE_GRACE_MS = 60_000  # don't reuse a token within 60s of expiry


def _load_cached_grant(api_key: str, base_model: str, robot_type: str) -> "SessionGrant | None":
    """NET.6: reuse a still-valid token from ~/.cache/reflex/session.json.

    Skipped via REFLEX_NO_SESSION_CACHE=1. The cache key includes api_key
    prefix + baseModel + robotType so unrelated calls don't collide.
    """
    if os.environ.get("REFLEX_NO_SESSION_CACHE"):
        return None
    try:
        if not CACHE_PATH.exists():
            return None
        obj = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return None
    if obj.get("api_key_prefix") != api_key[:16]:
        return None
    if obj.get("base_model") != base_model or obj.get("robot_type") != robot_type:
        return None
    expires_at = int(obj.get("expires_at", 0))
    if expires_at - time.time() * 1000 < CACHE_GRACE_MS:
        return None
    return SessionGrant(
        session_token=obj["session_token"],
        worker_url=obj["worker_url"],
        expires_at=expires_at,
        session_id=obj["session_id"],
        base_model=obj["base_model"],
    )


def _save_cached_grant(api_key: str, grant: "SessionGrant", base_model: str, robot_type: str) -> None:
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        CACHE_PATH.write_text(json.dumps({
            "api_key_prefix": api_key[:16],
            "base_model": base_model,
            "robot_type": robot_type,
            "session_token": grant.session_token,
            "worker_url": grant.worker_url,
            "expires_at": grant.expires_at,
            "session_id": grant.session_id,
        }), encoding="utf-8")
        try:
            os.chmod(CACHE_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass  # cache miss is harmless


def _prewarm_worker_tls(worker_url: str) -> None:
    """NET.7: fire-and-forget HEAD to warm the TCP+TLS connection to the
    Modal worker while the caller proceeds to build the WebRTC offer.

    The next /webrtc-offer POST reuses the freshly-warmed socket via the
    shared urllib3 PoolManager (NET.10 — was previously a best-effort hack
    against urllib's per-call socket cache that often missed). Saves
    ~50-100ms on cold runs on residential WAN.
    """
    import threading

    def _go():
        try:
            _http.request(
                "GET",
                f"{worker_url.rstrip('/')}/health",
                headers={"user-agent": USER_AGENT},
                timeout=5,
            )
        except Exception:
            pass  # pre-warm failures are silent

    t = threading.Thread(target=_go, name="reflex-tls-prewarm", daemon=True)
    t.start()


def maybe_authorize(
    *,
    base_model: str | None = None,
    robot_type: str | None = None,
    convex_url: str | None = None,
) -> SessionGrant | None:
    """Try to authorize a session; return None if no creds set (dev mode).

    Raises :class:`AuthError` if creds ARE set but the call fails — that's
    a real misconfiguration we should surface to the user.
    """
    api_key = _resolve_api_key()
    if not api_key:
        return None

    base_model = base_model or os.environ.get("REFLEX_BASE_MODEL") or "molmoact2-bimanualyam"
    robot_type = robot_type or os.environ.get("REFLEX_ROBOT_TYPE") or "yam_bimanual"

    # NET.6: try the session token cache first — saves ~400ms when a recent
    # cli run cached a still-valid token. Skipped via REFLEX_NO_SESSION_CACHE=1.
    cached = _load_cached_grant(api_key, base_model, robot_type)
    if cached is not None:
        print(
            f"[reflex] reused cached session (expires {time.strftime('%H:%M:%S', time.localtime(cached.expires_at/1000))}) — set REFLEX_NO_SESSION_CACHE=1 to disable",
            file=sys.stderr, flush=True,
        )
        _prewarm_worker_tls(cached.worker_url)
        return cached
    convex_url = (
        convex_url
        or os.environ.get("REFLEX_CONVEX_URL")
        or CONVEX_URL_DEFAULT
    )

    # NET.3: probe nearest region (cached after first call). Skipped via
    # REFLEX_SKIP_REGION_PROBE=1 if the caller already knows their region.
    client_region: str | None = None
    if not os.environ.get("REFLEX_SKIP_REGION_PROBE"):
        try:
            client_region = _probe_nearest_region()
        except Exception as exc:
            print(f"[reflex] region probe failed ({exc}); proceeding without hint", file=sys.stderr, flush=True)

    auth_args = {"apiKey": api_key, "baseModel": base_model, "robotType": robot_type}
    if client_region:
        auth_args["clientRegion"] = client_region

    t0 = time.perf_counter()
    result = _convex_mutation(
        convex_url,
        "publicApi:authorizeSession",
        auth_args,
    )
    dt_ms = (time.perf_counter() - t0) * 1000

    if not result.get("ok"):
        reason = result.get("reason", "unknown")
        hint = {
            "unknown_key": "API key not recognized — mint a new one at https://app.tryreflex.ai/keys",
            "balance_too_low": "org balance < $5 — top up at https://app.tryreflex.ai/billing",
            "no_inference_node_available": f"no worker live for baseModel={base_model!r}",
        }.get(reason, "")
        raise AuthError(f"authorize rejected: reason={reason} {hint}")

    print(
        f"[reflex] authorized session in {dt_ms:.0f} ms — session_id={result['sessionId']} "
        f"base_model={base_model} expires_at={result['expiresAt']}",
        file=sys.stderr, flush=True,
    )
    grant = SessionGrant(
        session_token=result["token"],
        worker_url=result.get("primeUrl") or result.get("workerUrl") or "",
        expires_at=int(result["expiresAt"]),
        session_id=result["sessionId"],
        base_model=result.get("model") or base_model,
    )
    # NET.6: cache the grant for the next cli run within TTL
    _save_cached_grant(api_key, grant, base_model, robot_type)
    # NET.7: pre-warm TLS to the worker while caller builds WebRTC offer
    if grant.worker_url:
        _prewarm_worker_tls(grant.worker_url)
    return grant
