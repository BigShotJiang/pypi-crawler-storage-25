"""SQLAlchemy model for the drafts table.

A draft is a staging artifact: a user pastes raw input (e.g. DDL) or
assembles a partial artifact, and the system captures both the raw
source and the parsed, portable YAML representation. Drafts can later
be promoted to real contracts or ontologies.

Drafts carry a ``visibility`` field (``private`` / ``team`` / ``public``)
so users can choose how widely they share in-progress work. Promotion
archives the draft with a reference to the new artifact, preserving
provenance.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class DraftModel(Base):
    """SQLAlchemy model for the drafts table.

    A draft captures a work-in-progress artifact before it is promoted
    to a full contract or ontology. Both the raw source and the parsed
    portable YAML form are stored so promotion is deterministic.
    """

    __tablename__ = "drafts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Core identifiers
    name = Column(String(255), nullable=False)
    namespace = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)

    # Source and parsed payloads
    source_type = Column(String(50), nullable=False)
    source_payload = Column(Text, nullable=False)
    parsed_yaml = Column(Text, nullable=False)

    # Visibility and ownership
    visibility = Column(String(20), nullable=False, default="private")
    owner_id = Column(String(255), nullable=False)
    team_id = Column(String(255), nullable=True)

    # Promotion provenance
    promoted_to_kind = Column(String(50), nullable=True)
    promoted_to_ref = Column(String(512), nullable=True)
    promoted_at = Column(DateTime(timezone=True), nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    __table_args__ = (
        UniqueConstraint("owner_id", "name", name="uq_drafts_owner_name"),
        {"schema": "pycharter"},
    )
