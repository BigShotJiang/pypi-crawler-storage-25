"""
SQLAlchemy model for proposals table.

Proposals are proposal-based change requests that link a source branch
to a target branch, similar to pull requests.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ProposalModel(Base):
    """SQLAlchemy model for proposals table."""

    __tablename__ = "proposals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(String(255), nullable=False, index=True)
    title = Column(String(500), nullable=False)
    description = Column(Text, nullable=True)
    source_branch_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.branches.id", ondelete="SET NULL"),
        nullable=True,
    )
    target_branch_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.branches.id", ondelete="SET NULL"),
        nullable=True,
    )
    status = Column(String(50), nullable=False, default="open")
    author = Column(String(255), nullable=False)
    proposal_type = Column(String(50), nullable=False, default="mapping_change")
    required_approvals = Column(Integer, nullable=False, server_default="1")
    enforce_gates = Column(Boolean, nullable=False, server_default="false")
    gate_status = Column(JSON, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = ({"schema": "pycharter"},)
