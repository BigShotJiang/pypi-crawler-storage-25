"""
SQLAlchemy models for imported schema tables.

Stores the raw imported schemas, tables, columns, and relationships
from external sources (DDL, dbt, OpenAPI, database introspection, CSV).
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ImportedSchemaModel(Base):
    """Top-level container for an imported schema source."""

    __tablename__ = "imported_schemas"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_name = Column(String(255), nullable=False, unique=True, index=True)
    source_type = Column(String(50), nullable=False)
    raw_source = Column(Text, nullable=True)
    metadata_json = Column(JSON, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)

    # Relationships
    tables = relationship(
        "ImportedTableModel",
        back_populates="schema",
        cascade="all, delete-orphan",
    )
    relationships_list = relationship(
        "ImportedRelationshipModel",
        back_populates="schema",
        cascade="all, delete-orphan",
    )

    __table_args__ = ({"schema": "pycharter"},)


class ImportedTableModel(Base):
    """A table within an imported schema."""

    __tablename__ = "imported_tables"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    schema_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_schemas.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name = Column(String(255), nullable=False)
    schema_name = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    is_view = Column(Boolean, nullable=False, server_default="false")
    is_junction = Column(Boolean, nullable=False, server_default="false")
    primary_key_columns = Column(JSON, nullable=True)
    tags = Column(JSON, nullable=True)
    extra_json = Column(JSON, nullable=True)

    # Mapping state for concept mapping workflow
    mapping_state = Column(String(20), nullable=False, server_default="unmapped")

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)

    # Relationships
    schema = relationship("ImportedSchemaModel", back_populates="tables")
    columns = relationship(
        "ImportedColumnModel",
        back_populates="table",
        cascade="all, delete-orphan",
        order_by="ImportedColumnModel.ordinal_position",
    )

    __table_args__ = ({"schema": "pycharter"},)


class ImportedColumnModel(Base):
    """A column within an imported table."""

    __tablename__ = "imported_columns"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    table_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_tables.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name = Column(String(255), nullable=False)
    data_type = Column(String(50), nullable=False, server_default="unknown")
    raw_type = Column(String(255), nullable=True)
    nullable = Column(Boolean, nullable=False, server_default="true")
    is_primary_key = Column(Boolean, nullable=False, server_default="false")
    is_unique = Column(Boolean, nullable=False, server_default="false")
    default_value = Column(String(1000), nullable=True)
    description = Column(Text, nullable=True)
    ordinal_position = Column(Integer, nullable=False, server_default="0")
    max_length = Column(Integer, nullable=True)
    precision = Column(Integer, nullable=True)
    scale = Column(Integer, nullable=True)

    # Mapping state for concept mapping workflow
    mapping_state = Column(String(20), nullable=False, server_default="unmapped")

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    created_by = Column(String(255), nullable=True)

    # Relationships
    table = relationship("ImportedTableModel", back_populates="columns")

    __table_args__ = ({"schema": "pycharter"},)


class ImportedRelationshipModel(Base):
    """A relationship between two imported tables."""

    __tablename__ = "imported_relationships"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    schema_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_schemas.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    source_table_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_tables.id", ondelete="CASCADE"),
        nullable=False,
    )
    target_table_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_tables.id", ondelete="CASCADE"),
        nullable=False,
    )
    source_columns = Column(JSON, nullable=False)
    target_columns = Column(JSON, nullable=False)
    cardinality = Column(String(50), nullable=False, server_default="many_to_one")
    is_declared = Column(Boolean, nullable=False, server_default="true")
    constraint_name = Column(String(255), nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    created_by = Column(String(255), nullable=True)

    # Relationships
    schema = relationship("ImportedSchemaModel", back_populates="relationships_list")

    __table_args__ = ({"schema": "pycharter"},)


class ConceptMappingModel(Base):
    """A mapping between an imported table/column and a concept."""

    __tablename__ = "concept_mappings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    concept_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.concepts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    table_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.imported_tables.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    column_name = Column(String(255), nullable=True)
    mapping_state = Column(String(20), nullable=False, server_default="mapped")
    confidence = Column(Integer, nullable=True)
    created_by = Column(String(255), nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = ({"schema": "pycharter"},)
