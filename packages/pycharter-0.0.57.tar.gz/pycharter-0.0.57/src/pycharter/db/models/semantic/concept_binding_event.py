"""SQLAlchemy model for the ``concept_binding_events`` table.

Append-only audit log of binding lifecycle transitions. One row is
written per call to :meth:`BindingLifecycle.transition`; the table is
queried by :class:`SqlBindingEventStore` to reconstruct current state
and by the ``/semantic/bindings/events`` route to render history.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, Index, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class ConceptBindingEventModel(Base):
    """Binding-lifecycle event row.

    Attributes:
        id: UUID primary key.
        contract_id: Owning contract identifier (e.g. ``"orders:1.0.0"``).
        field_path: Dotted path within the contract.
        concept_id: Concept the field is bound to.
        from_state: Pre-transition lifecycle state.
        to_state: Post-transition lifecycle state.
        actor: User or service that initiated the transition.
        reason: Free-text audit reason.
        created_at: UTC timestamp of the transition.
    """

    __tablename__ = "concept_binding_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(String(255), nullable=False, index=True)
    field_path = Column(String(512), nullable=False)
    concept_id = Column(String(255), nullable=False, index=True)
    from_state = Column(String(32), nullable=False)
    to_state = Column(String(32), nullable=False)
    actor = Column(String(255), nullable=False)
    reason = Column(Text, nullable=False, default="")
    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    __table_args__ = (
        Index(
            "ix_concept_binding_events_key",
            "contract_id",
            "field_path",
            "concept_id",
        ),
        {"schema": "pycharter"},
    )
