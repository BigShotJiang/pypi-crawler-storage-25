"""
SQLAlchemy models for ontology schema configuration tables.

Stores relationship types, concept types, and governance tiers as
database-backed configuration. YAML seed data populates the initial
rows; users can add custom types via the API.
"""

from __future__ import annotations

import uuid

from sqlalchemy import JSON, Boolean, Column, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class RelationshipTypeModel(Base):
    """Configurable relationship type definition."""

    __tablename__ = "relationship_types"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False, unique=True, index=True)
    meaning = Column(Text, nullable=False, default="")
    graph_shape = Column(String(50), nullable=False, default="generic")
    inverse = Column(String(100), nullable=False, default="")
    symmetric = Column(Boolean, nullable=False, default=False)
    predicate = Column(String(255), nullable=True)
    domain_types = Column(JSON, nullable=False, server_default="[]")
    range_types = Column(JSON, nullable=False, server_default="[]")
    is_builtin = Column(Boolean, nullable=False, default=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = ({"schema": "pycharter"},)


class ConceptTypeModel(Base):
    """Configurable concept type definition."""

    __tablename__ = "concept_types"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text, nullable=False, default="")
    is_builtin = Column(Boolean, nullable=False, default=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = ({"schema": "pycharter"},)


class TierModel(Base):
    """Configurable governance tier definition."""

    __tablename__ = "tiers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text, nullable=False, default="")
    is_builtin = Column(Boolean, nullable=False, default=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = ({"schema": "pycharter"},)
