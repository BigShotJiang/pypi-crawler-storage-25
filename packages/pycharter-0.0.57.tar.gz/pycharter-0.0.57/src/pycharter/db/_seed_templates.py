"""Seed ontology templates as concept schemes.

Reads template YAML files from ``data/templates/ontology/`` and creates
a concept scheme per template with its concepts and relationships. This
makes templates available in the editor-v2 scheme picker after seeding.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pycharter.db._seed_utils import set_sqlite_timestamps

logger = logging.getLogger(__name__)

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    yaml = None  # type: ignore[assignment]


def _seed_templates(seed_path: Path, session: Any) -> int:
    """Seed ontology templates as concept schemes.

    Args:
        seed_path: Seed directory (used to resolve the templates dir
            relative to the package root).
        session: SQLAlchemy session.

    Returns:
        Number of templates seeded.
    """
    if yaml is None:
        logger.warning("PyYAML not installed — skipping template seeding")
        return 0

    # Templates live in data/templates/ontology/ (sibling to data/seed/)
    templates_dir = seed_path.parent / "templates" / "ontology"
    if not templates_dir.exists():
        logger.debug("Templates directory not found: %s", templates_dir)
        return 0

    from pycharter.db.models.semantic.concept import ConceptModel
    from pycharter.db.models.semantic.concept_relationship import (
        ConceptRelationshipModel,
    )
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    count = 0
    for yaml_file in sorted(templates_dir.glob("*.yaml")):
        try:
            with open(yaml_file) as f:
                data = yaml.safe_load(f)
        except Exception as exc:
            logger.warning("Failed to read template %s: %s", yaml_file.name, exc)
            continue

        template = data.get("template")
        if not template:
            continue

        template_id = template.get("id", yaml_file.stem)
        template_name = template.get("name", template_id)
        description = template.get("description", "")
        concepts = template.get("concepts", [])
        relationships = template.get("relationships", [])

        # Ensure scheme exists (idempotent by unique scheme_key).
        scheme = (
            session.query(ConceptSchemeModel)
            .filter_by(scheme_key=f"template/{template_id}")
            .first()
        )
        if scheme is None:
            scheme = ConceptSchemeModel(
                scheme_key=f"template/{template_id}",
                title=template_name,
                version="1.0.0",
                description=description,
            )
            set_sqlite_timestamps(session, scheme)
            session.add(scheme)
            session.flush()
        else:
            # Keep template metadata fresh without changing key identity.
            scheme.title = template_name
            scheme.description = description
            set_sqlite_timestamps(session, scheme)

        # Create concepts.
        concept_name_to_id: dict[str, Any] = {}
        for concept_data in concepts:
            name = concept_data.get("name", "")
            if not name:
                continue
            concept_key = name.lower().replace(" ", "_")
            concept = session.query(ConceptModel).filter_by(name=name).first()
            if concept is None:
                concept = (
                    session.query(ConceptModel)
                    .filter_by(concept_key=concept_key)
                    .first()
                )
            if concept is None:
                concept = ConceptModel(
                    concept_key=concept_key,
                    name=name,
                    description=concept_data.get("definition"),
                    concept_type=concept_data.get("concept_type", "entity"),
                    tier="free",
                    scheme_id=scheme.id,
                )
                set_sqlite_timestamps(session, concept)
                session.add(concept)
                session.flush()
            else:
                # Reuse existing global concept names; update metadata conservatively.
                if not concept.concept_key:
                    concept.concept_key = concept_key
                if concept.description is None and concept_data.get("definition"):
                    concept.description = concept_data.get("definition")
                if concept.concept_type is None and concept_data.get("concept_type"):
                    concept.concept_type = concept_data.get("concept_type", "entity")
                if concept.scheme_id is None:
                    concept.scheme_id = scheme.id
                set_sqlite_timestamps(session, concept)
            concept_name_to_id[name] = concept.id

        # Create relationships.
        for rel_data in relationships:
            source_name = rel_data.get("source", "")
            target_name = rel_data.get("target", "")
            source_id = concept_name_to_id.get(source_name)
            target_id = concept_name_to_id.get(target_name)
            if not source_id or not target_id:
                continue
            rel_type = rel_data.get("type", "related_to")
            existing_rel = (
                session.query(ConceptRelationshipModel)
                .filter_by(
                    source_concept_id=source_id,
                    target_concept_id=target_id,
                    relationship_type=rel_type,
                )
                .first()
            )
            if existing_rel:
                continue
            rel = ConceptRelationshipModel(
                source_concept_id=source_id,
                target_concept_id=target_id,
                relationship_type=rel_type,
                scheme_id=scheme.id,
            )
            set_sqlite_timestamps(session, rel)
            session.add(rel)

        session.commit()
        count += 1
        logger.debug(
            "Seeded template scheme: %s (%d concepts)", template_id, len(concepts)
        )

    if count > 0:
        logger.info("Seeded %d template scheme(s)", count)
    return count
