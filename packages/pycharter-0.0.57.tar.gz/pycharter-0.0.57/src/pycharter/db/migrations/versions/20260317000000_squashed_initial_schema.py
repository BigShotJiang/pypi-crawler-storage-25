"""Squashed schema (single migration).

Revision ID: squashed_root
Revises: None
Create Date: 2026-03-17 00:00:00

Single migration that creates the full current schema from SQLAlchemy models via
``Base.metadata.create_all()`` after ensuring the ``pycharter`` schema exists
(PostgreSQL). ``create_all()`` skips tables that already exist.

Post-steps (formerly separate revisions, now inlined):

- Add ``data_contracts.revision`` if missing (``create_all`` does not ALTER).
- Rename legacy ``etl_pipeline_configs`` → ``pipeline_configs`` when needed.

**Operators:** If your database was stamped at an old revision id that was removed
during a squash, run ``pycharter db stamp squashed_root`` once the live schema
matches this package (then ``pycharter db upgrade`` is a no-op at head).

"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect, text

from pycharter.db.migrations.schema_helper import get_schema

# revision identifiers, used by Alembic.
revision: str = "squashed_root"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_PG_SCHEMA = "pycharter"
_DC_TABLE = "data_contracts"
_DC_COLUMN = "revision"

_OLD_ETL_TABLE = "etl_pipeline_configs"
_NEW_PIPELINE_TABLE = "pipeline_configs"
_OLD_ETL_UQ = "uq_etl_pipeline_configs_name_version"
_NEW_PIPELINE_UQ = "uq_pipeline_configs_name_version"


def _contract_schema(bind) -> str | None:
    url = str(bind.engine.url)
    return None if "sqlite" in url else _PG_SCHEMA


def _ensure_data_contracts_revision_column(bind) -> None:
    """Add data_contracts.revision if missing (idempotent)."""
    schema = _contract_schema(bind)
    insp = inspect(bind)
    cols = {c["name"] for c in insp.get_columns(_DC_TABLE, schema=schema)}
    if _DC_COLUMN in cols:
        return
    op.add_column(
        _DC_TABLE,
        sa.Column(
            _DC_COLUMN,
            sa.Integer(),
            nullable=False,
            server_default=sa.text("1"),
        ),
        schema=schema,
    )


def _maybe_rename_etl_pipeline_configs(bind) -> None:
    """Rename legacy etl_pipeline_configs → pipeline_configs if needed (idempotent)."""
    url = str(bind.engine.url)
    schema = None if "sqlite" in url else _PG_SCHEMA
    insp = inspect(bind)
    tables = (
        set(insp.get_table_names(schema=schema))
        if schema
        else set(insp.get_table_names())
    )

    if _NEW_PIPELINE_TABLE in tables:
        return
    if _OLD_ETL_TABLE not in tables:
        raise RuntimeError(
            f"Alembic squashed_root: expected '{_NEW_PIPELINE_TABLE}' after "
            f"create_all, or legacy '{_OLD_ETL_TABLE}' to rename; found neither."
        )

    op.rename_table(_OLD_ETL_TABLE, _NEW_PIPELINE_TABLE, schema=schema)

    if "sqlite" not in url:
        qual_new = f'"{schema}"."{_NEW_PIPELINE_TABLE}"'
        bind.execute(
            text(
                f'ALTER TABLE {qual_new} RENAME CONSTRAINT "{_OLD_ETL_UQ}" TO "{_NEW_PIPELINE_UQ}"'
            )
        )


def upgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    # PostgreSQL: create schema first
    if schema:
        bind.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))

    # Import all models so Base.metadata has every table (main + semantic)
    import pycharter.db.models  # noqa: F401
    import pycharter.db.models.semantic  # noqa: F401
    from pycharter.db.models.base import Base

    # SQLite: tables must not have schema="pycharter" or create_all will fail
    if schema is None:
        for table in Base.metadata.tables.values():
            if table.schema == "pycharter":
                table.schema = None

    Base.metadata.create_all(bind)

    _ensure_data_contracts_revision_column(bind)
    _maybe_rename_etl_pipeline_configs(bind)


def downgrade() -> None:
    import pycharter.db.models  # noqa: F401
    import pycharter.db.models.semantic  # noqa: F401
    from pycharter.db.models.base import Base

    bind = op.get_bind()
    schema = get_schema(bind)

    if schema is None:
        for table in Base.metadata.tables.values():
            if table.schema == "pycharter":
                table.schema = None

    Base.metadata.drop_all(bind)

    # PostgreSQL: drop schema
    if schema:
        bind.execute(text(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE'))
