"""concept_binding_events table.

Revision ID: concept_binding_events
Revises: squashed_root
Create Date: 2026-04-16 00:00:00

Adds the ``concept_binding_events`` table — an append-only audit log of
binding lifecycle transitions (``UNMAPPED → SUGGESTED → MAPPED →
APPROVED``) emitted by
:class:`pycharter.semantic.lifecycle.BindingLifecycle` when a persistent
:class:`SqlBindingEventStore` is bound to the service.
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op

from pycharter.db.migrations.schema_helper import get_schema

# revision identifiers, used by Alembic.
revision: str = "concept_binding_events"
down_revision: str | None = "squashed_root"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

_TABLE = "concept_binding_events"


def upgrade() -> None:
    """Create the concept_binding_events table + supporting index.

    Uses the SQLAlchemy model's metadata so the column types match the
    ORM and the same DDL works for both SQLite and PostgreSQL dialects.
    """
    bind = op.get_bind()
    schema = get_schema(bind)

    # Import the model so its table is registered on Base.metadata.
    from pycharter.db.models.semantic.concept_binding_event import (
        ConceptBindingEventModel,
    )

    table = ConceptBindingEventModel.__table__
    # SQLite cannot address the ``pycharter`` schema — strip it on that
    # dialect so create() emits a plain CREATE TABLE.
    original_schema = table.schema
    try:
        if schema is None:
            table.schema = None
        table.create(bind, checkfirst=True)
    finally:
        table.schema = original_schema


def downgrade() -> None:
    """Drop the concept_binding_events table."""
    bind = op.get_bind()
    schema = get_schema(bind)

    from pycharter.db.models.semantic.concept_binding_event import (
        ConceptBindingEventModel,
    )

    table = ConceptBindingEventModel.__table__
    original_schema = table.schema
    try:
        if schema is None:
            table.schema = None
        table.drop(bind, checkfirst=True)
    finally:
        table.schema = original_schema
