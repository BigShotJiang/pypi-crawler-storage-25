"""concept + concept_relationship provenance columns.

Revision ID: concept_provenance
Revises: concept_binding_events
Create Date: 2026-04-18 00:00:00

Adds ``origin`` (String(32), non-null, default ``"unknown"``) and
``provenance`` (JSON, nullable) columns to the ``concepts`` and
``concept_relationships`` tables. Pre-existing rows are backfilled to
``origin = "unknown"`` per the principle of being honest about data
whose lineage we did not capture at creation time. New rows written
through the ORM supply an explicit :class:`Origin` value.
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

from pycharter.db.migrations.schema_helper import get_schema

revision: str = "concept_provenance"
down_revision: str | None = "concept_binding_events"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Add origin + provenance columns to concepts and concept_relationships."""
    bind = op.get_bind()
    schema = get_schema(bind)

    op.add_column(
        "concepts",
        sa.Column(
            "origin",
            sa.String(length=32),
            nullable=False,
            server_default="unknown",
        ),
        schema=schema,
    )
    op.add_column(
        "concepts",
        sa.Column("provenance", sa.JSON(), nullable=True),
        schema=schema,
    )
    op.add_column(
        "concept_relationships",
        sa.Column(
            "origin",
            sa.String(length=32),
            nullable=False,
            server_default="unknown",
        ),
        schema=schema,
    )
    op.add_column(
        "concept_relationships",
        sa.Column("provenance", sa.JSON(), nullable=True),
        schema=schema,
    )


def downgrade() -> None:
    """Drop origin + provenance columns from concepts and concept_relationships."""
    bind = op.get_bind()
    schema = get_schema(bind)

    op.drop_column("concept_relationships", "provenance", schema=schema)
    op.drop_column("concept_relationships", "origin", schema=schema)
    op.drop_column("concepts", "provenance", schema=schema)
    op.drop_column("concepts", "origin", schema=schema)
