"""Contract artifact seeding: contracts, schemas, coercion/validation rules, metadata, field mappings."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from pycharter.db._seed_utils import seed_model, set_sqlite_timestamps
from pycharter.db.models import (
    CoercionRuleModel,
    DataContractModel,
    FieldMappingModel,
    MetadataRecordModel,
    SchemaModel,
    ValidationRuleModel,
)

logger = logging.getLogger(__name__)


def _seed_contracts_only(
    seed_path: Path, session: Any
) -> dict[tuple[str, str], int | None]:
    """Seed data_contracts from contracts.yaml. Returns (name, version) -> data_contract_id."""
    contracts_file = seed_path / "contracts.yaml"
    if not contracts_file.exists():
        logger.warning("No contracts.yaml found, skipping contract artifacts")
        return {}
    with open(contracts_file) as f:
        contracts = yaml.safe_load(f) or []
    if not contracts:
        return {}
    logger.info("Loading contracts...")
    lookup: dict[tuple[str, str], int | None] = {}
    for entry in contracts:
        name = entry.get("name")
        version = entry.get("version")
        if not name or not version:
            logger.warning("Skipping contract entry missing name or version")
            continue
        existing = (
            session.query(DataContractModel)
            .filter(
                DataContractModel.name == name,
                DataContractModel.version == version,
            )
            .first()
        )
        if existing:
            logger.debug("Skipped (exists): %s@%s", name, version)
            lookup[(name, version)] = existing.id
            continue
        contract = DataContractModel(
            name=name,
            version=version,
            status=entry.get("status") or "active",
            description=entry.get("description"),
        )
        set_sqlite_timestamps(session, contract)
        session.add(contract)
        session.flush()
        lookup[(name, version)] = contract.id
        logger.debug("Created contract: %s@%s", name, version)
    session.commit()
    if lookup:
        logger.info("Loaded %d contract(s)", len(lookup))
    return lookup


def _transform_schema(
    record: dict, contract_lookup: dict[tuple[str, str], int | None]
) -> dict | None:
    """Resolve contract ref and build SchemaModel kwargs with schema_data."""
    name = record.get("contract_name")
    version = record.get("contract_version")
    if not name or not version:
        return None
    key = (name, version)
    if key not in contract_lookup:
        return None
    data_contract_id = contract_lookup[key]
    title = record.get("title") or f"{name}_schema"
    version_val = record.get("version") or version
    schema_data = {
        k: v
        for k, v in record.items()
        if k not in ("contract_name", "contract_version")
    }
    schema_data.setdefault("title", title)
    schema_data.setdefault("version", version_val)
    return {
        "title": title,
        "data_contract_id": data_contract_id,
        "version": version_val,
        "schema_data": schema_data,
    }


def _build_contract_artifact_lookup(
    session: Any, contract_lookup: dict[tuple[str, str], int | None]
) -> dict[tuple[str, str], tuple[int, int | None]]:
    """Build (name, version) -> (data_contract_id, schema_id) after schemas are seeded."""
    full: dict[tuple[str, str], tuple[int, int | None]] = {}
    for (name, version), data_contract_id in contract_lookup.items():
        schema_row = (
            session.query(SchemaModel)
            .filter_by(data_contract_id=data_contract_id)
            .first()
        )
        schema_id = schema_row.id if schema_row else None
        full[(name, version)] = (data_contract_id, schema_id)
    return full


def _transform_artifact(
    record: dict,
    contract_lookup: dict[tuple[str, str], tuple[int, int | None]],
    include_schema_id: bool = False,
) -> dict | None:
    """Resolve contract ref to data_contract_id (and schema_id). Drop ref keys; return None if not found."""
    name = record.get("contract_name")
    version = record.get("contract_version")
    if not name or not version:
        return None
    key = (name, version)
    if key not in contract_lookup:
        return None
    data_contract_id, schema_id = contract_lookup[key]
    out = {
        k: v
        for k, v in record.items()
        if k not in ("contract_name", "contract_version")
    }
    out["data_contract_id"] = data_contract_id
    if include_schema_id:
        out["schema_id"] = schema_id
    return out

    # Metadata-specific seeding lives in _seed_metadata module


def seed_contract_artifacts(seed_path: Path, session: Any) -> int:
    """
    Seed contracts -> schemas -> link schema_id on contracts -> coercion/validation/metadata -> link FKs on contracts.

    Returns number of contracts seeded.
    """
    contract_lookup = _seed_contracts_only(seed_path, session)
    if not contract_lookup:
        return 0
    id_fields = ["data_contract_id", "title"]
    seed_model(
        session,
        SchemaModel,
        seed_path / "schemas.yaml",
        "schemas",
        id_field="title",
        id_fields=id_fields,
        transform_fn=lambda r: _transform_schema(r, contract_lookup),
    )
    for (name, version), data_contract_id in contract_lookup.items():
        contract = (
            session.query(DataContractModel)
            .filter_by(name=name, version=version)
            .first()
        )
        if not contract or contract.schema_id:
            continue
        schema_row = (
            session.query(SchemaModel)
            .filter_by(data_contract_id=data_contract_id)
            .first()
        )
        if schema_row:
            contract.schema_id = schema_row.id
    session.commit()
    full_lookup = _build_contract_artifact_lookup(session, contract_lookup)
    seed_model(
        session,
        CoercionRuleModel,
        seed_path / "coercion_rules.yaml",
        "coercion_rules",
        id_field="title",
        id_fields=id_fields,
        transform_fn=lambda r: _transform_artifact(
            r, full_lookup, include_schema_id=True
        ),
    )
    seed_model(
        session,
        ValidationRuleModel,
        seed_path / "validation_rules.yaml",
        "validation_rules",
        id_field="title",
        id_fields=id_fields,
        transform_fn=lambda r: _transform_artifact(
            r, full_lookup, include_schema_id=True
        ),
    )
    # Metadata: normalize to canonical, store payload, then sync relationships
    from pycharter.db._seed_metadata import seed_metadata_records

    seed_metadata_records(
        seed_path,
        session,
        full_lookup,
        id_fields,
        transform_artifact_fn=_transform_artifact,
        set_sqlite_timestamps_fn=set_sqlite_timestamps,
    )
    for (name, version), (data_contract_id, _schema_id) in full_lookup.items():
        contract = (
            session.query(DataContractModel)
            .filter_by(name=name, version=version)
            .first()
        )
        if not contract or contract.coercion_rules_id:
            continue
        cr = (
            session.query(CoercionRuleModel)
            .filter_by(data_contract_id=data_contract_id)
            .first()
        )
        vr = (
            session.query(ValidationRuleModel)
            .filter_by(data_contract_id=data_contract_id)
            .first()
        )
        meta = (
            session.query(MetadataRecordModel)
            .filter_by(data_contract_id=data_contract_id)
            .first()
        )
        if cr:
            contract.coercion_rules_id = cr.id
        if vr:
            contract.validation_rules_id = vr.id
        if meta:
            contract.metadata_record_id = meta.id
    session.commit()

    _seed_field_mappings(seed_path, session, full_lookup)
    return len(contract_lookup)


def _seed_field_mappings(
    seed_path: Path,
    session: Any,
    full_lookup: dict[tuple[str, str], tuple[Any, int | None]],
) -> int:
    """
    Seed field mapping (ontology) artifacts from ontology_mappings.yaml and
    link them to data contracts via field_mapping_id. Works for both SQLite and
    PostgreSQL so seeded contracts have ontology data.
    """
    mappings_file = seed_path / "ontology_mappings.yaml"
    if not mappings_file.exists():
        logger.warning("No ontology_mappings.yaml found, skipping field mappings")
        return 0
    with open(mappings_file) as f:
        data = yaml.safe_load(f) or []
    if not data:
        return 0
    logger.info("Loading field mappings (ontology)...")
    count = 0
    for record in data:
        contract_name = record.get("contract_name")
        contract_version = record.get("contract_version")
        if not contract_name or not contract_version:
            logger.warning(
                "Skipping ontology_mappings entry missing contract_name or contract_version"
            )
            continue
        key = (contract_name, contract_version)
        if key not in full_lookup:
            logger.debug(
                "Skipping field mapping for unknown contract: %s@%s",
                contract_name,
                contract_version,
            )
            continue
        data_contract_id, _schema_id = full_lookup[key]
        mapping_data = {
            k: v
            for k, v in record.items()
            if k not in ("contract_name", "contract_version")
        }
        if not mapping_data:
            continue
        mapping_data.setdefault("version", contract_version)
        title = f"{contract_name}_field_mapping"
        existing = (
            session.query(FieldMappingModel)
            .filter_by(
                title=title,
                version=contract_version,
            )
            .first()
        )
        if existing:
            if not existing.data_contract_id or str(existing.data_contract_id) != str(
                data_contract_id
            ):
                existing.data_contract_id = data_contract_id
            existing.mapping_data = mapping_data
            set_sqlite_timestamps(session, existing)
            mapping_obj = existing
            logger.debug(
                "Updated field mapping: %s@%s", contract_name, contract_version
            )
        else:
            mapping_obj = FieldMappingModel(
                title=title,
                data_contract_id=data_contract_id,
                version=contract_version,
                mapping_data=mapping_data,
            )
            set_sqlite_timestamps(session, mapping_obj)
            session.add(mapping_obj)
            session.flush()
            logger.debug(
                "Created field mapping: %s@%s", contract_name, contract_version
            )
        contract = (
            session.query(DataContractModel)
            .filter_by(name=contract_name, version=contract_version)
            .first()
        )
        if contract:
            contract.field_mapping_id = mapping_obj.id
        count += 1
    session.commit()
    if count:
        logger.info("Loaded %d field mapping(s) (ontology)", count)
    return count
