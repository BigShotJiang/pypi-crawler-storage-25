"""Shared seeding utilities: YAML-to-model upsert and timestamp helpers."""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    yaml = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


def utc_now() -> datetime:
    """Return the current UTC datetime."""
    return datetime.now(UTC)


def set_sqlite_timestamps(session: Any, instance: Any) -> None:
    """Set created_at/updated_at on instance when using SQLite."""
    try:
        bind = session.get_bind()
        dialect = getattr(bind, "dialect", None)
        if dialect is None or dialect.name != "sqlite":
            return
    except Exception:
        return
    now = utc_now()
    if hasattr(instance, "created_at"):
        instance.created_at = now
    if hasattr(instance, "updated_at"):
        instance.updated_at = now


def seed_model(
    session: Any,
    model_class: type,
    seed_file: Path,
    model_name: str,
    id_field: str = "id",
    id_fields: list[str] | None = None,
    transform_fn: Callable[[dict], dict | None] | None = None,
) -> int:
    """Load a YAML file and upsert rows into the given model.

    Args:
        session: SQLAlchemy session.
        model_class: The model class to upsert into.
        seed_file: Path to the YAML file.
        model_name: Human label for log messages.
        id_field: Primary key field name (default "id").
        id_fields: Composite key fields (overrides id_field).
        transform_fn: Optional transform applied to each YAML dict
            before upsert. Return None to skip the row.

    Returns:
        Number of rows processed.
    """
    if yaml is None:
        logger.warning("PyYAML not installed — skipping %s", model_name)
        return 0
    if not seed_file.exists():
        logger.warning("No %s file found, skipping %s", seed_file.name, model_name)
        return 0
    logger.info("Loading %s...", model_name)
    with open(seed_file) as f:
        data = yaml.safe_load(f) or []
    count = 0
    for item_data in data:
        if transform_fn:
            item_data = transform_fn(item_data)
            if item_data is None:
                continue
        keys = id_fields if id_fields is not None else [id_field]
        item_id = (
            item_data.get(id_field)
            if len(keys) == 1
            else tuple(item_data.get(k) for k in keys)
        )
        if item_id is None or (isinstance(item_id, tuple) and None in item_id):
            logger.warning(
                "Skipping %s entry missing key field(s): %s", model_name, keys
            )
            continue
        filter_kw = {k: item_data[k] for k in keys if k in item_data}
        existing = session.query(model_class).filter_by(**filter_kw).first()
        if existing:
            for key, value in item_data.items():
                if hasattr(existing, key):
                    setattr(existing, key, value)
            set_sqlite_timestamps(session, existing)
            logger.debug("Updated %s: %s", model_name, item_id)
        else:
            item = model_class(**item_data)
            set_sqlite_timestamps(session, item)
            session.add(item)
            logger.debug("Created %s: %s", model_name, item_id)
        count += 1
    session.commit()
    logger.info("Loaded %d %s(s)", count, model_name)
    return count
