# Data Contract Templates

Templates for creating data contracts with schema, coercion rules, validation rules, metadata, and semantic annotations.

## Quick Start

```python
from pycharter import parse_contract, validate_with_contract

# Option 1: Complete contract in one file
contract = {
    "schema": {
        "type": "object",
        "properties": {
            "order_id": {"type": "string", "format": "uuid"},
            "symbol": {"type": "string", "pattern": "^[A-Z]{1,5}$"},
        },
        "required": ["order_id", "symbol"]
    },
    "metadata": {"version": "1.0.0"},
    "ownership": {"owner": "quant-desk"}
}

# Validate data
result = validate_with_contract(contract, {"order_id": "abc-123", "symbol": "AAPL"})
print(f"Valid: {result.is_valid}")
```

## Template Files

| Template | Description |
|----------|-------------|
| `template_contract.yaml` | Complete contract (schema + rules + metadata + lifecycle + ontology) |
| `template_schema.yaml` | JSON Schema with PyCharter extensions |
| `template_coercion_rules.yaml` | Data type transformation rules (all 21 functions) |
| `template_validation_rules.yaml` | Business validation rules (all 16 rules) |
| `template_metadata.yaml` | Ownership, governance, lifecycle, data quality |
| `template_ontology.yaml` | Semantic field annotations (concept mappings) |

Seed data for contracts is in `pycharter/data/seed/` (contracts, schemas, metadata, coercion, validation, ontologies). Run `pycharter db seed` to load.

## Contract Structure

```yaml
# Complete contract structure (parse_contract / create-mixed compatible)
schema:
  type: object
  title: intraday_trade_order
  version: "1.0.0"
  additionalProperties: false
  properties:
    field_name:
      type: string
      pattern: "^[A-Z]{1,5}$"          # Regex constraint
      coercion: coerce_to_string        # PyCharter: inline coercion
      validations:                       # PyCharter: inline validation
        max_length: {threshold: 100}

coercion_rules:
  version: "1.0.0"
  rules:
    field_name: coerce_to_string

validation_rules:
  version: "1.0.0"
  rules:
    field_name: {max_length: {threshold: 100}}

metadata:
  version: "1.0.0"
  description: "Contract description"
  ownership:
    business_owners: [quant-desk]
    bu_sme: [portfolio-management]
    it_application_owners: [data-engineering]
    it_sme: [risk-team]
    support_lead: [compliance-ops]
    contract_owners: [data-engineering]
  lifecycle:
    state_machine_name: order_lifecycle
    state_field: status
    entity_id_field: order_id
  governance_rules:
    data_retention: {days: 2555, reason: "MiFID II compliance"}
    pii_fields: {fields: [trader_id, account_id]}
    sensitivity: confidential
    access_control: {read: [quant-desk], write: [data-engineering]}
    business_rules:
      rule_name: {description: "Rule description", enforced: true}
    indexes:
      - {columns: [order_id], unique: true}
    dependencies: [Instrument, Trader, Account]
    data_feed_association: [order-blotter]
  data_quality:
    accuracy: 0.997
    monitoring_enabled: true
    sla:
      min_overall_score: 95.0
      max_violation_rate: 0.05
      min_completeness: 0.95
      min_accuracy: 0.95
    total_records: 18420000

ontology:
  version: "1.0.0"
  fields:
    order_id:
      concept: OrderIdentifier
      tags: [critical, identifier]
      lineage: {source_system: oms}
      relationships:
        - {target: market_data_tick.tick_id, type: related_to}

versions:
  schema: "1.0.0"
  coercion_rules: "1.0.0"
  validation_rules: "1.0.0"
  metadata: "1.0.0"
  ontology: "1.0.0"
```

## Coercion Rules

Applied BEFORE Pydantic validation to transform input data:

### Standard Type Converters

| Rule | Description |
|------|-------------|
| `coerce_to_string` | Convert to string |
| `coerce_to_integer` | Convert to int (handles "123", 123.0, bool) |
| `coerce_to_float` | Convert to float |
| `coerce_to_boolean` | Convert to bool ("true"/"false", 0/1) |
| `coerce_to_datetime` | Parse datetime strings (ISO format) |
| `coerce_to_date` | Parse date strings |
| `coerce_to_uuid` | Parse UUID strings |

### String Manipulators

| Rule | Description |
|------|-------------|
| `coerce_to_lowercase` | Convert string to lowercase |
| `coerce_to_uppercase` | Convert string to uppercase |
| `coerce_to_stripped_string` | Trim leading/trailing whitespace |

### Special Coercions

| Rule | Description |
|------|-------------|
| `coerce_to_list` | Wrap single value in a list |
| `coerce_to_json` | Parse JSON string to object |
| `coerce_empty_to_null` | Convert empty string `""` to `None` |
| `coerce_to_none` | Always return `None` |

### Nullable Variants (preserve `None`)

| Rule | Description |
|------|-------------|
| `coerce_to_nullable_string` | Convert to string, preserve None |
| `coerce_to_nullable_integer` | Convert to int, preserve None |
| `coerce_to_nullable_float` | Convert to float, preserve None |
| `coerce_to_nullable_boolean` | Convert to bool, preserve None |
| `coerce_to_nullable_datetime` | Parse datetime, preserve None |
| `coerce_to_nullable_uuid` | Parse UUID, preserve None |
| `coerce_to_nullable_json` | Parse JSON, preserve None |

## Validation Rules

Applied AFTER Pydantic validation for business rules:

| Rule | Parameters | Description |
|------|------------|-------------|
| `non_empty_string` | `null` | String must not be empty after stripping |
| `min_length` | `{threshold: N}` | Minimum string length or item count |
| `max_length` | `{threshold: N}` | Maximum string length or item count |
| `greater_than_or_equal_to` | `{threshold: N}` | Minimum numeric value |
| `less_than_or_equal_to` | `{threshold: N}` | Maximum numeric value |
| `only_allow` | `{allowed_values: [...]}` | Value must be in the list |
| `only_allow_if` | `{condition_field, condition_value, allowed_values}` | Conditional enum |
| `is_positive` | `null` | Numeric value must be > 0 |
| `is_email` | `null` | Must be a valid email address |
| `is_url` | `null` | Must be a valid URL (http/https) |
| `is_alphanumeric` | `null` | Only letters and digits |
| `is_numeric_string` | `null` | String must represent a number |
| `no_capital_characters` | `null` | No uppercase letters |
| `no_special_characters` | `null` | Only alphanumeric and spaces |
| `matches_regex` | `{pattern: "..."}` | Match a regular expression |
| `is_unique` | `null` | All items in a list must be unique |

## Ontology (Semantic Field Annotations)

Maps physical schema fields to concepts in the concept registry (`ontologies.yaml`). Use under `ontology:` in a full contract or as a standalone file (`template_ontology.yaml`).

### Annotation Keys

| Key | Description |
|-----|-------------|
| `version` | Annotation version (e.g. `"1.0.0"`) |
| `fields` | Map of field name → annotation object |

### Per-Field Annotation

| Key | Description |
|-----|-------------|
| `concept` | Concept ID from the concept registry (required) |
| `tags` | Field-level tags (e.g. `[critical, pii, identifier]`) |
| `lineage` | `{derived_from?, source_system?}` — data provenance |
| `relationships` | Cross-contract field references (list of `{target, type}`) |

### Field-Level Relationship Types

| Type | Description |
|------|-------------|
| `references` | Foreign-key style pointer to another contract's field |
| `derived_from` | This field is computed from another field |
| `same_as` | Same real-world concept as another field |
| `related_to` | Loosely associated with another field |

### Concept-Level Relationship Types (in `ontology_schema.yaml`)

`is_a`, `has`, `depends_on`, `derived_from`, `precedes`, `causes`, `implements`, `governs`, `describes`, `equivalent_to`, `related_to`, `references`, `same_as`

## Usage Patterns

### 1. Validate with Contract

```python
from pycharter import validate_with_contract

result = validate_with_contract(
    "path/to/contract.yaml",  # or dict
    {"order_id": "abc-123", "symbol": "AAPL", "side": "buy", "quantity": 100}
)

if result.is_valid:
    print(f"Data: {result.data}")
else:
    print(f"Errors: {result.errors}")
```

### 2. Build Contract from Artifacts

```python
from pycharter import build_contract

contract = build_contract(
    schema=schema_dict,
    metadata=metadata_dict,
    coercion_rules=coercion_dict,
    validation_rules=validation_dict,
)
```

### 3. Quality Check

```python
from pycharter import QualityCheck

report = QualityCheck().run(
    contract=contract,
    data=records
)
print(f"Score: {report.quality_score.overall_score}/100")
```

## Examples

See the PyCharter documentation **tutorials** and **Examples & Notebooks** for working examples.
