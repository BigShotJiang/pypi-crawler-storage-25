"""PostgreSQL/SQLite-backed dead letter store.

Supports both PostgreSQL (JSONB columns) and SQLite (JSON as TEXT) via
dialect detection at connection time.  The table is created on first use
if it does not exist.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import threading
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from pycharter.dlq._types import (
    DeadLetterRecord,
    DLQStatistics,
    DLQStatus,
    QueryResult,
)

logger = logging.getLogger(__name__)

_TABLE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

DEFAULT_TABLE_NAME = "dead_letter_queue"


def _validate_identifier(name: str) -> str:
    """Return *name* if it is a safe SQL identifier fragment.

    Args:
        name: Candidate identifier.

    Returns:
        The validated name.

    Raises:
        ValueError: If *name* contains unsafe characters.
    """
    if not name or not _TABLE_RE.match(name):
        raise ValueError(
            f"Invalid SQL identifier: {name!r} (use letters, digits, underscore only)"
        )
    return name


def validate_table_name(name: str) -> str:
    """Return *name* if it is a safe table identifier (API / tooling)."""
    return _validate_identifier(name)


def _quote_ident(name: str) -> str:
    """Double-quote a validated SQL identifier."""
    _validate_identifier(name)
    return f'"{name}"'


class DatabaseDeadLetterStore:
    """Persist dead letter records to a relational database.

    Supports PostgreSQL and SQLite.  The dialect is detected from the
    connection URL and the SQL adapts accordingly (e.g. JSONB vs TEXT for
    JSON columns).

    Args:
        database_url: SQLAlchemy connection URL.
        table_name: Name of the DLQ table (must be a safe identifier).
        schema_name: Optional PostgreSQL schema name.
    """

    def __init__(
        self,
        database_url: str,
        table_name: str = DEFAULT_TABLE_NAME,
        schema_name: str | None = None,
        on_add: Any | None = None,
    ) -> None:
        self._table = _validate_identifier(table_name)
        self._schema = schema_name
        self._engine: Engine = create_engine(database_url, pool_pre_ping=True)
        self._schema_lock = threading.Lock()
        self._ensure_schema_done = False
        self._on_add = on_add

    # ------------------------------------------------------------------
    # Schema management
    # ------------------------------------------------------------------

    @property
    def _qualified_table(self) -> str:
        """Return the optionally schema-qualified, quoted table name."""
        t = _quote_ident(self._table)
        if self._schema:
            return f"{_quote_ident(self._schema)}.{t}"
        return t

    @property
    def _dialect(self) -> str:
        return self._engine.dialect.name

    def _ensure_schema_sync(self) -> None:
        """Create the DLQ table if it does not exist (idempotent)."""
        with self._schema_lock:
            if self._ensure_schema_done:
                return
            t = self._qualified_table
            if self._dialect == "postgresql":
                ddl = f"""
                CREATE TABLE IF NOT EXISTS {t} (
                    record_id TEXT PRIMARY KEY,
                    source_name TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    error_message TEXT NOT NULL DEFAULT '',
                    error_type TEXT NOT NULL DEFAULT '',
                    stage TEXT NOT NULL DEFAULT '',
                    payload JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                    metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                    attempt INTEGER NOT NULL DEFAULT 1,
                    max_attempts INTEGER NOT NULL DEFAULT 5,
                    status TEXT NOT NULL DEFAULT 'pending',
                    retry_count INTEGER NOT NULL DEFAULT 0,
                    created_at TIMESTAMPTZ NOT NULL,
                    updated_at TIMESTAMPTZ,
                    expires_at TIMESTAMPTZ
                )
                """
            else:
                ddl = f"""
                CREATE TABLE IF NOT EXISTS {t} (
                    record_id TEXT PRIMARY KEY,
                    source_name TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    error_message TEXT NOT NULL DEFAULT '',
                    error_type TEXT NOT NULL DEFAULT '',
                    stage TEXT NOT NULL DEFAULT '',
                    payload TEXT NOT NULL DEFAULT '{{}}',
                    metadata TEXT NOT NULL DEFAULT '{{}}',
                    attempt INTEGER NOT NULL DEFAULT 1,
                    max_attempts INTEGER NOT NULL DEFAULT 5,
                    status TEXT NOT NULL DEFAULT 'pending',
                    retry_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT,
                    expires_at TEXT
                )
                """
            with self._engine.connect() as conn:
                conn.execute(text(ddl))
                # Create indexes for common query patterns
                for col in (
                    "source_name",
                    "reason",
                    "status",
                    "stage",
                    "created_at",
                    "expires_at",
                ):
                    idx_name = f"ix_{self._table}_{col}"
                    conn.execute(
                        text(
                            f"CREATE INDEX IF NOT EXISTS {_quote_ident(idx_name)} "
                            f"ON {t} ({_quote_ident(col)})"
                        )
                    )
                conn.commit()
            self._ensure_schema_done = True

    # ------------------------------------------------------------------
    # Row conversion helpers
    # ------------------------------------------------------------------

    def _parse_json(self, raw: Any) -> dict[str, Any]:
        """Parse a JSON column value (JSONB dict or TEXT string)."""
        if isinstance(raw, str):
            return json.loads(raw) if raw else {}
        if raw is None:
            return {}
        return dict(raw)

    def _parse_datetime(self, raw: Any) -> datetime:
        """Parse a datetime column value (datetime or ISO string)."""
        if isinstance(raw, str):
            return datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if raw is None:
            return datetime.now(UTC)
        dt: datetime = raw
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt

    def _parse_optional_datetime(self, raw: Any) -> datetime | None:
        """Parse an optional datetime column value."""
        if raw is None:
            return None
        return self._parse_datetime(raw)

    def _row_to_record(self, row: Any) -> DeadLetterRecord:
        """Convert a database row mapping to a DeadLetterRecord."""
        try:
            status = DLQStatus(row["status"])
        except (ValueError, KeyError):
            status = DLQStatus.PENDING
        return DeadLetterRecord(
            record_id=row["record_id"],
            source_name=row["source_name"],
            reason=row["reason"],
            error_message=row["error_message"] or "",
            error_type=row["error_type"] or "",
            stage=row["stage"] or "",
            payload=self._parse_json(row["payload"]),
            metadata=self._parse_json(row["metadata"]),
            attempt=int(row["attempt"]),
            max_attempts=int(row["max_attempts"]),
            status=status,
            retry_count=int(row["retry_count"]),
            created_at=self._parse_datetime(row["created_at"]),
            updated_at=self._parse_optional_datetime(row["updated_at"]),
            expires_at=self._parse_optional_datetime(row["expires_at"]),
        )

    def _record_to_params(self, record: DeadLetterRecord) -> dict[str, Any]:
        """Build the parameter dict for an INSERT statement."""
        created = record.created_at
        if created.tzinfo is None:
            created = created.replace(tzinfo=UTC)
        params: dict[str, Any] = {
            "record_id": record.record_id,
            "source_name": record.source_name,
            "reason": record.reason,
            "error_message": record.error_message,
            "error_type": record.error_type,
            "stage": record.stage,
            "payload": json.dumps(record.payload),
            "metadata": json.dumps(record.metadata),
            "attempt": record.attempt,
            "max_attempts": record.max_attempts,
            "status": str(record.status),
            "retry_count": record.retry_count,
            "created_at": created
            if self._dialect == "postgresql"
            else created.isoformat(),
            "updated_at": self._format_optional_dt(record.updated_at),
            "expires_at": self._format_optional_dt(record.expires_at),
        }
        return params

    def _format_optional_dt(self, dt: datetime | None) -> Any:
        """Format an optional datetime for the current dialect."""
        if dt is None:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        if self._dialect != "postgresql":
            return dt.isoformat()
        return dt

    # ------------------------------------------------------------------
    # Core CRUD
    # ------------------------------------------------------------------

    def _add_sync(self, record: DeadLetterRecord) -> None:
        self._ensure_schema_sync()
        t = self._qualified_table
        params = self._record_to_params(record)
        if self._dialect == "postgresql":
            sql = text(f"""
                INSERT INTO {t} (
                    record_id, source_name, reason, error_message, error_type,
                    stage, payload, metadata, attempt, max_attempts,
                    status, retry_count, created_at, updated_at, expires_at
                ) VALUES (
                    :record_id, :source_name, :reason, :error_message, :error_type,
                    :stage, CAST(:payload AS jsonb), CAST(:metadata AS jsonb),
                    :attempt, :max_attempts, :status, :retry_count,
                    :created_at, :updated_at, :expires_at
                )
                ON CONFLICT (record_id) DO NOTHING
            """)
        else:
            sql = text(f"""
                INSERT OR IGNORE INTO {t} (
                    record_id, source_name, reason, error_message, error_type,
                    stage, payload, metadata, attempt, max_attempts,
                    status, retry_count, created_at, updated_at, expires_at
                ) VALUES (
                    :record_id, :source_name, :reason, :error_message, :error_type,
                    :stage, :payload, :metadata, :attempt, :max_attempts,
                    :status, :retry_count, :created_at, :updated_at, :expires_at
                )
            """)
        with self._engine.connect() as conn:
            conn.execute(sql, params)
            conn.commit()

    async def add(self, record: DeadLetterRecord) -> None:
        """Add a dead letter record to the database.

        Args:
            record: The record to store.
        """
        await asyncio.to_thread(self._add_sync, record)
        if self._on_add is not None:
            try:
                self._on_add(record)
            except Exception:
                logger.warning("DLQ on_add callback failed")

    def _add_batch_sync(self, records: list[DeadLetterRecord]) -> int:
        self._ensure_schema_sync()
        t = self._qualified_table
        inserted = 0
        if self._dialect == "postgresql":
            sql = text(f"""
                INSERT INTO {t} (
                    record_id, source_name, reason, error_message, error_type,
                    stage, payload, metadata, attempt, max_attempts,
                    status, retry_count, created_at, updated_at, expires_at
                ) VALUES (
                    :record_id, :source_name, :reason, :error_message, :error_type,
                    :stage, CAST(:payload AS jsonb), CAST(:metadata AS jsonb),
                    :attempt, :max_attempts, :status, :retry_count,
                    :created_at, :updated_at, :expires_at
                )
                ON CONFLICT (record_id) DO NOTHING
            """)
        else:
            sql = text(f"""
                INSERT OR IGNORE INTO {t} (
                    record_id, source_name, reason, error_message, error_type,
                    stage, payload, metadata, attempt, max_attempts,
                    status, retry_count, created_at, updated_at, expires_at
                ) VALUES (
                    :record_id, :source_name, :reason, :error_message, :error_type,
                    :stage, :payload, :metadata, :attempt, :max_attempts,
                    :status, :retry_count, :created_at, :updated_at, :expires_at
                )
            """)
        with self._engine.connect() as conn:
            for record in records:
                params = self._record_to_params(record)
                result = conn.execute(sql, params)
                inserted += result.rowcount
            conn.commit()
        return inserted

    async def add_batch(self, records: list[DeadLetterRecord]) -> int:
        """Add multiple records in a single transaction.

        Args:
            records: Records to store.

        Returns:
            Number of records actually inserted.
        """
        return await asyncio.to_thread(self._add_batch_sync, records)

    def _get_sync(self, record_id: str) -> DeadLetterRecord | None:
        self._ensure_schema_sync()
        t = self._qualified_table
        sql = text(f"SELECT * FROM {t} WHERE record_id = :rid")
        with self._engine.connect() as conn:
            row = conn.execute(sql, {"rid": record_id}).mappings().first()
        if row is None:
            return None
        return self._row_to_record(row)

    async def get(self, record_id: str) -> DeadLetterRecord | None:
        """Retrieve a single record by ID.

        Args:
            record_id: The unique record identifier.

        Returns:
            The record if found, or ``None``.
        """
        return await asyncio.to_thread(self._get_sync, record_id)

    # ------------------------------------------------------------------
    # Query with pagination
    # ------------------------------------------------------------------

    def _query_sync(
        self,
        *,
        source_name: str | None,
        reason: str | None,
        stage: str | None,
        status: DLQStatus | None,
        limit: int,
        offset: int,
        cursor: str | None,
    ) -> QueryResult:
        self._ensure_schema_sync()
        t = self._qualified_table
        clauses: list[str] = []
        params: dict[str, Any] = {"lim": limit}

        if source_name is not None:
            clauses.append("source_name = :sn")
            params["sn"] = source_name
        if reason is not None:
            clauses.append("reason = :reason")
            params["reason"] = reason
        if stage is not None:
            clauses.append("stage = :stage")
            params["stage"] = stage
        if status is not None:
            clauses.append("status = :st")
            params["st"] = str(status)

        # Cursor-based pagination: cursor is "created_at|record_id"
        if cursor:
            parts = cursor.split("|", 1)
            if len(parts) == 2:
                clauses.append(
                    "(created_at < :cursor_ts OR "
                    "(created_at = :cursor_ts AND record_id < :cursor_id))"
                )
                params["cursor_ts"] = parts[0]
                params["cursor_id"] = parts[1]
        elif offset > 0:
            params["off"] = offset

        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""

        with self._engine.connect() as conn:
            # Get total count for the filters (without pagination)
            count_where = where
            count_params = {k: v for k, v in params.items() if k not in ("lim", "off")}
            total = (
                conn.execute(
                    text(f"SELECT COUNT(*) FROM {t}{count_where}"),
                    count_params,
                ).scalar()
                or 0
            )

            # Fetch page
            if cursor or offset <= 0:
                sql = text(
                    f"SELECT * FROM {t}{where} "
                    f"ORDER BY created_at DESC, record_id DESC LIMIT :lim"
                )
            else:
                sql = text(
                    f"SELECT * FROM {t}{where} "
                    f"ORDER BY created_at DESC, record_id DESC "
                    f"LIMIT :lim OFFSET :off"
                )
            rows = conn.execute(sql, params).mappings().all()

        records = [self._row_to_record(r) for r in rows]
        has_more = len(records) == limit and (offset + limit) < total

        next_cursor: str | None = None
        if records and has_more:
            last = records[-1]
            ts = last.created_at.isoformat()
            next_cursor = f"{ts}|{last.record_id}"

        return QueryResult(
            records=records,
            total=int(total),
            has_more=has_more,
            next_cursor=next_cursor,
        )

    async def query(
        self,
        *,
        source_name: str | None = None,
        reason: str | None = None,
        stage: str | None = None,
        status: DLQStatus | None = None,
        limit: int = 100,
        offset: int = 0,
        cursor: str | None = None,
    ) -> QueryResult:
        """Query records with optional filters and pagination.

        Args:
            source_name: Filter by source name.
            reason: Filter by reason string.
            stage: Filter by processing stage.
            status: Filter by lifecycle status.
            limit: Maximum records per page.
            offset: Number of records to skip (offset pagination).
            cursor: Opaque cursor for keyset pagination.

        Returns:
            A :class:`QueryResult` with the matching page.
        """
        return await asyncio.to_thread(
            self._query_sync,
            source_name=source_name,
            reason=reason,
            stage=stage,
            status=status,
            limit=limit,
            offset=offset,
            cursor=cursor,
        )

    # ------------------------------------------------------------------
    # Status mutations
    # ------------------------------------------------------------------

    def _update_status_sync(
        self,
        record_id: str,
        new_status: DLQStatus,
        *,
        increment_retry: bool = False,
    ) -> bool:
        self._ensure_schema_sync()
        t = self._qualified_table
        now = datetime.now(UTC)
        now_param = now if self._dialect == "postgresql" else now.isoformat()

        if increment_retry:
            sql = text(
                f"UPDATE {t} SET status = :st, retry_count = retry_count + 1, "
                f"updated_at = :now WHERE record_id = :rid"
            )
        else:
            sql = text(
                f"UPDATE {t} SET status = :st, updated_at = :now WHERE record_id = :rid"
            )
        with self._engine.connect() as conn:
            result = conn.execute(
                sql,
                {"st": str(new_status), "now": now_param, "rid": record_id},
            )
            conn.commit()
            return result.rowcount > 0

    async def mark_retry(self, record_id: str) -> bool:
        """Mark a record as retrying and increment retry_count.

        Args:
            record_id: The record to mark.

        Returns:
            ``True`` if the record was found and updated.
        """
        return await asyncio.to_thread(
            self._update_status_sync,
            record_id,
            DLQStatus.RETRYING,
            increment_retry=True,
        )

    async def resolve(self, record_id: str) -> bool:
        """Mark a record as resolved.

        Args:
            record_id: The record to resolve.

        Returns:
            ``True`` if the record was found and updated.
        """
        return await asyncio.to_thread(
            self._update_status_sync, record_id, DLQStatus.RESOLVED
        )

    async def ignore(self, record_id: str) -> bool:
        """Mark a record as permanently ignored.

        Args:
            record_id: The record to ignore.

        Returns:
            ``True`` if the record was found and updated.
        """
        return await asyncio.to_thread(
            self._update_status_sync, record_id, DLQStatus.IGNORED
        )

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def _statistics_sync(self, source_name: str | None) -> DLQStatistics:
        self._ensure_schema_sync()
        t = self._qualified_table
        base_where = " WHERE source_name = :sn" if source_name else ""
        params: dict[str, Any] = {}
        if source_name:
            params["sn"] = source_name

        with self._engine.connect() as conn:
            total = (
                conn.execute(
                    text(f"SELECT COUNT(*) FROM {t}{base_where}"), params
                ).scalar()
                or 0
            )

            by_reason: dict[str, int] = {}
            by_status: dict[str, int] = {}
            by_stage: dict[str, int] = {}
            for col, dest in (
                ("reason", by_reason),
                ("status", by_status),
                ("stage", by_stage),
            ):
                q = text(
                    f"SELECT {_quote_ident(col)}, COUNT(*) AS c "
                    f"FROM {t}{base_where} GROUP BY {_quote_ident(col)}"
                )
                for row in conn.execute(q, params).mappings().all():
                    key = row[col] if row[col] is not None else "unknown"
                    dest[str(key)] = int(row["c"])

        return DLQStatistics(
            total=int(total),
            by_reason=by_reason,
            by_status=by_status,
            by_stage=by_stage,
        )

    async def statistics(
        self,
        source_name: str | None = None,
    ) -> DLQStatistics:
        """Get aggregate statistics for stored records.

        Args:
            source_name: Optional filter by source name.

        Returns:
            A :class:`DLQStatistics` instance.
        """
        return await asyncio.to_thread(self._statistics_sync, source_name)

    # ------------------------------------------------------------------
    # TTL / cleanup
    # ------------------------------------------------------------------

    def _purge_expired_sync(self) -> int:
        self._ensure_schema_sync()
        t = self._qualified_table
        now = datetime.now(UTC)
        now_param = now if self._dialect == "postgresql" else now.isoformat()
        sql = text(
            f"DELETE FROM {t} WHERE expires_at IS NOT NULL AND expires_at <= :now"
        )
        with self._engine.connect() as conn:
            result = conn.execute(sql, {"now": now_param})
            conn.commit()
            return result.rowcount

    async def purge_expired(self) -> int:
        """Delete records whose ``expires_at`` is in the past.

        Returns:
            Number of records removed.
        """
        return await asyncio.to_thread(self._purge_expired_sync)

    def _purge_resolved_sync(self, older_than: datetime | None) -> int:
        self._ensure_schema_sync()
        t = self._qualified_table
        if older_than:
            dt_param = (
                older_than if self._dialect == "postgresql" else older_than.isoformat()
            )
            sql = text(
                f"DELETE FROM {t} WHERE status = 'resolved' AND created_at < :older"
            )
            params: dict[str, Any] = {"older": dt_param}
        else:
            sql = text(f"DELETE FROM {t} WHERE status = 'resolved'")
            params = {}
        with self._engine.connect() as conn:
            result = conn.execute(sql, params)
            conn.commit()
            return result.rowcount

    async def purge_resolved(
        self,
        older_than: datetime | None = None,
    ) -> int:
        """Delete resolved records, optionally filtered by age.

        Args:
            older_than: If provided, only delete resolved records created
                before this timestamp.

        Returns:
            Number of records removed.
        """
        return await asyncio.to_thread(self._purge_resolved_sync, older_than)
