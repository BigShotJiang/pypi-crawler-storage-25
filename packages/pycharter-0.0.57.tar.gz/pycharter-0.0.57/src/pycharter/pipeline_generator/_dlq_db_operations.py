"""DLQ database query, retry, statistics, and file-query operations.

Extracted from :mod:`_dlq_database` to keep module sizes under 400 lines.
Shared helpers (``_resolve_table_name``, ``_is_table_missing_error``, etc.)
remain in ``_dlq_database`` and are imported here.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pycharter.pipeline_generator._dlq_database import (
    _EMPTY_STATS,
    _is_table_missing_error,
    _resolve_table_name,
)

if TYPE_CHECKING:
    from pycharter.pipeline_generator._dlq_core import DeadLetterRecord, DLQReason

logger = logging.getLogger(__name__)


def query_from_database(
    db_session: Any,
    schema_name: str | None,
    pipeline_name: str | None,
    reason: DLQReason | None,
    stage: str | None,
    status: str | None,
    limit: int,
) -> list[DeadLetterRecord]:
    """Query DLQ records from the database using configurable schema.

    Args:
        db_session: SQLAlchemy sync or async session.
        schema_name: Database schema name override.
        pipeline_name: Filter by pipeline name.
        reason: Filter by DLQ reason.
        stage: Filter by ETL stage.
        status: Filter by record status.
        limit: Maximum number of records to return.

    Returns:
        List of matching :class:`DeadLetterRecord` objects.
    """
    from sqlalchemy import text
    from sqlalchemy.exc import ProgrammingError
    from sqlalchemy.ext.asyncio import AsyncSession

    from pycharter.pipeline_generator._dlq_core import DeadLetterRecord, DLQReason

    is_async = isinstance(db_session, AsyncSession)
    table_name = _resolve_table_name(schema_name)

    try:
        if is_async:
            logger.debug(
                "get_records() called with async session - returning empty list. "
                "Use async method instead."
            )
            return []

        conditions: list[str] = []
        params: dict[str, Any] = {}
        if pipeline_name:
            conditions.append("pipeline_name = :pipeline_name")
            params["pipeline_name"] = pipeline_name
        if reason:
            conditions.append("reason = :reason")
            params["reason"] = reason.value
        if stage:
            conditions.append("stage = :stage")
            params["stage"] = stage
        if status:
            conditions.append("status = :status")
            params["status"] = status

        where_clause = " AND ".join(conditions) if conditions else "1=1"
        params["limit"] = limit
        query_sql = text(f"""
            SELECT id, pipeline_name, record_data, reason, error_message,
                   error_type, stage, additional_metadata, retry_count,
                   status, timestamp
            FROM {table_name}
            WHERE {where_clause}
            ORDER BY timestamp DESC
            LIMIT :limit""")

        result = db_session.execute(query_sql, params)
        records = []
        for row in result.fetchall():
            record = DeadLetterRecord(
                pipeline_name=row.pipeline_name,
                record_data=(
                    row.record_data
                    if isinstance(row.record_data, dict)
                    else json.loads(row.record_data)
                ),
                reason=DLQReason(row.reason),
                error_message=row.error_message,
                error_type=row.error_type,
                stage=row.stage,
                metadata=(
                    row.additional_metadata
                    if isinstance(row.additional_metadata, dict)
                    else (
                        json.loads(row.additional_metadata)
                        if row.additional_metadata
                        else {}
                    )
                ),
                id=row.id,
                retry_count=row.retry_count,
                status=row.status,
                timestamp=row.timestamp,
            )
            records.append(record)
        return records
    except ProgrammingError as e:
        if _is_table_missing_error(e):
            logger.debug("DLQ table does not exist - returning empty list")
        else:
            logger.warning("Failed to query DLQ records: %s", e)
        return []
    except Exception as e:
        logger.warning("Failed to query DLQ records: %s", e)
        return []


async def retry_record_in_database(
    db_session: Any,
    schema_name: str | None,
    record_id: str,
) -> bool:
    """Mark a DLQ record for retry in the database.

    Args:
        db_session: SQLAlchemy sync or async session.
        schema_name: Database schema name override.
        record_id: ID of the record to retry.

    Returns:
        True if the record was updated, False otherwise.
    """
    from sqlalchemy import text
    from sqlalchemy.exc import ProgrammingError
    from sqlalchemy.ext.asyncio import AsyncSession

    table_name = _resolve_table_name(schema_name)
    is_async = isinstance(db_session, AsyncSession)

    try:
        update_sql = text(f"""
            UPDATE {table_name}
            SET status = 'retrying', retry_count = retry_count + 1, updated_at = NOW()
            WHERE id = :id""")
        if is_async:
            result = await db_session.execute(update_sql, {"id": record_id})
            await db_session.commit()
            return result.rowcount > 0
        else:
            result = db_session.execute(update_sql, {"id": record_id})
            db_session.commit()
            return result.rowcount > 0
    except ProgrammingError as e:
        if _is_table_missing_error(e):
            logger.debug("DLQ table does not exist - cannot retry record")
        else:
            logger.warning("Failed to retry DLQ record: %s", e)
        return False
    except Exception as e:
        logger.warning("Failed to retry DLQ record: %s", e)
        return False


def get_statistics_from_database(
    db_session: Any,
    schema_name: str | None,
    pipeline_name: str | None,
) -> dict[str, Any]:
    """Retrieve DLQ statistics from the database.

    Args:
        db_session: SQLAlchemy sync or async session.
        schema_name: Database schema name override.
        pipeline_name: Optional pipeline name filter.

    Returns:
        Dictionary with ``total``, ``by_reason``, ``by_stage``, ``by_status``.
    """
    from sqlalchemy import text
    from sqlalchemy.exc import ProgrammingError

    table_name = _resolve_table_name(schema_name)

    try:
        where_clause = ""
        params: dict[str, Any] = {}
        if pipeline_name:
            where_clause = "WHERE pipeline_name = :pipeline_name"
            params["pipeline_name"] = pipeline_name

        count_sql = text(f"SELECT COUNT(*) FROM {table_name} {where_clause}")
        total = db_session.execute(count_sql, params).scalar()

        def _grouped(column: str) -> dict[str, int]:
            sql = text(
                f"SELECT {column}, COUNT(*) as count FROM {table_name} "
                f"{where_clause} GROUP BY {column}"
            )
            return {
                row[0]: row[1] for row in db_session.execute(sql, params).fetchall()
            }

        return {
            "total": total,
            "by_reason": _grouped("reason"),
            "by_stage": _grouped("stage"),
            "by_status": _grouped("status"),
        }
    except ProgrammingError as e:
        if _is_table_missing_error(e):
            logger.debug("DLQ table does not exist - returning empty statistics")
        else:
            logger.warning("Failed to get DLQ statistics: %s", e)
        return dict(_EMPTY_STATS)
    except Exception as e:
        logger.warning("Failed to get DLQ statistics: %s", e)
        return dict(_EMPTY_STATS)


def query_from_files(
    storage_path: Path,
    pipeline_name: str | None,
    reason: DLQReason | None,
    stage: str | None,
    status: str | None,
    limit: int,
) -> list[DeadLetterRecord]:
    """Query DLQ records from file storage.

    Args:
        storage_path: Directory containing DLQ JSON files.
        pipeline_name: Filter by pipeline name.
        reason: Filter by DLQ reason.
        stage: Filter by ETL stage.
        status: Filter by record status.
        limit: Maximum number of records to return.

    Returns:
        List of matching :class:`DeadLetterRecord` objects.
    """
    from pycharter.pipeline_generator._dlq_core import DeadLetterRecord, DLQReason

    records: list[DeadLetterRecord] = []
    if not storage_path.is_dir():
        return records
    for filepath in sorted(storage_path.glob("*.json"), reverse=True):
        if len(records) >= limit:
            break
        try:
            with open(filepath) as f:
                data = json.load(f)
            if pipeline_name and data.get("pipeline_name") != pipeline_name:
                continue
            if reason and data.get("reason") != reason.value:
                continue
            if stage and data.get("stage") != stage:
                continue
            if status and data.get("status") != status:
                continue
            record = DeadLetterRecord(
                pipeline_name=data["pipeline_name"],
                record_data=data["record_data"],
                reason=DLQReason(data["reason"]),
                error_message=data["error_message"],
                error_type=data["error_type"],
                stage=data["stage"],
                metadata=data.get("metadata") or {},
                id=data["id"],
                timestamp=datetime.fromisoformat(data["timestamp"]),
                retry_count=data.get("retry_count", 0),
                status=data.get("status", "pending"),
            )
            records.append(record)
        except Exception as e:
            logger.warning("Failed to read DLQ file %s: %s", filepath, e)
    return records
