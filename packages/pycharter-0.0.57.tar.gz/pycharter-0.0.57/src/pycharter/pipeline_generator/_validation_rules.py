# TODO(maintainability): This file is 411 lines (limit: 400). Split into smaller modules.
"""Validation rule implementations for ETL pipelines.

Provides schema/contract resolution, DLQ creation, and ETLValidator factory
functions used by the pipeline configuration layer.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from pycharter.contract_store import ContractStoreClient
from pycharter.pipeline_generator._validation_core import ETLValidator
from pycharter.pipeline_generator.config_models import (
    ContractRef,
    DLQBackend,
    DLQConfig,
    ExtractValidationConfig,
    LoadValidationConfig,
)
from pycharter.pipeline_generator.dlq import DeadLetterQueue

logger = logging.getLogger(__name__)


def _dlq_owned_session(url: str) -> tuple[Any, Any]:
    """SQLAlchemy engine + sync Session; dispose via :meth:`DeadLetterQueue.close`."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(url, pool_pre_ping=True)
    SessionLocal = sessionmaker(bind=engine)
    return engine, SessionLocal()


def resolve_schema(
    schema_ref: str,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    """Resolve a schema file path to a schema dict.

    Args:
        schema_ref: Path to schema file (absolute or relative).
        base_dir: Base directory for relative paths.

    Returns:
        Schema dict.

    Raises:
        FileNotFoundError: If schema file not found.
        ValueError: If schema file is invalid.
    """
    schema_path = Path(schema_ref)

    # Resolve relative paths
    if not schema_path.is_absolute() and base_dir:
        schema_path = base_dir / schema_path

    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")

    with open(schema_path) as f:
        schema = yaml.safe_load(f)

    if not isinstance(schema, dict):
        raise ValueError(f"Invalid schema file: {schema_path}")

    return schema


def resolve_contract(
    contract_ref: str | ContractRef | dict[str, Any],
    contract_store: ContractStoreClient = None,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    """Resolve a contract reference to a complete contract dict.

    Supports:
    - String path: "contracts/orders/schema.yaml" (file path)
    - ContractRef object: {"type": "database", "name": "orders", "version": "2.0"}
    - Dict with 'name' key: {"name": "orders"} (uses contract_store)
    - Dict with 'type': file' and 'path' key

    Args:
        contract_ref: Contract reference (path, ContractRef, or dict).
        contract_store: Optional ContractStoreClient for database contracts.
        base_dir: Base directory for relative file paths.

    Returns:
        Complete contract dict with schema (and optionally coercion/validation rules).

    Raises:
        FileNotFoundError: If file-based contract not found.
        ValueError: If contract reference is invalid or store not provided.
    """
    # Case 1: String path (file-based)
    if isinstance(contract_ref, str):
        return _load_contract_from_file(contract_ref, base_dir)

    # Case 2: ContractRef Pydantic model
    if isinstance(contract_ref, ContractRef):
        if not contract_store:
            raise ValueError("contract_store required for database contract reference")
        return _load_contract_from_store(
            contract_store, contract_ref.name, contract_ref.version
        )

    # Case 3: Dict
    if isinstance(contract_ref, dict):
        return _resolve_contract_dict(contract_ref, contract_store, base_dir)

    raise ValueError(f"Invalid contract reference: {contract_ref}")


def _resolve_contract_dict(
    contract_ref: dict[str, Any],
    contract_store: ContractStoreClient | None,
    base_dir: Path | None,
) -> dict[str, Any]:
    """Resolve a dict-based contract reference."""
    ref_type = contract_ref.get("type", "file")

    if ref_type == "file":
        path = contract_ref.get("path")
        if not path:
            raise ValueError("Contract reference missing 'path' field")
        return _load_contract_from_file(path, base_dir)

    if ref_type == "database":
        name = contract_ref.get("name")
        if not name:
            raise ValueError("Contract reference missing 'name' field")
        if not contract_store:
            raise ValueError("contract_store required for database contract reference")
        return _load_contract_from_store(
            contract_store, name, contract_ref.get("version")
        )

    # Shorthand for database: dict with just 'name'
    if "name" in contract_ref:
        if not contract_store:
            raise ValueError("contract_store required for contract name reference")
        return _load_contract_from_store(
            contract_store,
            contract_ref["name"],
            contract_ref.get("version"),
        )

    raise ValueError(f"Unknown contract reference type: {ref_type}")


def _load_contract_from_file(
    path: str,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    """Load contract from file path."""
    contract_path = Path(path)

    # Resolve relative paths
    if not contract_path.is_absolute() and base_dir:
        contract_path = base_dir / contract_path

    # Check if it's a directory (contract directory) or file
    if contract_path.is_dir():
        return _load_contract_from_directory(contract_path)
    if contract_path.exists():
        return _load_contract_from_single_file(contract_path)

    # Try adding common extensions
    for ext in (".yaml", ".yml", ".json"):
        if contract_path.with_suffix(ext).exists():
            return _load_contract_from_single_file(contract_path.with_suffix(ext))

    raise FileNotFoundError(f"Contract not found: {contract_path}")


def _load_contract_from_directory(directory: Path) -> dict[str, Any]:
    """Load contract from directory with separate files."""
    contract: dict[str, Any] = {}

    # Load schema (required)
    schema_path = directory / "schema.yaml"
    if not schema_path.exists():
        schema_path = directory / "schema.yml"
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema not found in contract directory: {directory}")

    with open(schema_path) as f:
        contract["json_schema"] = yaml.safe_load(f)

    # Load coercion rules (optional)
    for name in ("coercion_rules.yaml", "coercion_rules.yml", "coercion.yaml"):
        coercion_path = directory / name
        if coercion_path.exists():
            with open(coercion_path) as f:
                contract["coercion_rules"] = yaml.safe_load(f)
            break

    # Load validation rules (optional)
    for name in ("validation_rules.yaml", "validation_rules.yml", "validation.yaml"):
        validation_path = directory / name
        if validation_path.exists():
            with open(validation_path) as f:
                contract["validation_rules"] = yaml.safe_load(f)
            break

    return contract


def _load_contract_from_single_file(path: Path) -> dict[str, Any]:
    """Load contract from single file. Returns dict with 'json_schema' key."""
    with open(path) as f:
        content = yaml.safe_load(f)

    if not isinstance(content, dict):
        raise ValueError(f"Invalid contract file: {path}")

    # If it has a schema key (legacy 'schema' or 'json_schema'), normalize to json_schema
    schema = content.get("json_schema") or content.get("schema")
    if schema is not None:
        out = dict(content)
        out["json_schema"] = schema
        out.pop("schema", None)
        return out

    # Otherwise treat the whole file as the schema
    return {"json_schema": content}


def _load_contract_from_store(
    store: ContractStoreClient,
    name: str,
    version: str | None = None,
) -> dict[str, Any]:
    """Load contract from contract store.

    Returns raw schema + separate rules. The Validator handles merging internally.
    """
    # Get raw schema (not merged)
    schema = store.get_schema(name, version)

    if not schema:
        raise ValueError(f"Contract not found in store: {name} (version: {version})")

    # Get coercion and validation rules separately
    coercion_rules = store.get_coercion_rules(name, version)
    validation_rules = store.get_validation_rules(name, version)

    return {
        "schema": schema,
        "coercion_rules": coercion_rules or {},
        "validation_rules": validation_rules or {},
    }


def create_dlq(
    dlq_config: bool | DLQConfig | dict[str, Any] | None,
    default_config: DLQConfig | None = None,
    db_session: Any | None = None,
) -> DeadLetterQueue | None:
    """Create a DeadLetterQueue from configuration.

    Args:
        dlq_config: DLQ configuration (bool, DLQConfig, or dict). ``True`` with no
            ``default_config`` selects database backend using the main app DB URL.
        default_config: Default DLQ config from settings (e.g. file backend from
            ``settings.yaml``).
        db_session: Database session for database backend when not auto-created.

    Returns:
        DeadLetterQueue instance or None if disabled.
    """
    # Handle bool shorthand
    if dlq_config is True:
        if default_config:
            dlq_config = default_config
        else:
            dlq_config = DLQConfig(enabled=True, backend=DLQBackend.DATABASE)
    elif dlq_config is False or dlq_config is None:
        return None

    # Convert dict to DLQConfig if needed
    if isinstance(dlq_config, dict):
        dlq_config = DLQConfig(**dlq_config)

    if not dlq_config.enabled:
        return None

    if dlq_config.backend == DLQBackend.DATABASE:
        session = db_session
        owned_engine = None
        if session is None:
            raw = (dlq_config.connection_string or "").strip()
            url: str | None = raw if raw else None
            if not url:
                from pycharter.db.config import get_db_url

                url = get_db_url(None, required=False)
            if url:
                owned_engine, session = _dlq_owned_session(url)
            else:
                logger.warning(
                    "DLQ database backend has no URL; records use in-memory fallback"
                )
        return DeadLetterQueue(
            db_session=session,
            storage_backend=dlq_config.backend.value,
            storage_path=dlq_config.path,
            enabled=dlq_config.enabled,
            schema_name=dlq_config.schema_name,
            owned_engine=owned_engine,
        )

    return DeadLetterQueue(
        db_session=db_session if dlq_config.backend == DLQBackend.DATABASE else None,
        storage_backend=dlq_config.backend.value,
        storage_path=dlq_config.path,
        enabled=dlq_config.enabled,
        schema_name=dlq_config.schema_name,
    )


def create_etl_validator(
    validation_config: ExtractValidationConfig | LoadValidationConfig | dict[str, Any],
    pipeline_name: str,
    stage: str,
    contract_store: ContractStoreClient | None = None,
    default_contract: str | None = None,
    default_dlq_config: DLQConfig | None = None,
    base_dir: Path | None = None,
    db_session: Any | None = None,
) -> ETLValidator | None:
    """Create an ETLValidator from validation configuration.

    Args:
        validation_config: Validation config (ExtractValidationConfig,
            LoadValidationConfig, or dict).
        pipeline_name: Pipeline name for DLQ metadata.
        stage: ETL stage ('extract' or 'load').
        contract_store: Optional contract store for database contracts.
        default_contract: Default contract name from settings.
        default_dlq_config: Default DLQ config from settings.
        base_dir: Base directory for relative file paths.
        db_session: Database session for DLQ database backend.

    Returns:
        ETLValidator instance or None if validation not configured.
    """
    if validation_config is None:
        return None

    # Convert dict to appropriate config type
    if isinstance(validation_config, dict):
        if stage == "extract":
            validation_config = ExtractValidationConfig(**validation_config)
        else:
            validation_config = LoadValidationConfig(**validation_config)

    # Resolve schema/contract
    schema_or_contract = _resolve_validation_schema(
        validation_config, contract_store, default_contract, base_dir, stage
    )

    if schema_or_contract is None:
        return None

    # Create DLQ if configured
    dlq = create_dlq(validation_config.dlq, default_dlq_config, db_session)

    return ETLValidator(
        schema_or_contract=schema_or_contract,
        on_error=validation_config.on_error,
        dlq=dlq,
        pipeline_name=pipeline_name,
        stage=stage,
    )


def _resolve_validation_schema(
    validation_config: ExtractValidationConfig | LoadValidationConfig,
    contract_store: ContractStoreClient | None,
    default_contract: str | None,
    base_dir: Path | None,
    stage: str,
) -> dict[str, Any] | None:
    """Resolve the schema or contract from a validation config."""
    if isinstance(validation_config, ExtractValidationConfig):
        # Extract validation uses schema file
        if validation_config.schema_path:
            return resolve_schema(validation_config.schema_path, base_dir)
        logger.warning("Extract validation config missing 'schema_path' field")
        return None

    if isinstance(validation_config, LoadValidationConfig):
        # Load validation uses contract
        if validation_config.contract:
            return resolve_contract(
                validation_config.contract, contract_store, base_dir
            )
        if validation_config.use_contract and default_contract:
            return resolve_contract(
                {"name": default_contract}, contract_store, base_dir
            )
        logger.warning("Load validation config missing 'contract' field")
        return None

    logger.warning("Unrecognized validation config type for stage '%s'", stage)
    return None
