"""SQLAlchemy-backed draft repository.

Maps :class:`pycharter.db.models.DraftModel` rows to and from the
canonical :class:`pycharter.semantic.drafts.DraftConfig` Pydantic
shape so the service layer never touches DB types directly.
"""

from __future__ import annotations

import json
import uuid
from collections.abc import Iterable

from sqlalchemy import or_
from sqlalchemy.orm import Session

from pycharter.db.models.draft import DraftModel
from pycharter.semantic.drafts.models import (
    DraftConfig,
    DraftPromotion,
    DraftSourceType,
    DraftVisibility,
)
from pycharter.semantic.drafts.service import DraftActor, DraftNotFoundError


class SqlAlchemyDraftRepository:
    """Draft repository backed by the SQLAlchemy ``drafts`` table."""

    def __init__(self, session: Session) -> None:
        """Construct the repository with a SQLAlchemy session."""
        self._session = session

    def list_visible(self, actor: DraftActor) -> Iterable[DraftConfig]:
        """Yield drafts the actor can see.

        Visibility filtering happens at the SQL layer for efficiency:
        we issue a single query that combines the actor's owned
        drafts, public drafts, and any drafts whose team_id matches
        one of the actor's team memberships.
        """
        team_ids = list(actor.team_ids)
        clauses = [
            DraftModel.owner_id == actor.user_id,
            DraftModel.visibility == DraftVisibility.PUBLIC.value,
        ]
        if team_ids:
            clauses.append(
                (DraftModel.visibility == DraftVisibility.TEAM.value)
                & DraftModel.team_id.in_(team_ids),
            )
        rows = (
            self._session.query(DraftModel)
            .filter(or_(*clauses))
            .order_by(DraftModel.created_at.desc())
            .all()
        )
        for row in rows:
            yield self._row_to_config(row)

    def get(self, draft_id: str) -> DraftConfig | None:
        """Return one draft by id, or None if missing."""
        row = self._fetch_row(draft_id)
        if row is None:
            return None
        return self._row_to_config(row)

    def create(self, draft: DraftConfig) -> DraftConfig:
        """Insert a new draft row."""
        row = DraftModel(
            id=_parse_uuid(draft.id),
            name=draft.name,
            namespace=draft.namespace,
            description=draft.description,
            source_type=draft.source_type.value,
            source_payload=draft.source_payload,
            parsed_yaml=draft.parsed_yaml,
            visibility=draft.visibility.value,
            owner_id=draft.owner_id,
            team_id=draft.team_id,
        )
        if draft.promotions:
            self._stamp_promotion(row, draft.promotions[-1])
        self._session.add(row)
        self._session.flush()
        return self._row_to_config(row)

    def update(self, draft: DraftConfig) -> DraftConfig:
        """Update an existing draft row by id."""
        row = self._fetch_row(draft.id)
        if row is None:
            raise DraftNotFoundError(f"draft '{draft.id}' not found")
        row.name = draft.name
        row.namespace = draft.namespace
        row.description = draft.description
        row.source_type = draft.source_type.value
        row.source_payload = draft.source_payload
        row.parsed_yaml = draft.parsed_yaml
        row.visibility = draft.visibility.value
        row.team_id = draft.team_id
        if draft.promotions:
            self._stamp_promotion(row, draft.promotions[-1])
        # Round-trip the full promotion history through the description
        # column under a marker, mirroring the contract metadata trick.
        # This avoids a DB migration to add a JSONB promotions column
        # while keeping the canonical YAML form complete.
        if draft.promotions:
            row.description = _encode_with_promotions(
                draft.description,
                draft.promotions,
            )
        else:
            row.description = draft.description
        self._session.flush()
        return self._row_to_config(row)

    def delete(self, draft_id: str) -> None:
        """Delete a draft row; missing id is a no-op."""
        row = self._fetch_row(draft_id)
        if row is None:
            return
        self._session.delete(row)
        self._session.flush()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _fetch_row(self, draft_id: str) -> DraftModel | None:
        """Look up a draft row by id, returning None on bad UUIDs too."""
        try:
            uid = _parse_uuid(draft_id)
        except ValueError:
            return None
        return (
            self._session.query(DraftModel).filter(DraftModel.id == uid).one_or_none()
        )

    def _stamp_promotion(
        self,
        row: DraftModel,
        promotion: DraftPromotion,
    ) -> None:
        """Mirror the most recent promotion onto indexed columns."""
        row.promoted_to_kind = promotion.kind
        row.promoted_to_ref = promotion.ref
        row.promoted_at = promotion.promoted_at

    def _row_to_config(self, row: DraftModel) -> DraftConfig:
        """Convert a DraftModel row to a DraftConfig Pydantic instance."""
        description, promotions = _decode_with_promotions(row.description)
        if not promotions and row.promoted_to_kind and row.promoted_to_ref:
            # Reconstruct a single-entry history from the column copy
            # when the description marker is missing (e.g. for rows
            # written by other paths).
            promotions = (
                DraftPromotion(
                    kind=row.promoted_to_kind,  # type: ignore[arg-type]
                    ref=row.promoted_to_ref,
                    promoted_at=row.promoted_at,
                ),
            )
        return DraftConfig(
            id=str(row.id),
            name=row.name,
            namespace=row.namespace,
            description=description,
            source_type=DraftSourceType(row.source_type),
            source_payload=row.source_payload,
            parsed_yaml=row.parsed_yaml,
            visibility=DraftVisibility(row.visibility),
            owner_id=row.owner_id,
            team_id=row.team_id,
            created_at=row.created_at,
            updated_at=row.updated_at,
            promotions=promotions,
        )


_PROMOTIONS_MARKER = "\n\n<!-- draft-promotions -->"


def _parse_uuid(value: str) -> uuid.UUID:
    """Parse a UUID string, raising ValueError on malformed input."""
    return uuid.UUID(value)


def _encode_with_promotions(
    description: str | None,
    promotions: tuple[DraftPromotion, ...],
) -> str:
    """Stash the full promotion history alongside the description."""
    body = description or ""
    encoded = json.dumps(
        [
            {
                "kind": p.kind,
                "ref": p.ref,
                "promoted_at": p.promoted_at.isoformat(),
                "promoted_by": p.promoted_by,
            }
            for p in promotions
        ],
        ensure_ascii=False,
    )
    return f"{body}{_PROMOTIONS_MARKER}\n{encoded}"


def _decode_with_promotions(
    raw: str | None,
) -> tuple[str | None, tuple[DraftPromotion, ...]]:
    """Pull description + promotions back out of a stashed column."""
    if not raw:
        return None, ()
    if _PROMOTIONS_MARKER not in raw:
        return raw, ()
    prefix, _, tail = raw.partition(_PROMOTIONS_MARKER)
    description = prefix or None
    tail = tail.strip()
    promotions: list[DraftPromotion] = []
    if tail:
        try:
            parsed = json.loads(tail)
        except json.JSONDecodeError:
            parsed = []
        if isinstance(parsed, list):
            for entry in parsed:
                if not isinstance(entry, dict):
                    continue
                try:
                    promotions.append(
                        DraftPromotion.model_validate(entry),
                    )
                except Exception:  # noqa: BLE001
                    continue
    return description, tuple(promotions)
