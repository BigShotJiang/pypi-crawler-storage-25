"""Persistence layer — DB-backed repositories and data sources.

This package contains every module that directly imports SQLAlchemy
models or performs database I/O. The stateless core
(:mod:`pycharter.semantic`, :mod:`pycharter.pipeline_generator`)
depends on abstract interfaces (protocols); the persistence layer
provides the concrete implementations.

Relocating these modules from ``pycharter.semantic.*`` to
``pycharter.persistence.*`` enforces the layered architecture:

  Layer 0 (stateless core) → Layer 1 (persistence) → Layer 2 (API)

The old import paths remain available via re-exports with
deprecation warnings in the original ``__init__.py`` files.
"""

from __future__ import annotations
