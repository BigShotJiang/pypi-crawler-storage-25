"""
Proposal Manager - CRUD operations for proposals.

Proposals are proposal-based change requests for ontology modifications,
linking a source branch to a target branch.
"""

from __future__ import annotations

import uuid
from typing import Any

from pycharter.persistence.collaboration.review import ReviewWorkflow
from pycharter.semantic.collaboration.policy import evaluate_proposal_policy
from pycharter.semantic.shared.errors import CollaborationError


class ProposalManager:
    """
    Manages proposals for ontology changes.

    Args:
        session: SQLAlchemy session
    """

    def __init__(self, session=None):
        self._session = session

    def _require_session(self):
        if self._session is None:
            raise CollaborationError("No database session configured")

    def create_proposal(
        self,
        contract_id: str,
        title: str,
        author: str,
        description: str | None = None,
        source_branch_id: str | None = None,
        target_branch_id: str | None = None,
        proposal_type: str = "mapping_change",
        affected_tiers: list[str] | None = None,
    ) -> str:
        """
        Create a new proposal.

        Args:
            contract_id: Contract identifier
            title: Proposal title
            author: Author name
            description: Detailed description
            source_branch_id: Branch with changes
            target_branch_id: Branch to merge into

        Returns:
            UUID string of the created proposal
        """
        self._require_session()

        from pycharter.db.models.semantic.proposal import ProposalModel

        policy = evaluate_proposal_policy(
            proposal_type=proposal_type,
            affected_tiers=affected_tiers,
        )

        proposal = ProposalModel(
            contract_id=contract_id,
            title=title,
            author=author,
            description=description,
            source_branch_id=uuid.UUID(source_branch_id) if source_branch_id else None,
            target_branch_id=uuid.UUID(target_branch_id) if target_branch_id else None,
            proposal_type=policy["proposal_type"],
            required_approvals=policy["required_approvals"],
            enforce_gates=policy["enforce_gates"],
            gate_status={
                "overall": "pending",
                "enforce_gates": policy["enforce_gates"],
                "gates": [],
                "warnings": [],
            },
            created_by=author,
        )
        self._session.add(proposal)
        self._session.flush()
        return str(proposal.id)

    def get_proposal(self, proposal_id: str) -> dict[str, Any]:
        """
        Get a proposal by ID.

        Args:
            proposal_id: UUID of the proposal

        Returns:
            Proposal dict or None
        """
        self._require_session()

        from pycharter.db.models.semantic.proposal import ProposalModel

        row = (
            self._session.query(ProposalModel)
            .filter(ProposalModel.id == uuid.UUID(proposal_id))
            .first()
        )
        if row is None:
            return None
        return {
            "id": str(row.id),
            "contract_id": row.contract_id,
            "title": row.title,
            "description": row.description,
            "source_branch_id": (
                str(row.source_branch_id) if row.source_branch_id else None
            ),
            "target_branch_id": (
                str(row.target_branch_id) if row.target_branch_id else None
            ),
            "status": row.status,
            "author": row.author,
            "proposal_type": row.proposal_type,
            "required_approvals": row.required_approvals,
            "enforce_gates": row.enforce_gates,
            "gate_status": row.gate_status,
            "created_at": str(row.created_at) if row.created_at else None,
        }

    def list_proposals(
        self, contract_id: str, status: str | None = None
    ) -> list[dict[str, Any]]:
        """
        List proposals for a contract.

        Args:
            contract_id: Contract identifier
            status: Optional status filter

        Returns:
            List of proposal dicts
        """
        self._require_session()

        from pycharter.db.models.semantic.proposal import ProposalModel

        query = self._session.query(ProposalModel).filter(
            ProposalModel.contract_id == contract_id
        )
        if status:
            query = query.filter(ProposalModel.status == status)
        return [
            {
                "id": str(row.id),
                "contract_id": row.contract_id,
                "title": row.title,
                "description": row.description,
                "status": row.status,
                "author": row.author,
                "proposal_type": row.proposal_type,
                "required_approvals": row.required_approvals,
                "enforce_gates": row.enforce_gates,
                "gate_overall": (row.gate_status or {}).get("overall")
                if isinstance(row.gate_status, dict)
                else None,
                "created_at": str(row.created_at) if row.created_at else None,
                "updated_at": str(row.updated_at) if row.updated_at else None,
            }
            for row in query.all()
        ]

    def update_status(
        self, proposal_id: str, status: str, updated_by: str | None = None
    ) -> None:
        """
        Update a proposal's status.

        Args:
            proposal_id: UUID of the proposal
            status: New status (open, merged, closed)
            updated_by: Who is updating
        """
        self._require_session()

        from pycharter.db.models.semantic.proposal import ProposalModel

        row = (
            self._session.query(ProposalModel)
            .filter(ProposalModel.id == uuid.UUID(proposal_id))
            .first()
        )
        if row is None:
            raise CollaborationError(f"Proposal {proposal_id} not found")
        row.status = status
        if updated_by:
            row.updated_by = updated_by
        self._session.flush()

    def merge_proposal(self, proposal_id: str, merged_by: str) -> None:
        """
        Merge a proposal (mark as merged).

        Args:
            proposal_id: UUID of the proposal
            merged_by: Who is merging
        """
        self._require_session()
        from pycharter.db.models.semantic.proposal import ProposalModel

        row = (
            self._session.query(ProposalModel)
            .filter(ProposalModel.id == uuid.UUID(proposal_id))
            .first()
        )
        if row is None:
            raise CollaborationError(f"Proposal {proposal_id} not found")

        rw = ReviewWorkflow(self._session)
        approval = rw.check_approval_status(
            proposal_id,
            required_approvals=int(row.required_approvals or 1),
        )
        if not approval["approved"]:
            raise CollaborationError(
                "Proposal cannot be merged: insufficient approvals "
                f"({approval['approval_count']}/{approval['required_approvals']})."
            )

        gate_status = row.gate_status or {}
        if row.enforce_gates and gate_status.get("overall") != "pass":
            raise CollaborationError(
                "Proposal cannot be merged: required validation gates did not pass."
            )

        self.update_status(proposal_id, "merged", updated_by=merged_by)

    def set_gate_status(
        self,
        proposal_id: str,
        gate_status: dict[str, Any],
        updated_by: str | None = None,
    ) -> None:
        """Persist latest gate status for a proposal."""
        self._require_session()
        from pycharter.db.models.semantic.proposal import ProposalModel

        row = (
            self._session.query(ProposalModel)
            .filter(ProposalModel.id == uuid.UUID(proposal_id))
            .first()
        )
        if row is None:
            raise CollaborationError(f"Proposal {proposal_id} not found")
        row.gate_status = gate_status
        if updated_by:
            row.updated_by = updated_by
        self._session.flush()
