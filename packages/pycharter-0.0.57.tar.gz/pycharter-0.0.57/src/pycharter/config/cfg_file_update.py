"""Read/write ``pycharter.cfg`` for the admin server-config API.

Aligned with ``pystator.config.cfg_file_update``: allow-listed keys only (see
``pycharter.api.services.server_config_editor``), Admin-only routes, env overrides at runtime.

``interpolation=None`` avoids ``%`` issues in URLs and JSON-like values.
"""

from __future__ import annotations

import os
import tempfile
from configparser import ConfigParser
from pathlib import Path
from typing import Any

from pycharter.config._helpers import (
    _CONFIG_FILENAME,
    find_config_file,
    find_config_file_user_scoped,
)

MAX_OPTION_VALUE_CHARS = 65_536
# Subset of sections mirrored to user-scoped cfg when it differs from main (empty = none).
MIRROR_TO_USER_SCOPED_SECTIONS: frozenset[str] = frozenset()


def resolve_config_path_for_write() -> Path:
    existing = find_config_file(_CONFIG_FILENAME)
    if existing:
        return Path(existing)
    home_dir = Path.home() / ".pycharter"
    home_dir.mkdir(parents=True, exist_ok=True)
    return home_dir / _CONFIG_FILENAME


def resolve_user_scoped_cfg_path_for_write() -> Path:
    existing = find_config_file_user_scoped(_CONFIG_FILENAME)
    if existing:
        return Path(existing)
    home_dir = Path.home() / ".pycharter"
    home_dir.mkdir(parents=True, exist_ok=True)
    return home_dir / _CONFIG_FILENAME


def config_file_path_display() -> str | None:
    p = find_config_file(_CONFIG_FILENAME)
    return str(p) if p else None


def env_overrides(env_key: str) -> bool:
    raw = os.getenv(env_key)
    return raw is not None and str(raw).strip() != ""


def _config_parser() -> ConfigParser:
    return ConfigParser(interpolation=None)


def assert_option_value_length(value: str, *, key: str) -> None:
    if len(value) > MAX_OPTION_VALUE_CHARS:
        raise ValueError(
            f"{key}: value exceeds maximum length ({MAX_OPTION_VALUE_CHARS} characters)"
        )


def read_cfg_option(section: str, option_key: str) -> str | None:
    path = (
        resolve_user_scoped_cfg_path_for_write()
        if section in MIRROR_TO_USER_SCOPED_SECTIONS
        else resolve_config_path_for_write()
    )
    if not path.exists():
        return None
    cfg = _config_parser()
    try:
        cfg.read(path, encoding="utf-8")
    except OSError:
        return None
    if not cfg.has_section(section):
        return None
    if not cfg.has_option(section, option_key):
        return None
    val = cfg.get(section, option_key, fallback="")
    return val.strip() if val and val.strip() else val


def merge_and_write(
    section_updates: dict[str, dict[str, str]],
    *,
    target_path: Path | None = None,
) -> Path:
    path = target_path or resolve_config_path_for_write()
    cfg = _config_parser()
    if path.exists():
        try:
            cfg.read(path, encoding="utf-8")
        except OSError:
            pass

    for section, options in section_updates.items():
        if not cfg.has_section(section):
            cfg.add_section(section)
        for opt_key, val in options.items():
            assert_option_value_length(val, key=opt_key)
            cfg.set(section, opt_key, val)

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        suffix=".tmp",
        prefix="pycharter.cfg.",
        dir=path.parent,
        text=True,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            cfg.write(fh)
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise
    return path


def normalize_bool_for_cfg(value: Any) -> str:
    if isinstance(value, bool):
        return "1" if value else "0"
    s = str(value).strip().lower()
    if s in {"1", "true", "yes", "on"}:
        return "1"
    if s in {"0", "false", "no", "off"}:
        return "0"
    raise ValueError(f"expected boolean-like value, got {value!r}")


def normalize_int_for_cfg(value: Any, *, min_val: int | None = None) -> str:
    try:
        n = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"expected integer, got {value!r}") from e
    if min_val is not None and n < min_val:
        raise ValueError(f"value must be >= {min_val}")
    return str(n)


def normalize_float_for_cfg(
    value: Any, *, min_val: float = 0.0, max_val: float = 1.0
) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"expected number, got {value!r}") from e
    x = max(min_val, min(max_val, x))
    return str(x)
