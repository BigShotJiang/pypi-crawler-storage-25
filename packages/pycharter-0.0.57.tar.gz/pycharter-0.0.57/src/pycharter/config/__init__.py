"""PyCharter config: env or pycharter.cfg; keys = env names (e.g. PYCHARTER_DATABASE_URL, PYCHARTER_AUTH_JWT_SECRET).

Re-exports auth helpers from ``pycharter.config.auth`` for backward compatibility.
"""

from __future__ import annotations

import os
from configparser import ConfigParser
from pathlib import Path

from pycharter.config._helpers import _cfg, find_config_file
from pycharter.config.auth import (
    get_auth_admin_group_claims,
    get_auth_admin_role_claims,
    get_auth_jwt_secret,
    get_auth_service_introspect_path,
    get_auth_service_url,
    get_auth_users,
    is_auth_disabled,
)
from pycharter.config.ports import API_PORT

_DB_ENV = "PYCHARTER_DATABASE_URL"

_API_ENV = "PYCHARTER_API_URL"
_DEFAULT_API_URL = f"http://localhost:{API_PORT}"


def get_api_url() -> str:
    """Backend API URL for ``pycharter ui serve|dev`` proxy. Env overrides pycharter.cfg ``[api]``."""
    url = os.getenv(_API_ENV)
    if url and url.strip():
        return url.strip().rstrip("/")
    from_cfg = _cfg("api", _API_ENV)
    if from_cfg and from_cfg.strip():
        return from_cfg.strip().rstrip("/")
    return _DEFAULT_API_URL.rstrip("/")


__all__ = [
    # API (UI proxy)
    "get_api_url",
    # Auth (re-exported from config.auth)
    "get_auth_admin_group_claims",
    "get_auth_admin_role_claims",
    "get_auth_jwt_secret",
    "get_auth_service_introspect_path",
    "get_auth_service_url",
    "get_auth_users",
    "is_auth_disabled",
    # Database
    "get_database_url",
    "set_database_url",
    # Generic
    "find_config_file",
    "get_config_variable",
    # UI
    "get_ui_app_name",
    "get_ui_theme",
]


def get_database_url() -> str | None:
    """Return database URL from env, pycharter.cfg, or alembic.ini.

    Resolution order: env PYCHARTER_DATABASE_URL (overrides file), then
    pycharter.cfg [database] PYCHARTER_DATABASE_URL, then alembic.ini.
    If you set Postgres in pycharter.cfg but the app uses SQLite, check
    that the env var is not set (or set it to your Postgres URL).
    """
    url = os.getenv(_DB_ENV)
    if url:
        return url.strip()
    url = _cfg("database", _DB_ENV)
    if url:
        return url
    path = find_config_file("alembic.ini")
    if path:
        cfg = ConfigParser()
        cfg.read(path)
        url = cfg.get("alembic", "sqlalchemy.url", fallback=None)
        if url and url != "driver://user:pass@localhost/dbname":
            return url
    return None


def set_database_url(database_url: str) -> None:
    """Set database URL as environment variable."""
    os.environ[_DB_ENV] = database_url


def get_config_variable(var_name: str, section: str = "variables") -> str | None:
    """Read from pycharter.cfg [section] by key (used for [variables], [etl])."""
    return _cfg(section, var_name)


# Named palettes use data-theme="<id>"; light/dark/system use :root + .dark only.
_VALID_UI_THEMES = (
    "light",
    "dark",
    "system",
    "ocean",
    "forest",
    "sunset",
    "high-contrast",
    "sepia",
    "violet",
    "evergreen",
)
_DEFAULT_UI_APP_NAME = "PyCharter"


def get_ui_theme() -> str:
    """Return UI theme: light, dark, or system. Env overrides .cfg. Default light."""
    raw = os.getenv("PYCHARTER_UI_THEME") or _cfg("ui", "PYCHARTER_UI_THEME") or ""
    value = raw.strip().lower()
    return value if value in _VALID_UI_THEMES else "light"


def get_ui_app_name() -> str:
    """Return UI app/website name. Env overrides .cfg. Default PyCharter."""
    raw = (
        os.getenv("PYCHARTER_UI_APP_NAME") or _cfg("ui", "PYCHARTER_UI_APP_NAME") or ""
    )
    return raw.strip() or _DEFAULT_UI_APP_NAME
