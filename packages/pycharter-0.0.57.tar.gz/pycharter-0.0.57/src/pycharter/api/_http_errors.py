"""HTTP error helpers: avoid leaking exception text to clients (CodeQL / disclosure)."""

from __future__ import annotations

import logging
import os
from typing import Never

from fastapi import HTTPException, status


def is_development_environment() -> bool:
    return os.environ.get("ENVIRONMENT", "").lower() == "development"


def internal_error_response_body(exc: BaseException) -> dict[str, str]:
    """JSON body for unhandled 500s: generic in production; optional detail in development."""
    body: dict[str, str] = {"error": "Internal server error"}
    if is_development_environment():
        body["message"] = str(exc)
        body["type"] = type(exc).__name__
    return body


def raise_logged_http_exception(
    logger: logging.Logger,
    exc: BaseException,
    *,
    status_code: int,
    public_detail: str,
    log_event: str,
) -> Never:
    """Log *exc* server-side and raise ``HTTPException`` with a fixed *public_detail*."""
    logger.exception("%s", log_event, exc_info=exc)
    raise HTTPException(status_code=status_code, detail=public_detail) from exc


def raise_logged_bad_request(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_400_BAD_REQUEST,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_not_found(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_404_NOT_FOUND,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_conflict(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_409_CONFLICT,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_unprocessable(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_forbidden(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_403_FORBIDDEN,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_service_unavailable(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        public_detail=public_detail,
        log_event=log_event,
    )


def raise_logged_internal(
    logger: logging.Logger,
    exc: BaseException,
    *,
    public_detail: str,
    log_event: str,
) -> Never:
    raise_logged_http_exception(
        logger,
        exc,
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        public_detail=public_detail,
        log_event=log_event,
    )
