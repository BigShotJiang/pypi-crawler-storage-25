"""REST request/response models for editorv2 universal search."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

SearchKindLiteral = str  # open enum; mirrors semantic.search.indexer.SearchKind


class SearchDocumentResponse(BaseModel):
    """A single result row for the Cmd+K palette."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(..., description="Globally unique document id.")
    kind: SearchKindLiteral = Field(
        ...,
        description="Document kind (concept, scheme, contract, pipeline, draft).",
    )
    title: str = Field(..., description="Display title shown in the palette.")
    subtitle: str | None = Field(
        default=None,
        description="Optional subtitle (e.g. concept type · tier).",
    )
    body: str | None = Field(
        default=None,
        description="Matched body text. Empty when the document has none.",
    )
    route: str | None = Field(
        default=None,
        description="Navigation target for a click-through.",
    )
    loaded: bool = Field(
        default=False,
        description="Whether the document is in the user's current workspace.",
    )


class SearchResultItem(BaseModel):
    """A scored search result row."""

    model_config = ConfigDict(extra="forbid")

    document: SearchDocumentResponse
    score: float
    matched_tokens: tuple[str, ...] = ()


class SearchSectionResponse(BaseModel):
    """A labeled section in the palette (e.g. 'Loaded' / 'Available')."""

    model_config = ConfigDict(extra="forbid")

    label: str
    results: tuple[SearchResultItem, ...]


class SearchResponse(BaseModel):
    """Response body for the search endpoint."""

    model_config = ConfigDict(extra="forbid")

    query: str
    sections: tuple[SearchSectionResponse, ...]
