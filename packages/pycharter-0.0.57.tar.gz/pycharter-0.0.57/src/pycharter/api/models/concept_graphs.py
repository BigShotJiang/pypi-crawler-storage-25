"""REST request/response models for editorv2 concept graph endpoints.

These models wrap the core
:class:`pycharter.semantic.concept_graph.models.ConceptGraph` and
:class:`pycharter.semantic.concept_graph.models.ConceptGraphDelta`
types for use on the HTTP boundary. The wrappers carry additional
HTTP-level fields (notably ``allow_core``) that do not belong on the
service-level domain types.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from pycharter.semantic.concept_graph.linkml_projection import (
    LinkMLEntity,
    LinkMLEnum,
    LinkMLProjection,
    LinkMLSlot,
)
from pycharter.semantic.concept_graph.models import (
    ConceptGraph,
    ConceptGraphDelta,
)

# =============================================================================
# LinkML projection wire shape
# =============================================================================
#
# These mirror the dataclasses in
# ``pycharter.semantic.concept_graph.linkml_projection`` so the
# Schema-mode canvas can read the projection without parsing the
# raw LinkML YAML on the client side. The dataclasses themselves
# stay frozen + slotted for performance and immutability; the
# Pydantic mirrors live here purely for the FastAPI/JSON boundary.


class LinkMLSlotResponse(BaseModel):
    """Wire shape for a single LinkML slot in the projection."""

    model_config = ConfigDict(extra="forbid")

    name: str
    range: str
    required: bool = False
    multivalued: bool = False
    description: str | None = None
    pattern: str | None = None
    is_identifier: bool = False
    relationship_type: str | None = None


class LinkMLEntityResponse(BaseModel):
    """Wire shape for a single projected LinkML class."""

    model_config = ConfigDict(extra="forbid")

    name: str
    concept_key: str
    concept_type: str
    description: str | None = None
    parent_class: str | None = None
    slots: tuple[LinkMLSlotResponse, ...] = ()
    is_abstract: bool = False


class LinkMLEnumResponse(BaseModel):
    """Wire shape for a single projected LinkML enum."""

    model_config = ConfigDict(extra="forbid")

    name: str
    concept_key: str
    description: str | None = None
    permissible_values: tuple[str, ...] = ()


class LinkMLProjectionResponse(BaseModel):
    """Wire shape for the full Schema-mode projection."""

    model_config = ConfigDict(extra="forbid")

    entities: tuple[LinkMLEntityResponse, ...] = ()
    enums: tuple[LinkMLEnumResponse, ...] = ()
    skipped: tuple[str, ...] = ()


def _slot_to_response(slot: LinkMLSlot) -> LinkMLSlotResponse:
    """Convert a LinkMLSlot dataclass to its wire shape."""
    return LinkMLSlotResponse(
        name=slot.name,
        range=slot.range,
        required=slot.required,
        multivalued=slot.multivalued,
        description=slot.description,
        pattern=slot.pattern,
        is_identifier=slot.is_identifier,
        relationship_type=slot.relationship_type,
    )


def _entity_to_response(entity: LinkMLEntity) -> LinkMLEntityResponse:
    """Convert a LinkMLEntity dataclass to its wire shape."""
    return LinkMLEntityResponse(
        name=entity.name,
        concept_key=entity.concept_key,
        concept_type=entity.concept_type,
        description=entity.description,
        parent_class=entity.parent_class,
        slots=tuple(_slot_to_response(s) for s in entity.slots),
        is_abstract=entity.is_abstract,
    )


def _enum_to_response(enum: LinkMLEnum) -> LinkMLEnumResponse:
    """Convert a LinkMLEnum dataclass to its wire shape."""
    return LinkMLEnumResponse(
        name=enum.name,
        concept_key=enum.concept_key,
        description=enum.description,
        permissible_values=enum.permissible_values,
    )


def linkml_projection_to_response(
    projection: LinkMLProjection,
) -> LinkMLProjectionResponse:
    """Convert a LinkMLProjection to its wire shape.

    Used by the editor-v2 GET and PUT handlers so the Schema canvas
    mode can render entities/slots/enums without re-running the
    projector on the client.
    """
    return LinkMLProjectionResponse(
        entities=tuple(_entity_to_response(e) for e in projection.entities),
        enums=tuple(_enum_to_response(e) for e in projection.enums),
        skipped=projection.skipped,
    )


# =============================================================================
# Binding projection wire shape
# =============================================================================


class BindingEdgeResponse(BaseModel):
    """Wire shape for a single cross-layer binding edge."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    field_path: str
    contract_id: str
    contract_version: str
    target_ontology: str
    target_concept_id: str
    target_concept_key: str
    target_concept_name: str
    kind: Literal["primary", "annotation"]
    relationship: str | None = None
    confidence: float | None = None
    tags: list[str] = Field(default_factory=list)


class BindingProjectionResponse(BaseModel):
    """Wire shape for the binding projection (edges + unresolved)."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    edges: list[BindingEdgeResponse] = Field(default_factory=list)
    unresolved_count: int = Field(
        default=0,
        description="Number of bindings that could not be resolved.",
    )
    failed_contracts: list[str] = Field(
        default_factory=list,
        description=(
            "Contract file paths that could not be loaded. Surfaced "
            "so the UI can warn the user instead of silently returning "
            "an incomplete projection."
        ),
    )


class ConceptGraphResponse(BaseModel):
    """Response payload for GET ``/editor-v2/concept-graphs/{scheme_id}``."""

    model_config = ConfigDict(extra="forbid")

    graph: ConceptGraph = Field(
        ...,
        description="The full concept graph for the requested scheme.",
    )
    linkml_projection: LinkMLProjectionResponse | None = Field(
        default=None,
        description=(
            "Schema-mode projection of the concept graph. Computed by "
            "``project_to_linkml(graph)`` and attached to every load "
            "and save response so the Schema canvas can render without "
            "a second round-trip."
        ),
    )
    binding_projection: BindingProjectionResponse | None = Field(
        default=None,
        description=(
            "Cross-layer binding edges from contracts to concepts. "
            "Populated when the ``with_contracts`` query parameter is "
            "set on the GET request."
        ),
    )


class ConceptGraphApplyDeltaRequest(BaseModel):
    """Request payload for PUT ``/editor-v2/concept-graphs/{scheme_id}``."""

    model_config = ConfigDict(extra="forbid")

    delta: ConceptGraphDelta = Field(
        ...,
        description="Batch of node and edge changes to apply.",
    )
    allow_core: bool = Field(
        default=False,
        description=(
            "When True, bypass the tier governance gate for core-tier "
            "concepts. Only set after a governance proposal has been "
            "approved."
        ),
    )


class ConceptGraphApplyDeltaResponse(BaseModel):
    """Response payload after applying a concept graph delta."""

    model_config = ConfigDict(extra="forbid")

    graph: ConceptGraph = Field(
        ...,
        description="The post-delta concept graph.",
    )
    linkml_projection: LinkMLProjectionResponse | None = Field(
        default=None,
        description=(
            "Schema-mode projection of the post-delta concept graph. "
            "Refreshed by the editor-v2 backend on every successful "
            "apply_delta so the Schema canvas always reflects the "
            "latest state without a follow-up GET."
        ),
    )


class ConceptGraphCreateRequest(BaseModel):
    """Request payload for POST ``/editor-v2/concept-graphs``.

    Creates a new (empty) concept scheme that the editor can
    immediately load. Mirrors the existing
    ``/api/v1/semantic/schemes`` POST shape but lives on the
    editor-v2 surface so the front-end has a single namespace and
    so the create call commits unambiguously.
    """

    model_config = ConfigDict(extra="forbid")

    scheme_key: str = Field(
        ...,
        description=(
            "Unique slug identifier (e.g. 'risk-domain'). "
            "Must be unique across the installation."
        ),
        min_length=1,
    )
    title: str = Field(
        ...,
        description="Human-readable scheme title.",
        min_length=1,
    )
    version: str = Field(
        default="0.1.0",
        description="Initial semver string for the scheme.",
    )
    description: str | None = Field(
        default=None,
        description="Free-form scheme description.",
    )
    base_uri: str | None = Field(
        default=None,
        description="Base URI used when generating RDF output.",
    )


# =============================================================================
# Validation report
# =============================================================================


class ValidationIssueResponse(BaseModel):
    """Wire shape for a single concept graph validation issue."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str = Field(
        ...,
        description="Stable issue identifier (kind:target_id).",
    )
    severity: Literal["error", "warning"] = Field(
        ...,
        description="Issue severity — error or warning.",
    )
    kind: str = Field(
        ...,
        description="Machine-readable issue kind tag.",
    )
    target_id: str = Field(
        ...,
        description="Id of the offending node or edge.",
    )
    node_name: str = Field(
        ...,
        description="Human-readable name of the target.",
    )
    message: str = Field(
        ...,
        description="Human-readable issue description.",
    )
    category: str = Field(
        ...,
        description="Issue category (completeness, structure, ...).",
    )


class ValidationReportResponse(BaseModel):
    """Wire shape for the full validation report."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    scheme_id: str = Field(
        ...,
        description="Scheme UUID the report applies to.",
    )
    issues: list[ValidationIssueResponse] = Field(
        default_factory=list,
        description="List of issues, possibly empty.",
    )
