"""REST request/response models for the editorv2 drafts endpoints."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from pycharter.semantic.drafts.models import (
    DraftPromotion,
    DraftSourceType,
    DraftVisibility,
)


class DraftCreateRequest(BaseModel):
    """Request body for POST /editor-v2/drafts."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(..., description="Human-readable draft name.")
    namespace: str | None = Field(
        default=None,
        description="Optional virtual folder namespace (slash-delimited).",
    )
    description: str | None = Field(
        default=None,
        description="Longer description of the draft's purpose.",
    )
    source_type: DraftSourceType = Field(
        ...,
        description="Kind of input the draft was created from.",
    )
    source_payload: str = Field(
        ...,
        description="The raw source (e.g. DDL text, pasted YAML).",
    )
    parsed_yaml: str = Field(
        ...,
        description="Structured YAML produced from the source_payload.",
    )
    visibility: DraftVisibility = Field(
        default=DraftVisibility.PRIVATE,
        description="Who can see this draft.",
    )
    team_id: str | None = Field(
        default=None,
        description="Owning team identifier (required when visibility=team).",
    )


class DraftUpdateRequest(BaseModel):
    """Request body for PATCH /editor-v2/drafts/{id}."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None)
    namespace: str | None = Field(default=None)
    description: str | None = Field(default=None)
    source_payload: str | None = Field(default=None)
    parsed_yaml: str | None = Field(default=None)
    visibility: DraftVisibility | None = Field(default=None)
    team_id: str | None = Field(default=None)


class DraftPromoteRequest(BaseModel):
    """Request body for POST /editor-v2/drafts/{id}/promote."""

    model_config = ConfigDict(extra="forbid")

    kind: str = Field(
        ...,
        description="Target artifact kind: 'contract' or 'ontology'.",
    )
    ref: str = Field(
        ...,
        description="Promoted artifact reference in 'name:version' form.",
    )


class DraftResponse(BaseModel):
    """Response payload for a single draft."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    namespace: str | None
    description: str | None
    source_type: DraftSourceType
    source_payload: str
    parsed_yaml: str
    visibility: DraftVisibility
    owner_id: str
    team_id: str | None
    created_at: datetime | None
    updated_at: datetime | None
    promotions: tuple[DraftPromotion, ...] = ()


class DraftListItem(BaseModel):
    """Lightweight summary used in list responses."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    namespace: str | None
    description: str | None
    source_type: DraftSourceType
    visibility: DraftVisibility
    owner_id: str
    team_id: str | None
    created_at: datetime | None
    updated_at: datetime | None
    is_archived: bool


class DraftListResponse(BaseModel):
    """Response payload for GET /editor-v2/drafts."""

    model_config = ConfigDict(extra="forbid")

    drafts: tuple[DraftListItem, ...]
    total: int
