"""Shared factory for store dependency injection.

Eliminates the duplication across contract, pipeline, and semantic
store dependencies. Each concrete dependency calls
``create_store_singleton`` with its backend map and settings.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, TypeVar

from fastapi import HTTPException, status

from pycharter.config import get_database_url

T = TypeVar("T")


def resolve_connection(
    store_type: str,
    connection_string: str | None,
) -> tuple[str, str | None]:
    """Auto-detect store type and connection string from env.

    Returns:
        (resolved_store_type, resolved_connection_string)
    """
    db_url = get_database_url()
    if db_url and not connection_string:
        if db_url.startswith(("postgresql://", "postgres://")):
            store_type = "postgres"
            connection_string = db_url
        elif db_url.startswith("sqlite://"):
            store_type = "sqlite"
            connection_string = db_url

    if store_type == "sqlite" and not connection_string:
        connection_string = f"sqlite:///{Path.cwd() / 'pycharter.db'}"
    elif store_type == "postgres" and not connection_string:
        connection_string = get_database_url()

    return store_type, connection_string


def create_store(
    store_type: str,
    connection_string: str | None,
    backends: dict[str, type],
    store_label: str,
) -> Any:
    """Create and connect a store instance.

    Args:
        store_type: Backend key (sqlite, postgres, in_memory, mongodb, redis).
        connection_string: Database URL (may be None for in_memory).
        backends: Mapping of backend key -> store class.
        store_label: Human label for error messages (e.g. "contract").

    Returns:
        Connected store instance.

    Raises:
        ValueError: Unknown store type.
        HTTPException: Connection failure.
    """
    resolved_type, resolved_conn = resolve_connection(store_type, connection_string)

    cls = backends.get(resolved_type)
    if cls is None:
        raise ValueError(f"Unsupported {store_label} store type: {resolved_type}")

    if resolved_type == "in_memory":
        instance = cls()
    else:
        if not resolved_conn:
            raise ValueError(
                f"connection_string required for {resolved_type} {store_label} store"
            )
        instance = cls(connection_string=resolved_conn)

    try:
        instance.connect()
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to initialize {store_label} store: {exc!s}",
        ) from exc

    return instance
