"""FastAPI dependency for the pipeline config store (singleton)."""

from __future__ import annotations

from pycharter.pipeline_store import (
    InMemoryPipelineStore,
    MongoDBPipelineStore,
    PipelineStoreClient,
    PostgresPipelineStore,
    RedisPipelineStore,
    SQLitePipelineStore,
)

from ._store_factory import create_store, resolve_connection

_BACKENDS: dict[str, type] = {
    "sqlite": SQLitePipelineStore,
    "postgres": PostgresPipelineStore,
    "in_memory": InMemoryPipelineStore,
    "mongodb": MongoDBPipelineStore,
    "redis": RedisPipelineStore,
}

_instance: PipelineStoreClient | None = None


def get_pipeline_store() -> PipelineStoreClient:
    """Get or create the singleton pipeline store."""
    global _instance  # noqa: PLW0603
    if _instance is None:
        store_type, conn = resolve_connection("sqlite", None)
        _instance = create_store(store_type, conn, _BACKENDS, "pipeline")
    return _instance
