"""FastAPI dependency for :class:`BindingLifecycle`.

Exposes the service as a process-wide singleton backed by
:class:`SqlBindingEventStore` so every request shares the same event
log and the log survives restarts.

A session factory is built on first use from the configured database
URL; the factory is reused for the lifetime of the process. Tests can
override ``get_binding_lifecycle`` via the standard FastAPI
``dependency_overrides`` mechanism.
"""

from __future__ import annotations

import logging
import threading
from typing import Any

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.config import get_database_url
from pycharter.semantic.lifecycle import (
    BindingLifecycle,
    ImplementsAsserter,
    SqlBindingEventStore,
)

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_lifecycle: BindingLifecycle | None = None
_session_factory: Any = None


def _build_session_factory() -> Any:
    """Create an SQLAlchemy ``sessionmaker`` bound to the configured engine."""
    db_url = get_database_url() or "sqlite:///pycharter.db"
    connect_args: dict[str, Any] = {}
    if db_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
    engine = create_engine(db_url, connect_args=connect_args)
    return sessionmaker(bind=engine, expire_on_commit=False)


def get_binding_lifecycle() -> BindingLifecycle:
    """Return the process-wide :class:`BindingLifecycle` singleton.

    Every APPROVED transition fires :class:`ImplementsAsserter`, which
    upserts a ``contract → concept`` relationship of type
    ``implements`` in the shared semantic store. This turns the
    lifecycle into the source of truth for which concepts a contract
    realises.
    """
    global _lifecycle, _session_factory  # noqa: PLW0603 — module-level singleton
    with _lock:
        if _lifecycle is None:
            _session_factory = _build_session_factory()
            store = SqlBindingEventStore(_session_factory)
            asserter = ImplementsAsserter(get_semantic_store())
            _lifecycle = BindingLifecycle(
                store=store,
                on_approve=asserter.on_approve,
            )
            logger.info(
                "initialised SQL-backed binding lifecycle + IMPLEMENTS asserter"
            )
    return _lifecycle
