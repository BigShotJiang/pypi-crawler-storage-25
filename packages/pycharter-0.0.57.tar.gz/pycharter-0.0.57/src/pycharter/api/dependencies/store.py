"""FastAPI dependency for the contract store (singleton)."""

from __future__ import annotations

from pycharter.contract_store import (
    ContractStoreClient,
    InMemoryContractStore,
    MongoDBContractStore,
    PostgresContractStore,
    RedisContractStore,
    SQLiteContractStore,
)

from ._store_factory import create_store, resolve_connection

_BACKENDS: dict[str, type] = {
    "sqlite": SQLiteContractStore,
    "postgres": PostgresContractStore,
    "in_memory": InMemoryContractStore,
    "mongodb": MongoDBContractStore,
    "redis": RedisContractStore,
}

_instance: ContractStoreClient | None = None


def get_contract_store() -> ContractStoreClient:
    """Get or create the singleton contract store."""
    global _instance  # noqa: PLW0603
    if _instance is None:
        store_type, conn = resolve_connection("sqlite", None)
        _instance = create_store(store_type, conn, _BACKENDS, "contract")
    return _instance
