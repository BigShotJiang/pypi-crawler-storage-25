"""FastAPI dependency for the semantic store (singleton)."""

from __future__ import annotations

from pycharter.semantic_store import (
    InMemorySemanticStore,
    PostgresSemanticStore,
    SemanticStoreClient,
    SQLiteSemanticStore,
)

from ._store_factory import create_store, resolve_connection

_BACKENDS: dict[str, type] = {
    "sqlite": SQLiteSemanticStore,
    "postgres": PostgresSemanticStore,
    "in_memory": InMemorySemanticStore,
}

_instance: SemanticStoreClient | None = None


def get_semantic_store() -> SemanticStoreClient:
    """Get or create the singleton semantic store."""
    global _instance  # noqa: PLW0603
    if _instance is None:
        store_type, conn = resolve_connection("sqlite", None)
        _instance = create_store(store_type, conn, _BACKENDS, "semantic")
    return _instance
