"""Knowledge graph API routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Query

logger = logging.getLogger(__name__)

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.semantic.knowledge.graph import KnowledgeGraph
from pycharter.semantic.shared.errors import GraphError

router = APIRouter(tags=["Semantic"])


@router.get("/concepts/{concept_id}/ancestors")
async def get_ancestors(
    concept_id: str,
    scheme_id: str | None = Query(default=None, description="Filter by scheme UUID"),
    session=Depends(get_db_session),
):
    """Get ancestor concepts, optionally scoped to a scheme."""
    try:
        kg = KnowledgeGraph(session)
        return kg.get_ancestors(concept_id, scheme_id=scheme_id)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/concepts/{concept_id}/descendants")
async def get_descendants(
    concept_id: str,
    scheme_id: str | None = Query(default=None, description="Filter by scheme UUID"),
    session=Depends(get_db_session),
):
    """Get descendant concepts, optionally scoped to a scheme."""
    try:
        kg = KnowledgeGraph(session)
        return kg.get_descendants(concept_id, scheme_id=scheme_id)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/concepts/tree")
async def get_concept_tree(
    concept_type: str | None = None,
    scheme_id: str | None = Query(default=None, description="Filter by scheme UUID"),
    session=Depends(get_db_session),
):
    """Get the full concept hierarchy tree, optionally filtered by concept_type and scheme."""
    try:
        kg = KnowledgeGraph(session)
        tree = kg.get_concept_tree(scheme_id=scheme_id)
        if concept_type is None:
            return tree

        # Filter roots and children by concept_type
        def filter_by_type(nodes: list) -> list:
            result = []
            for node in nodes:
                children = filter_by_type(node.get("children", []))
                if node.get("concept_type") == concept_type or children:
                    filtered = {**node, "children": children}
                    result.append(filtered)
            return result

        return {"roots": filter_by_type(tree.get("roots", []))}
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/concepts/{concept_id}/fields")
async def get_related_fields(concept_id: str, session=Depends(get_db_session)):
    """Get fields related to a concept."""
    try:
        kg = KnowledgeGraph(session)
        return kg.find_related_fields(concept_id)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/concepts/by-name/{concept_name}/fields")
async def get_fields_for_concept(concept_name: str, session=Depends(get_db_session)):
    """Get fields for a concept by name."""
    try:
        kg = KnowledgeGraph(session)
        return kg.get_fields_for_concept(concept_name)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )
