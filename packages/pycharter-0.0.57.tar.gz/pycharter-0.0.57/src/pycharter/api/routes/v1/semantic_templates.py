"""Domain template API routes for the Knowledge Base builder.

Provides endpoints for listing, loading, and instantiating
domain templates and modeling patterns.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_not_found
from pycharter.semantic.shared.errors import OntologyError
from pycharter.semantic.templates.engine import (
    get_builtin_template,
    list_builtin_templates,
)
from pycharter.semantic.templates.parser import (
    parse_concept_list,
    parse_domain_description,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/semantic/templates", tags=["Templates"])


@router.get("/")
async def list_templates() -> list[dict[str, Any]]:
    """List all available domain templates."""
    return list_builtin_templates()


@router.get("/{template_id}")
async def get_template(template_id: str) -> dict[str, Any]:
    """Get a specific domain template by ID."""
    try:
        template = get_builtin_template(template_id)
        return template.to_dict()
    except OntologyError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )


class NLParseRequest(BaseModel):
    """Request to parse natural language into concepts."""

    text: str = Field(..., description="Domain description or concept list")
    mode: str = Field("description", description="'description' or 'list'")


@router.post("/parse-nl")
async def parse_natural_language(request: NLParseRequest) -> dict[str, Any]:
    """Parse natural language into concept suggestions.

    Supports two modes:
    - 'description': Parse a full domain description
    - 'list': Parse a comma/newline-separated list of concept names
    """
    if request.mode == "list":
        concepts = parse_concept_list(request.text)
        return {"concepts": concepts, "relationships": []}

    result = parse_domain_description(request.text)
    return result.to_dict()
