"""Route handlers for metadata entity CRUD (owners, domains, systems, etc.)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, status

logger = logging.getLogger(__name__)

from sqlalchemy.orm import Session

from pycharter.api._http_errors import raise_logged_bad_request, raise_logged_not_found
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.models.metadata_entities import (
    DomainCreateRequest,
    DomainUpdateRequest,
    EnvironmentCreateRequest,
    EnvironmentUpdateRequest,
    OwnerCreateRequest,
    OwnerUpdateRequest,
    StorageLocationCreateRequest,
    StorageLocationUpdateRequest,
    SystemCreateRequest,
    SystemUpdateRequest,
    TagCreateRequest,
    TagUpdateRequest,
)
from pycharter.api.services import metadata_service as svc
from pycharter.db.models import (
    DomainModel,
    EnvironmentModel,
    OwnerModel,
    StorageLocationModel,
    SystemModel,
    TagModel,
)

router = APIRouter(tags=["Metadata"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _handle_create(
    model_class: type,
    data: Any,
    db: Session,
    *,
    unique_field: str = "name",
) -> dict[str, Any]:
    """Map service exceptions to HTTP errors for entity creation."""
    try:
        return svc.create_entity(model_class, data, db, unique_field=unique_field)
    except svc.DuplicateEntityError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


def _handle_update(
    model_class: type,
    entity_id: str,
    data: Any,
    db: Session,
    *,
    entity_label: str | None = None,
    validate_uuid: bool = True,
) -> dict[str, Any]:
    """Map service exceptions to HTTP errors for entity updates."""
    try:
        return svc.update_entity(
            model_class,
            entity_id,
            data,
            db,
            entity_label=entity_label,
            validate_uuid=validate_uuid,
        )
    except svc.InvalidIdFormatError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Request could not be completed",
            log_event="route failed",
        )
    except svc.EntityNotFoundError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )


# ---------------------------------------------------------------------------
# Create endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/metadata/owners",
    status_code=status.HTTP_201_CREATED,
    summary="Create owner",
    description="Create a new owner",
    response_description="Created owner",
)
async def create_owner(
    request: OwnerCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new owner."""
    return _handle_create(OwnerModel, request, db, unique_field="id")


@router.post(
    "/metadata/domains",
    status_code=status.HTTP_201_CREATED,
    summary="Create domain",
    description="Create a new domain",
    response_description="Created domain",
)
async def create_domain(
    request: DomainCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new domain."""
    return _handle_create(DomainModel, request, db)


@router.post(
    "/metadata/systems",
    status_code=status.HTTP_201_CREATED,
    summary="Create system",
    description="Create a new system",
    response_description="Created system",
)
async def create_system(
    request: SystemCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new system."""
    return _handle_create(SystemModel, request, db)


@router.post(
    "/metadata/environments",
    status_code=status.HTTP_201_CREATED,
    summary="Create environment",
    description="Create a new environment",
    response_description="Created environment",
)
async def create_environment(
    request: EnvironmentCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new environment."""
    return _handle_create(EnvironmentModel, request, db)


@router.post(
    "/metadata/storage_locations",
    status_code=status.HTTP_201_CREATED,
    summary="Create storage location",
    description="Create a new storage location",
    response_description="Created storage location",
)
async def create_storage_location(
    request: StorageLocationCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new storage location."""
    return _handle_create(StorageLocationModel, request, db)


@router.post(
    "/metadata/tags",
    status_code=status.HTTP_201_CREATED,
    summary="Create tag",
    description="Create a new tag",
    response_description="Created tag",
)
async def create_tag(
    request: TagCreateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Create a new tag."""
    return _handle_create(TagModel, request, db)


# ---------------------------------------------------------------------------
# Update endpoints
# ---------------------------------------------------------------------------


@router.put(
    "/metadata/owners/{owner_id}",
    status_code=status.HTTP_200_OK,
    summary="Update owner",
    description="Update an existing owner",
    response_description="Updated owner",
)
async def update_owner(
    owner_id: str,
    request: OwnerUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing owner."""
    return _handle_update(
        OwnerModel,
        owner_id,
        request,
        db,
        entity_label="Owner",
        validate_uuid=False,
    )


@router.put(
    "/metadata/domains/{domain_id}",
    status_code=status.HTTP_200_OK,
    summary="Update domain",
    description="Update an existing domain",
    response_description="Updated domain",
)
async def update_domain(
    domain_id: str,
    request: DomainUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing domain."""
    return _handle_update(DomainModel, domain_id, request, db, entity_label="Domain")


@router.put(
    "/metadata/systems/{system_id}",
    status_code=status.HTTP_200_OK,
    summary="Update system",
    description="Update an existing system",
    response_description="Updated system",
)
async def update_system(
    system_id: str,
    request: SystemUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing system."""
    return _handle_update(SystemModel, system_id, request, db, entity_label="System")


@router.put(
    "/metadata/environments/{environment_id}",
    status_code=status.HTTP_200_OK,
    summary="Update environment",
    description="Update an existing environment",
    response_description="Updated environment",
)
async def update_environment(
    environment_id: str,
    request: EnvironmentUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing environment."""
    return _handle_update(
        EnvironmentModel, environment_id, request, db, entity_label="Environment"
    )


@router.put(
    "/metadata/storage_locations/{storage_location_id}",
    status_code=status.HTTP_200_OK,
    summary="Update storage location",
    description="Update an existing storage location",
    response_description="Updated storage location",
)
async def update_storage_location(
    storage_location_id: str,
    request: StorageLocationUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing storage location."""
    return _handle_update(
        StorageLocationModel,
        storage_location_id,
        request,
        db,
        entity_label="StorageLocation",
    )


@router.put(
    "/metadata/tags/{tag_id}",
    status_code=status.HTTP_200_OK,
    summary="Update tag",
    description="Update an existing tag",
    response_description="Updated tag",
)
async def update_tag(
    tag_id: str,
    request: TagUpdateRequest,
    db: Session = Depends(get_db_session),
) -> dict[str, Any]:
    """Update an existing tag."""
    return _handle_update(TagModel, tag_id, request, db, entity_label="Tag")
