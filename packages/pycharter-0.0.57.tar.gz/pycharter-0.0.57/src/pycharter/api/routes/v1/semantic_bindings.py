"""Binding lifecycle HTTP routes.

Exposes the :class:`pycharter.semantic.lifecycle.BindingLifecycle`
service so UIs can render binding history, initiate transitions, and
query current state without embedding the service in-process.

Endpoints:

- ``GET /bindings/events`` — list events, optionally filtered by
  contract / field / concept.
- ``GET /bindings/state`` — current state for a single binding triple.
- ``POST /bindings/transitions`` — initiate a transition (typically
  driven by a "promote" / "reject" button in the KB review UI).
"""

from __future__ import annotations

import logging
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies.lifecycle import get_binding_lifecycle
from pycharter.semantic.lifecycle import (
    BindingEvent,
    BindingLifecycle,
    BindingLifecycleError,
    BindingState,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Bindings"])


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


class BindingEventResponse(BaseModel):
    """Serialised :class:`BindingEvent`."""

    contract_id: str
    field_path: str
    concept_id: str
    from_state: BindingState
    to_state: BindingState
    actor: str
    reason: str
    timestamp: datetime

    @classmethod
    def from_event(cls, event: BindingEvent) -> BindingEventResponse:
        """Convert a domain :class:`BindingEvent` to the wire format."""
        return cls(
            contract_id=event.contract_id,
            field_path=event.field_path,
            concept_id=event.concept_id,
            from_state=event.from_state,
            to_state=event.to_state,
            actor=event.actor,
            reason=event.reason,
            timestamp=event.timestamp,
        )


class BindingStateResponse(BaseModel):
    """Response body for GET /bindings/state."""

    contract_id: str
    field_path: str
    concept_id: str
    state: BindingState


class TransitionRequest(BaseModel):
    """Request body for POST /bindings/transitions."""

    contract_id: str
    field_path: str
    concept_id: str
    to_state: BindingState
    actor: str
    reason: str = Field(default="", max_length=4096)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/events", response_model=list[BindingEventResponse])
def list_events(
    contract_id: str | None = Query(default=None),
    field_path: str | None = Query(default=None),
    concept_id: str | None = Query(default=None),
    lifecycle: BindingLifecycle = Depends(get_binding_lifecycle),
) -> list[BindingEventResponse]:
    """List binding lifecycle events, optionally filtered."""
    events = lifecycle.events(
        contract_id=contract_id,
        field_path=field_path,
        concept_id=concept_id,
    )
    return [BindingEventResponse.from_event(event) for event in events]


@router.get("/state", response_model=BindingStateResponse)
def get_state(
    contract_id: str = Query(...),
    field_path: str = Query(...),
    concept_id: str = Query(...),
    lifecycle: BindingLifecycle = Depends(get_binding_lifecycle),
) -> BindingStateResponse:
    """Return the current state of a binding triple."""
    state = lifecycle.state(contract_id, field_path, concept_id)
    return BindingStateResponse(
        contract_id=contract_id,
        field_path=field_path,
        concept_id=concept_id,
        state=state,
    )


@router.post("/transitions", response_model=BindingEventResponse, status_code=201)
def create_transition(
    request: TransitionRequest,
    lifecycle: BindingLifecycle = Depends(get_binding_lifecycle),
) -> BindingEventResponse:
    """Initiate a binding transition and record it as an event."""
    try:
        event = lifecycle.transition(
            contract_id=request.contract_id,
            field_path=request.field_path,
            concept_id=request.concept_id,
            to_state=request.to_state,
            actor=request.actor,
            reason=request.reason,
        )
    except BindingLifecycleError as exc:
        logger.info("illegal binding transition: %s", exc)
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Request could not be completed",
            log_event="route failed",
        )
    return BindingEventResponse.from_event(event)
