"""Definition drafting API route for the Knowledge Base builder.

Generates AI-powered first-draft definitions for concepts using
the configured LLM provider.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from pycharter.semantic.ai.config import get_kb_config
from pycharter.semantic.ai.provider import create_provider
from pycharter.semantic.ai.suggestion_pipeline import SuggestionPipeline

router = APIRouter(prefix="/semantic/definitions", tags=["Definitions"])


class DraftDefinitionRequest(BaseModel):
    """Request to draft a definition for a concept."""

    concept_name: str = Field(..., description="Name of the concept")
    mapped_tables: list[str] = Field(
        default_factory=list, description="Names of mapped tables"
    )
    column_names: list[str] = Field(
        default_factory=list, description="Related column names"
    )


class DraftDefinitionResponse(BaseModel):
    """Response with AI-drafted definition."""

    definition: str | None = None
    confidence: dict[str, Any] | None = None
    provider: str = "noop"


@router.post("/draft", response_model=DraftDefinitionResponse)
async def draft_definition(
    request: DraftDefinitionRequest,
) -> DraftDefinitionResponse:
    """Generate an AI-powered draft definition for a concept.

    Uses the configured AI provider (set via PYCHARTER_KB_AI_PROVIDER_TYPE).
    Returns null definition if no provider is configured (noop mode).
    """
    config = get_kb_config()

    try:
        provider = create_provider(config.ai_provider_type)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to initialize AI provider: {exc}",
        )

    pipeline = SuggestionPipeline(provider=provider, config=config)

    context = {
        "mapped_tables": request.mapped_tables,
        "column_names": request.column_names,
    }

    suggestion = pipeline.draft_definition(
        concept_name=request.concept_name,
        context=context,
    )

    if suggestion is None:
        return DraftDefinitionResponse(
            definition=None,
            provider=provider.name,
        )

    return DraftDefinitionResponse(
        definition=suggestion.details.get("definition"),
        confidence=suggestion.confidence.to_dict() if suggestion.confidence else None,
        provider=provider.name,
    )
