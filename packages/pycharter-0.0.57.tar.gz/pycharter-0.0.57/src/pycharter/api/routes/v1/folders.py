# TODO(maintainability): This file is 504 lines (limit: 400). Split into smaller modules.
"""Route handlers for editor folder operations.

Provides a generic, self-contained virtual file system API.  Folders
are organised by *folder_type* (e.g. ``'contract'``, ``'ontology'``) and
items are linked via the ``editor_folder_items`` join table so no
domain tables need modification.

When a :class:`~pycharter.api.services._folder_helpers.UnfiledItemResolver`
is registered, items that haven't been filed into any folder are surfaced
automatically as root-level nodes in the tree response.
"""

from __future__ import annotations

import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.folder_resolvers import get_unfiled_resolver
from pycharter.api.models.folders import (
    FolderCreate,
    FolderEnsurePathRequest,
    FolderEnsurePathResponse,
    FolderItemAssignRequest,
    FolderItemRemoveRequest,
    FolderResponse,
    FolderTreeResponse,
    FolderUpdate,
)
from pycharter.api.services._folder_helpers import (
    UnfiledItemResolver,
    build_tree,
    check_circular,
    folder_to_response,
)
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.editor_folder import (
    EditorFolderItemModel,
    EditorFolderModel,
)
from pycharter.db.models.pipeline_config import PipelineConfigModel
from pycharter.shared.name_validator import normalize_name

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Folders"])


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/folders/tree", response_model=FolderTreeResponse)
def get_folder_tree(
    folder_type: str = Query(..., alias="type", description="Root type"),
    db: Session = Depends(get_db_session),
    resolve_unfiled: UnfiledItemResolver | None = Depends(get_unfiled_resolver),
) -> FolderTreeResponse:
    """Return the full folder tree for a given type.

    When an unfiled-item resolver is registered, items that have not been
    assigned to any folder are automatically included as root-level nodes.
    """
    folders = (
        db.query(EditorFolderModel)
        .filter(EditorFolderModel.folder_type == folder_type)
        .all()
    )

    items = (
        db.query(EditorFolderItemModel)
        .filter(EditorFolderItemModel.item_type == folder_type)
        .all()
    )
    roots = build_tree(folders, items, folder_type)

    # Pluggable hook: append unfiled items from the domain layer
    if resolve_unfiled is not None:
        filed_ids = {item.item_id for item in items}
        unfiled = resolve_unfiled(db, filed_ids, folder_type)
        if unfiled:
            roots = [*roots, *unfiled]

    return FolderTreeResponse(folder_type=folder_type, roots=roots)


@router.post(
    "/folders",
    response_model=FolderResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_folder(
    body: FolderCreate,
    db: Session = Depends(get_db_session),
) -> FolderResponse:
    """Create a new folder."""
    parent_uuid = uuid.UUID(body.parent_id) if body.parent_id else None

    if parent_uuid:
        parent = db.get(EditorFolderModel, parent_uuid)
        if not parent:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Parent folder not found")
        if parent.folder_type != body.folder_type:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "Parent folder belongs to a different type",
            )

    # Duplicate-name check (app-level for SQLite NULL handling)
    existing = (
        db.query(EditorFolderModel)
        .filter(
            EditorFolderModel.parent_id == parent_uuid,
            EditorFolderModel.name == body.name,
            EditorFolderModel.folder_type == body.folder_type,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"A folder named '{body.name}' already exists here",
        )

    folder = EditorFolderModel(
        id=uuid.uuid4(),
        name=body.name,
        parent_id=parent_uuid,
        folder_type=body.folder_type,
        position=0,
    )
    db.add(folder)
    db.commit()
    db.refresh(folder)
    logger.info("Created folder %s (%s)", folder.name, folder.folder_type)
    return folder_to_response(folder)


@router.put("/folders/{folder_id}", response_model=FolderResponse)
def update_folder(
    folder_id: str,
    body: FolderUpdate,
    db: Session = Depends(get_db_session),
) -> FolderResponse:
    """Rename, move, or reorder a folder."""
    folder = db.get(EditorFolderModel, uuid.UUID(folder_id))
    if not folder:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Folder not found")

    if body.name is not None:
        folder.name = body.name

    if body.parent_id is not None:
        new_parent = uuid.UUID(body.parent_id) if body.parent_id else None
        if check_circular(db, folder.id, new_parent):
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST, "Move would create a circular reference"
            )
        folder.parent_id = new_parent

    if body.position is not None:
        folder.position = body.position

    db.commit()
    db.refresh(folder)
    logger.info("Updated folder %s", folder.name)
    return folder_to_response(folder)


@router.delete("/folders/{folder_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_folder(
    folder_id: str,
    db: Session = Depends(get_db_session),
) -> None:
    """Delete a folder and all its subfolders.  Items are unlinked."""
    folder = db.get(EditorFolderModel, uuid.UUID(folder_id))
    if not folder:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Folder not found")
    name = folder.name
    db.delete(folder)
    db.commit()
    logger.info("Deleted folder %s", name)


@router.post(
    "/folders/ensure-path",
    response_model=FolderEnsurePathResponse,
    status_code=status.HTTP_200_OK,
)
def ensure_folder_path(
    body: FolderEnsurePathRequest,
    db: Session = Depends(get_db_session),
) -> FolderEnsurePathResponse:
    """Walk a slash-separated path, creating any missing folders.

    Each segment is resolved by name under the current parent. Existing
    folders are reused; missing ones are created.  Returns the leaf
    folder ID so callers can assign items into it immediately.
    """
    segments = [s.strip() for s in body.path.split("/") if s.strip()]
    if not segments:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Path must contain at least one non-empty segment",
        )

    parent_id: uuid.UUID | None = None
    created: list[str] = []

    for segment in segments:
        existing = (
            db.query(EditorFolderModel)
            .filter(
                EditorFolderModel.parent_id == parent_id,
                EditorFolderModel.name == segment,
                EditorFolderModel.folder_type == body.folder_type,
            )
            .first()
        )
        if existing:
            parent_id = existing.id
        else:
            folder = EditorFolderModel(
                id=uuid.uuid4(),
                name=segment,
                parent_id=parent_id,
                folder_type=body.folder_type,
                position=0,
            )
            db.add(folder)
            db.flush()
            parent_id = folder.id
            created.append(segment)

    db.commit()

    normalised_path = "/".join(segments)
    if created:
        logger.info(
            "Ensured path '%s' (%s) — created: %s",
            normalised_path,
            body.folder_type,
            ", ".join(created),
        )

    return FolderEnsurePathResponse(
        folder_id=str(parent_id),
        path=normalised_path,
        created=created,
    )


# ---------------------------------------------------------------------------
# One-time migration: DB folders -> config-derived namespaces
# ---------------------------------------------------------------------------


def _folder_path_by_id(
    folders: dict[uuid.UUID, EditorFolderModel],
    folder_id: uuid.UUID,
) -> list[str]:
    parts: list[str] = []
    cur: uuid.UUID | None = folder_id
    visited: set[uuid.UUID] = set()
    while cur is not None:
        if cur in visited:
            break
        visited.add(cur)
        f = folders.get(cur)
        if f is None:
            break
        parts.append(f.name)
        cur = f.parent_id
    return list(reversed(parts))


@router.post(
    "/folders/migrate-to-namespaces",
    response_model=dict,
    status_code=status.HTTP_200_OK,
)
def migrate_folder_assignments_to_namespaces(
    db: Session = Depends(get_db_session),
) -> dict:
    """One-time migration helper.

    Copies existing editor folder assignments into each item's config-defined
    namespace field, so the new virtual-tree approach matches the old UI layout.

    Notes:
    - Contracts: namespace is stored under metadata_record.payload["namespace"].
    - Pipelines: namespace is stored under pipeline_config.settings["meta"]["namespace"].
    """
    folder_rows = db.query(EditorFolderModel).all()
    folders: dict[uuid.UUID, EditorFolderModel] = {f.id: f for f in folder_rows}

    item_rows = db.query(EditorFolderItemModel).all()

    # item_key -> chosen namespace (prefer deepest path; tie-break lexicographically)
    chosen: dict[tuple[str, str], str] = {}
    conflicts: list[dict[str, str]] = []
    skipped: list[dict[str, str]] = []

    for item in item_rows:
        if item.folder_id is None:
            continue

        raw_parts = _folder_path_by_id(folders, item.folder_id)
        normalized_parts: list[str] = []
        bad = False
        for p in raw_parts:
            nn = normalize_name(p)
            if not nn:
                skipped.append(
                    {
                        "reason": "invalid_folder_segment",
                        "folder_type": item.item_type,
                        "item_id": item.item_id,
                        "segment": p,
                    }
                )
                bad = True
                break
            normalized_parts.append(nn)
        if bad:
            continue

        ns = "/".join([p for p in normalized_parts if p])
        if not ns:
            continue

        key = (item.item_type, item.item_id)
        prev = chosen.get(key)
        if prev is None:
            chosen[key] = ns
            continue

        if prev != ns:
            winner = prev
            if (ns.count("/") > prev.count("/")) or (
                ns.count("/") == prev.count("/") and ns < prev
            ):
                winner = ns
            chosen[key] = winner
            conflicts.append(
                {
                    "folder_type": item.item_type,
                    "item_id": item.item_id,
                    "namespace_a": prev,
                    "namespace_b": ns,
                    "chosen": winner,
                }
            )

    updated_contracts = 0
    updated_pipelines = 0
    missing: list[dict[str, str]] = []

    for (item_type, item_id), ns in chosen.items():
        if item_type == "contract":
            try:
                cid = uuid.UUID(item_id)
            except ValueError:
                skipped.append(
                    {
                        "reason": "invalid_uuid_item_id",
                        "folder_type": item_type,
                        "item_id": item_id,
                    }
                )
                continue
            contract = db.get(DataContractModel, cid)
            if not contract:
                missing.append(
                    {"folder_type": item_type, "item_id": item_id, "namespace": ns}
                )
                continue
            mr = contract.metadata_record
            if mr is None:
                skipped.append(
                    {
                        "reason": "missing_metadata_record",
                        "folder_type": item_type,
                        "item_id": item_id,
                    }
                )
                continue
            payload = mr.payload if isinstance(mr.payload, dict) else {}
            payload = dict(payload)
            payload["namespace"] = ns
            mr.payload = payload
            updated_contracts += 1
        elif item_type == "pipeline":
            try:
                pid = uuid.UUID(item_id)
            except ValueError:
                skipped.append(
                    {
                        "reason": "invalid_uuid_item_id",
                        "folder_type": item_type,
                        "item_id": item_id,
                    }
                )
                continue
            row = db.get(PipelineConfigModel, pid)
            if not row:
                missing.append(
                    {"folder_type": item_type, "item_id": item_id, "namespace": ns}
                )
                continue
            settings = row.settings if isinstance(row.settings, dict) else {}
            settings = dict(settings)
            meta = settings.get("meta")
            meta = dict(meta) if isinstance(meta, dict) else {}
            meta["namespace"] = ns
            settings["meta"] = meta
            row.settings = settings
            updated_pipelines += 1
        else:
            skipped.append(
                {
                    "reason": "unsupported_folder_type",
                    "folder_type": item_type,
                    "item_id": item_id,
                }
            )

    db.commit()

    return {
        "updated": {
            "contracts": updated_contracts,
            "pipelines": updated_pipelines,
        },
        "conflicts": conflicts,
        "skipped": skipped,
        "missing": missing,
    }


@router.put("/folders/{folder_id}/items", response_model=dict)
def assign_items(
    folder_id: str,
    body: FolderItemAssignRequest,
    db: Session = Depends(get_db_session),
) -> dict:
    """Assign items into a folder (upsert — moves if already assigned)."""
    folder = db.get(EditorFolderModel, uuid.UUID(folder_id))
    if not folder:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Folder not found")

    moved = 0
    for item_input in body.items:
        existing = (
            db.query(EditorFolderItemModel)
            .filter(
                EditorFolderItemModel.item_type == item_input.item_type,
                EditorFolderItemModel.item_id == item_input.item_id,
            )
            .first()
        )
        if existing:
            existing.folder_id = folder.id
            existing.item_label = item_input.item_label or existing.item_label
            existing.item_meta = item_input.item_meta or existing.item_meta
        else:
            db.add(
                EditorFolderItemModel(
                    id=uuid.uuid4(),
                    folder_id=folder.id,
                    item_type=item_input.item_type,
                    item_id=item_input.item_id,
                    item_label=item_input.item_label,
                    item_meta=item_input.item_meta,
                )
            )
        moved += 1

    db.commit()
    logger.info("Assigned %d items to folder %s", moved, folder.name)
    return {"moved": moved}


@router.post("/folders/{folder_id}/items/remove", response_model=dict)
def remove_items(
    folder_id: str,
    body: FolderItemRemoveRequest,
    db: Session = Depends(get_db_session),
) -> dict:
    """Remove (unfile) items from a folder."""
    removed = (
        db.query(EditorFolderItemModel)
        .filter(
            EditorFolderItemModel.folder_id == uuid.UUID(folder_id),
            EditorFolderItemModel.item_id.in_(body.item_ids),
        )
        .delete(synchronize_session="fetch")
    )
    db.commit()
    logger.info("Removed %d items from folder %s", removed, folder_id)
    return {"removed": removed}
