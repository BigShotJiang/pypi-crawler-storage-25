"""Reconciliation API routes for the Knowledge Base builder.

Provides endpoints for matching imported schemas against existing
concepts and generating reconciliation proposals.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from pycharter.semantic.reconciliation.matcher import generate_reconciliation_matches

router = APIRouter(prefix="/reconciliation", tags=["Reconciliation"])


class ReconciliationRequest(BaseModel):
    """Request to generate reconciliation matches."""

    table_names: list[str] = Field(..., description="Names of imported tables")
    existing_concepts: list[str] = Field(
        default_factory=list, description="Names of existing concepts"
    )
    threshold: float = Field(0.5, description="Minimum match confidence")


class ReconciliationMatchResponse(BaseModel):
    """A single reconciliation match proposal."""

    table_name: str
    suggested_concept: str | None = None
    new_concept_name: str = ""
    action: str = "create"
    confidence: dict[str, Any] | None = None


@router.post("/match", response_model=list[ReconciliationMatchResponse])
async def match_tables_to_concepts(
    request: ReconciliationRequest,
) -> list[ReconciliationMatchResponse]:
    """Generate reconciliation matches for imported tables.

    For each table, proposes the best matching existing concept
    or suggests creating a new one.
    """
    matches = generate_reconciliation_matches(
        table_names=request.table_names,
        existing_concepts=request.existing_concepts,
        threshold=request.threshold,
    )
    return [
        ReconciliationMatchResponse(
            table_name=m.table_name,
            suggested_concept=m.suggested_concept,
            new_concept_name=m.new_concept_name,
            action=m.action,
            confidence=m.confidence.to_dict() if m.confidence else None,
        )
        for m in matches
    ]
