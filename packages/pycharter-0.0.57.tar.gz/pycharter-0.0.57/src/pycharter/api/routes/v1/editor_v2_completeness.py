"""FastAPI routes for editorv2 completeness metrics."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session

from pycharter.api._http_errors import (
    raise_logged_not_found,
)
from pycharter.api.dependencies.database import get_db_session
from pycharter.semantic.completeness import (
    OntologyCompleteness,
    ontology_completeness,
)
from pycharter.semantic.concept_graph import ConceptGraphService
from pycharter.semantic.concept_graph.sqlalchemy_repository import (
    SqlAlchemyConceptGraphRepository,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor v2 Completeness"])


class OntologyCompletenessResponse(BaseModel):
    """Response wrapper for the ontology completeness endpoint."""

    model_config = ConfigDict(extra="forbid")

    scheme_id: str
    total_concepts: int
    total_relationships: int
    concepts_with_definitions: int
    concepts_with_descriptions_ratio: float
    concepts_by_tier: dict[str, int]
    tier_ratios: dict[str, float]
    concepts_with_concept_type: int
    concept_type_ratio: float
    deprecated_concepts: int
    deprecated_ratio: float


def _to_response(
    metrics: OntologyCompleteness,
) -> OntologyCompletenessResponse:
    """Convert OntologyCompleteness to its REST response shape."""
    return OntologyCompletenessResponse(
        scheme_id=metrics.scheme_id,
        total_concepts=metrics.total_concepts,
        total_relationships=metrics.total_relationships,
        concepts_with_definitions=metrics.concepts_with_definitions,
        concepts_with_descriptions_ratio=metrics.concepts_with_descriptions_ratio,
        concepts_by_tier=dict(metrics.concepts_by_tier),
        tier_ratios=dict(metrics.tier_ratios),
        concepts_with_concept_type=metrics.concepts_with_concept_type,
        concept_type_ratio=metrics.concept_type_ratio,
        deprecated_concepts=metrics.deprecated_concepts,
        deprecated_ratio=metrics.deprecated_ratio,
    )


@router.get(
    "/editor-v2/completeness/ontology/{scheme_id}",
    response_model=OntologyCompletenessResponse,
    summary="Compute completeness metrics for an ontology scheme",
)
async def get_ontology_completeness(
    scheme_id: str,
    session: Session = Depends(get_db_session),
) -> OntologyCompletenessResponse:
    """Return ontology coverage metrics for the completeness panel."""
    service = ConceptGraphService(SqlAlchemyConceptGraphRepository(session))
    try:
        graph = service.get_graph(scheme_id)
    except KeyError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )
    metrics = ontology_completeness(graph)
    return _to_response(metrics)
