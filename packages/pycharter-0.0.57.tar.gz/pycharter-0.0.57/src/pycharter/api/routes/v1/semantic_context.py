"""Agent-facing knowledge-base context pack endpoint.

Serves a token-budgeted :class:`ContextPack` JSON payload so LLM agents
can reason about a concept's neighbourhood in far fewer tokens than
the raw relational or contract representation would require. Wraps
:func:`pycharter.semantic.knowledge.context.build_context_pack` and
does no business logic of its own.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.concept_graph.sqlalchemy_repository import (
    SqlAlchemyConceptGraphRepository,
)
from pycharter.semantic.knowledge.context import build_context_pack

router = APIRouter(tags=["Semantic - Context"])
logger = logging.getLogger(__name__)


@router.get("")
async def get_context_pack(
    scheme_id: str = Query(
        ...,
        description="UUID or scheme_key of the concept scheme to draw from.",
    ),
    concept: str = Query(
        ...,
        description="concept_key of the anchor concept the agent is asking about.",
    ),
    depth: int = Query(
        default=2,
        ge=0,
        le=10,
        description="Maximum BFS hops from the anchor to consider.",
    ),
    budget: int = Query(
        default=2000,
        ge=100,
        le=50000,
        description="Approximate upper bound on the pack size, in tokens.",
    ),
    session=Depends(get_db_session),
) -> dict[str, Any]:
    """Return a compressed context pack around an anchor concept."""
    scheme_uuid = _resolve_scheme_id(session, scheme_id)
    repo = SqlAlchemyConceptGraphRepository(session)
    try:
        graph = repo.load_graph(scheme_uuid)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Scheme not found: {scheme_id}"
        ) from exc

    try:
        pack = build_context_pack(
            graph,
            concept,
            depth=depth,
            token_budget=budget,
        )
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail=f"Concept '{concept}' not found in scheme '{scheme_id}'",
        ) from exc

    return pack.to_dict()


def _resolve_scheme_id(session, scheme_id: str) -> str:
    """Resolve a scheme_key to its UUID, or pass a UUID through unchanged.

    The core repository is UUID-only; accept human-friendly scheme_key
    as a convenience for agents. We detect which form was supplied by
    trying to parse the value as a UUID before it reaches SQLAlchemy,
    so the UUID column type never sees a non-UUID string.
    """
    import uuid as _uuid

    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        _uuid.UUID(scheme_id)
        filter_clause = ConceptSchemeModel.id == scheme_id
    except (ValueError, AttributeError):
        filter_clause = ConceptSchemeModel.scheme_key == scheme_id

    row = session.query(ConceptSchemeModel).filter(filter_clause).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")
    return str(row.id)
