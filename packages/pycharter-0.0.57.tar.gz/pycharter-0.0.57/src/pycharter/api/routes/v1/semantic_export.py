"""Concept-graph export endpoints.

Serve Obsidian vaults (written to a caller-supplied directory) and
Neo4j Cypher scripts (returned inline as plain text) derived from a
:class:`ConceptGraph`. Both routes are thin wrappers around the pure
exporter functions in :mod:`pycharter.semantic.export`.
"""

from __future__ import annotations

import logging
import uuid as uuid_mod
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.concept_graph.sqlalchemy_repository import (
    SqlAlchemyConceptGraphRepository,
)
from pycharter.semantic.export import (
    export_to_neo4j_cypher,
    export_to_obsidian,
)

router = APIRouter(tags=["Semantic - Export"])
logger = logging.getLogger(__name__)


class ObsidianExportRequest(BaseModel):
    """Request body for ``POST /api/v1/semantic/export/obsidian``."""

    scheme_id: str = Field(
        ...,
        description="UUID or scheme_key of the scheme to export.",
    )
    output_dir: str = Field(
        ...,
        description=(
            "Absolute path to the target Obsidian vault directory. "
            "Created if it does not exist; existing same-named files "
            "are overwritten."
        ),
    )


@router.post("/obsidian")
async def create_obsidian_vault(
    request: ObsidianExportRequest,
    session=Depends(get_db_session),
) -> dict[str, Any]:
    """Export the scheme as an Obsidian-compatible markdown vault.

    Raises:
        404 if the scheme is not found.
    """
    scheme_uuid = _resolve_scheme_id(session, request.scheme_id)
    graph = _load_graph(session, scheme_uuid)
    output_dir = Path(request.output_dir)
    logger.info(
        "obsidian export: scheme=%s target=%s concepts=%d",
        scheme_uuid,
        output_dir,
        len(graph.nodes),
    )
    result = export_to_obsidian(graph, output_dir)
    return result.to_dict()


@router.get("/neo4j", response_class=PlainTextResponse)
async def get_neo4j_cypher(
    scheme_id: str = Query(
        ...,
        description="UUID or scheme_key of the scheme to export.",
    ),
    session=Depends(get_db_session),
) -> str:
    """Return the scheme as an idempotent Neo4j Cypher script (plain text).

    Raises:
        404 if the scheme is not found.
    """
    scheme_uuid = _resolve_scheme_id(session, scheme_id)
    graph = _load_graph(session, scheme_uuid)
    logger.info(
        "neo4j cypher export: scheme=%s concepts=%d",
        scheme_uuid,
        len(graph.nodes),
    )
    return export_to_neo4j_cypher(graph)


def _resolve_scheme_id(session, scheme_id: str) -> str:
    """Resolve a scheme_key to its UUID, or pass a UUID through unchanged."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        uuid_mod.UUID(scheme_id)
        filter_clause = ConceptSchemeModel.id == scheme_id
    except (ValueError, AttributeError):
        filter_clause = ConceptSchemeModel.scheme_key == scheme_id

    row = session.query(ConceptSchemeModel).filter(filter_clause).first()
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")
    return str(row.id)


def _load_graph(session, scheme_uuid: str):
    """Load the ConceptGraph for ``scheme_uuid`` via the repository."""
    try:
        return SqlAlchemyConceptGraphRepository(session).load_graph(scheme_uuid)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Scheme not found: {scheme_uuid}"
        ) from exc
