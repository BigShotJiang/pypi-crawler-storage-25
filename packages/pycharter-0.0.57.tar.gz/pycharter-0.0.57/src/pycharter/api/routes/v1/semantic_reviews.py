"""Reviews API routes."""

from __future__ import annotations

import logging
import uuid

from fastapi import APIRouter, Depends, Query

logger = logging.getLogger(__name__)

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.api.models.semantic_reviews import SubmitReviewRequest
from pycharter.db.models.semantic.proposal import ProposalModel
from pycharter.persistence.collaboration.review import ReviewWorkflow
from pycharter.semantic.shared.errors import CollaborationError

router = APIRouter(tags=["Semantic"])


@router.post("/")
async def submit_review(request: SubmitReviewRequest, session=Depends(get_db_session)):
    """Submit a review on a proposal."""
    try:
        rw = ReviewWorkflow(session)
        review_id = rw.submit_review(
            proposal_id=request.proposal_id,
            reviewer=request.reviewer,
            decision=request.decision,
            comment=request.comment,
        )
        return {"review_id": review_id}
    except CollaborationError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/proposal/{proposal_id}")
async def get_reviews(proposal_id: str, session=Depends(get_db_session)):
    """Get all reviews for a proposal."""
    rw = ReviewWorkflow(session)
    return rw.get_reviews(proposal_id)


@router.get("/proposal/{proposal_id}/status")
async def check_approval(
    proposal_id: str,
    required: int | None = Query(None),
    session=Depends(get_db_session),
):
    """Check approval status for a proposal."""
    rw = ReviewWorkflow(session)
    required_approvals = required
    if required_approvals is None:
        proposal_uuid = None
        try:
            proposal_uuid = uuid.UUID(proposal_id)
        except ValueError:
            proposal_uuid = None
        proposal = (
            session.query(ProposalModel)
            .filter(ProposalModel.id == proposal_uuid)
            .first()
        )
        required_approvals = int(proposal.required_approvals) if proposal else 1
    return rw.check_approval_status(proposal_id, required_approvals=required_approvals)
