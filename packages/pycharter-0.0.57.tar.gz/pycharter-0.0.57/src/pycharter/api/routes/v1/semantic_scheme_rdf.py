"""RDF export / import routes for concept schemes.

Wraps :func:`pycharter.semantic.rdf.roundtrip.dump_scheme` and
:func:`load_scheme` so callers can fetch a scheme as Turtle / JSON-LD
without running rdflib themselves, and can re-ingest a serialised
scheme into the store.

``GET /semantic/schemes/{scheme_key}/rdf?format=ttl|jsonld`` returns a
``text/turtle`` or ``application/ld+json`` body.

``POST /semantic/schemes/rdf`` accepts a JSON body carrying the
serialised scheme + format + ``scheme_key`` override; every concept
from the parsed :class:`ConceptScheme` is upserted via
``SemanticStoreClient.store_concept``.
"""

from __future__ import annotations

import logging
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.semantic.ontology.models import Concept, ConceptScheme
from pycharter.semantic.rdf.roundtrip import dump_scheme, load_scheme
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Scheme RDF"])


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------


_MEDIA_TYPES: dict[str, str] = {
    "turtle": "text/turtle",
    "jsonld": "application/ld+json",
}


@router.get("/{scheme_key}/rdf", response_class=PlainTextResponse)
def export_scheme_rdf(
    scheme_key: str,
    format: Literal["turtle", "jsonld"] = Query(default="turtle"),
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> PlainTextResponse:
    """Serialise a concept scheme as Turtle or JSON-LD."""
    scheme = _load_scheme_from_store(store, scheme_key)
    if scheme is None:
        raise HTTPException(
            status_code=404,
            detail=f"Scheme {scheme_key!r} not found.",
        )
    body = dump_scheme(scheme, format=format)
    return PlainTextResponse(content=body, media_type=_MEDIA_TYPES[format])


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------


class SchemeImportRequest(BaseModel):
    """Request body for POST /semantic/schemes/rdf."""

    text: str = Field(..., description="The serialised scheme body.")
    format: Literal["turtle", "jsonld"] = Field(default="turtle")
    overwrite_scheme_key: str | None = Field(
        default=None,
        description=(
            "When set, the scheme is stored under this key instead of the "
            "id parsed out of the RDF document. Useful for re-homing an "
            "imported scheme under a namespace the caller controls."
        ),
    )


class SchemeImportResponse(BaseModel):
    """Response body for POST /semantic/schemes/rdf."""

    scheme_key: str
    concepts_upserted: int


@router.post("/rdf", response_model=SchemeImportResponse)
def import_scheme_rdf(
    request: SchemeImportRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> SchemeImportResponse:
    """Parse a serialised scheme and upsert its concepts into the store."""
    try:
        scheme = load_scheme(request.text, format=request.format)
    except Exception as exc:  # noqa: BLE001 — surface a clean 400
        logger.info("rdf import parse error: %s", exc)
        raise HTTPException(
            status_code=400,
            detail=f"Failed to parse {request.format} payload: {exc}",
        )

    scheme_key = request.overwrite_scheme_key or scheme.id or "imported"
    _upsert_scheme(store, scheme_key, scheme)
    concepts_upserted = _upsert_concepts(store, scheme_key, scheme.concepts)
    return SchemeImportResponse(
        scheme_key=scheme_key,
        concepts_upserted=concepts_upserted,
    )


# ---------------------------------------------------------------------------
# Store helpers
# ---------------------------------------------------------------------------


def _load_scheme_from_store(
    store: SemanticStoreClient,
    scheme_key: str,
) -> ConceptScheme | None:
    """Materialise a :class:`ConceptScheme` from the store's rows."""
    try:
        header = store.get_scheme(scheme_key)
    except Exception:  # noqa: BLE001 — treat unknown as missing
        logger.debug("get_scheme(%s) raised", scheme_key, exc_info=True)
        return None
    if header is None:
        return None

    scheme = ConceptScheme(
        id=str(header.get("key") or header.get("scheme_key") or scheme_key),
        title=str(header.get("title") or scheme_key),
        version=str(header.get("version") or "1.0.0"),
        description=str(header.get("description") or ""),
        base_uri=header.get("base_uri"),
    )
    rows = store.list_concepts(scheme_key=scheme_key)
    for row in rows:
        name = row.get("name")
        if not name:
            continue
        scheme.concepts.append(
            Concept(
                id=str(name),
                label=str(row.get("label") or name),
                definition=row.get("definition"),
                broader=row.get("broader"),
                notation=row.get("notation"),
                concept_type=row.get("concept_type"),
            )
        )
    return scheme


def _upsert_scheme(
    store: SemanticStoreClient,
    scheme_key: str,
    scheme: ConceptScheme,
) -> None:
    """Create the scheme row if it does not already exist."""
    try:
        existing = store.get_scheme(scheme_key)
    except Exception:  # noqa: BLE001 — let store_scheme raise on real errors
        existing = None
    if existing is not None:
        return
    store.store_scheme(
        scheme_key,
        title=scheme.title or scheme_key,
        version=scheme.version or "1.0.0",
        base_uri=scheme.base_uri or f"urn:pycharter:imported:{scheme_key}:",
    )


def _upsert_concepts(
    store: SemanticStoreClient,
    scheme_key: str,
    concepts: list[Concept],
) -> int:
    """Upsert every concept into the target scheme. Returns the insert count."""
    inserted = 0
    for concept in concepts:
        if concept.id and store.get_concept(concept.id) is not None:
            continue
        store.store_concept(
            name=concept.id,
            label=concept.label or concept.id,
            scheme_key=scheme_key,
            concept_type=concept.concept_type or "entity",
            **({"broader": concept.broader} if concept.broader else {}),
        )
        inserted += 1
    return inserted
