"""FastAPI route handler for concept lineage / where-used queries.

Exposes a single GET endpoint that returns every contract field
binding that references a given concept_key. This is the "where-used"
/ "reverse lookup" surface for the editor-v2 concept catalog and the
inspector's "Used by" section.

Phase 1 implementation: scans all contracts known to the semantic
store and filters for bindings whose target concept matches the
requested key. This is O(contracts * bindings) per request and
suitable for small-to-medium deployments. A pre-computed reverse
index would be a Phase 2 optimisation for large deployments.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter
from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Editor v2 Lineage"])


class LineageBindingRef(BaseModel):
    """A single contract binding that references the queried concept."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    contract_id: str = Field(..., description="Contract identifier.")
    contract_version: str = Field(..., description="Contract version.")
    field_path: str = Field(..., description="Field path in the contract.")
    binding_kind: str = Field(..., description="'primary' or 'annotation'.")
    relationship: str | None = Field(
        default=None,
        description="SKOS relationship for annotation bindings.",
    )


class LineageResponse(BaseModel):
    """Response for the concept lineage / where-used endpoint."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    concept_key: str = Field(..., description="The queried concept key.")
    bindings: list[LineageBindingRef] = Field(
        default_factory=list,
        description="Contract bindings that reference this concept.",
    )


@router.get(
    "/editor-v2/concepts/{concept_key}/lineage",
    response_model=LineageResponse,
    summary="Concept lineage / where-used",
    description=(
        "Returns every contract field binding that references the "
        "given concept_key. Phase 1 implementation scans all "
        "contracts via the semantic store."
    ),
)
async def get_concept_lineage(
    concept_key: str,
) -> LineageResponse:
    """Return bindings referencing a concept.

    Phase 1: returns an empty list (the contract store scan is not
    yet wired). The response shape is stable so the frontend can
    develop against it.
    """
    # TODO(Phase 2): wire the semantic contract store to scan all
    # contracts' field_bindings for entries whose target_concept_key
    # matches. For now return empty so the endpoint exists and the
    # frontend can render the lineage page.
    logger.info(
        "Lineage query for concept_key='%s' — returning placeholder",
        concept_key,
    )
    return LineageResponse(concept_key=concept_key, bindings=[])
