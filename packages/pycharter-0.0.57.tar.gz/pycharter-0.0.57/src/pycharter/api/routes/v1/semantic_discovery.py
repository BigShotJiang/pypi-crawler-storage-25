"""Discovery API routes."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Query

logger = logging.getLogger(__name__)

from pycharter.api._http_errors import raise_logged_bad_request
from pycharter.api.dependencies import get_db_session
from pycharter.semantic.knowledge.discovery import DiscoveryEngine
from pycharter.semantic.shared.errors import GraphError

router = APIRouter(tags=["Semantic"])


@router.get("/suggest")
async def suggest_concept(
    field_name: str = Query(..., description="Field name to get suggestions for"),
    session=Depends(get_db_session),
):
    """Suggest concepts for a field based on its name."""
    try:
        engine = DiscoveryEngine(session)
        return engine.suggest_concept(field_name)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/synonyms")
async def find_synonyms(
    concept_name: str = Query(..., description="Concept name to find synonyms for"),
    session=Depends(get_db_session),
):
    """Find fields that may be synonyms for a concept."""
    try:
        engine = DiscoveryEngine(session)
        return engine.find_synonyms(concept_name)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )


@router.get("/cross-contract")
async def find_cross_contract_mappings(
    concept_name: str = Query(..., description="Concept name to search for"),
    session=Depends(get_db_session),
):
    """Find fields across contracts that share the same concept."""
    try:
        engine = DiscoveryEngine(session)
        return engine.find_cross_contract_mappings(concept_name)
    except GraphError as e:
        raise_logged_bad_request(
            logger,
            e,
            public_detail="Request could not be completed",
            log_event="route failed",
        )
