"""Namespace / authority registry routes.

Exposes the in-process :class:`NamespaceRegistry` over HTTP so UIs and
downstream services can register, list, and mint IRIs under governed
authorities without each client reinventing the scheme.

The registry is a singleton per API process. A future phase can swap
the backing store for a persistent one without changing the wire API.
"""

from __future__ import annotations

import logging
import threading

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from pycharter.api._http_errors import (
    raise_logged_bad_request,
    raise_logged_conflict,
    raise_logged_not_found,
)
from pycharter.semantic.namespaces import (
    GovernanceTier,
    Namespace,
    NamespaceError,
    NamespaceRegistry,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Semantic - Namespaces"])

# ---------------------------------------------------------------------------
# Singleton dependency
# ---------------------------------------------------------------------------

_lock = threading.Lock()
_registry: NamespaceRegistry | None = None


def get_namespace_registry() -> NamespaceRegistry:
    """Return the process-wide :class:`NamespaceRegistry` singleton."""
    global _registry  # noqa: PLW0603 — module-level singleton by design
    with _lock:
        if _registry is None:
            reg = NamespaceRegistry()
            reg.register_defaults()
            _registry = reg
    return _registry


# ---------------------------------------------------------------------------
# Pydantic shapes
# ---------------------------------------------------------------------------


class NamespaceModel(BaseModel):
    """Serialised :class:`Namespace`."""

    prefix: str
    base_uri: str
    owner: str
    governance_tier: GovernanceTier
    description: str = ""

    @classmethod
    def from_namespace(cls, ns: Namespace) -> NamespaceModel:
        """Convert a domain :class:`Namespace` to a wire-format model."""
        return cls(
            prefix=ns.prefix,
            base_uri=ns.base_uri,
            owner=ns.owner,
            governance_tier=ns.governance_tier,
            description=ns.description,
        )

    def to_namespace(self) -> Namespace:
        """Convert a wire-format model back to the domain :class:`Namespace`."""
        return Namespace(
            prefix=self.prefix,
            base_uri=self.base_uri,
            owner=self.owner,
            governance_tier=self.governance_tier,
            description=self.description,
        )


class MintRequest(BaseModel):
    """Request body for POST /namespaces/{prefix}/mint."""

    local_name: str = Field(
        ...,
        description="Local name to append to the namespace's base URI.",
    )


class MintResponse(BaseModel):
    """Response body for POST /namespaces/{prefix}/mint."""

    iri: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=list[NamespaceModel])
def list_namespaces(
    registry: NamespaceRegistry = Depends(get_namespace_registry),
) -> list[NamespaceModel]:
    """Return every registered namespace, sorted by prefix."""
    return [NamespaceModel.from_namespace(ns) for ns in registry.list()]


@router.post("", response_model=NamespaceModel, status_code=201)
def register_namespace(
    namespace: NamespaceModel,
    registry: NamespaceRegistry = Depends(get_namespace_registry),
) -> NamespaceModel:
    """Register a new namespace.

    Duplicate registrations (same prefix + same base URI) are rejected
    with HTTP 409.
    """
    try:
        registry.register(namespace.to_namespace())
    except NamespaceError as exc:
        raise_logged_conflict(
            logger, exc, public_detail="Conflict", log_event="route failed"
        )
    return namespace


@router.get("/{prefix}", response_model=NamespaceModel)
def get_namespace(
    prefix: str,
    registry: NamespaceRegistry = Depends(get_namespace_registry),
) -> NamespaceModel:
    """Fetch a namespace by prefix."""
    try:
        return NamespaceModel.from_namespace(registry.get(prefix))
    except NamespaceError as exc:
        raise_logged_not_found(
            logger, exc, public_detail="Not found", log_event="route failed"
        )


@router.post("/{prefix}/mint", response_model=MintResponse)
def mint_iri(
    prefix: str,
    request: MintRequest,
    registry: NamespaceRegistry = Depends(get_namespace_registry),
) -> MintResponse:
    """Mint an IRI under ``prefix`` for ``local_name``."""
    try:
        iri = registry.mint(prefix, request.local_name)
    except NamespaceError as exc:
        raise_logged_bad_request(
            logger,
            exc,
            public_detail="Request could not be completed",
            log_event="route failed",
        )
    return MintResponse(iri=iri)
