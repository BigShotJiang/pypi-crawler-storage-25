"""Router registration for the FastAPI application.

Centralises all ``include_router`` calls so ``main.py`` stays lean.
"""

from __future__ import annotations

from fastapi import Depends, FastAPI

from pycharter.api.dependencies.auth import get_current_user
from pycharter.api.routes.v1 import (
    auth,
    contracts,
    docs,
    editor_layouts,
    editor_v2_completeness,
    editor_v2_concept_graphs,
    editor_v2_drafts,
    editor_v2_knowledge_base,
    editor_v2_lineage,
    editor_v2_pipeline_run,
    editor_v2_search,
    events,
    evolution,
    folders,
    metadata,
    metadata_entities,
    ontology_configs,
    pipeline,
    pipeline_configs,
    quality,
    reconciliation,
    runs,
    schema_import,
    schemas,
    semantic_bindings,
    semantic_concept_graph,
    semantic_context,
    semantic_dashboard,
    semantic_definitions,
    semantic_discovery,
    semantic_export,
    semantic_extraction,
    semantic_field_mapping,
    semantic_governance,
    semantic_graph,
    semantic_ingestion,
    semantic_lineage,
    semantic_namespaces,
    semantic_proposals,
    semantic_query,
    semantic_rdf,
    semantic_reasoning,
    semantic_reviews,
    semantic_schema,
    semantic_scheme_rdf,
    semantic_schemes,
    semantic_search,
    semantic_templates,
    semantic_versioning,
    settings,
    templates,
    tracking,
    validation,
    validation_jobs,
)

API_VERSION = "v1"


def register_routers(app: FastAPI) -> None:
    """Attach all v1 routers to *app*.

    Auth routes are public; every other router requires a valid Bearer
    token (when auth is enabled).
    """
    # Auth router: no global auth dependency
    app.include_router(
        auth.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Auth"],
    )

    _auth_dep = [Depends(get_current_user)]

    # --- Core routers ---
    app.include_router(
        contracts.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Contracts"],
        dependencies=_auth_dep,
    )
    app.include_router(
        metadata.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Metadata"],
        dependencies=_auth_dep,
    )
    app.include_router(
        metadata_entities.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Metadata"],
        dependencies=_auth_dep,
    )
    app.include_router(
        schemas.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Schemas"],
        dependencies=_auth_dep,
    )
    app.include_router(
        validation.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Validation"],
        dependencies=_auth_dep,
    )
    app.include_router(
        quality.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Quality"],
        dependencies=_auth_dep,
    )
    app.include_router(
        templates.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Templates"],
        dependencies=_auth_dep,
    )
    app.include_router(
        pipeline.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline"],
        dependencies=_auth_dep,
    )
    app.include_router(
        pipeline_configs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline Configs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        ontology_configs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Ontology Configs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        runs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline Runs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        settings.public_router,
        prefix=f"/api/{API_VERSION}",
        tags=["Settings"],
    )
    app.include_router(
        settings.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Settings"],
        dependencies=_auth_dep,
    )
    # Events: no auth so SSE clients can connect without token
    app.include_router(
        events.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Events"],
    )

    # Docs: no auth so UI can load route list without token
    app.include_router(
        docs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Documentation"],
    )
    app.include_router(
        tracking.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Quality Tracking"],
        dependencies=_auth_dep,
    )
    app.include_router(
        evolution.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Schema Evolution"],
        dependencies=_auth_dep,
    )
    app.include_router(
        validation_jobs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Validation Jobs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        folders.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Folders"],
        dependencies=_auth_dep,
    )

    # --- Semantic routers (ontology, knowledge graph, governance) ---
    _semantic = [
        (semantic_dashboard, "dashboard", "Dashboard"),
        (semantic_field_mapping, "field-mapping", "Field Mapping"),
        (semantic_versioning, "versioning", "Versioning"),
        (semantic_proposals, "proposals", "Proposals"),
        (semantic_reviews, "reviews", "Reviews"),
        (semantic_graph, "graph", "Graph"),
        (semantic_search, "search", "Search"),
        (semantic_ingestion, "ingestion", "Ingestion"),
        (semantic_lineage, "lineage", "Lineage"),
        (semantic_discovery, "discovery", "Discovery"),
        (semantic_rdf, "rdf", "RDF / JSON-LD / SHACL"),
        (semantic_concept_graph, "concept-graph", "Concept Graph"),
        (semantic_schema, "schema", "Schema"),
        (semantic_governance, "governance", "Governance"),
        (semantic_namespaces, "namespaces", "Namespaces"),
        (semantic_reasoning, "reasoning", "Reasoning"),
        (semantic_query, "query", "Query"),
        (semantic_bindings, "bindings", "Bindings"),
        (semantic_scheme_rdf, "schemes", "Scheme RDF"),
        (semantic_context, "context", "Context"),
        (semantic_extraction, "extraction", "Extraction"),
        (semantic_export, "export", "Export"),
    ]
    for module, path, label in _semantic:
        app.include_router(
            module.router,
            prefix=f"/api/{API_VERSION}/semantic/{path}",
            tags=[f"Semantic - {label}"],
            dependencies=_auth_dep,
        )

    # Schemes router has a shorter prefix (no sub-path)
    app.include_router(
        semantic_schemes.router,
        prefix=f"/api/{API_VERSION}/semantic",
        tags=["Semantic - Schemes"],
        dependencies=_auth_dep,
    )

    # --- Schema Import (KB builder) ---
    app.include_router(
        schema_import.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Schema Import"],
        dependencies=_auth_dep,
    )

    # --- Domain Templates (KB builder) ---
    app.include_router(
        semantic_templates.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Templates"],
        dependencies=_auth_dep,
    )

    # --- Definition Drafting (KB builder) ---
    app.include_router(
        semantic_definitions.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Definitions"],
        dependencies=_auth_dep,
    )

    # --- Reconciliation (KB builder) ---
    app.include_router(
        reconciliation.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Reconciliation"],
        dependencies=_auth_dep,
    )

    # --- Editor layout positions (no auth — lightweight CRUD) ---
    app.include_router(
        editor_layouts.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor Layouts"],
    )

    # --- Editor v2 concept graph (KB absorbed into unified editor) ---
    app.include_router(
        editor_v2_concept_graphs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Concept Graph"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 universal search ---
    app.include_router(
        editor_v2_search.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Search"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 drafts ---
    app.include_router(
        editor_v2_drafts.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Drafts"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 completeness metrics ---
    app.include_router(
        editor_v2_completeness.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Completeness"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 lineage / where-used ---
    app.include_router(
        editor_v2_lineage.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Lineage"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 pipeline run ---
    app.include_router(
        editor_v2_pipeline_run.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Pipeline Run"],
        dependencies=_auth_dep,
    )

    # --- Editor v2 knowledge base (versioning, linking, lineage) ---
    app.include_router(
        editor_v2_knowledge_base.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Editor v2 Knowledge Base"],
        dependencies=_auth_dep,
    )
