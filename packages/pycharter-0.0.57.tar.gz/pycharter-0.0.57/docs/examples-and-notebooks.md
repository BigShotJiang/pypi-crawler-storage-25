# Examples & Notebooks

PyCharter’s **narrative examples** live in the [Tutorials](tutorials/index.md) and [Guides](guides/index.md) sections of this documentation. They cover validation, ETL pipelines, data contracts, quality checks, contract stores, and schema conversion—the same topics that were previously demonstrated in removed Jupyter notebooks.

## Topics (see docs)

| Area | Where to start |
|------|----------------|
| Getting started | [Quick Start](getting-started/quickstart.md), tutorials index |
| ETL pipelines | [Pipelines guide](guides/index.md), async execution [async-execution.md](guides/async-execution.md) |
| Data contracts | Contract guides and API reference |
| Validation & quality | Quality and validation sections in guides |
| Contract store | Documentation for storage backends |
| Schema conversion | Pydantic / JSON Schema topics in guides and API |

## Interactive workflows

- **Marimo** (optional): `pip install -e ".[dev]"` includes `marimo`; use `marimo edit your_notebook.py` for reactive `.py` notebooks.
- **Tests**: The `tests/` tree contains executable examples of the public API.

## Related docs

- [Quick Start](getting-started/quickstart.md)
- [Tutorials](tutorials/index.md)
- [API Reference](api/index.md)
