# Example notebooks

Hands-on PyCharter material is covered in the **markdown tutorials** and **guides** in this documentation site (see [Examples & Notebooks](../examples-and-notebooks.md)).

For interactive exploration, install dev extras and use **[Marimo](https://marimo.io/)** (included in `pip install -e ".[dev]"`) to author `.py` notebooks locally, or run examples as plain Python scripts under `tests/` and project-specific scratch areas.

Historical Jupyter (`.ipynb`) notebooks were removed from the repository in favor of Marimo and the maintained docs.
