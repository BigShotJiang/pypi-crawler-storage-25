#!/usr/bin/env bash
set -euo pipefail

# ---------------------------------------------------------------------------
# Build and push PyCharter Docker image to DockerHub
#
# Produces a single image: optophi/pycharter
# Run with: docker run optophi/pycharter api|worker|ui
#
# Usage:
#   ./build.sh                      # build + push, auto-detect version
#   ./build.sh --version 0.1.0      # explicit version tag
#   ./build.sh --build-only         # build without pushing
#   ./build.sh --push-only          # push already-built image
# ---------------------------------------------------------------------------

REPO="optophi/pycharter"
VERSION=""
BUILD=true
PUSH=true

usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Options:
  --version VERSION   Image tag version (default: auto-detect from git)
  --build-only        Build image without pushing
  --push-only         Push already-built image without building
  -h, --help          Show this help
EOF
    exit 0
}

# -- Parse arguments --------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --version)     VERSION="$2"; shift 2 ;;
        --build-only)  PUSH=false; shift ;;
        --push-only)   BUILD=false; shift ;;
        -h|--help)     usage ;;
        *)  echo "Unknown option: $1"; usage ;;
    esac
done

# -- Auto-detect version from latest git tag --------------------------------
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -z "$VERSION" ]]; then
    VERSION=$(git -C "$PKG_DIR" tag --list 'v*' --sort=-v:refname | head -1 | sed 's/^v//') || true

    if [[ -z "$VERSION" ]]; then
        echo "ERROR: Could not determine version. No v* tags found."
        echo "Either tag a release or pass --version explicitly."
        exit 1
    fi
fi

echo "==> Repository : $REPO"
echo "==> Version    : $VERSION"
echo "==> Build      : $BUILD"
echo "==> Push       : $PUSH"
echo ""

# -- Preflight checks -------------------------------------------------------
if ! docker info >/dev/null 2>&1; then
    echo "ERROR: Docker daemon is not running. Start Docker Desktop first."
    exit 1
fi

if [[ "$PUSH" == true ]]; then
    if ! grep -q '"https://index.docker.io' ~/.docker/config.json 2>/dev/null && \
       ! grep -q 'credsStore' ~/.docker/config.json 2>/dev/null; then
        echo "WARNING: You may not be logged into DockerHub."
        echo "Run 'docker login' first, then re-run this script."
        exit 1
    fi
fi

# -- Build and push ---------------------------------------------------------
echo "==> Building ${REPO}:${VERSION}"
if [[ "$BUILD" == true ]]; then
    docker build \
        --target production-ui \
        --build-arg SETUPTOOLS_SCM_PRETEND_VERSION="$VERSION" \
        -t "${REPO}:${VERSION}" \
        -t "${REPO}:latest" \
        "$PKG_DIR"
fi

if [[ "$PUSH" == true ]]; then
    docker push "${REPO}:${VERSION}"
    docker push "${REPO}:latest"
fi

echo ""
echo "==> Done."
