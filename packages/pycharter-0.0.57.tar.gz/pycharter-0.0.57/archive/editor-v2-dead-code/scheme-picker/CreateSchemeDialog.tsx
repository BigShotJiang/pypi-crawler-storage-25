'use client';

/**
 * CreateSchemeDialog — Modal that creates a new concept scheme via
 * the editor-v2 POST endpoint, then routes the user into the new
 * ontology editor.
 *
 * Validates scheme_key client-side (lowercase letters, digits,
 * dashes, underscores, slashes for namespacing) so the user gets
 * an inline error before hitting the server. The server's 409 on
 * duplicate keys is caught and surfaced inline as well.
 */

import { useRouter } from 'next/navigation';
import { useState } from 'react';

import { editorV2Api } from '@/lib/api/editorV2';
import { ApiError } from '@/lib/api/helpers';

const SCHEME_KEY_PATTERN = /^[a-z0-9][a-z0-9_/-]*$/;

export interface CreateSchemeDialogProps {
  open: boolean;
  onClose: () => void;
  /** Called after successful creation with the new scheme ID.
   *  When provided, the dialog does not navigate away. */
  onCreated?: (schemeId: string) => void;
}

export function CreateSchemeDialog({
  open,
  onClose,
  onCreated,
}: CreateSchemeDialogProps): React.ReactElement | null {
  const router = useRouter();
  const [schemeKey, setSchemeKey] = useState('');
  const [title, setTitle] = useState('');
  const [version, setVersion] = useState('0.1.0');
  const [description, setDescription] = useState('');
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!open) return null;

  const reset = () => {
    setSchemeKey('');
    setTitle('');
    setVersion('0.1.0');
    setDescription('');
    setSubmitError(null);
    setIsSubmitting(false);
  };

  const handleClose = () => {
    if (isSubmitting) return;
    reset();
    onClose();
  };

  const validate = (): string | null => {
    if (!schemeKey.trim()) return 'Scheme key is required.';
    if (!SCHEME_KEY_PATTERN.test(schemeKey)) {
      return (
        'Scheme key must start with a lowercase letter or digit and may '
        + 'only contain lowercase letters, digits, dashes, underscores, '
        + 'and slashes.'
      );
    }
    if (!title.trim()) return 'Title is required.';
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setSubmitError(validationError);
      return;
    }
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      const bundle = await editorV2Api.createConceptGraph({
        scheme_key: schemeKey.trim(),
        title: title.trim(),
        version: version.trim() || '0.1.0',
        description: description.trim() || null,
      });
      reset();
      onClose();
      if (onCreated) {
        onCreated(bundle.graph.scheme.id);
      } else {
        router.push('/editor-v2');
      }
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setSubmitError(
          `A scheme with key "${schemeKey}" already exists.`,
        );
      } else if (err instanceof Error) {
        setSubmitError(err.message);
      } else {
        setSubmitError('Failed to create ontology.');
      }
      setIsSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-scheme-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4"
      onClick={handleClose}
    >
      <div
        className="w-full max-w-md rounded-lg border bg-background shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="border-b px-4 py-3">
          <h2 id="create-scheme-title" className="text-sm font-semibold">
            New ontology
          </h2>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            Creates an empty concept scheme you can immediately edit.
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3 px-4 py-3">
          <label className="block">
            <span className="mb-1 block text-[11px] font-medium text-muted-foreground">
              Scheme key
            </span>
            <input
              type="text"
              autoFocus
              value={schemeKey}
              onChange={(e) => setSchemeKey(e.target.value)}
              placeholder="trading-domain"
              className="w-full rounded-md border bg-background px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <span className="mt-0.5 block text-[10px] text-muted-foreground">
              Lowercase letters, digits, dashes, underscores, slashes.
            </span>
          </label>

          <label className="block">
            <span className="mb-1 block text-[11px] font-medium text-muted-foreground">
              Title
            </span>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Trading Domain"
              className="w-full rounded-md border bg-background px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-[11px] font-medium text-muted-foreground">
              Version
            </span>
            <input
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="0.1.0"
              className="w-full rounded-md border bg-background px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-[11px] font-medium text-muted-foreground">
              Description
            </span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="Optional"
              className="w-full resize-none rounded-md border bg-background px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </label>

          {submitError && (
            <div className="rounded border border-red-200 bg-red-50 px-2 py-1.5 text-[11px] text-red-800 dark:border-red-900/40 dark:bg-red-950/30 dark:text-red-200">
              {submitError}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={handleClose}
              disabled={isSubmitting}
              className="rounded-md border px-2.5 py-1 text-xs font-medium hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-md border bg-primary px-2.5 py-1 text-xs font-medium text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50 hover:opacity-90"
            >
              {isSubmitting ? 'Creating…' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
