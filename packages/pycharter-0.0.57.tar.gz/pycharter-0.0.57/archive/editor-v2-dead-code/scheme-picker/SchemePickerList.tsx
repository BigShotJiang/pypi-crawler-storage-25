'use client';

/**
 * SchemePickerList — Sortable, filterable list of concept schemes.
 *
 * Used by the editor-v2 scheme picker landing page. Each row is a
 * link to /editor-v2/ontology/[schemeId]. Filter matches both
 * scheme_key and title; sort defaults to title ascending.
 *
 * The component is presentational: it owns no data fetching, and
 * accepts schemes plus loading/error state via props so it can be
 * reused in other contexts (e.g. the Cmd+K palette).
 */

import Link from 'next/link';
import { useMemo, useState } from 'react';

import type { SchemeSummary } from '@/lib/api/editorV2';

type SortKey = 'title' | 'scheme_key' | 'version';

interface SortState {
  key: SortKey;
  asc: boolean;
}

export interface SchemePickerListProps {
  schemes: SchemeSummary[];
  isLoading: boolean;
  loadError: string | null;
  onRetry: () => void | Promise<void>;
}

function compareSchemes(
  a: SchemeSummary,
  b: SchemeSummary,
  state: SortState,
): number {
  const direction = state.asc ? 1 : -1;
  const left = (a[state.key] ?? '') as string;
  const right = (b[state.key] ?? '') as string;
  return left.localeCompare(right) * direction;
}

function matchesFilter(scheme: SchemeSummary, filter: string): boolean {
  if (!filter) return true;
  const needle = filter.toLowerCase();
  return (
    scheme.title.toLowerCase().includes(needle) ||
    scheme.scheme_key.toLowerCase().includes(needle) ||
    (scheme.description ?? '').toLowerCase().includes(needle)
  );
}

export function SchemePickerList({
  schemes,
  isLoading,
  loadError,
  onRetry,
}: SchemePickerListProps): React.ReactElement {
  const [filter, setFilter] = useState('');
  const [sort, setSort] = useState<SortState>({ key: 'title', asc: true });

  const visible = useMemo(() => {
    return schemes
      .filter((s) => matchesFilter(s, filter))
      .slice()
      .sort((a, b) => compareSchemes(a, b, sort));
  }, [schemes, filter, sort]);

  const onHeaderClick = (key: SortKey) => {
    setSort((prev) => ({ key, asc: prev.key === key ? !prev.asc : true }));
  };

  if (loadError) {
    return (
      <div className="flex h-full w-full items-center justify-center px-6">
        <div className="max-w-md rounded-lg border border-red-200 bg-red-50 px-6 py-5 text-sm text-red-900 shadow-sm dark:border-red-900/40 dark:bg-red-950/30 dark:text-red-200">
          <div className="mb-2 text-base font-semibold">
            Could not load schemes
          </div>
          <div className="mb-4 whitespace-pre-wrap text-xs">{loadError}</div>
          <button
            type="button"
            onClick={() => void onRetry()}
            className="rounded-md border border-red-300 bg-white px-3 py-1.5 text-xs font-medium text-red-900 hover:bg-red-100 dark:border-red-700 dark:bg-red-950 dark:text-red-100 dark:hover:bg-red-900"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex items-center justify-between border-b px-3 py-2">
        <div className="flex items-baseline gap-2">
          <span className="text-[11px] text-muted-foreground">
            {visible.length} / {schemes.length} schemes
          </span>
          {isLoading && (
            <span className="text-[11px] text-muted-foreground">Loading…</span>
          )}
        </div>
        <input
          type="search"
          placeholder="Filter by name or key…"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="rounded-md border bg-background px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse text-xs">
          <thead className="sticky top-0 z-10 bg-background/95 backdrop-blur">
            <tr className="border-b">
              <th className="px-3 py-2 text-left">
                <button
                  type="button"
                  onClick={() => onHeaderClick('title')}
                  className="flex items-center gap-1 font-semibold hover:text-primary"
                >
                  Title {sort.key === 'title' ? (sort.asc ? '↑' : '↓') : ''}
                </button>
              </th>
              <th className="px-3 py-2 text-left">
                <button
                  type="button"
                  onClick={() => onHeaderClick('scheme_key')}
                  className="flex items-center gap-1 font-semibold hover:text-primary"
                >
                  Key {sort.key === 'scheme_key' ? (sort.asc ? '↑' : '↓') : ''}
                </button>
              </th>
              <th className="px-3 py-2 text-left">
                <button
                  type="button"
                  onClick={() => onHeaderClick('version')}
                  className="flex items-center gap-1 font-semibold hover:text-primary"
                >
                  Version{' '}
                  {sort.key === 'version' ? (sort.asc ? '↑' : '↓') : ''}
                </button>
              </th>
              <th className="px-3 py-2 text-right font-semibold">Concepts</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((scheme) => (
              <tr
                key={scheme.id}
                className="border-b transition-colors hover:bg-muted/40"
              >
                <td className="px-3 py-2">
                  <Link
                    href={`/editor-v2/ontology/${scheme.id}`}
                    className="font-medium text-primary hover:underline"
                  >
                    {scheme.title}
                  </Link>
                  {scheme.description && (
                    <div className="mt-0.5 line-clamp-1 text-[10px] text-muted-foreground">
                      {scheme.description}
                    </div>
                  )}
                </td>
                <td className="px-3 py-2 font-mono text-[11px] text-muted-foreground">
                  {scheme.scheme_key}
                </td>
                <td className="px-3 py-2 text-muted-foreground">
                  {scheme.version}
                </td>
                <td className="px-3 py-2 text-right text-muted-foreground">
                  {scheme.concept_count ?? '—'}
                </td>
              </tr>
            ))}
            {visible.length === 0 && !isLoading && (
              <tr>
                <td
                  colSpan={4}
                  className="px-3 py-6 text-center text-muted-foreground"
                >
                  {schemes.length === 0
                    ? 'No ontologies yet. Click "New ontology" to create one.'
                    : 'No schemes match the current filter.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
