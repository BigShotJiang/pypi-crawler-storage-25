'use client';

/**
 * CrossLayerAnchors — SVG overlay drawn inside the ReactFlow canvas
 * that shows dashed connection lines from the focused asset to its
 * counterparts in other layers.
 *
 * Subscribes only to the scalar `focusedAssetId` from the workspace
 * store to avoid the render loop caused by `selectFocusedAssetAnchors`
 * returning fresh object/array references on every call.
 */

import { useMemo } from 'react';
import { useNodes } from '@xyflow/react';

import { useWorkspaceStore } from '@/stores/editor-v2/workspace';
import { LAYERS } from '@/lib/editor-v2/layer-config';
import type { LayerId } from '@/lib/editor-v2/asset-types';

const ANCHOR_COLORS: Record<LayerId, string> = {
  execution: LAYERS.execution.color,
  contract: LAYERS.contract.color,
  knowledge: LAYERS.knowledge.color,
};

export function CrossLayerAnchors(): React.ReactElement | null {
  // Subscribe to scalar only — no fresh references.
  const focusedAssetId = useWorkspaceStore((s) => s.focusedAssetId);
  const nodes = useNodes();

  // Compute anchors synchronously from store snapshot (not via selector).
  const lines = useMemo(() => {
    if (!focusedAssetId) return null;
    const state = useWorkspaceStore.getState();
    const { assetsById, edgesById } = state;

    // Build node position lookup from ReactFlow nodes.
    const posMap = new Map<string, { cx: number; cy: number }>();
    for (const node of nodes) {
      posMap.set(node.id, {
        cx: node.position.x + (node.measured?.width ?? 200) / 2,
        cy: node.position.y + (node.measured?.height ?? 80) / 2,
      });
    }

    const sourcePos = posMap.get(focusedAssetId);
    if (!sourcePos) return null;

    const result: { key: string; sx: number; sy: number; tx: number; ty: number; color: string }[] = [];

    for (const edge of Object.values(edgesById)) {
      let counterpartId: string | null = null;
      if (edge.sourceAssetId === focusedAssetId) {
        counterpartId = edge.targetAssetId;
      } else if (edge.targetAssetId === focusedAssetId) {
        counterpartId = edge.sourceAssetId;
      }
      if (!counterpartId) continue;

      const targetPos = posMap.get(counterpartId);
      if (!targetPos) continue;

      const counterpart = assetsById[counterpartId];
      if (!counterpart) continue;

      // Pick the color from the counterpart's primary layer.
      const layer: LayerId = [...counterpart.layers][0] ?? 'knowledge';
      const key = `${layer}:${counterpartId}`;
      // Deduplicate by key.
      if (result.some((l) => l.key === key)) continue;

      result.push({
        key,
        sx: sourcePos.cx,
        sy: sourcePos.cy,
        tx: targetPos.cx,
        ty: targetPos.cy,
        color: ANCHOR_COLORS[layer],
      });
    }

    return result.length > 0 ? result : null;
    // Only recompute when focusedAssetId or nodes change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusedAssetId, nodes]);

  if (!lines) return null;

  return (
    <svg
      className="pointer-events-none absolute inset-0"
      style={{ zIndex: 5, overflow: 'visible' }}
    >
      {lines.map(({ key, sx, sy, tx, ty, color }) => (
        <line
          key={key}
          x1={sx}
          y1={sy}
          x2={tx}
          y2={ty}
          stroke={color}
          strokeWidth={2}
          strokeDasharray="6 4"
          strokeOpacity={0.6}
        />
      ))}
    </svg>
  );
}
