'use client';

/**
 * SplitCanvasView — two side-by-side ReactFlow instances, each
 * showing a different layer. Pan/zoom synced. Selection shared.
 *
 * Each pane has its own ReactFlowProvider and layer filter override.
 * Viewport changes in one pane are mirrored to the other with a
 * debounce to prevent feedback loops.
 */

import { useCallback, useRef, useState } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  Controls,
  type Node,
  type NodeTypes,
  type EdgeTypes,
  type Connection,
  type Viewport,
  useOnViewportChange,
  useReactFlow,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import {
  ConceptNodeView,
} from '@/components/editor-v2/canvas/ConceptNodeView';
import { ContractFieldNode } from '@/components/editor-v2/canvas/ContractFieldNode';
import { PipelineStepNode } from '@/components/editor-v2/canvas/PipelineStepNode';
import { PipelineDataEdge } from '@/components/editor-v2/canvas/PipelineDataEdge';
import { MappingEdge } from '@/components/unified-editor/edges/MappingEdge';
import { SwimlaneBackground } from '@/components/editor-v2/canvas/SwimlaneBackground';
import { SplitLayerPicker } from '@/components/editor-v2/canvas/SplitLayerPicker';
import { useWorkspaceNodes } from '@/components/editor-v2/canvas/hooks/useWorkspaceNodes';
import { useWorkspaceEdges } from '@/components/editor-v2/canvas/hooks/useWorkspaceEdges';
import { useWorkspaceStore } from '@/stores/editor-v2/workspace';
import type { LayerId, ConceptAsset, SourceAsset, JobAsset, ConsumerAsset } from '@/lib/editor-v2/asset-types';
import { isAssetVisibleInLayers } from '@/lib/editor-v2/layer-config';
import { isEdgeVisibleInLayers } from '@/lib/editor-v2/edge-types';

// Stable module-level types.
const nodeTypes: NodeTypes = {
  concept: ConceptNodeView as unknown as NodeTypes[string],
  'contract-field': ContractFieldNode as unknown as NodeTypes[string],
  'pipeline-step': PipelineStepNode as unknown as NodeTypes[string],
};
const edgeTypes: EdgeTypes = {
  mapping: MappingEdge as unknown as EdgeTypes[string],
  'pipeline-data': PipelineDataEdge as unknown as EdgeTypes[string],
};

// ---------------------------------------------------------------------------
// Single pane (inside its own ReactFlowProvider)
// ---------------------------------------------------------------------------

function SplitPane({
  layer,
  onViewportChange,
  syncViewport,
}: {
  layer: LayerId;
  onViewportChange: (vp: Viewport) => void;
  syncViewport: Viewport | null;
}) {
  const selectAsset = useWorkspaceStore((s) => s.selectAsset);
  const setHoveredAsset = useWorkspaceStore((s) => s.setHoveredAsset);
  const reactFlow = useReactFlow();

  // Apply synced viewport from the other pane.
  const lastSyncRef = useRef<number>(0);
  if (syncViewport && Date.now() - lastSyncRef.current > 50) {
    // Use setViewport outside of render — schedule it.
    requestAnimationFrame(() => {
      reactFlow.setViewport(syncViewport, { duration: 0 });
    });
  }

  // Report viewport changes to the parent.
  useOnViewportChange({
    onChange: useCallback(
      (vp: Viewport) => {
        lastSyncRef.current = Date.now();
        onViewportChange(vp);
      },
      [onViewportChange],
    ),
  });

  // Override active layers to just this pane's layer.
  // We temporarily set it for the hooks, then restore. Actually, the
  // workspace hooks read from the store's activeLayers. For split view
  // we need per-pane filtering. The cleanest approach: filter the
  // hook output by layer.
  const buildConceptCallbacks = useCallback(
    (asset: ConceptAsset) => ({
      onRename:
        asset.tier === 'core'
          ? null
          : (next: string) =>
              useWorkspaceStore.getState().updateAsset(asset.id, { label: next }),
      onAddSlot: null,
    }),
    [],
  );
  const buildStepCallbacks = useCallback(
    (asset: SourceAsset | JobAsset | ConsumerAsset) => ({
      onRename: (next: string) =>
        useWorkspaceStore.getState().updateAsset(asset.id, { label: next }),
    }),
    [],
  );

  const { visibleNodes, handleNodesChange } = useWorkspaceNodes({
    zoomLevel: 'full',
    buildConceptCallbacks,
    buildStepCallbacks,
    allowedIds: null,
  });
  const { visibleEdges } = useWorkspaceEdges({
    trustView: false,
    allowedIds: null,
  });

  // Filter nodes/edges to this pane's layer.
  const layerSet = new Set<LayerId>([layer]);

  const filteredNodes = visibleNodes.filter((n) => {
    const asset = useWorkspaceStore.getState().assetsById[n.id];
    if (!asset) return true;
    return isAssetVisibleInLayers(asset.assetKind, layerSet);
  });

  const filteredEdges = visibleEdges.filter((e) => {
    const edge = useWorkspaceStore.getState().edgesById[e.id];
    if (!edge) return true;
    return isEdgeVisibleInLayers(edge, layerSet);
  });

  return (
    <ReactFlow
      nodes={filteredNodes}
      edges={filteredEdges}
      onNodesChange={handleNodesChange}
      onNodeClick={(_, node) => selectAsset(node.id)}
      onNodeMouseEnter={(_, node) => setHoveredAsset(node.id)}
      onNodeMouseLeave={() => setHoveredAsset(null)}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      nodesDraggable
      fitView
      minZoom={0.05}
      maxZoom={3}
    >
      <Background />
      <SwimlaneBackground />
      <Controls position="bottom-left" />
    </ReactFlow>
  );
}

function SplitPaneWrapper({
  layer,
  onViewportChange,
  syncViewport,
}: {
  layer: LayerId;
  onViewportChange: (vp: Viewport) => void;
  syncViewport: Viewport | null;
}) {
  return (
    <ReactFlowProvider>
      <SplitPane
        layer={layer}
        onViewportChange={onViewportChange}
        syncViewport={syncViewport}
      />
    </ReactFlowProvider>
  );
}

// ---------------------------------------------------------------------------
// Main split view
// ---------------------------------------------------------------------------

export interface SplitCanvasViewProps {
  trustView?: boolean;
}

export function SplitCanvasView({}: SplitCanvasViewProps) {
  const [leftLayer, setLeftLayer] = useState<LayerId>('execution');
  const [rightLayer, setRightLayer] = useState<LayerId>('knowledge');

  // Viewport sync: each pane reports its viewport; the other receives it.
  const [leftVp, setLeftVp] = useState<Viewport | null>(null);
  const [rightVp, setRightVp] = useState<Viewport | null>(null);
  const lastSourceRef = useRef<'left' | 'right' | null>(null);

  const handleLeftVpChange = useCallback((vp: Viewport) => {
    lastSourceRef.current = 'left';
    setRightVp(vp);
  }, []);

  const handleRightVpChange = useCallback((vp: Viewport) => {
    lastSourceRef.current = 'right';
    setLeftVp(vp);
  }, []);

  return (
    <div className="flex h-full w-full">
      {/* Left pane */}
      <div className="flex flex-1 flex-col border-r">
        <SplitLayerPicker
          activeLayer={leftLayer}
          onChange={setLeftLayer}
          side="left"
        />
        <div className="flex-1">
          <SplitPaneWrapper
            layer={leftLayer}
            onViewportChange={handleLeftVpChange}
            syncViewport={lastSourceRef.current === 'right' ? leftVp : null}
          />
        </div>
      </div>

      {/* Right pane */}
      <div className="flex flex-1 flex-col">
        <SplitLayerPicker
          activeLayer={rightLayer}
          onChange={setRightLayer}
          side="right"
        />
        <div className="flex-1">
          <SplitPaneWrapper
            layer={rightLayer}
            onViewportChange={handleRightVpChange}
            syncViewport={lastSourceRef.current === 'left' ? rightVp : null}
          />
        </div>
      </div>
    </div>
  );
}
