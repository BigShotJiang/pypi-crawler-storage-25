'use client';

/**
 * WorkspaceCanvas — multi-layer canvas powered by the unified
 * workspace store.
 *
 * Reuses the same node/edge components as ConceptCanvas. All store
 * subscriptions use scalar selectors or useShallow to prevent the
 * Zustand render loop (useSyncExternalStore infinite update).
 */

import { useCallback, useMemo, useRef, useState } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  Controls,
  Panel,
  type Node,
  type Edge,
  type NodeTypes,
  type EdgeTypes,
  type Connection,
  useOnViewportChange,
  useReactFlow,
  type Viewport,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import {
  ConceptNodeView,
  type ConceptZoomLevel,
} from '@/components/editor-v2/canvas/ConceptNodeView';
import { ContractFieldNode } from '@/components/editor-v2/canvas/ContractFieldNode';
import { PipelineStepNode } from '@/components/editor-v2/canvas/PipelineStepNode';
import { PipelineDataEdge } from '@/components/editor-v2/canvas/PipelineDataEdge';
import { MappingEdge } from '@/components/unified-editor/edges/MappingEdge';
import { RelationshipTypePopover } from '@/components/editor-v2/canvas/RelationshipTypePopover';
import { useWorkspaceNodes } from '@/components/editor-v2/canvas/hooks/useWorkspaceNodes';
import { useWorkspaceEdges } from '@/components/editor-v2/canvas/hooks/useWorkspaceEdges';
import { useWorkspaceStore } from '@/stores/editor-v2/workspace';
import type {
  ConceptAsset,
  SourceAsset,
  JobAsset,
  ConsumerAsset,
} from '@/lib/editor-v2/asset-types';
import { assetIdFor, defaultLayersForKind, defaultZoneForKind } from '@/lib/editor-v2/asset-types';
import {
  CONCEPT_TYPE_DRAG_MIME,
  CONCEPT_TYPES,
  type RelationshipTypeOption,
} from '@/lib/editor-v2/concept-types';
import { PIPELINE_STEP_DRAG_MIME } from '@/components/editor-v2/shell/PipelinePaletteTab';
import type { PipelineStepType } from '@/lib/editor-v2/pipeline-types';
import { pipelineStepTypeToAssetKind } from '@/lib/editor-v2/layer-config';

// Stable module-level nodeTypes / edgeTypes — never recreated.
const nodeTypes: NodeTypes = {
  concept: ConceptNodeView as unknown as NodeTypes[string],
  'contract-field': ContractFieldNode as unknown as NodeTypes[string],
  'pipeline-step': PipelineStepNode as unknown as NodeTypes[string],
};
const edgeTypes: EdgeTypes = {
  mapping: MappingEdge as unknown as EdgeTypes[string],
  'pipeline-data': PipelineDataEdge as unknown as EdgeTypes[string],
};

function neighborhood(
  startId: string,
  edges: Edge[],
  depth: number,
): Set<string> {
  if (depth <= 0) return new Set([startId]);
  const visited = new Set([startId]);
  let frontier = new Set([startId]);
  for (let hop = 0; hop < depth; hop++) {
    const next = new Set<string>();
    for (const edge of edges) {
      if (frontier.has(edge.source) && !visited.has(edge.target)) {
        next.add(edge.target);
        visited.add(edge.target);
      }
      if (frontier.has(edge.target) && !visited.has(edge.source)) {
        next.add(edge.source);
        visited.add(edge.source);
      }
    }
    if (next.size === 0) break;
    frontier = next;
  }
  return visited;
}

// ------------------------------------------------------------------
// Inner canvas
// ------------------------------------------------------------------

function WorkspaceCanvasInner({
  trustView,
  onInspectorOpen,
  onInspectorClose,
}: {
  trustView?: boolean;
  onInspectorOpen?: () => void;
  onInspectorClose?: () => void;
}) {
  // RULE: Only subscribe to SCALAR values or STABLE FUNCTION references
  // from the store. Never subscribe to objects/arrays/Sets directly.
  const addAsset = useWorkspaceStore((s) => s.addAsset);
  const addEdge = useWorkspaceStore((s) => s.addEdge);
  const clearSelection = useWorkspaceStore((s) => s.clearSelection);
  const setHoveredAsset = useWorkspaceStore((s) => s.setHoveredAsset);

  // Scalar selectors — safe, no fresh references.
  const selectedAssetId = useWorkspaceStore(
    (s) => (s.selection.kind === 'asset' ? s.selection.id : null),
  );

  const [zoomLevel, setZoomLevel] = useState<ConceptZoomLevel>('full');
  const [neighborhoodDepth, setNeighborhoodDepth] = useState(0);
  const [pendingConnection, setPendingConnection] = useState<{
    source: string;
    target: string;
    screenPos: { x: number; y: number };
  } | null>(null);
  const reactFlowInstance = useReactFlow();

  useOnViewportChange({
    onChange: useCallback((viewport: Viewport) => {
      const next: ConceptZoomLevel =
        viewport.zoom > 0.7 ? 'full' : viewport.zoom > 0.3 ? 'dot' : 'cluster';
      setZoomLevel((prev) => (prev === next ? prev : next));
    }, []),
  });

  // Stable callbacks — use getState() to avoid subscribing.
  const buildConceptCallbacks = useCallback(
    (asset: ConceptAsset) => ({
      onRename:
        asset.tier === 'core'
          ? null
          : (next: string) =>
              useWorkspaceStore.getState().updateAsset(asset.id, { label: next }),
      onAddSlot:
        asset.tier === 'core'
          ? null
          : () => {
              const current = useWorkspaceStore.getState().assetsById[asset.id] as ConceptAsset | undefined;
              const existing = current?.slots ?? [];
              let name = 'newAttribute';
              let suffix = 2;
              while (existing.some((s) => s.name === name)) {
                name = `newAttribute_${suffix}`;
                suffix += 1;
              }
              useWorkspaceStore.getState().updateAsset(asset.id, {
                slots: [...existing, { name, data_type: 'string' }],
              } as Partial<ConceptAsset>);
            },
    }),
    [],
  );

  const buildStepCallbacks = useCallback(
    (asset: SourceAsset | JobAsset | ConsumerAsset) => ({
      onRename: (next: string) =>
        useWorkspaceStore.getState().updateAsset(asset.id, { label: next }),
    }),
    [],
  );

  // Nodes and edges via workspace hooks.
  const { visibleNodes: allNodes, handleNodesChange } = useWorkspaceNodes({
    zoomLevel,
    buildConceptCallbacks,
    buildStepCallbacks,
    allowedIds: null,
  });
  const { semanticEdges, visibleEdges: allEdges } = useWorkspaceEdges({
    trustView,
    allowedIds: null,
  });

  // Neighborhood filter.
  const allowedIds = useMemo<Set<string> | null>(() => {
    if (neighborhoodDepth <= 0 || !selectedAssetId) return null;
    return neighborhood(selectedAssetId, semanticEdges, neighborhoodDepth);
  }, [semanticEdges, neighborhoodDepth, selectedAssetId]);

  const visibleNodes = useMemo(() => {
    if (!allowedIds) return allNodes;
    return allNodes.filter(
      (n) => n.type !== 'concept' || allowedIds.has(n.id),
    );
  }, [allNodes, allowedIds]);

  const visibleEdges = useMemo(() => {
    if (!allowedIds) return allEdges;
    return allEdges.filter(
      (e) =>
        e.type !== 'default' ||
        (allowedIds.has(e.source) && allowedIds.has(e.target)),
    );
  }, [allEdges, allowedIds]);

  // --- Interaction handlers ---
  // All use getState() for store writes to avoid extra subscriptions.

  const handleNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      useWorkspaceStore.getState().selectAsset(node.id);
    },
    [],
  );

  const handleNodeDoubleClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      useWorkspaceStore.setState({
        selection: { kind: 'asset', id: node.id },
        focusedAssetId: node.id,
      });
      onInspectorOpen?.();
    },
    [onInspectorOpen],
  );

  const handlePaneClick = useCallback(() => {
    useWorkspaceStore.getState().clearSelection();
    onInspectorClose?.();
  }, [onInspectorClose]);

  const handleNodeMouseEnter = useCallback(
    (_: React.MouseEvent, node: Node) => {
      useWorkspaceStore.getState().setHoveredAsset(node.id);
    },
    [],
  );
  const handleNodeMouseLeave = useCallback(() => {
    useWorkspaceStore.getState().setHoveredAsset(null);
  }, []);

  const handleConnect = useCallback(
    (connection: Connection) => {
      const { source, target } = connection;
      if (!source || !target) return;

      if (source.startsWith('concept:') && target.startsWith('concept:')) {
        const screenPos = reactFlowInstance.flowToScreenPosition({ x: 0, y: 0 });
        setPendingConnection({ source, target, screenPos });
        return;
      }

      const store = useWorkspaceStore.getState();
      if (
        !source.startsWith('concept:') && !target.startsWith('concept:')
      ) {
        store.addEdge({
          id: `flow:local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          kind: 'data-flow',
          sourceAssetId: source,
          targetAssetId: target,
          layer: 'execution',
          data: { inputLabel: null, trustStatus: 'ungoverned' },
          label: null,
        });
        return;
      }

      store.addEdge({
        id: `map:local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        kind: 'mapping',
        sourceAssetId: source,
        targetAssetId: target,
        layer: 'knowledge',
        data: { mappingType: 'direct', bindingKind: 'primary', relationship: null },
        label: null,
      });
    },
    [reactFlowInstance],
  );

  const cancelPendingConnection = useCallback(() => {
    setPendingConnection(null);
  }, []);

  const confirmConnection = useCallback(
    (option: RelationshipTypeOption) => {
      if (!pendingConnection) return;
      setPendingConnection(null);
      useWorkspaceStore.getState().addEdge({
        id: `rel:local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        kind: 'semantic-rel',
        sourceAssetId: pendingConnection.source,
        targetAssetId: pendingConnection.target,
        layer: 'knowledge',
        data: { relationshipType: option.id, cardinality: null, metadata: null },
        label: option.id,
      });
    },
    [pendingConnection],
  );

  const handleDragOver = useCallback((event: React.DragEvent) => {
    const types = Array.from(event.dataTransfer.types);
    if (
      types.includes(CONCEPT_TYPE_DRAG_MIME) ||
      types.includes(PIPELINE_STEP_DRAG_MIME)
    ) {
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    }
  }, []);

  const handleDrop = useCallback(
    (event: React.DragEvent) => {
      const store = useWorkspaceStore.getState();
      const conceptRaw = event.dataTransfer.getData(CONCEPT_TYPE_DRAG_MIME);
      if (conceptRaw && (CONCEPT_TYPES as readonly string[]).includes(conceptRaw)) {
        event.preventDefault();
        const pos = reactFlowInstance.screenToFlowPosition({
          x: event.clientX,
          y: event.clientY,
        });
        const id = `local-concept-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        store.addAsset({
          id: assetIdFor('concept', id),
          assetKind: 'concept',
          label: conceptRaw.charAt(0).toUpperCase() + conceptRaw.slice(1),
          description: null,
          position: pos,
          layers: defaultLayersForKind('concept'),
          zone: defaultZoneForKind('concept'),
          conceptKey: `new_${id}`,
          conceptType: conceptRaw,
          tier: 'free',
          parentConceptKey: null,
          slots: [],
          metadata: null,
        });
        return;
      }

      const pipelineRaw = event.dataTransfer.getData(PIPELINE_STEP_DRAG_MIME);
      if (pipelineRaw) {
        event.preventDefault();
        const pos = reactFlowInstance.screenToFlowPosition({
          x: event.clientX,
          y: event.clientY,
        });
        const kind = pipelineStepTypeToAssetKind(pipelineRaw);
        const id = `local-step-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const base = {
          id: assetIdFor('step', id),
          label: pipelineRaw.charAt(0).toUpperCase() + pipelineRaw.slice(1),
          description: null,
          position: pos,
          layers: defaultLayersForKind(kind),
          zone: defaultZoneForKind(kind),
        };
        if (kind === 'source') {
          store.addAsset({ ...base, assetKind: 'source', stepType: 'extract', config: {}, annotation: null, contract: null });
        } else if (kind === 'consumer') {
          store.addAsset({ ...base, assetKind: 'consumer', consumerType: null, config: {} });
        } else {
          store.addAsset({ ...base, assetKind: 'job', stepType: pipelineRaw as PipelineStepType, config: {}, annotation: null, contract: null, executionStatus: 'idle' });
        }
      }
    },
    [reactFlowInstance],
  );

  // Popover labels — read from store snapshot, not via subscription.
  const pendingSourceRef = useRef<string>('Source');
  const pendingTargetRef = useRef<string>('Target');
  if (pendingConnection) {
    const s = useWorkspaceStore.getState();
    pendingSourceRef.current = s.assetsById[pendingConnection.source]?.label ?? 'Source';
    pendingTargetRef.current = s.assetsById[pendingConnection.target]?.label ?? 'Target';
  }

  return (
    <div
      className="h-full w-full"
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <ReactFlow
        nodes={visibleNodes}
        edges={visibleEdges}
        onNodesChange={handleNodesChange}
        onNodeClick={handleNodeClick}
        onNodeDoubleClick={handleNodeDoubleClick}
        onPaneClick={handlePaneClick}
        onNodeMouseEnter={handleNodeMouseEnter}
        onNodeMouseLeave={handleNodeMouseLeave}
        onConnect={handleConnect}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        nodesDraggable
        fitView
        minZoom={0.05}
        maxZoom={3}
      >
        <Background />
        <Controls />
        <Panel position="top-left">
          <div className="flex items-center gap-1 rounded-lg border bg-background/90 p-1.5 text-[10px] shadow-sm backdrop-blur">
            <span className="font-semibold text-muted-foreground">Neighborhood</span>
            {[0, 1, 2, 3].map((depth) => (
              <button
                key={depth}
                onClick={() => setNeighborhoodDepth(depth)}
                className={[
                  'rounded px-1.5 py-0.5',
                  neighborhoodDepth === depth
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted',
                ].join(' ')}
                type="button"
              >
                {depth === 0 ? 'All' : `${depth}-hop`}
              </button>
            ))}
          </div>
        </Panel>
        <Panel position="bottom-left">
          <div className="rounded-md border bg-background/90 px-2 py-1 text-[10px] text-muted-foreground shadow-sm backdrop-blur">
            Zoom: <span className="font-medium text-foreground">{zoomLevel}</span>
            {' · '}{visibleNodes.length} nodes
          </div>
        </Panel>
      </ReactFlow>
      {pendingConnection && (
        <RelationshipTypePopover
          open
          position={pendingConnection.screenPos}
          sourceName={pendingSourceRef.current}
          targetName={pendingTargetRef.current}
          onSelect={confirmConnection}
          onCancel={cancelPendingConnection}
        />
      )}
    </div>
  );
}

// ------------------------------------------------------------------
// Public component
// ------------------------------------------------------------------

export interface WorkspaceCanvasProps {
  trustView?: boolean;
  inspectorOpen?: boolean;
  onInspectorOpen?: () => void;
  onInspectorClose?: () => void;
}

export function WorkspaceCanvas({
  trustView,
  onInspectorOpen,
  onInspectorClose,
}: WorkspaceCanvasProps) {
  return (
    <ReactFlowProvider>
      <WorkspaceCanvasInner
        trustView={trustView}
        onInspectorOpen={onInspectorOpen}
        onInspectorClose={onInspectorClose}
      />
    </ReactFlowProvider>
  );
}
