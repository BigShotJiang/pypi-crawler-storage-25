'use client';

/**
 * SwimlaneBackground — renders vertical zone separator lines and
 * labels at the top of the canvas. Gives users a stable mental model:
 *   Sources → Processing → Governed Assets → Knowledge Assets → Consumers
 *
 * Rendered as a ReactFlow Panel so it stays fixed relative to the
 * canvas viewport.
 */

import { useViewport } from '@xyflow/react';
import { ZONES, ZONE_ORDER } from '@/lib/editor-v2/layer-config';

export function SwimlaneBackground(): React.ReactElement {
  const { x: vpX, y: vpY, zoom } = useViewport();

  return (
    <svg
      className="pointer-events-none absolute inset-0"
      style={{ zIndex: 0, overflow: 'visible' }}
    >
      {ZONE_ORDER.map((zoneId, idx) => {
        const zone = ZONES[zoneId];
        const leftEdge = zone.centerX - zone.width / 2;

        // Transform canvas coordinates to screen coordinates.
        const screenX = leftEdge * zoom + vpX;
        const labelScreenX = zone.centerX * zoom + vpX;

        return (
          <g key={zoneId}>
            {/* Vertical separator line (skip the leftmost edge). */}
            {idx > 0 && (
              <line
                x1={screenX}
                y1={0}
                x2={screenX}
                y2="100%"
                stroke="hsl(var(--border))"
                strokeWidth={1}
                strokeDasharray="8 6"
                opacity={0.4}
              />
            )}
            {/* Zone label at top. */}
            <text
              x={labelScreenX}
              y={24}
              textAnchor="middle"
              fill="hsl(var(--muted-foreground))"
              fontSize={11}
              fontWeight={600}
              opacity={0.5}
              style={{ userSelect: 'none' }}
            >
              {zone.name}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
