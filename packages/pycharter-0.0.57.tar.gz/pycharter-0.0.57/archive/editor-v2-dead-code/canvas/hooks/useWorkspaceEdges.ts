'use client';

/**
 * useWorkspaceEdges — derives ReactFlow Edges from the unified
 * workspace store. Replaces useCanvasEdges when the workspace store
 * is active.
 *
 * Maps each UnifiedEdge to the ReactFlow Edge type expected by the
 * existing edge components (PipelineDataEdge, MappingEdge, default).
 *
 * Applies hover highlighting: edges connected to the hovered node
 * get bright stroke + animated dashes, matching the legacy pattern.
 */

import { useMemo } from 'react';
import type { Edge } from '@xyflow/react';
import { useShallow } from 'zustand/react/shallow';

import type { UnifiedEdge } from '@/lib/editor-v2/edge-types';
import { reactFlowEdgeType } from '@/lib/editor-v2/edge-types';
import { useWorkspaceStore } from '@/stores/editor-v2/workspace';
import { selectVisibleEdges } from '@/stores/editor-v2/workspace-selectors';

// ---------------------------------------------------------------------------
// UnifiedEdge -> ReactFlow Edge
// ---------------------------------------------------------------------------

function unifiedEdgeToFlowEdge(
  edge: UnifiedEdge,
  trustView: boolean,
): Edge {
  const flowType = reactFlowEdgeType(edge.kind);

  switch (edge.kind) {
    case 'data-flow': {
      const d = edge.data as {
        inputLabel: string | null;
        trustStatus: string;
      };
      return {
        id: edge.id,
        source: edge.sourceAssetId,
        target: edge.targetAssetId,
        type: flowType,
        label: d.inputLabel ?? undefined,
        data: {
          trustView,
          trustStatus: d.trustStatus,
        },
      };
    }
    case 'contract-binding':
    case 'mapping': {
      const d = edge.data as {
        mappingType?: string;
        bindingKind?: string;
        relationship?: string | null;
      };
      return {
        id: edge.id,
        source: edge.sourceAssetId,
        target: edge.targetAssetId,
        type: flowType,
        sourceHandle: 'field-source',
        targetHandle: 'concept-target',
        data: {
          mappingType: d.mappingType ?? 'direct',
          bindingKind: d.bindingKind ?? 'primary',
          relationshipType: d.relationship ?? undefined,
        },
      };
    }
    case 'semantic-rel': {
      const d = edge.data as { relationshipType: string };
      return {
        id: edge.id,
        source: edge.sourceAssetId,
        target: edge.targetAssetId,
        type: 'default',
        label: d.relationshipType,
      };
    }
    case 'foreign-key': {
      return {
        id: edge.id,
        source: edge.sourceAssetId,
        target: edge.targetAssetId,
        type: flowType,
        data: edge.data as unknown as Record<string, unknown>,
      };
    }
    case 'schema-rel':
    case 'cross-layer':
    default:
      return {
        id: edge.id,
        source: edge.sourceAssetId,
        target: edge.targetAssetId,
        type: 'default',
        label: edge.label ?? undefined,
        style: edge.kind === 'cross-layer'
          ? { strokeDasharray: '6 3', opacity: 0.5 }
          : undefined,
      };
  }
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export interface UseWorkspaceEdgesResult {
  /** Concept/semantic edges (for neighborhood filtering). */
  semanticEdges: Edge[];
  /** All visible edges with hover highlighting applied. */
  visibleEdges: Edge[];
}

export function useWorkspaceEdges({
  trustView,
  allowedIds,
}: {
  trustView?: boolean;
  allowedIds: Set<string> | null;
}): UseWorkspaceEdgesResult {
  const unifiedEdges = useWorkspaceStore(useShallow(selectVisibleEdges));
  const hoveredAssetId = useWorkspaceStore((s) => s.hoveredAssetId);

  // Map unified edges to ReactFlow edges.
  const flowEdges = useMemo(
    () => unifiedEdges.map((e) => unifiedEdgeToFlowEdge(e, !!trustView)),
    [unifiedEdges, trustView],
  );

  // Separate semantic edges for neighborhood filtering.
  const semanticEdges = useMemo(
    () => flowEdges.filter((e) =>
      unifiedEdges.find((ue) => ue.id === e.id)?.kind === 'semantic-rel',
    ),
    [flowEdges, unifiedEdges],
  );

  // Apply neighborhood filter and hover highlighting.
  const visibleEdges = useMemo(() => {
    // Filter semantic edges by neighborhood; non-semantic always pass.
    const semanticIds = new Set(semanticEdges.map((e) => e.id));
    let filtered = flowEdges;
    if (allowedIds !== null) {
      filtered = flowEdges.filter(
        (e) =>
          !semanticIds.has(e.id) ||
          (allowedIds.has(e.source) && allowedIds.has(e.target)),
      );
    }

    // Hover highlighting: edges connected to hovered node get bright
    // stroke + animated dashes (same as legacy canvas pattern).
    if (!hoveredAssetId) return filtered;
    return filtered.map((e) => {
      const isConnected =
        e.source === hoveredAssetId || e.target === hoveredAssetId;
      if (!isConnected) return e;
      return {
        ...e,
        style: {
          ...e.style,
          stroke: 'hsl(var(--primary))',
          strokeWidth: 2.5,
          strokeDasharray: '8 4',
        },
        animated: true,
      };
    });
  }, [flowEdges, semanticEdges, allowedIds, hoveredAssetId]);

  return { semanticEdges, visibleEdges };
}
