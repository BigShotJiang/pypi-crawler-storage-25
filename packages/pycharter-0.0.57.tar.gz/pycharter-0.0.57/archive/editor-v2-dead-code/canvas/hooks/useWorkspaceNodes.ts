'use client';

/**
 * useWorkspaceNodes — derives ReactFlow Nodes from the unified
 * workspace store. Replaces useCanvasNodes when the workspace store
 * is active.
 *
 * Maps each Asset to the ReactFlow Node type expected by the existing
 * node components (ConceptNodeView, PipelineStepNode, ContractFieldNode)
 * so those components are reused without changes.
 *
 * Manages local position state for drag, persists drag-end back to
 * the workspace store, and supports neighborhood filtering.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  applyNodeChanges,
  type Node,
  type NodeChange,
} from '@xyflow/react';
import { useShallow } from 'zustand/react/shallow';

import type {
  ConceptZoomLevel,
} from '@/components/editor-v2/canvas/ConceptNodeView';
import type { Asset, ConceptAsset, JobAsset, SourceAsset, ConsumerAsset, ContractAsset } from '@/lib/editor-v2/asset-types';
import { rawIdFromAssetId } from '@/lib/editor-v2/asset-types';
import { useWorkspaceStore } from '@/stores/editor-v2/workspace';
import {
  selectVisibleAssets,
} from '@/stores/editor-v2/workspace-selectors';

// ---------------------------------------------------------------------------
// Asset -> ReactFlow Node mapping
// ---------------------------------------------------------------------------

function assetToFlowNode(
  asset: Asset,
  zoomLevel: ConceptZoomLevel,
  buildConceptCallbacks: (asset: ConceptAsset) => {
    onRename: ((next: string) => void) | null;
    onAddSlot: (() => void) | null;
  },
  buildStepCallbacks: (asset: SourceAsset | JobAsset | ConsumerAsset) => {
    onRename: ((next: string) => void) | null;
  },
): Node {
  switch (asset.assetKind) {
    case 'concept': {
      const a = asset as ConceptAsset;
      const cbs = buildConceptCallbacks(a);
      return {
        id: a.id,
        type: 'concept',
        position: a.position,
        data: {
          conceptId: rawIdFromAssetId(a.id),
          conceptKey: a.conceptKey,
          name: a.label,
          conceptType: a.conceptType,
          tier: a.tier,
          description: a.description,
          slots: a.slots ?? [],
          zoomLevel,
          onRename: cbs.onRename,
          onAddSlot: cbs.onAddSlot,
        },
      };
    }
    case 'source':
    case 'job':
    case 'consumer': {
      const a = asset as SourceAsset | JobAsset | ConsumerAsset;
      const stepType =
        a.assetKind === 'source'
          ? 'extract'
          : a.assetKind === 'consumer'
            ? 'consumer'
            : (a as JobAsset).stepType;
      const cbs = buildStepCallbacks(a);
      return {
        id: a.id,
        type: 'pipeline-step',
        position: a.position,
        data: {
          stepId: rawIdFromAssetId(a.id),
          stepType,
          label: a.label,
          annotation: a.description,
          hasContract: !!(a as SourceAsset | JobAsset).contract,
          executionStatus:
            a.assetKind === 'job'
              ? (a as JobAsset).executionStatus
              : 'idle',
          onRename: cbs.onRename,
        },
      };
    }
    case 'contract': {
      const a = asset as ContractAsset;
      return {
        id: a.id,
        type: 'contract-field',
        position: a.position,
        draggable: false,
        data: {
          fieldPath: a.fieldPath ?? a.label,
          contractId: a.contractId,
          contractVersion: a.contractVersion,
        },
      };
    }
    default: {
      // Fallback for dataset, table, document-collection, vector-index.
      // Render as a generic concept-style node until dedicated components exist.
      return {
        id: asset.id,
        type: 'concept',
        position: asset.position,
        data: {
          conceptId: rawIdFromAssetId(asset.id),
          conceptKey: asset.id,
          name: asset.label,
          conceptType: null,
          tier: 'free',
          description: asset.description,
          slots: [],
          zoomLevel,
          onRename: null,
          onAddSlot: null,
        },
      };
    }
  }
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export interface UseWorkspaceNodesResult {
  visibleNodes: Node[];
  handleNodesChange: (changes: NodeChange[]) => void;
}

export function useWorkspaceNodes({
  zoomLevel,
  buildConceptCallbacks,
  buildStepCallbacks,
  allowedIds,
}: {
  zoomLevel: ConceptZoomLevel;
  buildConceptCallbacks: (asset: ConceptAsset) => {
    onRename: ((next: string) => void) | null;
    onAddSlot: (() => void) | null;
  };
  buildStepCallbacks: (asset: SourceAsset | JobAsset | ConsumerAsset) => {
    onRename: ((next: string) => void) | null;
  };
  allowedIds: Set<string> | null;
}): UseWorkspaceNodesResult {
  const assets = useWorkspaceStore(useShallow(selectVisibleAssets));
  const updateAsset = useWorkspaceStore((s) => s.updateAsset);

  // Map assets to ReactFlow nodes.
  const derivedNodes = useMemo(
    () =>
      assets.map((a) =>
        assetToFlowNode(a, zoomLevel, buildConceptCallbacks, buildStepCallbacks),
      ),
    [assets, zoomLevel, buildConceptCallbacks, buildStepCallbacks],
  );

  // Local node state so ReactFlow can apply drag position changes.
  const [flowNodes, setFlowNodes] = useState<Node[]>(derivedNodes);

  // Track whether any node is actively being dragged. During drag,
  // skip syncing derived nodes into local state to prevent the
  // render loop: drag → updateAsset → new assetsById → new
  // derivedNodes → setFlowNodes → re-render → ReactFlow fires
  // onNodesChange again.
  const isDraggingRef = useRef(false);

  // Sync derived nodes into local state, preserving drag positions.
  useEffect(() => {
    if (isDraggingRef.current) return;
    setFlowNodes((current) => {
      const currentById = new Map(current.map((n) => [n.id, n]));
      return derivedNodes.map((d) => {
        const existing = currentById.get(d.id);
        return existing ? { ...d, position: existing.position } : d;
      });
    });
  }, [derivedNodes]);

  // Handle position drags. Only persist to store on drag end.
  const handleNodesChange = useCallback(
    (changes: NodeChange[]) => {
      setFlowNodes((current) => applyNodeChanges(changes, current));
      for (const change of changes) {
        if (change.type === 'position') {
          if (change.dragging) {
            isDraggingRef.current = true;
          } else if (change.dragging === false) {
            isDraggingRef.current = false;
            if (change.position) {
              updateAsset(change.id, {
                position: { x: change.position.x, y: change.position.y },
              });
            }
          }
        }
      }
    },
    [updateAsset],
  );

  // Apply neighborhood filter.
  const visibleNodes = useMemo(() => {
    if (allowedIds === null) return flowNodes;
    return flowNodes.filter(
      (n) =>
        allowedIds.has(n.id) ||
        // Pipeline and contract nodes always pass through.
        n.type === 'pipeline-step' ||
        n.type === 'contract-field',
    );
  }, [flowNodes, allowedIds]);

  return { visibleNodes, handleNodesChange };
}
