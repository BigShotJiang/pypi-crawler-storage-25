'use client';

/**
 * SplitLayerPicker — small dropdown at the top of each split pane
 * that lets the user choose which layer that pane shows.
 */

import { Workflow, ShieldCheck, Brain } from 'lucide-react';

import { cn } from '@/lib/utils';
import type { LayerId } from '@/lib/editor-v2/asset-types';
import { LAYERS, LAYER_ORDER } from '@/lib/editor-v2/layer-config';

const ICONS: Record<string, typeof Workflow> = {
  workflow: Workflow,
  'shield-check': ShieldCheck,
  brain: Brain,
};

export interface SplitLayerPickerProps {
  activeLayer: LayerId;
  onChange: (layer: LayerId) => void;
  /** Which side this picker is on, for labeling. */
  side: 'left' | 'right';
}

export function SplitLayerPicker({
  activeLayer,
  onChange,
  side,
}: SplitLayerPickerProps): React.ReactElement {
  return (
    <div className="flex items-center gap-1 border-b bg-background/95 px-2 py-1 text-[10px] backdrop-blur">
      <span className="font-semibold text-muted-foreground uppercase tracking-wider">
        {side}
      </span>
      <div className="flex items-center gap-0.5 rounded border p-0.5">
        {LAYER_ORDER.map((layerId) => {
          const meta = LAYERS[layerId];
          const Icon = ICONS[meta.iconKey] ?? Workflow;
          const isActive = activeLayer === layerId;
          return (
            <button
              key={layerId}
              type="button"
              onClick={() => onChange(layerId)}
              className={cn(
                'inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-medium transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              <Icon className="h-3 w-3" />
              {meta.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}
