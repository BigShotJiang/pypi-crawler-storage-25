'use client';

/**
 * SchemaCanvas — Schema-mode rendering of the editorv2 ontology.
 *
 * Shows the LinkML projection (entities, slots, enums) computed by
 * the backend and attached to every load and save response. The
 * canvas is read-only in this slice — direct schema editing flows
 * through the existing Concept canvas, which is the source of
 * truth.
 *
 * Layout: simple grid via ReactFlow defaults so empty schemes look
 * tidy. Inheritance arrows are derived from each entity's
 * ``parent_class`` field. Enums are not yet rendered as ReactFlow
 * nodes — they appear in a side panel until a future slice adds a
 * dedicated enum node type. The current implementation keeps
 * enums in the bottom-left footer counter so users can confirm
 * the projection was computed and shipped.
 */

import { useMemo } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  Background,
  Controls,
  MiniMap,
  Panel,
  type Node,
  type Edge,
  type NodeTypes,
  type EdgeTypes,
  type NodeProps,
  Handle,
  Position,
  MarkerType,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import {
  selectLinkmlProjection,
  useEditorV2ConceptGraphStore,
} from '@/stores/editor-v2/concept-graph';
import type {
  LinkMLEntity,
  LinkMLSlot,
} from '@/lib/editor-v2/concept-graph-types';

type EntityNodeData = {
  entity: LinkMLEntity;
};

type FlowEntityNode = Node<EntityNodeData, 'linkml-entity'>;

const COLUMNS = 3;
const CELL_WIDTH = 320;
const CELL_HEIGHT = 240;

function layoutEntities(entities: readonly LinkMLEntity[]): FlowEntityNode[] {
  return entities.map((entity, idx) => ({
    id: entity.concept_key,
    type: 'linkml-entity',
    position: {
      x: (idx % COLUMNS) * CELL_WIDTH,
      y: Math.floor(idx / COLUMNS) * CELL_HEIGHT,
    },
    data: { entity },
  }));
}

function buildInheritanceEdges(
  entities: readonly LinkMLEntity[],
): Edge[] {
  const out: Edge[] = [];
  const present = new Set(entities.map((e) => e.concept_key));
  for (const entity of entities) {
    if (entity.parent_class && present.has(entity.parent_class)) {
      out.push({
        id: `is_a:${entity.concept_key}->${entity.parent_class}`,
        source: entity.concept_key,
        target: entity.parent_class,
        type: 'default',
        label: 'is_a',
        markerEnd: { type: MarkerType.ArrowClosed },
      });
    }
  }
  return out;
}

function buildObjectSlotEdges(
  entities: readonly LinkMLEntity[],
): Edge[] {
  const out: Edge[] = [];
  const present = new Set(entities.map((e) => e.concept_key));
  for (const entity of entities) {
    for (const slot of entity.slots ?? []) {
      // Object slots reference another class by name.
      if (slot.relationship_type && present.has(slot.range)) {
        out.push({
          id: `slot:${entity.concept_key}.${slot.name}->${slot.range}`,
          source: entity.concept_key,
          target: slot.range,
          type: 'default',
          label: slot.relationship_type,
          markerEnd: { type: MarkerType.ArrowClosed },
        });
      }
    }
  }
  return out;
}

function EntityNodeView({
  data,
  selected,
}: NodeProps<FlowEntityNode>): React.ReactElement {
  const { entity } = data;
  const primitiveSlots = (entity.slots ?? []).filter(
    (s) => !s.relationship_type,
  );
  return (
    <div
      className={[
        'min-w-[220px] max-w-[280px] rounded-md border bg-background/95 shadow-sm',
        selected ? 'ring-2 ring-primary' : 'hover:shadow-md',
        entity.is_abstract ? 'border-dashed' : 'border-solid',
      ].join(' ')}
    >
      <div className="flex items-center justify-between gap-2 border-b px-2 py-1">
        <span className="truncate text-xs font-semibold">{entity.name}</span>
        <span className="rounded bg-muted px-1 py-0.5 text-[9px] uppercase tracking-wide text-muted-foreground">
          {entity.concept_type}
        </span>
      </div>
      {entity.description && (
        <div className="border-b px-2 py-1 text-[10px] leading-snug text-muted-foreground line-clamp-2">
          {entity.description}
        </div>
      )}
      {primitiveSlots.length === 0 ? (
        <div className="px-2 py-1.5 text-[10px] italic text-muted-foreground">
          No attribute slots
        </div>
      ) : (
        <ul className="divide-y divide-border/60">
          {primitiveSlots.map((slot) => (
            <SlotRow key={slot.name} slot={slot} />
          ))}
        </ul>
      )}
      <Handle type="source" position={Position.Right} className="!h-2 !w-2" />
      <Handle type="target" position={Position.Left} className="!h-2 !w-2" />
    </div>
  );
}

function SlotRow({ slot }: { slot: LinkMLSlot }): React.ReactElement {
  return (
    <li className="flex items-center justify-between gap-1 px-2 py-1 text-[11px]">
      <div className="flex min-w-0 items-center gap-1 truncate">
        <span className="truncate font-mono">{slot.name}</span>
        {slot.is_identifier && (
          <span className="rounded bg-amber-100 px-1 text-[9px] font-semibold text-amber-900 dark:bg-amber-900/30 dark:text-amber-200">
            id
          </span>
        )}
        {slot.required && (
          <span className="rounded bg-blue-100 px-1 text-[9px] font-semibold text-blue-900 dark:bg-blue-900/30 dark:text-blue-200">
            req
          </span>
        )}
      </div>
      <span className="shrink-0 text-[10px] text-muted-foreground">
        {slot.range}
        {slot.multivalued ? '[]' : ''}
      </span>
    </li>
  );
}

const nodeTypes: NodeTypes = {
  'linkml-entity': EntityNodeView as unknown as NodeTypes[string],
};
const edgeTypes: EdgeTypes = {};

function SchemaCanvasInner(): React.ReactElement {
  const projection = useEditorV2ConceptGraphStore(selectLinkmlProjection);

  const nodes = useMemo(
    () => layoutEntities(projection?.entities ?? []),
    [projection],
  );
  const edges = useMemo(() => {
    const entities = projection?.entities ?? [];
    return [
      ...buildInheritanceEdges(entities),
      ...buildObjectSlotEdges(entities),
    ];
  }, [projection]);

  if (!projection || projection.entities.length === 0) {
    return (
      <div className="flex h-full w-full items-center justify-center text-sm text-muted-foreground">
        Schema mode shows entity classes derived from the concept graph.
        Add an entity concept in Concept mode to see it here.
      </div>
    );
  }

  return (
    <div className="h-full w-full">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        fitView
        minZoom={0.05}
        maxZoom={3}
        nodesDraggable
        nodesConnectable={false}
        elementsSelectable
      >
        <Background />
        <Controls />
        <MiniMap className="!bg-background/80 !border" />
        <Panel position="bottom-left">
          <div className="rounded-md border bg-background/90 px-2 py-1 text-[10px] text-muted-foreground shadow-sm backdrop-blur">
            <span>
              {projection.entities.length} entities · {edges.length} edges
            </span>
            {projection.enums.length > 0 && (
              <span className="ml-2">· {projection.enums.length} enums</span>
            )}
            {projection.skipped.length > 0 && (
              <span className="ml-2">
                · {projection.skipped.length} skipped
              </span>
            )}
          </div>
        </Panel>
      </ReactFlow>
    </div>
  );
}

export function SchemaCanvas(): React.ReactElement {
  return (
    <ReactFlowProvider>
      <SchemaCanvasInner />
    </ReactFlowProvider>
  );
}
