'use client';

/**
 * DraftsTab — left-sidebar tab listing draft staging artifacts.
 *
 * Mirrors :class:`SchemesTab` but routes to ``/editor-v2/drafts/{id}``.
 * Reads from the existing ``editorV2Api.listDrafts`` endpoint and
 * shows visibility (private/team/public) plus archived status.
 */

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';

import { editorV2Api, type DraftListItem } from '@/lib/api/editorV2';

export function DraftsTab(): React.ReactElement {
  const [drafts, setDrafts] = useState<DraftListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const result = await editorV2Api.listDrafts();
      setDrafts(result.drafts);
    } catch (err) {
      setLoadError(
        err instanceof Error ? err.message : 'Failed to load drafts',
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center px-4 py-6 text-[11px] text-muted-foreground">
        Loading drafts…
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="px-3 py-3">
        <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-[11px] text-red-800 dark:border-red-900/40 dark:bg-red-950/30 dark:text-red-200">
          <div className="mb-1 font-semibold">Could not load drafts</div>
          <div className="mb-2 break-words">{loadError}</div>
          <button
            type="button"
            onClick={() => void load()}
            className="rounded border border-red-300 bg-white px-2 py-0.5 text-[11px] font-medium text-red-900 hover:bg-red-100 dark:border-red-700 dark:bg-red-950 dark:text-red-100"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (drafts.length === 0) {
    return (
      <div className="px-3 py-4 text-[11px] text-muted-foreground">
        No drafts visible to you yet.
      </div>
    );
  }

  return (
    <ul className="divide-y divide-border/50">
      {drafts.map((draft) => (
        <li key={draft.id}>
          <Link
            href={`/editor-v2/drafts/${draft.id}`}
            className="flex flex-col gap-0.5 px-3 py-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate text-xs font-medium">{draft.name}</span>
              <span className="shrink-0 text-[10px] text-muted-foreground">
                {draft.source_type}
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
              <span className="truncate">
                {draft.namespace ?? draft.owner_id}
              </span>
              <span className="shrink-0">
                {draft.is_archived ? 'archived' : draft.visibility}
              </span>
            </div>
          </Link>
        </li>
      ))}
    </ul>
  );
}
