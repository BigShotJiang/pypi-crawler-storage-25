'use client';

/**
 * EditorV2Sidebar — left workspace panel for the editor-v2 ontology
 * page. Composes the shell-agnostic :class:`WorkspaceSidebar` with
 * editor-v2-specific tabs (Schemes, Drafts, Palette).
 *
 * Schemes + Drafts navigate to existing schemes or staging drafts.
 * Palette holds the draggable concept type cards used by the
 * canvas drop handler in slice A3.
 */

import { FolderOpen, FileText, LayoutGrid, Workflow } from 'lucide-react';

import { WorkspaceSidebar } from '@/components/workspace-shell';
import type {
  WorkspaceSidebarTab,
  SidebarLayoutApi,
} from '@/components/workspace-shell';
import { SchemesTab } from './SchemesTab';
import { DraftsTab } from './DraftsTab';
import { ConceptPaletteTab } from './ConceptPaletteTab';
import { PipelinePaletteTab } from './PipelinePaletteTab';

export interface EditorV2SidebarProps extends Partial<SidebarLayoutApi> {}

export function EditorV2Sidebar(
  props: EditorV2SidebarProps = {},
): React.ReactElement {
  const tabs: WorkspaceSidebarTab[] = [
    {
      id: 'schemes',
      label: 'Schemes',
      icon: <FolderOpen className="h-3.5 w-3.5" />,
      render: () => <SchemesTab />,
    },
    {
      id: 'drafts',
      label: 'Drafts',
      icon: <FileText className="h-3.5 w-3.5" />,
      render: () => <DraftsTab />,
    },
    {
      id: 'palette',
      label: 'Concepts',
      icon: <LayoutGrid className="h-3.5 w-3.5" />,
      render: () => <ConceptPaletteTab />,
    },
    {
      id: 'pipeline',
      label: 'Pipeline',
      icon: <Workflow className="h-3.5 w-3.5" />,
      render: () => <PipelinePaletteTab />,
    },
  ];

  return (
    <WorkspaceSidebar
      tabs={tabs}
      defaultTabId="schemes"
      tabBarLabel="Editor v2 sidebar"
      {...props}
    />
  );
}
