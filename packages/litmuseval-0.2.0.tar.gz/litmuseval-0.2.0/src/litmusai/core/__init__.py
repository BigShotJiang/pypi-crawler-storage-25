"""Core evaluation engine."""
