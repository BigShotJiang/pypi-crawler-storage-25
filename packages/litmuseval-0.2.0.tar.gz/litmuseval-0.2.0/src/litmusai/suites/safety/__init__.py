"""safety test suite."""
