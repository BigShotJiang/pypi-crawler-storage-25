"""planning test suite."""
