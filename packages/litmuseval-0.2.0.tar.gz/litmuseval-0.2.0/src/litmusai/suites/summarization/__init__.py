"""Summarization evaluation suite."""
