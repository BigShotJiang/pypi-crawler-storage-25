"""coding test suite."""
