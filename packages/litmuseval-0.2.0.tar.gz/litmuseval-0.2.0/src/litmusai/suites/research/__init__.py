"""research test suite."""
