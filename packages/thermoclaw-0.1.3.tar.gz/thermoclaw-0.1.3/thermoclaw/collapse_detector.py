"""
thermoclaw.collapse_detector
==============================
Detect weight-decay collapse via the grad_norm / param_norm ratio.

When weight decay is too aggressive, parameter norms shrink faster than
gradient signal can rebuild them. The observable signature is:

    collapse_ratio = ‖g_l‖ / ‖θ_l‖

dropping over time. This is a *direct physical measurement* — no entropy
decomposition, no incommensurable quantities, no formula debates.

Usage::

    from thermoclaw.collapse_detector import CollapseDetector

    detector = CollapseDetector(model, optimizer)
    for batch in loader:
        loss.backward()
        optimizer.step()
        detector.step()
        optimizer.zero_grad()

    recs = detector.get_recommendations()
    # → ["[HIGH] Weight decay collapse in 5 mlp layers: grad/param ratio
    #     dropped 4.2× from early to late training. Reduce weight_decay."]
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

from thermoclaw.layer_utils import detect_layer_type


class CollapseDetector:
    """Track per-layer grad_norm / param_norm to detect weight-decay collapse.

    Parameters
    ----------
    model : nn.Module
    optimizer : torch.optim.Optimizer
    window : int
        Number of recent steps to keep per group for trend analysis.
    """

    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        window: int = 50,
    ):
        self.optimizer = optimizer
        self.window = window
        self._global_step = 0

        self._groups: List[Dict[str, Any]] = []
        for i, pg in enumerate(optimizer.param_groups):
            name = pg.get('name', f'group_{i}')
            params = [p for p in pg['params'] if p.requires_grad]
            if not params:
                continue
            wd = float(pg.get('weight_decay', 0.0))
            self._groups.append({
                'name': name,
                'ltype': detect_layer_type(name),
                'params': params,
                'weight_decay': wd,
                'history': [],       # list of (grad_norm, param_norm, ratio)
            })

    def step(self) -> Dict[str, float]:
        """Record grad_norm / param_norm for each group. Call before zero_grad()."""
        self._global_step += 1
        ratios: Dict[str, float] = {}

        for gs in self._groups:
            params = gs['params']
            grads = [p.grad for p in params if p.grad is not None]
            if not grads:
                continue

            gnorm = math.sqrt(sum(
                float(torch.sum(g.float() ** 2)) for g in grads
            ))
            pnorm = math.sqrt(sum(
                float(torch.sum(p.data.float() ** 2)) for p in params
            ))
            gnorm = float(gnorm)
            pnorm = float(pnorm)
            ratio = gnorm / (pnorm + 1e-30)

            gs['history'].append((gnorm, pnorm, ratio))
            if len(gs['history']) > self.window * 4:
                # Keep enough for early-vs-late comparison
                pass  # Don't trim — we need early data too

            ratios[gs['name']] = ratio

        return ratios

    def get_recommendations(self) -> List[str]:
        """Detect weight-decay collapse from observable trends.

        Two signals, both trend-based (no absolute thresholds to calibrate):

        1. **Ratio collapse**: grad_norm / param_norm drops ≥ 2× from
           early to late training — params shrinking faster than gradient
           signal can rebuild.

        2. **Param norm shrinkage**: ‖θ‖ drops ≥ 4% from early to late —
           direct evidence that weight decay is eroding capacity.
           Threshold is intentionally low so the signal fires on short runs
           (50+ steps) where collapse may only produce a few percent of drop.
           Clean baselines (wd ≤ 0.01) show < 0.2% drift — the gap is wide.
        """
        if self._global_step < 20:
            return []

        recs: List[str] = []
        collapsing: Dict[str, List[str]] = defaultdict(list)
        collapse_ratios: Dict[str, float] = {}
        shrinking: Dict[str, List[str]] = defaultdict(list)
        shrink_pcts: Dict[str, float] = {}

        for gs in self._groups:
            if gs['weight_decay'] <= 0:
                continue
            history = gs['history']
            if len(history) < 20:
                continue

            n = len(history)
            ltype = gs['ltype']
            name = gs['name']
            # Adaptive window: always at least 10 steps so short-history
            # estimates are stable; quarter-based for long histories.
            win = max(10, n // 4)
            early = history[:win]
            late = history[n - win:]

            # ── Signal 1: Ratio collapse ──────────────────────────────────
            early_ratio = float(np.mean([h[2] for h in early]))
            late_ratio = float(np.mean([h[2] for h in late]))

            # ── Signal 2: Param norm shrinkage ────────────────────────────
            early_pnorm = float(np.mean([h[1] for h in early]))
            late_pnorm = float(np.mean([h[1] for h in late]))

            if early_ratio > 1e-20:
                drop_factor = early_ratio / (late_ratio + 1e-30)
                # Guard: only fire if param norm is not growing.
                # Healthy convergence from scratch = gradients shrink as model
                # fits data, param norm grows → ratio drops innocuously.
                # Weight-decay collapse = param norm shrinks → ratio drops
                # because capacity is being eroded, not because model converged.
                if drop_factor > 2.0 and late_pnorm <= early_pnorm:
                    collapsing[ltype].append(name)
                    collapse_ratios[name] = drop_factor
            if early_pnorm > 1e-20:
                shrink_pct = 1.0 - late_pnorm / early_pnorm
                if shrink_pct > 0.025:  # >2.5% param norm loss
                    shrinking[ltype].append(name)
                    shrink_pcts[name] = shrink_pct

        # ── Ratio collapse recommendations ────────────────────────────────
        for ltype, names in collapsing.items():
            if len(names) >= 2:
                mean_drop = float(np.mean([collapse_ratios[n] for n in names]))
                confidence = "HIGH" if mean_drop > 3.0 else "MEDIUM"
                recs.append(
                    f"[{confidence}] Weight decay collapse in {len(names)} {ltype} "
                    f"layers: grad/param ratio dropped {mean_drop:.1f}× from early "
                    f"to late training. Reduce weight_decay for {ltype} layers by "
                    f"{max(2, int(mean_drop))}×."
                )
            else:
                name = names[0]
                drop = collapse_ratios[name]
                if drop > 2.5:
                    recs.append(
                        f"[MEDIUM] {name} ({ltype}): grad/param ratio dropped "
                        f"{drop:.1f}× — weight decay may be too aggressive."
                    )

        # ── Param shrinkage recommendations ───────────────────────────────
        already_flagged = set(
            n for names in collapsing.values() for n in names
        )
        for ltype, names in shrinking.items():
            unflagged = [n for n in names if n not in already_flagged]
            if len(unflagged) >= 2:
                mean_pct = float(np.mean([shrink_pcts[n] for n in unflagged]))
                confidence = "HIGH" if mean_pct > 0.20 else "MEDIUM"
                recs.append(
                    f"[{confidence}] Weight decay is eroding {len(unflagged)} "
                    f"{ltype} layers: param norms dropped {mean_pct:.0%} during "
                    f"training. Reduce weight_decay."
                )

        return recs

    @property
    def is_collapsing(self) -> bool:
        """True if any collapse signal has fired — convenient intervention trigger.

        Returns True when get_recommendations() would return at least one
        HIGH or MEDIUM recommendation. Useful for mid-training interventions::

            if collapse_detector.is_collapsing:
                for pg in optimizer.param_groups:
                    pg['weight_decay'] *= 0.1
        """
        return len(self.get_recommendations()) > 0

    def summary(self) -> Dict[str, Any]:
        """Return summary stats for inspection."""
        layer_summaries = {}
        for gs in self._groups:
            h = gs['history']
            if not h:
                continue
            ratios = [x[2] for x in h]
            layer_summaries[gs['name']] = {
                'ltype': gs['ltype'],
                'weight_decay': gs['weight_decay'],
                'ratio_mean': float(np.mean(ratios)),
                'ratio_early': float(np.mean(ratios[:max(1, len(ratios) // 4)])),
                'ratio_late': float(np.mean(ratios[max(0, 3 * len(ratios) // 4):])),
                'n_steps': len(ratios),
            }
        return layer_summaries
