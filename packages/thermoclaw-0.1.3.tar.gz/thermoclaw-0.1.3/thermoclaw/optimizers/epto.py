"""
thermoclaw.optimizers.epto
===========================
EPTOv5 — Entropy-Production Targeted Optimisation v5.4 with TCI adaptive control.
For CNN, MLP, and RNN architectures.

Adapted from epto_sdk_v54/epto.py for the Thermoclaw package.
Changes: `group_norm_sq` inlined; `make_param_groups` from thermoclaw.layer_utils.

Core thermodynamic step (v5.4.1):
    v_thermal ← β_v · v_thermal + (1 - β_v) · ‖g‖²
    p_t       ← β_p · p_{t-1} + (1 - β_p) · g_t   (normalised OU drift)
    θ         ← θ - (η_eff · κ_l / √v_thermal) · p_t
"""

import math
import numpy as np
import torch
import torch.optim as optim
from typing import List, Dict, Any, Optional

from .tci import TCIController, compute_rho_t
from thermoclaw.layer_utils import make_param_groups


def _group_norm_sq(tensors: List[torch.Tensor]) -> float:
    """Fused squared L2 norm, float32 cast for bfloat16/AMP compatibility."""
    if not tensors:
        return 0.0
    norms = torch._foreach_norm([t.float() for t in tensors], ord=2)
    return float(sum(n.item() ** 2 for n in norms))


class EPTOv5(optim.Optimizer):
    """
    EPTO v5.4 — adaptive thermodynamic optimizer for CNN/MLP/RNN.

    Parameters
    ----------
    params:           Model parameters or param groups.
    eta0:             Initial learning rate (warmup start).
    alpha:            Entropy production scaling factor.
    warmup_steps:     Linear warmup duration (steps).
    total_steps:      Total training steps (for cosine ceiling).
    eta_min/max:      Learning rate bounds.
    eps2:             Numerical stability term added to g_norm_sq.
    adapt_rate:       Per-epoch entropy controller adaptation rate.
    lpm_gamma:        LPM suppression strength.
    iec_zeta:         Static IEC coupling (used when adaptive=False).
    weight_decay:     Decoupled weight decay.
    drift_scale:      Static OU drift scale (used when adaptive=False).
    adaptive:         Enable TCI adaptive control (v5.4).
    shadow_mode:      Compute TCI but do not adapt (validation).
    warmup_epochs:    Epochs before TCI adaptation fires.
    steps_per_epoch:  Steps per epoch (for EMA timescales).
    epochs:           Total epochs (informational).
    zeta_max:         Maximum IEC coupling (TCI=0 regime).
    drift_scale_max:  Maximum OU drift scale (TCI=1 regime).
    """

    def __init__(
        self,
        params,
        # Core
        eta0:          float = 1e-3,
        alpha:         float = 1.2,
        warmup_steps:  int   = 100,
        total_steps:   int   = 1000,
        eta_min:       float = 1e-7,
        eta_max:       float = 3e-3,
        eps2:          float = 1e-8,
        adapt_rate:    float = 0.05,
        lpm_gamma:     float = 1.0,
        iec_zeta:      float = 2.0,
        ema_delta:     float = 0.002,
        weight_decay:  float = 0.01,
        drift_scale:   float = 1.0,
        # TCI
        adaptive:         bool  = True,
        shadow_mode:      bool  = False,
        warmup_epochs:    int   = 2,
        steps_per_epoch:  int   = 100,
        epochs:           int   = 100,
        zeta_max:         float = 2.0,
        drift_scale_max:  float = 2.0,
        tci_log_every:    int   = 50,
        tci_verbose:      bool  = True,
    ):
        defaults = dict(
            eta0=eta0, alpha=alpha,
            warmup_steps=warmup_steps, total_steps=total_steps,
            eta_min=eta_min, eta_max=eta_max,
            eps2=eps2, adapt_rate=adapt_rate,
            lpm_gamma=lpm_gamma, iec_zeta=iec_zeta,
            ema_delta=ema_delta, weight_decay=weight_decay,
            drift_scale=drift_scale,
        )
        super().__init__(params, defaults)

        for group in self.param_groups:
            group.setdefault('name',            'layer')
            group.setdefault('steps_per_epoch', steps_per_epoch)
            group.setdefault('_step',           0)
            group.setdefault('_eta',            group['eta0'])
            group.setdefault('_sigma_star',     None)
            group.setdefault('_history',        [])
            group.setdefault('_sigma_ema',      None)
            group.setdefault('_sigma_window',   [])
            group.setdefault('_v_thermal',      None)
            group.setdefault('_p_drift',        None)

        self.last_thermo: Dict[str, Any] = {}

        self.adaptive         = adaptive
        self.shadow_mode      = shadow_mode
        self._static_iec_zeta    = iec_zeta
        self._static_drift_scale = drift_scale

        self.tci: Optional[TCIController] = None
        if adaptive or shadow_mode:
            self.tci = TCIController(
                warmup_epochs   = warmup_epochs,
                steps_per_epoch = steps_per_epoch,
                zeta_max        = zeta_max,
                drift_scale_max = drift_scale_max,
                shadow_mode     = shadow_mode,
                log_every       = tci_log_every,
                verbose         = tci_verbose,
            )

    def on_epoch_end(self) -> Dict[str, Any]:
        """Call at every epoch boundary. Updates drift_scale (slow TCI loop)."""
        if self.tci is None:
            return {}
        self.tci.update_epoch()
        if not self.shadow_mode:
            for group in self.param_groups:
                group['drift_scale'] = self.tci.current_drift_scale
        return self.tci.get_state()

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        # ── PASS 1: σ_ℓ, r_ℓ, σ* bookkeeping ────────────────────────────
        pass1: List[Dict] = []

        for group in self.param_groups:
            active = [p for p in group['params']
                      if p.requires_grad and p.grad is not None]
            if not active:
                pass1.append({'has_grad': False, 'group': group})
                continue

            group['_step'] += 1
            t   = group['_step']
            Tw  = group['warmup_steps']
            spe = group.get('steps_per_epoch', 100)

            grads     = [p.grad for p in active]
            g_norm_sq = _group_norm_sq(grads) + group['eps2']
            sigma_l   = group['_eta'] * g_norm_sq

            EMA_ALPHA = 2.0 / (max(50, spe // 10) + 1)
            if group['_sigma_ema'] is None:
                group['_sigma_ema'] = sigma_l
            else:
                group['_sigma_ema'] = ((1.0 - EMA_ALPHA) * group['_sigma_ema']
                                       + EMA_ALPHA * sigma_l)
            sigma_smooth = group['_sigma_ema']

            POST_CALIB = max(50, Tw // 10)
            if Tw < t <= Tw + POST_CALIB:
                group['_history'].append(sigma_smooth)
            if t == Tw + POST_CALIB + 1 and group['_sigma_star'] is None:
                hist = group['_history']
                group['_sigma_star'] = group['alpha'] * (
                    float(np.median(hist)) if hist else sigma_smooth)

            WINDOW = max(200, spe // 4)
            if t > Tw + POST_CALIB:
                group['_sigma_window'].append(sigma_smooth)
                if len(group['_sigma_window']) > WINDOW:
                    group['_sigma_window'].pop(0)
                if group['_sigma_window']:
                    group['_sigma_star'] = group['alpha'] * float(
                        np.median(group['_sigma_window']))

            ss  = group['_sigma_star'] if group['_sigma_star'] is not None else sigma_smooth
            r_l = sigma_smooth / (ss + 1e-30)

            pass1.append({
                'has_grad':     True,
                'group':        group,
                'active':       active,
                'grads':        grads,
                'g_norm_sq':    g_norm_sq,
                'sigma_l':      sigma_l,
                'sigma_smooth': sigma_smooth,
                'sigma_star':   ss,
                'r_l':          r_l,
                't':            t,
                'spe':          spe,
            })

        # ── IEC: network-wide median r ─────────────────────────────────────
        valid_r = [d['r_l'] for d in pass1 if d['has_grad']]
        R = float(np.median(valid_r)) if valid_r else 1.0

        # ── TCI UPDATE ─────────────────────────────────────────────────────
        if self.tci is not None and valid_r:
            r_tensor = torch.tensor(valid_r, dtype=torch.float32)
            rho_t = compute_rho_t(self.param_groups)
            self.tci.update_batch(r_tensor, rho_t)

        if self.tci is not None and not self.shadow_mode:
            active_zeta = self.tci.current_zeta
        else:
            active_zeta = self._static_iec_zeta

        # ── PASS 2: thermodynamic step ─────────────────────────────────────
        thermo_log = []

        for d in pass1:
            if not d['has_grad']:
                continue

            group   = d['group']
            t       = d['t']
            Tw      = group['warmup_steps']
            T       = group['total_steps']
            r_l     = d['r_l']
            active  = d['active']
            grads   = d['grads']
            spe     = d['spe']
            beta_v  = math.exp(-1.0 / max(spe, 1))

            if t <= Tw:
                eta_eff   = group['eta0'] * (t / max(Tw, 1))
                kappa_l   = 1.0
                lpm_scale = 1.0
            else:
                lpm_scale = max(0.1, min(1.0, math.exp(
                    -group['lpm_gamma'] * max(0.0, r_l - 1.0) ** 2)))
                kappa_l = max(0.1, min(1.0, math.exp(
                    -active_zeta * (r_l - R) ** 2)))
                a = group['adapt_rate'] / max(spe, 1)
                if d['sigma_smooth'] > d['sigma_star']:
                    group['_eta'] = max(group['_eta'] * (1.0 - a), group['eta_min'])
                else:
                    group['_eta'] = min(group['_eta'] * (1.0 + a), group['eta_max'])
                progress  = (t - Tw) / max(T - Tw, 1)
                eta_ceil  = (group['eta_min'] + 0.5 * (group['eta_max'] - group['eta_min'])
                             * (1.0 + math.cos(math.pi * progress)))
                eta_eff   = max(min(group['_eta'], eta_ceil), group['eta_min']) * lpm_scale

            if group['_v_thermal'] is None:
                group['_v_thermal'] = d['g_norm_sq']
            else:
                group['_v_thermal'] = (beta_v * group['_v_thermal']
                                       + (1.0 - beta_v) * d['g_norm_sq'])
            v_thermal = group['_v_thermal']

            drift_scale = group.get('drift_scale', 1.0)
            beta_p      = beta_v * drift_scale

            if group['_p_drift'] is None:
                group['_p_drift'] = [g.float().clone() for g in grads]
            else:
                torch._foreach_mul_(group['_p_drift'], beta_p)
                torch._foreach_add_(group['_p_drift'], [g.float() for g in grads], alpha=(1.0 - beta_p))

            MAX_DRIFT_MULT = 10.0
            max_drift_norm = MAX_DRIFT_MULT * math.sqrt(max(v_thermal, 1e-12))
            pd_norm_sq = _group_norm_sq(group['_p_drift'])
            if pd_norm_sq > max_drift_norm ** 2:
                scale = max_drift_norm / math.sqrt(pd_norm_sq)
                torch._foreach_mul_(group['_p_drift'], scale)

            if group['weight_decay'] != 0.0:
                for p in active:
                    p.data.mul_(1.0 - eta_eff * group['weight_decay'])

            step_scale = -(eta_eff * kappa_l) / math.sqrt(v_thermal)
            torch._foreach_add_(
                [p.data for p in active],
                [pd.to(p.data.dtype) for pd, p in zip(group['_p_drift'], active)],
                alpha=step_scale,
            )

            thermo_log.append({
                'name':        group.get('name', 'g'),
                'sigma':       d['sigma_l'],
                'sigma_star':  d['sigma_star'],
                'r':           r_l,
                'eta_eff':     eta_eff,
                'kappa':       kappa_l,
                'lpm_scale':   lpm_scale,
                'g_norm_sq':   d['g_norm_sq'],
                'iec_zeta':    active_zeta,
                'drift_scale': drift_scale,
            })

        self.last_thermo = {'layers': thermo_log, 'R': R}
        if self.tci is not None:
            self.last_thermo['tci'] = self.tci.get_state()

        return loss

    def export_tci_csv(self, path: str) -> None:
        """Export TCI signal history to CSV. Call after shadow-mode run."""
        if self.tci is not None:
            self.tci.export_csv(path)
        else:
            print("  [EPTO] No TCI controller attached (adaptive=False).")

    def validate_tci(self, noise_pct: str) -> Dict:
        """Validate TCI band separation after shadow-mode run."""
        if self.tci is not None:
            return self.tci.validate_separation(noise_pct)
        return {'pass': False, 'reason': 'adaptive=False — no TCI controller'}


# ── Convenience alias ─────────────────────────────────────────────────────────

def make_epto_param_groups(model: torch.nn.Module, **kwargs) -> List[Dict]:
    """Build one param group per named module. Alias for thermoclaw.make_param_groups."""
    return make_param_groups(model, **kwargs)
