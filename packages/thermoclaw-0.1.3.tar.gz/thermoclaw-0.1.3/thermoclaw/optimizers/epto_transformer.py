"""
thermoclaw.optimizers.epto_transformer
=======================================
EPTO-Transformer v6 — transformer-specific EPTO variant.

Adapted from epto_sdk_v54/epto_transformer.py for the Thermoclaw package.
Only change: imports `detect_layer_type` from thermoclaw.layer_utils instead
of the SDK's utils module.

Key parameters
--------------
use_scalar_v : bool
    False (default) — per-element preconditioning: each parameter has its own
    thermal velocity v_i = EMA(g_i²), matching Adam's equipartition property.

    True — scalar-v ablation: uses group-level thermal velocity for all params.
    This is the EPTO_SCALAR variant referenced in benchmarks.

disable_kappa : bool
    Skip the IEC inter-layer coupling suppression entirely.

kappa_mode : 'heuristic' | 'physics'
    'heuristic' — ratchet gate (original).
    'physics'   — Gaussian coupling via network-wide median R.
"""

import math
from collections import defaultdict, deque
from typing import Dict, List

import torch
import torch.nn.functional as F
import torch.optim as optim

from thermoclaw.layer_utils import detect_layer_type


class EPTOTransformer(optim.Optimizer):
    """
    Transformer-specific EPTO variant (GPT run v6).

    Notes:
      - Defaults match the validated v6 GPT configuration.
      - `tokens_per_step` defaults to 65536, matching batch 128 × seq 512.
      - `get_scale_metrics()` exposes per-layer thermodynamic diagnostics.
    """

    def __init__(
        self,
        params,
        eta0: float = 1e-4,
        alpha: float = 1.1,
        warmup_steps: int = 500,
        total_steps: int = 10000,
        eta_min: float = 1e-6,
        eta_max: float = 1e-2,
        eps2: float = 1e-8,
        adapt_rate: float = 0.1,
        iec_zeta: float = 2.0,
        ema_delta: float = 0.002,
        weight_decay: float = 0.1,
        corr_ema_rate: float = 0.05,
        steps_per_epoch: int = 100,
        tau_tokens: float = 5e6,
        tokens_per_step: int = 65536,
        sigma_ema_mom: float = 0.99,
        fim_window: int = 50,
        fim_eps: float = 0.15,
        fim_k: int = 2,
        post_warmup_min: int = 200,
        type_calib_min: int = 200,
        disable_kappa: bool = False,
        kappa_mode: str = 'heuristic',
        use_scalar_v: bool = False,
    ):
        defaults = dict(
            eta0=eta0,
            alpha=alpha,
            warmup_steps=warmup_steps,
            total_steps=total_steps,
            eta_min=eta_min,
            eta_max=eta_max,
            eps2=eps2,
            adapt_rate=adapt_rate,
            iec_zeta=iec_zeta,
            ema_delta=ema_delta,
            weight_decay=weight_decay,
            corr_ema_rate=corr_ema_rate,
            steps_per_epoch=steps_per_epoch,
        )
        super().__init__(params, defaults)

        self.tau_tokens = tau_tokens
        self.tokens_per_step = tokens_per_step
        self.sigma_ema_mom = sigma_ema_mom
        self.fim_window = fim_window
        self.fim_eps = fim_eps
        self.fim_k = fim_k
        post_warmup_budget = max(20, (total_steps - warmup_steps) // 3)
        self.post_warmup_min = min(post_warmup_min, post_warmup_budget)
        self.type_calib_min = min(type_calib_min, post_warmup_budget)
        self.disable_kappa = disable_kappa
        self.kappa_mode = kappa_mode
        self.use_scalar_v = use_scalar_v
        self._beta_p_base = math.exp(-tokens_per_step / tau_tokens)
        self._R_median = 1.0

        self._type_accum: Dict[str, List[float]] = defaultdict(list)
        self._type_scale: Dict[str, float] = {}
        self._type_ratio: Dict[str, float] = {}
        self._type_done = False

        for group in self.param_groups:
            n_params = sum(p.numel() for p in group['params'])
            group.setdefault('_step', 0)
            group.setdefault('_eta', group['eta0'])
            group.setdefault('_v', None)
            group.setdefault('_p', None)
            group.setdefault('_prev_g', None)
            group.setdefault('_corr', 0.9)
            group.setdefault('_s_hat_ema', None)
            group.setdefault('_s_hat_star', None)
            group.setdefault('_kappa', 1.0)
            group.setdefault('_n_params', n_params)
            group.setdefault('_ltype', detect_layer_type(group.get('name', '')))
            group.setdefault('_fim_buf', deque(maxlen=fim_window))
            group.setdefault('_fim_consec', 0)
            group.setdefault('_equilibrium', False)
            group.setdefault('_s_hat_window', [])
            group.setdefault('_s_hat_ref', None)
            group.setdefault('_v_elem', None)
            group.setdefault('_last_grad_norm', 0.0)
            group.setdefault('_last_weight_norm', 0.0)
            group.setdefault('_last_update_norm', 0.0)
            group.setdefault('_last_update_ratio', 0.0)
            group.setdefault('name', 'layer')

        self._s_window_size = max(200, 100)

    @staticmethod
    def _cosine_ceil(step: int, warmup: int, total: int,
                     eta_min: float, eta_max: float) -> float:
        if step < warmup or total <= warmup:
            return eta_max
        t = step - warmup
        total_active = total - warmup
        cos = 0.5 * (1 + math.cos(math.pi * t / max(1, total_active)))
        return eta_min + (eta_max - eta_min) * cos

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            params_with_grad = [p for p in group['params'] if p.grad is not None]
            if not params_with_grad:
                continue

            grads = [p.grad.detach() for p in params_with_grad]
            n_params = group['_n_params']
            layer_type = group['_ltype']
            spe = max(group['steps_per_epoch'], 1)
            step = group['_step']
            warmup = group['warmup_steps']
            total = group['total_steps']
            eta_min = group['eta_min']
            eta_max = group['eta_max']

            prev = group['_prev_g']
            if prev and len(prev) == len(grads):
                g_flat = torch.cat([x.float().flatten() for x in grads])
                p_flat = torch.cat([x.float().flatten() for x in prev])
                g_norm = g_flat.norm()
                p_norm = p_flat.norm()
                if g_norm > 1e-12 and p_norm > 1e-12:
                    corr = float(F.cosine_similarity(
                        g_flat.unsqueeze(0), p_flat.unsqueeze(0),
                    ).item())
                    rate = group['corr_ema_rate']
                    group['_corr'] = (1 - rate) * group['_corr'] + rate * corr
            group['_prev_g'] = [x.clone() for x in grads]

            beta_p = self._beta_p_base * max(0.0, group['_corr'])
            beta_v = math.exp(-1.0 / spe)

            norms = torch._foreach_norm([x.float() for x in grads], ord=2)
            g_norm_sq = float(sum(n.item() ** 2 for n in norms)) + group['eps2']
            grad_norm = math.sqrt(max(g_norm_sq - group['eps2'], 0.0))

            v = group['_v']
            v = g_norm_sq if v is None else beta_v * v + (1 - beta_v) * g_norm_sq
            v = max(v, group['eps2'])
            group['_v'] = v

            eta = group['_eta']
            eff_scale = eta / (math.sqrt(v) + group['eps2'])
            s_hat = (eff_scale * g_norm_sq) / max(n_params, 1)
            if group['_s_hat_ema'] is None:
                group['_s_hat_ema'] = s_hat
            else:
                group['_s_hat_ema'] = (
                    self.sigma_ema_mom * group['_s_hat_ema']
                    + (1 - self.sigma_ema_mom) * s_hat
                )

            post_warmup = step - warmup
            in_type_cal = (
                post_warmup >= self.post_warmup_min
                and post_warmup < self.post_warmup_min + self.type_calib_min
            )
            past_type_cal = post_warmup >= self.post_warmup_min + self.type_calib_min

            if step > warmup and in_type_cal and group['_s_hat_ema']:
                self._type_accum[layer_type].append(group['_s_hat_ema'])

            if past_type_cal and not self._type_done and self._type_accum:
                for key, vals in self._type_accum.items():
                    self._type_scale[key] = sum(vals) / max(len(vals), 1)
                global_mean = sum(self._type_scale.values()) / max(len(self._type_scale), 1)
                self._type_ratio = {
                    key: value / max(global_mean, 1e-30)
                    for key, value in self._type_scale.items()
                }
                self._type_done = True

            type_ratio = self._type_ratio.get(layer_type, 1.0) if self._type_done else 1.0

            group['_fim_buf'].append(g_norm_sq / max(n_params, 1))
            past_time_gate = post_warmup >= self.post_warmup_min
            if (
                step >= warmup
                and past_time_gate
                and not group['_equilibrium']
                and len(group['_fim_buf']) == self.fim_window
            ):
                buf = list(group['_fim_buf'])
                mean_fim = sum(buf) / len(buf)
                rel_var = sum((x - mean_fim) ** 2 for x in buf) / len(buf)
                rel_var /= (mean_fim ** 2 + 1e-30)
                if rel_var < self.fim_eps:
                    group['_fim_consec'] += 1
                    if group['_fim_consec'] >= self.fim_k:
                        group['_s_hat_star'] = group['alpha'] * group['_s_hat_ema']
                        group['_equilibrium'] = True
                else:
                    group['_fim_consec'] = 0

            if group['_equilibrium'] and group['_s_hat_star']:
                group['_s_hat_star'] = (
                    0.999 * group['_s_hat_star']
                    + 0.001 * group['alpha'] * group['_s_hat_ema']
                )

            alpha = group['alpha']
            if step == warmup and group['_s_hat_ema'] is not None:
                group['_s_hat_ref'] = group['_s_hat_ema']

            if step >= warmup and group['_s_hat_ema'] is not None:
                window = group['_s_hat_window']
                window.append(group['_s_hat_ema'])
                if len(window) > self._s_window_size:
                    window.pop(0)

            if group['_s_hat_star'] is not None:
                s_star = group['_s_hat_star']
            elif group['_s_hat_ref'] is not None:
                s_star = alpha * group['_s_hat_ref']
            elif group['_s_hat_ema'] is not None:
                s_star = alpha * group['_s_hat_ema']
            else:
                s_star = 0.0

            group['_s_star_diag'] = s_star
            group['_r_l'] = (
                group['_s_hat_ema'] / (s_star + 1e-30)
                if s_star > 0 and group['_s_hat_ema'] else 1.0
            )

            ceil = self._cosine_ceil(step, warmup, total, eta_min, eta_max)

            if step < warmup:
                group['_eta'] = eta_min + (eta_max - eta_min) * (step + 1) / max(1, warmup)
            else:
                eta_base = ceil
                if s_star > 0 and group['_s_hat_ema'] is not None and step >= warmup + self.post_warmup_min:
                    ratio = group['_s_hat_ema'] / (s_star + 1e-30)
                    adjust = group['adapt_rate'] / max(spe // 10, 10)
                    if ratio > 1.0:
                        group['_eta_mod'] = max(0.5, group.get('_eta_mod', 1.0) * (1 - adjust * min(ratio - 1.0, 2.0)))
                    else:
                        group['_eta_mod'] = min(1.0, group.get('_eta_mod', 1.0) * (1 + adjust * min(1.0 - ratio, 2.0)))
                    group['_eta'] = max(eta_min, min(eta_max, eta_base * group.get('_eta_mod', 1.0)))
                else:
                    group['_eta'] = eta_base
                    if step == warmup:
                        group['_eta_mod'] = 1.0

                if group['_equilibrium'] and len(group['_s_hat_window']) >= 20:
                    sorted_w = sorted(group['_s_hat_window'])
                    median_s = sorted_w[len(sorted_w) // 2]
                    group['_s_hat_star'] = alpha * median_s

            eta_eff = group['_eta']
            kappa = group['_kappa']

            if self.disable_kappa:
                group['_kappa'] = 1.0
            elif self.kappa_mode == 'physics' and s_star and s_star > 0 and step >= warmup:
                pass  # updated in physics-κ pass below
            elif s_star and s_star > 0 and group['_equilibrium']:
                typed_ratio = (group['_s_hat_ema'] / (s_star + 1e-30)) / max(type_ratio, 1e-6)
                if typed_ratio > group['iec_zeta']:
                    group['_kappa'] = max(0.3, kappa / typed_ratio)
                elif typed_ratio < 1 / group['iec_zeta']:
                    group['_kappa'] = min(1.0, kappa * group['iec_zeta'])
                else:
                    group['_kappa'] = min(1.0, kappa * 1.05)
            kappa = group['_kappa']

            if group['_p'] is None:
                group['_p'] = [x.float().clone().mul_(1.0 - beta_p) for x in grads]
            else:
                torch._foreach_mul_(group['_p'], beta_p)
                torch._foreach_add_(group['_p'], [x.float() for x in grads], alpha=(1.0 - beta_p))

            pd_norms = torch._foreach_norm(group['_p'], ord=2)
            pd_norm_sq = float(sum(n.item() ** 2 for n in pd_norms))
            max_drift_norm = 10.0 * math.sqrt(max(v, 1e-12))
            if pd_norm_sq > max_drift_norm ** 2:
                torch._foreach_mul_(group['_p'], max_drift_norm / math.sqrt(pd_norm_sq))

            eps2 = group['eps2']
            if not self.use_scalar_v:
                if group['_v_elem'] is None:
                    group['_v_elem'] = [g.float().square().clamp_(min=eps2) for g in grads]
                else:
                    for i, g in enumerate(grads):
                        gf = g.float()
                        group['_v_elem'][i].mul_(beta_v).addcmul_(gf, gf, value=1.0 - beta_v)
                precond = []
                for pd_i, ve_i in zip(group['_p'], group['_v_elem']):
                    precond.append(pd_i / torch.sqrt(ve_i + eps2))
            else:
                # EPTO_SCALAR: scalar-v ablation
                inv_sqrt_v = 1.0 / (math.sqrt(v) + eps2)
                precond = [pd_i * inv_sqrt_v for pd_i in group['_p']]

            scale = eta_eff * kappa
            wd = group['weight_decay']

            w_norms = torch._foreach_norm([p.data for p in params_with_grad], ord=2)
            weight_norm_sq = float(sum(n.item() ** 2 for n in w_norms))
            pc_norms = torch._foreach_norm(precond, ord=2)
            update_norm_sq = float(sum(n.item() ** 2 for n in pc_norms)) * (scale ** 2)
            if wd > 0:
                update_norm_sq += weight_norm_sq * ((eta_eff * wd) ** 2)

            if group['weight_decay'] > 0:
                torch._foreach_mul_(
                    [p.data for p in params_with_grad],
                    1 - eta_eff * group['weight_decay'],
                )
            torch._foreach_add_(
                [p.data for p in params_with_grad],
                [pc.to(p.data.dtype) for pc, p in zip(precond, params_with_grad)],
                alpha=-scale,
            )

            weight_norm = math.sqrt(max(weight_norm_sq, 0.0))
            update_norm = math.sqrt(max(update_norm_sq, 0.0))
            group['_last_grad_norm'] = grad_norm
            group['_last_weight_norm'] = weight_norm
            group['_last_update_norm'] = update_norm
            group['_last_update_ratio'] = (
                update_norm / max(weight_norm, 1e-30) if weight_norm > 0 else 0.0
            )
            group['_step'] += 1

        if self.kappa_mode == 'physics' and not self.disable_kappa:
            r_vals = [
                g.get('_r_l', 1.0)
                for g in self.param_groups
                if (g.get('_s_hat_ema') is not None
                    and g.get('_step', 0) > g.get('warmup_steps', 0))
            ]
            if r_vals:
                sorted_r = sorted(r_vals)
                self._R_median = sorted_r[len(sorted_r) // 2]
            for group in self.param_groups:
                if group.get('_step', 0) <= group.get('warmup_steps', 0):
                    continue
                r_l = group.get('_r_l', 1.0)
                zeta = group.get('iec_zeta', 2.0)
                R = self._R_median
                group['_kappa'] = max(0.3, min(1.0,
                    math.exp(-zeta * (r_l - R) ** 2)))

        return loss

    def get_scale_metrics(self) -> List[Dict]:
        """Per-layer thermodynamic diagnostics."""
        metrics: List[Dict] = []
        for group in self.param_groups:
            layer_type = group.get('_ltype', '?')
            type_ratio = self._type_ratio.get(layer_type, 1.0) if self._type_done else 1.0
            s_hat = group.get('_s_hat_ema') or 0.0
            s_star = group.get('_s_hat_star') or 0.0
            eta_eff = group.get('_eta', 0.0)
            kappa = group.get('_kappa', 1.0)
            beta_p = self._beta_p_base
            tau = (
                -self.tokens_per_step / math.log(beta_p + 1e-30)
                if 0 < beta_p < 1 else float('inf')
            )
            metrics.append({
                'name': group.get('name', '?')[:20],
                'layer_type': layer_type,
                'n_params': group.get('_n_params', 0),
                's_hat': s_hat,
                's_hat_star': s_star,
                'type_ratio': round(type_ratio, 6),
                'typed_r': round(s_hat / max(s_star * type_ratio, 1e-30), 4) if s_star else None,
                'kappa': round(float(kappa), 4),
                'eta_eff': round(float(eta_eff), 8),
                'grad_norm': round(float(group.get('_last_grad_norm', 0.0)), 8),
                'weight_norm': round(float(group.get('_last_weight_norm', 0.0)), 8),
                'update_norm': round(float(group.get('_last_update_norm', 0.0)), 8),
                'update_ratio': round(float(group.get('_last_update_ratio', 0.0)), 12),
                'tau_tokens': round(tau, 0),
                'equilibrium': group.get('_equilibrium', False),
                'r_l': round(float(group.get('_r_l', 1.0)), 6),
                'R_median': round(float(self._R_median), 6),
                'kappa_mode': self.kappa_mode,
                'use_scalar_v': self.use_scalar_v,
            })
        return metrics
