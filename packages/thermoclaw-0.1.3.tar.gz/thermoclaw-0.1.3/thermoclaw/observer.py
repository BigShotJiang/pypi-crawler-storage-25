"""
thermoclaw.observer
====================
Universal Optimizer Thermodynamic Observer.

Wraps ANY PyTorch optimizer and computes real-time thermodynamic diagnostics:

  σ_l(t) = η_eff · ‖g_l‖²        — per-layer entropy production
  r_l(t) = σ_l / σ*               — entropy ratio (1.0 = equilibrium)
  D(t)   = Var({r_1, …, r_L})     — inter-layer dispersion
  ρ(t)   = cos(g_t, g_{t-1})      — gradient alignment (step coherence)

Note on ρ and β₁ (empirically validated, non-obvious):
  High momentum (β₁ → 1) *increases* ρ, not decreases it. Momentum smooths
  consecutive gradient vectors, making them more correlated. So ρ is not a
  reliable diagnostic for over-damped momentum (β₁ too high). Use equilibrium
  fraction instead: over-damped runs show low eq_fraction despite high ρ,
  because the damped updates can't reach homeostatic σ* levels. Validated at
  Pythia-410M scale: β₁=0.999 produced ρ=0.71 vs baseline ρ=0.36.
  E(t)   = ‖θ_t − θ_0‖²          — cumulative parameter distance

Usage::

    observer = Observer(model, optimizer)
    for batch in loader:
        loss.backward()
        optimizer.step()
        snap = observer.step(loss=loss.item())
        optimizer.zero_grad()

    observer.plot_dashboard()
"""

from __future__ import annotations

import csv
import math
from collections import defaultdict
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

from thermoclaw.constants import (
    DEFAULT_ALPHA,
    DEFAULT_SIGMA_WINDOW,
    DEFAULT_SIGMA_CALIB_START,
    DEFAULT_EMA_SPAN,
)
from thermoclaw.layer_utils import detect_layer_type


class _GroupState:
    """Per-group running EMA state."""
    __slots__ = (
        'name', 'ltype', 'params', 'sigma_ema', 'sigma_star',
        'sigma_window', 'prev_grad_flat', 'step_count',
    )

    def __init__(self, name: str, params: List[torch.nn.Parameter]):
        self.name = name
        self.ltype = detect_layer_type(name)
        self.params = params
        self.sigma_ema: Optional[float] = None
        self.sigma_star: Optional[float] = None
        self.sigma_window: List[float] = []
        self.prev_grad_flat: Optional[torch.Tensor] = None
        self.step_count = 0


class Observer:
    """Observe thermodynamic quantities for any PyTorch optimizer.

    Parameters
    ----------
    model : nn.Module
        The model being trained.
    optimizer : torch.optim.Optimizer
        Any PyTorch optimizer (AdamW, SGD, Lion, Muon, EPTO, …).
    log_every : int
        Record a history entry every N steps (default 1 = every step).
    alpha : float
        Multiplier for σ* (equilibrium entropy target). 1.2 = default.
    sigma_window_size : int
        Rolling window for homeostatic σ* update.
    """

    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        log_every: int = 1,
        alpha: float = DEFAULT_ALPHA,
        sigma_window_size: int = DEFAULT_SIGMA_WINDOW,
        calib_start: int = DEFAULT_SIGMA_CALIB_START,
    ):
        self.model = model
        self.optimizer = optimizer
        self.log_every = log_every
        self.alpha = alpha
        self.sigma_window_size = sigma_window_size
        self.calib_start = calib_start

        self._global_step = 0
        self._epoch = 0

        # Build one group-state per param_group
        self._groups: List[_GroupState] = []
        for i, pg in enumerate(optimizer.param_groups):
            name = pg.get('name', f'group_{i}')
            params = [p for p in pg['params'] if p.requires_grad]
            self._groups.append(_GroupState(name, params))

        # Store initial weights for parameter distance tracking
        self._theta_0: Dict[int, torch.Tensor] = {
            id(p): p.data.detach().clone().float()
            for g in self._groups for p in g.params
        }

        # History (list of per-step snapshots)
        self.step_history: List[Dict[str, Any]] = []
        self.epoch_history: List[Dict[str, Any]] = []

        # Optimizer name detection
        self.optimizer_name = type(optimizer).__name__

    # ── Per-step recording ────────────────────────────────────────────────

    @property
    def global_step(self) -> int:
        return self._global_step

    def step(self, loss: Optional[float] = None) -> Dict[str, Any]:
        """Call after optimizer.step(). Returns current thermo snapshot."""
        self._global_step += 1
        t = self._global_step

        layer_sigmas: List[float] = []
        layer_r: List[float] = []
        layer_rho: List[float] = []
        layer_data: List[Dict[str, Any]] = []

        for gs in self._groups:
            grads = [p.grad for p in gs.params if p.grad is not None]
            if not grads:
                continue

            gs.step_count += 1

            # ── σ_l: entropy production estimate ──────────────────────────
            lr = self._get_group_lr(gs)
            gnorm_sq = self._group_norm_sq(grads)
            sigma_l = lr * gnorm_sq

            # σ EMA
            ema_alpha = 2.0 / (DEFAULT_EMA_SPAN + 1)
            if gs.sigma_ema is None:
                gs.sigma_ema = sigma_l
            else:
                gs.sigma_ema = (1.0 - ema_alpha) * gs.sigma_ema + ema_alpha * sigma_l

            # σ* calibration (rolling window after warmup)
            if gs.step_count > self.calib_start:
                gs.sigma_window.append(gs.sigma_ema)
                if len(gs.sigma_window) > self.sigma_window_size:
                    gs.sigma_window.pop(0)
                if gs.sigma_window:
                    gs.sigma_star = self.alpha * float(np.median(gs.sigma_window))

            ss = gs.sigma_star if gs.sigma_star is not None else gs.sigma_ema
            r_l = gs.sigma_ema / (ss + 1e-30)

            # ── ρ: gradient alignment ─────────────────────────────────────
            g_flat = torch.cat([g.float().flatten() for g in grads])
            rho = 0.0
            if gs.prev_grad_flat is not None and gs.prev_grad_flat.shape == g_flat.shape:
                g_norm = g_flat.norm()
                p_norm = gs.prev_grad_flat.norm()
                if g_norm > 1e-12 and p_norm > 1e-12:
                    rho = float(torch.dot(g_flat, gs.prev_grad_flat) / (g_norm * p_norm))
            gs.prev_grad_flat = g_flat.detach().clone()

            layer_sigmas.append(gs.sigma_ema)
            layer_r.append(r_l)
            layer_rho.append(rho)
            layer_data.append({
                'name': gs.name,
                'ltype': gs.ltype,
                'sigma': sigma_l,
                'sigma_ema': gs.sigma_ema,
                'sigma_star': ss,
                'r': r_l,
                'rho': rho,
                'lr': lr,
                'gnorm_sq': gnorm_sq,
            })

        # ── Network-wide signals ──────────────────────────────────────────
        D_t = float(np.var(layer_r)) if len(layer_r) > 1 else 0.0
        rho_mean = float(np.mean(layer_rho)) if layer_rho else 0.0
        R_median = float(np.median(layer_r)) if layer_r else 1.0

        # Parameter distance from init
        E_t = self._param_distance()

        snapshot = {
            'step': t,
            'epoch': self._epoch,
            'optimizer': self.optimizer_name,
            'D': round(D_t, 6),
            'rho_mean': round(rho_mean, 5),
            'R_median': round(R_median, 5),
            'E_param_dist': round(E_t, 6),
            'loss': round(loss, 5) if loss is not None else None,
            'layers': layer_data,
        }

        if t % self.log_every == 0:
            self.step_history.append(snapshot)

        return snapshot

    def epoch_end(self, val_acc: Optional[float] = None,
                  val_loss: Optional[float] = None) -> Dict[str, Any]:
        """Call at each epoch boundary. Aggregates epoch-level stats."""
        self._epoch += 1

        epoch_steps = [h for h in self.step_history if h['epoch'] == self._epoch
                       or (self._epoch == 1 and h['epoch'] == 0)]
        if not epoch_steps:
            epoch_steps = self.step_history[-1:] if self.step_history else []

        mean_D = float(np.mean([h['D'] for h in epoch_steps])) if epoch_steps else 0.0
        mean_rho = float(np.mean([h['rho_mean'] for h in epoch_steps])) if epoch_steps else 0.0
        mean_R = float(np.mean([h['R_median'] for h in epoch_steps])) if epoch_steps else 1.0

        entry = {
            'epoch': self._epoch,
            'optimizer': self.optimizer_name,
            'mean_D': round(mean_D, 6),
            'mean_rho': round(mean_rho, 5),
            'mean_R': round(mean_R, 5),
            'E_param_dist': round(self._param_distance(), 6),
            'val_acc': round(val_acc, 5) if val_acc is not None else None,
            'val_loss': round(val_loss, 5) if val_loss is not None else None,
        }
        self.epoch_history.append(entry)
        return entry

    # ── Visualisation ─────────────────────────────────────────────────────

    def plot_dashboard(self, save_path: Optional[str] = None,
                       show: bool = True) -> Any:
        """8-panel thermodynamic dashboard.

        Top row: σ per layer, r_l per layer, D(t), σ by layer type
        Bottom row: ρ(t), loss, E(t), equilibrium fraction
        """
        try:
            import matplotlib.pyplot as plt
            import matplotlib
            import warnings
            matplotlib.rcParams.update({'font.size': 9})
        except ImportError:
            print("[Thermoclaw] matplotlib not available — pip install thermoclaw[viz]")
            return None

        def _safe_legend(ax, **kw):
            handles, labels = ax.get_legend_handles_labels()
            if handles:
                ax.legend(**kw)

        def _safe_log_scale(ax):
            """Set log scale only if data has positive values."""
            for line in ax.get_lines():
                if any(v > 0 for v in line.get_ydata() if v == v):  # v==v filters nan
                    ax.set_yscale('log')
                    return

        fig, axes = plt.subplots(2, 4, figsize=(20, 9))
        fig.suptitle(f'Thermoclaw — {self.optimizer_name}', fontsize=14, fontweight='bold')

        steps = [h['step'] for h in self.step_history]
        if not steps:
            print("[Thermoclaw] No history to plot")
            return fig

        # Collect per-layer traces
        layer_names = []
        seen = set()
        for h in self.step_history:
            for ld in h.get('layers', []):
                if ld['name'] not in seen:
                    layer_names.append(ld['name'])
                    seen.add(ld['name'])

        layer_sigma: Dict[str, List[float]] = defaultdict(list)
        layer_r: Dict[str, List[float]] = defaultdict(list)
        layer_ltypes: Dict[str, str] = {}

        for h in self.step_history:
            layer_map = {ld['name']: ld for ld in h.get('layers', [])}
            for ln in layer_names:
                ld = layer_map.get(ln)
                layer_sigma[ln].append(ld['sigma_ema'] if ld else float('nan'))
                layer_r[ln].append(ld['r'] if ld else float('nan'))
                if ld and ln not in layer_ltypes:
                    layer_ltypes[ln] = ld.get('ltype', 'generic')

        # Panel 1: σ per layer
        ax = axes[0, 0]
        for ln in layer_names:
            ax.plot(steps, layer_sigma[ln], alpha=0.6, linewidth=0.6)
        ax.set_ylabel('σ_l')
        ax.set_title('Per-Layer Entropy σ')
        _safe_log_scale(ax)

        # Panel 2: r_l per layer
        ax = axes[0, 1]
        for ln in layer_names:
            ax.plot(steps, layer_r[ln], alpha=0.6, linewidth=0.6)
        ax.axhline(1.0, color='red', linestyle='--', linewidth=0.8, label='equilibrium')
        ax.set_ylabel('r_l = σ/σ*')
        ax.set_title('Entropy Ratio (1.0 = eq)')
        ax.legend(fontsize=7)

        # Panel 3: D(t)
        ax = axes[0, 2]
        D_vals = [h['D'] for h in self.step_history]
        ax.plot(steps, D_vals, color='#E67E22', linewidth=0.8)
        ax.fill_between(steps, D_vals, alpha=0.2, color='#E67E22')
        ax.set_ylabel('D(t)')
        ax.set_title('Inter-Layer Dispersion')

        # Panel 4: σ by layer type (aggregated)
        ax = axes[0, 3]
        ltype_sigma: Dict[str, List[float]] = defaultdict(lambda: [0.0] * len(steps))
        ltype_counts: Dict[str, int] = defaultdict(int)
        for ln in layer_names:
            lt = layer_ltypes.get(ln, 'generic')
            ltype_counts[lt] += 1
            for i, v in enumerate(layer_sigma[ln]):
                if not math.isnan(v):
                    ltype_sigma[lt][i] += v
        for lt in ltype_sigma:
            if ltype_counts[lt] > 0:
                vals = [v / ltype_counts[lt] for v in ltype_sigma[lt]]
                ax.plot(steps, vals, linewidth=1.2, label=lt)
        ax.set_ylabel('mean σ')
        ax.set_title('Entropy by Layer Type')
        _safe_log_scale(ax)
        _safe_legend(ax, fontsize=7)

        # Panel 5: ρ(t)
        ax = axes[1, 0]
        rho_vals = [h['rho_mean'] for h in self.step_history]
        ax.plot(steps, rho_vals, color='#2ECC71', linewidth=0.8)
        ax.axhline(0.0, color='gray', linestyle=':', linewidth=0.5)
        ax.set_ylabel('ρ(t)')
        ax.set_title('Gradient Alignment')
        ax.set_ylim(-1.05, 1.05)

        # Panel 6: Loss
        ax = axes[1, 1]
        loss_vals = [h.get('loss') for h in self.step_history]
        valid_loss = [(s, l) for s, l in zip(steps, loss_vals) if l is not None]
        if valid_loss:
            ax.plot(*zip(*valid_loss), color='#E74C3C', linewidth=0.8)
        ax.set_ylabel('Loss')
        ax.set_title('Training Loss')

        # Panel 7: E(t)
        ax = axes[1, 2]
        E_vals = [h['E_param_dist'] for h in self.step_history]
        ax.plot(steps, E_vals, color='#3498DB', linewidth=0.8)
        ax.set_ylabel('‖θ−θ₀‖²')
        ax.set_title('Parameter Distance')

        # Panel 8: Equilibrium fraction
        ax = axes[1, 3]
        eq_frac = []
        for h in self.step_history:
            layers = h.get('layers', [])
            if layers:
                n_eq = sum(1 for ld in layers if 0.85 <= ld['r'] <= 1.15)
                eq_frac.append(n_eq / len(layers))
            else:
                eq_frac.append(0.0)
        ax.plot(steps, eq_frac, color='#8E44AD', linewidth=0.8)
        ax.axhline(0.8, color='red', linestyle='--', linewidth=0.5, label='80% threshold')
        ax.set_ylabel('fraction at eq')
        ax.set_title('Equilibrium Fraction')
        ax.set_ylim(-0.05, 1.05)
        _safe_legend(ax, fontsize=7)

        for ax in axes.flat:
            ax.set_xlabel('step')

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        if show:
            plt.show()
        return fig

    # ── Side-by-side comparison ───────────────────────────────────────────

    @staticmethod
    def compare(observers: List['Observer'],
                save_path: Optional[str] = None,
                show: bool = True) -> Any:
        """Compare thermodynamic profiles of multiple optimizers side by side."""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            print("[Thermoclaw] matplotlib not available")
            return None

        if not observers:
            return None

        fig, axes = plt.subplots(2, 2, figsize=(14, 9))
        fig.suptitle('Thermoclaw — Optimizer Comparison', fontsize=14, fontweight='bold')

        colors = ['#E74C3C', '#2E86C1', '#27AE60', '#8E44AD', '#F39C12', '#1ABC9C']

        for i, obs in enumerate(observers):
            c = colors[i % len(colors)]
            label = obs.optimizer_name
            steps = [h['step'] for h in obs.step_history]
            if not steps:
                continue

            axes[0, 0].plot(steps, [h['D'] for h in obs.step_history],
                          color=c, label=label, linewidth=1)
            axes[0, 1].plot(steps, [h['rho_mean'] for h in obs.step_history],
                          color=c, label=label, linewidth=1)
            axes[1, 0].plot(steps, [h['R_median'] for h in obs.step_history],
                          color=c, label=label, linewidth=1)
            axes[1, 1].plot(steps, [h['E_param_dist'] for h in obs.step_history],
                          color=c, label=label, linewidth=1)

        axes[0, 0].set_title('Inter-Layer Dispersion D(t)')
        axes[0, 0].set_ylabel('D(t)')
        axes[0, 1].set_title('Gradient Alignment ρ(t)')
        axes[0, 1].set_ylabel('ρ(t)')
        axes[0, 1].set_ylim(-1.05, 1.05)
        axes[1, 0].set_title('Median Entropy Ratio R(t)')
        axes[1, 0].set_ylabel('R = median(r_l)')
        axes[1, 0].axhline(1.0, color='red', linestyle='--', linewidth=0.5)
        axes[1, 1].set_title('Parameter Distance E(t)')
        axes[1, 1].set_ylabel('‖θ−θ₀‖²')

        for ax in axes.flat:
            ax.set_xlabel('step')
            ax.legend()

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        if show:
            plt.show()
        return fig

    # ── Export ─────────────────────────────────────────────────────────────

    def export_csv(self, path: str) -> None:
        """Export full step-level history to CSV."""
        if not self.step_history:
            print("[Thermoclaw] No history to export")
            return

        rows = []
        for h in self.step_history:
            base = {k: v for k, v in h.items() if k != 'layers'}
            for ld in h.get('layers', []):
                row = {**base}
                row['layer_name'] = ld['name']
                row['layer_type'] = ld.get('ltype', 'generic')
                row['layer_sigma'] = ld['sigma']
                row['layer_sigma_ema'] = ld['sigma_ema']
                row['layer_sigma_star'] = ld['sigma_star']
                row['layer_r'] = ld['r']
                row['layer_rho'] = ld['rho']
                row['layer_lr'] = ld['lr']
                rows.append(row)

        if not rows:
            return

        keys = list(rows[0].keys())
        with open(path, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
        print(f"  [Thermoclaw] {len(rows)} rows → {path}")

    # ── Group accessors ───────────────────────────────────────────────────

    def get_group_state(self, name: str) -> Optional[_GroupState]:
        """Get the internal state for a named group."""
        for gs in self._groups:
            if gs.name == name:
                return gs
        return None

    @property
    def groups(self) -> List[_GroupState]:
        return list(self._groups)

    # ── Internal helpers ──────────────────────────────────────────────────

    def _get_group_lr(self, gs: _GroupState) -> float:
        """Extract the effective learning rate for this group."""
        for pg in self.optimizer.param_groups:
            pg_ids = {id(p) for p in pg['params']}
            gs_ids = {id(p) for p in gs.params}
            if pg_ids & gs_ids:
                # For EPTO, use _eta; for standard optimizers, use lr
                return float(pg.get('_eta', pg.get('lr', 1e-3)))
        return 1e-3

    @staticmethod
    def _group_norm_sq(tensors: List[torch.Tensor]) -> float:
        if not tensors:
            return 0.0
        norms = torch._foreach_norm([t.float() for t in tensors], ord=2)
        return float(sum(n.item() ** 2 for n in norms))

    def _param_distance(self) -> float:
        """Squared L2 distance from initial weights."""
        dist = 0.0
        for gs in self._groups:
            for p in gs.params:
                theta_0 = self._theta_0.get(id(p))
                if theta_0 is not None:
                    diff = p.data.float() - theta_0
                    dist += float(torch.sum(diff * diff).item())
        return dist
