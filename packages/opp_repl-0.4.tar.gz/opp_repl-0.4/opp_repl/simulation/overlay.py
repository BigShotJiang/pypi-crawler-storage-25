"""
This module provides fuse-overlayfs support for out-of-tree builds.

It contains:

- :py:class:`OverlayMount`: manages a single fuse-overlayfs mount (lower/upper/work/merged dirs).
- :py:class:`OverlaySimulationProject`: proxy wrapper that makes a :py:class:`SimulationProject` appear rooted at an overlay mount.
- :py:class:`OverlayOmnetppProject`: proxy wrapper that makes an :py:class:`OmnetppProject` appear rooted at an overlay mount.
"""

import logging
import os
import subprocess

_logger = logging.getLogger(__name__)

def get_build_root():
    """Returns the root directory for overlay builds (default ``~/.omnetpp/build``)."""
    return os.environ.get("OPP_BUILD_ROOT", os.path.expanduser("~/.omnetpp/build"))

class OverlayMount:
    """Manages a single fuse-overlayfs mount point.

    Parameters:
        lower_dir (str): Absolute path to the read-only source tree.
        overlay_name (str): Unique name used as subdirectory under the build root.
        build_root (str or None): Override for the build root directory.
    """

    def __init__(self, lower_dir, overlay_name, build_root=None):
        self.lower_dir = os.path.realpath(lower_dir)
        self.overlay_name = overlay_name
        self.build_root = build_root or get_build_root()
        self._base_dir = os.path.join(self.build_root, self.overlay_name)
        self.upper_dir = os.path.join(self._base_dir, "upper")
        self.work_dir = os.path.join(self._base_dir, "work")
        self._merged_dir = os.path.join(self._base_dir, "merged")

    @property
    def merged_path(self):
        """Absolute path to the merged (writable) mount point."""
        return self._merged_dir

    def is_mounted(self):
        """Check whether the overlay is currently mounted."""
        try:
            with open("/proc/mounts") as f:
                target = os.path.realpath(self._merged_dir)
                for line in f:
                    parts = line.split()
                    if len(parts) >= 2 and os.path.realpath(parts[1]) == target:
                        return True
        except OSError:
            pass
        return False

    def mount(self):
        """Create directories and mount the overlay (idempotent).

        Returns:
            str: The merged mount-point path.
        """
        if self.is_mounted():
            _logger.debug("Overlay %s already mounted at %s", self.overlay_name, self._merged_dir)
            return self._merged_dir
        for d in (self.upper_dir, self.work_dir, self._merged_dir):
            os.makedirs(d, exist_ok=True)
        cmd = [
            "fuse-overlayfs",
            "-o", f"lowerdir={self.lower_dir},upperdir={self.upper_dir},workdir={self.work_dir}",
            self._merged_dir,
        ]
        _logger.info("Mounting overlay %s: %s -> %s", self.overlay_name, self.lower_dir, self._merged_dir)
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(
                f"fuse-overlayfs failed for {self.overlay_name}: {result.stderr.strip()}"
            )
        return self._merged_dir

    def unmount(self):
        """Unmount the overlay (no-op if not mounted)."""
        if not self.is_mounted():
            return
        cmd = ["fusermount", "-u", self._merged_dir]
        _logger.info("Unmounting overlay %s at %s", self.overlay_name, self._merged_dir)
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(
                f"fusermount -u failed for {self.overlay_name}: {result.stderr.strip()}"
            )

    def clean(self):
        """Unmount (if mounted) and remove the upper/work directories."""
        self.unmount()
        import shutil
        for d in (self.upper_dir, self.work_dir):
            if os.path.isdir(d):
                shutil.rmtree(d)
        _logger.info("Cleaned overlay %s", self.overlay_name)

    def __repr__(self):
        mounted = " MOUNTED" if self.is_mounted() else ""
        return f"OverlayMount(name={self.overlay_name!r}, lower={self.lower_dir!r}{mounted})"


def list_overlays(build_root=None):
    """List overlay names that have directories under the build root.

    Returns:
        list of str: overlay names.
    """
    root = build_root or get_build_root()
    if not os.path.isdir(root):
        return []
    return sorted(
        entry for entry in os.listdir(root)
        if os.path.isdir(os.path.join(root, entry, "merged"))
    )

def cleanup_overlays(build_root=None):
    """Unmount all overlays under the build root."""
    root = build_root or get_build_root()
    for key in list_overlays(root):
        merged = os.path.join(root, key, "merged")
        try:
            subprocess.run(["fusermount", "-u", merged], capture_output=True, text=True)
            _logger.info("Unmounted overlay %s", key)
        except Exception as e:
            _logger.warning("Failed to unmount overlay %s: %s", key, e)

def clear_build_root(build_root=None):
    """Unmount all overlays and remove the entire build root directory."""
    import shutil
    root = build_root or get_build_root()
    cleanup_overlays(root)
    if os.path.isdir(root):
        shutil.rmtree(root)
        _logger.info("Removed build root %s", root)


def make_overlay_simulation_project(project, overlay_name=None, omnetpp_project=None, overlay_build_root=None):
    """Create an overlay-backed copy of a SimulationProject.

    .. deprecated::
        Use ``SimulationProject(..., overlay_name=..., overlay_build_root=...)`` instead.
    """
    import copy
    import warnings
    warnings.warn(
        "make_overlay_simulation_project is deprecated; pass overlay_name to SimulationProject() instead",
        DeprecationWarning, stacklevel=2,
    )
    clone = copy.copy(project)
    overlay = OverlayMount(
        project.get_root_path(),
        overlay_name or project.name,
        overlay_build_root,
    )
    clone._overlay = overlay
    clone.root_folder = overlay.merged_path
    clone.simulation_configs = None
    if omnetpp_project is not None:
        clone.omnetpp_project = omnetpp_project
    return clone


def make_overlay_omnetpp_project(project, overlay_name=None, overlay_build_root=None):
    """Create an overlay-backed copy of an OmnetppProject.

    .. deprecated::
        Use ``OmnetppProject(..., overlay_name=..., overlay_build_root=...)`` instead.
    """
    import copy
    import warnings
    warnings.warn(
        "make_overlay_omnetpp_project is deprecated; pass overlay_name to OmnetppProject() instead",
        DeprecationWarning, stacklevel=2,
    )
    root = project.get_root_path()
    clone = copy.copy(project)
    overlay = OverlayMount(
        root,
        overlay_name or os.path.basename(root),
        overlay_build_root,
    )
    clone._overlay = overlay
    clone.root_folder = overlay.merged_path
    return clone


# Keep old names as aliases for backward compatibility
OverlaySimulationProject = make_overlay_simulation_project
OverlayOmnetppProject = make_overlay_omnetpp_project


# -- CLI entry points for pre-sandbox overlay mounting --------------------

def _collect_overlays_from_opp_files(opp_patterns):
    """Parse .opp files and return :py:class:`OverlayMount` instances for overlay projects."""
    import glob as globmod
    from opp_repl.simulation.workspace import _parse_opp_file, _resolve_opp_paths
    overlays = []
    for pattern in opp_patterns:
        for opp_file in sorted(globmod.glob(pattern, recursive=True)):
            try:
                class_name, kwargs = _parse_opp_file(opp_file)
                _resolve_opp_paths(opp_file, kwargs)
            except ValueError as e:
                _logger.warning("Skipping %s: %s", opp_file, e)
                continue
            overlay_name = kwargs.get("overlay_name")
            if overlay_name is None:
                continue
            root_folder = kwargs.get("root_folder")
            if root_folder is None:
                _logger.warning("Skipping %s: overlay project has no root_folder", opp_file)
                continue
            overlay = OverlayMount(root_folder, overlay_name, kwargs.get("overlay_build_root"))
            overlays.append(overlay)
    return overlays

def mount_overlays_main():
    """CLI entry point: mount overlays defined in .opp files."""
    import argparse
    import sys
    parser = argparse.ArgumentParser(description="Mount fuse-overlayfs overlays defined in .opp files.")
    parser.add_argument("opp_files", nargs="+", metavar="OPP_FILE",
                        help="one or more .opp file paths or glob patterns")
    parser.add_argument("-l", "--log-level", choices=["ERROR", "WARN", "INFO", "DEBUG"],
                        default="INFO")
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(levelname)-5s %(name)s %(message)s")
    overlays = _collect_overlays_from_opp_files(args.opp_files)
    if not overlays:
        _logger.info("No overlay projects found in the specified .opp files")
        return
    failed = False
    for overlay in overlays:
        try:
            overlay.mount()
        except RuntimeError as e:
            _logger.error("%s", e)
            failed = True
    sys.exit(1 if failed else 0)

def unmount_overlays_main():
    """CLI entry point: unmount overlays defined in .opp files (or all)."""
    import argparse
    import sys
    parser = argparse.ArgumentParser(description="Unmount fuse-overlayfs overlays.")
    parser.add_argument("opp_files", nargs="*", metavar="OPP_FILE",
                        help="one or more .opp file paths or glob patterns (if omitted, unmount all)")
    parser.add_argument("-l", "--log-level", choices=["ERROR", "WARN", "INFO", "DEBUG"],
                        default="INFO")
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(levelname)-5s %(name)s %(message)s")
    if args.opp_files:
        overlays = _collect_overlays_from_opp_files(args.opp_files)
    else:
        overlays = [OverlayMount("unused", name) for name in list_overlays()]
    failed = False
    for overlay in overlays:
        try:
            overlay.unmount()
        except RuntimeError as e:
            _logger.error("%s", e)
            failed = True
    sys.exit(1 if failed else 0)
