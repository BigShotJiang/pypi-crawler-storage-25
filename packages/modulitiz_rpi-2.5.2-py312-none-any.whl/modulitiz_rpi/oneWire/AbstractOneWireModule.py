import glob
import os.path
import time
from abc import ABC
from abc import abstractmethod

from modulitiz_nano.ModuloStringhe import ModuloStringhe
from modulitiz_nano.exceptions.ExceptionRuntime import ExceptionRuntime
from modulitiz_nano.files.ModuloFiles import ModuloFiles
from modulitiz_nano.sistema.ModuloSystem import ModuloSystem


class AbstractOneWireModule(ABC):
	"""
	Before using this you must enable 1Wire interface through raspi-config.
	Then a reboot is needed.
	Requires root privileges (sudo) to enable 1Wire temperature channel.
	Default pin is GPIO-4
	"""
	BASE_DIR='/sys/bus/w1/devices/'
	
	def __init__(self,addressOrPattern:int|str):
		self.addressOrPattern=str(addressOrPattern)
		self.paths:dict[str,str]={}
	
	@abstractmethod
	def _populateCustom(self):
		"""
		Valorizzazione di campi aggiuntivi.
		"""
	
	def populate(self):
		output=ModuloSystem.systemCallReturnOutput('sudo modprobe w1-gpio',None).strip()
		if not ModuloStringhe.isEmpty(output):
			raise ExceptionRuntime(f"Cannot enable 1Wire channel:\n{output}")
		self._populateCustom()
		for path in glob.glob(self.BASE_DIR+self.addressOrPattern):
			idDevice=os.path.dirname(path)
			self.paths[idDevice]=path
		if len(self.paths)==0:
			raise ExceptionRuntime(f"No paths found for {self.addressOrPattern}")
	
	def read(self)->dict[str,str]:
		diz={}
		for idDevice,path in self.paths.items():
			devicePathFile=ModuloFiles.pathJoin(path,"w1_slave")
			diz[idDevice]=self.__readUntilValid(devicePathFile)
		return diz
	
	@classmethod
	def __readUntilValid(cls,devicePathFile:str)->str:
		lines=cls.__readRaw(devicePathFile)
		while not lines[0].strip().endswith('YES'):
			time.sleep(0.1)
			lines=cls.__readRaw(devicePathFile)
		return lines[1]
	
	@staticmethod
	def __readRaw(devicePathFile:str)->list[str]:
		with open(devicePathFile,'r') as fp:
			lines=fp.readlines()
		return lines
