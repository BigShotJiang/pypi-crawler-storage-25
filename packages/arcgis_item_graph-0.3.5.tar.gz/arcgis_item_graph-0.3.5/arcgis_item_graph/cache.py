"""arcgis_item_graph/cache.py — SQLite metadata cache for governance queries."""
import logging
import sqlite3
import time
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id              TEXT PRIMARY KEY,
    title           TEXT,
    type            TEXT,
    owner           TEXT,
    modified        INTEGER,
    created         INTEGER,
    access          TEXT,
    content_status  TEXT,
    delete_protected INTEGER,
    num_views       INTEGER,
    item_size       INTEGER,
    last_seen       INTEGER,
    source_org      TEXT
);
CREATE TABLE IF NOT EXISTS relationships (
    parent_id   TEXT NOT NULL,
    child_id    TEXT NOT NULL,
    source      TEXT NOT NULL,
    rel_type    TEXT,
    PRIMARY KEY (parent_id, child_id, source)
);
CREATE TABLE IF NOT EXISTS health (
    id          TEXT PRIMARY KEY,
    status      TEXT NOT NULL,
    last_checked INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS run_metrics (
    run_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_type    TEXT NOT NULL,
    started_at  INTEGER NOT NULL,
    finished_at INTEGER,
    item_count  INTEGER,
    edge_count  INTEGER,
    broken_count INTEGER
);
"""


class MetadataCache:
    """SQLite-backed metadata store populated by create/update, read by query/health/risk."""

    def __init__(self, db_path: str) -> None:
        self._path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    # ── Write operations ──────────────────────────────────────────────────────

    def build(self, graph: object, items: list) -> None:
        """Full rebuild from graph + items. Clears all previous data."""
        now = int(time.time() * 1000)
        self._conn.executescript(
            "DELETE FROM items; DELETE FROM relationships; DELETE FROM health;"
        )

        for node in graph.all_items():
            item = node.item
            if item is None:
                self._conn.execute(
                    "INSERT OR REPLACE INTO health VALUES (?, ?, ?)",
                    (node.id, "broken_no_item", now),
                )
                continue
            self._conn.execute(
                "INSERT OR REPLACE INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    item.itemid,
                    getattr(item, "title", ""),
                    getattr(item, "type", ""),
                    getattr(item, "owner", ""),
                    getattr(item, "modified", 0),
                    getattr(item, "created", 0),
                    getattr(item, "access", ""),
                    getattr(item, "content_status", "") or "",
                    1 if getattr(item, "protected", False) else 0,
                    getattr(item, "numViews", 0) or 0,
                    getattr(item, "size", 0) or 0,
                    now,
                    "",
                ),
            )
            self._conn.execute(
                "INSERT OR REPLACE INTO health VALUES (?, ?, ?)",
                (item.itemid, "ok", now),
            )
            for child in node.contains():
                self._conn.execute(
                    "INSERT OR IGNORE INTO relationships VALUES (?, ?, ?, ?)",
                    (node.id, child.id, "itemgraph", None),
                )

        self._conn.commit()
        logger.info("MetadataCache.build: committed %d nodes", sum(1 for _ in graph.all_items()))

    def update(self, modified_items: list, graph: object) -> None:
        """Upsert rows for modified items; update health for changed nodes."""
        now = int(time.time() * 1000)
        for item in modified_items:
            if item is None:
                continue
            self._conn.execute(
                "INSERT OR REPLACE INTO items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    item.itemid,
                    getattr(item, "title", ""),
                    getattr(item, "type", ""),
                    getattr(item, "owner", ""),
                    getattr(item, "modified", 0),
                    getattr(item, "created", 0),
                    getattr(item, "access", ""),
                    getattr(item, "content_status", "") or "",
                    1 if getattr(item, "protected", False) else 0,
                    getattr(item, "numViews", 0) or 0,
                    getattr(item, "size", 0) or 0,
                    now,
                    "",
                ),
            )
            self._conn.execute(
                "INSERT OR REPLACE INTO health VALUES (?, ?, ?)",
                (item.itemid, "ok", now),
            )
            self._conn.execute(
                "DELETE FROM relationships WHERE parent_id = ? AND source = 'itemgraph'",
                (item.itemid,),
            )
            node = graph.get_node(item.itemid)
            if node is not None:
                for child in node.contains():
                    self._conn.execute(
                        "INSERT OR IGNORE INTO relationships VALUES (?, ?, ?, ?)",
                        (item.itemid, child.id, "itemgraph", None),
                    )
        self._conn.commit()

    def record_run(
        self, run_type: str, started_at: int,
        item_count: int, edge_count: int, broken_count: int
    ) -> None:
        now = int(time.time() * 1000)
        self._conn.execute(
            """INSERT INTO run_metrics
               (run_type, started_at, finished_at, item_count, edge_count, broken_count)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (run_type, started_at, now, item_count, edge_count, broken_count),
        )
        self._conn.commit()

    def upsert_relationship(self, parent_id: str, child_id: str, source: str,
                            rel_type: Optional[str] = None) -> None:
        """Add a single relationship edge (called by parsers)."""
        self._conn.execute(
            "INSERT OR IGNORE INTO relationships VALUES (?, ?, ?, ?)",
            (parent_id, child_id, source, rel_type),
        )
        self._conn.commit()

    # ── Read operations ───────────────────────────────────────────────────────

    def get_item(self, item_id: str) -> Optional[dict]:
        row = self._conn.execute(
            "SELECT * FROM items WHERE id = ?", (item_id,)
        ).fetchone()
        return dict(row) if row else None

    def update_service_health(self, node_id: str, status: str) -> None:
        """Upsert a URL-node liveness status into the health table."""
        now = int(time.time() * 1000)
        self._conn.execute(
            "INSERT INTO health (id, status, last_checked) VALUES (?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET status=excluded.status, last_checked=excluded.last_checked",
            (node_id, status, now)
        )
        self._conn.commit()

    def get_health(self, item_id: str) -> str:
        """Return the health status for a node, or 'unchecked' if none recorded."""
        row = self._conn.execute(
            "SELECT status FROM health WHERE id = ?", (item_id,)
        ).fetchone()
        return row["status"] if row else "unchecked"

    def url_nodes_by_status(self, status: str) -> list:
        """Return URL-type node IDs (starting with 'http') with the given health status."""
        rows = self._conn.execute(
            "SELECT id FROM health WHERE status = ? AND id LIKE 'http%'",
            (status,)
        ).fetchall()
        return [r["id"] for r in rows]

    def broken_nodes(self) -> list[str]:
        rows = self._conn.execute(
            "SELECT id FROM health WHERE status != 'ok'"
        ).fetchall()
        return [r["id"] for r in rows]

    def orphan_candidates(self, days_inactive: int = 365, min_views: int = 0) -> list[dict]:
        cutoff = int(time.time() * 1000) - (days_inactive * 24 * 60 * 60 * 1000)
        rows = self._conn.execute(
            """SELECT i.* FROM items i
               WHERE i.modified < ?
               AND i.num_views <= ?
               AND NOT EXISTS (
                   SELECT 1 FROM relationships r WHERE r.child_id = i.id
               )""",
            (cutoff, min_views),
        ).fetchall()
        return [dict(r) for r in rows]

    def fanout(self, item_id: str) -> int:
        """Count distinct items that depend on this item."""
        row = self._conn.execute(
            "SELECT COUNT(DISTINCT parent_id) FROM relationships WHERE child_id = ?",
            (item_id,),
        ).fetchone()
        return row[0] if row else 0

    def close(self) -> None:
        self._conn.close()
