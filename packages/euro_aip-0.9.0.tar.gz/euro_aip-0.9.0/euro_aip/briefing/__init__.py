"""
Briefing module for parsing and filtering flight briefing data.

This module provides tools for:
- Parsing NOTAMs from ForeFlight PDFs and other sources
- Filtering and categorizing NOTAMs by location, time, category, and spatial criteria
- Integrating with euro_aip for airport coordinate lookups

Example usage:
    from euro_aip.briefing import ForeFlightSource, NotamCollection
    from euro_aip.briefing.categorization import CategorizationPipeline

    # Parse a ForeFlight briefing PDF
    source = ForeFlightSource(cache_dir="./cache")
    briefing = source.parse("path/to/briefing.pdf")

    # Apply categorization
    pipeline = CategorizationPipeline()
    pipeline.categorize_all(briefing.notams)

    # Query NOTAMs
    departure_notams = (
        briefing.notams_query
        .for_airport("LFPG")
        .active_now()
        .runway_related()
        .all()
    )
"""

from euro_aip.briefing.models.notam import Notam, NotamCategory
from euro_aip.briefing.models.route import Route, RoutePoint
from euro_aip.briefing.models.briefing import Briefing
from euro_aip.briefing.models.icao_fpl import ICAOFlightPlan, parse_icao_fpl
from euro_aip.briefing.collections.notam_collection import NotamCollection
from euro_aip.briefing.sources.foreflight import ForeFlightSource
from euro_aip.briefing.sources.avwx import AvWxSource
from euro_aip.briefing.sources.ogimet import OgimetSource
from euro_aip.briefing.parsers.notam_parser import NotamParser
from euro_aip.briefing.categorization.pipeline import CategorizationPipeline
from euro_aip.briefing.weather import (
    WeatherReport,
    FlightCategory,
    WindComponents,
    WeatherType,
    WeatherParser,
    WeatherAnalyzer,
    WeatherCollection,
    RouteWeatherService,
    RouteWeatherResult,
    RouteAirportWeather,
)

__all__ = [
    # Models
    'Notam',
    'NotamCategory',
    'Route',
    'RoutePoint',
    'Briefing',
    'ICAOFlightPlan',
    'parse_icao_fpl',
    # Collections
    'NotamCollection',
    # Sources
    'ForeFlightSource',
    'AvWxSource',
    'OgimetSource',
    # Parsers
    'NotamParser',
    # Categorization
    'CategorizationPipeline',
    # Weather
    'WeatherReport',
    'FlightCategory',
    'WindComponents',
    'WeatherType',
    'WeatherParser',
    'WeatherAnalyzer',
    'WeatherCollection',
    'RouteWeatherService',
    'RouteWeatherResult',
    'RouteAirportWeather',
]
