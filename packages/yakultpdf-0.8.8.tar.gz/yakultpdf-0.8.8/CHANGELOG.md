# Changelog

## [0.8.3] - 2026-04-16

- **CLI**: Disable cover generation by default. Replaced `--no-cover` flag with `--with-cover/--no-cover` to allow explicit opt-in.

## [0.7.17] - 2026-01-04

- **Templates**: Optimized default tempalte "nb".

## [0.7.0] - 2026-01-03

- Refactored project structure and for `mark2pdf` package publishing.
