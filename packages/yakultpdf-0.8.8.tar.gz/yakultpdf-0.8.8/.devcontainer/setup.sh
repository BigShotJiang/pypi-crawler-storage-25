#!/usr/bin/env bash
set -euo pipefail

# 安装 Pandoc
sudo apt-get update && sudo apt-get install -y --no-install-recommends pandoc fonts-noto-cjk

# 安装 Typst (latest)
arch="$(dpkg --print-architecture)"
case "$arch" in
  amd64) typst_arch="x86_64-unknown-linux-musl" ;;
  arm64) typst_arch="aarch64-unknown-linux-musl" ;;
  *) echo "Unsupported: $arch" >&2; exit 1 ;;
esac
wget -qO- "https://github.com/typst/typst/releases/latest/download/typst-${typst_arch}.tar.xz" \
  | sudo tar xJ --strip-components=1 -C /usr/local/bin

# 安装 uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# 安装项目依赖并将 CLI 安装到系统 PATH
uv sync --frozen
uv pip install --system -e .
