# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "markdown-it-py",
#     "mdit-py-plugins",
#     "pyyaml",
# ]
# ///
"""
深度测试：验证列表间距处理的各种场景
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mark2pdf.helper_markdown.md_preprocess import pre_add_line_breaks


def test_case(name: str, input_text: str, check_fn):
    print(f"\n{'='*50}")
    print(f"测试: {name}")
    print(f"{'='*50}")
    print(f"输入:\n{input_text}")
    print("-" * 30)
    result = pre_add_line_breaks(input_text, verbose=False)
    print(f"输出:\n{result}")
    print("-" * 30)
    
    passed, msg = check_fn(result)
    if passed:
        print(f"✅ PASS: {msg}")
    else:
        print(f"❌ FAIL: {msg}")
    return passed


def main():
    passed = 0
    failed = 0

    # Case 1: 段落紧接无序列表
    def check1(r):
        # 期望：段落与列表之间有空行，列表内部无额外空行
        if "段落\n\n- 项目1\n- 项目2" in r or "段落\n\n- 项目1\n\n- 项目2" in r:
            # 检查列表内部是否被打散
            if "- 项目1\n\n- 项目2" in r:
                return False, "列表内部被打散了！"
            return True, "段落与列表分开，列表内部紧凑"
        return False, f"格式不符预期"
    
    if test_case("段落 + 无序列表", "段落\n- 项目1\n- 项目2", check1):
        passed += 1
    else:
        failed += 1

    # Case 2: 段落紧接有序列表
    def check2(r):
        if "段落\n\n1. 项目1\n2. 项目2" in r or "段落\n\n1. 项目1\n\n2. 项目2" in r:
            if "1. 项目1\n\n2. 项目2" in r:
                return False, "列表内部被打散了！"
            return True, "段落与列表分开，列表内部紧凑"
        return False, f"格式不符预期"

    if test_case("段落 + 有序列表", "段落\n1. 项目1\n2. 项目2", check2):
        passed += 1
    else:
        failed += 1

    # Case 3: 已有空行的情况
    def check3(r):
        # 不应该多加空行
        if "段落\n\n- 项目1\n- 项目2" in r:
            if r.count("\n\n") == 1:  # 只有一个双换行
                return True, "保持原有格式"
        return False, f"格式不符预期"

    if test_case("段落 + 空行 + 列表", "段落\n\n- 项目1\n- 项目2", check3):
        passed += 1
    else:
        failed += 1

    # Case 4: 嵌套列表
    def check4(r):
        # 嵌套列表应该保持紧凑
        if "- 项目1\n  - 子项目" in r:
            return True, "嵌套结构保持"
        return False, f"嵌套结构被破坏"

    if test_case("嵌套列表", "段落\n- 项目1\n  - 子项目\n- 项目2", check4):
        passed += 1
    else:
        failed += 1

    # Case 5: 用户原始问题场景
    input5 = """**预期结果：**
Skill 会引导你完成五步框架：
1. **Objective**：确认目标是否 SMART
2. **Audience**：定义目标受众画像
3. **Message**：提炼核心信息和支持点"""

    def check5(r):
        # 期望：列表前有空行，列表内部紧凑
        lines = r.split("\n")
        # 找到列表开始位置
        list_start = -1
        for i, line in enumerate(lines):
            if line.strip().startswith("1."):
                list_start = i
                break
        
        if list_start <= 0:
            return False, "未找到列表"
        
        # 检查列表前是否有空行
        if lines[list_start - 1].strip() != "":
            return False, "列表前没有空行"
        
        # 检查列表内部是否紧凑（1和2之间）
        for i in range(list_start, len(lines) - 1):
            if lines[i].strip().startswith("1.") and lines[i+1].strip() == "":
                if i + 2 < len(lines) and lines[i+2].strip().startswith("2."):
                    return False, "列表项之间被插入了空行！"
        
        return True, "列表格式正确"

    if test_case("用户原始场景", input5, check5):
        passed += 1
    else:
        failed += 1

    # 总结
    print(f"\n{'='*50}")
    print(f"总结: {passed} 通过, {failed} 失败")
    print(f"{'='*50}")
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
