---
name: yakultpdf-workspace
description: 如何在其他项目中建立 yakultpdf 工作区来生成 PDF
---

# yakultpdf 工作区配置指南

在项目中建立独立的 PDF 工作区，使用 yakultpdf 生成文档。

---

## 前置条件

```bash
# 全局安装 yakultpdf
uv tool install yakultpdf
# 或: pipx install yakultpdf

# 依赖: Pandoc + Typst
```

---

## 1. 初始化工作区

> [!IMPORTANT]
> **工作区目录由用户自定义**，建议创建独立目录（如 `docs-pdf`）。

```bash
# 创建目录并初始化
mkdir docs-pdf && cd docs-pdf
yakultpdf init .
```

**要求**：目标目录必须为空（允许 `.DS_Store`）。

**生成结构**：
```
docs-pdf/
├── mark2pdf.config.toml   # 工作区配置文件
├── frontmatter.yaml       # 默认元数据（自动注入）
├── createpdf.py           # 自定义预处理脚本
├── in/                    # 输入目录
│   └── images/           # 图片目录（必须）
├── out/                   # 输出目录
├── tmp/                   # 临时目录
└── template/              # 本地模板（可选）
```

---

## 2. 配置文件

### `mark2pdf.config.toml`

```toml
[project]
name = "我的文档项目"

[paths]
input = "in"          # 输入目录
output = "out"        # 输出目录
tmp = "tmp"           # 临时目录
template = "template" # 本地模板目录
fonts = "fonts"       # 字体目录（可选）

[build]
default_template = "nb.typ"    # 默认模板
overwrite = false              # 是否覆盖输出文件
filename_with_title = false    # 使用 title 作为输出文件名
```

> [!IMPORTANT]
> `default_template` 必须放在 `[build]` 下。

### `frontmatter.yaml`

工作区根目录的默认元数据，自动注入所有文件（不覆盖已有字段）：

```yaml
title: "示例文档"
author: "作者名"
headerfooter:
  headerleft: "我的工作区"
```

---

## 3. 常用命令

```bash
cd docs-pdf

# 转换命令
yakultpdf convert              # 转换 in/index.md
yakultpdf convert in/doc.md    # 转换指定文件
yakultpdf convert --dir in/章节/  # 合并转换整个目录
yakultpdf convert --batch in/  # 批量转换（各自独立输出）

# 常用选项
yakultpdf convert -v           # 详细输出
yakultpdf convert -o           # 转换后打开 PDF
yakultpdf convert -t card.typ  # 指定模板
yakultpdf convert --tc         # 转换为繁体中文
yakultpdf convert --overwrite  # 覆盖输出文件

# 其他命令
yakultpdf clean                # 清理输出目录
yakultpdf fonts list           # 列出可用字体
yakultpdf fonts install lxgw-wenkai  # 安装字体
yakultpdf template nb.typ      # 导出内置模板到本地
yakultpdf update               # 更新工作区脚本
```

---

## 4. 图片处理 (mdimage)

```bash
# 下载网络图片到本地
yakultpdf mdimage download in/doc.md

# 覆盖原文件
yakultpdf mdimage download in/doc.md --overwrite

# 批量处理目录
yakultpdf mdimage download in/

# 目录结构迁移
yakultpdf mdimage todir abc.md   # 单文件 → 文件夹模式
yakultpdf mdimage tofile abc/    # 文件夹 → 单文件模式
```

---

## 5. Frontmatter 配置

### 完整示例

```yaml
---
title: "文档标题"
author: "作者"
date: "2026年1月"
description: "文档描述"
template: nb.typ
exportFilename: output-name
toc-depth: 2

pubinfo:
  edition: "系列名称"
  info: "2026年1月第一版"
  logo: ./images/logo.png
  font: "SourceHanSerif"
  titlefont: "SourceHanSans"
  watermark: "内部资料"

heroimage:
  image: ./images/cover.jpg
  caption: "封面图注"

headerfooter:
  headerleft: "页眉左侧"
  headerright: "页眉右侧"
  footerleft: "页脚左侧"
  footerright: ![](images/qr.png)

disables:
  - cover      # 禁用封面
  - backcover  # 禁用封底
  - toc        # 禁用目录
  - indent     # 禁用首行缩进
---
```

### 配置优先级（由高到低）

1. CLI `--template` 参数
2. 文件 frontmatter 中的 `template`
3. `mark2pdf.config.toml` 中的 `build.default_template`
4. 系统默认模板

### 深度合并规则

嵌套结构（`pubinfo`、`headerfooter`）支持部分覆盖，不会丢失未指定的子字段。

---

## 6. 自定义预处理脚本

编辑 `createpdf.py`，修改 `preprocess()` 函数：

```python
def preprocess(content: str) -> str:
    """工作区特定的预处理逻辑"""
    # 示例：替换敏感词
    # content = content.replace("敏感词", "***")
    return content
```

运行：`./createpdf.py [选项]`

---

## 7. 模板优先级

1. `template/` 目录下的本地模板
2. CLI `--template` 指定的模板
3. Frontmatter 中的 `template` 字段
4. `config.toml` 中的 `default_template`
5. 系统默认模板

---

## 参考文档

`reference/` 目录下的详细文档：
- **工作区使用指南** - 完整配置与高级用法
- **配置指南** - frontmatter 全部配置项
- **CLI使用说明** - 所有命令参考
- **nb-syntax** - 模板扩展语法（fullimage、topimage 等）
