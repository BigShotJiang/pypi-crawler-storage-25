#!/usr/bin/env bash
# 自动发布 yakultpdf 至 PyPI
# 读取 .env 中的 UV_PUBLISH_TOKEN，执行 clean -> build -> publish
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# --- 加载 .env ---
if [[ -f .env ]]; then
    export "$(grep -E '^UV_PUBLISH_TOKEN=' .env | xargs)"
else
    echo "❌ .env 文件不存在" >&2
    exit 1
fi

if [[ -z "${UV_PUBLISH_TOKEN:-}" ]]; then
    echo "❌ .env 中未找到 UV_PUBLISH_TOKEN" >&2
    exit 1
fi

# --- 读取版本号 ---
VERSION=$(grep '^version' pyproject.toml | head -1 | sed 's/.*"\(.*\)".*/\1/')
echo "📦 准备发布 yakultpdf v${VERSION}"

# --- 检查工作区状态 ---
if [[ -n "$(git status --porcelain 2>/dev/null)" ]]; then
    echo "⚠️  警告: 工作区有未提交的更改"
    read -rp "是否继续? (y/N) " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || exit 0
fi

# --- 清理 & 构建 ---
echo "🧹 清理 dist/"
rm -rf dist/

echo "🔨 构建..."
uv build

# --- 验证产物 ---
if [[ ! -f "dist/yakultpdf-${VERSION}.tar.gz" ]] || [[ ! -f "dist/yakultpdf-${VERSION}-py3-none-any.whl" ]]; then
    echo "❌ 构建产物不完整" >&2
    ls -la dist/
    exit 1
fi

echo "✅ 构建产物:"
ls -lh dist/

# --- 发布 ---
echo ""
read -rp "🚀 确认发布 v${VERSION} 至 PyPI? (y/N) " confirm
[[ "$confirm" =~ ^[Yy]$ ]] || { echo "已取消"; exit 0; }

uv publish
echo "🎉 yakultpdf v${VERSION} 发布成功!"
