# PyPI 发布 SOP (Standard Operating Procedure)

## 适用范围
本文档规定了 `yakultpdf` 项目使用 `uv` 工具发布新版本至 PyPI 的标准操作流程。

## 前置条件
1. 确保代码已提交且本地工作区干净（无未提交更改）。
2. 项目版本号（基于 `pyproject.toml`）已经更新（例如通过 `./commit`）。
3. 已获取用于发布的 `UV_PUBLISH_TOKEN`。

## 操作步骤

### 1. 确认与清理（推荐）
在构建之前，确保当前无遗留的错误构建文件：
```bash
rm -rf dist/
```

### 2. 构建产物
使用 `uv` 进行打包，生成源码包（sdist）和 whl 包：
```bash
uv build
```
执行完毕后，检查项目根目录下的 `dist/` 文件夹，确认是否成功生成：
- `yakultpdf-<version>.tar.gz`
- `yakultpdf-<version>-py3-none-any.whl`

### 3. 发布至 PyPI
使用 `uv publish` 将 `dist/` 目录下的产物上传至 PyPI。必须附带有效的凭证：
```bash
UV_PUBLISH_TOKEN="这里填入你的Token" uv publish
```
如果环境变量中已经存在该 `UV_PUBLISH_TOKEN`，可直接执行：
```bash
uv publish
```

## 验证发布
执行完毕后：
1. 终端输出将显示包已成功上传。
2. 登录 PyPI 页面搜索 `yakultpdf`，以验证发布的版本号与期望一致。
