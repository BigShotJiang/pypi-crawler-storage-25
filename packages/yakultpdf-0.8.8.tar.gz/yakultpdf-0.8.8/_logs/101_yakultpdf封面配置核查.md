# yakultpdf 封面配置改造计划

日期：2026-05-05

## 背景

改造前的真实行为是：

1. 默认不生成封面。
2. 只有 CLI 传 `--with-cover` 才会出封面。
3. `mark2pdf.config.toml` 里的 `withcover = true` 当时不会生效。
4. frontmatter 里的 `theme.withcover: true` 当时也不会生效。

用户现在要的目标很明确：

1. 在 config 增加封面开关。
2. 在 frontmatter 增加封面开关。
3. 不写开关时，默认无封面。
4. 写了开启开关时，生成封面。

## 现状判断

当前代码里，封面是否生成，最后是靠 `no_cover` 进入转换链。

当前问题不在模板样式，而在“开启封面”的决策链没有接入 config 和 frontmatter。

当前还存在一个关键限制：

CLI 的 `--with-cover/--no-cover` 现在是二值默认 `False`。

这会导致两种情况分不出来：

1. 用户根本没传 CLI 参数。
2. 用户显式传了 `--no-cover`。

如果不先改成三态，这次需求做不干净。

## 本次方案

本次直接补实现，不再维持“只能靠 CLI 开启封面”的旧行为。

采用下面这条简单规则：

1. 默认值：无封面。
2. config 写开启：有封面。
3. frontmatter 写开启：有封面。
4. CLI 显式传参：覆盖 config 和 frontmatter。

## 字段设计

### config

工作区配置使用：

1. `[options] withcover = true`

说明：

1. 主路径只写 `options.withcover`。
2. 不兼容旧 `build.withcover`。

### frontmatter

frontmatter 使用：

1. `theme.withcover: true`

说明：

1. 这样和现有 `theme.coverstyle`、`theme.coverbg` 放在一起，结构最顺。
2. `frontmatter.yaml` 和单文件 YAML 头都走同一个字段。

## 优先级

最终优先级定为：

1. CLI 显式参数
2. 单文件 YAML 头的 `theme.withcover`
3. `frontmatter.yaml` 的 `theme.withcover`
4. `mark2pdf.config.toml` 的 `options.withcover`
5. 默认 `false`

补充约定：

1. 仍保留现有 `disables: [cover]` 机制。
2. 如果有人同时写 `theme.withcover: true` 和 `disables: [cover]`，按禁用优先。
3. 不额外设计更多兜底规则。

## 实现点

### 1. 配置类型补字段

改动点：

1. `src/mark2pdf/config/types.py`
2. `src/mark2pdf/config/loader.py`
3. `src/mark2pdf/config/defaults.py`

伪代码：

```text
OptionsConfig:
  default_template
  overwrite
  auto_newline
  withcover = false

load config:
  options_data = options
  options.withcover = options_data.get("withcover", false)

default config template:
  [options]
  withcover = false
```

### 2. CLI 改成三态

改动点：

1. `src/mark2pdf/commands/convert.py`

目标：

1. 未传 CLI 时，不要立刻把封面判成关闭。
2. `--with-cover` 才是显式开。
3. `--no-cover` 才是显式关。

伪代码：

```text
click option:
  with_cover = None / True / False

if user passed --with-cover:
  cli_cover = true
elif user passed --no-cover:
  cli_cover = false
else:
  cli_cover = none
```

### 3. 加一个统一决策函数

不要在单文件、目录、批量三条路径里各写一套。

改动点：

1. `src/mark2pdf/commands/convert.py`
2. `src/mark2pdf/conversion.py`
3. 需要时可放到公共 helper

伪代码：

```text
resolve_cover_enabled(cli_cover, merged_fm, config):
  fm_cover = merged_fm.theme.withcover == true
  config_cover = config.options.withcover == true

  if cli_cover is not none:
    return cli_cover

  if disables contains cover:
    return false

  if fm_cover:
    return true

  if config_cover:
    return true

  return false
```

然后统一落到现有转换参数：

```text
final_cover = resolve_cover_enabled(...)
no_cover = not final_cover
```

### 4. 报告输出补充可见性

改动点：

1. `src/mark2pdf/config/reporter.py`
2. `src/mark2pdf/commands/convert.py`

目标：

1. `--show-config`
2. `--dry-run`
3. `--verbose`

这几个输出里，要能直接看到“最终是否开启封面”，否则用户还是难排查。

伪代码：

```text
report:
  show options.withcover
  show merged theme.withcover
  show final_cover
```

### 5. 文档和示例同步

改动点：

1. `docs/03.配置指南.md`
2. `src/mark2pdf/resources/frontmatter.yaml`

目标：

1. 配置指南里把 `withcover = true` 写回“真实可用”状态。
2. frontmatter 示例里补 `theme.withcover: true` 的写法。
3. 明确单文件 YAML 头优先于 `frontmatter.yaml`。
4. 明确“不写就是无封面”。

## 测试计划

重点补这些测试，不多做花活：

1. config 开启封面，未传 CLI，最终应出封面。
2. frontmatter 开启封面，未传 CLI，最终应出封面。
3. config 不写，frontmatter 不写，默认无封面。
4. config 开启，但 CLI 传 `--no-cover`，最终无封面。
5. config 关闭或不写，但 CLI 传 `--with-cover`，最终有封面。
6. frontmatter 开启且 `disables: [cover]`，最终无封面。
7. `--show-config` / `--dry-run` 能显示最终封面决策。

## 涉及文件

本次大概率会动这些文件：

1. `src/mark2pdf/config/types.py`
2. `src/mark2pdf/config/loader.py`
3. `src/mark2pdf/config/defaults.py`
4. `src/mark2pdf/commands/convert.py`
5. `src/mark2pdf/conversion.py`
6. `src/mark2pdf/config/reporter.py`
7. `docs/03.配置指南.md`
8. `src/mark2pdf/resources/frontmatter.yaml`
9. `src/mark2pdf/tests/test_cli.py`
10. `src/mark2pdf/tests/test_cli_alias.py`
11. 其他和转换决策有关的测试文件

## 不做的事

这次不做下面这些扩展：

1. 不新增第二套 frontmatter 字段名。
2. 不把“封面样式字段”改成“自动开启封面”。
3. 不改模板内部的封面样式逻辑。
4. 不兼容旧 `build.withcover` 写法。
5. 不为了兼容历史写法再加更多隐式规则。

## 最终结论

这次应当走“补实现”路线，而且要一次补完整：

1. config 可开封面。
2. frontmatter 可开封面。
3. 默认仍然无封面。
4. CLI 仍是最高优先级。
5. 决策逻辑只保留一处，最后统一映射到现有 `no_cover`。

## 已完成清单

1. 给 `OptionsConfig` 增加 `withcover: bool = false`。
2. 配置加载只读取 `[options].withcover`，不再读取旧 `build.withcover`。
3. CLI 的 `--with-cover/--no-cover` 改成三态；未传时保留 `None`。
4. 在转换层新增统一封面决策逻辑，单文件、目录、批量三条路径共用。
5. 支持 frontmatter 的 `theme.withcover: true` 开启封面。
6. 保留 `disables: [cover]`，并让它继续生效。
7. `--show-config` / `--dry-run` / `--verbose` 现在会显示 `options.withcover`、`theme.withcover` 和 `final_cover`。
8. 更新了 `README.md`、`docs/01.工作区使用指南.md`、`docs/02.CLI使用说明.md`、`docs/03.配置指南.md`、`docs/04.模板语法指南.md`、`docs/05.FAQ.md`、`docs/06.项目说明文档.md`、`AGENTS.md`、`src/mark2pdf/AGENTS.md`、`src/mark2pdf/templates/AGENTS.md`、`src/mark2pdf/resources/frontmatter.yaml` 和 `src/mark2pdf/resources/mark2pdf.config.toml`。
9. 增加了单元测试与 CLI/e2e 风格测试，覆盖 config、单文件 frontmatter、`frontmatter.yaml`、CLI 覆盖、`disables` 冲突和报告输出。
