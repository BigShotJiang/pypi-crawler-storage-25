from mark2pdf.core.directory import ConversionOptions, convert_directory, merge_directory_markdown

def test_merge_directory_with_content_index(tmp_path):
    """Test merging when index.md has actual content."""
    (tmp_path / "index.md").write_text("---\ntitle: Index\n---\nIndex Content", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text("# Chapter 1", encoding="utf-8")
    
    merged = merge_directory_markdown(tmp_path)
    
    # Expect separator because index has content
    assert "Index Content\n\n---\n\n# Chapter 1" in merged

def test_merge_directory_with_empty_index(tmp_path):
    """Test merging when index.md has NO content (only frontmatter)."""
    (tmp_path / "index.md").write_text("---\nauthor: Someone\n---\n", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text("# Chapter 1", encoding="utf-8")
    
    merged = merge_directory_markdown(tmp_path)
    
    # Expect NO separator because index is empty
    # The merge should just append Chapter 1 with normal paragraph break
    assert "\n---\n\n---\n" not in merged
    assert "---\n\n# Chapter 1" in merged or "---\n\n\n# Chapter 1" in merged

def test_merge_directory_with_whitespace_index(tmp_path):
    """Test merging when index.md has only whitespace content."""
    (tmp_path / "index.md").write_text("---\nauthor: Someone\n---\n   \n\t\n", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text("# Chapter 1", encoding="utf-8")
    
    merged = merge_directory_markdown(tmp_path)
    
    # Expect NO separator (the triple dash separator)
    assert "\n\n---\n\n# Chapter 1" not in merged
    
    # Verify the content is just concatenated
    assert "   \n\t\n\n\n# Chapter 1" in merged

def test_merge_directory_no_index(tmp_path):
    """Test merging with no index file."""
    (tmp_path / "chapter1.md").write_text("# Chapter 1", encoding="utf-8")
    (tmp_path / "chapter2.md").write_text("# Chapter 2", encoding="utf-8")
    
    merged = merge_directory_markdown(tmp_path)
    
    # Normal files should be separated
    assert "# Chapter 1\n\n---\n\n# Chapter 2" in merged

def test_merge_directory_only_index(tmp_path):
    """Test merging with only index file."""
    (tmp_path / "index.md").write_text("# Index Only", encoding="utf-8")
    
    merged = merge_directory_markdown(tmp_path)
    assert merged == "# Index Only"


def test_merge_directory_injects_title_and_image_from_subfile(tmp_path):
    """Sub-file title/image frontmatter should be injected into body after merge."""
    (tmp_path / "index.md").write_text("---\ntitle: Index\n---\n", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    merged = merge_directory_markdown(tmp_path)

    assert "::: {#topimage}\nimages/ch1.jpg\n:::" in merged
    assert "# Chapter One" in merged
    assert "正文内容" in merged
    assert "image: images/ch1.jpg" not in merged


def test_merge_directory_can_disable_title_injection(tmp_path):
    """When inject_title is False, title/image should not be injected."""
    (tmp_path / "index.md").write_text("---\ntitle: Index\n---\n", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    merged = merge_directory_markdown(tmp_path, inject_title=False)

    assert "::: {#topimage}\nimages/ch1.jpg\n:::" not in merged
    assert "# Chapter One" not in merged
    assert "正文内容" in merged


def test_merge_directory_injects_partial_title_or_image(tmp_path):
    """Only available fields should be injected."""
    (tmp_path / "index.md").write_text("---\ntitle: Index\n---\n", encoding="utf-8")
    (tmp_path / "chapter1.md").write_text("---\ntitle: Only Title\n---\nA", encoding="utf-8")
    (tmp_path / "chapter2.md").write_text("---\nimage: images/only.jpg\n---\nB", encoding="utf-8")

    merged = merge_directory_markdown(tmp_path)

    assert "# Only Title" in merged
    assert "::: {#topimage}\nimages/only.jpg\n:::" in merged
    assert "images/only.jpg\n:::\n\n# " not in merged


def test_merge_directory_injects_title_and_image_for_index(tmp_path):
    """Index title/image should also be injected while preserving frontmatter."""
    (tmp_path / "index.md").write_text(
        "---\ntitle: Index Title\nimage: images/index.jpg\n---\n",
        encoding="utf-8",
    )
    (tmp_path / "chapter1.md").write_text("# Chapter 1", encoding="utf-8")

    merged = merge_directory_markdown(tmp_path)

    assert merged.startswith("---\ntitle: Index Title")
    assert "::: {#topimage}\nimages/index.jpg\n:::" in merged
    assert "# Index Title" in merged
    assert "\n\n---\n\n# Chapter 1" in merged


def test_merge_directory_can_disable_index_image_injection(tmp_path):
    """Index image injection can be disabled independently."""
    (tmp_path / "index.md").write_text(
        "---\ntitle: Index Title\nimage: images/index.jpg\n---\n",
        encoding="utf-8",
    )
    (tmp_path / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    merged = merge_directory_markdown(tmp_path, inject_index_image=False)

    assert "# Index Title" in merged
    assert "::: {#topimage}\nimages/index.jpg\n:::" not in merged
    assert "::: {#topimage}\nimages/ch1.jpg\n:::" in merged


def test_convert_directory_disables_title_injection(tmp_path, monkeypatch):
    """index disables: [title_injection] should stop sub-file title/image injection."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("mark2pdf.core.directory.check_pandoc_typst", lambda: None)

    captured = {}

    def fake_execute_in_sandbox(
        *,
        content,
        temp_filename,
        output_path,
        images_source_dir,
        tmp_dir,
        sandbox_prefix,
        options,
        config=None,
        frontmatter=None,
    ):
        captured["content"] = content
        captured["output_path"] = output_path
        return output_path

    monkeypatch.setattr("mark2pdf.core.directory.execute_in_sandbox", fake_execute_in_sandbox)

    book_dir = tmp_path / "in" / "book"
    book_dir.mkdir(parents=True)
    (book_dir / "index.md").write_text(
        "---\ntitle: Book Index\ndisables:\n  - title_injection\n---\n",
        encoding="utf-8",
    )
    (book_dir / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    convert_directory(
        directory="book",
        options=ConversionOptions(),
        indir="in",
        outdir="out",
    )

    assert "# Chapter One" not in captured["content"]
    assert "::: {#topimage}\nimages/ch1.jpg\n:::" not in captured["content"]
    assert "# Book Index" not in captured["content"]
    assert "正文内容" in captured["content"]


def test_convert_directory_injects_title_by_default(tmp_path, monkeypatch):
    """Title/image injection should be enabled by default in directory mode."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("mark2pdf.core.directory.check_pandoc_typst", lambda: None)

    captured = {}

    def fake_execute_in_sandbox(
        *,
        content,
        temp_filename,
        output_path,
        images_source_dir,
        tmp_dir,
        sandbox_prefix,
        options,
        config=None,
        frontmatter=None,
    ):
        captured["content"] = content
        captured["output_path"] = output_path
        return output_path

    monkeypatch.setattr("mark2pdf.core.directory.execute_in_sandbox", fake_execute_in_sandbox)

    book_dir = tmp_path / "in" / "book"
    book_dir.mkdir(parents=True)
    (book_dir / "index.md").write_text(
        "---\ntitle: Book Index\nimage: images/index.jpg\n---\n",
        encoding="utf-8",
    )
    (book_dir / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    convert_directory(
        directory="book",
        options=ConversionOptions(),
        indir="in",
        outdir="out",
    )

    assert "# Book Index" in captured["content"]
    assert captured["content"].count("{#topimage}") == 2
    assert "images/index.jpg" in captured["content"]
    assert "# Chapter One" in captured["content"]
    assert "images/ch1.jpg" in captured["content"]


def test_convert_directory_disables_index_image_only(tmp_path, monkeypatch):
    """disables: [index_image] only disables index image injection."""
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("mark2pdf.core.directory.check_pandoc_typst", lambda: None)

    captured = {}

    def fake_execute_in_sandbox(
        *,
        content,
        temp_filename,
        output_path,
        images_source_dir,
        tmp_dir,
        sandbox_prefix,
        options,
        config=None,
        frontmatter=None,
    ):
        captured["content"] = content
        captured["output_path"] = output_path
        return output_path

    monkeypatch.setattr("mark2pdf.core.directory.execute_in_sandbox", fake_execute_in_sandbox)

    book_dir = tmp_path / "in" / "book"
    book_dir.mkdir(parents=True)
    (book_dir / "index.md").write_text(
        "---\ntitle: Book Index\nimage: images/index.jpg\ndisables:\n  - index_image\n---\n",
        encoding="utf-8",
    )
    (book_dir / "chapter1.md").write_text(
        "---\ntitle: Chapter One\nimage: images/ch1.jpg\n---\n正文内容",
        encoding="utf-8",
    )

    convert_directory(
        directory="book",
        options=ConversionOptions(),
        indir="in",
        outdir="out",
    )

    assert "# Book Index" in captured["content"]
    assert "# Chapter One" in captured["content"]
    assert captured["content"].count("{#topimage}") == 1
    assert "images/ch1.jpg" in captured["content"]
