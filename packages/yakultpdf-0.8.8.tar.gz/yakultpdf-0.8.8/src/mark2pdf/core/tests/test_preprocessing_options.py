from mark2pdf.core.utils import apply_default_preprocessing, is_feature_disabled
from mark2pdf.helper_markdown import (
    pre_add_line_breaks,
    pre_ensure_list_spacing,
    pre_for_typst,
    pre_mermaid_to_typst,
)


def test_apply_default_preprocessing_auto_newline_toggle():
    content = "line1\nline2\n"

    expected_with_auto = pre_for_typst(
        pre_add_line_breaks(pre_mermaid_to_typst(pre_ensure_list_spacing(content)))
    )
    expected_without_auto = pre_for_typst(
        pre_mermaid_to_typst(pre_ensure_list_spacing(content))
    )

    assert apply_default_preprocessing(content, auto_newline=True) == expected_with_auto
    assert apply_default_preprocessing(content, auto_newline=False) == expected_without_auto


def test_apply_default_preprocessing_converts_mermaid():
    content = "```mermaid\ngraph TD; A-->B;\n```"
    result = apply_default_preprocessing(content, auto_newline=False)

    assert "```{=typst}" in result
    assert '#mermaid("graph TD; A-->B;")' in result


def test_apply_default_preprocessing_can_disable_mermaid():
    content = "```mermaid\ngraph TD; A-->B;\n```"
    result = apply_default_preprocessing(content, auto_newline=False, enable_mermaid=False)

    assert "```{=typst}" not in result
    assert "```mermaid" in result


def test_is_feature_disabled_with_frontmatter_disables():
    fm = {"disables": ["cover", "mermaid", "toc"]}
    assert is_feature_disabled(fm, "mermaid") is True
    assert is_feature_disabled(fm, "toc") is True
    assert is_feature_disabled(fm, "header") is False
