"""
mark2pdf.core 目录模式 API

提供目录合并和转换功能。
"""

from collections.abc import Callable
import re
from typing import TYPE_CHECKING
from pathlib import Path

from mark2pdf.helper_markdown import extract_frontmatter, pre_clean_frontmatter
from mark2pdf.helper_typst import check_pandoc_typst

from .core import execute_in_sandbox
from .options import ConversionOptions
from .postprocess import ensure_tc_postprocess
from .utils import (
    apply_default_preprocessing,
    get_output_filename,
    inject_default_frontmatter,
    is_feature_disabled,
    merge_frontmatter,
)

if TYPE_CHECKING:
    from mark2pdf.config.types import ConfigLike

FRONTMATTER_BLOCK_PATTERN = re.compile(r"^---\s*\n.*?\n---\s*(?:\n|$)", re.DOTALL)


def _resolve_index_path(dir_path: Path) -> Path:
    """返回目录模式的 index 文件路径（优先 index.mdx，其次 index.md）。"""
    index_path = dir_path / "index.mdx"
    if index_path.exists():
        return index_path
    return dir_path / "index.md"


def _normalize_frontmatter_text(value: object | None) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _inject_title_header(content: str, title: object | None, image: object | None) -> str:
    """按 topimage -> title 的顺序注入正文头部。"""
    header_parts = []
    image_text = _normalize_frontmatter_text(image)
    title_text = _normalize_frontmatter_text(title)

    if image_text:
        header_parts.append(f"::: {{#topimage}}\n{image_text}\n:::")
    if title_text:
        header_parts.append(f"# {title_text}")

    if not header_parts:
        return content

    header = "\n\n".join(header_parts)
    if not content:
        return header
    return f"{header}\n\n{content}"


def _inject_title_header_preserve_frontmatter(
    content: str,
    title: object | None,
    image: object | None,
) -> str:
    """在保留 frontmatter 的前提下为正文注入题图/标题。"""
    match = FRONTMATTER_BLOCK_PATTERN.match(content)
    if not match:
        return _inject_title_header(content, title, image)

    fm_block = content[: match.end()]
    body = content[match.end() :]
    injected_body = _inject_title_header(body, title, image)
    if not injected_body:
        return fm_block
    return f"{fm_block}\n{injected_body}"


def merge_directory_markdown(
    dir_path: Path,
    verbose: bool = False,
    inject_title: bool = True,
    inject_index_image: bool = True,
) -> str:
    """
    合并目录中的所有 markdown 文件

    参数：
        dir_path: 目录路径
        verbose: 是否显示详细信息
        inject_title: 是否将子文件 frontmatter 的 title/image 注入正文
        inject_index_image: 是否注入 index frontmatter 的 image（仅目录模式）

    返回：
        合并后的内容字符串
    """
    if not dir_path.is_dir():
        raise ValueError(f"目录不存在：{dir_path}")

    merged_content = []

    # 首先处理 index.mdx 或 index.md（优先 mdx）
    index_path = _resolve_index_path(dir_path)
    if index_path.exists():
        if verbose:
            print(f"读取 {index_path.name}...")
        with open(index_path, encoding="utf-8") as f:
            index_content = f.read()
            if inject_title:
                index_fm = extract_frontmatter(index_content)
                index_image = index_fm.get("image") if inject_index_image else None
                index_content = _inject_title_header_preserve_frontmatter(
                    index_content,
                    index_fm.get("title"),
                    index_image,
                )
            merged_content.append(index_content)

    # 获取所有其他 .md 文件并排序
    md_files = []
    for md_file in dir_path.glob("*.md"):
        if md_file.name not in ["index.md", "merged.md"] and not md_file.name.startswith("md2pdf_"):
            md_files.append(md_file)

    md_files.sort(key=lambda x: x.name)

    for md_file in md_files:
        if verbose:
            print(f"读取 {md_file.name}...")
        with open(md_file, encoding="utf-8") as f:
            content = f.read()
            if merged_content:
                title = None
                image = None
                if inject_title:
                    fm = extract_frontmatter(content)
                    title = fm.get("title")
                    image = fm.get("image")

                # 使用更健壮的 frontmatter 移除函数
                content = pre_clean_frontmatter(content)
                if inject_title:
                    content = _inject_title_header(content, title, image)
            merged_content.append(content)

    if len(merged_content) > 0:
        index_content = merged_content[0]
        # 检查 Index 是否包含实际内容（去除 frontmatter 后是否为空）
        index_body = pre_clean_frontmatter(index_content).strip()
        has_index_content = len(index_body) > 0

        final_content = index_content

        for i, content in enumerate(merged_content[1:]):
            # 如果是第一个追加（即 Index 之后）且 Index 无内容，则不加分隔符
            # 否则（Index 有内容，或者后续章节之间）都需要分隔符
            if i == 0 and not has_index_content:
                final_content += "\n\n" + content
            else:
                final_content += "\n\n---\n\n" + content
    else:
        final_content = ""

    if verbose:
        print(f"合并完成，共 {len(md_files) + (1 if index_path.exists() else 0)} 个文件")

    return final_content


def convert_directory(
    directory: str,
    output_file: str | None = None,
    options: ConversionOptions = ConversionOptions(),
    indir: str | None = None,
    outdir: str | None = None,
    default_frontmatter: dict | None = None,
    postprocess: Callable[[str], str] | None = None,
    config: "ConfigLike | None" = None,
) -> Path | None:
    """
    合并目录中所有 Markdown 并转换为 PDF

    参数：
        directory: 目录路径（相对于 indir）
        output_file: 输出文件名（可选）
        options: 转换配置选项
        indir: 输入目录（默认从配置读取）
        outdir: 输出目录（默认从配置读取）
        default_frontmatter: 默认 frontmatter 字典，用于注入缺失的字段
        postprocess: 后处理函数，接收内容返回处理后内容。在内置预处理之后追加执行
        config: PdfworkConfig 配置对象（可选）

    返回：
        成功返回输出文件路径 Path，失败返回 None
    """
    check_pandoc_typst()

    if options.verbose:
        print(f"使用目录模式：{directory}")

    if config is None:
        try:
            from mark2pdf import ConfigManager

            config = ConfigManager.load()
        except ImportError:
            config = None

    base_dir = Path.cwd()
    if config is not None and config.data_root is not None:
        base_dir = config.data_root

    if indir is None and config is not None:
        indir_path = config.input_dir
    else:
        indir_path = Path(indir or "in")
        if not indir_path.is_absolute():
            indir_path = base_dir / indir_path

    if outdir is None and config is not None:
        out_dir = config.output_dir
    else:
        out_dir = Path(outdir or "out")
        if not out_dir.is_absolute():
            out_dir = base_dir / out_dir

    dir_path = indir_path / directory

    index_path = _resolve_index_path(dir_path)
    index_frontmatter = extract_frontmatter(index_path) if index_path.exists() else {}
    # 合并默认 frontmatter，使工作区级 disables 也能生效（index 自身优先）
    merged_index_fm = merge_frontmatter(default_frontmatter, index_frontmatter)
    enable_title_injection = not is_feature_disabled(merged_index_fm, "title_injection")
    enable_index_image_injection = not is_feature_disabled(merged_index_fm, "index_image")

    content = merge_directory_markdown(
        dir_path,
        verbose=options.verbose,
        inject_title=enable_title_injection,
        inject_index_image=enable_index_image_injection,
    )

    # 系统级：注入默认 frontmatter（在所有预处理之前）
    if default_frontmatter:
        content = inject_default_frontmatter(content, default_frontmatter, verbose=options.verbose)

    frontmatter = extract_frontmatter(content)

    if not output_file:
        output_name = dir_path.name
    else:
        output_name = output_file

    ext = "typ" if options.to_typst else "pdf"
    output_path = out_dir / f"{output_name}.{ext}"

    # 获取最终输出文件名
    output_path = get_output_filename(
        content,
        output_path,
        options.tc,
        options.verbose,
        options.force_filename,
        frontmatter=frontmatter,
    )

    # 预处理
    if options.verbose:
        print("应用 Markdown 预处理...")

    content = apply_default_preprocessing(
        content,
        removelink=options.removelink,
        auto_newline=options.auto_newline,
        enable_mermaid=not is_feature_disabled(frontmatter, "mermaid"),
        verbose=options.verbose,
    )

    if options.tc:
        postprocess = ensure_tc_postprocess(postprocess)

    if postprocess:
        content = postprocess(content)

    # 创建沙箱并执行转换
    if config is not None and config.data_root is not None:
        tmp_dir = config.tmp_dir
    else:
        tmp_dir = base_dir / "tmp"

    return execute_in_sandbox(
        content=content,
        temp_filename=f"{output_name}.md",
        output_path=output_path,
        images_source_dir=dir_path,  # 目录模式：使用目录本身（in/目录名/images/）
        tmp_dir=tmp_dir,
        sandbox_prefix="md2pdf_dir_",
        options=options,
        config=config,
        frontmatter=frontmatter,
    )
