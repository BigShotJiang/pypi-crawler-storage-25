"""
pre_ensure_list_spacing 单元测试

测试确保列表前有空行，同时列表内部保持紧凑
"""

import pytest

from mark2pdf.helper_markdown import pre_ensure_list_spacing


class TestPreEnsureListSpacing:
    """pre_ensure_list_spacing 函数测试"""

    def test_unordered_list_after_paragraph(self):
        """段落后紧接无序列表：应插入空行"""
        input_text = "段落\n- 项目1\n- 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert "段落\n\n- 项目1" in result
        assert "- 项目1\n- 项目2" in result  # 列表内部不打散

    def test_ordered_list_after_paragraph(self):
        """段落后紧接有序列表：应插入空行"""
        input_text = "段落\n1. 项目1\n2. 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert "段落\n\n1. 项目1" in result
        assert "1. 项目1\n2. 项目2" in result  # 列表内部不打散

    def test_list_already_separated(self):
        """已有空行：不应多加"""
        input_text = "段落\n\n- 项目1\n- 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert result.count("\n\n") == 1

    def test_list_items_stay_compact(self):
        """列表项之间不应插入空行"""
        input_text = "段落\n- 项目1\n- 项目2\n- 项目3"
        result = pre_ensure_list_spacing(input_text)
        # 列表内部应保持紧凑
        assert "- 项目1\n- 项目2\n- 项目3" in result

    def test_nested_list(self):
        """嵌套列表应保持结构"""
        input_text = "段落\n- 项目1\n  - 子项目\n- 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert "- 项目1\n  - 子项目" in result

    def test_code_block_protection(self):
        """代码块内的列表语法不应被处理"""
        input_text = "段落\n```\n- 这不是列表\n- 也不是\n```"
        result = pre_ensure_list_spacing(input_text)
        # 代码块内不应插入空行
        assert "```\n- 这不是列表\n- 也不是\n```" in result

    def test_user_scenario(self):
        """用户原始场景：引导语后紧接有序列表"""
        input_text = """**预期结果：**
Skill 会引导你完成五步框架：
1. **Objective**：确认目标是否 SMART
2. **Audience**：定义目标受众画像
3. **Message**：提炼核心信息和支持点"""
        result = pre_ensure_list_spacing(input_text)
        # 列表前应有空行
        assert "五步框架：\n\n1." in result
        # 列表内部应紧凑
        assert "1. **Objective**：确认目标是否 SMART\n2." in result

    def test_multiple_lists(self):
        """多个列表：每个列表前都应有空行"""
        input_text = "段落1\n- 列表1项1\n- 列表1项2\n段落2\n1. 列表2项1\n2. 列表2项2"
        result = pre_ensure_list_spacing(input_text)
        assert "段落1\n\n- 列表1项1" in result
        assert "段落2\n\n1. 列表2项1" in result

    def test_plus_and_star_markers(self):
        """+ 和 * 作为列表标记"""
        input_text = "段落\n+ 项目1\n* 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert "段落\n\n+ 项目1" in result

    def test_empty_content(self):
        """空内容不应报错"""
        result = pre_ensure_list_spacing("")
        assert result == ""

    def test_list_at_start(self):
        """文件开头就是列表：不应报错"""
        input_text = "- 项目1\n- 项目2"
        result = pre_ensure_list_spacing(input_text)
        assert result == input_text
