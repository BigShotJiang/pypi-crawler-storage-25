"""
pre_mermaid_to_typst 单元测试
"""

from mark2pdf.helper_markdown import pre_mermaid_to_typst


def test_pre_mermaid_to_typst_basic():
    content = "```mermaid\ngraph TD; A-->B;\n```"
    expected = '```{=typst}\n#mermaid("graph TD; A-->B;")\n```'
    assert pre_mermaid_to_typst(content) == expected


def test_pre_mermaid_to_typst_multiple_blocks():
    content = (
        "before\n\n"
        "```mermaid\ngraph TD; A-->B;\n```\n\n"
        "middle\n\n"
        "```mermaid\nsequenceDiagram\nA->>B: hello\n```\n\n"
        "after"
    )
    result = pre_mermaid_to_typst(content)

    assert '#mermaid("graph TD; A-->B;")' in result
    assert '#mermaid("sequenceDiagram\\nA->>B: hello")' in result
    assert result.count("```{=typst}") == 2
    assert "before" in result and "middle" in result and "after" in result


def test_pre_mermaid_to_typst_escape_quotes_and_backslashes():
    content = '```mermaid\ngraph TD; A["hello"] --> B[C:\\path\\to\\file];\n```'
    expected = (
        '```{=typst}\n'
        '#mermaid("graph TD; A[\\"hello\\"]-->B[C:\\\\path\\\\to\\\\file];")\n'
        "```"
    )
    assert pre_mermaid_to_typst(content) == expected


def test_pre_mermaid_to_typst_no_mermaid_block():
    content = "```python\nprint('hello')\n```"
    assert pre_mermaid_to_typst(content) == content


def test_pre_mermaid_to_typst_with_other_code_blocks():
    content = (
        "```python\nprint('keep')\n```\n\n"
        "```mermaid\nflowchart LR\nA --> B\n```\n\n"
        "```bash\necho keep\n```"
    )
    result = pre_mermaid_to_typst(content)

    assert "```python\nprint('keep')\n```" in result
    assert "```bash\necho keep\n```" in result
    assert '#mermaid("flowchart LR\\nA-->B")' in result


def test_pre_mermaid_to_typst_normalize_labeled_edges_spacing():
    content = "```mermaid\ngraph TD\nA-->B\nB -- Yes --> C\n```"
    result = pre_mermaid_to_typst(content)
    assert '#mermaid("graph TD\\nA-->B\\nB--Yes-->C")' in result


def test_pre_mermaid_to_typst_normalize_pipe_labeled_edges():
    content = (
        "```mermaid\n"
        "graph TD\n"
        "B-->|确定风格| C\n"
        "B -->|分析结构| D\n"
        "```"
    )
    result = pre_mermaid_to_typst(content)
    assert '#mermaid("graph TD\\nB--确定风格-->C\\nB--分析结构-->D")' in result


def test_pre_mermaid_to_typst_skip_inside_four_backticks():
    content = (
        "````\n"
        "```mermaid\n"
        "graph TB\n"
        "A[观察 AI 的自然表现] --> B{是否符合预期?}\n"
        "B -- 否 --> C[记录 AI 的错误和借口]\n"
        "C --> D[针对性编写技能规则]\n"
        "D --> E[重新测试验证]\n"
        "%% E --> B\n"
        "B -- 是 --> F[技能正式上线]\n"
        "```\n"
        "````\n"
    )
    assert pre_mermaid_to_typst(content) == content
