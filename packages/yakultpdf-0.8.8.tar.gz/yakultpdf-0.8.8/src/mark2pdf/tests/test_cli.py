"""
mark2pdf CLI 测试
"""

import os
import sys
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# 添加父目录路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from mark2pdf.cli import main


class TestInitCommand:
    """init 命令测试"""

    def test_init_missing_arg(self):
        """测试缺少参数"""
        runner = CliRunner()
        result = runner.invoke(main, ["init"])
        assert result.exit_code != 0
        assert "Missing argument 'TARGET_DIR'" in result.output

    def test_init_non_empty_dir_fails(self, tmp_path):
        """测试在非空目录运行失败"""
        # 创建一个非空目录
        target = tmp_path / "non_empty"
        target.mkdir()
        (target / "foo.txt").touch()

        runner = CliRunner()
        # 必须传入目录参数
        result = runner.invoke(main, ["init", str(target)])

        assert result.exit_code != 0
        assert "目录不为空" in result.output
        assert "禁止在非空目录初始化" in result.output

    def test_init_empty_dir_succeeds(self, tmp_path):
        """测试在空目录运行成功"""
        target = tmp_path / "empty"
        target.mkdir()

        runner = CliRunner()
        with patch("mark2pdf.commands.workspace.init_workspace") as mock_init:
            result = runner.invoke(main, ["init", str(target)])

            assert result.exit_code == 0
            mock_init.assert_called_once_with(
                target.resolve(),
                template_name=None,
                simple=False,
            )

    def test_init_template_only(self, tmp_path):
        """测试 --template 仅复制指定模板"""
        target = tmp_path / "template_only"
        target.mkdir()

        runner = CliRunner()
        with patch("mark2pdf.commands.workspace.init_workspace") as mock_init:
            result = runner.invoke(main, ["init", str(target), "--template", "nb.typ"])

            assert result.exit_code == 0
            mock_init.assert_called_once_with(
                target.resolve(),
                template_name="nb.typ",
                simple=False,
            )

    def test_init_ignores_ds_store(self, tmp_path):
        """测试忽略 .DS_Store 文件"""
        target = tmp_path / "ds_store_only"
        target.mkdir()
        (target / ".DS_Store").touch()

        runner = CliRunner()
        with patch("mark2pdf.commands.workspace.init_workspace") as mock_init:
            result = runner.invoke(main, ["init", str(target)])

            assert result.exit_code == 0
            mock_init.assert_called_once_with(
                target.resolve(),
                template_name=None,
                simple=False,
            )

    def test_init_simple_non_empty_dir_succeeds(self, tmp_path):
        """测试 --simple 允许非空目录"""
        target = tmp_path / "non_empty"
        target.mkdir()
        (target / "foo.txt").touch()

        runner = CliRunner()
        with patch("mark2pdf.commands.workspace.init_workspace") as mock_init:
            result = runner.invoke(main, ["init", str(target), "--simple"])

            assert result.exit_code == 0
            mock_init.assert_called_once_with(
                target.resolve(),
                template_name=None,
                simple=True,
            )


class TestVersionCommand:
    """version 命令测试"""

    def test_version_output(self):
        """测试版本输出"""
        runner = CliRunner()
        result = runner.invoke(main, ["version"])
        assert result.exit_code == 0
        assert "yakultpdf" in result.output


class TestConvertCommand:
    """convert 命令测试"""

    def test_convert_help(self):
        """测试帮助信息"""
        runner = CliRunner()
        result = runner.invoke(main, ["convert", "--help"])
        assert result.exit_code == 0
        assert "--show-config" in result.output
        assert "--dry-run" in result.output
        assert "--postprocess" in result.output
        assert "--batchall" in result.output
        assert "--typst" in result.output
        assert "--latest" in result.output

    def test_convert_standalone_dry_run(self):
        """测试无配置文件时的独立模式"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md", "--dry-run"])
            assert result.exit_code == 0
            assert "执行计划" in result.output
            assert "paths.input: ." in result.output
            assert "paths.output: ." in result.output

    def test_convert_batchall_dry_run(self):
        """测试 --batchall 等价于批量转换当前目录"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--batchall", "--dry-run"])
            assert result.exit_code == 0
            # jobs=4 时显示并发模式
            assert "转换目录 '.'" in result.output

    def test_batchall_batch_conflict(self):
        """--batchall 与 --batch 不能同时使用"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--batchall", "--batch", "foo"])
            assert result.exit_code != 0
            assert "--batchall 与 --batch 不能同时使用" in result.output

    def test_dir_batch_conflict(self):
        """--dir 与 --batch 不能同时使用"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            # 需要跳过工具检查，否则会检查 pandoc/typst
            result = runner.invoke(
                main, ["convert", "--dir", "foo", "--batch", "bar", "--skip-tool-check"]
            )
            assert result.exit_code != 0
            assert "--dir 和 --batch" in result.output

    def test_show_config_mode(self):
        """--show-config 仅显示配置不执行"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md", "--show-config"])
            assert result.exit_code == 0
            assert "合并后的完整配置" in result.output
            # 不应有执行计划
            assert "执行计划" not in result.output

    def test_show_config_reports_cover_from_config(self):
        """--show-config 应显示配置中的封面开关"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            Path("mark2pdf.config.toml").write_text("""
[options]
withcover = true
""")

            result = runner.invoke(main, ["convert", "test.md", "--show-config"])

            assert result.exit_code == 0
            assert "options.withcover: True" in result.output
            assert "final_cover: True" in result.output

    def test_dry_run_reports_cover_disabled_by_frontmatter(self):
        """--dry-run 应显示 disables: cover 后的最终封面结果"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("""---
theme:
  withcover: true
disables:
  - cover
---
# Test
""")

            result = runner.invoke(main, ["convert", "test.md", "--dry-run"])

            assert result.exit_code == 0
            assert "withcover" in result.output
            assert "final_cover: False" in result.output

    def test_show_config_cli_no_cover_overrides_config_withcover(self):
        """CLI 显式 --no-cover 应始终压过 config withcover"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            Path("mark2pdf.config.toml").write_text("""
[options]
withcover = true
""")

            result = runner.invoke(main, ["convert", "test.md", "--show-config", "--no-cover"])

            assert result.exit_code == 0
            assert "options.withcover: True" in result.output
            assert "final_cover: False" in result.output

    def test_show_config_cli_with_cover_overrides_frontmatter_disables(self):
        """CLI 显式 --with-cover 应始终压过 frontmatter disables"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("""---
disables:
  - cover
---
# Test
""")

            result = runner.invoke(main, ["convert", "test.md", "--show-config", "--with-cover"])

            assert result.exit_code == 0
            assert "disables" in result.output
            assert "final_cover: True" in result.output

    def test_show_config_reads_current_file_frontmatter_outside_input_dir(self):
        """单文件 frontmatter 应读取实际传入文件，而不是只看 input_dir"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("mark2pdf.config.toml").write_text("""
[paths]
in = "in"
out = "out"
""")
            Path("in").mkdir()
            Path("out").mkdir()
            Path("notes").mkdir()
            (Path("notes") / "test.md").write_text("""---
theme:
  withcover: true
---
# Test
""")

            previous_cwd = Path.cwd()
            os.chdir(Path("notes"))
            try:
                result = runner.invoke(main, ["convert", "test.md", "--show-config"])
            finally:
                os.chdir(previous_cwd)

            assert result.exit_code == 0
            assert "theme.withcover: True" in result.output
            assert "final_cover: True" in result.output

    def test_missing_default_file_fails_gracefully(self):
        """默认 index.md 缺失时应输出用户可读错误，而不是 traceback"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--skip-tool-check"])
            assert result.exit_code != 0
            assert "错误: 找不到输入文件" in result.output
            assert "index.md" in result.output
            assert "Traceback" not in result.output

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_single_file_calls_run_conversion(self, mock_check, mock_run):
        """单文件模式调用 run_conversion"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            # 验证调用参数
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["filename"] == "test.md"

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_single_file_typst_option(self, mock_check, mock_run):
        """单文件模式 --typst 应透传 to_typst=True"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md", "--typst"])
            assert result.exit_code == 0
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["to_typst"] is True

    @patch("mark2pdf.commands.convert.run_directory_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_dir_mode_calls_run_directory_conversion(self, mock_check, mock_run):
        """--dir 模式调用 run_directory_conversion"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("docs").mkdir()
            (Path("docs") / "index.md").write_text("# Docs")
            result = runner.invoke(main, ["convert", "--dir", "docs"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["directory"] == "docs"

    @patch("mark2pdf.commands.convert.run_batch_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_batch_mode_calls_run_batch_conversion(self, mock_check, mock_run):
        """--batch 模式调用 run_batch_conversion"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("batch").mkdir()
            (Path("batch") / "file1.md").write_text("# File 1")
            result = runner.invoke(main, ["convert", "--batch", "batch"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["directory"] == "batch"

class TestTemplateCommand:
    """template 命令测试"""

    def test_template_requires_workspace(self):
        """测试无工作区配置时失败"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["template", "nb.typ"])
            assert result.exit_code != 0
            assert "未检测到工作区配置" in result.output

    def test_template_copies_to_workspace(self):
        """测试复制模板到工作区"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("mark2pdf.config.toml").write_text('[project]\nname = "test"')

            result = runner.invoke(main, ["template", "card.typ"])

            assert result.exit_code == 0
            assert Path("template/card.typ").exists()

    def test_template_copies_directory(self):
        """测试复制模板目录"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("mark2pdf.config.toml").write_text('[project]\nname = "test"')

            result = runner.invoke(main, ["template", "letter"])

            assert result.exit_code == 0
            assert Path("template/letter").exists()


class TestCoverPrepareCommand:
    """coverimg 命令测试"""

    def test_list_papers(self):
        """测试列出纸型"""
        runner = CliRunner()
        result = runner.invoke(main, ["coverimg", "list"])
        assert result.exit_code == 0
        assert "a4" in result.output
        assert "letter" in result.output

    def test_check_help(self):
        """测试 check 子命令帮助"""
        runner = CliRunner()
        result = runner.invoke(main, ["coverimg", "check", "--help"])
        assert result.exit_code == 0
        assert "--paper" in result.output


class TestLatestFlag:
    """--latest 自动选择最新文件测试"""

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_latest_picks_newest_file(self, mock_check, mock_run):
        """--latest 选择 mtime 最新的 .md"""
        import os

        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("a.md").write_text("# A")
            Path("b.md").write_text("# B")
            # 显式设置 mtime: b.md 更新
            os.utime("a.md", (1000, 1000))
            os.utime("b.md", (2000, 2000))
            result = runner.invoke(main, ["convert", "--latest"])
            assert result.exit_code == 0
            assert "自动选择最新文件: b.md" in result.output
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["filename"] == "b.md"

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_latest_with_single_file(self, mock_check, mock_run):
        """只有一个 .md 文件时直接选中"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("only.md").write_text("# Only")
            result = runner.invoke(main, ["convert", "--latest"])
            assert result.exit_code == 0
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["filename"] == "only.md"

    def test_latest_no_md_files(self):
        """输入目录无 .md 文件时报错"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--latest"])
            assert result.exit_code != 0
            assert "未找到 .md 文件" in result.output
            assert "Traceback" not in result.output

    def test_latest_dir_conflict(self):
        """--latest 与 --dir 冲突"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--latest", "--dir", "docs"])
            assert result.exit_code != 0
            assert "--latest 与 --dir/--batch 不能同时使用" in result.output

    def test_latest_batch_conflict(self):
        """--latest 与 --batch 冲突"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--latest", "--batch", "foo"])
            assert result.exit_code != 0
            assert "--latest 与 --dir/--batch 不能同时使用" in result.output

    def test_latest_batchall_conflict(self):
        """--latest 与 --batchall 冲突"""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(main, ["convert", "--latest", "--batchall"])
            assert result.exit_code != 0
            assert "--latest 与 --dir/--batch 不能同时使用" in result.output
