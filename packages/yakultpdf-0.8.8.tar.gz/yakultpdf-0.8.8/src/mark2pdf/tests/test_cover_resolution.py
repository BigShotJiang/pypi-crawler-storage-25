"""
封面开关决策测试
"""

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from mark2pdf.config import CONFIG_FILENAME
from mark2pdf.conversion import (
    resolve_cover_enabled,
    run_batch_conversion,
    run_conversion,
    run_directory_conversion,
)


@pytest.fixture
def cover_workspace(tmp_path, monkeypatch):
    """创建封面测试工作区"""
    (tmp_path / "in").mkdir()
    (tmp_path / "out").mkdir()
    monkeypatch.chdir(tmp_path)
    return tmp_path


def write_config(workspace: Path, *, withcover: bool = False):
    (workspace / CONFIG_FILENAME).write_text(
        f"""
[project]
name = "cover-test"

[paths]
in = "in"
out = "out"

[options]
default_template = "nb"
withcover = {"true" if withcover else "false"}
""",
        encoding="utf-8",
    )


def make_dummy_config(*, withcover: bool):
    class DummyOptions:
        pass

    DummyOptions.withcover = withcover

    class DummyConfig:
        options = DummyOptions()

    return DummyConfig()


class TestResolveCoverEnabled:
    """cover 决策函数测试"""

    def test_disables_cover_wins(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=True),
                merged_fm={"theme": {"withcover": True}, "disables": ["cover"]},
                no_cover=None,
            )
            is False
        )

    def test_top_level_withcover_works(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=False),
                merged_fm={"withcover": True},
                no_cover=None,
            )
            is True
        )

    def test_file_frontmatter_overrides_default_disables(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=False),
                file_fm={"theme": {"withcover": True}},
                default_fm={"disables": ["cover"]},
                no_cover=None,
            )
            is True
        )

    def test_cli_with_cover_overrides_file_disables(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=False),
                file_fm={"disables": ["cover"]},
                default_fm={"theme": {"withcover": False}},
                no_cover=False,
            )
            is True
        )

    def test_cli_no_cover_overrides_file_withcover(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=True),
                file_fm={"theme": {"withcover": True}},
                default_fm={"withcover": True},
                no_cover=True,
            )
            is False
        )

    def test_cli_no_cover_overrides_config_withcover(self):
        assert (
            resolve_cover_enabled(
                config=make_dummy_config(withcover=True),
                file_fm={},
                default_fm={},
                no_cover=True,
            )
            is False
        )


class TestRunConversionCover:
    """run_conversion / run_directory_conversion / run_batch_conversion 的封面测试"""

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_uses_options_cover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=True)
        (cover_workspace / "in" / "test.md").write_text("# Test", encoding="utf-8")

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_uses_frontmatter_withcover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "in" / "test.md").write_text(
            """---
theme:
  withcover: true
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_uses_top_level_withcover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "in" / "test.md").write_text(
            """---
withcover: true
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_single_file_frontmatter_overrides_frontmatter_yaml(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "frontmatter.yaml").write_text(
            """theme:
  withcover: false
""",
            encoding="utf-8",
        )
        (cover_workspace / "in" / "test.md").write_text(
            """---
theme:
  withcover: true
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_single_file_frontmatter_overrides_workspace_disables(
        self, mock_convert, cover_workspace
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "frontmatter.yaml").write_text(
            """disables:
  - cover
""",
            encoding="utf-8",
        )
        (cover_workspace / "in" / "test.md").write_text(
            """---
theme:
  withcover: true
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_reads_current_file_when_not_in_input_dir(
        self, mock_convert, cover_workspace, monkeypatch
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        subdir = cover_workspace / "notes"
        subdir.mkdir()
        file_path = subdir / "test.md"
        file_path.write_text(
            """---
theme:
  withcover: true
---
# Test
""",
            encoding="utf-8",
        )
        monkeypatch.chdir(subdir)

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_single_file_frontmatter_false_overrides_frontmatter_yaml_true(
        self, mock_convert, cover_workspace
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "frontmatter.yaml").write_text(
            """theme:
  withcover: true
""",
            encoding="utf-8",
        )
        (cover_workspace / "in" / "test.md").write_text(
            """---
theme:
  withcover: false
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is True

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_disables_cover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=True)
        (cover_workspace / "in" / "test.md").write_text(
            """---
theme:
  withcover: true
disables:
  - cover
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is True

    @patch("mark2pdf.conversion.convert_file")
    def test_run_conversion_cli_with_cover_overrides_file_disables(
        self, mock_convert, cover_workspace
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "in" / "test.md").write_text(
            """---
disables:
  - cover
---
# Test
""",
            encoding="utf-8",
        )

        result = run_conversion(filename="test.md", workspace_dir=cover_workspace, no_cover=False)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_directory")
    def test_run_directory_conversion_uses_index_withcover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        docs_dir = cover_workspace / "in" / "docs"
        docs_dir.mkdir()
        (docs_dir / "index.md").write_text(
            """---
theme:
  withcover: true
---
# Docs
""",
            encoding="utf-8",
        )

        result = run_directory_conversion(directory="docs", workspace_dir=cover_workspace)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_directory")
    def test_run_directory_conversion_cli_no_cover_overrides_index_withcover(
        self, mock_convert, cover_workspace
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=True)
        docs_dir = cover_workspace / "in" / "docs"
        docs_dir.mkdir()
        (docs_dir / "index.md").write_text(
            """---
theme:
  withcover: true
---
# Docs
""",
            encoding="utf-8",
        )

        result = run_directory_conversion(
            directory="docs", workspace_dir=cover_workspace, no_cover=True
        )

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is True

    @patch("mark2pdf.conversion.convert_file")
    def test_run_batch_conversion_uses_options_cover(self, mock_convert, cover_workspace):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=True)
        (cover_workspace / "in" / "batch.md").write_text("# Batch", encoding="utf-8")

        result = run_batch_conversion(directory=".", workspace_dir=cover_workspace, jobs=1)

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False

    @patch("mark2pdf.conversion.convert_file")
    def test_run_batch_conversion_cli_with_cover_overrides_workspace_disables(
        self, mock_convert, cover_workspace
    ):
        mock_convert.return_value = True
        write_config(cover_workspace, withcover=False)
        (cover_workspace / "frontmatter.yaml").write_text(
            """disables:
  - cover
""",
            encoding="utf-8",
        )
        (cover_workspace / "in" / "batch.md").write_text("# Batch", encoding="utf-8")

        result = run_batch_conversion(
            directory=".", workspace_dir=cover_workspace, jobs=1, no_cover=False
        )

        assert result is True
        options = mock_convert.call_args[1]["options"]
        assert options.no_cover is False
