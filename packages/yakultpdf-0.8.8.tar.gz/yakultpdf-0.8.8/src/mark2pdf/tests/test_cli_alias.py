
import sys
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

# Ensure src is in path to import mark2pdf
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from mark2pdf.cli import main


class TestAliasArgs:

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_alias_args_passed_correctly(self, mock_check, mock_run):
        """测试别名参数正确传递"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            # 使用 --no-cover 和 --notoc
            result = runner.invoke(main, ["convert", "test.md", "--no-cover", "--notoc"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args[1]
            # 显式传 --no-cover 时 no_cover 应为 True
            assert call_kwargs["no_cover"] is True
            assert call_kwargs["no_toc"] is True

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_cover_flag_omitted_passes_none(self, mock_check, mock_run):
        """未传封面参数时应保留三态 None"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md"])
            assert result.exit_code == 0
            call_kwargs = mock_run.call_args[1]
            assert call_kwargs["no_cover"] is None

    @patch("mark2pdf.commands.convert.run_conversion")
    @patch("mark2pdf.commands.convert.check_pandoc_typst")
    def test_with_cover_flag(self, mock_check, mock_run):
        """测试 --with-cover 启用封面"""
        mock_run.return_value = True
        runner = CliRunner()
        with runner.isolated_filesystem():
            Path("test.md").write_text("# Test")
            result = runner.invoke(main, ["convert", "test.md", "--with-cover"])
            assert result.exit_code == 0
            mock_run.assert_called_once()
            call_kwargs = mock_run.call_args[1]
            # --with-cover 时 no_cover 应为 False
            assert call_kwargs["no_cover"] is False
