// report-lib.typ - Report 主库文件
// 提供 A4 横向、两栏等宽布局的文档模板
// 注意：由于 columns() 内不允许 pagebreak()，整页元素（fullimage、pagebg）不适用

// 全宽内容：延展到两栏之外
#let fullwidth(body) = {
  block(
    width: 100% + 1cm,
    inset: (x: -0.5cm, y: 0pt),
    body,
  )
}

// Action 引用：无底色，浅边框
#let action-quote(body) = {
  block(
    above: 2em,
    below: 2em,
    fill: none,
    stroke: 0.5pt + color.rgb("#B8E0E0"),
    breakable: true,
    radius: 0.5em,
    inset: 2em,
    body,
  )
}

// 主 report 函数
#let report(
  title: [Report title],
  author: [Author],
  description: [Report description],
  edition: none,
  publication-info: none,
  date: none,
  logo: none,
  font: none,
  titlefont: none,
  hero-image: none,
  disable-indent: false,
  toc: false,
  toc-depth: 3,
  headerleft: none,
  headerright: none,
  footerleft: none,
  footerright: none,
  watermark: none,
  overview-fill: none,
  disable-header: false,
  disable-pagenumber: false,
  body,
) = {
  // Set document metadata.
  set document(title: title, description: description)

  // A4 横向页面设置
  set page(
    width: 297mm,
    height: 210mm,
    margin: (left: 2cm, top: 2.5cm, right: 2cm, bottom: 2cm),
    fill: white,
    background: watermark,
    header: if disable-header {
      none
    } else {
      box(width: 100%, {
        if headerleft != none {
          text(size: 0.7em, headerleft)
        }
        h(1fr)
        if headerright != none {
          text(size: 0.7em, headerright)
        } else {
          text(size: 0.7em, title)
        }
      })
    },
    footer: context {
      if counter(page).at(here()).first() > 0 {
        set text(size: 7pt)
        box(width: 100%, {
          move(dy: 0.3cm, {
            grid(
              columns: (1fr, auto, 1fr),
              column-gutter: 0pt,
              align: (left, center, right),
              if footerleft != none {
                footerleft
              } else { [] },
              if not disable-pagenumber {
                counter(page).display("1")
              } else { [] },
              if footerright != none {
                footerright
              } else { [] },
            )
          })
        })
      }
    },
  )

  // Set the body font.
  set text(
    lang: "zh",
    font: font,
    size: 11pt,
    alternates: false,
  )

  // Configure headings.
  show heading: set text(font: font, weight: "semibold", fill: color.rgb("#00008B"))
  show heading.where(level: 1): it => {
    block(above: 2.0em, below: 1.5em, width: 100%, align(left, text(size: 18pt, it.body)))
  }
  show heading.where(level: 2): it => {
    block(above: 1.8em, below: 1.2em, width: 100%, align(left, text(size: 15pt, it.body)))
  }
  show heading.where(level: 3): it => {
    block(above: 1.5em, below: 1.0em, width: 100%, align(left, text(size: 13pt, it.body)))
  }

  show heading.where(level: 4): it => {
    block(above: 1.5em, below: 1.0em, width: 100%, align(left, text(size: 13pt, it.body)))
  }

  set par(
    first-line-indent: if (disable-indent) { 0em } else { (amount: 1.5em, all: true) },
    leading: 1.15em,
    justify: true,
    spacing: 2.5em,
  )

  show quote: it => {
    set par(
      leading: 1.2em,
      first-line-indent: if (disable-indent) { 0em } else { (amount: 2em, all: true) },
    )

    block(
      width: 100%,
      above: 2em,
      below: 2em,
      fill: color.rgb("#E4F6F6"),
      breakable: true,
      radius: 0.5em,
      inset: 2em,
      it.body,
    )
  }

  show <quote>: it => {
    set par(
      leading: 1.2em,
      first-line-indent: if (disable-indent) { 0em } else { (amount: 2em, all: true) },
    )

    block(
      width: 100%,
      above: 2em,
      below: 2em,
      fill: color.rgb("#E4F6F6"),
      breakable: true,
      radius: 0.5em,
      inset: 2em,
      it.body,
    )
  }

  set list(
    indent: 2em,
    body-indent: 1em,
  )
  set enum(
    indent: 2em,
    body-indent: 1em,
  )

  show table: set text(size: 10pt)
  show figure.caption: it => {
    text(size: 0.8em, it.body)
  }

  set image(width: 100%, fit: "contain")

  // Code snippets:
  set raw(theme: none)
  show raw: set block(inset: (left: 1em, top: 0.5em, right: 0.5em, bottom: 0.5em))
  show raw: set text(font: font, fill: color.rgb("#116611"), size: 8pt)

  // Footnote formatting
  set footnote.entry(indent: 0.5em)
  show footnote.entry: {
    set text(size: 10pt)
    set block(width: 50%)
  }

  // URLs
  show link: underline

  // Custom blocks - 全页块用 colbreak 代替 pagebreak 在 columns 内
  show <overview>: it => {
    // 在两栏布局中，overview 改为普通块样式
    block(
      width: 100%,
      fill: if overview-fill == "lightblue" { color.rgb("#E4F6F6") } else if overview-fill != none {
        color.rgb(overview-fill)
      } else { color.rgb("#FFF5F5") },
      inset: 2em,
      radius: 0.5em,
      it.body,
    )
  }

  show <ending>: it => {
    v(2em)
    align(center, it.body)
  }

  show <fullwidth>: it => fullwidth(it.body)

  show <action>: it => {
    show quote: q => action-quote(q.body)
    it.body
  }

  // Two-column layout for main content
  columns(2, gutter: 3cm, body)
}
