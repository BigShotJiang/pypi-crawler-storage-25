// report-backcover-lib.typ - Report 封底库文件
// 提供封底页的创建函数（A4 横向）

#let backcoverpage(
  title: none,
  author: none,
  edition: none,
  description: none,
  publication-info: none,
  date: none,
  logo: none,
) = {
  set page(
    width: 297mm,  // A4 landscape
    height: 210mm,
    fill: color.rgb(242, 242, 242),
  )
  set text(size: 0.7em)
  set par(first-line-indent: 0em)

  v(1fr)
  align(center, [
    #block(width: 3cm, logo)
    #v(1em)
    #edition \
    #publication-info \
    #date
  ])
}
