#import "./report-lib.typ": report
#import "./report-cover-lib.typ": coverpage
#import "./report-backcover-lib.typ": backcoverpage

// Markdown 的 --- 转换为简单的分栏符，不画线
#let horizontalrule = {
  colbreak()
}

// ==========================MAIN CONF=================================
#let conf(
  title: none,
  description: none,
  author: none,
  date: none,
  heroimage: none,
  edition: none,
  publication-info: none,
  sourcelink: none,
  tyfont: none,
  tyfont_title: none,
  disables: (),
  toc-depth: 3,
  logo: none,
  headerleft: none,
  headerright: none,
  footerleft: none,
  footerright: none,
  watermark: none,
  overview-fill: none,
  coverbg: none,
  doc,
) = {
  let disabled(name) = disables.contains(name)
  let disable_cover = disabled("cover")
  let disable_backcover = disabled("backcover")
  let disable_toc = disabled("toc")
  let disable_indent = disabled("indent")
  let disable_pagenumber = disabled("pagenumber")
  let disable_header = disabled("header")

  let font = if tyfont != none {
    (tyfont, "Helvetica", "LXGW Wenkai")
  } else {
    ("Helvetica", "LXGW Wenkai")
  }
  let titlefont = if tyfont_title != none {
    (tyfont_title, "Source Han Sans SC", "Source Han Sans TC", "Source Han Sans")
  } else {
    ("Source Han Sans SC", "Source Han Sans TC", "Source Han Sans", "PingFang SC", "Noto Sans CJK SC", "Noto Sans CJK TC", "SimHei", "Heiti SC")
  }

  set text(
    lang: "zh",
    font: font,
    size: 11pt,
    alternates: false,
  )

  set par(
    first-line-indent: if disable_indent { 0em } else { (amount: 1.5em, all: true) },
    leading: 1.15em,
    justify: true,
    spacing: 1.5em,
  )

  // 调用封面页
  if not disable_cover {
    coverpage(
      title: title,
      author: author,
      description: description,
      hero-image: heroimage,
      edition: edition,
      publication-info: publication-info,
      date: date,
      logo: logo,
      font: font,
      titlefont: titlefont,
      coverbg: coverbg,
    )
  }

  // TOC 页（两栏布局）
  if not disable_toc and toc-depth > 0 {
    set page(
      width: 297mm,
      height: 210mm,
      margin: (left: 2cm, top: 3.5cm, right: 2cm, bottom: 2cm),
      fill: color.rgb(249, 249, 249),
    )
    set outline.entry(fill: none)

    // 两栏目录
    columns(2, gutter: 3cm, {
      block(above: 3em, below: 2em, text(size: 18pt, weight: "bold", "目录"))
      outline(title: none, depth: toc-depth)

      if sourcelink != none {
        v(1fr)
        text(size: 0.7em, sourcelink)
      }
    })
    // 使用 colbreak 结束两栏布局
    colbreak()
  }

  // 正文（两栏布局）
  report(
    title: [#title],
    author: [#author],
    description: [#description],
    edition: [#edition],
    date: [#date],
    hero-image: heroimage,
    publication-info: [#publication-info],
    font: font,
    titlefont: titlefont,
    disable-indent: disable_indent,
    headerleft: headerleft,
    headerright: headerright,
    footerleft: footerleft,
    footerright: footerright,
    watermark: watermark,
    overview-fill: overview-fill,
    disable-header: disable_header,
    disable-pagenumber: disable_pagenumber,
    doc
  )

  // 调用封底页
  if not disable_cover and not disable_backcover {
    backcoverpage(
      title: title,
      author: author,
      description: description,
      edition: edition,
      publication-info: publication-info,
      date: date,
      logo: logo,
    )
  }
}

// ========================PANDOC TEMPLATE=============================
#show: doc => conf(
$if(title)$
title: [$title$],
$endif$
$if(description)$
description: [$description$],
$endif$
$if(author)$
author: [$author$],
$endif$
$if(date)$
date: [$date$],
$endif$
$if(heroimage)$
heroimage: (
  image: [#image("$heroimage.image$".replace("\_", "_"))],
  caption: [$heroimage.caption$],
),
$endif$
$if(pubinfo.logo)$
logo: [#image("$pubinfo.logo$".replace("\_", "_"))],
$endif$
$if(pubinfo.edition)$
edition: [$pubinfo.edition$],
$endif$
$if(pubinfo.info)$
publication-info: [$pubinfo.info$],
$endif$
$if(disables)$
disables: ($for(disables)$"$disables$"$sep$, $endfor$),
$endif$
$if(toc-depth)$
toc-depth: $toc-depth$,
$endif$
$if(sourcelink)$
sourcelink: [$sourcelink$],
$endif$
$if(headerfooter.headerleft)$
headerleft: [$headerfooter.headerleft$],
$endif$
$if(headerfooter.headerright)$
headerright: [$headerfooter.headerright$],
$endif$
$if(headerfooter.footerleft)$
footerleft: [$headerfooter.footerleft$],
$endif$
$if(headerfooter.footerright)$
footerright: [$headerfooter.footerright$],
$endif$
$if(pubinfo.watermark)$
watermark: rotate(45deg, text(size: 60pt, fill: color.rgb("#EEEEEE"), weight: "bold", "$pubinfo.watermark$")),
$endif$
$if(theme.overview-fill)$
overview-fill: "$theme.overview-fill$",
$endif$
$if(theme.coverbg)$
coverbg: "$theme.coverbg$".replace("\_", "_"),
$else$
$if(coverbg)$
coverbg: "$coverbg$".replace("\_", "_"),
$endif$
$endif$
$if(theme.font)$
tyfont: "$theme.font$",
$endif$
$if(theme.titlefont)$
tyfont_title: "$theme.titlefont$",
$endif$
doc,
)

$body$
