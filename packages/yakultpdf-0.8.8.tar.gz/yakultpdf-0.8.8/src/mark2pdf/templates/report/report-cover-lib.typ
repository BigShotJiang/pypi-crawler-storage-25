// report-cover-lib.typ - Report 封面库文件
// 简洁报告风封面，适配 A4 横向布局
// 版式：顶部标题+描述（居中，带底色），中部 Hero Image，底部底色条+版本信息+Logo

#let covertitle(
  title: none,
  titlefont: none,
) = {
  set text(font: titlefont, size: 28pt, tracking: -1pt, weight: "semibold", fill: color.rgb("#00008B"))
  block(
    width: 100%,
    par(
      leading: 0.5em,
      first-line-indent: 0em,
      align(center, text(title)),
    ),
  )
}

#let coverpage(
  title: none,
  author: none,
  edition: none,
  hero-image: none,
  description: none,
  publication-info: none,
  date: none,
  logo: none,
  font: none,
  titlefont: none,
  coverbg: none,
) = {
  set page(
    width: 297mm,  // A4 landscape
    height: 210mm,
    margin: (left: 2cm, top: 3.5cm, right: 2cm, bottom: 2cm),
    header: none,
    background: if coverbg != none {
      image(coverbg, width: 100%, height: 100%, fit: "cover")
    } else {
      none
    },
  )

  set text(
    lang: "zh",
    font: font,
    size: 12pt,
    alternates: false,
  )

  // 顶部：标题和 Description（居中，带底色遮罩）
  v(0.5cm)
  place(top + center, {
    rect(
      fill: color.rgb(255, 255, 255, 90%),
      inset: (x: 2cm, y: 0.5em),
      radius: 0.5em,
      align(center, [
        #set text(font: titlefont, size: 28pt, tracking: -1pt, weight: "semibold", fill: color.rgb("#00008B"))
        #title
        #if description != none {
          v(1em)
          text(size: 14pt, description)
        }
      ])
    )
  })

  v(1em)

  // 中部：Hero Image（横向适配）
  if hero-image != none {
    v(0.5fr)
    align(center + horizon, {
      set image(width: 80%)
      hero-image.image
    })
    v(0.3fr)
  } else {
    v(1fr)
  }

  // 底部：版本信息 + Logo
  place(bottom, {
    grid(
      columns: (1fr, auto),
      gutter: 2em,
      align: (center, center),
      {
        if edition != none {
          text(size: 14pt, weight: "bold", edition)
          linebreak()
        }
        if publication-info != none {
          publication-info
        }
      },
      if logo != none {
        block(width: 4cm, logo)
      },
    )
  })
}
