# Engineering roadmap

Phased plan for evolving **power-hmc-mcp** into a durable IBM Power MCP standard. Items marked **[PLACEHOLDER]** ship scaffolding without live HMC mutations yet. Items marked **[RISK]** need IBM/HMC-specific validation.

---

## Phase A — Foundation (complete)

Released **[v0.1.0](https://github.com/TylrDn/power-hmc-mcp-server/releases/tag/v0.1.0)** (2026-05-17). Phase A evaluation exited 2026-05-18; subsequent work tagged `v0.2.0-b1` (B1), `v0.3.0-b2`–`v0.3.2-b2` (B2 scaffolding).

- Centralized HMC route builders (`routes.py`) with tests.
- HTTP policy helpers (`http_policy.py`) and unified authenticated request pipeline (`HmcSession.request` in `session.py`).
- Observability: correlation IDs, structured logging (`HMC_LOG_JSON`), MCP + HMC lifecycle events, canonical `write_audit` event.
- MCP tools wrapped with `mcp_tool_call` for consistent tracing.
- **Structural write-safety boundary** (`tools/write.py`): `WriteAuthorization` capability token, `@mark_write_tool` registration marker, `run_write_tool` as the single issuer + audit emitter; `HmcClient` write methods require the token (no `execute: bool` fallback).
- Documentation set: [`README`](README.md), [`docs/glossary.md`](docs/glossary.md), [`docs/architecture.md`](docs/architecture.md), [`docs/transports.md`](docs/transports.md), [`docs/operations.md`](docs/operations.md), [`docs/agent-guide.md`](docs/agent-guide.md).

## Pre-Phase B — Gap closures (complete)

- [x] `log_logon_end` / `log_logoff_end` structured lifecycle events in `observability.py`.
- [x] `test_settings_requires_hmc_host` env isolation (`_env_file=None`).
- [x] Golden output fixture snapshots for all 8 read tools (`tests/fixtures/<tool>.json`).
- [x] Parametrized contract tests (`tests/test_contracts.py`) — schema drift alarm for agent consumers.
- [x] `_pcm_cpu_aggregates()` helper for CPU utilisation aggregates from metric JSON samples.
- [x] `get_capacity_full()` stub with size guard (`HMC_MAX_METRICS_BYTES`, `HmcResponseTooLargeError`).
- [x] Demo mode (`HMC_DEMO_MODE=true`): fixture-backed read tools, `executed=false/demo=true` writes, no HMC connection.
- [x] `suggested_next_step` field on all write tool response envelopes (denied / dry-run / authorized).

## Phase A evaluation (complete — gate exited 2026-05-18)

Team review of the Phase A release before Phase B implementation landed on `main`. Checklist and exit criteria: [`docs/milestone-evaluation.md`](docs/milestone-evaluation.md). Phase B1 and the bulk of B2 scaffolding have landed since exit; only firmware-capture work remains open under B2.

- [x] Read tools exercised against lab HMC or agreed demo fixtures (demo-mode fixtures bundled; lab capture pending under B2)
- [x] Agent JSON contracts reviewed with consumers (8 golden contract fixtures + `tests/test_contracts.py`)
- [x] Operations / security walkthrough complete ([`docs/operations.md`](docs/operations.md), [`SECURITY.md`](SECURITY.md))
- [x] B1 vs B2 priorities agreed; lab HMC access plan confirmed for the remaining B2 captures
- [x] Recorded **“Phase A evaluation complete — Phase B approved”**

## Phase B — Read-path excellence (in progress; B1 complete, B2 firmware captures pending)

Phase B is split by dependency: **B1** needs no live HMC; **B2** needs lab HMC or IBM simulator.
B1 landed in `v0.2.0-b1`; B2 scaffolding landed across `v0.3.0-b2`–`v0.3.2-b2`. Remaining
open B2 items require firmware capture against a real HMC.

**Scheduling note.** B2 firmware captures are expected to land closer to first production deployment. Non-mutating work in later phases (D / E / F / G — transport, observability export, agent ergonomics, orchestration) may proceed in parallel with B2 capture, as long as firmware-gated behaviours remain `[ASSUMED]` / `[RISK]` / `[PLACEHOLDER]` and no real writes are enabled. The gate "no `[ASSUMED]` → `[VALIDATED]` flips, no real POSTs without a compatibility row" stays exactly as encoded in [`CONTRIBUTING.md`](CONTRIBUTING.md#firmware-validation-rules).

### B1 — Complete (`v0.2.0-b1`)

- ~~`_log_logon_end` observability helper in `session.py`~~ (pre-Phase C gap closure).
- ~~`test_settings_requires_hmc_host` env isolation (`Settings(_env_file=None)`)~~ (pre-Phase C gap closure).
- ~~Tool output contract snapshots — one golden JSON fixture per read tool (**8 total**):
  `list_managed_systems`, `get_managed_system`, `list_lpars`, `get_lpar_status`,
  `get_lpar`, `list_partition_profiles`, `get_capacity`, `health_check`.
  Regression test compares normalized tool output to fixture; fails on schema drift
  (first-line defense for agent consumers).~~ Landed with `tests/test_contracts.py`.
- ~~Extra LPAR status normalization fixtures for edge-case firmware states.~~ Landed in `b2-1` (`normalize_lpar_state` + `canonical_state` field; 25 tests).
- ~~Expand PCM summary aggregates in `normalize.py` (min/max/avg CPU% beyond counts).~~ Landed as `_pcm_cpu_aggregates` helper in `hmc_client.py` (reads real IBM `serverUtil.processor.utilizedProcUnits` field; v1.1.0 deductIdle gated).
- ~~`mode='full'` unblock scaffolding: design `metrics_href` fetch + size guard API.~~ Landed in `b2-7a/7b` (`get_capacity_full` stub, `HMC_MAX_METRICS_BYTES`, `HmcResponseTooLargeError`); real `metrics_href` GET wiring tracked under B2 below.

### B2 — Firmware-gated (requires lab HMC or IBM simulator)

Scaffolding for B2-1/3/4/5/6/7a/7b has landed across `v0.3.0-b2`–`v0.3.2-b2`. The
items below are the remaining firmware-capture deliverables.

**Schema-level (now IBM-doc validated — no firmware capture required):**

These were previously tracked as `[RISK]` against IBM documentation; cross-checking against the official Power10/11 HMC REST docs has landed them as schema-aligned. They no longer need a firmware capture to lift to `[VALIDATED]` *at the schema layer*; per-firmware behavioural rows still apply where listed below.

- URL routes for `ManagedSystem`, `LogicalPartition`, `LogicalPartitionProfile`, and PCM `ProcessedMetrics` — `[VALIDATED — IBM Docs Power10/11]`. See [`docs/hmc-compatibility.md` URL Routes — IBM Doc Alignment](docs/hmc-compatibility.md#url-routes--ibm-doc-alignment).
- LPAR quick-property names (`PartitionState`, `PartitionName`, `PartitionID`, `RMCState`) — `[VALIDATED — IBM Docs Power9/10/11]`.
- PCM metric JSON field names (`utilizedProcUnits`, `utilizedProcUnitsDeductIdle`, `totalProcUnits`, `availableProcUnits`) — `[VALIDATED — IBM Docs Power9/10/11]`.
- `utilizedProcUnitsDeductIdle` `Since: version 1_1_0` gating — IBM-doc-documented; selected from `utilInfo.version` in the actual response, not from `HMC_API_VERSION_HINT`.

**Behaviour-level (still firmware-gated — capture required):**

- Confirm LPAR status normalization against diverse firmware levels — fixtures landed (`b2-1`); real-firmware confirmation of the enumerated `PartitionState` strings still pending **[RISK]**.
- Tune retry defaults using traces from busy HMCs — config table audited (`b2-2`); trace-driven tuning still pending **[RISK]**.
- Validate HMC echoes correlation header — primary header is `X-Transaction-ID` (IBM HMC REST spec), fallback `X-Client-Correlator` (V8+). Outbound and echo defaults are symmetric since `v0.3.1-b2` / `v0.3.2-b2`. Per-firmware echo behaviour still `[ASSUMED]` until at least one capture row lands in [`docs/hmc-compatibility.md` Correlation Header Echo](docs/hmc-compatibility.md#correlation-header-echo) **[RISK]**.
- HMC session expiry under long agent workflows (401 re-auth across multi-step chains) — unit coverage landed in `b2-4` (`session_reauth` event, `HMC_MAX_REAUTH_ATTEMPTS`); multi-step end-to-end against real firmware still pending **[RISK]**.
- LPAR quick-property latency measurement — scaffolding landed in `b2-5` (`HmcClient.get_lpar_quick` stub, `HMC_PREFER_QUICK_PROPERTIES` feature flag default `false`, route builder). The composite `.../quick` URL is **not** in the IBM URL-model docs; its content-type and round-trip latency vs. full-UOM GET must be captured against firmware before the flag default can flip **[RISK/PLACEHOLDER]**.
- Document observed PCM Atom feed `rel` attribute values — foundation file [`docs/hmc-compatibility.md`](docs/hmc-compatibility.md) seeded; rows populated as captures land **[RISK]**.
- Fetch PCM metric JSON behind `metrics_href` with size guards + streaming policy — contract scaffold landed in `b2-7a/7b` (size guard, error type, xfail gate); real HTTP fetch wiring is still **[PLACEHOLDER]**.

### Phase B scope boundaries

| Item | Where | Why |
|------|-------|-----|
| `_log_logon_end` | Pre-Phase C gap closure | Reviewer-facing hygiene on session extraction |
| `test_settings_requires_hmc_host` fix | Pre-Phase C gap closure | Last Phase A test gap; 109/109 CI |
| Tool output snapshots (8 fixtures) | Phase B1 | No HMC; protects agent JSON contracts |
| PCM aggregate expansion | Phase B1 | Code-only in `normalize.py` |
| Retry tuning, echo validation, session expiry | Phase B2 | Needs real firmware traces |
| Write execution (real POST bodies) | Phase C | Blocked on B2 validation |

## Phase C — Write-path execution

**Prerequisites (must land before the first real POST):**

- **Idempotency policy** decided — see [`docs/design/write-idempotency.md`](docs/design/write-idempotency.md). Client-side state check is the primary mechanism; HMC-side request token is an opt-in secondary layer. `WriteAuthorization` shape is preserved.
- **Threat model + RBAC matrix** drafted — see [`docs/design/threat-model.md`](docs/design/threat-model.md). Reprioritized from Phase H so the model is in place before mutations ship.

**Phase C deliverables:**

- **`HMC_WRITES_ENABLED` dual gate** — landed in `v0.6.0` (`config.py` +
  `guardrails.check_write_allowed()`). Live mutations require both
  `HMC_ENABLE_WRITE_TOOLS=true` and `HMC_WRITES_ENABLED=true`.
- **Phase C is blocked on Phase B2 firmware captures.** Real write POSTs and idempotency behaviour must not be treated as "done" based on IBM documentation alone — the URL **shape** (`/do/{OP}`) is IBM-doc-aligned, but the specific `{OP}` names and payload bodies require firmware capture to validate.
- **Planning, documentation, and non-mutating scaffolding for Phase C may land earlier** — e.g. idempotency design, threat-model / RBAC matrix drafts, approval-workflow stubs, audit-sink schema work — as long as no real POSTs are enabled and `HmcClient.start_lpar` / `stop_lpar` / `create_lpar_from_profile` continue to return `placeholder_execute_response(...)` on the authorized path.
- Replace `logical_partition_*_job_path` placeholders with IBM-validated paths AND JSON/XML bodies based on Power10/11 docs and lab HMC captures; promote the corresponding `[ASSUMPTION]` rows in [`docs/hmc-compatibility.md` Write Operation Paths](docs/hmc-compatibility.md#write-operation-paths) to `[VALIDATED vN]` per firmware. **[RISK]**
- Integration tests against lab HMC or simulator **[RISK]**.
- Enforce optional **production** refusal of write registration without extra confirmation flags.
- Approval workflow hooks (external ticket ID, dual-control) **[PLACEHOLDER]**.
- Implement idempotency per [`docs/design/write-idempotency.md`](docs/design/write-idempotency.md) (client-side state check for `start_lpar` / `stop_lpar`; request token for `create_lpar_from_profile`).
- **[RISK]** `create_lpar_from_profile` POST body schema varies by HMC firmware —
  track minimum/maximum tested firmware versions in a compatibility note once
  validated.
- Promote the `write_audit` log event to a persistent audit sink — the
  in-process schema is stable (`tool_name`, `operation`, `outcome`, `reason`,
  `execute_requested`, `correlation_id`); Phase E ships it via OpenTelemetry /
  log exporters. **[PLACEHOLDER]** for the sink wiring; the schema itself is
  no longer pending.
- Extend the authorized-path `write_audit` with the HMC echo correlation ID —
  **nearly unblocked**: outbound/echo header symmetry is fixed (`X-Transaction-ID`
  in `v0.3.1-b2` / `v0.3.2-b2`); only one firmware capture confirming echo
  behaviour remains. Today only `hmc_request_end` carries
  `hmc_echo_correlation_id`. **[PLACEHOLDER]**

## Phase D — Transport & deployment

May be implemented in parallel with B2 firmware capture, provided it does not change firmware-dependent behaviour or enable writes.

- ~~Multi-HMC Registry (`HMC_REGISTRY` JSON config, connection pool keyed by `(alias, mode)`).~~
  Landed (Phase D D5): `power_hmc_mcp.registry` (frozen `HmcEndpoint` dataclass +
  parser + `build_registry`), `power_hmc_mcp.pool.HmcClientPool` (sync + async,
  lazy, safe `close_all()`), every tool gains an optional `hmc_alias` parameter,
  `mcp_tool_call` propagates `hmc_alias` to start/end events. Single-HMC
  ergonomic preserved via `HMC_DEFAULT_ALIAS` and `single_client_resolver`.
- ~~Harden streamable HTTP deployment guides (reverse proxy samples, mTLS).~~
  Landed (Phase D D2): NGINX 1.27 + Envoy + docker-compose samples under
  `examples/deploy/`; session-affinity decision recorded at
  [`docs/design/http-session-affinity.md`](docs/design/http-session-affinity.md);
  bind-path smoke test pins env-var → `FastMCP.settings` propagation.
- ~~Health/readiness probes for HTTP mode~~ Landed (Phase D D3) via `HMC_MCP_HTTP_PROBES_PATH` (opt-in; collision-checked against `HMC_MCP_HTTP_PATH`).
- ~~Container images + Helm/Kubernetes examples~~ Landed (Phase D D4): multi-stage `Dockerfile`, `examples/deploy/helm/power-hmc-mcp/`, CI `docker-build` + `helm-lint` jobs.
- ~~**[PLACEHOLDER]** Async transport pair: introduce `asyncio.sleep` counterparts for
  the `# SYNC-ONLY` sites in `http_policy.py` (`retry_sleep`,
  `throttle_before_request`) and an `httpx.AsyncClient` pipeline alongside the
  existing sync client. Migrate together — do not swap the sleeps in isolation.~~
  Landed (Phase D D1): `retry_sleep_async` / `throttle_before_request_async`,
  `_assert_async_context`, `HmcAsyncSession`, `HmcAsyncClient`. Behind a
  Phase-D-internal seam — public MCP surface unchanged.

## Phase E — Observability export

May be implemented in parallel with B2 firmware capture, provided it does not change firmware-dependent behaviour or enable writes.

- [x] SLI definitions design doc — docs/design/sli-definitions.md
  (hmc_request_latency_p99, tool_error_rate, session_reauth_rate;
  thresholds [PROPOSED — adjust after lab capture])
- [x] OTEL wiring (E2) — telemetry_hook live export, hmc_alias closed
  on session_reauth and hmc_request_end, three SLI call sites active
- **[DEFERRED] Async MCP tool wiring (Phase D, D5.5).**
  `HmcClientPool.get_async()` exposes `HmcAsyncClient` per alias, but the
  public MCP tool path routes through the sync pool (D5) and the sync pool
  is sufficient for all current Phase E work. OTEL instrumentation (below)
  does not require async tool dispatch — OpenTelemetry spans propagate via
  `contextvars.Context` across both sync and async boundaries. D5.5 is
  deferred until there is a confirmed use case for concurrent multi-HMC
  fan-out within a single tool call (e.g. a scatter/gather read across
  two or more HMC aliases in parallel). Do not implement ahead of that
  requirement. Write tools stay sync-only regardless.
- Wire `telemetry_hook` to OpenTelemetry traces + metrics.
- Optional log shipping templates (Fluent Bit / Vector) — landed in `v0.6.0`
  (`integrations/fluent-bit/hmc-mcp.conf`, `integrations/vector/hmc-mcp.yaml`).
- ~~**[PLACEHOLDER]** W3C `traceparent` header propagation~~ — landed in `v0.6.0`
  (`inject_outbound_trace_headers` in `observability.py`; additive to
  `X-Transaction-ID`).
- `log_write_audit()` → `telemetry_hook` export — landed in `v0.6.0`.
- **[PLACEHOLDER]** Define three key SLIs before wiring telemetry: candidate set is
  `hmc_request_latency_p99`, `tool_error_rate`, `session_reauth_rate`. Agree on
  these first so Phase E instrumentation is purposeful.
- [x] Phase E stabilization — OTEL lifecycle hardened, cardinality reviewed, validation tests added

## Phase F — Agent ergonomics (complete)

- [x] Richer tool descriptions / schema constraints where MCP SDK allows.
- [x] Conversation-safe summaries for large list outputs (pagination policy).
- [x] Natural-language guardrail hints returned to agents on policy denial.

## Phase G — LangGraph / orchestration

May be implemented in parallel with B2 firmware capture, provided it does not change firmware-dependent behaviour or enable writes.

- ~~Working LangGraph graph invoking MCP stdio server (`integrations/langgraph/`).~~
  Landed in `v0.1.0a0` as a real subprocess + `mcp.ClientSession` loop closure.
- ~~Parallel HTTP transport example once client libs stabilize.~~ Landed in
  `v0.6.0` as `integrations/langgraph/example_list_lpars_http.py`.
- ~~CI job matrix smoke-testing optional `[langgraph]` extra.~~ Landed in
  `v0.6.0` via `.github/workflows/langgraph-smoke.yml` +
  `tests/integration/test_langgraph_stdio.py` (demo mode).

## Phase H — Security & compliance

Threat model and RBAC matrix were reprioritized to **Phase C prerequisites** — see
[`docs/design/threat-model.md`](docs/design/threat-model.md). Phase H scope is now
limited to formal external review and supply-chain hardening.

- ~~CI: `detect-secrets` workflow ([`.github/workflows/secret-scan.yml`](.github/workflows/secret-scan.yml)).~~
- ~~CI: `pip-audit` workflow ([`.github/workflows/audit.yml`](.github/workflows/audit.yml)).~~
- ~~[`SECURITY.md`](SECURITY.md) and [`CODE_OF_CONDUCT.md`](CODE_OF_CONDUCT.md).~~
- ~~PR template and issue templates (`.github/`).~~
- Formal external review of [`docs/design/threat-model.md`](docs/design/threat-model.md) and the populated RBAC matrix once firmware role behaviour is validated under Phase C.
- ~~Secrets via vault sidecars instead of env-only~~ — [`integrations/vault/`](integrations/vault/) Agent template + [Secrets management](docs/operations.md#secrets-management) runbook.
- ~~Signed releases + SBOM~~ — `release.yml` syft SBOM + cosign sign-blob + GitHub Release assets (PyPI OIDC attestations unchanged).

## Phase I — Release engineering

- ~~PyPI publish workflow (OIDC) — [`.github/workflows/release.yml`](.github/workflows/release.yml); configure [Trusted Publisher on PyPI](docs/release-engineering.md#pypi-trusted-publishing-oidc) before tagging.~~
- ~~Codecov coverage in CI — requires `CODECOV_TOKEN` secret ([setup](docs/release-engineering.md#codecov-codecov_token)).~~
- ~~Dependabot config (pip + github-actions + docker) — [`.github/dependabot.yml`](.github/dependabot.yml).~~
- ~~GitHub Environments documentation + `release.yml` environment stub — [GitHub Environments](docs/release-engineering.md#github-environments).~~
- ~~Release attestation verification runbook (PyPI + cosign + SBOM) — [Verifying Release Attestations](docs/release-engineering.md#verifying-release-attestations).~~
- ~~pip-audit CI coverage~~ — confirmed via [`.github/workflows/audit.yml`](.github/workflows/audit.yml) (Phase H); no `ci.yml` duplication.
- Versioning policy (semver for MCP contracts) — draft in [`docs/release-engineering.md`](docs/release-engineering.md#versioning-policy-draft).
- CHANGELOG discipline + migration guides for breaking tool schemas.

---

## Testing backlog

- ~~Contract tests for every route builder edge case (encoding, UUID variants).~~
  Extended in `v0.6.0` (`tests/test_routes.py` parametrized prefix checks).
- ~~**[PLACEHOLDER]** Smoke test for LangGraph stdio integration~~ — landed in
  `v0.6.0` as `tests/integration/test_langgraph_stdio.py` (demo mode).
- ~~Fault injection: 401 mid-sequence re-auth across a multi-step
  tool chain — verifies session recovery under realistic agent workload, not just
  single-request tests.~~ Unit coverage landed in B2-4 via
  `test_401_reauth_success_emits_session_reauth_event` and
  `test_401_reauth_failure_raises_and_emits_failure_event`; multi-step
  end-to-end validation still requires a live HMC capture (Phase B2 exit
  criteria).
- **[PLACEHOLDER]** Redaction property test: fuzz `logging_utils` with generated
  strings containing UUID-shaped and credential-shaped values.

## Documentation backlog

- ~~Agent caller guide — short doc for LangGraph / watsonx Orchestrate developers:
  how to connect, what correlation IDs to expect in logs, how to read dry-run vs
  execute responses.~~ Landed as [`docs/agent-guide.md`](docs/agent-guide.md).
- ~~Sample Claude Desktop + streamable HTTP configs side-by-side.~~ Covered in
  [`docs/transports.md`](docs/transports.md) and
  [`examples/claude_desktop_config.json`](examples/claude_desktop_config.json).
- ~~Operator runbook entries for common failure modes / HMC HTTP codes.~~
  Initial set in [`docs/operations.md` Common runbook entries](docs/operations.md#common-runbook-entries);
  expand as real-world failures surface.
- Path repair playbook — step-by-step for when IBM updates an HMC REST collection
  path: which file to diff (`routes.py`), how to find the IBM doc, how to verify
  with a fixture. **[PLACEHOLDER]**
- HMC firmware compatibility matrix — stub table tracking which behaviors are
  validated per firmware version. Grows as real testing happens.
  **In progress (B2-6):** foundation file [`docs/hmc-compatibility.md`](docs/hmc-compatibility.md)
  seeded with empty per-area tables; rows are populated as firmware captures
  land in subsequent Phase B2 PRs.
- ~~Threat model + RBAC matrix doc once Phase H lands.~~ Reprioritized as a Phase C prerequisite — draft in [`docs/design/threat-model.md`](docs/design/threat-model.md); RBAC matrix rows populated as Phase C firmware captures land.

## Assumptions & risks

- **[ASSUMPTION]** HMC REST XML/Atom shapes remain broadly stable; parsers must remain defensive.
- **[RISK]** Write endpoints vary by firmware — placeholders exist until validated per environment.
- **[RISK]** Aggressive retries can amplify incident load — defaults stay conservative on writes.

## Phase J — Provider abstraction

- [x] `HmcProvider` protocol + `DemoProvider` + `PowerVSProvider` stub
- [x] `HMC_PROVIDER=hmc|demo|powervs` routing via `create_provider()`
- [x] `HMC_DEMO_MODE=true` backward compat (routes to `DemoProvider`)
- See [provider-architecture.md](docs/design/provider-architecture.md)

## Deferred / out of scope (for now)

- Full partition lifecycle coverage beyond start/stop/create scaffold.
- DR automation (cross-site replication) — not target domain.
- Non-Power platforms.

---

Maintainers: keep placeholders **explicit** in code comments and sync this file when phases complete.
