# Security Policy

**power-hmc-mcp-server** is an MCP server that integrates with IBM Power Hardware Management Console (HMC) REST APIs. It can expose read operations today and write operations to production IBM Power infrastructure once Phase C lands. Security reports are treated with high priority.

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| `main` (latest) | :white_check_mark: |
| Older tags / branches | :x: |

Only the latest `main` branch receives security fixes. Tagged releases on PyPI (Phase I) will be supported when published; until then, track `main`.

## Reporting a Vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

Report privately via [GitHub Private Vulnerability Reporting](https://github.com/TylrDn/power-hmc-mcp-server/security/advisories/new) (Repository **Settings → Security → Private vulnerability reporting**).

| Milestone | Target |
| --------- | ------ |
| Acknowledgment | Within **72 hours** |
| Remediation plan / fix | Within **14 days** for confirmed issues (complex issues may need a coordinated disclosure timeline) |

Include: affected component (MCP tool, `hmc_client`, transport), steps to reproduce, impact assessment, and any suggested mitigations. We may request additional information under a coordinated disclosure process.

## Scope

The following are **in scope** for this project:

| Area | Examples |
| ---- | -------- |
| **Credential exposure in logs** | Session tokens, passwords, or API keys leaking via structured logs despite `RedactingFilter` in `logging_utils.py`; bypass of redaction for `HMC_*` secrets |
| **SSRF via HMC client** | Forging or injecting URLs that cause the server to request unintended hosts or internal networks through `hmc_client.py` or `routes.py` builders |
| **Write-path bypass** | Circumventing `run_write_tool`, `@mark_write_tool` boot-time validation, or `WriteAuthorization` so mutations reach the HMC without guardrail approval |
| **Unsafe deserialization** | XML/Atom parsing in `hmc_xml.py` or response handling that enables entity expansion, code execution, or memory exhaustion from untrusted HMC payloads |

Configuration mistakes (e.g. `HMC_VERIFY_TLS=false` in production) are documented in [`docs/operations.md`](docs/operations.md) but may still be reported if the default or tooling enables unsafe posture without clear warning.

## Out of Scope

- Vulnerabilities in **IBM HMC firmware** or IBM-supplied REST behavior not under this repository’s control
- Issues requiring **physical access** to the HMC or data-center hardware
- Denial-of-service against the HMC itself through normal API rate limits (report to IBM if applicable)
- Social engineering of HMC operators

## Priority

This server is designed to operate against production IBM Power systems. Write tools (`start_lpar`, `stop_lpar`, `create_lpar_from_profile`) are gated by structural guardrails today and will perform real mutations in Phase C. Reports affecting authentication, authorization, logging redaction, or write-path integrity receive expedited review.

See [`docs/architecture.md`](docs/architecture.md#write-safety-model) for the current write-safety model and [`TODO.md`](TODO.md) Phase H for the security roadmap.
