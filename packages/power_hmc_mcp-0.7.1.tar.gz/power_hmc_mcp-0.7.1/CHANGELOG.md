# Changelog

All notable changes to this project are documented here.

## [Unreleased]

## [0.7.1] - 2026-05-23

### Fixed

- **Release workflow** — publish to PyPI before SBOM/cosign artifacts are written
  into `dist/`, so `gh-action-pypi-publish` no longer rejects
  `.sigstore.json` / SBOM files as invalid distributions.

## [0.7.0] - 2026-05-23

Phase J provider abstraction plus Phase H/I release-engineering items accumulated
since `v0.6.2`. Real HMC mutations remain blocked until B2 firmware captures land.

### Added

- **Provider abstraction (Phase J)** — `HmcProvider` protocol,
  `DemoProvider` (bundled fixtures), `PowerVSProvider` stub, and
  `create_provider()` factory keyed on `HMC_PROVIDER` (`hmc` | `demo` |
  `powervs`). `HMC_DEMO_MODE=true` with default `HMC_PROVIDER=hmc` still
  routes to `DemoProvider`. Design doc:
  [`docs/design/provider-architecture.md`](docs/design/provider-architecture.md).
- **Dependabot** — [`.github/dependabot.yml`](.github/dependabot.yml) for `pip`,
  `github-actions`, and `docker` ecosystems (weekly updates with dev-deps grouping).
- **GitHub Environments runbook** — manual approval gate docs in
  [`docs/release-engineering.md`](docs/release-engineering.md#github-environments).
- **Attestation verification runbook** — PyPI (`pypi-attestations`), cosign
  bundle, and SBOM inspection commands in
  [`docs/release-engineering.md`](docs/release-engineering.md#verifying-release-attestations).
- **pip-audit CI coverage** — confirmed via existing
  [`.github/workflows/audit.yml`](.github/workflows/audit.yml) on every push/PR
  to `main` plus weekly schedule; no duplicate step in `ci.yml`.
- **Vault Agent sidecar template** — [`integrations/vault/`](integrations/vault/)
  `agent.hcl` + README for injecting `HMC_PASSWORD` at runtime; Secrets
  management runbook in [`docs/operations.md`](docs/operations.md#secrets-management).
- **Release SBOM + cosign signing** — `release.yml` generates a CycloneDX SBOM
  via syft, cosign-signs wheel/sdist/SBOM artifacts, and attaches them to the
  GitHub Release (complements existing PyPI OIDC attestations).
- **Write-path threat surface** — new Phase C section in
  [`docs/design/threat-model.md`](docs/design/threat-model.md) covering job
  submission, polling, and idempotency threats with `[TBD — B2 capture]`
  firmware placeholders.

### Changed

- **Production environment gate** — `release.yml` `publish` job now targets
  the GitHub `production` environment (tag policy `v*.*.*`) for PyPI OIDC
  alignment with Trusted Publisher.

## [0.6.2] - 2026-05-23

Release engineering: CI gate before PyPI publish and expanded CODEOWNERS.
No behavioral changes.

### Added

- **Release CI gate** — `release.yml` runs ruff, mypy, and pytest before PyPI
  publish (`publish` job `needs: test`).
- **`observability.py` in CODEOWNERS** — audit/telemetry spine gated alongside
  guardrails and write tools.

## [0.6.1] - 2026-05-23

Housekeeping release: mypy strict mode, LangGraph dependency pin, and
CODEOWNERS for write-safety boundaries. No behavioral changes.

### Changed

- **mypy strict mode** — `strict = true` in `pyproject.toml`; redundant
  per-flag overrides removed. Catches type holes before Phase C write-path
  work lands.
- **LangGraph optional dep** — upper bound `langgraph>=0.2,<1` to prevent
  silent CI breakage from breaking minor releases.

### Added

- **`.github/CODEOWNERS`** — auto-review on PRs touching guardrails, write
  tools, routes, config, and HMC compatibility doc.

### Removed

- **`power-hmc-mcp-server.code-workspace`** from version control; added
  `*.code-workspace` to `.gitignore` (local workspace files stay untracked).

## [0.6.0] - 2026-05-23

No-HMC release: dual write guardrails, observability hardening, Phase C
scaffolding (stubs only), expanded tests, log-shipping templates, and LangGraph
HTTP example. Real HMC mutations remain blocked until B2 firmware captures land.

### Added

- **`HMC_WRITES_ENABLED` dual gate** — live write mutations require both
  `HMC_ENABLE_WRITE_TOOLS=true` and `HMC_WRITES_ENABLED=true`.
- **W3C `traceparent` injection** — additive to IBM `X-Transaction-ID` on
  outbound HMC requests when an OpenTelemetry span is active.
- **`X-Audit-Memento` header** on PUT/POST requests ([ASSUMPTION] value format).
- **`log_write_audit()` → `telemetry_hook`** export seam for OTLP sinks.
- **Phase C scaffolding** — `logical_partition_jobs_path`,
  `logical_partition_job_status_path`, `execute_job()`, `poll_job_status()`
  stubs (no real POST yet).
- **Log shipping templates** — Fluent Bit and Vector starter configs under
  `integrations/`.
- **LangGraph HTTP example** — `integrations/langgraph/example_list_lpars_http.py`.
- **Integration smoke test** — `tests/integration/test_langgraph_stdio.py` plus
  `.github/workflows/langgraph-smoke.yml`.
- **Hypothesis property tests** for `normalize_lpar_state()`.
- **B2 capture checklist** in `docs/hmc-compatibility.md`.

### Changed

- **Breaking — default HMC port** — `HMC_PORT` default is now `443` (IBM docs
  for 7063-CR2 on V10/V11). Legacy V8/V9 appliances may still require `12443`;
  set `HMC_PORT=12443` explicitly when connecting to older firmware.

#### Migration — default port

```text
If your HMC still listens on 12443 (common on V8/V9 era appliances):

  HMC_PORT=12443

V10/V11 CR2 appliances using the IBM-documented REST port need no change after
upgrade if they already use 443.
```

## [0.5.0b1] - 2026-05-20

### Added

- **Agent ergonomics (Phase F)**: richer MCP tool descriptions and parameter
  schema hints (`Annotated` + `Field`); paginated list envelopes via
  `wrap_list_response()`; reason-specific write denial metadata
  (`guardrail_outcome`, `denial_reason_code`, `suggested_next_step`).

### Changed

- **Breaking — list tool MCP response shape**: `list_managed_systems`,
  `list_lpars`, and `list_partition_profiles` now return a dict envelope
  (`items` + `summary`) instead of a bare JSON array. HmcClient shapes and
  `tests/test_contracts.py` fixtures are unchanged; only the MCP tool surface
  changed.

#### Migration — list tools (agent consumers)

```text
Old: result[0]["name"]
New: result["items"][0]["name"]

Old: len(result)
New: result["summary"]["total_count"]

Pagination: when result["summary"]["truncated"] is true, pass
offset=result["summary"]["next_offset"] on the next call (with the same limit).

Ordering: items preserve HMC Atom feed order for the duration of one call.
Re-fetch if the inventory may have changed between paginated requests.
```

See [README: Agent-safe output behavior](README.md#agent-safe-output-behavior)
and [agent guide: list envelopes and pagination](docs/agent-guide.md#list-envelopes-and-pagination).

## [0.4.0b1] - 2026-05-20

Phase D — Transport & deployment (D1–D6).

### Added

- **CI matrix expansion (Phase D, D6)**: `ci.yml` `test` job grows a
  second matrix axis `extras = [dev, dev,langgraph]` on top of the
  existing Python `[3.11, 3.12]` axis (4 legs total) so the optional
  `[langgraph]` extra is regression-tested on every push; pre-commit
  and Codecov upload still run on the `dev` baseline only to keep CI
  fast and Codecov reports unique. New `async-pair` job re-runs only
  the asyncio test subset (`test_http_policy_async.py`,
  `test_session_async.py`, `test_hmc_client_async.py`, `test_pool.py`)
  with `-p no:cacheprovider` to surface event-loop regressions that
  the broad `test` job might mask. `docker-build` and `helm-lint` jobs
  collapse into a single `docker-helm` job (same smoke-test contract
  for the multi-stage image and the same chart-template / kubeconform
  validation, just one job for easier branch-protection setup). Wheel
  package scope verified unchanged
  (`[tool.hatch.build.targets.wheel] packages = ["src/power_hmc_mcp"]`)
  — examples/, tests/, top-level docs are never shipped in the wheel.
  Build matrix and required-status-check guidance documented in
  `docs/release-engineering.md`.
- **Multi-HMC registry (Phase D, D5)**: opt-in `HMC_REGISTRY` JSON env
  var lets a single `power-hmc-mcp` process route tool calls to multiple
  HMCs. New `power_hmc_mcp.registry` module (frozen `HmcEndpoint`
  dataclass + parser + `build_registry()`) and `power_hmc_mcp.pool`
  module (`HmcClientPool` keyed by `(alias, mode)`, lazy construction,
  safe `close_all()`); `HMC_DEFAULT_ALIAS` (default `"default"`) names
  the implicit endpoint built from `HMC_HOST` / `HMC_USERNAME` /
  `HMC_PASSWORD`; alias names normalised to lowercase and constrained to
  `[a-z0-9_-]`. Every MCP tool gains an optional `hmc_alias: str | None
  = None` parameter; alias resolution happens via a `ClientResolver =
  Callable[[str | None], HmcClient]` so tools work uniformly under both
  single-HMC (`HmcClient` wrapped with `single_client_resolver`) and
  multi-HMC (`HmcClientPool`) deployments. `mcp_tool_call` start/end
  events now carry `hmc_alias` whenever non-`None` (single-HMC callers
  see no extra log field). Bootstrap rejects collisions between the
  default alias and any registry entry. **No public behaviour change
  for existing single-HMC deployments** — the registry surface is
  purely additive.
- **Container & Kubernetes deployment (Phase D, D4)**: multi-stage
  `Dockerfile` (`python:3.12-slim-bookworm`, non-root UID 10001, `tini`
  PID 1, default streamable-HTTP listener on port 8000); `.dockerignore`
  to keep the build context lean; Helm chart at
  `examples/deploy/helm/power-hmc-mcp/` (Deployment + Service +
  optional Ingress + chart-managed Secret as a smoke-test fallback)
  with `livenessProbe`/`readinessProbe` wired to the D3 HTTP probes
  when `mcp.http.probesPath` is set, falling back to TCP-socket checks
  otherwise; CI gains `docker-build` (build + demo-mode boot smoke
  test) and `helm-lint` (`helm lint`, three `helm template`
  permutations, `kubeconform` strict validation) jobs.
- **HTTP health/readiness probes (Phase D, D3)**: opt-in `/healthz`
  and `/readyz` endpoints registered via `FastMCP.custom_route` and
  served from the same Starlette app as `/mcp`. Disabled by default
  (`HMC_MCP_HTTP_PROBES_PATH` empty); set `/` to mount at the listener
  root or a prefix like `/admin` for non-root mount. `/readyz` returns
  503 with `reason=no-active-hmc-session` until the shared HMC session
  is authenticated; demo mode is always ready. Probe handlers
  intentionally emit no `mcp_tool_call` / `write_audit` /
  `session_reauth` events so SIEM rules stay quiet under continuous
  probing. Boot validator rejects any `HMC_MCP_HTTP_PROBES_PATH` whose
  resolved `/healthz` or `/readyz` path collides with
  `HMC_MCP_HTTP_PATH` to prevent silent ingress shadowing.
- **Streamable-HTTP hardening (Phase D, D2)**:
  documented session-affinity decision (shared as v1 default,
  per-client / per-request listed as future opt-ins) at
  `docs/design/http-session-affinity.md`; reverse-proxy samples
  (NGINX 1.27, Envoy) plus a `docker-compose.yml` and `hmc.env.example`
  under `examples/deploy/`; bind-path smoke test
  (`tests/test_mcp_server_bind_path_smoke.py`) pinning the contract
  that `HMC_MCP_HTTP_HOST` / `_PORT` / `_PATH` propagate to
  `FastMCP.settings` before `mcp.run()` (so the ingress configs and
  the application listener cannot drift).
- **Async transport pair (Phase D, D1)**: `retry_sleep_async` and
  `throttle_before_request_async` in `http_policy.py` (paired `# ASYNC`
  with the existing `# SYNC-ONLY` helpers; `backoff_delay_seconds` is
  shared verbatim), `_assert_async_context` guard for the new helpers,
  new `HmcAsyncSession` (`session_async.py`) wrapping `httpx.AsyncClient`,
  and new `HmcAsyncClient` (`hmc_client_async.py`) exposing the same
  read-method surface as `HmcClient` plus `is_authenticated()` for D3
  readiness probes. Demo mode behaves identically on the async path.
  **No public behaviour change**: the MCP surface still runs through the
  sync client; the async pair is behind a Phase-D-internal seam consumed
  by D5 multi-HMC pools and future OpenTelemetry instrumentation.
- `HmcClient.is_authenticated()` predicate (no HMC traffic) used by D3
  readiness probes; demo mode always returns False.
- `pytest-asyncio` strict mode declared in `[tool.pytest.ini_options]`
  (`asyncio_mode = "strict"`); async tests must opt in explicitly via
  `@pytest.mark.asyncio` or `pytestmark`.

### Fixed

- `session.py` outbound correlation header was `X-Correlation-ID` (not an
  IBM HMC header); changed default to `X-Transaction-ID` per IBM HMC REST
  API spec. Now env-overridable via `HMC_OUTBOUND_CORRELATION_HEADER`
  (set `X-Correlation-ID` to restore previous behaviour).
- Outbound and echo-read headers are now symmetric: both default to
  `X-Transaction-ID`. The HMC echoes back what the client sends — the
  previous mismatch made B2-3 echo capture dead-on-arrival against
  real firmware.
- **PCM metric field name**: `_pcm_cpu_aggregates` now reads
  `serverUtil.processor.utilizedProcUnits` (and `utilizedProcUnitsDeductIdle`
  when `utilInfo.version >= 1.1.0`) instead of the non-existent `cpuUtil`
  field. The IBM PCM JSON schema is identical across Power9 / Power10 / Power11
  — a single implementation path handles all three; only the deductIdle field
  is version-gated. Helper signature changed from
  `_pcm_cpu_aggregates(list)` to `_pcm_cpu_aggregates(systemUtil_dict)`;
  reads `metricArrayOrder` to handle both `Processed` (`[Avg]`) and
  `Aggregated` (`[Avg, Min, Max]`) sample formats. `[RISK]` marker on
  `cpuUtil` removed — the field never existed in any Power generation, so
  it was a documentation error, not a risk to validate. Validated against
  IBM Docs.
- **Correlation echo header defaults**: `HMC_CORRELATION_ECHO_HEADER` now
  defaults to `X-Transaction-ID` (was `X-Correlation-ID`) and
  `HMC_CORRELATION_ECHO_FALLBACK_HEADERS` defaults to `X-Client-Correlator`
  (was `X-Request-ID`). According to the IBM HMC REST API spec,
  `X-Transaction-ID` is the spec-defined correlation header for HMC
  responses; `X-Client-Correlator` is the optional V8+ alternative.
  `X-Correlation-ID` and `X-Request-ID` are not defined in the IBM HMC
  spec. Per-firmware echo behaviour is still `[ASSUMED]` until rows land
  in `docs/hmc-compatibility.md` 'Correlation Header Echo'. Outbound
  request header (`session.py` `CORRELATION_HEADER`) is unchanged in
  this commit and remains `X-Correlation-ID`.
- **`metrics_href_response.json`** fixture rewritten to the real IBM PCM
  schema (`systemUtil.utilSamples[n].serverUtil.processor.utilizedProcUnits`
  array, v1.1.0 with deductIdle).
- **`metrics_href_response_v9.json`** added for the legacy v1.0.0 / no-deductIdle
  fallback path (Power9 / HMC < V10R2M1040).
- **B2-7b `xfail` gate narrowed** in `test_contracts.py` —
  `utilizedProcUnits` is now confirmed; only the real `metrics_href` GET
  wiring remains.

### Added

- **Demo mode** (`HMC_DEMO_MODE=true`): all 8 read tools return bundled JSON fixtures
  (`src/power_hmc_mcp/demo_fixtures/`), write tools return `{executed: false, demo: true,
  suggested_next_step: ...}`, `login()`/`close()` are no-ops, and server startup emits a
  prominent `WARNING`. Enables demos, CI smoke tests, and contributor onboarding without
  an HMC connection.
- **8 golden output fixtures** (`tests/fixtures/<tool_name>.json`) derived from XML
  fixtures — byte-for-byte snapshots of each read tool's normalized output. First-line
  drift alarm for agent consumers.
- **`tests/test_contracts.py`**: 8 contract test classes (~35 assertions) calling actual
  `HmcClient` methods against recorded XML. Covers `mode=metadata` with full golden-fixture
  match and `mode=summary` with shape-only assertions for `get_capacity`. Fails on schema
  drift immediately.
- **`_pcm_cpu_aggregates`** helper in `hmc_client.py`: computes min/max/avg CPU utilization
  from parsed PCM metric JSON samples. `[RISK]` — `cpuUtil` field name is provisional
  pending Phase B2 firmware validation.
- **`get_capacity_full` stub** with `[PLACEHOLDER]` fetch body, size guard
  (`_check_metrics_response_size`), and `HmcResponseTooLargeError`. Interface is testable;
  real HTTP fetch lands in Phase B2.
- **`HMC_MAX_METRICS_BYTES`** config key (default 10 MB, validated 1 KB–100 MB). Raises
  `HmcResponseTooLargeError` if the PCM metric JSON body exceeds the limit before parsing.
- **`suggested_next_step`** field on all write tool response envelopes: denied, dry-run,
  authorized placeholder, and demo paths all include a plain-English hint for the agent or
  operator.
- **`log_logon_end` / `log_logoff_end`** structured lifecycle events in `observability.py`:
  emit `session_logon_end` / `session_logoff_end` events with `hmc_host`, `outcome`
  (`success` / `error` / `demo`), `component`, and `correlation_id`. Documented in
  `docs/operations.md` Standard event types table.
- **`HmcSession.close()` now surfaces logoff failures** to `HmcClient.close()`, which
  emits `session_logoff_end` with `outcome="error"` instead of silently reporting success.

### Changed

- `HmcClient.__enter__` / `__exit__` now delegate to `self.login()` / `self.close()`
  (previously called `self._session.login()` / `close()` directly, bypassing demo mode
  guard and lifecycle events).
- `docs/architecture.md`: module map and layers table updated to reflect `session.py`
  (HMC transport/session lifecycle) and `normalize.py` (normalization helpers) extracted
  in `v0.1.0`. Request pipeline diagrams updated from `client._request` →
  `client._session.request`.
- `docs/operations.md` Standard event types table: `telemetry_placeholder` → `telemetry_stub`
  to match the actual `event_type` value emitted by `telemetry_hook()`.
- `docs/agent-guide.md` authorized placeholder example: `message` field updated to match
  the exact `PHASE_A_WRITE_SCAFFOLD_MESSAGE` constant.
- `docs/milestone-evaluation.md` status table: Phase B1 marked complete; Phase B2 noted
  as pending Phase A evaluation exit.

### Fixed

- `test_settings_requires_hmc_host` now uses `Settings(_env_file=None)` for proper
  environment isolation — prevents the test from reading a local `.env` file on disk.

### Process

- Phase A team evaluation gate documented in [`docs/milestone-evaluation.md`](docs/milestone-evaluation.md); Phase B work paused until exit criteria are met.

## [0.1.0] - 2026-05-17

Phase A complete: foundation, `HmcSession` transport seam, CI hardened.

### Added

- CI coverage (`pytest-cov`) with Codecov upload; `secret-scan`, `audit`, and `release` GitHub Actions workflows.
- `.github/PULL_REQUEST_TEMPLATE.md`, bug/feature issue templates, `SECURITY.md`, `CODE_OF_CONDUCT.md`.
- [`docs/release-engineering.md`](docs/release-engineering.md) — Codecov token, PyPI Trusted Publisher, milestones, CI summary.
- [`scripts/github-bootstrap.sh`](scripts/github-bootstrap.sh) — repo topics, Phase B–I milestones, issue/project triage (requires `gh auth login`).
- `HmcSession` in `session.py` — transport/session lifecycle extracted from `HmcClient` (pre-Phase C seam).
- `tests/test_session.py` — MockTransport tests for login, retry, and 401 re-auth.

### Changed

- `hmc_client.py` composes `HmcSession`; IBM API surface only.
- CI: `pre-commit run --all-files`, pip cache, concurrency cancel-in-progress; `pip-audit` excludes unpublished local package.
- Phase B roadmap split into B1 (no HMC) / B2 (firmware-gated) in `TODO.md`.

### Fixed

- `test_settings_requires_hmc_host` env isolation via `Settings(_env_file=None)`.
- Pre-commit / CI ruff aligned on 0.15.x.

### Maintainer setup (one-time)

1. `gh secret set CODECOV_TOKEN` — see [Codecov setup](docs/release-engineering.md#codecov-codecov_token).
2. PyPI Trusted Publisher for `release.yml` — see [PyPI OIDC](docs/release-engineering.md#pypi-trusted-publishing-oidc).
3. `./scripts/github-bootstrap.sh` — topics, milestones, project Priority/Effort (set `GH_PROJECT_NUMBER` if using a board).

Phase B read-path work continues; see `TODO.md`.

## [0.1.0b1] - 2026-05-16

Structural write boundary, symmetric `write_audit`, documentation build-out,
and `.env.example` fix. **Breaking** for direct callers of `HmcClient` write
methods (`execute=` removed; `authorization=` required). MCP tool JSON schemas
unchanged (`execute` remains the agent-facing flag).

### Changed

- **Write-tool safety is now structural, not conventional.** A new
  `power_hmc_mcp.tools.write` module owns the FastMCP-shaped guardrail
  decorator. `HmcClient.start_lpar` / `stop_lpar` / `create_lpar_from_profile`
  now require a `WriteAuthorization` capability token (no more
  `execute: bool`). Tokens are issued only by `run_write_tool` after
  `check_write_allowed` succeeds; `WriteAuthorization` raises on direct
  construction (module-private sentinel) and the client methods re-validate
  with `isinstance` to defend against `cast()` abuse. Forgetting the
  `@mark_write_tool` decorator on a registered write tool now fails server
  startup, not call time.
- **Documentation pass.** `README.md` rewritten in plain English with a
  mental model, plain-English write safety section, and "where each concept
  lives" navigation. `docs/architecture.md` gains a module map, request
  walkthroughs (read + write), and extension recipes. `docs/operations.md`
  expanded into a full configuration / event / exception reference with
  runbook entries. `docs/transports.md` adds end-to-end client snippets and
  reverse-proxy guidance. `CONTRIBUTING.md` and `AGENTS.md` reconciled with
  cross-doc links. `.env.example` corrected (`HMC_PROPAGATE_CORRELATION_HEADER`
  as bool per v0.1.0a0 semantics).

### Added

- `power_hmc_mcp.tools.write` — `mark_write_tool`, `is_write_tool`,
  `run_write_tool`, `WRITE_TOOL_ANNOTATIONS`, and `WRITE_TOOL_MARKER`.
- `observability.log_write_audit` — canonical `write_audit` event with
  stable schema (`tool_name`, `operation`, `outcome`, `reason`,
  `execute_requested`, `correlation_id`). Outcome is constrained to
  `denied` / `dry_run` / `authorized` and is emitted on every code path so
  denied write attempts are never silent.
- Tests for the structural boundary (`tests/test_tools_write.py`,
  `tests/test_guardrails.py` updates, `tests/test_hmc_client.py` updates).
  Suite: 78 passing, ruff + mypy clean.
- New docs: [`docs/glossary.md`](docs/glossary.md) and
  [`docs/agent-guide.md`](docs/agent-guide.md). `examples/claude_desktop_config.json`
  expanded as a copy-paste template.

## [0.1.0a0] - 2026-05-16

Phase A complete: layered architecture, observability, stdio transport, correlation
spanning the HMC boundary by default.

### Added

- Centralized HMC route builders in `routes.py`.
- HTTP policy module (`http_policy.py`) with read/write retry classification, backoff
  with jitter, and `# SYNC-ONLY` markers on `time.sleep` sites for the future async
  migration (Phase D).
- Observability helpers (`observability.py`): correlation IDs, structured JSON logging
  (`HMC_LOG_JSON`), MCP tool lifecycle logs, HMC request timing hooks, telemetry
  placeholder hook, and `hmc_echo_correlation_id` capture from HMC response headers.
- Unified `HmcClient` authenticated pipeline with throttle placeholder, single retry
  budget shared across transport and HTTP-status retries, structured `auth_retry` log
  before re-login, and PCM output modes (`metadata`, `summary`, `full` placeholder).
- Default-on outbound `X-Correlation-ID` propagation
  (`HMC_PROPAGATE_CORRELATION_HEADER=true`) so traces span the HMC boundary from the
  start; DEBUG canary fires if a request bypasses `mcp_tool_call`.
- MCP transport configuration (`HMC_MCP_TRANSPORT`: `stdio` or `streamable-http`) with
  HTTP bind settings applied via `mcp.settings` (compatible with `mcp>=1.27`).
- Write-tool MCP registration behind `HMC_ENABLE_WRITE_TOOLS`; placeholder execute
  responses with audit scaffolding (`write_placeholder_execute_response`).
- Deployment mode setting `HMC_DEPLOYMENT_MODE` (documentation-oriented baseline).
- Real subprocess + stdio MCP loop closure example
  (`integrations/langgraph/example_list_lpars_stdio.py`) with friendly preflight env
  validation and runtime error hints.
- Documentation: `docs/architecture.md`, `docs/transports.md`, `docs/operations.md`;
  LangGraph workspace under `integrations/langgraph/`.
- Phased roadmap in `TODO.md` (Phases A–I) with `[PLACEHOLDER]` and `[RISK]` markers.
- Tests for routes, HTTP policy, retries, correlation toggle (default-on, disabled,
  echo capture), write placeholders, and conditional tool registration. Suite: 65
  passing, ruff + mypy clean.
- GitHub Actions CI (Ruff, mypy, pytest on Python 3.11 and 3.12).
- Pre-commit hooks (Ruff, mypy, detect-secrets baseline).
- `logging_utils` with secret redaction for passwords and session tokens.
- HMC session re-authentication on HTTP 401 (single retry after re-login).
- `health_check` read-only MCP tool and `py.typed` marker.
- `CONTRIBUTING.md`, `examples/claude_desktop_config.json`, richer tool docstrings.

### Changed

- **`get_lpar_status`** now requires `managed_system_id` and defaults to a single
  canonical UOM GET (`HMC_LPAR_STATUS_SOURCE=uom`); quick fan-out remains opt-in via
  `quick`.
- **`get_capacity`** returns agent-normalized sample metadata and supports `mode`;
  `full` mode documents future metric JSON fetch work.
- **`stop_lpar`** / **`start_lpar`** tools take `managed_system_id` for consistent
  routing with write path builders.
- MCP startup registers tools via `register_tools()` (read tools always; write tools
  when enabled).
- MCP server startup uses `configure_logging(settings=...)` and observability-aware
  formatters.
- `HMC_PROPAGATE_CORRELATION_HEADER` semantics: was `str | None` (header name, opt-in);
  is now `bool` defaulting to `true` with the header name standardized to
  `X-Correlation-ID`. Set `false` only if older HMC firmware rejects unknown request
  headers.

## [0.0.1] - 2026-05-15

### Added

- Initial MCP server with seven read-only tools: `list_managed_systems`, `list_lpars`, `get_lpar_status`, `get_managed_system`, `get_lpar`, `list_partition_profiles`, `get_capacity`.
- HMC REST client with TLS options, managed-system allowlist, and typed errors.
- Unit tests with `respx` mocks; write tool modules present but not registered.
