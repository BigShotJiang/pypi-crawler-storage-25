# LangGraph integration workspace

Isolates **orchestration experiments** from the core `power_hmc_mcp` package. Lives separately so optional dependencies (`[langgraph]`) don't drag into the main install.

For the bigger picture see the [project README](../../README.md), the [architecture doc](../../docs/architecture.md), and the [agent caller guide](../../docs/agent-guide.md).

## Goals

- Show how to spawn `python -m power_hmc_mcp.mcp_server` over **stdio** (default transport).
- Provide a stable location for future LangGraph graphs without coupling releases to optional dependencies.

## Optional dependencies

```bash
pip install -e ".[langgraph]"
```

The `[langgraph]` extra intentionally stays minimal. The stdio example below uses only the already-installed `mcp` SDK — LangGraph itself is layered on top once you wire it into your graph.

## Examples

### `example_list_lpars_stdio.py` — real loop closure

Spawns the MCP server as a subprocess, opens a `mcp.ClientSession` over stdio, prints the list of registered tools, and calls `list_lpars` against a managed system UUID. The pattern is what any LangGraph adapter ends up doing under the hood.

#### Required environment

| Variable | Purpose |
|----------|---------|
| `HMC_HOST` | HMC hostname or IP. |
| `HMC_USERNAME` / `HMC_PASSWORD` | HMC credentials. |
| `HMC_VERIFY_TLS` (optional) | Set `false` for self-signed labs (or use `HMC_CA_BUNDLE`). |
| `HMC_TARGET_MANAGED_SYSTEM_ID` | UUID to list LPARs for (or pass as `argv[1]`). |

Full env reference: [`docs/operations.md` configuration reference](../../docs/operations.md#configuration-reference).

#### Run

```bash
python integrations/langgraph/example_list_lpars_stdio.py <managed-system-uuid>
```

The spawned server reads the same `HMC_*` env vars as a local run; the parent process forwards them through `StdioServerParameters(env=dict(os.environ))`. The script prints the tool list (so you can confirm registration) and the JSON list of LPARs.

If something goes wrong, the script prints a hint listing the most common causes (bad credentials, HMC unreachable, TLS mismatch, allowlist mismatch) and re-raises the underlying exception. Re-run with `HMC_LOG_JSON=true` for structured diagnostics.

### `example_list_lpars_http.py` — streamable HTTP client

Connects to a server already running with `HMC_MCP_TRANSPORT=streamable-http` at `http://localhost:8000/mcp` (override with `HMC_MCP_HTTP_URL`). Mirrors the stdio example's tool list + `list_lpars` call.

Start the server:

```bash
HMC_MCP_TRANSPORT=streamable-http python -m power_hmc_mcp.mcp_server
```

Run the client:

```bash
python integrations/langgraph/example_list_lpars_http.py <managed-system-uuid>
```

See [`docs/transports.md`](../../docs/transports.md) for bind address, TLS, and security notes.

## Notes

- Prefer **stdio** for local graphs; switch the server to `HMC_MCP_TRANSPORT=streamable-http` when running remotely and point your MCP client at the HTTP URL documented in [`docs/transports.md`](../../docs/transports.md).
- Correlation IDs propagate to HMC by default via `X-Transaction-ID` — see [`docs/operations.md` correlation IDs](../../docs/operations.md#correlation-ids).
- Sample tool inputs and outputs (so you know what to expect from each tool) live in the [agent guide](../../docs/agent-guide.md#sample-inputs-and-outputs).
