#!/usr/bin/env python3
"""Real stdio MCP loop: spawn the server, list tools, call ``list_lpars``.

Closes the integration loop using only the already-installed ``mcp`` SDK
(no LangGraph dependency). LangGraph adapters can layer on top of this
exact pattern; what matters here is that an out-of-process MCP client
talks to ``power_hmc_mcp.mcp_server`` over stdio.

Required env vars (the spawned server reads them):

- ``HMC_HOST``, ``HMC_USERNAME``, ``HMC_PASSWORD`` (and TLS settings)
- ``HMC_TARGET_MANAGED_SYSTEM_ID`` (or pass as argv[1]) — the managed
  system UUID to list LPARs for.

Run::

    python integrations/langgraph/example_list_lpars_stdio.py
"""

from __future__ import annotations

import os
import sys

import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

REQUIRED_ENV = ("HMC_HOST", "HMC_USERNAME", "HMC_PASSWORD")


def _preflight_env() -> list[str]:
    return [name for name in REQUIRED_ENV if not os.environ.get(name)]


async def run(managed_system_id: str) -> None:
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "power_hmc_mcp.mcp_server"],
        env=dict(os.environ),
    )
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print("tools:", sorted(t.name for t in tools.tools))
            result = await session.call_tool(
                "list_lpars",
                {"managed_system_id": managed_system_id},
            )
            for block in result.content:
                text = getattr(block, "text", None)
                if text is not None:
                    print(text)


def main() -> None:
    target = os.environ.get("HMC_TARGET_MANAGED_SYSTEM_ID")
    if target is None and len(sys.argv) > 1:
        target = sys.argv[1]
    if not target:
        print(
            "Set HMC_TARGET_MANAGED_SYSTEM_ID or pass the managed system "
            "UUID as the first argument.",
            file=sys.stderr,
        )
        sys.exit(2)

    missing = _preflight_env()
    if missing:
        print(
            "Missing required HMC env vars: "
            + ", ".join(missing)
            + ". Copy .env.example to .env, fill in HMC_HOST / HMC_USERNAME / "
            "HMC_PASSWORD, then re-run. The MCP server child process inherits "
            "this shell's environment.",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        anyio.run(run, target)
    except Exception as exc:
        # The MCP server logs its own startup failures to stderr (it's a child
        # process); this hint helps the operator connect a generic stdio EOF /
        # broken-pipe error to the most common root causes.
        print(
            f"\nstdio MCP loop failed: {type(exc).__name__}: {exc}\n"
            "Common causes: invalid HMC credentials, HMC unreachable from this "
            "host, TLS verification failures (set HMC_VERIFY_TLS=false for "
            "self-signed labs), or HMC_TARGET_MANAGED_SYSTEM_ID not in the "
            "configured allowlist. Re-run with HMC_LOG_JSON=true for "
            "structured diagnostics.",
            file=sys.stderr,
        )
        raise


if __name__ == "__main__":
    main()
