#!/usr/bin/env python3
"""Streamable HTTP MCP loop: connect to a running server, call ``list_lpars``.

Start the server in another terminal first::

    HMC_MCP_TRANSPORT=streamable-http \\
    HMC_MCP_HTTP_HOST=127.0.0.1 \\
    HMC_MCP_HTTP_PORT=8000 \\
    HMC_MCP_HTTP_PATH=/mcp \\
    python -m power_hmc_mcp.mcp_server

Then run this client::

    python integrations/langgraph/example_list_lpars_http.py <managed-system-uuid>

Required env vars match the stdio example (``HMC_HOST``, credentials, TLS).
The HTTP URL defaults to ``http://localhost:8000/mcp`` and can be overridden
with ``HMC_MCP_HTTP_URL``.
"""

from __future__ import annotations

import os
import sys

import anyio
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

REQUIRED_ENV = ("HMC_HOST", "HMC_USERNAME", "HMC_PASSWORD")
DEFAULT_HTTP_URL = "http://localhost:8000/mcp"


def _preflight_env() -> list[str]:
    return [name for name in REQUIRED_ENV if not os.environ.get(name)]


def _http_url() -> str:
    return os.environ.get("HMC_MCP_HTTP_URL", DEFAULT_HTTP_URL)


async def run(managed_system_id: str) -> None:
    url = _http_url()
    async with streamablehttp_client(url) as (read, write, _meta):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print("tools:", sorted(t.name for t in tools.tools))
            result = await session.call_tool(
                "list_lpars",
                {"managed_system_id": managed_system_id},
            )
            for block in result.content:
                text = getattr(block, "text", None)
                if text is not None:
                    print(text)


def main() -> None:
    target = os.environ.get("HMC_TARGET_MANAGED_SYSTEM_ID")
    if target is None and len(sys.argv) > 1:
        target = sys.argv[1]
    if not target:
        print(
            "Set HMC_TARGET_MANAGED_SYSTEM_ID or pass the managed system "
            "UUID as the first argument.",
            file=sys.stderr,
        )
        sys.exit(2)

    missing = _preflight_env()
    if missing:
        print(
            "Missing required HMC env vars: "
            + ", ".join(missing)
            + ". Copy .env.example to .env, fill in HMC_HOST / HMC_USERNAME / "
            "HMC_PASSWORD, then re-run.",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        anyio.run(run, target)
    except Exception as exc:
        print(
            f"\nHTTP MCP loop failed: {type(exc).__name__}: {exc}\n"
            f"Ensure the server is listening at {_http_url()} with "
            "HMC_MCP_TRANSPORT=streamable-http. See integrations/langgraph/README.md.",
            file=sys.stderr,
        )
        raise


if __name__ == "__main__":
    main()
