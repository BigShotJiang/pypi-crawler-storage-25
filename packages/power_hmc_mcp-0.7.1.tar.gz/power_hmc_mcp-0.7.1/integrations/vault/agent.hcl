# Vault Agent template for power-hmc-mcp HMC credentials.
# Mount as /vault/config/agent.hcl in the sidecar container.
# See integrations/vault/README.md for Kubernetes wiring.

pid_file = "/tmp/pidfile"

vault {
  address = "https://vault.example.com:8200"
}

auto_auth {
  method "kubernetes" {
    mount_path = "auth/kubernetes"
    config = {
      role = "power-hmc-mcp"
    }
  }

  sink "file" {
    config = {
      path = "/tmp/vault-token"
    }
  }
}

template {
  destination = "/vault/secrets/hmc.env"
  contents    = <<EOH
{{- with secret "secret/data/power-hmc/hmc" -}}
HMC_HOST={{ .Data.data.host }}
HMC_USERNAME={{ .Data.data.username }}
HMC_PASSWORD={{ .Data.data.password }}
{{- end -}}
EOH
}
