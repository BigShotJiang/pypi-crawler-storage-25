# Vault Agent sidecar for HMC credentials

Template configuration for injecting `HMC_HOST`, `HMC_USERNAME`, and
`HMC_PASSWORD` at runtime via [HashiCorp Vault Agent](https://developer.hashicorp.com/vault/docs/agent)
instead of baking secrets into Kubernetes Secrets or container images.

This directory ships **config only** — no Python changes. The MCP server still
reads credentials from environment variables at startup via Pydantic `Settings`
(see [`docs/operations.md`](../../docs/operations.md)).

## Prerequisites

- Vault cluster with KV secrets engine enabled (v2).
- Kubernetes auth method configured in Vault for the pod's service account.
- A secret stored at the path below (adjust to match your mount layout).

## Secret layout (example)

Store credentials in Vault KV v2:

```text
Path:   secret/data/power-hmc/hmc
Fields: host, username, password
```

Example write:

```bash
vault kv put secret/power-hmc/hmc \
  host=hmc.example.com \
  username=hmc_svc \
  password='***'
```

## Agent config

[`agent.hcl`](agent.hcl) renders `/vault/secrets/hmc.env` with the three
required variables. Mount this file into a Vault Agent sidecar container and
point the main `power-hmc-mcp` container at the rendered file.

## Kubernetes sidecar sketch

Adjust image tags, service account, and Vault address for your cluster:

```yaml
spec:
  serviceAccountName: power-hmc-mcp
  containers:
    - name: power-hmc-mcp
      image: ghcr.io/coomes-ai/power-hmc-mcp:0.6.2
      command: ["/bin/sh", "-c"]
      args:
        - |
          set -a
          . /vault/secrets/hmc.env
          set +a
          exec power-hmc-mcp
      volumeMounts:
        - name: vault-secrets
          mountPath: /vault/secrets
          readOnly: true
    - name: vault-agent
      image: hashicorp/vault:1.17
      args:
        - agent
        - -config=/vault/config/agent.hcl
      env:
        - name: VAULT_ADDR
          value: https://vault.example.com:8200
      volumeMounts:
        - name: vault-config
          mountPath: /vault/config
        - name: vault-secrets
          mountPath: /vault/secrets
  volumes:
    - name: vault-config
      configMap:
        name: power-hmc-mcp-vault-agent
    - name: vault-secrets
      emptyDir:
        medium: Memory
```

The sidecar must start before the main container reads `/vault/secrets/hmc.env`.
Use an init-container pattern or a startup probe that waits for the env file if
your orchestrator does not guarantee sidecar ordering.

## Alternatives

- **External Secrets Operator** — sync Vault KV into a native Kubernetes Secret
  and set `hmc.existingSecret` in the Helm chart
  ([`examples/deploy/helm/power-hmc-mcp/`](../../examples/deploy/helm/power-hmc-mcp/)).
- **Pilot / dev** — a mode-`600` `.env` file on the host is acceptable; see
  [Secrets management](../../docs/operations.md#secrets-management) in the
  operations guide.

## Related

- [`docs/design/threat-model.md`](../../docs/design/threat-model.md) — secrets
  handling requirements for Phase C entry.
- [`docs/operations.md`](../../docs/operations.md) — full configuration
  reference.
