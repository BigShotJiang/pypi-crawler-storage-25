"""HMC client exceptions."""

from __future__ import annotations


class HmcError(Exception):
    """Base error for HMC client operations."""


class HmcAuthError(HmcError):
    """Authentication or session establishment failed."""


class HmcHttpError(HmcError):
    """HTTP request to the HMC failed."""

    def __init__(self, message: str, *, status_code: int, url: str) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.url = url


class HmcParseError(HmcError):
    """HMC response body could not be parsed."""


class HmcValidationError(HmcError):
    """Invalid input before calling the HMC."""


class HmcResponseTooLargeError(HmcError):
    """HMC response body exceeds the configured size guard.

    Raised by :meth:`HmcClient.get_capacity_full` before parsing when the
    PCM metric JSON body exceeds ``HMC_MAX_METRICS_BYTES``.  Callers should
    surface this to agents rather than retrying — the response will not shrink
    without changing the query parameters.
    """

    def __init__(self, message: str, *, max_bytes: int, actual_bytes: int) -> None:
        super().__init__(message)
        self.max_bytes = max_bytes
        self.actual_bytes = actual_bytes


class HmcNotImplementedError(HmcError):
    """Operation scaffold exists but live HMC execution is not wired yet."""
