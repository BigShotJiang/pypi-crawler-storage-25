"""IBM Cloud Power Virtual Server provider stub (Phase J).

[PLACEHOLDER] IBM Cloud Power Virtual Server provider.

Connects to IBM Cloud Power VS instances via the IBM Cloud REST API
rather than the HMC REST API. Authentication uses IBM Cloud IAM tokens
(api_key → Bearer token exchange) rather than HMC session cookies.

Status: stub — all methods raise NotImplementedError.
Activation: requires IBM Cloud credentials (IBMCLOUD_API_KEY,
POWERVS_WORKSPACE_ID, POWERVS_REGION). Set HMC_PROVIDER=powervs.

IBM Cloud Power VS API reference:
https://cloud.ibm.com/apidocs/power-cloud
"""

from __future__ import annotations

from typing import Any

from power_hmc_mcp.config import CapacityOutputMode, Settings
from power_hmc_mcp.guardrails import WriteAuthorization

__all__ = ["PowerVSProvider", "_NOT_IMPLEMENTED_MSG"]

_NOT_IMPLEMENTED_MSG = (
    "PowerVSProvider is not yet implemented. Set HMC_PROVIDER=hmc (default) to use the HMC backend."
)


class PowerVSProvider:
    """[PLACEHOLDER] IBM Cloud Power Virtual Server backend (stub)."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        # [PLACEHOLDER] IBM Cloud IAM token exchange not implemented
        # Requires: IBMCLOUD_API_KEY, POWERVS_WORKSPACE_ID, POWERVS_REGION

    @property
    def settings(self) -> Settings:
        return self._settings

    def login(self) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def close(self) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def list_managed_systems(self) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_managed_system(self, managed_system_id: str) -> dict[str, Any]:
        del managed_system_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def list_lpars(self, managed_system_id: str) -> list[dict[str, Any]]:
        del managed_system_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_lpar_status(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        del managed_system_id, lpar_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_lpar(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        del managed_system_id, lpar_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_lpar_quick(self, lpar_id: str) -> dict[str, Any]:
        del lpar_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def list_partition_profiles(self, lpar_id: str) -> list[dict[str, Any]]:
        del lpar_id
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_capacity(
        self,
        managed_system_id: str,
        *,
        mode: CapacityOutputMode = "metadata",
    ) -> dict[str, Any]:
        del managed_system_id, mode
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def get_capacity_full(
        self,
        managed_system_id: str,
        metrics_href: str,
    ) -> dict[str, Any]:
        del managed_system_id, metrics_href
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def is_authenticated(self) -> bool:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def health_check(self) -> dict[str, Any]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def create_lpar_from_profile(
        self,
        managed_system_id: str,
        profile_name: str,
        new_lpar_name: str,
        overrides: dict[str, Any] | None = None,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, profile_name, new_lpar_name, overrides, authorization
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def start_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, lpar_id, authorization
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    def stop_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        mode: str = "normal",
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, lpar_id, mode, authorization
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)
