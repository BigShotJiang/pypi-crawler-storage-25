"""Agent-facing MCP output helpers (Phase F ergonomics).

Response shaping for inventory list tools lives here so :mod:`hmc_client` stays
faithful to HMC payloads while MCP tools expose deterministic, branch-friendly
envelopes.
"""

from __future__ import annotations

from collections import Counter
from typing import Any

from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.serialize import ensure_json_serializable


def _count_by_key(items: list[dict[str, Any]], key: str) -> dict[str, int]:
    """Return occurrence counts for ``key`` across *items* (deterministic order)."""
    counts: Counter[str] = Counter()
    for item in items:
        raw = item.get(key)
        label = raw if isinstance(raw, str) and raw else "unknown"
        counts[label] += 1
    return dict(sorted(counts.items()))


def wrap_list_response(
    items: list[dict[str, Any]],
    *,
    limit: int | None = None,
    offset: int = 0,
    state_counts: bool = False,
) -> dict[str, Any]:
    """Wrap an inventory list in a deterministic paginated envelope.

    Preserves HMC feed order (Atom collection order as returned by the HMC for
    that call). Offset pagination is safe within one inventory snapshot; if
    inventory may change between pages, re-fetch from ``offset=0``.

    When ``limit`` is omitted, all items are returned with ``summary.truncated=false``.
    When ``limit`` is set, slices ``items[offset:offset+limit]`` and sets truncation
    metadata explicitly (``next_offset`` when more rows remain).
    """
    if offset < 0:
        raise HmcValidationError("offset must be >= 0")
    if limit is not None and limit < 1:
        raise HmcValidationError("limit must be >= 1 when provided")

    total = len(items)
    if offset > total:
        offset = total

    if limit is None:
        page = items[offset:]
        truncated = False
        next_offset: int | None = None
    else:
        page = items[offset : offset + limit]
        truncated = offset + len(page) < total
        next_offset = offset + len(page) if truncated else None

    summary: dict[str, Any] = {
        "total_count": total,
        "returned_count": len(page),
        "offset": offset,
        "truncated": truncated,
    }
    if next_offset is not None:
        summary["next_offset"] = next_offset
    if state_counts:
        summary["state_counts"] = _count_by_key(items, "state")

    body: dict[str, Any] = {"items": page, "summary": summary}
    return ensure_json_serializable(body)
