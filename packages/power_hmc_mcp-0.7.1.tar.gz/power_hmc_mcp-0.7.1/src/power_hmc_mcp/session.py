"""HMC transport and session lifecycle.

HmcSession owns the httpx client, authentication token, login/logoff,
retry loop, throttle, and 401-recovery. It has no knowledge of IBM
resource shapes, allowlists, or write authorization.

All retry logic, backoff math, and auth-recovery behavior lives here
and must not be duplicated elsewhere.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import httpx

from power_hmc_mcp import observability, routes
from power_hmc_mcp.config import Settings
from power_hmc_mcp.exceptions import HmcAuthError, HmcHttpError
from power_hmc_mcp.hmc_xml import build_logon_request
from power_hmc_mcp.http_policy import (
    RequestClassification,
    is_retryable_http_status,
    is_retryable_transport_error,
    max_retries,
    throttle_before_request,
)

logger = logging.getLogger(__name__)

LOGON_PATH = routes.LOGON_PATH
SESSION_HEADER = routes.SESSION_HEADER

CONTENT_TYPE_LOGON = "application/vnd.ibm.powervm.web+xml; type=LogonRequest"
ACCEPT_ATOM = "application/atom+xml; charset=UTF-8"
ACCEPT_UOM_XML = "application/vnd.ibm.powervm.uom+xml"
CORRELATION_HEADER = "X-Transaction-ID"  # IBM HMC REST API spec default


def _sanitize_url(url: str) -> str:
    """Return URL without embedded credentials for error messages."""
    if "@" in url:
        scheme, rest = url.split("://", 1) if "://" in url else ("", url)
        if "@" in rest:
            rest = rest.split("@", 1)[1]
            return f"{scheme}://{rest}" if scheme else rest
    return url


def _log_logon_end(
    t0: float,
    *,
    status_code: int,
    outcome: str,
) -> None:
    observability.log_hmc_request_end(
        "PUT",
        LOGON_PATH,
        status_code=status_code,
        duration_ms=(time.perf_counter() - t0) * 1000,
        outcome=outcome,
    )


class HmcSession:
    """HMC transport and session lifecycle."""

    def __init__(
        self,
        settings: Settings,
        *,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._settings = settings
        self._owns_client = http_client is None
        self._http = http_client or self._build_http_client()
        self._session_token: str | None = None
        self._last_request_monotonic: float | None = None

    @property
    def settings(self) -> Settings:
        return self._settings

    def _build_http_client(self) -> httpx.Client:
        return httpx.Client(
            base_url=self._settings.base_url,
            verify=self._settings.httpx_verify(),
            timeout=self._settings.hmc_timeout_seconds,
        )

    def _echo_headers(self) -> tuple[str, ...]:
        """Ordered tuple of header names to walk when capturing the HMC echo.

        Built from ``HMC_CORRELATION_ECHO_HEADER`` (primary) plus
        ``HMC_CORRELATION_ECHO_FALLBACK_HEADERS``.  Passed to
        ``log_hmc_request_end`` so operator overrides take effect on every
        response.
        """
        return (
            self._settings.hmc_correlation_echo_header,
            *self._settings.hmc_correlation_echo_fallback_headers,
        )

    def __enter__(self) -> HmcSession:
        self.login()
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _map_transport_error(self, exc: httpx.HTTPError, *, method: str, path: str) -> HmcHttpError:
        url = _sanitize_url(str(exc.request.url)) if exc.request else path
        if isinstance(exc, httpx.TimeoutException):
            message = f"HMC request timed out: {method} {path}"
        elif isinstance(exc, httpx.ConnectError):
            message = f"HMC connection failed: {method} {path}"
        else:
            message = f"HMC request error: {method} {path}"
        return HmcHttpError(message, status_code=0, url=url)

    def login(self) -> None:
        """Establish an HMC REST API session."""
        body = build_logon_request(
            self._settings.hmc_username,
            self._settings.hmc_password.get_secret_value(),
        )
        observability.log_hmc_request_start("PUT", LOGON_PATH)
        t0 = time.perf_counter()
        try:
            response = self._http.put(
                LOGON_PATH,
                content=body,
                headers={"Content-Type": CONTENT_TYPE_LOGON},
            )
            if response.status_code >= 400:
                _log_logon_end(t0, status_code=response.status_code, outcome="http_error")
                raise HmcAuthError(
                    f"HMC logon failed with status {response.status_code}",
                )
            token = response.headers.get(SESSION_HEADER)
            if not token:
                _log_logon_end(t0, status_code=response.status_code, outcome="http_error")
                raise HmcAuthError("HMC logon succeeded but no session token was returned")
            self._session_token = token
            _log_logon_end(t0, status_code=response.status_code, outcome="success")
            logger.debug("HMC session established for host=%s", self._settings.hmc_host)
        except HmcAuthError:
            raise
        except httpx.HTTPStatusError as exc:
            _log_logon_end(t0, status_code=exc.response.status_code, outcome="http_error")
            raise HmcAuthError(
                f"HMC logon failed with status {exc.response.status_code}",
            ) from exc
        except httpx.TimeoutException as exc:
            _log_logon_end(t0, status_code=0, outcome="transport_error")
            raise HmcHttpError(
                "HMC logon timed out",
                status_code=0,
                url=_sanitize_url(str(exc.request.url)) if exc.request else LOGON_PATH,
            ) from exc
        except httpx.HTTPError as exc:
            _log_logon_end(t0, status_code=0, outcome="transport_error")
            raise self._map_transport_error(exc, method="PUT", path=LOGON_PATH) from exc

    def close(self) -> None:
        """Log off and close the HTTP client.

        Raises :class:`~power_hmc_mcp.exceptions.HmcHttpError` if the
        DELETE /Logon request fails so the caller can emit a structured
        ``session_logoff_end`` event with ``outcome="error"`` rather than
        silently reporting success.  The token is cleared and the HTTP client
        is closed regardless.
        """
        logoff_error: HmcHttpError | None = None
        if self._session_token is not None:
            try:
                observability.log_hmc_request_start("DELETE", LOGON_PATH)
                t0 = time.perf_counter()
                resp = self._http.delete(
                    LOGON_PATH,
                    headers={SESSION_HEADER: self._session_token},
                )
                observability.log_hmc_request_end(
                    "DELETE",
                    LOGON_PATH,
                    status_code=resp.status_code,
                    duration_ms=(time.perf_counter() - t0) * 1000,
                    outcome="success",
                )
            except httpx.HTTPError as exc:
                logger.debug("HMC logoff request failed", exc_info=True)
                logoff_error = self._map_transport_error(exc, method="DELETE", path=LOGON_PATH)
            self._session_token = None
        if self._owns_client:
            self._http.close()
        if logoff_error is not None:
            raise logoff_error

    def _ensure_session(self) -> None:
        if self._session_token is None:
            self.login()

    def request(
        self,
        method: str,
        path: str,
        *,
        accept: str = ACCEPT_ATOM,
        classification: RequestClassification = RequestClassification.READ,
        **kwargs: Any,
    ) -> httpx.Response:
        """Single pipeline for authenticated HMC HTTP calls (retries, throttle, 401 recovery)."""
        self._ensure_session()
        headers_template = dict(kwargs.pop("headers", {}))

        caps = max_retries(self._settings, classification)
        retry_attempt = 0
        auth_retries_remaining = self._settings.hmc_max_reauth_attempts

        while True:
            throttle_before_request(self._settings, self._last_request_monotonic)
            observability.log_hmc_request_start(method, path)
            t0 = time.perf_counter()

            headers = dict(headers_template)
            headers.setdefault(SESSION_HEADER, self._session_token or "")
            headers.setdefault("Accept", accept)
            if self._settings.hmc_propagate_correlation_header:
                cid = observability.get_correlation_id()
                if cid:
                    outbound_header = self._settings.hmc_outbound_correlation_header
                    headers[outbound_header] = cid
                else:
                    logger.debug(
                        "correlation id missing on outbound HMC request method=%s path=%s "
                        "(caller bypassed mcp_tool_call?)",
                        method,
                        path,
                    )
            observability.inject_outbound_trace_headers(headers)
            if method.upper() in ("PUT", "POST"):
                cid = observability.get_correlation_id()
                if cid:
                    # [ASSUMPTION] value format pending B2 capture — community sources
                    # confirm the header name; semantics are firmware-dependent.
                    headers["X-Audit-Memento"] = cid

            try:
                response = self._http.request(method, path, headers=headers, **kwargs)
            except httpx.HTTPError as exc:
                elapsed_ms = (time.perf_counter() - t0) * 1000
                observability.log_hmc_request_end(
                    method,
                    path,
                    status_code=0,
                    duration_ms=elapsed_ms,
                    outcome="transport_error",
                )
                observability.telemetry_hook(
                    "hmc_transport_error",
                    {"method": method, "path": path, "error": type(exc).__name__},
                )

                if (
                    is_retryable_transport_error(exc, classification=classification)
                    and retry_attempt < caps
                ):
                    from power_hmc_mcp import hmc_client

                    hmc_client.retry_sleep(self._settings, retry_attempt)
                    retry_attempt += 1
                    continue
                raise self._map_transport_error(exc, method=method, path=path) from exc

            elapsed_ms = (time.perf_counter() - t0) * 1000

            echo_headers = self._echo_headers()

            if response.status_code == 401:
                if path == LOGON_PATH:
                    observability.log_hmc_request_end(
                        method,
                        path,
                        status_code=401,
                        duration_ms=elapsed_ms,
                        outcome="auth_error",
                        response=response,
                        echo_headers=echo_headers,
                    )
                    raise HmcAuthError(
                        f"HMC logon failed with status {response.status_code}",
                    )
                if auth_retries_remaining > 0:
                    observability.log_hmc_request_end(
                        method,
                        path,
                        status_code=401,
                        duration_ms=elapsed_ms,
                        outcome="auth_retry",
                        response=response,
                        echo_headers=echo_headers,
                    )
                    auth_retries_remaining -= 1
                    self._session_token = None
                    self.login()
                    observability.log_session_reauth(
                        outcome="success",
                        hmc_host=self._settings.hmc_host,
                        trigger="401_mid_request",
                        hmc_alias=observability.get_active_hmc_alias(),
                    )
                    continue
                observability.log_hmc_request_end(
                    method,
                    path,
                    status_code=401,
                    duration_ms=elapsed_ms,
                    outcome="auth_error",
                    response=response,
                    echo_headers=echo_headers,
                )
                observability.log_session_reauth(
                    outcome="failure",
                    hmc_host=self._settings.hmc_host,
                    trigger="401_mid_request",
                    hmc_alias=observability.get_active_hmc_alias(),
                )
                raise HmcAuthError(
                    "HMC session expired and re-authentication failed",
                )

            if response.status_code >= 400:
                observability.log_hmc_request_end(
                    method,
                    path,
                    status_code=response.status_code,
                    duration_ms=elapsed_ms,
                    outcome="http_error",
                    response=response,
                    echo_headers=echo_headers,
                )

                if (
                    is_retryable_http_status(
                        response.status_code,
                        method,
                        classification=classification,
                    )
                    and retry_attempt < caps
                ):
                    from power_hmc_mcp import hmc_client

                    hmc_client.retry_sleep(self._settings, retry_attempt)
                    retry_attempt += 1
                    continue
                url = _sanitize_url(str(response.request.url))
                raise HmcHttpError(
                    f"HMC request failed: {method} {path} -> {response.status_code}",
                    status_code=response.status_code,
                    url=url,
                )

            observability.log_hmc_request_end(
                method,
                path,
                status_code=response.status_code,
                duration_ms=elapsed_ms,
                outcome="success",
                response=response,
                echo_headers=echo_headers,
            )
            self._last_request_monotonic = time.monotonic()
            observability.telemetry_hook(
                "hmc_request_success",
                {"method": method, "path": path, "status": response.status_code},
            )
            return response
