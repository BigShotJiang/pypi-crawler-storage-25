"""Input validation for HMC client paths."""

from __future__ import annotations

import re

from power_hmc_mcp.exceptions import HmcValidationError

UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)
RESOURCE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

_UUID_FORMAT_HINT = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"


def validate_resource_id(value: str, *, field: str, allow_non_uuid: bool = False) -> str:
    """Validate a resource id used in HMC REST URL paths."""
    value = value.strip()
    if not value:
        raise HmcValidationError(
            f"Invalid {field}: must be a UUID ({_UUID_FORMAT_HINT})",
        )
    if UUID_RE.fullmatch(value):
        return value.lower()
    if allow_non_uuid and RESOURCE_ID_RE.fullmatch(value):
        return value
    raise HmcValidationError(
        f"Invalid {field}: must be a UUID ({_UUID_FORMAT_HINT})",
    )
