"""Correlation IDs, structured log fields, and MCP tool invocation lifecycle."""

from __future__ import annotations

import atexit
import json
import logging
import os
import re
import threading
import time
import uuid
from collections.abc import Callable, Iterator, Sequence
from contextlib import contextmanager
from contextvars import ContextVar, Token
from typing import TYPE_CHECKING, Any, TypeVar

if TYPE_CHECKING:
    import httpx

logger = logging.getLogger(__name__)

T = TypeVar("T")

# Stable keys for JSON logs and future OTEL mapping (values are snake_case).
FIELD_CORRELATION_ID = "correlation_id"
FIELD_EVENT_TYPE = "event_type"
FIELD_COMPONENT = "component"
FIELD_TOOL_NAME = "tool_name"
FIELD_DURATION_MS = "duration_ms"
FIELD_OUTCOME = "outcome"
FIELD_ERROR_TYPE = "error_type"
FIELD_MESSAGE = "message"
FIELD_HMC_METHOD = "hmc_method"
FIELD_HMC_PATH = "hmc_path"
FIELD_HMC_STATUS = "hmc_status"
FIELD_HMC_ECHO_CORRELATION_ID = "hmc_echo_correlation_id"
FIELD_OPERATION = "operation"
FIELD_REASON = "reason"
FIELD_EXECUTE_REQUESTED = "execute_requested"
FIELD_TELEMETRY_EVENT = "telemetry_event"
FIELD_HMC_HOST = "hmc_host"
FIELD_HMC_API_VERSION_HINT = "hmc_api_version_hint"
FIELD_HMC_ALIAS = "hmc_alias"

# Stable outcomes for the `write_audit` event; consumed by log parsers / SIEM rules.
WRITE_AUDIT_OUTCOMES = frozenset({"denied", "dry_run", "authorized"})

# Stable outcomes/triggers for the `session_reauth` event (B2-4); SIEM rules pin on these.
SESSION_REAUTH_OUTCOMES: frozenset[str] = frozenset({"success", "failure"})
SESSION_REAUTH_TRIGGERS: frozenset[str] = frozenset({"401_mid_request"})

# Stable field name for the `session_reauth.trigger` slot.
FIELD_TRIGGER = "trigger"

_CORRELATION_ID: ContextVar[str | None] = ContextVar("power_hmc_mcp_correlation_id", default=None)
_ACTIVE_HMC_ALIAS: ContextVar[str | None] = ContextVar("power_hmc_mcp_hmc_alias", default=None)
_json_logs: bool = False

OTEL_AVAILABLE = False
try:
    from opentelemetry import metrics, trace

    OTEL_AVAILABLE = True
except ImportError:
    pass

_otel_ready = False
_otel_counters: dict[str, Any] = {}
_otel_lock = threading.Lock()
_otel_shutdown_registered = False
_tracer_provider: Any = None
_meter_provider: Any = None

# Collapse HMC resource IDs in metric labels (spans keep the full path).
_ROUTE_FAMILY_ANCHORS = (
    "ManagedSystem",
    "LogicalPartition",
    "PartitionProfile",
    "Processor",
    "VirtualEthernetAdapter",
)


def configure_observability(*, json_logs: bool) -> None:
    """Configure log emission style for this process (called from configure_logging)."""
    global _json_logs
    _json_logs = json_logs


def _emit_log(level: int, payload: dict[str, Any]) -> None:
    if _json_logs:
        logger.log(level, json.dumps(payload, default=str))
        return
    et = payload.get(FIELD_EVENT_TYPE, "event")
    cid = payload.get(FIELD_CORRELATION_ID, "")
    tail = {k: v for k, v in payload.items() if k not in (FIELD_EVENT_TYPE, FIELD_CORRELATION_ID)}
    logger.log(level, "%s correlation_id=%s %s", et, cid, tail)


def get_correlation_id() -> str | None:
    """Return the active correlation ID for this context, if any."""
    return _CORRELATION_ID.get()


def get_active_hmc_alias() -> str | None:
    """Return the active HMC alias bound by :func:`mcp_tool_call`, if any."""
    return _ACTIVE_HMC_ALIAS.get()


def set_correlation_id(value: str | None) -> Token[str | None]:
    """Set correlation ID; returns a token for reset()."""
    return _CORRELATION_ID.set(value)


def reset_correlation_id(token: Token[str | None]) -> None:
    _CORRELATION_ID.reset(token)


def new_correlation_id() -> str:
    return str(uuid.uuid4())


def ensure_correlation_id() -> str:
    """Return existing correlation ID or create and bind a new one."""
    existing = get_correlation_id()
    if existing:
        return existing
    cid = new_correlation_id()
    set_correlation_id(cid)
    return cid


@contextmanager
def correlation_scope(correlation_id: str | None = None) -> Iterator[str]:
    """Bind a correlation ID for the duration of the context manager."""
    cid = correlation_id or new_correlation_id()
    token = set_correlation_id(cid)
    try:
        yield cid
    finally:
        reset_correlation_id(token)


def base_log_fields(*, event_type: str, **extra: Any) -> dict[str, Any]:
    """Build a dict of standard fields for structured logging."""
    fields: dict[str, Any] = {
        FIELD_EVENT_TYPE: event_type,
        FIELD_COMPONENT: "power_hmc_mcp",
        FIELD_CORRELATION_ID: ensure_correlation_id(),
    }
    fields.update(extra)
    return fields


def _effective_hmc_alias(hmc_alias: str | None) -> str | None:
    return hmc_alias if hmc_alias is not None else get_active_hmc_alias()


def log_tool_start(tool_name: str, *, hmc_alias: str | None = None) -> None:
    extra: dict[str, Any] = {}
    if hmc_alias is not None:
        extra[FIELD_HMC_ALIAS] = hmc_alias
    _emit_log(
        logging.INFO,
        base_log_fields(event_type="mcp_tool_start", tool_name=tool_name, **extra),
    )


def log_tool_end(
    tool_name: str,
    *,
    outcome: str,
    duration_ms: float,
    error_type: str | None = None,
    hmc_alias: str | None = None,
) -> None:
    payload = base_log_fields(
        event_type="mcp_tool_end",
        tool_name=tool_name,
        outcome=outcome,
        duration_ms=round(duration_ms, 3),
    )
    if error_type:
        payload[FIELD_ERROR_TYPE] = error_type
    if hmc_alias is not None:
        payload[FIELD_HMC_ALIAS] = hmc_alias
    _emit_log(logging.INFO, payload)


def log_hmc_request_start(method: str, path: str) -> None:
    _emit_log(
        logging.DEBUG,
        base_log_fields(
            event_type="hmc_request_start",
            hmc_method=method,
            hmc_path=path,
        ),
    )


_DEFAULT_ECHO_HEADERS: tuple[str, ...] = ("X-Transaction-ID", "X-Client-Correlator")


def log_hmc_request_end(
    method: str,
    path: str,
    *,
    status_code: int,
    duration_ms: float,
    outcome: str,
    response: httpx.Response | None = None,
    echo_headers: Sequence[str] = _DEFAULT_ECHO_HEADERS,
    hmc_alias: str | None = None,
) -> None:
    """Emit ``hmc_request_end``; walks ``echo_headers`` in order for the echo capture.

    The default fallback list (``X-Transaction-ID`` then ``X-Client-Correlator``)
    follows the IBM HMC REST API spec — ``X-Transaction-ID`` is the
    spec-defined correlation header, ``X-Client-Correlator`` is the
    optional V8+ alternative.  Per-firmware echo behaviour is
    ``[ASSUMED]`` until rows land in
    ``docs/hmc-compatibility.md`` 'Correlation Header Echo' —
    treat missing echoes as expected on uncaptured firmware.
    ``HmcSession`` passes
    ``(settings.hmc_correlation_echo_header, *settings.hmc_correlation_echo_fallback_headers)``
    so operators can override either via env vars.  When no header matches,
    ``hmc_echo_correlation_id`` is omitted from the log payload entirely
    (never emitted as ``None`` / empty string).
    """
    extra: dict[str, Any] = {}
    if response is not None:
        for header_name in echo_headers:
            echo = response.headers.get(header_name)
            if echo:
                extra[FIELD_HMC_ECHO_CORRELATION_ID] = echo
                break
    effective_alias = _effective_hmc_alias(hmc_alias)
    if effective_alias is not None:
        extra[FIELD_HMC_ALIAS] = effective_alias
    rounded_duration_ms = round(duration_ms, 3)
    _emit_log(
        logging.INFO,
        base_log_fields(
            event_type="hmc_request_end",
            hmc_method=method,
            hmc_path=path,
            hmc_status=status_code,
            duration_ms=rounded_duration_ms,
            outcome=outcome,
            **extra,
        ),
    )
    telemetry_attrs: dict[str, Any] = {
        FIELD_DURATION_MS: rounded_duration_ms,
        FIELD_HMC_METHOD: method,
        FIELD_HMC_PATH: path,
        FIELD_HMC_STATUS: status_code,
        FIELD_OUTCOME: outcome,
        FIELD_CORRELATION_ID: get_correlation_id(),
    }
    if effective_alias is not None:
        telemetry_attrs[FIELD_HMC_ALIAS] = effective_alias
    telemetry_hook("hmc.request", telemetry_attrs)


def _api_version_hint_fields(api_version_hint: str | None) -> dict[str, Any]:
    """Return a ``{FIELD_HMC_API_VERSION_HINT: hint}`` dict when ``hint`` is set.

    Returns an empty dict when ``api_version_hint`` is ``None`` so the
    field is omitted from the log payload entirely (not emitted as
    ``None`` / empty string). The hint is a logging annotation only —
    callers must not branch behavior on it without first consulting
    ``docs/hmc-compatibility.md``.
    """
    if not api_version_hint:
        return {}
    return {FIELD_HMC_API_VERSION_HINT: api_version_hint}


def log_logon_end(
    hmc_host: str,
    *,
    outcome: str,
    api_version_hint: str | None = None,
) -> None:
    """Emit a structured ``session_logon_end`` lifecycle event.

    Called from :meth:`HmcClient.login` on the success path, providing
    session-level visibility symmetric with :func:`log_logoff_end`. The
    HTTP-layer events (``hmc_request_start`` / ``hmc_request_end``) are still
    emitted separately; this event surfaces the higher-level session state.

    ``api_version_hint`` (from :data:`Settings.hmc_api_version_hint`,
    ``HMC_API_VERSION_HINT`` env) is included in the payload when set so
    log queries can be scoped by the operator-declared firmware band.
    See ``docs/hmc-compatibility.md`` — the hint is metadata, not a
    behavior switch.
    """
    _emit_log(
        logging.INFO,
        base_log_fields(
            event_type="session_logon_end",
            hmc_host=hmc_host,
            outcome=outcome,
            **_api_version_hint_fields(api_version_hint),
        ),
    )


def log_logoff_end(
    hmc_host: str,
    *,
    outcome: str,
    api_version_hint: str | None = None,
) -> None:
    """Emit a structured ``session_logoff_end`` lifecycle event.

    Called from :meth:`HmcClient.close` after the logoff attempt, whether
    successful or silent-failed, providing symmetric teardown observability.

    ``api_version_hint`` mirrors :func:`log_logon_end` so a single log
    query joining ``session_logon_end`` and ``session_logoff_end`` keeps
    the hint alongside both endpoints of the session.
    """
    _emit_log(
        logging.INFO,
        base_log_fields(
            event_type="session_logoff_end",
            hmc_host=hmc_host,
            outcome=outcome,
            **_api_version_hint_fields(api_version_hint),
        ),
    )


def log_session_reauth(
    *,
    outcome: str,
    hmc_host: str,
    trigger: str,
    hmc_alias: str | None = None,
) -> None:
    """Emit a ``session_reauth`` event (B2-4).

    Fired by :class:`~power_hmc_mcp.session.HmcSession` after a 401 mid-request
    triggers a re-login attempt.  Emits ``outcome="success"`` after each
    successful re-login, and ``outcome="failure"`` before raising
    :class:`HmcAuthError` on the terminal branch (re-auth exhausted or
    immediately rejected when ``HMC_MAX_REAUTH_ATTEMPTS=0``).

    Keep this distinct from the ``hmc_request_end outcome="auth_retry"`` event
    (which lives on the request, not the session) so SIEM rules can pin on
    ``event_type=session_reauth`` for session-recovery alerting.
    """
    if outcome not in SESSION_REAUTH_OUTCOMES:
        raise ValueError(
            "session_reauth outcome must be one of "
            f"{sorted(SESSION_REAUTH_OUTCOMES)}; got {outcome!r}",
        )
    if trigger not in SESSION_REAUTH_TRIGGERS:
        raise ValueError(
            "session_reauth trigger must be one of "
            f"{sorted(SESSION_REAUTH_TRIGGERS)}; got {trigger!r}",
        )
    effective_alias = _effective_hmc_alias(hmc_alias)
    extra: dict[str, Any] = {FIELD_TRIGGER: trigger}
    if effective_alias is not None:
        extra[FIELD_HMC_ALIAS] = effective_alias
    _emit_log(
        logging.INFO,
        base_log_fields(
            event_type="session_reauth",
            hmc_host=hmc_host,
            outcome=outcome,
            **extra,
        ),
    )
    telemetry_attrs: dict[str, Any] = {
        FIELD_HMC_HOST: hmc_host,
        FIELD_OUTCOME: outcome,
        FIELD_TRIGGER: trigger,
        FIELD_CORRELATION_ID: get_correlation_id(),
    }
    if effective_alias is not None:
        telemetry_attrs[FIELD_HMC_ALIAS] = effective_alias
    telemetry_hook("session.reauth", telemetry_attrs)


def log_write_audit(
    *,
    tool_name: str,
    operation: str,
    outcome: str,
    reason: str,
    execute_requested: bool,
) -> None:
    """Emit a single ``write_audit`` event with the canonical schema.

    Fired from the write-tool decorator on every code path (denied, dry_run,
    authorized), so a denied write attempt is never silent. The schema is
    stable: log parsers and SIEM rules can pin on these fields.

    Required fields: ``correlation_id`` (auto-bound), ``event_type=write_audit``,
    ``component``, ``tool_name``, ``operation``, ``outcome``, ``reason``,
    ``execute_requested``. Outcome values are constrained to
    :data:`WRITE_AUDIT_OUTCOMES`.
    """
    if outcome not in WRITE_AUDIT_OUTCOMES:
        raise ValueError(
            f"write_audit outcome must be one of {sorted(WRITE_AUDIT_OUTCOMES)}; got {outcome!r}",
        )
    _emit_log(
        logging.INFO,
        base_log_fields(
            event_type="write_audit",
            tool_name=tool_name,
            operation=operation,
            outcome=outcome,
            reason=reason,
            execute_requested=execute_requested,
        ),
    )
    telemetry_hook(
        "write_audit",
        {
            FIELD_TOOL_NAME: tool_name,
            FIELD_OPERATION: operation,
            FIELD_OUTCOME: outcome,
            FIELD_REASON: reason,
            FIELD_EXECUTE_REQUESTED: execute_requested,
            FIELD_CORRELATION_ID: ensure_correlation_id(),
        },
    )


def format_traceparent(trace_id: int, span_id: int, trace_flags: int) -> str:
    """Format a W3C traceparent header value from OpenTelemetry span context parts."""
    return f"00-{trace_id:032x}-{span_id:016x}-{trace_flags:02x}"


def inject_outbound_trace_headers(headers: dict[str, str]) -> None:
    """Inject W3C ``traceparent`` when an active OpenTelemetry span is valid.

    ``X-Transaction-ID`` is injected separately by :class:`HmcSession` — this
    helper is additive and does not replace IBM's correlation header.
    """
    if not OTEL_AVAILABLE:
        return
    span_context = trace.get_current_span().get_span_context()
    if not span_context.is_valid:
        return
    headers["traceparent"] = format_traceparent(
        span_context.trace_id,
        span_context.span_id,
        span_context.trace_flags,
    )


def _emit_mcp_tool_telemetry(
    tool_name: str,
    *,
    outcome: str,
    error_type: str | None = None,
    hmc_alias: str | None = None,
) -> None:
    telemetry_attrs: dict[str, Any] = {
        FIELD_TOOL_NAME: tool_name,
        FIELD_OUTCOME: outcome,
        FIELD_CORRELATION_ID: get_correlation_id(),
    }
    if error_type:
        telemetry_attrs[FIELD_ERROR_TYPE] = error_type
    if hmc_alias is not None:
        telemetry_attrs[FIELD_HMC_ALIAS] = hmc_alias
    telemetry_hook("mcp.tool", telemetry_attrs)


def mcp_tool_call(
    tool_name: str,
    fn: Callable[[], T],
    *,
    hmc_alias: str | None = None,
) -> T:
    """Run a tool body with correlation ID and start/end logging.

    ``hmc_alias`` (D5) — when supplied, propagates onto both
    ``mcp_tool_start`` and ``mcp_tool_end`` so SIEM / dashboards can
    pivot on the target HMC. ``None`` is a no-op (backward compatible
    with single-HMC deployments).
    """
    ensure_correlation_id()
    alias_token = _ACTIVE_HMC_ALIAS.set(hmc_alias)
    log_tool_start(tool_name, hmc_alias=hmc_alias)
    start = time.perf_counter()
    try:
        result = fn()
    except Exception as exc:
        duration_ms = (time.perf_counter() - start) * 1000
        log_tool_end(
            tool_name,
            outcome="error",
            duration_ms=duration_ms,
            error_type=type(exc).__name__,
            hmc_alias=hmc_alias,
        )
        _emit_mcp_tool_telemetry(
            tool_name,
            outcome="error",
            error_type=type(exc).__name__,
            hmc_alias=hmc_alias,
        )
        raise
    finally:
        _ACTIVE_HMC_ALIAS.reset(alias_token)
    duration_ms = (time.perf_counter() - start) * 1000
    log_tool_end(
        tool_name,
        outcome="success",
        duration_ms=duration_ms,
        hmc_alias=hmc_alias,
    )
    _emit_mcp_tool_telemetry(tool_name, outcome="success", hmc_alias=hmc_alias)
    return result


def _emit_telemetry_stub(event_name: str, attributes: dict[str, Any]) -> None:
    _emit_log(
        logging.DEBUG,
        base_log_fields(
            event_type="telemetry_stub",
            telemetry_event=event_name,
            **attributes,
        ),
    )


def _init_otel_providers(endpoint: str) -> None:
    """Build and register OTLP trace + metric providers (call under ``_otel_lock``)."""
    global _otel_ready, _tracer_provider, _meter_provider

    from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    resource = Resource.create({"service.name": "power-hmc-mcp"})
    _tracer_provider = TracerProvider(resource=resource)
    _tracer_provider.add_span_processor(
        BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint)),
    )
    trace.set_tracer_provider(_tracer_provider)

    reader = PeriodicExportingMetricReader(OTLPMetricExporter(endpoint=endpoint))
    _meter_provider = MeterProvider(resource=resource, metric_readers=[reader])
    metrics.set_meter_provider(_meter_provider)
    _otel_ready = True


def _ensure_otel() -> bool:
    """Lazy-init OTLP trace + metric providers when configured."""
    global _otel_shutdown_registered
    if not OTEL_AVAILABLE:
        return False
    endpoint = os.environ.get("HMC_OTEL_ENDPOINT", "").strip()
    if not endpoint:
        return False
    if _otel_ready:
        return True
    with _otel_lock:
        if _otel_ready:
            return True
        _init_otel_providers(endpoint)
        if not _otel_shutdown_registered:
            atexit.register(_shutdown_otel)
            _otel_shutdown_registered = True
    return True


def _shutdown_otel() -> None:
    """Flush and shut down OTEL providers on process exit (best-effort)."""
    global _otel_ready, _tracer_provider, _meter_provider
    if not _otel_ready:
        return
    for provider in (_tracer_provider, _meter_provider):
        if provider is None:
            continue
        try:
            provider.force_flush(timeout_millis=5000)
        except Exception:
            logger.exception("OTEL provider force_flush failed during shutdown")
        try:
            provider.shutdown()
        except Exception:
            logger.exception("OTEL provider shutdown failed")
    _tracer_provider = None
    _meter_provider = None
    _otel_ready = False
    _otel_counters.clear()


def _otel_attribute_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def _route_family_for_metrics(path: str) -> str:
    """Normalize ``hmc_path`` for counter labels — aligns with SLI route-family rollups."""
    normalized = path
    for anchor in _ROUTE_FAMILY_ANCHORS:
        normalized = re.sub(rf"/{anchor}/[^/]+", rf"/{anchor}/{{id}}", normalized)
    return normalized


def _span_attributes(attributes: dict[str, Any]) -> dict[str, Any]:
    return {key: _otel_attribute_value(val) for key, val in attributes.items() if val is not None}


def _counter_attributes(attributes: dict[str, Any]) -> dict[str, Any]:
    # Counter labels stay bounded: omit per-request correlation_id; collapse hmc_path IDs.
    counter_attrs = {
        key: _otel_attribute_value(val)
        for key, val in attributes.items()
        if val is not None and key != FIELD_CORRELATION_ID
    }
    if FIELD_HMC_PATH in counter_attrs:
        counter_attrs[FIELD_HMC_PATH] = _route_family_for_metrics(
            str(counter_attrs[FIELD_HMC_PATH]),
        )
    return counter_attrs


def _export_otel(event_name: str, attributes: dict[str, Any]) -> None:
    from opentelemetry import metrics, trace

    span_attrs = _span_attributes(attributes)
    counter_attrs = _counter_attributes(attributes)
    tracer = trace.get_tracer(__name__)
    with tracer.start_as_current_span(event_name) as span:
        for key, val in span_attrs.items():
            span.set_attribute(key, val)

    meter = metrics.get_meter(__name__)
    counter_name = f"{event_name}.count"
    counter = _otel_counters.get(counter_name)
    if counter is None:
        counter = meter.create_counter(counter_name)
        _otel_counters[counter_name] = counter
    counter.add(1, counter_attrs)


def telemetry_hook(event_name: str, attributes: dict[str, Any] | None = None) -> None:
    """Export OpenTelemetry span + counter when configured; else DEBUG stub.

    When ``HMC_OTEL_ENDPOINT`` is set and ``opentelemetry`` is installed
    (``pip install power-hmc-mcp[otel]``), emits an OTLP span named
    ``event_name`` and a counter named ``event_name + ".count"``.
    Otherwise falls back to a DEBUG ``telemetry_stub`` log event so
    zero-config deployments stay safe.
    """
    attrs = attributes or {}
    if _ensure_otel():
        _export_otel(event_name, attrs)
        return
    _emit_telemetry_stub(event_name, attrs)
