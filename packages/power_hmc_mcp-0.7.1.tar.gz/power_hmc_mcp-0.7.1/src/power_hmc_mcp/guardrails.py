"""Write-operation guardrails: decisions, capability tokens, and stable response shapes.

This module is **framework-agnostic** (no FastMCP imports). The MCP-facing
decorator and audit log emission live in `power_hmc_mcp.tools.write`; the
write-tool body in `tools/<name>.py` is the only intended caller of
`run_write_tool`, which is the only intended caller of the private
authorization issuer below.

Structural property (Phase A tightening):

* Direct construction of :class:`WriteAuthorization` raises ``ValueError`` —
  the sentinel object is module-private and cannot be obtained from outside.
* :class:`HmcClient` write methods require a :class:`WriteAuthorization`
  parameter (no ``execute: bool`` fallback), so the type system makes
  ``client.start_lpar(..., execute=True)`` unreachable.
* The audit envelope is emitted from the decorator on every code path
  (denied / dry-run / authorized), so a denied write attempt is never silent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from power_hmc_mcp.config import Settings

PHASE_A_WRITE_SCAFFOLD_MESSAGE = (
    "Phase A scaffold: no HMC mutation was performed. This response previews "
    "what would be executed. Write execution lands in Phase C."
)
"""Stable message for placeholder execute responses and write-tool documentation."""

PHASE_A_WRITE_SCAFFOLD_DOC_PREFIX = (
    "[Phase A scaffold — no HMC mutation is performed. Returns a preview of "
    "what would be executed. Write execution lands in Phase C.]"
)

_GUARDRAIL_SENTINEL: object = object()
"""Module-private witness object passed by :func:`_issue_authorization`.

Forgeries via direct constructor calls fail in :meth:`WriteAuthorization.__post_init__`
because the sentinel cannot be referenced from outside this module without
explicitly importing the underscore-prefixed name (a deliberate breach, not a
copy-paste mistake). ``cast()`` abuse can still bypass the dataclass entirely;
:class:`HmcClient` methods defend against that with a runtime ``isinstance``
check before performing any HMC mutation.
"""


@dataclass(frozen=True)
class WriteAuthorization:
    """Capability token proving a write attempt cleared :func:`check_write_allowed`.

    Instances are issued only by :func:`_issue_authorization`, which is only
    called by the write-tool decorator in ``power_hmc_mcp.tools.write``. The
    ``_sentinel`` field must equal the module-private :data:`_GUARDRAIL_SENTINEL`
    or construction raises.
    """

    operation: str
    correlation_id: str
    _sentinel: object = field(default=None, repr=False, compare=False)

    def __post_init__(self) -> None:
        if self._sentinel is not _GUARDRAIL_SENTINEL:
            raise ValueError(
                "WriteAuthorization must be issued by power_hmc_mcp.guardrails "
                "via the write-tool decorator; do not construct it directly.",
            )


@dataclass(frozen=True)
class GuardrailDecision:
    """Result of a guardrail check for a write operation."""

    allowed: bool
    reason: str
    dry_run: bool


def write_tools_enabled(settings: Settings) -> bool:
    """Return True when write tools are enabled in configuration."""
    return settings.hmc_enable_write_tools


def require_execute_flag(settings: Settings, execute: bool) -> GuardrailDecision:
    """Require an explicit execute flag when configured."""
    if settings.hmc_require_execute_flag and not execute:
        return GuardrailDecision(
            allowed=False,
            reason="execute flag is required for write operations",
            dry_run=True,
        )
    return GuardrailDecision(
        allowed=True,
        reason="execute flag satisfied",
        dry_run=not execute,
    )


def check_write_allowed(settings: Settings, *, execute: bool) -> GuardrailDecision:
    """Check whether a write operation is permitted."""
    if not write_tools_enabled(settings):
        return GuardrailDecision(
            allowed=False,
            reason=_REASON_WRITES_DISABLED,
            dry_run=True,
        )
    if execute and not settings.hmc_writes_enabled:
        return GuardrailDecision(
            allowed=False,
            reason=_REASON_LIVE_WRITES_DISABLED,
            dry_run=True,
        )
    return require_execute_flag(settings, execute)


_REASON_WRITES_DISABLED = "write tools are disabled by configuration"
_REASON_LIVE_WRITES_DISABLED = "live write mutations are disabled (HMC_WRITES_ENABLED=false)"
_REASON_EXECUTE_REQUIRED = "execute flag is required for write operations"

_SUGGESTED_NEXT_STEP_WRITES_DISABLED = (
    "Set HMC_ENABLE_WRITE_TOOLS=true, restart the MCP server, then retry with execute=true."
)
_SUGGESTED_NEXT_STEP_LIVE_WRITES_DISABLED = (
    "Set HMC_WRITES_ENABLED=true in production only after operator approval, "
    "then retry with execute=true."
)
_SUGGESTED_NEXT_STEP_EXECUTE_REQUIRED = (
    "Pass execute=true after operator review, "
    "or call with execute=false for a dry-run preview only."
)
_SUGGESTED_NEXT_STEP_DRY_RUN = (
    "Set execute=true to perform this operation, "
    "or review the operation and params above before proceeding."
)

_DENIAL_HINTS: dict[str, tuple[str, str]] = {
    _REASON_WRITES_DISABLED: (
        "writes_disabled",
        _SUGGESTED_NEXT_STEP_WRITES_DISABLED,
    ),
    _REASON_LIVE_WRITES_DISABLED: (
        "live_writes_disabled",
        _SUGGESTED_NEXT_STEP_LIVE_WRITES_DISABLED,
    ),
    _REASON_EXECUTE_REQUIRED: (
        "execute_required",
        _SUGGESTED_NEXT_STEP_EXECUTE_REQUIRED,
    ),
}


def dry_run_response(
    operation: str,
    params: dict[str, Any],
    *,
    reason: str | None = None,
) -> dict[str, Any]:
    """Return a stable dry-run response shape.

    Always includes ``suggested_next_step``: a deterministic hint the agent
    or operator can surface directly to guide the next action.  The hint
    differs for denied vs. preview-only outcomes.
    """
    denied = reason is not None
    if denied:
        denial_reason_code, suggested_next_step = _DENIAL_HINTS.get(
            reason or "",
            ("denied", _SUGGESTED_NEXT_STEP_EXECUTE_REQUIRED),
        )
        guardrail_outcome = "denied"
    else:
        denial_reason_code = None
        suggested_next_step = _SUGGESTED_NEXT_STEP_DRY_RUN
        guardrail_outcome = "preview"

    body: dict[str, Any] = {
        "dry_run": True,
        "operation": operation,
        "params": params,
        "message": reason or "Dry run only; no changes were made to the HMC",
        "suggested_next_step": suggested_next_step,
        "guardrail_outcome": guardrail_outcome,
    }
    if denial_reason_code is not None:
        body["denial_reason_code"] = denial_reason_code
    return body


def write_audit_envelope(
    operation: str,
    *,
    execute_requested: bool,
    preview: dict[str, Any],
    correlation_id: str | None = None,
) -> dict[str, Any]:
    """Stable audit placeholder embedded in placeholder execute responses.

    Decorator-emitted ``write_audit`` log events are the durable audit signal;
    this envelope is a convenience for inline inspection of the response body
    until a persistent audit sink lands (Phase E).
    """
    from power_hmc_mcp import observability

    return {
        "correlation_id": correlation_id or observability.get_correlation_id(),
        "operation": operation,
        "execute_requested": execute_requested,
        "hmc_request_preview": preview,
        "record_status": "placeholder",
    }


def placeholder_execute_response(
    operation: str,
    params: dict[str, Any],
    *,
    preview_method: str,
    preview_path: str,
    authorization: WriteAuthorization,
) -> dict[str, Any]:
    """Authorized-path placeholder body until IBM mutation payloads ship.

    Reachable only when the decorator has issued a :class:`WriteAuthorization`,
    so the signature requires one. Returns a stable ``executed=false`` shape
    with an embedded audit envelope (defense in depth alongside the
    decorator-emitted ``write_audit`` log event).
    """
    from power_hmc_mcp.serialize import ensure_json_serializable

    preview = {"method": preview_method, "path": preview_path}
    body: dict[str, Any] = {
        "dry_run": False,
        "executed": False,
        "placeholder": True,
        "operation": operation,
        "params": params,
        "message": PHASE_A_WRITE_SCAFFOLD_MESSAGE,
        "suggested_next_step": (
            "Phase A placeholder: this write will execute against the HMC in Phase C "
            "once IBM payload schemas are validated. No action required."
        ),
        "guardrail_outcome": "authorized_placeholder",
        "audit": write_audit_envelope(
            operation,
            execute_requested=True,
            preview=preview,
            correlation_id=authorization.correlation_id,
        ),
    }
    return ensure_json_serializable(body)


def _issue_authorization(*, operation: str, correlation_id: str) -> WriteAuthorization:
    """Issue a :class:`WriteAuthorization`. Only called by the write-tool decorator.

    Importing this underscore-prefixed name from outside ``tools.write`` is a
    deliberate breach of the structural guardrail — review accordingly.
    """
    return WriteAuthorization(
        operation=operation,
        correlation_id=correlation_id,
        _sentinel=_GUARDRAIL_SENTINEL,
    )
