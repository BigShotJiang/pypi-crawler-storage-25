"""MCP tool: list_partition_profiles."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.agent_output import wrap_list_response
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def list_partition_profiles(
        lpar_id: Annotated[
            str,
            Field(description="HMC REST UUID for the logical partition (from list_lpars)."),
        ],
        limit: Annotated[
            int | None,
            Field(
                description=(
                    "Maximum items to return. Omit to return the full list "
                    "(see summary.total_count). Use with offset for pagination."
                ),
            ),
        ] = None,
        offset: Annotated[
            int,
            Field(
                description="Number of items to skip before returning results (use with limit).",
                ge=0,
            ),
        ] = 0,
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """List saved configuration profiles for one LPAR. Read-only.

        Use when:
            - Reporting saved snapshots / configurations for an LPAR.
            - Collecting ``profile_name`` values before ``create_lpar_from_profile``.

        Do not use when:
            - You need LPAR run state — call ``get_lpar_status``.
            - You need live LPAR config — call ``get_lpar``.

        Returns:
            dict with ``items`` (list of profiles) and ``summary`` (counts and
            truncation metadata). Each item has at least ``id``, ``name``, and
            ``uri``. Use ``name`` as ``profile_name`` for ``create_lpar_from_profile``.
            ``items`` preserve HMC Atom feed order for that call (stable for offset
            pagination within one snapshot).

        Does not:
            - Mutate HMC state.
            - Create or apply profiles (write tool is Phase A scaffold).
        """
        client = resolver(hmc_alias)

        def run() -> dict[str, Any]:
            items = client.list_partition_profiles(lpar_id)
            return wrap_list_response(items, limit=limit, offset=offset)

        return mcp_tool_call("list_partition_profiles", run, hmc_alias=hmc_alias)
