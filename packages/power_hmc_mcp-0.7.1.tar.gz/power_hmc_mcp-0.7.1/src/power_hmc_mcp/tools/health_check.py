"""MCP tool: health_check."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def health_check(
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Verify MCP server and HMC connectivity without inventory leak. Read-only.

        Use when:
            - Pre-flight before a batch of read calls.
            - Diagnosing connectivity or auth problems cheaply.
            - Confirming the HMC session is still alive between agent steps.

        Do not use when:
            - You need managed system or LPAR names — call ``list_managed_systems``
              or ``list_lpars``.
            - You need utilization data — call ``get_capacity``.

        Returns:
            dict with ``status`` (``"ok"`` when healthy), ``hmc_host``,
            ``session_active`` (bool), ``managed_system_count`` (int, allowlist-aware).

        Does not:
            - Return inventory names or UUIDs.
            - Mutate HMC state.
        """
        client = resolver(hmc_alias)
        return mcp_tool_call(
            "health_check",
            client.health_check,
            hmc_alias=hmc_alias,
        )
