"""MCP tool: get_lpar_status."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def get_lpar_status(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        lpar_id: Annotated[
            str,
            Field(description="HMC REST UUID for the logical partition (from list_lpars)."),
        ],
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Return one LPAR's run state in raw and canonical form. Read-only.

        Use when:
            - Deciding the next action ("is this LPAR running?", "safe to start?").
            - Building a status summary for an operator UI.

        Do not use when:
            - You need full LPAR configuration — call ``get_lpar``.
            - You are enumerating many LPARs — call ``list_lpars`` then this tool
              per LPAR of interest.

        **Always branch on ``canonical_state``** — stable lowercase-underscore enum
        (``running``, ``not_activated``, ``open_firmware``, ``starting``, ``stopping``,
        ``error``, ``migrating``, ``hardware_discovery``, ``unknown``) — not on
        ``state`` (raw firmware string).

        Returns:
            dict with ``managed_system_id``, ``lpar_id``, ``source`` (``"uom"`` or
            ``"quick"``), ``name``, ``state``, ``canonical_state``, ``partition_id``,
            ``rmc_state``. When ``source`` is ``"uom"``, includes ``properties``.
            When ``source`` is ``"quick"`` (``HMC_LPAR_STATUS_SOURCE=quick``),
            includes ``raw_quick`` instead of ``properties``.

        Does not:
            - Mutate HMC state.
            - Start or stop the LPAR (write tools are separate and gated).
        """
        client = resolver(hmc_alias)
        return mcp_tool_call(
            "get_lpar_status",
            lambda: client.get_lpar_status(managed_system_id, lpar_id),
            hmc_alias=hmc_alias,
        )
