"""MCP tool: stop_lpar (registered only when ``HMC_ENABLE_WRITE_TOOLS=true``)."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.guardrails import PHASE_A_WRITE_SCAFFOLD_DOC_PREFIX, WriteAuthorization
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.write import (
    WRITE_TOOL_ANNOTATIONS,
    mark_write_tool,
    run_write_tool,
)


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    def stop_lpar(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        lpar_id: Annotated[
            str,
            Field(description="HMC REST UUID for the logical partition (from list_lpars)."),
        ],
        mode: Annotated[
            str,
            Field(
                description=(
                    "IBM-defined stop mode (placeholder until firmware-validated). "
                    'Default "normal".'
                ),
            ),
        ] = "normal",
        execute: Annotated[
            bool,
            Field(
                description=(
                    "When true, requests authorization to perform the operation. "
                    "Default false returns a dry-run preview only."
                ),
            ),
        ] = False,
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        client = resolver(hmc_alias)
        params = {
            "managed_system_id": managed_system_id,
            "lpar_id": lpar_id,
            "mode": mode,
        }

        def executor(authorization: WriteAuthorization) -> dict[str, Any]:
            return client.stop_lpar(
                managed_system_id,
                lpar_id,
                mode,
                authorization=authorization,
            )

        def run() -> dict[str, Any]:
            return run_write_tool(
                tool_name="stop_lpar",
                operation="stop_lpar",
                settings=client.settings,
                params=params,
                execute=execute,
                executor=executor,
            )

        return mcp_tool_call("stop_lpar", run, hmc_alias=hmc_alias)

    stop_lpar.__doc__ = (
        PHASE_A_WRITE_SCAFFOLD_DOC_PREFIX
        + """

        Stop an LPAR. Write-gated — requires execute=true when HMC_REQUIRE_EXECUTE_FLAG
        is set (default). Does not execute against the HMC in Phase A (placeholder only).

        Use when:
            - An operator has approved shutting down a specific LPAR.
            - Previewing what would be sent (execute=false dry-run).

        Do not use when:
            - You only need run state — call ``get_lpar_status`` (read-only).
            - Write tools are disabled — response includes ``denial_reason_code``.

        Returns:
            dict dry-run/denial/placeholder envelope with ``suggested_next_step``,
            ``guardrail_outcome``, and optional ``denial_reason_code``.

        Does not:
            - Mutate the HMC today (Phase A scaffold; Phase C wires real POST).
        """
    )
    mcp.tool(annotations=WRITE_TOOL_ANNOTATIONS)(mark_write_tool(stop_lpar))
