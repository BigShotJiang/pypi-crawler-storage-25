"""MCP tool: create_lpar_from_profile (registered only when ``HMC_ENABLE_WRITE_TOOLS=true``)."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.guardrails import PHASE_A_WRITE_SCAFFOLD_DOC_PREFIX, WriteAuthorization
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.write import (
    WRITE_TOOL_ANNOTATIONS,
    mark_write_tool,
    run_write_tool,
)


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    def create_lpar_from_profile(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        profile_name: Annotated[
            str,
            Field(description="Source partition profile name (from list_partition_profiles)."),
        ],
        new_lpar_name: Annotated[
            str,
            Field(description="Desired display name for the new LPAR."),
        ],
        overrides: Annotated[
            dict[str, Any] | None,
            Field(description="Optional IBM-specific override map (schema TBD in Phase C)."),
        ] = None,
        execute: Annotated[
            bool,
            Field(
                description=(
                    "When true, requests authorization to perform the operation. "
                    "Default false returns a dry-run preview only."
                ),
            ),
        ] = False,
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        client = resolver(hmc_alias)
        params = {
            "managed_system_id": managed_system_id,
            "profile_name": profile_name,
            "new_lpar_name": new_lpar_name,
            "overrides": overrides or {},
        }

        def executor(authorization: WriteAuthorization) -> dict[str, Any]:
            return client.create_lpar_from_profile(
                managed_system_id,
                profile_name,
                new_lpar_name,
                overrides,
                authorization=authorization,
            )

        def run() -> dict[str, Any]:
            return run_write_tool(
                tool_name="create_lpar_from_profile",
                operation="create_lpar_from_profile",
                settings=client.settings,
                params=params,
                execute=execute,
                executor=executor,
            )

        return mcp_tool_call("create_lpar_from_profile", run, hmc_alias=hmc_alias)

    create_lpar_from_profile.__doc__ = (
        PHASE_A_WRITE_SCAFFOLD_DOC_PREFIX
        + """

        Create an LPAR from a base profile. Write-gated — requires execute=true when
        HMC_REQUIRE_EXECUTE_FLAG is set (default). Does not execute against the HMC in
        Phase A (placeholder only).

        Use when:
            - An operator has approved creating a new LPAR from a saved profile.
            - Previewing params before execution (execute=false dry-run).

        Do not use when:
            - You only need profile names — call ``list_partition_profiles`` (read-only).
            - Write tools are disabled — response includes ``denial_reason_code``.

        Returns:
            dict dry-run/denial/placeholder envelope with ``suggested_next_step``,
            ``guardrail_outcome``, and optional ``denial_reason_code``.

        Does not:
            - Mutate the HMC today (Phase A scaffold; Phase C wires real POST).
        """
    )
    mcp.tool(annotations=WRITE_TOOL_ANNOTATIONS)(mark_write_tool(create_lpar_from_profile))
