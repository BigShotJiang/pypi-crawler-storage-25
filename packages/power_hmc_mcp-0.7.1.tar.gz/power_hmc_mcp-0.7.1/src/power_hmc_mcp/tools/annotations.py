"""Shared MCP tool metadata.

Annotations are MCP-spec hints surfaced to clients/agents during tool discovery.
They are advisory metadata only — they do not gate behaviour on this server
(real safety is enforced by ``run_write_tool`` / ``WriteAuthorization`` in
``write.py``).

``READ_ONLY`` is reused by every read tool in this package so behavioural hints
stay consistent for agents:

* ``readOnlyHint=True`` — the tool only reads HMC state, never mutates it.
* ``destructiveHint=False`` — no destructive effect even on repeat calls.
* ``idempotentHint=True`` — calling the tool again with the same arguments
  produces the same response shape (the underlying HMC state may have changed
  between calls; idempotence is on the tool semantics, not the system snapshot).
* ``openWorldHint=True`` — the tool's effects extend beyond the MCP server
  process: every call reaches the configured HMC over HTTPS. This lets agent
  platforms scope sandboxing / approval policy correctly (cannot be treated
  as a pure local function).
"""

from mcp.types import ToolAnnotations

READ_ONLY = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)
