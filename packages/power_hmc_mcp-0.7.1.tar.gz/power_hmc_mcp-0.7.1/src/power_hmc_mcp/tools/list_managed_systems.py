"""MCP tool: list_managed_systems."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.agent_output import wrap_list_response
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def list_managed_systems(
        limit: Annotated[
            int | None,
            Field(
                description=(
                    "Maximum items to return. Omit to return the full list "
                    "(see summary.total_count). Use with offset for pagination."
                ),
            ),
        ] = None,
        offset: Annotated[
            int,
            Field(
                description="Number of items to skip before returning results (use with limit).",
                ge=0,
            ),
        ] = 0,
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """List every Power server (managed system) this HMC controls. Read-only.

        Use when:
            - Starting an inventory walk and you need the catalogue of servers.
            - Picking a ``managed_system_id`` for ``list_lpars``, ``get_managed_system``,
              or ``get_capacity``.
            - Confirming which systems are visible after ``HMC_ALLOWED_MANAGED_SYSTEMS``
              is applied.

        Do not use when:
            - You need full server properties — call ``get_managed_system`` with one UUID.
            - You only need connectivity — call ``health_check`` (no inventory).

        Returns:
            dict with ``items`` (list of managed systems) and ``summary`` (counts,
            truncation metadata, ``state_counts``). Each item has at least ``id``,
            ``name``, ``state``, and ``uri``. ``items`` preserve HMC Atom feed order
            for that call (stable for offset pagination within one snapshot).

        Does not:
            - Mutate HMC state.
            - Return raw XML/Atom.
        """
        client = resolver(hmc_alias)

        def run() -> dict[str, Any]:
            items = client.list_managed_systems()
            return wrap_list_response(items, limit=limit, offset=offset, state_counts=True)

        return mcp_tool_call("list_managed_systems", run, hmc_alias=hmc_alias)
