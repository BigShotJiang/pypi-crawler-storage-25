"""MCP tool: list_lpars."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.agent_output import wrap_list_response
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def list_lpars(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        limit: Annotated[
            int | None,
            Field(
                description=(
                    "Maximum items to return. Omit to return the full list "
                    "(see summary.total_count). Use with offset for pagination."
                ),
            ),
        ] = None,
        offset: Annotated[
            int,
            Field(
                description="Number of items to skip before returning results (use with limit).",
                ge=0,
            ),
        ] = 0,
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """List every logical partition (VM) on one Power server. Read-only.

        Use when:
            - Enumerating LPARs on a specific managed system.
            - Picking an ``lpar_id`` for ``get_lpar``, ``get_lpar_status``, or
              ``list_partition_profiles``.

        Do not use when:
            - You need run-state decisions — call ``get_lpar_status`` and branch on
              ``canonical_state``, not on ``items[].state`` (raw firmware strings).
            - You need full LPAR configuration — call ``get_lpar``.

        Returns:
            dict with ``items`` (list of LPARs) and ``summary`` (counts,
            truncation metadata, ``state_counts`` by raw state string). Each item
            has at least ``id``, ``name``, ``state``, ``partition_id``, and ``uri``.
            ``items`` preserve HMC Atom feed order for that call (stable for offset
            pagination within one snapshot).

        Does not:
            - Mutate HMC state.
            - Return canonical run state (use ``get_lpar_status``).
        """
        client = resolver(hmc_alias)

        def run() -> dict[str, Any]:
            items = client.list_lpars(managed_system_id)
            return wrap_list_response(items, limit=limit, offset=offset, state_counts=True)

        return mcp_tool_call("list_lpars", run, hmc_alias=hmc_alias)
