"""MCP tool: get_managed_system."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def get_managed_system(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Return one Power server's full UOM details. Read-only.

        Use when:
            - You have a ``managed_system_id`` and need the full ``ManagedSystem``
              document (name, state, MTMS, processor pool fields).
            - Reporting system state before capacity or LPAR operations.

        Do not use when:
            - You only need the server catalogue — call ``list_managed_systems``.
            - You need LPAR inventory — call ``list_lpars``.

        Returns:
            dict with ``id``, ``name``, ``state``, ``uri``, and ``properties`` (string
            map of HMC-doc-aligned fields such as ``SystemName``, ``State``, ``MTMS``).

        Does not:
            - Mutate HMC state.
            - Return raw XML/Atom.
        """
        client = resolver(hmc_alias)
        return mcp_tool_call(
            "get_managed_system",
            lambda: client.get_managed_system(managed_system_id),
            hmc_alias=hmc_alias,
        )
