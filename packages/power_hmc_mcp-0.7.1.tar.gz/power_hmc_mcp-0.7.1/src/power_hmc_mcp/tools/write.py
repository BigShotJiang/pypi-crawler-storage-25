"""Structural guardrail for MCP write tools.

This module is the **only** intended caller of
:func:`power_hmc_mcp.guardrails._issue_authorization`. Together with the
required-:class:`WriteAuthorization` parameter on :class:`HmcClient` write
methods, it makes the dry-run / authorized split structural rather than
conventional:

* :func:`mark_write_tool` tags an MCP-registered tool body so the
  registration-time check in ``tools/__init__.py`` can verify, at server boot,
  that every member of ``WRITE_TOOL_NAMES`` is wired through this module.
* :func:`run_write_tool` is the only path that produces a
  :class:`WriteAuthorization`. It also emits a ``write_audit`` log event on
  every code path (denied / dry_run / authorized) so a denied write attempt is
  never silent.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from mcp.types import ToolAnnotations

from power_hmc_mcp.config import Settings
from power_hmc_mcp.guardrails import (
    WriteAuthorization,
    _issue_authorization,
    check_write_allowed,
    dry_run_response,
)
from power_hmc_mcp.observability import (
    ensure_correlation_id,
    log_write_audit,
)

WRITE_TOOL_MARKER = "__power_hmc_mcp_write_tool__"
"""Attribute name set by :func:`mark_write_tool` on guarded tool bodies."""

WRITE_TOOL_ANNOTATIONS = ToolAnnotations(readOnlyHint=False, destructiveHint=True)
"""Canonical ToolAnnotations for write tools (consistency across files)."""


def mark_write_tool(fn: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
    """Tag an MCP-registered tool body as a guarded write tool.

    Apply this decorator on every MCP-registered write-tool function. The
    registration-time validator in ``tools/__init__.py`` reads the marker on
    the FastMCP-stored callable and refuses to start the server if any name in
    ``WRITE_TOOL_NAMES`` is missing it. Forgetting the decorator is therefore
    a server-startup failure, not a runtime mutation risk.
    """
    setattr(fn, WRITE_TOOL_MARKER, True)
    return fn


def is_write_tool(fn: Any) -> bool:
    """Return True when ``fn`` was tagged by :func:`mark_write_tool`."""
    return getattr(fn, WRITE_TOOL_MARKER, False) is True


def run_write_tool(
    *,
    tool_name: str,
    operation: str,
    settings: Settings,
    params: dict[str, Any],
    execute: bool,
    executor: Callable[[WriteAuthorization], dict[str, Any]],
) -> dict[str, Any]:
    """Gate a write-tool body through the guardrail and emit the audit event.

    Three outcomes, all audited:

    * ``denied`` — guardrail refuses (write tools disabled, or
      ``HMC_REQUIRE_EXECUTE_FLAG=true`` and ``execute=False``). ``executor`` is
      not called; the dry-run envelope shape is returned with the denial reason.
    * ``dry_run`` — preview only (``execute=False`` with the require-flag off).
      ``executor`` is not called; the dry-run envelope is returned.
    * ``authorized`` — ``executor`` is invoked with a freshly-issued
      :class:`WriteAuthorization`. Its return value is the tool's response.

    The audit event (``log_write_audit``) is emitted before any return path,
    including denial.
    """
    decision = check_write_allowed(settings, execute=execute)
    correlation_id = ensure_correlation_id()

    if not decision.allowed:
        log_write_audit(
            tool_name=tool_name,
            operation=operation,
            outcome="denied",
            reason=decision.reason,
            execute_requested=execute,
        )
        return dry_run_response(operation, params, reason=decision.reason)

    if decision.dry_run:
        log_write_audit(
            tool_name=tool_name,
            operation=operation,
            outcome="dry_run",
            reason=decision.reason,
            execute_requested=execute,
        )
        return dry_run_response(operation, params)

    authorization = _issue_authorization(
        operation=operation,
        correlation_id=correlation_id,
    )
    log_write_audit(
        tool_name=tool_name,
        operation=operation,
        outcome="authorized",
        reason=decision.reason,
        execute_requested=execute,
    )
    return executor(authorization)
