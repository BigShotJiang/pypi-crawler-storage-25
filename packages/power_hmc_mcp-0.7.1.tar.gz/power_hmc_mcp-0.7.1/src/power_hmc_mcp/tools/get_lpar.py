"""MCP tool: get_lpar."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def get_lpar(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        lpar_id: Annotated[
            str,
            Field(description="HMC REST UUID for the logical partition (from list_lpars)."),
        ],
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Return one LPAR's full UOM document (config, processors, memory). Read-only.

        Use when:
            - You need complete LPAR configuration, not just run state.
            - Reporting processor/memory entitlements or partition type.

        Do not use when:
            - You only need run state — call ``get_lpar_status`` (smaller payload,
              includes ``canonical_state``).
            - You are walking inventory — call ``list_lpars`` first.

        Returns:
            dict with ``id``, ``name``, ``state``, ``partition_id``, ``uri``,
            ``managed_system_id``, and ``properties`` (HMC-doc-aligned fields).

        Does not:
            - Mutate HMC state.
            - Return canonical run-state enum (use ``get_lpar_status``).
        """
        client = resolver(hmc_alias)
        return mcp_tool_call(
            "get_lpar",
            lambda: client.get_lpar(managed_system_id, lpar_id),
            hmc_alias=hmc_alias,
        )
