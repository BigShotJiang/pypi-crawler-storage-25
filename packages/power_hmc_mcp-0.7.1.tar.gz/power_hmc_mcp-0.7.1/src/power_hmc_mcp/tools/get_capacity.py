"""MCP tool: get_capacity."""

from __future__ import annotations

from typing import Annotated, Any

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from power_hmc_mcp.config import CapacityOutputMode
from power_hmc_mcp.observability import mcp_tool_call
from power_hmc_mcp.pool import ClientResolver
from power_hmc_mcp.tools.annotations import READ_ONLY


def register(mcp: FastMCP, resolver: ClientResolver) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def get_capacity(
        managed_system_id: Annotated[
            str,
            Field(description="HMC REST UUID for the managed system (from list_managed_systems)."),
        ],
        mode: Annotated[
            CapacityOutputMode,
            Field(
                description=(
                    'Output shape: "summary" for a small payload (counts/recency), '
                    '"metadata" for normalized sample entries (default), '
                    '"full" raises until Phase B wires metric JSON retrieval.'
                ),
            ),
        ] = "metadata",
        hmc_alias: Annotated[
            str | None,
            Field(
                description=(
                    "HMC alias when HMC_REGISTRY declares multiple HMCs. "
                    "Omit for the default alias."
                ),
            ),
        ] = None,
    ) -> dict[str, Any]:
        """Return PCM utilization samples for one Power server. Read-only.

        Use when:
            - Answering "how busy is this server?" — prefer ``mode="summary"`` for
              a conversation-safe payload.
            - Building a capacity view — ``mode="metadata"`` returns normalized sample
              entries (HMC query is bounded to one sample window per call).
            - Verifying PCM is enabled (check ``pcm_enabled``).

        Do not use when:
            - You need raw metric JSON — ``mode="full"`` is not wired yet.
            - You need LPAR-level detail — call ``get_lpar`` or ``get_lpar_status``.

        Returns:
            dict with ``managed_system_id``, ``mode``, ``window_start_ts``,
            ``pcm_enabled``, and either ``samples`` (``metadata``) or ``summary``
            (``summary`` mode).

        Does not:
            - Mutate HMC state.
            - Embed raw Atom/XML.
        """
        client = resolver(hmc_alias)
        return mcp_tool_call(
            "get_capacity",
            lambda: client.get_capacity(managed_system_id, mode=mode),
            hmc_alias=hmc_alias,
        )
