"""HTTP liveness/readiness probes mounted on the FastMCP custom_route surface.

Probes are **opt-in**: registered only when ``HMC_MCP_HTTP_PROBES_PATH`` is
non-empty AND the streamable-HTTP transport is selected. They MUST NOT
appear in MCP audit logs or correlation-id event streams — the audit pipeline
keys on tool_name and is unrelated to probe traffic. We deliberately do not
emit ``mcp_tool_call`` events for probes; only a debug-level structured log
that operators can opt into.

Semantics:

* ``/healthz`` — process liveness. Returns 200 unless the process is hard
  down (in which case the listener is down too and the probe times out at
  the L7). Demo mode is "live" — it just doesn't talk to HMC.

* ``/readyz`` — readiness to serve real HMC traffic. Returns 200 only if
  ``HmcClient.is_authenticated()`` is True (or demo mode is on, in which
  case readiness is "yes, demo is up"). Returns 503 with a JSON body
  describing the not-ready reason otherwise; this is the signal Kubernetes
  / operator runbooks should take action on.

Mount semantics (lifecycle):

The probes are registered before ``mcp.run()`` so they are part of the
Starlette app FastMCP builds for the streamable-HTTP transport. They are
NOT registered when transport=stdio — there is no HTTP listener.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from starlette.requests import Request
from starlette.responses import JSONResponse, Response

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from power_hmc_mcp.config import Settings
    from power_hmc_mcp.provider import HmcProvider

logger = logging.getLogger(__name__)

ProbeHandler = Callable[[Request], Awaitable[Response]]


def _probe_paths(probes_root: str) -> tuple[str, str]:
    """Resolve the (healthz, readyz) absolute paths for a given probes prefix.

    ``"/"`` mounts at the listener root. Any other value is treated as a
    prefix: ``"/admin"`` -> ``"/admin/healthz"`` / ``"/admin/readyz"``.
    """
    root = probes_root.rstrip("/") or "/"
    if root == "/":
        return "/healthz", "/readyz"
    return f"{root}/healthz", f"{root}/readyz"


async def _healthz(_request: Request) -> Response:
    return JSONResponse({"status": "ok"})


def _build_readyz_handler(
    client: HmcProvider,
    settings: Settings,
) -> ProbeHandler:
    """Bind a readyz handler to the live provider + Settings.

    The closure captures ``client`` rather than re-resolving via globals, so
    later D5 multi-HMC pools can replace the binding cleanly.
    """

    async def _readyz(_request: Request) -> Response:
        if settings.hmc_demo_mode:
            return JSONResponse(
                {"status": "ready", "mode": "demo", "hmc_host": settings.hmc_host},
            )
        if client.is_authenticated():
            return JSONResponse(
                {"status": "ready", "hmc_host": settings.hmc_host},
            )
        body = {
            "status": "not-ready",
            "reason": "no-active-hmc-session",
            "hmc_host": settings.hmc_host,
        }
        return Response(
            content=json.dumps(body),
            media_type="application/json",
            status_code=503,
        )

    return _readyz


def register_probes(
    mcp: FastMCP,
    client: HmcProvider,
    settings: Settings,
) -> tuple[str, str] | None:
    """Register ``/healthz`` and ``/readyz`` on the FastMCP custom-route surface.

    Returns the registered ``(healthz_path, readyz_path)`` pair, or ``None``
    if probes are disabled. Caller is responsible for transport gating —
    this function does not check ``hmc_mcp_transport`` itself, so it can
    stay test-friendly.
    """
    if not settings.hmc_mcp_http_probes_path:
        return None

    healthz_path, readyz_path = _probe_paths(settings.hmc_mcp_http_probes_path)

    mcp.custom_route(healthz_path, methods=["GET"], include_in_schema=False)(_healthz)
    mcp.custom_route(readyz_path, methods=["GET"], include_in_schema=False)(
        _build_readyz_handler(client, settings),
    )

    logger.info(
        "registered HTTP probes: healthz=%s readyz=%s (transport=%s)",
        healthz_path,
        readyz_path,
        settings.hmc_mcp_transport,
    )
    return healthz_path, readyz_path
