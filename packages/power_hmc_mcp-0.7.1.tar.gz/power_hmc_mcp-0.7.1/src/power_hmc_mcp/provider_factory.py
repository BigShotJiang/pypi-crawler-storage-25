"""Factory for backend provider selection (Phase J)."""

from __future__ import annotations

from power_hmc_mcp.config import Settings
from power_hmc_mcp.provider import HmcProvider

__all__ = ["create_provider"]


def create_provider(settings: Settings) -> HmcProvider:
    """Instantiate and return the configured provider.

    HMC_PROVIDER=hmc (default) → HmcClient
    HMC_PROVIDER=demo          → DemoProvider (alias for HMC_DEMO_MODE=true)
    HMC_PROVIDER=powervs       → PowerVSProvider (stub, raises on use)

    When ``HMC_DEMO_MODE=true`` and ``HMC_PROVIDER=hmc`` (the CI default),
    returns :class:`~power_hmc_mcp.demo_provider.DemoProvider` for backward
    compatibility.
    """
    if settings.hmc_demo_mode and settings.hmc_provider == "hmc":
        from power_hmc_mcp.demo_provider import DemoProvider

        return DemoProvider(settings)

    match settings.hmc_provider:
        case "hmc":
            from power_hmc_mcp.hmc_client import HmcClient

            return HmcClient(settings)
        case "demo":
            from power_hmc_mcp.demo_provider import DemoProvider

            return DemoProvider(settings)
        case "powervs":
            from power_hmc_mcp.powervs_provider import PowerVSProvider

            return PowerVSProvider(settings)
        case _:
            raise ValueError(
                f"Unknown HMC_PROVIDER={settings.hmc_provider!r}. Valid values: hmc, demo, powervs",
            )
