"""JSON serialization helpers for MCP tool outputs."""

from __future__ import annotations

import json
from typing import Any, TypeVar

T = TypeVar("T")


def drop_none(data: dict[str, Any]) -> dict[str, Any]:
    """Remove keys with None values for stable JSON output."""
    return {key: value for key, value in data.items() if value is not None}


def ensure_json_serializable(obj: T) -> T:
    """Raise TypeError if obj is not JSON-serializable."""
    json.dumps(obj)
    return obj
