"""Agent-facing normalization helpers: convert raw HMC XML/Atom data into
stable MCP-facing shapes. No HTTP, no auth, no side effects.

LPAR state string mapping (B2-1)
================================
Each raw HMC string mapped by :data:`_LPAR_STATE_CANONICAL` is annotated
``[VALIDATED vN]`` or ``[ASSUMED]``.  See
``docs/hmc-compatibility.md`` 'LPAR State Strings' table for capture
records.  **[RISK]** Strings marked ``[ASSUMED]`` have not been verified
against real firmware.  Do not remove ``[RISK]`` / ``[ASSUMED]``
annotations here without a corresponding row update in the compatibility
doc.

Canonical key  →  raw HMC strings (case-insensitive match):

* ``running``            ← ``"Running"``             ``[ASSUMED]``
* ``not_activated``      ← ``"Not Activated"``        ``[ASSUMED]``
* ``open_firmware``      ← ``"Open Firmware"``        ``[ASSUMED]``
* ``starting``           ← ``"Starting"``             ``[ASSUMED]``
* ``stopping``           ← ``"Stopping"``             ``[ASSUMED]``
* ``error``              ← ``"Error"``                ``[ASSUMED]``
* ``migrating``          ← ``"Migrating"``            ``[ASSUMED]``
* ``hardware_discovery`` ← ``"Hardware Discovery"``   ``[ASSUMPTION]`` may
  also appear as ``"Hardware discovery"`` (one capitalized word)
* ``unknown``            ← ``"Unknown"`` + any unseen string (fallback)

PCM Atom feed rel attributes (B2-6)
====================================
PCM Atom feed parsing assumes the following ``rel`` attribute values.
Each is annotated ``[VALIDATED]`` or ``[ASSUMED]``.  See
``docs/hmc-compatibility.md`` 'PCM Atom Feed rel Attributes' for capture
records.

* ``related``   — links to the PCM metric JSON resource  ``[ASSUMED]``
* ``enclosure`` — encapsulates the metrics payload       ``[ASSUMED]``
* IBM-custom rel values are added as observed.
"""

from __future__ import annotations

from typing import Any

from power_hmc_mcp.serialize import drop_none

# Canonical LPAR state map (case-insensitive).  All entries currently [ASSUMED]
# — see module docstring and docs/hmc-compatibility.md before promoting any to
# [VALIDATED vN].
_LPAR_STATE_CANONICAL: dict[str, str] = {
    "running": "running",
    "not activated": "not_activated",
    "open firmware": "open_firmware",
    "starting": "starting",
    "stopping": "stopping",
    "error": "error",
    "migrating": "migrating",
    "hardware discovery": "hardware_discovery",
    "unknown": "unknown",
}


def normalize_lpar_state(raw: str | None) -> str | None:
    """Normalize a raw HMC LPAR state string to a canonical key.

    Returns ``None`` only when ``raw`` is ``None`` (the property was absent
    from the HMC response).  Any unrecognized non-``None`` string maps to
    ``"unknown"`` — this function never raises and never returns an unmapped
    value.  See :data:`_LPAR_STATE_CANONICAL` and the module docstring for
    the full mapping and annotation status.
    """
    if raw is None:
        return None
    return _LPAR_STATE_CANONICAL.get(raw.strip().lower(), "unknown")


def normalize_pcm_samples_for_agent(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Stable MCP-facing sample metadata (Atom terminology hidden where practical)."""
    out: list[dict[str, Any]] = []
    for item in samples:
        out.append(
            drop_none(
                {
                    "sample_id": item.get("id"),
                    "category": item.get("category"),
                    "updated": item.get("updated"),
                    "metrics_href": item.get("link_href"),
                    "title": item.get("title"),
                },
            ),
        )
    return out


def pcm_summary(samples: list[dict[str, Any]]) -> dict[str, Any]:
    categories: dict[str, int] = {}
    latest_updated: str | None = None
    for item in samples:
        cat = item.get("category") or "unknown"
        categories[cat] = categories.get(cat, 0) + 1
        u = item.get("updated")
        if isinstance(u, str) and (latest_updated is None or u > latest_updated):
            latest_updated = u
    return {
        "sample_count": len(samples),
        "categories": categories,
        "latest_updated": latest_updated,
    }


def normalize_resource(
    resource_id: str,
    properties: dict[str, str],
    *,
    uri: str | None = None,
) -> dict[str, Any]:
    # Field-key provenance:
    # [VALIDATED — IBM Docs Power9/10/11] ``SystemName`` / ``State`` from the
    # Power10 ManagedSystem Quick properties table
    # (https://www.ibm.com/docs/en/power10?topic=apis-managed-system) and
    # ``PartitionName`` / ``PartitionState`` / ``PartitionID`` from the
    # Power11 LogicalPartition Quick properties table
    # (https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition).
    # The enumerated **string values** carried in ``state`` remain
    # firmware-dependent — see ``_LPAR_STATE_CANONICAL`` and
    # ``docs/hmc-compatibility.md`` 'LPAR State Strings'.
    return drop_none(
        {
            "id": resource_id,
            "name": properties.get("SystemName") or properties.get("PartitionName"),
            "state": properties.get("State") or properties.get("PartitionState"),
            "partition_id": properties.get("PartitionID"),
            "uri": uri,
            "properties": properties,
        },
    )
