"""Multi-HMC registry parser (Phase D, D5).

Translates the ``HMC_REGISTRY`` environment variable (a JSON list of
endpoint declarations) into a typed list of :class:`HmcEndpoint` objects
plus an :class:`HmcRegistry` view. The registry is **additive** on top of
the existing single-HMC env vars: ``HMC_HOST`` / ``HMC_USERNAME`` /
``HMC_PASSWORD`` always declare an alias named by ``HMC_DEFAULT_ALIAS``
(default ``"default"``); any aliases listed in ``HMC_REGISTRY`` are added
on top.

Example::

    HMC_REGISTRY=[
      {"alias": "prod-east", "host": "hmc-east.example", "port": 12443,
       "username": "u1", "password": "p1"},
      {"alias": "prod-west", "host": "hmc-west.example",
       "username": "u2", "password": "p2"}
    ]

Each entry MUST carry ``alias`` / ``host`` / ``username`` / ``password``.
Optional per-entry overrides: ``port`` (default ``12443``),
``verify_tls`` (default inherits from top-level ``HMC_VERIFY_TLS``),
``timeout_seconds`` (default inherits from ``HMC_TIMEOUT_SECONDS``).
Other HMC settings (allowlists, retry policy, write guardrails) are
**process-wide** and apply uniformly to every alias — operators that
need different posture per HMC should run separate processes.

Aliases are normalised to lowercase. Duplicate aliases (incl. collision
with ``HMC_DEFAULT_ALIAS``) raise at parse time.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from pydantic import SecretStr

from power_hmc_mcp.config import Settings

__all__ = [
    "HmcEndpoint",
    "HmcRegistry",
    "build_registry",
    "parse_registry_env",
]

_REQUIRED_KEYS = ("alias", "host", "username", "password")


@dataclass(frozen=True)
class HmcEndpoint:
    """A single HMC endpoint declaration."""

    alias: str
    host: str
    port: int
    username: str
    password: SecretStr
    verify_tls: bool
    timeout_seconds: float


def _coerce_entry(raw: Any, *, base: Settings) -> HmcEndpoint:
    if not isinstance(raw, dict):
        raise ValueError(
            f"HMC_REGISTRY entries must be JSON objects, got {type(raw).__name__}",
        )
    missing = [k for k in _REQUIRED_KEYS if not raw.get(k)]
    if missing:
        raise ValueError(
            f"HMC_REGISTRY entry missing required keys: {missing} (entry={raw!r})",
        )
    alias = str(raw["alias"]).strip().lower()
    if not alias:
        raise ValueError("HMC_REGISTRY entry alias must be non-empty")
    if "/" in alias or ":" in alias or " " in alias:
        raise ValueError(
            f"HMC_REGISTRY alias {alias!r} must contain only [a-z0-9_-] characters",
        )
    return HmcEndpoint(
        alias=alias,
        host=str(raw["host"]).strip(),
        port=int(raw.get("port", base.hmc_port)),
        username=str(raw["username"]).strip(),
        password=SecretStr(str(raw["password"])),
        verify_tls=bool(raw.get("verify_tls", base.hmc_verify_tls)),
        timeout_seconds=float(raw.get("timeout_seconds", base.hmc_timeout_seconds)),
    )


def parse_registry_env(value: str | None, *, base: Settings) -> list[HmcEndpoint]:
    """Parse ``HMC_REGISTRY`` JSON into :class:`HmcEndpoint` objects.

    Empty / ``None`` ⇒ empty list. The default alias built from the
    top-level ``HMC_HOST`` / ``HMC_USERNAME`` / ``HMC_PASSWORD`` is added
    by :func:`build_registry`, not here.
    """
    if not value:
        return []
    raw = value.strip()
    if not raw:
        return []
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"HMC_REGISTRY is not valid JSON: {exc}") from exc
    if not isinstance(parsed, list):
        raise ValueError(
            f"HMC_REGISTRY must be a JSON list of objects, got {type(parsed).__name__}",
        )
    return [_coerce_entry(entry, base=base) for entry in parsed]


def _default_endpoint(base: Settings) -> HmcEndpoint:
    return HmcEndpoint(
        alias=base.hmc_default_alias,
        host=base.hmc_host,
        port=base.hmc_port,
        username=base.hmc_username,
        password=base.hmc_password,
        verify_tls=base.hmc_verify_tls,
        timeout_seconds=base.hmc_timeout_seconds,
    )


class HmcRegistry:
    """Read-only view of all known HMC endpoints by alias."""

    def __init__(self, base: Settings, endpoints: list[HmcEndpoint]) -> None:
        self._base = base
        seen: dict[str, HmcEndpoint] = {}
        for ep in endpoints:
            if ep.alias in seen:
                raise ValueError(f"duplicate HMC alias: {ep.alias!r}")
            seen[ep.alias] = ep
        self._endpoints: dict[str, HmcEndpoint] = seen
        if base.hmc_default_alias not in self._endpoints:
            raise ValueError(
                f"HMC_DEFAULT_ALIAS={base.hmc_default_alias!r} is not declared "
                "in the registry; expected an entry built from top-level "
                "HMC_HOST/HMC_USERNAME/HMC_PASSWORD or an HMC_REGISTRY entry "
                "with that alias",
            )

    @property
    def base_settings(self) -> Settings:
        return self._base

    @property
    def default_alias(self) -> str:
        return self._base.hmc_default_alias

    def aliases(self) -> tuple[str, ...]:
        """Return the registered aliases in insertion order."""
        return tuple(self._endpoints.keys())

    def __contains__(self, alias: str) -> bool:
        return alias in self._endpoints

    def __getitem__(self, alias: str) -> HmcEndpoint:
        try:
            return self._endpoints[alias]
        except KeyError as exc:
            raise KeyError(
                f"unknown HMC alias: {alias!r}; known aliases: {sorted(self._endpoints)}",
            ) from exc

    def settings_for(self, alias: str) -> Settings:
        """Return per-alias :class:`Settings`, overlayed on the base settings.

        Settings carry a single ``hmc_host`` / ``hmc_username`` / ... ; for
        non-default aliases we construct a copy with the alias-specific
        values substituted. Process-wide behaviour (allowlists, retries,
        write guardrails, transport, observability) is unchanged.
        """
        ep = self[alias]
        if alias == self.default_alias:
            return self._base
        return self._base.model_copy(
            update={
                "hmc_host": ep.host,
                "hmc_port": ep.port,
                "hmc_username": ep.username,
                "hmc_password": ep.password,
                "hmc_verify_tls": ep.verify_tls,
                "hmc_timeout_seconds": ep.timeout_seconds,
                "hmc_default_alias": ep.alias,
            },
        )


def build_registry(base: Settings) -> HmcRegistry:
    """Build a :class:`HmcRegistry` from base settings + ``HMC_REGISTRY``.

    The default alias is **always** present, sourced from top-level
    ``HMC_HOST`` / ``HMC_USERNAME`` / ``HMC_PASSWORD``. Additional aliases
    from ``HMC_REGISTRY`` are appended; an entry whose alias collides with
    ``HMC_DEFAULT_ALIAS`` raises (operators must pick a non-default name).
    """
    extra = parse_registry_env(base.hmc_registry, base=base)
    for ep in extra:
        if ep.alias == base.hmc_default_alias:
            raise ValueError(
                f"HMC_REGISTRY entry alias {ep.alias!r} collides with "
                f"HMC_DEFAULT_ALIAS={base.hmc_default_alias!r}; "
                "rename the registry entry or override HMC_DEFAULT_ALIAS",
            )
    endpoints = [_default_endpoint(base), *extra]
    return HmcRegistry(base, endpoints)
