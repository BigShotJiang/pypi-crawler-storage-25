"""Logging configuration with secret redaction."""

from __future__ import annotations

import logging
import os
import re
from typing import TYPE_CHECKING, ClassVar

from power_hmc_mcp.observability import configure_observability

if TYPE_CHECKING:
    from power_hmc_mcp.config import Settings

REDACTED = "***REDACTED***"


class RedactingFilter(logging.Filter):
    """Redact secrets and session tokens from log records."""

    _STATIC_PATTERNS: ClassVar[list[re.Pattern[str]]] = [
        re.compile(r"(?i)(password\s*[=:]\s*)(\S+)"),
        re.compile(r"(?i)(<Password>)([^<]+)(</Password>)"),
        re.compile(r"(?i)(X-API-Session\s*[=:]\s*)(\S+)"),
        re.compile(r"(?i)(authorization\s*[=:]\s*Bearer\s+)(\S+)"),
    ]

    def __init__(self, secrets: list[str] | None = None) -> None:
        super().__init__()
        self._secrets = [value for value in (secrets or []) if value]

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = self._redact(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {key: self._redact_value(value) for key, value in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(self._redact_value(value) for value in record.args)
        return True

    def _redact(self, message: str) -> str:
        result = message
        for secret in self._secrets:
            if secret in result:
                result = result.replace(secret, REDACTED)
        for pattern in self._STATIC_PATTERNS:
            result = pattern.sub(self._redact_match, result)
        return result

    @staticmethod
    def _redact_match(match: re.Match[str]) -> str:
        if match.lastindex == 3:
            return f"{match.group(1)}{REDACTED}{match.group(3)}"
        return f"{match.group(1)}{REDACTED}"

    def _redact_value(self, value: object) -> object:
        if isinstance(value, str):
            return self._redact(value)
        return value


def _collect_secrets() -> list[str]:
    secrets: list[str] = []
    password = os.environ.get("HMC_PASSWORD")
    if password:
        secrets.append(password)
    return secrets


def configure_logging(level: int | None = None, *, settings: Settings | None = None) -> None:
    """Configure root logging with redaction and conservative httpx verbosity."""
    configure_observability(json_logs=bool(settings and settings.hmc_log_json))

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level if level is not None else logging.INFO)

    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(levelname)s %(name)s %(message)s"),
    )
    handler.addFilter(RedactingFilter(_collect_secrets()))
    root.addHandler(handler)

    for logger_name in ("httpx", "httpcore"):
        logging.getLogger(logger_name).setLevel(logging.WARNING)
