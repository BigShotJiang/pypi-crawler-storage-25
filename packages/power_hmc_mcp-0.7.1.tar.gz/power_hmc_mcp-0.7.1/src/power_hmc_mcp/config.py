"""HMC connection configuration from environment variables."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Literal

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

DeploymentMode = Literal["development", "controlled", "production"]
McpTransport = Literal["stdio", "streamable-http"]
LparStatusSource = Literal["uom", "quick"]
# "full" is reserved for Phase B (PCM metric JSON retrieval); Phase A raises on use.
CapacityOutputMode = Literal["metadata", "summary", "full"]
HmcProviderKind = Literal["hmc", "demo", "powervs"]


def _parse_allowlist(value: str | frozenset[str] | None) -> frozenset[str] | None:
    if value is None or value == "":
        return None
    if isinstance(value, frozenset):
        return value if value else None
    ids = {item.strip() for item in str(value).split(",") if item.strip()}
    if not ids:
        return None
    return frozenset(ids)


def _parse_echo_fallback_headers(
    value: str | tuple[str, ...] | list[str] | None,
) -> tuple[str, ...]:
    """Parse a comma-separated header list (env input) into an ordered tuple.

    Empty / missing input yields an empty tuple — callers must treat that as
    "no fallback configured" rather than a default insertion.
    """
    if value is None or value == "":
        return ()
    if isinstance(value, tuple):
        return value
    if isinstance(value, list):
        return tuple(value)
    return tuple(item.strip() for item in str(value).split(",") if item.strip())


class Settings(BaseSettings):
    """HMC connection settings loaded from environment variables or a .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    hmc_host: str = Field(..., validation_alias="HMC_HOST")
    hmc_port: int = Field(
        443,
        validation_alias="HMC_PORT",
        description=(
            "HMC REST API port. IBM docs for 7063-CR2 on V10/V11 firmware list "
            "443 as the default. Legacy V8/V9 appliances may require 12443 — "
            "confirm against your specific appliance and firmware level."
        ),
    )
    hmc_username: str = Field(..., validation_alias="HMC_USERNAME")
    hmc_password: SecretStr = Field(..., validation_alias="HMC_PASSWORD")
    hmc_verify_tls: bool = Field(True, validation_alias="HMC_VERIFY_TLS")
    hmc_timeout_seconds: float = Field(30.0, validation_alias="HMC_TIMEOUT_SECONDS")
    hmc_ca_bundle: Path | None = Field(None, validation_alias="HMC_CA_BUNDLE")
    hmc_enable_write_tools: bool = Field(False, validation_alias="HMC_ENABLE_WRITE_TOOLS")
    hmc_writes_enabled: bool = Field(
        False,
        validation_alias="HMC_WRITES_ENABLED",
        description=(
            "Master switch for live HMC write mutations. Must be True AND "
            "HMC_ENABLE_WRITE_TOOLS=true for write tools to execute. "
            "Default False. Never set True in demo or development mode."
        ),
    )
    hmc_require_execute_flag: bool = Field(True, validation_alias="HMC_REQUIRE_EXECUTE_FLAG")
    hmc_allowed_managed_systems: frozenset[str] | None = Field(
        None,
        validation_alias="HMC_ALLOWED_MANAGED_SYSTEMS",
    )
    hmc_log_json: bool = Field(False, validation_alias="HMC_LOG_JSON")
    hmc_deployment_mode: DeploymentMode = Field(
        "development",
        validation_alias="HMC_DEPLOYMENT_MODE",
    )
    hmc_read_max_retries: int = Field(2, validation_alias="HMC_READ_MAX_RETRIES")
    hmc_write_max_retries: int = Field(0, validation_alias="HMC_WRITE_MAX_RETRIES")
    hmc_retry_base_seconds: float = Field(0.5, validation_alias="HMC_RETRY_BASE_SECONDS")
    hmc_retry_max_seconds: float = Field(8.0, validation_alias="HMC_RETRY_MAX_SECONDS")
    hmc_min_request_interval_seconds: float = Field(
        0.0,
        validation_alias="HMC_MIN_REQUEST_INTERVAL_SECONDS",
    )
    hmc_max_reauth_attempts: int = Field(
        1,
        validation_alias="HMC_MAX_REAUTH_ATTEMPTS",
        description=(
            "Maximum number of re-authentication attempts when the HMC "
            "returns 401 mid-request. Default 1 (the previous hardcoded "
            "behaviour). Set 0 to disable automatic re-auth entirely; "
            "maximum 3 (higher values are unlikely to succeed and mask the "
            "underlying auth problem)."
        ),
    )
    hmc_propagate_correlation_header: bool = Field(
        True,
        validation_alias="HMC_PROPAGATE_CORRELATION_HEADER",
        description=(
            "Inject the configured outbound correlation header (see "
            "HMC_OUTBOUND_CORRELATION_HEADER, default X-Transaction-ID) "
            "into every outbound HMC request. Default True so traces span "
            "the HMC boundary. Set False only if HMC firmware rejects "
            "unknown request headers."
        ),
    )
    hmc_correlation_echo_header: str = Field(
        "X-Transaction-ID",
        validation_alias="HMC_CORRELATION_ECHO_HEADER",
        description=(
            "Primary response header to read for the HMC's correlation "
            "echo. The IBM HMC REST API spec defines X-Transaction-ID as "
            "the spec correlation header; per-firmware echo behaviour is "
            "[ASSUMED] until rows land in docs/hmc-compatibility.md "
            "'Correlation Header Echo'. Override only if your firmware "
            "version uses a different header."
        ),
    )
    hmc_correlation_echo_fallback_headers: Annotated[tuple[str, ...], NoDecode] = Field(
        default=("X-Client-Correlator",),
        validation_alias="HMC_CORRELATION_ECHO_FALLBACK_HEADERS",
        description=(
            "Comma-separated fallback headers checked after "
            "HMC_CORRELATION_ECHO_HEADER. X-Client-Correlator is the "
            "IBM-defined optional alternative (V8+). X-Request-ID and "
            "X-Correlation-ID are NOT IBM HMC headers. NoDecode ensures "
            "the env string is handed to the field validator without JSON "
            "parsing."
        ),
    )
    hmc_outbound_correlation_header: str = Field(
        "X-Transaction-ID",
        validation_alias="HMC_OUTBOUND_CORRELATION_HEADER",
        description=(
            "Header name sent outbound on every HMC REST request when "
            "HMC_PROPAGATE_CORRELATION_HEADER=true. According to the IBM "
            "HMC REST API spec, X-Transaction-ID is the spec-defined "
            "correlation header; per-firmware echo behaviour is "
            "[ASSUMED] until captured in docs/hmc-compatibility.md "
            "'Correlation Header Echo'. Set to X-Correlation-ID for "
            "backwards compatibility with existing log pipelines that "
            "grep for that header."
        ),
    )
    hmc_lpar_status_source: LparStatusSource = Field(
        "uom",
        validation_alias="HMC_LPAR_STATUS_SOURCE",
    )
    hmc_prefer_quick_properties: bool = Field(
        False,
        validation_alias="HMC_PREFER_QUICK_PROPERTIES",
        description=(
            "[PLACEHOLDER] Feature flag for the composite single-GET "
            "quick-property endpoint (.../LogicalPartition/{uuid}/quick). "
            "Default False. Do not set True until the endpoint shape is "
            "validated against firmware and documented in "
            "docs/hmc-compatibility.md 'LPAR Composite Quick Endpoint'."
        ),
    )
    hmc_max_metrics_bytes: int = Field(
        10_000_000,
        validation_alias="HMC_MAX_METRICS_BYTES",
        description=(
            "Maximum response body size in bytes for PCM metric JSON fetches "
            "(get_capacity_full). Requests whose response exceeds this limit raise "
            "HmcResponseTooLargeError before parsing. Default 10 MB."
        ),
    )
    hmc_demo_mode: bool = Field(
        False,
        validation_alias="HMC_DEMO_MODE",
        description=(
            "When true, all HmcClient read methods return bundled fixture responses "
            "instead of making real HTTP calls. Write tools return executed=false with "
            "demo=true. Startup emits a WARNING. Enables demos, CI smoke tests, and "
            "contributor onboarding without an HMC connection."
        ),
    )
    hmc_provider: HmcProviderKind = Field(
        "hmc",
        validation_alias="HMC_PROVIDER",
        description=(
            "Backend provider. 'hmc' = real HMC REST API (default), "
            "'demo' = bundled fixtures (no network), "
            "'powervs' = IBM Cloud Power VS stub (not yet implemented)."
        ),
    )
    ibmcloud_api_key: SecretStr | None = Field(
        None,
        validation_alias="IBMCLOUD_API_KEY",
        description=(
            "[PLACEHOLDER] IBM Cloud API key for Power VS provider "
            "(HMC_PROVIDER=powervs). Not used until PowerVSProvider is implemented."
        ),
    )
    powervs_workspace_id: str | None = Field(
        None,
        validation_alias="POWERVS_WORKSPACE_ID",
        description=(
            "[PLACEHOLDER] IBM Cloud Power VS workspace ID "
            "(HMC_PROVIDER=powervs). Not used until PowerVSProvider is implemented."
        ),
    )
    powervs_region: str | None = Field(
        None,
        validation_alias="POWERVS_REGION",
        description=(
            "[PLACEHOLDER] IBM Cloud Power VS region (e.g. us-south) "
            "(HMC_PROVIDER=powervs). Not used until PowerVSProvider is implemented."
        ),
    )
    hmc_api_version_hint: str | None = Field(
        None,
        validation_alias="HMC_API_VERSION_HINT",
        description=(
            "Operator-supplied hint about the target HMC API / firmware "
            "version (e.g. 'V10R2M1040', 'V11R1'). Used strictly for "
            "logging / observability annotations and, in the future, as "
            "an eligibility signal for IBM-doc-versioned endpoints "
            "('Since: Version 1_1_0' features). Does NOT flip "
            "firmware-gated behaviors — those remain controlled by their "
            "own feature flags and the compatibility tables in "
            "docs/hmc-compatibility.md. Empty string is treated as unset."
        ),
    )
    hmc_default_alias: str = Field(
        "default",
        validation_alias="HMC_DEFAULT_ALIAS",
        description=(
            "Alias name attached to the implicit endpoint built from "
            "HMC_HOST / HMC_USERNAME / HMC_PASSWORD (Phase D, D5). When "
            "HMC_REGISTRY is unset or empty, this is the only alias the "
            "tool resolver knows about. Must be lowercase [a-z0-9_-]+ "
            "and must not appear in HMC_REGISTRY."
        ),
    )
    hmc_registry: str | None = Field(
        None,
        validation_alias="HMC_REGISTRY",
        description=(
            "Optional JSON list of additional HMC endpoints exposed via "
            "the `hmc_alias` tool parameter (Phase D, D5). Each entry "
            "must declare alias / host / username / password; optional "
            "per-entry overrides are port / verify_tls / timeout_seconds. "
            "All other HMC settings (allowlists, retries, write "
            "guardrails, transport, observability) are process-wide and "
            "apply to every alias uniformly. Empty / unset disables the "
            "registry; only the default alias is then resolvable."
        ),
    )
    hmc_mcp_transport: McpTransport = Field("stdio", validation_alias="HMC_MCP_TRANSPORT")
    hmc_mcp_http_host: str = Field("127.0.0.1", validation_alias="HMC_MCP_HTTP_HOST")
    hmc_mcp_http_port: int = Field(8000, validation_alias="HMC_MCP_HTTP_PORT")
    hmc_mcp_http_path: str = Field("/mcp", validation_alias="HMC_MCP_HTTP_PATH")
    hmc_mcp_http_probes_path: str = Field(
        "",
        validation_alias="HMC_MCP_HTTP_PROBES_PATH",
        description=(
            "Mount prefix for the HTTP liveness/readiness probes "
            "(/healthz, /readyz). Empty string (default) disables probes; "
            "they are only registered when this is set AND the streamable-HTTP "
            "transport is selected. '/' mounts at the listener root: "
            "GET /healthz / /readyz. Any other value mounts under that prefix: "
            "e.g. '/admin' yields GET /admin/healthz, /admin/readyz. The "
            "value MUST start with '/' and MUST NOT collide with HMC_MCP_HTTP_PATH "
            "(otherwise the MCP endpoint and probe handler would race for the same path)."
        ),
    )

    @field_validator("hmc_host")
    @classmethod
    def validate_host(cls, value: str) -> str:
        if "://" in value or "/" in value:
            raise ValueError("HMC_HOST must be a hostname or IP, not a URL path")
        return value.strip()

    @field_validator("hmc_timeout_seconds")
    @classmethod
    def validate_timeout(cls, value: float) -> float:
        if value <= 0 or value > 300:
            raise ValueError("HMC_TIMEOUT_SECONDS must be between 0 and 300 (exclusive 0)")
        return value

    @field_validator("hmc_read_max_retries", "hmc_write_max_retries")
    @classmethod
    def validate_retries(cls, value: int) -> int:
        if value < 0 or value > 10:
            raise ValueError("HMC_*_MAX_RETRIES must be between 0 and 10")
        return value

    @field_validator("hmc_retry_base_seconds", "hmc_retry_max_seconds")
    @classmethod
    def validate_retry_seconds(cls, value: float) -> float:
        if value < 0 or value > 120:
            raise ValueError("retry seconds must be between 0 and 120")
        return value

    @field_validator("hmc_min_request_interval_seconds")
    @classmethod
    def validate_min_interval(cls, value: float) -> float:
        if value < 0 or value > 60:
            raise ValueError("HMC_MIN_REQUEST_INTERVAL_SECONDS must be between 0 and 60")
        return value

    @field_validator("hmc_max_reauth_attempts")
    @classmethod
    def validate_max_reauth_attempts(cls, value: int) -> int:
        if value < 0 or value > 3:
            raise ValueError("HMC_MAX_REAUTH_ATTEMPTS must be between 0 and 3")
        return value

    @field_validator("hmc_max_metrics_bytes")
    @classmethod
    def validate_max_metrics_bytes(cls, value: int) -> int:
        if value < 1_000 or value > 100_000_000:
            raise ValueError("HMC_MAX_METRICS_BYTES must be between 1 KB and 100 MB")
        return value

    @field_validator("hmc_mcp_http_port")
    @classmethod
    def validate_mcp_port(cls, value: int) -> int:
        if value <= 0 or value > 65535:
            raise ValueError("HMC_MCP_HTTP_PORT must be a valid TCP port")
        return value

    @field_validator("hmc_mcp_http_probes_path")
    @classmethod
    def validate_probes_path(cls, value: str) -> str:
        if value == "":
            return value
        if not value.startswith("/"):
            raise ValueError(
                "HMC_MCP_HTTP_PROBES_PATH must be empty (disabled) or start with '/'",
            )
        return value.rstrip("/") or "/"

    @field_validator("hmc_ca_bundle")
    @classmethod
    def validate_ca_bundle(cls, value: Path | None) -> Path | None:
        if value is None:
            return None
        if not value.is_file():
            raise ValueError(f"HMC_CA_BUNDLE does not exist or is not a file: {value}")
        return value

    @field_validator("hmc_allowed_managed_systems", mode="before")
    @classmethod
    def validate_allowlist(cls, value: str | frozenset[str] | None) -> frozenset[str] | None:
        return _parse_allowlist(value)

    @field_validator("hmc_correlation_echo_fallback_headers", mode="before")
    @classmethod
    def validate_echo_fallback_headers(
        cls,
        value: str | tuple[str, ...] | list[str] | None,
    ) -> tuple[str, ...]:
        return _parse_echo_fallback_headers(value)

    @field_validator("hmc_default_alias", mode="before")
    @classmethod
    def validate_default_alias(cls, value: str | None) -> str:
        if value is None or str(value).strip() == "":
            return "default"
        alias = str(value).strip().lower()
        if any(ch in alias for ch in (" ", "/", ":")):
            raise ValueError(
                f"HMC_DEFAULT_ALIAS must contain only [a-z0-9_-] characters: {alias!r}",
            )
        return alias

    @field_validator("hmc_api_version_hint", mode="before")
    @classmethod
    def validate_api_version_hint(cls, value: str | None) -> str | None:
        """Trim whitespace; treat empty string as unset (None)."""
        if value is None:
            return None
        trimmed = str(value).strip()
        return trimmed or None

    @model_validator(mode="after")
    def _reject_probe_mcp_path_collision(self) -> Settings:
        """Refuse to boot if probes path would shadow the MCP path.

        Both /healthz / /readyz handlers and the streamable-HTTP MCP route
        are registered on the same Starlette app. If the operator sets
        ``HMC_MCP_HTTP_PROBES_PATH`` to a value that resolves to the same
        prefix as ``HMC_MCP_HTTP_PATH`` we'd silently swap MCP traffic for
        a JSON probe response. Fail loud at boot instead.
        """
        if not self.hmc_mcp_http_probes_path:
            return self
        mcp_path = self.hmc_mcp_http_path.rstrip("/") or "/"
        probes_root = self.hmc_mcp_http_probes_path.rstrip("/") or "/"
        for probe in ("healthz", "readyz"):
            full_probe_path = f"/{probe}" if probes_root == "/" else f"{probes_root}/{probe}"
            if full_probe_path == mcp_path:
                raise ValueError(
                    f"HMC_MCP_HTTP_PROBES_PATH={self.hmc_mcp_http_probes_path!r} "
                    f"would mount {full_probe_path!r} which collides with "
                    f"HMC_MCP_HTTP_PATH={self.hmc_mcp_http_path!r}. Choose a "
                    "non-overlapping prefix or unset HMC_MCP_HTTP_PROBES_PATH "
                    "to disable probes.",
                )
        return self

    @property
    def base_url(self) -> str:
        if self.hmc_port == 443:
            return f"https://{self.hmc_host}"
        return f"https://{self.hmc_host}:{self.hmc_port}"

    def httpx_verify(self) -> bool | str:
        """Return the verify argument for httpx."""
        if not self.hmc_verify_tls:
            return False
        if self.hmc_ca_bundle is not None:
            return str(self.hmc_ca_bundle)
        return True

    def allowed_managed_system_ids(self) -> frozenset[str] | None:
        """Return configured allowlist, or None if all systems are permitted."""
        return self.hmc_allowed_managed_systems

    def is_managed_system_allowed(self, system_id: str) -> bool:
        """Return True if the managed system is permitted by policy."""
        allowlist = self.allowed_managed_system_ids()
        if allowlist is None:
            return True
        return system_id in allowlist

    def __repr__(self) -> str:
        return (
            "Settings("
            f"hmc_host={self.hmc_host!r}, hmc_port={self.hmc_port}, "
            f"hmc_username={self.hmc_username!r}, hmc_verify_tls={self.hmc_verify_tls}, "
            f"hmc_timeout_seconds={self.hmc_timeout_seconds}, "
            f"hmc_enable_write_tools={self.hmc_enable_write_tools}, "
            f"hmc_deployment_mode={self.hmc_deployment_mode!r}, "
            f"hmc_log_json={self.hmc_log_json}, "
            f"hmc_read_max_retries={self.hmc_read_max_retries}, "
            f"hmc_write_max_retries={self.hmc_write_max_retries}, "
            f"hmc_lpar_status_source={self.hmc_lpar_status_source!r}, "
            f"hmc_mcp_transport={self.hmc_mcp_transport!r})"
        )


def load_settings() -> Settings:
    """Load and validate settings, failing fast if required fields are missing."""
    return Settings()
