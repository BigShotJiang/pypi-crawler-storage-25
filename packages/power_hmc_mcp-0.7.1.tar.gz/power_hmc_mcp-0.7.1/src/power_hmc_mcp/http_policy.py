"""Transport helpers for the httpx sync and async clients.

Functions tagged ``# SYNC-ONLY`` (``retry_sleep`` / ``throttle_before_request``)
must not be called from a running event loop. Their async counterparts
(``retry_sleep_async`` / ``throttle_before_request_async``) live alongside
and are tagged ``# ASYNC``. ``backoff_delay_seconds`` is pure (no I/O,
no sleep) and is shared by both paths verbatim.

The sync/async pair was added in Phase D for the async transport
migration; the markers document the pair, do not delete them.
"""

from __future__ import annotations

import asyncio
import random
import time
from enum import StrEnum
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from power_hmc_mcp.config import Settings


def _assert_sync_context(fn_name: str) -> None:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    raise RuntimeError(
        f"{fn_name} is a sync-only function and must not be called from "
        f"an async context (running loop: {loop}). See TODO.md Phase D.",
    )


def _assert_async_context(fn_name: str) -> None:
    """Inverse of :func:`_assert_sync_context`.

    Raises if there is **no** running event loop. The async retry/throttle
    helpers exist so callers on the async path do not block the loop with
    ``time.sleep``; calling them outside an event loop is a bug, not a
    defensible "use either" pattern.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError as exc:
        raise RuntimeError(
            f"{fn_name} is an async-only function and must be called from "
            f"a running event loop. See TODO.md Phase D.",
        ) from exc


class RequestClassification(StrEnum):
    """Whether an HTTP call follows read-safe or write semantics for retries."""

    READ = "read"
    WRITE = "write"


def max_retries(settings: Settings, classification: RequestClassification) -> int:
    """Maximum *additional* attempts after the first request."""
    if classification is RequestClassification.WRITE:
        return settings.hmc_write_max_retries
    return settings.hmc_read_max_retries


def backoff_delay_seconds(settings: Settings, attempt_index: int) -> float:
    """Exponential backoff with jitter; attempt_index starts at 0 after first failure."""
    base = settings.hmc_retry_base_seconds
    ceiling = settings.hmc_retry_max_seconds
    exp = min(base * (2**attempt_index), ceiling)
    jitter = random.uniform(0.0, base * 0.25)
    return float(min(exp + jitter, ceiling))


def retry_sleep(settings: Settings, attempt_index: int) -> None:
    _assert_sync_context("retry_sleep")
    delay = backoff_delay_seconds(settings, attempt_index)
    if delay > 0:
        # SYNC-ONLY: paired with httpx.Client; Phase D introduces an asyncio.sleep counterpart.
        time.sleep(delay)


def is_idempotent_method(method: str) -> bool:
    """Conservative idempotency hint used for documentation and future policy."""
    return method.upper() in frozenset({"GET", "HEAD", "OPTIONS"})


def is_retryable_transport_error(
    exc: httpx.HTTPError,
    *,
    classification: RequestClassification,
) -> bool:
    """Whether a transport-level failure may be retried.

    All branches respect ``classification`` so retry behavior stays uniform across
    error types: by default writes do not auto-retry on any transport failure, and
    operators must opt in via ``HMC_WRITE_MAX_RETRIES``. Even though ``ConnectError``
    is typically safe to retry (the request never reached the server), the
    consistent gate avoids ambiguous policy and is paired with the per-classification
    retry budget for defense in depth.
    """
    if isinstance(
        exc,
        httpx.TimeoutException | httpx.ConnectError | httpx.RemoteProtocolError,
    ):
        return classification is RequestClassification.READ
    return False


def is_retryable_http_status(
    status_code: int,
    method: str,
    *,
    classification: RequestClassification,
) -> bool:
    """HTTP statuses that may succeed on retry (HMC may throttle or restart briefly)."""
    if status_code == 429:
        return True
    if status_code not in (502, 503, 504):
        return False
    if classification is RequestClassification.WRITE and not is_idempotent_method(method):
        return False
    return True


def throttle_before_request(settings: Settings, last_request_monotonic: float | None) -> None:
    """Client-side spacing between outbound calls (placeholder / conservative default)."""
    _assert_sync_context("throttle_before_request")
    floor_s = settings.hmc_min_request_interval_seconds
    if floor_s <= 0 or last_request_monotonic is None:
        return
    elapsed = time.monotonic() - last_request_monotonic
    wait_s = floor_s - elapsed
    if wait_s > 0:
        # SYNC-ONLY: paired with httpx.Client; async counterpart is throttle_before_request_async.
        time.sleep(wait_s)


# --- ASYNC counterparts (paired with the SYNC-ONLY helpers above) -----------


async def retry_sleep_async(settings: Settings, attempt_index: int) -> None:
    # ASYNC: paired with httpx.AsyncClient; mirrors retry_sleep using asyncio.sleep.
    _assert_async_context("retry_sleep_async")
    delay = backoff_delay_seconds(settings, attempt_index)
    if delay > 0:
        await asyncio.sleep(delay)


async def throttle_before_request_async(
    settings: Settings,
    last_request_monotonic: float | None,
) -> None:
    # ASYNC: paired with httpx.AsyncClient; mirrors throttle_before_request using asyncio.sleep.
    _assert_async_context("throttle_before_request_async")
    floor_s = settings.hmc_min_request_interval_seconds
    if floor_s <= 0 or last_request_monotonic is None:
        return
    elapsed = time.monotonic() - last_request_monotonic
    wait_s = floor_s - elapsed
    if wait_s > 0:
        await asyncio.sleep(wait_s)
