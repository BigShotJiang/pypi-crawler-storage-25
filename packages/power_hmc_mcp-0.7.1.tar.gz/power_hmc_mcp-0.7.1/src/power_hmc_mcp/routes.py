"""Named IBM Power HMC REST path builders.

All HMC URL paths used by the client should be constructed here so IBM path
revisions can be repaired in one place. Prefer these functions over ad hoc
string concatenation elsewhere.

IBM doc alignment
=================
Read-path builders below are aligned **verbatim** with the IBM Power10 /
Power11 HMC REST documentation (URL strings and path parameters identical
to the IBM-published forms).  See:

* Power10 ``ManagedSystem`` resource — https://www.ibm.com/docs/en/power10?topic=apis-managed-system
* Power11 ``LogicalPartition`` resource — https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition
* Power10 ``LogicalPartitionProfile`` resource — https://www.ibm.com/docs/en/power10?topic=system-logical-partition-profile
* Power10/11 URL model grammar — https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis

Per-builder annotations:

* ``[VALIDATED — IBM Docs Power10/11]`` — URL string matches the
  IBM-published form verbatim.  The annotation covers the URL shape only;
  payload schemas and firmware-specific behaviour stay subject to the
  compatibility tables in ``docs/hmc-compatibility.md``.
* ``[PLACEHOLDER]`` — kept until a firmware capture lands in
  ``docs/hmc-compatibility.md``.  These builders MUST NOT be relied on as
  IBM-aligned.

Write-path builders (``logical_partition_start_job_path``,
``logical_partition_stop_job_path``,
``logical_partition_create_from_profile_path``) remain **contract
placeholders**: the IBM URL grammar for asynchronous jobs is
``GET /rest/api/uom/{R}/{UUID}/do/{OP}`` for the template, then
``PUT /rest/api/uom/{R}/{UUID}/jobs`` to submit and
``GET /rest/api/uom/{R}/{UUID}/jobs/{JOBID}`` to poll.  The current
builders follow that ``/do/{OP}`` shape but the specific ``{OP}`` names
(``PowerOn`` / ``PowerOff`` / ``PartitionTemplateCreatePartition``)
remain firmware-pending and are marked ``[ASSUMPTION]`` until lab capture
lands in ``docs/hmc-compatibility.md`` 'Write Operation Paths' and
TODO.md Phase C.
"""

from __future__ import annotations

# Session / auth (Web API)
# [VALIDATED — IBM Docs Power10/11] IBM HMC REST Web API logon path.
LOGON_PATH = "/rest/api/web/Logon"
SESSION_HEADER = "X-API-Session"

# UOM collections and resources
# [VALIDATED — IBM Docs Power10/11] ManagedSystem collection.
# Doc: https://www.ibm.com/docs/en/power10?topic=apis-managed-system
MANAGED_SYSTEM_COLLECTION_PATH = "/rest/api/uom/ManagedSystem"


def managed_system_path(managed_system_id: str) -> str:
    """GET single ManagedSystem UOM document.

    [VALIDATED — IBM Docs Power10/11] ``/rest/api/uom/ManagedSystem/{uuid}``
    per https://www.ibm.com/docs/en/power10?topic=apis-managed-system.
    """
    return f"{MANAGED_SYSTEM_COLLECTION_PATH}/{managed_system_id}"


def logical_partition_collection_path(managed_system_id: str) -> str:
    """GET Atom feed of LogicalPartitions for a managed system.

    [VALIDATED — IBM Docs Power10/11]
    ``/rest/api/uom/ManagedSystem/{ManagedSystem_uuid}/LogicalPartition``
    per https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition.

    The IBM docs also publish a top-level ``/rest/api/uom/LogicalPartition``
    form; the nested form returned here is used because all read tools that
    consume this builder already carry a validated ``managed_system_id``.
    """
    return f"{managed_system_path(managed_system_id)}/LogicalPartition"


def logical_partition_path(managed_system_id: str, lpar_id: str) -> str:
    """GET single LogicalPartition UOM document.

    [VALIDATED — IBM Docs Power10/11]
    ``/rest/api/uom/ManagedSystem/{ManagedSystem_uuid}/LogicalPartition/{LogicalPartition_uuid}``
    per https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition.
    """
    return f"{logical_partition_collection_path(managed_system_id)}/{lpar_id}"


def logical_partition_quick_property_path(lpar_id: str, property_name: str) -> str:
    """GET a single quick property for an LPAR.

    [VALIDATED — IBM Docs Power10/11]
    ``/rest/api/uom/LogicalPartition/{LogicalPartition_uuid}/quick/{Property name}``
    per the IBM root-instance URL grammar
    (https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis)
    and the LPAR Quick Properties table
    (https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition).

    NOTE: this is the URL shape only.  The list of property names that any
    given firmware actually serves on this endpoint is firmware-dependent;
    callers must not assume every documented quick property is available
    on every firmware level.
    """
    return f"/rest/api/uom/LogicalPartition/{lpar_id}/quick/{property_name}"


def logical_partition_composite_quick_path(lpar_id: str) -> str:
    """[PLACEHOLDER] Composite GET returning all quick properties at once.

    The IBM URL-model grammar
    (https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis)
    documents ``/rest/api/uom/{R}/{UUID}/quick/{QP}`` as the per-property
    quick endpoint, but does NOT document an instance-level
    ``.../quick`` endpoint that returns the full set of quick properties
    in a single round trip.  Some HMC firmware levels return JSON here;
    others return ``application/xml;type=PartitionQuickProperties``; some
    do not support it at all.

    Validate the response shape against the target HMC firmware before
    wiring :meth:`HmcClient.get_lpar_quick`.  See
    ``docs/hmc-compatibility.md`` 'LPAR Composite Quick Endpoint'.

    [RISK] Do not promote this builder to ``[VALIDATED]`` without a row in
    the compatibility doc recording the firmware version, content-type,
    and round-trip latency observed.
    """
    return f"/rest/api/uom/LogicalPartition/{lpar_id}/quick"


def logical_partition_profiles_path(lpar_id: str) -> str:
    """GET Atom feed of LogicalPartitionProfile entries for an LPAR.

    [VALIDATED — IBM Docs Power10/11]
    ``/rest/api/uom/LogicalPartition/{LogicalPartition_uuid}/LogicalPartitionProfile``
    per https://www.ibm.com/docs/en/power10?topic=system-logical-partition-profile.

    The IBM docs also publish a nested form
    ``/rest/api/uom/ManagedSystem/{ManagedSystem_uuid}/LogicalPartition/{LogicalPartition_uuid}/LogicalPartitionProfile``;
    we use the standalone form because the current MCP tool surface
    addresses LPARs by UUID without requiring the parent ManagedSystem.
    """
    return f"/rest/api/uom/LogicalPartition/{lpar_id}/LogicalPartitionProfile"


def pcm_processed_metrics_path(managed_system_id: str) -> str:
    """GET PCM ProcessedMetrics Atom feed for a managed system.

    [VALIDATED — IBM Docs Power9/10/11]
    ``/rest/api/pcm/ManagedSystem/{uuid}/ProcessedMetrics`` per the IBM
    Performance Capacity Monitor (PCM) Atom feed convention; PCM JSON
    field names downstream of this feed are tracked in
    ``docs/hmc-compatibility.md`` 'PCM Metric JSON Field Names'.
    """
    return f"/rest/api/pcm/ManagedSystem/{managed_system_id}/ProcessedMetrics"


# --- Write paths (CONTRACT PLACEHOLDERS) ----------------------------------
#
# These builders are kept as ``[PLACEHOLDER]`` until firmware capture
# confirms the exact ``{OP}`` names.  See ``docs/hmc-compatibility.md``
# 'Write Operation Paths' and TODO.md Phase C.
#
# IBM job-submission grammar
# (https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis):
#
#   GET  /rest/api/uom/{R}/{UUID}/do/{OP}   -> template (JobRequest XSD)
#   PUT  /rest/api/uom/{R}/{UUID}/jobs      -> submit the populated job
#   GET  /rest/api/uom/{R}/{UUID}/jobs/{JOBID} -> poll job status
#
# The URL shape (``.../do/{OP}``) is IBM-doc grammar; the chosen ``{OP}``
# names below are ``[ASSUMPTION]`` placeholders pending firmware capture.
# DO NOT relabel these as ``[VALIDATED]`` or "IBM-aligned" without a row
# in the compatibility doc.


def logical_partition_start_job_path(managed_system_id: str, lpar_id: str) -> str:
    """[PLACEHOLDER] POST template path to start (power on) a logical partition.

    URL shape follows IBM's ``/do/{OP}`` instance-job grammar.  The
    ``{OP}`` name ``PowerOn`` is an ``[ASSUMPTION]`` placeholder pending
    firmware capture (lab HMC required); historical pypowervm callers
    have used both ``PowerOn`` and ``PartitionStart`` depending on
    firmware level.

    See ``docs/hmc-compatibility.md`` 'Write Operation Paths' and
    ``TODO.md`` Phase C — replacing this with the IBM-validated path is a
    Phase C deliverable, not a Phase B item.
    """
    return f"{logical_partition_path(managed_system_id, lpar_id)}/do/PowerOn"


def logical_partition_stop_job_path(managed_system_id: str, lpar_id: str) -> str:
    """[PLACEHOLDER] POST template path to stop (power off) a logical partition.

    URL shape follows IBM's ``/do/{OP}`` instance-job grammar.  The
    ``{OP}`` name ``PowerOff`` is an ``[ASSUMPTION]`` placeholder pending
    firmware capture; the body schema (shutdown mode, immediate vs.
    delayed) is also firmware-specific and is not encoded in the URL.

    See ``docs/hmc-compatibility.md`` 'Write Operation Paths' and
    ``TODO.md`` Phase C.
    """
    return f"{logical_partition_path(managed_system_id, lpar_id)}/do/PowerOff"


def logical_partition_create_from_profile_path(managed_system_id: str) -> str:
    """[PLACEHOLDER] POST template path to create a new LPAR from a stored profile.

    URL shape follows IBM's ``/do/{OP}`` anchor-job grammar applied at
    the LogicalPartition child anchor under a ManagedSystem.  The
    ``{OP}`` name ``PartitionTemplateCreatePartition`` is an
    ``[ASSUMPTION]`` placeholder pending firmware capture; the body
    schema (profile reference, override blocks) is firmware-specific.

    See ``docs/hmc-compatibility.md`` 'Write Operation Paths' and
    ``TODO.md`` Phase C.
    """
    return (
        f"{logical_partition_collection_path(managed_system_id)}"
        "/do/PartitionTemplateCreatePartition"
    )


def logical_partition_jobs_path(managed_system_id: str, lpar_id: str) -> str:
    """[ASSUMPTION] PUT to submit a JobRequest; GET to poll all jobs.

    IBM job-submission grammar:
    ``PUT /rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/jobs``
    """
    return f"{logical_partition_path(managed_system_id, lpar_id)}/jobs"


def logical_partition_job_status_path(
    managed_system_id: str,
    lpar_id: str,
    job_id: str,
) -> str:
    """[ASSUMPTION] GET to poll a specific job by ID.

    IBM job-submission grammar:
    ``GET /rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/jobs/{jobId}``
    """
    return f"{logical_partition_jobs_path(managed_system_id, lpar_id)}/{job_id}"


# Backwards-compatible aliases used by tests and older imports.
# Templates are derived from the builders so the path string lives in exactly one place.
MANAGED_SYSTEMS_PATH = MANAGED_SYSTEM_COLLECTION_PATH
LPAR_PROFILES_PATH = logical_partition_profiles_path("{lpar_id}")
PCM_PROCESSED_METRICS_PATH = pcm_processed_metrics_path("{system_id}")
