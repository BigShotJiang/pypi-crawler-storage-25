"""Backend provider protocol for MCP tool dispatch (Phase J).

Why Protocol over ABC
---------------------
``typing.Protocol`` with ``runtime_checkable=True`` enables *structural*
subtyping: :class:`~power_hmc_mcp.hmc_client.HmcClient` satisfies
:class:`HmcProvider` without inheriting from it, preserving the existing
class hierarchy and zero runtime overhead on the HMC path.

Providers
---------
* **hmc** — :class:`~power_hmc_mcp.hmc_client.HmcClient` (real HMC REST API).
* **demo** — :class:`~power_hmc_mcp.demo_provider.DemoProvider` (bundled fixtures,
  no network).
* **powervs** — :class:`~power_hmc_mcp.powervs_provider.PowerVSProvider`
  (stub; raises ``NotImplementedError`` on use).

Adding a new provider
---------------------
1. Implement every method in :class:`HmcProvider` on a new class.
2. Add a ``case`` branch in :func:`~power_hmc_mcp.provider_factory.create_provider`.
3. Document the new ``HMC_PROVIDER`` value in ``.env.example`` and
   ``docs/design/provider-architecture.md``.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from power_hmc_mcp.config import CapacityOutputMode, Settings
from power_hmc_mcp.guardrails import WriteAuthorization

__all__ = ["HmcProvider"]


@runtime_checkable
class HmcProvider(Protocol):
    """Structural interface for sync HMC/Power backends used by MCP tools."""

    @property
    def settings(self) -> Settings: ...

    def login(self) -> None: ...

    def close(self) -> None: ...

    def list_managed_systems(self) -> list[dict[str, Any]]: ...

    def get_managed_system(self, managed_system_id: str) -> dict[str, Any]: ...

    def list_lpars(self, managed_system_id: str) -> list[dict[str, Any]]: ...

    def get_lpar_status(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]: ...

    def get_lpar(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]: ...

    def get_lpar_quick(self, lpar_id: str) -> dict[str, Any]: ...

    def list_partition_profiles(self, lpar_id: str) -> list[dict[str, Any]]: ...

    def get_capacity(
        self,
        managed_system_id: str,
        *,
        mode: CapacityOutputMode = "metadata",
    ) -> dict[str, Any]: ...

    def get_capacity_full(
        self,
        managed_system_id: str,
        metrics_href: str,
    ) -> dict[str, Any]: ...

    def is_authenticated(self) -> bool: ...

    def health_check(self) -> dict[str, Any]: ...

    def create_lpar_from_profile(
        self,
        managed_system_id: str,
        profile_name: str,
        new_lpar_name: str,
        overrides: dict[str, Any] | None = None,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]: ...

    def start_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]: ...

    def stop_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        mode: str = "normal",
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]: ...
