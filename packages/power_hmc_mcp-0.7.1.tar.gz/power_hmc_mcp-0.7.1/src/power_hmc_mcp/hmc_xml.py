"""XML helpers for IBM Power HMC REST API payloads and responses."""

from __future__ import annotations

import logging
import xml.etree.ElementTree as ET
from typing import Any

from power_hmc_mcp.exceptions import HmcParseError
from power_hmc_mcp.serialize import drop_none

logger = logging.getLogger(__name__)

LOGON_NS = "http://www.ibm.com/xmlns/systems/power/firmware/web/mc/2012_10/"
ATOM_NS = "http://www.w3.org/2005/Atom"


def build_logon_request(username: str, password: str) -> str:
    """Build a LogonRequest XML body with escaped credentials."""
    root = ET.Element(
        "LogonRequest",
        {
            "xmlns": LOGON_NS,
            "schemaVersion": "V1_0",
        },
    )
    user_el = ET.SubElement(root, "UserID")
    user_el.text = username
    pass_el = ET.SubElement(root, "Password")
    pass_el.text = password
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + ET.tostring(
        root,
        encoding="unicode",
    )


def _local_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[-1]
    return tag


def _text(element: ET.Element | None) -> str | None:
    if element is None:
        return None
    text = (element.text or "").strip()
    return text or None


def _find_child(entry: ET.Element, name: str) -> ET.Element | None:
    for child in entry:
        if _local_name(child.tag) == name:
            return child
    return None


def _find_children(entry: ET.Element, name: str) -> list[ET.Element]:
    return [child for child in entry if _local_name(child.tag) == name]


def _extract_uuid(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    if "/" in value:
        return value.rstrip("/").rsplit("/", 1)[-1]
    return value


def _entry_href(entry: ET.Element) -> str | None:
    for link in _find_children(entry, "link"):
        rel = link.attrib.get("rel", "alternate")
        if rel in {"self", "alternate"}:
            href = link.attrib.get("href")
            if href:
                return href
    return None


def _entry_name(entry: ET.Element) -> str | None:
    for name in (
        "ProfileName",
        "SystemName",
        "PartitionName",
        "Name",
        "title",
    ):
        el = _find_child(entry, name)
        text = _text(el)
        if text:
            return text
    title = _find_child(entry, "title")
    return _text(title)


def _entry_state(entry: ET.Element) -> str | None:
    for name in ("State", "PartitionState", "CurrentState"):
        el = _find_child(entry, name)
        text = _text(el)
        if text:
            return text
    return None


def _entry_partition_id(entry: ET.Element) -> str | None:
    el = _find_child(entry, "PartitionID")
    return _text(el)


def _parse_xml(xml_text: str) -> ET.Element:
    try:
        return ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise HmcParseError("Invalid HMC XML response") from exc


def parse_feed_entries(xml_text: str) -> list[dict[str, Any]]:
    """Parse an Atom feed of HMC resources into normalized dicts."""
    root = _parse_xml(xml_text)
    entries: list[ET.Element] = []
    for element in root.iter():
        if _local_name(element.tag) == "entry":
            entries.append(element)

    results: list[dict[str, Any]] = []
    for entry in entries:
        entry_id = _text(_find_child(entry, "id"))
        resource_id = _extract_uuid(entry_id) or _extract_uuid(_entry_href(entry))
        if not resource_id:
            continue
        item: dict[str, Any] = {
            "id": resource_id,
            "name": _entry_name(entry),
            "uri": _entry_href(entry),
        }
        state = _entry_state(entry)
        if state is not None:
            item["state"] = state
        partition_id = _entry_partition_id(entry)
        if partition_id is not None:
            item["partition_id"] = partition_id
        results.append(drop_none(item))
    return results


def parse_resource_properties(xml_text: str) -> dict[str, str]:
    """Parse a single UOM resource XML document into a flat property map."""
    root = _parse_xml(xml_text)
    properties: dict[str, str] = {}
    for child in root:
        name = _local_name(child.tag)
        text = _text(child)
        if text is not None:
            properties[name] = text
    return properties


def parse_pcm_metrics_feed(xml_text: str) -> list[dict[str, Any]]:
    """Parse PCM ProcessedMetrics Atom feed into sample metadata dicts."""
    root = _parse_xml(xml_text)
    observed_rels: set[str] = set()
    for element in root.iter():
        if _local_name(element.tag) == "link":
            observed_rels.add(element.attrib.get("rel", "alternate"))

    entries: list[ET.Element] = []
    for element in root.iter():
        if _local_name(element.tag) == "entry":
            entries.append(element)

    samples: list[dict[str, Any]] = []
    for entry in entries:
        entry_id = _text(_find_child(entry, "id"))
        link_href = _entry_href(entry)
        category_el = _find_child(entry, "category")
        category = category_el.attrib.get("term") if category_el is not None else None
        item = drop_none(
            {
                "id": _extract_uuid(entry_id),
                "title": _text(_find_child(entry, "title")),
                "updated": _text(_find_child(entry, "updated")),
                "category": category,
                "link_href": link_href,
            },
        )
        if item:
            samples.append(item)

    if not samples and entries:
        rel_vals = ", ".join(sorted(observed_rels)) if observed_rels else "(none)"
        logger.warning(
            "PCM feed parsed 0 samples from %d entries. Observed rel values: %s. "
            "If this is unexpected, check HMC firmware rel attribute variants. "
            "See TODO.md Phase B [RISK].",
            len(entries),
            rel_vals,
        )
    return samples


def parse_quick_properties(xml_text: str) -> dict[str, str]:
    """Parse quick-property XML into a flat name -> value map."""
    root = _parse_xml(xml_text)
    properties: dict[str, str] = {}
    for element in root.iter():
        name = _local_name(element.tag)
        if name in {"feed", "entry", "id", "title", "link", "updated"}:
            continue
        text = _text(element)
        if text is not None:
            properties[name] = text
    return properties
