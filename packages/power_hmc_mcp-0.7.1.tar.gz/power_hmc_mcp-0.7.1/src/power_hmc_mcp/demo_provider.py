"""Demo backend backed by bundled fixtures — no network calls (Phase J)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

from power_hmc_mcp import observability
from power_hmc_mcp.config import CapacityOutputMode, Settings
from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.guardrails import WriteAuthorization
from power_hmc_mcp.hmc_client import _pcm_cpu_aggregates
from power_hmc_mcp.serialize import drop_none, ensure_json_serializable
from power_hmc_mcp.validation import validate_resource_id

__all__ = ["DemoProvider", "load_demo_fixture"]

_DEFAULT_FIXTURES_DIR = Path(__file__).parent / "demo_fixtures"


def load_demo_fixture(name: str, *, fixtures_dir: Path | None = None) -> Any:
    """Load a bundled demo fixture by tool name and return its parsed JSON."""
    directory = fixtures_dir or _DEFAULT_FIXTURES_DIR
    path = directory / f"{name}.json"
    if not path.is_file():
        raise FileNotFoundError(f"Demo fixture not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


class DemoProvider:
    """Provider backed by bundled demo fixtures. No network calls."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._systems: list[dict[str, Any]] = cast(
            list[dict[str, Any]],
            load_demo_fixture("list_managed_systems"),
        )
        self._managed_system: dict[str, Any] = cast(
            dict[str, Any],
            load_demo_fixture("get_managed_system"),
        )
        self._lpars: list[dict[str, Any]] = cast(
            list[dict[str, Any]],
            load_demo_fixture("list_lpars"),
        )
        self._lpar_status: dict[str, Any] = cast(
            dict[str, Any],
            load_demo_fixture("get_lpar_status"),
        )
        self._lpar: dict[str, Any] = cast(dict[str, Any], load_demo_fixture("get_lpar"))
        self._partition_profiles: list[dict[str, Any]] = cast(
            list[dict[str, Any]],
            load_demo_fixture("list_partition_profiles"),
        )
        self._capacity: dict[str, Any] = cast(
            dict[str, Any],
            load_demo_fixture("get_capacity"),
        )

    @property
    def settings(self) -> Settings:
        return self._settings

    def login(self) -> None:
        hint = self._settings.hmc_api_version_hint
        observability.log_logon_end(
            self._settings.hmc_host,
            outcome="demo",
            api_version_hint=hint,
        )

    def close(self) -> None:
        hint = self._settings.hmc_api_version_hint
        observability.log_logoff_end(
            self._settings.hmc_host,
            outcome="demo",
            api_version_hint=hint,
        )

    def list_managed_systems(self) -> list[dict[str, Any]]:
        return self._systems

    def get_managed_system(self, managed_system_id: str) -> dict[str, Any]:
        del managed_system_id
        return self._managed_system

    def list_lpars(self, managed_system_id: str) -> list[dict[str, Any]]:
        del managed_system_id
        return self._lpars

    def get_lpar_status(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        del managed_system_id, lpar_id
        return self._lpar_status

    def get_lpar(self, managed_system_id: str, lpar_id: str) -> dict[str, Any]:
        del managed_system_id, lpar_id
        return self._lpar

    def get_lpar_quick(self, lpar_id: str) -> dict[str, Any]:
        validated = validate_resource_id(lpar_id, field="lpar_id")
        return ensure_json_serializable(
            {
                "lpar_id": validated,
                "placeholder": True,
                "message": (
                    "[PLACEHOLDER] Composite quick-property endpoint not yet "
                    "wired. Pending firmware-version latency validation. "
                    "See docs/hmc-compatibility.md 'LPAR Composite Quick Endpoint'."
                ),
            },
        )

    def list_partition_profiles(self, lpar_id: str) -> list[dict[str, Any]]:
        del lpar_id
        return self._partition_profiles

    def get_capacity(
        self,
        managed_system_id: str,
        *,
        mode: CapacityOutputMode = "metadata",
    ) -> dict[str, Any]:
        del managed_system_id, mode
        return self._capacity

    def get_capacity_full(
        self,
        managed_system_id: str,
        metrics_href: str,
    ) -> dict[str, Any]:
        system_id = validate_resource_id(managed_system_id, field="managed_system_id")
        if not self._settings.is_managed_system_allowed(system_id):
            raise HmcValidationError(
                f"Managed system {system_id} is not in HMC_ALLOWED_MANAGED_SYSTEMS",
            )
        if not metrics_href or not metrics_href.strip():
            raise HmcValidationError("metrics_href must be a non-empty URL string")

        aggregates = _pcm_cpu_aggregates({})
        return ensure_json_serializable(
            {
                "managed_system_id": system_id,
                "metrics_href": metrics_href,
                "placeholder": True,
                "message": (
                    "[PLACEHOLDER] PCM full metric fetch not yet implemented; "
                    "Phase B2-7b will wire the real HTTP call. "
                    "PCM field shape (utilizedProcUnits / "
                    "utilizedProcUnitsDeductIdle) is confirmed against IBM "
                    "Docs Power9/10/11."
                ),
                **aggregates,
            }
        )

    def is_authenticated(self) -> bool:
        return False

    def health_check(self) -> dict[str, Any]:
        return ensure_json_serializable(
            drop_none(
                {
                    "status": "ok",
                    "hmc_host": self._settings.hmc_host,
                    "session_active": False,
                    "managed_system_count": 1,
                }
            )
        )

    @staticmethod
    def _demo_write_response(operation: str) -> dict[str, Any]:
        """Stable write-tool response shape returned when demo mode is active."""
        return {
            "executed": False,
            "demo": True,
            "operation": operation,
            "message": "Demo mode active — no HMC calls made",
            "suggested_next_step": (
                "Demo mode is active — no HMC calls are made. "
                "Set HMC_DEMO_MODE=false to execute against a real HMC."
            ),
        }

    def create_lpar_from_profile(
        self,
        managed_system_id: str,
        profile_name: str,
        new_lpar_name: str,
        overrides: dict[str, Any] | None = None,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, profile_name, new_lpar_name, overrides, authorization
        return self._demo_write_response("create_lpar_from_profile")

    def start_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, lpar_id, authorization
        return self._demo_write_response("start_lpar")

    def stop_lpar(
        self,
        managed_system_id: str,
        lpar_id: str,
        mode: str = "normal",
        *,
        authorization: WriteAuthorization,
    ) -> dict[str, Any]:
        del managed_system_id, lpar_id, mode, authorization
        return self._demo_write_response("stop_lpar")
