# Contributing

Thanks for helping improve **power-hmc-mcp**. This project exposes IBM Power HMC operations as MCP tools; **read tools work today, write tools are scaffolded behind a structural guardrail and don't touch the HMC yet** (Phase A through C in [`TODO.md`](TODO.md)).

Before you start, please skim the [glossary](docs/glossary.md) so terms like HMC, LPAR, PCM, UOM, and MCP have consistent meaning.

## Development setup

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env   # fill in HMC_* values for manual testing only
```

## Checks before opening a PR

Run `pre-commit run --all-files` before every push; CI runs the same pre-commit gate on every PR and on `main`.

```bash
pre-commit run --all-files
pytest --cov=src/power_hmc_mcp --cov-report=term-missing -q
ruff check .
ruff format --check .
mypy src/power_hmc_mcp
```

CI runs the same checks on Python 3.11 and 3.12, uploads coverage to Codecov, and runs `secret-scan` + `pip-audit` on every push/PR to `main` (see [`.github/workflows/`](.github/workflows/) and [`docs/release-engineering.md`](docs/release-engineering.md)).

Use the [pull request template](.github/PULL_REQUEST_TEMPLATE.md): link an issue, pick a **Phase** (B–I), and check IBM/HMC validation when behavior touches the HMC client.

## What good change looks like

- Match existing style: typed Python 3.11+, `httpx` sync client, normalized dict responses (no raw XML at the MCP boundary).
- Tests use `respx` mocks and fixtures under `tests/fixtures/`; avoid requiring a live HMC in unit tests.
- Update docs alongside code. Source of truth pointers:
  - new env var or flag → [`docs/operations.md` configuration reference](docs/operations.md#configuration-reference) **and** `.env.example`
  - new event type or field → [`docs/operations.md` standard event types](docs/operations.md#standard-event-types) (and the `FIELD_*` constants in `observability.py`)
  - new HMC route → `routes.py` only; never inline literals
  - new tool → architecture extending recipes (below) **and** the read/write tables in [`docs/agent-guide.md`](docs/agent-guide.md)
- Keep `[RISK]` / `[PLACEHOLDER]` / `[ASSUMPTION]` markers explicit in code comments and synced with `TODO.md`.

## Adding tools

Two recipes, one per kind, both detailed in [`docs/architecture.md` Extending safely](docs/architecture.md#extending-safely):

### Read tool

1. Add URL builder in `routes.py`.
2. Add a method on `HmcClient` using `_request` (default `RequestClassification.READ`).
3. Add a thin MCP wrapper under `src/power_hmc_mcp/tools/`, decorated with the `READ_ONLY` annotation.
4. Add the name to `READONLY_TOOL_NAMES` in `tools/__init__.py` and call its `register(...)` in `_register_read_tools`.
5. Cover with tests using `respx` against fixtures.

### Write tool

The structural guardrail is non-negotiable — server boot fails if you skip the marker. Required pattern:

1. Client method takes `authorization: WriteAuthorization` (no `execute: bool`); body starts with `self._require_authorization(authorization, operation="<name>")`.
2. MCP tool body wears **both** `@mcp.tool(annotations=WRITE_TOOL_ANNOTATIONS)` and `@mark_write_tool` and delegates to `run_write_tool(...)` inside `mcp_tool_call(...)`.
3. Add the name to `WRITE_TOOL_NAMES` in `tools/__init__.py` and call its `register(...)` inside the `if writes_enabled:` block.
4. Add denied / dry-run / authorized assertions on `write_audit` emission (see `tests/test_tools_write.py` for the pattern).

**Don't work around the boot-time marker check.** It exists precisely to catch "forgot the decorator on a new write tool" before any review or deployment. If you find yourself wanting to bypass it, you almost certainly want to fix the missing decorator instead.

## Firmware validation rules

These rules exist because most behavioural unknowns in this repo are firmware-dependent and [`docs/hmc-compatibility.md`](docs/hmc-compatibility.md) is our single source of truth for what has actually been observed against a real HMC.

- **No real write POSTs without all three of:**
  1. A lab HMC capture confirming both the `{OP}` name and the payload body for the operation.
  2. A new row in the appropriate [`docs/hmc-compatibility.md`](docs/hmc-compatibility.md) table (e.g. *Write Operation Paths*) with `firmware version`, `capture date`, and `tester`.
  3. The corresponding entry in [`TODO.md`](TODO.md) Phase C flipped to completed in the same PR.
- **No `[ASSUMED]` → `[VALIDATED]` flips** (in code comments or docs) unless the PR also adds a capture row in `docs/hmc-compatibility.md`. If a capture *contradicts* a prior assumption, leave the assumption as `[RISK]` and add the new observation alongside — never silently overwrite.
- **No behaviour keyed off `HMC_API_VERSION_HINT`.** It is logging metadata only; PCM field selection (`utilizedProcUnitsDeductIdle`) reads `utilInfo.version` from the in-band PCM payload, and state/echo handling stay firmware-agnostic until a compatibility row says otherwise.
- **PR description must link the compatibility row(s)** for any change that touches firmware-sensitive behaviour (LPAR state mapping, correlation echo, quick endpoints, PCM full fetch, write OP names). Use the *Compatibility doc rows* checkbox in [`.github/PULL_REQUEST_TEMPLATE.md`](.github/PULL_REQUEST_TEMPLATE.md).
- **The structural write guardrail is not negotiable.** `WriteAuthorization`, `@mark_write_tool`, and `run_write_tool` form the contract that makes real writes impossible without the explicit firmware-validation work above. If you find yourself wanting to bypass the marker check or skip the dry-run envelope, fix the missing decorator instead — see *Adding tools → Write tool* above.

## Reporting issues

Use the [bug report](.github/ISSUE_TEMPLATE/bug_report.md) or [feature request](.github/ISSUE_TEMPLATE/feature_request.md) templates. Include HMC firmware version (if known), Python version, redacted config (no passwords), and the MCP tool name plus arguments that failed. The `correlation_id` from the failing log line is gold — it joins MCP-side and HMC-side logs in one query.

Security vulnerabilities: see [`SECURITY.md`](SECURITY.md) — do not file public issues.
