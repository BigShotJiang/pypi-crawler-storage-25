# Streamable-HTTP HMC session affinity (Phase D)

**Status:** decided. v1 default is **shared** session affinity; per-client and
per-request modes are documented as future opt-ins.

**Scope:** when `HMC_MCP_TRANSPORT=streamable-http`, multiple MCP clients can
connect to the same `power-hmc-mcp` process concurrently. This document
records the policy for how those incoming MCP connections map onto outbound
HMC sessions.

For terminology see [`docs/glossary.md`](../glossary.md). For the threat model
this binds against see [`docs/design/threat-model.md`](threat-model.md).

---

## Three options considered

| Option | One HMC session per | Pros | Cons |
|--------|---------------------|------|------|
| **shared** | server process | matches today's behaviour; lowest HMC RBAC noise; minimal connection churn; predictable rate-limit posture | every MCP client drives the *same* HMC user — gateway / SSO must enforce per-caller identity |
| **per-client** | MCP HTTP connection | each MCP caller's actions appear under a distinct HMC session token | N-fold session count; HMC session-table pressure; multi-step agent loops re-login on reconnects; per-client lifetime tracking required |
| **per-request** | MCP tool call | strongest isolation; no token reuse across calls | login latency on every call (typically 100s of ms); HMC RBAC log volume goes up O(traffic); incompatible with `HMC_MAX_REAUTH_ATTEMPTS` semantics that key off "the" session |

## Decision: ship **shared** as v1 default

* Matches the v0.x behaviour and the structural write boundary
  (`WriteAuthorization` capability tokens are already correlation-id-keyed,
  not HMC-session-keyed).
* `HMC_MAX_REAUTH_ATTEMPTS` and the `session_reauth` event continue to
  describe one session lifecycle per process — no semantic split.
* `HMC_ALLOWED_MANAGED_SYSTEMS` and the per-correlation-id `mcp_tool_call`
  / `write_audit` events remain the supported per-call enforcement surface.
* The **gateway in front of the streamable-HTTP transport** is where
  per-caller identity, rate-limiting, and authentication belong. The MCP
  server intentionally does not implement auth itself
  ([`docs/transports.md`](../transports.md#security-notes)).

### What "shared" means concretely

* A single `HmcClient` (and therefore a single `HmcSession`) is constructed
  at server startup in `mcp_server.main()` (today's wiring) and is reused
  across every incoming streamable-HTTP request and every MCP tool call.
* The HMC session token lives in process memory; on the first call after
  startup `_ensure_session()` triggers `login()`; on a 401 mid-request the
  existing re-auth path applies (`HMC_MAX_REAUTH_ATTEMPTS`,
  `session_reauth` event with `outcome=success|failure`).
* Multi-HMC operation (D5) layers per-alias `HmcClient` instances on top
  of this model — each alias keeps **its own** shared session; the
  `(alias, mode)` pool key prevents a sync and async client for the same
  alias from racing on the same token.

### What "shared" does **not** mean

* It does **not** authorise one MCP caller as another at the application
  layer. Tool calls remain identified by the MCP correlation ID and (with
  D5) by `hmc_alias`; SIEM rules pin on those, not on the HMC session.
* It does **not** preclude per-caller HMC users — operators that need
  blast-radius isolation should run separate `power-hmc-mcp` processes
  (one per HMC user / posture) behind the same gateway. Multi-HMC registry
  (D5) is a different axis (one process, many HMCs); per-caller is still a
  multi-process pattern.

## Future opt-ins (deferred — not implemented in D2)

If a future deployment requires stronger isolation, two opt-in modes can
be added without breaking the shared default:

* `HMC_MCP_HTTP_SESSION_AFFINITY=per-client` — track an HMC session per
  incoming MCP connection (keyed by `Mcp-Session-Id` from the streamable
  HTTP transport). Lifecycle coupling = MCP connection lifetime; idle MCP
  connections are reaped to bound the HMC session table. Requires a new
  per-connection state container in `mcp_server.py`.
* `HMC_MCP_HTTP_SESSION_AFFINITY=per-request` — log on / log off around
  each tool call. Latency-prohibitive for chatty agents; only ship if a
  customer compliance requirement demands it.

Both modes need:

* The session-affinity env var added to `Settings` with a `field_validator`
  rejecting unknown values.
* The mode surfaced in the `mcp_tool_start` log fields so operators can
  tell which path serviced a given call.
* The threat-model doc updated to enumerate which guarantees each mode
  adds (none today vs per-client isolation vs per-call zero retention).

Until those land, the shared default is canonical.

## Implementation note (D2)

D2 ships only the **decision and documentation** — `mcp_server.main()`
already constructs a single `HmcClient` and reuses it across requests, so
the "shared" semantic is in place by virtue of unchanged code. D5 layers
the `(alias, mode)` keyed pool on top.

The reverse-proxy hardening guidance for ingress, mTLS, and timeouts that
match this model lives in [`docs/transports.md`](../transports.md) and the
companion examples under [`examples/deploy/`](../../examples/deploy/).

## Related

* [`docs/transports.md`](../transports.md) — operator-facing transport guide.
* [`docs/architecture.md`](../architecture.md) — write safety model + Multi-HMC Registry (Phase D+).
* [`docs/operations.md`](../operations.md) — `HMC_MAX_REAUTH_ATTEMPTS`, `session_reauth` event semantics.
* [`docs/design/threat-model.md`](threat-model.md) — assumptions a gateway-in-front model is meant to enforce.
