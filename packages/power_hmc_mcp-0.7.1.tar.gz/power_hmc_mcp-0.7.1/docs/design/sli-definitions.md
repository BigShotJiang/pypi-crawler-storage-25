# SLI / SLO Definitions

Status: Phase E design. Thresholds marked [PROPOSED — adjust after lab capture] require lab capture to validate. See [`docs/hmc-compatibility.md`](../hmc-compatibility.md) for firmware context.

This document is the canonical SLI/SLO reference for Phase E. All field names map 1:1 to `FIELD_*` constant string values in [`src/power_hmc_mcp/observability.py`](../../src/power_hmc_mcp/observability.py). Every structured log event also carries base fields `correlation_id`, `event_type`, and `component` (`power_hmc_mcp`).

## SLI 1 — HMC request latency (`hmc_request_latency_p99`)

**Definition:** 99th percentile of outbound HMC HTTP request duration over a rolling 5-minute window.

**Source event:** `event_type=hmc_request_end` (emitted by `log_hmc_request_end` in `observability.py`).

**Primary field:** `duration_ms` (`FIELD_DURATION_MS`)

**Segmentation dimensions:**

| Dimension | Field constant | Field value | Notes |
|-----------|----------------|-------------|-------|
| HTTP method | `FIELD_HMC_METHOD` | `hmc_method` | e.g. `GET`, `PUT`, `DELETE` |
| Route family | `FIELD_HMC_PATH` | `hmc_path` | Group by path prefix / route family |
| Outcome | `FIELD_OUTCOME` | `outcome` | Operator rollup convention (not frozenset-enforced): `success`, `retried`, `error`. Runtime values include `success`, `auth_retry` (rollup → `retried`), `auth_error`, `http_error`, `transport_error` (rollup → `error`) |
| HMC alias | `FIELD_HMC_ALIAS` | `hmc_alias` | Emitted on `hmc_request_end` when multi-HMC registry (D5) is active and the parent `mcp_tool_call` bound an alias — [closed — E2] |
| HTTP status | `FIELD_HMC_STATUS` | `hmc_status` | Optional drill-down dimension |
| Correlation | `FIELD_CORRELATION_ID` | `correlation_id` | Join key for alias lookup |

**SLO strawman:** p99 &lt; 2000 ms over a 5-minute window. [PROPOSED — adjust after lab capture]

**Log query example (platform-agnostic pseudocode):**

```text
events = filter(logs,
  event_type == "hmc_request_end",
  timestamp in window)

# Optional alias JOIN (required for per-alias dashboards today):
# alias = lookup(events.correlation_id -> mcp_tool_end.hmc_alias)

p99 = percentile(events.duration_ms, 99)
group_by(hmc_method, path_prefix(hmc_path), outcome, hmc_alias?)

alert if p99 > 2000  # [PROPOSED — adjust after lab capture]
```

Maps to structured JSON log queries (`event_type`, `duration_ms`, `hmc_method`, `hmc_path`, `outcome`) and a future OTEL histogram metric on `hmc.request` with `duration_ms` as the value and the segmentation fields as attributes.

## SLI 2 — Tool error rate (`tool_error_rate`)

**Definition:** Ratio of failed MCP tool invocations to total invocations per tool over a rolling 5-minute window.

**Source event:** `event_type=mcp_tool_end` (emitted by `log_tool_end` via `mcp_tool_call` in `observability.py`).

**Primary fields:**

| Field constant | Field value | Values |
|----------------|-------------|--------|
| `FIELD_OUTCOME` | `outcome` | `success` \| `error` |
| `FIELD_TOOL_NAME` | `tool_name` | MCP tool name |

**Optional segmentation:**

| Field constant | Field value | Notes |
|----------------|-------------|-------|
| `FIELD_HMC_ALIAS` | `hmc_alias` | Present when multi-HMC registry (D5) is active and the tool was invoked with an alias |
| `FIELD_ERROR_TYPE` | `error_type` | Present only on the error path (exception class name) |
| `FIELD_CORRELATION_ID` | `correlation_id` | Join key to related HMC request events |

**Formula:** `count(outcome=error) / count(all)` per `tool_name` per window.

**SLO strawman:** &lt; 1% error rate per tool over a 5-minute window. [PROPOSED — adjust after lab capture]

**Log query example (platform-agnostic pseudocode):**

```text
events = filter(logs,
  event_type == "mcp_tool_end",
  timestamp in window)

rate = count(events where outcome == "error") / count(events)
group_by(tool_name, hmc_alias?, error_type?)

alert if rate > 0.01  # [PROPOSED — adjust after lab capture]
```

Maps to structured JSON log queries (`event_type`, `outcome`, `tool_name`) and a future OTEL counter/ratio metric on `mcp.tool` with `outcome` and `tool_name` as attributes.

## SLI 3 — Session reauth rate (`session_reauth_rate`)

**Definition:** Ratio of session re-authentication events to total HMC HTTP requests over a rolling 5-minute window.

**Source event (numerator):** `event_type=session_reauth` (emitted by `log_session_reauth` in `observability.py`).

**Source event (denominator):** `event_type=hmc_request_end` (emitted by `log_hmc_request_end`).

**Primary fields (numerator):**

| Field constant | Field value | Values |
|----------------|-------------|--------|
| `FIELD_OUTCOME` | `outcome` | `success` \| `failure` (frozenset-enforced) |
| `FIELD_TRIGGER` | `trigger` | `401_mid_request` (frozenset-enforced) |
| `FIELD_HMC_HOST` | `hmc_host` | HMC hostname from session settings |

**`hmc_alias` on `session_reauth`:** [closed — E2] `log_session_reauth` accepts optional `hmc_alias`; when set (or propagated from the active `mcp_tool_call` context), `FIELD_HMC_ALIAS` is emitted on the `session_reauth` payload and the `session.reauth` OTEL metric.

**Formula:** `count(event_type=session_reauth) / count(event_type=hmc_request_end)` per window, segmented by `hmc_host` or `hmc_alias` when present.

**SLO strawman:** &lt; 0.5% reauth rate per alias over a 5-minute window. [PROPOSED — adjust after lab capture]

**Log query example (platform-agnostic pseudocode):**

```text
reauths = filter(logs,
  event_type == "session_reauth",
  timestamp in window)

requests = filter(logs,
  event_type == "hmc_request_end",
  timestamp in window)

# Per-host (available today):
rate_by_host = count(reauths) / count(requests)
group_by(hmc_host)

# Per-alias (available when hmc_alias is on session_reauth / hmc_request_end):
rate_by_alias = count(reauths) / count(requests)
group_by(hmc_alias)

alert if rate_by_alias > 0.005  # [PROPOSED — adjust after lab capture]
```

Maps to structured JSON log queries on `session_reauth` and `hmc_request_end` events and a future OTEL counter/ratio metric on `session.reauth`.

## Derivability from today's pipeline

| SLI | Available from sync log pipeline today? | Requires Phase E OTEL export? |
|-----|----------------------------------------|-------------------------------|
| `hmc_request_latency_p99` | **Yes** — derive p99 from `hmc_request_end` events using `duration_ms` (`FIELD_DURATION_MS`), segmented by `hmc_method`, `hmc_path`, `outcome`, and `hmc_alias` when present — [closed — E2] | **Yes** — continuous metric export and SLO dashboards via E2 `hmc.request` OTEL histogram |
| `tool_error_rate` | **Yes** — fully derivable from `mcp_tool_end` events using `outcome` (`FIELD_OUTCOME`) and `tool_name` (`FIELD_TOOL_NAME`); optional `hmc_alias` and `error_type` when present | **Yes** — E2 `mcp.tool` OTEL counter/ratio stream |
| `session_reauth_rate` | **Yes** — numerator from `session_reauth` (`outcome`, `trigger`, `hmc_host`, optional `hmc_alias`); denominator from `hmc_request_end`. Per-alias rate available when `hmc_alias` is present — [closed — E2] | **Yes** — E2 `session.reauth` OTEL counter/ratio |

None of the three SLIs require Phase D async MCP tool wiring (D5.5). The sync log pipeline already emits all source events.

```mermaid
flowchart LR
  mcpToolCall["mcp_tool_call"] --> toolEnd["mcp_tool_end"]
  mcpToolCall --> hmcSession["HmcSession._request"]
  hmcSession --> reqEnd["hmc_request_end"]
  hmcSession --> reauth["session_reauth"]
  reauth -.->|"hmc_alias when bound"| toolEnd
```

## `telemetry_hook` call sites (Phase E — E2 target)

These are the EXACT calls E2 will add to `observability.py`. The `event_name` values use OTEL dot-notation (distinct from the log `event_type` snake_case values). Use `FIELD_*` constant string values as attribute dict keys.

| SLI | event_name | attributes dict keys |
|-----|------------|----------------------|
| `hmc_request_latency_p99` | `hmc.request` | `duration_ms`, `hmc_method`, `hmc_path`, `hmc_status`, `outcome`, `correlation_id`, `hmc_alias` (optional — present when `FIELD_HMC_ALIAS` is in the log payload) |
| `tool_error_rate` | `mcp.tool` | `tool_name`, `outcome`, `error_type` (optional — error path only), `correlation_id`, `hmc_alias` (optional) |
| `session_reauth_rate` | `session.reauth` | `hmc_host`, `outcome`, `trigger`, `correlation_id`, `hmc_alias` (optional — emitted when bound by `mcp_tool_call` or passed explicitly) |

E2 wires `telemetry_hook` at each SLI call site. When `HMC_OTEL_ENDPOINT` is set and `power-hmc-mcp[otel]` is installed, exports OTLP spans and `{event_name}.count` counters; otherwise falls back to DEBUG `telemetry_stub` log events. Providers initialize lazily once per process; `atexit` flush/shutdown prevents silent drops on normal exit. Spans carry full attributes (including `correlation_id` and full `hmc_path`); counter labels omit `correlation_id` and normalize `hmc_path` to route family for bounded metric cardinality.

## Phase E gate conditions

Phase E2 (OTEL wiring) is considered complete when all of the following are true:

1. **`telemetry_hook` wired to a real OTEL exporter** — OTLP export when `HMC_OTEL_ENDPOINT` is set and `power-hmc-mcp[otel]` is installed; DEBUG stub fallback otherwise. [closed — E2]
2. **All three SLIs visible as OTEL metrics** — `hmc.request` (latency histogram), `mcp.tool` (error rate counter/ratio), `session.reauth` (reauth rate counter/ratio), each carrying the attribute keys specified above. [closed — E2]
3. **`hmc_alias` added to `log_session_reauth` and propagated onto `hmc_request_end`** — per-alias reauth rate without JOIN. [closed — E2]
4. **Lab data collected** to validate or revise all SLO thresholds marked [PROPOSED — adjust after lab capture]. Acceptance criteria pin on the strawman thresholds in this document until lab capture replaces them with validated values. See [`docs/hmc-compatibility.md`](../hmc-compatibility.md) for the firmware capture workflow.
