# Write idempotency policy (Phase C prerequisite)

Status: **Draft** — pending Phase C entry.
Owners: maintainers + first lab-HMC reviewer.
Last updated: 2026-05-18.

This document fixes the idempotency design **before** the first real `POST`
lands so that the structural write boundary established in Phase A
([`tools/write.py`](../../src/power_hmc_mcp/tools/write.py),
[architecture: write-safety-model](../architecture.md#write-safety-model))
does not have to change shape mid-implementation.

## Why decide now

The choice affects three contracts at once:

1. The [`WriteAuthorization`](../../src/power_hmc_mcp/guardrails.py) capability
   token shape. If idempotency requires additional context on the token (for
   example, an HMC-side request token), every write-tool signature changes.
2. The `write_audit` event enum (`outcome` field is currently
   `denied | dry_run | authorized`).
3. The agent-facing tool JSON schemas — adding an `idempotency_key` parameter
   later is a schema-drift event for every consumer.

Deciding after wiring forces a breaking change to all three.

## Decision

| Mechanism | Tool | Layer | Status |
|-----------|------|-------|--------|
| Client-side state check | `start_lpar`, `stop_lpar` | **Primary** | Required for Phase C entry |
| HMC-side request token (`idempotency_key`) | All three writes | **Secondary, opt-in** | Wired only after one firmware capture confirms HMC support |
| Client-side state check | `create_lpar_from_profile` | Not applicable (creation) | — |

### Primary: client-side state check (start_lpar / stop_lpar)

Before issuing the write `POST`, the executor:

1. Reads current LPAR state via the existing `get_lpar_status` path
   ([`hmc_client.HmcClient.get_lpar_status`](../../src/power_hmc_mcp/hmc_client.py)).
2. Refuses with a typed `HmcAlreadyInDesiredStateError` if the partition is
   already in the target state (`Running` for `start_lpar`, `Not Activated`
   for `stop_lpar`, per the canonical states surfaced by
   `normalize_lpar_state`).
3. Otherwise proceeds with the `POST`.

Rationale:

- Works against any HMC firmware; no dependency on a header or body field
  that may not exist on older firmware.
- Costs exactly one extra GET per write call. The GET is small (LPAR
  quick-property endpoint or a single UOM GET) and is already retry-armed by
  the read pipeline.
- Produces a clean audit trail: a new `outcome="denied_idempotent"` value on
  the `write_audit` event makes the no-op explicit rather than swallowing the
  duplicate silently.
- **Does not change** the `WriteAuthorization` shape. The capability token
  remains an opaque sentinel issued by `run_write_tool`; idempotency is a
  pre-condition on the executor body, not on the authorization.

### Secondary: HMC-side request token (opt-in)

A future `idempotency_key: str | None` parameter on each write tool, default
`None`:

- When set, forwarded to the HMC in whichever header or body field the
  firmware capture confirms (likely `If-Match` or a body element on the
  appropriate IBM HMC PowerVM POST schema).
- When `None`, behaviour is identical to today; the client-side state check
  is the only protection.

Wire this layer only after **one firmware capture** confirms (a) which header
or body element the HMC accepts and (b) the HMC's de-duplication window. Until
then the parameter is documented as `[PLACEHOLDER]`.

### Not applicable: create_lpar_from_profile

Creation has no "is it already done?" state to read — the LPAR does not exist
yet. A GET-then-POST pattern is unsafe (race: two agents see "not present",
both create). The only safe idempotency for `create_lpar_from_profile` is a
request token. Defer the wiring decision until firmware capture confirms
support; until then, this tool's idempotency story is **document only**
(operators must ensure dual-control approval prevents concurrent submission —
see [`threat-model.md`](threat-model.md) for the approval workflow).

## Audit event extension

`log_write_audit` ([`observability.py`](../../src/power_hmc_mcp/observability.py))
gains one new outcome value:

```text
outcome ∈ { "denied", "dry_run", "authorized", "denied_idempotent" }
```

Schema invariants:

- `denied_idempotent` is **only** emitted by the executor (after the GET
  reports the partition is already in target state), not by
  `check_write_allowed`.
- `reason` field carries a short machine-readable token, e.g.
  `lpar_already_running` / `lpar_already_stopped`.
- All other fields (`tool_name`, `operation`, `execute_requested`,
  `correlation_id`) remain unchanged.

This change is additive on the consumer side: SIEM filters that previously
counted `outcome != "authorized"` as a denial continue to work; the new value
just provides a finer breakdown.

## Boundary preserved

The structural write boundary established in `v0.1.0b1` is unchanged:

- `WriteAuthorization` is still issued only by `run_write_tool`.
- `@mark_write_tool` boot-time validation still gates registration.
- `HmcClient` write methods still require `isinstance(WriteAuthorization)`.
- The executor's idempotency GET runs **inside** the `executor` callback
  passed to `run_write_tool` — i.e. **after** the authorization is issued and
  the `authorized` audit event has fired. The `denied_idempotent` event is
  therefore a second audit emission from inside the executor, not a
  replacement for `authorized`.

```mermaid
flowchart TD
    A[Agent calls start_lpar tool] --> B[run_write_tool]
    B --> C{check_write_allowed}
    C -->|denied| D["write_audit: denied"]
    C -->|dry_run| E["write_audit: dry_run"]
    C -->|allowed| F["write_audit: authorized"]
    F --> G[Executor: GET current state]
    G -->|already in target state| H["write_audit: denied_idempotent (no POST)"]
    G -->|state differs| I[POST to HMC]
    I --> J[Return executor result]
```

## Open questions for Phase C kickoff

1. **GET freshness.** How long is the client-side state check trusted?
   For `start_lpar` / `stop_lpar` the window is short (single tool call); a
   parallel HMC GUI operator could race. **Recommendation:** document this
   race in the `agent-guide.md` runbook entry; treat the operator workflow as
   the canonical authority. Do not add a stale-read mitigation in Phase C.
2. **Quick-property endpoint usage.** Once `HMC_PREFER_QUICK_PROPERTIES`
   firmware capture lands (B2-5), prefer the quick endpoint for the
   idempotency GET — it is 1 round-trip vs. 4 for the fan-out.
3. **`get_capacity` family.** Not relevant; capacity tools are read-only.

## Cross-references

- [`TODO.md` Phase C](../../TODO.md#phase-c--write-path-execution) — Phase C
  prerequisites list this doc as required reading.
- [`docs/architecture.md` write-safety-model](../architecture.md#write-safety-model)
  — current structural boundary.
- [`docs/design/threat-model.md`](threat-model.md) — covers the dual-control
  workflow that complements the client-side state check for production
  deployments.
- [`docs/agent-guide.md`](../agent-guide.md) — operator-facing description of
  the `executed=false / denied_idempotent` envelope (Phase C addition).
