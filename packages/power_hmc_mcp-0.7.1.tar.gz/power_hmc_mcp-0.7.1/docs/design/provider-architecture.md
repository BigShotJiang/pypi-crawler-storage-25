# Provider architecture (Phase J)

This document describes the backend provider abstraction introduced in Phase J.
For operator-facing env vars see [operations.md](../operations.md#provider-selection).
For HMC-specific firmware notes see [hmc-compatibility.md](../hmc-compatibility.md).

## Why Protocol over ABC

The sync backend is defined as a `@runtime_checkable` `typing.Protocol` in
[`provider.py`](../../src/power_hmc_mcp/provider.py), not an abstract base class.

Structural subtyping lets the existing [`HmcClient`](../../src/power_hmc_mcp/hmc_client.py)
satisfy the interface **without inheritance**, preserving the current class
hierarchy and adding zero runtime overhead on the HMC path. `mypy` still
enforces that every provider implements the full read/write surface.

`isinstance(client, HmcProvider)` works at runtime for conformance tests and
for tool registration shims that accept a single client or a pool.

## Provider matrix

| `HMC_PROVIDER` | Class | Status | Network |
|----------------|-------|--------|---------|
| `hmc` (default) | `HmcClient` | Production HMC REST | Yes (when not in demo) |
| `demo` | `DemoProvider` | Production (fixtures) | No |
| `powervs` | `PowerVSProvider` | Stub — raises `NotImplementedError` | No |

Factory: [`provider_factory.create_provider()`](../../src/power_hmc_mcp/provider_factory.py).

## `HMC_PROVIDER` and `HMC_DEMO_MODE`

These interact as follows:

| `HMC_DEMO_MODE` | `HMC_PROVIDER` | Backend |
|-----------------|------------------|---------|
| `true` | `hmc` (default) | **`DemoProvider`** (backward compat) |
| `true` | `demo` | `DemoProvider` |
| `false` | `hmc` | `HmcClient` |
| `false` | `demo` | `DemoProvider` |
| any | `powervs` | `PowerVSProvider` (stub) |

CI and existing deployments that set only `HMC_DEMO_MODE=true` continue to work
without setting `HMC_PROVIDER`. The server still emits the demo-mode `WARNING`
when `HMC_DEMO_MODE=true`.

Demo logic previously scattered through `HmcClient` now lives in
[`DemoProvider`](../../src/power_hmc_mcp/demo_provider.py), backed by
[`demo_fixtures/`](../../src/power_hmc_mcp/demo_fixtures/).

## Dispatch path

```text
mcp_server.main()
  └─ HmcClientPool.get_sync(alias)
       └─ create_provider(settings)
            ├─ HmcClient        (real HMC)
            ├─ DemoProvider     (fixtures)
            └─ PowerVSProvider  (stub)
```

MCP tool bodies are unchanged; they resolve a sync client via
`ClientResolver` and call the same method names regardless of backend.

Write guardrails (`guardrails.check_write_allowed`, `WriteAuthorization`,
`run_write_tool`) apply uniformly — no provider may bypass them.

Observability hooks (`observability.log_logon_end`, tool telemetry) fire on
every tool call regardless of provider.

## Adding a new provider

1. Implement every method on [`HmcProvider`](../../src/power_hmc_mcp/provider.py)
   in a new module (exclude Phase C job stubs unless you wire them).
2. Add a `case` branch in [`create_provider()`](../../src/power_hmc_mcp/provider_factory.py)
   and extend the `HmcProviderKind` literal in [`config.py`](../../src/power_hmc_mcp/config.py).
3. Document the new `HMC_PROVIDER` value in `.env.example`, this file, and
   [`operations.md`](../operations.md).

## PowerVS activation checklist (future)

[`PowerVSProvider`](../../src/power_hmc_mcp/powervs_provider.py) is a safe-to-instantiate
stub today. To make it real:

1. **Credentials** — `IBMCLOUD_API_KEY`, `POWERVS_WORKSPACE_ID`, `POWERVS_REGION`
   (optional fields already on `Settings`).
2. **IAM token exchange** — `POST https://iam.cloud.ibm.com/identity/token` with
   `grant_type=urn:ibm:params:oauth:grant-type:apikey`; refresh before expiry.
3. **Power VS REST API** — map MCP tool contracts to
   [IBM Cloud Power VS API](https://cloud.ibm.com/apidocs/power-cloud) resources
   (instances, PVMs, networks). Validate response shapes against real workspaces.
4. **Write safety** — reuse `WriteAuthorization` / `run_write_tool`; do not add
   async write methods until Phase D5.5 policy changes.
5. **Compatibility doc** — add a Power VS section or companion doc; cross-check
   HMC-specific notes in [hmc-compatibility.md](../hmc-compatibility.md) only where
   concepts overlap (LPAR state strings, capacity metrics).

## Out of scope (Phase J)

- Real IBM Cloud API calls
- Async provider interface (`HmcAsyncClient` still has its own demo branches)
- `execute_job` / `poll_job_status` on the protocol (Phase C placeholders on `HmcClient` only)
