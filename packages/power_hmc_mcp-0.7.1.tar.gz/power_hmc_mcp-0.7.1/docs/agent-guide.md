# Agent caller guide

Short reference for people building LangGraph / watsonx Orchestrate / Claude Desktop / custom MCP clients on top of `power-hmc-mcp`. Assumes you have a running server (see [README](../README.md)) and want to know what your agent will actually see. Terms are in the [glossary](glossary.md).

## What you connect to

`power-hmc-mcp` is a standard MCP server. Connect with any MCP-compliant client. Two transports:

- **stdio** — your client spawns the server as a subprocess. See [transports: stdio](transports.md#stdio-default).
- **streamable HTTP** — your client connects over HTTP. See [transports: streamable HTTP](transports.md#streamable-http).

What you call into:

- One typed JSON contract per tool.
- All resource identifiers are HMC REST UUIDs (not partition numbers, not hostnames). Get them from `list_managed_systems` and `list_lpars`.
- Read tools always return normalized JSON. Write tools return either a dry-run envelope or a placeholder-executed envelope (until Phase C wires real HMC mutation payloads).

**IBM doc alignment.** The server is **schema-aligned** with the IBM Power9/10/11 HMC REST documentation for the core resources it exposes (`ManagedSystem`, `LogicalPartition`, `LogicalPartitionProfile`, PCM `ProcessedMetrics`) — URL paths and field names match the IBM-published forms verbatim. **Runtime behavioural compatibility** (firmware-specific state strings, header-echo behaviour, write job operation names, composite quick endpoint shape) is validated only for the firmware versions listed in [`docs/hmc-compatibility.md`](hmc-compatibility.md). Uncaptured firmware behaviour stays `[ASSUMED]` until a row lands. Branch agent logic on the normalized fields surfaced by the tool contracts (e.g. `canonical_state`) — not on raw firmware strings — to insulate yourself from per-firmware drift.

## Tool surface

All tools (and their inputs / outputs) at a glance.

### Read tools (always registered)

Every read tool is registered with the shared `READ_ONLY` annotation (`readOnlyHint=True`, `destructiveHint=False`, `idempotentHint=True`, `openWorldHint=True`). Idempotent here means the tool semantics — calling again with the same inputs produces the same response shape — not that the underlying HMC inventory is frozen. `openWorldHint=True` reflects that every call reaches the configured HMC over HTTPS, so agent platforms should not treat these as pure local functions.

| Tool | Inputs | Returns |
|------|--------|---------|
| `list_managed_systems` | `limit`, `offset` (optional) | Envelope: `items` + `summary` (counts, `state_counts`, truncation metadata). Filtered by `HMC_ALLOWED_MANAGED_SYSTEMS` if set. |
| `get_managed_system` | `managed_system_id` | One managed system's normalized properties. |
| `list_lpars` | `managed_system_id`, `limit`, `offset` (optional) | Envelope: `items` + `summary` (counts, `state_counts`, truncation metadata). |
| `get_lpar` | `managed_system_id`, `lpar_id` | Full LPAR detail. |
| `get_lpar_status` | `managed_system_id`, `lpar_id` | LPAR status from canonical UOM (default) or quick fan-out (`HMC_LPAR_STATUS_SOURCE=quick`). |
| `list_partition_profiles` | `lpar_id`, `limit`, `offset` (optional) | Envelope: `items` + `summary` (counts, truncation metadata). |
| `get_capacity` | `managed_system_id`, `mode` | PCM sample metadata (`metadata`), summary (`summary`), or `full` placeholder. |
| `health_check` | _(none)_ | `{"status": "ok", "hmc_host": …, "session_active": bool, "managed_system_count": int}` — no inventory leak. |

### When should my agent call this?

Quick reference for picking the right read tool. Each tool's docstring carries the same guidance so it shows up in MCP tool listings too.

| Tool | Call it when… |
|------|---------------|
| `list_managed_systems` | Starting an inventory walk, or you need a `managed_system_id` to pass to anything else. |
| `get_managed_system` | You have a `managed_system_id` and need full server detail — name, state, MTMS, processor pool fields. |
| `list_lpars` | Enumerating the VMs on one server, or you need an `lpar_id` to pass to the LPAR tools. |
| `get_lpar` | You need full LPAR configuration (processors, memory, partition type) — not just run state. |
| `get_lpar_status` | The agent must decide on a next action ("running?", "shut down?"). Branch on `canonical_state`, never on `state`. |
| `list_partition_profiles` | Reporting saved configurations for an LPAR, or you need a `profile_name` for `create_lpar_from_profile`. |
| `get_capacity` | "How busy is this server?" Use `mode="summary"` for a cheap check, `mode="metadata"` for the per-sample list. |
| `health_check` | Pre-flight before a batch of calls, or diagnosing a suspected connectivity / auth problem. No inventory data returned. |

**Branch on canonical fields, not raw HMC strings.** The JSON contracts for these tools are stable and covered by `tests/test_contracts.py`. Firmware-dependent values (LPAR state strings, correlation header echo, write OP names, composite quick endpoint shape) are documented separately in [`docs/hmc-compatibility.md`](hmc-compatibility.md). The most common pitfall: comparing `state == "Running"` instead of `canonical_state == "running"`. The former couples your agent to a single firmware level; the latter is the stable enum.

### Write tools (registered only when `HMC_ENABLE_WRITE_TOOLS=true`)

| Tool | Inputs | Default | Returns |
|------|--------|---------|---------|
| `start_lpar` | `managed_system_id`, `lpar_id`, `execute=false` | dry-run | Dry-run envelope or placeholder-authorized body. |
| `stop_lpar` | `managed_system_id`, `lpar_id`, `mode="normal"`, `execute=false` | dry-run | Same. |
| `create_lpar_from_profile` | `managed_system_id`, `profile_name`, `new_lpar_name`, `overrides=null`, `execute=false` | dry-run | Same. |

A write tool **never** mutates the HMC today (Phase A scaffold). On the authorized path it returns `executed=false, placeholder=true` with a stable `audit` block. Phase C wires real payloads; the contract surface for agents will be backwards-compatible.

## List envelopes and pagination

Inventory list tools return a **dict envelope**, not a bare JSON array:

```json
{
  "items": [ { "id": "…", "name": "…", "state": "…", "uri": "…" } ],
  "summary": {
    "total_count": 42,
    "returned_count": 20,
    "offset": 0,
    "truncated": true,
    "next_offset": 20,
    "state_counts": { "running": 30, "not activated": 12 }
  }
}
```

- **`items`** — the page of results (same item shape as before Phase F).
- **`summary.total_count`** — full inventory size before pagination.
- **`summary.truncated`** — always explicit; never silently drops rows.
- **`summary.next_offset`** — present only when `truncated=true`; pass as `offset` on the next call.
- **`summary.state_counts`** — on `list_managed_systems` and `list_lpars` only (raw HMC state strings; branch run-state logic on `get_lpar_status.canonical_state`).

**Ordering:** `items` preserve the HMC Atom feed order returned for that call. Offset pagination is safe within one inventory snapshot (same tool invocation chain, no intervening mutations). If LPARs or managed systems may be added or removed between pages, re-call from `offset=0` rather than assuming `total_count` is unchanged.

**Pagination:** pass `limit` (max items) and optional `offset`. Omit `limit` to return the full list (still wrapped in the envelope). Example: `list_lpars(managed_system_id, limit=50, offset=summary.next_offset)`.

#### Migration from pre–Phase F list responses

| Before | After |
|--------|-------|
| `result[0]["name"]` | `result["items"][0]["name"]` |
| `len(result)` | `result["summary"]["total_count"]` |
| _(n/a)_ | `offset=result["summary"]["next_offset"]` when `truncated` is true |

Golden MCP envelope fixtures: `tests/fixtures/mcp/*.json`, asserted by `tests/test_mcp_list_envelope.py`. HmcClient item shapes remain in `tests/test_contracts.py`.

## Sample inputs and outputs

### `list_managed_systems`

Input: `{}` Output (truncated):

```json
{
  "items": [
    {
      "id": "38f2a140-b30f-8544-7a1b-2c3d4e5f6789",
      "name": "p10-tampa-01",
      "state": "Operating",
      "uri": "/rest/api/uom/ManagedSystem/38f2a140-…"
    }
  ],
  "summary": {
    "total_count": 1,
    "returned_count": 1,
    "offset": 0,
    "truncated": false,
    "state_counts": { "Operating": 1 }
  }
}
```

### `get_lpar_status`

Input: `{"managed_system_id": "38f2a140-…", "lpar_id": "lpar-1111-…"}` Output:

```json
{
  "managed_system_id": "38f2a140-…",
  "lpar_id": "lpar-1111-…",
  "source": "uom",
  "name": "app-prod-01",
  "state": "Running",
  "canonical_state": "running",
  "partition_id": "5",
  "rmc_state": "active",
  "properties": { "...": "..." }
}
```

**State fields — read this if your agent makes decisions on LPAR state.** `state` contains the raw string emitted by the HMC firmware (e.g. `"Running"`, `"Not Activated"`, `"Open Firmware"`). It varies between firmware levels and is intentionally **not** the field your agent should branch on. `canonical_state` is the normalized, lowercase-underscore key from a stable enum: `"running"`, `"not_activated"`, `"open_firmware"`, `"starting"`, `"stopping"`, `"error"`, `"migrating"`, `"hardware_discovery"`, `"unknown"`. Branch logic on `canonical_state`; surface `state` to humans. Any firmware-specific string not in the known set maps to `"unknown"` — never `null` (the field is only `null` when the underlying HMC property is absent entirely). Per-firmware mapping records live in [`docs/hmc-compatibility.md`](hmc-compatibility.md) 'LPAR State Strings' and stay `[ASSUMED]` until a firmware capture lands.

### `start_lpar` — dry-run (default)

Input: `{"managed_system_id": "…", "lpar_id": "…"}` (note: no `execute`)

Output:

```json
{
  "dry_run": true,
  "operation": "start_lpar",
  "params": {"managed_system_id": "…", "lpar_id": "…"},
  "message": "Dry run only; no changes were made to the HMC",
  "suggested_next_step": "Set execute=true to perform this operation, or review the operation and params above before proceeding."
}
```

### `start_lpar` — denied (writes disabled)

Input: `{"managed_system_id": "…", "lpar_id": "…", "execute": true}` Output:

```json
{
  "dry_run": true,
  "operation": "start_lpar",
  "params": {"managed_system_id": "…", "lpar_id": "…"},
  "message": "write tools are disabled by configuration",
  "suggested_next_step": "Set HMC_ENABLE_WRITE_TOOLS=true, restart the MCP server, then retry with execute=true.",
  "guardrail_outcome": "denied",
  "denial_reason_code": "writes_disabled"
}
```

### `start_lpar` — denied (execute flag required)

Input: `{"managed_system_id": "…", "lpar_id": "…"}` (writes enabled, `HMC_REQUIRE_EXECUTE_FLAG=true`, no `execute`) Output:

```json
{
  "dry_run": true,
  "operation": "start_lpar",
  "params": {"managed_system_id": "…", "lpar_id": "…"},
  "message": "execute flag is required for write operations",
  "suggested_next_step": "Pass execute=true after operator review, or call with execute=false for a dry-run preview only.",
  "guardrail_outcome": "denied",
  "denial_reason_code": "execute_required"
}
```

A `write_audit` log event with `outcome=denied` is emitted server-side at the same `correlation_id`.

### `start_lpar` — authorized (Phase A placeholder)

Input: `{"managed_system_id": "…", "lpar_id": "…", "execute": true}` (with `HMC_ENABLE_WRITE_TOOLS=true`)

Output:

```json
{
  "dry_run": false,
  "executed": false,
  "placeholder": true,
  "operation": "start_lpar",
  "params": {"managed_system_id": "…", "lpar_id": "…"},
  "message": "Phase A scaffold: no HMC mutation was performed. This response previews what would be executed. Write execution lands in Phase C.",
  "suggested_next_step": "Phase A placeholder: this write will execute against the HMC in Phase C once IBM payload schemas are validated. No action required.",
  "guardrail_outcome": "authorized_placeholder",
  "audit": {
    "correlation_id": "abcd-…",
    "operation": "start_lpar",
    "execute_requested": true,
    "hmc_request_preview": {"method": "POST", "path": "/rest/api/uom/.../operations/Start"},
    "record_status": "placeholder"
  }
}
```

## How to read responses

Three envelope shapes for write tools. Pick on the agent side:

- `dry_run == true` — nothing happened on the HMC. The `message` field tells you whether this was an explicit preview or a guardrail denial.
- `executed == false && placeholder == true` — Phase A scaffold; the guardrail authorized the call but the HMC mutation is not implemented. Treat as "would have run; come back in Phase C."
- `executed == true` — Phase C+ only; reserved for when real mutation is wired.

Every write tool response — denied, dry-run, or authorized — includes:

- **`suggested_next_step`** — deterministic plain-English next action.
- **`guardrail_outcome`** — `denied`, `preview`, or `authorized_placeholder` (branch on this, not on parsing `message`).
- **`denial_reason_code`** — on denied paths only: `writes_disabled` or `execute_required`.

Examples:

- Denied (writes off): `"denial_reason_code": "writes_disabled"` — set `HMC_ENABLE_WRITE_TOOLS=true`, restart, retry with `execute=true`.
- Denied (execute missing): `"denial_reason_code": "execute_required"` — pass `execute=true` after review.
- Dry-run preview: `"guardrail_outcome": "preview"` — no `denial_reason_code`.
- Authorized placeholder: `"guardrail_outcome": "authorized_placeholder"`.

For read tools, the response is just the normalized JSON (list tools use the envelope described above); errors propagate as MCP error responses (see below).

## Errors your agent will see

The HMC client raises typed exceptions; FastMCP serializes them into MCP error responses with the exception class name and message.

| Error | Meaning | What the agent should do |
|-------|---------|--------------------------|
| `HmcAuthError` | HMC credentials wrong or session can't be re-established. | Surface; do not retry blindly. Operator must intervene. |
| `HmcHttpError` | HMC returned a `≥400` status (other than `401` re-auth) or a transport error after retries. Carries `status_code` and `url`. | If `429`, back off. Otherwise surface. |
| `HmcParseError` | HMC response body did not match expected XML / Atom shape. | Surface; report the firmware version and tool used. |
| `HmcValidationError` | Input failed local validation (bad UUID, system not in allowlist). | The agent gave bad input — fix the call, do not retry. |
| `HmcError` | Base; never raised directly. | — |

Sample error response (MCP wire format, content varies by client):

```json
{ "isError": true, "content": [{"type": "text", "text": "HmcValidationError: Managed system <id> is not in HMC_ALLOWED_MANAGED_SYSTEMS"}] }
```

## Correlation IDs

- Every tool invocation gets a UUID `correlation_id` unless the caller already bound one (rare; some MCP hosts pass one in).
- The same ID appears on every server-side log line for the call and is propagated to the HMC via `X-Correlation-ID`.
- If the HMC echoes a correlation header back, the server captures it as `hmc_echo_correlation_id` on the `hmc_request_end` log event so both sides of the wire are joinable.

If your agent platform supports trace IDs, you can correlate at the platform level by reading `correlation_id` out of the server logs and joining with platform spans. W3C `traceparent` propagation is on the roadmap (see [`TODO.md`](../TODO.md) Phase E).

## Common patterns

### Inventory walk

1. `list_managed_systems` → read `result["items"]`, pick a UUID from an entry's `id`.
2. `list_lpars(managed_system_id)` → read `result["items"]` for LPAR UUIDs and names.
3. `get_lpar_status(managed_system_id, lpar_id)` for any LPAR you want detail on.

For large inventories, pass `limit` and follow `summary.next_offset` until `summary.truncated` is false.

### Capacity check

`get_capacity(managed_system_id, mode="summary")` — small payload, sample counts and recency. Use `mode="metadata"` for normalized sample list. Avoid `mode="full"` until Phase B implements metric JSON retrieval.

### Safe write attempt (Phase A scaffold)

1. Call the write tool with `execute=false` (default). Read the dry-run envelope; show the operator what *would* happen.
2. After explicit operator approval, call again with `execute=true`. The placeholder body comes back today; full execution is Phase C.

Always check `dry_run` and `executed` fields — never assume an authorized write touched the HMC. Today it doesn't.

## Things not to do

- Don't pass partition numbers or LPAR display names where a UUID is expected. The HMC REST API and this server identify resources by UUID.
- Don't loop on a write tool without backing off on errors — `HmcHttpError(status=429)` means "slow down."
- Don't try to construct `WriteAuthorization` from the client side. It only exists as an internal capability token; agents never see it. The `execute` boolean is the agent-facing knob.
- Don't expose raw HMC URLs / session tokens in agent prompts or context. The server already redacts them in logs; keep them out of agent state.

## Where to read more

- [Architecture: write safety model](architecture.md#write-safety-model) — why `execute=true` is safe to wire into agents.
- [Operations: write_audit schema](operations.md#write_audit-schema) — what a security reviewer will see.
- [Transports](transports.md) — how to actually connect.
- [Glossary](glossary.md) — every acronym defined.
