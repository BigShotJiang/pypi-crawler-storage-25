# HMC firmware compatibility

This file is updated as captures are collected against real HMC firmware. All entries are `[VALIDATED vX]` or `[ASSUMED]` until replaced by a real capture. **Do not remove `[RISK]` / `[PLACEHOLDER]` markers from source code without a corresponding row in this file.**

**Two layers of validation:** the project is **schema-aligned** with the IBM Power9/10/11 HMC REST documentation (URL paths and core resource field names match the IBM-published forms verbatim — see [`URL Routes — IBM Doc Alignment`](#url-routes--ibm-doc-alignment) and [`PCM Metric JSON Field Names`](#pcm-metric-json-field-names) below). **Runtime behavioural compatibility** (firmware-specific state strings, header echo, retry behaviour, composite quick endpoint shape, write job operation names) is validated only for firmware versions that appear in the per-area tables; the rest carry `[ASSUMED]` or `[PLACEHOLDER]`.

The structure of this document is shared by several Phase B2 work items (see [`TODO.md`](../TODO.md) Phase B2 section). Each item appends rows to the table that owns its scope. New firmware captures should be added in PRs that also flip the corresponding `[ASSUMED]` → `[VALIDATED vN]` annotation in the source comment.

How to contribute a capture:

1. Run the request against the target HMC and save the verbatim response. For XML responses, drop the file under [`tests/fixtures/firmware/`](../tests/fixtures/firmware/) following the naming convention in that directory's `README.md`.
2. Add a row to the relevant table below with `firmware version`, `capture date (YYYY-MM-DD)`, and `tester`.
3. If the capture confirms a previously `[ASSUMED]` value, change the annotation in source to `[VALIDATED vN]` and update the row's status here.
4. If the capture contradicts a previously assumed value, leave the assumption as `[RISK]` and add the contradicting observation as a new row with notes — do not silently overwrite.

## Tested firmware versions

| Firmware version | Source | Capture date | Tester | Notes |
|------------------|--------|--------------|--------|-------|
| _(none captured yet)_ | | | | |

## URL Routes — IBM Doc Alignment

URL strings emitted by the read-path builders in [`src/power_hmc_mcp/routes.py`](../src/power_hmc_mcp/routes.py) are aligned **verbatim** with the IBM-published URL forms. This is a schema-level alignment only — it does not certify runtime behaviour against any specific firmware level.

| Builder | Emitted path | Status | IBM doc |
|---------|--------------|--------|---------|
| `MANAGED_SYSTEM_COLLECTION_PATH` | `/rest/api/uom/ManagedSystem` | `[VALIDATED — IBM Docs Power10/11]` | [Managed System](https://www.ibm.com/docs/en/power10?topic=apis-managed-system) |
| `managed_system_path(uuid)` | `/rest/api/uom/ManagedSystem/{uuid}` | `[VALIDATED — IBM Docs Power10/11]` | [Managed System](https://www.ibm.com/docs/en/power10?topic=apis-managed-system) |
| `logical_partition_collection_path(sys)` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition` | `[VALIDATED — IBM Docs Power10/11]` | [Logical Partition (Power11)](https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition) |
| `logical_partition_path(sys, lpar)` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}` | `[VALIDATED — IBM Docs Power10/11]` | [Logical Partition (Power11)](https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition) |
| `logical_partition_quick_property_path(lpar, prop)` | `/rest/api/uom/LogicalPartition/{lpar}/quick/{prop}` | `[VALIDATED — IBM Docs Power10/11]` (URL shape) | [URL Model](https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis), [LPAR Quick properties](https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition) |
| `logical_partition_profiles_path(lpar)` | `/rest/api/uom/LogicalPartition/{lpar}/LogicalPartitionProfile` | `[VALIDATED — IBM Docs Power10/11]` | [Logical Partition Profile](https://www.ibm.com/docs/en/power10?topic=system-logical-partition-profile) |
| `pcm_processed_metrics_path(sys)` | `/rest/api/pcm/ManagedSystem/{sys}/ProcessedMetrics` | `[VALIDATED — IBM Docs Power9/10/11]` | IBM Power Systems PCM Atom feed |
| `logical_partition_composite_quick_path(lpar)` | `/rest/api/uom/LogicalPartition/{lpar}/quick` | `[PLACEHOLDER]` — not in URL-model docs, firmware-dependent | See [LPAR composite quick endpoint](#lpar-composite-quick-endpoint) |

Schema-level URL alignment does **not** imply runtime behavioural support on any specific firmware. Behavioural notes (state strings, echo, latency, content-type, etc.) live in the per-area tables below.

## Write Operation Paths

Owner: [Phase C](../TODO.md#phase-c--write-path-execution). Source code: [`src/power_hmc_mcp/routes.py`](../src/power_hmc_mcp/routes.py) `logical_partition_*_job_path`.

The IBM URL grammar for asynchronous jobs ([URL Model](https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis)) is:

* `GET  /rest/api/uom/{R}/{UUID}/do/{OP}` — fetch a JobRequest XML template.
* `PUT  /rest/api/uom/{R}/{UUID}/jobs` — submit the populated job.
* `GET  /rest/api/uom/{R}/{UUID}/jobs/{JOBID}` — poll job status.

The route builders emit the `/do/{OP}` shape, but the specific `{OP}` names below are **`[ASSUMPTION]` placeholders** pending firmware capture. The Phase C deliverable is to replace these placeholders with IBM-validated paths AND payload bodies after lab capture.

| Tool | Builder | Current placeholder path | OP name status | Firmware versions confirmed |
|------|---------|--------------------------|----------------|------------------------------|
| `start_lpar` | `logical_partition_start_job_path` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/do/PowerOn` | `[ASSUMPTION]` — historical callers used `PowerOn` or `PartitionStart` depending on firmware | _(none captured yet)_ |
| `stop_lpar` | `logical_partition_stop_job_path` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/do/PowerOff` | `[ASSUMPTION]` — shutdown mode (immediate vs. delayed) lives in the body, not the URL | _(none captured yet)_ |
| `create_lpar_from_profile` | `logical_partition_create_from_profile_path` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/do/PartitionTemplateCreatePartition` | `[ASSUMPTION]` — anchor-level job; body schema (profile reference, override blocks) is firmware-specific | _(none captured yet)_ |
| _(job submit)_ | `logical_partition_jobs_path` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/jobs` | `[ASSUMPTION]` — PUT submits populated JobRequest XML | _(none captured yet)_ |
| _(job poll)_ | `logical_partition_job_status_path` | `/rest/api/uom/ManagedSystem/{sys}/LogicalPartition/{lpar}/jobs/{jobId}` | `[ASSUMPTION]` — GET polls job status until terminal state | _(none captured yet)_ |

`HmcClient.start_lpar` / `stop_lpar` / `create_lpar_from_profile` continue to return `placeholder_execute_response(...)` on the authorized path; no real POST is issued. Do not promote any row above to `[VALIDATED]` without:

1. A firmware capture confirming both the `{OP}` name AND the payload body.
2. An integration test in `tests/` exercising the round trip against a lab HMC or simulator.
3. A `Phase C` entry in `TODO.md` flipped to completed.

## LPAR state strings

Owner: [B2-1](../TODO.md#phase-b--read-path-excellence-not-started). Source comment: [`src/power_hmc_mcp/normalize.py`](../src/power_hmc_mcp/normalize.py) `_LPAR_STATE_CANONICAL`.

| Raw HMC string | Canonical key | Status | Firmware versions confirmed |
|----------------|---------------|--------|------------------------------|
| `Running` | `running` | `[ASSUMED]` | — |
| `Not Activated` | `not_activated` | `[ASSUMED]` | — |
| `Open Firmware` | `open_firmware` | `[ASSUMED]` | — |
| `Starting` | `starting` | `[ASSUMED]` | — |
| `Stopping` | `stopping` | `[ASSUMED]` | — |
| `Error` | `error` | `[ASSUMED]` | — |
| `Migrating` | `migrating` | `[ASSUMED]` | — |
| `Hardware Discovery` | `hardware_discovery` | `[ASSUMPTION]` may also be `Hardware discovery` (one capitalized word) | — |
| `Unknown` | `unknown` | `[ASSUMED]` | — |
| _(any other string)_ | `unknown` (fallback) | by design — never `None` for non-`None` input | — |

## Correlation Header Echo

Owner: [B2-3](../TODO.md#phase-b--read-path-excellence-not-started). Source code: [`src/power_hmc_mcp/observability.py`](../src/power_hmc_mcp/observability.py) `log_hmc_request_end`.

Operators can override the primary header name with `HMC_CORRELATION_ECHO_HEADER` and the fallback list with `HMC_CORRELATION_ECHO_FALLBACK_HEADERS` (comma-separated). See [`docs/operations.md`](operations.md#observability) for the config keys.

### IBM HMC REST API spec — which headers are echoed

Per-header status below is **spec-level** (IBM-documented). The actual per-firmware echo behaviour is **`[ASSUMED]`** until rows land in the [Per-firmware observations](#per-firmware-observations) table.

| Header Name | IBM HMC Spec Status | Documented Behaviour | Notes |
|-------------|---------------------|----------------------|-------|
| `X-Transaction-ID` | `[VALIDATED — IBM HMC REST API spec]` | Spec-defined correlation header; the IBM HMC REST API spec describes echo behaviour, but **per-firmware echo is `[ASSUMED]`** until a capture row lands below | Outbound send header (`HMC_OUTBOUND_CORRELATION_HEADER`) + primary echo-read header (`HMC_CORRELATION_ECHO_HEADER`). Both default to this value, so the outbound / echo-read pair is symmetric. |
| `X-Client-Correlator` | `[VALIDATED — IBM HMC V8+ spec]` | Optional; spec does not require server-side echo | Use as fallback. |
| `X-Correlation-ID` | **NOT defined in IBM HMC spec** | Not echoed | Generic web convention. Not a valid HMC header. |
| `X-Request-ID` | **NOT defined in IBM HMC spec** | Not echoed | Not a valid HMC header. |

<a id="per-firmware-observations"></a>

### Per-firmware observations

| Firmware version | Echoed header | Observed behaviour | Notes |
|------------------|---------------|--------------------|-------|
| _(none captured yet — probe with `curl -k -i -H 'X-Transaction-ID: probe-1' https://<hmc>:12443/rest/api/uom/ManagedSystem`)_ | | | |

## LPAR composite quick endpoint

Owner: [B2-5](../TODO.md#phase-b--read-path-excellence-not-started). Source code: [`src/power_hmc_mcp/hmc_client.py`](../src/power_hmc_mcp/hmc_client.py) `get_lpar_quick`.

The composite endpoint (`GET .../LogicalPartition/{uuid}/quick`) returns multiple quick properties in a single call. Response shape varies by firmware (JSON vs `application/xml;type=PartitionQuickProperties`). The `HMC_PREFER_QUICK_PROPERTIES` feature flag stays `false` until at least one firmware row is filled in.

| Firmware version | Endpoint supported | Response content-type | Median latency vs UOM | Notes |
|------------------|--------------------|------------------------|------------------------|-------|
| _(none captured yet)_ | | | | |

## PCM Atom feed `rel` attributes

Owner: [B2-6](../TODO.md#phase-b--read-path-excellence-not-started). Source comment: [`src/power_hmc_mcp/normalize.py`](../src/power_hmc_mcp/normalize.py) module-level `# PCM Atom feed rel attributes` block.

| `rel` value | Purpose | Status | Firmware versions confirmed |
|-------------|---------|--------|------------------------------|
| `related` | Links to the PCM metric JSON resource | `[ASSUMED]` | — |
| `enclosure` | Encapsulates the metrics payload | `[ASSUMED]` | — |
| _(IBM-custom values)_ | — | `[ASSUMED]` add as captured | — |

## PCM Metric JSON Field Names

Owner: [B2-7](../TODO.md#phase-b--read-path-excellence-not-started). Source: [`src/power_hmc_mcp/hmc_client.py`](../src/power_hmc_mcp/hmc_client.py) `_pcm_cpu_aggregates`.

Schema is identical across Power9 / Power10 / Power11 — single implementation path. Every numeric field is an *array* whose index order is declared by `utilInfo.metricArrayOrder` (`["Avg"]` for `Processed`; `["Avg", "Min", "Max"]` for `Aggregated`).

`get_capacity_full()` stays `[PLACEHOLDER]` until the real `metrics_href` GET is wired in B2-7b. The field name and JSON nesting path are **confirmed against IBM Docs** and no longer carry a `[RISK]` marker.

| Field Name | Path | Meaning | Status | Notes |
|------------|------|---------|--------|-------|
| `utilizedProcUnits` | `serverUtil.processor.utilizedProcUnits` | Proc units utilized by all LPARs (array) | `[VALIDATED — IBM Docs Power9/10/11]` | Always an array; length per `metricArrayOrder`. `cpuUtil` does NOT exist in the spec. |
| `utilizedProcUnitsDeductIdle` | `serverUtil.processor.utilizedProcUnitsDeductIdle` | Same but idle cycles excluded | `[VALIDATED — IBM Docs Power9/10/11]` | Present only when `utilInfo.version >= 1.1.0` (PHYP 7.8.0+, HMC V10R2M1040+). Fall back to `utilizedProcUnits` when absent. |
| `totalProcUnits` | `serverUtil.processor.totalProcUnits` | Total proc units installed | `[VALIDATED — IBM Docs Power9/10/11]` | Array format. |
| `availableProcUnits` | `serverUtil.processor.availableProcUnits` | Available for assignment | `[VALIDATED — IBM Docs Power9/10/11]` | Array format. |

## B2 firmware capture checklist

Use this checklist when lab HMC access is available. Each item requires a real capture before promoting `[ASSUMPTION]` annotations or enabling live mutations.

| Item | Endpoint / action | Fixture path | Source to update |
|------|-------------------|--------------|-------------------|
| B2-1 | Collect all `PartitionState` quick-property strings | `tests/fixtures/firmware/v11r1/lpar_states.json` | `src/power_hmc_mcp/normalize.py` → `_LPAR_STATE_CANONICAL` |
| B2-2 | Measure p99 latency on busy HMC (`GET /rest/api/uom/ManagedSystem`) | _(trace export — no fixture file)_ | `src/power_hmc_mcp/http_policy.py`, `config.py` retry defaults |
| B2-3 | Inspect response headers for correlation echo | Any GET with outbound `X-Transaction-ID` | `src/power_hmc_mcp/session.py`, `session_async.py` |
| B2-4 | Force 401 mid-sequence; save response body | `tests/fixtures/firmware/<level>/session_expired_401.json` | Session re-auth integration tests |
| B2-5 | Compare quick fan-out vs composite vs full UOM latency | `tests/fixtures/firmware/<level>/lpar_quick_*.xml` | `config.py` → `hmc_prefer_quick_properties` |
| B2-6 | Save PCM Atom feed XML with `rel=` attributes | `tests/fixtures/firmware/v11r1/pcm_atom_feed.xml` | `src/power_hmc_mcp/hmc_xml.py` |
| B2-7 | Save full metrics JSON behind `metrics_href` | `tests/fixtures/firmware/<level>/metrics_href.json` | `src/power_hmc_mcp/hmc_client.py` → `get_capacity_full()` |

For each capture: add a row to the relevant table above, save the verbatim response under `tests/fixtures/firmware/`, and only then flip the matching source annotation from `[ASSUMPTION]` to `[VALIDATED vN]`.
