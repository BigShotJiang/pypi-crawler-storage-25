# Glossary

Plain-English definitions of every term that appears unannotated in the rest of the docs. If you find a term in the code or another doc that isn't here, please add it.

## Core domain

**IBM Power** — IBM's line of enterprise servers built around the POWER processor (e.g. Power9, Power10). They run AIX, IBM i, and Linux workloads. This project does not run on Power; it *talks to* a Power server's management appliance.

**HMC (Hardware Management Console)** — The dedicated appliance (physical box or virtual appliance) that controls one or more Power servers. It exposes an HTTPS REST API on port `12443` by default. The HMC is what this project connects to. One HMC manages many servers; one server is managed by one HMC at a time.

**Managed system** — A single Power server controlled by the HMC. The HMC identifies each managed system by a UUID, not by hostname or serial number, when you call its REST API. Same idea as a "physical host" in a virtualization stack.

**LPAR (Logical Partition)** — A virtual machine running on a managed system. PowerVM (the hypervisor) carves the hardware into LPARs. Each LPAR has its own OS, CPU, and memory allocation. The HMC identifies LPARs by UUID. Same role as a VM in VMware/KVM, just IBM's terminology.

**Partition profile** — A saved set of resource assignments (CPU, memory, I/O) for an LPAR. You activate a profile to start an LPAR with that configuration. Stored on the HMC, not inside the LPAR.

**PCM (Performance and Capacity Monitoring)** — IBM's metrics subsystem on the HMC. Exposes utilization data (CPU, memory, network, etc.) as Atom feeds and JSON documents. The `get_capacity` tool reads from this.

**UOM (Unified Object Model)** — IBM's name for the canonical XML resource format the HMC REST API returns for managed systems, LPARs, profiles, and similar entities. Most of the read tools in this server parse UOM XML.

**Atom feed** — XML feed format (RFC 4287) used by the HMC for collections (e.g. "all LPARs on this system"). Each entry typically links to a UOM document with the full resource. Hidden from agents — tool outputs are normalized JSON.

**Quick property** — A lightweight HMC URL that returns just one named property of an LPAR (e.g. `PartitionState`) instead of the full UOM document. Cheaper but requires multiple round trips to assemble a status view. Available behind `HMC_LPAR_STATUS_SOURCE=quick`.

## Protocol layer

**MCP (Model Context Protocol)** — An open protocol for letting AI agents discover and call typed tools over a stable JSON contract. Think "REST for LLMs," but with strong typing, dry-run conventions, and tool annotations. See [modelcontextprotocol.io](https://modelcontextprotocol.io).

**FastMCP** — The reference Python implementation of an MCP server inside the official `mcp` SDK. This project builds on `FastMCP`; tools are functions decorated with `@mcp.tool(...)`.

**stdio transport** — The default way an MCP host (e.g. Claude Desktop, a LangGraph runner) spawns and talks to an MCP server: child process, stdin = requests, stdout = responses, stderr = logs. Simplest deployment, no networking.

**streamable HTTP transport** — Optional MCP transport for remote / containerized deployments. The server listens on an HTTP port; clients connect with HTTP POSTs that stream chunked JSON responses. Used when stdio fan-out is awkward (gateways, multi-tenant hosts).

**Tool annotation** — MCP-level metadata attached to a tool (e.g. `readOnlyHint=true`, `destructiveHint=true`) so agents and hosts can render confirmation prompts or filter what an agent is allowed to call. This server uses `READ_ONLY` for read tools and `WRITE_TOOL_ANNOTATIONS` for write tools.

## This project

**Read tool** — An MCP tool annotated `readOnlyHint=true` that only performs `GET`s against the HMC. Always registered; safe to expose to any agent.

**Write tool** — An MCP tool annotated `destructiveHint=true` that *would* mutate state on the HMC. Registered only when `HMC_ENABLE_WRITE_TOOLS=true`; gated by the structural write boundary; today returns a placeholder envelope until IBM mutation payloads are validated.

**Dry-run** — A write tool invocation with `execute=false` (or denied by the guardrail). Returns a stable JSON envelope describing what *would* have happened. Never touches the HMC.

**`WriteAuthorization`** — A capability token (Python frozen dataclass) issued only by the structural write boundary after `check_write_allowed` succeeds. Required by every `HmcClient` write method. Cannot be constructed directly; cannot be forged with `cast()` (the client re-validates with `isinstance`). The structural guarantee that no write reaches the HMC without the guardrail's approval.

**`run_write_tool`** — The single helper in `src/power_hmc_mcp/tools/write.py` that runs the guardrail, issues a `WriteAuthorization` on the authorized path, and emits the `write_audit` log event on every outcome.

**`@mark_write_tool`** — Decorator applied to every registered write-tool MCP function. The registration validator refuses to start the server if any expected write tool lacks the marker.

**`write_audit` event** — The canonical log event emitted on every write-tool invocation (denied / dry-run / authorized). Stable schema documented in [`operations.md`](operations.md#write_audit-schema).

**Correlation ID** — A UUID bound to one MCP tool invocation and propagated to the HMC via the `X-Correlation-ID` request header. Used to join MCP-side and HMC-side log lines for one request. Default-on; `HMC_PROPAGATE_CORRELATION_HEADER=false` disables propagation if needed.

**`hmc_echo_correlation_id`** — Field on `hmc_request_end` log events that captures any `X-Correlation-ID` (or `X-Request-ID`) the HMC echoed back. Best-effort; depends on firmware behavior.

**Allowlist (`HMC_ALLOWED_MANAGED_SYSTEMS`)** — Optional comma-separated list of managed-system UUIDs. When set, read tools only return / accept those systems and write tools refuse system IDs outside the list. Blast-radius reduction, not a substitute for HMC RBAC or network ACLs.

**Deployment mode (`HMC_DEPLOYMENT_MODE`)** — One of `development` / `controlled` / `production`. Today documents intent; the policy matrix in [`operations.md`](operations.md#deployment-modes-hmc_deployment_mode) describes recommended toggles.

## HMC REST API

**Session token (`X-API-Session`)** — The opaque token returned by `/rest/api/web/Logon` (PUT) and required as a header on every authenticated request. The `HmcClient` manages it transparently and re-establishes it on `401`.

**Logon path** — `/rest/api/web/Logon` (PUT to log on, DELETE to log off).

**`HmcAuthError` / `HmcHttpError` / `HmcParseError` / `HmcValidationError`** — Exception hierarchy raised by `HmcClient`. See [`operations.md`](operations.md#errors-and-exceptions) for what each one means and which HTTP statuses surface as which exception.

**Idempotent / non-idempotent** — `GET`s are idempotent (safe to retry). `POST`s that mutate are not, so this server's `HMC_WRITE_MAX_RETRIES` defaults to `0`. The `http_policy` module classifies each call before applying retry logic.
