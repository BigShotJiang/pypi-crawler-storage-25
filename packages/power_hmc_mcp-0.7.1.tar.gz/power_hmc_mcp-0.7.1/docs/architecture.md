# Architecture

This document explains **why** the layers exist and how they keep technical debt contained as IBM revises HMC REST paths or operation semantics. For setup see the [README](../README.md). For ops see [operations](operations.md). For agent-side guidance see the [agent guide](agent-guide.md). Terminology is defined in the [glossary](glossary.md).

## Module map

```text
src/power_hmc_mcp/
├── config.py            # Typed env settings (Pydantic). Single source of truth.
├── routes.py            # Named HMC URL builders. One diff point for IBM path changes.
├── http_policy.py       # Read/write retry classification, backoff, throttle helpers.
├── hmc_xml.py           # IBM XML / Atom parsing. Internal only — no Atom in MCP outputs.
├── exceptions.py        # HmcError hierarchy raised by HmcClient.
├── validation.py        # Resource-ID and input validation.
├── serialize.py         # JSON normalization helpers (drop_none, ensure_json_serializable).
├── session.py           # HMC transport and session lifecycle (HmcSession): logon/logoff,
│                        # retry loop, throttle, 401-recovery. Extracted pre-Phase C seam.
├── normalize.py         # Agent-facing normalization helpers: normalize_resource,
│                        # normalize_pcm_samples_for_agent, pcm_summary.
├── hmc_client.py        # IBM resource surface: parse, validate, delegate to HmcSession.
│                        # Mutation methods require WriteAuthorization.
├── guardrails.py        # Framework-agnostic decisions, capability token, dry-run shapes.
├── agent_output.py      # Phase F MCP list envelopes (wrap_list_response).
├── observability.py     # Correlation IDs, structured logs, write_audit, telemetry hook.
├── logging_utils.py     # Logging configuration + RedactingFilter.
├── mcp_server.py        # FastMCP server entrypoint; transport edge.
└── tools/
    ├── annotations.py            # Shared MCP ToolAnnotations constants.
    ├── write.py                  # Structural write boundary (the only WriteAuthorization issuer).
    ├── __init__.py               # Tool registration + boot-time validation.
    ├── list_managed_systems.py   # Read tools — one file per tool.
    ├── list_lpars.py
    ├── get_managed_system.py
    ├── get_lpar.py
    ├── get_lpar_status.py
    ├── list_partition_profiles.py
    ├── get_capacity.py
    ├── health_check.py
    ├── start_lpar.py             # Write tools — registered only when HMC_ENABLE_WRITE_TOOLS=true.
    ├── stop_lpar.py
    └── create_lpar_from_profile.py
```

## Layers

| Layer | Role | Must never |
|-------|------|------------|
| **Config** (`config.py`) | Typed env settings: connectivity, policy, transport, retries, deployment posture | Hold secrets in code |
| **Routes** (`routes.py`) | Named URL builders for every HMC path | Scatter `/rest/api/...` literals elsewhere |
| **HTTP policy** (`http_policy.py`) | Retry/backoff hints; read vs write classification | Hide non-idempotent POST retries behind "generic retry" |
| **XML / Atom** (`hmc_xml.py`) | Parse IBM XML and Atom feeds | Leak raw feeds to MCP agents |
| **HMC session** (`session.py`) | Transport and session lifecycle: logon/logoff, retry loop, throttle, 401-recovery via `HmcSession.request()` | Duplicate retry/auth logic outside this module |
| **HMC client** (`hmc_client.py`) | IBM resource surface: XML/Atom parsing, allowlist checks, normalization via `normalize.py`, demo mode shim. Delegates all HTTP to `HmcSession`. Write methods require a `WriteAuthorization`. | Be invoked directly by orchestrators (only MCP tools should) |
| **Async transport pair** (`session_async.py`, `hmc_client_async.py`) | Phase D async mirror of `HmcSession` / `HmcClient` (read surface). Wraps `httpx.AsyncClient` and pairs `time.sleep`-based retry/throttle with `asyncio.sleep` counterparts in `http_policy.py`. Demo mode behaves identically. **Currently behind a Phase-D-internal seam** — the public MCP surface still routes through the sync client. Multi-HMC pools (D5) expose `get_async()` per alias but the public MCP tool dispatch is sync-only today (D5); async tool wiring is deferred to D5.5, pending a confirmed concurrent fan-out use case. | Hold mutating methods until D5 + Phase C lands; defer writes to the sync path. |
| **Normalization** (`normalize.py`) | Agent-facing shape helpers: `normalize_resource`, `normalize_pcm_samples_for_agent`, `pcm_summary` | Mix normalization logic with HTTP or auth |
| **Guardrails** (`guardrails.py`) | Framework-agnostic decisions, `WriteAuthorization` capability token, dry-run / placeholder shapes | Import FastMCP or emit logs (kept pure for testability) |
| **Observability** (`observability.py`) | Correlation IDs, structured logs, timing hooks, canonical `write_audit` event | Duplicate ad hoc log schemas |
| **MCP write boundary** (`tools/write.py`) | The only path that issues `WriteAuthorization`; emits `write_audit` on every outcome; sets the registration-time marker | Be bypassed by a write tool body |
| **MCP tools** (`tools/`) | Stable JSON tool contracts; write tools use `@mark_write_tool` + `run_write_tool` | Import `httpx` or embed path strings |
| **Server edge** (`mcp_server.py`) | Transport (`stdio` / streamable HTTP), startup | Duplicate tool registration logic |

## Transport strategy (summary)

**Default: stdio** — simplest for desktop MCP hosts and local LangGraph experimentation; one process pair, minimal networking ambiguity.

**Optional: streamable HTTP** — for shared services, containers behind ingress, and org-standard MCP gateways. Transport differences stop at `mcp.run(...)`; tools and `HmcClient` stay identical.

See [transports](transports.md).

## Pathing strategy

All route strings live in `routes.py`. If IBM changes a collection path or moves an operations URL, fix **one module** and adjust tests that assert paths.

**Read paths** (`MANAGED_SYSTEM_COLLECTION_PATH`, `managed_system_path`, `logical_partition_collection_path`, `logical_partition_path`, `logical_partition_quick_property_path`, `logical_partition_profiles_path`, `pcm_processed_metrics_path`) are aligned **verbatim** with IBM Power10/11 HMC REST docs and are individually annotated `[VALIDATED — IBM Docs Power10/11]`. The cross-reference table lives in [`docs/hmc-compatibility.md`](hmc-compatibility.md#url-routes--ibm-doc-alignment).

**Write paths** (`logical_partition_*_job_path`, etc.) are explicit **contract placeholders**: the tool names and operation names exposed to agents are stable, but the exact REST path and request body are subject to firmware validation in Phase C. The current builders emit the IBM-documented `/do/{OP}` shape; the specific `{OP}` names (`PowerOn`, `PowerOff`, `PartitionTemplateCreatePartition`) are `[ASSUMPTION]` placeholders pending lab capture. The capture target rows live in [`docs/hmc-compatibility.md`](hmc-compatibility.md#write-operation-paths) 'Write Operation Paths'.

**Composite quick endpoint** (`logical_partition_composite_quick_path`) is `[PLACEHOLDER]` — the URL grammar does not document an instance-level "all quick properties" endpoint, so the builder exists but `HmcClient.get_lpar_quick` returns a placeholder until firmware capture confirms the content-type and latency profile.

## Request pipeline (read path)

Concrete walk of `list_lpars(managed_system_id)` end-to-end:

```text
agent (via MCP)
   ↓
FastMCP dispatches to tools/list_lpars.py
   ↓
mcp_tool_call("list_lpars", run)
   • binds correlation_id (UUID4 unless caller provided one)
   • emits mcp_tool_start
   ↓
client.list_lpars(managed_system_id)
   • _check_allowlist(...) — raises HmcValidationError if disallowed
   • routes.logical_partition_collection_path(system_id)
   ↓
client._session.request("GET", path)   [HmcSession]
   • _ensure_session() (PUT /rest/api/web/Logon if no token)
   • throttle_before_request(...) — sleeps if min interval not met
   • injects X-Correlation-ID header (if HMC_PROPAGATE_CORRELATION_HEADER=true)
   • emits hmc_request_start
   ↓
HMC HTTPS call
   ↓
   • on 401 (and not the logon path) → invalidate token, login, retry once
   • on retryable 5xx/429 + GET → retry with exponential backoff + jitter
   • emits hmc_request_end with status, duration, optional hmc_echo_correlation_id
   ↓
hmc_xml.parse_feed_entries(response.text) → list[dict]
   ↓
serialize.ensure_json_serializable(...)
   ↓
mcp_tool_call emits mcp_tool_end (outcome=success, duration_ms)
   ↓
agent receives normalized JSON
```

Authenticated traffic flows through `HmcSession.request` (delegated by `HmcClient`):

1. Session ensure (`login` if needed).
2. Client-side throttle spacing (`HMC_MIN_REQUEST_INTERVAL_SECONDS`).
3. Optional correlation header (`HMC_PROPAGATE_CORRELATION_HEADER`).
4. HTTP call with logging (`hmc_request_start` / `hmc_request_end`).
5. **401 handling**: invalidate session, log on once, retry the same logical request (not counted as generic backoff retry).
6. **Retryable failures** (reads vs writes per `http_policy`): transport errors and limited HTTP statuses (`502`, `503`, `504`, `429`) with exponential backoff + jitter.

Logon and logoff use dedicated code paths but emit the same observability events.

## Write pipeline (the structural boundary)

Concrete walk of `start_lpar(managed_system_id, lpar_id, execute=True)` with `HMC_ENABLE_WRITE_TOOLS=true`:

```text
agent (MCP call: start_lpar)
   ↓
FastMCP dispatches to tools/start_lpar.py
   • the function is wrapped by @mcp.tool(...) AND @mark_write_tool
   ↓
mcp_tool_call("start_lpar", run)
   • binds correlation_id
   • emits mcp_tool_start
   ↓
run_write_tool(tool_name, operation, settings, params, execute=True, executor=...)
   ↓
check_write_allowed(settings, execute=True)
   ↓
   ├─ if writes disabled or execute flag missing
   │     • emit write_audit { outcome: denied, reason }
   │     • return dry_run_response(operation, params, reason=...)
   │
   ├─ elif decision.dry_run is True (execute=False, require flag off)
   │     • emit write_audit { outcome: dry_run }
   │     • return dry_run_response(operation, params)
   │
   └─ else (authorized)
         • _issue_authorization(operation, correlation_id) → WriteAuthorization
         • emit write_audit { outcome: authorized }
         • call executor(authorization)
              ↓
         client.start_lpar(..., authorization=auth)
              • _require_authorization(authorization, operation)
                  - isinstance check (refuses cast() abuse)
                  - operation match (refuses cross-tool token reuse)
              • _check_allowlist(...)
              • returns placeholder_execute_response(...) until Phase C
                  (Phase C: replace with self._session.request("POST", ...))
   ↓
mcp_tool_call emits mcp_tool_end
   ↓
agent receives envelope (denial / dry-run / placeholder-authorized)
```

Sample log lines for an authorized invocation (human mode):

```text
mcp_tool_start correlation_id=abcd-… {tool_name=start_lpar, ...}
write_audit  correlation_id=abcd-… {tool_name=start_lpar, operation=start_lpar, outcome=authorized, reason="execute flag satisfied", execute_requested=True}
mcp_tool_end correlation_id=abcd-… {tool_name=start_lpar, outcome=success, duration_ms=…}
```

Sample log lines for a denied attempt:

```text
mcp_tool_start correlation_id=… {tool_name=start_lpar, ...}
write_audit  correlation_id=… {tool_name=start_lpar, operation=start_lpar, outcome=denied, reason="execute flag is required for write operations", execute_requested=False}
mcp_tool_end correlation_id=… {tool_name=start_lpar, outcome=success, duration_ms=…}
```

(Note that `mcp_tool_end.outcome=success` because the tool returned its denial envelope cleanly — the *write* outcome lives in the `write_audit` record. SIEM rules should pin on `event_type=write_audit` and `outcome=denied` for security review.)

## Observability model

- Every MCP tool invocation runs inside `mcp_tool_call` (`observability.py`): correlation ID bound (unless already set), `mcp_tool_start` / `mcp_tool_end` events, latency.
- HMC requests emit structured fields (`event_type`, `correlation_id`, `hmc_method`, `hmc_path`, `hmc_status`, `duration_ms`, `outcome`). The `X-Transaction-ID` request/response pair is spec-preferred per the IBM HMC REST API spec; per-firmware echo behaviour is still subject to capture in [`docs/hmc-compatibility.md`](hmc-compatibility.md#correlation-header-echo) 'Correlation Header Echo'.
- Write tools also emit `write_audit` events (`denied` / `dry_run` / `authorized`) — the canonical security signal.
- `HMC_LOG_JSON=true` switches to single-line JSON logs for ingestion; human-readable mode keeps the same fields in the message tail.
- `HMC_API_VERSION_HINT` is a **logging hint** surfaced on `session_logon_end` / `session_logoff_end` and the startup log line — see [`docs/operations.md`](operations.md#observability). It does not flip firmware-gated behaviour.
- `telemetry_hook` exports OTLP spans and `{event_name}.count` counters when `HMC_OTEL_ENDPOINT` is set and `power-hmc-mcp[otel]` is installed; otherwise emits DEBUG `telemetry_stub` log events. Providers initialize lazily once; `atexit` triggers flush/shutdown so batched export is not dropped on normal process exit.

Stable field names live as `FIELD_*` constants in `observability.py` so log parsers and OTEL mappings have one source of truth.

## Write safety model

The dry-run / authorized split is **structural**, not conventional — i.e. enforced by the type system and module boundaries rather than by repeated checks in tool bodies.

1. **Registration gate (boot-time)**: write MCP tools register only when `HMC_ENABLE_WRITE_TOOLS=true`. The registration validator additionally refuses to start if any name in `WRITE_TOOL_NAMES` is missing the `@mark_write_tool` marker (`tools/__init__.py::_validate_tool_registration`). Forgetting the decorator is a server-startup failure, not a runtime mutation risk.
2. **Capability token**: `HmcClient.start_lpar` / `stop_lpar` / `create_lpar_from_profile` require a `WriteAuthorization` parameter. The token is a frozen dataclass whose constructor raises unless it is built with a module-private sentinel; the client methods additionally `isinstance`-check it before any mutation, defeating `cast()` abuse.
3. **Single issuer**: the only path that produces a `WriteAuthorization` is `power_hmc_mcp.tools.write.run_write_tool`, which is the only intended caller of `guardrails._issue_authorization`. A write-tool body cannot reach the client mutation path without going through this helper.
4. **Audit on every outcome**: `run_write_tool` emits a `write_audit` log event (`observability.log_write_audit`, outcome ∈ `denied` / `dry_run` / `authorized`) before returning on every path. Denied write attempts are never silent.
5. **Execute gate**: when `HMC_REQUIRE_EXECUTE_FLAG=true`, the guardrail denies unless the caller passes `execute=true`; dry-run preview is never a mutation.
6. **Client scaffold**: on the authorized path the client returns a **placeholder executed=false** payload with `audit.record_status=placeholder` until IBM JSON/XML bodies are confirmed and integration-tested (Phase C). Phase C real writes are blocked on Phase B2 firmware captures and the validated write paths landing in [`docs/hmc-compatibility.md`](hmc-compatibility.md#write-operation-paths) — they are NOT unblocked by IBM documentation alone.
7. **Future hooks**: replace the placeholder body with real `_request` calls without changing the structural property — `WriteAuthorization` is still required to call the method.

## PCM / Atom layering

- **Client/parser**: understands Atom feeds (`parse_pcm_metrics_feed`) and PCM link metadata.
- **Agent surface**: `get_capacity` exposes `metadata` (normalized samples), `summary` (counts/recency), or `full` **placeholder** until metric JSON retrieval is implemented.

This preserves protocol fidelity while keeping Atom terminology out of primary agent flows.

## Deployment modes (`HMC_DEPLOYMENT_MODE`)

The enum is primarily a **documentation and policy rail** today; behavior matrices live in [operations](operations.md). Future work may tighten defaults (e.g., forbid write registration in `production` unless additional flags are set).

## Design justifications (at a glance)

| Decision | Why here | Trade-off |
|----------|----------|-----------|
| Central routes module | Single diff point when IBM moves URLs | Extra indirection vs inline strings |
| Single `_request` pipeline | Consistent logging, retries, auth refresh | More branching inside client |
| Capability token for writes | Type-system enforcement of guardrail | One extra concept (`WriteAuthorization`) |
| `@mark_write_tool` registration check | Boot-time failure beats call-time mutation | One extra decorator per write tool |
| Canonical UOM GET for LPAR status | Aligns with primary resource model; fewer round trips | Tool now needs `managed_system_id` |
| Atom kept below MCP | Agents get stable JSON | Maintainers still learn PCM feeds |
| stdio default transport | Lowest operational surprise locally | Remote gateways need HTTP mode |
| Structured logs + correlation | Audit-ready, machine-ingestible | Slightly more verbose stdout |

## Extending safely

### Adding a new read tool

1. Add URL builders to `routes.py` + unit tests.
2. Add a method on `HmcClient` using `_request` with `RequestClassification.READ` (default).
3. Add a thin MCP tool under `src/power_hmc_mcp/tools/` that wraps the client call with `mcp_tool_call`. Use the `READ_ONLY` annotation from `tools/annotations.py`.
4. Add the tool name to `READONLY_TOOL_NAMES` and call its `register(...)` from `_register_read_tools` in `tools/__init__.py`.
5. Document placeholders in docstrings and this file.

### Adding a new write tool

1. Add the client method with a required `authorization: WriteAuthorization` keyword (no `execute: bool`); start the body with `self._require_authorization(authorization, operation="<name>")`.
2. In `tools/<name>.py`, register an MCP tool body that builds `params`, defines an `executor(authorization)` closure that calls the client, and delegates to `run_write_tool(...)` inside `mcp_tool_call(...)`.
3. Apply both `@mcp.tool(annotations=WRITE_TOOL_ANNOTATIONS)` and `@mark_write_tool` (in that order, top-down) to the registered tool function.
4. Add the new tool name to `WRITE_TOOL_NAMES` in `tools/__init__.py` and call its `register(...)` inside the `if writes_enabled:` block. Server startup validates the marker is present.
5. Add a tool-level test asserting denied / dry-run / authorized outcomes each emit a `write_audit` event.

### Don't

- Don't import `httpx` from a tool — only the client speaks HTTP.
- Don't construct a `WriteAuthorization` directly — it raises and `mypy` rejects unsupplied arguments. Go through the decorator.
- Don't bypass the marker check by registering a write tool elsewhere — `_validate_tool_registration` will refuse to start.

## Agent output conventions (Phase F)

Phase F ergonomics apply at the **MCP tool boundary** only. `HmcClient` methods continue to return raw HMC-normalized shapes (lists for inventory feeds, dicts for single resources). MCP tools may wrap or annotate those shapes for agent consumers.

### List tool envelope

`list_managed_systems`, `list_lpars`, and `list_partition_profiles` return:

```json
{
  "items": [ /* same item dicts as HmcClient */ ],
  "summary": {
    "total_count": 0,
    "returned_count": 0,
    "offset": 0,
    "truncated": false,
    "next_offset": 0,
    "state_counts": { "running": 0 }
  }
}
```

Implementation: [`agent_output.wrap_list_response`](../src/power_hmc_mcp/agent_output.py), called from each list tool after the client fetch. Optional MCP params `limit` / `offset` slice the page; truncation is always explicit via `summary.truncated`. `state_counts` appears on system and LPAR lists only. **Ordering:** `items` preserve HMC Atom feed order for that call — offset pagination is safe within one snapshot; re-fetch from `offset=0` if inventory may have changed between pages.

**Breaking MCP contract (Phase F):** top-level response changed from `list[dict]` to this envelope. Migration: `result[0]` → `result["items"][0]`; see [CHANGELOG](../CHANGELOG.md#migration--list-tools-agent-consumers).

Contract tests: HmcClient item shapes in [`tests/test_contracts.py`](../tests/test_contracts.py); MCP envelopes in [`tests/test_mcp_list_envelope.py`](../tests/test_mcp_list_envelope.py) against [`tests/fixtures/mcp/`](../tests/fixtures/mcp/).

### Write guardrail hints

Write tool envelopes (denied / dry-run / authorized placeholder) include additive fields from [`guardrails.py`](../src/power_hmc_mcp/guardrails.py):

- `suggested_next_step` — reason-specific deterministic hint.
- `guardrail_outcome` — `denied` | `preview` | `authorized_placeholder`.
- `denial_reason_code` — `writes_disabled` | `execute_required` (denied paths only).

These extend the existing envelope; they do not change authorization semantics in `run_write_tool`.

---

## Provider abstraction (Phase J)

**Status: shipped.**

Sync backends implement the structural [`HmcProvider`](../../src/power_hmc_mcp/provider.py)
protocol. [`create_provider()`](../../src/power_hmc_mcp/provider_factory.py) selects
the implementation from `HMC_PROVIDER` (`hmc` | `demo` | `powervs`). Demo fixture
logic lives in [`DemoProvider`](../../src/power_hmc_mcp/demo_provider.py);
[`HmcClient`](../../src/power_hmc_mcp/hmc_client.py) is HMC HTTP only.
[`PowerVSProvider`](../../src/power_hmc_mcp/powervs_provider.py) is a stub pending
IBM Cloud integration.

When `HMC_DEMO_MODE=true` and `HMC_PROVIDER=hmc` (CI default), the factory returns
`DemoProvider` without requiring env changes.

Full design: [provider-architecture.md](design/provider-architecture.md).

---

## Multi-HMC Registry (Phase D, D5)

**Status: shipped.**

### Single-HMC ergonomic preserved

`HMC_HOST` / `HMC_USERNAME` / `HMC_PASSWORD` continue to identify a single endpoint, attached to the alias named by `HMC_DEFAULT_ALIAS` (default `"default"`). The implementation is **purely additive**: existing single-HMC deployments work unchanged and never see the registry surface.

### `HMC_REGISTRY` config

Set `HMC_REGISTRY` to a JSON list of objects to expose additional aliases. Inline values are intentional (Pydantic-friendly, no separate file format to standardise). Each entry MUST declare `alias` / `host` / `username` / `password`; optional per-entry overrides are `port` / `verify_tls` / `timeout_seconds`. All other HMC settings (allowlists, retries, write guardrails, transport, observability) are process-wide.

```bash
HMC_REGISTRY='[
  {"alias": "prod-east", "host": "hmc-east.example.com", "username": "api-user", "password": "..."},
  {"alias": "prod-west", "host": "hmc-west.example.com", "username": "api-user", "password": "..."}
]'
```

### Implementation

* [`registry.py`](../src/power_hmc_mcp/registry.py) — parser + frozen `HmcEndpoint` dataclass + `HmcRegistry` view; `build_registry(settings)` returns the merged registry (default + extras).
* [`pool.py`](../src/power_hmc_mcp/pool.py) — `HmcClientPool` keyed by `(alias, mode)` where mode is `"sync"` or `"async"`. Lazy construction; `close_all()` is safe to call from `atexit`. The `(alias, mode)` key prevents a sync and async client for the same alias from racing on a single HMC session token (the `# SYNC-ONLY` and `# ASYNC` retry/throttle helpers in `http_policy.py` MUST stay paired with their own client).
* [`tools/__init__.py`](../src/power_hmc_mcp/tools/__init__.py) — `register_tools(mcp, client_or_pool)` accepts either a single `HmcClient` (single-HMC ergonomic) or an `HmcClientPool`, wrapping the former with `single_client_resolver`. Every tool is registered with a `ClientResolver = Callable[[str | None], HmcClient]`.
* Per-tool: every tool exposes an optional `hmc_alias: str | None = None` parameter; alias resolution happens once per call (`client = resolver(hmc_alias)`).

### Observability

`mcp_tool_call(...)` accepts `hmc_alias=...` and propagates it onto both `mcp_tool_start` and `mcp_tool_end` events when non-`None`. Single-HMC callers (alias `None`) see no extra log field — the existing event shape is preserved verbatim. SIEM rules MAY pin on `hmc_alias` when present.

### Security model

* Each alias has its own `host` / `username` / `password`. Process-wide allowlists, retries, write guardrails, transport, and observability apply uniformly — operators that need different posture per HMC should run separate processes.
* `WriteAuthorization` capability tokens are correlation-id-keyed (not HMC-session-keyed), so write guardrails work identically across aliases.
* `write_audit` events should include `hmc_alias` when the parent `mcp_tool_call` was invoked with one (this falls out automatically from the same correlation context).
* The streamable-HTTP "shared HMC session" decision (D2 — see [`docs/design/http-session-affinity.md`](design/http-session-affinity.md)) applies **per alias**: each alias keeps its own shared session.

### Boundaries

* The async pool surface (`get_async`) returns `HmcAsyncClient` and is
  available for future use, but the public MCP tool path goes through the
  sync pool — D5 ships sync-only tool wiring and that is sufficient for all
  current work including Phase E OTEL instrumentation. D5.5 (async tool
  dispatch) is explicitly deferred; see `TODO.md` Phase E for the deferral
  rationale and unblock criteria.
* Write tools currently live only on the sync pool — operators that enable write tools on a multi-HMC deployment do so under stdio or the single-HMC streamable-HTTP path. Async writes follow whenever async client writes themselves are scaffolded.
