# MCP transports

`power-hmc-mcp` supports two MCP transports. The choice is purely about *how the MCP client reaches the server* — tools and `HmcClient` behavior are identical either way. Pick by hosting model.

For terminology see the [glossary](glossary.md). For environment variables see [operations: configuration reference](operations.md#configuration-reference).

---

## stdio (default)

**When to use**

- Local development.
- Desktop MCP hosts (Claude Desktop, etc.).
- A single LangGraph / Python process that wants to spawn the MCP server as a child.
- Anything where a per-user, per-session process is acceptable.

**How it runs**

The client spawns the server as a subprocess; stdin = MCP requests, stdout = MCP responses, stderr = logs.

```bash
python -m power_hmc_mcp.mcp_server   # HMC_MCP_TRANSPORT=stdio (default)
```

**Pros**

- Minimal networking — no listen socket.
- One-process-pair lifetime; no orphaned sessions.
- Easy to trace: pipe stderr to a file and you have the full server log for the run.

**Cons**

- Not ideal for multi-tenant remote exposure without a wrapper.
- Tightly coupled to the parent process lifecycle.

### Example: Claude Desktop

Edit `claude_desktop_config.json` (Claude → Settings → Developer → Edit Config) and add the snippet from [`examples/claude_desktop_config.json`](../examples/claude_desktop_config.json). Replace every `CHANGE_ME-…` value. Restart Claude Desktop. The `power-hmc-mcp` console script ships with the package and is on `PATH` after `pip install -e .`.

### Example: Python MCP client over stdio (LangGraph-shaped)

Full working script: [`integrations/langgraph/example_list_lpars_stdio.py`](../integrations/langgraph/example_list_lpars_stdio.py). Excerpt:

```python
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

params = StdioServerParameters(
    command=sys.executable,
    args=["-m", "power_hmc_mcp.mcp_server"],
    env=dict(os.environ),  # forwards HMC_HOST/USERNAME/PASSWORD/...
)
async with stdio_client(params) as (read, write):
    async with ClientSession(read, write) as session:
        await session.initialize()
        tools = await session.list_tools()
        result = await session.call_tool(
            "list_lpars",
            {"managed_system_id": "<uuid>"},
        )
```

The spawned server reads the same `HMC_*` env vars as a local run; the parent process forwards them through `StdioServerParameters(env=...)`.

---

## streamable HTTP

**When to use**

- Shared / containerized deployment behind ingress.
- Org-standard MCP gateways (DataPower, API Connect, custom proxies).
- Environments where stdio fan-out to many concurrent agents is awkward.
- Anything with a separate auth/policy plane in front of the server.

**Configuration**

| Variable | Default | Notes |
|----------|---------|-------|
| `HMC_MCP_TRANSPORT` | `stdio` | Set `streamable-http`. |
| `HMC_MCP_HTTP_HOST` | `127.0.0.1` | **Loopback** unless TLS + auth live in front. Use `0.0.0.0` only behind a reverse proxy. |
| `HMC_MCP_HTTP_PORT` | `8000` | Any free TCP port. |
| `HMC_MCP_HTTP_PATH` | `/mcp` | Path component the MCP client connects to. |

```bash
HMC_MCP_TRANSPORT=streamable-http \
HMC_MCP_HTTP_HOST=0.0.0.0 \
HMC_MCP_HTTP_PORT=8000 \
HMC_MCP_HTTP_PATH=/mcp \
python -m power_hmc_mcp.mcp_server
```

The server listens on `http://<host>:<port><path>`. MCP clients negotiate streamable HTTP and tunnel JSON-RPC requests/responses over POSTed chunks.

### Security notes

- **Bind to loopback** (`127.0.0.1`) unless TLS termination and authentication live in front.
- Treat the MCP HTTP endpoint like any privileged control plane:
  - Network ACLs / private networks — never expose directly to the internet.
  - mTLS or SSO gateway as required by org policy.
  - Per-client identity if the gateway supports it; correlation IDs flow through to HMC for audit.
- HMC credentials live in the server's environment, not in MCP requests. Anyone who can reach the MCP endpoint can drive the HMC user — choose your network and auth boundary accordingly.

### Example: Python MCP client over streamable HTTP

```python
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

url = "http://localhost:8000/mcp"  # or https://… behind a TLS proxy
async with streamablehttp_client(url) as (read, write, _meta):
    async with ClientSession(read, write) as session:
        await session.initialize()
        tools = await session.list_tools()
        result = await session.call_tool("list_lpars", {"managed_system_id": "<uuid>"})
```

### Reverse-proxy / TLS termination (sketch)

A typical deployment:

```text
[ MCP client ]
     ↓ HTTPS
[ ingress / reverse proxy ]   ← TLS termination, mTLS / SSO, rate limiting
     ↓ HTTP (loopback or private)
[ power-hmc-mcp (HMC_MCP_HTTP_HOST=127.0.0.1) ]
     ↓ HTTPS (with HMC_VERIFY_TLS=true and CA bundle)
[ HMC REST API ]
```

The MCP server is intentionally minimal: it does not implement auth itself. Put the gateway in front, then keep `HMC_MCP_HTTP_HOST=127.0.0.1` so the only path to the server is through the gateway.

Concrete configs (NGINX 1.27 and Envoy) plus a runnable `docker-compose.yml` live under [`examples/deploy/`](../examples/deploy/) and pair with the security posture above. They set `proxy_buffering off` (NGINX) / disable response buffering (Envoy) on the `/mcp` route — streamable HTTP is a long-lived chunked response and any L7 buffer would coalesce chunks and break the protocol. For the Helm chart that wires the same posture on Kubernetes, see [`examples/deploy/helm/power-hmc-mcp/`](../examples/deploy/helm/power-hmc-mcp/).

### Health and readiness probes

Set `HMC_MCP_HTTP_PROBES_PATH` to mount HTTP `/healthz` and `/readyz` handlers on the same listener as `/mcp`.

| Variable | Default | Notes |
|----------|---------|-------|
| `HMC_MCP_HTTP_PROBES_PATH` | (empty — disabled) | `/` mounts at the listener root: `GET /healthz`, `GET /readyz`. Any other value is treated as a prefix: `HMC_MCP_HTTP_PROBES_PATH=/admin` → `GET /admin/healthz`, `GET /admin/readyz`. Must not collide with `HMC_MCP_HTTP_PATH` (boot fails fast if it does). Probes are HTTP-only — never registered when `HMC_MCP_TRANSPORT=stdio`. |

Semantics:

- **`/healthz`** — process liveness. Returns `{"status":"ok"}` with `200` while the listener is up.
- **`/readyz`** — readiness to serve real HMC traffic. Returns `200` with `{"status":"ready"}` when an HMC session is authenticated; returns `503` with `{"status":"not-ready","reason":"no-active-hmc-session"}` otherwise. In demo mode (`HMC_DEMO_MODE=true`) `/readyz` is always `200` with `mode=demo`.

Probe traffic is intentionally invisible to the audit-log pipeline: probe handlers do not emit `mcp_tool_call`, `write_audit`, or `session_reauth` events, so SIEM rules pinned on those events stay quiet under continuous probing. The reverse-proxy samples in [`examples/deploy/`](../examples/deploy/) carry `access_log off` for `/healthz` / `/readyz` / `/probes/*` for the same reason.

### HMC session affinity

When multiple MCP clients drive the same `power-hmc-mcp` HTTP listener concurrently, the server reuses **one shared HMC session** across all of them. This matches the v0.x behaviour and the structural write boundary (`WriteAuthorization` keys off correlation IDs, not HMC sessions). Per-caller identity, rate-limiting, and authentication belong at the gateway in front. The full decision and the future `per-client` / `per-request` opt-ins are documented in [`docs/design/http-session-affinity.md`](design/http-session-affinity.md).

### SDK caveat

With `mcp>=1.27`, `FastMCP.run(transport=...)` reads HTTP bind options from `mcp.settings.host`, `mcp.settings.port`, and `mcp.settings.streamable_http_path`. `mcp_server.main()` assigns those from `Settings` before `mcp.run(...)` so future SDK changes stay localized to that single function.

---

## Internal architecture invariant

Regardless of transport, **`register_tools` + `HmcClient` stay identical**. Only `mcp_server.main()` chooses how the MCP runtime listens. The structural write boundary, correlation propagation, audit emission, and HMC client behavior do not vary by transport.

If you need to A/B both transports, run two server processes with different `HMC_MCP_TRANSPORT` values pointing at the same HMC; they share no state, but they will produce identical tool outputs and matching log records on the same `correlation_id` if a client sets one.
