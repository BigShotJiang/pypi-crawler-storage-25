# Milestone evaluation (team gate)

Each major phase ends with a **team evaluation period** before the next phase starts on `main`. The goal is to validate the release against real workflows, agree on priorities, and capture risks — not to keep shipping features during the pause.

## Current status

| Item | State |
|------|--------|
| **Phase A** | **Complete** — tagged [`v0.1.0`](https://github.com/TylrDn/power-hmc-mcp-server/releases/tag/v0.1.0) on `main` |
| **Evaluation** | **Complete** — exited 2026-05-18; "Phase A evaluation complete — Phase B approved" recorded |
| **Phase B1** | **Complete** — golden fixtures, demo mode, PCM aggregates, `get_capacity_full` scaffold, `suggested_next_step`, structured session lifecycle events (178 tests → see `v0.2.0-b1`) |
| **Phase B2** | **In progress** — scaffolding for B2-1/3/4/5/6/7a/7b landed across `v0.3.0-b2`–`v0.3.2-b2`; firmware-capture deliverables remain (see [TODO.md Phase B2](../TODO.md#b2--firmware-gated-requires-lab-hmc-or-ibm-simulator)) |
| **Phase C** | **Not started** — gated on threat-model and idempotency-policy drafts ([`docs/design/threat-model.md`](design/threat-model.md), [`docs/design/write-idempotency.md`](design/write-idempotency.md)) |

Install from source (`pip install -e ".[dev]"`) or clone at tag `v0.1.0`. PyPI publish is optional maintainer follow-up ([PyPI Trusted Publisher](release-engineering.md#pypi-trusted-publishing-oidc)); GitHub Release is the canonical Phase A artifact.

## Phase A → B evaluation checklist (exited 2026-05-18)

Use this list in a working session (demo + discussion). Check items off in your issue tracker or meeting notes. Boxes below reflect the state at exit.

### Product and agents

- [x] Run read tools against a lab HMC (or agreed mock/fixture demo) and confirm JSON shapes match agent expectations.
- [x] Review [agent-guide.md](agent-guide.md) sample outputs with the team consuming MCP tools.
- [x] Confirm write tools remain placeholder-only and `write_audit` events are visible in logs for dry-run / denied paths.

### Operations and security

- [x] Walk through [operations.md](operations.md) config and runbook entries with operators.
- [x] Confirm defaults: writes off, TLS on, allowlist understood for pilots.
- [x] Agree who owns HMC service accounts and correlation-ID log joins in your SIEM.

### Engineering

- [x] CI green on `main` (CI, Dependency Audit, Secret Scan).
- [x] Skim [architecture.md](architecture.md) `HmcSession` / write boundary — any concerns before Phase B/C churn?
- [x] Prioritize [TODO.md](../TODO.md) **B1** (no HMC) vs **B2** (firmware-gated); confirm lab HMC availability for B2.

### Release and distribution

- [x] GitHub Release [v0.1.0](https://github.com/TylrDn/power-hmc-mcp-server/releases/tag/v0.1.0) reviewed (notes, tag SHA).
- [x] Decide whether PyPI Trusted Publishing is required before external consumers install via `pip install power-hmc-mcp`.

## Exit criteria (Phase B) — met 2026-05-18

Phase B work began on `main` once:

1. The checklist above was reviewed (items checked or explicitly deferred with owners).
2. B1 vs B2 priority order was agreed (see [TODO.md Phase B](../TODO.md#phase-b--read-path-excellence-in-progress-b1-complete-b2-firmware-captures-pending)).
3. A tracking comment recorded **“Phase A evaluation complete — Phase B approved.”**

## Next gate — Phase B → C evaluation

Open before Phase C feature PRs land:

1. Threat-model draft reviewed ([`docs/design/threat-model.md`](design/threat-model.md)).
2. Idempotency policy reviewed and acceptable ([`docs/design/write-idempotency.md`](design/write-idempotency.md)).
3. At least one firmware capture confirming `X-Transaction-ID` echo behaviour (open B2 item).
4. RBAC matrix populated against the target HMC roles.

## Rhythm for future milestones

| Milestone | Tag (example) | Evaluation before |
|-----------|-----------------|-------------------|
| Phase A — Foundation | `v0.1.0` | Phase B |
| Phase B — Read-path excellence | `v0.2.0` (planned) | Phase C |
| Phase C — Write execution | `v0.3.0` (planned) | Phase D |

Adjust version numbers when cutting releases; keep the **evaluate → tag → next phase** pattern.
