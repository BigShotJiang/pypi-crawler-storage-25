# Release engineering & GitHub ops

Maintainer runbook for **power-hmc-mcp-server** Phase I (release) and Phase H (security CI). Complements [`TODO.md`](../TODO.md) and [`.github/workflows/`](../.github/workflows/).

---

## One-time GitHub bootstrap

After `gh auth login`, run from the repo root:

```bash
./scripts/github-bootstrap.sh
```

This script (idempotent where possible):

1. Sets repository **topics**: `mcp`, `ibm-power`, `hmc`, `lpar`, `python`, `opentelemetry`, `ai-agent`
2. Creates **milestones** Phase B through Phase I (skips if they already exist)
3. Assigns open issues to milestones using title/body heuristics
4. Adds open issues to your GitHub Project (if `GH_PROJECT_NUMBER` is set) and sets **Priority** / **Effort** fields when present

Override the project board:

```bash
export GH_PROJECT_NUMBER=1   # from github.com/users/TylrDn/projects/N
./scripts/github-bootstrap.sh
```

---

## Codecov (`CODECOV_TOKEN`)

CI uploads coverage from [`.github/workflows/ci.yml`](../.github/workflows/ci.yml). Step 1 is already implemented for **Python/pytest** (not Jest):

```bash
pytest --cov=src/power_hmc_mcp --cov-report=xml --cov-report=term-missing -q
```

That writes `coverage.xml` in the job workspace; the Codecov action uploads it on the Python 3.12 matrix leg only (avoids duplicate reports from 3.11 + 3.12).

Without `CODECOV_TOKEN`, uploads fail silently (`fail_ci_if_error: false`) and Codecov will not show coverage.

1. Sign in at [codecov.io](https://about.codecov.io/) and add the `TylrDn/power-hmc-mcp-server` repository.
2. Copy the **repository upload token** (Codecov → **power-hmc-mcp-server** → Settings → Repository Upload Token).
3. Add a GitHub Actions secret named exactly `CODECOV_TOKEN`:

   ```bash
   gh auth login -h github.com
   gh secret set CODECOV_TOKEN --repo TylrDn/power-hmc-mcp-server
   # paste the token when prompted; do not commit it to the repo
   ```

   Or: **GitHub → Settings → Secrets and variables → Actions → New repository secret** → name `CODECOV_TOKEN`, value = token from Codecov.

4. Push to `main` or re-run the **CI** workflow and confirm the upload step succeeds and the [Codecov dashboard](https://app.codecov.io/gh/TylrDn/power-hmc-mcp-server) shows coverage.

---

## PyPI Trusted Publishing (OIDC)

[`.github/workflows/release.yml`](../.github/workflows/release.yml) publishes on tags matching `v*.*.*` using OIDC — no long-lived PyPI password in GitHub.

### PyPI configuration

1. Create the project on [pypi.org](https://pypi.org/) if it does not exist (`power-hmc-mcp`).
2. **Publishing** → **Add a new trusted publisher**:
   - PyPI project name: `power-hmc-mcp`
   - Owner: `TylrDn`
   - Repository: `power-hmc-mcp-server`
   - Workflow name: `release.yml`
   - Environment name: *(leave empty until you enable the GitHub `production`
     environment — see [GitHub Environments](#github-environments); then set
     `production` here to match)*
3. Save.

### First release

Phase A shipped as GitHub tag **`v0.1.0`** ([release](https://github.com/TylrDn/power-hmc-mcp-server/releases/tag/v0.1.0)). PyPI publish requires Trusted Publisher setup below; until then, install from source or the release tarball.

```bash
# After Trusted Publisher is saved on PyPI (optional):
git tag v0.1.0.post1   # or re-run the failed Release workflow from Actions
git push origin v0.1.0.post1
```

The **Release** workflow builds with Hatchling and publishes with attestations (`pypa/gh-action-pypi-publish@release/v1`).

### SBOM and cosign-signed GitHub Release assets

After `python -m build`, the **Release** workflow also:

1. **Generates an SBOM** — `syft scan dir:dist` writes `dist/sbom.cyclonedx.json` (CycloneDX) covering the built wheel and sdist.
2. **Signs every release artifact** — `cosign sign-blob --yes` over each file in `dist/` (wheel, sdist, SBOM), emitting a `.sigstore.json` bundle per artifact.
3. **Attaches assets to the GitHub Release** — `softprops/action-gh-release@v2` uploads `dist/*` and the cosign bundles to the tag release page.

These GitHub Release artifacts are **complementary** to PyPI Sigstore attestations: PyPI consumers verify provenance via the Trusted Publisher + `attestations: true` path; GitHub Release consumers verify the same build via cosign bundles and the SBOM without touching PyPI. See [Verifying Release Attestations](#verifying-release-attestations) for consumer verification commands.

Container image signing (GHCR) is out of scope — `release.yml` does not publish images; CI only builds locally in the `docker-helm` job.

### Milestone rhythm

Each major phase ends with a tagged release and a **team evaluation** before the next phase starts. See [`milestone-evaluation.md`](milestone-evaluation.md) for the current gate (Phase A → B).

### Versioning policy (draft)

- **Semver** for MCP tool JSON contracts: breaking output shape or required args → major bump.
- **Pre-1.0**: `0.MINOR.PATCH` with optional `bN` beta suffix on tags (`v0.1.0b1`).
- Document breaking tool changes in [`CHANGELOG.md`](../CHANGELOG.md) with migration notes.

---

## GitHub Environments

GitHub Environments are configured in the repository UI — they cannot be created from workflow YAML alone.

### Create the `production` environment

1. Open **Settings → Environments → New environment**.
2. Name the environment **`production`**.

### Protection rules

Configure on the `production` environment:

- **Required reviewers:** `TylrDn` — blocks the `publish` job until a reviewer approves the deployment.
- **Deployment branches:** tag pattern **`v*.*.*`** — only semver release tags can trigger a publish to this environment.

### Activate in `release.yml`

Once the environment exists, uncomment `environment: production` in the `publish` job of [`.github/workflows/release.yml`](../.github/workflows/release.yml) (the stub is already present as commented lines). Re-run or push a tag to exercise the approval gate.

Also update the PyPI Trusted Publisher **Environment name** field to `production` so OIDC claims match (see [PyPI configuration](#pypi-configuration) above).

### Why this matters

A manual approval gate before PyPI publish gives maintainers a last checkpoint on sensitive releases (for example `v1.0.0`) without weakening the existing `needs: test` CI gate.

---

## Verifying Release Attestations

Release artifacts carry two independent provenance paths:

| Path | Tied to | Verified via |
|------|---------|--------------|
| **PyPI attestations** (PEP 740) | The package on PyPI | `pypi-attestations` against the installed version |
| **GitHub Release cosign bundles** | Assets on the GitHub Release page | `cosign verify-blob` against downloaded wheel/sdist/SBOM + `.sigstore.json` |

Both originate from the same [`release.yml`](../.github/workflows/release.yml) run but serve different consumers — PyPI installs vs GitHub Release downloads.

### PyPI attestation verification

After a tagged release is published to PyPI:

```bash
pip install pypi-attestations
python -m pypi_attestations verify power-hmc-mcp==X.Y.Z
```

Replace `X.Y.Z` with the release version (for example `0.6.2`).

### GitHub cosign bundle verification

Download the wheel and its `.sigstore.json` bundle from the GitHub Release assets, then:

```bash
cosign verify-blob dist/power_hmc_mcp-X.Y.Z-py3-none-any.whl \
  --bundle power_hmc_mcp-X.Y.Z-py3-none-any.whl.sigstore.json \
  --certificate-identity-regexp 'https://github.com/TylrDn/power-hmc-mcp-server' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

Repeat for the sdist (`.tar.gz`) and SBOM (`sbom.cyclonedx.json`) using their respective bundles.

### SBOM inspection

Inspect component names in the CycloneDX SBOM attached to the release:

```bash
cat dist/sbom.cyclonedx.json | jq .components[].name
```

---

## CI workflows summary

| Workflow | Trigger | Purpose |
|----------|---------|---------|
| `ci.yml` | push/PR `main` | `test` (4-leg matrix: ruff, mypy, pytest, coverage), `async-pair` (asyncio-only re-run), `docker-helm` (image build + smoke + chart lint/template/kubeconform) |
| `secret-scan.yml` | push/PR `main` | `detect-secrets scan --baseline` (CI-safe; interactive audit is local-only) |
| `audit.yml` | push/PR `main`, Mon 09:00 UTC | `pip-audit --strict`; artifact on failure |
| `release.yml` | tag `v*.*.*` | `test` (ruff, mypy, pytest on py3.12) then build + syft SBOM + cosign sign-blob + PyPI OIDC publish + GitHub Release assets |

### `ci.yml` build matrix (Phase D, D6)

`ci.yml` defines three jobs. The `test` job carries the 2 × 2 build matrix
that exercises the optional extras alongside the supported Python
versions; `async-pair` and `docker-helm` are 1-leg jobs that gate on
`test` and run in parallel.

| Job | Axis 1 — Python | Axis 2 — extras | What it runs | Codecov upload |
|-----|------------------|------------------|--------------|----------------|
| `test` | `3.11`, `3.12` | `dev`, `dev,langgraph` | `pre-commit` (only on `dev`), `ruff check`, `ruff format --check`, `mypy src/power_hmc_mcp`, `pytest --cov-fail-under=90` | only on `(3.12, dev)` to avoid duplicate reports |
| `async-pair` | `3.11`, `3.12` | `dev` | `pytest --no-cov` over `test_http_policy_async.py`, `test_session_async.py`, `test_hmc_client_async.py`, `test_pool.py` (re-runs only the asyncio test subset to surface event-loop regressions the broad `test` job could mask) | — |
| `docker-helm` | — | — | `docker buildx build` (multi-stage `Dockerfile`), demo-mode stdio boot smoke test, `helm lint`, three `helm template` permutations (default values, probes disabled, write tools enabled), `kubeconform -strict` on rendered manifests | — |

**Why two extras legs.** The `dev` leg is the fast-path baseline; the
`dev,langgraph` leg ensures the optional `[langgraph]` extra in
`pyproject.toml` (currently `langgraph>=0.2`) installs cleanly on every
push. Adding a new optional extra (e.g. `[otel]`) means appending one
matrix value here — never an axis that requires real HMC access.

**Why the async-pair job exists.** `http_policy.py` carries paired
`# SYNC-ONLY` and `# ASYNC` markers (Phase D, D1). A regression that
silently re-uses a sync helper from an async path would still pass the
broad `test` job because the surrounding sync test creates an event
loop. The `async-pair` job re-runs only the asyncio-marked tests with
`-p no:cacheprovider` to make event-loop regressions visible early.

**Why `docker-helm` is one job.** D4 originally shipped `docker-build`
and `helm-lint` as separate jobs. D6 collapsed them so the chart and
the image are validated against the same `pyproject.toml` snapshot in a
single workspace, simplifying required-status-check configuration on
`main`.

**Wheel package scope.** `[tool.hatch.build.targets.wheel] packages =
["src/power_hmc_mcp"]` in `pyproject.toml` already restricts the
distributed wheel to source — `examples/deploy/`, `tests/`, and
top-level docs never enter the artifact. D6 verifies this contract; do
not widen the package list when adding new top-level directories.

**Phase I separation.** D6 deliberately does not duplicate the full `ci.yml`
matrix in [`release.yml`](../.github/workflows/release.yml) — Phase I owns
release engineering. Tag-driven publishes run a representative `test` job
(py3.12, `dev` extras: ruff, mypy, pytest) before `publish` builds from
`pyproject.toml` via Trusted Publishing.

## Recommended branch protections (`main`)

Configure under **Settings → Branches → Branch protection rules** for `main`. These match the guardrails encoded in [`CONTRIBUTING.md` → Firmware validation rules](../CONTRIBUTING.md#firmware-validation-rules) and the CI matrix above.

> **Documentation ≠ enforcement.** Listing checks here does not block merges.
> Each name below must be ticked manually in the GitHub UI after at least
> one CI run has completed on a PR — status checks only appear in the picker
> once GitHub has seen them at least once.

### One-time setup (GitHub UI)

1. Open **Settings → Branches → Add branch protection rule** (or edit the existing `main` rule).
2. Branch name pattern: `main`.
3. Enable **Require a pull request before merging** (recommended).
4. Enable **Require status checks to pass before merging**.
5. Enable **Require branches to be up to date before merging** (recommended).
6. In **Status checks that are required**, search for and add each exact name from the table below. Job names come from the `name:` fields in [`.github/workflows/ci.yml`](../.github/workflows/ci.yml); GitHub prefixes them with the workflow name (`CI / …`).

| Required status check (exact string) | Source job |
|--------------------------------------|------------|
| `CI / test (py3.11, dev)` | `ci.yml` → `test` matrix |
| `CI / test (py3.11, dev,langgraph)` | `ci.yml` → `test` matrix |
| `CI / test (py3.12, dev)` | `ci.yml` → `test` matrix |
| `CI / test (py3.12, dev,langgraph)` | `ci.yml` → `test` matrix |
| `CI / async-pair (py3.11)` | `ci.yml` → `async-pair` matrix |
| `CI / async-pair (py3.12)` | `ci.yml` → `async-pair` matrix |
| `CI / docker-helm` | `ci.yml` → `docker-helm` |
| `Secret Scan / secret-scan` | `secret-scan.yml` |
| `Dependency Audit / audit` | `audit.yml` |

7. Save the rule. Open a test PR (or re-run CI on an existing PR) and confirm all nine checks appear green before merging.

### Policy summary

- Require a pull request before merging (no direct pushes to `main`).
- Require status checks to pass before merging — at minimum the nine checks in the table above.
- Require branches to be up to date before merging.
- (Optional) Require a `compatibility-doc` label or the "Compatibility doc rows" PR checklist to be ticked when the diff touches `src/power_hmc_mcp/normalize.py`, `routes.py` write builders, `observability.py` echo paths, or `docs/hmc-compatibility.md`.

Branch protection cannot be configured from this repo's CI — apply the rule in the GitHub UI (or via `gh api` with a token that has admin access). Private repos may require a GitHub plan that supports branch protection; if the API returns 403, use the web UI as repo owner.

---

## Milestones (Phase B → I)

| Milestone | Focus |
|-----------|--------|
| Phase B | Read-path excellence, firmware validation, PCM |
| Phase C | Write-path execution, real HMC mutations |
| Phase D | Transport, HTTP deployment, async client |
| Phase E | OpenTelemetry, log export, SLIs — **complete** |
| Phase F | Agent ergonomics, tool schemas, pagination — **complete** |
| Phase G | LangGraph / orchestration CI |
| Phase H | Threat model, vault, SBOM, security CI |
| Phase I | PyPI releases, semver, CHANGELOG discipline |

Map every open issue to exactly one milestone when triaging the project board.

---

## Related

- [`SECURITY.md`](../SECURITY.md) — vulnerability reporting
- [`CONTRIBUTING.md`](../CONTRIBUTING.md) — PR checklist (phase, HMC validation)
- [GitHub milestones](https://github.com/TylrDn/power-hmc-mcp-server/milestones)
