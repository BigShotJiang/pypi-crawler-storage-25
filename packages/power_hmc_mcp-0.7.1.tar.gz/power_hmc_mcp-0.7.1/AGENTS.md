# Agent instructions

Quick recipe for AI coding assistants and humans alike. Deeper docs live under [`docs/`](docs/) — start with [`docs/glossary.md`](docs/glossary.md) if any acronym is unfamiliar.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

Copy `.env.example` to `.env` and set HMC connection variables before running the server. Full env reference: [`docs/operations.md`](docs/operations.md#configuration-reference).

## Run

```bash
python -m power_hmc_mcp.mcp_server
```

Default transport is `stdio`. For streamable HTTP see [`docs/transports.md`](docs/transports.md).

## Test / lint / typecheck

```bash
pytest --cov=src/power_hmc_mcp --cov-report=term-missing -q
ruff check .
ruff format --check .
mypy src/power_hmc_mcp
```

CI runs the same checks on Python 3.11 and 3.12 plus coverage upload, secret scan, and dependency audit; pre-commit hooks (`pre-commit run --all-files`) bundle lint locally. Maintainer GitHub setup: [`docs/release-engineering.md`](docs/release-engineering.md).

## When you're touching code

- Read [`CONTRIBUTING.md`](CONTRIBUTING.md) for the new-tool recipes.
- Write tools must go through the structural guardrail (see [`docs/architecture.md` write safety model](docs/architecture.md#write-safety-model)). The boot-time marker check is intentional — fix the missing decorator, do not work around it.
- Keep `[RISK]` / `[PLACEHOLDER]` / `[ASSUMPTION]` markers in sync with [`TODO.md`](TODO.md).
