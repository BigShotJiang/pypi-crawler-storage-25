"""LangGraph examples moved under ``integrations/langgraph/``.

See ``integrations/langgraph/README.md``.
"""

from __future__ import annotations


def main() -> None:
    print("See integrations/langgraph/README.md")


if __name__ == "__main__":
    main()
