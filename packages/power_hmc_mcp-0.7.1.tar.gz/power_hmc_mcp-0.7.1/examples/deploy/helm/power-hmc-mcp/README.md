# power-hmc-mcp Helm chart

Kubernetes deployment for `power-hmc-mcp`. Mirrors the streamable-HTTP
posture from [`examples/deploy/`](../../) — the chart binds the MCP server
to a cluster-internal Service and assumes you place TLS termination + auth
at an Ingress / service mesh in front.

## Quickstart

```bash
# Optional: render templates to inspect before installing.
helm template my-power examples/deploy/helm/power-hmc-mcp \
  --set hmc.host=hmc.example.com \
  --set hmc.username=api-user \
  --set hmc.password=changeme

helm lint examples/deploy/helm/power-hmc-mcp

helm install my-power examples/deploy/helm/power-hmc-mcp \
  --create-namespace --namespace power-hmc \
  --set hmc.host=hmc.example.com \
  --set hmc.username=api-user \
  --set hmc.password=changeme   # prefer hmc.existingSecret for real installs
```

## Key values

| Value | Default | Notes |
|-------|---------|-------|
| `image.repository` / `image.tag` | `ghcr.io/coomes-ai/power-hmc-mcp` / `.Chart.AppVersion` | Override `image.tag` to pin to a specific build. |
| `mcp.transport` | `streamable-http` | `stdio` is unusual in K8s but supported via `kubectl exec`. |
| `mcp.http.probesPath` | `/` | Empty disables HTTP probes; the chart then falls back to TCP-socket health checks. |
| `hmc.existingSecret` | `""` | Recommended: pre-create a Secret with `HMC_HOST` / `HMC_USERNAME` / `HMC_PASSWORD` keys (External Secrets Operator, sealed-secrets, etc.). Inline `hmc.password` is for smoke tests only. |
| `hmc.allowedManagedSystems` | `[]` | Comma-joined into `HMC_ALLOWED_MANAGED_SYSTEMS` in the pod env. |
| `hmc.enableWriteTools` / `requireExecuteFlag` | `false` / `true` | Match the structural write-safety defaults; flip both deliberately if you intend to use write tools. |
| `ingress.enabled` | `false` | Off by default — bring your own gateway. |

## What the chart does NOT do

* It does not manage HMC credentials beyond emitting a chart-managed Secret
  (only when `hmc.existingSecret` is empty AND `hmc.host` is set). For
  production, **always** point `hmc.existingSecret` at a Secret managed by
  your platform (External Secrets, Sealed Secrets, ESO + Vault, …).
* It does not deploy NGINX / Envoy as a sidecar. Pair the chart with
  cluster-level ingress.
* It does not configure HMC RBAC. The user behind `HMC_USERNAME` should
  already be scoped to the operations the exposed tools need.

## Validating locally

```bash
helm lint examples/deploy/helm/power-hmc-mcp
helm template t examples/deploy/helm/power-hmc-mcp | kubectl apply --dry-run=client -f -
```

CI runs `helm lint` and `helm template` on every push (D6).
