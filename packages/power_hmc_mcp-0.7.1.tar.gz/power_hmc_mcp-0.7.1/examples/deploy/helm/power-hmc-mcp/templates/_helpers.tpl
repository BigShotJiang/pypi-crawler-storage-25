{{/*
Common helpers shared by all templates.
*/}}

{{- define "power-hmc-mcp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "power-hmc-mcp.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "power-hmc-mcp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "power-hmc-mcp.labels" -}}
helm.sh/chart: {{ include "power-hmc-mcp.chart" . }}
{{ include "power-hmc-mcp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "power-hmc-mcp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "power-hmc-mcp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Resolve the image tag, defaulting to .Chart.AppVersion when unset so
operators get a deterministic version pin even on a vanilla install.
*/}}
{{- define "power-hmc-mcp.imageTag" -}}
{{- default .Chart.AppVersion .Values.image.tag -}}
{{- end -}}
