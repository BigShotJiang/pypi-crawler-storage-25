# Deployment examples

Reverse-proxy and container orchestration samples for `power-hmc-mcp`. None of
these are run in CI as production endpoints — treat them as starting templates
to adapt to your network and identity provider.

For the operator-facing transport guide see
[`docs/transports.md`](../../docs/transports.md). For the session-affinity
decision the proxy hardening assumes, see
[`docs/design/http-session-affinity.md`](../../docs/design/http-session-affinity.md).
For the threat model these examples bind against, see
[`docs/design/threat-model.md`](../../docs/design/threat-model.md).

## Files

| Path | What it is |
|------|------------|
| `nginx.conf` | NGINX 1.27 reverse-proxy config: TLS termination, optional mTLS, `proxy_buffering off` for streamable HTTP, security headers, separate timeouts for `/mcp` vs `/healthz`/`/readyz`. |
| `envoy.yaml` | Equivalent Envoy config for environments that already run Envoy as the L7 ingress (e.g. service-mesh sidecars). |
| `docker-compose.yml` | Local stack: `power-hmc-mcp` (loopback streamable HTTP) behind `nginx:8443`. |
| `hmc.env.example` | Copy to `hmc.env` and fill in HMC credentials. **Do not commit `hmc.env`.** |
| `helm/power-hmc-mcp/` | Helm chart (D4) — deploys the same posture on Kubernetes. |

## What's NOT here

* Authentication policy. The MCP server intentionally does not implement
  auth itself — put SSO / OIDC / mTLS at the gateway.
* HMC RBAC. The user behind `HMC_USERNAME` should already be scoped to
  the operations the exposed tools need; the allowlist
  (`HMC_ALLOWED_MANAGED_SYSTEMS`) narrows blast radius further.
* Production-grade certificates. The samples reference paths under
  `./tls/`; provide real certs from your CA / cert-manager.

## Smoke test (NGINX path)

```bash
# 1. Drop a server cert/key into examples/deploy/tls/
mkdir -p examples/deploy/tls
openssl req -x509 -newkey rsa:2048 -nodes -keyout examples/deploy/tls/server.key \
    -out examples/deploy/tls/server.crt -days 30 \
    -subj "/CN=power-hmc-mcp.local"

# 2. Fill in HMC credentials
cp examples/deploy/hmc.env.example examples/deploy/hmc.env
$EDITOR examples/deploy/hmc.env

# 3. Bring up the stack
docker compose -f examples/deploy/docker-compose.yml up --build

# 4. Hit the listener (TLS verify off because of self-signed cert in this
#    smoke test; production must use a real CA).
curl -k https://localhost:8443/healthz
```
