"""Tests for observability helpers — structured log events and correlation IDs."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock

import pytest

from power_hmc_mcp import observability
from power_hmc_mcp.observability import (
    FIELD_CORRELATION_ID,
    FIELD_HMC_ALIAS,
    FIELD_HMC_PATH,
    FIELD_OUTCOME,
    FIELD_TOOL_NAME,
    telemetry_hook,
)


def _find_record(caplog: pytest.LogCaptureFixture, event_type: str) -> logging.LogRecord | None:
    for record in caplog.records:
        if getattr(record, "event_type", None) == event_type:
            return record
        if event_type in record.getMessage():
            return record
    return None


@pytest.fixture(autouse=True)
def _reset_observability_state(monkeypatch: pytest.MonkeyPatch) -> None:
    """Isolate correlation ID and OTEL state between tests."""
    token = observability.set_correlation_id(None)
    observability._otel_ready = False
    observability._otel_counters.clear()
    observability._otel_shutdown_registered = False
    observability._tracer_provider = None
    observability._meter_provider = None
    monkeypatch.delenv("HMC_OTEL_ENDPOINT", raising=False)
    yield
    observability.reset_correlation_id(token)
    observability._otel_ready = False
    observability._otel_counters.clear()
    observability._otel_shutdown_registered = False
    observability._tracer_provider = None
    observability._meter_provider = None


class TestLogLogonEnd:
    def test_emits_session_logon_end_event(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="success")

        assert any("session_logon_end" in r.getMessage() for r in caplog.records)

    def test_includes_hmc_host(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.example.com", outcome="success")

        assert any("hmc.example.com" in r.getMessage() for r in caplog.records)

    def test_includes_outcome(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="success")

        assert any("success" in r.getMessage() for r in caplog.records)

    def test_auto_binds_correlation_id(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="success")

        cid = observability.get_correlation_id()
        assert cid is not None
        assert any(cid in r.getMessage() for r in caplog.records)

    def test_demo_outcome_accepted(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="demo")

        assert any("demo" in r.getMessage() for r in caplog.records)

    def test_includes_component_field(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="success")

        assert any("power_hmc_mcp" in r.getMessage() for r in caplog.records)


class TestLogLogoffEnd:
    def test_emits_session_logoff_end_event(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logoff_end("hmc.test", outcome="success")

        assert any("session_logoff_end" in r.getMessage() for r in caplog.records)

    def test_error_outcome_accepted(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logoff_end("hmc.test", outcome="error")

        assert any("error" in r.getMessage() for r in caplog.records)

    def test_includes_component_field_via_base_fields(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logoff_end("hmc.test", outcome="success")

        assert any("power_hmc_mcp" in r.getMessage() for r in caplog.records)


class TestApiVersionHintInLogs:
    """HMC_API_VERSION_HINT plumbing — logging-only, omitted when unset."""

    def test_logon_includes_hint_when_set(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end(
                "hmc.test",
                outcome="success",
                api_version_hint="V11R1",
            )

        record = _find_record(caplog, "session_logon_end")
        assert record is not None
        message = record.getMessage()
        assert "hmc_api_version_hint" in message
        assert "V11R1" in message

    def test_logon_omits_hint_when_unset(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end("hmc.test", outcome="success")

        record = _find_record(caplog, "session_logon_end")
        assert record is not None
        assert "hmc_api_version_hint" not in record.getMessage()

    def test_logon_omits_hint_when_empty_string(
        self,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        """Defensive: empty string is treated the same as None."""
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logon_end(
                "hmc.test",
                outcome="success",
                api_version_hint="",
            )

        record = _find_record(caplog, "session_logon_end")
        assert record is not None
        assert "hmc_api_version_hint" not in record.getMessage()

    def test_logoff_includes_hint_when_set(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logoff_end(
                "hmc.test",
                outcome="success",
                api_version_hint="V10R2M1040",
            )

        record = _find_record(caplog, "session_logoff_end")
        assert record is not None
        message = record.getMessage()
        assert "hmc_api_version_hint" in message
        assert "V10R2M1040" in message

    def test_logoff_omits_hint_when_unset(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_logoff_end("hmc.test", outcome="success")

        record = _find_record(caplog, "session_logoff_end")
        assert record is not None
        assert "hmc_api_version_hint" not in record.getMessage()

    def test_field_constant_is_stable(self) -> None:
        """SIEM rules pin on this constant — must not silently rename."""
        assert observability.FIELD_HMC_API_VERSION_HINT == "hmc_api_version_hint"


class TestLogWriteAuditTelemetry:
    @pytest.mark.parametrize("outcome", ["denied", "dry_run", "authorized"])
    def test_log_write_audit_emits_telemetry_hook(
        self,
        outcome: str,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        captured: list[tuple[str, dict[str, object]]] = []

        def _capture(event_name: str, attributes: dict[str, object] | None = None) -> None:
            captured.append((event_name, attributes or {}))

        monkeypatch.setattr(observability, "telemetry_hook", _capture)
        observability.log_write_audit(
            tool_name="start_lpar",
            operation="start_lpar",
            outcome=outcome,
            reason="test reason",
            execute_requested=outcome == "authorized",
        )
        assert captured
        event_name, attrs = captured[-1]
        assert event_name == "write_audit"
        assert attrs[FIELD_TOOL_NAME] == "start_lpar"
        assert attrs[FIELD_OUTCOME] == outcome
        assert attrs[FIELD_CORRELATION_ID]


def test_format_traceparent_w3c_shape() -> None:
    value = observability.format_traceparent(
        trace_id=0x4BF92F3577B34DA6A3CE929D0E0E4736,
        span_id=0x00F067AA0BA902B7,
        trace_flags=0x01,
    )
    assert value == "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"


def test_inject_outbound_trace_headers_noop_without_otel(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(observability, "OTEL_AVAILABLE", False)
    headers: dict[str, str] = {}
    observability.inject_outbound_trace_headers(headers)
    assert "traceparent" not in headers


def test_telemetry_hook_emits_stub_when_otel_unavailable(
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(observability, "OTEL_AVAILABLE", False)
    caplog.set_level(logging.DEBUG, logger="power_hmc_mcp.observability")
    telemetry_hook("some_event", {"k": "v"})
    assert caplog.records
    message = caplog.records[-1].getMessage()
    assert "telemetry_stub" in message
    assert "some_event" in message


def test_telemetry_hook_emits_stub_when_endpoint_unset(
    caplog: pytest.LogCaptureFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(observability, "OTEL_AVAILABLE", True)
    caplog.set_level(logging.DEBUG, logger="power_hmc_mcp.observability")
    telemetry_hook("some_event", {"k": "v"})
    assert caplog.records
    message = caplog.records[-1].getMessage()
    assert "telemetry_stub" in message


def test_telemetry_hook_exports_otel_when_configured(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HMC_OTEL_ENDPOINT", "http://localhost:4318")
    monkeypatch.setattr(observability, "OTEL_AVAILABLE", True)
    export = MagicMock()
    monkeypatch.setattr(observability, "_ensure_otel", lambda: True)
    monkeypatch.setattr(observability, "_export_otel", export)

    telemetry_hook("hmc.request", {"duration_ms": 12.5, "outcome": "success"})

    export.assert_called_once_with(
        "hmc.request",
        {"duration_ms": 12.5, "outcome": "success"},
    )


class TestLogSessionReauth:
    def test_emits_session_reauth_event(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_session_reauth(
                outcome="success",
                hmc_host="hmc.test",
                trigger="401_mid_request",
            )
        assert any("session_reauth" in r.getMessage() for r in caplog.records)
        assert any("hmc.test" in r.getMessage() for r in caplog.records)
        assert any("401_mid_request" in r.getMessage() for r in caplog.records)

    def test_failure_outcome_accepted(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_session_reauth(
                outcome="failure",
                hmc_host="hmc.test",
                trigger="401_mid_request",
            )
        assert any("failure" in r.getMessage() for r in caplog.records)

    def test_rejects_unknown_outcome(self) -> None:
        with pytest.raises(ValueError, match="session_reauth outcome"):
            observability.log_session_reauth(
                outcome="not-an-outcome",
                hmc_host="hmc.test",
                trigger="401_mid_request",
            )

    def test_rejects_unknown_trigger(self) -> None:
        with pytest.raises(ValueError, match="session_reauth trigger"):
            observability.log_session_reauth(
                outcome="success",
                hmc_host="hmc.test",
                trigger="not-a-trigger",
            )

    def test_emits_hmc_alias_when_supplied(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_session_reauth(
                outcome="success",
                hmc_host="hmc.test",
                trigger="401_mid_request",
                hmc_alias="prod-east",
            )
        assert any(
            "hmc_alias" in r.getMessage() and "prod-east" in r.getMessage() for r in caplog.records
        )

    def test_omits_hmc_alias_when_none(self, caplog: pytest.LogCaptureFixture) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            observability.log_session_reauth(
                outcome="success",
                hmc_host="hmc.test",
                trigger="401_mid_request",
            )
        for record in caplog.records:
            assert "hmc_alias" not in record.getMessage()


class TestMcpToolCallTelemetry:
    def test_happy_path_emits_mcp_tool_telemetry(self, monkeypatch: pytest.MonkeyPatch) -> None:
        calls: list[tuple[str, dict[str, object] | None]] = []

        def _capture(event_name: str, attributes: dict[str, object] | None = None) -> None:
            calls.append((event_name, attributes))

        monkeypatch.setattr(observability, "telemetry_hook", _capture)
        observability.mcp_tool_call("health_check", lambda: {"status": "ok"}, hmc_alias="prod-east")

        mcp_calls = [c for c in calls if c[0] == "mcp.tool"]
        assert len(mcp_calls) == 1
        attrs = mcp_calls[0][1]
        assert attrs is not None
        assert attrs[FIELD_TOOL_NAME] == "health_check"
        assert attrs[FIELD_OUTCOME] == "success"
        assert attrs[FIELD_HMC_ALIAS] == "prod-east"


class TestOtelLifecycle:
    def test_ensure_otel_initializes_providers_once(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("HMC_OTEL_ENDPOINT", "http://localhost:4318")
        monkeypatch.setattr(observability, "OTEL_AVAILABLE", True)
        init = MagicMock()

        def _fake_init(endpoint: str) -> None:
            observability._tracer_provider = MagicMock()
            observability._meter_provider = MagicMock()
            observability._otel_ready = True

        init.side_effect = _fake_init
        monkeypatch.setattr(observability, "_init_otel_providers", init)
        monkeypatch.setattr(observability.atexit, "register", lambda *_a, **_kw: None)
        export = MagicMock()
        monkeypatch.setattr(observability, "_export_otel", export)

        telemetry_hook("hmc.request", {"outcome": "success"})
        telemetry_hook("mcp.tool", {"outcome": "success"})
        telemetry_hook("session.reauth", {"outcome": "success"})

        init.assert_called_once_with("http://localhost:4318")
        assert export.call_count == 3
        assert observability._otel_ready is True

    def test_shutdown_otel_flushes_and_shuts_down_providers(self) -> None:
        tracer = MagicMock()
        meter = MagicMock()
        observability._otel_ready = True
        observability._tracer_provider = tracer
        observability._meter_provider = meter
        observability._otel_counters["hmc.request.count"] = MagicMock()

        observability._shutdown_otel()

        tracer.force_flush.assert_called_once()
        tracer.shutdown.assert_called_once()
        meter.force_flush.assert_called_once()
        meter.shutdown.assert_called_once()
        assert observability._otel_ready is False
        assert observability._tracer_provider is None
        assert observability._meter_provider is None
        assert observability._otel_counters == {}

    def test_atexit_shutdown_registered_once_on_init(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        registrations: list[object] = []
        monkeypatch.setattr(
            observability.atexit,
            "register",
            lambda fn: registrations.append(fn),
        )
        monkeypatch.setenv("HMC_OTEL_ENDPOINT", "http://localhost:4318")
        monkeypatch.setattr(observability, "OTEL_AVAILABLE", True)

        def _fake_init(endpoint: str) -> None:
            observability._tracer_provider = MagicMock()
            observability._meter_provider = MagicMock()
            observability._otel_ready = True

        monkeypatch.setattr(observability, "_init_otel_providers", _fake_init)
        monkeypatch.setattr(observability, "_export_otel", MagicMock())

        telemetry_hook("hmc.request", {})
        telemetry_hook("hmc.request", {})

        assert len(registrations) == 1
        assert registrations[0] is observability._shutdown_otel


class TestOtelCardinality:
    def test_counter_attributes_exclude_correlation_id(self) -> None:
        attrs = {
            FIELD_CORRELATION_ID: "cid-123",
            FIELD_OUTCOME: "success",
            FIELD_HMC_PATH: "/rest/api/uom/ManagedSystem/sys1/LogicalPartition/l1",
        }
        span_attrs = observability._span_attributes(attrs)
        counter_attrs = observability._counter_attributes(attrs)
        assert FIELD_CORRELATION_ID in span_attrs
        assert FIELD_CORRELATION_ID not in counter_attrs

    def test_route_family_normalizes_dynamic_hmc_path_for_counters(self) -> None:
        path = "/rest/api/uom/ManagedSystem/system-abc/LogicalPartition/lpar-xyz/quick"
        normalized = observability._route_family_for_metrics(path)
        assert normalized == ("/rest/api/uom/ManagedSystem/{id}/LogicalPartition/{id}/quick")
        counter_attrs = observability._counter_attributes({FIELD_HMC_PATH: path})
        assert counter_attrs[FIELD_HMC_PATH] == normalized


class TestSliCallSiteTelemetry:
    def test_log_hmc_request_end_emits_hmc_request_telemetry(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        calls: list[tuple[str, dict[str, object] | None]] = []

        def _capture(event_name: str, attributes: dict[str, object] | None = None) -> None:
            calls.append((event_name, attributes))

        monkeypatch.setattr(observability, "telemetry_hook", _capture)
        observability.log_hmc_request_end(
            "GET",
            "/rest/api/uom/ManagedSystem",
            status_code=200,
            duration_ms=1.0,
            outcome="success",
        )
        assert calls[-1][0] == "hmc.request"

    def test_log_session_reauth_emits_session_reauth_telemetry(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        calls: list[tuple[str, dict[str, object] | None]] = []

        def _capture(event_name: str, attributes: dict[str, object] | None = None) -> None:
            calls.append((event_name, attributes))

        monkeypatch.setattr(observability, "telemetry_hook", _capture)
        observability.log_session_reauth(
            outcome="success",
            hmc_host="hmc.test",
            trigger="401_mid_request",
        )
        assert calls[-1][0] == "session.reauth"
