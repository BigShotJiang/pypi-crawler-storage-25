"""Bind-path smoke test for the streamable-HTTP transport (D2).

When ``HMC_MCP_TRANSPORT=streamable-http``, ``mcp_server.main()`` must
configure ``FastMCP.settings.host``, ``settings.port`` and
``settings.streamable_http_path`` from the corresponding ``HMC_MCP_HTTP_*``
env vars **before** calling ``mcp.run``. This guarantees that the
ASGI mount path advertised in ``docs/transports.md`` and assumed by the
NGINX / Envoy examples actually matches the application listener path.

Without this test, a refactor that drops the assignment would silently
change the ingress contract — every reverse-proxy doc would still claim
``/mcp`` while FastMCP defaults shifted to whatever the SDK ships next.
"""

from __future__ import annotations

import pytest

from power_hmc_mcp import mcp_server

_NON_DEFAULT_HOST = "0.0.0.0"  # noqa: S104 — non-default value for the test only
_NON_DEFAULT_PORT = 9123
_NON_DEFAULT_PATH = "/custom-mcp"


def _silence_atexit(monkeypatch: pytest.MonkeyPatch) -> None:
    """Avoid registering real atexit hooks during the smoke test."""
    monkeypatch.setattr(mcp_server.atexit, "register", lambda *_a, **_kw: None)


def test_streamable_http_bind_path_propagates_to_fastmcp(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    monkeypatch.setenv("HMC_MCP_TRANSPORT", "streamable-http")
    monkeypatch.setenv("HMC_MCP_HTTP_HOST", _NON_DEFAULT_HOST)
    monkeypatch.setenv("HMC_MCP_HTTP_PORT", str(_NON_DEFAULT_PORT))
    monkeypatch.setenv("HMC_MCP_HTTP_PATH", _NON_DEFAULT_PATH)

    captured: dict[str, object] = {}

    def fake_run(*args: object, **kwargs: object) -> None:
        captured["host"] = mcp_server.mcp.settings.host
        captured["port"] = mcp_server.mcp.settings.port
        captured["path"] = mcp_server.mcp.settings.streamable_http_path
        captured["transport_arg"] = kwargs.get("transport") or (args[0] if args else None)

    monkeypatch.setattr(mcp_server.mcp, "run", fake_run)
    _silence_atexit(monkeypatch)

    mcp_server.main()

    assert captured["host"] == _NON_DEFAULT_HOST, (
        "HMC_MCP_HTTP_HOST must propagate to FastMCP.settings.host before mcp.run; "
        "ingress docs assume the app listens on the env-var bind"
    )
    assert captured["port"] == _NON_DEFAULT_PORT
    assert captured["path"] == _NON_DEFAULT_PATH, (
        f"HMC_MCP_HTTP_PATH must propagate to FastMCP.settings.streamable_http_path; "
        f"reverse-proxy examples and docs/transports.md pin {_NON_DEFAULT_PATH!r} "
        "as the bind path"
    )
    assert captured["transport_arg"] == "streamable-http"


def test_stdio_transport_does_not_touch_http_settings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """For stdio, http settings must not be mutated by main()."""
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    monkeypatch.setenv("HMC_MCP_TRANSPORT", "stdio")

    sentinel_host = "sentinel.invalid"
    sentinel_port = 65432
    sentinel_path = "/sentinel"
    mcp_server.mcp.settings.host = sentinel_host
    mcp_server.mcp.settings.port = sentinel_port
    mcp_server.mcp.settings.streamable_http_path = sentinel_path

    monkeypatch.setattr(mcp_server.mcp, "run", lambda *_a, **_kw: None)
    _silence_atexit(monkeypatch)

    mcp_server.main()

    assert mcp_server.mcp.settings.host == sentinel_host
    assert mcp_server.mcp.settings.port == sentinel_port
    assert mcp_server.mcp.settings.streamable_http_path == sentinel_path
