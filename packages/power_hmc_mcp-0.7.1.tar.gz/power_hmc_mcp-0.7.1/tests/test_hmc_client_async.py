"""Tests for HmcAsyncClient — async mirror of HmcClient read surface.

Covers demo-mode short-circuit, list_managed_systems, list_lpars,
get_lpar_status (uom + quick), get_capacity, health_check, and
is_authenticated().
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client_async import HmcAsyncClient
from power_hmc_mcp.routes import LOGON_PATH, MANAGED_SYSTEMS_PATH, SESSION_HEADER
from power_hmc_mcp.session_async import HmcAsyncSession
from tests.conftest import LPAR_ID, SYSTEM_ID, apply_hmc_env

FIXTURES = Path(__file__).parent / "fixtures"

pytestmark = pytest.mark.asyncio


def _fx(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


def _make_async_client(
    settings: Settings,
    handler: Callable[[httpx.Request], httpx.Response],
) -> HmcAsyncClient:
    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    session = HmcAsyncSession(settings, http_client=http)
    return HmcAsyncClient(settings, session=session)


def _stable_handler() -> Callable[[httpx.Request], httpx.Response]:
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "async-tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and path.endswith(LOGON_PATH):
            return httpx.Response(200)
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(200, text=_fx("managed_systems_feed.xml"))
        if request.method == "GET" and path.endswith(
            f"{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}/LogicalPartition"
        ):
            return httpx.Response(200, text=_fx("logical_partitions_feed.xml"))
        if request.method == "GET" and path.endswith(f"{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}"):
            return httpx.Response(200, text=_fx("managed_system_detail.xml"))
        if request.method == "GET" and path.endswith(
            f"{MANAGED_SYSTEMS_PATH}/{SYSTEM_ID}/LogicalPartition/{LPAR_ID}",
        ):
            return httpx.Response(200, text=_fx("logical_partition_detail.xml"))
        if "ProcessedMetrics" in path:
            return httpx.Response(200, text=_fx("pcm_processed_metrics_feed.xml"))
        return httpx.Response(404)

    return handler


# --- demo mode -------------------------------------------------------------


async def test_demo_mode_makes_no_http_calls(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    settings = Settings()

    def reject(request: httpx.Request) -> httpx.Response:
        raise AssertionError(f"demo mode must not issue HTTP: {request.method} {request.url}")

    client = _make_async_client(settings, reject)
    await client.login()
    systems = await client.list_managed_systems()
    assert isinstance(systems, list)
    assert systems  # demo fixture is populated
    status = await client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    assert isinstance(status, dict)
    assert "lpar_id" in status
    health = await client.health_check()
    assert health["status"] == "ok"
    assert client.is_authenticated() is False  # demo never authenticates
    await client.close()


# --- read surface ----------------------------------------------------------


async def test_list_managed_systems_returns_list(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    assert client.is_authenticated() is True
    items = await client.list_managed_systems()
    assert isinstance(items, list)
    assert items, "fixture must produce at least one managed system"
    for item in items:
        assert "id" in item
        assert isinstance(item["id"], str)
    await client.close()
    assert client.is_authenticated() is False


async def test_list_lpars_returns_list(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    items = await client.list_lpars(SYSTEM_ID)
    assert isinstance(items, list)
    assert items
    await client.close()


async def test_get_lpar_status_uom(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    status = await client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    assert status["lpar_id"] == LPAR_ID
    assert status["source"] == "uom"
    assert "canonical_state" in status
    await client.close()


async def test_get_lpar_status_quick(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_LPAR_STATUS_SOURCE", "quick")
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and path.endswith(LOGON_PATH):
            return httpx.Response(200)
        if "/quick/PartitionState" in path:
            return httpx.Response(200, text=_fx("lpar_quick_partition_state.xml"))
        if "/quick/PartitionName" in path:
            return httpx.Response(200, text=_fx("lpar_quick_partition_name.xml"))
        if "/quick/PartitionID" in path:
            return httpx.Response(200, text=_fx("lpar_quick_partition_id.xml"))
        if "/quick/RMCState" in path:
            return httpx.Response(200, text=_fx("lpar_quick_rmc_state.xml"))
        return httpx.Response(404)

    client = _make_async_client(settings, handler)
    await client.login()
    status = await client.get_lpar_status(SYSTEM_ID, LPAR_ID)
    assert status["source"] == "quick"
    assert "raw_quick" in status
    await client.close()


async def test_get_capacity_metadata(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    capacity = await client.get_capacity(SYSTEM_ID, mode="metadata")
    assert capacity["managed_system_id"] == SYSTEM_ID
    assert capacity["mode"] == "metadata"
    assert "samples" in capacity
    await client.close()


async def test_get_capacity_full_placeholder(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    full: dict[str, Any] = await client.get_capacity_full(SYSTEM_ID, "/some/href")
    assert full["placeholder"] is True
    assert "min_cpu_pct" in full
    await client.close()


async def test_health_check_returns_status_ok(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    health = await client.health_check()
    assert health["status"] == "ok"
    assert health["session_active"] is True
    await client.close()


async def test_get_managed_system_normalizes(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    item = await client.get_managed_system(SYSTEM_ID)
    assert item["id"] == SYSTEM_ID
    assert "properties" in item
    await client.close()


async def test_get_lpar_normalizes(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    item = await client.get_lpar(SYSTEM_ID, LPAR_ID)
    assert item["managed_system_id"] == SYSTEM_ID
    await client.close()


async def test_list_partition_profiles_demo(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    settings = Settings()

    def reject(request: httpx.Request) -> httpx.Response:
        raise AssertionError("demo must not call HMC")

    client = _make_async_client(settings, reject)
    items = await client.list_partition_profiles(LPAR_ID)
    assert isinstance(items, list)
    await client.close()


async def test_get_capacity_summary(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    capacity = await client.get_capacity(SYSTEM_ID, mode="summary")
    assert capacity["mode"] == "summary"
    assert "summary" in capacity
    await client.close()


async def test_get_capacity_full_mode_raises_validation_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    from power_hmc_mcp.exceptions import HmcValidationError

    with pytest.raises(HmcValidationError, match="Phase A"):
        await client.get_capacity(SYSTEM_ID, mode="full")
    await client.close()


async def test_get_capacity_full_rejects_empty_href(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    from power_hmc_mcp.exceptions import HmcValidationError

    with pytest.raises(HmcValidationError, match="non-empty"):
        await client.get_capacity_full(SYSTEM_ID, "")


async def test_async_client_context_manager(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    transport = httpx.MockTransport(_stable_handler())
    http = httpx.AsyncClient(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    session = HmcAsyncSession(settings, http_client=http)
    async with HmcAsyncClient(settings, session=session) as client:
        items = await client.list_managed_systems()
        assert items


async def test_async_client_close_swallows_logoff_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """HmcClient.close() emits session_logoff_end error and does not raise."""
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and path.endswith(LOGON_PATH):
            raise httpx.ConnectError("boom", request=request)
        return httpx.Response(404)

    client = _make_async_client(settings, handler)
    await client.login()
    await client.close()  # must not raise


async def test_async_client_check_allowlist_rejects(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv(
        "HMC_ALLOWED_MANAGED_SYSTEMS",
        "00000000-0000-0000-0000-000000000000",
    )
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    from power_hmc_mcp.exceptions import HmcValidationError

    with pytest.raises(HmcValidationError, match="not in HMC_ALLOWED_MANAGED_SYSTEMS"):
        await client.list_lpars(SYSTEM_ID)


async def test_async_client_filters_managed_systems_to_allowlist(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Allowlist narrows list_managed_systems to permitted ids."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ALLOWED_MANAGED_SYSTEMS", SYSTEM_ID)
    settings = Settings()
    client = _make_async_client(settings, _stable_handler())
    await client.login()
    items = await client.list_managed_systems()
    for item in items:
        assert item["id"] == SYSTEM_ID
    await client.close()
