"""End-to-end tests with httpx.MockTransport (full HmcClient request pipeline)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import httpx
import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client import LOGON_PATH, MANAGED_SYSTEMS_PATH, SESSION_HEADER, HmcClient
from power_hmc_mcp.observability import mcp_tool_call
from tests.conftest import SYSTEM_ID, apply_hmc_env

FIXTURES = Path(__file__).parent / "fixtures"
MOCK_SESSION = "mock-token-123"
MANAGED_SYSTEMS_XML = (FIXTURES / "managed_systems_feed.xml").read_text(encoding="utf-8")


@dataclass
class _MockHmcState:
    managed_system_get_count: int = 0
    fail_first_managed_system_get: bool = False
    logon_count: int = 0


def _build_mock_handler(state: _MockHmcState):
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            state.logon_count += 1
            return httpx.Response(
                200,
                headers={SESSION_HEADER: MOCK_SESSION},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and path.endswith(LOGON_PATH):
            return httpx.Response(200)
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            state.managed_system_get_count += 1
            if state.fail_first_managed_system_get and state.managed_system_get_count == 1:
                return httpx.Response(401)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404, text=f"unmocked {request.method} {path}")

    return handler


def _mock_client(settings: Settings, state: _MockHmcState) -> HmcClient:
    transport = httpx.MockTransport(_build_mock_handler(state))
    http = httpx.Client(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    return HmcClient(settings, http_client=http)


@pytest.fixture
def integration_settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    return Settings()


def test_full_list_managed_systems(integration_settings: Settings) -> None:
    state = _MockHmcState()
    client = _mock_client(integration_settings, state)
    systems = client.list_managed_systems()
    assert len(systems) == 2
    assert systems[0]["id"] == SYSTEM_ID
    assert systems[0]["name"] == "p9-SiteA"
    assert systems[0]["state"] == "operating"
    assert systems[1]["name"] == "p9-SiteB"
    assert state.logon_count >= 1


def test_session_reauth_on_401(integration_settings: Settings) -> None:
    state = _MockHmcState(fail_first_managed_system_get=True)
    client = _mock_client(integration_settings, state)
    systems = client.list_managed_systems()
    assert len(systems) == 2
    assert state.managed_system_get_count == 2
    assert state.logon_count >= 2


def test_health_check_end_to_end(integration_settings: Settings) -> None:
    state = _MockHmcState()
    client = _mock_client(integration_settings, state)
    result = mcp_tool_call("health_check", client.health_check)
    assert result["status"] == "ok"
    assert result["hmc_host"] == "hmc.test"
    assert result["managed_system_count"] == 2
