"""Async HTTP policy helpers (mirror tests/test_http_policy.py).

Verifies:
  * ``_assert_async_context`` raises outside a running event loop.
  * ``retry_sleep_async`` defers to ``asyncio.sleep`` (no ``time.sleep``).
  * ``throttle_before_request_async`` is a no-op when the floor is 0
    and sleeps when within the floor window.
"""

from __future__ import annotations

import asyncio
import time

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.http_policy import (
    _assert_async_context,
    retry_sleep_async,
    throttle_before_request_async,
)
from tests.conftest import apply_hmc_env


def test_assert_async_context_raises_when_no_loop(monkeypatch: pytest.MonkeyPatch) -> None:
    """No event loop running ⇒ guard must raise (mirrors the sync-side guard)."""
    apply_hmc_env(monkeypatch)
    with pytest.raises(RuntimeError, match="async-only"):
        _assert_async_context("retry_sleep_async")


def test_assert_async_context_passes_when_loop_running(monkeypatch: pytest.MonkeyPatch) -> None:
    """Loop running ⇒ guard returns silently."""
    apply_hmc_env(monkeypatch)

    async def inner() -> None:
        _assert_async_context("retry_sleep_async")  # must not raise

    asyncio.run(inner())


@pytest.mark.asyncio
async def test_retry_sleep_async_uses_asyncio_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_RETRY_BASE_SECONDS", "0.01")
    monkeypatch.setenv("HMC_RETRY_MAX_SECONDS", "0.01")
    settings = Settings()

    sleeps_async: list[float] = []

    async def fake_async_sleep(seconds: float) -> None:
        sleeps_async.append(seconds)

    sleeps_sync: list[float] = []
    monkeypatch.setattr(time, "sleep", lambda s: sleeps_sync.append(s))
    monkeypatch.setattr(asyncio, "sleep", fake_async_sleep)

    await retry_sleep_async(settings, 0)
    assert sleeps_async, "retry_sleep_async must call asyncio.sleep"
    assert sleeps_sync == [], "retry_sleep_async must not call time.sleep"


@pytest.mark.asyncio
async def test_throttle_async_no_op_when_floor_zero(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MIN_REQUEST_INTERVAL_SECONDS", "0.0")
    settings = Settings()

    sleeps_async: list[float] = []

    async def fake_async_sleep(seconds: float) -> None:
        sleeps_async.append(seconds)

    monkeypatch.setattr(asyncio, "sleep", fake_async_sleep)
    await throttle_before_request_async(settings, last_request_monotonic=time.monotonic())
    assert sleeps_async == [], "asyncio.sleep must not be called when floor is 0"


@pytest.mark.asyncio
async def test_throttle_async_sleeps_when_within_floor(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MIN_REQUEST_INTERVAL_SECONDS", "10.0")
    settings = Settings()

    sleeps_async: list[float] = []

    async def fake_async_sleep(seconds: float) -> None:
        sleeps_async.append(seconds)

    monkeypatch.setattr(asyncio, "sleep", fake_async_sleep)
    await throttle_before_request_async(settings, last_request_monotonic=time.monotonic())
    assert sleeps_async, "asyncio.sleep must be called when within the floor window"
    assert 0 < sleeps_async[0] <= 10.0
