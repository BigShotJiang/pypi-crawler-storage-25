"""Tests for HmcClientPool and single_client_resolver (D5)."""

from __future__ import annotations

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.demo_provider import DemoProvider
from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.hmc_client_async import HmcAsyncClient
from power_hmc_mcp.pool import HmcClientPool, single_client_resolver
from power_hmc_mcp.registry import build_registry
from tests.conftest import apply_hmc_env


def _multi_settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv(
        "HMC_REGISTRY",
        '[{"alias": "prod-east", "host": "east.example", "username": "u",'
        ' "password": "p"},'
        ' {"alias": "prod-west", "host": "west.example", "username": "u",'
        ' "password": "p"}]',
    )
    return Settings()


def test_pool_lazy_construction(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))
    assert pool.aliases() == ("default", "prod-east", "prod-west")
    assert pool._sync == {}

    east = pool.get_sync("prod-east")
    assert isinstance(east, HmcClient)
    assert east.settings.hmc_host == "east.example"
    assert "prod-east" in pool._sync

    east_again = pool.get_sync("prod-east")
    assert east_again is east  # cached, single instance per (alias, mode)


def test_pool_resolves_none_to_default_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))

    default_via_none = pool.get_sync(None)
    default_via_name = pool.get_sync("default")
    assert default_via_none is default_via_name


def test_pool_normalises_alias_case(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))

    east_lower = pool.get_sync("prod-east")
    east_upper = pool.get_sync("PROD-EAST")
    assert east_upper is east_lower


def test_pool_unknown_alias_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))

    with pytest.raises(HmcValidationError, match="Unknown HMC alias"):
        pool.get_sync("does-not-exist")


def test_pool_sync_and_async_independent_per_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))

    sync_east = pool.get_sync("prod-east")
    async_east = pool.get_async("prod-east")
    assert isinstance(sync_east, HmcClient)
    assert isinstance(async_east, HmcAsyncClient)
    # The two share an alias but have separate clients (independent HMC sessions).
    assert sync_east is not async_east  # type: ignore[comparison-overlap]


def test_single_client_resolver_returns_client_for_default_alias(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = HmcClient(settings)
    resolver = single_client_resolver(client)
    assert resolver(None) is client
    assert resolver("default") is client
    assert resolver("DEFAULT") is client


def test_pool_demo_mode_returns_demo_provider(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    settings = Settings()
    pool = HmcClientPool(build_registry(settings))
    client = pool.get_sync(None)
    assert isinstance(client, DemoProvider)
    assert not isinstance(client, HmcClient)


def test_single_client_resolver_rejects_unknown_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    client = HmcClient(settings)
    resolver = single_client_resolver(client)
    with pytest.raises(HmcValidationError, match="Unknown HMC alias"):
        resolver("prod-east")


def test_pool_close_all_calls_close_on_each_sync_client(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))

    east = pool.get_sync("prod-east")
    closed = {"count": 0}

    def fake_close() -> None:
        closed["count"] += 1

    east.close = fake_close  # type: ignore[method-assign]
    pool.close_all()
    assert closed["count"] == 1
    assert pool._sync == {}


def test_pool_close_all_swallows_exceptions(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _multi_settings(monkeypatch)
    pool = HmcClientPool(build_registry(settings))
    east = pool.get_sync("prod-east")

    def boom() -> None:
        raise RuntimeError("close failed")

    east.close = boom  # type: ignore[method-assign]
    pool.close_all()  # must not raise
    assert pool._sync == {}
