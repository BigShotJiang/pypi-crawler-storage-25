"""Tool output contract tests — golden-fixture snapshot assertions.

Each parametrized case calls the corresponding HmcClient method (via the
``hmc_client`` fixture, which serves pre-recorded XML responses) and then
checks that the live output matches the golden JSON fixture stored in
``tests/fixtures/<tool_name>.json``.

The test intentionally FAILS when:
  - A key documented in the fixture disappears from the output.
  - A key's type changes (e.g. str → list).
  - An undocumented top-level key appears on dict responses.

This is the first-line drift alarm for agent consumers: if ``normalize.py``
(or the relevant section of ``hmc_client.py``) changes output shape, this test
catches it before agents silently receive broken data.

Note: ``window_start_ts`` in ``get_capacity`` is a dynamic timestamp computed
at call time.  The contract asserts it is a non-empty string; the fixture
stores a representative value for human reference but exact equality is not
checked for that field.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from tests.conftest import LPAR_ID, SYSTEM_ID

FIXTURES = Path(__file__).parent / "fixtures"


def _load(name: str) -> Any:
    return json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))


def _assert_keys_and_types(actual: dict[str, Any], expected: dict[str, Any]) -> None:
    """Assert every key in expected is present in actual with matching type."""
    for key, exp_val in expected.items():
        assert key in actual, f"key {key!r} missing from output"
        act_val = actual[key]
        assert type(act_val) is type(exp_val), (
            f"key {key!r}: expected type {type(exp_val).__name__}, got {type(act_val).__name__}"
        )


def _assert_no_extra_keys(actual: dict[str, Any], expected: dict[str, Any]) -> None:
    """Fail if actual has top-level keys not present in the golden fixture."""
    undocumented = set(actual.keys()) - set(expected.keys())
    assert not undocumented, (
        f"Undocumented keys in output (update the fixture or remove from tool): {undocumented}"
    )


def _assert_list_item_shape(
    items: list[Any],
    expected_item: dict[str, Any],
) -> None:
    """Assert every item in a list result has the same key+type shape."""
    for i, item in enumerate(items):
        assert isinstance(item, dict), f"item[{i}] is not a dict"
        _assert_keys_and_types(item, expected_item)
        _assert_no_extra_keys(item, expected_item)


class TestListManagedSystems:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.list_managed_systems()
        fixture = _load("list_managed_systems")

        assert isinstance(result, list)
        assert len(result) == len(fixture), "item count diverged from fixture"
        _assert_list_item_shape(result, fixture[0])

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("list_managed_systems")
        for item in fixture:
            for key in ("id", "name", "uri", "state"):
                assert key in item, f"fixture missing required key {key!r}"
            for key in ("id", "name", "uri", "state"):
                assert isinstance(item[key], str), f"fixture key {key!r} must be str"


class TestGetManagedSystem:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.get_managed_system(SYSTEM_ID)
        fixture = _load("get_managed_system")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)

    def test_properties_is_dict_of_strings(self, hmc_client: Any) -> None:
        result = hmc_client.get_managed_system(SYSTEM_ID)
        assert isinstance(result["properties"], dict)
        for v in result["properties"].values():
            assert isinstance(v, str), "all property values must be str"

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("get_managed_system")
        for key in ("id", "name", "state", "uri", "properties"):
            assert key in fixture, f"fixture missing required key {key!r}"


class TestListLpars:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.list_lpars(SYSTEM_ID)
        fixture = _load("list_lpars")

        assert isinstance(result, list)
        assert len(result) == len(fixture)
        _assert_list_item_shape(result, fixture[0])

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("list_lpars")
        for item in fixture:
            for key in ("id", "name", "uri", "state", "partition_id"):
                assert key in item, f"fixture missing required key {key!r}"


class TestGetLpar:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.get_lpar(SYSTEM_ID, LPAR_ID)
        fixture = _load("get_lpar")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("get_lpar")
        required = ("id", "name", "state", "partition_id", "uri", "properties", "managed_system_id")
        for key in required:
            assert key in fixture, f"fixture missing required key {key!r}"


class TestGetLparStatus:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.get_lpar_status(SYSTEM_ID, LPAR_ID)
        fixture = _load("get_lpar_status")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)

    def test_source_is_uom(self, hmc_client: Any) -> None:
        result = hmc_client.get_lpar_status(SYSTEM_ID, LPAR_ID)
        assert result["source"] == "uom"

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("get_lpar_status")
        for key in (
            "managed_system_id",
            "lpar_id",
            "source",
            "name",
            "state",
            "canonical_state",
            "partition_id",
            "rmc_state",
            "properties",
        ):
            assert key in fixture, f"fixture missing required key {key!r}"


class TestListPartitionProfiles:
    def test_output_matches_fixture(self, hmc_client: Any) -> None:
        result = hmc_client.list_partition_profiles(LPAR_ID)
        fixture = _load("list_partition_profiles")

        assert isinstance(result, list)
        assert len(result) == len(fixture)
        _assert_list_item_shape(result, fixture[0])

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("list_partition_profiles")
        for item in fixture:
            for key in ("id", "name", "uri"):
                assert key in item, f"fixture missing required key {key!r}"


class TestGetCapacity:
    def test_metadata_mode_output_matches_fixture_shape(self, hmc_client: Any) -> None:
        """Full golden fixture match for mode=metadata (canonical contract shape)."""
        result = hmc_client.get_capacity(SYSTEM_ID, mode="metadata")
        fixture = _load("get_capacity")

        assert isinstance(result, dict)
        # window_start_ts is dynamic — check type only, not exact value
        expected_without_ts = {k: v for k, v in fixture.items() if k != "window_start_ts"}
        actual_without_ts = {k: v for k, v in result.items() if k != "window_start_ts"}
        _assert_keys_and_types(actual_without_ts, expected_without_ts)
        _assert_no_extra_keys(actual_without_ts, expected_without_ts)

        assert "window_start_ts" in result
        assert isinstance(result["window_start_ts"], str)
        assert result["window_start_ts"]  # non-empty

    def test_metadata_mode_samples_shape(self, hmc_client: Any) -> None:
        result = hmc_client.get_capacity(SYSTEM_ID, mode="metadata")
        assert "samples" in result
        assert isinstance(result["samples"], list)
        for item in result["samples"]:
            assert isinstance(item, dict)
            for key in ("sample_id", "category", "updated", "metrics_href"):
                assert key in item, f"sample missing key {key!r}"
                assert isinstance(item[key], str)

    def test_summary_mode_shape_only(self, hmc_client: Any) -> None:
        """Shape-only assertion for mode=summary (no golden JSON file for this mode)."""
        result = hmc_client.get_capacity(SYSTEM_ID, mode="summary")

        assert isinstance(result, dict)
        assert result.get("mode") == "summary"
        assert "summary" in result, "mode=summary must include 'summary' key"
        assert "samples" not in result, "mode=summary must not include 'samples' key"

        summary = result["summary"]
        assert isinstance(summary, dict)
        assert "sample_count" in summary
        assert isinstance(summary["sample_count"], int)
        assert "categories" in summary
        assert isinstance(summary["categories"], dict)
        assert "latest_updated" in summary or summary.get("latest_updated") is None

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("get_capacity")
        for key in ("managed_system_id", "mode", "window_start_ts", "pcm_enabled", "samples"):
            assert key in fixture, f"fixture missing required key {key!r}"


class TestHealthCheck:
    def test_output_matches_fixture_shape(self, hmc_client: Any) -> None:
        result = hmc_client.health_check()
        fixture = _load("health_check")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)

    def test_status_is_ok(self, hmc_client: Any) -> None:
        result = hmc_client.health_check()
        assert result["status"] == "ok"

    def test_session_active_is_bool(self, hmc_client: Any) -> None:
        result = hmc_client.health_check()
        assert isinstance(result["session_active"], bool)

    def test_managed_system_count_is_int(self, hmc_client: Any) -> None:
        result = hmc_client.health_check()
        assert isinstance(result["managed_system_count"], int)

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("health_check")
        for key in ("status", "hmc_host", "session_active", "managed_system_count"):
            assert key in fixture, f"fixture missing required key {key!r}"


class TestGetCapacityFull:
    """B2-7a contract scaffold for ``get_capacity_full``.

    Phase B2-7a establishes the test surface and golden fixture *before* the
    actual ``metrics_href`` GET is wired (B2-7b).  ``placeholder=True`` paths
    pass today; the ``placeholder=False`` aggregate-shape assertion is marked
    ``xfail(strict=True)`` so it converts into a real assertion as soon as
    B2-7b lands and the fetch returns real samples.
    """

    METRICS_HREF = "/rest/api/pcm/ProcessedMetrics/sample.json"

    REQUIRED_KEYS = (
        "managed_system_id",
        "metrics_href",
        "placeholder",
        "min_cpu_pct",
        "max_cpu_pct",
        "avg_cpu_pct",
    )

    def test_returns_placeholder_until_b2_7b_wired(self, hmc_client: Any) -> None:
        result = hmc_client.get_capacity_full(SYSTEM_ID, self.METRICS_HREF)
        assert result["placeholder"] is True
        for key in self.REQUIRED_KEYS:
            assert key in result, f"placeholder result missing key {key!r}"
        assert result["metrics_href"] == self.METRICS_HREF

    def test_fixture_has_required_keys(self) -> None:
        fixture = _load("get_capacity_full")
        for key in self.REQUIRED_KEYS:
            assert key in fixture, f"fixture missing required key {key!r}"

    @pytest.mark.xfail(
        reason=(
            "B2-7b: requires real metrics_href GET wired in get_capacity_full; "
            "utilizedProcUnits field name is confirmed (IBM Docs Power9/10/11)"
        ),
        strict=True,
    )
    def test_aggregates_are_floats_when_samples_present(self, hmc_client: Any) -> None:
        """B2-7b gate: aggregates must be float (not None) after the real fetch is wired."""
        result = hmc_client.get_capacity_full(SYSTEM_ID, self.METRICS_HREF)
        assert result["placeholder"] is False
        assert isinstance(result["min_cpu_pct"], float)
        assert isinstance(result["max_cpu_pct"], float)
        assert isinstance(result["avg_cpu_pct"], float)
