"""Route builders stay aligned with IBM Power HMC REST conventions.

Read-path assertions below use **verbatim** IBM-doc URL strings so a
silent string drift in routes.py fails CI before agents see broken paths.
Doc references:

* Power10 ManagedSystem — https://www.ibm.com/docs/en/power10?topic=apis-managed-system
* Power11 LogicalPartition — https://www.ibm.com/docs/en/power11/9856-22H?topic=system-logical-partition
* Power10 LogicalPartitionProfile — https://www.ibm.com/docs/en/power10?topic=system-logical-partition-profile
* Power11 URL Model — https://www.ibm.com/docs/en/power11/9856-22H?topic=hmc-rest-apis

Write-path builders are deliberately asserted by **shape only** (prefix +
``/do/`` segment) because the IBM URL grammar's ``{OP}`` names remain
firmware-pending; see ``docs/hmc-compatibility.md`` 'Write Operation Paths'.
"""

from __future__ import annotations

import pytest

from power_hmc_mcp import routes

# Representative IBM-style UUIDs.  Values are arbitrary; tests only assert
# substring placement, never the UUID payload itself.
_SYS_UUID = "38f2a140-b30f-8544-7a1b-2c3d4e5f1234"
_LPAR_UUID = "11111111-2222-3333-4444-555566667777"


# --- Backwards-compatible / session constants ------------------------------


def test_backward_compatible_constants() -> None:
    assert routes.LOGON_PATH == "/rest/api/web/Logon"
    assert routes.MANAGED_SYSTEMS_PATH == routes.MANAGED_SYSTEM_COLLECTION_PATH
    assert routes.SESSION_HEADER == "X-API-Session"


# --- Read paths: verbatim IBM-doc string asserts ---------------------------


def test_managed_system_collection_path_matches_ibm_doc() -> None:
    # IBM Power10 ManagedSystem resource: /rest/api/uom/ManagedSystem
    assert routes.MANAGED_SYSTEM_COLLECTION_PATH == "/rest/api/uom/ManagedSystem"


def test_managed_system_path_matches_ibm_doc() -> None:
    # IBM Power10 ManagedSystem resource: /rest/api/uom/ManagedSystem/{uuid}
    assert routes.managed_system_path(_SYS_UUID) == f"/rest/api/uom/ManagedSystem/{_SYS_UUID}"


def test_logical_partition_collection_path_matches_ibm_doc() -> None:
    # IBM Power11 LogicalPartition resource:
    # /rest/api/uom/ManagedSystem/{ManagedSystem_uuid}/LogicalPartition
    assert (
        routes.logical_partition_collection_path(_SYS_UUID)
        == f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition"
    )


def test_logical_partition_path_matches_ibm_doc() -> None:
    # IBM Power11 LogicalPartition resource (nested instance form):
    # /rest/api/uom/ManagedSystem/{ManagedSystem_uuid}/LogicalPartition/{LogicalPartition_uuid}
    assert (
        routes.logical_partition_path(_SYS_UUID, _LPAR_UUID)
        == f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition/{_LPAR_UUID}"
    )


def test_logical_partition_path_joins_segments() -> None:
    """Preserved from earlier tests — shape check with synthetic ids."""
    assert (
        routes.logical_partition_path("sys-a", "lp-b")
        == "/rest/api/uom/ManagedSystem/sys-a/LogicalPartition/lp-b"
    )


def test_logical_partition_quick_property_path_matches_ibm_doc() -> None:
    # IBM root-instance URL grammar:
    # /rest/api/uom/LogicalPartition/{LogicalPartition_uuid}/quick/{Property name}
    assert (
        routes.logical_partition_quick_property_path(_LPAR_UUID, "PartitionState")
        == f"/rest/api/uom/LogicalPartition/{_LPAR_UUID}/quick/PartitionState"
    )


def test_logical_partition_profiles_path_matches_ibm_doc() -> None:
    # IBM Power10 LogicalPartitionProfile (standalone form):
    # /rest/api/uom/LogicalPartition/{LogicalPartition_uuid}/LogicalPartitionProfile
    assert (
        routes.logical_partition_profiles_path(_LPAR_UUID)
        == f"/rest/api/uom/LogicalPartition/{_LPAR_UUID}/LogicalPartitionProfile"
    )


def test_pcm_processed_metrics_path_matches_ibm_doc() -> None:
    # IBM PCM ProcessedMetrics Atom feed:
    # /rest/api/pcm/ManagedSystem/{uuid}/ProcessedMetrics
    assert (
        routes.pcm_processed_metrics_path(_SYS_UUID)
        == f"/rest/api/pcm/ManagedSystem/{_SYS_UUID}/ProcessedMetrics"
    )


def test_pcm_processed_metrics_path_short_id() -> None:
    """Preserved from earlier tests — shape check with synthetic id."""
    assert (
        routes.pcm_processed_metrics_path("abc")
        == "/rest/api/pcm/ManagedSystem/abc/ProcessedMetrics"
    )


# --- Composite quick endpoint: [PLACEHOLDER] -------------------------------


def test_logical_partition_composite_quick_path_is_placeholder_shape() -> None:
    """Composite ``.../quick`` (no property name) is firmware-dependent.

    Shape assertion only — IBM URL grammar does not document an
    instance-level "all quick properties" endpoint at this URL; see
    ``docs/hmc-compatibility.md`` 'LPAR Composite Quick Endpoint'.
    """
    path = routes.logical_partition_composite_quick_path(_LPAR_UUID)
    assert path.startswith(f"/rest/api/uom/LogicalPartition/{_LPAR_UUID}")
    assert path.endswith("/quick")


# --- Write paths: SHAPE-ONLY asserts ([PLACEHOLDER]) -----------------------
#
# These builders are contract placeholders.  We deliberately do NOT assert
# the specific {OP} name — it is firmware-pending (see
# docs/hmc-compatibility.md 'Write Operation Paths' and TODO.md Phase C).
# Asserting shape only lets Phase C revise {OP} names from lab capture
# without churning these tests.


def test_logical_partition_start_job_path_shape() -> None:
    path = routes.logical_partition_start_job_path(_SYS_UUID, _LPAR_UUID)
    assert path.startswith(
        f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition/{_LPAR_UUID}/do/"
    )
    op = path.rsplit("/do/", 1)[-1]
    assert op and "/" not in op


def test_logical_partition_stop_job_path_shape() -> None:
    path = routes.logical_partition_stop_job_path(_SYS_UUID, _LPAR_UUID)
    assert path.startswith(
        f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition/{_LPAR_UUID}/do/"
    )
    op = path.rsplit("/do/", 1)[-1]
    assert op and "/" not in op


def test_logical_partition_create_from_profile_path_shape() -> None:
    path = routes.logical_partition_create_from_profile_path(_SYS_UUID)
    assert path.startswith(f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition/do/")
    op = path.rsplit("/do/", 1)[-1]
    assert op and "/" not in op


def test_write_paths_share_same_managed_system_root() -> None:
    """All three write builders anchor below ``/rest/api/uom/ManagedSystem/``."""
    start = routes.logical_partition_start_job_path(_SYS_UUID, _LPAR_UUID)
    stop = routes.logical_partition_stop_job_path(_SYS_UUID, _LPAR_UUID)
    create = routes.logical_partition_create_from_profile_path(_SYS_UUID)
    for path in (start, stop, create):
        assert path.startswith(f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/")


def test_logical_partition_jobs_path_shape() -> None:
    path = routes.logical_partition_jobs_path(_SYS_UUID, _LPAR_UUID)
    assert path == (f"/rest/api/uom/ManagedSystem/{_SYS_UUID}/LogicalPartition/{_LPAR_UUID}/jobs")


def test_logical_partition_job_status_path_shape() -> None:
    job_id = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    path = routes.logical_partition_job_status_path(_SYS_UUID, _LPAR_UUID, job_id)
    assert path.endswith(f"/jobs/{job_id}")
    assert _LPAR_UUID in path


_READ_PATH_BUILDERS = (
    ("managed_system_collection", lambda: routes.MANAGED_SYSTEM_COLLECTION_PATH),
    ("managed_system", lambda: routes.managed_system_path(_SYS_UUID)),
    (
        "logical_partition_collection",
        lambda: routes.logical_partition_collection_path(_SYS_UUID),
    ),
    ("logical_partition", lambda: routes.logical_partition_path(_SYS_UUID, _LPAR_UUID)),
    (
        "logical_partition_quick_property",
        lambda: routes.logical_partition_quick_property_path(_LPAR_UUID, "PartitionState"),
    ),
    (
        "logical_partition_composite_quick",
        lambda: routes.logical_partition_composite_quick_path(_LPAR_UUID),
    ),
    ("logical_partition_profiles", lambda: routes.logical_partition_profiles_path(_LPAR_UUID)),
    ("pcm_processed_metrics", lambda: routes.pcm_processed_metrics_path(_SYS_UUID)),
)

_WRITE_PATH_BUILDERS = (
    (
        "logical_partition_start_job",
        lambda: routes.logical_partition_start_job_path(_SYS_UUID, _LPAR_UUID),
    ),
    (
        "logical_partition_stop_job",
        lambda: routes.logical_partition_stop_job_path(_SYS_UUID, _LPAR_UUID),
    ),
    (
        "logical_partition_create_from_profile",
        lambda: routes.logical_partition_create_from_profile_path(_SYS_UUID),
    ),
    ("logical_partition_jobs", lambda: routes.logical_partition_jobs_path(_SYS_UUID, _LPAR_UUID)),
    (
        "logical_partition_job_status",
        lambda: routes.logical_partition_job_status_path(
            _SYS_UUID,
            _LPAR_UUID,
            "job-123",
        ),
    ),
)


@pytest.mark.parametrize("name,builder", _READ_PATH_BUILDERS + _WRITE_PATH_BUILDERS)
def test_all_route_builders_start_with_rest_api_prefix(name: str, builder) -> None:
    path = builder()
    assert isinstance(path, str)
    assert path.startswith("/rest/api/")


def test_uuid_with_dashes_preserved_in_paths() -> None:
    sys_id = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
    lpar_id = "11111111-2222-3333-4444-555566667777"
    path = routes.logical_partition_path(sys_id, lpar_id)
    assert sys_id in path
    assert lpar_id in path


def test_managed_system_name_with_hyphen_preserved() -> None:
    path = routes.logical_partition_collection_path("sys-name-with-hyphens")
    assert "sys-name-with-hyphens" in path
