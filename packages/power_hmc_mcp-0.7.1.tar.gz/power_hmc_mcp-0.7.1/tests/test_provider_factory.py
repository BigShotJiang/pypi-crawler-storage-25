"""Tests for provider factory dispatch and protocol conformance."""

from __future__ import annotations

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.demo_provider import DemoProvider
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.powervs_provider import PowerVSProvider
from power_hmc_mcp.provider import HmcProvider
from power_hmc_mcp.provider_factory import create_provider
from tests.conftest import apply_hmc_env


@pytest.fixture
def settings_hmc(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEMO_MODE", "false")
    monkeypatch.setenv("HMC_PROVIDER", "hmc")
    return Settings()


@pytest.fixture
def settings_demo(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEMO_MODE", "false")
    monkeypatch.setenv("HMC_PROVIDER", "demo")
    return Settings()


@pytest.fixture
def settings_demo_mode_compat(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_PROVIDER", "hmc")
    return Settings()


@pytest.fixture
def settings_powervs(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROVIDER", "powervs")
    return Settings()


def test_hmc_provider_returns_hmc_client(settings_hmc: Settings) -> None:
    provider = create_provider(settings_hmc)
    assert isinstance(provider, HmcClient)


def test_demo_provider_returns_demo_provider(settings_demo: Settings) -> None:
    provider = create_provider(settings_demo)
    assert isinstance(provider, DemoProvider)


def test_demo_mode_true_with_hmc_provider_returns_demo(
    settings_demo_mode_compat: Settings,
) -> None:
    provider = create_provider(settings_demo_mode_compat)
    assert isinstance(provider, DemoProvider)


def test_powervs_provider_returns_powervs_provider(settings_powervs: Settings) -> None:
    provider = create_provider(settings_powervs)
    assert isinstance(provider, PowerVSProvider)


def test_unknown_provider_raises_value_error(settings_hmc: Settings) -> None:
    settings_hmc.hmc_provider = "invalid"  # type: ignore[misc]
    with pytest.raises(ValueError, match="Unknown HMC_PROVIDER"):
        create_provider(settings_hmc)


def test_hmc_client_satisfies_protocol(settings_hmc: Settings) -> None:
    assert isinstance(create_provider(settings_hmc), HmcProvider)


def test_demo_provider_satisfies_protocol(settings_demo: Settings) -> None:
    assert isinstance(create_provider(settings_demo), HmcProvider)


def test_powervs_provider_satisfies_protocol(settings_powervs: Settings) -> None:
    assert isinstance(create_provider(settings_powervs), HmcProvider)
