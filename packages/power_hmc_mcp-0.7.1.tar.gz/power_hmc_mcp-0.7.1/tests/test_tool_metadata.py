"""Tests MCP tool registration metadata (Phase F agent ergonomics)."""

from __future__ import annotations

import pytest
from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.tools import (
    READONLY_TOOL_NAMES,
    WRITE_TOOL_NAMES,
    register_readonly_tools,
    register_tools,
)
from power_hmc_mcp.tools.annotations import READ_ONLY
from tests.conftest import apply_hmc_env


@pytest.fixture
def readonly_mcp(hmc_settings) -> FastMCP:
    mcp = FastMCP("test-metadata", json_response=True)
    client = HmcClient(hmc_settings)
    register_readonly_tools(mcp, client)
    return mcp


@pytest.fixture
def full_mcp(monkeypatch: pytest.MonkeyPatch) -> FastMCP:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    settings = Settings()
    mcp = FastMCP("test-metadata-writes", json_response=True)
    client = HmcClient(settings)
    register_tools(mcp, client)
    return mcp


@pytest.mark.parametrize("tool_name", sorted(READONLY_TOOL_NAMES))
def test_read_tool_description_has_agent_sections(
    readonly_mcp: FastMCP,
    tool_name: str,
) -> None:
    tool = readonly_mcp._tool_manager._tools[tool_name]
    doc = tool.fn.__doc__ or ""
    assert "Use when" in doc, f"{tool_name} missing 'Use when' section"
    assert "Do not use when" in doc, f"{tool_name} missing 'Do not use when' section"
    assert "Does not" in doc, f"{tool_name} missing 'Does not' section"


@pytest.mark.parametrize("tool_name", sorted(READONLY_TOOL_NAMES))
def test_read_tool_has_read_only_annotations(readonly_mcp: FastMCP, tool_name: str) -> None:
    tool = readonly_mcp._tool_manager._tools[tool_name]
    annotations = tool.annotations
    assert annotations is not None
    assert annotations.readOnlyHint is READ_ONLY.readOnlyHint
    assert annotations.destructiveHint is READ_ONLY.destructiveHint


@pytest.mark.parametrize("tool_name", sorted(WRITE_TOOL_NAMES))
def test_write_tool_description_has_agent_sections(full_mcp: FastMCP, tool_name: str) -> None:
    tool = full_mcp._tool_manager._tools[tool_name]
    doc = tool.fn.__doc__ or ""
    assert "Use when" in doc, f"{tool_name} missing 'Use when' section"
    assert "Do not use when" in doc, f"{tool_name} missing 'Do not use when' section"
    assert "Does not" in doc, f"{tool_name} missing 'Does not' section"


@pytest.mark.parametrize("tool_name", sorted(WRITE_TOOL_NAMES))
def test_write_tool_destructive_hint(full_mcp: FastMCP, tool_name: str) -> None:
    tool = full_mcp._tool_manager._tools[tool_name]
    annotations = tool.annotations
    assert annotations is not None
    assert annotations.destructiveHint is True
    assert annotations.readOnlyHint is False


def test_list_lpars_schema_has_param_descriptions(readonly_mcp: FastMCP) -> None:
    tool = readonly_mcp._tool_manager._tools["list_lpars"]
    schema = tool.parameters
    props = schema.get("properties", {})
    assert props["managed_system_id"].get("description")
    assert props["limit"].get("description")
    assert props["offset"].get("description")
