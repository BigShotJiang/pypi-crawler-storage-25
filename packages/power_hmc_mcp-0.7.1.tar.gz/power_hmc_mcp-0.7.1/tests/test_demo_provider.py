"""Tests for DemoProvider fixture-backed backend."""

from __future__ import annotations

import logging
from pathlib import Path

import pytest

from power_hmc_mcp.demo_provider import DemoProvider, load_demo_fixture
from power_hmc_mcp.guardrails import _issue_authorization
from tests.conftest import LPAR_ID, SYSTEM_ID


class TestDemoProvider:
    """Demo provider: read tools return fixtures, write tools return demo envelope, no HTTP."""

    def test_list_managed_systems_returns_fixture(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.list_managed_systems()
        assert isinstance(result, list)
        assert len(result) > 0
        assert "id" in result[0]
        assert "name" in result[0]

    def test_get_managed_system_returns_fixture(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.get_managed_system(SYSTEM_ID)
        assert isinstance(result, dict)
        assert "id" in result
        assert "properties" in result

    def test_list_lpars_returns_fixture(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.list_lpars(SYSTEM_ID)
        assert isinstance(result, list)
        assert len(result) > 0

    def test_get_lpar_status_returns_fixture(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.get_lpar_status(SYSTEM_ID, LPAR_ID)
        assert isinstance(result, dict)
        assert result["source"] == "uom"

    def test_get_capacity_returns_fixture(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.get_capacity(SYSTEM_ID)
        assert isinstance(result, dict)
        assert "samples" in result or "summary" in result or "placeholder" in result

    def test_health_check_returns_synthetic(self, demo_provider: DemoProvider) -> None:
        result = demo_provider.health_check()
        assert result["status"] == "ok"
        assert result["session_active"] is False
        assert result["hmc_host"] == "demo-hmc.test"

    def test_login_is_noop(self, demo_provider: DemoProvider) -> None:
        demo_provider.login()

    def test_close_is_noop(self, demo_provider: DemoProvider) -> None:
        demo_provider.login()
        demo_provider.close()

    def test_is_authenticated_always_false(self, demo_provider: DemoProvider) -> None:
        demo_provider.login()
        assert demo_provider.is_authenticated() is False

    def test_write_tool_returns_demo_envelope(self, demo_provider: DemoProvider) -> None:
        auth = _issue_authorization(operation="start_lpar", correlation_id="test-cid-demo")
        result = demo_provider.start_lpar(SYSTEM_ID, LPAR_ID, authorization=auth)
        assert result["executed"] is False
        assert result["demo"] is True
        assert result["operation"] == "start_lpar"
        assert "suggested_next_step" in result
        assert result["suggested_next_step"]

    def test_login_emits_demo_logon_event(
        self,
        demo_provider: DemoProvider,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
            demo_provider.login()
        assert any("session_logon_end" in r.getMessage() for r in caplog.records)
        assert any("demo" in r.getMessage() for r in caplog.records)


def test_load_demo_fixture_missing_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="Demo fixture not found"):
        load_demo_fixture("nonexistent_tool", fixtures_dir=tmp_path)
