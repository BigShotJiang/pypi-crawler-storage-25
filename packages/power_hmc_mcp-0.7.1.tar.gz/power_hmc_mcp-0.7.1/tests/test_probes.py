"""HTTP probe tests for D3.

Exercises the probe handlers end-to-end via Starlette's TestClient
against the same Starlette app FastMCP builds for the streamable-HTTP
transport. Uses ``streamable_http_app`` because that is the ASGI app
``mcp.run(transport='streamable-http')`` would launch — anything that
works there is what real ingress traffic will see.

Coverage targets:
* probes are no-op when ``HMC_MCP_HTTP_PROBES_PATH`` is unset
* ``/healthz`` returns 200 unconditionally
* ``/readyz`` returns 200 in demo mode (regardless of session state)
* ``/readyz`` returns 200 when authenticated, 503 when not
* probe traffic does NOT emit ``mcp_tool_call`` / ``write_audit`` events
* path collision with ``HMC_MCP_HTTP_PATH`` is rejected at config load
* prefix mode mounts under ``<prefix>/healthz`` / ``<prefix>/readyz``
"""

from __future__ import annotations

import logging

import pytest
from mcp.server.fastmcp import FastMCP
from starlette.testclient import TestClient

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.probes import register_probes
from tests.conftest import apply_hmc_env


def _demo_settings(monkeypatch: pytest.MonkeyPatch, *, probes_path: str = "/") -> Settings:
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    monkeypatch.setenv("HMC_HOST", "demo-hmc.test")
    monkeypatch.setenv("HMC_USERNAME", "demo-user")
    monkeypatch.setenv("HMC_PASSWORD", "demo-password")
    monkeypatch.setenv("HMC_MCP_TRANSPORT", "streamable-http")
    monkeypatch.setenv("HMC_MCP_HTTP_PROBES_PATH", probes_path)
    return Settings()


def _client_for(mcp: FastMCP) -> TestClient:
    """Return a Starlette TestClient for the FastMCP streamable-HTTP ASGI app."""
    return TestClient(mcp.streamable_http_app())


# --- registration gating ----------------------------------------------------


def test_probes_not_registered_when_env_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)  # leaves HMC_MCP_HTTP_PROBES_PATH unset
    settings = Settings()
    assert settings.hmc_mcp_http_probes_path == ""

    mcp = FastMCP("test-no-probes")
    client = HmcClient(settings)
    out = register_probes(mcp, client, settings)
    assert out is None
    with _client_for(mcp) as http:
        # No /healthz route was registered — Starlette returns 404.
        assert http.get("/healthz").status_code == 404


def test_probes_registered_at_root_in_demo_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _demo_settings(monkeypatch, probes_path="/")
    mcp = FastMCP("test-probes-root")
    client = HmcClient(settings)
    out = register_probes(mcp, client, settings)
    assert out == ("/healthz", "/readyz")

    with _client_for(mcp) as http:
        healthz = http.get("/healthz")
        assert healthz.status_code == 200
        assert healthz.json() == {"status": "ok"}

        readyz = http.get("/readyz")
        assert readyz.status_code == 200
        body = readyz.json()
        assert body["status"] == "ready"
        assert body["mode"] == "demo"


def test_probes_registered_under_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = _demo_settings(monkeypatch, probes_path="/admin")
    mcp = FastMCP("test-probes-admin")
    client = HmcClient(settings)
    out = register_probes(mcp, client, settings)
    assert out == ("/admin/healthz", "/admin/readyz")

    with _client_for(mcp) as http:
        assert http.get("/admin/healthz").status_code == 200
        assert http.get("/admin/readyz").status_code == 200
        # Bare /healthz is NOT mounted in prefix mode.
        assert http.get("/healthz").status_code == 404


# --- readyz semantics -------------------------------------------------------


def test_readyz_503_when_not_authenticated(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MCP_HTTP_PROBES_PATH", "/")
    settings = Settings()
    assert settings.hmc_demo_mode is False

    mcp = FastMCP("test-readyz-503")
    client = HmcClient(settings)
    register_probes(mcp, client, settings)

    with _client_for(mcp) as http:
        readyz = http.get("/readyz")
        assert readyz.status_code == 503
        body = readyz.json()
        assert body["status"] == "not-ready"
        assert body["reason"] == "no-active-hmc-session"


def test_readyz_200_when_authenticated(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MCP_HTTP_PROBES_PATH", "/")
    settings = Settings()

    class _StubClient:
        def is_authenticated(self) -> bool:
            return True

    mcp = FastMCP("test-readyz-200")
    register_probes(mcp, _StubClient(), settings)  # type: ignore[arg-type]

    with _client_for(mcp) as http:
        readyz = http.get("/readyz")
        assert readyz.status_code == 200
        assert readyz.json()["status"] == "ready"


# --- audit-log silence ------------------------------------------------------


def test_probes_emit_no_tool_call_or_audit_events(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    settings = _demo_settings(monkeypatch, probes_path="/")
    mcp = FastMCP("test-probes-quiet")
    client = HmcClient(settings)
    register_probes(mcp, client, settings)

    with (
        _client_for(mcp) as http,
        caplog.at_level(logging.DEBUG, logger="power_hmc_mcp.observability"),
    ):
        for _ in range(3):
            http.get("/healthz")
            http.get("/readyz")

    forbidden_events = ("mcp_tool_call", "write_audit", "session_reauth")
    for record in caplog.records:
        msg = record.getMessage()
        for forbidden in forbidden_events:
            assert forbidden not in msg, (
                f"probe traffic must not emit {forbidden!r} events; found in {record.name}: {msg}"
            )


# --- collision rejection ----------------------------------------------------


def test_probes_path_collision_with_mcp_path_is_rejected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MCP_HTTP_PATH", "/healthz")
    monkeypatch.setenv("HMC_MCP_HTTP_PROBES_PATH", "/")
    with pytest.raises(ValueError, match="collides with HMC_MCP_HTTP_PATH"):
        Settings()


def test_probes_path_must_start_with_slash(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MCP_HTTP_PROBES_PATH", "admin")
    with pytest.raises(ValueError, match=r"start with '/'"):
        Settings()
