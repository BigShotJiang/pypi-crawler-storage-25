"""Tests for agent-facing list response envelopes."""

from __future__ import annotations

import json
from typing import Any

import pytest

from power_hmc_mcp.agent_output import wrap_list_response
from power_hmc_mcp.exceptions import HmcValidationError


def _make_items(n: int) -> list[dict[str, Any]]:
    return [{"id": f"id-{i}", "name": f"name-{i}", "state": "running"} for i in range(n)]


class TestWrapListResponse:
    def test_full_list_not_truncated(self) -> None:
        items = _make_items(3)
        out = wrap_list_response(items)
        assert out["items"] == items
        summary = out["summary"]
        assert summary["total_count"] == 3
        assert summary["returned_count"] == 3
        assert summary["offset"] == 0
        assert summary["truncated"] is False
        assert "next_offset" not in summary

    def test_limit_truncates_with_next_offset(self) -> None:
        items = _make_items(5)
        out = wrap_list_response(items, limit=2)
        assert len(out["items"]) == 2
        assert out["items"][0]["id"] == "id-0"
        summary = out["summary"]
        assert summary["truncated"] is True
        assert summary["next_offset"] == 2
        assert summary["returned_count"] == 2

    def test_offset_pagination(self) -> None:
        items = _make_items(4)
        out = wrap_list_response(items, limit=2, offset=2)
        assert [i["id"] for i in out["items"]] == ["id-2", "id-3"]
        summary = out["summary"]
        assert summary["offset"] == 2
        assert summary["truncated"] is False
        assert "next_offset" not in summary

    def test_empty_list(self) -> None:
        out = wrap_list_response([])
        assert out["items"] == []
        assert out["summary"]["total_count"] == 0
        assert out["summary"]["truncated"] is False

    def test_offset_beyond_total_returns_empty_page(self) -> None:
        out = wrap_list_response(_make_items(2), limit=5, offset=10)
        assert out["items"] == []
        assert out["summary"]["returned_count"] == 0
        assert out["summary"]["truncated"] is False

    def test_preserves_order(self) -> None:
        items = [{"id": "b"}, {"id": "a"}, {"id": "c"}]
        out = wrap_list_response(items, limit=2)
        assert [i["id"] for i in out["items"]] == ["b", "a"]

    def test_state_counts_when_requested(self) -> None:
        items = [
            {"id": "1", "state": "running"},
            {"id": "2", "state": "running"},
            {"id": "3", "state": "standby"},
        ]
        out = wrap_list_response(items, state_counts=True)
        assert out["summary"]["state_counts"] == {"running": 2, "standby": 1}

    def test_invalid_offset_raises(self) -> None:
        with pytest.raises(HmcValidationError, match="offset"):
            wrap_list_response([], offset=-1)

    def test_invalid_limit_raises(self) -> None:
        with pytest.raises(HmcValidationError, match="limit"):
            wrap_list_response([], limit=0)

    def test_json_serializable(self) -> None:
        out = wrap_list_response(_make_items(2), limit=1, state_counts=True)
        json.dumps(out)
