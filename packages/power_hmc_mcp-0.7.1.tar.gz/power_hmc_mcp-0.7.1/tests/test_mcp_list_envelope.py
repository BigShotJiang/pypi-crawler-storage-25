"""MCP list-tool envelope contract tests (Phase F)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest
from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.tools import register_readonly_tools
from tests.conftest import LPAR_ID, SYSTEM_ID
from tests.test_contracts import (
    _assert_keys_and_types,
    _assert_list_item_shape,
    _assert_no_extra_keys,
)

FIXTURES = Path(__file__).parent / "fixtures" / "mcp"


def _load(name: str) -> Any:
    return json.loads((FIXTURES / f"{name}.json").read_text(encoding="utf-8"))


@pytest.fixture
def readonly_mcp(hmc_client: HmcClient) -> FastMCP:
    mcp = FastMCP("test-envelope", json_response=True)
    register_readonly_tools(mcp, hmc_client)
    return mcp


class TestListManagedSystemsEnvelope:
    def test_matches_golden_fixture(self, readonly_mcp: FastMCP) -> None:
        fn = readonly_mcp._tool_manager._tools["list_managed_systems"].fn
        result = fn()
        fixture = _load("list_managed_systems_envelope")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)
        _assert_list_item_shape(result["items"], fixture["items"][0])

    def test_limit_truncates(self, readonly_mcp: FastMCP) -> None:
        fn = readonly_mcp._tool_manager._tools["list_managed_systems"].fn
        result = fn(limit=1)
        assert result["summary"]["truncated"] is True
        assert result["summary"]["next_offset"] == 1
        assert len(result["items"]) == 1


class TestListLparsEnvelope:
    def test_matches_golden_fixture(self, readonly_mcp: FastMCP) -> None:
        fn = readonly_mcp._tool_manager._tools["list_lpars"].fn
        result = fn(managed_system_id=SYSTEM_ID)
        fixture = _load("list_lpars_envelope")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)
        _assert_list_item_shape(result["items"], fixture["items"][0])


class TestListPartitionProfilesEnvelope:
    def test_matches_golden_fixture(self, readonly_mcp: FastMCP) -> None:
        fn = readonly_mcp._tool_manager._tools["list_partition_profiles"].fn
        result = fn(lpar_id=LPAR_ID)
        fixture = _load("list_partition_profiles_envelope")

        assert isinstance(result, dict)
        _assert_keys_and_types(result, fixture)
        _assert_no_extra_keys(result, fixture)
        _assert_list_item_shape(result["items"], fixture["items"][0])
