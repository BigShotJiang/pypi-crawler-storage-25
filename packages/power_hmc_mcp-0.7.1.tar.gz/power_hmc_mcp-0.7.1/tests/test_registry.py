"""Tests for the multi-HMC registry parser (D5)."""

from __future__ import annotations

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.registry import (
    HmcEndpoint,
    HmcRegistry,
    build_registry,
    parse_registry_env,
)
from tests.conftest import apply_hmc_env


def _settings(monkeypatch: pytest.MonkeyPatch, **extra: str) -> Settings:
    apply_hmc_env(monkeypatch)
    for k, v in extra.items():
        monkeypatch.setenv(k, v)
    return Settings()


# --- parse_registry_env ----------------------------------------------------


def test_parse_registry_env_empty_string_yields_no_entries(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(monkeypatch)
    assert parse_registry_env(None, base=base) == []
    assert parse_registry_env("", base=base) == []
    assert parse_registry_env("   ", base=base) == []


def test_parse_registry_env_invalid_json_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch)
    with pytest.raises(ValueError, match="not valid JSON"):
        parse_registry_env("[not json", base=base)


def test_parse_registry_env_must_be_list(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch)
    with pytest.raises(ValueError, match="JSON list"):
        parse_registry_env('{"alias": "x"}', base=base)


def test_parse_registry_env_rejects_missing_required_keys(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(monkeypatch)
    with pytest.raises(ValueError, match="missing required keys"):
        parse_registry_env(
            '[{"alias": "prod-east", "host": "h"}]',
            base=base,
        )


def test_parse_registry_env_rejects_bad_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch)
    with pytest.raises(ValueError, match="\\[a-z0-9_-\\]"):
        parse_registry_env(
            '[{"alias": "bad alias!", "host": "h", "username": "u", "password": "p"}]',
            base=base,
        )


def test_parse_registry_env_normalises_alias_lowercase(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(monkeypatch)
    out = parse_registry_env(
        '[{"alias": "PROD-EAST", "host": "h", "username": "u", "password": "p"}]',
        base=base,
    )
    assert out[0].alias == "prod-east"


def test_parse_registry_env_inherits_base_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch, HMC_PORT="9999", HMC_VERIFY_TLS="false")
    out = parse_registry_env(
        '[{"alias": "prod-east", "host": "h", "username": "u", "password": "p"}]',
        base=base,
    )
    assert out[0].port == 9999
    assert out[0].verify_tls is False


def test_parse_registry_env_per_entry_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch, HMC_PORT="12443")
    out = parse_registry_env(
        '[{"alias": "prod-east", "host": "h", "username": "u", "password": "p", '
        '"port": 8443, "verify_tls": false, "timeout_seconds": 7.5}]',
        base=base,
    )
    assert out[0].port == 8443
    assert out[0].verify_tls is False
    assert out[0].timeout_seconds == 7.5


# --- build_registry --------------------------------------------------------


def test_build_registry_default_alias_only_when_no_HMC_REGISTRY(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(monkeypatch)
    reg = build_registry(base)
    assert reg.aliases() == ("default",)
    assert reg.default_alias == "default"
    assert "default" in reg


def test_build_registry_appends_HMC_REGISTRY_aliases(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(
        monkeypatch,
        HMC_REGISTRY=(
            '[{"alias": "prod-east", "host": "east", "username": "u", "password": "p"},'
            ' {"alias": "prod-west", "host": "west", "username": "u", "password": "p"}]'
        ),
    )
    reg = build_registry(base)
    assert reg.aliases() == ("default", "prod-east", "prod-west")
    east = reg["prod-east"]
    assert east.host == "east"


def test_build_registry_rejects_default_alias_collision(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(
        monkeypatch,
        HMC_REGISTRY=('[{"alias": "default", "host": "x", "username": "u", "password": "p"}]'),
    )
    with pytest.raises(ValueError, match="collides with HMC_DEFAULT_ALIAS"):
        build_registry(base)


def test_build_registry_rejects_duplicate_aliases(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(
        monkeypatch,
        HMC_REGISTRY=(
            '[{"alias": "prod-east", "host": "a", "username": "u", "password": "p"},'
            ' {"alias": "prod-east", "host": "b", "username": "u", "password": "p"}]'
        ),
    )
    with pytest.raises(ValueError, match="duplicate HMC alias"):
        build_registry(base)


def test_build_registry_default_alias_overridable(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch, HMC_DEFAULT_ALIAS="primary")
    reg = build_registry(base)
    assert reg.default_alias == "primary"
    assert reg.aliases() == ("primary",)


def test_settings_for_returns_alias_specific_settings(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(
        monkeypatch,
        HMC_REGISTRY=(
            '[{"alias": "prod-east", "host": "east-host", "username": "east-u", '
            '"password": "east-p", "port": 8443}]'
        ),
    )
    reg = build_registry(base)
    east_settings = reg.settings_for("prod-east")
    assert east_settings.hmc_host == "east-host"
    assert east_settings.hmc_username == "east-u"
    assert east_settings.hmc_port == 8443
    assert east_settings.hmc_password.get_secret_value() == "east-p"
    # Process-wide policy carries through unchanged.
    assert east_settings.hmc_enable_write_tools == base.hmc_enable_write_tools


def test_settings_for_unknown_alias_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch)
    reg = build_registry(base)
    with pytest.raises(KeyError, match="unknown HMC alias"):
        reg["does-not-exist"]


def test_default_alias_settings_for_returns_base(monkeypatch: pytest.MonkeyPatch) -> None:
    base = _settings(monkeypatch)
    reg = build_registry(base)
    out = reg.settings_for(reg.default_alias)
    assert out is base  # same object — no need to clone for the default


def test_hmc_default_alias_validator_normalises_case(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEFAULT_ALIAS", "PRIMARY")
    settings = Settings()
    assert settings.hmc_default_alias == "primary"


def test_hmc_default_alias_validator_rejects_bad_chars(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEFAULT_ALIAS", "bad alias")
    with pytest.raises(ValueError, match="\\[a-z0-9_-\\]"):
        Settings()


def test_hmc_endpoint_dataclass_is_frozen() -> None:
    ep = HmcEndpoint(
        alias="x",
        host="h",
        port=12443,
        username="u",
        password=None,  # type: ignore[arg-type]
        verify_tls=True,
        timeout_seconds=30.0,
    )
    with pytest.raises(AttributeError):  # frozen dataclass
        ep.alias = "y"  # type: ignore[misc]


def test_hmc_registry_construction_rejects_missing_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    base = _settings(monkeypatch)
    with pytest.raises(ValueError, match="not declared in the registry"):
        HmcRegistry(base, [])
