"""Tests for HmcAsyncSession (mirror tests/test_session.py for the async pair).

Coverage: login, retry on 503, 401 re-auth success+failure (both emit
session_reauth), demo mode does NOT emit session_reauth, outbound
correlation header propagation, echo-header capture.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

from power_hmc_mcp import observability
from power_hmc_mcp.config import Settings
from power_hmc_mcp.exceptions import HmcAuthError
from power_hmc_mcp.http_policy import RequestClassification
from power_hmc_mcp.routes import LOGON_PATH, MANAGED_SYSTEMS_PATH, SESSION_HEADER
from power_hmc_mcp.session_async import HmcAsyncSession
from tests.conftest import apply_hmc_env

FIXTURES = Path(__file__).parent / "fixtures"
MANAGED_SYSTEMS_XML = (FIXTURES / "managed_systems_feed.xml").read_text(encoding="utf-8")

pytestmark = pytest.mark.asyncio


def _logon_then_managed_systems_handler(
    *,
    response_headers: dict[str, str] | None = None,
) -> Callable[[httpx.Request], httpx.Response]:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "test-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and request.url.path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(
                200,
                text=MANAGED_SYSTEMS_XML,
                headers=response_headers or {},
            )
        return httpx.Response(404)

    return handler


def _async_session_with_transport(
    settings: Settings,
    handler: Callable[[httpx.Request], httpx.Response],
) -> HmcAsyncSession:
    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    return HmcAsyncSession(settings, http_client=http)


# --- login / close lifecycle -----------------------------------------------


async def test_login_sets_session_token(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "async-token-abc"},
                text="<LogonResponse/>",
            )
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    assert session._session_token == "async-token-abc"
    await session.close()


async def test_login_raises_on_400(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(400)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    with pytest.raises(HmcAuthError):
        await session.login()
    await session.close()


async def test_login_raises_when_no_token_header(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(200, text="<LogonResponse/>")
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    with pytest.raises(HmcAuthError):
        await session.login()
    await session.close()


async def test_close_clears_session_token(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(200)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    await session.close()
    assert session._session_token is None


# --- retry / 401 re-auth ---------------------------------------------------


@dataclass
class _ReauthState:
    logon_count: int = 0
    managed_system_get_count: int = 0


@patch(
    "power_hmc_mcp.hmc_client_async.retry_sleep_async",
    new=lambda *_a, **_kw: _NOOP_AWAITABLE(),
)
async def test_request_retries_on_503(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    count = {"managed_system": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            count["managed_system"] += 1
            if count["managed_system"] == 1:
                return httpx.Response(503)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    response = await session.request(
        "GET",
        MANAGED_SYSTEMS_PATH,
        classification=RequestClassification.READ,
    )
    assert response.status_code == 200
    await session.close()


def _NOOP_AWAITABLE() -> object:
    """Return an awaitable that resolves to None — used to neutralize sleep."""

    class _Awaitable:
        def __await__(self):  # type: ignore[no-untyped-def]
            yield from iter(())
            return None

    return _Awaitable()


@patch(
    "power_hmc_mcp.hmc_client_async.retry_sleep_async",
    new=lambda *_a, **_kw: _NOOP_AWAITABLE(),
)
async def test_request_reauth_on_401(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    state = _ReauthState()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            state.logon_count += 1
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "re-authed-token"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            state.managed_system_get_count += 1
            if state.managed_system_get_count == 1:
                return httpx.Response(401)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        response = await session.request(
            "GET",
            MANAGED_SYSTEMS_PATH,
            classification=RequestClassification.READ,
        )
    assert response.status_code == 200
    assert state.logon_count >= 2

    reauth_records = [r for r in caplog.records if "session_reauth" in r.getMessage()]
    success_records = [r for r in reauth_records if "success" in r.getMessage()]
    assert len(success_records) == 1
    await session.close()


async def test_max_reauth_attempts_zero_raises_immediately(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_REAUTH_ATTEMPTS", "0")
    settings = Settings()
    assert settings.hmc_max_reauth_attempts == 0

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(401)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        with pytest.raises(HmcAuthError):
            await session.request("GET", MANAGED_SYSTEMS_PATH)

    failure_records = [
        r
        for r in caplog.records
        if "session_reauth" in r.getMessage() and "failure" in r.getMessage()
    ]
    assert len(failure_records) == 1
    await session.close()


# --- correlation header propagation ----------------------------------------


def _capture_outbound_handler(
    captured: dict[str, str | None],
    headers_to_capture: tuple[str, ...],
) -> Callable[[httpx.Request], httpx.Response]:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and request.url.path.endswith(MANAGED_SYSTEMS_PATH):
            for name in headers_to_capture:
                captured[name] = request.headers.get(name)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    return handler


async def test_outbound_header_default_is_x_transaction_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("X-Transaction-ID", "X-Correlation-ID"),
    )
    session = _async_session_with_transport(settings, handler)
    await session.login()
    with observability.correlation_scope("cid-async-default"):
        await session.request("GET", MANAGED_SYSTEMS_PATH)
    assert captured["X-Transaction-ID"] == "cid-async-default"
    assert captured["X-Correlation-ID"] is None
    await session.close()


async def test_outbound_header_disabled_when_propagation_off(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROPAGATE_CORRELATION_HEADER", "false")
    settings = Settings()
    captured: dict[str, str | None] = {}
    handler = _capture_outbound_handler(
        captured,
        headers_to_capture=("X-Transaction-ID",),
    )
    session = _async_session_with_transport(settings, handler)
    await session.login()
    with observability.correlation_scope("cid-async-off"):
        await session.request("GET", MANAGED_SYSTEMS_PATH)
    assert captured["X-Transaction-ID"] is None
    await session.close()


# --- echo header capture ---------------------------------------------------


async def test_correlation_echo_primary_header_used(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    handler = _logon_then_managed_systems_handler(
        response_headers={"X-Transaction-ID": "tid-async"},
    )
    session = _async_session_with_transport(settings, handler)
    await session.login()
    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        await session.request("GET", MANAGED_SYSTEMS_PATH)
    end_records = [r for r in caplog.records if "hmc_request_end" in r.getMessage()]
    assert end_records
    assert any("tid-async" in r.getMessage() for r in end_records)
    await session.close()


# --- async context manager + transport / http error coverage ---------------


async def test_async_context_manager_logs_in_and_out(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    handler = _logon_then_managed_systems_handler()
    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        base_url=settings.base_url,
        transport=transport,
        verify=settings.httpx_verify(),
        timeout=settings.hmc_timeout_seconds,
    )
    async with HmcAsyncSession(settings, http_client=http) as session:
        assert session._session_token == "test-token"
    assert session._session_token is None


@patch(
    "power_hmc_mcp.hmc_client_async.retry_sleep_async",
    new=lambda *_a, **_kw: _NOOP_AWAITABLE(),
)
async def test_request_transport_error_retried_then_succeeds(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Read-classified transport error retries once and then succeeds."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    state = {"failures": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            if state["failures"] < 1:
                state["failures"] += 1
                raise httpx.ConnectError("simulated", request=request)
            return httpx.Response(200, text=MANAGED_SYSTEMS_XML)
        return httpx.Response(404)

    session = _async_session_with_transport(settings, handler)
    await session.login()
    response = await session.request(
        "GET",
        MANAGED_SYSTEMS_PATH,
        classification=RequestClassification.READ,
    )
    assert response.status_code == 200
    assert state["failures"] == 1
    await session.close()


async def test_request_500_becomes_http_error(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "GET" and path.endswith(MANAGED_SYSTEMS_PATH):
            return httpx.Response(500, text="server boom")
        return httpx.Response(404)

    from power_hmc_mcp.exceptions import HmcHttpError

    session = _async_session_with_transport(settings, handler)
    await session.login()
    with pytest.raises(HmcHttpError):
        await session.request("GET", MANAGED_SYSTEMS_PATH)
    await session.close()


async def test_close_swallows_logoff_failure_but_clears_token(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if request.method == "PUT" and path.endswith(LOGON_PATH):
            return httpx.Response(
                200,
                headers={SESSION_HEADER: "tok"},
                text="<LogonResponse/>",
            )
        if request.method == "DELETE" and path.endswith(LOGON_PATH):
            raise httpx.ConnectError("logoff failed", request=request)
        return httpx.Response(404)

    from power_hmc_mcp.exceptions import HmcHttpError

    session = _async_session_with_transport(settings, handler)
    await session.login()
    with pytest.raises(HmcHttpError):
        await session.close()
    assert session._session_token is None


async def test_login_timeout_raises_http_error(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("timeout", request=request)

    from power_hmc_mcp.exceptions import HmcHttpError

    session = _async_session_with_transport(settings, handler)
    with pytest.raises(HmcHttpError, match="timed out"):
        await session.login()
