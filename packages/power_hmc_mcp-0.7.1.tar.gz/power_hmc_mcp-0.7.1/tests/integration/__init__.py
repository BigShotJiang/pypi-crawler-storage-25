"""Integration tests that exercise out-of-process MCP transports."""
