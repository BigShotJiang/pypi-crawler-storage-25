"""Subprocess smoke test for the stdio MCP loop (LangGraph-shaped client).

Runs against ``HMC_DEMO_MODE=true`` so no live HMC is required.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "mcp"
ENVELOPE_FIXTURE = FIXTURES / "list_managed_systems_envelope.json"


@pytest.fixture
def demo_env(monkeypatch: pytest.MonkeyPatch) -> dict[str, str]:
    env = dict(os.environ)
    env.update(
        {
            "HMC_DEMO_MODE": "true",
            "HMC_HOST": "localhost",
            "HMC_USERNAME": "demo",
            "HMC_PASSWORD": "demo",
            "HMC_VERIFY_TLS": "false",
            "HMC_MCP_TRANSPORT": "stdio",
        },
    )
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    return env


@pytest.mark.asyncio
async def test_langgraph_stdio_list_managed_systems_demo_mode(
    demo_env: dict[str, str],
) -> None:
    expected = json.loads(ENVELOPE_FIXTURE.read_text(encoding="utf-8"))
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "power_hmc_mcp.mcp_server"],
        env=demo_env,
    )

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool("list_managed_systems", {})
            assert not result.isError

            payload_blocks = [
                block.text for block in result.content if getattr(block, "text", None) is not None
            ]
            assert payload_blocks, "expected JSON text content from list_managed_systems"
            body = json.loads(payload_blocks[0])
            assert body["items"] == expected["items"]
            assert body["summary"]["total_count"] == expected["summary"]["total_count"]
            assert body["summary"]["returned_count"] == expected["summary"]["returned_count"]
            assert "Traceback" not in payload_blocks[0]
