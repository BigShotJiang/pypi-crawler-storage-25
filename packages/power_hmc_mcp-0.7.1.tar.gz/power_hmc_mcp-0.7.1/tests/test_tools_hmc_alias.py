"""End-to-end tests for the optional ``hmc_alias`` tool parameter (D5).

Covers the resolver path on every read tool: alias=None reaches the
default client, an explicit registered alias reaches the alias-specific
client, and an unknown alias surfaces ``HmcValidationError`` on the tool
boundary instead of silently routing to default.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import pytest
from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.config import Settings
from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.pool import ClientResolver, HmcClientPool
from power_hmc_mcp.registry import build_registry
from power_hmc_mcp.tools import register_readonly_tools
from tests.conftest import SYSTEM_ID


class _StubClient:
    """Records calls and returns canned data; satisfies the HmcClient surface
    used by the read tools without touching httpx."""

    def __init__(self, alias: str) -> None:
        self.alias = alias
        self.calls: list[str] = []

    @property
    def settings(self) -> Any:
        # Tools only access settings on write tools, which this stub does not register.
        return None  # type: ignore[return-value]

    def list_managed_systems(self) -> list[dict[str, Any]]:
        self.calls.append("list_managed_systems")
        return [
            {
                "id": SYSTEM_ID,
                "name": f"system-on-{self.alias}",
                "uri": "/x",
                "state": "Operating",
            },
        ]

    def list_lpars(self, _system_id: str) -> list[dict[str, Any]]:
        self.calls.append("list_lpars")
        return []

    def get_lpar_status(self, *_a: object, **_kw: object) -> dict[str, Any]:
        self.calls.append("get_lpar_status")
        return {"alias": self.alias}

    def get_lpar(self, *_a: object, **_kw: object) -> dict[str, Any]:
        self.calls.append("get_lpar")
        return {"alias": self.alias}

    def get_managed_system(self, *_a: object, **_kw: object) -> dict[str, Any]:
        self.calls.append("get_managed_system")
        return {"alias": self.alias}

    def list_partition_profiles(self, *_a: object, **_kw: object) -> list[dict[str, Any]]:
        self.calls.append("list_partition_profiles")
        return []

    def get_capacity(self, *_a: object, **_kw: object) -> dict[str, Any]:
        self.calls.append("get_capacity")
        return {"alias": self.alias}

    def health_check(self) -> dict[str, Any]:
        self.calls.append("health_check")
        return {
            "status": "ok",
            "hmc_host": self.alias,
            "session_active": True,
            "managed_system_count": 1,
        }


def _build_resolver(stubs: dict[str, _StubClient]) -> ClientResolver:
    def resolver(alias: str | None) -> HmcClient:
        key = alias.lower() if alias else "default"
        if key not in stubs:
            raise HmcValidationError(
                f"Unknown HMC alias {alias!r}; known aliases: {', '.join(stubs)}",
            )
        return stubs[key]  # type: ignore[return-value]

    return resolver


def _register(mcp: FastMCP, resolver: ClientResolver) -> None:
    from power_hmc_mcp.tools import (
        get_capacity,
        get_lpar,
        get_lpar_status,
        get_managed_system,
        health_check,
        list_lpars,
        list_managed_systems,
        list_partition_profiles,
    )

    list_managed_systems.register(mcp, resolver)
    list_lpars.register(mcp, resolver)
    get_lpar_status.register(mcp, resolver)
    get_managed_system.register(mcp, resolver)
    get_lpar.register(mcp, resolver)
    list_partition_profiles.register(mcp, resolver)
    get_capacity.register(mcp, resolver)
    health_check.register(mcp, resolver)


def _tool_fn(mcp: FastMCP, name: str) -> Callable[..., Any]:
    return mcp._tool_manager._tools[name].fn


def test_alias_none_routes_to_default() -> None:
    stubs = {"default": _StubClient("default"), "prod-east": _StubClient("prod-east")}
    mcp = FastMCP("alias-default")
    _register(mcp, _build_resolver(stubs))

    out = _tool_fn(mcp, "list_managed_systems")()
    assert out["items"][0]["name"] == "system-on-default"
    assert stubs["default"].calls == ["list_managed_systems"]
    assert stubs["prod-east"].calls == []


def test_explicit_alias_routes_to_named_client() -> None:
    stubs = {"default": _StubClient("default"), "prod-east": _StubClient("prod-east")}
    mcp = FastMCP("alias-explicit")
    _register(mcp, _build_resolver(stubs))

    out = _tool_fn(mcp, "list_managed_systems")(hmc_alias="prod-east")
    assert out["items"][0]["name"] == "system-on-prod-east"
    assert stubs["prod-east"].calls == ["list_managed_systems"]
    assert stubs["default"].calls == []


def test_unknown_alias_surfaces_validation_error() -> None:
    stubs = {"default": _StubClient("default")}
    mcp = FastMCP("alias-unknown")
    _register(mcp, _build_resolver(stubs))

    with pytest.raises(HmcValidationError, match="Unknown HMC alias"):
        _tool_fn(mcp, "list_managed_systems")(hmc_alias="does-not-exist")


def test_mcp_tool_call_emits_hmc_alias_field(
    caplog: pytest.LogCaptureFixture,
) -> None:
    stubs = {"default": _StubClient("default"), "prod-east": _StubClient("prod-east")}
    mcp = FastMCP("alias-log")
    _register(mcp, _build_resolver(stubs))

    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        _tool_fn(mcp, "list_managed_systems")(hmc_alias="prod-east")

    start_records = [r for r in caplog.records if "mcp_tool_start" in r.getMessage()]
    end_records = [r for r in caplog.records if "mcp_tool_end" in r.getMessage()]

    def _has(records: list[logging.LogRecord]) -> bool:
        return any("hmc_alias" in r.getMessage() and "prod-east" in r.getMessage() for r in records)

    assert _has(start_records)
    assert _has(end_records)


def test_alias_none_does_not_emit_hmc_alias_field(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Backward compat: legacy single-HMC callers see no extra log field."""
    stubs = {"default": _StubClient("default")}
    mcp = FastMCP("alias-none")
    _register(mcp, _build_resolver(stubs))

    with caplog.at_level(logging.INFO, logger="power_hmc_mcp.observability"):
        _tool_fn(mcp, "list_managed_systems")()

    for record in caplog.records:
        assert "hmc_alias" not in record.getMessage(), record.getMessage()


def test_register_tools_with_pool_routes_through_resolver(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """register_readonly_tools(mcp, pool) wires every read tool to the pool resolver."""
    from tests.conftest import apply_hmc_env

    apply_hmc_env(monkeypatch)
    monkeypatch.setenv(
        "HMC_REGISTRY",
        '[{"alias": "prod-east", "host": "east.example", "username": "u", "password": "p"}]',
    )
    settings = Settings()
    pool = HmcClientPool(build_registry(settings))

    mcp = FastMCP("pool-register")
    register_readonly_tools(mcp, pool)

    # Tools should be registered with the alias parameter visible in their
    # schema (FastMCP infers schema from function signatures).
    tool = mcp._tool_manager._tools["list_managed_systems"]
    schema_params = tool.parameters.get("properties", {})
    assert "hmc_alias" in schema_params, "every tool must expose hmc_alias as an optional parameter"
