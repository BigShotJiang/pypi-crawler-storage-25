"""Tests for configuration loading."""

import pytest
from pydantic import ValidationError

from power_hmc_mcp.config import Settings
from tests.conftest import apply_hmc_env


def test_settings_requires_hmc_host(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("HMC_HOST", raising=False)
    monkeypatch.setenv("HMC_USERNAME", "user")
    monkeypatch.setenv("HMC_PASSWORD", "secret")

    # _env_file=None prevents Pydantic from reading a real .env on disk,
    # ensuring the test is fully isolated from local developer config.
    with pytest.raises(ValidationError):
        Settings(_env_file=None)


def test_settings_loads_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    assert settings.hmc_host == "hmc.test"
    assert settings.hmc_port == 443
    assert settings.hmc_username == "api-user"
    assert settings.hmc_password.get_secret_value() == "super-secret"
    assert settings.hmc_verify_tls is False
    assert settings.base_url == "https://hmc.test"


def test_settings_timeout_and_ca_bundle(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    ca_file = tmp_path / "hmc-ca.pem"
    ca_file.write_text("fake-ca", encoding="utf-8")
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_VERIFY_TLS", "true")
    monkeypatch.setenv("HMC_TIMEOUT_SECONDS", "45")
    monkeypatch.setenv("HMC_CA_BUNDLE", str(ca_file))

    settings = Settings()

    assert settings.hmc_timeout_seconds == 45.0
    assert settings.hmc_ca_bundle == ca_file
    assert settings.httpx_verify() == str(ca_file)


def test_settings_httpx_verify_disabled_when_tls_off(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.httpx_verify() is False


def test_settings_rejects_invalid_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_TIMEOUT_SECONDS", "0")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_rejects_missing_ca_bundle(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_CA_BUNDLE", "/nonexistent/ca.pem")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_rejects_url_in_host(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_HOST", "https://hmc.example.com")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_allowlist_parsing(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv(
        "HMC_ALLOWED_MANAGED_SYSTEMS",
        "uuid-a, uuid-b ,uuid-c",
    )
    settings = Settings()
    assert settings.allowed_managed_system_ids() == frozenset({"uuid-a", "uuid-b", "uuid-c"})


def test_settings_empty_allowlist_allows_all(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.allowed_managed_system_ids() is None
    assert settings.is_managed_system_allowed("any-id")


def test_settings_write_flags_default_safe(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_enable_write_tools is False
    assert settings.hmc_writes_enabled is False
    assert settings.hmc_require_execute_flag is True


def test_settings_transport_and_observability_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_mcp_transport == "stdio"
    assert settings.hmc_log_json is False
    assert settings.hmc_read_max_retries == 2
    assert settings.hmc_write_max_retries == 0
    assert settings.hmc_propagate_correlation_header is True


def test_settings_demo_mode_default_false(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_demo_mode is False


def test_settings_demo_mode_enabled(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_DEMO_MODE", "true")
    settings = Settings()
    assert settings.hmc_demo_mode is True


def test_settings_hmc_provider_default_hmc(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_provider == "hmc"


def test_settings_hmc_provider_demo(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROVIDER", "demo")
    settings = Settings()
    assert settings.hmc_provider == "demo"


def test_settings_hmc_provider_powervs(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_PROVIDER", "powervs")
    settings = Settings()
    assert settings.hmc_provider == "powervs"


def test_settings_hmc_max_metrics_bytes_default(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_max_metrics_bytes == 10_000_000


def test_settings_hmc_max_metrics_bytes_custom(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_METRICS_BYTES", "5000000")
    settings = Settings()
    assert settings.hmc_max_metrics_bytes == 5_000_000


def test_settings_hmc_max_metrics_bytes_rejects_too_small(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_METRICS_BYTES", "100")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_hmc_max_metrics_bytes_rejects_too_large(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_METRICS_BYTES", "200000000")  # 200 MB — over the 100 MB cap
    with pytest.raises(ValidationError):
        Settings()


def test_settings_echo_header_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """Defaults follow the IBM HMC REST API spec (X-Transaction-ID + X-Client-Correlator)."""
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_correlation_echo_header == "X-Transaction-ID"
    assert settings.hmc_correlation_echo_fallback_headers == ("X-Client-Correlator",)


def test_settings_echo_fallback_headers_parses_csv(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv(
        "HMC_CORRELATION_ECHO_FALLBACK_HEADERS",
        "X-Client-Correlator, X-Trace-ID , X-IBM-Trace-ID",
    )
    settings = Settings()
    assert settings.hmc_correlation_echo_fallback_headers == (
        "X-Client-Correlator",
        "X-Trace-ID",
        "X-IBM-Trace-ID",
    )


def test_settings_echo_fallback_headers_empty_yields_empty_tuple(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_CORRELATION_ECHO_FALLBACK_HEADERS", "")
    settings = Settings()
    assert settings.hmc_correlation_echo_fallback_headers == ()


def test_settings_outbound_correlation_header_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """Default outbound header is X-Transaction-ID (IBM HMC REST API spec)."""
    apply_hmc_env(monkeypatch)
    monkeypatch.delenv("HMC_OUTBOUND_CORRELATION_HEADER", raising=False)
    settings = Settings()
    assert settings.hmc_outbound_correlation_header == "X-Transaction-ID"


def test_settings_outbound_correlation_header_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """Operators can override to X-Correlation-ID for backwards compat with log pipelines."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_OUTBOUND_CORRELATION_HEADER", "X-Correlation-ID")
    settings = Settings()
    assert settings.hmc_outbound_correlation_header == "X-Correlation-ID"


def test_settings_max_reauth_attempts_default(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()
    assert settings.hmc_max_reauth_attempts == 1


def test_settings_max_reauth_attempts_zero_accepted(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_REAUTH_ATTEMPTS", "0")
    settings = Settings()
    assert settings.hmc_max_reauth_attempts == 0


def test_settings_max_reauth_attempts_rejects_too_large(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_REAUTH_ATTEMPTS", "4")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_max_reauth_attempts_rejects_negative(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MAX_REAUTH_ATTEMPTS", "-1")
    with pytest.raises(ValidationError):
        Settings()


def test_settings_api_version_hint_default_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """HMC_API_VERSION_HINT defaults to None — no hint declared."""
    apply_hmc_env(monkeypatch)
    monkeypatch.delenv("HMC_API_VERSION_HINT", raising=False)
    settings = Settings()
    assert settings.hmc_api_version_hint is None


def test_settings_api_version_hint_from_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_API_VERSION_HINT", "V11R1")
    settings = Settings()
    assert settings.hmc_api_version_hint == "V11R1"


def test_settings_api_version_hint_trims_whitespace(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_API_VERSION_HINT", "  V10R2M1040  ")
    settings = Settings()
    assert settings.hmc_api_version_hint == "V10R2M1040"


def test_settings_api_version_hint_empty_string_is_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty string is treated as 'unset' so operators can clear the hint via env."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_API_VERSION_HINT", "")
    settings = Settings()
    assert settings.hmc_api_version_hint is None
