"""Tests for agent-facing normalization helpers."""

from __future__ import annotations

from pathlib import Path

import pytest
from hypothesis import given
from hypothesis import strategies as st

from power_hmc_mcp.hmc_xml import parse_resource_properties
from power_hmc_mcp.normalize import (
    _LPAR_STATE_CANONICAL,
    normalize_lpar_state,
    normalize_pcm_samples_for_agent,
    normalize_resource,
    pcm_summary,
)

FIRMWARE_FIXTURES = Path(__file__).parent / "fixtures" / "firmware"


def test_normalize_resource_system_properties() -> None:
    result = normalize_resource(
        "38f2a140-b30f-8544-7a1b-2c3d4e5f1234",
        {"SystemName": "p9-SiteA", "State": "operating", "IPAddress": "10.0.0.1"},
        uri="/rest/api/uom/ManagedSystem/38f2a140-b30f-8544-7a1b-2c3d4e5f1234",
    )
    assert result["id"] == "38f2a140-b30f-8544-7a1b-2c3d4e5f1234"
    assert result["name"] == "p9-SiteA"
    assert result["state"] == "operating"
    assert result["uri"].endswith("ManagedSystem/38f2a140-b30f-8544-7a1b-2c3d4e5f1234")


def test_normalize_resource_partition_properties() -> None:
    result = normalize_resource(
        "11111111-1111-2222-3333-444455556666",
        {"PartitionName": "AIX01", "PartitionState": "running", "PartitionID": "2"},
    )
    assert result["name"] == "AIX01"
    assert result["state"] == "running"
    assert result["partition_id"] == "2"
    assert "uri" not in result


def test_normalize_resource_empty_properties() -> None:
    result = normalize_resource("11111111-1111-2222-3333-444455556666", {})
    assert result == {"id": "11111111-1111-2222-3333-444455556666", "properties": {}}


def test_pcm_summary_empty_samples() -> None:
    summary = pcm_summary([])
    assert summary["sample_count"] == 0
    assert summary["categories"] == {}
    assert summary["latest_updated"] is None


def test_pcm_summary_single_category() -> None:
    summary = pcm_summary(
        [{"category": "phyp", "updated": "2025-01-01T00:00:00Z"}],
    )
    assert summary["sample_count"] == 1
    assert summary["categories"] == {"phyp": 1}
    assert summary["latest_updated"] == "2025-01-01T00:00:00Z"


def test_pcm_summary_multi_category_latest_updated() -> None:
    summary = pcm_summary(
        [
            {"category": "phyp", "updated": "2025-01-01T00:00:00Z"},
            {"category": "mem", "updated": "2025-02-01T00:00:00Z"},
            {"category": "phyp", "updated": "2025-01-15T00:00:00Z"},
        ],
    )
    assert summary["sample_count"] == 3
    assert summary["categories"] == {"phyp": 2, "mem": 1}
    assert summary["latest_updated"] == "2025-02-01T00:00:00Z"


def test_normalize_pcm_samples_for_agent_drops_none_fields() -> None:
    normalized = normalize_pcm_samples_for_agent(
        [
            {
                "id": "sample-1",
                "category": "phyp",
                "updated": None,
                "link_href": "/metrics/1.json",
                "title": None,
            },
        ],
    )
    assert normalized == [
        {
            "sample_id": "sample-1",
            "category": "phyp",
            "metrics_href": "/metrics/1.json",
        },
    ]


# --- B2-1: LPAR state canonicalization -----------------------------------


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("Running", "running"),
        ("Not Activated", "not_activated"),
        ("Open Firmware", "open_firmware"),
        ("Starting", "starting"),
        ("Stopping", "stopping"),
        ("Error", "error"),
        ("Migrating", "migrating"),
        ("Hardware Discovery", "hardware_discovery"),
        ("Unknown", "unknown"),
        # case-insensitive matching
        ("running", "running"),
        ("RUNNING", "running"),
        ("hardware discovery", "hardware_discovery"),
        # surrounding whitespace tolerated
        ("  Running  ", "running"),
    ],
)
def test_normalize_lpar_state_known_strings(raw: str, expected: str) -> None:
    assert normalize_lpar_state(raw) == expected


def test_normalize_lpar_state_unknown_string_maps_to_unknown() -> None:
    """An unmapped firmware-specific string must fall back to 'unknown'."""
    assert normalize_lpar_state("SomeFutureFirmwareState") == "unknown"


def test_normalize_lpar_state_none_returns_none() -> None:
    """None input (absent property) returns None, not 'unknown'."""
    assert normalize_lpar_state(None) is None


def test_normalize_lpar_state_empty_string_maps_to_unknown() -> None:
    assert normalize_lpar_state("") == "unknown"


def test_normalize_lpar_state_whitespace_only_maps_to_unknown() -> None:
    assert normalize_lpar_state("   ") == "unknown"


@given(st.text())
def test_normalize_lpar_state_never_raises_on_arbitrary_string(raw: str) -> None:
    result = normalize_lpar_state(raw)
    assert result in {None, *set(_LPAR_STATE_CANONICAL.values()), "unknown"}


@given(st.text())
def test_normalize_lpar_state_unmapped_returns_unknown(raw: str) -> None:
    if raw.strip().lower() not in _LPAR_STATE_CANONICAL:
        assert normalize_lpar_state(raw) == "unknown"


@pytest.mark.parametrize(
    ("raw_key", "expected"),
    [(key, value) for key, value in _LPAR_STATE_CANONICAL.items()],
)
def test_normalize_lpar_state_all_map_entries(raw_key: str, expected: str) -> None:
    assert normalize_lpar_state(raw_key) == expected
    assert normalize_lpar_state(raw_key.title()) == expected


# Firmware-variant XML fixtures — synthetic stubs that exercise the
# parse → normalize pipeline for every known canonical state.  When real
# captures replace these synthetic files, the same tests keep running and
# this assertion gains real-firmware coverage automatically.
@pytest.mark.parametrize(
    ("fixture_name", "expected_canonical"),
    [
        ("firmware_v9_lpar_status_running.xml", "running"),
        ("firmware_v9_lpar_status_not_activated.xml", "not_activated"),
        ("firmware_v9_lpar_status_open_firmware.xml", "open_firmware"),
        ("firmware_v9_lpar_status_starting.xml", "starting"),
        ("firmware_v9_lpar_status_stopping.xml", "stopping"),
        ("firmware_v9_lpar_status_error.xml", "error"),
        ("firmware_v9_lpar_status_migrating.xml", "migrating"),
        ("firmware_v9_lpar_status_hardware_discovery.xml", "hardware_discovery"),
        ("firmware_v9_lpar_status_unknown.xml", "unknown"),
    ],
)
def test_firmware_variant_xml_parses_to_canonical_state(
    fixture_name: str,
    expected_canonical: str,
) -> None:
    body = (FIRMWARE_FIXTURES / fixture_name).read_text(encoding="utf-8")
    properties = parse_resource_properties(body)
    raw_state = properties.get("PartitionState") or properties.get("State")
    assert normalize_lpar_state(raw_state) == expected_canonical
