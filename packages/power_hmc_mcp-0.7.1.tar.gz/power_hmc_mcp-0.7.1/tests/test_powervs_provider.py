"""Tests for PowerVSProvider stub behavior."""

from __future__ import annotations

import inspect

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.guardrails import _issue_authorization
from power_hmc_mcp.powervs_provider import PowerVSProvider
from tests.conftest import LPAR_ID, SYSTEM_ID, apply_hmc_env


@pytest.fixture
def powervs_provider(monkeypatch: pytest.MonkeyPatch) -> PowerVSProvider:
    apply_hmc_env(monkeypatch)
    return PowerVSProvider(Settings(hmc_provider="powervs"))


def test_init_does_not_raise(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    PowerVSProvider(Settings(hmc_provider="powervs"))


def test_login_raises_not_implemented(powervs_provider: PowerVSProvider) -> None:
    with pytest.raises(NotImplementedError, match="PowerVSProvider is not yet implemented"):
        powervs_provider.login()


@pytest.mark.parametrize(
    "method_name,kwargs",
    [
        ("close", {}),
        ("list_managed_systems", {}),
        ("get_managed_system", {"managed_system_id": SYSTEM_ID}),
        ("list_lpars", {"managed_system_id": SYSTEM_ID}),
        ("get_lpar_status", {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID}),
        ("get_lpar", {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID}),
        ("get_lpar_quick", {"lpar_id": LPAR_ID}),
        ("list_partition_profiles", {"lpar_id": LPAR_ID}),
        ("get_capacity", {"managed_system_id": SYSTEM_ID}),
        (
            "get_capacity_full",
            {"managed_system_id": SYSTEM_ID, "metrics_href": "/metrics.json"},
        ),
        ("is_authenticated", {}),
        ("health_check", {}),
    ],
)
def test_read_methods_raise_not_implemented(
    powervs_provider: PowerVSProvider,
    method_name: str,
    kwargs: dict[str, str],
) -> None:
    method = getattr(powervs_provider, method_name)
    with pytest.raises(NotImplementedError, match="PowerVSProvider is not yet implemented"):
        method(**kwargs)


def test_write_methods_raise_not_implemented(powervs_provider: PowerVSProvider) -> None:
    auth = _issue_authorization(operation="start_lpar", correlation_id="cid-pv")
    write_methods = [
        (
            powervs_provider.create_lpar_from_profile,
            {
                "managed_system_id": SYSTEM_ID,
                "profile_name": "default",
                "new_lpar_name": "new-lpar",
                "authorization": auth,
            },
        ),
        (
            powervs_provider.start_lpar,
            {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID, "authorization": auth},
        ),
        (
            powervs_provider.stop_lpar,
            {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID, "authorization": auth},
        ),
    ]
    for method, kwargs in write_methods:
        with pytest.raises(NotImplementedError, match="PowerVSProvider is not yet implemented"):
            method(**kwargs)


def test_all_public_methods_covered(powervs_provider: PowerVSProvider) -> None:
    public = [
        name
        for name, member in inspect.getmembers(powervs_provider)
        if not name.startswith("_") and callable(member) and name != "settings"
    ]
    assert "login" in public
    assert len(public) >= 15
