"""HTTP policy helpers (classification and retry hints)."""

from __future__ import annotations

import asyncio

import httpx
import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.http_policy import (
    RequestClassification,
    is_idempotent_method,
    is_retryable_http_status,
    is_retryable_transport_error,
    retry_sleep,
    throttle_before_request,
)
from tests.conftest import apply_hmc_env


def test_is_idempotent_method_get_only() -> None:
    assert is_idempotent_method("GET") is True
    assert is_idempotent_method("POST") is False


def test_retryable_status_for_reads_not_writes() -> None:
    assert is_retryable_http_status(
        503,
        "GET",
        classification=RequestClassification.READ,
    )
    assert not is_retryable_http_status(
        503,
        "POST",
        classification=RequestClassification.WRITE,
    )


def test_retry_sleep_raises_in_async_context(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    async def invoke() -> None:
        retry_sleep(settings, 0)

    with pytest.raises(RuntimeError, match="retry_sleep"):
        asyncio.run(invoke())


def test_throttle_before_request_raises_in_async_context(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    settings = Settings()

    async def invoke() -> None:
        throttle_before_request(settings, None)

    with pytest.raises(RuntimeError, match="throttle_before_request"):
        asyncio.run(invoke())


def test_transport_errors_retryable_selectively() -> None:
    req = httpx.Request("GET", "https://h.example/rest")
    exc = httpx.TimeoutException("timeout", request=req)
    assert is_retryable_transport_error(exc, classification=RequestClassification.READ)
    assert not is_retryable_transport_error(exc, classification=RequestClassification.WRITE)


def test_throttle_before_request_no_op_when_floor_is_zero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """throttle_before_request returns immediately when the floor is 0.0.

    B2-2 guard: documents that the default HMC_MIN_REQUEST_INTERVAL_SECONDS=0.0
    incurs zero overhead — operators only pay throttle latency when they
    explicitly opt in.
    """
    import time

    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_MIN_REQUEST_INTERVAL_SECONDS", "0.0")
    settings = Settings()
    assert settings.hmc_min_request_interval_seconds == 0.0

    sleep_calls: list[float] = []
    monkeypatch.setattr(time, "sleep", lambda s: sleep_calls.append(s))
    throttle_before_request(settings, last_request_monotonic=time.monotonic())
    assert sleep_calls == [], "time.sleep must not be called when floor is 0"
