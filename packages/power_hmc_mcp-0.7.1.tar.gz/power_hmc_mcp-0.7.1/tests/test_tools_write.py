"""Tests for the structural write-tool decorator and the audit emission contract.

These cover the Phase A tightening: the only path from an MCP write tool to a
mutation-capable :class:`HmcClient` method goes through ``run_write_tool``,
which is the only path that can issue a :class:`WriteAuthorization`.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

import pytest
from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from power_hmc_mcp.config import Settings
from power_hmc_mcp.guardrails import WriteAuthorization
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.tools import (
    READONLY_TOOL_NAMES,
    WRITE_TOOL_NAMES,
    register_tools,
)
from power_hmc_mcp.tools.write import (
    WRITE_TOOL_MARKER,
    is_write_tool,
    mark_write_tool,
    run_write_tool,
)
from tests.conftest import LPAR_ID, SYSTEM_ID, apply_hmc_env


def _enable_writes(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    monkeypatch.setenv("HMC_WRITES_ENABLED", "true")
    monkeypatch.setenv("HMC_REQUIRE_EXECUTE_FLAG", "true")
    return Settings()


def test_mark_write_tool_sets_marker_attribute() -> None:
    @mark_write_tool
    def tool(x: int) -> dict[str, Any]:
        return {"x": x}

    assert getattr(tool, WRITE_TOOL_MARKER) is True
    assert is_write_tool(tool) is True
    assert is_write_tool(lambda: None) is False


def test_run_write_tool_denied_path_returns_envelope_and_skips_executor(
    settings: Settings,
    caplog: pytest.LogCaptureFixture,
) -> None:
    invocations: list[WriteAuthorization] = []

    def executor(auth: WriteAuthorization) -> dict[str, Any]:
        invocations.append(auth)
        raise AssertionError("executor must not run on the denied path")

    caplog.set_level(logging.INFO, logger="power_hmc_mcp.observability")
    out = run_write_tool(
        tool_name="start_lpar",
        operation="start_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=True,
        executor=executor,
    )

    assert invocations == []
    assert out["dry_run"] is True
    assert out["operation"] == "start_lpar"
    assert "disabled" in out["message"]

    audit_records = [
        rec
        for rec in caplog.records
        if "write_audit" in rec.getMessage() and "denied" in rec.getMessage()
    ]
    assert audit_records, "denied path must emit a write_audit record"
    assert "start_lpar" in audit_records[-1].getMessage()


def test_run_write_tool_dry_run_path_returns_envelope_and_audits(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    monkeypatch.setenv("HMC_REQUIRE_EXECUTE_FLAG", "false")
    settings = Settings()

    def executor(auth: WriteAuthorization) -> dict[str, Any]:
        raise AssertionError("executor must not run on the dry-run path")

    caplog.set_level(logging.INFO, logger="power_hmc_mcp.observability")
    out = run_write_tool(
        tool_name="start_lpar",
        operation="start_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=False,
        executor=executor,
    )

    assert out["dry_run"] is True
    audit_records = [
        rec
        for rec in caplog.records
        if "write_audit" in rec.getMessage() and "dry_run" in rec.getMessage()
    ]
    assert audit_records, "dry-run path must emit a write_audit record"


def test_run_write_tool_authorized_path_invokes_executor_with_token(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    settings = _enable_writes(monkeypatch)
    seen: list[WriteAuthorization] = []

    def executor(auth: WriteAuthorization) -> dict[str, Any]:
        seen.append(auth)
        return {"ran": True, "operation": auth.operation}

    caplog.set_level(logging.INFO, logger="power_hmc_mcp.observability")
    out = run_write_tool(
        tool_name="start_lpar",
        operation="start_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=True,
        executor=executor,
    )

    assert out == {"ran": True, "operation": "start_lpar"}
    assert len(seen) == 1
    assert isinstance(seen[0], WriteAuthorization)
    assert seen[0].operation == "start_lpar"
    assert seen[0].correlation_id

    audit_records = [
        rec
        for rec in caplog.records
        if "write_audit" in rec.getMessage() and "authorized" in rec.getMessage()
    ]
    assert audit_records, "authorized path must emit a write_audit record"


def test_register_write_tools_requires_marker(
    monkeypatch: pytest.MonkeyPatch,
    hmc_routes,  # noqa: ANN001  (fixture from conftest)
) -> None:
    """A write tool that forgets @mark_write_tool fails registration, not call time."""
    settings = _enable_writes(monkeypatch)
    mcp = FastMCP("test-server", json_response=True)
    client = HmcClient(settings)

    # Register the read tools and two of three write tools properly.
    from power_hmc_mcp.pool import single_client_resolver
    from power_hmc_mcp.tools import (
        create_lpar_from_profile,
        get_capacity,
        get_lpar,
        get_lpar_status,
        get_managed_system,
        health_check,
        list_lpars,
        list_managed_systems,
        list_partition_profiles,
        start_lpar,
    )

    resolver = single_client_resolver(client)
    list_managed_systems.register(mcp, resolver)
    list_lpars.register(mcp, resolver)
    get_lpar_status.register(mcp, resolver)
    get_managed_system.register(mcp, resolver)
    get_lpar.register(mcp, resolver)
    list_partition_profiles.register(mcp, resolver)
    get_capacity.register(mcp, resolver)
    health_check.register(mcp, resolver)
    create_lpar_from_profile.register(mcp, resolver)
    start_lpar.register(mcp, resolver)

    # Manually register a stop_lpar replacement that is missing the marker.
    @mcp.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
    def stop_lpar(  # noqa: ARG001
        managed_system_id: str,
        lpar_id: str,
        mode: str = "normal",
        execute: bool = False,
    ) -> dict[str, Any]:
        return {"oops": "no marker"}

    from power_hmc_mcp.tools import _validate_tool_registration

    with pytest.raises(RuntimeError, match="missing the @mark_write_tool decorator"):
        _validate_tool_registration(mcp, writes_enabled=True)


def test_register_tools_accepts_correctly_decorated_writes(
    monkeypatch: pytest.MonkeyPatch,
    hmc_routes,  # noqa: ANN001
) -> None:
    settings = _enable_writes(monkeypatch)
    mcp = FastMCP("test-server", json_response=True)
    client = HmcClient(settings)

    register_tools(mcp, client)

    registered = frozenset(mcp._tool_manager._tools.keys())
    assert registered == READONLY_TOOL_NAMES | WRITE_TOOL_NAMES

    # Every write tool carries the marker on its `Tool.fn` callable.
    for name in WRITE_TOOL_NAMES:
        assert is_write_tool(mcp._tool_manager._tools[name].fn), (
            f"registered write tool {name!r} is missing the structural marker"
        )


def test_run_write_tool_envelope_is_json_serializable(settings: Settings) -> None:
    out = run_write_tool(
        tool_name="start_lpar",
        operation="start_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=True,
        executor=lambda _: {"unreached": True},
    )
    json.dumps(out)


def test_denied_response_has_suggested_next_step(settings: Settings) -> None:
    """run_write_tool denied path includes suggested_next_step in the envelope."""
    out = run_write_tool(
        tool_name="start_lpar",
        operation="start_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=True,
        executor=lambda _: {"unreached": True},
    )
    assert "suggested_next_step" in out
    assert isinstance(out["suggested_next_step"], str)
    assert out["suggested_next_step"]
    assert out["guardrail_outcome"] == "denied"
    assert out["denial_reason_code"] == "writes_disabled"


def test_dry_run_envelope_has_suggested_next_step(monkeypatch: pytest.MonkeyPatch) -> None:
    """run_write_tool dry-run path includes suggested_next_step in the envelope."""
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    monkeypatch.setenv("HMC_REQUIRE_EXECUTE_FLAG", "false")
    settings = Settings()

    out = run_write_tool(
        tool_name="stop_lpar",
        operation="stop_lpar",
        settings=settings,
        params={"lpar_id": "x"},
        execute=False,
        executor=lambda _: {"unreached": True},
    )
    assert "suggested_next_step" in out
    assert isinstance(out["suggested_next_step"], str)
    assert out["guardrail_outcome"] == "preview"
    assert "denial_reason_code" not in out


@pytest.fixture
def settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    return Settings()


@pytest.mark.parametrize(
    ("operation", "params", "executor_factory"),
    [
        (
            "start_lpar",
            {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID},
            lambda client: lambda auth: client.start_lpar(SYSTEM_ID, LPAR_ID, authorization=auth),
        ),
        (
            "stop_lpar",
            {"managed_system_id": SYSTEM_ID, "lpar_id": LPAR_ID, "mode": "normal"},
            lambda client: (
                lambda auth: client.stop_lpar(
                    SYSTEM_ID,
                    LPAR_ID,
                    "normal",
                    authorization=auth,
                )
            ),
        ),
        (
            "create_lpar_from_profile",
            {
                "managed_system_id": SYSTEM_ID,
                "profile_name": "default",
                "new_lpar_name": "NEW01",
                "overrides": {},
            },
            lambda client: (
                lambda auth: client.create_lpar_from_profile(
                    SYSTEM_ID,
                    "default",
                    "NEW01",
                    None,
                    authorization=auth,
                )
            ),
        ),
    ],
)
def test_run_write_tool_authorized_path_returns_phase_a_scaffold(
    monkeypatch: pytest.MonkeyPatch,
    hmc_client: HmcClient,
    operation: str,
    params: dict[str, Any],
    executor_factory: Any,
) -> None:
    settings = _enable_writes(monkeypatch)
    out = run_write_tool(
        tool_name=operation,
        operation=operation,
        settings=settings,
        params=params,
        execute=True,
        executor=executor_factory(hmc_client),
    )
    assert out["placeholder"] is True
    assert out["executed"] is False
    assert out["guardrail_outcome"] == "authorized_placeholder"
    assert re.search(r"scaffold|phase c", out["message"], re.IGNORECASE)
