"""Tests for write-operation guardrails and the structural decorator boundary."""

from __future__ import annotations

import json
import logging

import pytest

from power_hmc_mcp.config import Settings
from power_hmc_mcp.guardrails import (
    _GUARDRAIL_SENTINEL,
    WriteAuthorization,
    _issue_authorization,
    check_write_allowed,
    dry_run_response,
    placeholder_execute_response,
    require_execute_flag,
    write_tools_enabled,
)
from tests.conftest import apply_hmc_env


@pytest.fixture
def settings(monkeypatch: pytest.MonkeyPatch) -> Settings:
    apply_hmc_env(monkeypatch)
    return Settings()


def test_write_tools_disabled_by_default(settings: Settings) -> None:
    assert write_tools_enabled(settings) is False
    decision = check_write_allowed(settings, execute=False)
    assert decision.allowed is False
    assert "disabled" in decision.reason


def test_write_tools_enabled_requires_execute_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    monkeypatch.setenv("HMC_WRITES_ENABLED", "true")
    monkeypatch.setenv("HMC_REQUIRE_EXECUTE_FLAG", "true")
    settings = Settings()

    denied = require_execute_flag(settings, execute=False)
    assert denied.allowed is False
    assert denied.dry_run is True

    allowed = check_write_allowed(settings, execute=True)
    assert allowed.allowed is True


def test_live_writes_disabled_blocks_even_when_write_tools_enabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    monkeypatch.setenv("HMC_WRITES_ENABLED", "false")
    settings = Settings()

    decision = check_write_allowed(settings, execute=True)
    assert decision.allowed is False
    assert "HMC_WRITES_ENABLED=false" in decision.reason

    resp = dry_run_response(
        "start_lpar",
        {"lpar_id": "x"},
        reason=decision.reason,
    )
    assert resp["denial_reason_code"] == "live_writes_disabled"
    assert "HMC_WRITES_ENABLED" in resp["suggested_next_step"]


def test_dry_run_response_is_stable_and_json_serializable() -> None:
    response = dry_run_response(
        "start_lpar",
        {"lpar_id": "11111111-1111-2222-3333-444455556666"},
    )
    assert response["dry_run"] is True
    assert response["operation"] == "start_lpar"
    json.dumps(response)


def test_write_authorization_direct_construction_is_rejected() -> None:
    with pytest.raises(ValueError, match="must be issued"):
        WriteAuthorization(operation="start_lpar", correlation_id="cid-1")


def test_write_authorization_with_unrelated_sentinel_is_rejected() -> None:
    with pytest.raises(ValueError, match="must be issued"):
        WriteAuthorization(
            operation="start_lpar",
            correlation_id="cid-1",
            _sentinel=object(),
        )


def test_issue_authorization_returns_valid_token() -> None:
    auth = _issue_authorization(operation="start_lpar", correlation_id="cid-42")
    assert isinstance(auth, WriteAuthorization)
    assert auth.operation == "start_lpar"
    assert auth.correlation_id == "cid-42"
    assert auth._sentinel is _GUARDRAIL_SENTINEL


def test_placeholder_execute_response_requires_authorization_shape() -> None:
    auth = _issue_authorization(operation="start_lpar", correlation_id="cid-1")
    body = placeholder_execute_response(
        "start_lpar",
        {"lpar_id": "x"},
        preview_method="POST",
        preview_path="/rest/api/demo",
        authorization=auth,
    )
    assert body["dry_run"] is False
    assert body["executed"] is False
    assert body["placeholder"] is True
    assert body["audit"]["record_status"] == "placeholder"
    assert body["audit"]["correlation_id"] == "cid-1"
    assert body["audit"]["execute_requested"] is True


class TestSuggestedNextStep:
    """suggested_next_step must be present on every write tool response shape."""

    def test_dry_run_response_has_suggested_next_step(self) -> None:
        resp = dry_run_response("start_lpar", {"managed_system_id": "x"})
        assert "suggested_next_step" in resp
        assert isinstance(resp["suggested_next_step"], str)
        assert resp["suggested_next_step"]

    def test_denied_response_has_suggested_next_step(self) -> None:
        resp = dry_run_response(
            "start_lpar",
            {"managed_system_id": "x"},
            reason="write tools are disabled by configuration",
        )
        assert "suggested_next_step" in resp
        assert isinstance(resp["suggested_next_step"], str)
        assert "HMC_ENABLE_WRITE_TOOLS" in resp["suggested_next_step"]
        assert resp["guardrail_outcome"] == "denied"
        assert resp["denial_reason_code"] == "writes_disabled"

    def test_execute_required_denial_hint(self) -> None:
        resp = dry_run_response(
            "start_lpar",
            {"managed_system_id": "x"},
            reason="execute flag is required for write operations",
        )
        assert resp["denial_reason_code"] == "execute_required"
        assert "execute=true" in resp["suggested_next_step"]

    def test_dry_run_hint_differs_from_denied_hint(self) -> None:
        preview = dry_run_response("start_lpar", {})
        denied = dry_run_response(
            "start_lpar",
            {},
            reason="write tools are disabled by configuration",
        )
        assert preview["suggested_next_step"] != denied["suggested_next_step"]
        assert preview["guardrail_outcome"] == "preview"
        assert "denial_reason_code" not in preview

    def test_placeholder_execute_response_has_suggested_next_step(self) -> None:
        auth = _issue_authorization(operation="start_lpar", correlation_id="test-cid")
        resp = placeholder_execute_response(
            "start_lpar",
            {"managed_system_id": "x"},
            preview_method="POST",
            preview_path="/rest/api/uom/test/operations/Start",
            authorization=auth,
        )
        assert "suggested_next_step" in resp
        assert isinstance(resp["suggested_next_step"], str)
        assert resp["suggested_next_step"]
        assert resp["guardrail_outcome"] == "authorized_placeholder"

    def test_suggested_next_step_is_json_serializable(self) -> None:
        resp = dry_run_response("stop_lpar", {})
        json.dumps(resp)


def test_log_write_audit_rejects_unknown_outcome() -> None:
    from power_hmc_mcp.observability import log_write_audit

    with pytest.raises(ValueError, match="outcome must be one of"):
        log_write_audit(
            tool_name="start_lpar",
            operation="start_lpar",
            outcome="bogus",
            reason="x",
            execute_requested=True,
        )


def test_log_write_audit_emits_canonical_fields(
    caplog: pytest.LogCaptureFixture,
) -> None:
    from power_hmc_mcp.observability import log_write_audit

    caplog.set_level(logging.INFO, logger="power_hmc_mcp.observability")
    log_write_audit(
        tool_name="start_lpar",
        operation="start_lpar",
        outcome="denied",
        reason="execute flag is required for write operations",
        execute_requested=False,
    )

    matching = [
        rec
        for rec in caplog.records
        if "write_audit" in rec.getMessage() and "start_lpar" in rec.getMessage()
    ]
    assert matching, "expected a write_audit log record to be emitted"
    msg = matching[-1].getMessage()
    for required in (
        "write_audit",
        "tool_name",
        "operation",
        "outcome",
        "denied",
        "reason",
        "execute_requested",
    ):
        assert required in msg, f"missing field {required!r} in audit message: {msg}"
