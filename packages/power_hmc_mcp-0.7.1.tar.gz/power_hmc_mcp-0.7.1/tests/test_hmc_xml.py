"""Tests for HMC XML helpers."""

import logging

import pytest

from power_hmc_mcp.exceptions import HmcParseError
from power_hmc_mcp.hmc_xml import (
    build_logon_request,
    parse_feed_entries,
    parse_pcm_metrics_feed,
    parse_quick_properties,
    parse_resource_properties,
)


def test_build_logon_request_escapes_credentials() -> None:
    body = build_logon_request("user&name", "p<ass>")
    assert "<UserID>user&amp;name</UserID>" in body
    assert "<Password>p&lt;ass&gt;</Password>" in body


def test_parse_feed_entries_managed_systems() -> None:
    xml = """<?xml version="1.0"?>
    <feed xmlns="http://www.w3.org/2005/Atom">
      <entry>
        <id>uuid://abc-def</id>
        <SystemName>sys1</SystemName>
        <State>operating</State>
      </entry>
    </feed>"""
    entries = parse_feed_entries(xml)
    assert len(entries) == 1
    assert entries[0]["id"] == "abc-def"
    assert entries[0]["name"] == "sys1"
    assert entries[0]["state"] == "operating"


def test_parse_feed_entries_invalid_xml_raises() -> None:
    with pytest.raises(HmcParseError):
        parse_feed_entries("not xml")


def test_parse_resource_properties() -> None:
    xml = """<?xml version="1.0"?>
    <ManagedSystem><SystemName>sys1</SystemName><State>on</State></ManagedSystem>"""
    props = parse_resource_properties(xml)
    assert props["SystemName"] == "sys1"
    assert props["State"] == "on"


def test_parse_pcm_metrics_feed() -> None:
    xml = """<?xml version="1.0"?>
    <feed xmlns="http://www.w3.org/2005/Atom">
      <entry>
        <id>uuid://abc</id>
        <title>ProcessedMetrics</title>
        <updated>2025-01-01T00:00:00Z</updated>
        <category term="phyp"/>
        <link rel="alternate" href="/metrics/sample.json"/>
      </entry>
    </feed>"""
    samples = parse_pcm_metrics_feed(xml)
    assert len(samples) == 1
    assert samples[0]["category"] == "phyp"
    assert samples[0]["link_href"] == "/metrics/sample.json"


def test_parse_pcm_metrics_feed_warns_on_unmatched_rel(
    caplog: pytest.LogCaptureFixture,
) -> None:
    xml = """<?xml version="1.0"?>
    <feed xmlns="http://www.w3.org/2005/Atom">
      <entry>
        <link rel="enclosure" href="/metrics/unknown.json"/>
      </entry>
    </feed>"""
    caplog.set_level(logging.WARNING, logger="power_hmc_mcp.hmc_xml")
    samples = parse_pcm_metrics_feed(xml)
    assert samples == []
    assert any("Observed rel values" in rec.message for rec in caplog.records)
    assert any("enclosure" in rec.message for rec in caplog.records)


def test_parse_quick_properties() -> None:
    xml = """<?xml version="1.0"?>
    <LogicalPartition>
      <PartitionState>running</PartitionState>
    </LogicalPartition>"""
    props = parse_quick_properties(xml)
    assert props["PartitionState"] == "running"
