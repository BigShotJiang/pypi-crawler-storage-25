"""Tests for resource ID validation."""

from __future__ import annotations

import pytest

from power_hmc_mcp.exceptions import HmcValidationError
from power_hmc_mcp.validation import validate_resource_id


def test_validate_resource_id_accepts_lowercase_uuid() -> None:
    value = "38f2a140-b30f-8544-7a1b-2c3d4e5f1234"
    assert validate_resource_id(value, field="managed_system_id") == value


def test_validate_resource_id_accepts_uppercase_uuid() -> None:
    value = "38F2A140-B30F-8544-7A1B-2C3D4E5F1234"
    assert validate_resource_id(value, field="managed_system_id") == value.lower()


def test_validate_resource_id_accepts_mixed_case_uuid() -> None:
    value = "38f2A140-B30f-8544-7a1B-2c3d4e5f1234"
    assert validate_resource_id(value, field="lpar_id") == value.lower()


def test_validate_resource_id_strips_whitespace() -> None:
    value = "  38f2a140-b30f-8544-7a1b-2c3d4e5f1234  "
    assert validate_resource_id(value, field="managed_system_id") == value.strip().lower()


def test_validate_resource_id_rejects_short_string() -> None:
    with pytest.raises(HmcValidationError, match="UUID"):
        validate_resource_id("abc", field="lpar_id")


def test_validate_resource_id_rejects_path_traversal() -> None:
    with pytest.raises(HmcValidationError, match="UUID"):
        validate_resource_id("../admin", field="managed_system_id")


def test_validate_resource_id_rejects_empty_string() -> None:
    with pytest.raises(HmcValidationError, match="UUID"):
        validate_resource_id("   ", field="managed_system_id")


def test_validate_resource_id_allow_non_uuid_fallback() -> None:
    assert (
        validate_resource_id("legacy-id_1", field="resource", allow_non_uuid=True) == "legacy-id_1"
    )
