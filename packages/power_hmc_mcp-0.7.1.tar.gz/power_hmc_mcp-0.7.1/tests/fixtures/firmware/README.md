# Firmware variant fixtures

XML response captures scoped to specific HMC firmware versions. Each file documents the firmware version it was captured from and the LPAR lifecycle state it exercises.

## Naming convention

```
firmware_v<major>_<resource>_<state_slug>.xml
```

Examples:

```
firmware_v9_lpar_status_running.xml
firmware_v10_lpar_status_not_activated.xml
```

## How to add a real capture

1. Record the response body verbatim against the target HMC.
2. Add a comment header to the top of the file:
   ```xml
   <!-- Captured: HMC V<version>, <YYYY-MM-DD>, <tester> -->
   ```
3. Update [`docs/hmc-compatibility.md`](../../docs/hmc-compatibility.md):
   - Add a row to "Tested firmware versions".
   - Flip the corresponding row in "LPAR state strings" from `[ASSUMED]` to `[VALIDATED vN]` and list the firmware version.

## Why synthetic stubs ship today

The synthetic stubs in this directory exist so the parametrized normalization tests in [`tests/test_normalize.py`](../../tests/test_normalize.py) (and the contract test surface in [`tests/test_contracts.py`](../../tests/test_contracts.py)) have something to load and exercise immediately. Each synthetic file is annotated:

```xml
<!-- [ASSUMED] synthetic fixture — not captured from real firmware -->
```

Replace these `[ASSUMED]` files with real captures as access to V9 / V10 HMCs becomes available. **Do not flip the `[ASSUMED]` annotation to `[VALIDATED]` unless the file is a verbatim real capture.**
