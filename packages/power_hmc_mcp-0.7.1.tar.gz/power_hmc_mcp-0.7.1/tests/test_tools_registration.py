"""Tests MCP tool registration with deployment flags."""

from __future__ import annotations

import pytest
from mcp.server.fastmcp import FastMCP

from power_hmc_mcp.config import Settings
from power_hmc_mcp.hmc_client import HmcClient
from power_hmc_mcp.tools import (
    READONLY_TOOL_NAMES,
    WRITE_TOOL_NAMES,
    register_readonly_tools,
    register_tools,
)
from tests.conftest import apply_hmc_env


def test_only_readonly_tools_registered(hmc_settings) -> None:
    mcp = FastMCP("test-server", json_response=True)
    client = HmcClient(hmc_settings)
    register_readonly_tools(mcp, client)

    registered = frozenset(mcp._tool_manager._tools.keys())

    assert registered == READONLY_TOOL_NAMES
    assert not registered & WRITE_TOOL_NAMES


def test_register_tools_includes_writes_when_enabled(monkeypatch: pytest.MonkeyPatch) -> None:
    apply_hmc_env(monkeypatch)
    monkeypatch.setenv("HMC_ENABLE_WRITE_TOOLS", "true")
    settings = Settings()
    mcp = FastMCP("test-server", json_response=True)
    client = HmcClient(settings)
    register_tools(mcp, client)
    registered = frozenset(mcp._tool_manager._tools.keys())
    assert registered == READONLY_TOOL_NAMES | WRITE_TOOL_NAMES
