"""Tests for logging redaction."""

from __future__ import annotations

import logging

from power_hmc_mcp.logging_utils import REDACTED, RedactingFilter, configure_logging


def test_redacting_filter_static_patterns() -> None:
    filt = RedactingFilter()
    assert filt._redact("password=secret123") == f"password={REDACTED}"
    assert filt._redact("<Password>abc</Password>") == f"<Password>{REDACTED}</Password>"
    assert filt._redact("X-API-Session: tok-xyz") == f"X-API-Session: {REDACTED}"
    assert filt._redact("Authorization: Bearer my-jwt") == f"Authorization: Bearer {REDACTED}"


def test_redacting_filter_env_secret() -> None:
    filt = RedactingFilter(["super-secret"])
    assert filt._redact("login failed for super-secret user") == f"login failed for {REDACTED} user"


def test_redacting_filter_on_log_record() -> None:
    filt = RedactingFilter(["hunter2"])
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="token hunter2 leaked",
        args=(),
        exc_info=None,
    )
    assert filt.filter(record) is True
    assert REDACTED in record.msg
    assert "hunter2" not in record.msg


def test_configure_logging_sets_redacting_handler() -> None:
    configure_logging()
    root = logging.getLogger()
    assert root.handlers
    assert any(
        any(isinstance(f, RedactingFilter) for f in handler.filters) for handler in root.handlers
    )
