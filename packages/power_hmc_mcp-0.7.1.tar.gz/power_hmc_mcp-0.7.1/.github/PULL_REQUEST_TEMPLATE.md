## Summary

<!-- 1-2 sentences: what changed and why (e.g. new read tool, guardrail fix, CI workflow) -->

## Linked Issue

Closes #

## Phase

<!-- Which phase does this belong to: B / C / D / E / F / H / I / Docs / Testing -->

## Type of Change

- [ ] Bug fix
- [ ] New tool/feature
- [ ] Refactor
- [ ] CI/CD
- [ ] Docs
- [ ] Security
- [ ] Tests

## Test Coverage

- [ ] New tests added or existing tests updated
- [ ] pytest passes locally (both 3.11 and 3.12)
- [ ] mypy passes with no new errors
- [ ] ruff passes with no new violations

## IBM/HMC Validation

- [ ] Not applicable (no HMC-specific behavior changed)
- [ ] Tested against live HMC
- [ ] Blocked on IBM validation — see issue for details

## Compatibility doc rows

Required when this PR touches firmware-sensitive behavior (LPAR state mapping, correlation header echo, quick endpoints, PCM full fetch, or write OP names). See [CONTRIBUTING.md → Firmware validation rules](../CONTRIBUTING.md#firmware-validation-rules).

- [ ] Not applicable
- [ ] Adds/updates a row in [`docs/hmc-compatibility.md`](../docs/hmc-compatibility.md) (linked below)
- [ ] No `[ASSUMED]` → `[VALIDATED]` flips without a corresponding capture row in this PR

Linked rows / sections:

## Notes for Reviewer

<!-- Anything that needs special attention, known limitations, or follow-up issues -->
