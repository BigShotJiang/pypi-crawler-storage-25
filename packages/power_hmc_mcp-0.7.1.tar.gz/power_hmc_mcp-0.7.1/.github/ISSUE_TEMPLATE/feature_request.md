---
name: Feature Request
about: Propose a new MCP tool, capability, or improvement
labels: enhancement
---

## Summary

<!-- What should be added to power-hmc-mcp-server (tool, config flag, transport, observability, etc.) -->

## Motivation

<!-- What use case or agent workflow does this enable? Reference Phase B–I in TODO.md if applicable. -->

## Proposed MCP Tool Name

<!-- If applicable — snake_case name matching existing tools (e.g. get_capacity, list_lpars) -->

## HMC REST Endpoint

<!--
If known — include collection path or operation URL as built in routes.py
(e.g. /rest/api/uom/ManagedSystem/..., PCM Atom feed)
-->

## IBM Validation Required

<!-- yes/no + reason — mark [RISK] in TODO.md if firmware-specific validation is needed -->

## Acceptance Criteria

- [ ]
- [ ]
- [ ]

## Alternatives Considered

<!-- Other approaches you evaluated -->

## Additional Context

<!-- Links to IBM docs, sample payloads, related issues, or phase roadmap notes -->
