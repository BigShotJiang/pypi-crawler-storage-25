---
name: Bug Report
about: Report unexpected behavior from an MCP tool or the HMC client
labels: bug
---

## Describe the bug

<!-- A clear description of what went wrong when using power-hmc-mcp-server -->

## MCP Tool Name

<!-- Which MCP tool triggered the issue (e.g. list_lpars, get_lpar_status, start_lpar) -->

## HMC Firmware Version

<!-- If known — helps correlate with [RISK] items in TODO.md Phase B/C -->

## Steps to Reproduce

1.
2.
3.

## Expected Behavior

<!-- What you expected the tool or HMC client to return -->

## Actual Behavior

<!-- What actually happened, including error messages or unexpected JSON -->

## Relevant Logs

<!--
Paste structured log excerpts (HMC_LOG_JSON=true helps).
Redact credentials, hostnames, session tokens, and managed system identifiers.
-->

## Environment

- Python version:
- OS:
- MCP client (e.g. Claude Desktop, Cursor, custom stdio host):
- Transport (stdio / streamable HTTP):
- `HMC_ENABLE_WRITE_TOOLS` (if relevant):

## Additional Context

<!-- Screenshots, correlation IDs, related issues, or firmware-specific notes -->
