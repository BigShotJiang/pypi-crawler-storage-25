#!/usr/bin/env bash
# Bootstrap GitHub repo metadata for power-hmc-mcp-server:
# topics, Phase B–I milestones, issue milestone assignment, project board triage.
#
# Prerequisites: gh auth login (scopes: repo, project, read:org)
# Usage: ./scripts/github-bootstrap.sh

set -euo pipefail

REPO="${GITHUB_REPOSITORY:-TylrDn/power-hmc-mcp-server}"
OWNER="${REPO%%/*}"
NAME="${REPO##*/}"
PROJECT_NUMBER="${GH_PROJECT_NUMBER:-}"

log() { printf '==> %s\n' "$*"; }
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

command -v gh >/dev/null || die "gh CLI not found"
command -v jq >/dev/null || die "jq not found"

gh auth status -h github.com >/dev/null 2>&1 || die "Run: gh auth login -h github.com"

log "Setting repository topics on ${REPO}"
gh repo edit "${REPO}" \
  --add-topic mcp \
  --add-topic ibm-power \
  --add-topic hmc \
  --add-topic lpar \
  --add-topic python \
  --add-topic opentelemetry \
  --add-topic ai-agent

create_milestone() {
  local title="$1"
  local description="$2"
  if gh api "repos/${REPO}/milestones" --jq ".[].title" | grep -Fxq "${title}"; then
    log "Milestone exists: ${title}"
  else
    log "Creating milestone: ${title}"
    gh api "repos/${REPO}/milestones" -f title="${title}" -f description="${description}" >/dev/null
  fi
}

log "Creating Phase B–I milestones"
create_milestone "Phase B — Read-path excellence" \
  "LPAR/PCM normalization, firmware validation, correlation headers, retry tuning. See TODO.md Phase B."
create_milestone "Phase C — Write-path execution" \
  "Real HMC mutation payloads, integration tests, idempotency, write_audit sink wiring. See TODO.md Phase C."
create_milestone "Phase D — Transport & deployment" \
  "Streamable HTTP hardening, containers, async httpx client. See TODO.md Phase D."
create_milestone "Phase E — Observability export" \
  "OpenTelemetry, traceparent, SLIs, log shipping. See TODO.md Phase E."
create_milestone "Phase F — Agent ergonomics" \
  "Tool descriptions, pagination, guardrail hints for agents. See TODO.md Phase F."
create_milestone "Phase G — LangGraph / orchestration" \
  "LangGraph CI smoke, HTTP transport examples. See TODO.md Phase G."
create_milestone "Phase H — Security & compliance" \
  "Threat model, vault secrets, SBOM, security CI. See TODO.md Phase H."
create_milestone "Phase I — Release engineering" \
  "PyPI OIDC, semver policy, CHANGELOG discipline. See TODO.md Phase I."

milestone_number() {
  local title="$1"
  gh api "repos/${REPO}/milestones?state=all&per_page=100" \
    --jq ".[] | select(.title==\"${title}\") | .number" | head -1
}

guess_milestone_title() {
  local title="$1"
  local body="$2"
  local combined
  combined="$(printf '%s %s' "${title}" "${body}" | tr '[:upper:]' '[:lower:]')"

  if [[ "${combined}" =~ (pypi|release|changelog|semver|publish|tag) ]]; then
    echo "Phase I — Release engineering"
  elif [[ "${combined}" =~ (secret|audit|security|sbom|threat|codecov|dependabot|conduct) ]]; then
    echo "Phase H — Security & compliance"
  elif [[ "${combined}" =~ (langgraph|orchestrat) ]]; then
    echo "Phase G — LangGraph / orchestration"
  elif [[ "${combined}" =~ (pagination|tool.desc|ergonom|schema.constraint|guardrail.hint) ]]; then
    echo "Phase F — Agent ergonomics"
  elif [[ "${combined}" =~ (opentelemetry|otel|telemetry|traceparent|fluent|vector|sli) ]]; then
    echo "Phase E — Observability export"
  elif [[ "${combined}" =~ (async|helm|kubernetes|container|streamable.http|mtls|readiness) ]]; then
    echo "Phase D — Transport & deployment"
  elif [[ "${combined}" =~ (write|start_lpar|stop_lpar|create_lpar|mutation|execute|idempot) ]]; then
    echo "Phase C — Write-path execution"
  elif [[ "${combined}" =~ (read|lpar|pcm|firmware|correlation|retry|atom|uom|capacity) ]]; then
    echo "Phase B — Read-path excellence"
  else
    echo "Phase B — Read-path excellence"
  fi
}

guess_priority() {
  local title="$1"
  local body="$2"
  local combined
  combined="$(printf '%s %s' "${title}" "${body}" | tr '[:upper:]' '[:lower:]')"

  if [[ "${combined}" =~ (security|secret|write.path|guardrail|credential|ssrf) ]]; then
    echo "P0 — Critical"
  elif [[ "${combined}" =~ (release|pypi|breaking|regression) ]]; then
    echo "P1 — High"
  elif [[ "${combined}" =~ (placeholder|docs|documentation|nice.to.have) ]]; then
    echo "P3 — Low"
  else
    echo "P2 — Medium"
  fi
}

guess_effort() {
  local title="$1"
  local body="$2"
  local combined
  combined="$(printf '%s %s' "${title}" "${body}" | tr '[:upper:]' '[:lower:]')"

  if [[ "${combined}" =~ (threat.model|async.transport|opentelemetry|integration.test|helm) ]]; then
    echo "L — Large"
  elif [[ "${combined}" =~ (fixture|doc|topic|template|workflow|ci) ]]; then
    echo "S — Small"
  else
    echo "M — Medium"
  fi
}

log "Assigning milestones to open issues"
issues_json="$(gh issue list --repo "${REPO}" --state open --limit 100 --json number,title,body,milestone)"
issue_count="$(echo "${issues_json}" | jq 'length')"
log "Found ${issue_count} open issue(s)"

echo "${issues_json}" | jq -c '.[]' | while read -r issue; do
  num="$(echo "${issue}" | jq -r '.number')"
  title="$(echo "${issue}" | jq -r '.title')"
  body="$(echo "${issue}" | jq -r '.body // ""')"
  current_ms="$(echo "${issue}" | jq -r '.milestone.title // empty')"

  ms_title="$(guess_milestone_title "${title}" "${body}")"
  if [[ -n "${current_ms}" ]]; then
    log "Issue #${num}: keeping milestone ${current_ms}"
    ms_title="${current_ms}"
  fi

  ms_num="$(milestone_number "${ms_title}")"
  if [[ -z "${ms_num}" ]]; then
    log "Issue #${num}: no milestone number for ${ms_title}, skipping"
    continue
  fi

  gh api "repos/${REPO}/issues/${num}" -X PATCH -f milestone="${ms_num}" >/dev/null
  log "Issue #${num}: ${title} → ${ms_title}"
done

if [[ -z "${PROJECT_NUMBER}" ]]; then
  log "GH_PROJECT_NUMBER not set — skipping project board triage"
  log "List projects: gh project list --owner ${OWNER}"
  log "Then: export GH_PROJECT_NUMBER=<N> && $0"
  exit 0
fi

log "Project board triage (project #${PROJECT_NUMBER})"

PROJECT_ID="$(gh api graphql -f query='
  query($owner:String!, $number:Int!) {
  user(login:$owner) { projectV2(number:$number) { id title } }
  organization(login:$owner) { projectV2(number:$number) { id title } }
}' -f owner="${OWNER}" -F number="${PROJECT_NUMBER}" \
  --jq '(.data.user.projectV2 // .data.organization.projectV2).id' 2>/dev/null || true)"

if [[ -z "${PROJECT_ID}" || "${PROJECT_ID}" == "null" ]]; then
  PROJECT_ID="$(gh api graphql -f query='
    query($owner:String!, $number:Int!) {
      organization(login:$owner) { projectV2(number:$number) { id } }
    }' -f owner="${OWNER}" -F number="${PROJECT_NUMBER}" --jq '.data.organization.projectV2.id' 2>/dev/null || true)"
fi

[[ -n "${PROJECT_ID}" && "${PROJECT_ID}" != "null" ]] || die "Could not resolve project V2 id for ${OWNER} #${PROJECT_NUMBER}"

field_ids() {
  gh api graphql -f query='
    query($project:ID!) {
      node(id:$project) {
        ... on ProjectV2 {
          fields(first:50) {
            nodes {
              ... on ProjectV2Field { id name }
              ... on ProjectV2SingleSelectField { id name options { id name } }
            }
          }
        }
      }
    }' -f project="${PROJECT_ID}"
}

fields_json="$(field_ids)"
priority_field="$(echo "${fields_json}" | jq -r '.data.node.fields.nodes[] | select(.name=="Priority") | .id' | head -1)"
effort_field="$(echo "${fields_json}" | jq -r '.data.node.fields.nodes[] | select(.name=="Effort") | .id' | head -1)"

priority_option() {
  local label="$1"
  echo "${fields_json}" | jq -r --arg l "${label}" \
    '.data.node.fields.nodes[] | select(.name=="Priority") | .options[]? | select(.name==$l) | .id' | head -1
}

effort_option() {
  local label="$1"
  echo "${fields_json}" | jq -r --arg l "${label}" \
    '.data.node.fields.nodes[] | select(.name=="Effort") | .options[]? | select(.name==$l) | .id' | head -1
}

if [[ -z "${priority_field}" || -z "${effort_field}" ]]; then
  die "Project must have single-select fields named Priority and Effort. Create them in the board UI first."
fi

echo "${issues_json}" | jq -c '.[]' | while read -r issue; do
  num="$(echo "${issue}" | jq -r '.number')"
  title="$(echo "${issue}" | jq -r '.title')"
  body="$(echo "${issue}" | jq -r '.body // ""')"
  priority="$(guess_priority "${title}" "${body}")"
  effort="$(guess_effort "${title}" "${body}")"
  prio_opt="$(priority_option "${priority}")"
  eff_opt="$(effort_option "${effort}")"

  [[ -n "${prio_opt}" ]] || prio_opt="$(priority_option "P2 — Medium")"
  [[ -n "${eff_opt}" ]] || eff_opt="$(effort_option "M — Medium")"

  item_id="$(gh api graphql -f query='
    query($owner:String!, $repo:String!, $number:Int!) {
      repository(owner:$owner, name:$repo) {
        issue(number:$number) { id }
      }
    }' -f owner="${OWNER}" -f repo="${NAME}" -F number="${num}" --jq '.data.repository.issue.id')"

  add_resp="$(gh api graphql -f query='
    mutation($project:ID!, $content:ID!) {
      addProjectV2ItemById(input:{projectId:$project contentId:$content}) {
        item { id }
      }
    }' -f project="${PROJECT_ID}" -f content="${item_id}" 2>/dev/null || true)"

  proj_item="$(echo "${add_resp}" | jq -r '.data.addProjectV2ItemById.item.id // empty')"
  if [[ -z "${proj_item}" ]]; then
    proj_item="$(gh api graphql -f query='
      query($project:ID!) {
        node(id:$project) {
          ... on ProjectV2 {
            items(first:100) {
              nodes { id content { ... on Issue { number } } }
            }
          }
        }
      }' -f project="${PROJECT_ID}" --jq ".data.node.items.nodes[] | select(.content.number==${num}) | .id" | head -1)"
  fi

  [[ -n "${proj_item}" ]] || { log "Issue #${num}: could not add/find project item, skipping fields"; continue; }

  gh api graphql -f query='
    mutation($project:ID!, $item:ID!, $field:ID!, $option:String!) {
      updateProjectV2ItemFieldValue(input:{
        projectId:$project itemId:$item fieldId:$field
        value:{ singleSelectOptionId:$option }
      }) { projectV2Item { id } }
    }' -f project="${PROJECT_ID}" -f item="${proj_item}" -f field="${priority_field}" -f option="${prio_opt}" >/dev/null

  gh api graphql -f query='
    mutation($project:ID!, $item:ID!, $field:ID!, $option:String!) {
      updateProjectV2ItemFieldValue(input:{
        projectId:$project itemId:$item fieldId:$field
        value:{ singleSelectOptionId:$option }
      }) { projectV2Item { id } }
    }' -f project="${PROJECT_ID}" -f item="${proj_item}" -f field="${effort_field}" -f option="${eff_opt}" >/dev/null

  log "Issue #${num}: project Priority=${priority} Effort=${effort}"
done

log "Done."
