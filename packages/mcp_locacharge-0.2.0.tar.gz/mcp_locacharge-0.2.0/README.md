# mcp-locacharge

MCP server for LocaCharge — manage properties, charges, roommates and settlements via AI assistants (Claude, ChatGPT, Cursor...).

## Installation

```bash
uvx mcp-locacharge
# or
pip install mcp-locacharge
```

## Configuration

### Claude Code / Cursor

Add to your MCP settings:

```json
{
  "locacharge": {
    "command": "uvx",
    "args": ["mcp-locacharge"],
    "env": {
      "LOCACHARGE_API_KEY": "lc_tok_your_token_here",
      "LOCACHARGE_URL": "https://locacharge.fr"
    }
  }
}
```

### ChatGPT (via SSE)

ChatGPT connects via remote SSE. Start the MCP server in SSE mode:

```bash
LOCACHARGE_API_KEY=lc_tok_xxx \
LOCACHARGE_URL=https://locacharge.fr \
LOCACHARGE_TRANSPORT=sse \
LOCACHARGE_SSE_PORT=8001 \
mcp-locacharge
```

Then in ChatGPT:
1. Settings > Apps & Connectors > Developer Mode > ON
2. Connectors > Create
3. Name: LocaCharge
4. URL: `https://your-domain.fr:8001/sse`
5. Authentication: API Key

### Get your API key

1. Log in to LocaCharge
2. Go to Profile > API Keys
3. Click "New key"
4. Copy the token (shown only once)

## Available tools

### Properties
- `list_properties` — List all your properties
- `get_property` — Property details with roommates and charges
- `create_property` — Create a new property
- `update_property` — Update a property
- `delete_property` — Delete a property

### Roommates
- `list_roommates` — List roommates for a property
- `add_roommate` — Add a roommate
- `update_roommate` — Update or set departure date

### Charges
- `list_expense_categories` — List expense categories
- `add_expense_category` — Create a category
- `list_charges` — List monthly charges
- `set_charge` — Set a monthly charge amount

### Payments
- `list_payments` — List roommate payments
- `set_payment` — Record a payment

### Settlements
- `list_settlements` — List saved settlements
- `get_settlement` — Settlement details

### Admin (requires admin scope)
- `admin_list_users` — List all users
- `admin_get_user` — User details
- `admin_revenue` — Revenue metrics (MRR, ARR, churn)

## License

MIT
