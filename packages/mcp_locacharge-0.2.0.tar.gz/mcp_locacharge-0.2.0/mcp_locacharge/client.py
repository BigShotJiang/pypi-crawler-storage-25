"""HTTP client for LocaCharge REST API."""
import os

import httpx


class LocaChargeClient:
    """Async HTTP client wrapping the LocaCharge /api/v1/ endpoints."""

    def __init__(self):
        self.base_url = os.environ.get('LOCACHARGE_URL', 'https://locacharge.fr').rstrip('/')
        self.api_key = os.environ.get('LOCACHARGE_API_KEY', '')
        if not self.api_key:
            raise ValueError("LOCACHARGE_API_KEY environment variable is required")
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
        }

    @classmethod
    def from_token(cls, token, base_url=None):
        """Create a client for a specific user token (SSE per-connection)."""
        instance = cls.__new__(cls)
        instance.base_url = (base_url or os.environ.get('LOCACHARGE_URL', 'https://locacharge.fr')).rstrip('/')
        instance.api_key = token
        instance.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        }
        return instance

    async def request(self, method: str, path: str, data: dict = None) -> dict:
        """Send an HTTP request to the API and return the parsed JSON response."""
        async with httpx.AsyncClient(timeout=30) as http:
            response = await http.request(
                method,
                f"{self.base_url}/api/v1{path}",
                headers=self.headers,
                json=data,
            )
            response.raise_for_status()
            return response.json()

    async def get(self, path: str) -> dict:
        return await self.request('GET', path)

    async def post(self, path: str, data: dict) -> dict:
        return await self.request('POST', path, data)

    async def put(self, path: str, data: dict) -> dict:
        return await self.request('PUT', path, data)

    async def delete(self, path: str) -> dict:
        return await self.request('DELETE', path)
