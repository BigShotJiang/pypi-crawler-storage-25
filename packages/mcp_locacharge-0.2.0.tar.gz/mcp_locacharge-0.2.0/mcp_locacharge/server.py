"""LocaCharge MCP Server — stdio and SSE transports."""
import asyncio
import json
import logging
import os

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .client import LocaChargeClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('mcp_locacharge')

app = Server("locacharge")
client: LocaChargeClient | None = None
user_scope: str = "owner"


async def init_client():
    """Initialize the API client and discover user scope.

    In SSE mode without LOCACHARGE_API_KEY, skip initialization —
    the token comes from each client's Authorization header.
    """
    global client, user_scope
    api_key = os.environ.get('LOCACHARGE_API_KEY', '')
    if not api_key:
        client = None
        user_scope = 'owner'
        logger.info("init_client: no LOCACHARGE_API_KEY — SSE per-connection mode")
        return
    client = LocaChargeClient()
    logger.info(f"init_client: connecting to {client.base_url}")
    try:
        me = await client.get('/auth/me')
        user_scope = me.get('scope', 'owner')
        logger.info(f"init_client: OK, scope={user_scope}")
    except Exception as e:
        user_scope = 'owner'
        logger.warning(f"init_client: /auth/me failed: {e}")


# =============================================================================
# Tool definitions
# =============================================================================

OWNER_TOOLS = [
    # Properties
    Tool(
        name="list_properties",
        description="Lister tous vos biens immobiliers",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="get_property",
        description="Détail d'un bien (locataires, catégories, charges)",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string", "description": "ID du bien"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="create_property",
        description="Créer un nouveau bien",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "address": {"type": "string"},
                "max_roommates": {"type": "integer", "default": 1},
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="update_property",
        description="Modifier un bien existant",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "name": {"type": "string"},
                "address": {"type": "string"},
                "max_roommates": {"type": "integer"},
            },
            "required": ["property_id"],
        },
    ),
    Tool(
        name="delete_property",
        description="Supprimer un bien et toutes ses données",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),

    # Roommates
    Tool(
        name="list_roommates",
        description="Lister les locataires d'un bien",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="add_roommate",
        description="Ajouter un locataire à un bien",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "email": {"type": "string"},
                "arrival_date": {"type": "string", "description": "YYYY-MM-DD"},
            },
            "required": ["property_id", "first_name", "last_name", "arrival_date"],
        },
    ),
    Tool(
        name="update_roommate",
        description="Modifier un locataire",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "roommate_id": {"type": "string"},
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "email": {"type": "string"},
                "departure_date": {"type": "string", "description": "YYYY-MM-DD pour marquer le départ"},
            },
            "required": ["property_id", "roommate_id"],
        },
    ),

    # Expense categories
    Tool(
        name="list_expense_categories",
        description="Lister les catégories de charges d'un bien (Eau, Électricité...)",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="add_expense_category",
        description="Créer une catégorie de charges",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "name": {"type": "string", "description": "Nom de la catégorie (Eau, Électricité, Internet...)"},
            },
            "required": ["property_id", "name"],
        },
    ),
    Tool(
        name="delete_expense_category",
        description="Supprimer une catégorie de charges",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "category_id": {"type": "string"},
            },
            "required": ["property_id", "category_id"],
        },
    ),

    # Monthly charges
    Tool(
        name="list_charges",
        description="Lister les montants mensuels d'une catégorie de charges",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "category_id": {"type": "string"},
            },
            "required": ["property_id", "category_id"],
        },
    ),
    Tool(
        name="set_charge",
        description="Saisir ou modifier le montant d'une charge pour un mois donné",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "category_id": {"type": "string"},
                "month": {"type": "integer", "minimum": 1, "maximum": 12},
                "year": {"type": "integer"},
                "amount": {"type": "number"},
                "note": {"type": "string"},
            },
            "required": ["property_id", "category_id", "month", "year", "amount"],
        },
    ),

    # Payments
    Tool(
        name="list_payments",
        description="Lister les versements (provisions) d'un locataire",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "roommate_id": {"type": "string"},
            },
            "required": ["property_id", "roommate_id"],
        },
    ),
    Tool(
        name="set_payment",
        description="Saisir ou modifier un versement pour un mois donné",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "roommate_id": {"type": "string"},
                "month": {"type": "integer", "minimum": 1, "maximum": 12},
                "year": {"type": "integer"},
                "amount": {"type": "number"},
            },
            "required": ["property_id", "roommate_id", "month", "year", "amount"],
        },
    ),

    # Settlements
    Tool(
        name="list_settlements",
        description="Lister les régularisations enregistrées d'un bien",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="get_settlement",
        description="Détail d'une régularisation",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "settlement_id": {"type": "string"},
            },
            "required": ["property_id", "settlement_id"],
        },
    ),

    # Rent
    Tool(
        name="get_rent_config",
        description="Configuration des loyers d'un bien (montants, jour d'échéance)",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="list_rent_payments",
        description="Lister les échéances de loyer d'un bien",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),

    # Interventions
    Tool(
        name="list_interventions",
        description="Lister les interventions (travaux) d'un bien",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),
    Tool(
        name="create_intervention",
        description="Créer une intervention (travaux) sur un bien",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "title": {"type": "string"},
                "intervention_type": {"type": "string", "description": "plomberie|electricite|peinture|menuiserie|nettoyage|autre"},
                "status": {"type": "string", "description": "planned|in_progress|completed|cancelled"},
                "planned_date": {"type": "string", "description": "YYYY-MM-DD"},
                "provider": {"type": "string"},
                "estimated_cost": {"type": "number"},
                "description": {"type": "string"},
            },
            "required": ["property_id", "title"],
        },
    ),

    # Vacancy
    Tool(
        name="get_vacancy",
        description="Vacances locatives d'un bien (chambres, occupation)",
        inputSchema={
            "type": "object",
            "properties": {"property_id": {"type": "string"}},
            "required": ["property_id"],
        },
    ),

    # Activity
    Tool(
        name="list_activity",
        description="Journal d'activité récent (50 derniers événements)",
        inputSchema={"type": "object", "properties": {}},
    ),

    # Settlement preview
    Tool(
        name="calculate_settlement",
        description="Calculer une régularisation (aperçu, non enregistré)",
        inputSchema={
            "type": "object",
            "properties": {
                "property_id": {"type": "string"},
                "start_date": {"type": "string", "description": "YYYY-MM-DD"},
                "end_date": {"type": "string", "description": "YYYY-MM-DD"},
            },
            "required": ["property_id", "start_date", "end_date"],
        },
    ),

    # Account
    Tool(
        name="whoami",
        description="Informations sur votre compte LocaCharge",
        inputSchema={"type": "object", "properties": {}},
    ),
]

ADMIN_TOOLS = [
    Tool(
        name="admin_list_users",
        description="[Admin] Lister tous les utilisateurs",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="admin_get_user",
        description="[Admin] Détail d'un utilisateur",
        inputSchema={
            "type": "object",
            "properties": {"user_id": {"type": "string"}},
            "required": ["user_id"],
        },
    ),
    Tool(
        name="admin_revenue",
        description="[Admin] Métriques financières (MRR, ARR, abonnés, churn)",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="admin_list_all_properties",
        description="[Admin] Lister tous les biens de tous les utilisateurs",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="admin_audit_log",
        description="[Admin] Journal d'audit (événements admin)",
        inputSchema={"type": "object", "properties": {}},
    ),
]


@app.list_tools()
async def list_tools():
    tools = list(OWNER_TOOLS)
    if user_scope == 'admin':
        tools.extend(ADMIN_TOOLS)
    return tools


@app.call_tool()
async def call_tool(name: str, arguments: dict):
    logger.info(f"call_tool: {name}, args={arguments}")
    try:
        result = await _dispatch(name, arguments)
        logger.info(f"call_tool result: {name} → {str(result)[:200]}")
        return [TextContent(
            type="text",
            text=json.dumps(result, ensure_ascii=False, indent=2, default=str),
        )]
    except httpx.HTTPStatusError as e:
        error_body = e.response.text
        logger.error(f"call_tool HTTP error: {name} → {e.response.status_code}: {error_body[:200]}")
        return [TextContent(type="text", text=f"Erreur API ({e.response.status_code}): {error_body}")]
    except Exception as e:
        logger.error(f"call_tool exception: {name} → {type(e).__name__}: {e}")
        return [TextContent(type="text", text=f"Erreur: {e}")]


async def _dispatch(name: str, args: dict) -> dict:
    """Route tool calls to API endpoints."""
    if client is None:
        raise RuntimeError(
            "API client not initialized — no Bearer token received on SSE connection"
        )

    # Account
    if name == 'whoami':
        return await client.get('/auth/me')

    # Properties
    if name == 'list_properties':
        return await client.get('/properties')
    if name == 'get_property':
        return await client.get(f"/properties/{args['property_id']}")
    if name == 'create_property':
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.post('/properties', payload)
    if name == 'update_property':
        pid = args['property_id']
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.put(f"/properties/{pid}", payload)
    if name == 'delete_property':
        return await client.delete(f"/properties/{args['property_id']}")

    # Roommates
    if name == 'list_roommates':
        return await client.get(f"/properties/{args['property_id']}/roommates")
    if name == 'add_roommate':
        pid = args['property_id']
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.post(f"/properties/{pid}/roommates", payload)
    if name == 'update_roommate':
        pid = args['property_id']
        rid = args['roommate_id']
        payload = {k: v for k, v in args.items() if k not in ('property_id', 'roommate_id')}
        return await client.put(f"/properties/{pid}/roommates/{rid}", payload)

    # Expense categories
    if name == 'list_expense_categories':
        return await client.get(f"/properties/{args['property_id']}/categories")
    if name == 'add_expense_category':
        pid = args['property_id']
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.post(f"/properties/{pid}/categories", payload)
    if name == 'delete_expense_category':
        return await client.delete(
            f"/properties/{args['property_id']}/categories/{args['category_id']}"
        )

    # Charges
    if name == 'list_charges':
        return await client.get(
            f"/properties/{args['property_id']}/categories/{args['category_id']}/charges"
        )
    if name == 'set_charge':
        pid = args['property_id']
        cid = args['category_id']
        payload = {k: v for k, v in args.items() if k not in ('property_id', 'category_id')}
        return await client.post(f"/properties/{pid}/categories/{cid}/charges", payload)

    # Payments
    if name == 'list_payments':
        return await client.get(
            f"/properties/{args['property_id']}/roommates/{args['roommate_id']}/payments"
        )
    if name == 'set_payment':
        pid = args['property_id']
        rid = args['roommate_id']
        payload = {k: v for k, v in args.items() if k not in ('property_id', 'roommate_id')}
        return await client.post(f"/properties/{pid}/roommates/{rid}/payments", payload)

    # Settlements
    if name == 'list_settlements':
        return await client.get(f"/properties/{args['property_id']}/settlements")
    if name == 'get_settlement':
        return await client.get(
            f"/properties/{args['property_id']}/settlements/{args['settlement_id']}"
        )

    # Rent
    if name == 'get_rent_config':
        return await client.get(f"/properties/{args['property_id']}/rent/config")
    if name == 'list_rent_payments':
        return await client.get(f"/properties/{args['property_id']}/rent/payments")

    # Interventions
    if name == 'list_interventions':
        return await client.get(f"/properties/{args['property_id']}/interventions")
    if name == 'create_intervention':
        pid = args['property_id']
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.post(f"/properties/{pid}/interventions", payload)

    # Vacancy
    if name == 'get_vacancy':
        return await client.get(f"/properties/{args['property_id']}/vacancy")

    # Activity
    if name == 'list_activity':
        return await client.get('/activity')

    # Settlement preview
    if name == 'calculate_settlement':
        pid = args['property_id']
        payload = {k: v for k, v in args.items() if k != 'property_id'}
        return await client.post(f"/properties/{pid}/settlement/calculate", payload)

    # Admin
    if name == 'admin_list_users':
        return await client.get('/admin/users')
    if name == 'admin_get_user':
        return await client.get(f"/admin/users/{args['user_id']}")
    if name == 'admin_revenue':
        return await client.get('/admin/revenue')
    if name == 'admin_list_all_properties':
        return await client.get('/admin/properties')
    if name == 'admin_audit_log':
        return await client.get('/admin/audit-log')

    raise ValueError(f"Unknown tool: {name}")


def run_stdio():
    """stdio transport — for Claude Code, Cursor."""
    async def _run():
        await init_client()
        async with stdio_server() as (read_stream, write_stream):
            await app.run(read_stream, write_stream, app.create_initialization_options())

    asyncio.run(_run())


def run_sse():
    """SSE transport — for ChatGPT, remote clients."""
    import uvicorn
    from contextlib import asynccontextmanager
    from mcp.server.sse import SseServerTransport
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.routing import Route

    sse_transport = SseServerTransport("/messages")

    # Raw ASGI handlers — Starlette's Route wraps plain functions with
    # request_response() which expects a Response return value. MCP SSE
    # handlers write directly to the ASGI send() callback and return None,
    # which crashes. Using callable classes bypasses the wrapping:
    # inspect.isfunction(instance) is False → Route sets self.app = endpoint.

    class SSEHandler:
        """Handle both SSE (GET) and Streamable HTTP (POST) on /sse."""

        async def __call__(self, scope, receive, send):
            request = Request(scope, receive, send)

            # POST with JSON → delegate to Streamable HTTP handler
            if request.method == 'POST':
                content_type = request.headers.get('content-type', '')
                if 'json' in content_type:
                    handler = StreamableHTTPHandler()
                    return await handler(scope, receive, send)

            # GET → standard SSE transport
            global client, user_scope

            # Extract Bearer token from Authorization header
            auth_header = request.headers.get('authorization', '')
            if auth_header.startswith('Bearer '):
                token = auth_header[7:]
                client = LocaChargeClient.from_token(token)
                try:
                    me = await client.get('/auth/me')
                    user_scope = me.get('scope', 'owner')
                    logger.info(f"SSE auth OK: scope={user_scope}, user={me.get('email', '?')}")
                except Exception as e:
                    user_scope = 'owner'
                    logger.warning(f"SSE /auth/me failed: {e}")
            else:
                logger.info("SSE connection without Bearer token")

            async with sse_transport.connect_sse(scope, receive, send) as streams:
                await app.run(
                    streams[0], streams[1], app.create_initialization_options()
                )

    class MessagesHandler:
        async def __call__(self, scope, receive, send):
            await sse_transport.handle_post_message(scope, receive, send)

    # OAuth proxy routes — claude.ai hits mcp.* subdomain for these,
    # but they are served by Django on the main domain (port 8000).
    from starlette.responses import RedirectResponse, JSONResponse

    django_base = os.environ.get('LOCACHARGE_URL', 'http://localhost:8000')

    async def proxy_authorize(request):
        """Redirect /authorize to Django on the main domain.

        Must be a redirect (not proxy) so the user sees the consent page
        on the main domain where Django session cookies work.
        """
        # Build public-facing main domain URL (strip mcp. prefix)
        host = request.headers.get('host', '')
        scheme = 'https' if request.headers.get('x-forwarded-proto') == 'https' else 'http'
        if host.startswith('mcp.'):
            main_host = host[4:]
        else:
            # Local dev: mcp runs on port 8001, Django on 8000
            main_host = host.replace(':8001', ':8000') if ':8001' in host else host
        main_base = f"{scheme}://{main_host}"
        query_string = request.url.query
        target = f"{main_base}/authorize?{query_string}" if query_string else f"{main_base}/authorize"
        logger.info(f"OAuth proxy: /authorize → {target}")
        return RedirectResponse(target)

    def _proxy_headers(request):
        """Build headers for proxied requests to Django.

        Strips the mcp. subdomain prefix so Django ALLOWED_HOSTS
        sees the main domain, and preserves X-Forwarded-Proto.
        """
        host = request.headers.get('x-forwarded-host', request.headers.get('host', ''))
        if host.startswith('mcp.'):
            host = host[4:]
        return {
            'Host': host,
            'X-Forwarded-Proto': request.headers.get('x-forwarded-proto', 'https'),
        }

    def _safe_json_response(resp):
        """Return JSONResponse, falling back to 502 if body is not JSON."""
        try:
            return JSONResponse(resp.json(), status_code=resp.status_code)
        except Exception:
            logger.warning(f"OAuth proxy: non-JSON response ({resp.status_code}): {resp.text[:200]}")
            return JSONResponse(
                {'error': 'proxy_error', 'message': resp.text[:200]},
                status_code=502,
            )

    async def proxy_token(request):
        """Proxy POST /token to Django (backend-to-backend, no redirect)."""
        body = await request.body()
        headers = _proxy_headers(request)
        headers['Content-Type'] = request.headers.get('content-type', 'application/x-www-form-urlencoded')
        logger.info(f"OAuth proxy: /token → {django_base}/token")
        async with httpx.AsyncClient() as http:
            resp = await http.post(f"{django_base}/token", content=body, headers=headers)
        return _safe_json_response(resp)

    def _mcp_base_url(request):
        """Build the public MCP base URL from the incoming request."""
        host = request.headers.get('x-forwarded-host', request.headers.get('host', ''))
        scheme = request.headers.get('x-forwarded-proto', 'https')
        return f"{scheme}://{host}"

    async def proxy_well_known_resource(request):
        """Proxy /.well-known/oauth-protected-resource, rewrite URLs to MCP domain."""
        logger.info(f"OAuth proxy: /.well-known/oauth-protected-resource → {django_base}")
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                f"{django_base}/.well-known/oauth-protected-resource",
                headers=_proxy_headers(request),
            )
        try:
            data = resp.json()
            mcp_base = _mcp_base_url(request)
            data['resource'] = f"{mcp_base}/sse"
            data['authorization_servers'] = [mcp_base]
            return JSONResponse(data)
        except Exception:
            return _safe_json_response(resp)

    async def proxy_well_known_server(request):
        """Proxy /.well-known/oauth-authorization-server, rewrite URLs to MCP domain."""
        logger.info(f"OAuth proxy: /.well-known/oauth-authorization-server → {django_base}")
        async with httpx.AsyncClient() as http:
            resp = await http.get(
                f"{django_base}/.well-known/oauth-authorization-server",
                headers=_proxy_headers(request),
            )
        try:
            data = resp.json()
            mcp_base = _mcp_base_url(request)
            data['issuer'] = mcp_base
            data['authorization_endpoint'] = f"{mcp_base}/authorize"
            data['token_endpoint'] = f"{mcp_base}/token"
            return JSONResponse(data)
        except Exception:
            return _safe_json_response(resp)

    async def handle_register(request):
        """POST /register — Dynamic Client Registration (DCR).

        Generates client credentials and stores them in Django.
        """
        import secrets as _secrets

        try:
            body = await request.json()
        except Exception:
            return JSONResponse({'error': 'invalid_request'}, status_code=400)

        client_id = f"lc_dyn_{_secrets.token_urlsafe(16)}"
        client_secret = f"lcs_{_secrets.token_urlsafe(32)}"

        # Store in Django
        headers = _proxy_headers(request)
        headers['Content-Type'] = 'application/json'
        async with httpx.AsyncClient() as http:
            resp = await http.post(
                f"{django_base}/oauth/register",
                json={
                    'client_id': client_id,
                    'client_secret': client_secret,
                    'redirect_uris': body.get('redirect_uris', []),
                    'client_name': body.get('client_name', 'ChatGPT'),
                },
                headers=headers,
            )

        if resp.status_code != 201:
            logger.warning(f"DCR: Django registration failed: {resp.status_code} {resp.text[:200]}")
            return _safe_json_response(resp)

        logger.info(f"DCR: registered dynamic client {client_id}")

        return JSONResponse({
            'client_id': client_id,
            'client_secret': client_secret,
            'client_name': body.get('client_name', 'ChatGPT'),
            'redirect_uris': body.get('redirect_uris', []),
            'grant_types': ['authorization_code'],
            'response_types': ['code'],
            'token_endpoint_auth_method': 'client_secret_post',
        }, status_code=201)

    # Streamable HTTP transport — single POST /mcp endpoint for JSON-RPC.
    # ChatGPT and newer MCP clients use this instead of SSE.

    class StreamableHTTPHandler:
        """MCP Streamable HTTP transport — handles JSON-RPC over POST /mcp."""

        async def __call__(self, scope, receive, send):
            request = Request(scope, receive, send)

            if request.method == 'GET':
                # GET /mcp returns server info (health check)
                resp = JSONResponse({
                    'name': 'locacharge',
                    'version': '1.0.0',
                    'transport': 'streamable-http',
                })
                return await resp(scope, receive, send)

            if request.method == 'DELETE':
                # DELETE /mcp — session termination (acknowledge)
                resp = JSONResponse({}, status_code=200)
                return await resp(scope, receive, send)

            if request.method != 'POST':
                resp = JSONResponse({'error': 'method_not_allowed'}, status_code=405)
                return await resp(scope, receive, send)

            # Authenticate via Bearer token
            global client, user_scope
            auth_header = request.headers.get('authorization', '')
            if auth_header.startswith('Bearer '):
                token = auth_header[7:]
                client = LocaChargeClient.from_token(token)
                try:
                    me = await client.get('/auth/me')
                    user_scope = me.get('scope', 'owner')
                except Exception:
                    user_scope = 'owner'

            try:
                body = await request.json()
            except Exception:
                resp = JSONResponse(
                    {'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}, 'id': None},
                    status_code=400,
                )
                return await resp(scope, receive, send)

            method = body.get('method', '')
            req_id = body.get('id')
            params = body.get('params', {})

            logger.info(f"Streamable HTTP: method={method}, id={req_id}")

            try:
                result = await self._handle_method(method, params)
            except Exception as e:
                logger.error(f"Streamable HTTP error: {method} → {e}")
                resp = JSONResponse({
                    'jsonrpc': '2.0',
                    'error': {'code': -32603, 'message': str(e)},
                    'id': req_id,
                })
                return await resp(scope, receive, send)

            # Notifications (no id) get 202 Accepted
            if req_id is None:
                resp = JSONResponse({}, status_code=202)
                return await resp(scope, receive, send)

            resp = JSONResponse({
                'jsonrpc': '2.0',
                'id': req_id,
                'result': result,
            })
            return await resp(scope, receive, send)

        async def _handle_method(self, method, params):
            """Dispatch JSON-RPC method to MCP handler."""
            if method == 'initialize':
                return {
                    'protocolVersion': '2025-03-26',
                    'capabilities': {'tools': {'listChanged': False}},
                    'serverInfo': {'name': 'locacharge', 'version': '1.0.0'},
                }

            if method == 'notifications/initialized':
                return {}

            if method == 'tools/list':
                tools = await list_tools()
                return {'tools': [
                    {
                        'name': t.name,
                        'description': t.description,
                        'inputSchema': t.inputSchema,
                    }
                    for t in tools
                ]}

            if method == 'tools/call':
                name = params.get('name', '')
                arguments = params.get('arguments', {})
                result_contents = await call_tool(name, arguments)
                return {'content': [
                    {'type': c.type, 'text': c.text}
                    for c in result_contents
                ]}

            if method == 'resources/list':
                return {'resources': []}

            if method == 'prompts/list':
                return {'prompts': []}

            if method == 'ping':
                return {}

            raise ValueError(f"Unknown method: {method}")

    async def openid_configuration(request):
        """Serve OpenID Connect discovery (ChatGPT checks this endpoint)."""
        mcp_base = _mcp_base_url(request)
        return JSONResponse({
            'issuer': mcp_base,
            'authorization_endpoint': f'{mcp_base}/authorize',
            'token_endpoint': f'{mcp_base}/token',
            'response_types_supported': ['code'],
            'grant_types_supported': ['authorization_code'],
            'code_challenge_methods_supported': ['S256'],
            'token_endpoint_auth_methods_supported': ['client_secret_post', 'client_secret_basic'],
            'subject_types_supported': ['public'],
        })

    @asynccontextmanager
    async def lifespan(starlette_app):
        await init_client()
        yield

    starlette_app = Starlette(
        routes=[
            Route("/sse", endpoint=SSEHandler()),
            Route("/messages", endpoint=MessagesHandler(), methods=["POST"]),
            Route("/mcp", endpoint=StreamableHTTPHandler()),
            Route("/authorize", endpoint=proxy_authorize),
            Route("/token", endpoint=proxy_token, methods=["POST"]),
            Route("/register", endpoint=handle_register, methods=["POST"]),
            Route("/.well-known/oauth-protected-resource", endpoint=proxy_well_known_resource),
            Route("/.well-known/oauth-protected-resource/{path:path}", endpoint=proxy_well_known_resource),
            Route("/.well-known/oauth-authorization-server", endpoint=proxy_well_known_server),
            Route("/.well-known/oauth-authorization-server/{path:path}", endpoint=proxy_well_known_server),
            Route("/.well-known/openid-configuration", endpoint=openid_configuration),
            Route("/.well-known/openid-configuration/{path:path}", endpoint=openid_configuration),
        ],
        lifespan=lifespan,
    )

    host = os.environ.get('LOCACHARGE_SSE_HOST', '0.0.0.0')
    port = int(os.environ.get('LOCACHARGE_SSE_PORT', '8001'))
    uvicorn.run(starlette_app, host=host, port=port)


def main():
    mode = os.environ.get('LOCACHARGE_TRANSPORT', 'stdio')
    if mode == 'sse':
        run_sse()
    else:
        run_stdio()


if __name__ == "__main__":
    main()
