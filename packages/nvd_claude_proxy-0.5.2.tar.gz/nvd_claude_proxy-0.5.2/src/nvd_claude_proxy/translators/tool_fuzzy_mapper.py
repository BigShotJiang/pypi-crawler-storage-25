"""Fuzzy tool name mapping to correct common model hallucinations.

Ported from claude-code-router's tool repair strategies.
"""

from __future__ import annotations

import difflib


class FuzzyToolMapper:
    """Corrects common model hallucinations of tool names."""

    # Key is hallucinated name (lowercase), Value is the Claude Code tool name.
    STRICT_MAPPINGS = {
        "read": "read_file",
        "write": "write_file",
        "list": "ls",
        "ls": "ls",
        "search": "grep_search",
        "grep": "grep_search",
        "bash": "bash",
        "shell": "bash",
        "edit": "edit_file",
        "replace": "replace_file_content",
        "think": "thinking",
    }

    # Common argument key hallucinations. 
    # Key is tool name (or '*' for all), Value is a map of hallucinated -> real.
    STRICT_ARG_MAPPINGS = {
        "read_file": {
            "path": "file_path",
            "filepath": "file_path",
            "filename": "file_path",
        },
        "write_file": {
            "path": "file_path",
            "filepath": "file_path",
            "filename": "file_path",
            "text": "file_content",
        },
        "ls": {
            "path": "path",
        },
        "grep_search": {
            "query": "query",
            "path": "include_pattern",
        },
    }

    def __init__(self, valid_names: set[str]) -> None:
        self.valid_names = valid_names
        # Lowercase version for easier lookups
        self._lower_to_valid = {n.lower(): n for n in valid_names}

    def map_name(self, name: str) -> str | None:
        """Attempt to map a potentially hallucinated name to a valid one.

        Returns the valid name if a match is found, else None.
        """
        if name in self.valid_names:
            return name

        lower_name = name.lower()

        # 1. Exact case-insensitive match
        if lower_name in self._lower_to_valid:
            return self._lower_to_valid[lower_name]

        # 2. Strict alias mapping
        if lower_name in self.STRICT_MAPPINGS:
            alias = self.STRICT_MAPPINGS[lower_name]
            if alias in self.valid_names:
                return alias

        # 3. Fuzzy matching (difflib)
        matches = difflib.get_close_matches(name, self.valid_names, n=1, cutoff=0.7)
        if matches:
            return matches[0]

        # 4. Prefix/Suffix matching
        for valid in self.valid_names:
            v_lower = valid.lower()
            if lower_name in v_lower or v_lower in lower_name:
                # Only return if it's a "safe" substring match (length check)
                if len(lower_name) > 3 and len(v_lower) > 3:
                    return valid

        return None

    def map_arguments(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Attempt to map hallucinated argument keys to valid ones.
        
        Example: read_file(path="/foo") -> read_file(file_path="/foo")
        """
        if tool_name not in self.STRICT_ARG_MAPPINGS:
            return arguments
            
        mapping = self.STRICT_ARG_MAPPINGS[tool_name]
        new_args = {}
        for k, v in arguments.items():
            if k in mapping:
                new_args[mapping[k]] = v
            else:
                new_args[k] = v
        return new_args
