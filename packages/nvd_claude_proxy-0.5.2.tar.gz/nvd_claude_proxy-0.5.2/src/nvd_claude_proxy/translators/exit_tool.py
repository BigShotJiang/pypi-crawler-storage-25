"""ExitTool injection for models that don't natively support tool calling well.

Ported from claude-code-router's ``tooluse.transformer.ts``.

When enabled, this module:
1. Injects an ``ExitTool`` into the tool list.
2. Adds a system reminder for tool mode discipline.
3. Strips ExitTool calls from responses, converting them back to text.

Enable via ``exit_tool_enabled: true`` in model config.
"""

from __future__ import annotations

import json
from typing import Any

import structlog

_log = structlog.get_logger("nvd_claude_proxy.exit_tool")

EXIT_TOOL_NAME = "ExitTool"

EXIT_TOOL_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": EXIT_TOOL_NAME,
        "description": (
            "Use this tool when you are in tool mode and have completed the task. "
            "This is the only valid way to exit tool mode.\n"
            "IMPORTANT: Before using this tool, ensure that none of the available "
            "tools are applicable to the current task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "response": {
                    "type": "string",
                    "description": "Your response will be forwarded to the user exactly as returned.",
                },
            },
            "required": ["response"],
        },
    },
}

_SYSTEM_REMINDER = (
    "<system-reminder>Tool mode is active. The user expects you to proactively "
    "execute the most suitable tool to help complete the task.\n"
    "Before invoking a tool, you must carefully evaluate whether it matches the "
    "current task. If no available tool is appropriate for the task, you MUST call "
    "the `ExitTool` to exit tool mode.\n"
    "Always prioritize completing the user's task effectively and efficiently by "
    "using tools whenever appropriate.</system-reminder>"
)


def inject_exit_tool(
    openai_messages: list[dict],
    openai_tools: list[dict],
) -> tuple[list[dict], list[dict]]:
    """Inject ExitTool into tool list and add system reminder.

    Returns (modified_messages, modified_tools).
    Only modifies if ``openai_tools`` is non-empty.
    """
    if not openai_tools:
        return openai_messages, openai_tools

    modified_tools = list(openai_tools)
    modified_tools.append(EXIT_TOOL_SCHEMA)

    modified_messages = list(openai_messages)
    modified_messages.append({"role": "system", "content": _SYSTEM_REMINDER})

    _log.debug("exit_tool.injected", tool_count=len(modified_tools))
    return modified_messages, modified_tools


def strip_exit_tool_from_response(response: dict) -> dict:
    """Convert ExitTool calls in a non-streaming response back to text content."""
    choices = response.get("choices") or [{}]
    choice = choices[0]
    msg = choice.get("message") or {}
    tool_calls = msg.get("tool_calls") or []

    if not tool_calls:
        return response

    first_tc = tool_calls[0]
    fn = first_tc.get("function") or {}
    if fn.get("name") != EXIT_TOOL_NAME:
        return response

    try:
        args = json.loads(fn.get("arguments", "{}"))
        text = args.get("response", "")
    except (json.JSONDecodeError, ValueError):
        text = fn.get("arguments", "")

    msg["content"] = text
    if "tool_calls" in msg:
        del msg["tool_calls"]

    _log.debug("exit_tool.stripped_from_response")
    return response


class ExitToolStreamState:
    """Tracks ExitTool state during streaming."""

    def __init__(self) -> None:
        self._exit_tool_index: int = -1
        self._exit_tool_response: str = ""
        self._exit_tool_detected: bool = False

    @property
    def is_active(self) -> bool:
        return self._exit_tool_index >= 0

    def process_chunk(self, chunk: dict) -> dict | None:
        """Process one OpenAI streaming chunk.

        Returns None if chunk was absorbed (part of ExitTool).
        Returns the chunk (possibly modified) if it should be forwarded.
        """
        choices = chunk.get("choices") or []
        if not choices:
            return chunk

        choice = choices[0]
        delta = choice.get("delta") or {}
        tool_calls = delta.get("tool_calls") or []

        for tc in tool_calls:
            fn = tc.get("function") or {}

            if fn.get("name") == EXIT_TOOL_NAME:
                self._exit_tool_index = tc.get("index", 0)
                self._exit_tool_detected = True
                return None

            if self._exit_tool_index >= 0 and tc.get("index") == self._exit_tool_index:
                args_fragment = fn.get("arguments", "")
                if args_fragment:
                    self._exit_tool_response += args_fragment
                    try:
                        parsed = json.loads(self._exit_tool_response)
                        text = parsed.get("response", "")
                        converted = dict(chunk)
                        converted["choices"] = [{
                            **choice,
                            "delta": {"role": "assistant", "content": text},
                        }]
                        return converted
                    except (json.JSONDecodeError, ValueError):
                        pass
                return None

        finish = choice.get("finish_reason")
        if finish == "tool_calls" and self._exit_tool_detected:
            modified = dict(chunk)
            modified["choices"] = [{**choice, "finish_reason": "stop", "delta": delta}]
            return modified

        return chunk
