# ARG --enable=ASYNC103,ASYNC104

from typing import Any


def foo() -> Any: ...


# fmt: off
# TODO: Black 23.1.0 moves the long comments around a bit.

try:
    ...
except (SyntaxError, ValueError, BaseException):
    raise

try:
    ...
except (
    SyntaxError,
    ValueError,
    BaseException,  # ASYNC103_trio: 4, "BaseException"
) as p:
    ...

try:
    ...
except (SyntaxError, ValueError):
    raise

try:
    ...
except BaseException as e:
    raise e

try:
    ...
except BaseException as e:
    raise  # acceptable - see https://peps.python.org/pep-0678/#example-usage

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    ...

# if
try:
    ...
except BaseException as e:  # ASYNC103_trio: 7, "BaseException"
    if foo():
        raise e
    elif foo():
        ...
    else:
        raise e

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    if True:
        raise

try:
    ...
except BaseException:  # safe
    if foo():
        raise
    elif foo():
        raise
    else:
        raise

# loops
# raises inside the body are never guaranteed to run and are ignored
try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    while foo():
        raise

# raise inside else are guaranteed to run, unless there's a break
try:
    ...
except BaseException:
    while ...:
        ...
    else:
        raise

try:
    ...
except BaseException:
    for _ in "":
        ...
    else:
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    while ...:
        if ...:
            break
        raise
    else:
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for _ in "":
        if ...:
            break
        raise
    else:
        raise

# ensure we don't ignore previous guaranteed raise (although that's unreachable code)
try:
    ...
except BaseException:
    raise
    for _ in "": # type: ignore[unreachable]
        if ...:
            break
        raise
    else:
        raise

# nested try
# in theory safe if the try, and all excepts raises - and there's a bare except.
# But is a very weird pattern that we don't handle.
try:
    ...
except BaseException as e:  # ASYNC103_trio: 7, "BaseException"
    try:
        raise e
    except ValueError:
        raise e
    except:
        raise e  # ASYNC104: 8

try:
    ...
except BaseException:  # safe
    try:
        ...
    finally:
        raise

# check that nested non-critical exceptions are ignored
try:
    ...
except BaseException:
    try:
        ...
    except ValueError:
        ...  # safe
    raise

# check that name isn't lost
try:
    ...
except BaseException as e:
    try:
        ...
    except BaseException as f:
        raise f
    raise e

# don't bypass raise by raising from nested except
try:
    ...
except BaseException as e:
    try:
        ...
    except ValueError as g:
        raise g  # ASYNC104: 8
    except BaseException as h:
        raise h  # error? currently treated as safe
    raise e

# bare except, equivalent to `except baseException`
try:
    ...
except:  # ASYNC103_trio: 0, "bare except"
    ...

try:
    ...
except:
    raise

# point to correct exception in multi-line handlers
my_super_mega_long_exception_so_it_gets_split = SyntaxError
try:
    ...
except (
    my_super_mega_long_exception_so_it_gets_split,
    SyntaxError,
    BaseException,  # ASYNC103_trio: 4, "BaseException"
    ValueError,
    BaseException,  # no complaint on this line
):
    ...

# loop over non-empty static collection
try:
    ...
except BaseException as e:
    for i in [1, 2, 3]:
        raise
try:
    ...
except BaseException as e:
    for i in (1, 2, 3):
        raise
try:
    ...
except BaseException as e:
    for i in {1, 2, 3}:
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in [1, 2, 3]:
        ...

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in [1, 2, 3]:
        if ...:
            continue
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in foo():
        raise

try:
    ...
except BaseException:
    for i in (*(), *(1, 2),):
        raise

try:
    ...
except BaseException:
    for i in {**{}, **{1: 2}}: # type: ignore[arg-type]
        raise

try:
    ...
except BaseException:
    for i in range(3):
        raise

try:
    ...
except BaseException:
    for i in range(27670116110564327421):
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in range(foo()):
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in []:
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    for i in {}:
        raise

try:
    ...
except BaseException:
    for i in {1: 2}:
        raise

try:
    ...
except BaseException:
    while True:
        raise

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    while True:
        if ...:
            break
        raise

try:
    ...
except BaseException:
    while True:
        if ...:
            continue
        raise

# Issue #106, false alarm on excepts after `Cancelled` has already been handled
try:
    ...
except BaseException:
    raise
except:  # now silent
    ...

# don't throw multiple 103's even if `Cancelled` wasn't properly handled.
try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    ...
except:  # now silent
    ...

# Check state management of whether cancelled has been handled across nested try's
try:
    try:
        ...
    except BaseException:
        raise
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    ...
except:
    try:
        ...
    except BaseException:  # ASYNC103_trio: 11, "BaseException"
        ...

# structural pattern matching
try:
    ...
except BaseException as e:  # ASYNC103_trio: 7, "BaseException"
    match foo():
        case True:
            raise e
        case False:
            ...
        case _:
            raise e

try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    match foo():
        case True:
            raise

try:
    ...
except BaseException:  # safe
    match foo():
        case True:
            raise
        case False:
            raise
        case _:
            raise
try:
    ...
except BaseException:  # ASYNC103_trio: 7, "BaseException"
    match foo():
        case _ if foo():
            raise
