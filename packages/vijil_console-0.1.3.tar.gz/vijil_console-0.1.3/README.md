# vijil-console

CLI for the Vijil AI trust platform. Manage agents, evaluations, evolutions, and more from the command line against a Vijil Console deployed in your VPC.

## Install

```bash
pip install vijil-console
# or isolated:
pipx install vijil-console
```

For development (from the vijil-console repo):

```bash
pip install -e src/cli
```

## Connecting to a deployed environment

The CLI talks to the Vijil Console nginx API gateway — the single load balancer that routes to all backend microservices. You need one URL: the external address of the `vijil-console-nginx-api` service.

### 1. Find your Console API URL

If you have `kubectl` access to the EKS cluster:

```bash
kubectl get svc vijil-console-nginx-api -n vijil-console \
  -o jsonpath='{.status.loadBalancer.ingress[0].hostname}'
```

This gives you the raw ELB hostname. If a DNS record exists (e.g., `console-api.dev05.vijil.ai`), use that instead — check Route 53 for CNAME records pointing at this ELB.

### 2. Initialize the CLI

```bash
vijil init
# Prompt: Vijil Console URL []: http://console-api.dev05.vijil.ai
```

This saves the URL to `~/.vijil/config.yaml`. The init command verifies connectivity by hitting `/teams/healthz` through the gateway.

**Note:** The gateway does not expose a root `/healthz` — health checks are routed per-service (e.g., `/teams/healthz`, `/evaluations/healthz`). The CLI uses `/teams/healthz` as the connectivity check since the teams service handles authentication and is always required.

### 3. Authenticate

```bash
vijil login
# Prompt: Email: user@example.com
# Prompt: Password: ********
```

The CLI sends a JSON `POST /auth/jwt/login` with `{"email": "...", "password": "..."}` to the teams service. On success it stores the JWT access token and (if available) refresh token in `~/.vijil/config.yaml`.

If your account belongs to a single team, the CLI auto-selects it. If you belong to multiple teams, select one:

```bash
vijil team list
vijil team use <team_id>
```

The active `team_id` is injected automatically into API calls that require it (evaluations, harnesses, etc.).

### 4. Use

```bash
vijil agent list                         # list agents
vijil agent get <agent_id>               # agent details
vijil eval run --agent-id <id> --wait    # run evaluation, poll until done
vijil eval list                          # list evaluations
vijil eval results <evaluation_id>       # get results
vijil harness list                       # list standard harnesses
vijil evolution run <agent_id> --wait    # trigger Darwin evolution
vijil proposal list                      # list mutation proposals
vijil dashboard show --json              # trust dashboard
vijil redteam run --help                 # see red team options
```

Every command supports `--json` for machine-readable output and `--help` for usage details.

## Gateway routing

The CLI sends all requests to the single gateway URL. The nginx gateway routes paths to backend microservices:

| Path prefix | Backend service |
|-------------|----------------|
| `/auth`, `/users`, `/teams` | `teams` |
| `/agent-configurations`, `/agents/*/evolution*`, `/personas`, `/policies`, `/rules`, `/demographics`, `/dimensions`, `/proposals`, `/genomes`, `/dashboard` | `agent-environment` |
| `/evaluations`, `/evaluation-summaries`, `/evaluation-results`, `/harnesses`, `/custom-harnesses` | `diamond` |
| `/dome-configs`, `/detections`, `/telemetry` | `dome` |
| `/redteam/*` | `redteam` (prefix stripped by nginx) |

The redteam service is the only one with a gateway prefix rewrite — `/redteam/tools` on the gateway maps to `/tools` on the service. This is handled automatically by the `path_prefix` field in `mapping.yaml`.

## Configuration

All CLI state is stored in `~/.vijil/config.yaml`:

```yaml
console_url: http://console-api.dev05.vijil.ai
auth_token: eyJhbG...
refresh_token: ...
default_team_id: c58aea71-3861-4f28-b8c4-20832a2f22ee
```

Token refresh is automatic — if a request returns 401, the CLI attempts `POST /auth/jwt/refresh` before failing.

## Commands

Run `vijil --help` for the full list:

```
agent       Manage AI agents (list, create, get, update, delete, import)
eval        Run and manage evaluations (run, status, list, results)
harness     Manage test harnesses (list, custom-list, custom-create, ...)
dome        Dome guardrail configuration and detection
telemetry   Query observability telemetry (metrics, traces, logs)
evolution   Darwin evolution engine (run, status)
proposal    Manage mutation proposals (list, approve, reject)
genome      Manage agent genomes (list, get, create, extract)
persona     Manage test personas
policy      Manage compliance policies and rules
redteam     Red team attack campaigns (tools, run, list, results)
dashboard   Trust dashboard
```

## Development: keeping the CLI in sync

Command files in `vijil_cli/commands/` (except `auth.py` and `team.py`) are **auto-generated** from OpenAPI specs. When APIs change:

```bash
# 1. Regenerate OpenAPI specs from FastAPI app objects (no cluster needed)
make openapi-static

# 2. Regenerate CLI commands from specs + mapping
make generate-cli

# 3. Validate all endpoints have CLI mappings (CI check)
make validate-cli
```

### Adding a new API endpoint to the CLI

1. Add the route in the service
2. Run `make generate-cli` — codegen warns about unmapped operations
3. Add the mapping in `src/cli/mapping.yaml`:
   ```yaml
   groups:
     mygroup:
       service: service_foo
       commands:
         new-command:
           method: POST
           path: /new-endpoint
   ```
4. Run `make generate-cli` again — the command appears
5. CI `make validate-cli` ensures nothing is missed

### mapping.yaml reference

| Field | Purpose |
|-------|---------|
| `service` | Which OpenAPI spec to read (`service_teams`, `service_diamond`, etc.) |
| `path_prefix` | Gateway path prefix prepended to all paths (e.g., `/redteam`) |
| `method` / `path` | HTTP method and path as defined in the OpenAPI spec |
| `positional` | Path parameters to expose as CLI arguments |
| `output: table` | Display results as a table (default: key-value detail) |
| `table_columns` | Columns to show in table output |
| `confirm: true` | Prompt "Are you sure?" before executing |
| `async_poll` | Enable `--wait` flag with polling path and ID field |
