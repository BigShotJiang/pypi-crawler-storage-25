"""Vijil CLI — manage agents, evaluations, and evolutions."""
