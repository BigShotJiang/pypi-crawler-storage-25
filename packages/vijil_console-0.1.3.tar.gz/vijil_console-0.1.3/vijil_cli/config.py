"""Persistent CLI configuration stored at ~/.vijil/config.yaml."""

import os
from pathlib import Path

import click
import yaml

CONFIG_DIR = Path.home() / ".vijil"
CONFIG_FILE = CONFIG_DIR / "config.yaml"


def load_config() -> dict:
    if CONFIG_FILE.exists():
        data = yaml.safe_load(CONFIG_FILE.read_text())
        return data if isinstance(data, dict) else {}
    return {}


def save_config(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    content = yaml.dump(cfg, default_flow_style=False)
    # Open with explicit 0o600 mode to avoid a window where the file is
    # world-readable (TOCTOU race with write-then-chmod).
    fd = os.open(str(CONFIG_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, content.encode())
    finally:
        os.close(fd)


def require_console_url() -> str:
    cfg = load_config()
    url = cfg.get("console_url")
    if not url:
        raise click.ClickException("Not configured. Run 'vijil init' first.")
    return url


def require_team_id() -> str:
    cfg = load_config()
    tid = cfg.get("default_team_id")
    if not tid:
        raise click.ClickException("No team selected. Run 'vijil team use <team_id>' first.")
    return tid
