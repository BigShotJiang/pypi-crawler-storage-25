"""Output formatting helpers: tables, JSON, and key-value detail views."""

from __future__ import annotations

import json
from typing import Any

import click


def print_json(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, default=str))


def print_table(rows: list[dict], columns: list[str]) -> None:
    if not rows:
        click.echo("No results.")
        return

    widths = {c: len(c) for c in columns}
    for row in rows:
        for c in columns:
            widths[c] = max(widths[c], min(len(str(row.get(c, ""))), 60))

    header = "  ".join(c.upper().ljust(widths[c]) for c in columns)
    click.echo(header)
    click.echo("-" * len(header))
    for row in rows:
        parts = []
        for c in columns:
            val = str(row.get(c, ""))
            if len(val) > 60:
                val = val[:57] + "..."
            parts.append(val.ljust(widths[c]))
        click.echo("  ".join(parts))


def print_detail(data: dict, skip: tuple[str, ...] = ()) -> None:
    for k, v in data.items():
        if k in skip:
            continue
        if isinstance(v, dict | list):
            v = json.dumps(v, indent=2, default=str)
        click.echo(f"{k}: {v}")
