"""Allow running as: python -m vijil_cli"""

from vijil_cli.main import cli

cli()
