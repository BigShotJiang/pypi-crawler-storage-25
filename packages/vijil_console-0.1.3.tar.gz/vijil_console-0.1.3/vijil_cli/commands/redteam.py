# AUTO-GENERATED from specs/service_redteam.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def redteam():
    """Red team attack campaigns."""


@redteam.command("tools")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_tools(as_json):
    """List Tools"""
    resp = api().get("/redteam/tools")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "description"])

@redteam.command("run")
@click.option("--tool", type=click.Choice(["diamond_security", "promptfoo", "garak", "pyrit", "unknown"]), required=True, help="Red team tool to use")
@click.option("--agent-url", help="Target agent endpoint URL")
@click.option("--agent-id", help="Agent ID from Agent Registry (resolves URL)")
@click.option("--agent-api-key", help="API key for the target agent")
@click.option("--agent-model-name", help="Model name if agent is an LLM gateway")
@click.option("--purpose", required=True, help="Agent purpose description (for context-aware attacks)")
@click.option("--categories", required=True, help="Attack categories to test (JSON array)")
@click.option("--custom-plugins", help="Custom plugin/probe names (for CUSTOM category) (JSON array)")
@click.option("--strategies", help="Evaluation strategies (tool-specific) (JSON array)")
@click.option("--num-tests", type=int, help="Number of test cases per category")
@click.option("--provider-config", help="Provider-specific configuration (JSON object)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def redteam_run(tool, agent_url, agent_id, agent_api_key, agent_model_name, purpose, categories, custom_plugins, strategies, num_tests, provider_config, as_json, wait):
    """Create Campaign"""
    import json as _json
    body = {}
    body["team_id"] = require_team_id()
    if tool is not None:
        body["tool"] = tool
    if agent_url is not None:
        body["agent_url"] = agent_url
    if agent_id is not None:
        body["agent_id"] = agent_id
    if agent_api_key is not None:
        body["agent_api_key"] = agent_api_key
    if agent_model_name is not None:
        body["agent_model_name"] = agent_model_name
    if purpose is not None:
        body["purpose"] = purpose
    if categories is not None:
        body["categories"] = _json.loads(categories)
    if custom_plugins is not None:
        body["custom_plugins"] = _json.loads(custom_plugins)
    if strategies is not None:
        body["strategies"] = _json.loads(strategies)
    if num_tests is not None:
        body["num_tests"] = num_tests
    if provider_config is not None:
        body["provider_config"] = _json.loads(provider_config)
    resp = api().post("/redteam/campaigns", json=body)
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/redteam/campaigns/{data['campaign_id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@redteam.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_list(as_json):
    """List Campaigns"""
    resp = api().get("/redteam/campaigns")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["campaign_id", "tool", "status", "created_at"])

@redteam.command("status")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_status(campaign_id, as_json):
    """Get Campaign Status"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/redteam/campaigns/{campaign_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@redteam.command("results")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_results(campaign_id, as_json):
    """Get Campaign Results"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/redteam/campaigns/{campaign_id}/results", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@redteam.command("delete")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_delete(campaign_id, as_json):
    """Delete Campaign"""
    if not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().delete(f"/redteam/campaigns/{campaign_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@redteam.command("logs")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_logs(campaign_id, as_json):
    """Get Campaign Logs"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/redteam/campaigns/{campaign_id}/logs", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@redteam.command("cancel")
@click.argument("campaign_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def redteam_cancel(campaign_id, as_json):
    """Cancel Campaign"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().post(f"/redteam/campaigns/{campaign_id}/cancel", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
