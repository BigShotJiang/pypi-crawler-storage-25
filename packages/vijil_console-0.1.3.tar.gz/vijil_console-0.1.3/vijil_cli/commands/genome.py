# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def genome():
    """Manage agent genomes."""


@genome.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_list(as_json):
    """GET /genomes/"""
    resp = api().get("/genomes/")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "agent_id", "created_at"])

@genome.command("get")
@click.argument("genome_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_get(genome_id, as_json):
    """GET /genomes/{genome_id}"""
    resp = api().get(f"/genomes/{genome_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("create")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_create(as_json):
    """POST /genomes/"""
    resp = api().post("/genomes/", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("update")
@click.argument("genome_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_update(genome_id, as_json):
    """PUT /genomes/{genome_id}"""
    resp = api().put(f"/genomes/{genome_id}", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("extract")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_extract(agent_id, as_json):
    """GET /genomes/{agent_id}/extract"""
    resp = api().get(f"/genomes/{agent_id}/extract")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
