# AUTO-GENERATED from specs/service_diamond.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def eval():
    """Run and manage evaluations."""


@eval.command("run")
@click.option("--agent-id", required=True, help="UUID of the agent from Agent Registry")
@click.option("--type", help="Type of evaluation to run. Currently only 'behavioral' is supported.")
@click.option("--harness-names", required=True, help="List of harnesses to run (e.g., ['safety', 'ethics', 'privacy', 'security', 'toxicity']) (JSON array)")
@click.option("--harness-type", type=click.Choice(["standard", "custom"]), help="Type of all harnesses: 'standard' or 'custom'. All harnesses in harness_names must be of thi...")
@click.option("--sample-size", type=int, help="Number of prompts to randomly sample per harness. If omitted, all prompts run (~1250 for security). Recommended: 10 for fast i...")
@click.option("--evaluation-id", help="Optional UUID for the evaluation. If provided, this UUID will be used when creating the evaluation in Diamond. If not provided, Diamon...")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def eval_run(agent_id, type, harness_names, harness_type, sample_size, evaluation_id, as_json, wait):
    """Create Evaluation"""
    import json as _json
    body = {}
    body["team_id"] = require_team_id()
    if agent_id is not None:
        body["agent_id"] = agent_id
    if type is not None:
        body["type"] = type
    if harness_names is not None:
        body["harness_names"] = _json.loads(harness_names)
    if harness_type is not None:
        body["harness_type"] = harness_type
    if sample_size is not None:
        body["sample_size"] = sample_size
    if evaluation_id is not None:
        body["evaluation_id"] = evaluation_id
    resp = api().post("/evaluations/", json=body)
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/evaluations/{data['evaluation_id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("status")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_status(evaluation_id, as_json):
    """Get Evaluation"""
    resp = api().get(f"/evaluations/{evaluation_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("list")
@click.option("--agent-id", help="Filter by agent ID")
@click.option("--status", help="Filter by status (running, completed, failed, cancelled)")
@click.option("--harness-type", help="Filter by harness type (standard or custom)")
@click.option("--tested-by", help="Filter by tool that ran the evaluation")
@click.option("--limit", type=int, help="Maximum number of results to return")
@click.option("--offset", type=int, help="Number of results to skip for paging")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_list(agent_id, status, harness_type, tested_by, limit, offset, as_json):
    """List Evaluation Summaries"""
    params = {}
    params["team_id"] = require_team_id()
    if agent_id is not None:
        params["agent_id"] = agent_id
    if status is not None:
        params["status"] = status
    if harness_type is not None:
        params["harness_type"] = harness_type
    if tested_by is not None:
        params["tested_by"] = tested_by
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/evaluation-summaries/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["evaluation_id", "agent_id", "status", "created_at"])

@eval.command("list-all")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_list_all(as_json):
    """List Team Evaluations"""
    resp = api().get("/evaluations/")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["evaluation_id", "status", "created_at"])

@eval.command("logs")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_logs(evaluation_id, as_json):
    """Get Evaluation Logs"""
    resp = api().get(f"/evaluations/{evaluation_id}/logs")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("delete")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_delete(evaluation_id, as_json):
    """Delete Evaluation"""
    if not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/evaluations/{evaluation_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("cancel")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_cancel(evaluation_id, as_json):
    """Cancel Evaluation"""
    resp = api().post(f"/evaluations/{evaluation_id}/cancel", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("report")
@click.argument("evaluation_id")
@click.option("--force-regenerate", is_flag=True, help="Force regeneration even if cached")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_report(evaluation_id, force_regenerate, as_json):
    """Generate Report On Demand"""
    params = {}
    params["team_id"] = require_team_id()
    if force_regenerate:
        params["force_regenerate"] = force_regenerate
    resp = api().post(f"/evaluations/{evaluation_id}/report", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("results-list")
@click.option("--limit", type=int, help="Maximum number of results to return")
@click.option("--offset", type=int, help="Number of results to skip for paging")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_results_list(limit, offset, as_json):
    """List Completed Evaluations"""
    params = {}
    params["team_id"] = require_team_id()
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/evaluation-results/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["evaluation_id", "status"])

@eval.command("results-detail")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_results_detail(evaluation_id, as_json):
    """Get Evaluation Results"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/evaluation-results/{evaluation_id}/results", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("results-report")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_results_report(evaluation_id, as_json):
    """Get Evaluation Report"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/evaluation-results/{evaluation_id}/report", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("summary-by-agent")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_summary_by_agent(as_json):
    """List Latest Evaluation Summaries By Agent"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get("/evaluation-summaries/latest-by-agent", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["agent_id", "evaluation_id", "status"])

@eval.command("summary-get")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_summary_get(evaluation_id, as_json):
    """Get Evaluation Summary"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/evaluation-summaries/{evaluation_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@eval.command("summary-delete")
@click.argument("evaluation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def eval_summary_delete(evaluation_id, as_json):
    """Delete Evaluation Summary"""
    if not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().delete(f"/evaluation-summaries/{evaluation_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
