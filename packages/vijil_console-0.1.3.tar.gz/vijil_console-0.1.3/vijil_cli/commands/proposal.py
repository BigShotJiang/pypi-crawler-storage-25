# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def proposal():
    """Manage mutation proposals."""


@proposal.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_list(as_json):
    """GET /proposals/"""
    resp = api().get("/proposals/")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "status", "created_at"])

@proposal.command("get")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_get(proposal_id, as_json):
    """GET /proposals/{proposal_id}"""
    resp = api().get(f"/proposals/{proposal_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@proposal.command("approve")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_approve(proposal_id, as_json):
    """POST /proposals/{proposal_id}/approve"""
    resp = api().post(f"/proposals/{proposal_id}/approve", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@proposal.command("reject")
@click.argument("proposal_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def proposal_reject(proposal_id, as_json):
    """POST /proposals/{proposal_id}/reject"""
    resp = api().post(f"/proposals/{proposal_id}/reject", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
