# AUTO-GENERATED from specs/service_dome.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def telemetry():
    """Query observability telemetry."""


@telemetry.command("metric-total")
@click.argument("metric_name")
@click.option("--time-range", help="Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d")
@click.option("--evaluation-id", help="Filter by evaluation ID")
@click.option("--test-id", help="Filter by test ID")
@click.option("--probe-id", help="Filter by probe ID")
@click.option("--agent-configuration-id", help="Filter by agent configuration ID")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_metric_total(metric_name, time_range, evaluation_id, test_id, probe_id, agent_configuration_id, as_json):
    """Get Counter Total"""
    params = {}
    if time_range is not None:
        params["time_range"] = time_range
    if evaluation_id is not None:
        params["evaluation_id"] = evaluation_id
    if test_id is not None:
        params["test_id"] = test_id
    if probe_id is not None:
        params["probe_id"] = probe_id
    if agent_configuration_id is not None:
        params["agent_configuration_id"] = agent_configuration_id
    resp = api().get(f"/telemetry/counters/{metric_name}/total", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@telemetry.command("counter-series")
@click.argument("metric_name")
@click.option("--time-range", help="Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d")
@click.option("--evaluation-id", help="Filter by evaluation ID")
@click.option("--agent-configuration-id", help="Filter by agent configuration ID")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_counter_series(metric_name, time_range, evaluation_id, agent_configuration_id, as_json):
    """Get Counter Time Series"""
    params = {}
    if time_range is not None:
        params["time_range"] = time_range
    if evaluation_id is not None:
        params["evaluation_id"] = evaluation_id
    if agent_configuration_id is not None:
        params["agent_configuration_id"] = agent_configuration_id
    resp = api().get(f"/telemetry/counters/{metric_name}/time_series", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@telemetry.command("latency-metric")
@click.argument("metric_name")
@click.option("--time-range", help="Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d")
@click.option("--time-window", help="Time window for aggregation (e.g., '1m', '5m', '15m')")
@click.option("--percentiles", help="Comma-separated list of percentiles to query (e.g., '0.5,0.95'). If not specified, defaults to [0.5, 0.9, 0.95, 0.99]")
@click.option("--evaluation-id", help="Filter by evaluation ID")
@click.option("--test-id", help="Filter by test ID")
@click.option("--probe-id", help="Filter by probe ID")
@click.option("--agent-configuration-id", help="Filter by agent configuration ID")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_latency_metric(metric_name, time_range, time_window, percentiles, evaluation_id, test_id, probe_id, agent_configuration_id, as_json):
    """Get Latency Over Time"""
    params = {}
    if time_range is not None:
        params["time_range"] = time_range
    if time_window is not None:
        params["time_window"] = time_window
    if percentiles is not None:
        params["percentiles"] = percentiles
    if evaluation_id is not None:
        params["evaluation_id"] = evaluation_id
    if test_id is not None:
        params["test_id"] = test_id
    if probe_id is not None:
        params["probe_id"] = probe_id
    if agent_configuration_id is not None:
        params["agent_configuration_id"] = agent_configuration_id
    resp = api().get(f"/telemetry/latency/{metric_name}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@telemetry.command("logs")
@click.option("--time-range", help="Window to pull logs for")
@click.option("--service-name", help="Filter by service_name label")
@click.option("--level", help="Filter by level label")
@click.option("--job", help="Filter by job label")
@click.option("--exporter", help="Filter by exporter label")
@click.option("--agent-configuration-id", help="Restrict to a specific agent configuration id")
@click.option("--evaluation-id", help="Restrict logs to an evaluation id")
@click.option("--test-id", help="Restrict logs to a test id")
@click.option("--probe-id", help="Restrict logs to a probe id")
@click.option("--search", help="Substring search applied via LogQL pipeline")
@click.option("--logql", help="Advanced LogQL expression (overrides generated selector when provided)")
@click.option("--limit", type=int, help="Maximum log lines to return")
@click.option("--direction", help="Return order for log entries")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_logs(time_range, service_name, level, job, exporter, agent_configuration_id, evaluation_id, test_id, probe_id, search, logql, limit, direction, as_json):
    """Get Logs"""
    params = {}
    if time_range is not None:
        params["time_range"] = time_range
    if service_name is not None:
        params["service_name"] = service_name
    if level is not None:
        params["level"] = level
    if job is not None:
        params["job"] = job
    if exporter is not None:
        params["exporter"] = exporter
    if agent_configuration_id is not None:
        params["agent_configuration_id"] = agent_configuration_id
    if evaluation_id is not None:
        params["evaluation_id"] = evaluation_id
    if test_id is not None:
        params["test_id"] = test_id
    if probe_id is not None:
        params["probe_id"] = probe_id
    if search is not None:
        params["search"] = search
    if logql is not None:
        params["logql"] = logql
    if limit is not None:
        params["limit"] = limit
    if direction is not None:
        params["direction"] = direction
    resp = api().get("/telemetry/logs", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@telemetry.command("traces")
@click.option("--time-range", help="Window to search for traces")
@click.option("--limit", type=int, help="Maximum number of traces to return")
@click.option("--service-name", help="Filter by root service")
@click.option("--agent-configuration-id", help="Filter by agent id")
@click.option("--min-duration-ms", type=int, help="Lower bound on trace duration (ms)")
@click.option("--max-duration-ms", type=int, help="Upper bound on trace duration (ms)")
@click.option("--query", help="Advanced TraceQL query")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_traces(time_range, limit, service_name, agent_configuration_id, min_duration_ms, max_duration_ms, query, as_json):
    """Search Traces"""
    params = {}
    if time_range is not None:
        params["time_range"] = time_range
    if limit is not None:
        params["limit"] = limit
    if service_name is not None:
        params["service_name"] = service_name
    if agent_configuration_id is not None:
        params["agent_configuration_id"] = agent_configuration_id
    if min_duration_ms is not None:
        params["min_duration_ms"] = min_duration_ms
    if max_duration_ms is not None:
        params["max_duration_ms"] = max_duration_ms
    if query is not None:
        params["query"] = query
    resp = api().get("/telemetry/traces", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@telemetry.command("trace-get")
@click.argument("trace_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def telemetry_trace_get(trace_id, as_json):
    """Get Trace By Id"""
    resp = api().get(f"/telemetry/traces/{trace_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
