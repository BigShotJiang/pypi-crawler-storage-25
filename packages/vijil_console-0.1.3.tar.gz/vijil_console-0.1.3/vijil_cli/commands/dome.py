# AUTO-GENERATED from specs/service_dome.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def dome():
    """Dome guardrail configuration and detection."""


@dome.command("config-list")
@click.option("--agent-id", help="If set, only configs whose dome_configs.agent_id matches (paginated).")
@click.option("--limit", type=int, help="Page size")
@click.option("--offset", type=int, help="Pagination offset")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_list(agent_id, limit, offset, as_json):
    """List Dome Configs"""
    params = {}
    params["team_id"] = require_team_id()
    if agent_id is not None:
        params["agent_id"] = agent_id
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/dome-configs", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "agent_id", "status", "created_at"])

@dome.command("config-create")
@click.option("--config-body", help="Guard configuration. If not provided, uses default config. (JSON object)")
@click.option("--agent-id", help="Agent to bind this config to. When set, writes config_pending.json to storage.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_create(config_body, agent_id, as_json):
    """Create Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    import json as _json
    body = {}
    if config_body is not None:
        body["config_body"] = _json.loads(config_body)
    if agent_id is not None:
        body["agent_id"] = agent_id
    resp = api().post("/dome-configs", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("config-get")
@click.argument("config_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_get(config_id, as_json):
    """Get Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/dome-configs/{config_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("config-update")
@click.argument("config_id")
@click.option("--config-body", required=True, help="Updated guard configuration. (JSON object)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_update(config_id, config_body, as_json):
    """Update Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    import json as _json
    body = {}
    if config_body is not None:
        body["config_body"] = _json.loads(config_body)
    resp = api().put(f"/dome-configs/{config_id}", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("config-delete")
@click.argument("config_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_delete(config_id, as_json):
    """Delete Dome Config"""
    if not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().delete(f"/dome-configs/{config_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("config-patch")
@click.argument("config_id")
@click.option("--dome-instance-url", required=True, help="Dome instance URL to set, or null to clear.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_patch(config_id, dome_instance_url, as_json):
    """Patch Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    body = {}
    if dome_instance_url is not None:
        body["dome_instance_url"] = dome_instance_url
    resp = api().patch(f"/dome-configs/{config_id}", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("config-apply")
@click.argument("config_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_config_apply(config_id, as_json):
    """Apply Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().post(f"/dome-configs/{config_id}/apply", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("default-config")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_default_config(as_json):
    """Get Default Dome Config"""
    resp = api().get("/default-dome-config")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("detect")
@click.option("--id", required=True, help="Id")
@click.option("--detector-id", required=True, help="Detector Id")
@click.option("--detector-params", help="Parameters for a detection request. (JSON object)")
@click.option("--detector-inputs", required=True, help="Detector Inputs (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def dome_detect(id, detector_id, detector_params, detector_inputs, as_json, wait):
    """Create Detection"""
    import json as _json
    body = {}
    if id is not None:
        body["id"] = id
    if detector_id is not None:
        body["detector_id"] = detector_id
    if detector_params is not None:
        body["detector_params"] = _json.loads(detector_params)
    if detector_inputs is not None:
        body["detector_inputs"] = _json.loads(detector_inputs)
    resp = api().post("/detections", json=body)
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/detections/{data['id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@dome.command("detect-status")
@click.argument("detection_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dome_detect_status(detection_id, as_json):
    """Get Detection"""
    resp = api().get(f"/detections/{detection_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
