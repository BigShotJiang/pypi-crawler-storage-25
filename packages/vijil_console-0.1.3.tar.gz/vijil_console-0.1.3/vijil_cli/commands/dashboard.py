# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def dashboard():
    """Trust dashboard."""


@dashboard.command("show")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def dashboard_show(as_json):
    """Get Trust Dashboard"""
    resp = api().get("/dashboard/trust")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
