# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def demographics():
    """Manage demographic dimensions."""


@demographics.command("list")
@click.option("--protected-class-only", is_flag=True, help="Filter to only protected class dimensions")
@click.option("--limit", type=int, help="Maximum number of results")
@click.option("--offset", type=int, help="Number of results to skip")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_list(protected_class_only, limit, offset, as_json):
    """List Dimensions"""
    params = {}
    if protected_class_only:
        params["protected_class_only"] = protected_class_only
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/demographics/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name"])

@demographics.command("create")
@click.option("--name", required=True, help="Name")
@click.option("--display-name", required=True, help="Display Name")
@click.option("--protected-class", is_flag=True, help="Protected Class")
@click.option("--description", help="Description")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_create(name, display_name, protected_class, description, as_json):
    """Create Dimension"""
    body = {}
    if name is not None:
        body["name"] = name
    if display_name is not None:
        body["display_name"] = display_name
    if protected_class:
        body["protected_class"] = protected_class
    if description is not None:
        body["description"] = description
    resp = api().post("/demographics/", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("get")
@click.argument("dimension_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_get(dimension_id, as_json):
    """Get Dimension"""
    resp = api().get(f"/demographics/{dimension_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("update")
@click.argument("dimension_id")
@click.option("--display-name", help="Display Name")
@click.option("--protected-class", is_flag=True, help="Protected Class")
@click.option("--description", help="Description")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_update(dimension_id, display_name, protected_class, description, as_json):
    """Update Dimension"""
    body = {}
    if display_name is not None:
        body["display_name"] = display_name
    if protected_class:
        body["protected_class"] = protected_class
    if description is not None:
        body["description"] = description
    resp = api().put(f"/demographics/{dimension_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("delete")
@click.argument("dimension_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_delete(dimension_id, as_json):
    """Delete Dimension"""
    if not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/demographics/{dimension_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("get-by-name")
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_get_by_name(name, as_json):
    """Get Dimension By Name"""
    resp = api().get(f"/demographics/by-name/{name}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("values")
@click.argument("dimension_id")
@click.option("--limit", type=int, help="Maximum number of results")
@click.option("--offset", type=int, help="Number of results to skip")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_values(dimension_id, limit, offset, as_json):
    """List Values"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get(f"/demographics/{dimension_id}/values", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("add-value")
@click.argument("dimension_id")
@click.option("--value", required=True, help="Value")
@click.option("--display-name", help="Display Name")
@click.option("--metadata", help="Metadata (JSON object)")
@click.option("--sort-order", type=int, help="Sort Order")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_add_value(dimension_id, value, display_name, metadata, sort_order, as_json):
    """Add Value"""
    import json as _json
    body = {}
    if value is not None:
        body["value"] = value
    if display_name is not None:
        body["display_name"] = display_name
    if metadata is not None:
        body["metadata"] = _json.loads(metadata)
    if sort_order is not None:
        body["sort_order"] = sort_order
    resp = api().post(f"/demographics/{dimension_id}/values", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("add-values-bulk")
@click.argument("dimension_id")
@click.option("--values", required=True, help="Values (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_add_values_bulk(dimension_id, values, as_json):
    """Bulk Add Values"""
    import json as _json
    body = {}
    if values is not None:
        body["values"] = _json.loads(values)
    resp = api().post(f"/demographics/{dimension_id}/values/bulk", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("update-value")
@click.argument("value_id")
@click.option("--value", help="Value")
@click.option("--display-name", help="Display Name")
@click.option("--metadata", help="Metadata (JSON object)")
@click.option("--sort-order", type=int, help="Sort Order")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_update_value(value_id, value, display_name, metadata, sort_order, as_json):
    """Update Value"""
    import json as _json
    body = {}
    if value is not None:
        body["value"] = value
    if display_name is not None:
        body["display_name"] = display_name
    if metadata is not None:
        body["metadata"] = _json.loads(metadata)
    if sort_order is not None:
        body["sort_order"] = sort_order
    resp = api().put(f"/demographics/values/{value_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@demographics.command("delete-value")
@click.argument("value_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def demographics_delete_value(value_id, as_json):
    """Delete Value"""
    if not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/demographics/values/{value_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
