"""Authentication commands — always hand-written (not generated)."""

import click
import httpx

from vijil_cli.config import load_config, save_config


@click.command()
@click.option("--url", prompt="Vijil Console URL", help="Base URL of the Vijil Console gateway.")
def init(url: str) -> None:
    """Configure the Vijil Console URL."""
    url = url.rstrip("/")

    # The nginx gateway has no root /healthz; check the teams service health endpoint.
    try:
        resp = httpx.get(f"{url}/teams/healthz", timeout=10)
        resp.raise_for_status()
    except Exception:
        raise click.ClickException(f"Cannot reach {url}/teams/healthz — check the URL and try again.")

    cfg = load_config()
    cfg["console_url"] = url
    save_config(cfg)
    click.echo(f"Saved console URL: {url}")


@click.command()
@click.option("--email", prompt=True, help="Account email.")
@click.option("--password", prompt=True, hide_input=True, help="Account password.")
def login(email: str, password: str) -> None:
    """Log in and store credentials."""
    cfg = load_config()
    url = cfg.get("console_url")
    if not url:
        raise click.ClickException("Not configured. Run 'vijil init' first.")

    resp = httpx.post(
        f"{url}/auth/jwt/login",
        json={"email": email, "password": password},
        timeout=30,
    )
    if resp.status_code != 200:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise click.ClickException(f"Login failed ({resp.status_code}): {detail}")

    data = resp.json()
    cfg["auth_token"] = data.get("access_token", "")
    save_config(cfg)

    # Fetch user info and team memberships
    headers = {"Authorization": f"Bearer {cfg['auth_token']}"}
    me_resp = httpx.get(f"{url}/auth/users/me", headers=headers, timeout=10)
    if me_resp.status_code == 200:
        me = me_resp.json()
        click.echo(f"Logged in as {me.get('email', email)}")

    teams_resp = httpx.get(f"{url}/users/me/teams", headers=headers, timeout=10)
    if teams_resp.status_code == 200:
        teams = teams_resp.json()
        if isinstance(teams, list) and len(teams) == 1:
            tid = teams[0].get("team_id") or teams[0].get("id", "")
            if tid:
                cfg["default_team_id"] = tid
                save_config(cfg)
                click.echo(f"Default team set: {tid}")
        elif isinstance(teams, list) and len(teams) > 1:
            click.echo("Multiple teams available — run 'vijil team use <team_id>' to select one:")
            for t in teams:
                tid = t.get("team_id") or t.get("id", "")
                click.echo(f"  {tid}  {t.get('team_name', '')}")


@click.command()
def logout() -> None:
    """Clear stored credentials."""
    cfg = load_config()
    cfg.pop("auth_token", None)
    cfg.pop("refresh_token", None)  # clean up legacy config entries
    save_config(cfg)
    click.echo("Logged out.")
