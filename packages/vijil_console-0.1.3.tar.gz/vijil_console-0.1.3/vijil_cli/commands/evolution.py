# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def evolution():
    """Darwin evolution engine."""


@evolution.command("run")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def evolution_run(agent_id, as_json, wait):
    """POST /agents/{agent_id}/evolutions"""
    resp = api().post(f"/agents/{agent_id}/evolutions", json={})
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/agents/{agent_id}/evolutions/{data['id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@evolution.command("status")
@click.argument("agent_id")
@click.argument("evolution_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def evolution_status(agent_id, evolution_id, as_json):
    """GET /agents/{agent_id}/evolutions/{evolution_id}"""
    resp = api().get(f"/agents/{agent_id}/evolutions/{evolution_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
