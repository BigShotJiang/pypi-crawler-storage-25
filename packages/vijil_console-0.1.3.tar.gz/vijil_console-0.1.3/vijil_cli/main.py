"""CLI entry point — assembles all command groups."""

import importlib

import click

from vijil_cli.commands.auth import init, login, logout
from vijil_cli.commands.team import team

# Generated command groups are loaded dynamically so the CLI still works
# even if some groups haven't been generated yet.
_GENERATED_GROUPS = [
    "agent",
    "eval",
    "harness",
    "dome",
    "telemetry",
    "evolution",
    "proposal",
    "genome",
    "persona",
    "demographics",
    "dimensions",
    "policy",
    "redteam",
    "dashboard",
]


@click.group()
@click.version_option(package_name="vijil-cli")
def cli() -> None:
    """Vijil CLI — manage agents, evaluations, and evolutions."""


# Hand-written commands
cli.add_command(init)
cli.add_command(login)
cli.add_command(logout)
cli.add_command(team)

# Load generated command groups
for _name in _GENERATED_GROUPS:
    try:
        mod = importlib.import_module(f"vijil_cli.commands.{_name}")
        group = getattr(mod, _name, None)
        if group:
            cli.add_command(group)
    except ModuleNotFoundError as exc:
        if exc.name == f"vijil_cli.commands.{_name}":
            pass  # group not yet generated — skip silently
        else:
            raise  # real import error — surface it
