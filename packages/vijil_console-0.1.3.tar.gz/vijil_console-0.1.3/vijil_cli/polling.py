"""Poll async API operations until a terminal status is reached."""

from __future__ import annotations

import time

import click

from vijil_cli.client import VijilClient

TERMINAL = frozenset({"completed", "failed", "cancelled", "error"})


def poll_until_done(
    client: VijilClient,
    path: str,
    *,
    status_field: str = "status",
    interval: int = 5,
    timeout: int = 600,
) -> dict:
    start = time.monotonic()
    last_status = ""
    while True:
        elapsed = time.monotonic() - start
        if elapsed > timeout:
            raise click.ClickException(f"Timed out after {timeout}s (last status: {last_status})")

        resp = client.get(path)
        data = resp.json()
        status = str(data.get(status_field, "unknown")).lower()

        if status != last_status:
            click.echo(f"  Status: {status}")
            last_status = status

        if status in TERMINAL:
            return data

        time.sleep(interval)
