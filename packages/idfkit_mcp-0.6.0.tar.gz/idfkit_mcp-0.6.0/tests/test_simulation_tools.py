"""Tests for simulation tools."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from fastmcp.exceptions import ToolError
from idfkit.simulation.result import SimulationResult

from idfkit_mcp.models import ListOutputVariablesResult
from idfkit_mcp.state import ServerState
from tests.conftest import call_tool


class TestRunSimulation:
    async def test_no_model(self, client: object) -> None:
        with pytest.raises(ToolError):
            await call_tool(client, "run_simulation")

    async def test_no_weather(self, client: object, state_with_model: ServerState) -> None:
        with pytest.raises(ToolError):
            await call_tool(client, "run_simulation")

    async def test_output_directory_accepted(self, client: object, state_with_model: ServerState) -> None:
        with pytest.raises(ToolError, match=r"weather|No weather"):
            await call_tool(client, "run_simulation", {"output_directory": "/tmp/test_out"})  # noqa: S108

    async def test_defaults_to_latest_energyplus(self, client: object, state_with_model: ServerState) -> None:
        with patch("idfkit.simulation.config.find_energyplus") as mock_find:
            mock_find.side_effect = RuntimeError("test stop")
            with pytest.raises(ToolError):
                await call_tool(client, "run_simulation", {"design_day": True})
            mock_find.assert_called_once_with(path=None, version=None)

    async def test_adds_output_sqlite_when_missing(
        self, client: object, state_with_model: ServerState, tmp_path: Path
    ) -> None:
        fake_config = SimpleNamespace(
            version=(25, 2, 0),
            install_dir=Path("/fake/energyplus"),
            executable=Path("/fake/energyplus/energyplus"),
        )
        fake_errors = SimpleNamespace(
            fatal_count=0,
            severe_count=0,
            warning_count=0,
            has_fatal=False,
            has_severe=False,
            simulation_complete=True,
        )
        fake_result = SimpleNamespace(
            success=True,
            runtime_seconds=0.1,
            run_dir=tmp_path / "fake-run",
            errors=fake_errors,
        )

        async def _fake_simulate(doc: object, **_kwargs: object) -> object:
            collection = doc.get_collection("Output:SQLite")  # type: ignore[union-attr]
            sqlite_object = collection.first()
            assert sqlite_object is not None
            assert sqlite_object.option_type == "SimpleAndTabular"
            return fake_result

        with (
            patch("idfkit.simulation.config.find_energyplus", return_value=fake_config),
            patch("idfkit.simulation.async_simulate", side_effect=_fake_simulate),
        ):
            result = await call_tool(client, "run_simulation", {"design_day": True})

        assert result["success"] is True
        # The original model must NOT be mutated — simulation runs on a copy.
        assert "Output:SQLite" not in state_with_model.document  # type: ignore[operator]

    async def test_upgrades_existing_output_sqlite(
        self, client: object, state_with_model: ServerState, tmp_path: Path
    ) -> None:
        doc = state_with_model.document
        doc.add("Output:SQLite", "", option_type="Simple")  # type: ignore[union-attr]

        fake_config = SimpleNamespace(
            version=(25, 2, 0),
            install_dir=Path("/fake/energyplus"),
            executable=Path("/fake/energyplus/energyplus"),
        )
        fake_errors = SimpleNamespace(
            fatal_count=0,
            severe_count=0,
            warning_count=0,
            has_fatal=False,
            has_severe=False,
            simulation_complete=True,
        )
        fake_result = SimpleNamespace(
            success=True,
            runtime_seconds=0.1,
            run_dir=tmp_path / "fake-run",
            errors=fake_errors,
        )

        async def _fake_simulate(doc: object, **_kwargs: object) -> object:
            collection = doc.get_collection("Output:SQLite")  # type: ignore[union-attr]
            sqlite_object = collection.first()
            assert sqlite_object is not None
            assert sqlite_object.option_type == "SimpleAndTabular"
            return fake_result

        with (
            patch("idfkit.simulation.config.find_energyplus", return_value=fake_config),
            patch("idfkit.simulation.async_simulate", side_effect=_fake_simulate),
        ):
            result = await call_tool(client, "run_simulation", {"design_day": True})

        assert result["success"] is True
        # The original model must NOT be mutated — simulation runs on a copy.
        collection = state_with_model.document.get_collection("Output:SQLite")  # type: ignore[union-attr]
        sqlite_object = collection.first()
        assert sqlite_object is not None
        assert sqlite_object.option_type == "Simple"  # unchanged


class TestListOutputVariables:
    async def test_no_simulation(self, client: object) -> None:
        with pytest.raises(ToolError):
            await call_tool(client, "list_output_variables")

    async def test_falls_back_to_sql_when_rdd_and_mdd_are_empty(
        self, client: object, state_with_sql_only_simulation: ServerState
    ) -> None:
        result = await call_tool(client, "list_output_variables", model=ListOutputVariablesResult)
        assert result.total_available == 3
        assert result.returned == 3
        assert {item.name for item in result.variables} == {
            "Zone Mean Air Temperature",
            "Site Outdoor Air Drybulb Temperature",
            "Electricity:Facility",
        }

    async def test_sql_fallback_respects_search(
        self, client: object, state_with_sql_only_simulation: ServerState
    ) -> None:
        result = await call_tool(client, "list_output_variables", {"search": "Drybulb"}, ListOutputVariablesResult)
        assert result.total_available == 3
        assert result.returned == 1
        assert result.variables[0].name == "Site Outdoor Air Drybulb Temperature"

    async def test_search_invalid_regex_raises(
        self, client: object, state_with_sql_only_simulation: ServerState
    ) -> None:
        """An invalid regex pattern is rejected with a clear error."""
        with pytest.raises(ToolError, match="Invalid regex"):
            await call_tool(client, "list_output_variables", {"search": "[invalid"})

    async def test_search_regex_works(self, client: object, state_with_sql_only_simulation: ServerState) -> None:
        """Valid regex patterns still work as expected."""
        result = await call_tool(
            client, "list_output_variables", {"search": "^Zone.*Temperature$"}, ListOutputVariablesResult
        )
        assert result.returned == 1
        assert result.variables[0].name == "Zone Mean Air Temperature"

    async def test_sql_fallback_ignores_thread_bound_cached_sql(
        self, client: object, state_with_sql_only_simulation: ServerState, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        def _raise_thread_error(_self: SimulationResult) -> object:
            msg = "SQLite objects created in a thread can only be used in that same thread"
            raise RuntimeError(msg)

        monkeypatch.setattr(SimulationResult, "sql", property(_raise_thread_error))

        result = await call_tool(client, "list_output_variables", model=ListOutputVariablesResult)
        assert result.total_available == 3
        assert result.returned == 3


class TestQueryTimeseries:
    async def test_no_simulation(self, client: object) -> None:
        with pytest.raises(ToolError):
            await call_tool(client, "query_timeseries", {"variable_name": "Zone Mean Air Temperature"})

    async def test_meter_with_null_key_value(
        self, client: object, state_with_sql_only_simulation: ServerState, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        fake_ts = SimpleNamespace(
            variable_name="DistrictCooling:Facility",
            key_value=None,
            units="J",
            frequency="Hourly",
            timestamps=[datetime(2013, 1, 1, 1, 0, 0)],
            values=[123.0],
        )
        monkeypatch.setattr("idfkit.simulation.parsers.sql.SQLResult.get_timeseries", lambda *_args, **_kwargs: fake_ts)

        result = await call_tool(
            client,
            "query_timeseries",
            {
                "variable_name": "DistrictCooling:Facility",
                "key_value": "*",
                "frequency": "Hourly",
                "environment": "annual",
            },
        )

        assert result["variable_name"] == "DistrictCooling:Facility"
        assert result["key_value"] is None
        assert result["returned"] == 1


class TestExportTimeseries:
    async def test_no_simulation(self, client: object) -> None:
        with pytest.raises(ToolError):
            await call_tool(client, "export_timeseries", {"variable_name": "Zone Mean Air Temperature"})

    async def test_meter_with_null_key_value(
        self,
        client: object,
        state_with_sql_only_simulation: ServerState,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        fake_ts = SimpleNamespace(
            variable_name="DistrictCooling:Facility",
            key_value=None,
            units="J",
            frequency="Hourly",
            timestamps=[datetime(2013, 1, 1, 1, 0, 0)],
            values=[456.0],
        )
        monkeypatch.setattr("idfkit.simulation.parsers.sql.SQLResult.get_timeseries", lambda *_args, **_kwargs: fake_ts)

        monkeypatch.chdir(tmp_path)
        result = await call_tool(
            client,
            "export_timeseries",
            {
                "variable_name": "DistrictCooling:Facility",
                "key_value": "*",
                "frequency": "Hourly",
                "environment": "annual",
                "output_path": "district_cooling.csv",
            },
        )

        assert result["variable_name"] == "DistrictCooling:Facility"
        assert result["key_value"] is None
        assert result["rows"] == 1
        assert (tmp_path / "district_cooling.csv").exists()

    async def test_export_rejects_path_outside_cwd(
        self,
        client: object,
        state_with_sql_only_simulation: ServerState,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path: Path,
    ) -> None:
        monkeypatch.chdir(tmp_path)
        with pytest.raises(ToolError, match="allowed directory"):
            await call_tool(
                client,
                "export_timeseries",
                {"variable_name": "Test", "output_path": "/tmp/evil.csv"},  # noqa: S108
            )


class TestEnsureSqliteOutput:
    """Unit tests for _ensure_sqlite_output pre-flight function."""

    def test_adds_output_sqlite_when_missing(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_sqlite_output

        doc = state_with_model.require_model()
        assert "Output:SQLite" not in doc
        _ensure_sqlite_output(doc)
        obj = doc["Output:SQLite"].first()
        assert obj is not None
        assert obj.option_type == "SimpleAndTabular"

    def test_upgrades_simple_to_simple_and_tabular(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_sqlite_output

        doc = state_with_model.require_model()
        doc.add("Output:SQLite", "", option_type="Simple")
        _ensure_sqlite_output(doc)
        assert doc["Output:SQLite"].first().option_type == "SimpleAndTabular"

    def test_leaves_simple_and_tabular_unchanged(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_sqlite_output

        doc = state_with_model.require_model()
        doc.add("Output:SQLite", "", option_type="SimpleAndTabular")
        _ensure_sqlite_output(doc)
        assert len(list(doc["Output:SQLite"])) == 1

    def test_overrides_output_control_files(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_sqlite_output

        doc = state_with_model.require_model()
        doc.add("OutputControl:Files", output_sqlite="No", output_tabular="No")
        _ensure_sqlite_output(doc)
        ctrl = doc["OutputControl:Files"].first()
        assert ctrl.output_sqlite == "Yes"
        assert ctrl.output_tabular == "Yes"

    def test_leaves_output_control_files_yes_unchanged(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_sqlite_output

        doc = state_with_model.require_model()
        doc.add("OutputControl:Files", output_sqlite="Yes", output_tabular="Yes")
        _ensure_sqlite_output(doc)
        ctrl = doc["OutputControl:Files"].first()
        assert ctrl.output_sqlite == "Yes"
        assert ctrl.output_tabular == "Yes"


class TestEnsureSummaryReports:
    """Unit tests for _ensure_summary_reports pre-flight function."""

    def test_adds_reports_when_missing(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_summary_reports

        doc = state_with_model.require_model()
        assert "Output:Table:SummaryReports" not in doc
        _ensure_summary_reports(doc)
        obj = doc["Output:Table:SummaryReports"].first()
        assert obj is not None
        from idfkit_mcp.tools.simulation import _REQUIRED_SUMMARY_REPORTS

        assert obj.report_name in _REQUIRED_SUMMARY_REPORTS

    def test_appends_missing_reports_to_existing(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_summary_reports

        doc = state_with_model.require_model()
        doc.add("Output:Table:SummaryReports", data={"report_name": "AnnualBuildingUtilityPerformanceSummary"})
        _ensure_summary_reports(doc)
        obj = doc["Output:Table:SummaryReports"].first()
        # Original report preserved
        assert obj.report_name == "AnnualBuildingUtilityPerformanceSummary"
        # New ones appended
        existing = set()
        idx = 1
        while True:
            field = "report_name" if idx == 1 else f"report_name_{idx}"
            val = getattr(obj, field, None)
            if val is None:
                break
            existing.add(val)
            idx += 1
        assert "SensibleHeatGainSummary" in existing
        assert "HVACSizingSummary" in existing
        assert "AnnualBuildingUtilityPerformanceSummary" in existing

    def test_skips_when_all_summary_present(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_summary_reports

        doc = state_with_model.require_model()
        doc.add("Output:Table:SummaryReports", data={"report_name": "AllSummary"})
        _ensure_summary_reports(doc)
        obj = doc["Output:Table:SummaryReports"].first()
        # Should not append anything — AllSummary covers everything
        assert obj.report_name == "AllSummary"
        assert getattr(obj, "report_name_2", None) is None

    def test_skips_when_already_present(self, state_with_model: ServerState) -> None:
        from idfkit_mcp.tools.simulation import _ensure_summary_reports

        doc = state_with_model.require_model()
        from idfkit_mcp.tools.simulation import _REQUIRED_SUMMARY_REPORTS

        data: dict[str, str] = {}
        for i, name in enumerate(_REQUIRED_SUMMARY_REPORTS, 1):
            data["report_name" if i == 1 else f"report_name_{i}"] = name
        doc.add("Output:Table:SummaryReports", data=data)
        _ensure_summary_reports(doc)
        obj = doc["Output:Table:SummaryReports"].first()
        # Nothing appended beyond what's already there
        next_field = f"report_name_{len(_REQUIRED_SUMMARY_REPORTS) + 1}"
        assert getattr(obj, next_field, None) is None
