# cli-dolibarr

**[English](README_EN.md)**

> Dolibarr ERP/CRM 命令行工具与智能体工具层

基于 Click 框架的 Dolibarr REST API 管理工具。覆盖 49 个命令组、391 个 API 端点，同时提供 388 个 OpenAI Function Calling 格式的智能体工具定义。

## 安装

```bash
pip install cli-dolibarr
```

从 GitHub 安装最新版本：

```bash
pip install git+https://github.com/zswll2/cli-dolibarr.git
```

要求 Python >= 3.8，运行时依赖仅 click 和 requests。

## 配置

交互式初始化：

```bash
cli-dolibarr config init
```

或通过环境变量配置（见下方「环境变量」一节）。

## 快速开始

### 客户管理 (thirdparties)

```bash
cli-dolibarr thirdparties list                                # 列出客户
cli-dolibarr thirdparties get 42                              # 查看详情
cli-dolibarr thirdparties create --name "Acme Corp"           # 新建客户
cli-dolibarr thirdparties update 42 --town "Shanghai"         # 修改客户
```

### 产品管理 (products)

```bash
cli-dolibarr products list                                    # 列出产品
cli-dolibarr products get 7                                   # 查看详情
cli-dolibarr products create --ref "P001" --label "产品A"     # 新建产品
```

### 发票管理 (invoices)

```bash
cli-dolibarr invoices list                                    # 列出发票
cli-dolibarr invoices get 15                                  # 查看详情
cli-dolibarr invoices create --socid 42                       # 新建发票
```

### 订单管理 (orders)

```bash
cli-dolibarr orders list                                      # 列出订单
cli-dolibarr orders get 23                                    # 查看详情
cli-dolibarr orders create --socid 42 --date "2026-01-15"     # 新建订单
```

### 库存管理 (stockmovements)

```bash
cli-dolibarr stockmovements list                              # 查询流水
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty 50   # 入库
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty -10  # 出库
```

其余模块（proposals、shipments、projects、tasks、warehouses、contacts 等）用法相同，均支持 `list`、`get`、`create`、`update`、`delete` 操作。运行 `cli-dolibarr --help` 查看完整命令列表。

## 输出格式

默认以表格形式输出。通过全局选项切换格式：

```bash
cli-dolibarr products list --json         # JSON
cli-dolibarr invoices list --csv          # CSV（可直接导入 Excel）
```

## 全局选项

| 选项 | 说明 |
|------|------|
| `--json` | 以 JSON 格式输出 |
| `--csv` | 以 CSV 格式输出 |
| `--url` | 覆盖 Dolibarr API 地址 |
| `--api-key` | 覆盖 API Key |
| `--limit N` | 限制返回条数 |
| `--verify` | 启用 SSL 证书验证 |

## SQL 过滤器

通过 `--sql-filter` 对列表命令进行高级筛选：

```bash
cli-dolibarr thirdparties list --sql-filter "(t.name:like:'Acme%')"          # 模糊匹配
cli-dolibarr invoices list --sql-filter "(t.datec:>=:'2026-01-01')"          # 日期范围
cli-dolibarr products list --sql-filter "(t.toselect:=:1) and (t.status:=:1)" # 组合条件
cli-dolibarr orders list --sql-filter "(t.status:IN:1,2,3)"                  # IN 查询
```

支持的操作符：`:=`、`:like:`、`:<`、`:>`、`:<=`、`:>=`、`:!=`、`:IN:`、`:NOTIN:`

## 交互模式 (REPL)

```bash
cli-dolibarr repl
```

进入后无需重复认证，直接输入子命令：

```
dolibarr> thirdparties list
dolibarr> products get 7
dolibarr> exit
```

## Schema 管理

内置 API 自动发现系统，保持 CLI 命令与 Dolibarr 版本同步。

| 命令 | 说明 |
|------|------|
| `schema refresh --admin-api-key KEY` | 一键刷新：sync → extrafields → enrich |
| `schema sync` | 从 Dolibarr swagger 端点拉取最新 API 定义 |
| `schema extrafields --admin-api-key KEY` | 拉取自定义字段定义并注入 schema（需管理员 key） |
| `schema enrich` | 用 models_supplement.json 补全 model 字段定义（sync 后必须执行） |
| `schema diff` | 对比覆盖情况，显示哪些端点尚无 CLI 命令 |
| `schema generate --all` | 自动生成缺失的 CLI 命令文件 |
| `schema agents` | 重新生成 AGENTS.md 代码地图 |
| `schema export --format jsonl --output data.jsonl` | 导出端点数据，用于模型微调 |

`schema generate --all --dry-run` 可预览生成结果而不写入文件。

## 智能体工具

cli-dolibarr 提供完整的智能体工具层，自动生成 388 个 OpenAI Function Calling 格式的工具定义，支持 AI 智能体直接操作 Dolibarr ERP。

### 工具定义生成 (ToolsSchemaGenerator)

从 `schema.json` 生成 OpenAI Function Calling 格式的工具定义：

```python
from cli_dolibarr.dolibarr.tools import ToolsSchemaGenerator

gen = ToolsSchemaGenerator()
tools = gen.generate_all()  # 生成全部 388 个工具定义

# 按业务域筛选
invoice_tools = gen.generate_by_groups(['invoices', 'supplierinvoices'])

# 查询工具信息
gen.get_tool_names()                              # 列出所有工具名
gen.get_endpoint_by_tool_name("list_invoices")    # 按名称查找端点
gen.get_stats()                                   # 生成统计信息
```

### 工具执行器 (ToolsExecutor)

通过 REST API 执行工具调用：

```python
from cli_dolibarr.dolibarr.tools import ToolsExecutor

# 从配置文件或环境变量初始化
executor = ToolsExecutor.from_config()

# 执行工具调用
result = executor.execute("list_invoices", {"limit": 5})

# 查询可用工具
executor.list_tools()
executor.tool_count  # 388
```

也可直接指定连接参数：

```python
executor = ToolsExecutor(
    base_url="https://your-dolibarr.example.com/api/index.php",
    api_key="your_api_key",
    verify_ssl=False
)
```

### Hermes 插件

Hermes 插件安装后自动注册 388 个 Dolibarr 工具，智能体可直接调用：

```bash
bash cli_dolibarr/dolibarr/hermes_plugin/install.sh
```

安装脚本会自动完成：检测 Python 环境、安装 cli-dolibarr 包、复制插件文件、配置环境变量、在 Hermes 中启用插件。

### vLLM / Gemma 4 部署

使用 vLLM 部署 Gemma 4 模型并启用工具调用支持：

```bash
python -m vllm.entrypoints.openai.api_server \
    --model google/gemma-4-31b-it \
    --tool-call-parser gemma4 \
    --enable-auto-tool-choice
```

微调训练数据的格式和完整流程参见 `docs/FINE_TUNING_GUIDE.md`。

### 工具命名规则

工具名由 HTTP 方法和 URL 路径自动推导：

| HTTP 方法 | URL 模式 | 工具名 |
|-----------|---------|--------|
| GET | /resource | `list_{resource}` |
| GET | /resource/{id} | `get_{resource}` |
| POST | /resource | `create_{resource}` |
| PUT | /resource/{id} | `update_{resource}` |
| DELETE | /resource/{id} | `delete_{resource}` |
| GET | /resource/ref/{ref} | `get_{resource}_by_ref` |

## 环境变量

| 变量 | 说明 |
|------|------|
| `DOLIBARR_URL` | API 完整地址，例如 `https://your-dolibarr.example.com/api/index.php` |
| `DOLIBARR_API_KEY` | Dolibarr 用户设置中的 API Key |
| `DOLIBARR_VERIFY_SSL` | 设为 `1` 或 `true` 启用 SSL 证书验证 |

配置文件路径：`~/.config/cli-dolibarr/config.json`

## 相关文档

- `API_SYNC_GUIDE.md` - API 同步与 schema 生成指南
- `docs/FINE_TUNING_GUIDE.md` - Gemma 4 模型微调训练数据格式与流程
- `AGENTS.md` - AI 代码地图，包含全部端点和数据模型

## 许可证

MIT License. 源码仓库：https://github.com/zswll2/cli-dolibarr
