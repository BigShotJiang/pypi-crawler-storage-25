"""OpenAI Tools Schema Generator for Dolibarr API.

Generates valid OpenAI Function Calling tool definitions from schema.json.
Each of the 391 API endpoints becomes a tool with proper naming, parameters,
and descriptions suitable for AI model consumption.

Excluded endpoints:
  - login group (credential exposure risk)
  - documents/upload (binary upload, not JSON-compatible)
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

_SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.json"

_EXCLUDED_GROUPS = {"login"}
_EXCLUDED_ENDPOINTS = {
    ("POST", "/documents/upload"),
}

# Known irregular singularizations for Dolibarr resource groups
_SINGULAR_OVERRIDES = {
    "invoices": "invoice",
    "warehouses": "warehouse",
    "status": "status",
    "supplierinvoices": "supplier_invoice",
    "supplierorders": "supplier_order",
    "supplierproposals": "supplier_proposal",
    "thirdparties": "thirdparty",
    "stockmovements": "stock_movement",
    "bankaccounts": "bank_account",
    "agendaevents": "agenda_event",
    "mobilehubapi": "mobilehub_api",
    "orderprocessor": "order_processor",
    "multicurrencies": "multi_currency",
    "boms": "bom",
    "mos": "mo",
}


def _load_schema() -> dict:
    with open(_SCHEMA_PATH, encoding="utf-8") as f:
        return json.load(f)


def _singularize(word: str) -> str:
    if word in _SINGULAR_OVERRIDES:
        return _SINGULAR_OVERRIDES[word]
    if word.endswith("ies"):
        return word[:-3] + "y"
    if word.endswith("s") and not word.endswith("ss") and len(word) > 2:
        return word[:-1]
    return word


def _snake_case(name: str) -> str:
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', name)
    s = re.sub(r'([a-z\d])([A-Z])', r'\1_\2', s)
    s = s.replace("-", "_")
    return s.lower()


class ToolsSchemaGenerator:
    """Generate OpenAI Function Calling tool definitions from Dolibarr schema."""

    def __init__(self, schema_path: Optional[str] = None):
        if schema_path:
            with open(schema_path, encoding="utf-8") as f:
                self._schema = json.load(f)
        else:
            self._schema = _load_schema()
        self._models = self._schema.get("models", {})
        self._endpoints = self._schema.get("endpoints", [])
        self._name_map: Dict[str, dict] = {}
        self._build_name_map()

    def _is_excluded(self, endpoint: dict) -> bool:
        group = endpoint.get("group", "")
        method = endpoint.get("method", "")
        path = endpoint.get("path", "")
        if group in _EXCLUDED_GROUPS:
            return True
        if (method, path) in _EXCLUDED_ENDPOINTS:
            return True
        return False

    @staticmethod
    def _path_segments(path: str) -> List[str]:
        return [s for s in path.split("/") if s]

    def _endpoint_to_tool_name(self, endpoint: dict) -> str:
        """Derive a unique function name from method + path + group.

        Uses all meaningful path segments to build a descriptive name.
        """
        method = endpoint["method"]
        path = endpoint["path"]
        group = endpoint.get("group", "")
        segs = self._path_segments(path)

        singular = _singularize(group)
        # Split compound singulars like "supplier_invoice" into parts
        resource_parts = singular.split("_")

        # Identify placeholder positions
        placeholders = {i for i, s in enumerate(segs) if s.startswith("{")}

        # Get concrete (non-placeholder) segments, excluding the group root
        concrete = []
        for i, seg in enumerate(segs):
            if seg.startswith("{"):
                continue
            snake = _snake_case(seg)
            # Skip if it matches the group/root
            if snake == group or snake == singular or snake in resource_parts:
                continue
            concrete.append((i, snake))

        # Detect ref/ref_ext patterns
        has_ref = any(s == "ref" for s in segs)
        has_ref_ext = any(s == "ref_ext" for s in segs)

        # Detect if this is a sub-resource under an {id}
        # sub_resources = concrete segments that appear AFTER a placeholder
        sub_after_id = []
        for i, snake in concrete:
            # Check if there's a placeholder before this segment
            for j in range(i - 1, -1, -1):
                if segs[j].startswith("{"):
                    sub_after_id.append(snake)
                    break
                elif not segs[j].startswith("{"):
                    break

        # ---------------------------------------------------------------
        # Build the name
        # ---------------------------------------------------------------
        parts = []

        # Action verb
        if method == "GET":
            # Check if listing or getting single
            has_id_param = any(s.startswith("{id") or s.startswith("{socid}") or
                              s.startswith("{code}") or s.startswith("{iso}") or
                              s.startswith("{email}") or s.startswith("{track_id}") or
                              s.startswith("{barcode}") or s.startswith("{month}")
                              for s in segs)
            if has_id_param or has_ref or has_ref_ext:
                verb = "get"
            else:
                verb = "list"
        elif method == "POST":
            verb = "create"
        elif method in ("PUT", "PATCH"):
            verb = "update"
        elif method == "DELETE":
            verb = "delete"
        else:
            verb = method.lower()

        parts.append(verb)
        parts.append(singular)

        # Add sub-resource info from concrete segments
        for _, snake in concrete:
            if snake not in parts:
                parts.append(snake)

        # Add ref/ref_ext disambiguation
        if has_ref_ext:
            parts.append("by_ref_ext")
        elif has_ref:
            parts.append("by_ref")

        # Clean up
        name = "_".join(parts)
        name = re.sub(r'_+', '_', name).strip("_")
        return name

    def _build_name_map(self) -> None:
        """Pre-build all tool names and resolve collisions."""
        candidates: Dict[str, List[dict]] = {}
        for ep in self._endpoints:
            if self._is_excluded(ep):
                continue
            name = self._endpoint_to_tool_name(ep)
            candidates.setdefault(name, []).append(ep)

        for name, eps in candidates.items():
            if len(eps) == 1:
                self._name_map[name] = eps[0]
            else:
                for ep in eps:
                    suffix = self._make_unique_suffix(ep, eps)
                    final_name = f"{name}_{suffix}" if suffix else name
                    if final_name in self._name_map:
                        final_name = f"{final_name}_{ep['method'].lower()}"
                    self._name_map[final_name] = ep

    def _make_unique_suffix(self, ep: dict, siblings: List[dict]) -> str:
        method = ep["method"].lower()
        path = ep["path"]
        segs = self._path_segments(path)

        # Try method first
        methods = {e["method"] for e in siblings}
        if len(methods) > 1:
            return method

        # Try last concrete segment that differs
        concrete = [(i, _snake_case(s)) for i, s in enumerate(segs) if not s.startswith("{")]
        if concrete:
            last = concrete[-1][1]
            sibling_lasts = set()
            for s in siblings:
                if s is ep:
                    continue
                s_segs = self._path_segments(s["path"])
                s_concrete = [_snake_case(seg) for seg in s_segs if not seg.startswith("{")]
                if s_concrete:
                    sibling_lasts.add(s_concrete[-1])
            if last not in sibling_lasts:
                return last

        # Try second-to-last
        if len(concrete) >= 2:
            return concrete[-2][1]

        return method

    # ------------------------------------------------------------------
    # Parameters
    # ------------------------------------------------------------------

    def _model_to_parameters(self, model_name: str) -> Dict[str, Any]:
        model = self._models.get(model_name)
        if not model:
            return {"type": "object", "properties": {}, "required": []}
        props = model.get("properties", {})
        if not props:
            return {"type": "object", "properties": {}, "required": []}

        properties: Dict[str, Any] = {}
        for field_name, field_def in props.items():
            json_type = self._map_type(field_def.get("type", "string"))
            desc = field_def.get("description", "").strip()
            prop: Dict[str, Any] = {"type": json_type}
            if desc:
                prop["description"] = desc
            if field_name == "request_data":
                prop["items"] = {"type": "object"}
            properties[field_name] = prop

        return {"type": "object", "properties": properties, "required": []}

    @staticmethod
    def _map_type(schema_type: str) -> str:
        return {"integer": "integer", "number": "number", "boolean": "boolean",
                "array": "array", "object": "object"}.get(schema_type, "string")

    def _endpoint_to_parameters(self, endpoint: dict) -> Dict[str, Any]:
        properties: Dict[str, Any] = {}
        required: List[str] = []

        for param in endpoint.get("parameters", []):
            name = param["name"]
            json_type = self._map_type(param.get("type", "string"))
            prop: Dict[str, Any] = {"type": json_type}
            desc = param.get("description", "").strip()
            if desc:
                prop["description"] = desc
            properties[name] = prop
            if param.get("required", False) or param.get("in") == "path":
                required.append(name)

        body_model = endpoint.get("request_body")
        if body_model and isinstance(body_model, str):
            body_params = self._model_to_parameters(body_model)
            for fname, fdef in body_params.get("properties", {}).items():
                if fname not in properties:
                    properties[fname] = fdef

        return {"type": "object", "properties": properties, "required": required}

    # ------------------------------------------------------------------
    # Tool generation
    # ------------------------------------------------------------------

    def _endpoint_to_tool(self, name: str, endpoint: dict) -> dict:
        summary = endpoint.get("summary", "")
        summary = re.sub(r'[^\w\s,.\-()/:;+=]', '', summary).strip()
        if not summary:
            summary = f"{endpoint['method']} {endpoint['path']}"

        return {
            "type": "function",
            "function": {
                "name": name,
                "description": summary,
                "parameters": self._endpoint_to_parameters(endpoint),
            },
        }

    def generate_all(self) -> List[dict]:
        tools = []
        for name, ep in self._name_map.items():
            tools.append(self._endpoint_to_tool(name, ep))
        return tools

    def generate_by_groups(self, groups: List[str]) -> List[dict]:
        group_set = set(groups)
        tools = []
        for name, ep in self._name_map.items():
            if ep.get("group", "") in group_set:
                tools.append(self._endpoint_to_tool(name, ep))
        return tools

    def get_tool_names(self) -> List[str]:
        return list(self._name_map.keys())

    def get_endpoint_by_tool_name(self, tool_name: str) -> Optional[dict]:
        return self._name_map.get(tool_name)

    def get_stats(self) -> Dict[str, int]:
        total = len(self._endpoints)
        excluded = sum(1 for ep in self._endpoints if self._is_excluded(ep))
        return {
            "total_endpoints": total,
            "excluded": excluded,
            "tools_generated": len(self._name_map),
        }
