"""Agent tools for Dolibarr API.

Provides:
  - ToolsSchemaGenerator: Generate OpenAI Function Calling tool definitions
  - ToolsExecutor: Execute tool calls against the Dolibarr REST API

Usage:
    from cli_dolibarr.dolibarr.tools import ToolsSchemaGenerator, ToolsExecutor

    # Generate tool schemas
    gen = ToolsSchemaGenerator()
    tools = gen.generate_all()  # 391 tool definitions

    # Execute a tool call
    executor = ToolsExecutor.from_config()
    result = executor.execute("list_status", {})
"""

from cli_dolibarr.dolibarr.tools.tools_schema import ToolsSchemaGenerator
from cli_dolibarr.dolibarr.tools.executor import ToolsExecutor

__all__ = ["ToolsSchemaGenerator", "ToolsExecutor"]
