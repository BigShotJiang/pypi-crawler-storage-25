"""ToolsExecutor — Execute OpenAI tool calls against Dolibarr REST API.

Maps tool names (from ToolsSchemaGenerator) back to HTTP requests
and executes them via requests.Session.

Usage:
    from cli_dolibarr.dolibarr.tools.executor import ToolsExecutor

    executor = ToolsExecutor.from_config()
    result = executor.execute("list_status", {})
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import urllib3

from cli_dolibarr.dolibarr.core.config import DolibarrConfig
from cli_dolibarr.dolibarr.tools.tools_schema import ToolsSchemaGenerator

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_SCHEMA_PATH = Path(__file__).resolve().parent.parent / "schema.json"


def _load_schema() -> dict:
    with open(_SCHEMA_PATH, encoding="utf-8") as f:
        return json.load(f)


class ToolsExecutor:
    """Execute tool calls by name against the Dolibarr REST API."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        verify_ssl: bool = False,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.verify_ssl = verify_ssl

        self._session = requests.Session()
        self._session.verify = verify_ssl
        self._session.headers.update({
            "Content-Type": "application/json",
            "DOLAPIKEY": api_key,
        })

        self._schema = _load_schema()
        self._generator = ToolsSchemaGenerator()
        self._registry = self._build_registry()

    @classmethod
    def from_config(cls) -> "ToolsExecutor":
        """Create an executor from the CLI config file or environment."""
        config = DolibarrConfig()
        config.resolve()
        if not config.is_configured():
            raise RuntimeError(
                "Dolibarr not configured. Run 'cli-dolibarr config init' "
                "or set DOLIBARR_URL + DOLIBARR_API_KEY env vars."
            )
        return cls(
            base_url=config.base_url,
            api_key=config.api_key,
            verify_ssl=config.verify_ssl,
        )

    # ------------------------------------------------------------------
    # Registry: tool_name → endpoint metadata
    # ------------------------------------------------------------------

    def _build_registry(self) -> Dict[str, dict]:
        """Build name → endpoint mapping from schema."""
        registry: Dict[str, dict] = {}
        schema_endpoints = self._schema.get("endpoints", [])

        # Use the generator's name map to get canonical names
        for tool_name in self._generator.get_tool_names():
            ep = self._generator.get_endpoint_by_tool_name(tool_name)
            if ep:
                registry[tool_name] = {
                    "method": ep.get("method", "GET"),
                    "path": ep.get("path", ""),
                    "parameters": ep.get("parameters", []),
                    "request_body": ep.get("request_body"),
                }
        return registry

    # ------------------------------------------------------------------
    # Request building
    # ------------------------------------------------------------------

    @staticmethod
    def _build_path(path_template: str, arguments: dict) -> str:
        """Substitute {param} placeholders in path with argument values."""
        result = path_template
        for key, value in arguments.items():
            placeholder = "{" + key + "}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        return result

    @staticmethod
    def _extract_path_params(path_template: str) -> List[str]:
        """Extract path parameter names like 'id' from '/resource/{id}'."""
        return re.findall(r'\{(\w+)\}', path_template)

    def _build_request(
        self, tool_name: str, arguments: dict
    ) -> Tuple[str, str, Optional[dict], Optional[dict]]:
        """Map tool name + arguments → (method, path, query_params, body).

        Returns:
            (http_method, resolved_path, query_params, request_body)
        """
        entry = self._registry.get(tool_name)
        if not entry:
            raise ValueError(f"Unknown tool: {tool_name}")

        method = entry["method"]
        path_template = entry["path"]
        path_params = self._extract_path_params(path_template)
        schema_params = entry.get("parameters", [])
        body_model_name = entry.get("request_body")

        # Separate path params from query/body params
        path_arg_names = set(path_params)
        # Also check schema parameters for path params
        for p in schema_params:
            if p.get("in") == "path" and p.get("name") not in path_arg_names:
                path_arg_names.add(p.get("name"))

        # Resolve path
        path_args = {k: v for k, v in arguments.items() if k in path_arg_names}
        resolved_path = self._build_path(path_template, path_args)

        # Query parameters (for GET requests)
        query_params = None
        if method in ("GET",):
            query_param_names = {
                p.get("name")
                for p in schema_params
                if p.get("in") == "query"
            }
            query_params = {
                k: v for k, v in arguments.items()
                if k in query_param_names and v is not None
            }

        # Body parameters
        body = None
        if method in ("POST", "PUT", "PATCH") and arguments:
            # Everything that's not a path or query param goes in body
            non_body_keys = path_arg_names
            if query_params:
                non_body_keys = non_body_keys | set(query_params.keys())
            body_fields = {
                k: v for k, v in arguments.items()
                if k not in non_body_keys and v is not None
            }
            if body_fields:
                body = body_fields

        return method, resolved_path, query_params, body

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def _make_url(self, path: str) -> str:
        """Build full API URL from path."""
        path = path.lstrip("/")
        return f"{self.base_url}/{path}"

    def execute(self, tool_name: str, arguments: dict) -> Any:
        """Execute a tool call and return the API response.

        Args:
            tool_name: Function name from the generated tools schema.
            arguments: Dict of parameter values matching the tool's schema.

        Returns:
            dict | list | str: The API response body.

        Raises:
            ValueError: If tool_name is not recognized.
            requests.RequestException: On network errors.
        """
        try:
            method, path, query_params, body = self._build_request(
                tool_name, arguments
            )
        except ValueError:
            raise
        except Exception as exc:
            return {"error": f"Failed to build request: {exc}"}

        url = self._make_url(path)

        try:
            if method == "GET":
                resp = self._session.get(url, params=query_params or {})
            elif method == "POST":
                resp = self._session.post(url, json=body)
            elif method == "PUT":
                resp = self._session.put(url, json=body)
            elif method == "PATCH":
                resp = self._session.patch(url, json=body)
            elif method == "DELETE":
                resp = self._session.delete(url)
            else:
                return {"error": f"Unsupported HTTP method: {method}"}
        except requests.RequestException as exc:
            return {"error": f"Request failed: {exc}", "status_code": None}

        # Parse response
        if resp.status_code >= 400:
            try:
                error_data = resp.json()
                error_msg = error_data.get("error", {}).get("message", str(error_data))
            except (ValueError, AttributeError):
                error_msg = resp.text[:500]
            return {
                "error": error_msg,
                "status_code": resp.status_code,
            }

        content_type = resp.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                return resp.json()
            except ValueError:
                return resp.text.strip()
        return resp.text.strip()

    def get_tool_schema(self, tool_name: str) -> Optional[dict]:
        """Get the OpenAI tool definition for a specific tool name."""
        for tool in self._generator.generate_all():
            if tool["function"]["name"] == tool_name:
                return tool
        return None

    def list_tools(self) -> List[str]:
        """List all available tool names."""
        return list(self._registry.keys())

    @property
    def tool_count(self) -> int:
        """Number of registered tools."""
        return len(self._registry)
