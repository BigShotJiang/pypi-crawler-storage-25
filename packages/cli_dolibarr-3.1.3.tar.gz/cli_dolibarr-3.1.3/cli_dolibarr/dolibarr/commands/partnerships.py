import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def partnerships():
    pass


@partnerships.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_partnerships(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('partnerships', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@partnerships.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_partnership(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('partnerships', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@partnerships.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--fk_soc', default=None, type=int, help='Third party ID')
@click.option('--type', 'partnership_type', default=None, help='Partnership type')
@click.option('--date_start', default=None, help='Start date')
@click.option('--date_end', default=None, help='End date')
@click.pass_context
def create_partnership(ctx, data, fk_soc, partnership_type, date_start, date_end):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if fk_soc is not None:
                payload['fk_soc'] = fk_soc
            if partnership_type is not None:
                payload['type'] = partnership_type
            if date_start is not None:
                payload['date_start'] = date_start
            if date_end is not None:
                payload['date_end'] = date_end
        result = client.post('partnerships', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@partnerships.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_partnership(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('partnerships', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('partnerships', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@partnerships.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_partnership(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('partnerships', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
