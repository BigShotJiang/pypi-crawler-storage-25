"""CLI commands for Dolibarr mobilehub module.

Uses SessionClient for custom endpoints under /custom/mobilehub/api/.
"""

import sys
import json
import click

from cli_dolibarr.dolibarr.core.client import DolibarrAPIError
from cli_dolibarr.dolibarr.core.session_client import SessionClient
from cli_dolibarr.dolibarr.core.output import OutputFormatter

PREFIX = "custom/mobilehub/api"


def _get_session_client(ctx) -> SessionClient:
    cfg = ctx.obj["config"]
    cfg.resolve()
    base_url = cfg.base_url
    api_key = cfg.api_key
    if not base_url or not api_key:
        click.echo(
            "Error: base_url and api_key required (config or flags)",
            err=True,
        )
        sys.exit(1)
    return SessionClient(base_url=base_url, api_key=api_key)


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj["formatter"]


def _output(ctx, result):
    _get_formatter(ctx).output(result)


@click.group()
def mobilehub():
    """MobileHub module commands (mobile warehouse operations)."""


@mobilehub.command()
@click.option("--query", required=True, help="Search query string")
@click.pass_context
def search(ctx, query):
    """Search products by keyword."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/product_search.php", query=query)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("stock")
@click.option("--product-id", required=True, help="Product ID")
@click.pass_context
def stock(ctx, product_id):
    """Query stock for a specific product."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/product_stock_search.php", product_id=product_id)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("stock-all")
@click.pass_context
def stock_all(ctx):
    """Query all stock levels."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/stock_query_all.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.group()
def stockin():
    """Stock-in operations."""


@stockin.command("upload")
@click.option("--data", default=None, help="Upload data JSON")
@click.pass_context
def stockin_upload(ctx, data):
    """Upload stock-in data."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/stockin_upload.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockin.command("execute")
@click.option("--data", default=None, help="Stock-in execution data JSON")
@click.pass_context
def stockin_execute(ctx, data):
    """Execute stock-in."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/stockin_execute.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockin.command("match-po")
@click.option("--data", default=None, help="PO match data JSON")
@click.pass_context
def stockin_match_po(ctx, data):
    """Match stock-in with purchase order."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/stockin_match_po.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockin.command("create-invoice")
@click.option("--data", default=None, help="Invoice creation data JSON")
@click.pass_context
def stockin_create_invoice(ctx, data):
    """Create invoice from stock-in."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/stockin_create_invoice.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockin.command("ocr")
@click.option("--data", default=None, help="OCR processing data JSON")
@click.pass_context
def stockin_ocr(ctx, data):
    """Run OCR on stock-in document."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/stockin_ocr.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("customer-orders")
@click.option("--data", default=None, help="Filter data JSON")
@click.pass_context
def customer_orders(ctx, data):
    """List customer orders."""
    client = _get_session_client(ctx)
    try:
        if data:
            params = json.loads(data)
        else:
            params = {}
        result = client.get(f"{PREFIX}/customer_order_list.php", **params)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("customer-search")
@click.option("--query", required=True, help="Customer search query")
@click.pass_context
def customer_search(ctx, query):
    """Search customers."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/customer_search.php", query=query)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("shipment-get")
@click.option("--id", "record_id", required=True, help="Shipment ID")
@click.pass_context
def shipment_get(ctx, record_id):
    """Get shipment details."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/shipment_get.php", id=record_id)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("shipment-confirm")
@click.option("--data", default=None, help="Shipment confirmation data JSON")
@click.pass_context
def shipment_confirm(ctx, data):
    """Confirm shipment."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/shipment_confirm.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("print-label")
@click.option("--data", default=None, help="Label print data JSON")
@click.pass_context
def print_label(ctx, data):
    """Print a label."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/print_label_api.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@mobilehub.command("quick-sales")
@click.option("--data", required=True, help="Quick sales data JSON")
@click.pass_context
def quick_sales(ctx, data):
    """Execute quick sales operation."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data)
        result = client.post(f"{PREFIX}/quick_sales_execute.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)




@mobilehub.command("warehouses")
@click.pass_context
def warehouses(ctx):
    """List warehouses."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/warehouse_list.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mobilehub.command("templates")
@click.pass_context
def templates(ctx):
    """List available templates."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/template_list.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


