"""
Schema-driven API discovery and code generation.

Provides subcommands for fetching, inspecting, and generating CLI code
from the Dolibarr Swagger API specification.
"""

import json
import os
import sys
from pathlib import Path

import click

from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter
from cli_dolibarr.dolibarr.core.schema_agents import SchemaAgentsGenerator
from cli_dolibarr.dolibarr.core.schema_manager import SchemaManager
from cli_dolibarr.dolibarr.core.schema_generator import SchemaGenerator


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def schema():
    """Schema-driven API discovery and code generation."""
    pass


@schema.command()
@click.pass_context
def sync(ctx):
    """Fetch API schema from Dolibarr swagger.json endpoint.

    Downloads the Swagger/OpenAPI spec from the configured Dolibarr instance,
    normalizes it, and saves it locally for use by other schema commands.
    """
    client = _get_client(ctx)
    try:
        manager = SchemaManager()

        click.echo("Fetching swagger.json from Dolibarr...")
        swagger = manager.fetch_swagger(client)
        click.echo(f"  Swagger version: {swagger.get('swagger', '?')}")

        click.echo("Normalizing schema...")
        schema = manager.normalize(swagger)

        click.echo("Saving schema.json...")
        manager.save(schema)

        endpoints = schema['endpoints']
        models = schema['models']
        coverage = schema['cli_coverage']

        groups_in_schema = {ep['group'] for ep in endpoints}
        covered_groups = {
            g for g in groups_in_schema if g in coverage
        }
        uncovered_groups = groups_in_schema - covered_groups

        click.echo("\nSync complete.")
        click.echo(f"  Endpoints: {len(endpoints)}")
        click.echo(f"  Models:    {len(models)}")
        click.echo(f"  Groups:    {len(groups_in_schema)} "
                    f"({len(covered_groups)} covered, "
                    f"{len(uncovered_groups)} uncovered)")
        click.echo(f"  Saved to:  {manager.SCHEMA_PATH}")

        if uncovered_groups:
            click.echo("\nUncovered groups:")
            for g in sorted(uncovered_groups):
                click.echo(f"  - {g}")
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command()
@click.option('--json', 'as_json', is_flag=True, default=False,
              help='Output raw diff data as JSON')
@click.option('--group', 'group_filter', default=None,
              help='Filter to groups matching this substring')
@click.pass_context
def diff(ctx, as_json, group_filter):
    """Compare API schema against current CLI commands.

    Shows which API endpoints are covered by CLI commands and which
    are missing, helping identify gaps in CLI coverage.
    """
    try:
        manager = SchemaManager()
        result = manager.diff(group_filter=group_filter)

        if as_json:
            click.echo(json.dumps(result, indent=2))
            return

        match_map = result['match_map']

        click.echo(
            f"Coverage: {len(result['covered'])}/"
            f"{result['total_swagger_groups']} "
            f"({result['coverage_pct']}%)"
        )
        click.echo(
            f"CLI groups: {result['total_cli_groups']} "
            f"({len(result['extra_cli'])} not in swagger)"
        )
        click.echo()

        if result['covered']:
            click.echo("Covered:")
            for g in result['covered']:
                cli_match = match_map.get(g, g)
                label = f"{g} → {cli_match}" if cli_match != g else g
                click.echo(f"  ✓ {label}")
            click.echo()

        if result['uncovered']:
            click.echo("Uncovered (no CLI command):")
            for g in result['uncovered']:
                click.echo(f"  ✗ {g}")
            click.echo()

        if result['extra_cli']:
            click.echo("Extra CLI (not in swagger):")
            for g in result['extra_cli']:
                click.echo(f"  + {g}")

    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command()
@click.option('--group', default=None,
              help='Generate only a specific endpoint group')
@click.option('--all', 'generate_all', is_flag=True, default=False,
              help='Generate all uncovered groups')
@click.option('--dry-run', is_flag=True, default=False,
              help='Preview without writing files')
@click.pass_context
def generate(ctx, group, generate_all, dry_run):
    """Generate CLI command files from API schema.

    Creates Click command files in cli_dolibarr/dolibarr/commands/
    based on the endpoints defined in the synced API schema.
    Never overwrites existing files.
    """
    try:
        manager = SchemaManager()
        generator = SchemaGenerator(manager)
        schema_data = manager.load()
        if schema_data is None:
            click.echo("Error: schema.json not found. Run 'schema sync' first.", err=True)
            sys.exit(1)

        if group:
            endpoints = [ep for ep in schema_data['endpoints'] if ep['group'] == group]
            if not endpoints:
                click.echo(f"No endpoints found for group '{group}'.", err=True)
                sys.exit(1)
            models = schema_data.get('models', {})
            content = generator.generate_group(group, endpoints, models)
            filename = f"{group.replace('-', '_')}.py"
            coverage = manager.scan_cli_coverage()
            if group in coverage:
                click.echo(f"Skipping {group}: already covered by {coverage[group]['file']}")
                return
            if dry_run:
                click.echo(f"Would generate: {filename} ({len(content.splitlines())} lines)")
                click.echo("---")
                click.echo(content[:2000])
                if len(content) > 2000:
                    click.echo(f"... ({len(content) - 2000} more chars)")
            else:
                written = generator._write_file(filename, content)
                if written:
                    click.echo(f"Generated: {filename} ({len(content.splitlines())} lines)")
                else:
                    click.echo(f"Skipped: {filename} (already exists)")
        else:
            if not generate_all:
                click.echo("Specify --group NAME or --all. Use --dry-run to preview.")
                return
            results = generator.generate_all(dry_run=dry_run)
            if not results:
                click.echo("All groups are already covered. Nothing to generate.")
                return
            for grp, fname, written in results:
                if dry_run:
                    click.echo(f"Would generate: {fname} for group '{grp}'")
                elif written:
                    click.echo(f"Generated: {fname} for group '{grp}'")
                else:
                    click.echo(f"Skipped: {fname} (already exists)")
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command('agents')
@click.pass_context
def agents(ctx):
    """Generate AGENTS.md from API schema.

    Produces a comprehensive reference document for AI agents that describes
    all available API endpoints, parameters, and usage patterns.
    """
    try:
        manager = SchemaManager()
        gen = SchemaAgentsGenerator(manager)
        content = gen.generate()

        agents_path = Path(__file__).resolve().parent.parent.parent.parent / 'AGENTS.md'
        agents_path.write_text(content, encoding='utf-8')

        click.echo(f"Generated {agents_path}")
        click.echo(f"  {len(content)} bytes, {content.count(chr(10))} lines")
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command()
@click.pass_context
def enrich(ctx):
    """Enrich schema.json models using models_supplement.json.

    Replaces models that only have 'request_data' with proper field definitions
    from the supplement file. Idempotent: safe to run multiple times.
    """
    try:
        manager = SchemaManager()
        result = manager.enrich()

        click.echo(f"Models enriched: {result['enriched']}")
        click.echo(f"Skipped (no supplement entry): {result['skipped_bad']}")
        click.echo(f"Skipped (already good): {result['skipped_good']}")

        if result['enriched'] > 0:
            click.echo(f"\nSaved to: {manager.SCHEMA_PATH}")
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command()
@click.option('--format', 'fmt', default='jsonl',
              type=click.Choice(['jsonl', 'csv', 'conversations']),
              help='Export format (default: jsonl)')
@click.option('--output', 'output_file', default=None,
              type=click.Path(), help='Write to file instead of stdout')
@click.pass_context
def export(ctx, fmt, output_file):
    """Export schema data for AI fine-tuning or analysis."""
    try:
        manager = SchemaManager()
        result = manager.export_data(fmt)

        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(result)
                if not result.endswith('\n'):
                    f.write('\n')
            click.echo(f"Exported to {output_file}")
        else:
            click.echo(result)

    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _resolve_admin_key(ctx, admin_api_key):
    """Resolve admin API key: CLI option > env var > default client key."""
    if admin_api_key:
        return admin_api_key
    env_key = os.environ.get('DOLIBARR_ADMIN_API_KEY')
    if env_key:
        return env_key
    return None


@schema.command()
@click.option('--admin-api-key', default=None,
              help='Admin API key (overrides config). Falls back to DOLIBARR_ADMIN_API_KEY env var.')
@click.pass_context
def extrafields(ctx, admin_api_key):
    """Fetch extrafield definitions from Dolibarr and inject into schema.

    Calls the /setup/extrafields API endpoint (requires admin API key) and
    adds array_options properties to the corresponding models in schema.json.

    Admin key resolution: --admin-api-key > DOLIBARR_ADMIN_API_KEY env > default key.
    """
    client = _get_client(ctx)
    resolved_key = _resolve_admin_key(ctx, admin_api_key)
    if resolved_key:
        client.session.headers['DOLAPIKEY'] = resolved_key
    try:
        manager = SchemaManager()
        click.echo("Fetching extrafield definitions...")
        ef_data = manager.fetch_extrafields(client)
        total = sum(len(v) for v in ef_data.values())
        click.echo(f"  Found {total} extrafields across {len(ef_data)} object types")

        result = manager.inject_extrafields(ef_data)
        click.echo(f"  Injected into {result['injected_models']} models "
                    f"({result['injected_fields']} field definitions)")
        if result['injected_models'] > 0:
            click.echo(f"\nSaved to: {manager.SCHEMA_PATH}")
    except RuntimeError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@schema.command()
@click.option('--admin-api-key', default=None,
              help='Admin API key. Falls back to DOLIBARR_ADMIN_API_KEY env var.')
@click.pass_context
def refresh(ctx, admin_api_key):
    """Full schema refresh: sync + extrafields + enrich.

    One-command pipeline that:
    1. Syncs API schema from Dolibarr swagger
    2. Fetches extrafield definitions (admin key via --admin-api-key or DOLIBARR_ADMIN_API_KEY)
    3. Enriches models with supplement definitions
    """
    client = _get_client(ctx)
    resolved_key = _resolve_admin_key(ctx, admin_api_key)
    if resolved_key:
        client.session.headers['DOLAPIKEY'] = resolved_key
    try:
        manager = SchemaManager()
        click.echo("Refreshing schema...")

        click.echo("  [1/3] Syncing from Dolibarr swagger...")
        swagger = manager.fetch_swagger(client)
        schema = manager.normalize(swagger)
        manager.save(schema)
        endpoints = len(schema['endpoints'])
        models_count = len(schema['models'])
        click.echo(f"         {endpoints} endpoints, {models_count} models")

        click.echo("  [2/3] Fetching extrafields...")
        ef_stats = {'injected_models': 0, 'injected_fields': 0, 'elementtypes': 0}
        try:
            ef_data = manager.fetch_extrafields(client)
            ef_stats = manager.inject_extrafields(ef_data)
            click.echo(f"         {ef_stats['injected_fields']} fields injected "
                        f"into {ef_stats['injected_models']} models")
        except RuntimeError:
            click.echo("         Skipped (requires admin API key)")

        click.echo("  [3/3] Enriching models...")
        enrich_stats = manager.enrich()
        click.echo(f"         {enrich_stats['enriched']} enriched, "
                    f"{enrich_stats['skipped_good']} already good")

        click.echo("\nRefresh complete.")
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
