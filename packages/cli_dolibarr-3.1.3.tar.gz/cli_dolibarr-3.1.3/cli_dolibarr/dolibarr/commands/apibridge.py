"""CLI commands for Dolibarr apibridge module.

Uses SessionClient for custom endpoints under /custom/apibridge/api/.
Apibridge uses an index.php?handler=XXX routing pattern.
"""

import sys
import json
import click

from cli_dolibarr.dolibarr.core.client import DolibarrAPIError
from cli_dolibarr.dolibarr.core.session_client import SessionClient
from cli_dolibarr.dolibarr.core.output import OutputFormatter

PREFIX = "custom/apibridge/api"


def _get_session_client(ctx) -> SessionClient:
    cfg = ctx.obj["config"]
    cfg.resolve()
    base_url = cfg.base_url
    api_key = cfg.api_key
    if not base_url or not api_key:
        click.echo(
            "Error: base_url and api_key required (config or flags)",
            err=True,
        )
        sys.exit(1)
    return SessionClient(base_url=base_url, api_key=api_key)


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj["formatter"]


def _output(ctx, result):
    _get_formatter(ctx).output(result)


@click.group()
def apibridge():
    """APIBridge module commands (proposal lines, conversions)."""


@apibridge.command("add-proposal-lines")
@click.option("--proposal-id", required=True, type=int, help="Proposal ID")
@click.option("--lines", default=None, help="Lines data JSON (array of line objects)")
@click.option("--data", default=None, help="Full payload JSON (overrides --proposal-id and --lines)")
@click.pass_context
def add_proposal_lines(ctx, proposal_id, lines, data):
    """Add lines to a proposal."""
    client = _get_session_client(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {"id": proposal_id}
            if lines:
                line_data = json.loads(lines)
                import base64
                encoded = base64.b64encode(
                    json.dumps(line_data).encode()
                ).decode()
                payload["lines"] = encoded
        payload["handler"] = "addProposalLines"
        result = client.post(f"{PREFIX}/index.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@apibridge.command("base64-convert")
@click.option("--data", required=True, help="Data to convert (JSON payload)")
@click.pass_context
def base64_convert(ctx, data):
    """Base64 conversion operation."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data)
        payload["handler"] = "base64Convert"
        result = client.post(f"{PREFIX}/index.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
