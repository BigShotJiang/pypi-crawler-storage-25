import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def webhook():
    """Manage Dolibarr webhooks."""
    pass


@webhook.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_webhooks(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List all webhooks."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('webhook', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@webhook.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_webhook(ctx, id):
    """Get a webhook by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('webhook', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@webhook.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--url', default=None, help='Webhook URL')
@click.option('--event', default=None, help='Event type to trigger on')
@click.pass_context
def create_webhook(ctx, data, url, event):
    """Create a new webhook."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if url is not None:
                payload['url'] = url
            if event is not None:
                payload['event'] = event
        result = client.post('webhook', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@webhook.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_webhook(ctx, id):
    """Delete a webhook by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('webhook', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
