"""
Command template for Dolibarr CLI.

Copy this file to create a new command. Name it after your resource
(e.g. warehouses.py) and rename the group function to match.

Registration is automatic — any .py file in this directory (not starting
with _) that exposes a click.Group or click.Command matching the filename
will be discovered at startup.
"""

import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


# The function name MUST match the filename (without .py).
# e.g. file "warehouses.py" → function "warehouses".
@click.group()
def template():          # ← rename to match your filename
    pass


@template.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_items(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('template', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@template.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_item(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('template', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@template.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.pass_context
def create_item(ctx, data):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post('template', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@template.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_item(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('template', resource_id=id)
            payload = existing if isinstance(existing, dict) else {}
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('template', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@template.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_item(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('template', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
