import sys
import click
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def zapier():
    """Manage Dolibarr Zapier integration."""
    pass


@zapier.command('triggers')
@click.pass_context
def list_triggers(ctx):
    """List available Zapier triggers."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('zapier', sub_resource='triggers')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@zapier.command('actions')
@click.pass_context
def list_actions(ctx):
    """List available Zapier actions."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('zapier', sub_resource='actions')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
