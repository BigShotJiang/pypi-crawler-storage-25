"""CLI commands for Dolibarr PDF generation (PDFA module)."""

import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def pdfa():
    """PDF generation commands."""
    pass


@pdfa.command('templates')
@click.pass_context
def list_templates(ctx):
    """List available PDF templates."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('pdfa', sub_resource='templates')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@pdfa.command('generate')
@click.option('--module_part', required=True,
              help='Document module (proposal, order, invoice, etc.)')
@click.option('--id', 'doc_id', required=True, type=int,
              help='Document ID')
@click.option('--template', default=None,
              help='PDF template name')
@click.pass_context
def generate_pdf(ctx, module_part, doc_id, template):
    """Generate a PDF for a document."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = {
            'module_part': module_part,
            'id': doc_id,
        }
        if template is not None:
            payload['template'] = template
        result = client.post('pdfa', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@pdfa.command('download')
@click.option('--module_part', required=True,
              help='Document module (proposal, order, invoice, etc.)')
@click.option('--ref', default=None,
              help='Document reference')
@click.option('--id', 'doc_id', default=None, type=int,
              help='Document ID')
@click.option('--output', '-o', default=None,
              help='Output file path')
@click.pass_context
def download_pdf(ctx, module_part, ref, doc_id, output):
    """Download a generated PDF file."""
    client = _get_client(ctx)
    try:
        url = client._url('pdfa')
        params = {'module_part': module_part}
        if ref is not None:
            params['ref'] = ref
        if doc_id is not None:
            params['id'] = doc_id

        response = client.session.get(url, params=params)

        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get('error', str(error_data))
            except (ValueError, AttributeError):
                message = response.text[:500]
            raise DolibarrAPIError(message, response.status_code, response)

        content_type = response.headers.get('content-type', '')

        if 'application/pdf' in content_type or response.content[:4] == b'%PDF':
            filename = output
            if filename is None:
                doc_name = ref or str(doc_id) or 'document'
                filename = f"{module_part}_{doc_name}.pdf"
            with open(filename, 'wb') as f:
                f.write(response.content)
            click.echo(f"PDF saved to {filename} ({len(response.content)} bytes)")
        else:
            formatter = _get_formatter(ctx)
            try:
                result = response.json()
            except ValueError:
                result = response.text.strip()
            formatter.output(result)

    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
