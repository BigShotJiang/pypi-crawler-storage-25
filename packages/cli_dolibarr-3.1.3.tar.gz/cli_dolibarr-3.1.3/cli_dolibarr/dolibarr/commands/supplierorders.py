import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


RESOURCE = 'supplierorders'


@click.group()
def supplierorders():
    """Get properties of a supplier order object"""
    pass


@supplierorders.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_supplierorders(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List supplierorders."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_supplierorder(ctx, id):
    """Get supplierorders by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.pass_context
def create_supplierorder(ctx, data):
    """Create supplierorders."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}

        result = client.post(RESOURCE, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_supplierorder(ctx, id, data, set_fields):
    """Update supplierorders."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get(RESOURCE, resource_id=id)
            payload = existing if isinstance(existing, dict) else {}
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put(RESOURCE, resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_supplierorder(ctx, id):
    """Delete supplierorders."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.command('validate')
@click.argument('id', type=int)
@click.pass_context
def validate_supplierorders(ctx, id):
    """Validate an order"""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post(RESOURCE, resource_id=id, action='validate')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierorders.group()
def approve():
    """Manage approve for supplierorders."""
    pass


@approve.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_approve(ctx, parent_id, data):
    """Create approve."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='approve', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@supplierorders.group()
def contact():
    """Manage contact for supplierorders."""
    pass


@contact.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_contact(ctx, parent_id, data):
    """Create contact."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='contact', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contact.command('delete')
@click.argument('parent_id', type=int)
@click.argument('sub_id', type=int)
@click.pass_context
def delete_contact(ctx, parent_id, sub_id):
    """Delete contact."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=parent_id, sub_resource='contact', sub_id=sub_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@supplierorders.group()
def contacts():
    """Manage contacts for supplierorders."""
    pass


@contacts.command('list')
@click.argument('parent_id', type=int)
@click.pass_context
def list_contacts(ctx, parent_id):
    """List contacts."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=parent_id, sub_resource='contacts')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@supplierorders.group()
def makeorder():
    """Manage makeorder for supplierorders."""
    pass


@makeorder.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_makeorder(ctx, parent_id, data):
    """Create makeorder."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='makeorder', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@supplierorders.group()
def receive():
    """Manage receive for supplierorders."""
    pass


@receive.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_receive(ctx, parent_id, data):
    """Create receive."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='receive', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
