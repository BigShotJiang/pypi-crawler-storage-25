import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def categories():
    pass


@categories.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--type', default=None, help='Category type filter')
@click.pass_context
def list_categories(ctx, sortfield, sortorder, limit, page, sqlfilters, type):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {}
        if type is not None:
            params['type'] = type
        result = client.list('categories', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             **params)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_category(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('categories', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--label', default=None, help='Category label')
@click.option('--type', default=None, help='Category type')
@click.option('--description', default=None, help='Description')
@click.option('--color', default=None, help='Color code')
@click.option('--fk_parent', default=None, type=int, help='Parent category ID')
@click.pass_context
def create_category(ctx, data, label, type, description, color, fk_parent):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if label is not None:
                payload['label'] = label
            if type is not None:
                payload['type'] = type
            if description is not None:
                payload['description'] = description
            if color is not None:
                payload['color'] = color
            if fk_parent is not None:
                payload['fk_parent'] = fk_parent
        result = client.post('categories', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_category(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('categories', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('categories', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_category(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('categories', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('objects')
@click.argument('id', type=int)
@click.option('--type', default=None, required=True, help='Object type (product, thirdparty, etc.)')
@click.pass_context
def list_category_objects(ctx, id, type):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('categories', resource_id=id, sub_resource=type)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('link')
@click.argument('id', type=int)
@click.option('--type', default=None, required=True, help='Object type')
@click.option('--object-id', required=True, type=int, help='Object ID to link')
@click.pass_context
def link_category_object(ctx, id, type, object_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = {}
        result = client.post('categories', resource_id=id, sub_resource=type, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@categories.command('unlink')
@click.argument('id', type=int)
@click.option('--type', default=None, required=True, help='Object type')
@click.option('--object-id', required=True, type=int, help='Object ID to unlink')
@click.pass_context
def unlink_category_object(ctx, id, type, object_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('categories', resource_id=id, sub_resource=type, sub_id=object_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
