import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


RESOURCE = 'stockmovements'


@click.group()
def stockmovements():
    """Get a list of stock movement"""
    pass


@stockmovements.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_stockmovements(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List stockmovements."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@stockmovements.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--product_id', default=None, type=int, help='product_id')
@click.option('--warehouse_id', default=None, type=int, help='warehouse_id')
@click.option('--qty', default=None, type=float, help='qty')
@click.option('--type', default=None, type=int, help='type')
@click.option('--lot', default=None, type=str, help='lot')
@click.option('--movementcode', default=None, type=str, help='movementcode')
@click.option('--movementlabel', default=None, type=str, help='movementlabel')
@click.option('--price', default=None, type=str, help='price')
@click.pass_context
def create_stockmovement(ctx, data, product_id, warehouse_id, qty, type, lot, movementcode, movementlabel, price):
    """Create stockmovements."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if product_id is not None:
                payload['product_id'] = product_id
            if warehouse_id is not None:
                payload['warehouse_id'] = warehouse_id
            if qty is not None:
                payload['qty'] = qty
            if type is not None:
                payload['type'] = type
            if lot is not None:
                payload['lot'] = lot
            if movementcode is not None:
                payload['movementcode'] = movementcode
            if movementlabel is not None:
                payload['movementlabel'] = movementlabel
            if price is not None:
                payload['price'] = price
        result = client.post(RESOURCE, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
