import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


RESOURCE = 'mobilehubapi'


@click.group()
def mobilehubapi():
    """Submit a delivery-note image for OCR processing"""
    pass


@mobilehubapi.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_mobilehubapi(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List mobilehubapi."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@mobilehubapi.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_mobilehubapi(ctx, id):
    """Get mobilehubapi by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@mobilehubapi.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--request_body', default=None, help='request_body')
@click.pass_context
def create_mobilehubapi(ctx, data, request_body):
    """Create mobilehubapi."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if request_body is not None:
                payload['request_body'] = request_body
        result = client.post(RESOURCE, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
