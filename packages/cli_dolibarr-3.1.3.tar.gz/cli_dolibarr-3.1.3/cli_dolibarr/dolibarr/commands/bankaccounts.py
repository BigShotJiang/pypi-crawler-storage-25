import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def bankaccounts():
    """Manage Dolibarr bank accounts."""
    pass


@bankaccounts.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_bankaccounts(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    """List bank accounts."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('bankaccounts', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@bankaccounts.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_bankaccount(ctx, id):
    """Get a bank account by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('bankaccounts', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@bankaccounts.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--ref', default=None, help='Account ref/label')
@click.option('--bank', default=None, help='Bank name')
@click.pass_context
def create_bankaccount(ctx, data, ref, bank):
    """Create a bank account."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if ref is not None:
                payload['ref'] = ref
            if bank is not None:
                payload['bank'] = bank
        result = client.post('bankaccounts', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@bankaccounts.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_bankaccount(ctx, id, data, set_fields):
    """Update a bank account."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('bankaccounts', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('bankaccounts', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@bankaccounts.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_bankaccount(ctx, id):
    """Delete a bank account."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('bankaccounts', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@bankaccounts.group('lines')
@click.argument('account_id', type=int)
@click.pass_context
def lines(ctx, account_id):
    """Manage bank account transaction lines."""
    ctx.ensure_object(dict)
    ctx.obj['account_id'] = account_id


@lines.command('list')
@click.pass_context
def list_lines(ctx):
    """List transaction lines for a bank account."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    account_id = ctx.obj['account_id']
    try:
        result = client.get('bankaccounts', resource_id=account_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
