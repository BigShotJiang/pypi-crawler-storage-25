import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def shipments():
    pass


@shipments.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_shipments(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('shipments', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@shipments.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_shipment(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('shipments', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@shipments.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--thirdparty_id', default=None, type=int, help='Third party ID')
@click.option('--date', default=None, help='Date (YYYYMMDD)')
@click.pass_context
def create_shipment(ctx, data, thirdparty_id, date):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if thirdparty_id is not None:
                payload['thirdparty_id'] = thirdparty_id
            if date is not None:
                payload['date'] = date
        result = client.post('shipments', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@shipments.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_shipment(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('shipments', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('shipments', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@shipments.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_shipment(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('shipments', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
