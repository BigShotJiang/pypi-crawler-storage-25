import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def thirdparties():
    pass


@thirdparties.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_thirdparties(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('thirdparties', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_thirdparty(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('thirdparties', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--name', default=None, help='Third party name')
@click.option('--email', default=None, help='Email address')
@click.option('--phone', default=None, help='Phone number')
@click.option('--town', default=None, help='City/town')
@click.option('--country', default=None, help='Country code')
@click.option('--client', default=None, type=int, help='Customer flag (1=customer)')
@click.option('--fournisseur', default=None, type=int, help='Supplier flag (1=supplier)')
@click.option('--barcode', default=None, help='Barcode')
@click.pass_context
def create_thirdparty(ctx, data, name, email, phone, town, country, client, fournisseur, barcode):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if name is not None:
                payload['name'] = name
                payload['nom'] = name
            if email is not None:
                payload['email'] = email
            if phone is not None:
                payload['phone'] = phone
            if town is not None:
                payload['town'] = town
            if country is not None:
                payload['country'] = country
            if client is not None:
                payload['client'] = str(client)
            if fournisseur is not None:
                payload['fournisseur'] = str(fournisseur)
            if barcode is not None:
                payload['barcode'] = barcode
        result = client.post('thirdparties', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_thirdparty(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('thirdparties', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('thirdparties', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_thirdparty(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('thirdparties', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('email')
@click.argument('email_addr')
@click.pass_context
def email_thirdparty(ctx, email_addr):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('thirdparties', sqlfilters=f"t.email='{email_addr}'")
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@thirdparties.command('categories')
@click.argument('id', type=int)
@click.pass_context
def categories_thirdparty(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('categories', resource_id=id, sub_resource='thirdparties')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
