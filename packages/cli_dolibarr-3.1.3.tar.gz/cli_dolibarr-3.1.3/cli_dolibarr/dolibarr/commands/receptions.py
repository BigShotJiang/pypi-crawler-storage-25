import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def receptions():
    pass


@receptions.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_receptions(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('receptions', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_reception(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('receptions', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.command('create')
@click.option('--socid', required=True, type=int, help='Third party ID (supplier)')
@click.option('--origin_id', default=None, type=int, help='Origin document ID (e.g. supplier order)')
@click.option('--origin_type', default=None, help='Origin type (e.g. commande_fournisseur)')
@click.option('--data', default=None, help='JSON string with all fields')
@click.pass_context
def create_reception(ctx, socid, origin_id, origin_type, data):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            payload['socid'] = socid
            if origin_id is not None:
                payload['origin_id'] = origin_id
            if origin_type is not None:
                payload['origin_type'] = origin_type
        result = client.post('receptions', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_reception(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('receptions', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('receptions', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_reception(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('receptions', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.command('validate')
@click.argument('id', type=int)
@click.pass_context
def validate_reception(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post('receptions', resource_id=id, action='validate')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@receptions.group()
def lines():
    pass


@lines.command('list')
@click.argument('reception_id', type=int)
@click.pass_context
def list_lines(ctx, reception_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('receptions', resource_id=reception_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('create')
@click.argument('reception_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.pass_context
def create_line(ctx, reception_id, data):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
        result = client.post('receptions', resource_id=reception_id, sub_resource='lines', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('update')
@click.argument('reception_id', type=int)
@click.argument('line_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_line(ctx, reception_id, line_id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('receptions', resource_id=reception_id, sub_resource='lines')
            payload = {}
            if isinstance(existing, list):
                for line in existing:
                    if str(line.get('id', '')) == str(line_id) or str(line.get('rowid', '')) == str(line_id):
                        payload = line
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('receptions', resource_id=reception_id, sub_resource='lines', sub_id=line_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('delete')
@click.argument('reception_id', type=int)
@click.argument('line_id', type=int)
@click.pass_context
def delete_line(ctx, reception_id, line_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('receptions', resource_id=reception_id, sub_resource='lines', sub_id=line_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
