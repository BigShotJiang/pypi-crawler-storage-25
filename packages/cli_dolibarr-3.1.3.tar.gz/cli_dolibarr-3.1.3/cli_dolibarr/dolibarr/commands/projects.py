import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def projects():
    pass


@projects.group()
def task():
    pass


@projects.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_projects(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('projects', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@projects.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_project(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('projects', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@projects.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--title', default=None, help='Project title')
@click.option('--ref', default=None, help='Reference')
@click.option('--description', default=None, help='Description')
@click.option('--thirdparty_ids', default=None, help='Comma-separated third party IDs')
@click.pass_context
def create_project(ctx, data, title, ref, description, thirdparty_ids):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if title is not None:
                payload['title'] = title
            if ref is not None:
                payload['ref'] = ref
            if description is not None:
                payload['description'] = description
            if thirdparty_ids is not None:
                payload['thirdparty_ids'] = thirdparty_ids
        result = client.post('projects', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@projects.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_project(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('projects', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('projects', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@projects.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_project(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('projects', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_tasks(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('tasks', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_task(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('tasks', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--ref', default=None, help='Task reference')
@click.option('--label', default=None, help='Task label')
@click.option('--fk_project', default=None, type=int, help='Project ID')
@click.option('--fk_task_parent', default=None, type=int, help='Parent task ID')
@click.pass_context
def create_task(ctx, data, ref, label, fk_project, fk_task_parent):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if ref is not None:
                payload['ref'] = ref
            if label is not None:
                payload['label'] = label
            if fk_project is not None:
                payload['fk_project'] = fk_project
            if fk_task_parent is not None:
                payload['fk_task_parent'] = fk_task_parent
        result = client.post('tasks', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_task(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('tasks', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('tasks', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_task(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('tasks', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@task.command('addtime')
@click.argument('id', type=int)
@click.option('--duration', default=None, help='Duration (e.g. 3600 for 1h in seconds)')
@click.option('--note', default=None, help='Time note')
@click.pass_context
def add_time(ctx, id, duration, note):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = {}
        if duration is not None:
            payload['duration'] = duration
        if note is not None:
            payload['note'] = note
        result = client.post('tasks', resource_id=id, action='addtime', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
