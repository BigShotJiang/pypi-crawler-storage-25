"""Dolibarr CLI — document management (list, get, upload, download)."""

import sys
import os
import click
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def documents():
    """Manage Dolibarr documents (files)."""
    pass


@documents.command('list')
@click.option('--module_part', default=None, help='Module name (e.g. facture, propal)')
@click.option('--ref', default=None, help='Object reference')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.pass_context
def list_documents(ctx, module_part, ref, sortfield, sortorder):
    """List documents."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {'sortfield': sortfield, 'sortorder': sortorder}
        if module_part is not None:
            params['modulepart'] = module_part
        if ref is not None:
            params['ref'] = ref
        result = client.get('documents', **params)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@documents.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_document(ctx, id):
    """Get document info by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('documents', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@documents.command('upload')
@click.option('--file', 'filepath', required=True, type=click.Path(exists=True),
              help='Path to file to upload')
@click.option('--module_part', required=True, help='Module name (e.g. facture, propal)')
@click.option('--ref', default=None, help='Object reference')
@click.option('--filename', default=None, help='Custom filename on server')
@click.option('--description', default=None, help='File description')
@click.pass_context
def upload_document(ctx, filepath, module_part, ref, filename, description):
    """Upload a file as a Dolibarr document."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url('documents') + '/upload'
        upload_name = filename or os.path.basename(filepath)
        with open(filepath, 'rb') as f:
            files = {'file': (upload_name, f, 'application/octet-stream')}
            data = {'modulepart': module_part}
            if ref is not None:
                data['ref'] = ref
            if description is not None:
                data['description'] = description
            headers = {'Content-Type': None}  # let requests set multipart boundary
            response = client.session.post(url, files=files, data=data, headers=headers)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@documents.command('download')
@click.option('--module_part', required=True, help='Module name (e.g. facture, propal)')
@click.option('--file', 'filepath', required=True,
              help='File path within module directory')
@click.option('--output', 'output_path', default=None,
              help='Save to this path (default: write to stdout)')
@click.pass_context
def download_document(ctx, module_part, filepath, output_path):
    """Download a document file."""
    client = _get_client(ctx)
    try:
        url = client._url('documents') + '/download'
        params = {'modulepart': module_part, 'file': filepath}
        response = client.session.get(url, params=params, stream=True)
        if response.status_code >= 400:
            client._handle_response(response)
        if output_path:
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            click.echo(f"Saved to {output_path}", err=True)
        else:
            click.get_text_stream('stdout').buffer.write(response.content)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
