import sys
import click
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def setup():

    pass


@setup.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.pass_context
def list_setup(ctx, sortfield, sortorder, limit, page):

    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('setup', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@setup.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_setup(ctx, id):

    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('setup', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
