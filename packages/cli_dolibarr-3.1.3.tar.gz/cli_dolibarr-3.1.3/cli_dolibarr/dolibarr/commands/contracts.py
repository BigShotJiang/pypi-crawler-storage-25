import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def contracts():
    pass


@contracts.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_contracts(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('contracts', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contracts.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_contract(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('contracts', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contracts.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--fk_soc', default=None, type=int, help='Third party ID')
@click.option('--date_contrat', default=None, help='Contract date (YYYYMMDD)')
@click.option('--note_private', default=None, help='Private note')
@click.pass_context
def create_contract(ctx, data, fk_soc, date_contrat, note_private):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if fk_soc is not None:
                payload['fk_soc'] = fk_soc
            if date_contrat is not None:
                payload['date_contrat'] = date_contrat
            if note_private is not None:
                payload['note_private'] = note_private
        result = client.post('contracts', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contracts.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_contract(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('contracts', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('contracts', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contracts.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_contract(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('contracts', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@contracts.group()
def lines():
    pass


@lines.command('list')
@click.argument('contract_id', type=int)
@click.pass_context
def list_lines(ctx, contract_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('contracts', resource_id=contract_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('add')
@click.argument('contract_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--desc', default=None, help='Line description')
@click.option('--subprice', default=None, type=float, help='Unit price HT')
@click.option('--qty', default=None, type=float, help='Quantity')
@click.option('--tva_tx', default=None, type=float, help='VAT rate')
@click.option('--date_start', default=None, help='Start date (YYYYMMDD)')
@click.option('--date_end', default=None, help='End date (YYYYMMDD)')
@click.pass_context
def add_line(ctx, contract_id, data, desc, subprice, qty, tva_tx, date_start, date_end):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if desc is not None:
                payload['desc'] = desc
            if subprice is not None:
                payload['subprice'] = subprice
            if qty is not None:
                payload['qty'] = qty
            if tva_tx is not None:
                payload['tva_tx'] = tva_tx
            if date_start is not None:
                payload['date_start'] = date_start
            if date_end is not None:
                payload['date_end'] = date_end
        result = client.post('contracts', resource_id=contract_id, sub_resource='lines', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('update')
@click.argument('contract_id', type=int)
@click.argument('line_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_line(ctx, contract_id, line_id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('contracts', resource_id=contract_id, sub_resource='lines')
            payload = {}
            if isinstance(existing, list):
                for line in existing:
                    if str(line.get('id', '')) == str(line_id) or str(line.get('rowid', '')) == str(line_id):
                        payload = line
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('contracts', resource_id=contract_id, sub_resource='lines', sub_id=line_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('delete')
@click.argument('contract_id', type=int)
@click.argument('line_id', type=int)
@click.pass_context
def delete_line(ctx, contract_id, line_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('contracts', resource_id=contract_id, sub_resource='lines', sub_id=line_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
