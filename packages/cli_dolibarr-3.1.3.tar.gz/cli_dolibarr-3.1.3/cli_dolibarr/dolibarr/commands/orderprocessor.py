import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter

RESOURCE = 'orderprocessor'


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def orderprocessor():
    """OrderProcessor module - reconciliation, queue, uploads."""
    pass


# ── Queue ────────────────────────────────────────────────────────────────

@orderprocessor.command('list-queue')
@click.option('--status', default=None, type=int, help='Filter: 0=Pending,1=Processed,2=Canceled')
@click.option('--mode', default=None, type=click.Choice(['order', 'batch']), help='Filter by mode')
@click.option('--limit', default=20, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.pass_context
def list_queue(ctx, status, mode, limit, page):
    """List API queue items."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {}
        if status is not None:
            params['status'] = status
        if mode is not None:
            params['mode'] = mode
        params.update({'limit': limit, 'page': page})
        url = client._url(f'{RESOURCE}/queue')
        response = client.session.get(url, params=params)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Smart Upload ─────────────────────────────────────────────────────────

@orderprocessor.command('smart-upload')
@click.option('--filename', required=True, help='File name with extension')
@click.option('--filecontent', required=True, help='Base64 encoded file content')
@click.option('--mode', default='order', type=click.Choice(['order', 'batch']))
@click.option('--auto-save', is_flag=True, default=False, help='Auto save after processing')
@click.pass_context
def smart_upload(ctx, filename, filecontent, mode, auto_save):
    """Upload an order or batch note file."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = {
            'filename': filename,
            'filecontent': filecontent,
            'mode': mode,
            'auto_save': auto_save,
        }
        url = client._url(f'{RESOURCE}/smartupload')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Reconciliation ───────────────────────────────────────────────────────

@orderprocessor.command('reconciliation-stats')
@click.pass_context
def reconciliation_stats(ctx):
    """Get reconciliation statistics (AR, AP, tax)."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/reconciliation/stats')
        response = client.session.get(url)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('reconciliation-monthly')
@click.argument('month')  # YYYY-MM
@click.pass_context
def reconciliation_monthly(ctx, month):
    """Get monthly reconciliation stats for all third parties."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/reconciliation/monthly/{month}')
        response = client.session.get(url)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('reconciliation-summary')
@click.argument('socid', type=int)
@click.option('--date-start', default=None, help='Start date (YYYY-MM-DD)')
@click.option('--date-end', default=None, help='End date (YYYY-MM-DD)')
@click.pass_context
def reconciliation_summary(ctx, socid, date_start, date_end):
    """Get reconciliation summary for a third party."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {}
        if date_start:
            params['date_start'] = date_start
        if date_end:
            params['date_end'] = date_end
        url = client._url(f'{RESOURCE}/reconciliation/summary/{socid}')
        response = client.session.get(url, params=params)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('reconciliation-invoices')
@click.argument('socid', type=int)
@click.pass_context
def reconciliation_invoices(ctx, socid):
    """Get reconciliation invoices for a third party."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/reconciliation/invoices/{socid}')
        response = client.session.get(url)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Statements ───────────────────────────────────────────────────────────

@orderprocessor.command('statement-latest')
@click.argument('socid', type=int)
@click.option('--month', default=None, help='Month filter (YYYY-MM)')
@click.option('--date-start', default=None, help='Start date (YYYY-MM-DD)')
@click.option('--date-end', default=None, help='End date (YYYY-MM-DD)')
@click.pass_context
def statement_latest(ctx, socid, month, date_start, date_end):
    """Get latest reconciliation statement for a third party."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {}
        if month:
            params['month'] = month
        if date_start:
            params['date_start'] = date_start
        if date_end:
            params['date_end'] = date_end
        url = client._url(f'{RESOURCE}/statement/latest/{socid}')
        response = client.session.get(url, params=params)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('statement-detail')
@click.argument('id', type=int)
@click.pass_context
def statement_detail(ctx, id):
    """Get detail of a reconciliation statement."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/statement/{id}')
        response = client.session.get(url)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('statement-generate')
@click.option('--data', default=None, help='JSON string with generation parameters')
@click.pass_context
def statement_generate(ctx, data):
    """Generate a reconciliation statement."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        url = client._url(f'{RESOURCE}/statement/generate')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Write-offs ───────────────────────────────────────────────────────────

@orderprocessor.command('writeoff-customer')
@click.option('--data', default=None, help='JSON string with write-off data')
@click.pass_context
def writeoff_customer(ctx, data):
    """Write off a customer invoice."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        url = client._url(f'{RESOURCE}/writeoff/customer')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@orderprocessor.command('writeoff-supplier')
@click.option('--data', default=None, help='JSON string with write-off data')
@click.pass_context
def writeoff_supplier(ctx, data):
    """Write off a supplier invoice."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        url = client._url(f'{RESOURCE}/writeoff/supplier')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Tax Invoice Status ──────────────────────────────────────────────────

@orderprocessor.command('tax-invoice-status')
@click.option('--data', default=None, help='JSON string with invoice status data')
@click.pass_context
def tax_invoice_status(ctx, data):
    """Update tax invoice status."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        url = client._url(f'{RESOURCE}/taxinvoicestatus')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
