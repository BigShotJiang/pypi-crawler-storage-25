import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def tickets():
    pass


@tickets.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_tickets(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('tickets', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_ticket(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('tickets', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--subject', default=None, help='Ticket subject')
@click.option('--type_code', default=None, help='Type code')
@click.option('--category_code', default=None, help='Category code')
@click.option('--message', default=None, help='Initial message')
@click.option('--urgency', default=None, help='Urgency level')
@click.pass_context
def create_ticket(ctx, data, subject, type_code, category_code, message, urgency):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if subject is not None:
                payload['subject'] = subject
            if type_code is not None:
                payload['type_code'] = type_code
            if category_code is not None:
                payload['category_code'] = category_code
            if message is not None:
                payload['message'] = message
            if urgency is not None:
                payload['urgency'] = urgency
        result = client.post('tickets', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_ticket(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('tickets', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('tickets', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_ticket(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('tickets', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('messages')
@click.argument('id', type=int)
@click.pass_context
def ticket_messages(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('tickets', resource_id=id, sub_resource='messages')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tickets.command('close')
@click.argument('id', type=int)
@click.pass_context
def close_ticket(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post('tickets', resource_id=id, action='close')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
