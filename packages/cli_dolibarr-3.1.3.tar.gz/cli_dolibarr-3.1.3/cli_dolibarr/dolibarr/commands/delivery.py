"""CLI commands for Dolibarr delivery module (SF/FedEx/SFI logistics)."""
import sys
import json
import click
from cli_dolibarr.dolibarr.core.client import DolibarrAPIError
from cli_dolibarr.dolibarr.core.session_client import SessionClient
from cli_dolibarr.dolibarr.core.output import OutputFormatter

PREFIX = "custom/delivery/api"

def _get_session_client(ctx) -> SessionClient:
    cfg = ctx.obj["config"]
    cfg.resolve()
    if not cfg.base_url or not cfg.api_key:
        click.echo("Error: base_url and api_key required (config or flags)", err=True)
        sys.exit(1)
    return SessionClient(base_url=cfg.base_url, api_key=cfg.api_key)

def _output(ctx, result):
    ctx.obj["formatter"].output(result)

@click.group()
def delivery():
    """Delivery module commands (SF / FedEx / SFI logistics)."""

@delivery.group()
def sf():
    """顺丰 (SF Express) logistics commands."""

@sf.command("order")
@click.option("--data", default=None, help="Full shipment JSON payload")
@click.option("--orderid", default=None, help="Order ID")
@click.option("--sender", default=None, help="Sender info (JSON string)")
@click.option("--receiver", default=None, help="Receiver info (JSON string)")
@click.pass_context
def sf_order(ctx, data, orderid, sender, receiver):
    """Create SF shipment order."""
    client = _get_session_client(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if orderid:
                payload["orderid"] = orderid
            if sender:
                payload["sender"] = json.loads(sender) if isinstance(sender, str) else sender
            if receiver:
                payload["receiver"] = json.loads(receiver) if isinstance(receiver, str) else receiver
        result = client.post(f"{PREFIX}/sf_order.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sf.command("track")
@click.option("--tracking-number", required=True, help="Tracking number")
@click.pass_context
def sf_track(ctx, tracking_number):
    """Track SF shipment."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/sf_track.php", tracking_number=tracking_number)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sf.command("print")
@click.option("--id", "record_id", required=True, help="Record ID to print")
@click.option("--output", default=None, help="Output file path")
@click.pass_context
def print_label(ctx, record_id, output):
    """Print SF shipping label."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/sf_print.php", id=record_id)
        if output and isinstance(result, str):
            with open(output, "w") as f:
                f.write(result)
            click.echo(f"Saved to {output}")
        else:
            _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sf.command("price-query")
@click.option("--from", "from_code", required=True, help="Origin code")
@click.option("--to", "to_code", required=True, help="Destination code")
@click.option("--weight", default=None, help="Weight (kg)")
@click.pass_context
def sf_price_query(ctx, from_code, to_code, weight):
    """Query SF shipping price."""
    client = _get_session_client(ctx)
    try:
        params = {"from": from_code, "to": to_code}
        if weight:
            params["weight"] = weight
        result = client.get(f"{PREFIX}/sf_price_query.php", **params)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sf.command("cancel")
@click.option("--order-id", required=True, help="SF order ID to cancel")
@click.option("--waybill-no", default=None, help="Waybill number (optional)")
@click.pass_context
def sf_cancel(ctx, order_id, waybill_no):
    """Cancel an SF shipment order."""
    client = _get_session_client(ctx)
    try:
        payload = {"order_id": order_id}
        if waybill_no:
            payload["waybill_no"] = waybill_no
        result = client.post(f"{PREFIX}/sf_cancel_order.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sf.command("batch-print")
@click.option("--waybills", required=True, help="Comma-separated waybill numbers")
@click.pass_context
def sf_batch_print(ctx, waybills):
    """Batch print SF shipping labels."""
    client = _get_session_client(ctx)
    try:
        payload = {"waybillNumbers": [w.strip() for w in waybills.split(",")]}
        result = client.post(f"{PREFIX}/sf_batch_print.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@delivery.group()
def fedex():
    """FedEx logistics commands."""

@fedex.command()
@click.option("--data", default=None, help="Full shipment JSON payload")
@click.pass_context
def shipment(ctx, data):
    """Create FedEx shipment."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/fedex_shipment.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@fedex.command("track")
@click.option("--tracking-number", required=True, help="Tracking number")
@click.pass_context
def fedex_track(ctx, tracking_number):
    """Track FedEx shipment."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/fedex_track.php", tracking_number=tracking_number)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@fedex.command("rate-query")
@click.option("--from", "from_code", required=True, help="Origin address/code")
@click.option("--to", "to_code", required=True, help="Destination address/code")
@click.option("--weight", default=None, help="Weight (kg)")
@click.pass_context
def fedex_rate_query(ctx, from_code, to_code, weight):
    """Query FedEx shipping rate."""
    client = _get_session_client(ctx)
    try:
        params = {"from": from_code, "to": to_code}
        if weight:
            params["weight"] = weight
        result = client.get(f"{PREFIX}/fedex_rate_query.php", **params)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@fedex.command("cancel")
@click.option("--tracking-number", required=True, help="FedEx tracking number")
@click.option("--deletion-control", default=None, help="Deletion control (default: DELETE_ALL_PACKAGES)")
@click.pass_context
def fedex_cancel(ctx, tracking_number, deletion_control):
    """Cancel a FedEx shipment."""
    client = _get_session_client(ctx)
    try:
        payload = {"trackingNumber": tracking_number}
        if deletion_control:
            payload["deletionControl"] = deletion_control
        result = client.post(f"{PREFIX}/fedex_cancel.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@fedex.command("label-download")
@click.option("--tracking", required=True, help="Tracking number")
@click.option("--type", "label_type", default="pdf", help="Label type: pdf or png")
@click.option("--action", default="download", help="Action: download or view")
@click.pass_context
def fedex_label_download(ctx, tracking, label_type, action):
    """Download FedEx shipping label."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/fedex_label_download.php", tracking=tracking, type=label_type, action=action)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@fedex.command("address-validation")
@click.option("--data", default=None, help="Full address JSON payload")
@click.option("--country-code", default=None, help="Country code (e.g. US, CN)")
@click.option("--street-lines", default=None, help="Comma-separated street lines")
@click.pass_context
def fedex_address_validation(ctx, data, country_code, street_lines):
    """Validate a shipping address via FedEx."""
    client = _get_session_client(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if street_lines:
                payload["streetLines"] = [s.strip() for s in street_lines.split(",")]
            if country_code:
                payload["countryCode"] = country_code
        result = client.post(f"{PREFIX}/fedex_address_validation.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@delivery.group()
def sfi():
    """顺丰国际 (SF International) logistics commands."""

@sfi.command("order")
@click.option("--data", default=None, help="Full shipment JSON payload")
@click.pass_context
def sfi_order(ctx, data):
    """Create SFI (SF International) shipment order."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/sfi_order.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sfi.command("price-query")
@click.option("--from", "from_code", required=True, help="Origin code")
@click.option("--to", "to_code", required=True, help="Destination code")
@click.option("--weight", default=None, help="Weight (kg)")
@click.pass_context
def sfi_price_query(ctx, from_code, to_code, weight):
    """Query SFI (SF International) shipping price."""
    client = _get_session_client(ctx)
    try:
        params = {"from": from_code, "to": to_code}
        if weight:
            params["weight"] = weight
        result = client.get(f"{PREFIX}/sfi_price_query.php", **params)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)

@sfi.command("get-customer-code")
@click.pass_context
def sfi_get_customer_code(ctx):
    """Get SFI customer code."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/sfi_get_customer_code.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
