import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def accountancy():
    """Manage Dolibarr accountancy (会计) entries."""
    pass


@accountancy.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_accountancy(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    """List accountancy entries."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('accountancy', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@accountancy.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_accountancy(ctx, id):
    """Get a single accountancy entry by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('accountancy', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@accountancy.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--doc_type', default=None, help='Document type')
@click.option('--doc_ref', default=None, help='Document reference')
@click.option('--numero_compte', default=None, help='Account number')
@click.option('--label_operation', default=None, help='Label of the operation')
@click.pass_context
def create_accountancy(ctx, data, doc_type, doc_ref, numero_compte, label_operation):
    """Create a new accountancy entry."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if doc_type is not None:
                payload['doc_type'] = doc_type
            if doc_ref is not None:
                payload['doc_ref'] = doc_ref
            if numero_compte is not None:
                payload['numero_compte'] = numero_compte
            if label_operation is not None:
                payload['label_operation'] = label_operation
        result = client.post('accountancy', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@accountancy.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_accountancy(ctx, id, data, set_fields):
    """Update an existing accountancy entry."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('accountancy', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('accountancy', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@accountancy.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_accountancy(ctx, id):
    """Delete an accountancy entry by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('accountancy', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
