import sys
import click
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def system():
    pass


@system.command('info')
@click.pass_context
def system_info(ctx):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('info')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@system.command('ping')
@click.pass_context
def ping(ctx):
    client = _get_client(ctx)
    try:
        ok = client.test_connection()
        if ok:
            click.echo("Connection OK")
        else:
            click.echo("Connection FAILED", err=True)
            sys.exit(1)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@system.command('login-check')
@click.pass_context
def login_check(ctx):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('info')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
