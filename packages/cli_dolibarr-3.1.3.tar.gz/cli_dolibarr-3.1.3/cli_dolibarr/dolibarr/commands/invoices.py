import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def invoices():
    pass


@invoices.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_invoices(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('invoices', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_invoice(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('invoices', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--socid', default=None, type=int, help='Third party ID')
@click.option('--date', default=None, help='Date (YYYYMMDD)')
@click.option('--note_private', default=None, help='Private note')
@click.option('--note_public', default=None, help='Public note')
@click.pass_context
def create_invoice(ctx, data, socid, date, note_private, note_public):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if socid is not None:
                payload['socid'] = socid
            if date is not None:
                payload['date'] = date
            if note_private is not None:
                payload['note_private'] = note_private
            if note_public is not None:
                payload['note_public'] = note_public
        result = client.post('invoices', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_invoice(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('invoices', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('invoices', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_invoice(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('invoices', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('validate')
@click.argument('id', type=int)
@click.pass_context
def validate_invoice(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post('invoices', resource_id=id, action='validate')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('settopaid')
@click.argument('id', type=int)
@click.pass_context
def settopaid_invoice(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post('invoices', resource_id=id, action='settopaid')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.command('payments')
@click.argument('id', type=int)
@click.pass_context
def payments_invoice(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('invoices', resource_id=id, sub_resource='payments')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@invoices.group()
def lines():
    pass


@lines.command('list')
@click.argument('invoice_id', type=int)
@click.pass_context
def list_lines(ctx, invoice_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('invoices', resource_id=invoice_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('create')
@click.argument('invoice_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--desc', default=None, help='Line description')
@click.option('--subprice', default=None, type=float, help='Unit price HT')
@click.option('--qty', default=None, type=float, help='Quantity')
@click.option('--tva_tx', default=None, type=float, help='VAT rate')
@click.option('--product_type', default=None, type=int, help='Product type (0=product, 1=service)')
@click.pass_context
def create_line(ctx, invoice_id, data, desc, subprice, qty, tva_tx, product_type):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if desc is not None:
                payload['desc'] = desc
            if subprice is not None:
                payload['subprice'] = subprice
            if qty is not None:
                payload['qty'] = qty
            if tva_tx is not None:
                payload['tva_tx'] = tva_tx
            if product_type is not None:
                payload['product_type'] = product_type
        result = client.post('invoices', resource_id=invoice_id, sub_resource='lines', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('update')
@click.argument('invoice_id', type=int)
@click.argument('line_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_line(ctx, invoice_id, line_id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('invoices', resource_id=invoice_id, sub_resource='lines')
            payload = {}
            if isinstance(existing, list):
                for line in existing:
                    if str(line.get('id', '')) == str(line_id) or str(line.get('rowid', '')) == str(line_id):
                        payload = line
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('invoices', resource_id=invoice_id, sub_resource='lines', sub_id=line_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('delete')
@click.argument('invoice_id', type=int)
@click.argument('line_id', type=int)
@click.pass_context
def delete_line(ctx, invoice_id, line_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('invoices', resource_id=invoice_id, sub_resource='lines', sub_id=line_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
