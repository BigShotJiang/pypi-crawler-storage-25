import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def multicurrencies():
    """Manage Dolibarr multi-currencies."""
    pass


@multicurrencies.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_multicurrencies(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    """List all multi-currencies."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('multicurrencies', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@multicurrencies.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_multicurrency(ctx, id):
    """Get a multi-currency by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('multicurrencies', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@multicurrencies.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--code', default=None, help='Currency code (e.g. USD, EUR)')
@click.option('--name', default=None, help='Currency name')
@click.option('--rate', default=None, type=float, help='Exchange rate')
@click.pass_context
def create_multicurrency(ctx, data, code, name, rate):
    """Create a new multi-currency."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if code is not None:
                payload['code'] = code
            if name is not None:
                payload['name'] = name
            if rate is not None:
                payload['rate'] = rate
        result = client.post('multicurrencies', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@multicurrencies.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_multicurrency(ctx, id, data, set_fields):
    """Update a multi-currency."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('multicurrencies', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('multicurrencies', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@multicurrencies.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_multicurrency(ctx, id):
    """Delete a multi-currency."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('multicurrencies', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@multicurrencies.command('rate')
@click.argument('id', type=int)
@click.pass_context
def get_rate(ctx, id):
    """Get exchange rate for a multi-currency."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('multicurrencies', resource_id=id, sub_resource='rate')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
