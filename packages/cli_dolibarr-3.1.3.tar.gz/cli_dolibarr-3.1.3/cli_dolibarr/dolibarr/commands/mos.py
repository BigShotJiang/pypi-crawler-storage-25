import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def mos():
    pass


@mos.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_mos(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('mos', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mos.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_mo(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('mos', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mos.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--fk_bom', default=None, type=int, help='BOM ID')
@click.option('--fk_soc', default=None, type=int, help='Third party ID')
@click.option('--qty', default=None, type=float, help='Quantity')
@click.pass_context
def create_mo(ctx, data, fk_bom, fk_soc, qty):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if fk_bom is not None:
                payload['fk_bom'] = fk_bom
            if fk_soc is not None:
                payload['fk_soc'] = fk_soc
            if qty is not None:
                payload['qty'] = qty
        result = client.post('mos', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mos.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_mo(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('mos', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('mos', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mos.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_mo(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('mos', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@mos.group()
def lines():
    pass


@lines.command('list')
@click.argument('mo_id', type=int)
@click.pass_context
def list_lines(ctx, mo_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('mos', resource_id=mo_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('create')
@click.argument('mo_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--fk_product', default=None, type=int, help='Product ID')
@click.option('--qty', default=None, type=float, help='Quantity')
@click.pass_context
def create_line(ctx, mo_id, data, fk_product, qty):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if fk_product is not None:
                payload['fk_product'] = fk_product
            if qty is not None:
                payload['qty'] = qty
        result = client.post('mos', resource_id=mo_id, sub_resource='lines', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('update')
@click.argument('mo_id', type=int)
@click.argument('line_id', type=int)
@click.option('--data', default=None, help='JSON string with line fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_line(ctx, mo_id, line_id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('mos', resource_id=mo_id, sub_resource='lines')
            payload = {}
            if isinstance(existing, list):
                for line in existing:
                    if str(line.get('id', '')) == str(line_id) or str(line.get('rowid', '')) == str(line_id):
                        payload = line
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('mos', resource_id=mo_id, sub_resource='lines', sub_id=line_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('delete')
@click.argument('mo_id', type=int)
@click.argument('line_id', type=int)
@click.pass_context
def delete_line(ctx, mo_id, line_id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('mos', resource_id=mo_id, sub_resource='lines', sub_id=line_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
