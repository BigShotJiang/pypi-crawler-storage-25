import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


RESOURCE = 'supplierinvoices'


@click.group()
def supplierinvoices():
    """Get properties of a supplier invoice object"""
    pass


@supplierinvoices.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_supplierinvoices(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List supplierinvoices."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_supplierinvoice(ctx, id):
    """Get supplierinvoices by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.pass_context
def create_supplierinvoice(ctx, data):
    """Create supplierinvoices."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}

        result = client.post(RESOURCE, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_supplierinvoice(ctx, id, data, set_fields):
    """Update supplierinvoices."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get(RESOURCE, resource_id=id)
            payload = existing if isinstance(existing, dict) else {}
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put(RESOURCE, resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_supplierinvoice(ctx, id):
    """Delete supplierinvoices."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.command('validate')
@click.argument('id', type=int)
@click.pass_context
def validate_supplierinvoices(ctx, id):
    """Validate an invoice"""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.post(RESOURCE, resource_id=id, action='validate')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@supplierinvoices.group()
def lines():
    """Manage lines for supplierinvoices."""
    pass


@lines.command('list')
@click.argument('parent_id', type=int)
@click.pass_context
def list_lines(ctx, parent_id):
    """List lines."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=parent_id, sub_resource='lines')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_lines(ctx, parent_id, data):
    """Create lines."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='lines', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('update')
@click.argument('parent_id', type=int)
@click.argument('sub_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_lines(ctx, parent_id, sub_id, data, set_fields):
    """Update lines."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get(RESOURCE, resource_id=parent_id, sub_resource='lines')
            payload = {}
            if isinstance(existing, list):
                for item in existing:
                    if str(item.get('id', '')) == str(sub_id) or str(item.get('rowid', '')) == str(sub_id):
                        payload = item
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put(RESOURCE, resource_id=parent_id, sub_resource='lines', sub_id=sub_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@lines.command('delete')
@click.argument('parent_id', type=int)
@click.argument('sub_id', type=int)
@click.pass_context
def delete_lines(ctx, parent_id, sub_id):
    """Delete lines."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=parent_id, sub_resource='lines', sub_id=sub_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@supplierinvoices.group()
def payments():
    """Manage payments for supplierinvoices."""
    pass


@payments.command('list')
@click.argument('parent_id', type=int)
@click.pass_context
def list_payments(ctx, parent_id):
    """List payments."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=parent_id, sub_resource='payments')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@payments.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_payments(ctx, parent_id, data):
    """Create payments."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='payments', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
