import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def products():
    pass


@products.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.option('--properties', default=None, help='Fields to return')
@click.pass_context
def list_products(ctx, sortfield, sortorder, limit, page, sqlfilters, properties):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('products', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters,
                             properties=properties)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_product(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('products', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--ref', default=None, help='Product reference')
@click.option('--label', default=None, help='Product label')
@click.option('--barcode', default=None, help='Barcode')
@click.option('--price', default=None, type=float, help='Price HT')
@click.option('--price_ttc', default=None, type=float, help='Price TTC')
@click.option('--tva_tx', default=None, type=float, help='VAT rate')
@click.option('--status', default=None, type=int, help='Status (0=not on sale, 1=on sale)')
@click.option('--weight', default=None, type=float, help='Weight')
@click.option('--weight_units', default=None, type=int, help='Weight units (0=kg, -6=g)')
@click.pass_context
def create_product(ctx, data, ref, label, barcode, price, price_ttc, tva_tx, status, weight, weight_units):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if ref is not None:
                payload['ref'] = ref
            if label is not None:
                payload['label'] = label
            if barcode is not None:
                payload['barcode'] = barcode
            if price is not None:
                payload['price'] = price
            if price_ttc is not None:
                payload['price_ttc'] = price_ttc
            if tva_tx is not None:
                payload['tva_tx'] = tva_tx
            if status is not None:
                payload['status'] = status
            if weight is not None:
                payload['weight'] = weight
            if weight_units is not None:
                payload['weight_units'] = weight_units
        result = client.post('products', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_product(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('products', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('products', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_product(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('products', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('barcode')
@click.argument('barcode_val')
@click.pass_context
def barcode_product(ctx, barcode_val):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('products', sqlfilters=f"t.barcode='{barcode_val}'")
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@products.command('categories')
@click.argument('id', type=int)
@click.pass_context
def categories_product(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('categories', resource_id=id, sub_resource='products')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
