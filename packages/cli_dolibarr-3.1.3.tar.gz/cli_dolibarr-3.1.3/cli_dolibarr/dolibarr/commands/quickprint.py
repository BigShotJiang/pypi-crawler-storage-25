"""CLI commands for Dolibarr quickprint module (ZPL label printing).

Uses SessionClient with DOLAPIKEY auth for custom endpoints
under /custom/quickprint/api/zpl/.
"""

import sys
import json
import click

from cli_dolibarr.dolibarr.core.client import DolibarrAPIError
from cli_dolibarr.dolibarr.core.session_client import SessionClient
from cli_dolibarr.dolibarr.core.output import OutputFormatter

PREFIX = "custom/quickprint/api/zpl"


def _get_session_client(ctx) -> SessionClient:
    cfg = ctx.obj["config"]
    cfg.resolve()
    base_url = cfg.base_url
    api_key = cfg.api_key
    if not base_url or not api_key:
        click.echo(
            "Error: base_url and api_key required (config or flags)",
            err=True,
        )
        sys.exit(1)
    return SessionClient(base_url=base_url, api_key=api_key)


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj["formatter"]


def _output(ctx, result):
    _get_formatter(ctx).output(result)


@click.group()
def quickprint():
    """QuickPrint module commands (ZPL label printing)."""


@quickprint.command()
@click.option("--data", default=None, help="Full label data JSON payload")
@click.option("--printer", default=None, help="Target printer name/ID")
@click.option("--template", default=None, help="Template name/ID to use")
@click.option("--quantity", default=None, help="Number of labels to print")
@click.pass_context
def print(ctx, data, printer, template, quantity):
    """Print a ZPL label."""
    client = _get_session_client(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
        if printer:
            payload["printer"] = printer
        if template:
            payload["template"] = template
        if quantity:
            payload["quantity"] = int(quantity)
        result = client.post(f"{PREFIX}/print.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@quickprint.command()
@click.option("--data", default=None, help="Full batch label data JSON payload")
@click.pass_context
def batch_print(ctx, data):
    """Batch print ZPL labels."""
    client = _get_session_client(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(f"{PREFIX}/batch_print.php", data=payload)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@quickprint.command()
@click.pass_context
def printers(ctx):
    """List available printers."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/printers.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@quickprint.command()
@click.pass_context
def templates(ctx):
    """List available label templates."""
    client = _get_session_client(ctx)
    try:
        result = client.get(f"{PREFIX}/templates.php")
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@quickprint.command()
@click.option("--data", default=None, help="Label data JSON for preview")
@click.option("--template", default=None, help="Template name/ID")
@click.pass_context
def preview(ctx, data, template):
    """Preview ZPL label (without printing)."""
    client = _get_session_client(ctx)
    try:
        params = {}
        if data:
            params["data"] = data
        if template:
            params["template"] = template
        result = client.get(f"{PREFIX}/preview.php", **params)
        _output(ctx, result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
