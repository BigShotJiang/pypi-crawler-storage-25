import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def stock():
    pass


@stock.group()
def warehouse():
    pass


@warehouse.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_warehouses(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('warehouses', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@warehouse.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_warehouse(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get('warehouses', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@warehouse.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--label', default=None, help='Warehouse label')
@click.option('--description', default=None, help='Description')
@click.option('--address', default=None, help='Address')
@click.pass_context
def create_warehouse(ctx, data, label, description, address):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if label is not None:
                payload['label'] = label
                payload['name'] = label
            if description is not None:
                payload['description'] = description
            if address is not None:
                payload['address'] = address
        result = client.post('warehouses', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@warehouse.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_warehouse(ctx, id, data, set_fields):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get('warehouses', resource_id=id)
            payload = {}
            if isinstance(existing, dict):
                payload = existing
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put('warehouses', resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@warehouse.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_warehouse(ctx, id):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete('warehouses', resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stock.group()
def movement():
    pass


@movement.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_movements(ctx, sortfield, sortorder, limit, page, sqlfilters):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list('stockmovements', sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@movement.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--product_id', default=None, type=int, help='Product ID')
@click.option('--warehouse_id', default=None, type=int, help='Warehouse ID')
@click.option('--qty', default=None, type=float, help='Quantity')
@click.option('--movementlabel', default=None, help='Movement label')
@click.option('--movementcode', default=None, help='Movement code')
@click.option('--lot', default=None, help='Lot number')
@click.option('--type', default=None, type=int, help='Movement type')
@click.option('--price', default=None, type=float, help='Price')
@click.option('--dlc', default=None, help='Use-by date')
@click.option('--dluo', default=None, help='Best-before date')
@click.pass_context
def create_movement(ctx, data, product_id, warehouse_id, qty, movementlabel,
                    movementcode, lot, type, price, dlc, dluo):
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if product_id is not None:
                payload['product_id'] = product_id
            if warehouse_id is not None:
                payload['warehouse_id'] = warehouse_id
            if qty is not None:
                payload['qty'] = qty
            if movementlabel is not None:
                payload['movementlabel'] = movementlabel
            if movementcode is not None:
                payload['movementcode'] = movementcode
            if lot is not None:
                payload['lot'] = lot
            if type is not None:
                payload['type'] = type
            if price is not None:
                payload['price'] = price
            if dlc is not None:
                payload['dlc'] = dlc
            if dluo is not None:
                payload['dluo'] = dluo
        result = client.post('stockmovements', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
