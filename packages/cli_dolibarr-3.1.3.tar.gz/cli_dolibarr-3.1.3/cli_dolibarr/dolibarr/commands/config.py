import sys
import click

from cli_dolibarr.dolibarr.core.config import DolibarrConfig
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError


@click.group()
def config():
    """Manage Dolibarr CLI configuration."""
    pass


@config.command('init')
@click.option('--url', default=None, help='Dolibarr instance URL')
@click.option('--api-key', default=None, help='Dolibarr API key')
def config_init(url, api_key):
    """Initialize Dolibarr CLI configuration.

    Prompts interactively for URL and API key unless --url and --api-key are provided.
    Saves configuration to ~/.config/cli-dolibarr/config.json.
    """
    try:
        cfg = DolibarrConfig()

        if url is None:
            url = click.prompt('Dolibarr URL', type=str)
        if api_key is None:
            api_key = click.prompt('Dolibarr API key', type=str, hide_input=True)

        url = url.strip().rstrip('/')
        api_key = api_key.strip()

        if not url:
            click.echo("Error: URL cannot be empty.", err=True)
            sys.exit(1)
        if not api_key:
            click.echo("Error: API key cannot be empty.", err=True)
            sys.exit(1)

        cfg.base_url = url
        cfg.api_key = api_key
        cfg.save()

        click.echo(f"Configuration saved to {cfg.config_path}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@config.command('show')
def config_show():
    """Display current Dolibarr CLI configuration.

    Loads configuration from ~/.config/cli-dolibarr/config.json.
    API key is masked for security.
    """
    try:
        cfg = DolibarrConfig()
        loaded = cfg.load()

        if not loaded:
            click.echo("No configuration found. Run 'config init' first.", err=True)
            sys.exit(1)

        masked_key = _mask_api_key(cfg.api_key)

        click.echo(f"Config file : {cfg.config_path}")
        click.echo(f"Base URL    : {cfg.base_url}")
        click.echo(f"API Key     : {masked_key}")
        click.echo(f"Verify SSL  : {cfg.verify_ssl}")
        click.echo(f"Output      : {cfg.output_format}")
        click.echo(f"Default Limit: {cfg.default_limit}")
        click.echo(f"Sort Field  : {cfg.default_sortfield}")
        click.echo(f"Sort Order  : {cfg.default_sortorder}")

        if not cfg.is_configured():
            click.echo("\nWarning: Configuration is incomplete (missing URL or API key).", err=True)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@config.command('test')
def config_test():
    """Test connection to Dolibarr using current configuration.

    Loads saved configuration and attempts to connect to the Dolibarr instance.
    """
    try:
        cfg = DolibarrConfig()
        cfg.resolve()

        if not cfg.is_configured():
            click.echo(
                "Error: No configuration found. Run 'config init' first.",
                err=True,
            )
            sys.exit(1)

        masked_key = _mask_api_key(cfg.api_key)
        click.echo(f"Connecting to {cfg.base_url} (key: {masked_key})...")

        client = DolibarrClient(
            base_url=cfg.base_url,
            api_key=cfg.api_key,
            verify_ssl=cfg.verify_ssl,
        )

        if client.test_connection():
            click.echo("Connection successful!")
        else:
            click.echo("Connection failed. Check your URL and API key.", err=True)
            sys.exit(1)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


def _mask_api_key(key: str) -> str:
    """Mask API key, showing only first 4 characters."""
    if not key:
        return '(not set)'
    if len(key) <= 4:
        return '****'
    return key[:4] + '****'
