import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter

RESOURCE = 'stockmoduleapi'


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


@click.group()
def stockmodule():
    """StockModule - inbound/outbound inventory management."""
    pass


# ── Inbound ──────────────────────────────────────────────────────────────

@stockmodule.command('list-inbound')
@click.option('--sortfield', default='id', help='Sort field')
@click.option('--sortorder', default='DESC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.pass_context
def list_inbound(ctx, sortfield, sortorder, limit, page):
    """List inbound stock records."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {'sortfield': sortfield, 'sortorder': sortorder,
                  'limit': limit, 'page': page}
        url = client._url(f'{RESOURCE}/inbound')
        response = client.session.get(url, params=params)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockmodule.command('create-inbound')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--product-name', required=False, help='Product name (required)')
@click.option('--quantity', default=None, type=float, help='Quantity')
@click.option('--batch-number', default=None, help='Batch number')
@click.option('--warehouse-location', default=None, help='Warehouse location')
@click.option('--operator', default=None, help='Operator name')
@click.option('--remarks', default=None, help='Remarks')
@click.pass_context
def create_inbound(ctx, data, product_name, quantity, batch_number,
                   warehouse_location, operator, remarks):
    """Create an inbound stock record."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if product_name is not None:
                payload['product_name'] = product_name
            if quantity is not None:
                payload['quantity'] = quantity
            if batch_number is not None:
                payload['batch_number'] = batch_number
            if warehouse_location is not None:
                payload['warehouse_location'] = warehouse_location
            if operator is not None:
                payload['operator'] = operator
            if remarks is not None:
                payload['remarks'] = remarks
        url = client._url(f'{RESOURCE}/inbound')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Outbound ─────────────────────────────────────────────────────────────

@stockmodule.command('list-outbound')
@click.option('--sortfield', default='id', help='Sort field')
@click.option('--sortorder', default='DESC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.pass_context
def list_outbound(ctx, sortfield, sortorder, limit, page):
    """List outbound stock records."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        params = {'sortfield': sortfield, 'sortorder': sortorder,
                  'limit': limit, 'page': page}
        url = client._url(f'{RESOURCE}/outbound')
        response = client.session.get(url, params=params)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockmodule.command('create-outbound')
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--product-name', required=False, help='Product name (required)')
@click.option('--quantity', default=None, type=float, help='Quantity')
@click.option('--batch-number', default=None, help='Batch number')
@click.option('--warehouse-location', default=None, help='Warehouse location')
@click.option('--operator', default=None, help='Operator name')
@click.option('--remarks', default=None, help='Remarks')
@click.pass_context
def create_outbound(ctx, data, product_name, quantity, batch_number,
                    warehouse_location, operator, remarks):
    """Create an outbound stock record."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}
            if product_name is not None:
                payload['product_name'] = product_name
            if quantity is not None:
                payload['quantity'] = quantity
            if batch_number is not None:
                payload['batch_number'] = batch_number
            if warehouse_location is not None:
                payload['warehouse_location'] = warehouse_location
            if operator is not None:
                payload['operator'] = operator
            if remarks is not None:
                payload['remarks'] = remarks
        url = client._url(f'{RESOURCE}/outbound')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Search ───────────────────────────────────────────────────────────────

@stockmodule.command('search')
@click.argument('keyword')
@click.pass_context
def search(ctx, keyword):
    """Search stock records by keyword."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/search')
        response = client.session.get(url, params={'keyword': keyword})
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


# ── Debug ────────────────────────────────────────────────────────────────

@stockmodule.command('debug-status')
@click.pass_context
def debug_status(ctx):
    """Get debug status."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        url = client._url(f'{RESOURCE}/debug/status')
        response = client.session.get(url)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@stockmodule.command('debug-toggle')
@click.option('--data', default=None, help='JSON string with toggle parameters')
@click.pass_context
def debug_toggle(ctx, data):
    """Toggle debug mode."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        url = client._url(f'{RESOURCE}/debug/toggle')
        response = client.session.post(url, json=payload)
        result = client._handle_response(response)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
