import sys
import click
import json
from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError
from cli_dolibarr.dolibarr.core.output import OutputFormatter


def _get_client(ctx) -> DolibarrClient:
    return ctx.obj['client']


def _get_formatter(ctx) -> OutputFormatter:
    return ctx.obj['formatter']


RESOURCE = 'tasks'


@click.group()
def tasks():
    """Get properties of a task object"""
    pass


@tasks.command('list')
@click.option('--sortfield', default='t.rowid', help='Sort field')
@click.option('--sortorder', default='ASC', type=click.Choice(['ASC', 'DESC']))
@click.option('--limit', default=100, type=int, help='Items per page')
@click.option('--page', default=0, type=int, help='Page number')
@click.option('--filter', 'sqlfilters', default=None, help='SQL filter')
@click.pass_context
def list_tasks(ctx, sortfield, sortorder, limit, page, sqlfilters):
    """List tasks."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,
                             limit=limit, page=page, sqlfilters=sqlfilters)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@tasks.command('get')
@click.argument('id', type=int)
@click.pass_context
def get_task(ctx, id):
    """Get tasks by ID."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@tasks.command('create')
@click.option('--data', default=None, help='JSON string with all fields')
@click.pass_context
def create_task(ctx, data):
    """Create tasks."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            payload = {}

        result = client.post(RESOURCE, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@tasks.command('update')
@click.argument('id', type=int)
@click.option('--data', default=None, help='JSON string with all fields')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_task(ctx, id, data, set_fields):
    """Update tasks."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get(RESOURCE, resource_id=id)
            payload = existing if isinstance(existing, dict) else {}
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put(RESOURCE, resource_id=id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@tasks.command('delete')
@click.argument('id', type=int)
@click.pass_context
def delete_task(ctx, id):
    """Delete tasks."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)



@tasks.group()
def addtimespent():
    """Manage addtimespent for tasks."""
    pass


@addtimespent.command('create')
@click.argument('parent_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.pass_context
def create_addtimespent(ctx, parent_id, data):
    """Create addtimespent."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        payload = json.loads(data) if data else {}
        result = client.post(RESOURCE, resource_id=parent_id, sub_resource='addtimespent', data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tasks.group()
def roles():
    """Manage roles for tasks."""
    pass


@roles.command('list')
@click.argument('parent_id', type=int)
@click.pass_context
def list_roles(ctx, parent_id):
    """List roles."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.get(RESOURCE, resource_id=parent_id, sub_resource='roles')
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@tasks.group()
def timespent():
    """Manage timespent for tasks."""
    pass


@timespent.command('update')
@click.argument('parent_id', type=int)
@click.argument('sub_id', type=int)
@click.option('--data', default=None, help='JSON string')
@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')
@click.pass_context
def update_timespent(ctx, parent_id, sub_id, data, set_fields):
    """Update timespent."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        if data:
            payload = json.loads(data)
        else:
            existing = client.get(RESOURCE, resource_id=parent_id, sub_resource='timespent')
            payload = {}
            if isinstance(existing, list):
                for item in existing:
                    if str(item.get('id', '')) == str(sub_id) or str(item.get('rowid', '')) == str(sub_id):
                        payload = item
                        break
            for sf in set_fields:
                if '=' in sf:
                    k, v = sf.split('=', 1)
                    payload[k] = v
        result = client.put(RESOURCE, resource_id=parent_id, sub_resource='timespent', sub_id=sub_id, data=payload)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)


@timespent.command('delete')
@click.argument('parent_id', type=int)
@click.argument('sub_id', type=int)
@click.pass_context
def delete_timespent(ctx, parent_id, sub_id):
    """Delete timespent."""
    client = _get_client(ctx)
    formatter = _get_formatter(ctx)
    try:
        result = client.delete(RESOURCE, resource_id=parent_id, sub_resource='timespent', sub_id=sub_id)
        formatter.output(result)
    except DolibarrAPIError as e:
        click.echo(f"Error: {e.message}", err=True)
        sys.exit(1)
