"""Hermes plugin: Auto-registers 388 Dolibarr API tools.

This plugin is loaded by the Hermes agent framework. It generates
OpenAI function calling tool definitions from the Dolibarr schema
and registers them with the Hermes tool registry.

Installation:
    Copy this directory to ~/.hermes/plugins/dolibarr/
    Or run: bash cli_dolibarr/dolibarr/hermes_plugin/install.sh

Usage in Hermes:
    Hermes will auto-discover the plugin and register all 388 tools
    under the "dolibarr" toolset. The AI model can then call any
    Dolibarr API endpoint through standard function calling.
"""

import json
import os

from cli_dolibarr.dolibarr.tools import ToolsSchemaGenerator, ToolsExecutor


_executor = None


def _get_executor():
    """Lazy-initialize the executor (singleton)."""
    global _executor
    if _executor is None:
        _executor = ToolsExecutor.from_config()
    return _executor


def _make_handler(tool_name: str):
    """Create a handler function for a specific tool."""
    def handler(params, **kwargs):
        executor = _get_executor()
        try:
            result = executor.execute(tool_name, params or {})
            return json.dumps(result, default=str)
        except Exception as exc:
            return json.dumps({"error": str(tool_name), "message": str(exc)})
    return handler


def register(ctx):
    """Entry point called by Hermes plugin loader.

    Args:
        ctx: Hermes plugin context with register_tool() method.
    """
    generator = ToolsSchemaGenerator()
    tools = generator.generate_all()

    for tool_def in tools:
        name = tool_def["function"]["name"]
        schema = tool_def["function"]
        handler = _make_handler(name)

        ctx.register_tool(
            name=name,
            toolset="dolibarr",
            schema=schema,
            handler=handler,
        )
