"""Tests for the agent tools layer: ToolsSchemaGenerator + ToolsExecutor."""

import json
import unittest

from cli_dolibarr.dolibarr.tools import ToolsSchemaGenerator, ToolsExecutor


class TestToolsSchemaGenerator(unittest.TestCase):
    """Test the OpenAI Tools Schema generator."""

    @classmethod
    def setUpClass(cls):
        cls.gen = ToolsSchemaGenerator()
        cls.tools = cls.gen.generate_all()

    def test_schema_generator_all_returns_tools(self):
        """generate_all() returns a non-empty list of tool dicts."""
        self.assertIsInstance(self.tools, list)
        self.assertGreater(len(self.tools), 300)
        for t in self.tools:
            self.assertEqual(t["type"], "function")
            self.assertIn("name", t["function"])
            self.assertIn("parameters", t["function"])

    def test_schema_generator_format(self):
        """Each tool has valid OpenAI function calling format."""
        for t in self.tools:
            func = t["function"]
            self.assertIn("name", func)
            self.assertIn("description", func)
            self.assertIn("parameters", func)
            params = func["parameters"]
            self.assertEqual(params.get("type"), "object")
            self.assertIn("properties", params)
            self.assertIn("required", params)

    def test_schema_generator_filtered(self):
        """generate_by_groups() filters correctly."""
        inv_tools = self.gen.generate_by_groups(["invoices"])
        for t in inv_tools:
            self.assertIn("invoice", t["function"]["name"].lower())

    def test_schema_generator_excludes_login(self):
        """Login group endpoints are excluded."""
        names = [t["function"]["name"] for t in self.tools]
        login_group = [t for t in self.tools
                       if self.gen.get_endpoint_by_tool_name(t["function"]["name"])
                       and self.gen.get_endpoint_by_tool_name(t["function"]["name"]).get("group") == "login"]
        self.assertEqual(len(login_group), 0)

    def test_tool_name_uniqueness(self):
        """All generated tool names are unique."""
        names = [t["function"]["name"] for t in self.tools]
        self.assertEqual(len(names), len(set(names)))

    def test_path_params_required(self):
        """Path parameters are in the required list."""
        for t in self.tools:
            params = t["function"]["parameters"]
            name = t["function"]["name"]
            ep = self.gen.get_endpoint_by_tool_name(name)
            if ep:
                path_params = [p["name"] for p in ep.get("parameters", [])
                               if p.get("in") == "path"]
                for pp in path_params:
                    self.assertIn(pp, params.get("required", []),
                                  f"Path param '{pp}' not required in {name}")

    def test_tool_naming_convention(self):
        """Naming follows documented convention (verb_resource pattern)."""
        valid_prefixes = {"list_", "get_", "create_", "update_", "delete_"}
        for t in self.tools:
            name = t["function"]["name"]
            has_valid_prefix = any(name.startswith(p) for p in valid_prefixes)
            self.assertTrue(has_valid_prefix,
                            f"Tool '{name}' doesn't follow naming convention")

    def test_stats(self):
        """Stats are correct."""
        stats = self.gen.get_stats()
        self.assertEqual(stats["total_endpoints"], 391)
        self.assertEqual(stats["excluded"], 3)
        self.assertGreaterEqual(stats["tools_generated"], 385)

    def test_tool_names_method(self):
        """get_tool_names() returns all names."""
        names = self.gen.get_tool_names()
        self.assertEqual(len(names), len(self.tools))


class TestToolsExecutor(unittest.TestCase):
    """Test the ToolsExecutor."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.executor = ToolsExecutor.from_config()
            cls.has_config = True
        except RuntimeError:
            cls.has_config = False

    def test_executor_init(self):
        """ToolsExecutor can be instantiated directly."""
        exec = ToolsExecutor(
            base_url="https://example.com/api/index.php",
            api_key="test_key",
        )
        self.assertEqual(exec.base_url, "https://example.com/api/index.php")
        self.assertEqual(exec.api_key, "test_key")

    def test_executor_from_config(self):
        """from_config() loads from config file or environment."""
        if not self.has_config:
            self.skipTest("No Dolibarr config available")
        self.assertTrue(self.executor.api_key)
        self.assertTrue(self.executor.base_url)

    def test_executor_execute(self):
        """execute() returns dict/list for a live API call."""
        if not self.has_config:
            self.skipTest("No Dolibarr config available")
        result = self.executor.execute("list_status", {})
        self.assertIsInstance(result, (dict, list))

    def test_executor_unknown_tool(self):
        """execute() raises ValueError for unknown tool names."""
        if not self.has_config:
            self.skipTest("No Dolibarr config available")
        with self.assertRaises(ValueError):
            self.executor.execute("nonexistent_tool_xyz", {})

    def test_executor_tool_count(self):
        """tool_count matches generated tools."""
        if not self.has_config:
            self.skipTest("No Dolibarr config available")
        self.assertGreaterEqual(self.executor.tool_count, 385)

    def test_executor_list_tools(self):
        """list_tools() returns tool names."""
        if not self.has_config:
            self.skipTest("No Dolibarr config available")
        names = self.executor.list_tools()
        self.assertIsInstance(names, list)
        self.assertGreater(len(names), 300)


if __name__ == "__main__":
    unittest.main()
