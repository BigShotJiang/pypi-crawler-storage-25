import json
import os
import sys
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from cli_dolibarr.dolibarr.core.client import DolibarrAPIError, DolibarrClient
from cli_dolibarr.dolibarr.core.config import DolibarrConfig
from cli_dolibarr.dolibarr.core.output import OutputFormatter


class TestDolibarrConfig:

    def test_default_config_values(self):
        config = DolibarrConfig()
        assert config.base_url == ''
        assert config.api_key == ''
        assert config.verify_ssl is False
        assert config.default_limit == 100
        assert config.output_format == 'table'
        assert config.default_sortfield == 't.rowid'
        assert config.default_sortorder == 'ASC'

    def test_save_and_load(self, tmp_path):
        config_file = tmp_path / 'config.json'
        config = DolibarrConfig(config_path=config_file)
        config.base_url = 'https://example.com/api'
        config.api_key = 'test-key-123'
        config.verify_ssl = True
        config.default_limit = 50
        config.output_format = 'json'
        config.default_sortfield = 't.ref'
        config.default_sortorder = 'DESC'
        config.save()

        loaded = DolibarrConfig(config_path=config_file)
        assert loaded.load() is True
        assert loaded.base_url == 'https://example.com/api'
        assert loaded.api_key == 'test-key-123'
        assert loaded.verify_ssl is True
        assert loaded.default_limit == 50
        assert loaded.output_format == 'json'
        assert loaded.default_sortfield == 't.ref'
        assert loaded.default_sortorder == 'DESC'

    def test_from_env(self):
        env = {
            'DOLIBARR_URL': 'https://env.example.com/api',
            'DOLIBARR_API_KEY': 'env-key-456',
            'DOLIBARR_VERIFY_SSL': 'true',
        }
        with patch.dict(os.environ, env, clear=False):
            config = DolibarrConfig.from_env()
        assert config.base_url == 'https://env.example.com/api'
        assert config.api_key == 'env-key-456'
        assert config.verify_ssl is True

    def test_from_env_verify_ssl_case_insensitive(self):
        with patch.dict(os.environ, {'DOLIBARR_VERIFY_SSL': 'TRUE'}, clear=False):
            config = DolibarrConfig.from_env()
        assert config.verify_ssl is True

        with patch.dict(os.environ, {'DOLIBARR_VERIFY_SSL': '1'}, clear=False):
            config = DolibarrConfig.from_env()
        assert config.verify_ssl is True

    def test_is_configured_true(self):
        config = DolibarrConfig()
        config.base_url = 'https://example.com'
        config.api_key = 'key'
        assert config.is_configured() is True

    def test_is_configured_false(self):
        config = DolibarrConfig()
        assert config.is_configured() is False
        config.base_url = 'https://example.com'
        assert config.is_configured() is False
        config.api_key = ''
        assert config.is_configured() is False

    def test_resolve_from_config_file(self, tmp_path):
        config_file = tmp_path / 'config.json'
        config = DolibarrConfig(config_path=config_file)
        config.base_url = 'https://file.example.com/api'
        config.api_key = 'file-key-789'
        config.save()

        resolve_config = DolibarrConfig(config_path=config_file)
        with patch.dict(os.environ, {}, clear=False):
            resolve_config.resolve()
        assert resolve_config.base_url == 'https://file.example.com/api'
        assert resolve_config.api_key == 'file-key-789'

    def test_resolve_silent_when_not_configured(self, tmp_path):
        config = DolibarrConfig(config_path=tmp_path / 'nonexistent.json')
        env = {k: v for k, v in os.environ.items() if k not in ('DOLIBARR_URL', 'DOLIBARR_API_KEY')}
        with patch.dict(os.environ, env, clear=True):
            config.resolve()
            assert not config.is_configured()


class TestDolibarrClient:

    def test_url_construction(self):
        client = DolibarrClient.__new__(DolibarrClient)
        client.base_url = 'https://example.com/api/index.php'
        assert client._url('thirdparties') == 'https://example.com/api/index.php/thirdparties'
        assert client._url('thirdparties', 42) == 'https://example.com/api/index.php/thirdparties/42'
        assert client._url('products', 'SKU-001') == 'https://example.com/api/index.php/products/SKU-001'

    def test_url_with_sub_resource(self):
        client = DolibarrClient.__new__(DolibarrClient)
        client.base_url = 'https://example.com/api/index.php'
        assert client._url('orders', 1, sub_resource='lines') == 'https://example.com/api/index.php/orders/1/lines'

    def test_url_with_action(self):
        client = DolibarrClient.__new__(DolibarrClient)
        client.base_url = 'https://example.com/api/index.php'
        assert client._url('thirdparties', 1, action='create') == 'https://example.com/api/index.php/thirdparties/1/create'
        assert client._url('orders', 5, sub_resource='lines', action='create') == 'https://example.com/api/index.php/orders/5/lines/create'

    def test_headers_contain_api_key(self):
        client = DolibarrClient(base_url='https://example.com/api', api_key='test-key')
        assert client.session.headers['DOLAPIKEY'] == 'test-key'
        assert client.session.headers['Content-Type'] == 'application/json'

    def test_ssl_verify_false_default(self):
        client = DolibarrClient(base_url='https://example.com/api', api_key='key')
        assert client.session.verify is False

    def test_ssl_verify_true(self):
        client = DolibarrClient(base_url='https://example.com/api', api_key='key', verify_ssl=True)
        assert client.session.verify is True

    def test_base_url_stripped_trailing_slash(self):
        client = DolibarrClient(base_url='https://example.com/api/', api_key='key')
        assert client.base_url == 'https://example.com/api'


class TestDolibarrAPIError:

    def test_error_message(self):
        err = DolibarrAPIError("Something went wrong")
        assert str(err) == 'HTTP 0: Something went wrong'
        assert err.message == 'Something went wrong'
        assert err.status_code == 0
        assert err.response is None

    def test_error_with_status_code(self):
        err = DolibarrAPIError("Not found", status_code=404)
        assert str(err) == 'HTTP 404: Not found'
        assert err.status_code == 404

    def test_error_with_response(self):
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = 'Internal Server Error'
        err = DolibarrAPIError("Server error", status_code=500, response=mock_response)
        assert err.status_code == 500
        assert err.response is mock_response
        assert err.response.text == 'Internal Server Error'


class TestOutputFormatter:

    def _capture(self, data, fmt='table', columns=None, title=None):
        old_stdout = sys.stdout
        sys.stdout = buf = StringIO()
        formatter = OutputFormatter(fmt=fmt)
        formatter.output(data, columns=columns, title=title)
        sys.stdout = old_stdout
        return buf.getvalue().strip()

    def test_json_output_list(self):
        data = [{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}]
        output = self._capture(data, fmt='json')
        parsed = json.loads(output)
        assert parsed == data

    def test_json_output_dict(self):
        data = {'id': 1, 'name': 'Test', 'status': 1}
        output = self._capture(data, fmt='json')
        parsed = json.loads(output)
        assert parsed == data

    def test_json_output_scalar(self):
        output = self._capture(42, fmt='json')
        assert output == '42'

    def test_csv_output_list(self):
        data = [{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}]
        output = self._capture(data, fmt='csv')
        lines = output.splitlines()
        assert 'id,name' in lines[0]
        assert any('Alice' in l for l in lines)
        assert any('Bob' in l for l in lines)

    def test_csv_output_dict(self):
        data = {'key1': 'val1', 'key2': 'val2'}
        output = self._capture(data, fmt='csv')
        lines = output.splitlines()
        assert 'key,value' in lines[0]
        assert any('val1' in l for l in lines)
        assert any('val2' in l for l in lines)

    def test_table_output_list(self):
        data = [{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}]
        output = self._capture(data, fmt='table')
        assert 'id' in output
        assert 'name' in output
        assert 'Alice' in output
        assert 'Bob' in output
        assert '(2 items)' in output

    def test_table_output_dict(self):
        data = {'id': 1, 'name': 'Test', 'status': 'active'}
        output = self._capture(data, fmt='table')
        assert 'id: 1' in output
        assert 'name: Test' in output
        assert 'status: active' in output

    def test_table_output_scalar(self):
        assert self._capture(42, fmt='table') == '42'
        assert self._capture('hello', fmt='table') == 'hello'

    def test_table_empty_list(self):
        output = self._capture([], fmt='table')
        assert '(no results)' in output

    def test_auto_columns_priority(self):
        items = [
            {'zzz': 1, 'yyy': 2, 'id': 10, 'ref': 'R001', 'name': 'Test'},
        ]
        formatter = OutputFormatter()
        cols = formatter._auto_columns(items)
        assert cols[0] == 'id'
        assert 'ref' in cols[:3]
        assert 'name' in cols[:4]

    def test_auto_columns_max_limit(self):
        items = [{f'col_{i}': i for i in range(20)}]
        formatter = OutputFormatter()
        cols = formatter._auto_columns(items)
        assert len(cols) <= 8

    def test_auto_columns_empty(self):
        formatter = OutputFormatter()
        assert formatter._auto_columns([]) == []

    def test_truncate_long_value(self):
        assert OutputFormatter._truncate('a' * 50) == 'a' * 37 + '...'
        assert OutputFormatter._truncate('short') == 'short'

    def test_table_output_with_title(self):
        data = [{'id': 1, 'name': 'Test'}]
        output = self._capture(data, fmt='table', title='My Title')
        assert 'My Title' in output
        assert '===' in output

    def test_table_output_error_dict(self):
        data = {'error': 'Something failed'}
        output = self._capture(data, fmt='table')
        assert 'Error: Something failed' in output

    def test_table_output_success_with_list(self):
        data = {'success': True, 'data': [{'id': 1, 'name': 'Item'}]}
        output = self._capture(data, fmt='table')
        assert 'id' in output
        assert 'Item' in output

    def test_table_output_success_with_dict(self):
        data = {'success': True, 'data': {'id': 1, 'name': 'Result'}}
        output = self._capture(data, fmt='table')
        assert 'id: 1' in output
        assert 'name: Result' in output


class TestCLIEntryPoints:

    @pytest.fixture
    def cli(self):
        from cli_dolibarr.dolibarr.dolibarr_cli import cli
        return cli

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_cli_help(self, runner, cli):
        result = runner.invoke(cli, ['--help'])
        assert result.exit_code == 0
        assert 'Dolibarr' in result.output or 'API' in result.output

    def test_cli_rejects_no_config(self, runner, cli):
        with patch.dict(os.environ, {}, clear=False):
            with patch.object(DolibarrConfig, 'load', return_value=False):
                result = runner.invoke(cli, ['thirdparties', 'list'])
                assert result.exit_code != 0

    def test_all_commands_registered(self, cli):
        expected = [
            'thirdparties', 'products', 'invoices', 'orders', 'proposals',
            'stock', 'projects', 'contacts', 'categories', 'users',
            'contracts', 'tickets', 'shipments', 'system',
        ]
        for name in expected:
            assert name in cli.commands, f"Missing command group: {name}"
        assert len(cli.commands) >= 14
