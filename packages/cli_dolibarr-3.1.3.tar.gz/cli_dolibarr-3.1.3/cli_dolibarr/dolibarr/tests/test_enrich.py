"""Tests for SchemaManager.enrich() and models_supplement.json coverage."""

import copy
import json
import shutil
import unittest
from pathlib import Path

from cli_dolibarr.dolibarr.core.schema_manager import SchemaManager
from cli_dolibarr.dolibarr.tools import ToolsSchemaGenerator


class TestSchemaEnrich(unittest.TestCase):
    """Test the enrich() method and supplement coverage."""

    @classmethod
    def setUpClass(cls):
        cls.sm = SchemaManager()
        cls.schema_path = cls.sm.SCHEMA_PATH
        cls.supplement_path = cls.sm.SUPPLEMENT_PATH
        # Save original schema.json
        with open(cls.schema_path, 'r', encoding='utf-8') as f:
            cls.original_schema = f.read()

    def setUp(self):
        """Restore schema.json before each test."""
        with open(self.schema_path, 'w', encoding='utf-8') as f:
            f.write(self.original_schema)

    def tearDown(self):
        """Ensure schema.json is restored after each test."""
        with open(self.schema_path, 'w', encoding='utf-8') as f:
            f.write(self.original_schema)

    def test_enrich_empty_supplement(self):
        """With empty supplement, no models are enriched."""
        original_data = json.loads(self.original_schema)

        # Monkey-patch _load_supplement to return {}
        original_load = self.sm._load_supplement
        self.sm._load_supplement = lambda: {}
        try:
            result = self.sm.enrich()
        finally:
            self.sm._load_supplement = original_load

        self.assertEqual(result['enriched'], 0)

        # Restore original schema
        with open(self.schema_path, 'w', encoding='utf-8') as f:
            json.dump(original_data, f, indent=2, ensure_ascii=False)

    def test_enrich_replaces_request_data(self):
        """Enrich replaces a bad model (only request_data) with supplement fields."""
        # Load current schema and make createInvoicesModel bad
        schema = json.loads(self.original_schema)
        schema['models']['createInvoicesModel'] = {
            'properties': {'request_data': {'type': 'string', 'description': 'body'}}
        }
        with open(self.schema_path, 'w', encoding='utf-8') as f:
            json.dump(schema, f, indent=2, ensure_ascii=False)

        result = self.sm.enrich()
        self.assertGreater(result['enriched'], 0)

        # Verify the model now has proper fields from supplement
        enriched_schema = self.sm.load()
        props = enriched_schema['models']['createInvoicesModel']['properties']
        self.assertIn('socid', props)
        self.assertNotIn('request_data', props)

        # Restore
        with open(self.schema_path, 'w', encoding='utf-8') as f:
            f.write(self.original_schema)

    def test_enrich_preserves_good_models(self):
        """Enrich skips models that already have proper fields."""
        result = self.sm.enrich()
        # All 75 supplement models exist in schema and are already good
        self.assertEqual(result['enriched'], 0)
        self.assertEqual(result['skipped_good'], 82)

    def test_enrich_idempotent(self):
        """Calling enrich twice produces identical schema.json content."""
        self.sm.enrich()
        with open(self.schema_path, 'r', encoding='utf-8') as f:
            first = f.read()

        self.sm.enrich()
        with open(self.schema_path, 'r', encoding='utf-8') as f:
            second = f.read()

        self.assertEqual(first, second)

    def test_supplement_json_valid(self):
        """models_supplement.json is valid JSON with exactly 75 keys."""
        with open(self.supplement_path, 'r', encoding='utf-8') as f:
            supplement = json.load(f)
        self.assertIsInstance(supplement, dict)
        self.assertEqual(len(supplement), 82)

    def test_all_bad_models_covered(self):
        """Every supplement model name exists in schema.json models."""
        with open(self.supplement_path, 'r', encoding='utf-8') as f:
            supplement = json.load(f)
        schema = self.sm.load()
        models = schema.get('models', {})

        uncovered = [name for name in supplement if name not in models]
        self.assertEqual(
            uncovered, [],
            f"Supplement models not found in schema: {uncovered}"
        )

    def test_tool_params_enriched(self):
        """create_invoice tool has enriched params (not just request_data)."""
        # Ensure enrich has been applied
        self.sm.enrich()
        gen = ToolsSchemaGenerator()
        tools = gen.generate_all()
        create_invoice = next(
            (t for t in tools if t['function']['name'] == 'create_invoice'),
            None,
        )
        self.assertIsNotNone(create_invoice, "create_invoice tool not found")

        props = create_invoice['function']['parameters']['properties']
        self.assertGreater(len(props), 1, "Should have more than 1 parameter")
        self.assertIn('socid', props, "socid should be in create_invoice params")


if __name__ == "__main__":
    unittest.main()
