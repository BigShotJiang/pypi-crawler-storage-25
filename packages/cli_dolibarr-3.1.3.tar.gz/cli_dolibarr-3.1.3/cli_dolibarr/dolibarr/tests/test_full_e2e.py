import json
import os
import shutil
import subprocess
import sys
import unittest
from collections import namedtuple
from unittest.mock import patch

from click.testing import CliRunner

from cli_dolibarr.dolibarr.dolibarr_cli import cli

SubprocessResult = namedtuple("SubprocessResult", ["returncode", "stdout", "stderr"])


class TestCLISubprocess(unittest.TestCase):

    @staticmethod
    def _resolve_cli():
        if os.environ.get("CLI_ANYTHING_FORCE_INSTALLED") == "1":
            path = shutil.which("cli-dolibarr")
            if path:
                return [path]
            raise FileNotFoundError("cli-dolibarr not found in PATH")
        return [sys.executable, "-m", "cli_dolibarr.dolibarr.dolibarr_cli"]

    def _run(self, *args, env_overrides=None):
        env = dict(os.environ)
        if env_overrides:
            env.update(env_overrides)
        cmd = self._resolve_cli() + list(args)
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=15, env=env,
        )
        return SubprocessResult(proc.returncode, proc.stdout, proc.stderr)


class TestCLIHelp(TestCLISubprocess):

    def test_root_help(self):
        r = self._run("--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("Commands:", r.output if hasattr(r, "output") else r.stdout)

    def test_thirdparties_help(self):
        r = self._run("thirdparties", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        out = r.stdout
        self.assertIn("list", out)
        self.assertIn("create", out)

    def test_products_help(self):
        r = self._run("products", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        out = r.stdout
        self.assertIn("list", out)
        self.assertIn("create", out)

    def test_stock_help(self):
        r = self._run("stock", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        out = r.stdout
        self.assertIn("warehouse", out)
        self.assertIn("movement", out)

    def test_invoices_help(self):
        r = self._run("invoices", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        out = r.stdout
        self.assertIn("validate", out)
        self.assertIn("settopaid", out)

    def test_orders_help(self):
        r = self._run("orders", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_proposals_help(self):
        r = self._run("proposals", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_projects_help(self):
        r = self._run("projects", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_system_help(self):
        r = self._run("system", "--help")
        self.assertEqual(r.returncode, 0, r.stderr)
        out = r.stdout
        self.assertIn("info", out)


class TestCLIErrorHandling(TestCLISubprocess):

    def test_missing_credentials(self):
        env = {
            k: v for k, v in os.environ.items()
            if k not in ("DOLIBARR_URL", "DOLIBARR_API_KEY")
        }
        r = self._run("thirdparties", "list", env_overrides=env)
        self.assertNotEqual(r.returncode, 0)

    def test_invalid_json_flag_combination(self):
        env = {
            k: v for k, v in os.environ.items()
            if k not in ("DOLIBARR_URL", "DOLIBARR_API_KEY")
        }
        r = self._run("--json", "nonexistent_cmd", env_overrides=env)
        self.assertNotEqual(r.returncode, 0)


class TestCLIWithFakeServer(unittest.TestCase):

    def _runner(self):
        return CliRunner(mix_stderr=False)

    @staticmethod
    def _base_env():
        env = dict(os.environ)
        env["DOLIBARR_URL"] = "http://fake"
        env["DOLIBARR_API_KEY"] = "fake"
        return env

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_list_thirdparties_mock(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.list.return_value = [
            {"id": 1, "name": "Test Co", "email": "test@test.com"},
        ]
        runner = self._runner()
        result = runner.invoke(
            cli,
            ["--json", "--url", "http://fake", "--api-key", "fake", "thirdparties", "list"],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("Test Co", result.output)
        mock_instance.list.assert_called_once()

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_get_thirdparty_mock(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.get.return_value = {"id": 1, "name": "Test Co"}
        runner = self._runner()
        result = runner.invoke(
            cli,
            ["--json", "--url", "http://fake", "--api-key", "fake", "thirdparties", "get", "1"],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        data = json.loads(result.output)
        self.assertEqual(data["name"], "Test Co")
        mock_instance.get.assert_called_once()

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_stock_movement_create_mock(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.post.return_value = 42
        runner = self._runner()
        result = runner.invoke(
            cli,
            [
                "--json", "--url", "http://fake", "--api-key", "fake",
                "stock", "movement", "create",
                "--product_id", "1", "--warehouse_id", "1", "--qty", "100",
            ],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("42", result.output)
        mock_instance.post.assert_called_once()


class TestCLIOutputFormats(unittest.TestCase):

    def _runner(self):
        return CliRunner(mix_stderr=False)

    @staticmethod
    def _base_env():
        env = dict(os.environ)
        env["DOLIBARR_URL"] = "http://fake"
        env["DOLIBARR_API_KEY"] = "fake"
        return env

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_json_output(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.list.return_value = [
            {"id": 1, "name": "Acme", "email": "a@b.com"},
            {"id": 2, "name": "Beta", "email": "b@c.com"},
        ]
        runner = self._runner()
        result = runner.invoke(
            cli,
            ["--json", "--url", "http://fake", "--api-key", "fake", "thirdparties", "list"],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        parsed = json.loads(result.output)
        self.assertIsInstance(parsed, list)
        self.assertEqual(len(parsed), 2)

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_table_output(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.list.return_value = [
            {"id": 1, "name": "Acme", "email": "a@b.com"},
            {"id": 2, "name": "Beta", "email": "b@c.com"},
        ]
        runner = self._runner()
        result = runner.invoke(
            cli,
            ["--url", "http://fake", "--api-key", "fake", "thirdparties", "list"],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        self.assertIn("Acme", result.output)
        self.assertIn("|", result.output)

    @patch("cli_dolibarr.dolibarr.dolibarr_cli.DolibarrClient")
    def test_csv_output(self, MockClient):
        mock_instance = MockClient.return_value
        mock_instance.list.return_value = [
            {"id": 1, "name": "Acme", "email": "a@b.com"},
            {"id": 2, "name": "Beta", "email": "b@c.com"},
        ]
        runner = self._runner()
        result = runner.invoke(
            cli,
            ["--csv", "--url", "http://fake", "--api-key", "fake", "thirdparties", "list"],
            env=self._base_env(),
            catch_exceptions=False,
        )
        self.assertEqual(result.exit_code, 0, result.output)
        lines = result.output.strip().split("\n")
        self.assertGreaterEqual(len(lines), 2)
        for line in lines:
            self.assertIn(",", line)


if __name__ == "__main__":
    unittest.main()
