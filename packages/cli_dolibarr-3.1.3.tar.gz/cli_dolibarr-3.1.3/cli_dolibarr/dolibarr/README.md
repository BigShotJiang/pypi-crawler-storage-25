# cli-dolibarr

A stateful command-line interface for managing Dolibarr ERP/CRM via its REST API. Supports third parties, products, invoices, orders, proposals, stock movements, warehouses, projects, tasks, and more.

## Installation

```bash
pip install cli-dolibarr
```

Or install from GitHub:

```bash
pip install git+https://github.com/zswll2/cli-dolibarr.git
```

## Configuration

```bash
cli-dolibarr config init
```

Or set environment variables:

```bash
export DOLIBARR_URL="https://your-dolibarr.example.com/api/index.php"
export DOLIBARR_API_KEY="your_api_key"
```

## Usage

### Third Parties (Customers/Companies)

```bash
# List all third parties
cli-dolibarr thirdparties list

# Get a specific third party
cli-dolibarr thirdparties get 42

# Create a third party (required: name)
cli-dolibarr thirdparties create --name "Acme Corp"

# Update a third party
cli-dolibarr thirdparties update 42 --town "New York" --phone "+1234567890"

# Delete a third party
cli-dolibarr thirdparties delete 42
```

### Products

```bash
# List products
cli-dolibarr products list

# Get a specific product
cli-dolibarr products get 7

# Create a product (required: ref, label)
cli-dolibarr products create --ref "PROD-001" --label "Widget A"

# Update a product
cli-dolibarr products update 7 --description "Updated description"

# Delete a product
cli-dolibarr products delete 7
```

### Invoices

```bash
# List invoices
cli-dolibarr invoices list

# Get a specific invoice
cli-dolibarr invoices get 15

# Create an invoice (required: socid)
cli-dolibarr invoices create --socid 42

# Update an invoice
cli-dolibarr invoices update 15 --note "Payment pending"

# Delete an invoice
cli-dolibarr invoices delete 15
```

### Orders

```bash
# List orders
cli-dolibarr orders list

# Get a specific order
cli-dolibarr orders get 23

# Create an order (required: socid, date)
cli-dolibarr orders create --socid 42 --date "2026-01-15"

# Update an order
cli-dolibarr orders update 23 --note "Expedited shipping"

# Delete an order
cli-dolibarr orders delete 23
```

### Proposals

```bash
# List proposals
cli-dolibarr proposals list

# Get a specific proposal
cli-dolibarr proposals get 31

# Create a proposal (required: socid)
cli-dolibarr proposals create --socid 42

# Update a proposal
cli-dolibarr proposals update 31 --note "Revised terms"

# Delete a proposal
cli-dolibarr proposals delete 31
```

### Stock Movements

```bash
# List stock movements
cli-dolibarr stockmovements list

# Stock in (type=3, positive qty)
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty 50

# Stock out (type=2, negative qty)
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty -10
```

### Warehouses

```bash
# List warehouses
cli-dolibarr warehouses list

# Get a specific warehouse
cli-dolibarr warehouses get 1

# Create a warehouse (required: label)
cli-dolibarr warehouses create --label "Main Warehouse"

# Update a warehouse
cli-dolibarr warehouses update 1 --town "Shanghai"

# Delete a warehouse
cli-dolibarr warehouses delete 1
```

### Projects

```bash
# List projects
cli-dolibarr projects list

# Get a specific project
cli-dolibarr projects get 5

# Create a project (required: title)
cli-dolibarr projects create --title "Website Redesign"

# Update a project
cli-dolibarr projects update 5 --description "Phase 2 started"

# Delete a project
cli-dolibarr projects delete 5
```

### Tasks

```bash
# List tasks
cli-dolibarr tasks list

# Get a specific task
cli-dolibarr tasks get 12

# Create a task (requires project context)
cli-dolibarr tasks create --title "Design mockups" --project-id 5

# Update a task
cli-dolibarr tasks update 12 --progress 75

# Delete a task
cli-dolibarr tasks delete 12
```

## Global Options

| Option          | Description                        |
|-----------------|------------------------------------|
| `--json`        | Output in JSON format              |
| `--csv`         | Output in CSV format               |
| `--url`         | Override Dolibarr API URL          |
| `--api-key`     | Override API key                   |
| `--limit N`     | Limit results to N items           |
| `--verify`      | Enable SSL certificate verification|

```bash
# Example: JSON output with limit
cli-dolibarr products list --json --limit 5

# Example: CSV output
cli-dolibarr invoices list --csv

# Example: Override URL and API key
cli-dolibarr thirdparties list --url "https://your-dolibarr.example.com/api/index.php" --api-key "your_api_key"
```

## REPL Mode

Start an interactive session for repeated commands without re-authenticating:

```bash
cli-dolibarr repl
```

Inside the REPL, use commands directly:

```
dolibarr> thirdparties list
dolibarr> products get 7
dolibarr> exit
```

## Environment Variables

| Variable            | Description                          |
|---------------------|--------------------------------------|
| `DOLIBARR_URL`      | Full API URL (e.g., `https://your-dolibarr.example.com/api/index.php`) |
| `DOLIBARR_API_KEY`  | API key from Dolibarr user settings  |
| `DOLIBARR_VERIFY_SSL`| Set to `1` or `true` to verify SSL  |

## SQL Filters

Use the `--sql-filter` option to apply advanced filters on list commands:

```bash
# Filter by name pattern
cli-dolibarr thirdparties list --sql-filter "(t.name:like:'Acme%')"

# Filter by date range
cli-dolibarr invoices list --sql-filter "(t.datec:>=:'2026-01-01')"

# Combined filters
cli-dolibarr products list --sql-filter "(t.toselect:=:1) and (t.status:=:1)"

# IN operator
cli-dolibarr orders list --sql-filter "(t.status:IN:1,2,3)"
```

Operators: `:=`, `:like:`, `:<`, `:>`, `:<=`, `:>=`, `:!=`, `:IN:`, `:NOTIN:`

## SSL Verification

By default, SSL verification is **disabled** (`--no-verify`) to support self-signed certificates common in self-hosted Dolibarr installations. To enable verification:

```bash
cli-dolibarr --verify thirdparties list
```

Or set the environment variable:

```bash
export DOLIBARR_VERIFY_SSL="true"
```

## Schema Management

Built-in schema-driven API discovery system for keeping CLI commands in sync with Dolibarr API changes.

```bash
# Fetch latest API spec from Dolibarr
cli-dolibarr schema sync

# Check coverage (which endpoints have CLI commands)
cli-dolibarr schema diff

# Auto-generate CLI commands for uncovered endpoints
cli-dolibarr schema generate --all

# Preview without writing files
cli-dolibarr schema generate --all --dry-run

# Generate AI code map (AGENTS.md)
cli-dolibarr schema agents

# Export endpoint data for AI fine-tuning
cli-dolibarr schema export --format jsonl --output data.jsonl
```

## Available Commands

49 command groups covering all Dolibarr REST API resources: thirdparties, products, invoices, orders, proposals, shipments, projects, tasks, warehouses, stockmovements, contacts, bankaccounts, categories, users, tickets, webhooks, and more. Run `cli-dolibarr --help` for the full list.

---

## 中文说明

Dolibarr ERP/CRM REST API 的命令行管理工具。支持客户、产品、发票、订单、报价、库存、仓库、项目、任务等 49 个模块。

### 安装

```bash
pip install cli-dolibarr
```

或从 GitHub 安装：

```bash
pip install git+https://github.com/zswll2/cli-dolibarr.git
```

### 配置

```bash
# 交互式配置（输入 URL 和 API Key）
cli-dolibarr config init

# 或使用环境变量
export DOLIBARR_URL="https://your-dolibarr.example.com/api/index.php"
export DOLIBARR_API_KEY="your_api_key"
```

### 常用命令

```bash
# 客户管理
cli-dolibarr thirdparties list                          # 列出所有客户
cli-dolibarr thirdparties get 42                        # 查看客户详情
cli-dolibarr thirdparties create --name "Acme Corp"     # 创建客户

# 产品管理
cli-dolibarr products list                              # 列出产品
cli-dolibarr products create --ref "P001" --label "产品A" # 创建产品

# 发票管理
cli-dolibarr invoices list                              # 列出发票
cli-dolibarr invoices create --socid 42                 # 创建发票

# 订单管理
cli-dolibarr orders list                                # 列出订单
cli-dolibarr orders create --socid 42 --date "2026-01-15" # 创建订单

# 库存管理
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty 50  # 入库
cli-dolibarr stockmovements create --product-id 7 --warehouse-id 1 --qty -10  # 出库

# 项目与任务
cli-dolibarr projects list                              # 列出项目
cli-dolibarr tasks list                                 # 列出任务
```

### Schema 管理系统

内置 API 自动发现系统，Dolibarr 升级后可自动同步新端点：

```bash
cli-dolibarr schema sync           # 从 Dolibarr 拉取最新 API 定义
cli-dolibarr schema diff           # 查看覆盖情况（哪些有命令、哪些没有）
cli-dolibarr schema generate --all # 自动生成缺失的 CLI 命令
cli-dolibarr schema agents         # 生成 AI 代码地图 (AGENTS.md)
cli-dolibarr schema export --format jsonl --output data.jsonl  # 导出微调数据
```

### 输出格式

```bash
cli-dolibarr --json products list   # JSON 格式
cli-dolibarr --csv invoices list    # CSV 格式（可导入 Excel）
```

### 全局选项

| 选项 | 说明 |
|------|------|
| `--json` | JSON 格式输出 |
| `--csv` | CSV 格式输出 |
| `--url` | 覆盖 API URL |
| `--api-key` | 覆盖 API Key |
| `--limit N` | 限制返回条数 |
| `--verify` | 启用 SSL 证书验证 |

### 交互模式

```bash
cli-dolibarr repl
# 进入后可直接输入命令：
# doli> thirdparties list
# doli> products get 7
# doli> exit
```

### SQL 过滤器

```bash
cli-dolibarr thirdparties list --sql-filter "(t.name:like:'Acme%')"   # 按名称筛选
cli-dolibarr invoices list --sql-filter "(t.datec:>=:'2026-01-01')"   # 按日期筛选
```

支持的操作符：`:=`, `:like:`, `:<`, `:>`, `:<=`, `:>=`, `:!=`, `:IN:`, `:NOTIN:`
