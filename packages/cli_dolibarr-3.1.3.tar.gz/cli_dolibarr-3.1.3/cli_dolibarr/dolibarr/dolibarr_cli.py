import sys
import os
import importlib
import logging
import click
from cli_dolibarr.dolibarr.core.client import DolibarrClient
from cli_dolibarr.dolibarr.core.config import DolibarrConfig
from cli_dolibarr.dolibarr.core.output import OutputFormatter

logger = logging.getLogger(__name__)


def _init_client(url, api_key, verify):
    config = DolibarrConfig()
    config.resolve()
    base_url = url or config.base_url
    api_key_val = api_key or config.api_key
    if not base_url or not api_key_val:
        click.echo("Error: --url and --api-key required, or configure via env/config", err=True)
        sys.exit(1)
    return DolibarrClient(base_url=base_url, api_key=api_key_val, verify_ssl=verify), config


@click.group(chain=False)
@click.option('--url', default=None, help='Dolibarr base URL')
@click.option('--api-key', default=None, help='Dolibarr API key')
@click.option('--json', 'output_json', is_flag=True, default=False, help='Output as JSON')
@click.option('--csv', 'output_csv', is_flag=True, default=False, help='Output as CSV')
@click.option('--limit', default=None, type=int, help='Default limit for list commands')
@click.option('--verify/--no-verify', default=False, help='Verify SSL certificates')
@click.pass_context
def cli(ctx, url, api_key, output_json, output_csv, limit, verify):
    fmt = 'table'
    if output_json:
        fmt = 'json'
    elif output_csv:
        fmt = 'csv'

    client = None
    config = DolibarrConfig()
    if '--help' not in sys.argv and '-h' not in sys.argv:
        client, config = _init_client(url, api_key, verify)

    formatter = OutputFormatter(fmt=fmt)

    ctx.obj = {
        'client': client,
        'formatter': formatter,
        'config': config,
        'limit': limit,
    }


@cli.command()
@click.pass_context
def repl(ctx):
    from click.testing import CliRunner
    runner = CliRunner()
    click.echo("cli-dolibarr REPL")
    click.echo("Type 'help' for commands, 'quit' or 'exit' to leave")
    while True:
        try:
            raw = input("doli> ")
        except (EOFError, KeyboardInterrupt):
            click.echo()
            break

        raw = raw.strip()
        if not raw:
            continue
        if raw in ('quit', 'exit'):
            break
        if raw == 'help':
            click.echo(ctx.get_help())
            continue

        parts = raw.split()
        cmd_args = parts
        result = runner.invoke(cli, cmd_args, obj=ctx.obj, standalone_mode=False)
        if result.exit_code != 0 and result.output:
            click.echo(result.output, err=True)
        elif result.output:
            click.echo(result.output, nl=False)


def _auto_discover_commands():
    """Scan commands/ directory and register all click commands/groups automatically."""
    commands_dir = os.path.join(os.path.dirname(__file__), 'commands')
    if not os.path.isdir(commands_dir):
        return
    for filename in sorted(os.listdir(commands_dir)):
        if not filename.endswith('.py'):
            continue
        if filename.startswith('_'):
            continue
        module_name = filename[:-3]
        full_module = f'cli_dolibarr.dolibarr.commands.{module_name}'
        try:
            mod = importlib.import_module(full_module)
        except Exception as e:
            logger.warning("Failed to import command module %s: %s", full_module, e)
            continue
        # Find click.Command or click.Group at module level
        cmd = getattr(mod, module_name, None)
        if cmd is not None and isinstance(cmd, (click.Command, click.Group)):
            cli.add_command(cmd)
        else:
            # Fallback: scan module dict for any click.Group/Command
            for attr_name, attr_val in vars(mod).items():
                if isinstance(attr_val, (click.Command, click.Group)) and not attr_name.startswith('_'):
                    cli.add_command(attr_val)
                    break


_auto_discover_commands()


if __name__ == '__main__':
    cli()
