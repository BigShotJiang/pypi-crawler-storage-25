"""SessionClient for Dolibarr custom endpoints.

Supports two authentication modes:
  1. DOLAPIKEY header auth (same as DolibarrClient)
  2. Cookie-based session auth via DOLSESSID

URL construction is base_url + path — no /api/index.php/ prefix.
"""

import requests
import urllib3
from typing import Any, Dict, Optional

from cli_dolibarr.dolibarr.core.client import DolibarrAPIError

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class SessionClient:

    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        session_cookie: Optional[str] = None,
        verify_ssl: bool = False,
    ):
        if not api_key and not session_cookie:
            raise ValueError("Either api_key or session_cookie must be provided")

        self.base_url = base_url.rstrip('/')
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.verify = self.verify_ssl
        self.session.headers.update({'Content-Type': 'application/json'})

        if api_key:
            self.session.headers['DOLAPIKEY'] = api_key
        if session_cookie:
            self.session.cookies.set('DOLSESSID', session_cookie)

    def _url(self, path: str) -> str:
        """Build full URL: base_url + path.

        Unlike DolibarrClient which prefixes /api/index.php/, this
        joins the base URL directly with the given path so custom
        endpoint paths like ``/custom/delivery/api/sf_order.php`` work.
        """
        path = path.lstrip('/')
        return f"{self.base_url}/{path}"

    def _handle_response(self, response: requests.Response) -> Any:
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get('error', str(error_data))
            except (ValueError, AttributeError):
                message = response.text[:500]
            raise DolibarrAPIError(message, response.status_code, response)

        content_type = response.headers.get('content-type', '')
        if 'application/json' in content_type:
            try:
                return response.json()
            except ValueError:
                return response.text.strip()
        return response.text.strip()

    def get(self, path: str, **params) -> Any:
        """GET request to ``base_url + path``."""
        url = self._url(path)
        response = self.session.get(url, params=params)
        return self._handle_response(response)

    def post(self, path: str, data: Optional[Dict] = None) -> Any:
        """POST request with JSON body to ``base_url + path``."""
        url = self._url(path)
        response = self.session.post(url, json=data)
        return self._handle_response(response)

    def login(self, username: str, password: str) -> str:
        """Authenticate via the Dolibarr login endpoint.

        POSTs form data to ``/api/index.php/login`` and extracts the
        ``DOLSESSID`` cookie from the response.

        Returns:
            The DOLSESSID cookie value.

        Raises:
            DolibarrAPIError: On HTTP errors or missing session cookie.
        """
        login_url = f"{self.base_url}/api/index.php/login"
        form_data = {
            'login': username,
            'password': password,
            'entity': 1,
        }

        # Temporarily override content-type for form POST
        old_ct = self.session.headers.get('Content-Type')
        self.session.headers['Content-Type'] = 'application/x-www-form-urlencoded'
        try:
            response = self.session.post(login_url, data=form_data)
        finally:
            if old_ct:
                self.session.headers['Content-Type'] = old_ct
            else:
                self.session.headers.pop('Content-Type', None)

        result = self._handle_response(response)

        # Extract DOLSESSID from response cookies
        dol_sessid = None
        for cookie in self.session.cookies:
            if cookie.name == 'DOLSESSID':
                dol_sessid = cookie.value
                break

        if not dol_sessid:
            raise DolibarrAPIError(
                "Login succeeded but no DOLSESSID cookie received",
                response.status_code,
                result,
            )

        return dol_sessid
