"""
SchemaGenerator: Auto-generates Click command .py files from schema.json.

Reads the canonical schema (produced by SchemaManager) and generates
command files that follow the _template.py pattern. Never overwrites
existing files. Keeps generated files <= 300 lines.
"""

from typing import Any, Dict, List, Optional, Tuple

from cli_dolibarr.dolibarr.core.schema_manager import SchemaManager, COMMANDS_DIR

# Groups that are custom CLI commands, not derived from swagger
SKIP_GROUPS = {
    'delivery', 'quickprint', 'mobilehub', 'login', 'config',
    'setup', 'system', 'apibridge', 'schema', 'zapier', 'pdfa',
    'orderprocessor', 'stockmodule', 'mos', 'knowledge',
}

# Common list-endpoint params we always include as click options
COMMON_LIST_PARAMS = {'sortfield', 'sortorder', 'limit', 'page'}

# Params to skip (handled as standard list options)
SKIP_PARAMS = COMMON_LIST_PARAMS | {'sqlfilters', 'properties', 'pagination_data'}

# Swagger type → Click type mapping
TYPE_MAP = {
    'integer': 'int',
    'number': 'float',
    'boolean': 'bool',
    'string': 'str',
}


class SchemaGenerator:
    """Generate Click command .py files from a synced API schema."""

    def __init__(self, schema_manager: Optional[SchemaManager] = None):
        self.manager = schema_manager or SchemaManager()
        self.data: Optional[Dict[str, Any]] = None

    def _load_schema(self) -> Dict[str, Any]:
        if self.data is None:
            self.data = self.manager.load()
            if self.data is None:
                raise FileNotFoundError(
                    "schema.json not found. Run 'schema sync' first."
                )
        return self.data

    # ── Public API ────────────────────────────────────────────────

    def generate_all(self, dry_run: bool = False) -> List[Tuple[str, str, bool]]:
        """Generate command files for all uncovered swagger groups.

        Returns:
            List of (group_name, filename, was_written) tuples.
        """
        schema = self._load_schema()
        endpoints = schema.get('endpoints', [])
        coverage = self.manager.scan_cli_coverage()

        groups_in_schema = {ep['group'] for ep in endpoints}
        uncovered = sorted(
            g for g in groups_in_schema
            if g not in coverage and g not in SKIP_GROUPS
        )

        results: List[Tuple[str, str, bool]] = []
        for group in uncovered:
            group_eps = [ep for ep in endpoints if ep['group'] == group]
            content = self.generate_group(group, group_eps, schema.get('models', {}))
            filename = f"{group.replace('-', '_')}.py"
            if dry_run:
                results.append((group, filename, False))
            else:
                written = self._write_file(filename, content)
                results.append((group, filename, written))
        return results

    def generate_group(
        self,
        group_name: str,
        endpoints: List[Dict[str, Any]],
        models: Dict[str, Any],
    ) -> str:
        """Generate .py file content for an endpoint group."""
        func_name = group_name.replace('-', '_')
        resource = group_name  # REST path segment

        # Categorize endpoints
        crud, actions, sub_resources = self._categorize_endpoints(endpoints)

        lines: List[str] = []
        lines.append('import sys')
        lines.append('import click')
        lines.append('import json')
        lines.append('from cli_dolibarr.dolibarr.core.client import DolibarrClient, DolibarrAPIError')
        lines.append('from cli_dolibarr.dolibarr.core.output import OutputFormatter')
        lines.append('')
        lines.append('')
        lines.append('def _get_client(ctx) -> DolibarrClient:')
        lines.append("    return ctx.obj['client']")
        lines.append('')
        lines.append('')
        lines.append('def _get_formatter(ctx) -> OutputFormatter:')
        lines.append("    return ctx.obj['formatter']")
        lines.append('')
        lines.append('')
        lines.append(f"RESOURCE = '{resource}'")
        lines.append('')
        lines.append('')

        # Group command
        summary = self._group_summary(endpoints)
        lines.append('@click.group()')
        lines.append(f'def {func_name}():')
        lines.append(f'    """{summary}"""')
        lines.append('    pass')
        lines.append('')
        lines.append('')

        # CRUD commands
        if 'list' in crud:
            lines.append(self._gen_list(func_name, resource, crud['list']))
        if 'get' in crud:
            lines.append(self._gen_get(func_name, resource, crud['get']))
        if 'create' in crud:
            lines.append(self._gen_create(func_name, resource, crud['create'], models))
        if 'update' in crud:
            lines.append(self._gen_update(func_name, resource, crud['update']))
        if 'delete' in crud:
            lines.append(self._gen_delete(func_name, resource, crud['delete']))

        # Special action commands (validate, close, etc.)
        for action_name, ep in sorted(actions.items()):
            lines.append(self._gen_action(func_name, resource, action_name, ep))

        # Sub-resource groups
        for sub_name, sub_eps in sorted(sub_resources.items()):
            lines.append(self._gen_sub_resource(func_name, resource, sub_name, sub_eps, models))

        content = '\n'.join(lines)
        # Trim trailing whitespace but keep trailing newline
        content = content.rstrip() + '\n'

        # Enforce 300-line limit
        if len(content.splitlines()) > 300:
            content = self._truncate(content, 300)

        return content

    # ── Endpoint Categorization ───────────────────────────────────

    def _categorize_endpoints(
        self, endpoints: List[Dict[str, Any]]
    ) -> Tuple[Dict[str, Dict], Dict[str, Dict], Dict[str, List[Dict]]]:
        """Sort endpoints into CRUD, actions, and sub-resources."""
        crud: Dict[str, Dict] = {}
        actions: Dict[str, Dict] = {}
        sub_resources: Dict[str, List[Dict]] = {}

        for ep in endpoints:
            path = ep['path']
            method = ep['method']
            parts = self._path_parts(path)

            # Check if sub-resource: /group/{id}/subresource/...
            sub = self._extract_sub_resource(path)
            if sub:
                sub_resources.setdefault(sub, []).append(ep)
                continue

            # CRUD mapping
            if method == 'GET' and '{id}' not in path:
                crud['list'] = ep
            elif method == 'GET' and '{id}' in path:
                crud['get'] = ep
            elif method == 'POST' and '{id}' not in path:
                crud['create'] = ep
            elif method == 'PUT' and '{id}' in path:
                crud['update'] = ep
            elif method == 'DELETE' and '{id}' in path:
                crud['delete'] = ep
            elif method == 'POST' and '{id}' in path:
                # POST on /group/{id}/action → special action
                action_name = self._extract_action_name(path, parts)
                if action_name:
                    actions[action_name] = ep
                else:
                    # POST /group/{id} with no sub-path → treat as create-with-id? skip.
                    pass

        return crud, actions, sub_resources

    @staticmethod
    def _path_parts(path: str) -> List[str]:
        return [p for p in path.strip('/').split('/')
                if p not in ('api', 'index.php')]

    @staticmethod
    def _extract_sub_resource(path: str) -> Optional[str]:
        """Extract sub-resource name from path like /invoices/{id}/lines."""
        parts = path.strip('/').split('/')
        # Skip api/index.php prefixes
        cleaned = [p for p in parts if p not in ('api', 'index.php')]
        # Pattern: group/{id}/subresource or group/{id}/subresource/{subid}
        if len(cleaned) >= 3 and cleaned[1].startswith('{'):
            sub = cleaned[2]
            # Only if it's not a known action or the resource id itself
            if not sub.startswith('{') and sub not in ('validate', 'close', 'reopen',
                    'settopaid', 'setunpaid', 'markAsAccepted'):
                return sub
        return None

    @staticmethod
    def _extract_action_name(path: str, parts: List[str]) -> Optional[str]:
        """Extract action name from POST /group/{id}/action."""
        cleaned = [p for p in parts if not p.startswith('{')]
        if len(cleaned) >= 2:
            return cleaned[-1]
        return None

    # ── Code Generation Helpers ───────────────────────────────────

    def _gen_list(self, func: str, resource: str, ep: Dict) -> str:
        """Generate list command."""
        cmd_func = f'list_{func}'
        return (
            f'@{func}.command(\'list\')\n'
            f'@click.option(\'--sortfield\', default=\'t.rowid\', help=\'Sort field\')\n'
            f'@click.option(\'--sortorder\', default=\'ASC\', type=click.Choice([\'ASC\', \'DESC\']))\n'
            f'@click.option(\'--limit\', default=100, type=int, help=\'Items per page\')\n'
            f'@click.option(\'--page\', default=0, type=int, help=\'Page number\')\n'
            f'@click.option(\'--filter\', \'sqlfilters\', default=None, help=\'SQL filter\')\n'
            f'@click.pass_context\n'
            f'def {cmd_func}(ctx, sortfield, sortorder, limit, page, sqlfilters):\n'
            f'    """List {resource}."""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        result = client.list(RESOURCE, sortfield=sortfield, sortorder=sortorder,\n'
            f'                             limit=limit, page=page, sqlfilters=sqlfilters)\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_get(self, func: str, resource: str, ep: Dict) -> str:
        """Generate get command."""
        cmd_func = f'get_{self._singularize(func)}'
        return (
            f'@{func}.command(\'get\')\n'
            f'@click.argument(\'id\', type=int)\n'
            f'@click.pass_context\n'
            f'def {cmd_func}(ctx, id):\n'
            f'    """Get {resource} by ID."""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        result = client.get(RESOURCE, resource_id=id)\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_create(
        self, func: str, resource: str, ep: Dict, models: Dict
    ) -> str:
        """Generate create command."""
        cmd_func = f'create_{self._singularize(func)}'

        model_fields = self._get_model_fields(ep, models)

        opts_lines = ["@click.option('--data', default=None, help='JSON string with all fields')"]
        payload_lines = []
        for field_name, field_type in model_fields:
            click_type = self._swagger_type_to_click(field_type)
            opts_lines.append(
                f"@click.option('--{field_name}', default=None, "
                f"{f'type={click_type}, ' if click_type else ''}help='{field_name}')"
            )
            payload_lines.append(
                f"            if {field_name} is not None:\n"
                f"                payload['{field_name}'] = {field_name}"
            )

        opts = '\n'.join(opts_lines)
        payload = '\n'.join(payload_lines)
        params = ', '.join(f[0] for f in model_fields)
        sig = f'def {cmd_func}(ctx, data, {params})' if params else f'def {cmd_func}(ctx, data)'

        return (
            f'@{func}.command(\'create\')\n'
            f'{opts}\n'
            f'@click.pass_context\n'
            f'{sig}:\n'
            f'    """Create {resource}."""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        if data:\n'
            f'            payload = json.loads(data)\n'
            f'        else:\n'
            f'            payload = {{}}\n'
            f'{payload}\n'
            f'        result = client.post(RESOURCE, data=payload)\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_update(self, func: str, resource: str, ep: Dict) -> str:
        """Generate update command."""
        cmd_func = f'update_{self._singularize(func)}'
        return (
            f'@{func}.command(\'update\')\n'
            f'@click.argument(\'id\', type=int)\n'
            f'@click.option(\'--data\', default=None, help=\'JSON string with all fields\')\n'
            f'@click.option(\'--set\', \'set_fields\', multiple=True, help=\'Key=value pairs\')\n'
            f'@click.pass_context\n'
            f'def {cmd_func}(ctx, id, data, set_fields):\n'
            f'    """Update {resource}."""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        if data:\n'
            f'            payload = json.loads(data)\n'
            f'        else:\n'
            f'            existing = client.get(RESOURCE, resource_id=id)\n'
            f'            payload = existing if isinstance(existing, dict) else {{}}\n'
            f'            for sf in set_fields:\n'
            f'                if \'=\' in sf:\n'
            f'                    k, v = sf.split(\'=\', 1)\n'
            f'                    payload[k] = v\n'
            f'        result = client.put(RESOURCE, resource_id=id, data=payload)\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_delete(self, func: str, resource: str, ep: Dict) -> str:
        """Generate delete command."""
        cmd_func = f'delete_{self._singularize(func)}'
        return (
            f'@{func}.command(\'delete\')\n'
            f'@click.argument(\'id\', type=int)\n'
            f'@click.pass_context\n'
            f'def {cmd_func}(ctx, id):\n'
            f'    """Delete {resource}."""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        result = client.delete(RESOURCE, resource_id=id)\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_action(
        self, func: str, resource: str, action: str, ep: Dict
    ) -> str:
        """Generate a special action command (validate, close, etc.)."""
        cmd_func = f'{action}_{func}'
        return (
            f'@{func}.command(\'{action}\')\n'
            f'@click.argument(\'id\', type=int)\n'
            f'@click.pass_context\n'
            f'def {cmd_func}(ctx, id):\n'
            f'    """{ep.get("summary", f"{action} {resource}").replace("🔐", "").strip()}"""\n'
            f'    client = _get_client(ctx)\n'
            f'    formatter = _get_formatter(ctx)\n'
            f'    try:\n'
            f'        result = client.post(RESOURCE, resource_id=id, action=\'{action}\')\n'
            f'        formatter.output(result)\n'
            f'    except DolibarrAPIError as e:\n'
            f'        click.echo(f"Error: {{e.message}}", err=True)\n'
            f'        sys.exit(1)\n'
            f'\n\n'
        )

    def _gen_sub_resource(
        self,
        parent_func: str,
        parent_resource: str,
        sub_name: str,
        sub_eps: List[Dict],
        models: Dict,
    ) -> str:
        """Generate a sub-command group for a sub-resource."""
        lines: List[str] = []

        lines.append(f'@{parent_func}.group()')
        lines.append(f'def {sub_name}():')
        lines.append(f'    """Manage {sub_name} for {parent_resource}."""')
        lines.append('    pass')
        lines.append('')
        lines.append('')

        sub_crud: Dict[str, Dict] = {}
        for ep in sub_eps:
            method = ep['method']
            path = ep['path']
            has_sub_id = '{lineid}' in path or '{line_id}' in path or '{subid}' in path
            if method == 'GET' and not has_sub_id:
                sub_crud['list'] = ep
            elif method == 'GET':
                sub_crud['get'] = ep
            elif method == 'POST':
                sub_crud['create'] = ep
            elif method == 'PUT':
                sub_crud['update'] = ep
            elif method == 'DELETE':
                sub_crud['delete'] = ep

        if 'list' in sub_crud:
            lines.append(f'@{sub_name}.command(\'list\')')
            lines.append('@click.argument(\'parent_id\', type=int)')
            lines.append('@click.pass_context')
            lines.append(f'def list_{sub_name}(ctx, parent_id):')
            lines.append(f'    """List {sub_name}."""')
            lines.append('    client = _get_client(ctx)')
            lines.append('    formatter = _get_formatter(ctx)')
            lines.append('    try:')
            lines.append(
                f"        result = client.get(RESOURCE, resource_id=parent_id, "
                f"sub_resource='{sub_name}')"
            )
            lines.append('        formatter.output(result)')
            lines.append('    except DolibarrAPIError as e:')
            lines.append('        click.echo(f"Error: {e.message}", err=True)')
            lines.append('        sys.exit(1)')
            lines.append('')
            lines.append('')

        if 'create' in sub_crud:
            lines.append(f'@{sub_name}.command(\'create\')')
            lines.append('@click.argument(\'parent_id\', type=int)')
            lines.append("@click.option('--data', default=None, help='JSON string')")
            lines.append('@click.pass_context')
            lines.append(f'def create_{sub_name}(ctx, parent_id, data):')
            lines.append(f'    """Create {sub_name}."""')
            lines.append('    client = _get_client(ctx)')
            lines.append('    formatter = _get_formatter(ctx)')
            lines.append('    try:')
            lines.append('        payload = json.loads(data) if data else {}')
            lines.append(
                f"        result = client.post(RESOURCE, resource_id=parent_id, "
                f"sub_resource='{sub_name}', data=payload)"
            )
            lines.append('        formatter.output(result)')
            lines.append('    except DolibarrAPIError as e:')
            lines.append('        click.echo(f"Error: {e.message}", err=True)')
            lines.append('        sys.exit(1)')
            lines.append('')
            lines.append('')

        if 'update' in sub_crud:
            lines.append(f'@{sub_name}.command(\'update\')')
            lines.append('@click.argument(\'parent_id\', type=int)')
            lines.append('@click.argument(\'sub_id\', type=int)')
            lines.append("@click.option('--data', default=None, help='JSON string')")
            lines.append("@click.option('--set', 'set_fields', multiple=True, help='Key=value pairs')")
            lines.append('@click.pass_context')
            lines.append(f'def update_{sub_name}(ctx, parent_id, sub_id, data, set_fields):')
            lines.append(f'    """Update {sub_name}."""')
            lines.append('    client = _get_client(ctx)')
            lines.append('    formatter = _get_formatter(ctx)')
            lines.append('    try:')
            lines.append('        if data:')
            lines.append('            payload = json.loads(data)')
            lines.append('        else:')
            lines.append(f"            existing = client.get(RESOURCE, resource_id=parent_id, sub_resource='{sub_name}')")
            lines.append('            payload = {}')
            lines.append('            if isinstance(existing, list):')
            lines.append("                for item in existing:")
            lines.append("                    if str(item.get('id', '')) == str(sub_id) or str(item.get('rowid', '')) == str(sub_id):")
            lines.append('                        payload = item')
            lines.append('                        break')
            lines.append('            for sf in set_fields:')
            lines.append("                if '=' in sf:")
            lines.append("                    k, v = sf.split('=', 1)")
            lines.append("                    payload[k] = v")
            lines.append(
                f"        result = client.put(RESOURCE, resource_id=parent_id, "
                f"sub_resource='{sub_name}', sub_id=sub_id, data=payload)"
            )
            lines.append('        formatter.output(result)')
            lines.append('    except DolibarrAPIError as e:')
            lines.append('        click.echo(f"Error: {e.message}", err=True)')
            lines.append('        sys.exit(1)')
            lines.append('')
            lines.append('')

        if 'delete' in sub_crud:
            lines.append(f'@{sub_name}.command(\'delete\')')
            lines.append('@click.argument(\'parent_id\', type=int)')
            lines.append('@click.argument(\'sub_id\', type=int)')
            lines.append('@click.pass_context')
            lines.append(f'def delete_{sub_name}(ctx, parent_id, sub_id):')
            lines.append(f'    """Delete {sub_name}."""')
            lines.append('    client = _get_client(ctx)')
            lines.append('    formatter = _get_formatter(ctx)')
            lines.append('    try:')
            lines.append(
                f"        result = client.delete(RESOURCE, resource_id=parent_id, "
                f"sub_resource='{sub_name}', sub_id=sub_id)"
            )
            lines.append('        formatter.output(result)')
            lines.append('    except DolibarrAPIError as e:')
            lines.append('        click.echo(f"Error: {e.message}", err=True)')
            lines.append('        sys.exit(1)')
            lines.append('')
            lines.append('')

        return '\n'.join(lines)

    # ── Model Field Extraction ────────────────────────────────────

    def _get_model_fields(
        self, ep: Dict, models: Dict
    ) -> List[Tuple[str, str]]:
        """Extract (name, type) pairs from the request body model.

        Returns up to 8 fields to keep create commands manageable.
        """
        body_ref = ep.get('request_body')
        if not body_ref or body_ref not in models:
            return []
        props = models[body_ref].get('properties', {})
        fields = []
        for name, info in list(props.items())[:8]:
            if name in ('request_data', 'id', 'rowid', 'tms', 'date_creation',
                        'date_modification', 'import_key'):
                continue
            fields.append((name, info.get('type', 'string')))
        return fields

    # ── Utility Methods ───────────────────────────────────────────

    @staticmethod
    def _singularize(func: str) -> str:
        """Convert plural resource name to singular for function naming."""
        if func.endswith('ies'):
            return func[:-3] + 'y'
        elif func.endswith('ses'):
            return func[:-2]
        elif func.endswith('s'):
            return func[:-1]
        return func

    @staticmethod
    def _swagger_type_to_click(swagger_type: str) -> str:
        """Convert swagger type string to click type string."""
        return TYPE_MAP.get(swagger_type, '')

    @staticmethod
    def _group_summary(endpoints: List[Dict]) -> str:
        """Extract a short description for the group."""
        for ep in endpoints:
            s = ep.get('summary', '')
            if s:
                # Clean up emoji and trailing punctuation
                s = s.replace('🔐', '').strip()
                # Use first endpoint summary as group doc
                return s.rstrip('.')
        return 'API resource'

    @staticmethod
    def _write_file(filename: str, content: str) -> bool:
        """Write generated file. Returns False if file already exists."""
        filepath = COMMANDS_DIR / filename
        if filepath.exists():
            return False
        COMMANDS_DIR.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding='utf-8')
        return True

    @staticmethod
    def _truncate(content: str, max_lines: int) -> str:
        """Truncate content to max_lines, keeping valid Python structure."""
        lines = content.splitlines()[:max_lines]
        return '\n'.join(lines) + '\n'
