"""
SchemaManager: Core class for Dolibarr API schema operations.

Manages the lifecycle of API schema data: fetching from the Dolibarr
Swagger endpoint, normalizing to a canonical format, persisting to disk,
and providing data to CLI commands for diff, generation, and export.

Schema file location: cli_dolibarr/dolibarr/schema.json
"""

import csv
import io
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

COMMANDS_DIR = Path(__file__).parent.parent / 'commands'


class SchemaManager:
    """Manages Dolibarr API schema discovery and code generation."""

    SCHEMA_PATH = Path(__file__).parent.parent / 'schema.json'
    SUPPLEMENT_PATH = Path(__file__).parent.parent / 'models_supplement.json'
    EXTRAFIELDS_CACHE_PATH = Path(__file__).parent.parent / 'extrafields_cache.json'

    _DIFF_ALIASES: Dict[str, str] = {
        'warehouses': 'stock', 'stockmovements': 'stock',
        'tasks': 'projects', 'status': 'system', 'mobilehubapi': 'mobilehub',
    }

    _ELEMENTTYPE_TO_MODELS: Dict[str, List[str]] = {
        'product': ['createProductsModel', 'updateProductsModel'],
        'societe': ['createThirdpartiesModel', 'updateThirdpartiesModel'],
        'socpeople': ['createContactsModel', 'updateContactsModel'],
        'facture': ['createInvoicesModel', 'updateInvoicesModel'],
        'facturedet': ['invoicesCreateLineModel', 'invoicesUpdateLineModel'],
        'commande': ['createOrdersModel', 'updateOrdersModel'],
        'commandedet': ['ordersCreateLineModel', 'ordersUpdateLineModel'],
        'propal': ['createProposalsModel', 'updateProposalsModel'],
        'propaldet': ['proposalsCreateLineModel', 'proposalsUpdateLineModel'],
        'expedition': ['createShipmentsModel', 'updateShipmentsModel'],
        'commande_fournisseur': ['createSupplierordersModel', 'updateSupplierordersModel'],
        'facture_fourn': ['createSupplierinvoicesModel', 'updateSupplierinvoicesModel'],
        'entrepot': ['createWarehousesModel', 'updateWarehousesModel'],
        'mrp_mo': ['createMosModel', 'updateMosModel'],
        'bank_account': ['createBankaccountsModel', 'updateBankaccountsModel'],
        'user': ['createUsersModel', 'updateUsersModel'],
    }

    _TYPE_MAP: Dict[str, str] = {
        'varchar': 'string', 'text': 'string', 'html': 'string',
        'int': 'integer', 'integer': 'integer', 'double': 'number',
        'price': 'number', 'pricecy': 'number',
        'date': 'string', 'datetime': 'string', 'duration': 'integer',
        'boolean': 'integer', 'phone': 'string', 'email': 'string',
        'url': 'string', 'ip': 'string', 'icon': 'string',
        'password': 'string', 'select': 'string', 'sellist': 'string',
        'radio': 'string', 'checkbox': 'string', 'chkbxlst': 'string',
        'separate': 'string',
    }

    def __init__(self):
        self.data: Optional[Dict[str, Any]] = None

    def load(self) -> Optional[Dict[str, Any]]:
        """Load schema.json from disk, or None if missing."""
        if not self.SCHEMA_PATH.exists():
            return None
        with open(self.SCHEMA_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)

    def save(self, data: Dict[str, Any]) -> None:
        self.SCHEMA_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(self.SCHEMA_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        self.data = data

    def enrich(self) -> Dict[str, int]:
        """Enrich schema.json models using models_supplement.json.

        For each model in supplement:
        - If schema.json model has ONLY 'request_data' as property → replace with supplement
        - If schema.json model already has proper fields → skip (don't overwrite)

        Returns dict with stats: {'enriched': N, 'skipped_bad': N, 'skipped_good': N}
        """
        schema = self.load()
        if schema is None:
            raise FileNotFoundError("schema.json not found. Run 'schema sync' first.")

        supplement = self._load_supplement()

        enriched = 0
        skipped_bad = 0
        skipped_good = 0

        models = schema.get('models', {})

        for model_name, model_def in models.items():
            props = model_def.get('properties', {})
            prop_names = set(props.keys())
            substantive = prop_names - {'request_data', 'dummy', 'array_options'}
            is_bad = not substantive

            if model_name in supplement:
                if is_bad:
                    models[model_name] = supplement[model_name]
                    enriched += 1
                else:
                    skipped_good += 1
            elif is_bad:
                skipped_bad += 1

        self.save(schema)
        return {'enriched': enriched, 'skipped_bad': skipped_bad, 'skipped_good': skipped_good}

    def _load_supplement(self) -> Dict[str, Any]:
        if not self.SUPPLEMENT_PATH.exists():
            return {}
        with open(self.SUPPLEMENT_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)

    def fetch_extrafields(self, client) -> Dict[str, Any]:
        """Fetch extrafield definitions from Dolibarr /setup/extrafields API.

        Requires an admin API key. Saves the raw response to
        extrafields_cache.json and returns the data dict.
        """
        base = client.base_url.rstrip('/')
        url = base + '/setup/extrafields'
        response = client.session.get(url, params={'sortfield': 'elementtype', 'sortorder': 'ASC'})
        if response.status_code == 403:
            raise RuntimeError(
                "403 Forbidden: extrafields API requires admin API key. "
                "Use --admin-api-key option or configure an admin key."
            )
        if response.status_code != 200:
            raise RuntimeError(
                f"Failed to fetch extrafields: HTTP {response.status_code} from {url}"
            )
        data = response.json()
        if isinstance(data, list):
            grouped: Dict[str, Any] = {}
            for item in data:
                et = item.get('elementtype', 'unknown')
                fname = item.get('name', item.get('attrname', ''))
                grouped.setdefault(et, {})[fname] = item
            data = grouped
        with open(self.EXTRAFIELDS_CACHE_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return data

    def inject_extrafields(self, extrafields_data: Dict[str, Any]) -> Dict[str, int]:
        """Inject extrafield definitions into schema.json models.

        For each elementtype in _ELEMENTTYPE_TO_MODELS, builds an array_options
        property and injects it into the corresponding create/update models.
        """
        schema = self.load()
        if schema is None:
            raise FileNotFoundError("schema.json not found. Run 'schema sync' first.")

        models = schema.get('models', {})
        injected_models = 0
        injected_fields = 0
        elementtypes = 0

        for elementtype, model_names in self._ELEMENTTYPE_TO_MODELS.items():
            ef_defs = extrafields_data.get(elementtype, {})
            if not ef_defs:
                continue
            elementtypes += 1

            options_props: Dict[str, Any] = {}
            for fname, fdef in ef_defs.items():
                ef_type = fdef.get('type', 'varchar')
                label = fdef.get('label', fname)
                json_type = self._TYPE_MAP.get(ef_type, 'string')
                options_props[fname] = {
                    'type': json_type,
                    'description': f'{label} (extrafield: {ef_type})',
                }
                injected_fields += 1

            array_options_prop = {
                'type': 'object',
                'description': f'自定义字段 (extrafields for {elementtype})',
                'properties': options_props,
            }

            for model_name in model_names:
                if model_name in models:
                    models[model_name].setdefault('properties', {})
                    models[model_name]['properties']['array_options'] = array_options_prop
                    injected_models += 1

        self.save(schema)
        return {
            'injected_models': injected_models,
            'injected_fields': injected_fields,
            'elementtypes': elementtypes,
        }

    def refresh(self, client) -> Dict[str, Any]:
        """Full schema refresh: sync + extrafields + enrich.

        One-command pipeline that:
        1. Syncs API schema from Dolibarr swagger
        2. Fetches extrafield definitions (best-effort, skips if no admin key)
        3. Enriches models with supplement definitions
        """
        # Step 1: sync
        swagger = self.fetch_swagger(client)
        schema = self.normalize(swagger)
        self.save(schema)

        # Step 2: extrafields (best-effort)
        ef_stats = {'injected_models': 0, 'injected_fields': 0, 'elementtypes': 0}
        try:
            ef_data = self.fetch_extrafields(client)
            ef_stats = self.inject_extrafields(ef_data)
        except RuntimeError:
            pass

        # Step 3: enrich
        enrich_stats = self.enrich()

        return {
            'endpoints': len(schema['endpoints']),
            'models': len(schema['models']),
            'extrafields': ef_stats,
            'enrich': enrich_stats,
        }

    def fetch_swagger(self, client) -> Dict[str, Any]:
        """Fetch swagger.json from Dolibarr explorer endpoint."""
        base = client.base_url.rstrip('/')
        url = base + '/explorer/swagger.json'
        response = client.session.get(url)
        if response.status_code != 200:
            raise RuntimeError(
                f"Failed to fetch swagger.json: HTTP {response.status_code} from {url}")
        return response.json()

    def normalize(self, swagger: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize Swagger 2.0 spec to canonical schema format."""
        version = swagger.get('info', {}).get('version', 'unknown')
        paths, definitions = swagger.get('paths', {}), swagger.get('definitions', {})
        endpoints: List[Dict[str, Any]] = []
        for path, methods in paths.items():
            for mu, spec in methods.items():
                if mu.upper() not in ('GET', 'POST', 'PUT', 'DELETE', 'PATCH'):
                    continue
                endpoints.append({
                    'path': path, 'method': mu.upper(),
                    'summary': spec.get('summary', ''),
                    'group': self._extract_group(path),
                    'parameters': self._extract_parameters(spec),
                    'request_body': self._extract_request_body(spec),
                    'response_schema': self._extract_response_schema(spec),
                })
        models = {name: {'properties': {
            k: {'type': v.get('type', 'string'), 'description': v.get('description', '')}
            for k, v in md.get('properties', {}).items()}}
            for name, md in definitions.items()}
        return {
            'synced_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'source': 'swagger', 'dolibarr_version': version,
            'endpoints': endpoints, 'models': models,
            'cli_coverage': self.scan_cli_coverage(),
        }

    def scan_cli_coverage(self) -> Dict[str, Dict[str, Any]]:
        coverage: Dict[str, Dict[str, Any]] = {}
        if not COMMANDS_DIR.exists():
            return coverage
        for fpath in sorted(COMMANDS_DIR.iterdir()):
            if fpath.is_file() and fpath.suffix == '.py' and not fpath.stem.startswith('_'):
                group = fpath.stem.replace('_', '-')
                coverage[group] = {'file': fpath.name, 'covered': True}
        return coverage

    def diff(self, group_filter: Optional[str] = None) -> Dict[str, Any]:
        """Compare API schema against current CLI commands."""
        data = self.load()
        if data is None:
            raise FileNotFoundError("schema.json not found. Run 'schema sync' first.")
        swagger_groups = sorted({ep['group'] for ep in data.get('endpoints', [])})
        cli_groups = sorted(data.get('cli_coverage', {}).keys())
        cli_norm = {cg.replace('-', '').replace('_', '').lower(): cg for cg in cli_groups}
        covered, uncovered, match_map = [], [], {}
        for sg in swagger_groups:
            matched = self._match_swagger_to_cli(sg, cli_norm)
            match_map[sg] = matched
            (covered if matched else uncovered).append(sg)
        matched_cli = {v for v in match_map.values() if v is not None}
        extra_cli = [cg for cg in cli_groups if cg not in matched_cli]
        total_sw = len(swagger_groups)
        result = {
            'covered': covered, 'uncovered': uncovered, 'extra_cli': extra_cli,
            'total_swagger_groups': total_sw, 'total_cli_groups': len(cli_groups),
            'coverage_pct': round(len(covered) / total_sw * 100, 1) if total_sw else 0.0,
            'match_map': match_map,
        }
        if group_filter:
            gf = group_filter.lower()
            result['covered'] = [g for g in covered if gf in g or gf in (match_map.get(g) or '')]
            result['uncovered'] = [g for g in uncovered if gf in g]
            result['extra_cli'] = [g for g in extra_cli if gf in g]
        return result

    @classmethod
    def _match_swagger_to_cli(cls, sg: str, cli_norm: Dict[str, str]) -> Optional[str]:
        if sg in cli_norm:
            return sg
        alias = cls._DIFF_ALIASES.get(sg)
        if alias:
            if alias in cli_norm:
                return cli_norm[alias]
            alias_n = alias.replace('-', '').replace('_', '').lower()
            if alias_n in cli_norm:
                return cli_norm[alias_n]
        return cli_norm.get(sg.replace('-', '').replace('_', '').lower())

    # ── Export (T6) ───────────────────────────────────────────────

    def export_data(self, fmt: str = 'jsonl') -> str:
        schema = self.load()
        if not schema:
            raise FileNotFoundError(
                "No schema found. Run 'schema sync' first."
            )
        if fmt == 'jsonl':
            return self._export_jsonl(schema)
        elif fmt == 'csv':
            return self._export_csv(schema)
        elif fmt == 'conversations':
            return self._export_conversations(schema)
        raise ValueError(f"Unknown format: {fmt}")

    def _export_jsonl(self, schema: Dict[str, Any]) -> str:
        lines: List[str] = []
        for ep in schema.get('endpoints', []):
            params = [p['name'] for p in ep.get('parameters', [])
                      if p.get('in') != 'path']
            lines.append(json.dumps({
                'endpoint': ep['path'],
                'method': ep['method'],
                'summary': ep.get('summary', ''),
                'group': ep.get('group', ''),
                'cli_command': self._endpoint_to_cli(ep),
                'parameters': params,
            }, ensure_ascii=False))
        return '\n'.join(lines)

    def _export_csv(self, schema: Dict[str, Any]) -> str:
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(['group', 'method', 'endpoint', 'summary',
                         'cli_command', 'parameters'])
        for ep in schema.get('endpoints', []):
            params = ','.join(
                p['name'] for p in ep.get('parameters', [])
                if p.get('in') != 'path'
            )
            writer.writerow([
                ep.get('group', ''), ep['method'], ep['path'],
                ep.get('summary', ''), self._endpoint_to_cli(ep), params,
            ])
        return buf.getvalue()

    def _export_conversations(self, schema: Dict[str, Any]) -> str:
        pairs: List[str] = []
        for ep in schema.get('endpoints', []):
            group, method = ep.get('group', ''), ep['method']
            summary, path = ep.get('summary', ''), ep['path']
            cli = self._endpoint_to_cli(ep)
            param_names = [p['name'] for p in ep.get('parameters', [])
                           if p.get('in') != 'path']
            jd = lambda d: json.dumps(d, ensure_ascii=False)

            pairs.append(jd({'instruction': summary.strip() or f"{method} {path}",
                             'response': cli}))

            if method == 'GET' and '{id}' not in path:
                resp = cli + (' ' + ' '.join(f'[--{n} VALUE]' for n in param_names[:4])
                              if param_names else '')
                pairs.append(jd({'instruction': f"How do I list all {group}?", 'response': resp}))
            elif method == 'GET':
                pairs.append(jd({'instruction': f"Get details for a specific {group} entry",
                                 'response': f"{cli} ID"}))
            elif method == 'POST':
                pairs.append(jd({'instruction': f"Create a new {group} entry", 'response': cli}))
            elif method in ('PUT', 'PATCH'):
                pairs.append(jd({'instruction': f"Update an existing {group} entry",
                                 'response': f"{cli} ID [FIELDS...]"}))
            elif method == 'DELETE':
                pairs.append(jd({'instruction': f"Delete a {group} entry", 'response': f"{cli} ID"}))
        return '\n'.join(pairs)

    @staticmethod
    def _endpoint_to_cli(ep: Dict[str, Any]) -> str:
        group = ep.get('group', 'unknown')
        method = ep['method']
        path = ep['path']
        if method == 'GET':
            action = 'get' if '{id}' in path else 'list'
        elif method == 'POST':
            action = 'create'
        elif method in ('PUT', 'PATCH'):
            action = 'update'
        elif method == 'DELETE':
            action = 'delete'
        else:
            action = 'call'
        return f"cli-dolibarr {group} {action}"

    # ── Private helpers ───────────────────────────────────────────

    @staticmethod
    def _extract_group(path: str) -> str:
        parts = path.strip('/').split('/')
        for part in parts:
            if part in ('api', 'index.php'):
                continue
            if part.startswith('{'):
                continue
            return part
        return 'unknown'

    @staticmethod
    def _extract_parameters(spec: Dict[str, Any]) -> List[Dict[str, Any]]:
        params: List[Dict[str, Any]] = []
        for p in spec.get('parameters', []):
            if p.get('in') == 'body':
                continue
            params.append({
                'name': p.get('name', ''), 'in': p.get('in', 'query'),
                'type': p.get('type', 'string'), 'required': p.get('required', False),
            })
        return params

    @staticmethod
    def _extract_request_body(spec: Dict[str, Any]) -> Optional[str]:
        for p in spec.get('parameters', []):
            if p.get('in') == 'body':
                ref = p.get('schema', {}).get('$ref', '')
                if ref:
                    return ref.rsplit('/', 1)[-1]
        return None

    @staticmethod
    def _extract_response_schema(spec: Dict[str, Any]) -> Optional[str]:
        schema = spec.get('responses', {}).get('200', {}).get('schema', {})
        if not schema:
            return None
        ref = schema.get('$ref', '')
        return ref.rsplit('/', 1)[-1] if ref else schema.get('type')
