import json
import os
from pathlib import Path
from typing import Optional


DEFAULT_CONFIG_DIR = Path.home() / '.config' / 'cli-dolibarr'
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / 'config.json'


class DolibarrConfig:
    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or DEFAULT_CONFIG_FILE
        self.base_url: str = ''
        self.api_key: str = ''
        self.verify_ssl: bool = False
        self.default_limit: int = 100
        self.output_format: str = 'table'
        self.default_sortfield: str = 't.rowid'
        self.default_sortorder: str = 'ASC'

    def save(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'base_url': self.base_url,
            'api_key': self.api_key,
            'verify_ssl': self.verify_ssl,
            'default_limit': self.default_limit,
            'output_format': self.output_format,
            'default_sortfield': self.default_sortfield,
            'default_sortorder': self.default_sortorder,
        }
        self.config_path.write_text(json.dumps(data, indent=2))

    def load(self) -> bool:
        if not self.config_path.exists():
            return False
        try:
            data = json.loads(self.config_path.read_text())
            self.base_url = data.get('base_url', '')
            self.api_key = data.get('api_key', '')
            self.verify_ssl = data.get('verify_ssl', False)
            self.default_limit = data.get('default_limit', 100)
            self.output_format = data.get('output_format', 'table')
            self.default_sortfield = data.get('default_sortfield', 't.rowid')
            self.default_sortorder = data.get('default_sortorder', 'ASC')
            return True
        except (json.JSONDecodeError, KeyError):
            return False

    @classmethod
    def from_env(cls) -> 'DolibarrConfig':
        config = cls()
        config.base_url = os.environ.get('DOLIBARR_URL', '')
        config.api_key = os.environ.get('DOLIBARR_API_KEY', '')
        if os.environ.get('DOLIBARR_VERIFY_SSL', '').lower() in ('1', 'true'):
            config.verify_ssl = True
        return config

    def is_configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    def resolve(self) -> None:
        if not self.is_configured():
            env_config = self.from_env()
            if env_config.is_configured():
                self.base_url = env_config.base_url
                self.api_key = env_config.api_key
            else:
                self.load()
