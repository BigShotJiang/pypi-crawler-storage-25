import requests
import urllib3
from typing import Any, Dict, List, Optional, Union

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class DolibarrAPIError(Exception):
    def __init__(self, message: str, status_code: int = 0, response: Any = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(f"HTTP {status_code}: {message}")


class DolibarrClient:
    def __init__(self, base_url: str, api_key: str, verify_ssl: bool = False):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.headers.update({
            'DOLAPIKEY': self.api_key,
            'Content-Type': 'application/json',
        })
        self.session.verify = self.verify_ssl

    def _url(self, resource: str, resource_id: Optional[Union[int, str]] = None,
             action: Optional[str] = None, sub_resource: Optional[str] = None) -> str:
        parts = [self.base_url, resource]
        if resource_id is not None:
            parts.append(str(resource_id))
        if sub_resource is not None:
            parts.append(sub_resource)
        if action is not None:
            parts.append(action)
        return '/'.join(parts)

    def _handle_response(self, response: requests.Response) -> Any:
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get('error', str(error_data))
            except (ValueError, AttributeError):
                message = response.text[:500]
            raise DolibarrAPIError(message, response.status_code, response)
        content_type = response.headers.get('content-type', '')
        if 'application/json' in content_type:
            try:
                return response.json()
            except ValueError:
                return response.text.strip()
        return response.text.strip()

    def get(self, resource: str, resource_id: Optional[Union[int, str]] = None,
            **params) -> Any:
        url = self._url(resource, resource_id)
        response = self.session.get(url, params=params)
        return self._handle_response(response)

    def post(self, resource: str, data: Optional[Dict] = None,
             resource_id: Optional[Union[int, str]] = None,
             action: Optional[str] = None, sub_resource: Optional[str] = None) -> Any:
        url = self._url(resource, resource_id, action, sub_resource)
        response = self.session.post(url, json=data)
        return self._handle_response(response)

    def put(self, resource: str, resource_id: Union[int, str],
            data: Optional[Dict] = None,
            sub_resource: Optional[str] = None,
            sub_id: Optional[Union[int, str]] = None) -> Any:
        url = self._url(resource, resource_id, sub_resource=sub_resource)
        if sub_id is not None:
            url = f"{url}/{sub_id}"
        response = self.session.put(url, json=data)
        return self._handle_response(response)

    def delete(self, resource: str, resource_id: Union[int, str],
               sub_resource: Optional[str] = None,
               sub_id: Optional[Union[int, str]] = None) -> Any:
        url = self._url(resource, resource_id, sub_resource=sub_resource)
        if sub_id is not None:
            url = f"{url}/{sub_id}"
        response = self.session.delete(url)
        return self._handle_response(response)

    def list(self, resource: str, sortfield: str = 't.rowid', sortorder: str = 'ASC',
             limit: int = 100, page: int = 0, sqlfilters: Optional[str] = None,
             properties: Optional[str] = None, pagination_data: bool = False,
             **extra_params) -> Any:
        params = {
            'sortfield': sortfield,
            'sortorder': sortorder,
            'limit': limit,
            'page': page,
        }
        if sqlfilters:
            params['sqlfilters'] = sqlfilters
        if properties:
            params['properties'] = properties
        if pagination_data:
            params['pagination_data'] = 'true'
        params.update(extra_params)
        return self.get(resource, **params)

    def test_connection(self) -> bool:
        try:
            result = self.get('status')
            return bool(result)
        except DolibarrAPIError:
            return False
