import csv
import json
import sys
from typing import Any, Dict, List, Optional


class OutputFormatter:
    def __init__(self, fmt: str = 'table'):
        self.fmt = fmt

    def output(self, data: Any, columns: Optional[List[str]] = None,
               title: Optional[str] = None) -> None:
        if self.fmt == 'json':
            self._print_json(data)
        elif self.fmt == 'csv':
            self._print_csv(data, columns)
        else:
            self._print_table(data, columns, title)

    def _print_json(self, data: Any) -> None:
        print(json.dumps(data, indent=2, ensure_ascii=False, default=str))

    def _print_table(self, data: Any, columns: Optional[List[str]] = None,
                     title: Optional[str] = None) -> None:
        if title:
            print(f"\n{title}")
            print("=" * len(title))

        if isinstance(data, dict) and 'error' in data:
            print(f"Error: {data['error']}")
            return

        if isinstance(data, dict) and 'success' in data:
            if isinstance(data.get('data'), list):
                items = data['data']
                if columns:
                    self._print_tabular(items, columns)
                else:
                    self._print_tabular(items, self._auto_columns(items))
                return
            elif isinstance(data.get('data'), dict):
                data = data['data']

        if isinstance(data, dict):
            self._print_kv(data)
        elif isinstance(data, list):
            if not data:
                print("(no results)")
                return
            if columns:
                self._print_tabular(data, columns)
            else:
                self._print_tabular(data, self._auto_columns(data))
        elif isinstance(data, (int, float, str)):
            print(data)
        else:
            print(json.dumps(data, indent=2, ensure_ascii=False, default=str))

    def _print_kv(self, d: Dict, indent: int = 0) -> None:
        prefix = "  " * indent
        for key, value in d.items():
            if isinstance(value, dict):
                print(f"{prefix}{key}:")
                self._print_kv(value, indent + 1)
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                print(f"{prefix}{key}: [{len(value)} items]")
            else:
                print(f"{prefix}{key}: {value}")

    def _print_tabular(self, items: List[Dict], columns: List[str]) -> None:
        filtered = [col for col in columns if col in items[0] if items]
        if not filtered:
            filtered = self._auto_columns(items)
        widths = {}
        for col in filtered:
            widths[col] = max(len(str(col)),
                              max((len(str(self._truncate(item.get(col, '')))) for item in items), default=0))
        header = " | ".join(str(col).ljust(widths[col]) for col in filtered)
        print(header)
        print("-+-".join("-" * widths[col] for col in filtered))
        for item in items:
            row = " | ".join(
                str(self._truncate(item.get(col, ''))).ljust(widths[col])
                for col in filtered
            )
            print(row)
        print(f"\n({len(items)} items)")

    def _print_csv(self, data: Any, columns: Optional[List[str]] = None) -> None:
        writer = csv.writer(sys.stdout)
        if isinstance(data, list) and data:
            if not columns:
                columns = self._auto_columns(data)
            writer.writerow(columns)
            for item in data:
                writer.writerow([item.get(col, '') for col in columns])
        elif isinstance(data, dict):
            writer.writerow(['key', 'value'])
            for k, v in data.items():
                writer.writerow([k, v])
        else:
            print(data)

    def _auto_columns(self, items: List[Dict], max_columns: int = 8) -> List[str]:
        if not items:
            return []
        keys = set()
        for item in items[:5]:
            keys.update(item.keys())
        priority = [
            'id', 'rowid', 'ref', 'label', 'name', 'status', 'total_ttc', 'total_ht',
            'date_creation', 'datec', 'town', 'country', 'email', 'phone',
            'description', 'title', 'qty', 'reel', 'value', 'fk_product',
            'fk_entrepot', 'datem', 'lastname', 'firstname', 'login',
        ]
        ordered = []
        for p in priority:
            if p in keys:
                ordered.append(p)
                keys.discard(p)
        ordered.extend(sorted(keys)[:max_columns - len(ordered)])
        return ordered[:max_columns]

    @staticmethod
    def _truncate(value: Any, max_len: int = 40) -> Any:
        s = str(value)
        return s if len(s) <= max_len else s[:max_len - 3] + '...'
