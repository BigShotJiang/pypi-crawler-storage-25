"""
Analyze a Python project and export structure, call graph, and image artifacts.

Outputs:
  1. Terminal summary
  2. project_analysis.png
  3. project_call_graph.png
  4. project_hotspots.png
  5. project_analysis.json
"""

from __future__ import annotations

import argparse
import ast
import configparser
from collections import defaultdict
from dataclasses import dataclass, field
from fnmatch import fnmatch
import json
import math
import os
from pathlib import Path
import re
import sys

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - exercised on Python 3.9/3.10
    import tomli as tomllib

import matplotlib

matplotlib.use('Agg')

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import networkx as nx


SCHEMA_VERSION = '0.2'

DEFAULT_TARGET = None

SKIP_DIRS = {
    '.venv', 'venv', 'env', '__pycache__', '.git', 'node_modules',
    '.idea', '.vscode', 'dist', 'build', 'eggs', '.eggs',
    'migrations', '.pytest_cache', '.mypy_cache', '.tox',
    'analysis_output',
}

DEFAULT_RECURSIVE = True
DEFAULT_CALL_TREE_DEPTH = 4
DEFAULT_CALL_TREE_MAX_BR = 6
DEFAULT_MAX_ENTRY_TREES = 8
DEFAULT_HOTSPOT_TOP_N = 15
DEFAULT_MAX_UNRESOLVED_DISPLAY = 20
DEFAULT_MAX_FILES_WARNING = 1000

OUTPUT_PNG = 'project_analysis.png'
OUTPUT_CALLS = 'project_call_graph.png'
OUTPUT_HOTSPOTS = 'project_hotspots.png'
OUTPUT_JSON = 'project_analysis.json'
OUTPUT_WALKTHROUGH = 'walkthrough.md'
OUTPUT_EXECUTION_FLOW = 'execution_flow.json'
OUTPUT_DECISION_TREE = 'decision_tree.md'
OUTPUT_DATA_FLOW = 'data_flow.md'

EXIT_INVALID_DIR = 1
EXIT_NO_PY_FILES = 2

BUILTIN_CALLS = {
    'print', 'len', 'range', 'enumerate', 'zip', 'map', 'filter', 'sorted',
    'reversed', 'list', 'dict', 'set', 'tuple', 'frozenset', 'str', 'int',
    'float', 'bool', 'bytes', 'bytearray', 'type', 'isinstance', 'issubclass',
    'hasattr', 'getattr', 'setattr', 'delattr', 'super', 'open', 'repr',
    'format', 'round', 'abs', 'min', 'max', 'sum', 'any', 'all', 'next',
    'iter', 'vars', 'dir', 'id', 'hash', 'hex', 'oct', 'bin', 'ord', 'chr',
    'staticmethod', 'classmethod', 'property', 'object', 'callable', 'input',
    'eval', 'exec', 'compile', 'globals', 'locals', 'breakpoint',
    'Exception', 'ValueError', 'TypeError', 'KeyError', 'AttributeError',
    'RuntimeError', 'StopIteration', 'StopAsyncIteration',
    'NotImplementedError', 'IndexError', 'IOError', 'OSError',
    'FileNotFoundError', 'PermissionError', 'AssertionError',
    'ZeroDivisionError', 'ArithmeticError', 'ImportError',
    'ModuleNotFoundError',
    'extend', 'insert', 'remove', 'pop', 'clear',
    'items', 'keys', 'values', 'setdefault', 'copy',
    'join', 'split', 'rsplit', 'strip', 'lstrip', 'rstrip',
    'lower', 'upper', 'title', 'capitalize', 'replace',
    'startswith', 'endswith', 'find', 'rfind', 'index', 'count',
    'encode', 'decode', 'readline', 'readlines', 'seek', 'tell', 'flush',
    'discard', 'union', 'intersection', 'difference',
}

DICT_METHODS = {
    'get', 'set', 'items', 'keys', 'values', 'update', 'pop',
    'append', 'extend', 'insert', 'remove', 'clear', 'copy',
    'setdefault', 'discard', 'add', 'union', 'intersection',
}

ENTRY_FUNCTION_NAMES = {
    'main', 'run', 'start', 'serve', 'execute', 'handler', 'lambda_handler',
}
STRONG_ENTRY_FUNCTION_NAMES = {'main', 'run', 'start'}
FRAMEWORK_DECORATORS = {
    'route', 'get', 'post', 'put', 'patch', 'delete', 'websocket',
}
SECRET_NAME_RE = re.compile(
    r'(token|password|passwd|secret|api[_-]?key|credential|private[_-]?key|auth)',
    re.IGNORECASE,
)
SECRET_ASSIGNMENT_RE = re.compile(
    r'([A-Za-z_][A-Za-z0-9_]*(?:TOKEN|PASSWORD|PASSWD|SECRET|API_KEY|APIKEY|KEY|CREDENTIAL)[A-Za-z0-9_]*)\s*=\s*([^\s,;]+)',
    re.IGNORECASE,
)


@dataclass
class AnalysisWarning:
    code: str
    message: str
    file: str
    line: int | None = None


@dataclass
class AnalysisStats:
    files_scanned: int = 0
    files_skipped: int = 0
    syntax_error_files: int = 0
    resolved_calls: int = 0
    unresolved_calls: int = 0
    cross_module_edges: int = 0


@dataclass
class CallSite:
    name: str
    line: int


@dataclass
class DecisionInfo:
    kind: str
    condition: str
    line: int
    true_calls: list[str] = field(default_factory=list)
    false_calls: list[str] = field(default_factory=list)
    confidence: str = 'high'
    evidence: list[str] = field(default_factory=list)


@dataclass
class DataFlowInfo:
    source: str
    target: str
    value: str
    line: int
    producer: str | None = None
    consumer: str | None = None
    confidence: str = 'high'
    evidence: list[str] = field(default_factory=list)


@dataclass
class SideEffectInfo:
    kind: str
    detail: str
    line: int
    confidence: str = 'high'
    evidence: list[str] = field(default_factory=list)


@dataclass
class FrameworkInfo:
    kind: str
    name: str
    line: int
    target: str
    reason: str


@dataclass
class CallableInfo:
    name: str
    line: int
    calls: list[CallSite] = field(default_factory=list)
    docstring: str | None = None
    params: list[str] = field(default_factory=list)
    returns: list[str] = field(default_factory=list)
    decisions: list[DecisionInfo] = field(default_factory=list)
    data_flows: list[DataFlowInfo] = field(default_factory=list)
    side_effects: list[SideEffectInfo] = field(default_factory=list)
    external_calls: list[CallSite] = field(default_factory=list)


@dataclass
class ClassInfo:
    name: str
    line: int
    bases: list[str] = field(default_factory=list)
    methods: list[CallableInfo] = field(default_factory=list)


@dataclass
class ImportRecord:
    kind: str
    module: str
    level: int
    imported_name: str | None
    used_name: str
    line: int


@dataclass
class ImportBinding:
    used_name: str
    kind: str
    import_path: str
    module_key: str | None = None
    symbol_name: str | None = None


@dataclass
class ParsedModule:
    classes: list[ClassInfo]
    functions: list[CallableInfo]
    raw_imports: list[ImportRecord]
    lines: int
    main_guard_calls: list[CallSite] = field(default_factory=list)
    framework_entries: list[FrameworkInfo] = field(default_factory=list)
    warnings: list[AnalysisWarning] = field(default_factory=list)


@dataclass
class ModuleInfo:
    file: str
    filepath: str
    display_name: str
    lines: int
    classes: list[ClassInfo]
    functions: list[CallableInfo]
    ext_imports: list[str]
    local_deps: set[str] = field(default_factory=set)
    import_bindings: dict[str, ImportBinding] = field(default_factory=dict)
    main_guard_calls: list[CallSite] = field(default_factory=list)
    framework_entries: list[FrameworkInfo] = field(default_factory=list)


@dataclass
class UnresolvedCall:
    module: str
    callable: str
    call: str
    line: int
    reason: str
    likely_local: bool


@dataclass
class ResolveResult:
    target: tuple[str, str] | None
    reason: str | None = None
    likely_local: bool = False


def get_project_name(root):
    """
    Walk up the path until we find a directory name that is NOT a generic
    code-container name like 'src', 'source', 'lib', etc.
    """
    parts = Path(root).resolve().parts
    generic = {'src', 'source', 'lib', 'app', 'code', 'scripts'}
    for part in reversed(parts):
        if part.lower() not in generic:
            return part
    return parts[-1] if parts else 'project'


def _module_key_from_relpath(rel_path):
    return os.path.splitext(rel_path)[0].replace(os.sep, '.')


def _import_name_for_module(module_key):
    if module_key.endswith('.__init__'):
        return module_key[:-9]
    return module_key


def _package_name_for_module(module_key):
    import_name = _import_name_for_module(module_key)
    if module_key.endswith('.__init__'):
        return import_name
    if '.' in import_name:
        return import_name.rsplit('.', 1)[0]
    return ''


def _warning_file_for_root(filepath, root):
    try:
        return os.path.relpath(filepath, root)
    except ValueError:
        return filepath


def collect_py_files(root, recursive=True, exclude_dirs=None, include_globs=None):
    py_files = []
    skipped = 0
    script_path = Path(__file__).resolve()
    exclude = set(SKIP_DIRS)
    exclude.update(exclude_dirs or [])
    patterns = [p.replace(os.sep, '/') for p in (include_globs or [])]

    def include_file(filepath):
        rel_posix = Path(os.path.relpath(filepath, root)).as_posix()
        if patterns and not any(fnmatch(rel_posix, pattern) for pattern in patterns):
            return False
        return True

    if recursive:
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in exclude]
            for filename in filenames:
                if not filename.endswith('.py'):
                    continue
                filepath = os.path.join(dirpath, filename)
                if Path(filepath).resolve() == script_path:
                    skipped += 1
                    continue
                if not include_file(filepath):
                    skipped += 1
                    continue
                py_files.append(filepath)
    else:
        for filename in os.listdir(root):
            filepath = os.path.join(root, filename)
            if not os.path.isfile(filepath) or not filename.endswith('.py'):
                continue
            if Path(filepath).resolve() == script_path:
                skipped += 1
                continue
            if not include_file(filepath):
                skipped += 1
                continue
            py_files.append(filepath)

    return sorted(py_files), skipped


def _call_name(func_expr):
    if isinstance(func_expr, ast.Name):
        return func_expr.id

    if isinstance(func_expr, ast.Attribute):
        parts = []
        cur = func_expr
        while isinstance(cur, ast.Attribute):
            parts.append(cur.attr)
            cur = cur.value
        if isinstance(cur, ast.Name):
            root = cur.id
            parts.reverse()
            if root in {'self', 'cls'}:
                return '.'.join(parts) if parts else None
            return root + '.' + '.'.join(parts)
    return None


def _safe_unparse(node):
    try:
        return ast.unparse(node)
    except Exception:
        return type(node).__name__


def _redact_text(value):
    if value is None:
        return ''
    text = str(value)
    text = SECRET_ASSIGNMENT_RE.sub(lambda match: f"{match.group(1)}=***", text)
    if '=***' in text:
        return text
    stripped = text.strip('"\'')
    is_env_name = bool(re.match(r'^[A-Z][A-Z0-9_]*$', stripped))
    is_phrase = bool(re.search(r'\s', stripped))
    if SECRET_NAME_RE.search(stripped) and not is_env_name and not is_phrase:
        return '***'
    return text


def _is_sensitive_name(name):
    return bool(name and SECRET_NAME_RE.search(name))


def _string_constant(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return _redact_text(node.value)
    return None


def _target_names(target):
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, ast.Attribute):
        return [_safe_unparse(target)]
    if isinstance(target, (ast.Tuple, ast.List)):
        names = []
        for item in target.elts:
            names.extend(_target_names(item))
        return names
    return []


def _iter_nodes_without_nested(nodes):
    nested = (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)

    def visit(node):
        if isinstance(node, nested):
            return
        yield node
        for child in ast.iter_child_nodes(node):
            yield from visit(child)

    for item in nodes:
        yield from visit(item)


def _collect_call_names(nodes):
    calls = []
    seen = set()
    for node in _iter_nodes_without_nested(nodes):
        if isinstance(node, ast.Call):
            name = _call_name(node.func)
            if name and name not in seen:
                seen.add(name)
                calls.append(name)
    return calls


def _normalize_instance_call(name, instance_bindings):
    if not name or '.' not in name:
        return name
    head, rest = name.split('.', 1)
    if head in instance_bindings:
        return f"{instance_bindings[head]}.{rest}"
    return name


def _extract_call_sites(func_node):
    seen = set()
    call_sites = []
    instance_bindings = {}

    def add_call(name, lineno):
        if not name:
            return
        normalized = _normalize_instance_call(name, instance_bindings)
        if normalized in BUILTIN_CALLS or normalized.startswith('_'):
            return
        if normalized not in seen:
            seen.add(normalized)
            call_sites.append(CallSite(normalized, lineno))

    def constructor_name(value):
        if not isinstance(value, ast.Call):
            return None
        name = _call_name(value.func)
        if not name:
            return None
        normalized = _normalize_instance_call(name, instance_bindings)
        if normalized in BUILTIN_CALLS or normalized.startswith('_'):
            return None
        return normalized

    def update_binding(target, ctor_name):
        if isinstance(target, ast.Name):
            if ctor_name:
                instance_bindings[target.id] = ctor_name
            else:
                instance_bindings.pop(target.id, None)
            return
        if isinstance(target, (ast.Tuple, ast.List)):
            for item in target.elts:
                update_binding(item, ctor_name)

    def visit(node):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.Lambda, ast.ClassDef)):
            return

        if isinstance(node, ast.Assign):
            visit(node.value)
            ctor_name = constructor_name(node.value)
            for target in node.targets:
                update_binding(target, ctor_name)
            return

        if isinstance(node, ast.AnnAssign):
            if node.value is not None:
                visit(node.value)
                update_binding(node.target, constructor_name(node.value))
            else:
                update_binding(node.target, None)
            return

        if isinstance(node, ast.AugAssign):
            visit(node.value)
            update_binding(node.target, None)
            return

        if isinstance(node, ast.Call):
            add_call(_call_name(node.func), node.lineno)

        for child in ast.iter_child_nodes(node):
            visit(child)

    for stmt in func_node.body:
        visit(stmt)

    return call_sites


def _mode_from_open_call(node):
    if len(node.args) >= 2:
        mode = _string_constant(node.args[1])
        if mode:
            return mode
    for keyword in node.keywords:
        if keyword.arg == 'mode':
            mode = _string_constant(keyword.value)
            if mode:
                return mode
    return 'r'


def _detail_from_first_arg(node):
    if not node.args:
        return ''
    value = _string_constant(node.args[0])
    if value is not None:
        return value
    return _redact_text(_safe_unparse(node.args[0]))


def _side_effect_for_call(name, node):
    if not name:
        return None
    lower = name.lower()

    if name == 'open' or lower.endswith('.open'):
        mode = _mode_from_open_call(node)
        kind = 'file_write' if any(flag in mode for flag in ('w', 'a', '+', 'x')) else 'file_read'
        detail = _detail_from_first_arg(node) or f'mode={mode}'
        return SideEffectInfo(
            kind=kind,
            detail=_redact_text(detail),
            line=node.lineno,
            evidence=[f'calls {name}() with mode {mode!r}'],
        )

    if lower.endswith(('.read_text', '.read_bytes', '.readlines', '.readline')):
        return SideEffectInfo(
            kind='file_read',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if lower.endswith(('.write_text', '.write_bytes', '.write', '.writelines')):
        return SideEffectInfo(
            kind='file_write',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if lower.startswith(('requests.', 'httpx.', 'urllib.request.')) or 'aiohttp' in lower:
        return SideEffectInfo(
            kind='network_request',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if lower.startswith('subprocess.') or lower in {'popen', 'system'} or lower.endswith('.system'):
        return SideEffectInfo(
            kind='subprocess',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if lower.endswith(('.execute', '.executemany', '.cursor')) or lower.startswith(
        ('sqlite3.', 'psycopg2.', 'sqlalchemy.', 'pymongo.', 'redis.')
    ):
        return SideEffectInfo(
            kind='database',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if name in {'os.getenv', 'getenv'} or name.startswith('os.environ'):
        detail = _detail_from_first_arg(node) or name
        if _is_sensitive_name(detail):
            detail = f'{detail}=***'
        return SideEffectInfo(
            kind='env_var',
            detail=_redact_text(detail),
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if name == 'print' or lower.startswith('logging.') or lower.endswith(('.info', '.warning', '.error', '.debug')):
        return SideEffectInfo(
            kind='print_log',
            detail=name,
            line=node.lineno,
            evidence=[f'calls {name}()'],
        )

    if any(token in lower for token in ('notify', 'notification', 'telegram', 'email', 'smtp')):
        return SideEffectInfo(
            kind='notification',
            detail=name,
            line=node.lineno,
            confidence='medium',
            evidence=[f'call name suggests notification: {name}()'],
        )

    return None


def _env_side_effect_for_subscript(node):
    value_name = _safe_unparse(node.value)
    if value_name != 'os.environ':
        return None
    detail = _safe_unparse(node.slice)
    if isinstance(node.slice, ast.Constant):
        detail = str(node.slice.value)
    if _is_sensitive_name(detail):
        detail = f'{detail}=***'
    return SideEffectInfo(
        kind='env_var',
        detail=_redact_text(detail),
        line=getattr(node, 'lineno', 0),
        evidence=['reads os.environ[...]'],
    )


def _return_descriptions(func_node):
    returns = []
    seen = set()
    for node in _iter_nodes_without_nested(func_node.body):
        if isinstance(node, ast.Return) and node.value is not None:
            value = _redact_text(_safe_unparse(node.value))
            if value not in seen:
                seen.add(value)
                returns.append(value)
    return returns


def _extract_decisions(func_node):
    decisions = []
    for node in _iter_nodes_without_nested(func_node.body):
        if isinstance(node, ast.If):
            condition = _redact_text(_safe_unparse(node.test))
            evidence = ['AST if statement']
            if any(token in condition.lower() for token in ('arg', 'config', 'env', 'os.environ')):
                evidence.append('condition references args/config/env')
            decisions.append(
                DecisionInfo(
                    kind='if',
                    condition=condition,
                    line=node.lineno,
                    true_calls=_collect_call_names(node.body),
                    false_calls=_collect_call_names(node.orelse),
                    evidence=evidence,
                )
            )
        elif isinstance(node, ast.Try):
            handler_names = [
                _safe_unparse(handler.type) if handler.type is not None else 'Exception'
                for handler in node.handlers
            ]
            decisions.append(
                DecisionInfo(
                    kind='try',
                    condition=f"try/except handles {', '.join(handler_names) or 'exceptions'}",
                    line=node.lineno,
                    true_calls=_collect_call_names(node.body),
                    false_calls=[
                        call
                        for handler in node.handlers
                        for call in _collect_call_names(handler.body)
                    ],
                    evidence=['AST try/except statement'],
                )
            )
    return decisions


def _extract_data_flows(func_node):
    flows = []
    producers = {}
    seen = set()

    def record_consumed_args(call_node, consumer):
        if not consumer:
            return
        for arg in call_node.args:
            if isinstance(arg, ast.Name) and arg.id in producers:
                producer, produced_line = producers[arg.id]
                key = ('consume', arg.id, producer, consumer, call_node.lineno)
                if key in seen:
                    continue
                seen.add(key)
                flows.append(
                    DataFlowInfo(
                        source=producer,
                        target=consumer,
                        value=arg.id,
                        producer=producer,
                        consumer=consumer,
                        line=call_node.lineno,
                        evidence=[
                            f'{arg.id} produced at line {produced_line}',
                            f'{arg.id} passed into {consumer}()',
                        ],
                    )
                )

    for node in _iter_nodes_without_nested(func_node.body):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            value = node.value if isinstance(node, ast.Assign) else node.value
            if isinstance(value, ast.Call):
                producer = _call_name(value.func)
                record_consumed_args(value, producer)
                if producer:
                    targets = []
                    if isinstance(node, ast.Assign):
                        for target in node.targets:
                            targets.extend(_target_names(target))
                    else:
                        targets.extend(_target_names(node.target))
                    for target in targets:
                        producers[target] = (producer, node.lineno)
                        key = ('produce', target, producer, node.lineno)
                        if key not in seen:
                            seen.add(key)
                            flows.append(
                                DataFlowInfo(
                                    source=producer,
                                    target=target,
                                    value=target,
                                    producer=producer,
                                    line=node.lineno,
                                    evidence=[f'{target} assigned from {producer}()'],
                                )
                            )
            continue

        if isinstance(node, ast.Call):
            record_consumed_args(node, _call_name(node.func))
    return flows


def _extract_callable_analysis(func_node):
    calls = _extract_call_sites(func_node)
    external_calls = []
    side_effects = []
    seen_external = set()
    seen_effects = set()

    for node in _iter_nodes_without_nested(func_node.body):
        if isinstance(node, ast.Call):
            name = _call_name(node.func)
            if name and name not in seen_external:
                seen_external.add(name)
                external_calls.append(CallSite(name, node.lineno))
            effect = _side_effect_for_call(name, node)
            if effect:
                key = (effect.kind, effect.detail, effect.line)
                if key not in seen_effects:
                    seen_effects.add(key)
                    side_effects.append(effect)
        elif isinstance(node, ast.Subscript):
            effect = _env_side_effect_for_subscript(node)
            if effect:
                key = (effect.kind, effect.detail, effect.line)
                if key not in seen_effects:
                    seen_effects.add(key)
                    side_effects.append(effect)

    params = [arg.arg for arg in func_node.args.args]
    if getattr(func_node.args, 'posonlyargs', None):
        params = [arg.arg for arg in func_node.args.posonlyargs] + params
    params.extend(arg.arg for arg in func_node.args.kwonlyargs)

    return {
        'calls': calls,
        'docstring': ast.get_docstring(func_node),
        'params': params,
        'returns': _return_descriptions(func_node),
        'decisions': _extract_decisions(func_node),
        'data_flows': _extract_data_flows(func_node),
        'side_effects': side_effects,
        'external_calls': external_calls,
    }


def _is_main_guard(test):
    if not isinstance(test, ast.Compare) or len(test.ops) != 1 or len(test.comparators) != 1:
        return False
    if not isinstance(test.ops[0], ast.Eq):
        return False
    left = _safe_unparse(test.left)
    right = _safe_unparse(test.comparators[0]).strip('"\'')
    return left == '__name__' and right == '__main__'


def _extract_main_guard_calls(tree):
    calls = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.If) and _is_main_guard(node.test):
            calls.extend(CallSite(name, node.lineno) for name in _collect_call_names(node.body))
    return calls


def _extract_framework_entries(tree):
    entries = []
    app_names = set()

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            call = _call_name(node.value.func)
            if call and call.split('.')[-1] in {'FastAPI', 'Flask'}:
                for target in node.targets:
                    for name in _target_names(target):
                        app_names.add(name)
                        entries.append(
                            FrameworkInfo(
                                kind=call.split('.')[-1].lower(),
                                name=name,
                                line=node.lineno,
                                target=name,
                                reason=f'Found {call} application object',
                            )
                        )

    for node in ast.iter_child_nodes(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            expr = decorator.func if isinstance(decorator, ast.Call) else decorator
            name = _call_name(expr)
            if not name or '.' not in name:
                continue
            app_name, _, method = name.partition('.')
            if app_name in app_names and method in FRAMEWORK_DECORATORS:
                entries.append(
                    FrameworkInfo(
                        kind='route',
                        name=node.name,
                        line=node.lineno,
                        target=f'{app_name}.{method}',
                        reason=f'Found framework route decorator @{name}',
                    )
                )
    return entries


def _base_names(class_node):
    bases = []
    for base in class_node.bases:
        name = _call_name(base)
        if name:
            bases.append(name)
    return bases


def analyze_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8-sig', errors='ignore') as handle:
            source = handle.read()
    except OSError as exc:
        return ParsedModule(
            classes=[],
            functions=[],
            raw_imports=[],
            lines=0,
            warnings=[
                AnalysisWarning(
                    code='read-error',
                    message=str(exc),
                    file=filepath,
                )
            ],
        )

    lines = source.count('\n') + 1

    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return ParsedModule(
            classes=[],
            functions=[],
            raw_imports=[],
            lines=lines,
            warnings=[
                AnalysisWarning(
                    code='syntax-error',
                    message=str(exc),
                    file=filepath,
                    line=exc.lineno,
                )
            ],
        )

    classes = []
    functions = []
    raw_imports = []
    main_guard_calls = _extract_main_guard_calls(tree)
    framework_entries = _extract_framework_entries(tree)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                used_name = alias.asname if alias.asname else alias.name.split('.')[0]
                raw_imports.append(
                    ImportRecord(
                        kind='import',
                        module=alias.name,
                        level=0,
                        imported_name=None,
                        used_name=used_name,
                        line=node.lineno,
                    )
                )
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                used_name = alias.asname if alias.asname else alias.name
                raw_imports.append(
                    ImportRecord(
                        kind='from',
                        module=node.module or '',
                        level=node.level or 0,
                        imported_name=alias.name,
                        used_name=used_name,
                        line=node.lineno,
                    )
                )

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ClassDef):
            methods = []
            for child in ast.iter_child_nodes(node):
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    analysis = _extract_callable_analysis(child)
                    methods.append(
                        CallableInfo(
                            name=child.name,
                            line=child.lineno,
                            calls=analysis['calls'],
                            docstring=analysis['docstring'],
                            params=analysis['params'],
                            returns=analysis['returns'],
                            decisions=analysis['decisions'],
                            data_flows=analysis['data_flows'],
                            side_effects=analysis['side_effects'],
                            external_calls=analysis['external_calls'],
                        )
                    )
            classes.append(
                ClassInfo(
                    name=node.name,
                    line=node.lineno,
                    bases=_base_names(node),
                    methods=methods,
                )
            )
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            analysis = _extract_callable_analysis(node)
            functions.append(
                CallableInfo(
                    name=node.name,
                    line=node.lineno,
                    calls=analysis['calls'],
                    docstring=analysis['docstring'],
                    params=analysis['params'],
                    returns=analysis['returns'],
                    decisions=analysis['decisions'],
                    data_flows=analysis['data_flows'],
                    side_effects=analysis['side_effects'],
                    external_calls=analysis['external_calls'],
                )
            )

    return ParsedModule(
        classes=classes,
        functions=functions,
        raw_imports=raw_imports,
        lines=lines,
        main_guard_calls=main_guard_calls,
        framework_entries=framework_entries,
    )


def _resolve_relative_base(importer_module_key, level):
    package_name = _package_name_for_module(importer_module_key)
    parts = package_name.split('.') if package_name else []
    climb = level - 1
    if climb > len(parts):
        return None
    if climb:
        parts = parts[:-climb]
    return '.'.join(parts)


def _resolve_from_base(module_str, level, importer_module_key):
    if level > 0:
        base = _resolve_relative_base(importer_module_key, level)
        if base is None:
            return None
        if module_str:
            return f"{base}.{module_str}" if base else module_str
        return base
    return module_str or None


def _resolve_imports(parsed, importer_module_key, import_name_to_key):
    local_deps = set()
    import_bindings = {}
    ext_imports = set()
    warnings = []

    for record in parsed.raw_imports:
        if record.kind == 'import':
            module_key = import_name_to_key.get(record.module)
            if module_key:
                local_deps.add(module_key)
                if record.used_name == record.module.split('.')[0] and record.module != record.used_name:
                    import_path = record.used_name
                else:
                    import_path = record.module
                import_bindings[record.used_name] = ImportBinding(
                    used_name=record.used_name,
                    kind='namespace',
                    import_path=import_path,
                    module_key=module_key,
                )
            else:
                ext_imports.add(record.module.split('.')[0])
            continue

        if record.imported_name == '*':
            base_name = _resolve_from_base(record.module, record.level, importer_module_key)
            if base_name and base_name in import_name_to_key:
                local_deps.add(import_name_to_key[base_name])
                warnings.append(
                    AnalysisWarning(
                        code='star-import',
                        message='Star import cannot be fully resolved statically.',
                        file='',
                        line=record.line,
                    )
                )
            elif base_name:
                ext_imports.add(base_name.split('.')[0])
            continue

        base_name = _resolve_from_base(record.module, record.level, importer_module_key)
        full_name = None
        if base_name:
            full_name = f"{base_name}.{record.imported_name}"
        elif record.imported_name:
            full_name = record.imported_name

        if full_name and full_name in import_name_to_key:
            module_key = import_name_to_key[full_name]
            local_deps.add(module_key)
            import_bindings[record.used_name] = ImportBinding(
                used_name=record.used_name,
                kind='module',
                import_path=full_name,
                module_key=module_key,
            )
            continue

        if base_name and base_name in import_name_to_key:
            module_key = import_name_to_key[base_name]
            local_deps.add(module_key)
            import_bindings[record.used_name] = ImportBinding(
                used_name=record.used_name,
                kind='symbol',
                import_path=base_name,
                module_key=module_key,
                symbol_name=record.imported_name,
            )
            continue

        if base_name:
            ext_imports.add(base_name.split('.')[0])
        elif record.imported_name:
            ext_imports.add(record.imported_name.split('.')[0])

    return local_deps, import_bindings, sorted(ext_imports), warnings


def scan_project(root, recursive=True, exclude_dirs=None, include_globs=None):
    py_files, skipped_count = collect_py_files(
        root,
        recursive=recursive,
        exclude_dirs=exclude_dirs,
        include_globs=include_globs,
    )

    stats = AnalysisStats(files_skipped=skipped_count)
    if not py_files:
        return {}, [], stats

    file_to_module = {}
    import_name_to_key = {}
    for filepath in py_files:
        rel_path = os.path.relpath(filepath, root)
        module_key = _module_key_from_relpath(rel_path)
        file_to_module[filepath] = module_key
        import_name_to_key[_import_name_for_module(module_key)] = module_key

    short_counts = defaultdict(int)
    for module_key in file_to_module.values():
        short_counts[module_key.rsplit('.', 1)[-1]] += 1

    parsed_modules = {}
    warnings = []
    for filepath in py_files:
        parsed = analyze_file(filepath)
        for warning in parsed.warnings:
            warning.file = _warning_file_for_root(warning.file, root)
        parsed_modules[filepath] = parsed
        warnings.extend(parsed.warnings)

    stats.files_scanned = len(py_files)
    stats.syntax_error_files = sum(
        1 for warning in warnings if warning.code == 'syntax-error'
    )
    if stats.files_scanned > DEFAULT_MAX_FILES_WARNING:
        warnings.append(
            AnalysisWarning(
                code='large-project',
                message=(
                    f'{stats.files_scanned} Python files scanned; use --include-glob '
                    'or --exclude-dir if the walkthrough is too large.'
                ),
                file='.',
            )
        )

    data = {}
    for filepath in py_files:
        parsed = parsed_modules[filepath]
        module_key = file_to_module[filepath]
        rel_path = os.path.relpath(filepath, root)
        short_name = module_key.rsplit('.', 1)[-1]
        display_name = short_name if short_counts[short_name] == 1 else module_key

        local_deps, bindings, ext_imports, import_warnings = _resolve_imports(
            parsed,
            module_key,
            import_name_to_key,
        )
        for warning in import_warnings:
            warning.file = rel_path
        warnings.extend(import_warnings)

        data[module_key] = ModuleInfo(
            file=rel_path,
            filepath=filepath,
            display_name=display_name,
            lines=parsed.lines,
            classes=parsed.classes,
            functions=parsed.functions,
            ext_imports=ext_imports,
            local_deps=local_deps,
            import_bindings=bindings,
            main_guard_calls=parsed.main_guard_calls,
            framework_entries=parsed.framework_entries,
        )

    return data, warnings, stats


def _all_callables(data):
    for module_key, info in data.items():
        for fn in info.functions:
            yield module_key, fn.name
        for cls in info.classes:
            yield module_key, cls.name
            for method in cls.methods:
                yield module_key, f"{cls.name}.{method.name}"


def _callable_owner_name(callable_name):
    return callable_name.split('.', 1)[0] if '.' in callable_name else None


def build_call_graph(data):
    local_functions = defaultdict(set)
    local_classes = defaultdict(set)
    local_methods = defaultdict(lambda: defaultdict(set))
    import_name_to_key = {
        _import_name_for_module(module_key): module_key
        for module_key in data
    }

    for module_key, info in data.items():
        for fn in info.functions:
            local_functions[module_key].add(fn.name)
        for cls in info.classes:
            local_classes[module_key].add(cls.name)
            for method in cls.methods:
                local_methods[module_key][cls.name].add(method.name)

    def resolve_in_module(module_key, parts):
        if not parts:
            return ResolveResult(
                target=None,
                reason='module-object-call',
                likely_local=True,
            )

        first = parts[0]
        rest = parts[1:]

        if first in local_functions[module_key]:
            if rest:
                return ResolveResult(
                    target=None,
                    reason='function-attribute-call',
                    likely_local=True,
                )
            return ResolveResult(target=(module_key, first), likely_local=True)

        if first in local_classes[module_key]:
            if not rest:
                return ResolveResult(target=(module_key, first), likely_local=True)
            if rest[0] in local_methods[module_key][first]:
                return ResolveResult(
                    target=(module_key, f"{first}.{rest[0]}"),
                    likely_local=True,
                )
            return ResolveResult(
                target=None,
                reason='class-member-not-found',
                likely_local=True,
            )

        return ResolveResult(
            target=None,
            reason='module-member-not-found',
            likely_local=True,
        )

    def resolve_from_import_path(import_path, remainder_parts):
        parts = import_path.split('.') if import_path else []
        parts.extend(remainder_parts)

        for idx in range(len(parts), 0, -1):
            candidate = '.'.join(parts[:idx])
            module_key = import_name_to_key.get(candidate)
            if module_key:
                return resolve_in_module(module_key, parts[idx:])

        return ResolveResult(
            target=None,
            reason='import-path-not-local',
            likely_local=False,
        )

    def resolve_symbol_binding(binding, remainder_parts):
        module_key = binding.module_key
        symbol_name = binding.symbol_name
        if module_key is None or not symbol_name:
            return ResolveResult(
                target=None,
                reason='invalid-symbol-binding',
                likely_local=True,
            )

        if symbol_name in local_functions[module_key]:
            if remainder_parts:
                return ResolveResult(
                    target=None,
                    reason='function-attribute-call',
                    likely_local=True,
                )
            return ResolveResult(target=(module_key, symbol_name), likely_local=True)

        if symbol_name in local_classes[module_key]:
            if not remainder_parts:
                return ResolveResult(target=(module_key, symbol_name), likely_local=True)
            if remainder_parts[0] in local_methods[module_key][symbol_name]:
                return ResolveResult(
                    target=(module_key, f"{symbol_name}.{remainder_parts[0]}"),
                    likely_local=True,
                )
            return ResolveResult(
                target=None,
                reason='class-member-not-found',
                likely_local=True,
            )

        return ResolveResult(
            target=None,
            reason='imported-symbol-not-found',
            likely_local=True,
        )

    def resolve_call(module_key, call_name, current_class=None):
        head, sep, rest = call_name.partition('.')
        if rest and rest.split('.')[0] in DICT_METHODS:
            return ResolveResult(
                target=None,
                reason='container-method',
                likely_local=False,
            )

        binding = data[module_key].import_bindings.get(head)
        if binding:
            remainder_parts = rest.split('.') if sep else []
            if binding.kind == 'symbol':
                return resolve_symbol_binding(binding, remainder_parts)
            return resolve_from_import_path(binding.import_path, remainder_parts)

        if not sep and head in local_functions[module_key]:
            return ResolveResult(target=(module_key, head), likely_local=True)

        if not sep and head in local_classes[module_key]:
            return ResolveResult(target=(module_key, head), likely_local=True)

        if not sep and current_class and head in local_methods[module_key][current_class]:
            return ResolveResult(
                target=(module_key, f"{current_class}.{head}"),
                likely_local=True,
            )

        if sep and head in local_classes[module_key]:
            return resolve_in_module(module_key, [head] + rest.split('.'))

        return ResolveResult(
            target=None,
            reason='unknown-call-target',
            likely_local=not sep or head in data[module_key].import_bindings,
        )

    calls_to = defaultdict(list)
    called_by = defaultdict(list)
    inheritance = defaultdict(list)
    unresolved = []
    seen_edges = set()
    resolved_call_count = 0

    def add_edge(src, dst):
        key = (src, dst)
        if key in seen_edges:
            return
        seen_edges.add(key)
        calls_to[src].append(dst)
        called_by[dst].append(src)

    for module_key, info in data.items():
        for cls in info.classes:
            for base in cls.bases:
                result = resolve_call(module_key, base)
                if result.target and result.target[0] in data:
                    inheritance[(module_key, cls.name)].append(result.target)

    for module_key, info in data.items():
        for fn in info.functions:
            src = (module_key, fn.name)
            for call_site in fn.calls:
                result = resolve_call(module_key, call_site.name)
                if result.target and result.target[0] in data:
                    add_edge(src, result.target)
                    resolved_call_count += 1
                else:
                    unresolved.append(
                        UnresolvedCall(
                            module=module_key,
                            callable=fn.name,
                            call=call_site.name,
                            line=call_site.line,
                            reason=result.reason or 'unknown',
                            likely_local=result.likely_local,
                        )
                    )

        for cls in info.classes:
            for method in cls.methods:
                src = (module_key, f"{cls.name}.{method.name}")
                for call_site in method.calls:
                    result = resolve_call(
                        module_key,
                        call_site.name,
                        current_class=cls.name,
                    )
                    if result.target and result.target[0] in data:
                        add_edge(src, result.target)
                        resolved_call_count += 1
                    else:
                        unresolved.append(
                            UnresolvedCall(
                                module=module_key,
                                callable=f"{cls.name}.{method.name}",
                                call=call_site.name,
                                line=call_site.line,
                                reason=result.reason or 'unknown',
                                likely_local=result.likely_local,
                            )
                        )

    return dict(calls_to), dict(called_by), dict(inheritance), unresolved, resolved_call_count


def find_cycles(data):
    graph = {module_key: list(info.local_deps) for module_key, info in data.items()}
    visited = set()
    cycles = []
    cycle_keys = set()

    def dfs(node, path, path_set):
        visited.add(node)
        path.append(node)
        path_set.add(node)
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                dfs(neighbor, path, path_set)
            elif neighbor in path_set:
                start = path.index(neighbor)
                cycle = path[start:] + [neighbor]
                canonical = tuple(sorted(cycle[:-1]))
                if canonical not in cycle_keys:
                    cycle_keys.add(canonical)
                    cycles.append(cycle)
        path.pop()
        path_set.discard(node)

    for node in graph:
        if node not in visited:
            dfs(node, [], set())
    return cycles


def find_entry_points(data, called_by):
    imported_modules = set()
    for info in data.values():
        imported_modules.update(info.local_deps)

    skip_modules = set()
    for module_key, info in data.items():
        has_main = any(fn.name == 'main' for fn in info.functions)
        if module_key not in imported_modules and not has_main:
            skip_modules.add(module_key)

    entry_points = []
    for module_key, callable_name in _all_callables(data):
        if module_key in skip_modules:
            continue
        simple_name = callable_name.split('.')[-1]
        if simple_name.startswith('_') or simple_name.startswith('test'):
            continue
        if (module_key, callable_name) in called_by:
            continue
        owner = _callable_owner_name(callable_name)
        if owner and (module_key, owner) in called_by:
            continue
        entry_points.append((module_key, callable_name))
    return sorted(entry_points)


def find_leaves(data, calls_to):
    leaves = []
    for key in _all_callables(data):
        if key not in calls_to:
            leaves.append(key)
    return sorted(leaves)


def find_hotspots(called_by, top_n):
    ranked = sorted(
        called_by.items(),
        key=lambda item: len(item[1]),
        reverse=True,
    )
    return [(key, len(callers)) for key, callers in ranked[:top_n]]


def build_call_tree(start, calls_to, depth, max_branches, visited=None):
    if visited is None:
        visited = set()
    if start in visited or depth <= 0:
        return start, [], start in visited

    next_visited = visited | {start}
    children_raw = calls_to.get(start, [])[:max_branches]
    children = [
        build_call_tree(child, calls_to, depth - 1, max_branches, next_visited)
        for child in children_raw
    ]
    truncated = len(calls_to.get(start, [])) > max_branches
    return start, children, False, truncated


def _print_tree(node_tuple, prefix='', is_last=True):
    if len(node_tuple) == 3:
        node, children, is_cycle = node_tuple
        truncated = False
    else:
        node, children, is_cycle, truncated = node_tuple

    connector = '└─ ' if is_last else '├─ '
    label = f"{node[0]}.{node[1]}"
    if is_cycle:
        label += '  ↺'
    print(f"{prefix}{connector}{label}")

    extension = '   ' if is_last else '│  '
    for index, child in enumerate(children):
        _print_tree(child, prefix + extension, is_last=(index == len(children) - 1))
    if truncated:
        print(f"{prefix}{extension}└─ …")


def print_summary(data, project_root, calls_to, called_by, inheritance,
                  cycles, entry_points, leaves, hotspots, warnings,
                  unresolved_calls, stats, call_tree_depth,
                  call_tree_max_branches, max_entry_trees,
                  show_unresolved):
    project_name = get_project_name(project_root)
    total_lines = sum(info.lines for info in data.values())
    total_files = len(data)
    total_classes = sum(len(info.classes) for info in data.values())
    total_methods = sum(len(cls.methods) for info in data.values() for cls in info.classes)
    total_functions = sum(len(info.functions) for info in data.values())

    width = 74
    print('\n' + '═' * width)
    print(f"  PROJECT : {project_name.upper()}")
    print(
        f"  {total_files} files  ·  {total_lines} lines  ·  "
        f"{total_classes} classes  ·  {total_methods} methods  ·  "
        f"{total_functions} functions"
    )
    print(
        f"  resolved calls: {stats.resolved_calls}  ·  "
        f"unresolved calls: {stats.unresolved_calls}  ·  "
        f"warnings: {len(warnings)}"
    )
    print('═' * width)

    if warnings:
        print(f"\n  ⚠   WARNINGS  [{len(warnings)}]")
        for warning in warnings[:10]:
            location = warning.file
            if warning.line:
                location = f"{location}:{warning.line}"
            print(f"      {location}  [{warning.code}]  {warning.message}")
        if len(warnings) > 10:
            print(f"      … +{len(warnings) - 10} more")

    if cycles:
        print(f"\n  ⚠   CIRCULAR IMPORTS  [{len(cycles)}]")
        for cycle in cycles:
            labels = ' → '.join(data[module].display_name for module in cycle)
            print(f"      {labels}")

    if hotspots:
        print(f"\n  🔥  HOTSPOTS — most-called callables  (top {len(hotspots)})")
        for (module_key, callable_name), count in hotspots:
            print(f"      {count:>3}×  {data[module_key].display_name}.{callable_name}")

    if entry_points:
        print(f"\n  ◎   ENTRY POINTS (never called internally)  [{len(entry_points)}]")
        for module_key, callable_name in entry_points[:25]:
            print(f"      {data[module_key].display_name}.{callable_name}")
        if len(entry_points) > 25:
            print(f"      … +{len(entry_points) - 25} more")

    if leaves:
        print(f"\n  ●   LEAVES (call nothing inside project)  [{len(leaves)}]")
        for module_key, callable_name in leaves[:10]:
            print(f"      {data[module_key].display_name}.{callable_name}")
        if len(leaves) > 10:
            print(f"      … +{len(leaves) - 10} more")

    cross_pairs = defaultdict(int)
    for src, targets in calls_to.items():
        for dst in targets:
            if src[0] != dst[0]:
                cross_pairs[(src[0], dst[0])] += 1
    if cross_pairs:
        print(
            f"\n  ↔   CROSS-MODULE CALL EDGES  "
            f"[{sum(cross_pairs.values())} calls across {len(cross_pairs)} module pairs]"
        )
        ranked_pairs = sorted(cross_pairs.items(), key=lambda item: -item[1])
        for (from_mod, to_mod), count in ranked_pairs[:15]:
            print(
                f"      {data[from_mod].display_name:<24} ──{count:>3}──→  "
                f"{data[to_mod].display_name}"
            )

    if inheritance:
        print(f"\n  ⬡   INHERITANCE  [{len(inheritance)} subclasses]")
        for (module_key, class_name), bases in sorted(inheritance.items()):
            labels = ', '.join(
                f"{data[base_mod].display_name}.{base_name}"
                for base_mod, base_name in bases
            )
            print(f"      {data[module_key].display_name}.{class_name}  ◁──  {labels}")

    if show_unresolved and unresolved_calls:
        likely_local = [call for call in unresolved_calls if call.likely_local]
        display_calls = likely_local or unresolved_calls
        print(f"\n  ?   UNRESOLVED CALLS  [{min(len(display_calls), DEFAULT_MAX_UNRESOLVED_DISPLAY)} shown]")
        for call in display_calls[:DEFAULT_MAX_UNRESOLVED_DISPLAY]:
            print(
                f"      {call.module}.{call.callable}:{call.line}  "
                f"→ {call.call}  [{call.reason}]"
            )
        if len(display_calls) > DEFAULT_MAX_UNRESOLVED_DISPLAY:
            print(f"      … +{len(display_calls) - DEFAULT_MAX_UNRESOLVED_DISPLAY} more")

    if entry_points and calls_to:
        print(f"\n  🌳  CALL TREES FROM ENTRY POINTS  (depth ≤ {call_tree_depth})")
        shown = 0
        for entry_point in entry_points:
            if entry_point not in calls_to:
                continue
            if shown >= max_entry_trees:
                print(f"\n      … +{len(entry_points) - shown} more entry points")
                break
            print()
            tree = build_call_tree(
                entry_point,
                calls_to,
                call_tree_depth,
                call_tree_max_branches,
            )
            _print_tree(tree, prefix='      ')
            shown += 1

    print()
    for module_key in sorted(data.keys()):
        info = data[module_key]
        deps = ', '.join(
            sorted(data[dep].display_name for dep in info.local_deps if dep in data)
        ) or '—'
        print(f"\n{'─' * width}")
        print(f"  📄  {info.file}   ({info.lines} lines)")
        print(f"      Local deps : {deps}")
        if info.ext_imports:
            shown_imports = info.ext_imports[:12]
            extra = len(info.ext_imports) - len(shown_imports)
            line = ', '.join(shown_imports) + (f"  +{extra}" if extra > 0 else '')
            print(f"      Ext pkgs   : {line}")

        for cls in info.classes:
            bases = f"({', '.join(cls.bases)})" if cls.bases else ''
            print(f"\n      ⬡  class {cls.name}{bases}  [line {cls.line}]")
            for method in cls.methods:
                if method.calls:
                    shown_calls = [call.name for call in method.calls[:7]]
                    extra = len(method.calls) - len(shown_calls)
                    suffix = f"  +{extra}" if extra > 0 else ''
                    calls_str = '  →  ' + ', '.join(shown_calls) + suffix
                else:
                    calls_str = ''
                print(f"           • {method.name}{calls_str}")

        if info.functions:
            print()
            for fn in info.functions:
                if fn.calls:
                    shown_calls = [call.name for call in fn.calls[:7]]
                    extra = len(fn.calls) - len(shown_calls)
                    suffix = f"  +{extra}" if extra > 0 else ''
                    calls_str = '  →  ' + ', '.join(shown_calls) + suffix
                else:
                    calls_str = ''
                print(f"      ƒ  {fn.name}{calls_str}")

    print('\n' + '═' * width + '\n')


def export_json(data, calls_to, called_by, inheritance, cycles, entry_points,
                leaves, hotspots, warnings, unresolved_calls, stats,
                output_path):
    def key_str(key):
        return f"{key[0]}::{key[1]}"

    modules_out = {}
    for module_key, info in data.items():
        modules_out[module_key] = {
            'file': info.file,
            'display_name': info.display_name,
            'lines': info.lines,
            'local_deps': sorted(info.local_deps),
            'ext_imports': info.ext_imports,
            'classes': [
                {
                    'name': cls.name,
                    'line': cls.line,
                    'bases': cls.bases,
                    'methods': [
                        {
                            'name': method.name,
                            'line': method.line,
                            'calls': [call.name for call in method.calls],
                        }
                        for method in cls.methods
                    ],
                }
                for cls in info.classes
            ],
            'functions': [
                {
                    'name': fn.name,
                    'line': fn.line,
                    'calls': [call.name for call in fn.calls],
                }
                for fn in info.functions
            ],
        }

    out = {
        'schema_version': SCHEMA_VERSION,
        'modules': modules_out,
        'calls_to': {
            key_str(key): [key_str(target) for target in value]
            for key, value in calls_to.items()
        },
        'called_by': {
            key_str(key): [key_str(source) for source in value]
            for key, value in called_by.items()
        },
        'inheritance': {
            key_str(key): [key_str(target) for target in value]
            for key, value in inheritance.items()
        },
        'circular_imports': cycles,
        'entry_points': [
            {'module': module_key, 'callable': callable_name}
            for module_key, callable_name in entry_points
        ],
        'leaves': [
            {'module': module_key, 'callable': callable_name}
            for module_key, callable_name in leaves
        ],
        'hotspots': [
            {
                'module': key[0],
                'callable': key[1],
                'incoming_calls': count,
            }
            for key, count in hotspots
        ],
        'warnings': [
            {
                'code': warning.code,
                'message': warning.message,
                'file': warning.file,
                'line': warning.line,
            }
            for warning in warnings
        ],
        'stats': {
            'files_scanned': stats.files_scanned,
            'files_skipped': stats.files_skipped,
            'syntax_error_files': stats.syntax_error_files,
            'resolved_calls': stats.resolved_calls,
            'unresolved_calls': stats.unresolved_calls,
            'cross_module_edges': stats.cross_module_edges,
        },
        'unresolved_calls': [
            {
                'module': item.module,
                'callable': item.callable,
                'call': item.call,
                'line': item.line,
                'reason': item.reason,
                'likely_local': item.likely_local,
            }
            for item in unresolved_calls
        ],
    }

    with open(output_path, 'w', encoding='utf-8') as handle:
        json.dump(out, handle, indent=2, ensure_ascii=False)
    print(f"✅  Saved: {output_path}")


def _callable_lookup(data):
    lookup = {}
    for module_key, info in data.items():
        for fn in info.functions:
            lookup[(module_key, fn.name)] = fn
        for cls in info.classes:
            lookup[(module_key, cls.name)] = CallableInfo(
                name=cls.name,
                line=cls.line,
                docstring=None,
                params=[],
                returns=[],
            )
            for method in cls.methods:
                lookup[(module_key, f'{cls.name}.{method.name}')] = method
    return lookup


def _callable_ref(data, key):
    module_key, callable_name = key
    info = data.get(module_key)
    fn = _callable_lookup(data).get(key)
    return {
        'module': module_key,
        'function': callable_name,
        'file': info.file if info else module_key,
        'line': fn.line if fn else None,
    }


def _read_text_if_exists(path, limit=6000):
    try:
        text = path.read_text(encoding='utf-8', errors='ignore')
    except OSError:
        return ''
    return _redact_text(text[:limit])


def _env_keys_from_text(text):
    keys = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith('#') or '=' not in stripped:
            continue
        key = stripped.split('=', 1)[0].strip()
        if key and re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', key):
            keys.append(f'{key}=***')
    return keys


def collect_project_context(root):
    root_path = Path(root)
    context = {
        'readme_excerpt': '',
        'env_vars': [],
        'config_files': [],
        'dependencies': [],
        'metadata_files': [],
    }

    for readme_name in ('README.md', 'README.rst', 'README.txt'):
        readme_path = root_path / readme_name
        if readme_path.exists():
            context['readme_excerpt'] = _read_text_if_exists(readme_path, limit=3000)
            context['metadata_files'].append(readme_name)
            break

    for env_name in ('.env.example', '.env'):
        env_path = root_path / env_name
        if env_path.exists():
            context['env_vars'].extend(_env_keys_from_text(_read_text_if_exists(env_path)))
            context['metadata_files'].append(env_name)

    for config_name in ('config.py', 'settings.py'):
        config_path = root_path / config_name
        if config_path.exists():
            context['config_files'].append(config_name)

    requirements_path = root_path / 'requirements.txt'
    if requirements_path.exists():
        deps = []
        for line in _read_text_if_exists(requirements_path).splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                deps.append(_redact_text(stripped))
        context['dependencies'] = deps[:30]
        context['metadata_files'].append('requirements.txt')

    pyproject_path = root_path / 'pyproject.toml'
    if pyproject_path.exists():
        context['metadata_files'].append('pyproject.toml')

    return context


def _first_readme_sentence(readme_excerpt):
    if not readme_excerpt:
        return ''
    lines = [line.strip('# ').strip() for line in readme_excerpt.splitlines()]
    lines = [line for line in lines if line]
    if not lines:
        return ''
    first = lines[0]
    if len(lines) > 1 and len(first) < 25:
        first = f'{first}: {lines[1]}'
    return _redact_text(first[:240])


def infer_project_purpose(project_name, data, context):
    evidence = []
    readme_sentence = _first_readme_sentence(context.get('readme_excerpt', ''))
    if readme_sentence:
        evidence.append('README excerpt')
        return {
            'text': readme_sentence,
            'confidence': 'high',
            'evidence': evidence,
        }

    deps = {dep.lower() for dep in context.get('dependencies', [])}
    all_functions = [fn.name for info in data.values() for fn in info.functions]
    names = ' '.join(all_functions).lower()
    if any('fastapi' in dep or 'flask' in dep for dep in deps):
        evidence.append('web framework dependency')
        return {
            'text': 'This appears to be a Python web service or API application.',
            'confidence': 'medium',
            'evidence': evidence,
        }
    if any(token in names for token in ('fetch', 'scrape', 'request', 'notify', 'send')):
        evidence.append('function naming patterns')
        return {
            'text': 'This appears to retrieve data, process it, and produce notifications or output.',
            'confidence': 'medium',
            'evidence': evidence,
        }
    return {
        'text': f'{project_name} appears to be a Python codebase with statically discovered functions and modules.',
        'confidence': 'low',
        'evidence': ['fallback project structure heuristic'],
    }


def _parse_pyproject_console_scripts(root):
    pyproject = Path(root) / 'pyproject.toml'
    if not pyproject.exists():
        return []
    try:
        with pyproject.open('rb') as handle:
            parsed = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return []
    scripts = parsed.get('project', {}).get('scripts', {})
    return [
        {
            'script': name,
            'target': target,
            'source': 'pyproject.toml',
            'reason': 'Found in pyproject.toml project.scripts',
        }
        for name, target in scripts.items()
    ]


def _parse_setup_cfg_console_scripts(root):
    setup_cfg = Path(root) / 'setup.cfg'
    if not setup_cfg.exists():
        return []
    parser = configparser.ConfigParser()
    try:
        parser.read(setup_cfg, encoding='utf-8')
    except configparser.Error:
        return []
    if not parser.has_section('options.entry_points'):
        return []
    raw = parser.get('options.entry_points', 'console_scripts', fallback='')
    scripts = []
    for line in raw.splitlines():
        if '=' not in line:
            continue
        name, target = [part.strip() for part in line.split('=', 1)]
        scripts.append(
            {
                'script': name,
                'target': target,
                'source': 'setup.cfg',
                'reason': 'Found in setup.cfg console_scripts',
            }
        )
    return scripts


def _parse_setup_py_console_scripts(root):
    setup_py = Path(root) / 'setup.py'
    if not setup_py.exists():
        return []
    text = _read_text_if_exists(setup_py)
    scripts = []
    for match in re.finditer(r'([A-Za-z0-9_.-]+)\s*=\s*([A-Za-z0-9_.]+:[A-Za-z0-9_.]+)', text):
        scripts.append(
            {
                'script': match.group(1),
                'target': match.group(2),
                'source': 'setup.py',
                'reason': 'Found setup.py console_scripts-like entry',
            }
        )
    return scripts


def _console_scripts(root):
    return (
        _parse_pyproject_console_scripts(root)
        + _parse_setup_cfg_console_scripts(root)
        + _parse_setup_py_console_scripts(root)
    )


def _target_to_callable_key(target, data):
    if ':' not in target:
        return None
    module_name, callable_name = target.split(':', 1)
    callable_name = callable_name.split('.', 1)[0]
    import_name_to_key = {
        _import_name_for_module(module_key): module_key
        for module_key in data
    }
    module_key = import_name_to_key.get(module_name)
    if not module_key:
        return None
    if (module_key, callable_name) in _callable_lookup(data):
        return module_key, callable_name
    return None


def _entry_command(entry):
    kind = entry.get('kind')
    module_key = entry.get('module')
    file = entry.get('file')
    if kind == 'console_script':
        return entry.get('script')
    if kind == 'main_guard':
        return f'python {file}'
    if kind == 'framework_app':
        app_name = entry.get('name')
        if entry.get('framework') == 'flask':
            return f'flask --app {_import_name_for_module(module_key)} run'
        return f'uvicorn {_import_name_for_module(module_key)}:{app_name}'
    return f'python -m {_import_name_for_module(module_key)}'


def discover_onboarding_entry_points(root, data, entry_filter=None):
    lookup = _callable_lookup(data)
    entries = []
    seen = set()

    def add_entry(kind, key, rank, reason, confidence='medium', evidence=None, extra=None):
        module_key, callable_name = key
        fn = lookup.get(key)
        info = data.get(module_key)
        if not fn or not info:
            return
        dedupe = (module_key, callable_name)
        if dedupe in seen:
            return
        seen.add(dedupe)
        entry = {
            'kind': kind,
            'module': module_key,
            'name': callable_name,
            'file': info.file,
            'line': fn.line,
            'rank': rank,
            'reason': reason,
            'confidence': confidence,
            'evidence': evidence or [reason],
        }
        if extra:
            entry.update(extra)
        entry['command'] = _entry_command(entry)
        entries.append(entry)

    for script in _console_scripts(root):
        key = _target_to_callable_key(script['target'], data)
        if key:
            add_entry(
                'console_script',
                key,
                1,
                script['reason'],
                confidence='high',
                evidence=[script['source'], f"{script['script']} = {script['target']}"],
                extra={'script': script['script'], 'target': script['target']},
            )

    for module_key, info in data.items():
        for call in info.main_guard_calls:
            head = call.name.split('.', 1)[0]
            key = (module_key, head)
            if key in lookup:
                add_entry(
                    'main_guard',
                    key,
                    2,
                    'Found under if __name__ == "__main__"',
                    confidence='high',
                    evidence=[f'{info.file}:{call.line}', f'calls {call.name}()'],
                )

    for module_key, info in data.items():
        for framework in info.framework_entries:
            if framework.kind in {'fastapi', 'flask'}:
                entry = {
                    'kind': 'framework_app',
                    'framework': framework.kind,
                    'module': module_key,
                    'name': framework.name,
                    'file': info.file,
                    'line': framework.line,
                    'rank': 3,
                    'reason': framework.reason,
                    'confidence': 'high',
                    'evidence': [f'{info.file}:{framework.line}', framework.reason],
                }
                entry['command'] = _entry_command(entry)
                dedupe = (module_key, framework.name, 'framework_app')
                if dedupe not in seen:
                    seen.add(dedupe)
                    entries.append(entry)
            elif framework.kind == 'route':
                key = (module_key, framework.name)
                if key in lookup:
                    add_entry(
                        'framework_route',
                        key,
                        3,
                        framework.reason,
                        confidence='high',
                        evidence=[f'{info.file}:{framework.line}', framework.target],
                    )

    for key, fn in lookup.items():
        if fn.name in ENTRY_FUNCTION_NAMES:
            rank = 4 if fn.name in STRONG_ENTRY_FUNCTION_NAMES else 5
            add_entry(
                'function_name',
                key,
                rank,
                'Function name matches common entry point pattern',
                confidence='medium',
                evidence=[f'function name: {fn.name}'],
            )

    def matches_filter(entry):
        if not entry_filter:
            return True
        haystacks = {
            entry['name'],
            f"{entry['module']}::{entry['name']}",
            f"{entry['module']}.{entry['name']}",
            f"{entry['file']}::{entry['name']}",
        }
        return entry_filter in haystacks

    entries = [entry for entry in entries if matches_filter(entry)]
    return sorted(entries, key=lambda item: (item['rank'], item['file'], item['line'] or 0))


def infer_callable_purpose(fn):
    evidence = []
    if fn.docstring:
        first_line = _redact_text(fn.docstring.strip().splitlines()[0])
        return first_line, 'high', ['docstring']

    name = fn.name.lower()
    patterns = [
        (('load', 'read', 'settings', 'config', 'env'), 'loads configuration or input data'),
        (('fetch', 'request', 'scrape', 'download'), 'retrieves data from an external source'),
        (('parse', 'transform', 'normalize', 'process', 'filter'), 'processes or transforms data'),
        (('save', 'write', 'export'), 'writes output or persists results'),
        (('notify', 'send', 'email', 'telegram'), 'sends a notification or message'),
        (('validate', 'check'), 'validates input or state'),
        (('main', 'run', 'start', 'handler'), 'coordinates the main application flow'),
    ]
    for needles, purpose in patterns:
        if any(needle in name for needle in needles):
            evidence.append(f'function name: {fn.name}')
            return purpose, 'medium', evidence

    if fn.side_effects:
        kinds = ', '.join(sorted({effect.kind for effect in fn.side_effects}))
        return f'performs {kinds} side effects', 'medium', ['side effect analysis']
    if fn.calls:
        return 'coordinates local function calls', 'low', ['local call graph']
    return 'contains project logic; purpose could not be inferred precisely', 'low', ['fallback heuristic']


def _format_side_effect(effect):
    detail = _redact_text(effect.detail)
    location = f'line {effect.line}' if effect.line else 'unknown line'
    return f'{effect.kind}: {detail} ({location})'


def _flow_node(data, key, step, flags=None):
    flags = flags or {}
    lookup = _callable_lookup(data)
    fn = lookup.get(key)
    info = data.get(key[0])
    if not fn or not info:
        return None
    purpose, confidence, evidence = infer_callable_purpose(fn)
    evidence = evidence + flags.get('evidence', [])
    decisions = [
        {
            'kind': decision.kind,
            'condition': decision.condition,
            'line': decision.line,
            'true_calls': decision.true_calls,
            'false_calls': decision.false_calls,
            'confidence': decision.confidence,
            'evidence': decision.evidence,
        }
        for decision in fn.decisions
    ]
    return {
        'step': step,
        'module': key[0],
        'function': key[1],
        'file': info.file,
        'line': fn.line,
        'purpose': purpose,
        'inputs': fn.params,
        'outputs': fn.returns,
        'side_effects': [_format_side_effect(effect) for effect in fn.side_effects],
        'external_calls': [call.name for call in fn.external_calls if call.name],
        'calls': [],
        'decisions': decisions,
        'data_flows': [
            {
                'source': flow.source,
                'target': flow.target,
                'value': flow.value,
                'line': flow.line,
                'producer': flow.producer,
                'consumer': flow.consumer,
                'confidence': flow.confidence,
                'evidence': flow.evidence,
            }
            for flow in fn.data_flows
        ],
        'confidence': flags.get('confidence', confidence),
        'evidence': evidence,
        'recursion_detected': flags.get('recursion_detected', False),
        'repeated': flags.get('repeated', False),
        'truncated': flags.get('truncated', False),
    }


def build_execution_flow_for_entry(entry, data, calls_to, max_depth, max_branches):
    if entry.get('kind') == 'framework_app':
        return []

    root_key = (entry['module'], entry['name'])
    flow = []
    expanded = set()
    step_counter = {'value': 0}

    def add_node(key, depth, stack):
        if depth < 0:
            return
        step_counter['value'] += 1
        if key in stack:
            node = _flow_node(
                data,
                key,
                step_counter['value'],
                flags={
                    'confidence': 'high',
                    'recursion_detected': True,
                    'evidence': ['recursion detected in local call graph'],
                },
            )
            if node:
                flow.append(node)
            return
        if key in expanded:
            node = _flow_node(
                data,
                key,
                step_counter['value'],
                flags={
                    'confidence': 'high',
                    'repeated': True,
                    'evidence': ['repeated function collapsed'],
                },
            )
            if node:
                flow.append(node)
            return

        expanded.add(key)
        local_calls = calls_to.get(key, [])
        shown_calls = local_calls[:max_branches]
        node = _flow_node(
            data,
            key,
            step_counter['value'],
            flags={'truncated': len(local_calls) > max_branches},
        )
        if not node:
            return
        node['calls'] = [_callable_ref(data, child) for child in shown_calls]
        flow.append(node)
        for child in shown_calls:
            add_node(child, depth - 1, stack | {key})

    add_node(root_key, max_depth, set())
    return flow


def _flatten_report_nodes(report):
    for entry in report['entry_points']:
        for node in entry.get('flow', []):
            yield entry, node


def build_onboarding_report(root, project_name, data, calls_to, max_depth,
                            max_branches, entry_filter=None):
    context = collect_project_context(root)
    purpose = infer_project_purpose(project_name, data, context)
    entry_points = discover_onboarding_entry_points(root, data, entry_filter=entry_filter)
    limitations = [
        'Static analysis does not execute the target project.',
        'Dynamic imports, monkey patching, runtime dispatch, and complex data flow may be incomplete.',
        'External library behavior is summarized as side effects instead of expanded into the local call tree.',
    ]
    if not entry_points:
        limitations.append('No strong entry point was discovered; inspect modules manually.')

    for entry in entry_points:
        entry['flow'] = build_execution_flow_for_entry(
            entry,
            data,
            calls_to,
            max_depth=max_depth,
            max_branches=max_branches,
        )

    return {
        'project': project_name,
        'root': root,
        'purpose': purpose,
        'context': context,
        'entry_points': entry_points,
        'limitations': limitations,
    }


def _md_list(items, fallback='None detected.'):
    if not items:
        return f'- {fallback}\n'
    return ''.join(f'- {_redact_text(item)}\n' for item in items)


def _location(file, line):
    return f'{file}:{line}' if line else file


def render_execution_walkthrough(report):
    lines = ['## Execution Walkthrough', '']
    if not report['entry_points']:
        lines.extend(['No entry point was discovered.', ''])
        return '\n'.join(lines)

    for entry in report['entry_points']:
        lines.extend([
            f"### Entry point: {entry['name']}()",
            '',
            f"Location: {_location(entry['file'], entry.get('line'))}",
            f"Reason: {entry['reason']}",
            f"Confidence: {entry['confidence']}",
            '',
        ])
        if entry.get('kind') == 'framework_app':
            lines.extend([
                f"This framework application object starts via: `{entry['command']}`.",
                '',
            ])
            continue
        for node in entry.get('flow', []):
            flags = []
            if node.get('recursion_detected'):
                flags.append('recursion detected')
            if node.get('repeated'):
                flags.append('repeated function collapsed')
            if node.get('truncated'):
                flags.append('calls truncated by max branch limit')
            suffix = f" ({', '.join(flags)})" if flags else ''
            lines.extend([
                f"Step {node['step']} - {node['function']}(){suffix}",
                f"Location: {_location(node['file'], node['line'])}",
                f"Purpose: {node['purpose']}",
                f"Confidence: {node['confidence']}",
                f"Evidence: {', '.join(node['evidence']) or 'None'}",
                f"Inputs: {', '.join(node['inputs']) or 'None detected'}",
                f"Outputs: {', '.join(node['outputs']) or 'None detected'}",
                'Side effects:',
                _md_list(node['side_effects'], fallback='None detected.').rstrip(),
                'Next local calls:',
                _md_list(
                    [f"{call['function']}() at {_location(call['file'], call['line'])}" for call in node['calls']],
                    fallback='No local project calls detected.',
                ).rstrip(),
                '',
            ])
    return '\n'.join(lines)


def render_decision_tree(report):
    lines = ['# Decision Tree', '']
    found = False
    for _entry, node in _flatten_report_nodes(report):
        for decision in node.get('decisions', []):
            found = True
            lines.extend([
                f"## {node['function']}() at {_location(node['file'], decision['line'])}",
                f"Condition: {decision['condition']}",
                f"Confidence: {decision['confidence']}",
                f"Evidence: {', '.join(decision['evidence']) or 'AST branch'}",
                'True branch calls:',
                _md_list(decision['true_calls'], fallback='No calls detected.').rstrip(),
                'False/error branch calls:',
                _md_list(decision['false_calls'], fallback='No calls detected.').rstrip(),
                '',
            ])
    if not found:
        lines.append('No important if/else or try/except branches were detected in the selected flow.')
    return '\n'.join(lines) + '\n'


def render_data_flow(report):
    lines = ['# Data Flow', '']
    found = False
    for _entry, node in _flatten_report_nodes(report):
        for flow in node.get('data_flows', []):
            found = True
            if flow.get('consumer'):
                sentence = (
                    f"`{flow['value']}` is produced by `{flow['producer']}()` and passed into "
                    f"`{flow['consumer']}()` in `{node['function']}()` at "
                    f"{_location(node['file'], flow['line'])}."
                )
            else:
                sentence = (
                    f"`{flow['target']}` is produced by `{flow['producer']}()` in "
                    f"`{node['function']}()` at {_location(node['file'], flow['line'])}."
                )
            lines.extend([
                f'- {sentence}',
                f"  Confidence: {flow['confidence']}; evidence: {', '.join(flow['evidence'])}",
            ])
    if not found:
        lines.append('No simple assignment-to-call data flow chain was detected in the selected flow.')
    return '\n'.join(lines) + '\n'


def render_walkthrough(report):
    purpose = report['purpose']
    context = report['context']
    lines = [
        '# Project Walkthrough',
        '',
        '## Project Purpose Guess',
        '',
        f"{purpose['text']}",
        '',
        f"Confidence: {purpose['confidence']}",
        f"Evidence: {', '.join(purpose['evidence']) or 'None'}",
        '',
        '## How to Run',
        '',
    ]
    commands = []
    for entry in report['entry_points']:
        command = entry.get('command')
        if command and command not in commands:
            commands.append(command)
    if commands:
        lines.extend(f'- `{command}`' for command in commands)
    else:
        lines.append('- No confident run command was inferred.')
    lines.extend(['', '## Entry Points', ''])
    if report['entry_points']:
        for index, entry in enumerate(report['entry_points'], start=1):
            lines.extend([
                f"### {index}. {entry['file']}::{entry['name']} at {_location(entry['file'], entry.get('line'))}",
                f"Reason: {entry['reason']}",
                f"Confidence: {entry['confidence']}",
                f"Evidence: {', '.join(entry['evidence']) or 'None'}",
                f"Suggested command: `{entry.get('command', 'unknown')}`",
                '',
            ])
    else:
        lines.extend(['No entry points were discovered.', ''])

    lines.append(render_execution_walkthrough(report))
    lines.extend(['## Decision Points', '', render_decision_tree(report).replace('# Decision Tree\n\n', '').rstrip(), ''])
    lines.extend(['## Data Flow', '', render_data_flow(report).replace('# Data Flow\n\n', '').rstrip(), ''])
    lines.extend(['## Side Effects', ''])
    side_effects = []
    for _entry, node in _flatten_report_nodes(report):
        for effect in node.get('side_effects', []):
            side_effects.append(f"{node['function']}() at {_location(node['file'], node['line'])}: {effect}")
    lines.append(_md_list(side_effects, fallback='No side effects detected in the selected flow.').rstrip())
    lines.extend(['', '## Final Outcome', ''])
    if side_effects:
        lines.append('The program reaches external-visible behavior through the side effects listed above.')
    elif report['entry_points']:
        lines.append('The selected entry point completes local Python logic; no external-visible effect was confidently detected statically.')
    else:
        lines.append('No final outcome could be inferred because no strong entry point was discovered.')
    lines.extend(['', '## Context Sources', ''])
    lines.append(_md_list(context.get('metadata_files', []), fallback='No README/config metadata files detected.').rstrip())
    if context.get('env_vars'):
        lines.extend(['', 'Environment variables mentioned:', _md_list(context['env_vars']).rstrip()])
    lines.extend(['', '## Unknowns / Static Analysis Limits', ''])
    lines.append(_md_list(report['limitations']).rstrip())
    return '\n'.join(lines) + '\n'


def execution_flow_json(report):
    return {
        'project': report['project'],
        'entry_points': [
            {
                'name': entry['name'],
                'module': entry['module'],
                'file': entry['file'],
                'line': entry.get('line'),
                'reason': entry['reason'],
                'confidence': entry['confidence'],
                'evidence': entry['evidence'],
                'command': entry.get('command'),
                'flow': entry.get('flow', []),
            }
            for entry in report['entry_points']
        ],
        'limitations': report['limitations'],
    }


def export_onboarding_report(report, output_dir):
    outputs = {
        OUTPUT_WALKTHROUGH: render_walkthrough(report),
        OUTPUT_DECISION_TREE: render_decision_tree(report),
        OUTPUT_DATA_FLOW: render_data_flow(report),
    }
    for filename, content in outputs.items():
        output_path = output_dir / filename
        output_path.write_text(content, encoding='utf-8')
        print(f"✅  Saved: {output_path}")

    execution_path = output_dir / OUTPUT_EXECUTION_FLOW
    with execution_path.open('w', encoding='utf-8') as handle:
        json.dump(execution_flow_json(report), handle, indent=2, ensure_ascii=False)
    print(f"✅  Saved: {execution_path}")


def print_walkthrough_preview(report, output_dir=None):
    print('PROJECT WALKTHROUGH PREVIEW')
    print('─' * 74)
    print(f"Purpose guess ({report['purpose']['confidence']}): {report['purpose']['text']}")
    if report['entry_points']:
        print('Top entry points:')
        for entry in report['entry_points'][:5]:
            print(
                f"  - {entry['file']}::{entry['name']} "
                f"at {_location(entry['file'], entry.get('line'))} "
                f"[{entry['confidence']}]"
            )
            print(f"    reason: {entry['reason']}")
    else:
        print('No strong entry point was found.')
    if output_dir:
        print(f"\nOutput dir     : {output_dir}")
        print(f"Walkthrough    : {output_dir / OUTPUT_WALKTHROUGH}")
    print()


ROLE_MIXED = '#4C9BE8'
ROLE_CLASSES = '#F4A261'
ROLE_FUNCS = '#2EC4B6'
ROLE_UTIL = '#E0E0E0'

BG_LIGHT = '#FAFAFA'
TEXT_DARK = '#1f2937'
EDGE_GRAY = '#9ca3af'
NODE_BORDER = '#334155'
HOTSPOT_RING = '#DC2626'


def _module_role_color(info):
    has_classes = bool(info.classes)
    has_functions = bool(info.functions)
    if has_classes and has_functions:
        return ROLE_MIXED
    if has_classes:
        return ROLE_CLASSES
    if has_functions:
        return ROLE_FUNCS
    return ROLE_UTIL


def _node_size(info, min_size=450, max_size=3800):
    lines = max(info.lines, 1)
    return min(max_size, min_size + math.sqrt(lines) * 65)


def _subfolder_pos_hints(data):
    groups = defaultdict(list)
    for module_key, info in data.items():
        first = info.file.split(os.sep)[0]
        if first.endswith('.py'):
            first = '_root'
        groups[first].append(module_key)

    n_groups = max(len(groups), 1)
    hints = {}
    for group_index, (_, modules) in enumerate(sorted(groups.items())):
        angle = 2 * math.pi * group_index / n_groups
        group_x, group_y = math.cos(angle), math.sin(angle)
        for module_key in modules:
            jitter_x = ((hash(module_key) % 100) - 50) / 500.0
            jitter_y = ((hash(module_key + 'y') % 100) - 50) / 500.0
            hints[module_key] = (group_x + jitter_x, group_y + jitter_y)
    return hints


def _stats_box(ax, text):
    ax.text(
        0.99,
        0.99,
        text,
        transform=ax.transAxes,
        ha='right',
        va='top',
        fontsize=9,
        family='monospace',
        color=TEXT_DARK,
        bbox=dict(
            boxstyle='round,pad=0.5',
            facecolor='white',
            edgecolor='#d1d5db',
            linewidth=1,
        ),
    )


def _style_axes(ax, title):
    ax.set_title(title, fontsize=14, color=TEXT_DARK, pad=15, fontweight='bold')
    ax.set_axis_off()
    for spine in ax.spines.values():
        spine.set_visible(False)


def draw_module_graph(data, output_path, project_name):
    if not data:
        return

    graph = nx.DiGraph()
    for module_key, info in data.items():
        graph.add_node(
            module_key,
            label=info.display_name,
            lines=info.lines,
            color=_module_role_color(info),
            size=_node_size(info),
        )
    for module_key, info in data.items():
        for dep in info.local_deps:
            if dep in data:
                graph.add_edge(module_key, dep, weight=1)

    n_nodes = graph.number_of_nodes()
    spring_k = 2.5 / math.sqrt(max(n_nodes, 1))
    hints = _subfolder_pos_hints(data)
    try:
        pos = nx.spring_layout(graph, k=spring_k, seed=42, iterations=80, pos=hints)
    except Exception:
        pos = nx.spring_layout(graph, k=spring_k, seed=42, iterations=80)

    fig_w = max(12, min(24, n_nodes * 0.55))
    fig_h = max(9, min(18, n_nodes * 0.42))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), facecolor=BG_LIGHT)
    ax.set_facecolor(BG_LIGHT)

    node_sizes = [graph.nodes[module]['size'] for module in graph.nodes]
    node_colors = [graph.nodes[module]['color'] for module in graph.nodes]

    if graph.number_of_edges() > 0:
        nx.draw_networkx_edges(
            graph,
            pos,
            ax=ax,
            edge_color=EDGE_GRAY,
            width=1.3,
            alpha=0.55,
            arrows=True,
            arrowsize=12,
            arrowstyle='-|>',
            connectionstyle='arc3,rad=0.08',
            node_size=node_sizes,
        )

    nx.draw_networkx_nodes(
        graph,
        pos,
        ax=ax,
        node_color=node_colors,
        node_size=node_sizes,
        edgecolors=NODE_BORDER,
        linewidths=1.2,
        alpha=0.95,
    )

    for module_key, (x, y) in pos.items():
        info = data[module_key]
        ax.text(
            x,
            y - 0.050,
            info.display_name,
            ha='center',
            va='top',
            fontsize=9,
            color=TEXT_DARK,
            fontweight='bold',
            zorder=5,
        )
        ax.text(
            x,
            y - 0.085,
            f"{info.lines}L",
            ha='center',
            va='top',
            fontsize=7,
            color='#6b7280',
            zorder=5,
        )

    legend_items = [
        mpatches.Patch(color=ROLE_MIXED, label='classes + functions'),
        mpatches.Patch(color=ROLE_CLASSES, label='classes only'),
        mpatches.Patch(color=ROLE_FUNCS, label='functions only'),
        mpatches.Patch(color=ROLE_UTIL, label='utility / empty'),
    ]
    ax.legend(
        handles=legend_items,
        loc='lower left',
        frameon=True,
        facecolor='white',
        edgecolor='#d1d5db',
        fontsize=9,
        title='Module role',
        title_fontsize=9,
    )

    _stats_box(
        ax,
        f"files   : {len(data)}\n"
        f"lines   : {sum(info.lines for info in data.values()):,}\n"
        f"imports : {graph.number_of_edges()}",
    )
    _style_axes(ax, f'{project_name} — Module Dependency Graph')

    plt.tight_layout()
    plt.savefig(output_path, dpi=200, bbox_inches='tight', facecolor=BG_LIGHT)
    plt.close(fig)
    print(f"✅  Saved: {output_path}")


def draw_call_graph(data, calls_to, called_by, output_path, project_name):
    edge_counts = defaultdict(int)
    for src, targets in calls_to.items():
        for dst in targets:
            if src[0] != dst[0]:
                edge_counts[(src[0], dst[0])] += 1

    if not edge_counts:
        print('  ℹ  No cross-module calls — skipping call graph.')
        return

    active_modules = set()
    for from_mod, to_mod in edge_counts:
        active_modules.add(from_mod)
        active_modules.add(to_mod)

    graph = nx.DiGraph()
    for module_key in active_modules:
        info = data[module_key]
        graph.add_node(
            module_key,
            label=info.display_name,
            lines=info.lines,
            color=_module_role_color(info),
            size=_node_size(info),
        )
    for (from_mod, to_mod), count in edge_counts.items():
        graph.add_edge(from_mod, to_mod, weight=count)

    try:
        pos = nx.kamada_kawai_layout(graph)
    except Exception:
        pos = nx.spring_layout(
            graph,
            k=2.5 / math.sqrt(max(len(active_modules), 1)),
            seed=42,
        )

    per_module_max = defaultdict(int)
    for (module_key, _callable_name), callers in called_by.items():
        if len(callers) > per_module_max[module_key]:
            per_module_max[module_key] = len(callers)
    hotspot_modules = {
        module_key for module_key in active_modules
        if per_module_max.get(module_key, 0) > 5
    }

    n_modules = len(active_modules)
    fig_w = max(12, min(24, n_modules * 0.75))
    fig_h = max(9, min(18, n_modules * 0.58))
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), facecolor=BG_LIGHT)
    ax.set_facecolor(BG_LIGHT)

    node_sizes = [graph.nodes[module]['size'] for module in graph.nodes]
    node_colors = [graph.nodes[module]['color'] for module in graph.nodes]

    max_count = max(edge_counts.values())
    for (from_mod, to_mod), count in edge_counts.items():
        width = 0.9 + (count / max_count) * 4.2
        nx.draw_networkx_edges(
            graph,
            pos,
            ax=ax,
            edgelist=[(from_mod, to_mod)],
            width=width,
            edge_color=EDGE_GRAY,
            alpha=0.65,
            arrows=True,
            arrowsize=14,
            arrowstyle='-|>',
            connectionstyle='arc3,rad=0.12',
            node_size=node_sizes,
        )

    nx.draw_networkx_nodes(
        graph,
        pos,
        ax=ax,
        node_color=node_colors,
        node_size=node_sizes,
        edgecolors=NODE_BORDER,
        linewidths=1.2,
        alpha=0.95,
    )

    if hotspot_modules:
        ring_sizes = [graph.nodes[module]['size'] * 1.6 for module in hotspot_modules]
        nx.draw_networkx_nodes(
            graph,
            pos,
            ax=ax,
            nodelist=list(hotspot_modules),
            node_color='none',
            node_size=ring_sizes,
            edgecolors=HOTSPOT_RING,
            linewidths=2.6,
        )

    edge_labels = {edge: str(count) for edge, count in edge_counts.items()}
    nx.draw_networkx_edge_labels(
        graph,
        pos,
        ax=ax,
        edge_labels=edge_labels,
        font_size=7,
        font_color='#374151',
        bbox=dict(
            boxstyle='round,pad=0.15',
            facecolor='white',
            edgecolor='none',
            alpha=0.85,
        ),
        rotate=False,
    )

    for module_key, (x, y) in pos.items():
        info = data[module_key]
        ax.text(
            x,
            y - 0.055,
            info.display_name,
            ha='center',
            va='top',
            fontsize=9,
            color=TEXT_DARK,
            fontweight='bold',
            zorder=5,
        )

    legend_items = [
        mpatches.Patch(color=ROLE_MIXED, label='classes + functions'),
        mpatches.Patch(color=ROLE_CLASSES, label='classes only'),
        mpatches.Patch(color=ROLE_FUNCS, label='functions only'),
        mpatches.Patch(color=ROLE_UTIL, label='utility / empty'),
        mpatches.Patch(
            edgecolor=HOTSPOT_RING,
            facecolor='none',
            linewidth=2,
            label='hotspot (>5 callers)',
        ),
    ]
    ax.legend(
        handles=legend_items,
        loc='lower left',
        frameon=True,
        facecolor='white',
        edgecolor='#d1d5db',
        fontsize=9,
        title='Legend',
        title_fontsize=9,
    )

    _stats_box(
        ax,
        f"modules : {len(active_modules)}\n"
        f"lines   : {sum(info.lines for info in data.values()):,}\n"
        f"calls   : {sum(edge_counts.values())}\n"
        f"edges   : {len(edge_counts)}",
    )
    _style_axes(ax, f'{project_name} — Cross-Module Call Graph')

    plt.tight_layout()
    plt.savefig(output_path, dpi=200, bbox_inches='tight', facecolor=BG_LIGHT)
    plt.close(fig)
    print(f"✅  Saved: {output_path}")


def draw_hotspots(hotspots, data, output_path, project_name):
    if not hotspots:
        print('  ℹ  No hotspots — skipping hotspots chart.')
        return

    items = list(reversed(hotspots))
    labels = [
        f"{data[module_key].display_name}.{callable_name}"
        for (module_key, callable_name), _count in items
    ]
    counts = [count for _key, count in items]

    def bar_color(count):
        if count >= 8:
            return '#DC2626'
        if count >= 4:
            return '#F59E0B'
        return '#10B981'

    colors = [bar_color(count) for count in counts]

    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG_LIGHT)
    ax.set_facecolor(BG_LIGHT)

    bars = ax.barh(
        labels,
        counts,
        color=colors,
        edgecolor='#1f2937',
        linewidth=0.6,
        height=0.72,
    )

    pad = max(counts) * 0.01 if counts else 0
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_width() + pad,
            bar.get_y() + bar.get_height() / 2,
            str(count),
            ha='left',
            va='center',
            fontsize=9,
            color=TEXT_DARK,
            fontweight='bold',
        )

    ax.set_xlabel('Incoming call count', fontsize=10, color=TEXT_DARK)
    ax.set_title(
        f'{project_name} — Most-Called Functions & Methods',
        fontsize=13,
        color=TEXT_DARK,
        pad=14,
        fontweight='bold',
    )

    for side in ('top', 'right', 'left'):
        ax.spines[side].set_visible(False)
    ax.spines['bottom'].set_color('#9ca3af')

    ax.tick_params(axis='y', length=0, labelsize=9, colors=TEXT_DARK)
    ax.tick_params(axis='x', colors='#6b7280', labelsize=9)
    ax.xaxis.grid(True, color='#e5e7eb', linewidth=0.8)
    ax.set_axisbelow(True)
    if counts:
        ax.set_xlim(0, max(counts) * 1.15)

    legend_items = [
        mpatches.Patch(color='#10B981', label='1 – 3 calls'),
        mpatches.Patch(color='#F59E0B', label='4 – 7 calls'),
        mpatches.Patch(color='#DC2626', label='8+ calls'),
    ]
    ax.legend(
        handles=legend_items,
        loc='lower right',
        frameon=True,
        facecolor='white',
        edgecolor='#d1d5db',
        fontsize=9,
    )

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor=BG_LIGHT)
    plt.close(fig)
    print(f"✅  Saved: {output_path}")


def _positive_int(value, flag_name):
    try:
        parsed = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"{flag_name} must be an integer.") from exc
    if parsed < 1:
        raise argparse.ArgumentTypeError(f"{flag_name} must be >= 1.")
    return parsed


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description=(
            'Analyze a Python project and export an onboarding walkthrough, '
            'execution flow, decision tree, data flow, graphs, and JSON report.'
        )
    )
    parser.add_argument(
        'target',
        nargs='?',
        default=DEFAULT_TARGET,
        help='Directory to analyze. Defaults to the current working directory.',
    )
    parser.add_argument(
        '--output-dir',
        default=None,
        help=(
            'Directory for generated artifacts. Defaults to '
            './analysis_output/<project_name>/'
        ),
    )
    parser.add_argument(
        '--depth', '--max-depth',
        dest='depth',
        type=lambda value: _positive_int(value, '--depth'),
        default=DEFAULT_CALL_TREE_DEPTH,
        help='Call tree and walkthrough depth limit.',
    )
    parser.add_argument(
        '--max-branches',
        type=lambda value: _positive_int(value, '--max-branches'),
        default=DEFAULT_CALL_TREE_MAX_BR,
        help='Maximum call-tree branches per node.',
    )
    parser.add_argument(
        '--max-entry-trees',
        type=lambda value: _positive_int(value, '--max-entry-trees'),
        default=DEFAULT_MAX_ENTRY_TREES,
        help='Maximum entry-point call trees to print.',
    )
    parser.add_argument(
        '--hotspots',
        type=lambda value: _positive_int(value, '--hotspots'),
        default=DEFAULT_HOTSPOT_TOP_N,
        help='Number of hotspot callables to include.',
    )
    parser.add_argument(
        '--non-recursive',
        action='store_true',
        help='Only analyze Python files in the top-level target directory.',
    )
    parser.add_argument(
        '--include-glob',
        action='append',
        default=[],
        metavar='PATTERN',
        help='Repeatable glob pattern matched against relative Python file paths.',
    )
    parser.add_argument(
        '--exclude-dir',
        action='append',
        default=[],
        metavar='NAME',
        help='Repeatable directory name to exclude in addition to defaults.',
    )
    parser.add_argument(
        '--show-unresolved',
        action='store_true',
        help='Show unresolved call examples in the terminal summary.',
    )
    parser.add_argument(
        '--entry',
        default=None,
        metavar='ENTRYPOINT',
        help=(
            'Only generate walkthrough details for a matching entry point, '
            'for example main, pkg.mod::main, or pkg.mod.main.'
        ),
    )
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        '--summary-only',
        action='store_true',
        help='Only print the terminal summary; do not write JSON or images.',
    )
    mode_group.add_argument(
        '--json-only',
        action='store_true',
        help='Only write project_analysis.json; skip PNG artifacts.',
    )
    mode_group.add_argument(
        '--walkthrough-only',
        action='store_true',
        help='Only write onboarding walkthrough, execution flow, decision tree, and data flow reports.',
    )
    return parser.parse_args(argv)


def resolve_output_dir(project_name, output_dir):
    if output_dir:
        return Path(output_dir).expanduser().resolve()
    return Path.cwd() / 'analysis_output' / project_name


def main(argv=None):
    args = parse_args(argv)
    root = os.path.abspath(args.target or os.getcwd())

    if not os.path.isdir(root):
        print(f"❌  Not a valid directory: {root}", file=sys.stderr)
        return EXIT_INVALID_DIR

    project_name = get_project_name(root)
    recursive = DEFAULT_RECURSIVE and not args.non_recursive

    data, warnings, stats = scan_project(
        root,
        recursive=recursive,
        exclude_dirs=args.exclude_dir,
        include_globs=args.include_glob,
    )
    if not data:
        print(f"❌  No Python files found in: {root}", file=sys.stderr)
        return EXIT_NO_PY_FILES

    calls_to, called_by, inheritance, unresolved_calls, resolved_call_count = build_call_graph(data)
    cycles = find_cycles(data)
    structural_entry_points = find_entry_points(data, called_by)
    leaves = find_leaves(data, calls_to)
    hotspots = find_hotspots(called_by, args.hotspots)

    stats.resolved_calls = resolved_call_count
    stats.unresolved_calls = len(unresolved_calls)
    stats.cross_module_edges = sum(
        1
        for src, targets in calls_to.items()
        for dst in targets
        if src[0] != dst[0]
    )

    print(f"\n🔍  Scanning: {root}")
    print(f"    Project    : {project_name}")
    print(f"    Recursive  : {recursive}")
    if args.summary_only:
        print("    Output dir : disabled (--summary-only)\n")
    else:
        out_dir = resolve_output_dir(project_name, args.output_dir)
        print(f"    Output dir : {out_dir}\n")

    if not args.walkthrough_only:
        print_summary(
            data,
            root,
            calls_to,
            called_by,
            inheritance,
            cycles,
            structural_entry_points,
            leaves,
            hotspots,
            warnings,
            unresolved_calls,
            stats,
            call_tree_depth=args.depth,
            call_tree_max_branches=args.max_branches,
            max_entry_trees=args.max_entry_trees,
            show_unresolved=args.show_unresolved,
        )

    if args.summary_only:
        return 0

    out_dir = resolve_output_dir(project_name, args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.json_only:
        export_json(
            data,
            calls_to,
            called_by,
            inheritance,
            cycles,
            structural_entry_points,
            leaves,
            hotspots,
            warnings,
            unresolved_calls,
            stats,
            out_dir / OUTPUT_JSON,
        )
        print(f"\nOutput dir  : {out_dir}")
        print(f"JSON report : {out_dir / OUTPUT_JSON}\n")
        return 0

    onboarding_report = build_onboarding_report(
        root,
        project_name,
        data,
        calls_to,
        max_depth=args.depth,
        max_branches=args.max_branches,
        entry_filter=args.entry,
    )
    print_walkthrough_preview(onboarding_report, out_dir)
    export_onboarding_report(onboarding_report, out_dir)

    if args.walkthrough_only:
        print(f"\nOutput dir  : {out_dir}")
        print(f"Walkthrough : {out_dir / OUTPUT_WALKTHROUGH}\n")
        return 0

    draw_module_graph(data, out_dir / OUTPUT_PNG, project_name)
    draw_call_graph(data, calls_to, called_by, out_dir / OUTPUT_CALLS, project_name)
    draw_hotspots(hotspots, data, out_dir / OUTPUT_HOTSPOTS, project_name)
    export_json(
        data,
        calls_to,
        called_by,
        inheritance,
        cycles,
        structural_entry_points,
        leaves,
        hotspots,
        warnings,
        unresolved_calls,
        stats,
        out_dir / OUTPUT_JSON,
    )
    print(f"\nOutput dir  : {out_dir}")
    print(f"Walkthrough : {out_dir / OUTPUT_WALKTHROUGH}\n")
    return 0


if __name__ == '__main__':
    sys.exit(main())
