import json
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = REPO_ROOT / 'analyze_project.py'
CONSOLE_SCRIPT_NAMES = (
    'analyze-project.exe',
    'analyze-project-script.py',
    'analyze-project',
) if os.name == 'nt' else ('analyze-project',)
EXPECTED_OUTPUTS = {
    'project_analysis.png',
    'project_call_graph.png',
    'project_hotspots.png',
    'project_analysis.json',
}
ONBOARDING_OUTPUTS = {
    'walkthrough.md',
    'execution_flow.json',
    'decision_tree.md',
    'data_flow.md',
}


def run_cli(*args, cwd=None):
    return subprocess.run(
        [sys.executable, str(SCRIPT_PATH), *args],
        cwd=cwd or REPO_ROOT,
        capture_output=True,
        text=True,
    )


def resolve_console_script_path():
    script_dir = Path(sys.executable).parent
    for name in CONSOLE_SCRIPT_NAMES:
        path = script_dir / name
        if path.exists():
            return path
    return script_dir / CONSOLE_SCRIPT_NAMES[0]


def run_console_cli(*args, cwd=None):
    script_path = resolve_console_script_path()
    if not script_path.exists():
        pytest.skip('console script unavailable; install the package first')
    return subprocess.run(
        [str(script_path), *args],
        cwd=cwd or REPO_ROOT,
        capture_output=True,
        text=True,
    )


def write_project_files(base_dir, files):
    for rel_path, content in files.items():
        path = base_dir / rel_path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            textwrap.dedent(content).lstrip('\n'),
            encoding='utf-8',
        )


def create_basic_project(base_dir):
    project_dir = base_dir / f'sample_project_{base_dir.name}'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'alpha.py': """
                from beta import helper

                def run():
                    return helper()

                if __name__ == "__main__":
                    run()
            """,
            'beta.py': """
                def helper():
                    return 42
            """,
        },
    )
    return project_dir


def load_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def test_help_output():
    result = run_cli('--help')
    assert result.returncode == 0
    assert '--summary-only' in result.stdout
    assert '--json-only' in result.stdout
    assert '--include-glob' in result.stdout
    assert '--exclude-dir' in result.stdout
    assert '--show-unresolved' in result.stdout
    assert '--walkthrough-only' in result.stdout
    assert '--entry' in result.stdout
    assert '--max-depth' in result.stdout


def test_console_script_help_output():
    result = run_console_cli('--help')
    assert result.returncode == 0
    assert 'Analyze a Python project' in result.stdout


def test_defaults_to_current_working_directory(tmp_path):
    project_dir = create_basic_project(tmp_path)
    result = run_cli(cwd=project_dir)
    assert result.returncode == 0, result.stderr

    out_dir = project_dir / 'analysis_output' / project_dir.name
    assert out_dir.exists()
    assert EXPECTED_OUTPUTS.issubset({path.name for path in out_dir.iterdir()})
    assert ONBOARDING_OUTPUTS.issubset({path.name for path in out_dir.iterdir()})


def test_generates_expected_outputs_for_sample_project(tmp_path):
    project_dir = create_basic_project(tmp_path)
    result = run_cli(str(project_dir), cwd=tmp_path)
    assert result.returncode == 0, result.stderr

    out_dir = tmp_path / 'analysis_output' / project_dir.name
    assert out_dir.exists()
    assert EXPECTED_OUTPUTS.issubset({path.name for path in out_dir.iterdir()})
    assert ONBOARDING_OUTPUTS.issubset({path.name for path in out_dir.iterdir()})


def test_custom_output_dir_is_respected(tmp_path):
    project_dir = create_basic_project(tmp_path)
    custom_output_dir = tmp_path / 'custom-artifacts'

    result = run_cli(str(project_dir), '--output-dir', str(custom_output_dir))
    assert result.returncode == 0, result.stderr
    assert custom_output_dir.exists()
    assert EXPECTED_OUTPUTS.issubset(
        {path.name for path in custom_output_dir.iterdir()}
    )
    assert ONBOARDING_OUTPUTS.issubset(
        {path.name for path in custom_output_dir.iterdir()}
    )


def test_invalid_directory_returns_non_zero(tmp_path):
    missing_dir = tmp_path / 'missing'
    result = run_cli(str(missing_dir))
    assert result.returncode != 0
    assert 'Not a valid directory' in result.stderr


def test_directory_without_python_files_returns_non_zero(tmp_path):
    empty_dir = tmp_path / 'empty_project'
    empty_dir.mkdir()
    result = run_cli(str(empty_dir))
    assert result.returncode != 0
    assert 'No Python files found' in result.stderr


def test_json_only_writes_only_json_and_schema_fields(tmp_path):
    project_dir = create_basic_project(tmp_path)
    out_dir = tmp_path / 'json-only'

    result = run_cli(str(project_dir), '--json-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    assert out_dir.exists()
    assert {path.name for path in out_dir.iterdir()} == {'project_analysis.json'}

    data = load_json(out_dir / 'project_analysis.json')
    assert data['schema_version'] == '0.2'
    assert 'warnings' in data
    assert 'stats' in data
    assert 'unresolved_calls' in data


def test_summary_only_does_not_create_artifacts(tmp_path):
    project_dir = create_basic_project(tmp_path)
    out_dir = tmp_path / 'summary-only'

    result = run_cli(
        str(project_dir),
        '--summary-only',
        '--output-dir',
        str(out_dir),
    )
    assert result.returncode == 0, result.stderr
    assert not out_dir.exists()
    assert 'PROJECT :' in result.stdout


def test_nested_package_relative_import_and_instance_method_resolution(tmp_path):
    project_dir = tmp_path / 'nested_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'pkg/__init__.py': '',
            'pkg/service.py': """
                class Service:
                    def work(self):
                        return 1
            """,
            'pkg/consumer.py': """
                from .service import Service

                def run():
                    svc = Service()
                    return svc.work()
            """,
            'main.py': """
                from pkg.consumer import run

                def main():
                    return run()
            """,
        },
    )

    out_dir = tmp_path / 'nested-out'
    result = run_cli(str(project_dir), '--json-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    data = load_json(out_dir / 'project_analysis.json')
    assert data['calls_to']['main::main'] == ['pkg.consumer::run']
    assert 'pkg.service::Service' in data['calls_to']['pkg.consumer::run']
    assert 'pkg.service::Service.work' in data['calls_to']['pkg.consumer::run']


def test_from_package_import_submodule_is_not_reported_as_external(tmp_path):
    project_dir = tmp_path / 'package_import_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'pkg/__init__.py': '',
            'pkg/tools.py': """
                def greet():
                    return "hi"
            """,
            'main.py': """
                from pkg import tools

                def main():
                    return tools.greet()
            """,
        },
    )

    out_dir = tmp_path / 'package-import-out'
    result = run_cli(str(project_dir), '--json-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    data = load_json(out_dir / 'project_analysis.json')
    assert 'pkg' not in data['modules']['main']['ext_imports']
    assert data['calls_to']['main::main'] == ['pkg.tools::greet']


def test_unknown_object_method_is_reported_as_unresolved(tmp_path):
    project_dir = tmp_path / 'unresolved_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'main.py': """
                def main(obj):
                    return obj.run()
            """,
        },
    )

    out_dir = tmp_path / 'unresolved-out'
    result = run_cli(
        str(project_dir),
        '--json-only',
        '--show-unresolved',
        '--output-dir',
        str(out_dir),
    )
    assert result.returncode == 0, result.stderr

    data = load_json(out_dir / 'project_analysis.json')
    assert data['stats']['unresolved_calls'] >= 1
    assert any(item['call'] == 'obj.run' for item in data['unresolved_calls'])


def create_onboarding_project(base_dir):
    project_dir = base_dir / 'onboarding_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'README.md': '# Flat alert\n\nMonitors listings and sends alerts.',
            '.env.example': 'TELEGRAM_BOT_TOKEN=super-secret-token\nSEARCH_URL=https://example.test',
            'pyproject.toml': """
                [project]
                name = "flat-alert"
                version = "0.1.0"

                [project.scripts]
                flat-alert = "app.main:main"
            """,
            'app/__init__.py': '',
            'app/config.py': """
                import os

                def load_config():
                    token = os.environ["TELEGRAM_BOT_TOKEN"]
                    url = os.getenv("SEARCH_URL")
                    return {"token": token, "url": url}
            """,
            'app/fetcher.py': """
                import requests

                def fetch_listings(config):
                    response = requests.get(config["url"])
                    return response.json()
            """,
            'app/notify.py': """
                def send_notification(listings):
                    print("sending")
                    return len(listings)
            """,
            'app/main.py': """
                from .config import load_config
                from .fetcher import fetch_listings
                from .notify import send_notification

                def main():
                    config = load_config()
                    listings = fetch_listings(config)
                    if listings:
                        send_notification(listings)
                    else:
                        print("No listings")
                    return listings

                if __name__ == "__main__":
                    main()
            """,
        },
    )
    return project_dir


def test_onboarding_reports_include_entry_flow_data_and_redacted_secrets(tmp_path):
    project_dir = create_onboarding_project(tmp_path)
    out_dir = tmp_path / 'onboarding-out'

    result = run_cli(str(project_dir), '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr
    assert 'Walkthrough' in result.stdout
    assert ONBOARDING_OUTPUTS.issubset({path.name for path in out_dir.iterdir()})

    flow = load_json(out_dir / 'execution_flow.json')
    assert flow['project'] == project_dir.name
    assert flow['entry_points'][0]['reason'] == 'Found in pyproject.toml project.scripts'
    functions = [node['function'] for node in flow['entry_points'][0]['flow']]
    assert functions[:4] == ['main', 'load_config', 'fetch_listings', 'send_notification']
    assert all(node['confidence'] in {'high', 'medium', 'low'} for node in flow['entry_points'][0]['flow'])
    assert all('evidence' in node for node in flow['entry_points'][0]['flow'])

    walkthrough = (out_dir / 'walkthrough.md').read_text(encoding='utf-8')
    assert '# Project Walkthrough' in walkthrough
    assert '## Project Purpose Guess' in walkthrough
    assert '## How to Run' in walkthrough
    assert '## Unknowns / Static Analysis Limits' in walkthrough
    assert 'TELEGRAM_BOT_TOKEN=***' in walkthrough
    assert 'super-secret-token' not in walkthrough

    decision_tree = (out_dir / 'decision_tree.md').read_text(encoding='utf-8')
    assert 'Condition: listings' in decision_tree

    data_flow = (out_dir / 'data_flow.md').read_text(encoding='utf-8')
    assert '`config` is produced by `load_config()` and passed into `fetch_listings()`' in data_flow
    assert '`listings` is produced by `fetch_listings()` and passed into `send_notification()`' in data_flow


def test_walkthrough_only_writes_only_onboarding_outputs(tmp_path):
    project_dir = create_basic_project(tmp_path)
    out_dir = tmp_path / 'walkthrough-only'

    result = run_cli(str(project_dir), '--walkthrough-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr
    assert {path.name for path in out_dir.iterdir()} == ONBOARDING_OUTPUTS


def test_recursive_function_is_reported_without_infinite_flow(tmp_path):
    project_dir = tmp_path / 'recursive_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'main.py': """
                def main():
                    return loop()

                def loop():
                    return loop()

                if __name__ == "__main__":
                    main()
            """,
        },
    )
    out_dir = tmp_path / 'recursive-out'

    result = run_cli(str(project_dir), '--walkthrough-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    flow = load_json(out_dir / 'execution_flow.json')
    nodes = flow['entry_points'][0]['flow']
    assert len(nodes) < 10
    assert any(node['recursion_detected'] for node in nodes)


def test_external_calls_are_side_effects_not_local_tree_nodes(tmp_path):
    project_dir = tmp_path / 'external_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'main.py': """
                import requests

                def main():
                    requests.get("https://example.test")
                    return helper()

                def helper():
                    return 1

                if __name__ == "__main__":
                    main()
            """,
        },
    )
    out_dir = tmp_path / 'external-out'

    result = run_cli(str(project_dir), '--walkthrough-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    flow = load_json(out_dir / 'execution_flow.json')
    main_node = flow['entry_points'][0]['flow'][0]
    assert [call['function'] for call in main_node['calls']] == ['helper']
    assert 'requests.get' in main_node['external_calls']
    assert any('network_request' in effect for effect in main_node['side_effects'])


def test_syntax_error_file_emits_warning_and_analysis_continues(tmp_path):
    project_dir = tmp_path / 'syntax_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'good.py': """
                def ok():
                    return 1
            """,
            'broken.py': """
                def nope(
            """,
        },
    )

    out_dir = tmp_path / 'syntax-out'
    result = run_cli(str(project_dir), '--json-only', '--output-dir', str(out_dir))
    assert result.returncode == 0, result.stderr

    data = load_json(out_dir / 'project_analysis.json')
    assert data['stats']['syntax_error_files'] == 1
    assert any(item['code'] == 'syntax-error' for item in data['warnings'])
    assert 'good' in data['modules']


def test_include_glob_and_exclude_dir_filter_scanned_files(tmp_path):
    project_dir = tmp_path / 'filter_project'
    project_dir.mkdir()
    write_project_files(
        project_dir,
        {
            'a.py': """
                def a():
                    return 1
            """,
            'keep/b.py': """
                def b():
                    return 2
            """,
            'skipme/c.py': """
                def c():
                    return 3
            """,
        },
    )

    out_dir = tmp_path / 'filter-out'
    result = run_cli(
        str(project_dir),
        '--json-only',
        '--include-glob',
        'keep/*.py',
        '--exclude-dir',
        'skipme',
        '--output-dir',
        str(out_dir),
    )
    assert result.returncode == 0, result.stderr

    data = load_json(out_dir / 'project_analysis.json')
    assert data['stats']['files_scanned'] == 1
    assert set(data['modules']) == {'keep.b'}
