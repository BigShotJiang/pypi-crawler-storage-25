"""Tests for MCP transport implementations."""

import asyncio
import json
import os
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openlaoke.core.tool import ToolRegistry
from openlaoke.services.mcp import (
    ConnectionState,
    MCPServerConfig,
    MCPServerConnection,
    MCPService,
    OAuthConfig,
    OAuthState,
    OAuthTokens,
    TransportType,
)


@pytest.fixture
def registry():
    return ToolRegistry()


@pytest.fixture
def mcp_service(registry):
    return MCPService(registry)


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


class TestTransportType:
    def test_transport_types(self):
        assert TransportType.STDIO == "stdio"
        assert TransportType.SSE == "sse"
        assert TransportType.HTTP == "http"
        assert TransportType.WS == "ws"

    def test_transport_type_values(self):
        types = [t.value for t in TransportType]
        assert "stdio" in types
        assert "sse" in types
        assert "http" in types
        assert "ws" in types


class TestConnectionState:
    def test_connection_states(self):
        assert ConnectionState.CONNECTED == "connected"
        assert ConnectionState.DISCONNECTED == "disconnected"
        assert ConnectionState.FAILED == "failed"
        assert ConnectionState.NEEDS_AUTH == "needs_auth"

    def test_all_states(self):
        states = [s.value for s in ConnectionState]
        assert len(states) == 6


class TestOAuthConfig:
    def test_default_config(self):
        config = OAuthConfig()
        assert config.client_id is None
        assert config.client_secret is None
        assert config.scope is None
        assert config.redirect_uri == "http://127.0.0.1:19876/mcp/oauth/callback"

    def test_custom_config(self):
        config = OAuthConfig(
            client_id="test_client",
            client_secret="test_secret",
            scope="read write",
            redirect_uri="http://custom.uri/callback",
        )
        assert config.client_id == "test_client"
        assert config.client_secret == "test_secret"
        assert config.scope == "read write"
        assert config.redirect_uri == "http://custom.uri/callback"


class TestOAuthTokens:
    def test_default_tokens(self):
        tokens = OAuthTokens(access_token="token123")
        assert tokens.access_token == "token123"
        assert tokens.refresh_token is None
        assert tokens.expires_at is None
        assert tokens.scope is None

    def test_full_tokens(self):
        tokens = OAuthTokens(
            access_token="access",
            refresh_token="refresh",
            expires_at=12345.0,
            scope="read",
        )
        assert tokens.access_token == "access"
        assert tokens.refresh_token == "refresh"
        assert tokens.expires_at == 12345.0


class TestOAuthState:
    def test_default_state(self):
        state = OAuthState()
        assert state.code_verifier is None
        assert state.state is None
        assert state.tokens is None

    def test_with_tokens(self):
        tokens = OAuthTokens(access_token="test")
        state = OAuthState(code_verifier="verifier", state="state123", tokens=tokens)
        assert state.code_verifier == "verifier"
        assert state.state == "state123"
        assert state.tokens.access_token == "test"


class TestMCPServerConfig:
    def test_stdio_config(self):
        config = MCPServerConfig(
            name="test",
            transport=TransportType.STDIO,
            command="python",
            args=["-m", "mcp_server"],
        )
        assert config.name == "test"
        assert config.transport == TransportType.STDIO
        assert config.command == "python"
        assert config.args == ["-m", "mcp_server"]
        assert config.enabled

    def test_http_config(self):
        config = MCPServerConfig(
            name="http_test",
            transport=TransportType.HTTP,
            url="http://localhost:8080/mcp",
            headers={"Authorization": "Bearer token"},
        )
        assert config.name == "http_test"
        assert config.transport == TransportType.HTTP
        assert config.url == "http://localhost:8080/mcp"
        assert "Authorization" in config.headers

    def test_sse_config(self):
        config = MCPServerConfig(
            name="sse_test",
            transport=TransportType.SSE,
            url="http://localhost:8080/sse",
        )
        assert config.transport == TransportType.SSE

    def test_ws_config(self):
        config = MCPServerConfig(
            name="ws_test",
            transport=TransportType.WS,
            url="ws://localhost:8080/ws",
        )
        assert config.transport == TransportType.WS

    def test_oauth_config(self):
        oauth = OAuthConfig(client_id="client123")
        config = MCPServerConfig(
            name="oauth_test",
            transport=TransportType.HTTP,
            url="http://example.com/mcp",
            oauth=oauth,
        )
        assert config.oauth.client_id == "client123"

    def test_disabled_config(self):
        config = MCPServerConfig(name="disabled", enabled=False)
        assert not config.enabled

    def test_timeout_config(self):
        config = MCPServerConfig(name="timeout_test", timeout=60000)
        assert config.timeout == 60000

    def test_env_vars(self):
        config = MCPServerConfig(
            name="env_test",
            env={"API_KEY": "secret", "DEBUG": "1"},
        )
        assert config.env["API_KEY"] == "secret"
        assert config.env["DEBUG"] == "1"


class TestMCPServerConnection:
    def test_default_connection(self):
        config = MCPServerConfig(name="test")
        conn = MCPServerConnection(config=config)
        assert conn.config.name == "test"
        assert conn.state == ConnectionState.DISCONNECTED
        assert conn.tools == []
        assert conn.process is None
        assert conn.error is None

    def test_connection_with_oauth_state(self):
        config = MCPServerConfig(name="oauth_test", oauth=OAuthConfig())
        oauth_state = OAuthState()
        conn = MCPServerConnection(config=config, oauth_state=oauth_state)
        assert conn.oauth_state is not None

    def test_connection_state_changes(self):
        config = MCPServerConfig(name="test")
        conn = MCPServerConnection(config=config)
        conn.state = ConnectionState.CONNECTED
        assert conn.state == ConnectionState.CONNECTED

        conn.state = ConnectionState.FAILED
        assert conn.state == ConnectionState.FAILED


class TestMCPService:
    def test_service_initialization(self, mcp_service):
        assert mcp_service.registry is not None
        assert mcp_service.servers == {}
        assert mcp_service._config_path.endswith("mcp_servers.json")
        assert mcp_service._auth_path.endswith("mcp_auth.json")

    def test_oauth_callback_port(self, mcp_service):
        assert mcp_service.OAUTH_CALLBACK_PORT == 19876
        assert mcp_service.OAUTH_CALLBACK_PATH == "/mcp/oauth/callback"

    @pytest.mark.asyncio
    async def test_load_empty_config(self, mcp_service, temp_dir):
        config_path = os.path.join(temp_dir, "mcp_servers.json")
        mcp_service._config_path = config_path

        await mcp_service.load_config()
        assert mcp_service.servers == {}

    @pytest.mark.asyncio
    async def test_load_config_with_servers(self, mcp_service, temp_dir):
        config_path = os.path.join(temp_dir, "mcp_servers.json")
        config_data = {
            "mcpServers": {
                "test_server": {
                    "transport": "stdio",
                    "command": "python",
                    "args": ["-m", "test"],
                    "enabled": True,
                }
            }
        }
        with open(config_path, "w") as f:
            json.dump(config_data, f)

        mcp_service._config_path = config_path
        await mcp_service.load_config()

        assert "test_server" in mcp_service.servers
        assert mcp_service.servers["test_server"].config.transport == TransportType.STDIO

    @pytest.mark.asyncio
    async def test_load_config_http_transport(self, mcp_service, temp_dir):
        config_path = os.path.join(temp_dir, "mcp_servers.json")
        config_data = {
            "mcpServers": {
                "http_server": {
                    "transport": "http",
                    "url": "http://localhost:8080/mcp",
                }
            }
        }
        with open(config_path, "w") as f:
            json.dump(config_data, f)

        mcp_service._config_path = config_path
        await mcp_service.load_config()

        assert mcp_service.servers["http_server"].config.transport == TransportType.HTTP

    @pytest.mark.asyncio
    async def test_load_config_oauth(self, mcp_service, temp_dir):
        config_path = os.path.join(temp_dir, "mcp_servers.json")
        config_data = {
            "mcpServers": {
                "oauth_server": {
                    "transport": "http",
                    "url": "http://example.com/mcp",
                    "oauth": {
                        "clientId": "test_client",
                        "scope": "read",
                    },
                }
            }
        }
        with open(config_path, "w") as f:
            json.dump(config_data, f)

        mcp_service._config_path = config_path
        await mcp_service.load_config()

        conn = mcp_service.servers["oauth_server"]
        assert conn.config.oauth is not None
        assert conn.config.oauth.client_id == "test_client"

    @pytest.mark.asyncio
    async def test_connect_disabled_server(self, mcp_service):
        config = MCPServerConfig(name="disabled", enabled=False)
        conn = MCPServerConnection(config=config)
        mcp_service.servers["disabled"] = conn

        result = await mcp_service.connect_server("disabled")
        assert result.state == ConnectionState.DISABLED

    @pytest.mark.asyncio
    async def test_connect_nonexistent_server(self, mcp_service):
        result = await mcp_service.connect_server("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_disconnect_all(self, mcp_service):
        config = MCPServerConfig(name="test", transport=TransportType.HTTP, url="http://test")
        conn = MCPServerConnection(config=config)
        conn._http_client = AsyncMock()
        conn._http_client.aclose = AsyncMock()
        mcp_service.servers["test"] = conn

        await mcp_service.disconnect_all()
        assert conn._http_client is None

    def test_get_server_status_empty(self, mcp_service):
        status = mcp_service.get_server_status()
        assert status == []

    def test_get_server_status_with_servers(self, mcp_service):
        config1 = MCPServerConfig(name="server1")
        config2 = MCPServerConfig(name="server2")
        conn1 = MCPServerConnection(config=config1, state=ConnectionState.CONNECTED)
        conn2 = MCPServerConnection(config=config2, state=ConnectionState.DISCONNECTED)

        mcp_service.servers["server1"] = conn1
        mcp_service.servers["server2"] = conn2

        status = mcp_service.get_server_status()
        assert len(status) == 2
        assert any(s["name"] == "server1" and s["state"] == "connected" for s in status)
        assert any(s["name"] == "server2" and s["state"] == "disconnected" for s in status)

    def test_supports_oauth_stdio_false(self, mcp_service):
        config = MCPServerConfig(name="stdio", transport=TransportType.STDIO)
        conn = MCPServerConnection(config=config)
        mcp_service.servers["stdio"] = conn

        assert not mcp_service.supports_oauth("stdio")

    def test_supports_oauth_http_true(self, mcp_service):
        config = MCPServerConfig(name="http", transport=TransportType.HTTP, url="http://test")
        conn = MCPServerConnection(config=config)
        mcp_service.servers["http"] = conn

        assert mcp_service.supports_oauth("http")

    def test_supports_oauth_disabled(self, mcp_service):
        config = MCPServerConfig(
            name="disabled_oauth", transport=TransportType.HTTP, url="http://test", oauth=False
        )
        conn = MCPServerConnection(config=config)
        mcp_service.servers["disabled_oauth"] = conn

        assert not mcp_service.supports_oauth("disabled_oauth")

    def test_has_stored_tokens_false(self, mcp_service):
        config = MCPServerConfig(name="test")
        conn = MCPServerConnection(config=config)
        mcp_service.servers["test"] = conn

        assert not mcp_service.has_stored_tokens("test")

    def test_has_stored_tokens_true(self, mcp_service):
        config = MCPServerConfig(name="test")
        oauth_state = OAuthState(tokens=OAuthTokens(access_token="token"))
        conn = MCPServerConnection(config=config, oauth_state=oauth_state)
        mcp_service.servers["test"] = conn

        assert mcp_service.has_stored_tokens("test")

    def test_build_headers_no_auth(self, mcp_service):
        config = MCPServerConfig(name="test", headers={"X-Custom": "value"})
        conn = MCPServerConnection(config=config)
        mcp_service.servers["test"] = conn

        headers = mcp_service._build_headers(conn)
        assert headers["X-Custom"] == "value"
        assert "Authorization" not in headers

    def test_build_headers_with_auth(self, mcp_service):
        config = MCPServerConfig(name="test")
        oauth_state = OAuthState(tokens=OAuthTokens(access_token="test_token"))
        conn = MCPServerConnection(config=config, oauth_state=oauth_state)
        mcp_service.servers["test"] = conn

        headers = mcp_service._build_headers(conn)
        assert headers["Authorization"] == "Bearer test_token"

    def test_nonexistent_server_oauth_check(self, mcp_service):
        assert not mcp_service.supports_oauth("nonexistent")
        assert not mcp_service.has_stored_tokens("nonexistent")


class TestSSETransport:
    @pytest.mark.asyncio
    async def test_sse_connection_success(self, mcp_service):
        config = MCPServerConfig(
            name="sse_test", transport=TransportType.SSE, url="http://localhost:8080/sse"
        )
        conn = MCPServerConnection(config=config)
        mcp_service.servers["sse_test"] = conn

        with patch("httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.raise_for_status = MagicMock()

            mock_client_instance = AsyncMock()
            mock_client_instance.get = AsyncMock(return_value=mock_response)
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            await mcp_service._connect_sse(conn)
            assert conn.state == ConnectionState.CONNECTED

    @pytest.mark.asyncio
    async def test_sse_needs_auth(self, mcp_service):
        config = MCPServerConfig(
            name="sse_auth", transport=TransportType.SSE, url="http://localhost:8080/sse"
        )
        conn = MCPServerConnection(config=config)
        mcp_service.servers["sse_auth"] = conn

        with patch("httpx.AsyncClient") as mock_client:
            from httpx import HTTPStatusError, Request, Response

            mock_response = MagicMock()
            mock_response.status_code = 401

            mock_client_instance = AsyncMock()
            http_error = HTTPStatusError(
                message="401 Unauthorized",
                request=MagicMock(),
                response=mock_response,
            )
            mock_client_instance.get = AsyncMock(side_effect=http_error)
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            try:
                await mcp_service._connect_sse(conn)
            except Exception:
                pass

            assert conn.state in (
                ConnectionState.NEEDS_AUTH,
                ConnectionState.FAILED,
                ConnectionState.DISCONNECTED,
            )


class TestHTTPTransport:
    @pytest.mark.asyncio
    async def test_http_request(self, mcp_service):
        config = MCPServerConfig(
            name="http_test", transport=TransportType.HTTP, url="http://localhost:8080/mcp"
        )
        conn = MCPServerConnection(config=config)

        with patch("httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.json = MagicMock(return_value={"result": "success"})
            mock_response.raise_for_status = MagicMock()

            mock_client_instance = AsyncMock()
            mock_client_instance.post = AsyncMock(return_value=mock_response)
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            conn._http_client = mock_client_instance

            result = await mcp_service._http_request(conn, "test_method", {"param": "value"})
            assert result["result"] == "success"


class TestWebSocketTransport:
    @pytest.mark.asyncio
    async def test_ws_request(self, mcp_service):
        config = MCPServerConfig(
            name="ws_test", transport=TransportType.WS, url="ws://localhost:8080/ws"
        )
        conn = MCPServerConnection(config=config)

        mock_ws = AsyncMock()
        mock_ws.send = AsyncMock()
        mock_ws.recv = AsyncMock(return_value=json.dumps({"result": "ws_success"}))
        conn._ws_connection = mock_ws

        result = await mcp_service._ws_request(conn, "test_method", {"param": "value"})
        assert result["result"] == "ws_success"


class TestOAuthFlow:
    @pytest.mark.asyncio
    async def test_start_oauth_flow(self, mcp_service):
        config = MCPServerConfig(
            name="oauth_test",
            transport=TransportType.HTTP,
            url="http://example.com/mcp",
            oauth=OAuthConfig(client_id="test_client", scope="read write"),
        )
        conn = MCPServerConnection(config=config)
        mcp_service.servers["oauth_test"] = conn

        auth_url, state = await mcp_service.start_oauth_flow("oauth_test")

        assert "authorize" in auth_url
        assert state is not None
        assert conn.oauth_state is not None
        assert conn.oauth_state.code_verifier is not None

    @pytest.mark.asyncio
    async def test_start_oauth_flow_disabled(self, mcp_service):
        config = MCPServerConfig(
            name="oauth_disabled",
            transport=TransportType.HTTP,
            url="http://example.com/mcp",
            oauth=False,
        )
        conn = MCPServerConnection(config=config)
        mcp_service.servers["oauth_disabled"] = conn

        with pytest.raises(ValueError, match="OAuth disabled"):
            await mcp_service.start_oauth_flow("oauth_disabled")

    @pytest.mark.asyncio
    async def test_start_oauth_flow_nonexistent(self, mcp_service):
        with pytest.raises(ValueError, match="not found"):
            await mcp_service.start_oauth_flow("nonexistent")

    @pytest.mark.asyncio
    async def test_finish_oauth_flow(self, mcp_service, temp_dir):
        auth_path = os.path.join(temp_dir, "mcp_auth.json")
        mcp_service._auth_path = auth_path

        config = MCPServerConfig(
            name="oauth_finish",
            transport=TransportType.HTTP,
            url="http://example.com/mcp",
            oauth=OAuthConfig(client_id="test_client"),
        )
        oauth_state = OAuthState(code_verifier="test_verifier", state="test_state")
        conn = MCPServerConnection(config=config, oauth_state=oauth_state)
        mcp_service.servers["oauth_finish"] = conn
        mcp_service._oauth_transports["oauth_finish"] = conn

        with patch("httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.json = MagicMock(
                return_value={"access_token": "new_token", "refresh_token": "refresh"}
            )
            mock_response.raise_for_status = MagicMock()

            mock_client_instance = AsyncMock()
            mock_client_instance.post = AsyncMock(return_value=mock_response)
            mock_client_instance.aclose = AsyncMock()
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            with patch.object(mcp_service, "connect_server", AsyncMock()):
                result = await mcp_service.finish_oauth_flow("oauth_finish", "test_code")

        assert conn.oauth_state.tokens is not None
        assert conn.oauth_state.tokens.access_token == "new_token"

    @pytest.mark.asyncio
    async def test_remove_auth(self, mcp_service):
        config = MCPServerConfig(name="auth_test", transport=TransportType.HTTP, url="http://test")
        oauth_state = OAuthState(tokens=OAuthTokens(access_token="token"))
        conn = MCPServerConnection(config=config, oauth_state=oauth_state)
        mcp_service.servers["auth_test"] = conn
        mcp_service._oauth_transports["auth_test"] = conn

        await mcp_service.remove_auth("auth_test")
        assert conn.oauth_state is None
        assert "auth_test" not in mcp_service._oauth_transports


class TestSTDIOTransport:
    @pytest.mark.asyncio
    async def test_stdio_request_format(self, mcp_service):
        config = MCPServerConfig(name="stdio_test", transport=TransportType.STDIO, command="test")
        conn = MCPServerConnection(config=config)

        mock_process = AsyncMock()
        mock_process.stdin = AsyncMock()
        mock_process.stdin.write = MagicMock()
        mock_process.stdin.drain = AsyncMock()
        mock_process.stdout = AsyncMock()
        mock_process.stdout.readline = AsyncMock(
            return_value=json.dumps({"result": "stdio_test"}).encode()
        )

        conn.process = mock_process

        result = await mcp_service._stdio_request(conn, "test", {"param": 1})
        assert result["result"] == "stdio_test"

        call_args = mock_process.stdin.write.call_args[0][0]
        request = json.loads(call_args.decode())
        assert request["jsonrpc"] == "2.0"
        assert request["method"] == "test"

    @pytest.mark.asyncio
    async def test_stdio_request_timeout(self, mcp_service):
        config = MCPServerConfig(
            name="stdio_timeout", transport=TransportType.STDIO, command="test"
        )
        conn = MCPServerConnection(config=config)

        mock_process = AsyncMock()
        mock_process.stdin = AsyncMock()
        mock_process.stdin.write = MagicMock()
        mock_process.stdin.drain = AsyncMock()
        mock_process.stdout = AsyncMock()
        mock_process.stdout.readline = AsyncMock(side_effect=asyncio.TimeoutError())

        conn.process = mock_process

        with pytest.raises(asyncio.TimeoutError):
            await mcp_service._stdio_request(conn, "test", {}, timeout=1.0)
