"""Comprehensive tests for HyperAuto system."""

from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openlaoke.core.hyperauto.agent import AnalysisResult, HyperAutoAgent, SkillGenerationResult
from openlaoke.core.hyperauto.code_search import (
    CodeSearchEngine,
    CodeSnippet,
    SearchSource,
    SearchResult,
)
from openlaoke.core.hyperauto.config import HyperAutoConfig
from openlaoke.core.hyperauto.decision_engine import (
    Context,
    DecisionCategory,
    DecisionEngine,
    DecisionOption,
    DecisionRecord,
    RiskAssessment,
    RiskLevel,
)
from openlaoke.core.hyperauto.learning import (
    EnhancedStrategy,
    Experience,
    ExperienceType,
    Knowledge,
    KnowledgeCategory,
    LearningSession,
    LearningSystem,
    Pattern,
    PatternType,
    Strategy,
    StrategyType,
)
from openlaoke.core.hyperauto.project_initializer import (
    InitResult,
    ProjectAnalysis,
    ProjectInitializer,
    ProjectType,
)
from openlaoke.core.hyperauto.reflection import (
    Analysis,
    Correction,
    CorrectionStatus,
    Error,
    ErrorCategory,
    ErrorSeverity,
    Improvement,
    ImprovementPriority,
    QualityDimension,
    QualityScore,
    ReflectionReport,
    ReflectionSystem,
    Review,
    ReviewType,
)
from openlaoke.core.hyperauto.skill_generator import (
    GenerationResult,
    SkillDesign,
    SkillGenerator,
    SkillParameter,
    SkillRequirement,
    SkillTrigger,
)
from openlaoke.core.hyperauto.test_runner import (
    AutoTestRunner,
    CoverageReport,
    Diagnosis,
    TestAnalysis,
    TestCycleResult,
    TestFailure,
    TestFramework,
    TestInfo,
    TestResults,
    TestSeverity,
    TestStatus,
)
from openlaoke.core.hyperauto.types import (
    Decision,
    DecisionType,
    HyperAutoMode,
    HyperAutoState,
    Reflection,
    SubTask,
    SubTaskStatus,
    WorkflowContext,
)
from openlaoke.core.hyperauto.validator import (
    Artifact,
    Language,
    Requirements,
    ResultValidator,
    SecurityReport,
    ValidationCategory,
    ValidationIssue,
    ValidationLevel,
    ValidationResult,
    ValidatorQualityScore,
)
from openlaoke.core.hyperauto.workflow import (
    DependencyEdge,
    DependencyGraph,
    ExecutionPlan,
    ExecutionResult,
    ExecutionStep,
    ProgressInfo,
    RecoveryAction,
    RecoveryStrategy,
    TaskTree,
    WorkflowOrchestrator,
    WorkflowPhase,
    WorkflowResult,
)
from openlaoke.core.state import AppState, create_app_state


class TestHyperAutoAgent:
    def test_agent_creation(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)
            assert agent.app_state == state
            assert agent.config is not None
            assert agent.context is not None

    def test_agent_creation_with_config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            config = HyperAutoConfig(dry_run=True)
            agent = HyperAutoAgent(state, config)
            assert agent.config.dry_run is True

    @pytest.mark.asyncio
    async def test_analyze_request(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)
            agent.context.original_request = "Create a new function"

            result = await agent._analyze_request()

            assert result.task_type == "creation"
            assert len(result.sub_tasks) > 0
            assert result.confidence > 0

    @pytest.mark.asyncio
    async def test_generate_skills(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)

            content = await agent._generate_skill_content("test_skill", "A test skill")

            assert "test_skill" in content
            assert "A test skill" in content

    @pytest.mark.asyncio
    async def test_initialize_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)

            result = await agent._initialize_project(tmpdir, "python")

            assert result["initialized"] is True
            assert result["type"] == "python"

    @pytest.mark.asyncio
    async def test_search_code(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)

            results = await agent._search_code("test query", "*.py")

            assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_execute_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            config = HyperAutoConfig(dry_run=True, max_iterations=2)
            agent = HyperAutoAgent(state, config)

            result = await agent.run("Create a test function")

            assert "success" in result
            assert "session_id" in result

    @pytest.mark.asyncio
    async def test_reflection(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            config = HyperAutoConfig(reflection_enabled=True)
            agent = HyperAutoAgent(state, config)

            task = SubTask(name="test", description="Test task")
            task.status = SubTaskStatus.COMPLETED
            task.result = {"done": True}
            agent.context.sub_tasks.append(task)

            reflection = await agent._reflect()

            assert len(reflection.observations) > 0

    @pytest.mark.asyncio
    async def test_learning(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            config = HyperAutoConfig(learning_enabled=True)
            agent = HyperAutoAgent(state, config)

            reflection = Reflection(
                task_id="test",
                success=True,
                learned_patterns=["pattern1", "pattern2"],
            )
            agent.context.reflections.append(reflection)

            result = await agent._learn()

            assert "patterns_learned" in result

    def test_decision_making(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            agent = HyperAutoAgent(state)

            task_type = agent._classify_task("Create a new feature")
            assert task_type == "creation"

            task_type = agent._classify_task("Fix the bug in the code")
            assert task_type == "bugfix"

    @pytest.mark.asyncio
    async def test_full_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            config = HyperAutoConfig(dry_run=True, max_iterations=2)
            agent = HyperAutoAgent(state, config)

            result = await agent.run("Test task")

            assert "success" in result
            assert result.get("session_id") is not None


class TestSkillGenerator:
    def test_analyze_skill_needs(self):
        generator = SkillGenerator()

        requirements = generator.analyze_skill_needs("Write tests for the new feature")

        assert len(requirements) > 0
        assert any(r.task_type == "testing" for r in requirements)

    def test_design_skill(self):
        generator = SkillGenerator()

        requirement = SkillRequirement(
            task_type="testing",
            description="Test task",
            keywords=["test", "testing"],
            suggested_tools=["bash", "read"],
        )

        design = generator.design_skill(requirement)

        assert design.name != ""
        assert len(design.triggers) > 0
        assert len(design.capabilities) > 0

    def test_generate_content(self):
        generator = SkillGenerator()

        design = SkillDesign(
            name="test_skill",
            description="A test skill",
            capabilities=["Test capability"],
            workflow_steps=["Step 1", "Step 2"],
        )

        content = generator.generate_skill_content(design)

        assert "---" in content
        assert "test_skill" in content
        assert "A test skill" in content

    def test_validate_skill(self):
        generator = SkillGenerator()

        valid_content = """---
name: test_skill
description: A test skill
---

# Test Skill

This is a valid skill content with enough text to pass validation.
The body content needs to be at least 100 characters long to be valid.
We add more content here to ensure the validation passes successfully.
"""

        result = generator.validate_skill(valid_content)
        assert result.result is True

        invalid_content = "Too short"
        result = generator.validate_skill(invalid_content)
        assert result.result is False

    def test_register_skill(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            generator = SkillGenerator(skill_dir=Path(tmpdir))

            content = """---
name: test_skill
description: A test skill
---

# Test Skill

This is a test skill content with enough text to pass validation.
The body content needs to be at least 100 characters long to be valid.
We add more content here to ensure the registration passes successfully.
"""

            result = generator.register_skill(content, "test_skill")
            assert result.success is True

    def test_auto_generate(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            generator = SkillGenerator(skill_dir=Path(tmpdir))

            skills = generator.auto_generate_for_task(
                "Write unit tests for authentication",
                register=False,
            )

            assert len(skills) >= 0

    def test_skill_template_format(self):
        generator = SkillGenerator()

        requirement = SkillRequirement(
            task_type="code_review",
            description="Review code",
            keywords=["review"],
            suggested_tools=["read", "grep"],
        )

        design = generator.design_skill(requirement)
        content = generator.generate_skill_content(design)

        assert "##" in content
        assert "Workflow" in content

    def test_skill_yaml_frontmatter(self):
        generator = SkillGenerator()

        design = SkillDesign(
            name="yaml_test",
            description="YAML test",
            version="1.0.0",
        )

        content = generator.generate_skill_content(design)

        assert content.startswith("---")
        parts = content.split("---")
        assert len(parts) >= 3


class TestProjectInitializer:
    def test_detect_project_type_python(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "pyproject.toml").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))

            assert project_type == ProjectType.PYTHON

    def test_detect_project_type_nodejs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "package.json").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))

            assert project_type == ProjectType.NODE_JS

    def test_detect_project_type_go(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "go.mod").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))

            assert project_type == ProjectType.GO

    def test_detect_project_type_rust(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "Cargo.toml").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))

            assert project_type == ProjectType.RUST

    def test_analyze_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "pyproject.toml").touch()

            analysis = initializer.analyze_project(Path(tmpdir))

            assert analysis.project_type == ProjectType.PYTHON
            assert isinstance(analysis.has_git, bool)
            assert isinstance(analysis.has_readme, bool)

    def test_create_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()

            result = initializer.create_project_structure(Path(tmpdir), ProjectType.PYTHON)

            assert result is True

    def test_generate_config_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()

            analysis = ProjectAnalysis(
                project_type=ProjectType.PYTHON,
                path=Path(tmpdir),
                has_git=False,
                has_readme=False,
                has_agents_md=False,
            )

            configs = initializer.generate_config_files(analysis)

            assert ".gitignore" in configs
            assert "README.md" in configs
            assert "AGENTS.md" in configs

    def test_install_dependencies(self):
        initializer = ProjectInitializer()

        result = initializer.install_dependencies(ProjectType.PYTHON)

        assert isinstance(result, bool)

    @pytest.mark.asyncio
    async def test_auto_initialize(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()

            result = await initializer.auto_initialize(Path(tmpdir))

            assert isinstance(result, InitResult)
            assert result.project_type is not None

    def test_python_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "pyproject.toml").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))
            assert project_type == ProjectType.PYTHON

    def test_nodejs_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "package.json").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))
            assert project_type == ProjectType.NODE_JS

    def test_go_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "go.mod").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))
            assert project_type == ProjectType.GO

    def test_rust_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            initializer = ProjectInitializer()
            Path(tmpdir, "Cargo.toml").touch()

            project_type = initializer.detect_project_type(Path(tmpdir))
            assert project_type == ProjectType.RUST


class TestCodeSearchEngine:
    def test_search_local(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir, "test.py")
            test_file.write_text("def hello():\n    print('hello')\n")

            engine = CodeSearchEngine(project_path=Path(tmpdir))
            results = engine.search_local("hello", max_results=10)

            assert isinstance(results, list)

    def test_search_reference_projects(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            ref_dir = Path(tmpdir, "reference")
            ref_dir.mkdir()
            Path(ref_dir, "test.py").write_text("def test_func():\n    pass\n")

            engine = CodeSearchEngine(
                project_path=Path(tmpdir),
                reference_projects=[ref_dir],
            )
            results = engine.search_reference_projects("test_func", max_results=10)

            assert isinstance(results, list)

    @pytest.mark.asyncio
    async def test_search_github(self):
        engine = CodeSearchEngine()

        results = await engine.search_github("test query", max_results=5)

        assert isinstance(results, list)

    def test_analyze_reusability(self):
        engine = CodeSearchEngine()

        snippet = CodeSnippet(
            source="local",
            file_path="test.py",
            language="python",
            content="def test():\n    return 1\n",
            description="Test function",
        )

        score = engine.analyze_reusability(snippet)

        assert 0.0 <= score <= 1.0

    def test_adapt_code(self):
        engine = CodeSearchEngine()

        snippet = CodeSnippet(
            source="local",
            file_path="test.py",
            language="python",
            content="def old_name():\n    return 1\n",
            description="Test function",
        )

        context = {"rename_map": {"old_name": "new_name"}}
        adapted = engine.adapt_code(snippet, context)

        assert "new_name" in adapted

    @pytest.mark.asyncio
    async def test_auto_search(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = CodeSearchEngine(project_path=Path(tmpdir))

            results = await engine.auto_search_and_adapt(
                "test query",
                {"language": "python"},
                max_results=5,
            )

            assert isinstance(results, list)

    def test_semantic_search(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = CodeSearchEngine(project_path=Path(tmpdir))

            results = engine.search_semantic("test query", max_results=10)

            assert isinstance(results, list)

    def test_result_ranking(self):
        engine = CodeSearchEngine()

        snippets = [
            CodeSnippet(
                source="local",
                file_path="test1.py",
                language="python",
                content="first unique content",
                description="Low relevance",
                relevance_score=0.3,
            ),
            CodeSnippet(
                source="local",
                file_path="test2.py",
                language="python",
                content="second unique content",
                description="High relevance",
                relevance_score=0.9,
            ),
        ]

        results = engine._deduplicate(snippets)
        assert len(results) == 2


class TestWorkflowOrchestrator:
    def test_decompose_task(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            tree = orchestrator.decompose_task("Create a new feature")

            assert tree.root_task == "Create a new feature"
            assert len(tree.subtasks) > 0

    def test_analyze_dependencies(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task1 = SubTask(name="task1", description="First task")
            task2 = SubTask(name="task2", description="Second task", dependencies=[task1.id])
            orchestrator.context.sub_tasks = [task1, task2]

            graph = orchestrator.analyze_dependencies([task1, task2])

            assert len(graph.nodes) == 2
            assert len(graph.edges) == 1

    def test_create_execution_plan(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task1 = SubTask(name="task1", description="First task")
            task2 = SubTask(name="task2", description="Second task", dependencies=[task1.id])
            orchestrator.context.sub_tasks = [task1, task2]

            graph = orchestrator.analyze_dependencies([task1, task2])
            plan = orchestrator.create_execution_plan(graph)

            assert len(plan.steps) == 2

    @pytest.mark.asyncio
    async def test_execute_plan(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task = SubTask(name="task1", description="Test task")
            step = ExecutionStep(
                task_id=task.id,
                phase=WorkflowPhase.ANALYZE,
            )
            plan = ExecutionPlan(steps=[step], parallel_groups={0: [task.id]})
            orchestrator.context.sub_tasks = [task]

            result = await orchestrator.execute_plan(plan)

            assert result.success is True

    def test_track_progress(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            progress = orchestrator.track_progress()

            assert progress.total_tasks >= 0

    def test_handle_error(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task = SubTask(name="test", description="Test task")
            error = TimeoutError("Test timeout")

            recovery = orchestrator.handle_error(error, task)

            assert recovery.strategy == RecoveryStrategy.RETRY

    def test_validate_result(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task = SubTask(name="test", description="Test task")

            assert orchestrator.validate_result(task, {"status": "completed"}) is True
            assert orchestrator.validate_result(task, None) is False

    @pytest.mark.asyncio
    async def test_parallel_execution(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            task1 = SubTask(name="task1", description="Task 1")
            task2 = SubTask(name="task2", description="Task 2")

            plan = ExecutionPlan(
                steps=[
                    ExecutionStep(task_id=task1.id, phase=WorkflowPhase.ANALYZE),
                    ExecutionStep(task_id=task2.id, phase=WorkflowPhase.ANALYZE),
                ],
                parallel_groups={0: [task1.id, task2.id]},
            )
            orchestrator.context.sub_tasks = [task1, task2]

            result = await orchestrator.execute_plan(plan)

            assert result.success is True

    def test_dependency_resolution(self):
        graph = DependencyGraph()

        graph.nodes = ["a", "b", "c"]
        graph.edges = [
            DependencyEdge(source="a", target="b"),
            DependencyEdge(source="b", target="c"),
        ]
        graph.adjacency = {"a": ["b"], "b": ["c"], "c": []}
        graph.reverse_adjacency = {"a": [], "b": ["a"], "c": ["b"]}

        order = graph.topological_sort()

        assert order.index("a") < order.index("b")
        assert order.index("b") < order.index("c")

    @pytest.mark.asyncio
    async def test_full_workflow(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            state = create_app_state(cwd=tmpdir)
            orchestrator = WorkflowOrchestrator(state)

            result = await orchestrator.run_full_workflow("Test task")

            assert isinstance(result, WorkflowResult)
            assert result.workflow_id != ""


class TestDecisionEngine:
    def test_analyze_context(self):
        engine = DecisionEngine()

        task = SubTask(name="test", description="Test task")
        context = engine.analyze_context(HyperAutoState.ANALYZING, task)

        assert context.state == HyperAutoState.ANALYZING
        assert len(context.available_tools) > 0

    def test_generate_options(self):
        engine = DecisionEngine()

        task = SubTask(
            name="test",
            description="Test task",
            metadata={"type": "skill_creation"},
        )
        context = engine.analyze_context(HyperAutoState.ANALYZING, task)

        options = engine.generate_options(context)

        assert len(options) > 0

    def test_assess_risks(self):
        engine = DecisionEngine()

        options = [
            DecisionOption(
                action="test_action",
                risk_level=RiskLevel.LOW,
                confidence=0.8,
            ),
            DecisionOption(
                action="risky_action",
                risk_level=RiskLevel.HIGH,
                confidence=0.5,
            ),
        ]

        assessments = engine.assess_risks(options)

        assert len(assessments) == 2

    def test_calculate_confidence(self):
        engine = DecisionEngine()

        option = DecisionOption(
            action="test",
            confidence=0.5,
            risk_level=RiskLevel.LOW,
        )

        task = SubTask(name="test", description="Test task")
        context = engine.analyze_context(HyperAutoState.ANALYZING, task)

        confidence = engine.calculate_confidence(option, context)

        assert 0.0 <= confidence <= 1.0

    def test_select_best(self):
        engine = DecisionEngine()

        options = [
            DecisionOption(
                action="low_confidence",
                confidence=0.3,
                risk_level=RiskLevel.LOW,
            ),
            DecisionOption(
                action="high_confidence",
                confidence=0.9,
                risk_level=RiskLevel.LOW,
            ),
        ]

        decision = engine.select_best(options)

        assert decision.action == "high_confidence"

    def test_record_decision(self):
        engine = DecisionEngine()

        decision = Decision(type=DecisionType.SKILL_CREATION, confidence=0.8)
        record = DecisionRecord()

        engine.record_decision(decision, record)

        assert len(engine.get_decision_history()) == 1

    def test_risk_based_decision(self):
        engine = DecisionEngine()

        options = [
            DecisionOption(
                action="safe_option",
                confidence=0.7,
                risk_level=RiskLevel.LOW,
            ),
            DecisionOption(
                action="risky_option",
                confidence=0.9,
                risk_level=RiskLevel.CRITICAL,
            ),
        ]

        decision = engine.select_best(options)

        assert decision.action == "safe_option"

    def test_confidence_threshold(self):
        engine = DecisionEngine()

        options = [
            DecisionOption(
                action="low_confidence",
                confidence=0.3,
                risk_level=RiskLevel.LOW,
            ),
        ]

        decision = engine.select_best(options)

        assert decision.confidence == 0.3


class TestLearningSystem:
    def test_collect_experience(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            from openlaoke.core.hyperauto.workflow import (
                TaskTree,
                ExecutionPlan,
                WorkflowResult,
            )

            result = WorkflowResult(
                workflow_id="test",
                success=True,
                task_tree=TaskTree(root_task="test"),
                execution_plan=ExecutionPlan(),
            )

            experience = system.collect_experience(result)

            assert experience.type == ExperienceType.SUCCESS

    def test_extract_knowledge(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            experiences = [
                Experience(
                    task="test task",
                    type=ExperienceType.SUCCESS,
                    steps=["step1", "step2"],
                )
            ]

            knowledge = system.extract_knowledge(experiences)

            assert knowledge.title != ""

    def test_recognize_patterns(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            knowledge = Knowledge(
                title="test",
                description="test knowledge",
            )

            experiences = [
                Experience(
                    id="exp1",
                    task="test",
                    type=ExperienceType.SUCCESS,
                    steps=["step1", "step2"],
                )
            ]
            system._experiences = experiences
            knowledge.source_experiences = ["exp1"]

            patterns = system.recognize_patterns(knowledge)

            assert isinstance(patterns, list)

    def test_optimize_strategy(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            patterns = [
                Pattern(
                    type=PatternType.SEQUENTIAL,
                    name="test_pattern",
                    sequence=["step1", "step2"],
                    success_rate=0.9,
                )
            ]

            strategy = system.optimize_strategy(patterns)

            assert strategy.type == StrategyType.AGGRESSIVE

    def test_persist_knowledge(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            knowledge = Knowledge(
                id="test_id",
                title="Test Knowledge",
                description="Test description",
            )

            result = system.persist_knowledge(knowledge)

            assert result is True

    def test_load_knowledge(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            knowledge = system.load_knowledge()

            assert isinstance(knowledge, Knowledge)

    def test_apply_learning(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            enhanced = system.apply_learning("create a test")

            assert isinstance(enhanced, EnhancedStrategy)
            assert enhanced.base_strategy is not None

    def test_learning_session(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = LearningSystem(storage_dir=Path(tmpdir))

            session = system.start_session()

            assert session.id != ""
            assert session.start_time > 0

            ended = system.end_session()

            assert ended is not None
            assert ended.end_time is not None


class TestReflectionSystem:
    def test_review_result(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            from openlaoke.core.hyperauto.workflow import (
                TaskTree,
                ExecutionPlan,
                ExecutionResult,
                WorkflowResult,
            )

            result = WorkflowResult(
                workflow_id="test",
                success=True,
                task_tree=TaskTree(root_task="test"),
                execution_plan=ExecutionPlan(),
                execution_results=[ExecutionResult(task_id="task1", success=True, output={})],
            )

            review = system.review_result(result)

            assert review.overall_score >= 0

    def test_analyze_errors(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            errors = [
                Error(
                    severity=ErrorSeverity.HIGH,
                    category=ErrorCategory.LOGIC,
                    message="Test error",
                )
            ]

            analysis = system.analyze_errors(errors)

            assert analysis.error_count == 1
            assert analysis.high_count == 1

    def test_generate_improvements(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            analysis = Analysis(
                error_count=2,
                root_causes=["Missing validation", "Incorrect logic"],
            )

            improvements = system.generate_improvements(analysis)

            assert len(improvements) > 0

    def test_auto_correct(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            from openlaoke.core.hyperauto.workflow import (
                TaskTree,
                ExecutionPlan,
                WorkflowResult,
            )

            result = WorkflowResult(
                workflow_id="test",
                success=False,
                task_tree=TaskTree(root_task="test"),
                execution_plan=ExecutionPlan(),
            )

            improvements = [
                Improvement(
                    priority=ImprovementPriority.HIGH,
                    category="error_fix",
                    description="Fix the error",
                )
            ]

            corrected = system.auto_correct(result, improvements)

            assert corrected is not None

    def test_assess_quality(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            from openlaoke.core.hyperauto.workflow import (
                TaskTree,
                ExecutionPlan,
                ExecutionResult,
                WorkflowResult,
            )

            result = WorkflowResult(
                workflow_id="test",
                success=True,
                task_tree=TaskTree(root_task="test"),
                execution_plan=ExecutionPlan(
                    steps=[ExecutionStep(task_id="task1", phase=WorkflowPhase.ANALYZE)]
                ),
                execution_results=[ExecutionResult(task_id="task1", success=True)],
            )

            quality = system.assess_quality(result)

            assert quality.overall >= 0

    def test_reflection_report(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            system = ReflectionSystem(storage_dir=Path(tmpdir))

            from openlaoke.core.hyperauto.workflow import (
                TaskTree,
                ExecutionPlan,
                WorkflowResult,
            )

            result = WorkflowResult(
                workflow_id="test",
                success=True,
                task_tree=TaskTree(root_task="test"),
                execution_plan=ExecutionPlan(),
            )

            report = system.reflect_on_workflow(result)

            assert report.summary != ""

    def test_error_severity(self):
        error = Error(
            severity=ErrorSeverity.CRITICAL,
            message="Critical error",
        )

        assert error.severity == ErrorSeverity.CRITICAL

    def test_improvement_priority(self):
        improvement = Improvement(
            priority=ImprovementPriority.IMMEDIATE,
            description="Urgent fix",
        )

        assert improvement.priority == ImprovementPriority.IMMEDIATE


class TestAutoTestRunner:
    def test_detect_framework(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            runner = AutoTestRunner()
            Path(tmpdir, "pyproject.toml").touch()

            framework = runner.detect_test_framework(Path(tmpdir))

            assert framework == TestFramework.PYTEST

    def test_discover_tests(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir, "test_example.py")
            test_file.write_text("def test_something():\n    assert True\n")

            runner = AutoTestRunner()
            tests = runner.discover_tests(Path(tmpdir))

            assert isinstance(tests, list)

    def test_run_tests(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            runner = AutoTestRunner()

            tests = [TestInfo(name="test_example", framework=TestFramework.PYTEST)]

            results = runner.run_tests(tests, Path(tmpdir))

            assert isinstance(results, TestResults)

    def test_analyze_results(self):
        runner = AutoTestRunner()

        results = TestResults(
            total_tests=10,
            passed=8,
            failed=2,
        )

        analysis = runner.analyze_results(results)

        assert analysis.success_rate == 80.0

    def test_check_coverage(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            runner = AutoTestRunner()

            coverage = runner.check_coverage(Path(tmpdir))

            assert isinstance(coverage, CoverageReport)

    def test_diagnose_failures(self):
        runner = AutoTestRunner()

        failures = [
            TestFailure(
                test_id="test1",
                test_name="test_example",
                error_message="AssertionError: expected True",
            )
        ]

        diagnoses = runner.diagnose_failures(failures)

        assert len(diagnoses) == 1

    def test_auto_fix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            runner = AutoTestRunner()

            diagnosis = Diagnosis(
                failure_id="test1",
                auto_fixable=False,
            )

            result = runner.auto_fix_tests(diagnosis, Path(tmpdir))

            assert result is False

    @pytest.mark.asyncio
    async def test_full_cycle(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            runner = AutoTestRunner()

            result = await runner.async_run_full_cycle(Path(tmpdir))

            assert isinstance(result, TestCycleResult)


class TestResultValidator:
    def test_validate_code(self):
        validator = ResultValidator()

        code = "def hello():\n    print('hello')\n"
        result = validator.validate_code(code, Language.PYTHON)

        assert isinstance(result, ValidationResult)

    def test_validate_functionality(self):
        validator = ResultValidator()

        implementation = "def add(a, b):\n    return a + b\n"
        requirements = ["add two numbers", "return sum"]

        result = validator.validate_functionality(implementation, requirements, Language.PYTHON)

        assert isinstance(result, ValidationResult)

    def test_validate_performance(self):
        validator = ResultValidator()

        code = "def test():\n    pass\n"
        benchmarks = {"max_execution_time_ms": 100.0}

        result = validator.validate_performance(code, benchmarks, Language.PYTHON)

        assert isinstance(result, SecurityReport) or hasattr(result, "benchmark_passed")

    def test_validate_security(self):
        validator = ResultValidator()

        code = "password = 'secret123'\n"
        result = validator.validate_security(code, Language.PYTHON)

        assert result.secure is False
        assert len(result.vulnerabilities) > 0

    def test_validate_compatibility(self):
        validator = ResultValidator()

        code = "def test():\n    pass\n"
        result = validator.validate_compatibility(code, "Python 3.11", Language.PYTHON)

        assert isinstance(result, ValidationResult)

    def test_quality_score(self):
        validator = ResultValidator()

        results = {
            "syntax": ValidationResult(score=100.0),
            "style": ValidationResult(score=90.0),
            "functionality": ValidationResult(score=85.0),
        }

        score = validator.calculate_quality_score(results)

        assert isinstance(score, ValidatorQualityScore)

    def test_full_validation(self):
        validator = ResultValidator()

        artifact = Artifact(
            type="code",
            content="def test():\n    pass\n",
            language=Language.PYTHON,
        )

        result = validator.validate_code(artifact.content, artifact.language)

        assert result is not None

    def test_validation_report(self):
        validator = ResultValidator()

        code = "def hello():\n    print('hello')\n"

        code_result = validator.validate_code(code, Language.PYTHON)
        security_result = validator.validate_security(code, Language.PYTHON)

        assert code_result is not None
        assert security_result is not None
