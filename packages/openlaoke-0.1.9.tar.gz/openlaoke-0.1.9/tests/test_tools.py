"""Tests for tool implementations."""

import os
import tempfile

import pytest

from openlaoke.core.state import create_app_state
from openlaoke.core.tool import ToolContext
from openlaoke.tools.bash_tool import BashTool
from openlaoke.tools.read_tool import ReadTool
from openlaoke.tools.write_tool import WriteTool
from openlaoke.tools.edit_tool import EditTool
from openlaoke.tools.glob_tool import GlobTool
from openlaoke.tools.grep_tool import GrepTool


@pytest.fixture
def app_state():
    import openlaoke

    project_root = os.path.dirname(os.path.dirname(openlaoke.__file__))
    return create_app_state(cwd=project_root)


@pytest.fixture
def ctx(app_state):
    return ToolContext(app_state=app_state, tool_use_id="test_1")


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


class TestBashTool:
    @pytest.mark.asyncio
    async def test_simple_command(self, ctx):
        tool = BashTool()
        result = await tool.call(ctx, command="echo hello")
        assert not result.is_error
        assert "hello" in result.content

    @pytest.mark.asyncio
    async def test_empty_command(self, ctx):
        tool = BashTool()
        result = await tool.call(ctx, command="")
        assert result.is_error

    @pytest.mark.asyncio
    async def test_failing_command(self, ctx):
        tool = BashTool()
        result = await tool.call(ctx, command="exit 1")
        assert result.is_error


class TestReadTool:
    @pytest.mark.asyncio
    async def test_read_file(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.txt")
        with open(path, "w") as f:
            f.write("line1\nline2\nline3\n")

        tool = ReadTool()
        result = await tool.call(ctx, file_path=path)
        assert not result.is_error
        assert "line1" in result.content
        assert "line2" in result.content

    @pytest.mark.asyncio
    async def test_read_with_offset(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.txt")
        with open(path, "w") as f:
            f.write("a\nb\nc\nd\n")

        tool = ReadTool()
        result = await tool.call(ctx, file_path=path, offset=3)
        assert "c" in result.content
        assert "a" not in result.content

    @pytest.mark.asyncio
    async def test_read_with_limit(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.txt")
        with open(path, "w") as f:
            f.write("a\nb\nc\nd\n")

        tool = ReadTool()
        result = await tool.call(ctx, file_path=path, limit=2)
        assert "a" in result.content
        assert "b" in result.content

    @pytest.mark.asyncio
    async def test_read_nonexistent(self, ctx):
        tool = ReadTool()
        result = await tool.call(ctx, file_path="/nonexistent/file.txt")
        assert result.is_error

    @pytest.mark.asyncio
    async def test_read_directory(self, ctx, temp_dir):
        os.makedirs(os.path.join(temp_dir, "subdir"))
        with open(os.path.join(temp_dir, "file.txt"), "w") as f:
            f.write("test")

        tool = ReadTool()
        result = await tool.call(ctx, file_path=temp_dir)
        assert not result.is_error
        assert "file.txt" in result.content


class TestWriteTool:
    @pytest.mark.asyncio
    async def test_write_new_file(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "new.txt")
        tool = WriteTool()
        result = await tool.call(ctx, file_path=path, content="hello world")
        assert not result.is_error
        assert "Created" in result.content

        with open(path) as f:
            assert f.read() == "hello world"

    @pytest.mark.asyncio
    async def test_write_existing_file(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "existing.txt")
        with open(path, "w") as f:
            f.write("old content")

        tool = WriteTool()
        result = await tool.call(ctx, file_path=path, content="new content")
        assert not result.is_error
        assert "Updated" in result.content

        with open(path) as f:
            assert f.read() == "new content"

    @pytest.mark.asyncio
    async def test_write_creates_directories(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "a", "b", "c.txt")
        tool = WriteTool()
        result = await tool.call(ctx, file_path=path, content="nested")
        assert not result.is_error
        assert os.path.exists(path)


class TestEditTool:
    @pytest.mark.asyncio
    async def test_simple_edit(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "edit.txt")
        with open(path, "w") as f:
            f.write("hello world\nsecond line\n")

        tool = EditTool()
        result = await tool.call(
            ctx,
            file_path=path,
            old_string="hello world",
            new_string="goodbye world",
        )
        assert not result.is_error
        assert "Replaced 1 occurrence" in result.content

        with open(path) as f:
            content = f.read()
            assert "goodbye world" in content
            assert "hello world" not in content

    @pytest.mark.asyncio
    async def test_edit_not_found(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "edit.txt")
        with open(path, "w") as f:
            f.write("some content\n")

        tool = EditTool()
        result = await tool.call(
            ctx,
            file_path=path,
            old_string="nonexistent text",
            new_string="replacement",
        )
        assert result.is_error


class TestGlobTool:
    @pytest.mark.asyncio
    async def test_glob_python_files(self, ctx, temp_dir):
        for name in ["a.py", "b.py", "c.txt"]:
            with open(os.path.join(temp_dir, name), "w") as f:
                f.write("")

        tool = GlobTool()
        result = await tool.call(ctx, pattern="*.py", path=temp_dir)
        assert not result.is_error
        assert "a.py" in result.content
        assert "b.py" in result.content
        assert "c.txt" not in result.content


class TestGrepTool:
    @pytest.mark.asyncio
    async def test_grep_content(self, ctx, temp_dir):
        with open(os.path.join(temp_dir, "test.py"), "w") as f:
            f.write("def hello():\n    print('world')\n")

        tool = GrepTool()
        result = await tool.call(ctx, pattern="def hello", path=temp_dir)
        assert not result.is_error
        assert "def hello" in result.content

    @pytest.mark.asyncio
    async def test_grep_no_matches(self, ctx, temp_dir):
        with open(os.path.join(temp_dir, "test.py"), "w") as f:
            f.write("no matches here\n")

        tool = GrepTool()
        result = await tool.call(ctx, pattern="nonexistent_pattern", path=temp_dir)
        assert not result.is_error
        assert "No matches" in result.content

    @pytest.mark.asyncio
    async def test_grep_files_with_matches(self, ctx, temp_dir):
        with open(os.path.join(temp_dir, "a.py"), "w") as f:
            f.write("TODO: fix this\n")
        with open(os.path.join(temp_dir, "b.py"), "w") as f:
            f.write("no todos\n")

        tool = GrepTool()
        result = await tool.call(
            ctx, pattern="TODO", path=temp_dir, output_mode="files_with_matches"
        )
        assert "a.py" in result.content
