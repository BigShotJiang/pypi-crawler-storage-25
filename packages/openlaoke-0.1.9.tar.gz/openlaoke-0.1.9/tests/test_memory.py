"""Tests for long-term memory and knowledge graph system."""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest

from openlaoke.core.memory import (
    ConsolidationStrategy,
    EmbeddingEngine,
    Fact,
    Inference,
    KnowledgeEdge,
    KnowledgeGraph,
    KnowledgeNode,
    LongTermMemory,
    Memory,
    MemoryConsolidator,
    MemoryRetriever,
    MemorySummary,
    SearchResult,
    VectorIndex,
)


class TestMemory:
    """Test Memory data structure."""

    def test_create_memory(self) -> None:
        m = Memory(id="test_1", content="Test content")
        assert m.id == "test_1"
        assert m.content == "Test content"
        assert m.embedding is None
        assert m.importance == 0.5
        assert m.access_count == 0

    def test_memory_to_dict(self) -> None:
        m = Memory(id="test_2", content="Test", importance=0.8)
        data = m.to_dict()
        assert data["id"] == "test_2"
        assert data["content"] == "Test"
        assert data["importance"] == 0.8

    def test_memory_from_dict(self) -> None:
        data = {
            "id": "test_3",
            "content": "Content",
            "importance": 0.9,
            "access_count": 5,
        }
        m = Memory.from_dict(data)
        assert m.id == "test_3"
        assert m.importance == 0.9
        assert m.access_count == 5

    def test_memory_touch(self) -> None:
        m = Memory(id="test_4", content="Test")
        initial_count = m.access_count
        m.touch()
        assert m.access_count == initial_count + 1


class TestEmbeddingEngine:
    """Test embedding engine."""

    @pytest.mark.asyncio
    async def test_embed_text(self) -> None:
        engine = EmbeddingEngine()
        embedding = await engine.embed("test text")
        assert len(embedding) == 128
        assert all(isinstance(x, float) for x in embedding)

    @pytest.mark.asyncio
    async def test_embed_batch(self) -> None:
        engine = EmbeddingEngine()
        embeddings = await engine.embed_batch(["text1", "text2"])
        assert len(embeddings) == 2
        assert all(len(e) == 128 for e in embeddings)

    def test_cosine_similarity(self) -> None:
        a = [1.0, 0.0, 0.0]
        b = [1.0, 0.0, 0.0]
        similarity = EmbeddingEngine.cosine_similarity(a, b)
        assert similarity == 1.0

        c = [0.0, 1.0, 0.0]
        similarity = EmbeddingEngine.cosine_similarity(a, c)
        assert similarity == 0.0

    @pytest.mark.asyncio
    async def test_embedding_cache(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = EmbeddingEngine(cache_path=Path(tmpdir))
            embedding1 = await engine.embed("cached text")
            embedding2 = await engine.embed("cached text")
            assert embedding1 == embedding2


class TestVectorIndex:
    """Test vector index."""

    def test_add_and_search(self) -> None:
        index = VectorIndex(dimension=3)
        index.add("vec1", [1.0, 0.0, 0.0])
        index.add("vec2", [0.9, 0.1, 0.0])
        index.add("vec3", [0.0, 1.0, 0.0])

        query = [1.0, 0.0, 0.0]
        results = index.search(query, k=2)
        assert len(results) == 2
        assert results[0][0] == "vec1"
        assert results[0][1] > results[1][1]

    def test_remove(self) -> None:
        index = VectorIndex(dimension=3)
        index.add("vec1", [1.0, 0.0, 0.0])
        index.remove("vec1")
        assert index.size() == 0

    def test_dimension_validation(self) -> None:
        index = VectorIndex(dimension=3)
        index.add("vec1", [1.0, 0.0, 0.0])
        index.add("vec2", [1.0, 0.0])  # Wrong dimension
        assert index.size() == 1


class TestMemoryRetriever:
    """Test memory retriever."""

    @pytest.mark.asyncio
    async def test_search(self) -> None:
        embedder = EmbeddingEngine()
        retriever = MemoryRetriever(embedder)

        m1 = Memory(
            id="m1",
            content="Python programming",
            embedding=await embedder.embed("Python programming"),
        )
        m2 = Memory(
            id="m2",
            content="JavaScript coding",
            embedding=await embedder.embed("JavaScript coding"),
        )
        m3 = Memory(
            id="m3", content="Cooking recipes", embedding=await embedder.embed("Cooking recipes")
        )

        query_embedding = await embedder.embed("Python")
        results = retriever.search([m1, m2, m3], query_embedding, limit=2)
        assert len(results) == 2
        assert results[0].id == "m1"

    def test_keyword_search(self) -> None:
        retriever = MemoryRetriever()
        m1 = Memory(id="m1", content="Python programming language")
        m2 = Memory(id="m2", content="JavaScript web development")

        results = retriever.keyword_search([m1, m2], ["python"], limit=1)
        assert len(results) == 1
        assert results[0].memory.id == "m1"


class TestLongTermMemory:
    """Test long-term memory system."""

    @pytest.mark.asyncio
    async def test_store_and_recall(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            ltm = LongTermMemory(storage_path=Path(tmpdir))

            m = Memory(id="", content="Test memory about Python")
            await ltm.store(m)

            results = await ltm.recall("Python", limit=1)
            assert len(results) == 1
            assert "Python" in results[0].content

    @pytest.mark.asyncio
    async def test_forget(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            ltm = LongTermMemory(storage_path=Path(tmpdir))

            m = Memory(id="to_delete", content="Delete this")
            await ltm.store(m)

            success = await ltm.forget("to_delete")
            assert success

            results = await ltm.recall("Delete", limit=10)
            assert len(results) == 0

    @pytest.mark.asyncio
    async def test_associate(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            ltm = LongTermMemory(storage_path=Path(tmpdir))

            m1 = Memory(id="m1", content="Memory 1")
            m2 = Memory(id="m2", content="Memory 2")
            await ltm.store(m1)
            await ltm.store(m2)

            await ltm.associate(["m1", "m2"])

            m1_loaded = ltm.storage.get("m1")
            assert m1_loaded is not None
            assert "m2" in m1_loaded.associations

    @pytest.mark.asyncio
    async def test_summarize(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            ltm = LongTermMemory(storage_path=Path(tmpdir))

            m1 = Memory(id="m1", content="Memory 1", importance=0.8)
            m2 = Memory(id="m2", content="Memory 2", importance=0.6)
            await ltm.store(m1)
            await ltm.store(m2)

            summary = await ltm.summarize()
            assert summary.total_memories == 2
            assert 0.0 <= summary.avg_importance <= 1.0


class TestKnowledgeGraph:
    """Test knowledge graph."""

    @pytest.mark.asyncio
    async def test_add_nodes_and_edges(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            kg = KnowledgeGraph(storage_path=Path(tmpdir))

            n1 = KnowledgeNode(id="", type="concept", content="Python")
            n2 = KnowledgeNode(id="", type="concept", content="Programming")

            id1 = await kg.add_node(n1)
            id2 = await kg.add_node(n2)

            await kg.add_edge(id1, id2, "is_related")

            assert len(kg.nodes) == 2
            assert len(kg.edges) == 1

    def test_get_neighbors(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            kg = KnowledgeGraph(storage_path=Path(tmpdir))
            kg.nodes["n1"] = KnowledgeNode(id="n1", type="concept", content="Python")
            kg.nodes["n2"] = KnowledgeNode(id="n2", type="concept", content="Programming")
            kg.edges.append(KnowledgeEdge(id="e1", source="n1", target="n2", relation="related"))

            neighbors = kg.get_neighbors("n1")
            assert len(neighbors) == 1
            assert neighbors[0].content == "Programming"

    @pytest.mark.asyncio
    async def test_visualize(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            kg = KnowledgeGraph(storage_path=Path(tmpdir))
            kg.nodes["n1"] = KnowledgeNode(id="n1", type="concept", content="Python")
            kg.nodes["n2"] = KnowledgeNode(id="n2", type="concept", content="Programming")
            kg.edges.append(KnowledgeEdge(id="e1", source="n1", target="n2", relation="related"))

            viz = await kg.visualize()
            assert len(viz.nodes) == 2
            assert len(viz.edges) == 1

    def test_find_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            kg = KnowledgeGraph(storage_path=Path(tmpdir))
            kg.nodes["n1"] = KnowledgeNode(id="n1", type="concept", content="A")
            kg.nodes["n2"] = KnowledgeNode(id="n2", type="concept", content="B")
            kg.nodes["n3"] = KnowledgeNode(id="n3", type="concept", content="C")
            kg.edges.append(KnowledgeEdge(id="e1", source="n1", target="n2", relation="to"))
            kg.edges.append(KnowledgeEdge(id="e2", source="n2", target="n3", relation="to"))

            path = kg.find_path("n1", "n3")
            assert path is not None
            assert path == ["n1", "n2", "n3"]


class TestConsolidation:
    """Test memory consolidation."""

    @pytest.mark.asyncio
    async def test_consolidate_empty(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            ltm = LongTermMemory(storage_path=Path(tmpdir))
            result = await ltm.consolidate()
            assert result.memories_removed == 0
            assert result.memories_merged == 0
