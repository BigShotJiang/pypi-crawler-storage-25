"""Tests for provider integration and tool calls."""

from __future__ import annotations

import asyncio
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from openlaoke.core.multi_provider_api import MultiProviderClient, ModelPricing
from openlaoke.types.providers import MultiProviderConfig, ProviderConfig, ProviderType


class TestMultiProviderClient:
    """Tests for MultiProviderClient."""
    
    def test_client_creation(self):
        """Test creating a client."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        assert client.config == config
        assert client._proxy is None
    
    def test_get_api_key_minimax(self):
        """Test getting MiniMax API key."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        
        client = MultiProviderClient(config)
        api_key = client._get_api_key(minimax)
        
        assert api_key == "test_key"
    
    def test_get_api_key_from_env(self):
        """Test getting API key from environment."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        
        with patch.dict(os.environ, {"MINIMAX_API_KEY": "env_key"}):
            client = MultiProviderClient(config)
            api_key = client._get_api_key(minimax)
            assert api_key == "env_key"
    
    def test_get_base_url_aliyun(self):
        """Test getting Aliyun base URL."""
        config = MultiProviderConfig.defaults()
        aliyun = config.providers["aliyun_coding_plan"]
        aliyun.base_url = "https://custom.aliyun.com/v1"
        
        client = MultiProviderClient(config)
        base_url = client._get_base_url(aliyun)
        
        assert base_url == "https://custom.aliyun.com/v1"
    
    def test_build_headers_anthropic(self):
        """Test building headers for Anthropic."""
        config = MultiProviderConfig.defaults()
        anthropic = config.providers["anthropic"]
        anthropic.api_key = "sk-ant-test"
        
        client = MultiProviderClient(config)
        headers = client._build_headers(anthropic)
        
        assert headers["x-api-key"] == "sk-ant-test"
        assert "anthropic-version" in headers
    
    def test_build_headers_openai(self):
        """Test building headers for OpenAI."""
        config = MultiProviderConfig.defaults()
        openai = config.providers["openai"]
        openai.api_key = "sk-test"
        
        client = MultiProviderClient(config)
        headers = client._build_headers(openai)
        
        assert headers["Authorization"] == "Bearer sk-test"
    
    def test_build_headers_local_no_auth(self):
        """Test that local providers don't send auth header."""
        config = MultiProviderConfig.defaults()
        ollama = config.providers["ollama"]
        
        client = MultiProviderClient(config)
        headers = client._build_headers(ollama)
        
        assert "Authorization" not in headers
        assert "Content-Type" in headers
    
    def test_convert_tools_to_openai_format(self):
        """Test converting tools to OpenAI format."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        tools = [
            {
                "name": "Bash",
                "description": "Execute bash",
                "input_schema": {
                    "type": "object",
                    "properties": {"command": {"type": "string"}},
                    "required": ["command"],
                },
            }
        ]
        
        openai_tools = client._convert_tools_to_openai_format(tools)
        
        assert len(openai_tools) == 1
        assert openai_tools[0]["type"] == "function"
        assert openai_tools[0]["function"]["name"] == "Bash"
        assert "parameters" in openai_tools[0]["function"]
    
    def test_convert_tools_already_openai_format(self):
        """Test that already-converted tools are preserved."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        tools = [{
            "type": "function",
            "function": {
                "name": "Bash",
                "description": "Test",
                "parameters": {"type": "object"},
            }
        }]
        
        converted = client._convert_tools_to_openai_format(tools)
        
        assert converted == tools
    
    def test_convert_messages_to_openai_format(self):
        """Test converting messages to OpenAI format."""
        config = MultiProviderConfig.defaults()
        client = MultiProviderClient(config)
        
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "tool_calls": [
                {"id": "call_1", "type": "function", "function": {"name": "Bash", "arguments": '{"command":"ls"}'}}
            ]},
            {"role": "tool", "tool_call_id": "call_1", "content": "file.txt"},
        ]
        
        converted = client._convert_to_openai_format(messages)
        
        assert len(converted) == 3
        assert converted[0]["role"] == "user"
        assert converted[1]["role"] == "assistant"
        assert converted[2]["role"] == "tool"
        assert converted[2]["tool_call_id"] == "call_1"
    
    @pytest.mark.asyncio
    async def test_send_message_mock(self):
        """Test sending message with mocked response."""
        config = MultiProviderConfig.defaults()
        minimax = config.providers["minimax"]
        minimax.api_key = "test_key"
        config.active_provider = "minimax"
        
        client = MultiProviderClient(config)
        
        mock_response = {
            "choices": [{
                "message": {"content": "Hello!", "tool_calls": []},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            "model": "MiniMax-M2.7-highspeed",
        }
        
        with patch.object(client, "_get_client") as mock_get_client:
            mock_http_client = MagicMock()
            mock_resp = MagicMock()
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()
            mock_http_client.post = AsyncMock(return_value=mock_resp)
            mock_get_client.return_value = mock_http_client
            
            response, usage, cost = await client.send_message(
                system_prompt="You are helpful.",
                messages=[{"role": "user", "content": "Hi"}],
                tools=None,
            )
            
            assert response.content == "Hello!"
            assert usage.input_tokens == 10
            assert usage.output_tokens == 5


class TestModelPricing:
    """Tests for model pricing."""
    
    def test_default_pricing(self):
        """Test default pricing."""
        pricing = ModelPricing()
        assert pricing.input_price == 3.0
        assert pricing.output_price == 15.0
    
    def test_minimax_pricing_exists(self):
        """Test that MiniMax models have pricing."""
        from openlaoke.core.multi_provider_api import MODEL_PRICES
        
        assert "MiniMax-M2.7-highspeed" in MODEL_PRICES
        pricing = MODEL_PRICES["MiniMax-M2.7-highspeed"]
        assert pricing.input_price > 0
        assert pricing.output_price > 0
    
    def test_aliyun_pricing_exists(self):
        """Test that Aliyun models have pricing."""
        from openlaoke.core.multi_provider_api import MODEL_PRICES
        
        assert "qwen3.5-plus" in MODEL_PRICES
        assert "glm-5" in MODEL_PRICES


class TestProviderConfig:
    """Tests for provider configuration."""
    
    def test_minimax_config(self):
        """Test MiniMax provider configuration."""
        config = MultiProviderConfig.defaults()
        
        assert "minimax" in config.providers
        minimax = config.providers["minimax"]
        
        assert minimax.provider_type == ProviderType.MINIMAX
        assert minimax.base_url == "https://api.minimaxi.com/v1"
        assert minimax.default_model == "MiniMax-M2.7-highspeed"
        assert len(minimax.models) > 0
    
    def test_aliyun_config(self):
        """Test Aliyun provider configuration."""
        config = MultiProviderConfig.defaults()
        
        assert "aliyun_coding_plan" in config.providers
        aliyun = config.providers["aliyun_coding_plan"]
        
        assert aliyun.provider_type == ProviderType.ALIYUN_CODING_PLAN
        assert aliyun.base_url == "https://coding.dashscope.aliyuncs.com/v1"
        assert "qwen3.5-plus" in aliyun.models
        assert "glm-5" in aliyun.models
    
    def test_ollama_is_local(self):
        """Test that Ollama is marked as local."""
        config = MultiProviderConfig.defaults()
        ollama = config.providers["ollama"]
        
        assert ollama.is_local is True
        assert ollama.api_key == ""
    
    def test_is_configured(self):
        """Test is_configured method."""
        config = ProviderConfig(
            provider_type=ProviderType.MINIMAX,
            api_key="test",
        )
        assert config.is_configured() is True
        
        config_no_key = ProviderConfig(
            provider_type=ProviderType.MINIMAX,
            api_key="",
        )
        assert config_no_key.is_configured() is False
        
        config_local = ProviderConfig(
            provider_type=ProviderType.OLLAMA,
            is_local=True,
        )
        assert config_local.is_configured() is True