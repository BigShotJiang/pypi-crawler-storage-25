"""Tests for new tool implementations."""

import os
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from openlaoke.core.state import create_app_state
from openlaoke.core.tool import ToolContext
from openlaoke.tools.webfetch_tool import WebFetchTool
from openlaoke.tools.websearch_tool import WebSearchTool
from openlaoke.tools.todo_tool import TodoWriteTool
from openlaoke.tools.question_tool import QuestionTool
from openlaoke.tools.ls_tool import ListDirectoryTool
from openlaoke.tools.lsp_tool import LSPTool
from openlaoke.tools.git_tool import GitTool
from openlaoke.tools.apply_patch_tool import ApplyPatchTool
from openlaoke.tools.batch_tool import BatchTool, ToolCallSpec
from openlaoke.tools.plan_tool import PlanTool


@pytest.fixture
def app_state():
    import openlaoke

    project_root = os.path.dirname(os.path.dirname(openlaoke.__file__))
    return create_app_state(cwd=project_root)


@pytest.fixture
def ctx(app_state):
    return ToolContext(app_state=app_state, tool_use_id="test_1")


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


class TestWebFetchTool:
    @pytest.mark.asyncio
    async def test_empty_url(self, ctx):
        tool = WebFetchTool()
        result = await tool.call(ctx, url="")
        assert result.is_error
        assert "URL is required" in result.content

    @pytest.mark.asyncio
    async def test_missing_url(self, ctx):
        tool = WebFetchTool()
        result = await tool.call(ctx)
        assert result.is_error
        assert "URL is required" in result.content

    @pytest.mark.asyncio
    async def test_url_auto_https(self, ctx):
        tool = WebFetchTool()
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.text = "<html><body>test</body></html>"
            mock_response.raise_for_status = MagicMock()

            mock_client_instance = AsyncMock()
            mock_client_instance.get = AsyncMock(return_value=mock_response)
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            result = await tool.call(ctx, url="example.com")
            assert not result.is_error
            assert "test" in result.content

    @pytest.mark.asyncio
    async def test_timeout_limit(self, ctx):
        tool = WebFetchTool()

        result = await tool.call(ctx, url="https://example.com", timeout=200)
        assert not result.is_error or "Error" in result.content

    @pytest.mark.asyncio
    async def test_html_to_markdown(self, ctx):
        tool = WebFetchTool()
        html = "<h1>Title</h1><p>Paragraph</p><pre>code</pre>"
        result = tool._html_to_markdown(html)
        assert "# " in result
        assert "Title" in result
        assert "``" in result

    def test_tool_properties(self):
        tool = WebFetchTool()
        assert tool.name == "WebFetch"
        assert tool.is_read_only
        assert not tool.is_destructive
        assert not tool.requires_approval


class TestWebSearchTool:
    @pytest.mark.asyncio
    async def test_empty_query(self, ctx):
        tool = WebSearchTool()
        result = await tool.call(ctx, query="")
        assert result.is_error
        assert "query is required" in result.content

    @pytest.mark.asyncio
    async def test_missing_query(self, ctx):
        tool = WebSearchTool()
        result = await tool.call(ctx)
        assert result.is_error

    @pytest.mark.asyncio
    async def test_no_results(self, ctx):
        tool = WebSearchTool()
        with patch("httpx.AsyncClient") as mock_client:
            mock_response = MagicMock()
            mock_response.text = "<html>No results</html>"
            mock_response.raise_for_status = MagicMock()

            mock_client_instance = AsyncMock()
            mock_client_instance.post = AsyncMock(return_value=mock_response)
            mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
            mock_client_instance.__aexit__ = AsyncMock()
            mock_client.return_value = mock_client_instance

            result = await tool.call(ctx, query="nonexistent query xyz")
            assert not result.is_error
            assert "No results" in result.content

    def test_strip_tags(self):
        tool = WebSearchTool()
        text = "<span>hello</span> world <b>test</b>"
        result = tool._strip_tags(text)
        assert "hello" in result
        assert "world" in result
        assert "test" in result
        assert "<" not in result

    def test_tool_properties(self):
        tool = WebSearchTool()
        assert tool.name == "WebSearch"
        assert tool.is_read_only
        assert not tool.is_destructive


class TestTodoWriteTool:
    @pytest.mark.asyncio
    async def test_empty_todos(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(ctx, todos=[])
        assert not result.is_error
        assert "empty" in result.content.lower()

    @pytest.mark.asyncio
    async def test_single_todo(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(ctx, todos=[{"content": "Test task"}])
        assert not result.is_error
        assert "Test task" in result.content

    @pytest.mark.asyncio
    async def test_multiple_todos(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(
            ctx,
            todos=[
                {"content": "Task 1", "status": "completed"},
                {"content": "Task 2", "status": "in_progress"},
                {"content": "Task 3", "status": "pending", "priority": "high"},
            ],
        )
        assert not result.is_error
        assert "Task 1" in result.content
        assert "Task 2" in result.content
        assert "Task 3" in result.content

    @pytest.mark.asyncio
    async def test_invalid_status(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(ctx, todos=[{"content": "Task", "status": "invalid_status"}])
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_invalid_priority(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(ctx, todos=[{"content": "Task", "priority": "invalid"}])
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_invalid_todos_type(self, ctx):
        tool = TodoWriteTool()
        result = await tool.call(ctx, todos="not a list")
        assert result.is_error

    def test_tool_properties(self):
        tool = TodoWriteTool()
        assert tool.name == "TodoWrite"
        assert not tool.is_read_only
        assert not tool.is_destructive


class TestQuestionTool:
    @pytest.mark.asyncio
    async def test_single_question(self, ctx):
        tool = QuestionTool()
        result = await tool.call(ctx, questions=[{"question": "What is your name?"}])
        assert not result.is_error
        assert "What is your name?" in result.content

    @pytest.mark.asyncio
    async def test_question_with_options(self, ctx):
        tool = QuestionTool()
        result = await tool.call(
            ctx,
            questions=[
                {
                    "question": "Choose an option",
                    "options": [{"value": "a", "label": "Option A"}, {"value": "b"}],
                }
            ],
        )
        assert not result.is_error
        assert "Option A" in result.content
        assert "Option B" in result.content or "b" in result.content

    @pytest.mark.asyncio
    async def test_multiple_questions(self, ctx):
        tool = QuestionTool()
        result = await tool.call(
            ctx,
            questions=[
                {"question": "Q1?", "header": "Header 1"},
                {"question": "Q2?", "header": "Header 2"},
            ],
        )
        assert not result.is_error
        assert "Q1?" in result.content
        assert "Q2?" in result.content
        assert "Header 1" in result.content

    @pytest.mark.asyncio
    async def test_multiple_selection(self, ctx):
        tool = QuestionTool()
        result = await tool.call(
            ctx,
            questions=[{"question": "Select all", "multiple": True, "options": [{"value": "x"}]}],
        )
        assert not result.is_error
        assert "select all that apply" in result.content.lower()

    @pytest.mark.asyncio
    async def test_invalid_questions_type(self, ctx):
        tool = QuestionTool()
        result = await tool.call(ctx, questions="not a list")
        assert result.is_error

    def test_tool_properties(self):
        tool = QuestionTool()
        assert tool.name == "Question"
        assert tool.is_read_only


class TestListDirectoryTool:
    @pytest.mark.asyncio
    async def test_list_current_directory(self, ctx):
        tool = ListDirectoryTool()
        result = await tool.call(ctx)
        assert not result.is_error
        assert "Contents of" in result.content

    @pytest.mark.asyncio
    async def test_list_temp_directory(self, ctx, temp_dir):
        with open(os.path.join(temp_dir, "file.txt"), "w") as f:
            f.write("test")
        os.makedirs(os.path.join(temp_dir, "subdir"))

        tool = ListDirectoryTool()
        result = await tool.call(ctx, path=temp_dir)
        assert not result.is_error
        assert "file.txt" in result.content
        assert "subdir" in result.content

    @pytest.mark.asyncio
    async def test_nonexistent_path(self, ctx):
        tool = ListDirectoryTool()
        result = await tool.call(ctx, path="/nonexistent/path")
        assert result.is_error
        assert "does not exist" in result.content

    @pytest.mark.asyncio
    async def test_path_is_file(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "file.txt")
        with open(path, "w") as f:
            f.write("test")

        tool = ListDirectoryTool()
        result = await tool.call(ctx, path=path)
        assert result.is_error
        assert "Not a directory" in result.content

    def test_format_size(self):
        tool = ListDirectoryTool()
        assert tool._format_size(0) == "0.0B"
        assert tool._format_size(1024) == "1.0KB"
        assert tool._format_size(1024 * 1024) == "1.0MB"
        assert tool._format_size(1024 * 1024 * 1024) == "1.0GB"

    def test_tool_properties(self):
        tool = ListDirectoryTool()
        assert tool.name == "ListDirectory"
        assert tool.is_read_only


class TestLSPTool:
    @pytest.mark.asyncio
    async def test_missing_action(self, ctx):
        tool = LSPTool()
        result = await tool.call(ctx, file_path="test.py")
        assert result.is_error
        assert "action is required" in result.content

    @pytest.mark.asyncio
    async def test_missing_file_path(self, ctx):
        tool = LSPTool()
        result = await tool.call(ctx, action="diagnostics")
        assert result.is_error
        assert "file_path is required" in result.content

    @pytest.mark.asyncio
    async def test_nonexistent_file(self, ctx):
        tool = LSPTool()
        result = await tool.call(ctx, action="diagnostics", file_path="/nonexistent/file.py")
        assert result.is_error
        assert "not found" in result.content.lower()

    @pytest.mark.asyncio
    async def test_unsupported_file_type(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.xyz")
        with open(path, "w") as f:
            f.write("content")

        tool = LSPTool()
        result = await tool.call(ctx, action="diagnostics", file_path=path)
        assert result.is_error
        assert "Unsupported" in result.content

    @pytest.mark.asyncio
    async def test_diagnostics_python(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.py")
        with open(path, "w") as f:
            f.write("def hello():\n    pass\n")

        tool = LSPTool()
        result = await tool.call(ctx, action="diagnostics", file_path=path)
        assert not result.is_error

    @pytest.mark.asyncio
    async def test_symbols_python(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.py")
        with open(path, "w") as f:
            f.write("def func1():\n    pass\n\nclass MyClass:\n    pass\n")

        tool = LSPTool()
        result = await tool.call(ctx, action="symbols", file_path=path)
        assert not result.is_error
        assert "func1" in result.content
        assert "MyClass" in result.content

    @pytest.mark.asyncio
    async def test_definition_missing_position(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.py")
        with open(path, "w") as f:
            f.write("test\n")

        tool = LSPTool()
        result = await tool.call(ctx, action="definition", file_path=path)
        assert result.is_error
        assert "line and column required" in result.content

    @pytest.mark.asyncio
    async def test_definition_with_position(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.py")
        with open(path, "w") as f:
            f.write("test\n")

        tool = LSPTool()
        result = await tool.call(ctx, action="definition", file_path=path, line=1, column=1)
        assert not result.is_error

    def test_detect_language(self):
        tool = LSPTool()
        assert tool._detect_language("test.py") == "python"
        assert tool._detect_language("test.js") == "javascript"
        assert tool._detect_language("test.ts") == "typescript"
        assert tool._detect_language("test.go") == "go"
        assert tool._detect_language("test.rs") == "rust"
        assert tool._detect_language("test.xyz") is None

    def test_tool_properties(self):
        tool = LSPTool()
        assert tool.name == "LSP"
        assert tool.is_read_only


class TestGitTool:
    @pytest.mark.asyncio
    async def test_missing_action(self, ctx):
        tool = GitTool()
        result = await tool.call(ctx)
        assert result.is_error
        assert "action is required" in result.content

    @pytest.mark.asyncio
    async def test_invalid_action(self, ctx):
        tool = GitTool()
        result = await tool.call(ctx, action="invalid_action")
        assert result.is_error
        assert "Unknown" in result.content

    @pytest.mark.asyncio
    async def test_not_git_repo(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        tool = GitTool()
        result = await tool.call(ctx, action="status")
        assert result.is_error
        assert "Not a git repository" in result.content

    def test_is_git_repo(self, temp_dir):
        tool = GitTool()
        assert not tool._is_git_repo(temp_dir)

        git_dir = os.path.join(temp_dir, ".git")
        os.makedirs(git_dir)
        assert tool._is_git_repo(temp_dir)

    def test_tool_properties(self):
        tool = GitTool()
        assert tool.name == "Git"
        assert not tool.is_read_only
        assert tool.is_destructive
        assert tool.requires_approval


class TestApplyPatchTool:
    @pytest.mark.asyncio
    async def test_empty_patch(self, ctx):
        tool = ApplyPatchTool()
        result = await tool.call(ctx, patch_content="")
        assert result.is_error
        assert "required" in result.content.lower()

    @pytest.mark.asyncio
    async def test_invalid_patch(self, ctx):
        tool = ApplyPatchTool()
        result = await tool.call(ctx, patch_content="not a valid patch")
        assert result.is_error

    @pytest.mark.asyncio
    async def test_patch_nonexistent_file(self, ctx):
        patch = """--- a/test.txt
+++ b/test.txt
@@ -1,1 +1,1 @@
-old
+new
"""
        tool = ApplyPatchTool()
        result = await tool.call(ctx, patch_content=patch)
        assert not result.is_error
        assert "not found" in result.content.lower() or "Skipped" in result.content

    @pytest.mark.asyncio
    async def test_valid_patch(self, ctx, temp_dir):
        path = os.path.join(temp_dir, "test.txt")
        with open(path, "w") as f:
            f.write("old content\n")

        patch = f"""--- a/test.txt
+++ b/test.txt
@@ -1,1 +1,1 @@
-old content
+new content
"""
        tool = ApplyPatchTool()
        result = await tool.call(ctx, patch_content=patch)
        assert not result.is_error

    def test_parse_patch(self):
        tool = ApplyPatchTool()
        patch = """--- a/file.py
+++ b/file.py
@@ -1,3 +1,3 @@
 line1
-old
+new
 line3
"""
        patches = tool._parse_patch(patch)
        assert len(patches) == 1
        assert patches[0]["file"] == "file.py"
        assert len(patches[0]["hunks"]) == 1

    def test_tool_properties(self):
        tool = ApplyPatchTool()
        assert tool.name == "ApplyPatch"
        assert not tool.is_read_only
        assert not tool.is_destructive
        assert tool.requires_approval


class TestBatchTool:
    @pytest.mark.asyncio
    async def test_empty_calls(self, ctx):
        tool = BatchTool()
        result = await tool.call(ctx, calls=[])
        assert result.is_error
        assert "calls list is required" in result.content

    @pytest.mark.asyncio
    async def test_too_many_calls(self, ctx):
        tool = BatchTool()
        calls = [ToolCallSpec(tool_name="Bash", args={"command": "echo"}) for _ in range(51)]
        result = await tool.call(ctx, calls=calls)
        assert result.is_error
        assert "Too many" in result.content

    @pytest.mark.asyncio
    async def test_unknown_tool(self, ctx):
        tool = BatchTool()
        result = await tool.call(ctx, calls=[ToolCallSpec(tool_name="UnknownTool", args={})])
        assert "Unknown tool" in result.content or "ERROR" in result.content

    def test_tool_properties(self):
        tool = BatchTool()
        assert tool.name == "Batch"
        assert not tool.is_read_only


class TestPlanTool:
    @pytest.mark.asyncio
    async def test_missing_action(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx)
        assert result.is_error
        assert "action is required" in result.content

    @pytest.mark.asyncio
    async def test_invalid_action(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx, action="invalid")
        assert result.is_error
        assert "Unknown action" in result.content

    @pytest.mark.asyncio
    async def test_enter_plan(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx, action="enter", plan_content="Test plan")
        assert not result.is_error
        assert "Entered plan mode" in result.content

    @pytest.mark.asyncio
    async def test_enter_missing_content(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx, action="enter")
        assert result.is_error
        assert "plan_content is required" in result.content

    @pytest.mark.asyncio
    async def test_status_not_in_plan(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx, action="status")
        assert not result.is_error
        assert "Not in plan mode" in result.content

    @pytest.mark.asyncio
    async def test_exit_not_in_plan(self, ctx):
        tool = PlanTool()
        result = await tool.call(ctx, action="exit")
        assert not result.is_error
        assert "Not in plan mode" in result.content

    @pytest.mark.asyncio
    async def test_update_after_enter(self, ctx):
        tool = PlanTool()
        await tool.call(ctx, action="enter", plan_content="Initial plan")
        result = await tool.call(ctx, action="update", plan_content="Updated plan")
        assert not result.is_error
        assert "Plan updated" in result.content

    @pytest.mark.asyncio
    async def test_status_after_enter(self, ctx):
        tool = PlanTool()
        await tool.call(ctx, action="enter", plan_content="1. Step one\n2. Step two")
        result = await tool.call(ctx, action="status")
        assert not result.is_error
        assert "Step one" in result.content
        assert "Step two" in result.content

    @pytest.mark.asyncio
    async def test_append_to_plan(self, ctx):
        tool = PlanTool()
        await tool.call(ctx, action="enter", plan_content="Initial")
        result = await tool.call(ctx, action="append", plan_content="Added")
        assert not result.is_error
        assert "Appended" in result.content

    @pytest.mark.asyncio
    async def test_prepend_to_plan(self, ctx):
        tool = PlanTool()
        await tool.call(ctx, action="enter", plan_content="Initial")
        result = await tool.call(ctx, action="prepend", plan_content="Prepended")
        assert not result.is_error
        assert "Prepended" in result.content

    def test_parse_steps(self):
        tool = PlanTool()
        content = "1. First step\n2. Second step\n- Bullet item\n* Another bullet"
        steps = tool._parse_steps(content)
        assert "First step" in steps
        assert "Second step" in steps
        assert "Bullet item" in steps
        assert "Another bullet" in steps

    def test_tool_properties(self):
        tool = PlanTool()
        assert tool.name == "Plan"
        assert not tool.is_read_only
