"""Tests for ProjectInitializer."""

from __future__ import annotations

import tempfile
from pathlib import Path

from openlaoke.core.hyperauto import (
    InitResult,
    ProjectAnalysis,
    ProjectInitializer,
    ProjectType,
)


class TestProjectTypeDetection:
    def test_detect_python_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "pyproject.toml").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.PYTHON

    def test_detect_nodejs_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "package.json").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.NODE_JS

    def test_detect_go_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "go.mod").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.GO

    def test_detect_rust_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "Cargo.toml").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.RUST

    def test_detect_java_maven_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "pom.xml").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.JAVA_MAVEN

    def test_detect_java_gradle_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "build.gradle").touch()

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.JAVA_GRADLE

    def test_detect_generic_project(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.detect_project_type(tmp_path)

            assert result == ProjectType.GENERIC

    def test_detect_none_for_invalid_path(self):
        initializer = ProjectInitializer()
        result = initializer.detect_project_type(Path("/nonexistent/path"))

        assert result is None


class TestProjectAnalysis:
    def test_analyze_empty_directory(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)

            assert analysis.project_type == ProjectType.GENERIC
            assert not analysis.has_git
            assert not analysis.has_readme
            assert not analysis.has_agents_md
            assert not analysis.has_tests
            assert not analysis.has_ci

    def test_analyze_python_project_with_tests(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "pyproject.toml").write_text("[project]\nname = 'test'")
            (tmp_path / "tests").mkdir()
            (tmp_path / "tests" / "__init__.py").touch()

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)

            assert analysis.project_type == ProjectType.PYTHON
            assert analysis.has_tests

    def test_analyze_existing_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "README.md").touch()
            (tmp_path / "AGENTS.md").touch()
            (tmp_path / ".gitignore").touch()

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)

            assert analysis.has_readme
            assert analysis.has_agents_md


class TestConfigGeneration:
    def test_generate_gitignore_for_python(self):
        initializer = ProjectInitializer()
        content = initializer._generate_gitignore(ProjectType.PYTHON)

        assert "__pycache__" in content
        assert "*.py[cod]" in content
        assert ".pytest_cache" in content
        assert ".DS_Store" in content

    def test_generate_gitignore_for_nodejs(self):
        initializer = ProjectInitializer()
        content = initializer._generate_gitignore(ProjectType.NODE_JS)

        assert "node_modules" in content
        assert "npm-debug.log" in content
        assert ".DS_Store" in content

    def test_generate_gitignore_for_go(self):
        initializer = ProjectInitializer()
        content = initializer._generate_gitignore(ProjectType.GO)

        assert "*.exe" in content
        assert "go.work" in content
        assert ".DS_Store" in content

    def test_generate_gitignore_for_rust(self):
        initializer = ProjectInitializer()
        content = initializer._generate_gitignore(ProjectType.RUST)

        assert "target/" in content
        assert "Cargo.lock" in content
        assert ".DS_Store" in content

    def test_generate_gitignore_for_java(self):
        initializer = ProjectInitializer()
        content = initializer._generate_gitignore(ProjectType.JAVA_MAVEN)

        assert "*.class" in content
        assert "target/" in content
        assert ".DS_Store" in content

    def test_generate_readme_contains_project_name(self):
        with tempfile.TemporaryDirectory(suffix="test_project") as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)
            content = initializer._generate_readme(analysis)

            assert tmp_path.name in content
            assert "Installation" in content
            assert "Usage" in content
            assert "Testing" in content

    def test_generate_agents_md(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)
            content = initializer._generate_agents_md(analysis)

            assert "# AGENTS.md" in content
            assert "Commands" in content
            assert "Setup" in content

    def test_generate_pyproject_toml(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            (tmp_path / "pyproject.toml").touch()

            initializer = ProjectInitializer()
            analysis = initializer.analyze_project(tmp_path)
            content = initializer._generate_pyproject(analysis)

            assert "[build-system]" in content
            assert "[project]" in content
            assert "requires-python" in content
            assert "[tool.ruff]" in content
            assert "[tool.mypy]" in content


class TestProjectStructure:
    def test_create_python_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.PYTHON)

            assert result
            assert (tmp_path / "src").exists()
            assert (tmp_path / "tests").exists()
            assert (tmp_path / "tests" / "__init__.py").exists()
            assert (tmp_path / "docs").exists()

    def test_create_nodejs_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.NODE_JS)

            assert result
            assert (tmp_path / "src").exists()
            assert (tmp_path / "tests").exists()
            assert (tmp_path / "lib").exists()

    def test_create_go_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.GO)

            assert result
            assert (tmp_path / "cmd").exists()
            assert (tmp_path / "pkg").exists()
            assert (tmp_path / "internal").exists()

    def test_create_rust_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.RUST)

            assert result
            assert (tmp_path / "src").exists()

    def test_create_java_maven_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.JAVA_MAVEN)

            assert result
            assert (tmp_path / "src" / "main" / "java").exists()
            assert (tmp_path / "src" / "test" / "java").exists()

    def test_create_generic_structure(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            initializer = ProjectInitializer()
            result = initializer.create_project_structure(tmp_path, ProjectType.GENERIC)

            assert result
            assert (tmp_path / "src").exists()
            assert (tmp_path / "docs").exists()


class TestGetRequiredFiles:
    def test_python_required_files(self):
        initializer = ProjectInitializer()
        files = initializer.get_required_files(ProjectType.PYTHON)

        assert "README.md" in files
        assert ".gitignore" in files
        assert "AGENTS.md" in files

    def test_nodejs_required_files(self):
        initializer = ProjectInitializer()
        files = initializer.get_required_files(ProjectType.NODE_JS)

        assert "README.md" in files
        assert ".gitignore" in files
        assert "AGENTS.md" in files

    def test_generic_required_files(self):
        initializer = ProjectInitializer()
        files = initializer.get_required_files(ProjectType.GENERIC)

        assert "README.md" in files
        assert ".gitignore" in files
        assert "AGENTS.md" in files


class TestInitResult:
    def test_init_result_dataclass(self):
        result = InitResult(
            success=True,
            project_type=ProjectType.PYTHON,
            path=Path("/tmp/test"),
            files_created=["README.md", ".gitignore"],
            files_skipped=["pyproject.toml"],
            errors=[],
            warnings=["Git not initialized"],
            next_steps=["Install dependencies"],
        )

        assert result.success
        assert result.project_type == ProjectType.PYTHON
        assert len(result.files_created) == 2
        assert len(result.files_skipped) == 1
        assert len(result.errors) == 0
        assert len(result.warnings) == 1
        assert len(result.next_steps) == 1


class TestProjectAnalysisDataclass:
    def test_project_analysis_dataclass(self):
        analysis = ProjectAnalysis(
            project_type=ProjectType.NODE_JS,
            path=Path("/tmp/test"),
            has_git=True,
            has_readme=True,
            has_agents_md=False,
            has_tests=True,
            has_ci=False,
            existing_files=["package.json", "README.md"],
            missing_files=["AGENTS.md"],
            dependencies=["express", "typescript"],
            suggested_structure={"directories": ["__tests__"]},
        )

        assert analysis.project_type == ProjectType.NODE_JS
        assert analysis.has_git
        assert analysis.has_readme
        assert not analysis.has_agents_md
        assert analysis.has_tests
        assert len(analysis.existing_files) == 2
        assert len(analysis.missing_files) == 1
        assert len(analysis.dependencies) == 2
