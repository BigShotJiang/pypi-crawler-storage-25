"""Tests for the task scheduler system."""

from __future__ import annotations

import asyncio
import time
from typing import Any

import pytest

from openlaoke.core.scheduler import (
    PriorityQueue,
    ScheduledTask,
    TaskExecutor,
    TaskResult,
    TaskScheduler,
    TimeoutHandler,
)
from openlaoke.types.core_types import TaskStatus


class TestPriorityQueue:
    """Tests for PriorityQueue."""

    def test_basic_operations(self) -> None:
        """Test basic put and get operations."""
        queue = PriorityQueue()

        queue.put("item1", priority=1)
        queue.put("item2", priority=0)
        queue.put("item3", priority=2)

        assert queue.qsize() == 3
        assert queue.get() == "item2"
        assert queue.get() == "item1"
        assert queue.get() == "item3"
        assert queue.empty()

    def test_priority_order(self) -> None:
        """Test that items are retrieved by priority."""
        queue = PriorityQueue()

        queue.put("low", priority=10)
        queue.put("high", priority=1)
        queue.put("medium", priority=5)

        assert queue.get() == "high"
        assert queue.get() == "medium"
        assert queue.get() == "low"

    def test_blocking_get(self) -> None:
        """Test blocking get with timeout."""
        queue = PriorityQueue()

        result = queue.get(block=False)
        assert result is None

        result = queue.get(block=True, timeout=0.1)
        assert result is None

    def test_maxsize(self) -> None:
        """Test queue with maxsize."""
        queue = PriorityQueue(maxsize=2)

        assert queue.put("item1", priority=1)
        assert queue.put("item2", priority=2)
        assert queue.full()

        result = queue.put("item3", priority=3, block=False)
        assert not result

    def test_peek(self) -> None:
        """Test peek operation."""
        queue = PriorityQueue()

        queue.put("item1", priority=1)
        queue.put("item2", priority=0)

        assert queue.peek() == "item2"
        assert queue.qsize() == 2

    def test_clear(self) -> None:
        """Test clear operation."""
        queue = PriorityQueue()

        queue.put("item1", priority=1)
        queue.put("item2", priority=2)
        queue.clear()

        assert queue.empty()


class TestTimeoutHandler:
    """Tests for TimeoutHandler."""

    @pytest.mark.asyncio
    async def test_with_timeout_success(self) -> None:
        """Test successful execution with timeout."""
        handler = TimeoutHandler(default_timeout=5.0)

        async def quick_task() -> str:
            await asyncio.sleep(0.1)
            return "done"

        result = await handler.with_timeout(quick_task(), timeout=1.0, task_id="test1")
        assert result == "done"

    @pytest.mark.asyncio
    async def test_with_timeout_exceeded(self) -> None:
        """Test timeout exceeded."""
        handler = TimeoutHandler(default_timeout=5.0)

        async def slow_task() -> str:
            await asyncio.sleep(10.0)
            return "done"

        with pytest.raises(TimeoutError):
            await handler.with_timeout(slow_task(), timeout=1.0, task_id="test2")

    def test_set_timeout(self) -> None:
        """Test setting a timeout callback."""
        handler = TimeoutHandler()

        callback_called = []

        def callback() -> None:
            callback_called.append(True)

        handle = handler.set_timeout("test3", 0.1, callback)

        time.sleep(0.2)
        assert callback_called

        handle.cancel()

    def test_cancel_timeout(self) -> None:
        """Test cancelling a timeout."""
        handler = TimeoutHandler()

        callback_called = []

        def callback() -> None:
            callback_called.append(True)

        handler.set_timeout("test4", 0.5, callback)
        cancelled = handler.cancel_timeout("test4")

        assert cancelled
        time.sleep(0.6)
        assert not callback_called

    def test_get_remaining_time(self) -> None:
        """Test getting remaining time."""
        handler = TimeoutHandler()

        handler.set_timeout("test5", 5.0, lambda: None)
        remaining = handler.get_remaining_time("test5")

        assert remaining is not None
        assert 4.0 < remaining < 5.0

        handler.cancel_timeout("test5")


class TestTaskExecutor:
    """Tests for TaskExecutor."""

    @pytest.mark.asyncio
    async def test_execute_sync_function(self) -> None:
        """Test executing a synchronous function."""
        executor = TaskExecutor(max_workers=2)

        def sync_func(x: int) -> int:
            return x * 2

        result = await executor.execute("test1", sync_func, 5)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == 10
        assert result.error is None

        executor.shutdown()

    @pytest.mark.asyncio
    async def test_execute_async_function(self) -> None:
        """Test executing an async function."""
        executor = TaskExecutor(max_workers=2)

        async def async_func(x: int) -> int:
            await asyncio.sleep(0.1)
            return x * 3

        result = await executor.execute_async("test2", async_func(5), timeout=1.0)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == 15

        executor.shutdown()

    @pytest.mark.asyncio
    async def test_execute_with_timeout(self) -> None:
        """Test execution with timeout."""
        executor = TaskExecutor(max_workers=2)

        def slow_func() -> None:
            time.sleep(10.0)

        result = await executor.execute("test3", slow_func, timeout=0.5)

        assert result.status == TaskStatus.FAILED
        assert "Timeout" in result.error or "timeout" in result.error.lower()

        executor.shutdown()

    @pytest.mark.asyncio
    async def test_execute_with_retries(self) -> None:
        """Test execution with retries."""
        executor = TaskExecutor(max_workers=2, max_retries=3, retry_delay=0.1)

        attempts = []

        def flaky_func() -> str:
            attempts.append(1)
            if len(attempts) < 3:
                raise ValueError("Not yet")
            return "success"

        result = await executor.execute("test4", flaky_func, retries=3)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == "success"
        assert len(attempts) == 3

        executor.shutdown()


class TestTaskScheduler:
    """Tests for TaskScheduler."""

    @pytest.mark.asyncio
    async def test_submit_single_task(self) -> None:
        """Test submitting a single task."""
        scheduler = TaskScheduler(max_concurrent=2)
        await scheduler.start()

        def simple_task() -> str:
            return "hello"

        result = await scheduler.submit(simple_task, priority=0, timeout=5.0)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == "hello"

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_submit_async_task(self) -> None:
        """Test submitting an async task."""
        scheduler = TaskScheduler(max_concurrent=2)
        await scheduler.start()

        async def async_task() -> str:
            await asyncio.sleep(0.1)
            return "async_result"

        result = await scheduler.submit(async_task, timeout=5.0)

        assert result.status == TaskStatus.COMPLETED
        assert result.result == "async_result"

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_submit_batch_parallel(self) -> None:
        """Test submitting batch tasks in parallel."""
        scheduler = TaskScheduler(max_concurrent=5)
        await scheduler.start()

        def task(n: int) -> int:
            time.sleep(0.1)
            return n * 2

        tasks = [(task, (i,), {}) for i in range(5)]
        results = await scheduler.submit_batch(tasks, parallel=True, timeout=10.0)

        assert len(results) == 5
        for i, result in enumerate(results):
            assert result.status == TaskStatus.COMPLETED
            assert result.result == i * 2

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_submit_batch_sequential(self) -> None:
        """Test submitting batch tasks sequentially."""
        scheduler = TaskScheduler(max_concurrent=2)
        await scheduler.start()

        def task(n: int) -> int:
            return n * 3

        tasks = [(task, (i,), {}) for i in range(3)]
        results = await scheduler.submit_batch(tasks, parallel=False, timeout=10.0)

        assert len(results) == 3
        for i, result in enumerate(results):
            assert result.status == TaskStatus.COMPLETED
            assert result.result == i * 3

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_cancel_task(self) -> None:
        """Test cancelling a task."""
        scheduler = TaskScheduler(max_concurrent=2)
        await scheduler.start()

        def slow_task() -> None:
            time.sleep(10.0)

        task_id = f"cancel_test_{time.time()}"

        submit_coro = scheduler.submit(slow_task, timeout=15.0, task_id=task_id)

        await asyncio.sleep(0.1)

        cancelled = await scheduler.cancel(task_id)

        if cancelled:
            result = await submit_coro
            assert result.status == TaskStatus.KILLED
            assert "Cancelled" in result.error or "cancelled" in result.error.lower()

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_get_status(self) -> None:
        """Test getting task status."""
        scheduler = TaskScheduler(max_concurrent=2)
        await scheduler.start()

        def quick_task() -> str:
            return "done"

        result = await scheduler.submit(quick_task, timeout=5.0)
        status = await scheduler.get_status(result.task_id)

        assert status == TaskStatus.COMPLETED

        await scheduler.shutdown()

    @pytest.mark.asyncio
    async def test_get_stats(self) -> None:
        """Test getting scheduler statistics."""
        scheduler = TaskScheduler(max_concurrent=3)

        stats = scheduler.get_stats()
        assert stats["total"] == 0
        assert stats["pending"] == 0
        assert stats["running"] == 0

        await scheduler.start()

        def task() -> str:
            time.sleep(0.2)
            return "result"

        await scheduler.submit(task, timeout=5.0)

        stats = scheduler.get_stats()
        assert stats["total"] == 1

        await scheduler.shutdown()


class TestScheduledTask:
    """Tests for ScheduledTask dataclass."""

    def test_creation(self) -> None:
        """Test creating a ScheduledTask."""
        task = ScheduledTask(
            id="test_task",
            func=lambda: "result",
            priority=5,
            timeout=10.0,
        )

        assert task.id == "test_task"
        assert task.priority == 5
        assert task.timeout == 10.0
        assert task.status == TaskStatus.PENDING
        assert task.kwargs == {}

    def test_with_args_kwargs(self) -> None:
        """Test ScheduledTask with args and kwargs."""
        task = ScheduledTask(
            id="test_task",
            func=lambda x, y: x + y,
            args=(5,),
            kwargs={"y": 10},
            priority=1,
        )

        assert task.args == (5,)
        assert task.kwargs == {"y": 10}


class TestTaskResult:
    """Tests for TaskResult dataclass."""

    def test_success_result(self) -> None:
        """Test successful task result."""
        result = TaskResult(
            task_id="test",
            status=TaskStatus.COMPLETED,
            result="success",
            duration=1.5,
        )

        assert result.task_id == "test"
        assert result.status == TaskStatus.COMPLETED
        assert result.result == "success"
        assert result.error is None
        assert result.duration == 1.5

    def test_error_result(self) -> None:
        """Test error task result."""
        result = TaskResult(
            task_id="test",
            status=TaskStatus.FAILED,
            error="Task failed",
        )

        assert result.status == TaskStatus.FAILED
        assert result.result is None
        assert result.error == "Task failed"
