"""Tests for permission classifier and command classification."""

import pytest

from openlaoke.types.core_types import PermissionMode, PermissionResult
from openlaoke.types.permissions import PermissionConfig, PermissionRule


class TestBashClassifier:
    def test_safe_read_commands(self):
        config = PermissionConfig.defaults()
        safe_commands = ["ls", "cat", "echo", "pwd", "whoami", "date", "uname"]

        for cmd in safe_commands:
            result = config.check_tool("Bash")
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_write_commands_need_approval(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Write")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_destructive_commands_need_approval(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Git")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)


class TestSafeCommands:
    def test_read_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Read")
        assert result == PermissionResult.ALLOW

    def test_glob_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Glob")
        assert result == PermissionResult.ALLOW

    def test_grep_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Grep")
        assert result == PermissionResult.ALLOW

    def test_webfetch_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("WebFetch")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_websearch_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("WebSearch")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_question_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Question")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_listdirectory_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("ListDirectory")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_lsp_tool_allowed(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("LSP")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)


class TestDangerousCommands:
    def test_edit_tool_ask(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Edit")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_write_tool_ask(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Write")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_applypatch_tool_ask(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("ApplyPatch")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_batch_tool_handling(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Batch")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)


class TestDestructiveCommands:
    def test_git_tool_needs_approval(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Git")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK, PermissionResult.DENY)

    def test_agent_tool_ask(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("Agent")
        assert result == PermissionResult.ASK

    def test_taskkill_tool_handling(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("TaskKill")
        assert result in (PermissionResult.ALLOW, PermissionResult.ASK)


class TestPermissionModes:
    def test_bypass_mode_allows_all(self):
        config = PermissionConfig(mode=PermissionMode.BYPASS)
        assert config.check_tool("Bash") == PermissionResult.ALLOW
        assert config.check_tool("Write") == PermissionResult.ALLOW
        assert config.check_tool("Git") == PermissionResult.ALLOW
        assert config.check_tool("Agent") == PermissionResult.ALLOW

    def test_auto_mode_allows_safe(self):
        config = PermissionConfig(mode=PermissionMode.AUTO)
        assert config.check_tool("Read") == PermissionResult.ALLOW
        assert config.check_tool("Glob") == PermissionResult.ALLOW

    def test_default_mode_asks_for_dangerous(self):
        config = PermissionConfig(mode=PermissionMode.DEFAULT)
        assert config.check_tool("Agent") == PermissionResult.ASK

    def test_unknown_tool_handling(self):
        config = PermissionConfig.defaults()
        result = config.check_tool("UnknownTool")
        assert result == PermissionResult.ASK


class TestPermissionRules:
    def test_custom_always_allow_rule(self):
        rule = PermissionRule("CustomTool*", PermissionResult.ALLOW)
        config = PermissionConfig(always_allow_rules=[rule])
        assert config.check_tool("CustomTool1") == PermissionResult.ALLOW
        assert config.check_tool("CustomTool2") == PermissionResult.ALLOW

    def test_custom_deny_rule(self):
        rule = PermissionRule("DangerousTool", PermissionResult.DENY)
        config = PermissionConfig(always_deny_rules=[rule])
        assert config.check_tool("DangerousTool") == PermissionResult.DENY

    def test_pattern_matching(self):
        rule = PermissionRule("Test*", PermissionResult.ALLOW)
        config = PermissionConfig(always_allow_rules=[rule])
        assert config.check_tool("TestTool") == PermissionResult.ALLOW
        assert config.check_tool("Testing") == PermissionResult.ALLOW

    def test_exact_match(self):
        rule = PermissionRule("ExactTool", PermissionResult.ALLOW)
        config = PermissionConfig(always_allow_rules=[rule])
        assert config.check_tool("ExactTool") == PermissionResult.ALLOW
        assert config.check_tool("ExactToolExtra") == PermissionResult.ASK

    def test_multiple_rules_priority(self):
        allow_rule = PermissionRule("Tool*", PermissionResult.ALLOW)
        deny_rule = PermissionRule("ToolDangerous", PermissionResult.DENY)
        config = PermissionConfig(
            always_allow_rules=[allow_rule],
            always_deny_rules=[deny_rule],
        )
        assert config.check_tool("ToolSafe") == PermissionResult.ALLOW


class TestToolApproval:
    def test_approve_tool(self):
        config = PermissionConfig.defaults()
        config.approve_tool("Bash", remember=True)
        assert config.check_tool("Bash") == PermissionResult.ALLOW

    def test_approve_unknown_tool(self):
        config = PermissionConfig.defaults()
        config.approve_tool("UnknownTool", remember=True)
        assert config.check_tool("UnknownTool") == PermissionResult.ALLOW

    def test_deny_tool(self):
        config = PermissionConfig.defaults()
        config.approve_tool("DangerousTool", remember=True)
        assert config.check_tool("DangerousTool") == PermissionResult.ALLOW
        config.deny_tool("DangerousTool")
        assert "DangerousTool" not in config.approved_tools


class TestPermissionConfigDefaults:
    def test_defaults_creation(self):
        config = PermissionConfig.defaults()
        assert config.mode == PermissionMode.DEFAULT

    def test_defaults_read_allowed(self):
        config = PermissionConfig.defaults()
        assert config.check_tool("Read") == PermissionResult.ALLOW

    def test_defaults_bash_allowed(self):
        config = PermissionConfig.defaults()
        assert config.check_tool("Bash") == PermissionResult.ALLOW

    def test_defaults_agent_ask(self):
        config = PermissionConfig.defaults()
        assert config.check_tool("Agent") == PermissionResult.ASK


class TestPermissionResult:
    def test_result_values(self):
        assert PermissionResult.ALLOW.value == "allow"
        assert PermissionResult.ASK.value == "ask"
        assert PermissionResult.DENY.value == "deny"

    def test_result_comparison(self):
        assert PermissionResult.ALLOW != PermissionResult.ASK
        assert PermissionResult.ASK != PermissionResult.DENY


class TestPermissionMode:
    def test_mode_values(self):
        assert PermissionMode.DEFAULT.value == "default"
        assert PermissionMode.AUTO.value == "auto"
        assert PermissionMode.BYPASS.value == "bypass"

    def test_mode_from_string(self):
        assert PermissionMode("default") == PermissionMode.DEFAULT
        assert PermissionMode("auto") == PermissionMode.AUTO
        assert PermissionMode("bypass") == PermissionMode.BYPASS

    def test_invalid_mode(self):
        with pytest.raises(ValueError):
            PermissionMode("invalid")


class TestRulePatterns:
    def test_wildcard_end_pattern(self):
        rule = PermissionRule("Web*", PermissionResult.ALLOW)
        assert rule.matches("WebFetch")
        assert rule.matches("WebSearch")
        assert not rule.matches("Other")

    def test_wildcard_middle_pattern(self):
        rule = PermissionRule("Test*Tool", PermissionResult.ALLOW)
        config = PermissionConfig(always_allow_rules=[rule])
        assert config.check_tool("TestOneTool") == PermissionResult.ALLOW
        assert config.check_tool("TestTwoTool") == PermissionResult.ALLOW
        assert config.check_tool("TestingTool") == PermissionResult.ALLOW

    def test_no_wildcard_exact_match(self):
        rule = PermissionRule("Bash", PermissionResult.ALLOW)
        assert rule.matches("Bash")
        assert not rule.matches("BashTool")
        assert not rule.matches("OtherBash")

    def test_empty_pattern(self):
        rule = PermissionRule("", PermissionResult.ALLOW)
        assert not rule.matches("AnyTool")


class TestConcurrentSafeTools:
    def test_read_only_tools_safe(self):
        safe_tools = ["Read", "Glob", "Grep", "WebFetch", "WebSearch", "LSP"]
        config = PermissionConfig.defaults()

        for tool in safe_tools:
            result = config.check_tool(tool)
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)


class TestToolCategories:
    def test_file_read_category(self):
        config = PermissionConfig.defaults()
        read_tools = ["Read", "Glob", "Grep", "ListDirectory"]
        for tool in read_tools:
            result = config.check_tool(tool)
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_file_write_category(self):
        config = PermissionConfig.defaults()
        write_tools = ["Write", "Edit", "ApplyPatch"]
        for tool in write_tools:
            result = config.check_tool(tool)
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_system_category(self):
        config = PermissionConfig.defaults()
        system_tools = ["Bash", "Git"]
        for tool in system_tools:
            result = config.check_tool(tool)
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)

    def test_network_category(self):
        config = PermissionConfig.defaults()
        network_tools = ["WebFetch", "WebSearch"]
        for tool in network_tools:
            result = config.check_tool(tool)
            assert result in (PermissionResult.ALLOW, PermissionResult.ASK)
