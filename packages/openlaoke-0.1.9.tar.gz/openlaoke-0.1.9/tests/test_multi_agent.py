"""Basic tests for multi-agent system."""

from __future__ import annotations

import pytest

from openlaoke.core.multi_agent import (
    AgentCoordinator,
    AgentMailbox,
    AgentPool,
    AgentRole,
    AgentState,
    AgentType,
    Assignment,
    Conflict,
    ConflictResolution,
    ConflictResolver,
    GlobalState,
    Message,
    MessagePriority,
    MessageType,
    Priority,
    ResolutionStrategy,
    Team,
    TeamMember,
    TeamResult,
    TaskDistributor,
)


def test_agent_types():
    assert AgentType.COORDINATOR == "coordinator"
    assert AgentType.EXPLORER == "explorer"
    assert AgentType.IMPLEMENTER == "implementer"
    assert AgentType.REVIEWER == "reviewer"
    assert AgentType.TESTER == "tester"
    assert AgentType.RESEARCHER == "researcher"
    assert AgentType.ANALYZER == "analyzer"


def test_agent_pool_creation():
    pool = AgentPool(max_agents=3)
    assert pool.max_agents == 3
    assert pool.active_count == 0
    assert pool.total_count == 0


def test_agent_mailbox_creation():
    mailbox = AgentMailbox()
    assert mailbox.max_queue_size == 1000
    stats = mailbox.get_stats()
    assert stats["queue_count"] == 0
    assert stats["total_messages"] == 0


def test_message_creation():
    message = Message(
        sender="agent_1",
        content="Test message",
        recipients=["agent_2"],
    )
    assert message.sender == "agent_1"
    assert message.content == "Test message"
    assert message.message_type == MessageType.TASK
    assert message.priority == MessagePriority.NORMAL


def test_priority_comparison():
    assert Priority.LOW < Priority.MEDIUM
    assert Priority.MEDIUM < Priority.HIGH
    assert Priority.HIGH < Priority.URGENT
    assert Priority.URGENT > Priority.HIGH


def test_task_distributor_creation():
    distributor = TaskDistributor()
    assert distributor.config.max_retries == 3
    stats = distributor.get_stats()
    assert stats["total_assignments"] == 0


def test_conflict_resolver_creation():
    resolver = ConflictResolver()
    assert resolver.default_strategy == ResolutionStrategy.COORDINATOR_DECIDES
    stats = resolver.get_stats()
    assert stats["total_conflicts"] == 0
    assert stats["pending_conflicts"] == 0


def test_conflict_creation():
    conflict = Conflict(
        agents_involved=["agent_1", "agent_2"],
        description="Resource conflict",
    )
    assert len(conflict.agents_involved) == 2
    assert conflict.description == "Resource conflict"


def test_team_creation():
    team = Team(name="TestTeam")
    assert team.name == "TestTeam"
    assert team.status == "forming"
    assert len(team.members) == 0


def test_team_member_creation():
    member = TeamMember(
        agent_id="agent_1",
        role=AgentRole.LEADER,
    )
    assert member.agent_id == "agent_1"
    assert member.role == AgentRole.LEADER


def test_team_add_member():
    team = Team(name="TestTeam")
    success = team.add_member("agent_1", AgentRole.LEADER)
    assert success is True
    assert len(team.members) == 1
    assert team.get_leader().agent_id == "agent_1"


def test_agent_state_creation():
    state = AgentState(
        agent_id="agent_123",
        agent_type=AgentType.IMPLEMENTER,
    )
    assert state.agent_id == "agent_123"
    assert state.agent_type == AgentType.IMPLEMENTER
    assert state.status == "idle"


@pytest.mark.asyncio
async def test_agent_coordinator_creation():
    coordinator = AgentCoordinator(max_agents=3)
    assert coordinator.max_agents == 3
    assert coordinator.agent_pool.max_agents == 3
    assert coordinator.mailbox is not None


@pytest.mark.asyncio
async def test_agent_coordinator_broadcast():
    coordinator = AgentCoordinator(max_agents=3)
    message = Message(
        sender="coordinator",
        content="Broadcast test",
        message_type=MessageType.BROADCAST,
    )
    await coordinator.broadcast(message)
    stats = coordinator.mailbox.get_stats()
    assert stats["total_messages"] == 0


@pytest.mark.asyncio
async def test_agent_coordinator_sync_state():
    coordinator = AgentCoordinator(max_agents=3)
    state = await coordinator.sync_state()
    assert isinstance(state, GlobalState)
    assert state.active_agents == 0
    assert state.total_tasks == 0


@pytest.mark.asyncio
async def test_agent_pool_acquire_release():
    pool = AgentPool(max_agents=3)
    agent_id = await pool.acquire(AgentType.EXPLORER)
    assert agent_id.startswith("agent_")
    assert pool.active_count == 1
    await pool.release(agent_id)
    assert pool.active_count == 0


@pytest.mark.asyncio
async def test_agent_mailbox_send_receive():
    mailbox = AgentMailbox()
    message = Message(
        sender="agent_1",
        content="Test",
        recipients=["agent_2"],
    )
    await mailbox.send(message)
    received = await mailbox.receive("agent_2", timeout=1.0)
    assert received is not None
    assert received.sender == "agent_1"
    assert received.content == "Test"
