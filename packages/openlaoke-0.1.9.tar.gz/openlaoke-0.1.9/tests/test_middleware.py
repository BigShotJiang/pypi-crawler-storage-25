"""Tests for middleware system."""

from __future__ import annotations

import pytest

from openlaoke.core.middleware import (
    ErrorEvent,
    Event,
    MiddlewareChain,
    MiddlewareContext,
    ProgressEvent,
    SyncMiddleware,
    ThreadDataMiddleware,
)
from openlaoke.core.state import AppState


class SimpleMiddleware(SyncMiddleware):
    """Simple test middleware."""

    def process(self, context: MiddlewareContext) -> list[Event]:
        return [ProgressEvent(message="Processing")]


class CountingMiddleware(SyncMiddleware):
    """Middleware that counts calls."""

    def __init__(self) -> None:
        self.call_count = 0

    def process(self, context: MiddlewareContext) -> list[Event]:
        self.call_count += 1
        context.set_metadata("count", self.call_count)
        return []


@pytest.fixture
def app_state() -> AppState:
    """Create a test AppState."""
    return AppState(session_id="test_session", cwd="/tmp")


@pytest.fixture
def context(app_state: AppState) -> MiddlewareContext:
    """Create a test MiddlewareContext."""
    return MiddlewareContext(state=app_state, session_id="test_session")


def test_middleware_context_metadata(context: MiddlewareContext) -> None:
    """Test MiddlewareContext metadata operations."""
    context.set_metadata("key", "value")
    assert context.get_metadata("key") == "value"
    assert context.get_metadata("missing", "default") == "default"


def test_middleware_context_abort(context: MiddlewareContext) -> None:
    """Test MiddlewareContext abort functionality."""
    assert not context.aborted
    context.abort("test_reason")
    assert context.aborted
    assert context.get_metadata("abort_reason") == "test_reason"


def test_middleware_chain_add() -> None:
    """Test adding middleware to chain."""
    chain = MiddlewareChain()
    assert len(chain) == 0

    chain.add(SimpleMiddleware())
    assert len(chain) == 1

    chain.add(CountingMiddleware())
    assert len(chain) == 2


def test_middleware_chain_remove() -> None:
    """Test removing middleware from chain."""
    chain = MiddlewareChain()
    chain.add(SimpleMiddleware())
    chain.add(CountingMiddleware())

    assert len(chain) == 2
    assert chain.remove("SimpleMiddleware")
    assert len(chain) == 1
    assert not chain.remove("NonExistent")
    assert len(chain) == 1


def test_middleware_chain_get() -> None:
    """Test getting middleware from chain."""
    chain = MiddlewareChain()
    simple = SimpleMiddleware()
    chain.add(simple)

    found = chain.get("SimpleMiddleware")
    assert found is simple
    assert chain.get("NonExistent") is None


def test_middleware_chain_contains() -> None:
    """Test checking middleware presence."""
    chain = MiddlewareChain()
    chain.add(SimpleMiddleware())

    assert "SimpleMiddleware" in chain
    assert "NonExistent" not in chain


def test_middleware_chain_clear() -> None:
    """Test clearing middleware chain."""
    chain = MiddlewareChain()
    chain.add(SimpleMiddleware())
    chain.add(CountingMiddleware())

    assert len(chain) == 2
    chain.clear()
    assert len(chain) == 0


def test_middleware_chain_insert() -> None:
    """Test inserting middleware at position."""
    chain = MiddlewareChain()
    chain.add(SimpleMiddleware())
    chain.insert(0, CountingMiddleware())

    assert chain.middlewares[0].name == "CountingMiddleware"
    assert chain.middlewares[1].name == "SimpleMiddleware"


def test_syncmiddleware_name() -> None:
    """Test middleware name property."""
    mw = SimpleMiddleware()
    assert mw.name == "SimpleMiddleware"


def test_thread_data_middleware(app_state: AppState) -> None:
    """Test ThreadDataMiddleware."""
    mw = ThreadDataMiddleware()
    ctx = MiddlewareContext(state=app_state, session_id="test_session")

    events = mw.process(ctx)
    assert len(events) == 0
    assert "thread_data" in ctx.metadata


@pytest.mark.asyncio
async def test_middleware_chain_process(context: MiddlewareContext) -> None:
    """Test processing through middleware chain."""
    chain = MiddlewareChain()
    chain.add(SimpleMiddleware())

    events = []
    async for event in chain.process(context):
        events.append(event)

    assert len(events) == 1
    assert events[0].type == "progress"


@pytest.mark.asyncio
async def test_middleware_chain_abort(context: MiddlewareContext) -> None:
    """Test middleware chain abort."""
    chain = MiddlewareChain()

    class AbortMiddleware(SyncMiddleware):
        def process(self, ctx: MiddlewareContext) -> list[Event]:
            ctx.abort("test")
            return []

    chain.add(AbortMiddleware())
    chain.add(SimpleMiddleware())

    events = []
    async for event in chain.process(context):
        events.append(event)

    assert len(events) == 0


def test_event_to_dict() -> None:
    """Test Event serialization."""
    event = ProgressEvent(message="test", percentage=50.0)
    data = event.to_dict()

    assert data["type"] == "progress"
    assert data["data"]["message"] == "test"
    assert data["data"]["percentage"] == 50.0


def test_error_event() -> None:
    """Test ErrorEvent creation."""
    event = ErrorEvent(error="test error", error_type="TestError")
    assert event.type == "error"
    assert event.data["error"] == "test error"
    assert event.data["error_type"] == "TestError"
