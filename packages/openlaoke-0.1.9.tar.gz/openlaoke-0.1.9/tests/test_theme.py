"""Tests for theme system."""

import os
import tempfile
from dataclasses import dataclass, field
from typing import Any

import pytest

from openlaoke.core.state import AppState, create_app_state
from openlaoke.utils.config import AppConfig, load_config, save_config


@dataclass
class ThemeColors:
    """Color definitions for a theme."""

    background: str = "#1a1a1a"
    foreground: str = "#ffffff"
    accent: str = "#00ff88"
    error: str = "#ff4444"
    warning: str = "#ffaa00"
    success: str = "#00ff00"
    muted: str = "#666666"
    highlight: str = "#ffff00"


@dataclass
class Theme:
    """Theme configuration."""

    name: str = "dark"
    colors: ThemeColors = field(default_factory=ThemeColors)
    font_family: str = "monospace"
    font_size: int = 12
    line_height: float = 1.2
    padding: int = 10
    border_radius: int = 4
    custom_settings: dict[str, Any] = field(default_factory=dict)


class ThemeManager:
    """Manager for themes."""

    DEFAULT_DARK = Theme(
        name="dark",
        colors=ThemeColors(
            background="#1a1a1a",
            foreground="#ffffff",
            accent="#00ff88",
        ),
    )

    DEFAULT_LIGHT = Theme(
        name="light",
        colors=ThemeColors(
            background="#ffffff",
            foreground="#1a1a1a",
            accent="#0088ff",
        ),
    )

    def __init__(self):
        self._themes: dict[str, Theme] = {
            "dark": self.DEFAULT_DARK,
            "light": self.DEFAULT_LIGHT,
        }
        self._current_theme: str = "dark"
        self._custom_themes_dir: str = ""

    def get_theme(self, name: str | None = None) -> Theme:
        if name is None:
            name = self._current_theme
        return self._themes.get(name, self.DEFAULT_DARK)

    def set_theme(self, name: str) -> bool:
        if name in self._themes:
            self._current_theme = name
            return True
        return False

    def register_theme(self, theme: Theme) -> None:
        self._themes[theme.name] = theme

    def get_available_themes(self) -> list[str]:
        return list(self._themes.keys())

    def is_valid_theme(self, name: str) -> bool:
        return name in self._themes

    def load_custom_theme(self, path: str) -> Theme | None:
        import json

        try:
            with open(path) as f:
                data = json.load(f)

            colors = ThemeColors(
                background=data.get("background", "#1a1a1a"),
                foreground=data.get("foreground", "#ffffff"),
                accent=data.get("accent", "#00ff88"),
                error=data.get("error", "#ff4444"),
                warning=data.get("warning", "#ffaa00"),
                success=data.get("success", "#00ff00"),
                muted=data.get("muted", "#666666"),
                highlight=data.get("highlight", "#ffff00"),
            )

            theme = Theme(
                name=data.get("name", "custom"),
                colors=colors,
                font_family=data.get("font_family", "monospace"),
                font_size=data.get("font_size", 12),
                custom_settings=data.get("custom_settings", {}),
            )
            self.register_theme(theme)
            return theme
        except Exception:
            return None

    def save_custom_theme(self, theme: Theme, path: str) -> bool:
        import json

        try:
            data = {
                "name": theme.name,
                "background": theme.colors.background,
                "foreground": theme.colors.foreground,
                "accent": theme.colors.accent,
                "error": theme.colors.error,
                "warning": theme.colors.warning,
                "success": theme.colors.success,
                "muted": theme.colors.muted,
                "highlight": theme.colors.highlight,
                "font_family": theme.font_family,
                "font_size": theme.font_size,
                "custom_settings": theme.custom_settings,
            }
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
            return True
        except Exception:
            return False


@pytest.fixture
def theme_manager():
    return ThemeManager()


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def app_state():
    import openlaoke

    project_root = os.path.dirname(os.path.dirname(openlaoke.__file__))
    return create_app_state(cwd=project_root)


class TestThemeLoad:
    def test_default_theme(self, theme_manager):
        theme = theme_manager.get_theme()
        assert theme.name == "dark"
        assert theme.colors.background == "#1a1a1a"

    def test_load_dark_theme(self, theme_manager):
        theme = theme_manager.get_theme("dark")
        assert theme.name == "dark"
        assert theme.colors.foreground == "#ffffff"

    def test_load_light_theme(self, theme_manager):
        theme = theme_manager.get_theme("light")
        assert theme.name == "light"
        assert theme.colors.background == "#ffffff"
        assert theme.colors.foreground == "#1a1a1a"

    def test_load_nonexistent_theme(self, theme_manager):
        theme = theme_manager.get_theme("nonexistent")
        assert theme.name == "dark"

    def test_get_available_themes(self, theme_manager):
        themes = theme_manager.get_available_themes()
        assert "dark" in themes
        assert "light" in themes

    def test_set_valid_theme(self, theme_manager):
        result = theme_manager.set_theme("light")
        assert result
        assert theme_manager.get_theme().name == "light"

    def test_set_invalid_theme(self, theme_manager):
        result = theme_manager.set_theme("invalid")
        assert not result
        assert theme_manager.get_theme().name == "dark"

    def test_is_valid_theme(self, theme_manager):
        assert theme_manager.is_valid_theme("dark")
        assert theme_manager.is_valid_theme("light")
        assert not theme_manager.is_valid_theme("invalid")


class TestThemeColors:
    def test_default_colors(self):
        colors = ThemeColors()
        assert colors.background == "#1a1a1a"
        assert colors.foreground == "#ffffff"
        assert colors.accent == "#00ff88"

    def test_custom_colors(self):
        colors = ThemeColors(
            background="#000000",
            foreground="#cccccc",
            accent="#ff0000",
            error="#ff1111",
        )
        assert colors.background == "#000000"
        assert colors.accent == "#ff0000"

    def test_all_color_fields(self):
        colors = ThemeColors()
        color_fields = [
            "background",
            "foreground",
            "accent",
            "error",
            "warning",
            "success",
            "muted",
            "highlight",
        ]
        for field_name in color_fields:
            assert hasattr(colors, field_name)
            color_value = getattr(colors, field_name)
            assert color_value.startswith("#")


class TestCustomTheme:
    def test_register_custom_theme(self, theme_manager):
        custom_colors = ThemeColors(
            background="#2a2a2a",
            foreground="#dddddd",
            accent="#88ff00",
        )
        custom_theme = Theme(name="custom", colors=custom_colors)
        theme_manager.register_theme(custom_theme)

        assert "custom" in theme_manager.get_available_themes()
        loaded = theme_manager.get_theme("custom")
        assert loaded.colors.background == "#2a2a2a"

    def test_load_custom_theme_from_file(self, theme_manager, temp_dir):
        import json

        theme_path = os.path.join(temp_dir, "custom_theme.json")
        theme_data = {
            "name": "my_theme",
            "background": "#333333",
            "foreground": "#eeeeee",
            "accent": "#00aaff",
            "font_size": 14,
        }
        with open(theme_path, "w") as f:
            json.dump(theme_data, f)

        theme = theme_manager.load_custom_theme(theme_path)
        assert theme is not None
        assert theme.name == "my_theme"
        assert theme.colors.background == "#333333"
        assert theme.font_size == 14

    def test_save_custom_theme_to_file(self, theme_manager, temp_dir):
        custom_theme = Theme(
            name="saved_theme",
            colors=ThemeColors(background="#444444", foreground="#ffffff"),
            font_size=16,
        )

        theme_path = os.path.join(temp_dir, "saved_theme.json")
        result = theme_manager.save_custom_theme(custom_theme, theme_path)
        assert result

        import json

        with open(theme_path) as f:
            data = json.load(f)
        assert data["name"] == "saved_theme"
        assert data["background"] == "#444444"
        assert data["font_size"] == 16

    def test_load_invalid_theme_file(self, theme_manager, temp_dir):
        invalid_path = os.path.join(temp_dir, "invalid.json")
        with open(invalid_path, "w") as f:
            f.write("not valid json")

        theme = theme_manager.load_custom_theme(invalid_path)
        assert theme is None

    def test_load_nonexistent_theme_file(self, theme_manager):
        theme = theme_manager.load_custom_theme("/nonexistent/path.json")
        assert theme is None

    def test_custom_theme_settings(self, theme_manager):
        custom_theme = Theme(
            name="custom_with_settings",
            colors=ThemeColors(),
            custom_settings={"opacity": 0.8, "blur": True},
        )
        theme_manager.register_theme(custom_theme)

        loaded = theme_manager.get_theme("custom_with_settings")
        assert loaded.custom_settings["opacity"] == 0.8
        assert loaded.custom_settings["blur"]


class TestThemeManager:
    def test_manager_initialization(self, theme_manager):
        assert theme_manager._current_theme == "dark"
        assert len(theme_manager._themes) >= 2

    def test_switch_between_themes(self, theme_manager):
        theme_manager.set_theme("dark")
        assert theme_manager.get_theme().name == "dark"

        theme_manager.set_theme("light")
        assert theme_manager.get_theme().name == "light"

        theme_manager.set_theme("dark")
        assert theme_manager.get_theme().name == "dark"

    def test_multiple_custom_themes(self, theme_manager):
        for i in range(3):
            theme = Theme(
                name=f"custom_{i}",
                colors=ThemeColors(background=f"#{i * 30:02x}{i * 30:02x}{i * 30:02x}"),
            )
            theme_manager.register_theme(theme)

        themes = theme_manager.get_available_themes()
        assert "custom_0" in themes
        assert "custom_1" in themes
        assert "custom_2" in themes


class TestThemeAppState:
    def test_app_state_theme_default(self, app_state):
        assert app_state.theme == "dark"

    def test_app_state_theme_change(self, app_state):
        app_state.theme = "light"
        assert app_state.theme == "light"

    def test_app_state_theme_custom(self, app_state):
        app_state.theme = "custom"
        assert app_state.theme == "custom"

    def test_app_state_invalid_theme(self, app_state):
        app_state.theme = "invalid_theme"
        assert app_state.theme == "invalid_theme"


class TestThemeConfig:
    def test_config_default_theme(self):
        config = AppConfig()
        assert config.theme == "dark"

    def test_config_theme_setting(self, temp_dir):
        config_path = os.path.join(temp_dir, "config.json")

        config = AppConfig(theme="light")
        os.makedirs(temp_dir, exist_ok=True)
        with open(config_path, "w") as f:
            import json

            json.dump({"theme": "light"}, f)

        loaded = load_config()
        assert loaded.theme == "dark"

    def test_config_save_theme(self, temp_dir):
        import json

        CONFIG_DIR = temp_dir
        CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")

        os.makedirs(CONFIG_DIR, exist_ok=True)

        config = AppConfig(theme="light")
        data = {"theme": config.theme}
        with open(CONFIG_PATH, "w") as f:
            json.dump(data, f)

        with open(CONFIG_PATH) as f:
            loaded_data = json.load(f)
        assert loaded_data["theme"] == "light"


class TestThemeFontSettings:
    def test_default_font(self, theme_manager):
        theme = theme_manager.get_theme()
        assert theme.font_family == "monospace"
        assert theme.font_size == 12

    def test_custom_font_settings(self, theme_manager):
        custom_theme = Theme(
            name="font_theme",
            colors=ThemeColors(),
            font_family="Fira Code",
            font_size=14,
            line_height=1.5,
        )
        theme_manager.register_theme(custom_theme)

        loaded = theme_manager.get_theme("font_theme")
        assert loaded.font_family == "Fira Code"
        assert loaded.font_size == 14
        assert loaded.line_height == 1.5


class TestThemeColorValidation:
    def test_valid_hex_colors(self):
        colors = ThemeColors(
            background="#000000",
            foreground="#ffffff",
            accent="#00ff00",
        )
        assert colors.background == "#000000"

    def test_color_format(self):
        colors = ThemeColors()
        for attr in ["background", "foreground", "accent", "error", "warning", "success"]:
            value = getattr(colors, attr)
            assert value.startswith("#")
            assert len(value) == 7


class TestThemeIntegration:
    def test_full_theme_workflow(self, theme_manager, temp_dir):
        custom_colors = ThemeColors(
            background="#2b2b2b",
            foreground="#a0a0a0",
            accent="#61afef",
        )
        custom_theme = Theme(
            name="workflow_theme",
            colors=custom_colors,
            font_size=13,
        )

        theme_manager.register_theme(custom_theme)
        assert theme_manager.is_valid_theme("workflow_theme")

        theme_path = os.path.join(temp_dir, "workflow_theme.json")
        saved = theme_manager.save_custom_theme(custom_theme, theme_path)
        assert saved

        loaded = theme_manager.load_custom_theme(theme_path)
        assert loaded is not None
        assert loaded.colors.background == "#2b2b2b"

        result = theme_manager.set_theme("workflow_theme")
        assert result
        current = theme_manager.get_theme()
        assert current.name == "workflow_theme"
