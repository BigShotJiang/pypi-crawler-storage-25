"""Tests for OpenLaoKe."""
