"""Tests for file history and snapshot functionality."""

import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import pytest


@dataclass
class FileSnapshot:
    """Snapshot of a file at a specific point in time."""

    path: str
    content: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    checksum: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.checksum:
            import hashlib

            self.checksum = hashlib.md5(self.content.encode()).hexdigest()


@dataclass
class FileHistoryEntry:
    """Entry in file history."""

    snapshots: list[FileSnapshot] = field(default_factory=list)
    current_index: int = -1

    def add_snapshot(self, snapshot: FileSnapshot) -> None:
        self.snapshots.append(snapshot)
        self.current_index = len(self.snapshots) - 1

    def get_current(self) -> FileSnapshot | None:
        if self.current_index >= 0 and self.current_index < len(self.snapshots):
            return self.snapshots[self.current_index]
        return None

    def get_previous(self) -> FileSnapshot | None:
        if self.current_index > 0:
            self.current_index -= 1
            return self.snapshots[self.current_index]
        return None

    def get_next(self) -> FileSnapshot | None:
        if self.current_index < len(self.snapshots) - 1:
            self.current_index += 1
            return self.snapshots[self.current_index]
        return None

    def can_go_back(self) -> bool:
        return self.current_index > 0

    def can_go_forward(self) -> bool:
        return self.current_index < len(self.snapshots) - 1


class FileHistoryManager:
    """Manager for file history."""

    def __init__(self):
        self._history: dict[str, FileHistoryEntry] = {}

    def save_snapshot(
        self, path: str, content: str, metadata: dict[str, Any] = None
    ) -> FileSnapshot:
        snapshot = FileSnapshot(path=path, content=content, metadata=metadata or {})
        if path not in self._history:
            self._history[path] = FileHistoryEntry()
        self._history[path].add_snapshot(snapshot)
        return snapshot

    def get_history(self, path: str) -> FileHistoryEntry | None:
        return self._history.get(path)

    def get_current(self, path: str) -> FileSnapshot | None:
        entry = self._history.get(path)
        if entry:
            return entry.get_current()
        return None

    def restore_previous(self, path: str) -> str | None:
        entry = self._history.get(path)
        if entry and entry.can_go_back():
            snapshot = entry.get_previous()
            if snapshot:
                return snapshot.content
        return None

    def restore_next(self, path: str) -> str | None:
        entry = self._history.get(path)
        if entry and entry.can_go_forward():
            snapshot = entry.get_next()
            if snapshot:
                return snapshot.content
        return None

    def clear_history(self, path: str) -> None:
        if path in self._history:
            del self._history[path]

    def get_all_paths(self) -> list[str]:
        return list(self._history.keys())


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def history_manager():
    return FileHistoryManager()


class TestFileSnapshot:
    def test_create_snapshot(self):
        snapshot = FileSnapshot(path="/test/file.txt", content="test content")
        assert snapshot.path == "/test/file.txt"
        assert snapshot.content == "test content"
        assert snapshot.timestamp
        assert snapshot.checksum

    def test_snapshot_checksum(self):
        snapshot1 = FileSnapshot(path="test", content="same content")
        snapshot2 = FileSnapshot(path="test", content="same content")
        assert snapshot1.checksum == snapshot2.checksum

        snapshot3 = FileSnapshot(path="test", content="different content")
        assert snapshot1.checksum != snapshot3.checksum

    def test_snapshot_metadata(self):
        metadata = {"author": "test", "version": 1}
        snapshot = FileSnapshot(path="test", content="content", metadata=metadata)
        assert snapshot.metadata["author"] == "test"
        assert snapshot.metadata["version"] == 1

    def test_default_metadata(self):
        snapshot = FileSnapshot(path="test", content="content")
        assert snapshot.metadata == {}

    def test_timestamp_format(self):
        snapshot = FileSnapshot(path="test", content="content")
        assert "T" in snapshot.timestamp


class TestFileHistoryEntry:
    def test_empty_entry(self):
        entry = FileHistoryEntry()
        assert entry.snapshots == []
        assert entry.current_index == -1
        assert entry.get_current() is None

    def test_add_single_snapshot(self):
        entry = FileHistoryEntry()
        snapshot = FileSnapshot(path="test", content="v1")
        entry.add_snapshot(snapshot)

        assert len(entry.snapshots) == 1
        assert entry.current_index == 0
        assert entry.get_current() == snapshot

    def test_add_multiple_snapshots(self):
        entry = FileHistoryEntry()
        s1 = FileSnapshot(path="test", content="v1")
        s2 = FileSnapshot(path="test", content="v2")
        s3 = FileSnapshot(path="test", content="v3")

        entry.add_snapshot(s1)
        entry.add_snapshot(s2)
        entry.add_snapshot(s3)

        assert len(entry.snapshots) == 3
        assert entry.current_index == 2
        assert entry.get_current().content == "v3"

    def test_navigation_previous(self):
        entry = FileHistoryEntry()
        s1 = FileSnapshot(path="test", content="v1")
        s2 = FileSnapshot(path="test", content="v2")

        entry.add_snapshot(s1)
        entry.add_snapshot(s2)

        assert entry.current_index == 1
        prev = entry.get_previous()
        assert prev.content == "v1"
        assert entry.current_index == 0

    def test_navigation_next(self):
        entry = FileHistoryEntry()
        s1 = FileSnapshot(path="test", content="v1")
        s2 = FileSnapshot(path="test", content="v2")

        entry.add_snapshot(s1)
        entry.add_snapshot(s2)

        entry.current_index = 0
        next_snap = entry.get_next()
        assert next_snap.content == "v2"
        assert entry.current_index == 1

    def test_cannot_go_back_at_start(self):
        entry = FileHistoryEntry()
        s1 = FileSnapshot(path="test", content="v1")
        entry.add_snapshot(s1)

        assert not entry.can_go_back()
        assert entry.get_previous() is None

    def test_cannot_go_forward_at_end(self):
        entry = FileHistoryEntry()
        s1 = FileSnapshot(path="test", content="v1")
        entry.add_snapshot(s1)

        assert not entry.can_go_forward()
        assert entry.get_next() is None

    def test_navigation_bounds(self):
        entry = FileHistoryEntry()
        for i in range(5):
            entry.add_snapshot(FileSnapshot(path="test", content=f"v{i}"))

        entry.current_index = 0
        assert entry.get_previous() is None
        assert entry.current_index == 0

        entry.current_index = 4
        assert entry.get_next() is None
        assert entry.current_index == 4


class TestFileHistorySave:
    def test_save_first_snapshot(self, history_manager):
        snapshot = history_manager.save_snapshot("/test/file.txt", "initial content")
        assert snapshot.content == "initial content"
        assert history_manager.get_history("/test/file.txt") is not None

    def test_save_multiple_snapshots(self, history_manager):
        history_manager.save_snapshot("/test/file.txt", "v1")
        history_manager.save_snapshot("/test/file.txt", "v2")
        history_manager.save_snapshot("/test/file.txt", "v3")

        history = history_manager.get_history("/test/file.txt")
        assert len(history.snapshots) == 3

    def test_save_with_metadata(self, history_manager):
        metadata = {"source": "user_edit", "line_count": 10}
        snapshot = history_manager.save_snapshot("/test/file.txt", "content", metadata)
        assert snapshot.metadata["source"] == "user_edit"

    def test_save_different_files(self, history_manager):
        history_manager.save_snapshot("/file1.txt", "content1")
        history_manager.save_snapshot("/file2.txt", "content2")

        assert len(history_manager.get_all_paths()) == 2

    def test_get_current_after_save(self, history_manager):
        history_manager.save_snapshot("/test.txt", "old")
        history_manager.save_snapshot("/test.txt", "new")

        current = history_manager.get_current("/test.txt")
        assert current.content == "new"


class TestFileHistoryRestore:
    def test_restore_previous(self, history_manager):
        history_manager.save_snapshot("/test.txt", "version 1")
        history_manager.save_snapshot("/test.txt", "version 2")

        content = history_manager.restore_previous("/test.txt")
        assert content == "version 1"

    def test_restore_next(self, history_manager):
        history_manager.save_snapshot("/test.txt", "version 1")
        history_manager.save_snapshot("/test.txt", "version 2")

        history_manager.restore_previous("/test.txt")
        content = history_manager.restore_next("/test.txt")
        assert content == "version 2"

    def test_restore_nonexistent_file(self, history_manager):
        content = history_manager.restore_previous("/nonexistent.txt")
        assert content is None

    def test_restore_at_first_version(self, history_manager):
        history_manager.save_snapshot("/test.txt", "only version")
        content = history_manager.restore_previous("/test.txt")
        assert content is None

    def test_restore_at_last_version(self, history_manager):
        history_manager.save_snapshot("/test.txt", "v1")
        history_manager.save_snapshot("/test.txt", "v2")
        content = history_manager.restore_next("/test.txt")
        assert content is None

    def test_multiple_restore_cycles(self, history_manager):
        history_manager.save_snapshot("/test.txt", "v1")
        history_manager.save_snapshot("/test.txt", "v2")
        history_manager.save_snapshot("/test.txt", "v3")

        assert history_manager.restore_previous("/test.txt") == "v2"
        assert history_manager.restore_previous("/test.txt") == "v1"
        assert history_manager.restore_previous("/test.txt") is None

        assert history_manager.restore_next("/test.txt") == "v2"
        assert history_manager.restore_next("/test.txt") == "v3"
        assert history_manager.restore_next("/test.txt") is None


class TestFileHistoryManager:
    def test_clear_history(self, history_manager):
        history_manager.save_snapshot("/test.txt", "content")
        history_manager.clear_history("/test.txt")

        assert history_manager.get_history("/test.txt") is None

    def test_get_all_paths_empty(self, history_manager):
        paths = history_manager.get_all_paths()
        assert paths == []

    def test_get_all_paths_multiple(self, history_manager):
        history_manager.save_snapshot("/file1.txt", "c1")
        history_manager.save_snapshot("/file2.txt", "c2")
        history_manager.save_snapshot("/file3.txt", "c3")

        paths = history_manager.get_all_paths()
        assert len(paths) == 3
        assert "/file1.txt" in paths
        assert "/file2.txt" in paths

    def test_get_history_nonexistent(self, history_manager):
        history = history_manager.get_history("/nonexistent.txt")
        assert history is None

    def test_get_current_nonexistent(self, history_manager):
        current = history_manager.get_current("/nonexistent.txt")
        assert current is None


class TestFileHistoryIntegration:
    def test_full_cycle(self, history_manager, temp_dir):
        path = os.path.join(temp_dir, "test.txt")

        with open(path, "w") as f:
            f.write("initial")
        history_manager.save_snapshot(path, "initial")

        with open(path, "w") as f:
            f.write("modified")
        history_manager.save_snapshot(path, "modified")

        with open(path, "w") as f:
            f.write("final")
        history_manager.save_snapshot(path, "final")

        history = history_manager.get_history(path)
        assert len(history.snapshots) == 3

        restored = history_manager.restore_previous(path)
        assert restored == "modified"

        with open(path, "w") as f:
            f.write(restored)
        with open(path) as f:
            assert f.read() == "modified"

    def test_checksum_validation(self, history_manager):
        s1 = history_manager.save_snapshot("/test.txt", "content")
        s2 = history_manager.save_snapshot("/test.txt", "content")

        assert s1.checksum == s2.checksum

        s3 = history_manager.save_snapshot("/test.txt", "different content")
        assert s1.checksum != s3.checksum

    def test_metadata_preservation(self, history_manager):
        meta1 = {"step": 1}
        meta2 = {"step": 2, "note": "fix"}

        s1 = history_manager.save_snapshot("/test.txt", "v1", meta1)
        s2 = history_manager.save_snapshot("/test.txt", "v2", meta2)

        history = history_manager.get_history("/test.txt")
        assert history.snapshots[0].metadata["step"] == 1
        assert history.snapshots[1].metadata["note"] == "fix"


class TestFileHistoryEdgeCases:
    def test_empty_content(self, history_manager):
        snapshot = history_manager.save_snapshot("/empty.txt", "")
        assert snapshot.content == ""
        assert snapshot.checksum

    def test_large_content(self, history_manager):
        large_content = "x" * 10000
        snapshot = history_manager.save_snapshot("/large.txt", large_content)
        assert len(snapshot.content) == 10000

    def test_unicode_content(self, history_manager):
        unicode_content = "Hello 世界 🌍"
        snapshot = history_manager.save_snapshot("/unicode.txt", unicode_content)
        assert snapshot.content == unicode_content

    def test_special_characters(self, history_manager):
        special_content = "Line1\nLine2\tTabbed\r\nWindows"
        snapshot = history_manager.save_snapshot("/special.txt", special_content)
        assert snapshot.content == special_content

    def test_concurrent_saves_same_file(self, history_manager):
        for i in range(100):
            history_manager.save_snapshot("/test.txt", f"version{i}")

        history = history_manager.get_history("/test.txt")
        assert len(history.snapshots) == 100
