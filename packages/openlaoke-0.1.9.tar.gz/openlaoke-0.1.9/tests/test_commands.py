"""Tests for command implementations."""

import asyncio
import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from openlaoke.core.state import create_app_state
from openlaoke.commands.base import (
    CommandContext,
    CommandResult,
    DoctorCommand,
    InitCommand,
    McpCommand,
    ThemeCommand,
    HooksCommand,
    ExportCommand,
    UsageCommand,
    MemoryCommand,
    AgentsCommand,
    VimCommand,
    SettingsCommand,
    CompactCommand,
    CwdCommand,
    ResumeCommand,
    CommandsCommand,
)
from openlaoke.commands.registry import register_all
from openlaoke.types.core_types import (
    MessageRole,
    PermissionMode,
    TaskType,
    TaskStatus,
    TaskState,
    TokenUsage,
    UserMessage,
)


@pytest.fixture(autouse=True)
def setup_commands():
    register_all()


@pytest.fixture
def app_state():
    import openlaoke

    project_root = os.path.dirname(os.path.dirname(openlaoke.__file__))
    return create_app_state(cwd=project_root)


@pytest.fixture
def ctx(app_state):
    return CommandContext(app_state=app_state)


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


class TestDoctorCommand:
    @pytest.mark.asyncio
    async def test_execute(self, ctx):
        cmd = DoctorCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Diagnostic" in result.message
        assert "System:" in result.message
        assert "Python:" in result.message

    @pytest.mark.asyncio
    async def test_shows_environment(self, ctx):
        cmd = DoctorCommand()
        result = await cmd.execute(ctx)
        assert "Environment:" in result.message
        assert "Anthropic:" in result.message
        assert "OpenAI:" in result.message

    @pytest.mark.asyncio
    async def test_shows_tools(self, ctx):
        cmd = DoctorCommand()
        result = await cmd.execute(ctx)
        assert "Tools:" in result.message
        assert "git:" in result.message
        assert "python3:" in result.message

    @pytest.mark.asyncio
    async def test_shows_config(self, ctx):
        cmd = DoctorCommand()
        result = await cmd.execute(ctx)
        assert "Configuration:" in result.message
        assert "AGENTS.md:" in result.message

    @pytest.mark.asyncio
    async def test_shows_session(self, ctx):
        cmd = DoctorCommand()
        result = await cmd.execute(ctx)
        assert "Session:" in result.message
        assert "Session ID:" in result.message
        assert "Messages:" in result.message

    def test_command_properties(self):
        cmd = DoctorCommand()
        assert cmd.name == "doctor"
        assert "diagnostic" in cmd.description.lower()


class TestInitCommand:
    @pytest.mark.asyncio
    async def test_creates_agents_md(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        cmd = InitCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Created AGENTS.md" in result.message
        assert os.path.exists(os.path.join(temp_dir, "AGENTS.md"))

    @pytest.mark.asyncio
    async def test_agents_md_already_exists(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        agents_path = os.path.join(temp_dir, "AGENTS.md")
        with open(agents_path, "w") as f:
            f.write("existing content")

        cmd = InitCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "already exists" in result.message

    @pytest.mark.asyncio
    async def test_agents_md_content(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        cmd = InitCommand()
        await cmd.execute(ctx)

        with open(os.path.join(temp_dir, "AGENTS.md")) as f:
            content = f.read()

        assert "# AGENTS.md" in content
        assert "Project Overview" in content
        assert "Commands" in content

    def test_command_properties(self):
        cmd = InitCommand()
        assert cmd.name == "init"
        assert "AGENTS.md" in cmd.description


class TestMcpCommand:
    @pytest.mark.asyncio
    async def test_list_no_servers(self, ctx):
        cmd = McpCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "MCP Servers:" in result.message

    @pytest.mark.asyncio
    async def test_list_with_args(self, ctx):
        cmd = McpCommand()
        ctx.args = "list"
        result = await cmd.execute(ctx)
        assert result.success
        assert "MCP Servers:" in result.message

    @pytest.mark.asyncio
    async def test_add_server(self, ctx):
        cmd = McpCommand()
        ctx.args = "add test-server"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "edit" in result.message.lower()

    @pytest.mark.asyncio
    async def test_remove_server(self, ctx):
        cmd = McpCommand()
        ctx.args = "remove test-server"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "edit" in result.message.lower()

    @pytest.mark.asyncio
    async def test_enable_server(self, ctx):
        cmd = McpCommand()
        ctx.args = "enable test-server"
        result = await cmd.execute(ctx)
        assert result.success
        assert "enabled" in result.message

    @pytest.mark.asyncio
    async def test_disable_server(self, ctx):
        cmd = McpCommand()
        ctx.args = "disable test-server"
        result = await cmd.execute(ctx)
        assert result.success
        assert "disabled" in result.message

    @pytest.mark.asyncio
    async def test_invalid_usage(self, ctx):
        cmd = McpCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Usage:" in result.message

    def test_command_properties(self):
        cmd = McpCommand()
        assert cmd.name == "mcp"
        assert "MCP" in cmd.description


class TestThemeCommand:
    @pytest.mark.asyncio
    async def test_show_current_theme(self, ctx):
        cmd = ThemeCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Current theme:" in result.message
        assert "dark" in result.message

    @pytest.mark.asyncio
    async def test_set_valid_theme(self, ctx):
        cmd = ThemeCommand()
        ctx.args = "light"
        result = await cmd.execute(ctx)
        assert result.success
        assert "light" in result.message
        assert ctx.app_state.theme == "light"

    @pytest.mark.asyncio
    async def test_set_custom_theme(self, ctx):
        cmd = ThemeCommand()
        ctx.args = "custom"
        result = await cmd.execute(ctx)
        assert result.success
        assert ctx.app_state.theme == "custom"

    @pytest.mark.asyncio
    async def test_set_invalid_theme(self, ctx):
        cmd = ThemeCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Invalid theme" in result.message

    @pytest.mark.asyncio
    async def test_show_available_themes(self, ctx):
        cmd = ThemeCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Available themes:" in result.message
        assert "dark" in result.message
        assert "light" in result.message
        assert "custom" in result.message

    def test_command_properties(self):
        cmd = ThemeCommand()
        assert cmd.name == "theme"
        assert "theme" in cmd.description.lower()


class TestHooksCommand:
    @pytest.mark.asyncio
    async def test_list_hooks(self, ctx):
        cmd = HooksCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Registered Hooks:" in result.message

    @pytest.mark.asyncio
    async def test_list_with_args(self, ctx):
        cmd = HooksCommand()
        ctx.args = "list"
        result = await cmd.execute(ctx)
        assert result.success
        assert "Registered Hooks:" in result.message

    @pytest.mark.asyncio
    async def test_test_valid_hook(self, ctx):
        cmd = HooksCommand()
        ctx.args = "test pre_tool_call"
        result = await cmd.execute(ctx)
        assert result.success
        assert "Hook test" in result.message

    @pytest.mark.asyncio
    async def test_test_invalid_hook(self, ctx):
        cmd = HooksCommand()
        ctx.args = "test InvalidHook"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Invalid hook type" in result.message

    @pytest.mark.asyncio
    async def test_invalid_usage(self, ctx):
        cmd = HooksCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Usage:" in result.message

    def test_command_properties(self):
        cmd = HooksCommand()
        assert cmd.name == "hooks"
        assert "hooks" in cmd.description.lower()


class TestExportCommand:
    @pytest.mark.asyncio
    async def test_show_usage(self, ctx):
        cmd = ExportCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Usage:" in result.message
        assert "json" in result.message
        assert "markdown" in result.message

    @pytest.mark.asyncio
    async def test_export_json(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content="test"))

        cmd = ExportCommand()
        ctx.args = "json"
        result = await cmd.execute(ctx)
        assert result.success
        assert "exported" in result.message.lower()

    @pytest.mark.asyncio
    async def test_export_json_with_filename(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content="test"))

        cmd = ExportCommand()
        ctx.args = "json test_export.json"
        result = await cmd.execute(ctx)
        assert result.success
        assert "test_export.json" in result.message

    @pytest.mark.asyncio
    async def test_export_markdown(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content="test"))

        cmd = ExportCommand()
        ctx.args = "markdown"
        result = await cmd.execute(ctx)
        assert result.success
        assert "exported" in result.message.lower()

    @pytest.mark.asyncio
    async def test_export_markdown_alias(self, ctx, temp_dir):
        ctx.app_state.set_cwd(temp_dir)
        ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content="test"))

        cmd = ExportCommand()
        ctx.args = "md"
        result = await cmd.execute(ctx)
        assert result.success

    @pytest.mark.asyncio
    async def test_invalid_format(self, ctx):
        cmd = ExportCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Invalid format" in result.message

    def test_command_properties(self):
        cmd = ExportCommand()
        assert cmd.name == "export"
        assert "Export" in cmd.description


class TestUsageCommand:
    @pytest.mark.asyncio
    async def test_show_usage(self, ctx):
        ctx.app_state.accumulate_tokens(TokenUsage(input_tokens=100, output_tokens=50))

        cmd = UsageCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Usage Statistics" in result.message
        assert "100" in result.message or "100," in result.message

    @pytest.mark.asyncio
    async def test_show_cost(self, ctx):
        cmd = UsageCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Cost Breakdown:" in result.message
        assert "Total cost:" in result.message

    @pytest.mark.asyncio
    async def test_show_session_info(self, ctx):
        cmd = UsageCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Session Info:" in result.message
        assert "Session ID:" in result.message
        assert "Messages:" in result.message

    def test_command_properties(self):
        cmd = UsageCommand()
        assert cmd.name == "usage"
        assert "usage" in cmd.description.lower()


class TestMemoryCommand:
    @pytest.mark.asyncio
    async def test_list_empty(self, ctx):
        cmd = MemoryCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Memory Storage:" in result.message
        assert "No memories" in result.message

    @pytest.mark.asyncio
    async def test_add_memory(self, ctx, temp_dir):
        memory_path = os.path.join(temp_dir, "memory.json")
        with patch("openlaoke.commands.base.MemoryCommand._list_memory") as mock_list:
            mock_list.return_value = CommandResult(message="Memory added: Test memory...")

            cmd = MemoryCommand()
            ctx.args = "add Test memory"
            result = cmd._add_memory(ctx, "Test memory")
            assert result.success
            assert "Memory added" in result.message

    @pytest.mark.asyncio
    async def test_remove_invalid_index(self, ctx):
        cmd = MemoryCommand()
        ctx.args = "remove abc"
        result = cmd._remove_memory(ctx, "abc")
        assert not result.success
        assert "Invalid index" in result.message

    @pytest.mark.asyncio
    async def test_clear_memory(self, ctx):
        cmd = MemoryCommand()
        ctx.args = "clear"
        result = cmd._clear_memory(ctx)
        assert result.success
        assert "cleared" in result.message.lower()

    @pytest.mark.asyncio
    async def test_invalid_usage(self, ctx):
        cmd = MemoryCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Usage:" in result.message

    def test_command_properties(self):
        cmd = MemoryCommand()
        assert cmd.name == "memory"
        assert "memory" in cmd.description.lower()


class TestAgentsCommand:
    @pytest.mark.asyncio
    async def test_show_agent_types(self, ctx):
        cmd = AgentsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Available Agent Types:" in result.message

    @pytest.mark.asyncio
    async def test_show_all_task_types(self, ctx):
        cmd = AgentsCommand()
        result = await cmd.execute(ctx)
        assert result.success

        for task_type in TaskType:
            assert task_type.value in result.message

    @pytest.mark.asyncio
    async def test_show_active_tasks(self, ctx):
        task = TaskState(id="t1", type=TaskType.LOCAL_BASH, description="Test task")
        task.status = TaskStatus.RUNNING
        ctx.app_state.add_task(task)

        cmd = AgentsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Active Tasks:" in result.message
        assert "t1" in result.message

    @pytest.mark.asyncio
    async def test_show_no_active_tasks(self, ctx):
        cmd = AgentsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "No active tasks" in result.message

    def test_command_properties(self):
        cmd = AgentsCommand()
        assert cmd.name == "agents"
        assert "agent" in cmd.description.lower()


class TestVimCommand:
    @pytest.mark.asyncio
    async def test_show_current_mode(self, ctx):
        cmd = VimCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Vim mode:" in result.message

    @pytest.mark.asyncio
    async def test_enable_vim_mode(self, ctx):
        cmd = VimCommand()
        ctx.args = "on"
        result = await cmd.execute(ctx)
        assert result.success
        assert "enabled" in result.message
        assert ctx.app_state.vim_mode

    @pytest.mark.asyncio
    async def test_disable_vim_mode(self, ctx):
        ctx.app_state.vim_mode = True
        cmd = VimCommand()
        ctx.args = "off"
        result = await cmd.execute(ctx)
        assert result.success
        assert "disabled" in result.message
        assert not ctx.app_state.vim_mode

    @pytest.mark.asyncio
    async def test_toggle_vim_mode(self, ctx):
        cmd = VimCommand()
        ctx.args = "toggle"
        result = await cmd.execute(ctx)
        assert result.success
        assert ctx.app_state.vim_mode

        result = await cmd.execute(ctx)
        assert result.success
        assert not ctx.app_state.vim_mode

    @pytest.mark.asyncio
    async def test_invalid_usage(self, ctx):
        cmd = VimCommand()
        ctx.args = "invalid"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Usage:" in result.message

    def test_command_properties(self):
        cmd = VimCommand()
        assert cmd.name == "vim"
        assert "Vim" in cmd.description


class TestSettingsCommand:
    @pytest.mark.asyncio
    async def test_show_settings(self, ctx):
        cmd = SettingsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Settings:" in result.message
        assert "Model:" in result.message
        assert "Permissions:" in result.message

    @pytest.mark.asyncio
    async def test_shows_model(self, ctx):
        cmd = SettingsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert ctx.app_state.session_config.model in result.message

    @pytest.mark.asyncio
    async def test_shows_working_dir(self, ctx):
        cmd = SettingsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Working dir:" in result.message

    def test_command_properties(self):
        cmd = SettingsCommand()
        assert cmd.name == "settings"
        assert "settings" in cmd.description.lower()


class TestCompactCommand:
    @pytest.mark.asyncio
    async def test_compact_short_conversation(self, ctx):
        ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content="test"))
        cmd = CompactCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "too short" in result.message.lower()

    @pytest.mark.asyncio
    async def test_compact_long_conversation(self, ctx):
        for i in range(10):
            ctx.app_state.add_message(UserMessage(role=MessageRole.USER, content=f"msg{i}"))

        cmd = CompactCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "compacted" in result.message.lower()

    def test_command_properties(self):
        cmd = CompactCommand()
        assert cmd.name == "compact"
        assert "compact" in cmd.description.lower()


class TestCwdCommand:
    @pytest.mark.asyncio
    async def test_show_current_cwd(self, ctx):
        cmd = CwdCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Working directory:" in result.message

    @pytest.mark.asyncio
    async def test_change_to_valid_directory(self, ctx, temp_dir):
        cmd = CwdCommand()
        ctx.args = temp_dir
        result = await cmd.execute(ctx)
        assert result.success
        assert temp_dir in result.message

    @pytest.mark.asyncio
    async def test_change_to_invalid_directory(self, ctx):
        cmd = CwdCommand()
        ctx.args = "/nonexistent/path"
        result = await cmd.execute(ctx)
        assert not result.success
        assert "Not a directory" in result.message

    def test_command_properties(self):
        cmd = CwdCommand()
        assert cmd.name == "cwd"
        assert "directory" in cmd.description.lower()


class TestResumeCommand:
    @pytest.mark.asyncio
    async def test_resume_command(self, ctx):
        cmd = ResumeCommand()
        result = await cmd.execute(ctx)
        assert result.success

    def test_command_properties(self):
        cmd = ResumeCommand()
        assert cmd.name == "resume"
        assert "Resume" in cmd.description


class TestCommandsCommand:
    @pytest.mark.asyncio
    async def test_show_examples(self, ctx):
        cmd = CommandsCommand()
        result = await cmd.execute(ctx)
        assert result.success
        assert "Examples:" in result.message

    def test_command_properties(self):
        cmd = CommandsCommand()
        assert cmd.name == "commands"
        assert "example" in cmd.description.lower()
