"""Tests for the skill system."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from openlaoke.core.skill_system import Skill, SkillRegistry, get_skill_registry, load_skill, list_available_skills


class TestSkill:
    """Tests for the Skill class."""
    
    def test_skill_creation(self):
        """Test basic skill creation."""
        skill = Skill(
            name="test_skill",
            description="A test skill",
            version="1.0.0",
            content="Test content",
        )
        
        assert skill.name == "test_skill"
        assert skill.description == "A test skill"
        assert skill.version == "1.0.0"
        assert skill.content == "Test content"
    
    def test_skill_from_content_with_frontmatter(self):
        """Test parsing skill from content with YAML frontmatter."""
        content = """---
name: test_skill
version: 2.0.0
description: |
  A test skill
  with multiple lines
allowed-tools:
  - Bash
  - Read
---

# Test Skill Content

This is the skill body.
"""
        
        skill = Skill.from_content(content)
        
        assert skill.name == "test_skill"
        assert skill.version == "2.0.0"
        assert "A test skill" in skill.description
        assert "Bash" in skill.allowed_tools
        assert "Read" in skill.allowed_tools
        assert "# Test Skill Content" in skill.content
    
    def test_skill_from_content_without_frontmatter(self):
        """Test parsing skill without frontmatter."""
        content = "# Simple Skill\n\nJust content here."
        
        skill = Skill.from_content(content)
        
        assert skill.name == "unknown"
        assert skill.content == content
    
    def test_skill_from_file(self):
        """Test loading skill from file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            skill_path = Path(tmpdir) / "SKILL.md"
            skill_path.write_text("""---
name: file_skill
description: A skill from file
---

# Content
""")
            
            skill = Skill.from_file(skill_path)
            
            assert skill is not None
            assert skill.name == "file_skill"
            assert skill.path == skill_path
    
    def test_skill_from_nonexistent_file(self):
        """Test loading from non-existent file."""
        skill = Skill.from_file(Path("/nonexistent/SKILL.md"))
        assert skill is None
    
    def test_get_preamble(self):
        """Test extracting bash preamble."""
        content = """---
name: preamble_test
---

# Test

```bash
echo "Hello"
pwd
```

More content.
"""
        
        skill = Skill.from_content(content)
        preamble = skill.get_preamble()
        
        assert preamble is not None
        assert 'echo "Hello"' in preamble
        assert "pwd" in preamble
    
    def test_get_system_prompt(self):
        """Test getting system prompt."""
        skill = Skill(
            name="prompt_test",
            content="# Instructions\n\nDo this.",
        )
        
        prompt = skill.get_system_prompt()
        assert "# Instructions" in prompt


class TestSkillRegistry:
    """Tests for the SkillRegistry class."""
    
    def test_registry_creation(self):
        """Test creating a skill registry."""
        registry = SkillRegistry()
        assert len(registry.list_skills()) == 0
    
    def test_add_skill_directory(self):
        """Test adding a skill directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            # Create skill directory
            skill_dir = tmpdir / "test_skill"
            skill_dir.mkdir()
            (skill_dir / "SKILL.md").write_text("""---
name: test_skill
description: Test
---
Content
""")
            
            registry = SkillRegistry()
            count = registry.add_skill_directory(tmpdir)
            
            assert count == 1
            assert "test_skill" in registry.list_skills()
    
    def test_get_skill(self):
        """Test getting a skill by name."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            skill_dir = tmpdir / "my_skill"
            skill_dir.mkdir()
            (skill_dir / "SKILL.md").write_text("""---
name: my_skill
---
Content
""")
            
            registry = SkillRegistry()
            registry.add_skill_directory(tmpdir)
            
            skill = registry.get_skill("my_skill")
            assert skill is not None
            assert skill.name == "my_skill"
    
    def test_get_nonexistent_skill(self):
        """Test getting a non-existent skill."""
        registry = SkillRegistry()
        skill = registry.get_skill("nonexistent")
        assert skill is None
    
    def test_has_skill(self):
        """Test checking if a skill exists."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            skill_dir = tmpdir / "exists"
            skill_dir.mkdir()
            (skill_dir / "SKILL.md").write_text("""---
name: exists
---
Content
""")
            
            registry = SkillRegistry()
            registry.add_skill_directory(tmpdir)
            
            assert registry.has_skill("exists")
            assert not registry.has_skill("nope")
    
    def test_get_all_skills(self):
        """Test getting all skills."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            
            for name in ["skill1", "skill2"]:
                skill_dir = tmpdir / name
                skill_dir.mkdir()
                (skill_dir / "SKILL.md").write_text(f"""---
name: {name}
---
Content
""")
            
            registry = SkillRegistry()
            registry.add_skill_directory(tmpdir)
            
            all_skills = registry.get_all_skills()
            assert len(all_skills) == 2


class TestGlobalRegistry:
    """Tests for the global skill registry functions."""
    
    def test_get_skill_registry_singleton(self):
        """Test that get_skill_registry returns a singleton."""
        registry1 = get_skill_registry()
        registry2 = get_skill_registry()
        
        assert registry1 is registry2
    
    def test_list_available_skills(self):
        """Test listing available skills."""
        skills = list_available_skills()
        assert isinstance(skills, list)
    
    def test_load_skill(self):
        """Test loading a skill."""
        # This will return None if no skills are installed
        skill = load_skill("nonexistent")
        assert skill is None


class TestClaudeCodeCompatibility:
    """Tests for Claude Code skill format compatibility."""
    
    def test_parse_claude_code_skill(self):
        """Test parsing a Claude Code style skill."""
        content = """---
name: browse
version: 1.1.0
description: |
  Fast headless browser for QA testing and site dogfooding.
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

## Preamble (run first)

```bash
echo "Setup"
```

## Main Content

Instructions here.
"""
        
        skill = Skill.from_content(content)
        
        assert skill.name == "browse"
        assert skill.version == "1.1.0"
        assert "Fast headless browser" in skill.description
        assert "Bash" in skill.allowed_tools
        assert "Read" in skill.allowed_tools
        preamble = skill.get_preamble()
        assert 'echo "Setup"' in preamble


class TestOpenCodeCompatibility:
    """Tests for OpenCode skill format compatibility."""
    
    def test_parse_opencode_skill(self):
        """Test parsing an OpenCode style skill."""
        content = """---
name: agents-sdk
description: Build AI agents on Cloudflare Workers using the Agents SDK.
---

# Cloudflare Agents SDK

**STOP.** Your knowledge of the Agents SDK may be outdated.

## Documentation

Fetch current docs from `https://github.com/cloudflare/agents/tree/main/docs`.
"""
        
        skill = Skill.from_content(content)
        
        assert skill.name == "agents-sdk"
        assert "Build AI agents" in skill.description
        assert "Cloudflare Agents SDK" in skill.content