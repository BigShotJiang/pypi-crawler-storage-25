"""Entry points for OpenLaoKe."""
