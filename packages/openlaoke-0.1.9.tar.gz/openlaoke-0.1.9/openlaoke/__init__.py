"""OpenLaoKe - Open-source terminal AI coding assistant."""

__version__ = "0.1.9"
__build_time__ = "2026-04-03T00:00:00Z"
