"""Core systems for OpenLaoKe."""
