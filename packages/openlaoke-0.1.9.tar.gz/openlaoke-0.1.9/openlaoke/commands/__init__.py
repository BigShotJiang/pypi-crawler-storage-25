"""Slash commands for OpenLaoKe."""
