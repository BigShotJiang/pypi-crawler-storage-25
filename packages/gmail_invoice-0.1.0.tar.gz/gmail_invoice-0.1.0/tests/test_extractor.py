"""Smoke tests for invoice extraction."""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import cast

from gmail_invoice.gmail_extractor import GMailClient, GMailInvoiceExtractor
from tests.mock_client import MockGmailClient


def test_extract_purchases_writes_json_and_pdf(tmp_path: Path) -> None:
    client = cast(GMailClient, MockGmailClient())
    extractor = GMailInvoiceExtractor(
        client,
        date(2026, 5, 22),
        output_dir=str(tmp_path),
    )
    extractor.extract_purchases_for_date()

    json_files = list(tmp_path.glob("email_*.json"))
    pdf_files = list(tmp_path.glob("*.pdf"))

    assert len(json_files) == 1
    assert len(pdf_files) == 1
