import verinum


def test_get_vat_rate():
    rate = verinum.vat_rates.get("DE")
    assert rate is not None
    assert rate["standard_rate"] == 19.0
    assert rate["reduced_rates"] == [7.0]


def test_get_vat_rate_nonexistent():
    assert verinum.vat_rates.get("US") is None
