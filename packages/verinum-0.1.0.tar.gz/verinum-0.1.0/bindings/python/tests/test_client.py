import pytest
import verinum
from verinum import Client, VerinumError


def test_client_offline():
    v = Client()
    assert v.iban.is_valid("GB82WEST12345698765432")
    assert v.vat.is_valid("DE123456789")


def test_client_verify_no_key():
    v = Client()
    with pytest.raises(VerinumError, match="API key required"):
        v.verify("iban", "GB82WEST12345698765432")


def test_client_verify_with_key():
    v = Client(api_key="test-key")
    with pytest.raises(NotImplementedError, match="coming soon"):
        v.verify("iban", "GB82WEST12345698765432")


def test_client_stores_config():
    v = Client(api_key="my-key", base_url="https://example.com")
    assert v.api_key == "my-key"
    assert v.base_url == "https://example.com"
