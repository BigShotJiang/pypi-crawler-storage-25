import verinum


def test_iban_valid():
    assert verinum.iban.is_valid("GB82 WEST 1234 5698 7654 32")
    assert verinum.iban.is_valid("DE89370400440532013000")


def test_iban_invalid():
    assert not verinum.iban.is_valid("GB82WEST12345698765433")
    assert not verinum.iban.is_valid("")


def test_iban_validate():
    result = verinum.iban.validate("GB82WEST12345698765432")
    assert result["is_valid"] is True
    assert result["kind"] == "iban"
    assert result["country"] == "GB"
    assert result["error"] is None


def test_bic_valid():
    assert verinum.bic.is_valid("DEUTDEFF")
    assert verinum.bic.is_valid("DEUTDEFF500")


def test_credit_card_valid():
    assert verinum.credit_card.is_valid("4111111111111111")
    assert verinum.credit_card.is_valid("4111 1111 1111 1111")


def test_credit_card_validate():
    result = verinum.credit_card.validate("4111111111111111")
    assert result["is_valid"] is True
    assert result["brand"] == "visa"


def test_isbn_valid():
    assert verinum.isbn.is_valid("9780306406157")
    assert verinum.isbn.is_valid("0306406152")


def test_issn_valid():
    assert verinum.issn.is_valid("0378-5955")


def test_isin_valid():
    assert verinum.isin.is_valid("US0378331005")


def test_lei_valid():
    assert verinum.lei.is_valid("529900T8BM49AURSDO55")


def test_ean_valid():
    assert verinum.ean.is_valid("4006381333931")


def test_vat_valid():
    assert verinum.vat.is_valid("DE123456789")
    assert verinum.vat.is_valid("ATU12345678")


def test_vat_validate():
    result = verinum.vat.validate("DE123456789")
    assert result["is_valid"] is True
    assert result["country"] == "DE"


def test_invalid_returns_error():
    result = verinum.iban.validate("INVALID")
    assert result["is_valid"] is False
    assert result["error"] is not None
