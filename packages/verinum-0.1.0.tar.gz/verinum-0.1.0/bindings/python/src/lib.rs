use pyo3::prelude::*;
use pyo3::types::PyDict;
use verinum::types::{Metadata, ValidationResult as RustValidationResult};

fn result_to_pydict(
    py: Python<'_>,
    result: &RustValidationResult,
    kind: &str,
) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    dict.set_item("is_valid", result.is_valid)?;
    dict.set_item("compact", result.compact.as_str())?;
    dict.set_item("formatted", result.formatted.as_str())?;
    dict.set_item("error", result.error.map(|e| e.as_str()))?;
    dict.set_item("kind", kind)?;

    match &result.metadata {
        Metadata::Iban {
            country,
            check_digits,
            bban_length,
        } => {
            dict.set_item("country", core::str::from_utf8(country).unwrap_or(""))?;
            dict.set_item(
                "check_digits",
                core::str::from_utf8(check_digits).unwrap_or(""),
            )?;
            dict.set_item("bban_length", *bban_length)?;
        }
        Metadata::Bic {
            bank_code,
            country,
            location,
            branch,
        } => {
            dict.set_item("bank_code", core::str::from_utf8(bank_code).unwrap_or(""))?;
            dict.set_item("country", core::str::from_utf8(country).unwrap_or(""))?;
            dict.set_item("location", core::str::from_utf8(location).unwrap_or(""))?;
            dict.set_item(
                "branch",
                branch.map(|b| core::str::from_utf8(&b).unwrap_or("").to_string()),
            )?;
        }
        Metadata::CreditCard { brand } => {
            dict.set_item("brand", brand.as_str())?;
        }
        Metadata::Isbn {
            isbn_type,
            isbn10,
            isbn13,
        } => {
            dict.set_item(
                "isbn_type",
                match isbn_type {
                    verinum::types::IsbnType::Isbn10 => "isbn10",
                    verinum::types::IsbnType::Isbn13 => "isbn13",
                },
            )?;
            dict.set_item("isbn10", isbn10.map(|b| b.as_str().to_string()))?;
            dict.set_item("isbn13", isbn13.map(|b| b.as_str().to_string()))?;
        }
        Metadata::Isin { country } => {
            dict.set_item("country", core::str::from_utf8(country).unwrap_or(""))?;
        }
        Metadata::Lei { lou_prefix } => {
            dict.set_item("lou_prefix", core::str::from_utf8(lou_prefix).unwrap_or(""))?;
        }
        Metadata::Ean {
            ean_type,
            country_prefix,
        } => {
            dict.set_item(
                "ean_type",
                match ean_type {
                    verinum::types::EanType::Ean8 => "ean8",
                    verinum::types::EanType::Ean13 => "ean13",
                },
            )?;
            dict.set_item("country_prefix", country_prefix.as_str())?;
        }
        Metadata::Vat { country } => {
            dict.set_item("country", core::str::from_utf8(country).unwrap_or(""))?;
        }
        Metadata::Issn {} => {}
        Metadata::None => {}
    }

    Ok(dict.into())
}

// ---- Validator functions ----

#[pyfunction]
fn is_valid_iban(input: &str) -> bool {
    verinum::iban::is_valid(input)
}

#[pyfunction]
fn validate_iban(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::iban::validate(input);
    result_to_pydict(py, &result, "iban")
}

#[pyfunction]
fn is_valid_bic(input: &str) -> bool {
    verinum::bic::is_valid(input)
}

#[pyfunction]
fn validate_bic(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::bic::validate(input);
    result_to_pydict(py, &result, "bic")
}

#[pyfunction]
fn is_valid_credit_card(input: &str) -> bool {
    verinum::credit_card::is_valid(input)
}

#[pyfunction]
fn validate_credit_card(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::credit_card::validate(input);
    result_to_pydict(py, &result, "credit_card")
}

#[pyfunction]
fn is_valid_isbn(input: &str) -> bool {
    verinum::isbn::is_valid(input)
}

#[pyfunction]
fn validate_isbn(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::isbn::validate(input);
    result_to_pydict(py, &result, "isbn")
}

#[pyfunction]
fn is_valid_issn(input: &str) -> bool {
    verinum::issn::is_valid(input)
}

#[pyfunction]
fn validate_issn(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::issn::validate(input);
    result_to_pydict(py, &result, "issn")
}

#[pyfunction]
fn is_valid_isin(input: &str) -> bool {
    verinum::isin::is_valid(input)
}

#[pyfunction]
fn validate_isin(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::isin::validate(input);
    result_to_pydict(py, &result, "isin")
}

#[pyfunction]
fn is_valid_lei(input: &str) -> bool {
    verinum::lei::is_valid(input)
}

#[pyfunction]
fn validate_lei(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::lei::validate(input);
    result_to_pydict(py, &result, "lei")
}

#[pyfunction]
fn is_valid_ean(input: &str) -> bool {
    verinum::ean::is_valid(input)
}

#[pyfunction]
fn validate_ean(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::ean::validate(input);
    result_to_pydict(py, &result, "ean")
}

#[pyfunction]
fn is_valid_vat(input: &str) -> bool {
    verinum::vat::is_valid(input)
}

#[pyfunction]
fn validate_vat(py: Python<'_>, input: &str) -> PyResult<Py<PyDict>> {
    let result = verinum::vat::validate(input);
    result_to_pydict(py, &result, "vat")
}

// ---- Algorithm functions ----

#[pyfunction]
fn luhn_validate(input: &str) -> bool {
    verinum::algorithms::luhn::validate_str(input)
}

#[pyfunction]
fn luhn_generate(input: &str) -> u8 {
    verinum::algorithms::luhn::generate(input.as_bytes())
}

#[pyfunction]
fn verhoeff_validate(input: &str) -> bool {
    verinum::algorithms::verhoeff::validate_str(input)
}

#[pyfunction]
fn damm_validate(input: &str) -> bool {
    verinum::algorithms::damm::validate_str(input)
}

// ---- Data functions ----

fn country_to_pydict(py: Python<'_>, c: &verinum::countries::Country) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    dict.set_item("alpha2", c.alpha2)?;
    dict.set_item("alpha3", c.alpha3)?;
    dict.set_item("numeric", c.numeric)?;
    dict.set_item("name", c.name)?;
    dict.set_item("official_name", c.official_name)?;
    dict.set_item("common_name", c.common_name)?;
    dict.set_item("flag", c.flag)?;
    dict.set_item("currency", c.currency)?;
    dict.set_item("calling_code", c.calling_code)?;
    dict.set_item("tld", c.tld)?;
    dict.set_item("eu_member", c.eu_member)?;
    dict.set_item("iban_length", c.iban_length)?;
    Ok(dict.into())
}

#[pyfunction]
fn get_country(py: Python<'_>, alpha2: &str) -> PyResult<Option<Py<PyDict>>> {
    match verinum::countries::get(alpha2) {
        Some(c) => Ok(Some(country_to_pydict(py, c)?)),
        None => Ok(None),
    }
}

#[pyfunction]
fn get_country_by_alpha3(py: Python<'_>, alpha3: &str) -> PyResult<Option<Py<PyDict>>> {
    match verinum::countries::get_by_alpha3(alpha3) {
        Some(c) => Ok(Some(country_to_pydict(py, c)?)),
        None => Ok(None),
    }
}

fn currency_to_pydict(py: Python<'_>, c: &verinum::currencies::Currency) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    dict.set_item("code", c.code)?;
    dict.set_item("numeric", c.numeric)?;
    dict.set_item("name", c.name)?;
    dict.set_item("symbol", c.symbol)?;
    dict.set_item("decimals", c.decimals)?;
    let countries: Vec<&str> = c.countries.to_vec();
    dict.set_item("countries", countries)?;
    Ok(dict.into())
}

#[pyfunction]
fn get_currency(py: Python<'_>, code: &str) -> PyResult<Option<Py<PyDict>>> {
    match verinum::currencies::get(code) {
        Some(c) => Ok(Some(currency_to_pydict(py, c)?)),
        None => Ok(None),
    }
}

#[pyfunction]
fn get_vat_rate(py: Python<'_>, country: &str) -> PyResult<Option<Py<PyDict>>> {
    match verinum::data::vat_rates::get(country) {
        Some(r) => {
            let dict = PyDict::new(py);
            dict.set_item("country", r.country)?;
            dict.set_item("standard_rate", r.standard_rate)?;
            let reduced: Vec<f32> = r.reduced_rates.to_vec();
            dict.set_item("reduced_rates", reduced)?;
            Ok(Some(dict.into()))
        }
        None => Ok(None),
    }
}

// ---- Module registration ----

#[pymodule]
fn _verinum(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Validators
    m.add_function(wrap_pyfunction!(is_valid_iban, m)?)?;
    m.add_function(wrap_pyfunction!(validate_iban, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_bic, m)?)?;
    m.add_function(wrap_pyfunction!(validate_bic, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_credit_card, m)?)?;
    m.add_function(wrap_pyfunction!(validate_credit_card, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_isbn, m)?)?;
    m.add_function(wrap_pyfunction!(validate_isbn, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_issn, m)?)?;
    m.add_function(wrap_pyfunction!(validate_issn, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_isin, m)?)?;
    m.add_function(wrap_pyfunction!(validate_isin, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_lei, m)?)?;
    m.add_function(wrap_pyfunction!(validate_lei, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_ean, m)?)?;
    m.add_function(wrap_pyfunction!(validate_ean, m)?)?;
    m.add_function(wrap_pyfunction!(is_valid_vat, m)?)?;
    m.add_function(wrap_pyfunction!(validate_vat, m)?)?;

    // Algorithms
    m.add_function(wrap_pyfunction!(luhn_validate, m)?)?;
    m.add_function(wrap_pyfunction!(luhn_generate, m)?)?;
    m.add_function(wrap_pyfunction!(verhoeff_validate, m)?)?;
    m.add_function(wrap_pyfunction!(damm_validate, m)?)?;

    // Data
    m.add_function(wrap_pyfunction!(get_country, m)?)?;
    m.add_function(wrap_pyfunction!(get_country_by_alpha3, m)?)?;
    m.add_function(wrap_pyfunction!(get_currency, m)?)?;
    m.add_function(wrap_pyfunction!(get_vat_rate, m)?)?;

    Ok(())
}
