use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_iban(c: &mut Criterion) {
    let mut group = c.benchmark_group("iban");
    group.bench_function("is_valid", |b| {
        b.iter(|| verinum::iban::is_valid(black_box("GB82WEST12345698765432")))
    });
    group.bench_function("validate", |b| {
        b.iter(|| verinum::iban::validate(black_box("GB82WEST12345698765432")))
    });
    group.finish();
}

fn bench_credit_card(c: &mut Criterion) {
    let mut group = c.benchmark_group("credit_card");
    group.bench_function("is_valid_visa", |b| {
        b.iter(|| verinum::credit_card::is_valid(black_box("4111111111111111")))
    });
    group.bench_function("validate_visa", |b| {
        b.iter(|| verinum::credit_card::validate(black_box("4111111111111111")))
    });
    group.finish();
}

fn bench_vat(c: &mut Criterion) {
    let mut group = c.benchmark_group("vat");
    group.bench_function("is_valid_de", |b| {
        b.iter(|| verinum::vat::is_valid(black_box("DE123456789")))
    });
    group.bench_function("is_valid_gb", |b| {
        b.iter(|| verinum::vat::is_valid(black_box("GB123456789")))
    });
    group.finish();
}

fn bench_isbn(c: &mut Criterion) {
    let mut group = c.benchmark_group("isbn");
    group.bench_function("is_valid_13", |b| {
        b.iter(|| verinum::isbn::is_valid(black_box("9780306406157")))
    });
    group.bench_function("is_valid_10", |b| {
        b.iter(|| verinum::isbn::is_valid(black_box("0306406152")))
    });
    group.finish();
}

fn bench_ean(c: &mut Criterion) {
    c.bench_function("ean_is_valid", |b| {
        b.iter(|| verinum::ean::is_valid(black_box("4006381333931")))
    });
}

fn bench_isin(c: &mut Criterion) {
    c.bench_function("isin_is_valid", |b| {
        b.iter(|| verinum::isin::is_valid(black_box("US0378331005")))
    });
}

fn bench_bic(c: &mut Criterion) {
    c.bench_function("bic_is_valid", |b| {
        b.iter(|| verinum::bic::is_valid(black_box("DEUTDEFF500")))
    });
}

criterion_group!(
    benches,
    bench_iban,
    bench_credit_card,
    bench_vat,
    bench_isbn,
    bench_ean,
    bench_isin,
    bench_bic
);
criterion_main!(benches);
