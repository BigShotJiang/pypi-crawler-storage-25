use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_currency_lookup(c: &mut Criterion) {
    c.bench_function("currency_get", |b| {
        b.iter(|| verinum::currencies::get(black_box("EUR")))
    });
}

fn bench_vat_rate_lookup(c: &mut Criterion) {
    c.bench_function("vat_rate_get", |b| {
        b.iter(|| verinum::data::vat_rates::get(black_box("DE")))
    });
}

criterion_group!(benches, bench_currency_lookup, bench_vat_rate_lookup);
criterion_main!(benches);
