use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_luhn(c: &mut Criterion) {
    let mut group = c.benchmark_group("luhn");
    group.bench_function("validate_16", |b| {
        b.iter(|| verinum::algorithms::luhn::validate(black_box(b"4111111111111111")))
    });
    group.bench_function("generate_15", |b| {
        b.iter(|| verinum::algorithms::luhn::generate(black_box(b"411111111111111")))
    });
    group.finish();
}

fn bench_verhoeff(c: &mut Criterion) {
    c.bench_function("verhoeff_validate", |b| {
        b.iter(|| verinum::algorithms::verhoeff::validate(black_box(b"2363")))
    });
}

fn bench_damm(c: &mut Criterion) {
    c.bench_function("damm_validate", |b| {
        b.iter(|| verinum::algorithms::damm::validate(black_box(b"5724")))
    });
}

fn bench_iso7064(c: &mut Criterion) {
    c.bench_function("mod97_alpha", |b| {
        b.iter(|| {
            verinum::algorithms::iso7064::mod97_10_alpha_validate(black_box(
                b"WEST12345698765432GB82",
            ))
        })
    });
}

criterion_group!(
    benches,
    bench_luhn,
    bench_verhoeff,
    bench_damm,
    bench_iso7064
);
criterion_main!(benches);
