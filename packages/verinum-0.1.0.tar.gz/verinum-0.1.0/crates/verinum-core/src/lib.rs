#![no_std]

#[cfg(feature = "alloc")]
extern crate alloc;
#[cfg(feature = "std")]
extern crate std;

pub mod error;
pub mod types;
pub mod util;

#[cfg(any(
    feature = "luhn",
    feature = "verhoeff",
    feature = "damm",
    feature = "iso7064"
))]
pub mod algorithms;

#[cfg(any(
    feature = "iban",
    feature = "bic",
    feature = "credit_card",
    feature = "isbn",
    feature = "issn",
    feature = "isin",
    feature = "lei",
    feature = "ean",
    feature = "vat"
))]
pub mod validators;

#[cfg(any(
    feature = "data-countries",
    feature = "data-subdivisions",
    feature = "data-currencies",
    feature = "data-languages",
    feature = "data-vat-rates"
))]
pub mod data;

// Re-exports for convenience: verinum::iban, verinum::vat, etc.
#[cfg(feature = "bic")]
pub use validators::bic;
#[cfg(feature = "credit_card")]
pub use validators::credit_card;
#[cfg(feature = "ean")]
pub use validators::ean;
#[cfg(feature = "iban")]
pub use validators::iban;
#[cfg(feature = "isbn")]
pub use validators::isbn;
#[cfg(feature = "isin")]
pub use validators::isin;
#[cfg(feature = "issn")]
pub use validators::issn;
#[cfg(feature = "lei")]
pub use validators::lei;
#[cfg(feature = "vat")]
pub use validators::vat;

#[cfg(feature = "data-countries")]
pub use data::countries;
#[cfg(feature = "data-currencies")]
pub use data::currencies;
#[cfg(feature = "data-languages")]
pub use data::languages;
#[cfg(feature = "data-subdivisions")]
pub use data::subdivisions;
#[cfg(feature = "data-vat-rates")]
pub use data::vat_rates;
