use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    let len = bytes.len();
    if len != 8 && len != 11 {
        return false;
    }
    // Bank code: 4 uppercase letters
    if !util::all_ascii_upper(&bytes[..4]) {
        return false;
    }
    // Country code: 2 uppercase letters
    if !bytes[4].is_ascii_uppercase() || !bytes[5].is_ascii_uppercase() {
        return false;
    }
    // Location: 2 alphanumeric
    if !bytes[6].is_ascii_alphanumeric() || !bytes[7].is_ascii_alphanumeric() {
        return false;
    }
    // Branch: 3 alphanumeric (if present)
    if len == 11 && !util::all_ascii_alphanumeric(&bytes[8..11]) {
        return false;
    }
    true
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    let bytes = compact.as_bytes();
    let len = bytes.len();

    if len != 8 && len != 11 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_upper(&bytes[..4]) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !bytes[4].is_ascii_uppercase() || !bytes[5].is_ascii_uppercase() {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCountry);
    }
    if !bytes[6].is_ascii_alphanumeric() || !bytes[7].is_ascii_alphanumeric() {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if len == 11 && !util::all_ascii_alphanumeric(&bytes[8..11]) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }

    let mut bank_code = [0u8; 4];
    bank_code.copy_from_slice(&bytes[..4]);
    let country = [bytes[4], bytes[5]];
    let location = [bytes[6], bytes[7]];
    let branch = if len == 11 {
        let mut b = [0u8; 3];
        b.copy_from_slice(&bytes[8..11]);
        Some(b)
    } else {
        None
    };

    let formatted = compact;

    ValidationResult::valid(
        compact,
        formatted,
        Metadata::Bic {
            bank_code,
            country,
            location,
            branch,
        },
    )
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_and_upper(input.as_bytes(), buf)
}

/// Format — BICs have no standard formatting beyond uppercase.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    compact_into(input, buf)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_8char() {
        assert!(is_valid("DEUTDEFF"));
        assert!(is_valid("COBADEFF"));
        assert!(is_valid("BNPAFRPP"));
    }

    #[test]
    fn test_valid_11char() {
        assert!(is_valid("DEUTDEFF500"));
        assert!(is_valid("COBADEFFXXX"));
    }

    #[test]
    fn test_case_insensitive() {
        assert!(is_valid("deutdeff"));
        assert!(is_valid("Deutdeff500"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("DEUTDEFF5")); // 9 chars
        assert!(!is_valid("1234DEFF")); // digits in bank code
        assert!(!is_valid("DEUT12FF")); // digits in country
        assert!(!is_valid(""));
        assert!(!is_valid("AB")); // too short
    }

    #[test]
    fn test_validate_metadata() {
        let result = validate("DEUTDEFF500");
        assert!(result.is_valid);
        if let Metadata::Bic {
            bank_code,
            country,
            location,
            branch,
        } = result.metadata
        {
            assert_eq!(&bank_code, b"DEUT");
            assert_eq!(&country, b"DE");
            assert_eq!(&location, b"FF");
            assert_eq!(branch, Some(*b"500"));
        } else {
            panic!("Expected BIC metadata");
        }
    }
}
