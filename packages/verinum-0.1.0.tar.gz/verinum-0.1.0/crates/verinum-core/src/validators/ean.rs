use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, EanType, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    let len = bytes.len();
    if len != 8 && len != 13 {
        return false;
    }
    if !util::all_ascii_digits(bytes) {
        return false;
    }
    ean_checksum_valid(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    let bytes = compact.as_bytes();
    let len = bytes.len();

    if len != 8 && len != 13 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_digits(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !ean_checksum_valid(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let ean_type = if len == 8 {
        EanType::Ean8
    } else {
        EanType::Ean13
    };

    // Extract country/GS1 prefix (first 3 digits for EAN-13, first 3 for EAN-8 N/A)
    let mut prefix_buf = CompactBuf::new();
    if len == 13 {
        for &b in &bytes[..3] {
            prefix_buf.push(b);
        }
    }

    let mut formatted = CompactBuf::new();
    format_ean(bytes, &mut formatted);

    ValidationResult::valid(
        compact,
        formatted,
        Metadata::Ean {
            ean_type,
            country_prefix: prefix_buf,
        },
    )
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_formatting(input.as_bytes(), buf)
}

/// Format with standard separators.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    let mut compact = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut compact) {
        return false;
    }
    buf.clear();
    format_ean(compact.as_bytes(), buf);
    true
}

#[inline]
fn ean_checksum_valid(digits: &[u8]) -> bool {
    let mut sum: u32 = 0;
    let len = digits.len();
    for (i, &d) in digits.iter().enumerate() {
        let n = (d - b'0') as u32;
        if (len - 1 - i).is_multiple_of(2) {
            sum += n;
        } else {
            sum += n * 3;
        }
    }
    sum.is_multiple_of(10)
}

fn format_ean(bytes: &[u8], buf: &mut CompactBuf) {
    // EAN-13: X-XXXXXX-XXXXXX-X or just the digits
    // EAN-8: XXXX-XXXX or just the digits
    // Standard: no separators, just digits
    for &b in bytes {
        buf.push(b);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_ean13() {
        assert!(is_valid("4006381333931"));
        assert!(is_valid("5901234123457"));
        assert!(is_valid("4003994155486"));
    }

    #[test]
    fn test_valid_ean8() {
        assert!(is_valid("96385074"));
        assert!(is_valid("65833254"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("4006381333932")); // wrong check digit
        assert!(!is_valid("123456")); // wrong length
        assert!(!is_valid(""));
        assert!(!is_valid("400638133393A")); // non-digit
    }

    #[test]
    fn test_with_formatting() {
        assert!(is_valid("4006381 333931"));
        assert!(is_valid("4006-3813-33931"));
    }

    #[test]
    fn test_validate_metadata() {
        let result = validate("4006381333931");
        assert!(result.is_valid);
        assert_eq!(result.compact.as_str(), "4006381333931");
        if let Metadata::Ean { ean_type, .. } = result.metadata {
            assert_eq!(ean_type, EanType::Ean13);
        } else {
            panic!("Expected Ean metadata");
        }
    }
}
