use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !strip_issn(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    if bytes.len() != 8 {
        return false;
    }
    issn_checksum_valid(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !strip_issn(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    let bytes = compact.as_bytes();

    if bytes.len() != 8 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_digits(&bytes[..7]) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !issn_checksum_valid(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let mut formatted = CompactBuf::new();
    format_issn(bytes, &mut formatted);

    ValidationResult::valid(compact, formatted, Metadata::Issn {})
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    strip_issn(input.as_bytes(), buf)
}

/// Format with standard separators.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    let mut compact = CompactBuf::new();
    if !strip_issn(input.as_bytes(), &mut compact) {
        return false;
    }
    buf.clear();
    format_issn(compact.as_bytes(), buf);
    true
}

fn strip_issn(input: &[u8], buf: &mut CompactBuf) -> bool {
    for &b in input {
        match b {
            b' ' | b'-' | b'\t' => continue,
            b'0'..=b'9' => {
                if !buf.push(b) {
                    return false;
                }
            }
            b'X' | b'x' => {
                if !buf.push(b'X') {
                    return false;
                }
            }
            _ => return false,
        }
    }
    true
}

/// ISSN checksum: weighted sum of first 7 digits with weights 8,7,6,5,4,3,2.
/// Check digit (8th) makes total mod 11 == 0. X represents 10.
fn issn_checksum_valid(bytes: &[u8]) -> bool {
    if bytes.len() != 8 {
        return false;
    }
    if !util::all_ascii_digits(&bytes[..7]) {
        return false;
    }
    let mut sum: u32 = 0;
    for (i, &b) in bytes[..7].iter().enumerate() {
        sum += (b - b'0') as u32 * (8 - i as u32);
    }
    let last = if bytes[7] == b'X' {
        10u32
    } else if bytes[7].is_ascii_digit() {
        (bytes[7] - b'0') as u32
    } else {
        return false;
    };
    sum += last;
    sum.is_multiple_of(11)
}

fn format_issn(bytes: &[u8], buf: &mut CompactBuf) {
    // ISSN format: XXXX-XXXX
    for (i, &b) in bytes.iter().enumerate() {
        if i == 4 {
            buf.push(b'-');
        }
        buf.push(b);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid() {
        assert!(is_valid("0378-5955"));
        assert!(is_valid("03785955"));
        assert!(is_valid("0317-8471"));
        assert!(is_valid("1050-124X"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("0378-5956")); // wrong check
        assert!(!is_valid("1234")); // too short
        assert!(!is_valid(""));
        assert!(!is_valid("ABCDEFGH"));
    }

    #[test]
    fn test_validate_formatted() {
        let result = validate("0378-5955");
        assert!(result.is_valid);
        assert_eq!(result.compact.as_str(), "03785955");
        assert_eq!(result.formatted.as_str(), "0378-5955");
    }
}
