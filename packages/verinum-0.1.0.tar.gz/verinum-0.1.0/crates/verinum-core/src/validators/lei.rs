use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    if bytes.len() != 20 {
        return false;
    }
    if !util::all_ascii_alphanumeric(bytes) {
        return false;
    }
    // Positions 5-6 (0-indexed: 4-5) must be "00"
    if bytes[4] != b'0' || bytes[5] != b'0' {
        return false;
    }
    // Mod 97-10 check on alphanumeric
    crate::algorithms::iso7064::mod97_10_alpha_validate(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    let bytes = compact.as_bytes();

    if bytes.len() != 20 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_alphanumeric(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if bytes[4] != b'0' || bytes[5] != b'0' {
        return ValidationResult::invalid(ValidationErrorKind::InvalidStructure);
    }
    if !crate::algorithms::iso7064::mod97_10_alpha_validate(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let mut lou_prefix = [0u8; 4];
    lou_prefix.copy_from_slice(&bytes[..4]);

    let formatted = compact;

    ValidationResult::valid(compact, formatted, Metadata::Lei { lou_prefix })
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_and_upper(input.as_bytes(), buf)
}

/// Format — LEIs have no standard formatting.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    compact_into(input, buf)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid() {
        assert!(is_valid("529900T8BM49AURSDO55")); // Known valid LEI
        assert!(is_valid("213800WSGIIZCXF1P572")); // Known valid LEI
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("529900T8BM49AURSDO56")); // wrong check
        assert!(!is_valid("12345")); // too short
        assert!(!is_valid(""));
    }

    #[test]
    fn test_position_5_6_must_be_00() {
        // Positions 5-6 (1-indexed) = indices 4-5 must be "00"
        assert!(is_valid("529900T8BM49AURSDO55")); // 5299[00] - OK
    }

    #[test]
    fn test_validate_metadata() {
        let result = validate("529900T8BM49AURSDO55");
        assert!(result.is_valid);
        if let Metadata::Lei { lou_prefix } = result.metadata {
            assert_eq!(&lou_prefix, b"5299");
        } else {
            panic!("Expected LEI metadata");
        }
    }
}
