use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, Metadata, ValidationResult};
use crate::util;
use phf::phf_map;

/// BBAN lengths by country code (ISO 13616).
static IBAN_LENGTHS: phf::Map<&'static str, u8> = phf_map! {
    "AL" => 28, "AD" => 24, "AT" => 20, "AZ" => 28, "BH" => 22,
    "BY" => 28, "BE" => 16, "BA" => 20, "BR" => 29, "BG" => 22,
    "CR" => 22, "HR" => 21, "CY" => 28, "CZ" => 24, "DK" => 18,
    "DO" => 28, "TL" => 23, "EG" => 29, "SV" => 28, "EE" => 20,
    "FO" => 18, "FI" => 18, "FR" => 27, "GE" => 22, "DE" => 22,
    "GI" => 23, "GR" => 27, "GL" => 18, "GT" => 28, "HU" => 28,
    "IS" => 26, "IQ" => 23, "IE" => 22, "IL" => 23, "IT" => 27,
    "JO" => 30, "KZ" => 20, "XK" => 20, "KW" => 30, "LV" => 21,
    "LB" => 28, "LY" => 25, "LI" => 21, "LT" => 20, "LU" => 20,
    "MT" => 31, "MR" => 27, "MU" => 30, "MC" => 27, "MD" => 24,
    "ME" => 22, "NL" => 18, "MK" => 19, "NO" => 15, "PK" => 24,
    "PS" => 29, "PL" => 28, "PT" => 25, "QA" => 29, "RO" => 24,
    "LC" => 32, "SM" => 27, "ST" => 25, "SA" => 24, "RS" => 22,
    "SC" => 31, "SK" => 24, "SI" => 19, "ES" => 24, "SD" => 18,
    "SE" => 24, "CH" => 21, "TN" => 24, "TR" => 26, "UA" => 29,
    "AE" => 23, "GB" => 22, "VA" => 22, "VG" => 24,
};

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    if bytes.len() < 5 {
        return false;
    }
    // Country code: 2 uppercase letters
    if !bytes[0].is_ascii_uppercase() || !bytes[1].is_ascii_uppercase() {
        return false;
    }
    // Check digits: 2 digits
    if !bytes[2].is_ascii_digit() || !bytes[3].is_ascii_digit() {
        return false;
    }
    // Verify length against country
    let cc = core::str::from_utf8(&bytes[..2]).unwrap_or("");
    if let Some(&expected_len) = IBAN_LENGTHS.get(cc) {
        if bytes.len() != expected_len as usize {
            return false;
        }
    } else {
        return false;
    }
    // BBAN: alphanumeric
    if !util::all_ascii_alphanumeric(&bytes[4..]) {
        return false;
    }
    // Mod 97-10 check: rearrange (BBAN + country + check digits)
    iban_mod97_check(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    let bytes = compact.as_bytes();

    if bytes.len() < 5 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !bytes[0].is_ascii_uppercase() || !bytes[1].is_ascii_uppercase() {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCountry);
    }
    if !bytes[2].is_ascii_digit() || !bytes[3].is_ascii_digit() {
        return ValidationResult::invalid(ValidationErrorKind::InvalidStructure);
    }

    let cc = core::str::from_utf8(&bytes[..2]).unwrap_or("");
    let expected_len = match IBAN_LENGTHS.get(cc) {
        Some(&len) => len,
        None => return ValidationResult::invalid(ValidationErrorKind::UnsupportedCountry),
    };

    if bytes.len() != expected_len as usize {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_alphanumeric(&bytes[4..]) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !iban_mod97_check(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let country = [bytes[0], bytes[1]];
    let check_digits = [bytes[2], bytes[3]];
    let bban_length = expected_len - 4;

    let mut formatted = CompactBuf::new();
    format_iban(bytes, &mut formatted);

    ValidationResult::valid(
        compact,
        formatted,
        Metadata::Iban {
            country,
            bban_length,
            check_digits,
        },
    )
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_and_upper(input.as_bytes(), buf)
}

/// Format with standard separators (groups of 4).
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    let mut compact = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut compact) {
        return false;
    }
    buf.clear();
    format_iban(compact.as_bytes(), buf);
    true
}

/// IBAN Mod 97-10 check: rearrange BBAN + CC + check digits, then validate.
fn iban_mod97_check(bytes: &[u8]) -> bool {
    // Rearrange: move first 4 chars to end
    let mut remainder: u32 = 0;
    // Process BBAN (positions 4..)
    for &b in &bytes[4..] {
        if b.is_ascii_digit() {
            remainder = (remainder * 10 + (b - b'0') as u32) % 97;
        } else if b.is_ascii_uppercase() {
            let val = (b - b'A' + 10) as u32;
            remainder = (remainder * 10 + val / 10) % 97;
            remainder = (remainder * 10 + val % 10) % 97;
        }
    }
    // Process country code + check digits (positions 0..4)
    for &b in &bytes[..4] {
        if b.is_ascii_digit() {
            remainder = (remainder * 10 + (b - b'0') as u32) % 97;
        } else if b.is_ascii_uppercase() {
            let val = (b - b'A' + 10) as u32;
            remainder = (remainder * 10 + val / 10) % 97;
            remainder = (remainder * 10 + val % 10) % 97;
        }
    }
    remainder == 1
}

fn format_iban(bytes: &[u8], buf: &mut CompactBuf) {
    // Groups of 4, separated by spaces
    for (i, &b) in bytes.iter().enumerate() {
        if i > 0 && i % 4 == 0 {
            buf.push(b' ');
        }
        buf.push(b);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid() {
        assert!(is_valid("GB82 WEST 1234 5698 7654 32"));
        assert!(is_valid("GB82WEST12345698765432"));
        assert!(is_valid("DE89370400440532013000"));
        assert!(is_valid("FR7630006000011234567890189"));
        assert!(is_valid("ES9121000418450200051332"));
    }

    #[test]
    fn test_case_insensitive() {
        assert!(is_valid("gb82west12345698765432"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("GB82WEST12345698765433")); // wrong check
        assert!(!is_valid("XX82WEST12345698765432")); // unsupported country
        assert!(!is_valid("GB00WEST12345698765432")); // different check
        assert!(!is_valid(""));
        assert!(!is_valid("AB")); // too short
    }

    #[test]
    fn test_wrong_length() {
        // DE should be 22 chars, this is 21
        assert!(!is_valid("DE8937040044053201300"));
    }

    #[test]
    fn test_validate_metadata() {
        let result = validate("GB82WEST12345698765432");
        assert!(result.is_valid);
        if let Metadata::Iban {
            country,
            check_digits,
            bban_length,
        } = result.metadata
        {
            assert_eq!(&country, b"GB");
            assert_eq!(&check_digits, b"82");
            assert_eq!(bban_length, 18);
        } else {
            panic!("Expected IBAN metadata");
        }
    }

    #[test]
    fn test_formatted() {
        let result = validate("GB82WEST12345698765432");
        assert_eq!(result.formatted.as_str(), "GB82 WEST 1234 5698 7654 32");
    }
}
