use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, IsbnType, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !strip_isbn(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    match bytes.len() {
        10 => is_valid_isbn10(bytes),
        13 => is_valid_isbn13(bytes),
        _ => false,
    }
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !strip_isbn(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    let bytes = compact.as_bytes();

    match bytes.len() {
        10 => {
            if !is_valid_isbn10(bytes) {
                return if !util::all_ascii_digits(&bytes[..9]) {
                    ValidationResult::invalid(ValidationErrorKind::InvalidCharset)
                } else {
                    ValidationResult::invalid(ValidationErrorKind::InvalidChecksum)
                };
            }
            // Cross-convert to ISBN-13
            let isbn13 = isbn10_to_13(bytes);
            let mut formatted = CompactBuf::new();
            format_isbn10(bytes, &mut formatted);

            ValidationResult::valid(
                compact,
                formatted,
                Metadata::Isbn {
                    isbn_type: IsbnType::Isbn10,
                    isbn10: Some(compact),
                    isbn13,
                },
            )
        }
        13 => {
            if !is_valid_isbn13(bytes) {
                return if !util::all_ascii_digits(bytes) {
                    ValidationResult::invalid(ValidationErrorKind::InvalidCharset)
                } else if !bytes.starts_with(b"978") && !bytes.starts_with(b"979") {
                    ValidationResult::invalid(ValidationErrorKind::InvalidPrefix)
                } else {
                    ValidationResult::invalid(ValidationErrorKind::InvalidChecksum)
                };
            }
            let isbn10 = isbn13_to_10(bytes);
            let mut formatted = CompactBuf::new();
            format_isbn13(bytes, &mut formatted);

            ValidationResult::valid(
                compact,
                formatted,
                Metadata::Isbn {
                    isbn_type: IsbnType::Isbn13,
                    isbn10,
                    isbn13: Some(compact),
                },
            )
        }
        _ => ValidationResult::invalid(ValidationErrorKind::InvalidLength),
    }
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    strip_isbn(input.as_bytes(), buf)
}

/// Format with standard separators.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    let mut compact = CompactBuf::new();
    if !strip_isbn(input.as_bytes(), &mut compact) {
        return false;
    }
    buf.clear();
    match compact.len() {
        10 => format_isbn10(compact.as_bytes(), buf),
        13 => format_isbn13(compact.as_bytes(), buf),
        _ => return false,
    }
    true
}

/// Strip ISBN formatting (spaces, hyphens) and normalize.
/// Keeps digits and final X/x (for ISBN-10).
fn strip_isbn(input: &[u8], buf: &mut CompactBuf) -> bool {
    for &b in input {
        match b {
            b' ' | b'-' | b'.' | b'\t' => continue,
            b'0'..=b'9' => {
                if !buf.push(b) {
                    return false;
                }
            }
            b'X' | b'x' => {
                if !buf.push(b'X') {
                    return false;
                }
            }
            _ => return false,
        }
    }
    true
}

/// ISBN-10 check: weighted sum mod 11, last digit can be X (=10).
fn is_valid_isbn10(bytes: &[u8]) -> bool {
    if bytes.len() != 10 {
        return false;
    }
    // First 9 must be digits
    if !util::all_ascii_digits(&bytes[..9]) {
        return false;
    }
    let mut sum: u32 = 0;
    for (i, &b) in bytes[..9].iter().enumerate() {
        sum += (b - b'0') as u32 * (10 - i as u32);
    }
    let last = if bytes[9] == b'X' {
        10u32
    } else if bytes[9].is_ascii_digit() {
        (bytes[9] - b'0') as u32
    } else {
        return false;
    };
    sum += last;
    sum.is_multiple_of(11)
}

/// ISBN-13 check: weighted sum mod 10, weights alternating 1 and 3.
fn is_valid_isbn13(bytes: &[u8]) -> bool {
    if bytes.len() != 13 {
        return false;
    }
    if !util::all_ascii_digits(bytes) {
        return false;
    }
    // Must start with 978 or 979
    if !bytes.starts_with(b"978") && !bytes.starts_with(b"979") {
        return false;
    }
    let mut sum: u32 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        let n = (b - b'0') as u32;
        if i % 2 == 0 {
            sum += n;
        } else {
            sum += n * 3;
        }
    }
    sum.is_multiple_of(10)
}

/// Convert ISBN-10 to ISBN-13.
fn isbn10_to_13(isbn10: &[u8]) -> Option<CompactBuf> {
    if isbn10.len() != 10 {
        return None;
    }
    let mut buf = CompactBuf::new();
    buf.push(b'9');
    buf.push(b'7');
    buf.push(b'8');
    for &b in &isbn10[..9] {
        buf.push(b);
    }
    // Calculate ISBN-13 check digit
    let bytes = buf.as_bytes();
    let mut sum: u32 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        let n = (b - b'0') as u32;
        if i % 2 == 0 {
            sum += n;
        } else {
            sum += n * 3;
        }
    }
    let check = ((10 - (sum % 10)) % 10) as u8 + b'0';
    buf.push(check);
    Some(buf)
}

/// Convert ISBN-13 to ISBN-10 (only works for 978-prefix).
fn isbn13_to_10(isbn13: &[u8]) -> Option<CompactBuf> {
    if isbn13.len() != 13 || !isbn13.starts_with(b"978") {
        return None;
    }
    let mut buf = CompactBuf::new();
    for &b in &isbn13[3..12] {
        buf.push(b);
    }
    // Calculate ISBN-10 check digit
    let bytes = buf.as_bytes();
    let mut sum: u32 = 0;
    for (i, &b) in bytes.iter().enumerate() {
        sum += (b - b'0') as u32 * (10 - i as u32);
    }
    let check = (11 - (sum % 11)) % 11;
    if check == 10 {
        buf.push(b'X');
    } else {
        buf.push(check as u8 + b'0');
    }
    Some(buf)
}

fn format_isbn10(bytes: &[u8], buf: &mut CompactBuf) {
    // Simple format: X-XXX-XXXXX-X
    for (i, &b) in bytes.iter().enumerate() {
        if i == 1 || i == 4 || i == 9 {
            buf.push(b'-');
        }
        buf.push(b);
    }
}

fn format_isbn13(bytes: &[u8], buf: &mut CompactBuf) {
    // Simple format: XXX-X-XXX-XXXXX-X
    for (i, &b) in bytes.iter().enumerate() {
        if i == 3 || i == 4 || i == 7 || i == 12 {
            buf.push(b'-');
        }
        buf.push(b);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_isbn10() {
        assert!(is_valid("0306406152"));
        assert!(is_valid("0-306-40615-2"));
        assert!(is_valid("080442957X"));
        assert!(is_valid("0-8044-2957-X"));
    }

    #[test]
    fn test_valid_isbn13() {
        assert!(is_valid("9780306406157"));
        assert!(is_valid("978-0-306-40615-7"));
        assert!(is_valid("9780131103627"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("0306406153")); // wrong check
        assert!(!is_valid("9780306406158")); // wrong check
        assert!(!is_valid("123")); // too short
        assert!(!is_valid(""));
        assert!(!is_valid("ABCDEFGHIJ")); // non-digits
    }

    #[test]
    fn test_cross_conversion() {
        let result = validate("0306406152");
        assert!(result.is_valid);
        if let Metadata::Isbn {
            isbn_type, isbn13, ..
        } = result.metadata
        {
            assert_eq!(isbn_type, IsbnType::Isbn10);
            assert_eq!(isbn13.unwrap().as_str(), "9780306406157");
        }

        let result = validate("9780306406157");
        assert!(result.is_valid);
        if let Metadata::Isbn {
            isbn_type, isbn10, ..
        } = result.metadata
        {
            assert_eq!(isbn_type, IsbnType::Isbn13);
            assert_eq!(isbn10.unwrap().as_str(), "0306406152");
        }
    }
}
