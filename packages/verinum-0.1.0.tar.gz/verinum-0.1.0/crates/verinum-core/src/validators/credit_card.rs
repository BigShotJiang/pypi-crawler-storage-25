use crate::error::ValidationErrorKind;
use crate::types::{CardBrand, CompactBuf, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    let len = bytes.len();
    if !(12..=19).contains(&len) {
        return false;
    }
    if !util::all_ascii_digits(bytes) {
        return false;
    }
    crate::algorithms::luhn::validate(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    let bytes = compact.as_bytes();
    let len = bytes.len();

    if !(12..=19).contains(&len) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !util::all_ascii_digits(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !crate::algorithms::luhn::validate(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let brand = detect_brand(bytes);
    let mut formatted = CompactBuf::new();
    format_card(bytes, brand, &mut formatted);

    ValidationResult::valid(compact, formatted, Metadata::CreditCard { brand })
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_formatting(input.as_bytes(), buf)
}

/// Format with standard separators.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    let mut compact = CompactBuf::new();
    if !util::strip_formatting(input.as_bytes(), &mut compact) {
        return false;
    }
    buf.clear();
    let brand = detect_brand(compact.as_bytes());
    format_card(compact.as_bytes(), brand, buf);
    true
}

/// Detect card brand from IIN (Issuer Identification Number) prefix.
fn detect_brand(bytes: &[u8]) -> CardBrand {
    if bytes.is_empty() {
        return CardBrand::Unknown;
    }
    let len = bytes.len();

    // Amex: starts with 34 or 37, 15 digits
    if len == 15 && bytes[0] == b'3' && (bytes[1] == b'4' || bytes[1] == b'7') {
        return CardBrand::Amex;
    }

    // Visa: starts with 4, 13 or 16 digits
    if bytes[0] == b'4' && (len == 13 || len == 16 || len == 19) {
        return CardBrand::Visa;
    }

    // Mastercard: starts with 51-55 or 2221-2720, 16 digits
    if len == 16 {
        if bytes[0] == b'5' && bytes[1] >= b'1' && bytes[1] <= b'5' {
            return CardBrand::Mastercard;
        }
        if bytes[0] == b'2' {
            let prefix4 = prefix_num(bytes, 4);
            if (2221..=2720).contains(&prefix4) {
                return CardBrand::Mastercard;
            }
        }
    }

    // Discover: starts with 6011, 622126-622925, 644-649, 65
    if bytes[0] == b'6' && (len == 16 || len == 19) {
        if bytes.starts_with(b"6011") {
            return CardBrand::Discover;
        }
        if bytes.starts_with(b"65") {
            return CardBrand::Discover;
        }
        if bytes[1] == b'4' && (b'4'..=b'9').contains(&bytes[2]) {
            return CardBrand::Discover;
        }
        let prefix6 = prefix_num(bytes, 6);
        if (622126..=622925).contains(&prefix6) {
            return CardBrand::Discover;
        }
    }

    // Diners Club: starts with 300-305, 36, 38
    if bytes[0] == b'3' {
        if bytes.starts_with(b"36") && (len == 14 || len == 16) {
            return CardBrand::DinersClub;
        }
        if bytes.starts_with(b"38") && len == 14 {
            return CardBrand::DinersClub;
        }
        if len == 14 {
            let prefix3 = prefix_num(bytes, 3);
            if (300..=305).contains(&prefix3) {
                return CardBrand::DinersClub;
            }
        }
    }

    // JCB: starts with 3528-3589, 16-19 digits
    if bytes[0] == b'3' && (16..=19).contains(&len) {
        let prefix4 = prefix_num(bytes, 4);
        if (3528..=3589).contains(&prefix4) {
            return CardBrand::Jcb;
        }
    }

    // UnionPay: starts with 62, 16-19 digits
    if bytes.starts_with(b"62") && (16..=19).contains(&len) {
        return CardBrand::UnionPay;
    }

    CardBrand::Unknown
}

fn prefix_num(bytes: &[u8], n: usize) -> u32 {
    let mut val: u32 = 0;
    for &b in bytes.iter().take(n) {
        val = val * 10 + (b - b'0') as u32;
    }
    val
}

fn format_card(bytes: &[u8], brand: CardBrand, buf: &mut CompactBuf) {
    match brand {
        CardBrand::Amex => {
            // XXXX XXXXXX XXXXX
            for (i, &b) in bytes.iter().enumerate() {
                if i == 4 || i == 10 {
                    buf.push(b' ');
                }
                buf.push(b);
            }
        }
        _ => {
            // XXXX XXXX XXXX XXXX (standard 4-group)
            for (i, &b) in bytes.iter().enumerate() {
                if i > 0 && i % 4 == 0 {
                    buf.push(b' ');
                }
                buf.push(b);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_visa() {
        assert!(is_valid("4111111111111111"));
        assert!(is_valid("4111 1111 1111 1111"));
        assert!(is_valid("4012888888881881"));
    }

    #[test]
    fn test_valid_mastercard() {
        assert!(is_valid("5500000000000004"));
        assert!(is_valid("5105105105105100"));
        assert!(is_valid("2223000048400011"));
    }

    #[test]
    fn test_valid_amex() {
        assert!(is_valid("378282246310005"));
        assert!(is_valid("371449635398431"));
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("4111111111111112")); // wrong check
        assert!(!is_valid("1234")); // too short
        assert!(!is_valid(""));
        assert!(!is_valid("ABCDEFGHIJKLMNOP"));
    }

    #[test]
    fn test_brand_detection() {
        let r = validate("4111111111111111");
        if let Metadata::CreditCard { brand } = r.metadata {
            assert_eq!(brand, CardBrand::Visa);
        }

        let r = validate("5500000000000004");
        if let Metadata::CreditCard { brand } = r.metadata {
            assert_eq!(brand, CardBrand::Mastercard);
        }

        let r = validate("378282246310005");
        if let Metadata::CreditCard { brand } = r.metadata {
            assert_eq!(brand, CardBrand::Amex);
        }
    }

    #[test]
    fn test_format_amex() {
        let r = validate("378282246310005");
        assert_eq!(r.formatted.as_str(), "3782 822463 10005");
    }

    #[test]
    fn test_format_visa() {
        let r = validate("4111111111111111");
        assert_eq!(r.formatted.as_str(), "4111 1111 1111 1111");
    }
}
