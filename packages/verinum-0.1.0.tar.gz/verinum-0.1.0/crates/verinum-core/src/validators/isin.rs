use crate::error::ValidationErrorKind;
use crate::types::{CompactBuf, Metadata, ValidationResult};
use crate::util;

/// Fast path — zero allocations, standalone implementation.
#[inline]
pub fn is_valid(input: &str) -> bool {
    let mut buf = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut buf) {
        return false;
    }
    let bytes = buf.as_bytes();
    if bytes.len() != 12 {
        return false;
    }
    // First 2 chars: uppercase letters (country code)
    if !bytes[0].is_ascii_uppercase() || !bytes[1].is_ascii_uppercase() {
        return false;
    }
    // Chars 3-11: alphanumeric
    if !util::all_ascii_alphanumeric(&bytes[2..]) {
        return false;
    }
    isin_luhn_valid(bytes)
}

/// Full structured validation with metadata.
pub fn validate(input: &str) -> ValidationResult {
    let mut compact = CompactBuf::new();
    if !util::strip_and_upper(input.as_bytes(), &mut compact) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    let bytes = compact.as_bytes();

    if bytes.len() != 12 {
        return ValidationResult::invalid(ValidationErrorKind::InvalidLength);
    }
    if !bytes[0].is_ascii_uppercase() || !bytes[1].is_ascii_uppercase() {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCountry);
    }
    if !util::all_ascii_alphanumeric(&bytes[2..]) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidCharset);
    }
    if !isin_luhn_valid(bytes) {
        return ValidationResult::invalid(ValidationErrorKind::InvalidChecksum);
    }

    let country = [bytes[0], bytes[1]];
    let formatted = compact;

    ValidationResult::valid(compact, formatted, Metadata::Isin { country })
}

/// Strip formatting into a stack buffer.
#[inline]
pub fn compact_into(input: &str, buf: &mut CompactBuf) -> bool {
    buf.clear();
    util::strip_and_upper(input.as_bytes(), buf)
}

/// Format — ISINs have no standard formatting beyond uppercase.
#[inline]
pub fn format_into(input: &str, buf: &mut CompactBuf) -> bool {
    compact_into(input, buf)
}

/// ISIN Luhn validation: convert letters to numbers (A=10..Z=35),
/// concatenate all digits, then apply Luhn.
fn isin_luhn_valid(bytes: &[u8]) -> bool {
    let mut digits = [0u8; 24]; // max: 12 chars * 2 digits each
    let mut len = 0;
    for &b in bytes {
        if b.is_ascii_digit() {
            digits[len] = b;
            len += 1;
        } else if b.is_ascii_uppercase() {
            let val = b - b'A' + 10;
            digits[len] = val / 10 + b'0';
            len += 1;
            digits[len] = val % 10 + b'0';
            len += 1;
        } else {
            return false;
        }
    }
    crate::algorithms::luhn::validate(&digits[..len])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid() {
        assert!(is_valid("US0378331005")); // Apple
        assert!(is_valid("GB0002634946")); // BAE Systems
        assert!(is_valid("US38259P5089")); // Google
        assert!(is_valid("AU0000XVGZA3")); // Treasury Corp
    }

    #[test]
    fn test_invalid() {
        assert!(!is_valid("US0378331006")); // wrong check
        assert!(!is_valid("US037833100")); // too short
        assert!(!is_valid(""));
        assert!(!is_valid("XX0000000000")); // valid format but check fails
    }

    #[test]
    fn test_case_insensitive() {
        assert!(is_valid("us0378331005"));
    }

    #[test]
    fn test_validate_metadata() {
        let result = validate("US0378331005");
        assert!(result.is_valid);
        if let Metadata::Isin { country } = result.metadata {
            assert_eq!(&country, b"US");
        } else {
            panic!("Expected ISIN metadata");
        }
    }
}
