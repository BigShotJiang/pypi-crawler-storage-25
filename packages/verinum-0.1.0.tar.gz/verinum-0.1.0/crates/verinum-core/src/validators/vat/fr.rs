/// France — 2 digits/letters + 9 digits (11 chars total).
/// If the first 2 chars are digits, validate: full 11-digit number mod 97 remainder.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 11 {
        return false;
    }
    // First 2 chars must be alphanumeric
    if !number[0].is_ascii_alphanumeric() || !number[1].is_ascii_alphanumeric() {
        return false;
    }
    // Remaining 9 chars must be digits
    if !util::all_ascii_digits(&number[2..]) {
        return false;
    }

    // If the first 2 characters are both digits, perform modulo 97 check
    if number[0].is_ascii_digit() && number[1].is_ascii_digit() {
        let full: u64 = number
            .iter()
            .fold(0u64, |acc, &b| acc * 10 + (b - b'0') as u64);
        return full.is_multiple_of(97);
    }

    true
}
