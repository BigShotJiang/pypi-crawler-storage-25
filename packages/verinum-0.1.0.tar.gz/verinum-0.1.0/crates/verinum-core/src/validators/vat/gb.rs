/// United Kingdom — 9 or 12 digits, or "GD" + 3 digits, or "HA" + 3 digits.
/// For 9-digit numbers: modulo 97 or modulo 9755 check.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    let len = number.len();

    // Government departments: "GD" + 3 digits (number 000-499)
    if len == 5 && number[0] == b'G' && number[1] == b'D' {
        return util::all_ascii_digits(&number[2..]);
    }

    // Health authorities: "HA" + 3 digits (number 500-999)
    if len == 5 && number[0] == b'H' && number[1] == b'A' {
        return util::all_ascii_digits(&number[2..]);
    }

    // Standard: 9 or 12 digits
    if len != 9 && len != 12 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    if len == 9 {
        // Modulo 97 check or modulo 9755 check
        let n: u64 = number
            .iter()
            .fold(0u64, |acc, &b| acc * 10 + (b - b'0') as u64);
        // The number must be non-zero
        if n == 0 {
            return false;
        }
        // Check: either n % 97 == 0 or n % 9755 == 0
        return n.is_multiple_of(97) || n.is_multiple_of(9755);
    }

    // 12 digits: first 9 pass the same check, last 3 are branch code
    if len == 12 {
        let first9: u64 = number[..9]
            .iter()
            .fold(0u64, |acc, &b| acc * 10 + (b - b'0') as u64);
        if first9 == 0 {
            return false;
        }
        return first9.is_multiple_of(97) || first9.is_multiple_of(9755);
    }

    false
}
