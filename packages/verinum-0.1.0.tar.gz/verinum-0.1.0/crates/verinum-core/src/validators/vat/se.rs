/// Sweden — 12 digits. Last 2 digits must be "01".
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 12 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }
    // Last 2 digits must be "01"
    number[10] == b'0' && number[11] == b'1'
}
