/// Netherlands — 9 digits + "B" + 2 digits (12 chars total).
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 12 {
        return false;
    }
    // First 9 chars: digits
    if !util::all_ascii_digits(&number[..9]) {
        return false;
    }
    // 10th char: 'B'
    if number[9] != b'B' {
        return false;
    }
    // Last 2 chars: digits
    util::all_ascii_digits(&number[10..])
}
