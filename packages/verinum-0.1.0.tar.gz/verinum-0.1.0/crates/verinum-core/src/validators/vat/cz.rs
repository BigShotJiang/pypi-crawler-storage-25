/// Czech Republic — 8, 9, or 10 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    let len = number.len();
    if len != 8 && len != 9 && len != 10 {
        return false;
    }
    util::all_ascii_digits(number)
}
