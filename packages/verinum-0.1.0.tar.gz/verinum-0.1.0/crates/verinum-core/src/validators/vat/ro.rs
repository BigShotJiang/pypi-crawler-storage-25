/// Romania — 2 to 10 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    let len = number.len();
    if !(2..=10).contains(&len) {
        return false;
    }
    util::all_ascii_digits(number)
}
