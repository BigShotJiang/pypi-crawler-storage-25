/// Cyprus — 8 digits + 1 letter (9 chars total). First 2 digits cannot be "12".
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 9 {
        return false;
    }
    // First 8 characters must be digits
    if !util::all_ascii_digits(&number[..8]) {
        return false;
    }
    // Last character must be a letter
    if !number[8].is_ascii_uppercase() {
        return false;
    }
    // First 2 digits cannot be "12"
    if number[0] == b'1' && number[1] == b'2' {
        return false;
    }
    true
}
