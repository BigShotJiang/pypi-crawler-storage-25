/// Luxembourg — 8 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    number.len() == 8 && util::all_ascii_digits(number)
}
