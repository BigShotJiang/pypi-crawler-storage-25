/// Spain — 9 chars: first/last are letter or digit, middle 7 are digits.
/// Covers DNI, NIE, and CIF formats with a simplified format check.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 9 {
        return false;
    }
    // First char: letter or digit
    if !number[0].is_ascii_alphanumeric() {
        return false;
    }
    // Middle 7: digits
    if !util::all_ascii_digits(&number[1..8]) {
        return false;
    }
    // Last char: letter or digit
    number[8].is_ascii_alphanumeric()
}
