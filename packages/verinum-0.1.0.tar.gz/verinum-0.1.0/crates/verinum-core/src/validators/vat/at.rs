/// Austria — ATU + 8 digits. The number passed here excludes the "AT" prefix.
/// Must start with 'U' followed by 8 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 9 {
        return false;
    }
    if number[0] != b'U' {
        return false;
    }
    util::all_ascii_digits(&number[1..])
}
