/// Portugal — 9 digits. Weighted checksum: weights [9,8,7,6,5,4,3,2], mod 11.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 9 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    const WEIGHTS: [u32; 8] = [9, 8, 7, 6, 5, 4, 3, 2];
    let sum: u32 = number[..8]
        .iter()
        .zip(WEIGHTS.iter())
        .map(|(&b, &w)| (b - b'0') as u32 * w)
        .sum();
    let remainder = sum % 11;
    let check = if remainder < 2 { 0 } else { 11 - remainder };
    (number[8] - b'0') as u32 == check
}
