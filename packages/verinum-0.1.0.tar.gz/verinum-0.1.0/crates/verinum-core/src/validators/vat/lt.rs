/// Lithuania — 9 or 12 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    let len = number.len();
    (len == 9 || len == 12) && util::all_ascii_digits(number)
}
