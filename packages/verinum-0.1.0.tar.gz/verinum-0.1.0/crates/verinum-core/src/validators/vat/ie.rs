//! Ireland — 8 or 9 chars.
//! Old format: 1 digit + 1 letter + 5 digits + 1 letter (8 chars)
//! New format: 7 digits + 1-2 letters (8 or 9 chars)

pub fn is_valid(number: &[u8]) -> bool {
    let len = number.len();
    if len != 8 && len != 9 {
        return false;
    }

    // Try new format: 7 digits + 1-2 letters
    if number[..7].iter().all(|b| b.is_ascii_digit()) {
        if !number[7].is_ascii_uppercase() {
            return false;
        }
        if len == 9 && !number[8].is_ascii_uppercase() {
            return false;
        }
        return true;
    }

    // Try old format (8 chars only): 1 digit + 1 letter + 5 digits + 1 letter
    if len == 8
        && number[0].is_ascii_digit()
        && number[1].is_ascii_uppercase()
        && number[2..7].iter().all(|b| b.is_ascii_digit())
        && number[7].is_ascii_uppercase()
    {
        return true;
    }

    false
}
