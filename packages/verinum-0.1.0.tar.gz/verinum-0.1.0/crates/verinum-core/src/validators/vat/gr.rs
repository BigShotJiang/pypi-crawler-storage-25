/// Greece — 9 digits. Weighted checksum with powers of 2, mod 11.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 9 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    // Weights are powers of 2: 256, 128, 64, 32, 16, 8, 4, 2
    let sum: u32 = number[..8]
        .iter()
        .enumerate()
        .map(|(i, &b)| (b - b'0') as u32 * (1 << (8 - i)))
        .sum();
    let check = (sum % 11) % 10;
    (number[8] - b'0') as u32 == check
}
