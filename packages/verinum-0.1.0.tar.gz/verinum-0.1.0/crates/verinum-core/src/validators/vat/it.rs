/// Italy — 11 digits. Luhn-like checksum.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 11 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    let mut sum: u32 = 0;
    for (i, &b) in number.iter().enumerate() {
        let d = (b - b'0') as u32;
        if i % 2 == 0 {
            sum += d;
        } else {
            let doubled = d * 2;
            sum += if doubled > 9 { doubled - 9 } else { doubled };
        }
    }
    sum.is_multiple_of(10)
}
