/// Slovenia — 8 digits. Must not start with "0".
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 8 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }
    // Must not start with '0'
    number[0] != b'0'
}
