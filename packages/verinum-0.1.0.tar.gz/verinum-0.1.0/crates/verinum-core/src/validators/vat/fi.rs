/// Finland — 8 digits. Weighted checksum: weights [7,9,10,5,8,4,2], mod 11.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 8 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    const WEIGHTS: [u32; 7] = [7, 9, 10, 5, 8, 4, 2];
    let sum: u32 = number[..7]
        .iter()
        .zip(WEIGHTS.iter())
        .map(|(&b, &w)| (b - b'0') as u32 * w)
        .sum();
    let remainder = sum % 11;
    let check = if remainder == 0 {
        0
    } else if remainder == 1 {
        // Invalid — no single digit can represent 11 - 1 = 10
        return false;
    } else {
        11 - remainder
    };
    (number[7] - b'0') as u32 == check
}
