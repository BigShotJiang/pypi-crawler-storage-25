/// Estonia — 9 digits.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    number.len() == 9 && util::all_ascii_digits(number)
}
