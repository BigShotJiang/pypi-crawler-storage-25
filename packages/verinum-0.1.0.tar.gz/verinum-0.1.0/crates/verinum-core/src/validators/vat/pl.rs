/// Poland — 10 digits. Weighted checksum: weights [6,5,7,2,3,4,5,6,7], mod 11.
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 10 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }

    const WEIGHTS: [u32; 9] = [6, 5, 7, 2, 3, 4, 5, 6, 7];
    let sum: u32 = number[..9]
        .iter()
        .zip(WEIGHTS.iter())
        .map(|(&b, &w)| (b - b'0') as u32 * w)
        .sum();
    let check = sum % 11;
    // If remainder is 10, the number is invalid
    if check == 10 {
        return false;
    }
    (number[9] - b'0') as u32 == check
}
