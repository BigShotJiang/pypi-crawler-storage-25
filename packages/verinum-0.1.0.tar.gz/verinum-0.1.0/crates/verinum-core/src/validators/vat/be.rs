/// Belgium — 10 digits. First digit must be 0 or 1.
/// Checksum: last 2 digits = 97 - (first 8 digits mod 97).
use crate::util;

pub fn is_valid(number: &[u8]) -> bool {
    if number.len() != 10 {
        return false;
    }
    if !util::all_ascii_digits(number) {
        return false;
    }
    // First digit must be 0 or 1
    if number[0] != b'0' && number[0] != b'1' {
        return false;
    }
    // Checksum: last 2 digits = 97 - (first 8 digits mod 97)
    let first8: u64 = number[..8]
        .iter()
        .fold(0u64, |acc, &b| acc * 10 + (b - b'0') as u64);
    let check: u64 = (number[8] - b'0') as u64 * 10 + (number[9] - b'0') as u64;
    check == 97 - (first8 % 97)
}
