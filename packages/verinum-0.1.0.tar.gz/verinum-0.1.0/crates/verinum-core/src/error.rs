#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationErrorKind {
    InvalidLength,
    InvalidCharset,
    InvalidPrefix,
    InvalidChecksum,
    InvalidStructure,
    InvalidCountry,
    UnsupportedCountry,
    UnsupportedFormat,
    UnknownFormat,
}

impl ValidationErrorKind {
    /// Returns the stable snake_case string code for FFI boundaries.
    #[inline]
    pub fn as_str(self) -> &'static str {
        match self {
            Self::InvalidLength => "invalid_length",
            Self::InvalidCharset => "invalid_charset",
            Self::InvalidPrefix => "invalid_prefix",
            Self::InvalidChecksum => "invalid_checksum",
            Self::InvalidStructure => "invalid_structure",
            Self::InvalidCountry => "invalid_country",
            Self::UnsupportedCountry => "unsupported_country",
            Self::UnsupportedFormat => "unsupported_format",
            Self::UnknownFormat => "unknown_format",
        }
    }
}

impl core::fmt::Display for ValidationErrorKind {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str(self.as_str())
    }
}
