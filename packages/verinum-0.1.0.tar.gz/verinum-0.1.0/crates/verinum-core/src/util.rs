use crate::types::CompactBuf;

/// Check if all bytes are ASCII digits.
#[inline]
pub fn all_ascii_digits(input: &[u8]) -> bool {
    input.iter().all(|&b| b.wrapping_sub(b'0') < 10)
}

/// Check if all bytes are ASCII uppercase letters.
#[inline]
pub fn all_ascii_upper(input: &[u8]) -> bool {
    input.iter().all(|&b| b.is_ascii_uppercase())
}

/// Check if all bytes are ASCII alphanumeric.
#[inline]
pub fn all_ascii_alphanumeric(input: &[u8]) -> bool {
    input.iter().all(|&b| b.is_ascii_alphanumeric())
}

/// Strip formatting characters (spaces, hyphens, dots, tabs) into a stack buffer.
#[inline]
pub fn strip_formatting(input: &[u8], buf: &mut CompactBuf) -> bool {
    for &b in input {
        match b {
            b' ' | b'-' | b'.' | b'\t' => continue,
            _ => {
                if !buf.push(b) {
                    return false;
                }
            }
        }
    }
    true
}

/// Strip formatting and convert to uppercase.
#[inline]
pub fn strip_and_upper(input: &[u8], buf: &mut CompactBuf) -> bool {
    for &b in input {
        match b {
            b' ' | b'-' | b'.' | b'\t' => continue,
            b'a'..=b'z' => {
                if !buf.push(b - 32) {
                    return false;
                }
            }
            _ => {
                if !buf.push(b) {
                    return false;
                }
            }
        }
    }
    true
}

/// Convert a single ASCII hex digit to its value.
#[inline]
pub fn ascii_digit(b: u8) -> Option<u8> {
    if b.wrapping_sub(b'0') < 10 {
        Some(b - b'0')
    } else {
        None
    }
}
