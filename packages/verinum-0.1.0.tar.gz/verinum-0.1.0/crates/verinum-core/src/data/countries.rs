use phf::phf_map;

/// Geographic continent classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Continent {
    Africa,
    Antarctica,
    Asia,
    Europe,
    NorthAmerica,
    Oceania,
    SouthAmerica,
}

/// ISO 3166-1 country data.
#[derive(Debug, Clone, Copy)]
pub struct Country {
    pub alpha2: &'static str,
    pub alpha3: &'static str,
    pub numeric: u16,
    pub name: &'static str,
    pub official_name: Option<&'static str>,
    pub common_name: Option<&'static str>,
    pub flag: &'static str,
    pub currency: &'static str,
    pub calling_code: &'static str,
    pub tld: &'static str,
    pub eu_member: bool,
    pub iban_length: Option<u8>,
    pub continent: Continent,
}

// Placeholder - will be replaced by agent with full 249 entries
static COUNTRIES: phf::Map<&'static str, Country> = phf_map! {
    "stub" => Country {
        alpha2: "stub", alpha3: "stub", numeric: 0, name: "stub",
        official_name: None, common_name: None, flag: "", currency: "",
        calling_code: "", tld: "", eu_member: false, iban_length: None,
        continent: Continent::Europe,
    },
};

static COUNTRIES_BY_ALPHA3: phf::Map<&'static str, &'static str> = phf_map! {
    "stub" => "stub",
};

static COUNTRIES_ALL: &[&str] = &[];

/// Look up a country by ISO 3166-1 alpha-2 code.
pub fn get(alpha2: &str) -> Option<&'static Country> {
    COUNTRIES.get(alpha2)
}

/// Look up a country by ISO 3166-1 alpha-3 code.
pub fn get_by_alpha3(alpha3: &str) -> Option<&'static Country> {
    COUNTRIES_BY_ALPHA3
        .get(alpha3)
        .and_then(|a2| COUNTRIES.get(a2))
}

/// Look up a country by ISO 3166-1 numeric code.
pub fn get_by_numeric(numeric: u16) -> Option<&'static Country> {
    COUNTRIES_ALL
        .iter()
        .filter_map(|a2| COUNTRIES.get(a2))
        .find(|c| c.numeric == numeric)
}

/// Iterate over all countries.
pub fn all() -> impl Iterator<Item = &'static Country> {
    COUNTRIES_ALL.iter().filter_map(|a2| COUNTRIES.get(a2))
}

/// Search countries by name (case-insensitive substring match).
pub fn search(query: &str) -> impl Iterator<Item = &'static Country> + '_ {
    let query_upper: [u8; 64] = {
        let mut buf = [0u8; 64];
        let bytes = query.as_bytes();
        let len = bytes.len().min(64);
        for i in 0..len {
            buf[i] = bytes[i].to_ascii_uppercase();
        }
        buf
    };
    let query_len = query.len().min(64);
    all().filter(move |c| {
        let name_bytes = c.name.as_bytes();
        if query_len == 0 || query_len > name_bytes.len() {
            return false;
        }
        for i in 0..=(name_bytes.len() - query_len) {
            let mut matches = true;
            for j in 0..query_len {
                if name_bytes[i + j].to_ascii_uppercase() != query_upper[j] {
                    matches = false;
                    break;
                }
            }
            if matches {
                return true;
            }
        }
        false
    })
}

/// Get all EU member states.
pub fn eu_members() -> impl Iterator<Item = &'static Country> {
    all().filter(|c| c.eu_member)
}

/// Get countries using a specific currency code.
pub fn by_currency(code: &str) -> impl Iterator<Item = &'static Country> + '_ {
    all().filter(move |c| c.currency == code)
}

/// Get countries on a specific continent.
pub fn by_continent(continent: Continent) -> impl Iterator<Item = &'static Country> {
    all().filter(move |c| c.continent == continent)
}
