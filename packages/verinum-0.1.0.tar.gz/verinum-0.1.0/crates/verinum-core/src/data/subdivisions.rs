/// ISO 3166-2 subdivision data.
#[derive(Debug, Clone, Copy)]
pub struct Subdivision {
    pub code: &'static str,
    pub name: &'static str,
    pub country_alpha2: &'static str,
    pub subdivision_type: &'static str,
    pub parent: Option<&'static str>,
}

// Placeholder - will be replaced by agent with ~5000 entries
static SUBDIVISIONS: &[Subdivision] = &[];

/// Look up a subdivision by ISO 3166-2 code (binary search).
pub fn get(code: &str) -> Option<&'static Subdivision> {
    SUBDIVISIONS
        .binary_search_by_key(&code, |s| s.code)
        .ok()
        .map(|i| &SUBDIVISIONS[i])
}

/// Get all subdivisions for a country.
pub fn by_country(alpha2: &str) -> impl Iterator<Item = &'static Subdivision> + '_ {
    SUBDIVISIONS
        .iter()
        .filter(move |s| s.country_alpha2 == alpha2)
}

/// Search subdivisions by name (case-insensitive substring).
pub fn search<'a>(
    query: &'a str,
    country: Option<&'a str>,
) -> impl Iterator<Item = &'static Subdivision> + 'a {
    let query_upper: [u8; 64] = {
        let mut buf = [0u8; 64];
        let bytes = query.as_bytes();
        let len = bytes.len().min(64);
        for i in 0..len {
            buf[i] = bytes[i].to_ascii_uppercase();
        }
        buf
    };
    let query_len = query.len().min(64);
    SUBDIVISIONS.iter().filter(move |s| {
        if let Some(cc) = country {
            if s.country_alpha2 != cc {
                return false;
            }
        }
        let name_bytes = s.name.as_bytes();
        if query_len == 0 || query_len > name_bytes.len() {
            return false;
        }
        for i in 0..=(name_bytes.len() - query_len) {
            let mut matches = true;
            for j in 0..query_len {
                if name_bytes[i + j].to_ascii_uppercase() != query_upper[j] {
                    matches = false;
                    break;
                }
            }
            if matches {
                return true;
            }
        }
        false
    })
}
