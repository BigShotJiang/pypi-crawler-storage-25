use phf::phf_map;

/// Scope of a language code assignment.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LanguageScope {
    Individual,
    Macro,
    Special,
}

/// Type of language.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LanguageType {
    Living,
    Historical,
    Constructed,
    Extinct,
    Ancient,
}

/// Language data entry.
#[derive(Debug, Clone, Copy)]
pub struct Language {
    pub alpha2: Option<&'static str>,
    pub alpha3: &'static str,
    pub name: &'static str,
    pub native_name: Option<&'static str>,
    pub scope: LanguageScope,
    pub language_type: LanguageType,
}

// Placeholder - will be replaced by agent with ~230 entries
static LANGUAGES_BY_ALPHA2: phf::Map<&'static str, Language> = phf_map! {
    "stub" => Language {
        alpha2: Some("stub"), alpha3: "stub", name: "stub",
        native_name: None, scope: LanguageScope::Individual,
        language_type: LanguageType::Living,
    },
};

static LANGUAGES_BY_ALPHA3: phf::Map<&'static str, &'static str> = phf_map! {
    "stub" => "stub",
};

static LANGUAGES_ALPHA3_ONLY: phf::Map<&'static str, Language> = phf_map! {
    "stub" => Language {
        alpha2: None, alpha3: "stub", name: "stub",
        native_name: None, scope: LanguageScope::Individual,
        language_type: LanguageType::Living,
    },
};

static LANGUAGES_ALL: &[&str] = &[];

/// Look up a language by ISO 639-1 alpha-2 code.
pub fn get(alpha2: &str) -> Option<&'static Language> {
    LANGUAGES_BY_ALPHA2.get(alpha2)
}

/// Look up a language by ISO 639-3 alpha-3 code.
pub fn get_by_alpha3(alpha3: &str) -> Option<&'static Language> {
    if let Some(a2) = LANGUAGES_BY_ALPHA3.get(alpha3) {
        LANGUAGES_BY_ALPHA2.get(a2)
    } else {
        LANGUAGES_ALPHA3_ONLY.get(alpha3)
    }
}

/// Iterate over all languages.
pub fn all() -> impl Iterator<Item = &'static Language> {
    LANGUAGES_ALL.iter().filter_map(|key| {
        LANGUAGES_BY_ALPHA2
            .get(key)
            .or_else(|| LANGUAGES_ALPHA3_ONLY.get(key))
    })
}
