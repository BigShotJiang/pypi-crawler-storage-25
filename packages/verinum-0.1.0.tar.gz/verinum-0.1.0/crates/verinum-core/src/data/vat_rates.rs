use phf::phf_map;

/// VAT rate information for a country.
#[derive(Debug, Clone, Copy)]
pub struct VatRate {
    pub country: &'static str,
    pub standard_rate: f32,
    pub reduced_rates: &'static [f32],
}

static VAT_RATES: phf::Map<&'static str, VatRate> = phf_map! {
    "AT" => VatRate { country: "AT", standard_rate: 20.0, reduced_rates: &[10.0, 13.0] },
    "BE" => VatRate { country: "BE", standard_rate: 21.0, reduced_rates: &[6.0, 12.0] },
    "BG" => VatRate { country: "BG", standard_rate: 20.0, reduced_rates: &[9.0] },
    "HR" => VatRate { country: "HR", standard_rate: 25.0, reduced_rates: &[5.0, 13.0] },
    "CY" => VatRate { country: "CY", standard_rate: 19.0, reduced_rates: &[5.0, 9.0] },
    "CZ" => VatRate { country: "CZ", standard_rate: 21.0, reduced_rates: &[12.0] },
    "DK" => VatRate { country: "DK", standard_rate: 25.0, reduced_rates: &[] },
    "EE" => VatRate { country: "EE", standard_rate: 22.0, reduced_rates: &[9.0] },
    "FI" => VatRate { country: "FI", standard_rate: 25.5, reduced_rates: &[10.0, 14.0] },
    "FR" => VatRate { country: "FR", standard_rate: 20.0, reduced_rates: &[5.5, 10.0] },
    "DE" => VatRate { country: "DE", standard_rate: 19.0, reduced_rates: &[7.0] },
    "GR" => VatRate { country: "GR", standard_rate: 24.0, reduced_rates: &[6.0, 13.0] },
    "HU" => VatRate { country: "HU", standard_rate: 27.0, reduced_rates: &[5.0, 18.0] },
    "IE" => VatRate { country: "IE", standard_rate: 23.0, reduced_rates: &[9.0, 13.5] },
    "IT" => VatRate { country: "IT", standard_rate: 22.0, reduced_rates: &[4.0, 5.0, 10.0] },
    "LV" => VatRate { country: "LV", standard_rate: 21.0, reduced_rates: &[5.0, 12.0] },
    "LT" => VatRate { country: "LT", standard_rate: 21.0, reduced_rates: &[5.0, 9.0] },
    "LU" => VatRate { country: "LU", standard_rate: 17.0, reduced_rates: &[3.0, 8.0, 14.0] },
    "MT" => VatRate { country: "MT", standard_rate: 18.0, reduced_rates: &[5.0, 7.0] },
    "NL" => VatRate { country: "NL", standard_rate: 21.0, reduced_rates: &[9.0] },
    "PL" => VatRate { country: "PL", standard_rate: 23.0, reduced_rates: &[5.0, 8.0] },
    "PT" => VatRate { country: "PT", standard_rate: 23.0, reduced_rates: &[6.0, 13.0] },
    "RO" => VatRate { country: "RO", standard_rate: 19.0, reduced_rates: &[5.0, 9.0] },
    "SK" => VatRate { country: "SK", standard_rate: 23.0, reduced_rates: &[5.0, 10.0] },
    "SI" => VatRate { country: "SI", standard_rate: 22.0, reduced_rates: &[5.0, 9.5] },
    "ES" => VatRate { country: "ES", standard_rate: 21.0, reduced_rates: &[4.0, 10.0] },
    "SE" => VatRate { country: "SE", standard_rate: 25.0, reduced_rates: &[6.0, 12.0] },
    "GB" => VatRate { country: "GB", standard_rate: 20.0, reduced_rates: &[5.0] },
    "NO" => VatRate { country: "NO", standard_rate: 25.0, reduced_rates: &[12.0, 15.0] },
    "CH" => VatRate { country: "CH", standard_rate: 8.1, reduced_rates: &[2.6, 3.8] },
    "IS" => VatRate { country: "IS", standard_rate: 24.0, reduced_rates: &[11.0] },
};

static VAT_RATES_ALL: &[&str] = &[
    "AT", "BE", "BG", "CH", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HR", "HU",
    "IE", "IS", "IT", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK",
];

/// Look up VAT rate information by country alpha-2 code.
pub fn get(country_alpha2: &str) -> Option<&'static VatRate> {
    VAT_RATES.get(country_alpha2)
}

/// Iterate over all VAT rates.
pub fn all() -> impl Iterator<Item = &'static VatRate> {
    VAT_RATES_ALL.iter().filter_map(|code| VAT_RATES.get(code))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_de() {
        let rate = get("DE").unwrap();
        assert_eq!(rate.standard_rate, 19.0);
        assert_eq!(rate.reduced_rates, &[7.0]);
    }

    #[test]
    fn test_get_gb() {
        let rate = get("GB").unwrap();
        assert_eq!(rate.standard_rate, 20.0);
    }

    #[test]
    fn test_get_nonexistent() {
        assert!(get("XX").is_none());
        assert!(get("US").is_none());
    }

    #[test]
    fn test_all_count() {
        assert_eq!(all().count(), 31);
    }

    #[test]
    fn test_eu_all_present() {
        let eu = [
            "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE",
            "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE",
        ];
        for code in &eu {
            assert!(get(code).is_some(), "Missing EU country: {}", code);
        }
    }
}
