use phf::phf_map;

/// An ISO 4217 currency.
#[derive(Debug, Clone, Copy)]
pub struct Currency {
    pub code: &'static str,
    pub numeric: u16,
    pub name: &'static str,
    pub symbol: &'static str,
    pub decimals: u8,
    pub countries: &'static [&'static str],
}

/// All active ISO 4217 currencies keyed by alphabetic code.
pub static CURRENCIES: phf::Map<&'static str, Currency> = phf_map! {
    "AED" => Currency { code: "AED", numeric: 784, name: "UAE Dirham", symbol: "د.إ", decimals: 2, countries: &["AE"] },
    "AFN" => Currency { code: "AFN", numeric: 971, name: "Afghani", symbol: "؋", decimals: 2, countries: &["AF"] },
    "ALL" => Currency { code: "ALL", numeric: 8, name: "Lek", symbol: "L", decimals: 2, countries: &["AL"] },
    "AMD" => Currency { code: "AMD", numeric: 51, name: "Armenian Dram", symbol: "֏", decimals: 2, countries: &["AM"] },
    "ANG" => Currency { code: "ANG", numeric: 532, name: "Netherlands Antillean Guilder", symbol: "ƒ", decimals: 2, countries: &["CW", "SX"] },
    "AOA" => Currency { code: "AOA", numeric: 973, name: "Kwanza", symbol: "Kz", decimals: 2, countries: &["AO"] },
    "ARS" => Currency { code: "ARS", numeric: 32, name: "Argentine Peso", symbol: "$", decimals: 2, countries: &["AR"] },
    "AUD" => Currency { code: "AUD", numeric: 36, name: "Australian Dollar", symbol: "A$", decimals: 2, countries: &["AU", "CC", "CX", "HM", "KI", "NF", "NR", "TV"] },
    "AWG" => Currency { code: "AWG", numeric: 533, name: "Aruban Florin", symbol: "ƒ", decimals: 2, countries: &["AW"] },
    "AZN" => Currency { code: "AZN", numeric: 944, name: "Azerbaijan Manat", symbol: "₼", decimals: 2, countries: &["AZ"] },
    "BAM" => Currency { code: "BAM", numeric: 977, name: "Convertible Mark", symbol: "KM", decimals: 2, countries: &["BA"] },
    "BBD" => Currency { code: "BBD", numeric: 52, name: "Barbados Dollar", symbol: "Bds$", decimals: 2, countries: &["BB"] },
    "BDT" => Currency { code: "BDT", numeric: 50, name: "Taka", symbol: "৳", decimals: 2, countries: &["BD"] },
    "BGN" => Currency { code: "BGN", numeric: 975, name: "Bulgarian Lev", symbol: "лв", decimals: 2, countries: &["BG"] },
    "BHD" => Currency { code: "BHD", numeric: 48, name: "Bahraini Dinar", symbol: ".د.ب", decimals: 3, countries: &["BH"] },
    "BIF" => Currency { code: "BIF", numeric: 108, name: "Burundi Franc", symbol: "FBu", decimals: 0, countries: &["BI"] },
    "BMD" => Currency { code: "BMD", numeric: 60, name: "Bermudian Dollar", symbol: "$", decimals: 2, countries: &["BM"] },
    "BND" => Currency { code: "BND", numeric: 96, name: "Brunei Dollar", symbol: "B$", decimals: 2, countries: &["BN"] },
    "BOB" => Currency { code: "BOB", numeric: 68, name: "Boliviano", symbol: "Bs.", decimals: 2, countries: &["BO"] },
    "BOV" => Currency { code: "BOV", numeric: 984, name: "Mvdol", symbol: "BOV", decimals: 2, countries: &["BO"] },
    "BRL" => Currency { code: "BRL", numeric: 986, name: "Brazilian Real", symbol: "R$", decimals: 2, countries: &["BR"] },
    "BSD" => Currency { code: "BSD", numeric: 44, name: "Bahamian Dollar", symbol: "$", decimals: 2, countries: &["BS"] },
    "BTN" => Currency { code: "BTN", numeric: 64, name: "Ngultrum", symbol: "Nu.", decimals: 2, countries: &["BT"] },
    "BWP" => Currency { code: "BWP", numeric: 72, name: "Pula", symbol: "P", decimals: 2, countries: &["BW"] },
    "BYN" => Currency { code: "BYN", numeric: 933, name: "Belarusian Ruble", symbol: "Br", decimals: 2, countries: &["BY"] },
    "BZD" => Currency { code: "BZD", numeric: 84, name: "Belize Dollar", symbol: "BZ$", decimals: 2, countries: &["BZ"] },
    "CAD" => Currency { code: "CAD", numeric: 124, name: "Canadian Dollar", symbol: "CA$", decimals: 2, countries: &["CA"] },
    "CDF" => Currency { code: "CDF", numeric: 976, name: "Congolese Franc", symbol: "FC", decimals: 2, countries: &["CD"] },
    "CHE" => Currency { code: "CHE", numeric: 947, name: "WIR Euro", symbol: "CHE", decimals: 2, countries: &["CH"] },
    "CHF" => Currency { code: "CHF", numeric: 756, name: "Swiss Franc", symbol: "Fr.", decimals: 2, countries: &["CH", "LI"] },
    "CHW" => Currency { code: "CHW", numeric: 948, name: "WIR Franc", symbol: "CHW", decimals: 2, countries: &["CH"] },
    "CLF" => Currency { code: "CLF", numeric: 990, name: "Unidad de Fomento", symbol: "CLF", decimals: 4, countries: &["CL"] },
    "CLP" => Currency { code: "CLP", numeric: 152, name: "Chilean Peso", symbol: "$", decimals: 0, countries: &["CL"] },
    "CNY" => Currency { code: "CNY", numeric: 156, name: "Yuan Renminbi", symbol: "¥", decimals: 2, countries: &["CN"] },
    "COP" => Currency { code: "COP", numeric: 170, name: "Colombian Peso", symbol: "$", decimals: 2, countries: &["CO"] },
    "COU" => Currency { code: "COU", numeric: 970, name: "Unidad de Valor Real", symbol: "COU", decimals: 2, countries: &["CO"] },
    "CRC" => Currency { code: "CRC", numeric: 188, name: "Costa Rican Colon", symbol: "₡", decimals: 2, countries: &["CR"] },
    "CUC" => Currency { code: "CUC", numeric: 931, name: "Peso Convertible", symbol: "$", decimals: 2, countries: &["CU"] },
    "CUP" => Currency { code: "CUP", numeric: 192, name: "Cuban Peso", symbol: "₱", decimals: 2, countries: &["CU"] },
    "CVE" => Currency { code: "CVE", numeric: 132, name: "Cabo Verde Escudo", symbol: "$", decimals: 2, countries: &["CV"] },
    "CZK" => Currency { code: "CZK", numeric: 203, name: "Czech Koruna", symbol: "Kč", decimals: 2, countries: &["CZ"] },
    "DJF" => Currency { code: "DJF", numeric: 262, name: "Djibouti Franc", symbol: "Fdj", decimals: 0, countries: &["DJ"] },
    "DKK" => Currency { code: "DKK", numeric: 208, name: "Danish Krone", symbol: "kr", decimals: 2, countries: &["DK", "FO", "GL"] },
    "DOP" => Currency { code: "DOP", numeric: 214, name: "Dominican Peso", symbol: "RD$", decimals: 2, countries: &["DO"] },
    "DZD" => Currency { code: "DZD", numeric: 12, name: "Algerian Dinar", symbol: "د.ج", decimals: 2, countries: &["DZ"] },
    "EGP" => Currency { code: "EGP", numeric: 818, name: "Egyptian Pound", symbol: "E£", decimals: 2, countries: &["EG"] },
    "ERN" => Currency { code: "ERN", numeric: 232, name: "Nakfa", symbol: "Nfk", decimals: 2, countries: &["ER"] },
    "ETB" => Currency { code: "ETB", numeric: 230, name: "Ethiopian Birr", symbol: "Br", decimals: 2, countries: &["ET"] },
    "EUR" => Currency { code: "EUR", numeric: 978, name: "Euro", symbol: "€", decimals: 2, countries: &["AT", "BE", "CY", "DE", "EE", "ES", "FI", "FR", "GR", "HR", "IE", "IT", "LT", "LU", "LV", "MT", "NL", "PT", "SI", "SK"] },
    "FJD" => Currency { code: "FJD", numeric: 242, name: "Fiji Dollar", symbol: "FJ$", decimals: 2, countries: &["FJ"] },
    "FKP" => Currency { code: "FKP", numeric: 238, name: "Falkland Islands Pound", symbol: "£", decimals: 2, countries: &["FK"] },
    "GBP" => Currency { code: "GBP", numeric: 826, name: "Pound Sterling", symbol: "£", decimals: 2, countries: &["GB", "GG", "IM", "JE"] },
    "GEL" => Currency { code: "GEL", numeric: 981, name: "Lari", symbol: "₾", decimals: 2, countries: &["GE"] },
    "GHS" => Currency { code: "GHS", numeric: 936, name: "Ghana Cedi", symbol: "GH₵", decimals: 2, countries: &["GH"] },
    "GIP" => Currency { code: "GIP", numeric: 292, name: "Gibraltar Pound", symbol: "£", decimals: 2, countries: &["GI"] },
    "GMD" => Currency { code: "GMD", numeric: 270, name: "Dalasi", symbol: "D", decimals: 2, countries: &["GM"] },
    "GNF" => Currency { code: "GNF", numeric: 324, name: "Guinean Franc", symbol: "FG", decimals: 0, countries: &["GN"] },
    "GTQ" => Currency { code: "GTQ", numeric: 320, name: "Quetzal", symbol: "Q", decimals: 2, countries: &["GT"] },
    "GYD" => Currency { code: "GYD", numeric: 328, name: "Guyana Dollar", symbol: "G$", decimals: 2, countries: &["GY"] },
    "HKD" => Currency { code: "HKD", numeric: 344, name: "Hong Kong Dollar", symbol: "HK$", decimals: 2, countries: &["HK"] },
    "HNL" => Currency { code: "HNL", numeric: 340, name: "Lempira", symbol: "L", decimals: 2, countries: &["HN"] },
    "HTG" => Currency { code: "HTG", numeric: 332, name: "Gourde", symbol: "G", decimals: 2, countries: &["HT"] },
    "HUF" => Currency { code: "HUF", numeric: 348, name: "Forint", symbol: "Ft", decimals: 2, countries: &["HU"] },
    "IDR" => Currency { code: "IDR", numeric: 360, name: "Rupiah", symbol: "Rp", decimals: 2, countries: &["ID"] },
    "ILS" => Currency { code: "ILS", numeric: 376, name: "New Israeli Sheqel", symbol: "₪", decimals: 2, countries: &["IL", "PS"] },
    "INR" => Currency { code: "INR", numeric: 356, name: "Indian Rupee", symbol: "₹", decimals: 2, countries: &["IN", "BT"] },
    "IQD" => Currency { code: "IQD", numeric: 368, name: "Iraqi Dinar", symbol: "ع.د", decimals: 3, countries: &["IQ"] },
    "IRR" => Currency { code: "IRR", numeric: 364, name: "Iranian Rial", symbol: "﷼", decimals: 2, countries: &["IR"] },
    "ISK" => Currency { code: "ISK", numeric: 352, name: "Iceland Krona", symbol: "kr", decimals: 0, countries: &["IS"] },
    "JMD" => Currency { code: "JMD", numeric: 388, name: "Jamaican Dollar", symbol: "J$", decimals: 2, countries: &["JM"] },
    "JOD" => Currency { code: "JOD", numeric: 400, name: "Jordanian Dinar", symbol: "د.ا", decimals: 3, countries: &["JO"] },
    "JPY" => Currency { code: "JPY", numeric: 392, name: "Yen", symbol: "¥", decimals: 0, countries: &["JP"] },
    "KES" => Currency { code: "KES", numeric: 404, name: "Kenyan Shilling", symbol: "KSh", decimals: 2, countries: &["KE"] },
    "KGS" => Currency { code: "KGS", numeric: 417, name: "Som", symbol: "лв", decimals: 2, countries: &["KG"] },
    "KHR" => Currency { code: "KHR", numeric: 116, name: "Riel", symbol: "៛", decimals: 2, countries: &["KH"] },
    "KMF" => Currency { code: "KMF", numeric: 174, name: "Comorian Franc", symbol: "CF", decimals: 0, countries: &["KM"] },
    "KPW" => Currency { code: "KPW", numeric: 408, name: "North Korean Won", symbol: "₩", decimals: 2, countries: &["KP"] },
    "KRW" => Currency { code: "KRW", numeric: 410, name: "Won", symbol: "₩", decimals: 0, countries: &["KR"] },
    "KWD" => Currency { code: "KWD", numeric: 414, name: "Kuwaiti Dinar", symbol: "د.ك", decimals: 3, countries: &["KW"] },
    "KYD" => Currency { code: "KYD", numeric: 136, name: "Cayman Islands Dollar", symbol: "CI$", decimals: 2, countries: &["KY"] },
    "KZT" => Currency { code: "KZT", numeric: 398, name: "Tenge", symbol: "₸", decimals: 2, countries: &["KZ"] },
    "LAK" => Currency { code: "LAK", numeric: 418, name: "Lao Kip", symbol: "₭", decimals: 2, countries: &["LA"] },
    "LBP" => Currency { code: "LBP", numeric: 422, name: "Lebanese Pound", symbol: "ل.ل", decimals: 2, countries: &["LB"] },
    "LKR" => Currency { code: "LKR", numeric: 144, name: "Sri Lanka Rupee", symbol: "Rs", decimals: 2, countries: &["LK"] },
    "LRD" => Currency { code: "LRD", numeric: 430, name: "Liberian Dollar", symbol: "L$", decimals: 2, countries: &["LR"] },
    "LSL" => Currency { code: "LSL", numeric: 426, name: "Loti", symbol: "M", decimals: 2, countries: &["LS"] },
    "LYD" => Currency { code: "LYD", numeric: 434, name: "Libyan Dinar", symbol: "ل.د", decimals: 3, countries: &["LY"] },
    "MAD" => Currency { code: "MAD", numeric: 504, name: "Moroccan Dirham", symbol: "د.م.", decimals: 2, countries: &["MA", "EH"] },
    "MDL" => Currency { code: "MDL", numeric: 498, name: "Moldovan Leu", symbol: "L", decimals: 2, countries: &["MD"] },
    "MGA" => Currency { code: "MGA", numeric: 969, name: "Malagasy Ariary", symbol: "Ar", decimals: 2, countries: &["MG"] },
    "MKD" => Currency { code: "MKD", numeric: 807, name: "Denar", symbol: "ден", decimals: 2, countries: &["MK"] },
    "MMK" => Currency { code: "MMK", numeric: 104, name: "Kyat", symbol: "K", decimals: 2, countries: &["MM"] },
    "MNT" => Currency { code: "MNT", numeric: 496, name: "Tugrik", symbol: "₮", decimals: 2, countries: &["MN"] },
    "MOP" => Currency { code: "MOP", numeric: 446, name: "Pataca", symbol: "MOP$", decimals: 2, countries: &["MO"] },
    "MRU" => Currency { code: "MRU", numeric: 929, name: "Ouguiya", symbol: "UM", decimals: 2, countries: &["MR"] },
    "MUR" => Currency { code: "MUR", numeric: 480, name: "Mauritius Rupee", symbol: "₨", decimals: 2, countries: &["MU"] },
    "MVR" => Currency { code: "MVR", numeric: 462, name: "Rufiyaa", symbol: "Rf", decimals: 2, countries: &["MV"] },
    "MWK" => Currency { code: "MWK", numeric: 454, name: "Malawi Kwacha", symbol: "MK", decimals: 2, countries: &["MW"] },
    "MXN" => Currency { code: "MXN", numeric: 484, name: "Mexican Peso", symbol: "MX$", decimals: 2, countries: &["MX"] },
    "MXV" => Currency { code: "MXV", numeric: 979, name: "Mexican Unidad de Inversion (UDI)", symbol: "MXV", decimals: 2, countries: &["MX"] },
    "MYR" => Currency { code: "MYR", numeric: 458, name: "Malaysian Ringgit", symbol: "RM", decimals: 2, countries: &["MY"] },
    "MZN" => Currency { code: "MZN", numeric: 943, name: "Mozambique Metical", symbol: "MT", decimals: 2, countries: &["MZ"] },
    "NAD" => Currency { code: "NAD", numeric: 516, name: "Namibia Dollar", symbol: "N$", decimals: 2, countries: &["NA"] },
    "NGN" => Currency { code: "NGN", numeric: 566, name: "Naira", symbol: "₦", decimals: 2, countries: &["NG"] },
    "NIO" => Currency { code: "NIO", numeric: 558, name: "Cordoba Oro", symbol: "C$", decimals: 2, countries: &["NI"] },
    "NOK" => Currency { code: "NOK", numeric: 578, name: "Norwegian Krone", symbol: "kr", decimals: 2, countries: &["NO", "BV", "SJ"] },
    "NPR" => Currency { code: "NPR", numeric: 524, name: "Nepalese Rupee", symbol: "₨", decimals: 2, countries: &["NP"] },
    "NZD" => Currency { code: "NZD", numeric: 554, name: "New Zealand Dollar", symbol: "NZ$", decimals: 2, countries: &["NZ", "CK", "NU", "PN", "TK"] },
    "OMR" => Currency { code: "OMR", numeric: 512, name: "Rial Omani", symbol: "ر.ع.", decimals: 3, countries: &["OM"] },
    "PAB" => Currency { code: "PAB", numeric: 590, name: "Balboa", symbol: "B/.", decimals: 2, countries: &["PA"] },
    "PEN" => Currency { code: "PEN", numeric: 604, name: "Sol", symbol: "S/.", decimals: 2, countries: &["PE"] },
    "PGK" => Currency { code: "PGK", numeric: 598, name: "Kina", symbol: "K", decimals: 2, countries: &["PG"] },
    "PHP" => Currency { code: "PHP", numeric: 608, name: "Philippine Peso", symbol: "₱", decimals: 2, countries: &["PH"] },
    "PKR" => Currency { code: "PKR", numeric: 586, name: "Pakistan Rupee", symbol: "₨", decimals: 2, countries: &["PK"] },
    "PLN" => Currency { code: "PLN", numeric: 985, name: "Zloty", symbol: "zł", decimals: 2, countries: &["PL"] },
    "PYG" => Currency { code: "PYG", numeric: 600, name: "Guarani", symbol: "₲", decimals: 0, countries: &["PY"] },
    "QAR" => Currency { code: "QAR", numeric: 634, name: "Qatari Rial", symbol: "ر.ق", decimals: 2, countries: &["QA"] },
    "RON" => Currency { code: "RON", numeric: 946, name: "Romanian Leu", symbol: "lei", decimals: 2, countries: &["RO"] },
    "RSD" => Currency { code: "RSD", numeric: 941, name: "Serbian Dinar", symbol: "din.", decimals: 2, countries: &["RS"] },
    "RUB" => Currency { code: "RUB", numeric: 643, name: "Russian Ruble", symbol: "₽", decimals: 2, countries: &["RU"] },
    "RWF" => Currency { code: "RWF", numeric: 646, name: "Rwanda Franc", symbol: "RF", decimals: 0, countries: &["RW"] },
    "SAR" => Currency { code: "SAR", numeric: 682, name: "Saudi Riyal", symbol: "ر.س", decimals: 2, countries: &["SA"] },
    "SBD" => Currency { code: "SBD", numeric: 90, name: "Solomon Islands Dollar", symbol: "SI$", decimals: 2, countries: &["SB"] },
    "SCR" => Currency { code: "SCR", numeric: 690, name: "Seychelles Rupee", symbol: "₨", decimals: 2, countries: &["SC"] },
    "SDG" => Currency { code: "SDG", numeric: 938, name: "Sudanese Pound", symbol: "ج.س.", decimals: 2, countries: &["SD"] },
    "SEK" => Currency { code: "SEK", numeric: 752, name: "Swedish Krona", symbol: "kr", decimals: 2, countries: &["SE"] },
    "SGD" => Currency { code: "SGD", numeric: 702, name: "Singapore Dollar", symbol: "S$", decimals: 2, countries: &["SG"] },
    "SHP" => Currency { code: "SHP", numeric: 654, name: "Saint Helena Pound", symbol: "£", decimals: 2, countries: &["SH"] },
    "SLE" => Currency { code: "SLE", numeric: 925, name: "Leone", symbol: "Le", decimals: 2, countries: &["SL"] },
    "SOS" => Currency { code: "SOS", numeric: 706, name: "Somali Shilling", symbol: "Sh", decimals: 2, countries: &["SO"] },
    "SRD" => Currency { code: "SRD", numeric: 968, name: "Surinam Dollar", symbol: "Sr$", decimals: 2, countries: &["SR"] },
    "SSP" => Currency { code: "SSP", numeric: 728, name: "South Sudanese Pound", symbol: "SS£", decimals: 2, countries: &["SS"] },
    "STN" => Currency { code: "STN", numeric: 930, name: "Dobra", symbol: "Db", decimals: 2, countries: &["ST"] },
    "SVC" => Currency { code: "SVC", numeric: 222, name: "El Salvador Colon", symbol: "₡", decimals: 2, countries: &["SV"] },
    "SYP" => Currency { code: "SYP", numeric: 760, name: "Syrian Pound", symbol: "£S", decimals: 2, countries: &["SY"] },
    "SZL" => Currency { code: "SZL", numeric: 748, name: "Lilangeni", symbol: "E", decimals: 2, countries: &["SZ"] },
    "THB" => Currency { code: "THB", numeric: 764, name: "Baht", symbol: "฿", decimals: 2, countries: &["TH"] },
    "TJS" => Currency { code: "TJS", numeric: 972, name: "Somoni", symbol: "SM", decimals: 2, countries: &["TJ"] },
    "TMT" => Currency { code: "TMT", numeric: 934, name: "Turkmenistan New Manat", symbol: "T", decimals: 2, countries: &["TM"] },
    "TND" => Currency { code: "TND", numeric: 788, name: "Tunisian Dinar", symbol: "د.ت", decimals: 3, countries: &["TN"] },
    "TOP" => Currency { code: "TOP", numeric: 776, name: "Pa'anga", symbol: "T$", decimals: 2, countries: &["TO"] },
    "TRY" => Currency { code: "TRY", numeric: 949, name: "Turkish Lira", symbol: "₺", decimals: 2, countries: &["TR"] },
    "TTD" => Currency { code: "TTD", numeric: 780, name: "Trinidad and Tobago Dollar", symbol: "TT$", decimals: 2, countries: &["TT"] },
    "TWD" => Currency { code: "TWD", numeric: 901, name: "New Taiwan Dollar", symbol: "NT$", decimals: 2, countries: &["TW"] },
    "TZS" => Currency { code: "TZS", numeric: 834, name: "Tanzanian Shilling", symbol: "TSh", decimals: 2, countries: &["TZ"] },
    "UAH" => Currency { code: "UAH", numeric: 980, name: "Hryvnia", symbol: "₴", decimals: 2, countries: &["UA"] },
    "UGX" => Currency { code: "UGX", numeric: 800, name: "Uganda Shilling", symbol: "USh", decimals: 0, countries: &["UG"] },
    "USD" => Currency { code: "USD", numeric: 840, name: "US Dollar", symbol: "$", decimals: 2, countries: &["US", "AS", "EC", "GU", "MH", "FM", "MP", "PW", "PR", "TL", "TC", "VG", "VI"] },
    "USN" => Currency { code: "USN", numeric: 997, name: "US Dollar (Next day)", symbol: "$", decimals: 2, countries: &["US"] },
    "UYI" => Currency { code: "UYI", numeric: 940, name: "Uruguay Peso en Unidades Indexadas (UI)", symbol: "UYI", decimals: 0, countries: &["UY"] },
    "UYU" => Currency { code: "UYU", numeric: 858, name: "Peso Uruguayo", symbol: "$U", decimals: 2, countries: &["UY"] },
    "UYW" => Currency { code: "UYW", numeric: 927, name: "Unidad Previsional", symbol: "UYW", decimals: 4, countries: &["UY"] },
    "UZS" => Currency { code: "UZS", numeric: 860, name: "Uzbekistan Sum", symbol: "сўм", decimals: 2, countries: &["UZ"] },
    "VED" => Currency { code: "VED", numeric: 926, name: "Bolivar Soberano", symbol: "VED", decimals: 2, countries: &["VE"] },
    "VES" => Currency { code: "VES", numeric: 928, name: "Bolivar Soberano", symbol: "Bs.S", decimals: 2, countries: &["VE"] },
    "VND" => Currency { code: "VND", numeric: 704, name: "Dong", symbol: "₫", decimals: 0, countries: &["VN"] },
    "VUV" => Currency { code: "VUV", numeric: 548, name: "Vatu", symbol: "VT", decimals: 0, countries: &["VU"] },
    "WST" => Currency { code: "WST", numeric: 882, name: "Tala", symbol: "WS$", decimals: 2, countries: &["WS"] },
    "XAF" => Currency { code: "XAF", numeric: 950, name: "CFA Franc BEAC", symbol: "FCFA", decimals: 0, countries: &["CM", "CF", "TD", "CG", "GQ", "GA"] },
    "XCD" => Currency { code: "XCD", numeric: 951, name: "East Caribbean Dollar", symbol: "EC$", decimals: 2, countries: &["AG", "DM", "GD", "KN", "LC", "VC", "AI", "MS"] },
    "XDR" => Currency { code: "XDR", numeric: 960, name: "SDR (Special Drawing Right)", symbol: "SDR", decimals: 0, countries: &[] },
    "XOF" => Currency { code: "XOF", numeric: 952, name: "CFA Franc BCEAO", symbol: "CFA", decimals: 0, countries: &["BJ", "BF", "CI", "GW", "ML", "NE", "SN", "TG"] },
    "XPF" => Currency { code: "XPF", numeric: 953, name: "CFP Franc", symbol: "₣", decimals: 0, countries: &["PF", "NC", "WF"] },
    "XSU" => Currency { code: "XSU", numeric: 994, name: "Sucre", symbol: "XSU", decimals: 0, countries: &[] },
    "XUA" => Currency { code: "XUA", numeric: 965, name: "ADB Unit of Account", symbol: "XUA", decimals: 0, countries: &[] },
    "YER" => Currency { code: "YER", numeric: 886, name: "Yemeni Rial", symbol: "﷼", decimals: 2, countries: &["YE"] },
    "ZAR" => Currency { code: "ZAR", numeric: 710, name: "Rand", symbol: "R", decimals: 2, countries: &["ZA", "LS", "NA", "SZ"] },
    "ZMW" => Currency { code: "ZMW", numeric: 967, name: "Zambian Kwacha", symbol: "ZK", decimals: 2, countries: &["ZM"] },
    "ZWL" => Currency { code: "ZWL", numeric: 932, name: "Zimbabwe Dollar", symbol: "Z$", decimals: 2, countries: &["ZW"] },
};

/// Sorted list of all ISO 4217 currency codes for iteration.
pub static CURRENCIES_ALL: &[&str] = &[
    "AED", "AFN", "ALL", "AMD", "ANG", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT",
    "BGN", "BHD", "BIF", "BMD", "BND", "BOB", "BOV", "BRL", "BSD", "BTN", "BWP", "BYN", "BZD",
    "CAD", "CDF", "CHE", "CHF", "CHW", "CLF", "CLP", "CNY", "COP", "COU", "CRC", "CUC", "CUP",
    "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "GBP",
    "GEL", "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HTG", "HUF", "IDR", "ILS",
    "INR", "IQD", "IRR", "ISK", "JMD", "JOD", "JPY", "KES", "KGS", "KHR", "KMF", "KPW", "KRW",
    "KWD", "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LYD", "MAD", "MDL", "MGA", "MKD",
    "MMK", "MNT", "MOP", "MRU", "MUR", "MVR", "MWK", "MXN", "MXV", "MYR", "MZN", "NAD", "NGN",
    "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR",
    "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLE", "SOS",
    "SRD", "SSP", "STN", "SVC", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRY", "TTD",
    "TWD", "TZS", "UAH", "UGX", "USD", "USN", "UYI", "UYU", "UYW", "UZS", "VED", "VES", "VND",
    "VUV", "WST", "XAF", "XCD", "XDR", "XOF", "XPF", "XSU", "XUA", "YER", "ZAR", "ZMW", "ZWL",
];

/// Look up a currency by its ISO 4217 alphabetic code.
pub fn get(code: &str) -> Option<&'static Currency> {
    CURRENCIES.get(code)
}

/// Look up a currency by its ISO 4217 numeric code.
///
/// This performs a linear scan since numeric codes are not the primary key.
pub fn get_by_numeric(numeric: u16) -> Option<&'static Currency> {
    CURRENCIES_ALL
        .iter()
        .filter_map(|code| CURRENCIES.get(code))
        .find(|c| c.numeric == numeric)
}

/// Return an iterator over all currencies in alphabetic code order.
pub fn all() -> impl Iterator<Item = &'static Currency> {
    CURRENCIES_ALL
        .iter()
        .filter_map(|code| CURRENCIES.get(code))
}

#[cfg(test)]
mod tests {
    extern crate alloc;
    use super::*;
    use alloc::vec::Vec;

    #[test]
    fn test_get_eur() {
        let eur = get("EUR").expect("EUR should exist");
        assert_eq!(eur.code, "EUR");
        assert_eq!(eur.numeric, 978);
        assert_eq!(eur.name, "Euro");
        assert_eq!(eur.symbol, "€");
        assert_eq!(eur.decimals, 2);
        assert!(eur.countries.contains(&"DE"));
        assert!(eur.countries.contains(&"FR"));
        assert!(eur.countries.contains(&"IT"));
    }

    #[test]
    fn test_get_usd() {
        let usd = get("USD").expect("USD should exist");
        assert_eq!(usd.code, "USD");
        assert_eq!(usd.numeric, 840);
        assert_eq!(usd.name, "US Dollar");
        assert_eq!(usd.symbol, "$");
        assert_eq!(usd.decimals, 2);
        assert!(usd.countries.contains(&"US"));
        assert!(usd.countries.contains(&"AS"));
        assert!(usd.countries.contains(&"EC"));
        assert!(usd.countries.contains(&"GU"));
    }

    #[test]
    fn test_get_by_numeric_978() {
        let eur = get_by_numeric(978).expect("numeric 978 should be EUR");
        assert_eq!(eur.code, "EUR");
    }

    #[test]
    fn test_get_by_numeric_840() {
        let usd = get_by_numeric(840).expect("numeric 840 should be USD");
        assert_eq!(usd.code, "USD");
    }

    #[test]
    fn test_get_nonexistent() {
        assert!(get("ZZZZZ").is_none());
        assert!(get("").is_none());
        assert!(get("abc").is_none());
    }

    #[test]
    fn test_get_by_numeric_nonexistent() {
        assert!(get_by_numeric(9999).is_none());
    }

    #[test]
    fn test_all_returns_150_plus() {
        let count = all().count();
        assert!(
            count >= 150,
            "Expected at least 150 currencies, got {}",
            count
        );
    }

    #[test]
    fn test_all_sorted() {
        let codes: Vec<&str> = all().map(|c| c.code).collect();
        let mut sorted = codes.clone();
        sorted.sort();
        assert_eq!(
            codes, sorted,
            "all() should return currencies in sorted order"
        );
    }

    #[test]
    fn test_currencies_all_matches_map() {
        for code in CURRENCIES_ALL {
            assert!(
                CURRENCIES.contains_key(code),
                "CURRENCIES_ALL contains '{}' but CURRENCIES map does not",
                code
            );
        }
    }

    #[test]
    fn test_jpy_zero_decimals() {
        let jpy = get("JPY").expect("JPY should exist");
        assert_eq!(jpy.decimals, 0);
        assert_eq!(jpy.symbol, "¥");
    }

    #[test]
    fn test_bhd_three_decimals() {
        let bhd = get("BHD").expect("BHD should exist");
        assert_eq!(bhd.decimals, 3);
    }

    #[test]
    fn test_gbp() {
        let gbp = get("GBP").expect("GBP should exist");
        assert_eq!(gbp.code, "GBP");
        assert_eq!(gbp.numeric, 826);
        assert_eq!(gbp.name, "Pound Sterling");
        assert_eq!(gbp.symbol, "£");
        assert_eq!(gbp.decimals, 2);
        assert!(gbp.countries.contains(&"GB"));
    }

    #[test]
    fn test_chf() {
        let chf = get("CHF").expect("CHF should exist");
        assert_eq!(chf.code, "CHF");
        assert_eq!(chf.numeric, 756);
        assert_eq!(chf.name, "Swiss Franc");
        assert_eq!(chf.symbol, "Fr.");
        assert_eq!(chf.decimals, 2);
        assert!(chf.countries.contains(&"CH"));
        assert!(chf.countries.contains(&"LI"));
    }

    #[test]
    fn test_cny() {
        let cny = get("CNY").expect("CNY should exist");
        assert_eq!(cny.code, "CNY");
        assert_eq!(cny.numeric, 156);
        assert_eq!(cny.name, "Yuan Renminbi");
        assert_eq!(cny.symbol, "¥");
        assert_eq!(cny.decimals, 2);
        assert!(cny.countries.contains(&"CN"));
    }
}
