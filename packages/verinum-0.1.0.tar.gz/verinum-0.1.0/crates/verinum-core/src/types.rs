use crate::error::ValidationErrorKind;

/// Stack-allocated buffer for normalized output.
/// 64 bytes covers every identifier type (IBAN max 34, credit card 19, LEI 20, etc.)
#[derive(Clone, Copy)]
pub struct CompactBuf {
    buf: [u8; 64],
    len: u8,
}

impl Default for CompactBuf {
    fn default() -> Self {
        Self::new()
    }
}

impl CompactBuf {
    #[inline]
    pub const fn new() -> Self {
        Self {
            buf: [0u8; 64],
            len: 0,
        }
    }

    #[inline]
    pub fn as_str(&self) -> &str {
        // SAFETY: We only ever push valid ASCII bytes
        unsafe { core::str::from_utf8_unchecked(&self.buf[..self.len as usize]) }
    }

    #[inline]
    pub fn as_bytes(&self) -> &[u8] {
        &self.buf[..self.len as usize]
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.len as usize
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    #[inline]
    pub fn push(&mut self, b: u8) -> bool {
        if (self.len as usize) < self.buf.len() {
            self.buf[self.len as usize] = b;
            self.len += 1;
            true
        } else {
            false
        }
    }

    #[inline]
    pub fn push_str(&mut self, s: &str) -> bool {
        for &b in s.as_bytes() {
            if !self.push(b) {
                return false;
            }
        }
        true
    }

    #[inline]
    pub fn clear(&mut self) {
        self.len = 0;
    }
}

impl core::fmt::Debug for CompactBuf {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("CompactBuf")
            .field("value", &self.as_str())
            .finish()
    }
}

impl core::fmt::Display for CompactBuf {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Credit card brand detection.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CardBrand {
    Visa,
    Mastercard,
    Amex,
    Discover,
    DinersClub,
    Jcb,
    UnionPay,
    Unknown,
}

impl CardBrand {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Visa => "visa",
            Self::Mastercard => "mastercard",
            Self::Amex => "amex",
            Self::Discover => "discover",
            Self::DinersClub => "diners_club",
            Self::Jcb => "jcb",
            Self::UnionPay => "unionpay",
            Self::Unknown => "unknown",
        }
    }
}

/// ISBN type discriminator.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IsbnType {
    Isbn10,
    Isbn13,
}

/// EAN type discriminator.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EanType {
    Ean8,
    Ean13,
}

/// Structured metadata — one variant per validator type.
/// Zero allocations, type-safe, exhaustive.
#[derive(Debug, Clone, Copy)]
pub enum Metadata {
    None,
    Iban {
        country: [u8; 2],
        bban_length: u8,
        check_digits: [u8; 2],
    },
    Bic {
        bank_code: [u8; 4],
        country: [u8; 2],
        location: [u8; 2],
        branch: Option<[u8; 3]>,
    },
    CreditCard {
        brand: CardBrand,
    },
    Isbn {
        isbn_type: IsbnType,
        isbn10: Option<CompactBuf>,
        isbn13: Option<CompactBuf>,
    },
    Issn {},
    Isin {
        country: [u8; 2],
    },
    Lei {
        lou_prefix: [u8; 4],
    },
    Ean {
        ean_type: EanType,
        country_prefix: CompactBuf,
    },
    Vat {
        country: [u8; 2],
    },
}

/// Full validation result — stack-allocated, no HashMap.
#[derive(Debug, Clone)]
pub struct ValidationResult {
    pub is_valid: bool,
    pub compact: CompactBuf,
    pub formatted: CompactBuf,
    pub error: Option<ValidationErrorKind>,
    pub metadata: Metadata,
}

impl ValidationResult {
    /// Create a successful validation result.
    #[inline]
    pub fn valid(compact: CompactBuf, formatted: CompactBuf, metadata: Metadata) -> Self {
        Self {
            is_valid: true,
            compact,
            formatted,
            error: None,
            metadata,
        }
    }

    /// Create a failed validation result.
    #[cold]
    #[inline(never)]
    pub fn invalid(error: ValidationErrorKind) -> Self {
        Self {
            is_valid: false,
            compact: CompactBuf::new(),
            formatted: CompactBuf::new(),
            error: Some(error),
            metadata: Metadata::None,
        }
    }
}
