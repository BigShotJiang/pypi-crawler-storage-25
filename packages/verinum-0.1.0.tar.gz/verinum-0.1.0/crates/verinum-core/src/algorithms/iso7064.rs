//! ISO 7064 check digit algorithms.
//!
//! Implements Mod 97-10 (used by IBAN, LEI) and Mod 11-2 (used by ISIN, ISBN-13 prefix).

/// Compute Mod 97-10 remainder from a byte sequence of ASCII digits.
/// Returns 1 for a valid sequence (including check digits).
#[inline]
pub fn mod97_10_checksum(digits: &[u8]) -> u32 {
    let mut remainder: u32 = 0;
    for &d in digits {
        remainder = (remainder * 10 + (d.wrapping_sub(b'0')) as u32) % 97;
    }
    remainder
}

/// Validate a numeric sequence using Mod 97-10.
/// The sequence (including check digits) must have remainder 1.
#[inline]
pub fn mod97_10_validate(digits: &[u8]) -> bool {
    if digits.len() < 2 {
        return false;
    }
    mod97_10_checksum(digits) == 1
}

/// Compute the two check digits for Mod 97-10.
/// Input is the sequence WITHOUT check digits; append "00" before calling.
/// Returns (digit1, digit2) as ASCII bytes.
#[inline]
pub fn mod97_10_generate(digits_with_00: &[u8]) -> (u8, u8) {
    let remainder = mod97_10_checksum(digits_with_00);
    let check = 98 - remainder;
    let d1 = (check / 10) as u8 + b'0';
    let d2 = (check % 10) as u8 + b'0';
    (d1, d2)
}

/// Compute Mod 97-10 remainder for IBAN-style alphanumeric input.
/// Letters are converted: A=10, B=11, ..., Z=35.
#[inline]
pub fn mod97_10_alpha(input: &[u8]) -> u32 {
    let mut remainder: u32 = 0;
    for &b in input {
        if b.is_ascii_digit() {
            remainder = (remainder * 10 + (b - b'0') as u32) % 97;
        } else if b.is_ascii_uppercase() {
            let val = (b - b'A' + 10) as u32;
            // Two-digit value: first digit then second
            remainder = (remainder * 10 + val / 10) % 97;
            remainder = (remainder * 10 + val % 10) % 97;
        }
    }
    remainder
}

/// Validate IBAN-style alphanumeric input using Mod 97-10.
#[inline]
pub fn mod97_10_alpha_validate(input: &[u8]) -> bool {
    if input.len() < 2 {
        return false;
    }
    mod97_10_alpha(input) == 1
}

/// Mod 11-2 checksum (ISO 7064).
/// Used for some identifier systems. Check character is 0-9 or X (for 10).
#[inline]
pub fn mod11_2_checksum(digits: &[u8]) -> u8 {
    let mut sum: u32 = 0;
    for &d in digits {
        sum = (sum + (d.wrapping_sub(b'0')) as u32) * 2 % 11;
    }
    let check = (12 - sum) % 11;
    if check == 10 {
        b'X'
    } else {
        check as u8 + b'0'
    }
}

/// Validate using Mod 11-2. The last character is the check (0-9 or X).
#[inline]
pub fn mod11_2_validate(input: &[u8]) -> bool {
    if input.len() < 2 {
        return false;
    }
    let data = &input[..input.len() - 1];
    let expected = input[input.len() - 1];
    mod11_2_checksum(data) == expected
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mod97_iban() {
        // IBAN: GB82WEST12345698765432
        // Rearrange to: WEST12345698765432GB82
        let input = b"WEST12345698765432GB82";
        assert!(mod97_10_alpha_validate(input));
    }

    #[test]
    fn test_mod97_numeric() {
        // 98 - (remainder of ...00 mod 97) = check digits
        // 123400 % 97 = 16, check = 98 - 16 = 82
        let (d1, d2) = mod97_10_generate(b"123400");
        assert_eq!(d1, b'8');
        assert_eq!(d2, b'2');
        assert!(mod97_10_validate(b"123482"));
    }

    #[test]
    fn test_mod97_invalid() {
        assert!(!mod97_10_validate(b"123465"));
        assert!(!mod97_10_validate(b"1"));
    }
}
