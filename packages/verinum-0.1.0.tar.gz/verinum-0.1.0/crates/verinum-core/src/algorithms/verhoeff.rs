//! Verhoeff check digit algorithm.
//!
//! Uses three static tables: multiplication (d), permutation (p), and inverse (inv).

/// Dihedral group D5 multiplication table.
static D: [[u8; 10]; 10] = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
];

/// Permutation table.
static P: [[u8; 10]; 8] = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
];

/// Inverse table.
static INV: [u8; 10] = [0, 4, 3, 2, 1, 5, 6, 7, 8, 9];

/// Compute the Verhoeff checksum.
#[inline]
pub fn checksum(digits: &[u8]) -> u8 {
    let mut c: u8 = 0;
    for (i, &d) in digits.iter().rev().enumerate() {
        let digit = d.wrapping_sub(b'0');
        c = D[c as usize][P[(i + 1) % 8][digit as usize] as usize];
    }
    INV[c as usize]
}

/// Validate a digit sequence (including check digit) using Verhoeff.
#[inline]
pub fn validate(digits: &[u8]) -> bool {
    if digits.is_empty() {
        return false;
    }
    let mut c: u8 = 0;
    for (i, &d) in digits.iter().rev().enumerate() {
        let digit = d.wrapping_sub(b'0');
        c = D[c as usize][P[i % 8][digit as usize] as usize];
    }
    c == 0
}

/// Generate the Verhoeff check digit for a sequence (without check digit).
#[inline]
pub fn generate(digits: &[u8]) -> u8 {
    checksum(digits)
}

/// Validate a string representation.
pub fn validate_str(input: &str) -> bool {
    let bytes: &[u8] = input.as_bytes();
    if bytes.is_empty() || !bytes.iter().all(|&b| b.is_ascii_digit()) {
        return false;
    }
    validate(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_and_validate() {
        // Known test: 236 -> check digit 3 -> 2363
        let check = generate(b"236");
        assert_eq!(check, 3);
        assert!(validate(b"2363"));
    }

    #[test]
    fn test_validate_invalid() {
        assert!(!validate(b"2364"));
        assert!(!validate(b""));
    }

    #[test]
    fn test_known_values() {
        // Aadhaar-style: 123456789 -> check digit
        let check = generate(b"12345678");
        let mut full = *b"123456780";
        full[8] = check + b'0';
        assert!(validate(&full));
    }
}
