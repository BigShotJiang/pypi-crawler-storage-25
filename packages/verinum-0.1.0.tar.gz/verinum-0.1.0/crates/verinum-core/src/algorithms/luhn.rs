//! Luhn algorithm (ISO/IEC 7812-1).
//!
//! Operates on ASCII digit bytes (b'0'..=b'9').

/// Compute the Luhn checksum of a digit sequence.
/// Returns a value 0-9; the input is valid if the result is 0.
#[inline]
pub fn checksum(digits: &[u8]) -> u8 {
    let mut sum: u16 = 0;
    let mut double = false;
    for &d in digits.iter().rev() {
        let mut n = (d.wrapping_sub(b'0')) as u16;
        if double {
            n *= 2;
            if n > 9 {
                n -= 9;
            }
        }
        sum += n;
        double = !double;
    }
    (sum % 10) as u8
}

/// Validate a digit sequence using the Luhn algorithm.
#[inline]
pub fn validate(digits: &[u8]) -> bool {
    if digits.is_empty() {
        return false;
    }
    checksum(digits) == 0
}

/// Generate the Luhn check digit for a digit sequence (without the check digit).
/// Returns the check digit (0-9) that should be appended.
#[inline]
pub fn generate(digits: &[u8]) -> u8 {
    let mut sum: u16 = 0;
    let mut double = true; // first from right is doubled since it will be the check digit position
    for &d in digits.iter().rev() {
        let mut n = (d.wrapping_sub(b'0')) as u16;
        if double {
            n *= 2;
            if n > 9 {
                n -= 9;
            }
        }
        sum += n;
        double = !double;
    }
    ((10 - (sum % 10)) % 10) as u8
}

/// Validate a string of digits using the Luhn algorithm.
/// Strips spaces and hyphens.
pub fn validate_str(input: &str) -> bool {
    let mut buf = [0u8; 64];
    let mut len = 0usize;
    for &b in input.as_bytes() {
        match b {
            b' ' | b'-' => continue,
            b'0'..=b'9' => {
                if len >= buf.len() {
                    return false;
                }
                buf[len] = b;
                len += 1;
            }
            _ => return false,
        }
    }
    if len == 0 {
        return false;
    }
    validate(&buf[..len])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_validate_known_valid() {
        assert!(validate(b"49927398716"));
        assert!(validate(b"79927398713"));
        assert!(validate(b"4111111111111111")); // Visa test
        assert!(validate(b"0"));
    }

    #[test]
    fn test_validate_known_invalid() {
        assert!(!validate(b"49927398717"));
        assert!(!validate(b"1234567812345678"));
        assert!(!validate(b""));
    }

    #[test]
    fn test_generate() {
        assert_eq!(generate(b"7992739871"), 3);
        assert_eq!(generate(b"4992739871"), 6);
        assert_eq!(generate(b"411111111111111"), 1); // Visa
    }

    #[test]
    fn test_validate_str() {
        assert!(validate_str("4111 1111 1111 1111"));
        assert!(validate_str("4111-1111-1111-1111"));
        assert!(!validate_str("4111 1111 1111 1112"));
        assert!(!validate_str(""));
        assert!(!validate_str("abc"));
    }
}
