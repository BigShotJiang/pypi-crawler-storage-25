//! Damm check digit algorithm.
//!
//! Uses a 10x10 quasigroup (anti-symmetric) operation table.

/// Quasigroup operation table for Damm algorithm.
static TABLE: [[u8; 10]; 10] = [
    [0, 3, 1, 7, 5, 9, 8, 6, 4, 2],
    [7, 0, 9, 2, 1, 5, 4, 8, 6, 3],
    [4, 2, 0, 6, 8, 7, 1, 3, 5, 9],
    [1, 7, 5, 0, 9, 8, 3, 4, 2, 6],
    [6, 1, 2, 3, 0, 4, 5, 9, 7, 8],
    [3, 6, 7, 4, 2, 0, 9, 5, 8, 1],
    [5, 8, 6, 9, 7, 2, 0, 1, 3, 4],
    [8, 9, 4, 5, 3, 6, 2, 0, 1, 7],
    [9, 4, 3, 8, 6, 1, 7, 2, 0, 5],
    [2, 5, 8, 1, 4, 3, 6, 7, 9, 0],
];

/// Compute the Damm checksum (interim digit).
#[inline]
pub fn checksum(digits: &[u8]) -> u8 {
    let mut interim: u8 = 0;
    for &d in digits {
        let digit = d.wrapping_sub(b'0');
        interim = TABLE[interim as usize][digit as usize];
    }
    interim
}

/// Validate a digit sequence (including check digit) using Damm.
/// Valid if the final interim digit is 0.
#[inline]
pub fn validate(digits: &[u8]) -> bool {
    if digits.is_empty() {
        return false;
    }
    checksum(digits) == 0
}

/// Generate the Damm check digit for a sequence (without check digit).
#[inline]
pub fn generate(digits: &[u8]) -> u8 {
    checksum(digits)
}

/// Validate a string representation.
pub fn validate_str(input: &str) -> bool {
    let bytes: &[u8] = input.as_bytes();
    if bytes.is_empty() || !bytes.iter().all(|&b| b.is_ascii_digit()) {
        return false;
    }
    validate(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_and_validate() {
        // Known: 572 -> check digit 4
        let check = generate(b"572");
        assert_eq!(check, 4);
        assert!(validate(b"5724"));
    }

    #[test]
    fn test_validate_invalid() {
        assert!(!validate(b"5723"));
        assert!(!validate(b""));
    }

    #[test]
    fn test_single_digit() {
        // 0 with check digit 0 -> "00"
        assert_eq!(generate(b"0"), 0);
        assert!(validate(b"00"));
    }
}
