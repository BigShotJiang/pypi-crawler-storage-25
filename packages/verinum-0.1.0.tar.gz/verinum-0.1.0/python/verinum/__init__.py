"""
verinum — High-performance validation and reference data library.

Usage:
    import verinum
    verinum.iban.is_valid("GB82 WEST 1234 5698 7654 32")
    verinum.vat.validate("DE123456789")
    verinum.countries.get(alpha2="DE")
"""

from verinum._verinum import (
    # Validators
    is_valid_iban,
    validate_iban,
    is_valid_bic,
    validate_bic,
    is_valid_credit_card,
    validate_credit_card,
    is_valid_isbn,
    validate_isbn,
    is_valid_issn,
    validate_issn,
    is_valid_isin,
    validate_isin,
    is_valid_lei,
    validate_lei,
    is_valid_ean,
    validate_ean,
    is_valid_vat,
    validate_vat,
    # Algorithms
    luhn_validate,
    luhn_generate,
    verhoeff_validate,
    damm_validate,
    # Data
    get_country,
    get_country_by_alpha3,
    get_currency,
    get_vat_rate,
)


class VerinumError(Exception):
    """Base exception for verinum errors."""
    pass


class _ValidatorModule:
    """Namespace for a validator type."""

    def __init__(self, is_valid_fn, validate_fn):
        self._is_valid = is_valid_fn
        self._validate = validate_fn

    def is_valid(self, input: str) -> bool:
        return self._is_valid(input)

    def validate(self, input: str) -> dict:
        return self._validate(input)


class _CountriesModule:
    """Namespace for country data lookups."""

    @staticmethod
    def get(*, alpha2: str = None, alpha3: str = None, numeric: int = None):
        if alpha2 is not None:
            return get_country(alpha2)
        if alpha3 is not None:
            return get_country_by_alpha3(alpha3)
        if numeric is not None:
            raise NotImplementedError("Numeric lookup not yet available")
        raise ValueError("Provide alpha2, alpha3, or numeric")


class _CurrenciesModule:
    """Namespace for currency data lookups."""

    @staticmethod
    def get(*, code: str = None, numeric: int = None):
        if code is not None:
            return get_currency(code)
        if numeric is not None:
            raise NotImplementedError("Numeric lookup not yet available")
        raise ValueError("Provide code or numeric")


class _VatRatesModule:
    """Namespace for VAT rate data lookups."""

    @staticmethod
    def get(country_alpha2: str):
        return get_vat_rate(country_alpha2)


class _AlgorithmsModule:
    """Namespace for check digit algorithms."""

    @staticmethod
    def luhn_validate(input: str) -> bool:
        return luhn_validate(input)

    @staticmethod
    def luhn_generate(input: str) -> int:
        return luhn_generate(input)

    @staticmethod
    def verhoeff_validate(input: str) -> bool:
        return verhoeff_validate(input)

    @staticmethod
    def damm_validate(input: str) -> bool:
        return damm_validate(input)


# Module-level namespaces
iban = _ValidatorModule(is_valid_iban, validate_iban)
bic = _ValidatorModule(is_valid_bic, validate_bic)
credit_card = _ValidatorModule(is_valid_credit_card, validate_credit_card)
isbn = _ValidatorModule(is_valid_isbn, validate_isbn)
issn = _ValidatorModule(is_valid_issn, validate_issn)
isin = _ValidatorModule(is_valid_isin, validate_isin)
lei = _ValidatorModule(is_valid_lei, validate_lei)
ean = _ValidatorModule(is_valid_ean, validate_ean)
vat = _ValidatorModule(is_valid_vat, validate_vat)

countries = _CountriesModule()
currencies = _CurrenciesModule()
vat_rates = _VatRatesModule()
algorithms = _AlgorithmsModule()


class Client:
    """Optional client wrapper for verinum.

    Provides the same offline validation as module-level functions.
    The verify() method is scaffolded for future live registry checks.
    """

    def __init__(self, api_key: str = None, base_url: str = "https://api.verinum.dev/v1"):
        self.api_key = api_key
        self.base_url = base_url
        self.iban = _ValidatorModule(is_valid_iban, validate_iban)
        self.bic = _ValidatorModule(is_valid_bic, validate_bic)
        self.credit_card = _ValidatorModule(is_valid_credit_card, validate_credit_card)
        self.isbn = _ValidatorModule(is_valid_isbn, validate_isbn)
        self.issn = _ValidatorModule(is_valid_issn, validate_issn)
        self.isin = _ValidatorModule(is_valid_isin, validate_isin)
        self.lei = _ValidatorModule(is_valid_lei, validate_lei)
        self.ean = _ValidatorModule(is_valid_ean, validate_ean)
        self.vat = _ValidatorModule(is_valid_vat, validate_vat)
        self.countries = _CountriesModule()
        self.currencies = _CurrenciesModule()
        self.vat_rates = _VatRatesModule()
        self.algorithms = _AlgorithmsModule()

    def verify(self, validator_type: str, input: str):
        """Live registry verification (not yet implemented)."""
        if self.api_key is None:
            raise VerinumError("API key required for verify()")
        raise NotImplementedError("Live verification coming soon")


__version__ = "0.1.0"
__all__ = [
    "iban", "bic", "credit_card", "isbn", "issn", "isin", "lei", "ean", "vat",
    "countries", "currencies", "vat_rates", "algorithms",
    "is_valid_iban", "validate_iban", "is_valid_bic", "validate_bic",
    "is_valid_credit_card", "validate_credit_card",
    "is_valid_isbn", "validate_isbn", "is_valid_issn", "validate_issn",
    "is_valid_isin", "validate_isin", "is_valid_lei", "validate_lei",
    "is_valid_ean", "validate_ean", "is_valid_vat", "validate_vat",
    "Client", "VerinumError",
]
