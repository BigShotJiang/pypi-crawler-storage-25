# verinum

High-performance validation and reference data library with a compiled Rust
core, exposed to Python via [PyO3](https://pyo3.rs/).

- **Identifier validation** — IBAN, BIC, credit card, ISBN, ISSN, ISIN, LEI,
  EAN, EU VAT numbers
- **Reference data** — countries, subdivisions, currencies, languages,
  VAT rates
- **Check digit algorithms** — Luhn, Verhoeff, Damm, ISO 7064
- **Offline-first** — all validation and lookup works without network access
- **Zero-allocation hot paths** — `is_valid()` functions are standalone,
  allocation-free implementations in the Rust core

## Installation

```bash
pip install verinum
```

Prebuilt wheels are provided for Linux (manylinux + musllinux, x86_64 and
aarch64), macOS (Intel and Apple Silicon), and Windows (x64). On other
platforms `pip` will build from the sdist, which requires a Rust toolchain.

## Usage

```python
import verinum

# Validators
verinum.iban.is_valid("GB82 WEST 1234 5698 7654 32")   # True
verinum.vat.validate("DE123456789")
# {'is_valid': True, 'compact': 'DE123456789', 'country': 'DE', ...}

verinum.credit_card.validate("4111111111111111")
# {'is_valid': True, 'brand': 'visa', ...}

# Flat convenience aliases
verinum.is_valid_iban("GB82 WEST 1234 5698 7654 32")
verinum.validate_vat("DE123456789")

# Reference data
verinum.countries.get(alpha2="DE")
verinum.currencies.get(code="EUR")
verinum.vat_rates.get("DE")

# Algorithms
verinum.algorithms.luhn_validate("4111111111111111")

# Client (optional wrapper)
from verinum import Client
v = Client()
v.iban.validate("GB82WEST12345698765432")
```

## Validation semantics

- **`is_valid(input)`** — offline format/checksum validation. Fast path,
  zero allocations. Standalone implementation, not a wrapper around
  `validate()`.
- **`validate(input)`** — offline structured validation with normalization,
  typed error codes, and validator-specific metadata.
- **`verify(input)`** — future live registry validation (scaffolded, raises
  `NotImplementedError` in v1).

## Supported validators

| Validator   | Format                        | Checksum              |
|-------------|-------------------------------|-----------------------|
| IBAN        | Country + check digits + BBAN | Mod 97-10             |
| BIC/SWIFT   | 8 or 11 alphanumeric          | Structural            |
| Credit Card | 12–19 digits                  | Luhn                  |
| ISBN        | ISBN-10 / ISBN-13             | Mod 11 / Mod 10       |
| ISSN        | 8 digits                      | Mod 11                |
| ISIN        | 12 alphanumeric               | Luhn (letter expand)  |
| LEI         | 20 alphanumeric               | Mod 97-10             |
| EAN         | EAN-8 / EAN-13                | Weighted checksum     |
| EU VAT      | 28 country formats            | Country-specific      |

## Links

- Source and full documentation:
  <https://github.com/yanivtoledano/verinum>
- Issue tracker:
  <https://github.com/yanivtoledano/verinum/issues>

## License

MIT OR Apache-2.0
