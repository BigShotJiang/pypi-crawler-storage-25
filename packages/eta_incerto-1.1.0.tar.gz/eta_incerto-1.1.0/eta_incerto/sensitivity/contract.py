"""
Initialization and management of the sensitivity contract namespace.

This module is responsible for creating and maintaining the directory
structure and metadata for sensitivity analysis within a given run_dir.

Responsibilities:
- Initialize run_dir/sensitivity/ structure
- Create required subdirectories (baseline, scenarios, results, aggregate)
- Write and validate contract.json
- Ensure idempotent initialization (safe repeated calls)

This module defines the entry point:
    initialize_sensitivity_contract(...)
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .paths import (
    PathLike,
    aggregate_dir,
    baseline_dir,
    contract_path,
    results_dir,
    scenarios_dir,
    sensitivity_dir,
)

CONTRACT_VERSION = "1.0"
SCHEMA_VERSION = "1.0"
DEFAULT_SENSITIVITY_ID = "default"


def utc_now_iso() -> str:
    """Return the current UTC timestamp in ISO-8601 format."""
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def build_contract_metadata(
    run_dir: PathLike,
    *,
    sensitivity_id: str = DEFAULT_SENSITIVITY_ID,
    created_by: str = "initialize_sensitivity_contract",
    notes: str | None = None,
) -> dict[str, Any]:
    """
    Build the metadata payload for contract.json.

    Parameters
    ----------
    run_dir:
        Base run directory under which the sensitivity namespace lives.
    sensitivity_id:
        Logical identifier for the sensitivity namespace.
    created_by:
        Name of the function/tool creating the contract.
    notes:
        Optional free-text notes.

    Returns
    -------
    dict[str, Any]
        Contract metadata ready to be serialized to JSON.
    """
    run_path = Path(run_dir)

    payload: dict[str, Any] = {
        "contract_version": CONTRACT_VERSION,
        "schema_version": SCHEMA_VERSION,
        "run_dir": str(run_path.resolve()),
        "sensitivity_id": sensitivity_id,
        "created_at_utc": utc_now_iso(),
        "created_by": created_by,
    }

    if notes is not None:
        payload["notes"] = notes

    return payload


def write_contract_json(
    run_dir: PathLike,
    contract_data: dict[str, Any],
    *,
    force: bool = False,
) -> Path:
    """
    Write contract.json under run_dir/sensitivity/.

    Parameters
    ----------
    run_dir:
        Base run directory.
    contract_data:
        JSON-serializable contract metadata.
    force:
        If True, overwrite an existing contract.json.

    Returns
    -------
    Path
        Path to the written contract.json.

    Raises
    ------
    FileExistsError
        If contract.json already exists and force=False.
    """
    path = contract_path(run_dir)

    if path.exists() and not force:
        raise FileExistsError(f"contract.json already exists at '{path}'. Use force=True to overwrite.")

    path.write_text(json.dumps(contract_data, indent=2, sort_keys=True), encoding="utf-8")
    return path


def read_contract_json(run_dir: PathLike) -> dict[str, Any]:
    """
    Read contract.json from run_dir/sensitivity/.

    Parameters
    ----------
    run_dir:
        Base run directory.

    Returns
    -------
    dict[str, Any]
        Parsed JSON content.
    """
    path = contract_path(run_dir)
    return json.loads(path.read_text(encoding="utf-8"))


def ensure_sensitivity_directories(run_dir: PathLike) -> dict[str, Path]:
    """
    Create the sensitivity directory structure if it does not exist.

    Parameters
    ----------
    run_dir:
        Base run directory.

    Returns
    -------
    dict[str, Path]
        Dictionary containing the created/resolved directories.
    """
    directories = {
        "sensitivity": sensitivity_dir(run_dir),
        "baseline": baseline_dir(run_dir),
        "scenarios": scenarios_dir(run_dir),
        "results": results_dir(run_dir),
        "aggregate": aggregate_dir(run_dir),
    }

    for directory in directories.values():
        directory.mkdir(parents=True, exist_ok=True)

    return directories


def initialize_sensitivity_contract(
    run_dir: PathLike,
    *,
    sensitivity_id: str = DEFAULT_SENSITIVITY_ID,
    created_by: str = "initialize_sensitivity_contract",
    notes: str | None = "Foundation v1 initialized",
    force: bool = False,
) -> dict[str, Any]:
    """
    Initialize the sensitivity contract namespace under a run directory.

    This function creates the directory structure and writes contract.json.
    It is safe to call repeatedly. Existing directories are preserved.
    Existing contract.json is preserved unless force=True.

    Parameters
    ----------
    run_dir:
        Base run directory.
    sensitivity_id:
        Logical identifier for the sensitivity namespace.
    created_by:
        Name of the initializing function/tool.
    notes:
        Optional note written into contract.json.
    force:
        If True, overwrite an existing contract.json.

    Returns
    -------
    dict[str, Any]
        Summary including created directories and contract metadata.
    """
    dirs = ensure_sensitivity_directories(run_dir)
    cpath = contract_path(run_dir)

    if cpath.exists() and not force:
        contract_data = read_contract_json(run_dir)
        contract_written = False
    else:
        contract_data = build_contract_metadata(
            run_dir,
            sensitivity_id=sensitivity_id,
            created_by=created_by,
            notes=notes,
        )
        write_contract_json(run_dir, contract_data, force=True)
        contract_written = True

    return {
        "run_dir": str(Path(run_dir).resolve()),
        "sensitivity_dir": str(dirs["sensitivity"].resolve()),
        "contract_path": str(cpath.resolve()),
        "contract_written": contract_written,
        "contract_data": contract_data,
    }
