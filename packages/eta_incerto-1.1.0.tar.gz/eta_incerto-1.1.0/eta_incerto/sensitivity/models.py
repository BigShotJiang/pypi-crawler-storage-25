"""
Data models for the sensitivity contract.

This module defines structured representations (e.g. dataclasses or typed
dicts) for the main entities used in the sensitivity feature.

Typical models include:
- Contract metadata
- Provenance records
- Baseline metadata
- Scenario definitions

The goal is to provide clear, typed, and reusable structures that are shared
across contract initialization, I/O, validation, and aggregation.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(slots=True)
class ContractMetadata:
    """
    Metadata stored in contract.json.
    """

    contract_version: str
    schema_version: str
    run_dir: str
    sensitivity_id: str
    created_at_utc: str
    created_by: str
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ProvenanceRecord:
    """
    Minimal provenance information required for sensitivity artifacts.
    """

    run_id: str | None
    run_dir: str
    schema_version: str
    sensitivity_id: str
    config_hash: str | None
    code_commit: str | None
    code_version: str | None
    solver_name: str | None
    solver_version: str | None
    solver_options: dict[str, Any] = field(default_factory=dict)
    scenario_id: str | None = None
    scenario_descriptor_hash: str | None = None
    created_at_utc: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class BaselineMetadata:
    """
    Metadata stored in baseline/baseline.json.
    """

    schema_version: str
    run_id: str | None
    sensitivity_id: str
    baseline_ref: str
    objective_value: float | None
    solver_status: str | None
    solve_time_seconds: float | None
    mip_gap: float | None
    solver: dict[str, Any] = field(default_factory=dict)
    stable_variable_subset: dict[str, Any] = field(default_factory=dict)
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ScenarioDefinition:
    """
    Single scenario entry as stored in scenarios/scenarios.json.
    """

    scenario_id: str
    name: str | None
    descriptor: dict[str, Any]
    seed: int | None = None
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ScenarioCollection:
    """
    Container for a full scenarios/scenarios.json payload.
    """

    schema_version: str
    run_id: str | None
    sensitivity_id: str
    scenarios: list[ScenarioDefinition] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["scenarios"] = [scenario.to_dict() for scenario in self.scenarios]
        return data
