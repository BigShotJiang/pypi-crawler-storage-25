"""
Input/output utilities for sensitivity artifacts.

This module handles reading and writing of all data files associated with
the sensitivity contract.

Responsibilities:
- Read/write contract.json, baseline.json, scenarios.json
- Read/write incumbent data (NPZ)
- Read/write scenario results (HDF5)
- Ensure atomic writes for result files
- Implement idempotence checks based on provenance

All file operations should go through this module to ensure consistency.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

from .paths import (
    PathLike,
    baseline_json_path,
    incumbent_npz_path,
    scenarios_json_path,
)
from .schemas import validate_baseline_data, validate_scenarios_data


def _write_json(path: Path, data: dict[str, Any]) -> Path:
    """
    Write a JSON file with stable formatting.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return path


def _read_json(path: Path) -> dict[str, Any]:
    """
    Read a JSON file and return its parsed content.
    """
    return json.loads(path.read_text(encoding="utf-8"))


def write_baseline_json(run_dir: PathLike, data: dict[str, Any]) -> Path:
    """
    Validate and write baseline/baseline.json.
    """
    errors = validate_baseline_data(data)
    if errors:
        raise ValueError("Invalid baseline.json payload:\n- " + "\n- ".join(errors))

    path = baseline_json_path(run_dir)
    return _write_json(path, data)


def read_baseline_json(run_dir: PathLike, *, validate: bool = True) -> dict[str, Any]:
    """
    Read baseline/baseline.json and optionally validate it.
    """
    path = baseline_json_path(run_dir)
    data = _read_json(path)

    if validate:
        errors = validate_baseline_data(data)
        if errors:
            raise ValueError("Invalid baseline.json payload:\n- " + "\n- ".join(errors))

    return data


def write_scenarios_json(run_dir: PathLike, data: dict[str, Any]) -> Path:
    """
    Validate and write scenarios/scenarios.json.
    """
    errors = validate_scenarios_data(data)
    if errors:
        raise ValueError("Invalid scenarios.json payload:\n- " + "\n- ".join(errors))

    path = scenarios_json_path(run_dir)
    return _write_json(path, data)


def read_scenarios_json(run_dir: PathLike, *, validate: bool = True) -> dict[str, Any]:
    """
    Read scenarios/scenarios.json and optionally validate it.
    """
    path = scenarios_json_path(run_dir)
    data = _read_json(path)

    if validate:
        errors = validate_scenarios_data(data)
        if errors:
            raise ValueError("Invalid scenarios.json payload:\n- " + "\n- ".join(errors))

    return data


def write_incumbent_npz(
    run_dir: PathLike,
    *,
    variable_names: list[str] | np.ndarray,
    variable_values: list[float] | np.ndarray,
    **extra_arrays: Any,
) -> Path:
    """
    Write baseline/incumbent.npz.

    Required arrays:
    - variable_names
    - variable_values

    Additional arrays can be passed via **extra_arrays, e.g. subset masks or
    index mappings.
    """
    names = np.asarray(variable_names)
    values = np.asarray(variable_values)

    if names.ndim != 1:
        raise ValueError("variable_names must be a 1D array-like")
    if values.ndim != 1:
        raise ValueError("variable_values must be a 1D array-like")
    if len(names) != len(values):
        raise ValueError("variable_names and variable_values must have the same length")

    path = incumbent_npz_path(run_dir)
    path.parent.mkdir(parents=True, exist_ok=True)

    np.savez(
        path,
        variable_names=names,
        variable_values=values,
        **extra_arrays,
    )
    return path


def read_incumbent_npz(run_dir: PathLike) -> dict[str, np.ndarray]:
    """
    Read baseline/incumbent.npz into a plain dict of numpy arrays.
    """
    path = incumbent_npz_path(run_dir)
    with np.load(path, allow_pickle=False) as data:
        return {key: data[key] for key in data.files}
