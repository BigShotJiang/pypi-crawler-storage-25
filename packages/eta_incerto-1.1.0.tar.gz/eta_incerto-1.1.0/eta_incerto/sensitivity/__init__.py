"""
Sensitivity analysis module for eta-incerto.

This package provides a structured and reproducible framework for
sensitivity analysis on optimization runs.

Public API includes:
- Contract initialization
- Data I/O (baseline, scenarios, incumbent)
- Provenance handling and comparison

Internal modules (paths, schemas, etc.) are not intended for direct use.
"""

from __future__ import annotations

# I/O
from .artifact_io import (
    read_baseline_json,
    read_incumbent_npz,
    read_scenarios_json,
    write_baseline_json,
    write_incumbent_npz,
    write_scenarios_json,
)

# Contract
from .contract import initialize_sensitivity_contract

# Provenance
from .provenance import build_provenance, provenance_matches

__all__ = [
    "build_provenance",
    "initialize_sensitivity_contract",
    "provenance_matches",
    "read_baseline_json",
    "read_incumbent_npz",
    "read_scenarios_json",
    "write_baseline_json",
    "write_incumbent_npz",
    "write_scenarios_json",
]
