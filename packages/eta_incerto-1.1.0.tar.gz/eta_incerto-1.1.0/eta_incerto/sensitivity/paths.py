from pathlib import Path

# Type alias for flexibility (accept str or Path)
PathLike = str | Path


def _to_path(run_dir: PathLike) -> Path:
    """Ensure run_dir is a Path object."""
    return run_dir if isinstance(run_dir, Path) else Path(run_dir)


# ---------------------------------------------------------------------------
# Base directories
# ---------------------------------------------------------------------------


def sensitivity_dir(run_dir: PathLike) -> Path:
    """Base sensitivity directory under a run."""
    return _to_path(run_dir) / "sensitivity"


def baseline_dir(run_dir: PathLike) -> Path:
    return sensitivity_dir(run_dir) / "baseline"


def scenarios_dir(run_dir: PathLike) -> Path:
    return sensitivity_dir(run_dir) / "scenarios"


def results_dir(run_dir: PathLike) -> Path:
    return sensitivity_dir(run_dir) / "results"


def aggregate_dir(run_dir: PathLike) -> Path:
    return sensitivity_dir(run_dir) / "aggregate"


# ---------------------------------------------------------------------------
# Contract + baseline
# ---------------------------------------------------------------------------


def contract_path(run_dir: PathLike) -> Path:
    return sensitivity_dir(run_dir) / "contract.json"


def baseline_json_path(run_dir: PathLike) -> Path:
    return baseline_dir(run_dir) / "baseline.json"


def incumbent_npz_path(run_dir: PathLike) -> Path:
    return baseline_dir(run_dir) / "incumbent.npz"


# ---------------------------------------------------------------------------
# Scenarios
# ---------------------------------------------------------------------------


def scenarios_json_path(run_dir: PathLike) -> Path:
    return scenarios_dir(run_dir) / "scenarios.json"


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------


def result_h5_path(run_dir: PathLike, scenario_id: str) -> Path:
    return results_dir(run_dir) / f"{scenario_id}.h5"


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------


def scorecard_h5_path(run_dir: PathLike) -> Path:
    return aggregate_dir(run_dir) / "scorecard.h5"
