"""
Provenance construction and validation utilities.

This module defines how provenance metadata is created, normalized, and
compared across different artifacts.

Responsibilities:
- Build provenance records for baseline and scenario results
- Define required provenance fields (e.g. run_id, config_hash, solver info)
- Compare provenance for idempotence checks
- Provide normalization helpers for stable comparison

Provenance is used to ensure reproducibility and consistency of results.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import asdict
from typing import Any

from .models import ProvenanceRecord

# Minimal fields required by the contract across relevant artifacts.
REQUIRED_PROVENANCE_FIELDS: tuple[str, ...] = (
    "run_dir",
    "schema_version",
    "sensitivity_id",
)

# Additional fields that are expected for scenario result artifacts.
SCENARIO_PROVENANCE_FIELDS: tuple[str, ...] = (
    "scenario_id",
    "scenario_descriptor_hash",
)


def build_provenance(  # noqa: PLR0913
    *,
    run_id: str | None,
    run_dir: str,
    schema_version: str,
    sensitivity_id: str,
    config_hash: str | None = None,
    code_commit: str | None = None,
    code_version: str | None = None,
    solver_name: str | None = None,
    solver_version: str | None = None,
    solver_options: dict[str, Any] | None = None,
    scenario_id: str | None = None,
    scenario_descriptor_hash: str | None = None,
    created_at_utc: str | None = None,
) -> dict[str, Any]:
    """
    Build a provenance dictionary from normalized input fields.
    """
    record = ProvenanceRecord(
        run_id=run_id,
        run_dir=run_dir,
        schema_version=schema_version,
        sensitivity_id=sensitivity_id,
        config_hash=config_hash,
        code_commit=code_commit,
        code_version=code_version,
        solver_name=solver_name,
        solver_version=solver_version,
        solver_options=solver_options or {},
        scenario_id=scenario_id,
        scenario_descriptor_hash=scenario_descriptor_hash,
        created_at_utc=created_at_utc,
    )
    return asdict(record)


def validate_provenance_dict(
    provenance: dict[str, Any],
    *,
    require_scenario_fields: bool = False,
) -> list[str]:
    """
    Validate that a provenance dictionary contains the minimally required fields.

    Returns
    -------
    list[str]
        A list of validation error messages. Empty means valid enough for the
        current contract stage.
    """
    errors: list[str] = []

    for field in REQUIRED_PROVENANCE_FIELDS:
        value = provenance.get(field)
        if value is None or value == "":
            errors.append(f"Missing required provenance field: '{field}'")

    if require_scenario_fields:
        for field in SCENARIO_PROVENANCE_FIELDS:
            value = provenance.get(field)
            if value is None or value == "":
                errors.append(f"Missing required scenario provenance field: '{field}'")

    solver_options = provenance.get("solver_options")
    if solver_options is not None and not isinstance(solver_options, dict):
        errors.append("Provenance field 'solver_options' must be a dict if provided")

    return errors


def normalize_provenance_for_compare(provenance: dict[str, Any]) -> dict[str, Any]:
    """
    Normalize provenance so comparisons are stable.

    Current normalization is intentionally lightweight:
    - missing solver_options -> {}
    - keep only plain dict values as-is
    """
    normalized = dict(provenance)
    if normalized.get("solver_options") is None:
        normalized["solver_options"] = {}
    return normalized


def provenance_matches(
    expected: dict[str, Any],
    observed: dict[str, Any],
    *,
    keys: Iterable[str] | None = None,
) -> bool:
    """
    Compare two provenance dictionaries on a selected key set.

    Parameters
    ----------
    expected:
        The provenance values expected for the current operation.
    observed:
        The provenance values found in an existing artifact.
    keys:
        Specific keys to compare. If omitted, a default contract-oriented set
        is used.

    Returns
    -------
    bool
        True if all selected keys match, otherwise False.
    """
    default_keys = (
        "run_id",
        "run_dir",
        "schema_version",
        "sensitivity_id",
        "config_hash",
        "code_commit",
        "code_version",
        "solver_name",
        "solver_version",
        "scenario_id",
        "scenario_descriptor_hash",
    )
    compare_keys = tuple(keys) if keys is not None else default_keys

    expected_norm = normalize_provenance_for_compare(expected)
    observed_norm = normalize_provenance_for_compare(observed)

    return all(expected_norm.get(key) == observed_norm.get(key) for key in compare_keys)
