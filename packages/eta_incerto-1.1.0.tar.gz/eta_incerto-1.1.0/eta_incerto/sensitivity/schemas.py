"""
Validation logic and schemas for sensitivity artifacts.

This module defines the expected structure of JSON-based artifacts such as:
- contract.json
- baseline.json
- scenarios.json

Responsibilities:
- Validate required fields and types
- Enforce schema constraints
- Provide helper functions for validating loaded JSON data

The validation approach can be lightweight (manual checks) or based on a
schema system, depending on project conventions.
"""

from __future__ import annotations

from typing import Any

from .provenance import validate_provenance_dict


def _require_dict(data: Any, *, name: str) -> list[str]:
    if not isinstance(data, dict):
        return [f"{name} must be a JSON object / dict"]
    return []


def _require_field(
    data: dict[str, Any],
    field_name: str,
    expected_type: type | tuple[type, ...] | None = None,
) -> list[str]:
    errors: list[str] = []

    if field_name not in data:
        errors.append(f"Missing required field: '{field_name}'")
        return errors

    if expected_type is not None and not isinstance(data[field_name], expected_type):
        if isinstance(expected_type, tuple):
            expected_name = ", ".join(t.__name__ for t in expected_type)
        else:
            expected_name = expected_type.__name__
        actual_name = type(data[field_name]).__name__
        errors.append(f"Field '{field_name}' must be of type {expected_name}, got {actual_name}")

    return errors


def validate_contract_data(data: dict[str, Any]) -> list[str]:
    """
    Validate contract.json content.
    """
    errors = _require_dict(data, name="contract.json")
    if errors:
        return errors

    errors.extend(_require_field(data, "contract_version", str))
    errors.extend(_require_field(data, "schema_version", str))
    errors.extend(_require_field(data, "run_dir", str))
    errors.extend(_require_field(data, "sensitivity_id", str))
    errors.extend(_require_field(data, "created_at_utc", str))
    errors.extend(_require_field(data, "created_by", str))

    if "notes" in data and data["notes"] is not None and not isinstance(data["notes"], str):
        errors.append("Field 'notes' must be a string or null")

    return errors


def validate_baseline_data(data: dict[str, Any]) -> list[str]:
    """
    Validate baseline/baseline.json content.
    """
    errors = _require_dict(data, name="baseline.json")
    if errors:
        return errors

    errors.extend(_require_field(data, "schema_version", str))
    if "run_id" in data and data["run_id"] is not None and not isinstance(data["run_id"], str):
        errors.append("Field 'run_id' must be a string or null")

    errors.extend(_require_field(data, "sensitivity_id", str))
    errors.extend(_require_field(data, "baseline_ref", str))

    if (
        "objective_value" in data
        and data["objective_value"] is not None
        and not isinstance(data["objective_value"], int | float)
    ):
        errors.append("Field 'objective_value' must be numeric or null")

    if "solver_status" in data and data["solver_status"] is not None and not isinstance(data["solver_status"], str):
        errors.append("Field 'solver_status' must be a string or null")

    if (
        "solve_time_seconds" in data
        and data["solve_time_seconds"] is not None
        and not isinstance(data["solve_time_seconds"], int | float)
    ):
        errors.append("Field 'solve_time_seconds' must be numeric or null")

    if "mip_gap" in data and data["mip_gap"] is not None and not isinstance(data["mip_gap"], int | float):
        errors.append("Field 'mip_gap' must be numeric or null")

    if "solver" in data and not isinstance(data.get("solver", {}), dict):
        errors.append("Field 'solver' must be a dict if provided")

    if "stable_variable_subset" in data and not isinstance(data.get("stable_variable_subset", {}), dict):
        errors.append("Field 'stable_variable_subset' must be a dict if provided")

    provenance = data.get("provenance")
    if provenance is None:
        errors.append("Missing required field: 'provenance'")
    elif not isinstance(provenance, dict):
        errors.append("Field 'provenance' must be a dict")
    else:
        errors.extend(validate_provenance_dict(provenance, require_scenario_fields=False))

    return errors


def validate_scenario_definition(data: dict[str, Any]) -> list[str]:
    """
    Validate a single scenario entry from scenarios/scenarios.json.
    """
    errors = _require_dict(data, name="scenario")
    if errors:
        return errors

    errors.extend(_require_field(data, "scenario_id", str))

    if "name" in data and data["name"] is not None and not isinstance(data["name"], str):
        errors.append("Field 'name' must be a string or null")

    errors.extend(_require_field(data, "descriptor", dict))

    if "seed" in data and data["seed"] is not None and not isinstance(data["seed"], int):
        errors.append("Field 'seed' must be an int or null")

    if "tags" in data:
        if not isinstance(data["tags"], list):
            errors.append("Field 'tags' must be a list if provided")
        elif not all(isinstance(tag, str) for tag in data["tags"]):
            errors.append("All entries in 'tags' must be strings")

    return errors


def validate_scenarios_data(data: dict[str, Any]) -> list[str]:
    """
    Validate scenarios/scenarios.json content.
    """
    errors = _require_dict(data, name="scenarios.json")
    if errors:
        return errors

    errors.extend(_require_field(data, "schema_version", str))
    if "run_id" in data and data["run_id"] is not None and not isinstance(data["run_id"], str):
        errors.append("Field 'run_id' must be a string or null")

    errors.extend(_require_field(data, "sensitivity_id", str))
    errors.extend(_require_field(data, "scenarios", list))

    scenarios = data.get("scenarios", [])
    if isinstance(scenarios, list):
        seen_ids: set[str] = set()
        for index, scenario in enumerate(scenarios):
            scenario_errors = validate_scenario_definition(scenario)
            errors.extend([f"scenarios[{index}]: {msg}" for msg in scenario_errors])

            if isinstance(scenario, dict) and "scenario_id" in scenario:
                scenario_id = scenario["scenario_id"]
                if isinstance(scenario_id, str):
                    if scenario_id in seen_ids:
                        errors.append(f"scenarios[{index}]: duplicate scenario_id '{scenario_id}'")
                    seen_ids.add(scenario_id)

    return errors
