from __future__ import annotations

import json
from pathlib import Path


def initialize_sensitivity_contract(run_dir: str | Path) -> Path:
    """
    Initialize the sensitivity analysis structure inside a run directory.

    This creates:
        <run_dir>/sensitivity/
            contract.json
            baseline/
            scenarios/
            results/
            aggregate/

    Parameters
    ----------
    run_dir : str or Path
        Path to the existing run directory.

    Returns
    -------
    Path
        Path to the created sensitivity directory.
    """

    run_path = Path(run_dir)

    if not run_path.exists():
        raise FileNotFoundError(f"Run directory does not exist: {run_path}")

    sensitivity_dir = run_path / "sensitivity"

    # Create directory structure
    (sensitivity_dir / "baseline").mkdir(parents=True, exist_ok=True)
    (sensitivity_dir / "scenarios").mkdir(parents=True, exist_ok=True)
    (sensitivity_dir / "results").mkdir(parents=True, exist_ok=True)
    (sensitivity_dir / "aggregate").mkdir(parents=True, exist_ok=True)

    # Create contract.json if it does not exist
    contract_path = sensitivity_dir / "contract.json"

    if not contract_path.exists():
        contract = {
            "version": "0.1",
            "status": "initialized",
            "baseline_defined": False,
            "scenarios_defined": False,
            "results_available": False,
            "created_at": None,
        }

        with contract_path.open("w") as f:
            json.dump(contract, f, indent=2)

    return sensitivity_dir
