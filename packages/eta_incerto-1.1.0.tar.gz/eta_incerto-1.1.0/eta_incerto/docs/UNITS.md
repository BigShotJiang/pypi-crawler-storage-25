# Units: Required Inputs and Achieved Outputs (eta-incerto)

SI units are used in evaluation and HDF5 storage: W, Wh, EUR. Display units (MWh, kEUR, kW) are applied only in the plotting module.

## eta-incerto envs (evaluation → HDF5)

| Quantity | Required input (from model/bundle) | Achieved output (written to HDF5) |
|----------|-----------------------------------|-----------------------------------|
| Trader energy | `amount` in **W**, aggregated with `step_length` in **h** | **Wh** (key e.g. `energy/{trader}_wh`) |
| Trader costs | From model in **EUR** | **EUR** (key e.g. `costs/{trader}_eur`) |
| Trader emissions | From model in **t** | **t** (key e.g. `emissions/{trader}_t`) |
| Objective (NPV) | Solver value in **EUR** | **EUR** (key `objective/npv`) |
| Objective (TAC) | Solver value in **EUR/a** | **EUR/a** (key `objective/tac`) |
| Capex | From model in **EUR** | **EUR** (key `objective/capex`) |

## HDF5 storage (SI)

| Group / dataset | Stored unit |
|-----------------|-------------|
| `__expected__/energy/*_wh` | **Wh** (annual equivalent) |
| `__expected__/costs/*_eur` | **EUR** |
| `__expected__/emissions/*_t` | **t** (tonnes CO2) |
| `__expected__/objective/npv` | **EUR** |
| `__expected__/objective/tac` | **EUR/a** |
| `__expected__/objective/capex` | **EUR** |
| Scenario `unit_dispatch` (power) | **W** |

## Plotting (display only)

| Plot / axis | Input read from HDF5 | Display unit (axis/label) |
|-------------|----------------------|---------------------------|
| Comparison (energy) | **Wh** | **MWh** |
| Comparison (costs) | **EUR** | **kEUR** |
| Comparison (emissions) | **t** | **t** (no conversion) |
| Table (all scalars) | As stored (Wh, EUR, t) | Show with unit suffix |
| Dispatch heatmap | **W** | **kW** |
