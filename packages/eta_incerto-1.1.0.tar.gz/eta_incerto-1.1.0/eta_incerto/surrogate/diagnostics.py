"""Surrogate diagnostics: RMSE and related metrics."""

from __future__ import annotations

from typing import Any

import numpy as np

from eta_incerto.surrogate.pce import fit_pce_regression, predict_pce


def root_mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=float).ravel()
    y_pred = np.asarray(y_pred, dtype=float).ravel()
    if y_true.shape != y_pred.shape:
        raise ValueError(f"y_true shape {y_true.shape} != y_pred shape {y_pred.shape}")
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def kfold_pce_rmse(
    poly_expansion: Any,
    x_samples: np.ndarray,
    y_samples: np.ndarray,
    n_folds: int,
    *,
    random_state: int | None = 0,
) -> tuple[float, np.ndarray]:
    """K-fold CV RMSE for a fixed polynomial basis and training sample.

    Fits PCE on each training fold and scores on the held-out fold (chaospy regression).

    Parameters
    ----------
    x_samples
        Shape ``(n_dim, n_samples)`` (chaospy layout).
    y_samples
        Shape ``(n_samples,)`` responses aligned with columns of ``x_samples``.
    n_folds
        Number of folds; capped to ``n_samples`` and must be >= 2 when ``n_samples`` >= 2.

    Returns
    -------
    mean_rmse
        Mean of per-fold RMSE values.
    fold_rmses
        Shape ``(n_folds_used,)``.
    """
    x_samples = np.asarray(x_samples, dtype=float)
    y_samples = np.asarray(y_samples, dtype=float).ravel()
    n = int(y_samples.shape[0])
    if n < 2:
        raise ValueError(f"k-fold CV needs at least 2 training points, got {n}")
    n_folds = int(min(max(2, n_folds), n))
    rng = np.random.default_rng(random_state)
    perm = rng.permutation(n)
    splits = np.array_split(perm, n_folds)
    fold_rmses_list: list[float] = []
    for k in range(len(splits)):
        val_idx = splits[k]
        if val_idx.size == 0:
            continue
        train_idx = np.concatenate([splits[i] for i in range(len(splits)) if i != k])
        if train_idx.size == 0:
            continue
        x_tr = x_samples[:, train_idx]
        y_tr = y_samples[train_idx]
        x_va = x_samples[:, val_idx]
        y_va = y_samples[val_idx]
        pce = fit_pce_regression(poly_expansion, x_tr, y_tr)
        y_pred = predict_pce(pce, x_va)
        fold_rmses_list.append(root_mean_squared_error(y_va, y_pred))
    fold_rmses = np.asarray(fold_rmses_list, dtype=float)
    if fold_rmses.size == 0:
        raise ValueError("k-fold CV produced no folds; check n_folds and sample count")
    return float(np.mean(fold_rmses)), fold_rmses


def leave_one_out_pce_rmse(
    poly_expansion: Any,
    x_samples: np.ndarray,
    y_samples: np.ndarray,
) -> float:
    """Exact leave-one-out RMSE: one refit per training point (cost O(n) fits)."""
    x_samples = np.asarray(x_samples, dtype=float)
    y_samples = np.asarray(y_samples, dtype=float).ravel()
    n = int(y_samples.shape[0])
    if n < 2:
        raise ValueError(f"LOO needs at least 2 training points, got {n}")
    sq = 0.0
    for i in range(n):
        mask = np.ones(n, dtype=bool)
        mask[i] = False
        x_tr = x_samples[:, mask]
        y_tr = y_samples[mask]
        x_i = x_samples[:, i : i + 1]
        y_i = y_samples[i]
        pce = fit_pce_regression(poly_expansion, x_tr, y_tr)
        y_pred = float(predict_pce(pce, x_i).ravel()[0])
        sq += (y_i - y_pred) ** 2
    return float(np.sqrt(sq / n))
