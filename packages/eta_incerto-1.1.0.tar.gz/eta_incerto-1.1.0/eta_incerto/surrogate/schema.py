"""HDF5 layout versioning for surrogate-related artifacts."""

from __future__ import annotations

HDF5_SCHEMA_VERSION: int = 1


def tag_group_schema_version(group, version: int = HDF5_SCHEMA_VERSION) -> None:
    """Set schema_version on an h5py Group (idempotent for writers)."""
    group.attrs["schema_version"] = int(version)
