"""Moments and risk metrics from fitted surrogates (quadrature; Sobol TBD)."""

from __future__ import annotations

from typing import Any

import chaospy as cp
import numpy as np
from chaospy import generate_quadrature
from chaospy.distributions.baseclass import Distribution
from numpy import asarray


def pce_mean_nominal(pce_model: Any, distribution_data: Distribution) -> float:
    """Expectation of the fitted PCE under the modelled joint ``distribution_data``."""
    return float(cp.E(pce_model, distribution_data))


def pce_variance_nominal(pce_model: Any, distribution_data: Distribution) -> float:
    """Variance of the fitted PCE under the modelled joint ``distribution_data``."""
    try:
        return float(cp.Var(pce_model, distribution_data))
    except Exception:
        ex = float(cp.E(pce_model, distribution_data))
        ex2 = float(cp.E(pce_model**2, distribution_data))
        return max(0.0, ex2 - ex * ex)


def quadrature_nodes_weights(
    distribution_data: Distribution,
    quad_order: int,
    quad_rule: str,
) -> tuple[np.ndarray, np.ndarray]:
    """Return quadrature nodes and weights for ``distribution_data`` (stateless; no caching).

    For repeated UPR evaluations at fixed ``quad_order`` / ``quad_rule``, use
    :meth:`QuadratureUPRCache.quadrature_nodes_weights` instead.
    """
    return generate_quadrature(order=int(quad_order), dist=distribution_data, rule=str(quad_rule))


class QuadratureUPRCache:
    """Caches (nodes, weights) for repeated UPR evaluations at fixed quadrature rule."""

    def __init__(self) -> None:
        self._cache: dict[tuple[int, str], tuple[np.ndarray, np.ndarray]] = {}

    def quadrature_nodes_weights(
        self,
        distribution_data: Distribution,
        quad_order: int,
        quad_rule: str,
    ) -> tuple[np.ndarray, np.ndarray]:
        key = (int(quad_order), str(quad_rule))
        if key not in self._cache:
            self._cache[key] = quadrature_nodes_weights(distribution_data, quad_order, quad_rule)
        return self._cache[key]

    def upr_from_pce(
        self,
        pce_model: Any,
        distribution_data: Distribution,
        omega: float,
        quad_order: int,
        quad_rule: str,
    ) -> float:
        from eta_incerto.util.numba_stats import upr_from_y_weights

        nodes, weights = self.quadrature_nodes_weights(distribution_data, quad_order, quad_rule)
        y = asarray(pce_model(*nodes), dtype=float)
        return float(upr_from_y_weights(y, asarray(weights, dtype=float), float(omega)))
