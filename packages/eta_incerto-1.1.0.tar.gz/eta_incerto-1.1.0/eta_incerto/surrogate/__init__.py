"""Surrogate models and uncertainty propagation helpers (PCE-focused).

Public API (stable for downstream experiments; import from ``eta_incerto.surrogate``).

Includes :func:`quadrature_nodes_weights` for stateless quadrature; for caching, use
:class:`QuadratureUPRCache`.
"""

from __future__ import annotations

from eta_incerto.surrogate.diagnostics import (
    kfold_pce_rmse,
    leave_one_out_pce_rmse,
    root_mean_squared_error,
)
from eta_incerto.surrogate.feasible_sampling import (
    feasible_samples_chaospy_layout,
    normalize_distribution_sample_to_rows,
)
from eta_incerto.surrogate.moments import (
    QuadratureUPRCache,
    pce_mean_nominal,
    pce_variance_nominal,
    quadrature_nodes_weights,
)
from eta_incerto.surrogate.pce import (
    fit_pce_regression,
    fit_pce_regression_with_coefficients,
    generate_polynomial_expansion,
    predict_pce,
    training_sample_count,
)
from eta_incerto.surrogate.schema import HDF5_SCHEMA_VERSION, tag_group_schema_version
from eta_incerto.surrogate.sobol import pce_first_total_sobol

__all__ = [
    "HDF5_SCHEMA_VERSION",
    "QuadratureUPRCache",
    "feasible_samples_chaospy_layout",
    "fit_pce_regression",
    "fit_pce_regression_with_coefficients",
    "generate_polynomial_expansion",
    "kfold_pce_rmse",
    "leave_one_out_pce_rmse",
    "normalize_distribution_sample_to_rows",
    "pce_first_total_sobol",
    "pce_mean_nominal",
    "pce_variance_nominal",
    "predict_pce",
    "quadrature_nodes_weights",
    "root_mean_squared_error",
    "tag_group_schema_version",
    "training_sample_count",
]
