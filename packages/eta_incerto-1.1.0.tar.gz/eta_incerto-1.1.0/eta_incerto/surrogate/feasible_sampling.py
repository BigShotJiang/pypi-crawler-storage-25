"""Feasible and unconditional xi sampling layouts for chaospy regression."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from eta_incerto.util.sampling_feasibility import RejectionSamplerWithStats


def normalize_distribution_sample_to_rows(sample: np.ndarray, n: int) -> np.ndarray:
    """Map chaospy-style samples to shape (n, n_features) for batched xi rows.

    Chaospy often returns (dim, n) or other layouts; XiSampler expects first dim n.
    """
    n = int(n)
    s = np.asarray(sample, dtype=float)
    if s.ndim == 1:
        s = s.reshape(n, 1) if s.shape[0] == n else s.reshape(-1, n).T
    else:
        if s.shape[-1] == n and s.shape[0] != n:
            s = np.moveaxis(s, -1, 0)
        if s.shape[0] != n and s.shape[1] == n:
            s = s.T
        if s.shape[0] != n:
            raise ValueError(f"Unexpected sample shape {s.shape} for n={n}")
        s = s.reshape(n, -1)
    return s


def feasible_samples_chaospy_layout(
    sampler: RejectionSamplerWithStats,
    rng: np.random.Generator,
    n_samples: int,
    *,
    key: str,
) -> np.ndarray:
    """Draw feasible xi and return (n_dim, n_samples) for chaospy.fit_regression."""
    n_samples = int(n_samples)
    x_rows = sampler.draw_many(rng, n_samples, key=key)
    x_rows = np.asarray(x_rows, dtype=float)
    return x_rows.T
