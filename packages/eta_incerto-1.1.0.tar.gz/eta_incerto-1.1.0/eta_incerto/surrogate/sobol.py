"""Sobol' sensitivity indices for a PCE fit (variance decomposition on the expansion basis).

Indices are computed from regression coefficients with Chaospy's analytical formulas
(:func:`chaospy.FirstOrderSobol`, :func:`chaospy.TotalOrderSobol`). They describe
sensitivity of the **fitted surrogate** with respect to the **nominal independent
joint** used in :func:`eta_incerto.surrogate.generate_polynomial_expansion`, not the
feasible conditional law used for training samples.
"""

from __future__ import annotations

from typing import Any

import numpy as np
from chaospy import FirstOrderSobol, TotalOrderSobol


def pce_first_total_sobol(
    poly_expansion: Any,
    coefficients: np.ndarray,
    *,
    n_dim: int,
) -> tuple[np.ndarray, np.ndarray]:
    """
    First- and total-order Sobol' indices from PCE coefficients.

    Args:
        poly_expansion: Basis from ``generate_polynomial_expansion``.
        coefficients: Coefficient vector from ``fit_pce_regression(..., retall=True)``.
        n_dim: Stochastic dimension (number of uncertain inputs); used if variance is zero.

    Returns:
        (S1, ST) each shape ``(n_dim,)``.
    """
    coefficients = np.asarray(coefficients, dtype=float).ravel()
    n_dim = int(n_dim)
    zeros = np.zeros((n_dim,), dtype=float)
    if coefficients.size == 0 or n_dim <= 0:
        return zeros.copy(), zeros.copy()

    try:
        s1 = np.asarray(FirstOrderSobol(poly_expansion, coefficients), dtype=float).ravel()
        st = np.asarray(TotalOrderSobol(poly_expansion, coefficients), dtype=float).ravel()
    except Exception:
        return zeros.copy(), zeros.copy()

    if s1.shape != (n_dim,) or st.shape != (n_dim,):
        # Defensive reshape / truncate
        s1 = s1.reshape(-1)[:n_dim]
        st = st.reshape(-1)[:n_dim]
        if s1.size < n_dim:
            s1 = np.pad(s1, (0, n_dim - s1.size))
        if st.size < n_dim:
            st = np.pad(st, (0, n_dim - st.size))
    s1 = np.nan_to_num(s1, nan=0.0, posinf=0.0, neginf=0.0)
    st = np.nan_to_num(st, nan=0.0, posinf=0.0, neginf=0.0)
    return s1, st
