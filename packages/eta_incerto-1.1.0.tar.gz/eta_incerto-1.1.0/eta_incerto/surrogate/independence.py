"""Pairwise linear dependence diagnostics on $\\xi$ samples (Pearson correlation).

Polynomial chaos with a ``J(marginals)`` joint treats inputs as **independent** under the
nominal model law. **Feasibility rejection** reweights support and generally introduces
dependence in the **feasible** ensemble—use ``sample_space='feasible'`` to summarize what
the surrogate actually trains on. These metrics are **necessary but not sufficient** for
independence; large correlations flag further modelling review.
"""

from __future__ import annotations

from typing import Literal

import numpy as np


def pearson_correlation_matrix(xi: np.ndarray) -> np.ndarray:
    """Pearson correlation of uncertain parameters.

    Parameters
    ----------
    xi
        Chaospy layout ``(n_dim, n_samples)`` — one row per uncertain parameter.
    """
    xi = np.asarray(xi, dtype=float)
    if xi.ndim != 2:
        raise ValueError(f"xi must be 2D (n_dim, n_samples), got shape {xi.shape}")
    d, n = xi.shape
    if n < 2:
        raise ValueError(f"need at least 2 samples for correlation, got n={n}")
    if d < 1:
        raise ValueError("need at least one uncertain dimension")
    # variables as rows -> np.corrcoef(xi)
    return np.asarray(np.corrcoef(xi), dtype=float)


def max_abs_correlation_off_diagonal(corr: np.ndarray) -> float:
    c = np.asarray(corr, dtype=float)
    d = int(c.shape[0])
    if d < 2:
        return 0.0
    mask = ~np.eye(d, dtype=bool)
    return float(np.max(np.abs(c[mask])))


def independence_corr_status(
    max_abs_off_diagonal: float,
    threshold: float,
) -> Literal["below_threshold", "above_threshold"]:
    if max_abs_off_diagonal <= float(threshold):
        return "below_threshold"
    return "above_threshold"
