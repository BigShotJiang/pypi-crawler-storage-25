"""Polynomial chaos expansion: expansion, fit, predict (chaospy-backed)."""

from __future__ import annotations

from typing import Any

import numpy as np
from chaospy import (
    fit_regression as _fit_regression,
    generate_expansion as _generate_expansion,
)
from chaospy.distributions.baseclass import Distribution
from numpy import asarray


def generate_polynomial_expansion(order: int, dist: Distribution) -> Any:
    return _generate_expansion(order=int(order), dist=dist)


def training_sample_count(poly_expansion: Any, factor: int) -> int:
    """Training samples = max(factor * n_basis, 1)."""
    factor = int(factor)
    return max(factor * len(poly_expansion), 1)


def fit_pce_regression(poly_expansion: Any, samples: np.ndarray, responses: Any) -> Any:
    """Fit PCE via regression; samples are (n_dim, n_samples) chaospy layout."""
    return _fit_regression(poly_expansion, samples, responses)


def fit_pce_regression_with_coefficients(
    poly_expansion: Any,
    samples: np.ndarray,
    responses: Any,
) -> tuple[Any, np.ndarray]:
    """Same as :func:`fit_pce_regression` but also return regression coefficients (for Sobol' indices)."""
    model, coeffs = _fit_regression(poly_expansion, samples, responses, retall=True)
    return model, np.asarray(coeffs, dtype=float)


def predict_pce(pce_model: Any, evaluation_points: np.ndarray) -> np.ndarray:
    """Evaluate fitted PCE at chaospy-layout points (n_dim, n_points)."""
    return asarray(pce_model(*evaluation_points), dtype=float)
