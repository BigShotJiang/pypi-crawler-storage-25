"""Plausibilization module: validate optimization results against input data (no-storage systems)."""

from eta_incerto.plausibilization.result_types import FailureDetail, PlausibilizationResult
from eta_incerto.plausibilization.runner import run_plausibilization

__all__ = [
    "FailureDetail",
    "PlausibilizationResult",
    "run_plausibilization",
]
