"""Orchestration: load config, discover result files, run checks, aggregate result."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.plausibilization.cost_consistency import check_cost_consistency
from eta_incerto.plausibilization.energy_balance import check_energy_balance_no_storage
from eta_incerto.plausibilization.loaders import (
    get_typical_series_path,
    load_scenario_unit_price_by_year,
    load_traders_yearly_from_h5,
)
from eta_incerto.plausibilization.result_types import FailureDetail, PlausibilizationResult
from eta_incerto.util.io_utils import load_config

logger = logging.getLogger(__name__)

# Variants for which energy-balance (no-storage) check is applicable.
NO_STORAGE_VARIANTS = frozenset({"variant_zero"})


def _find_config_file(run_dir: Path) -> Path:
    for name in ("config.json", "config.yaml", "config.yml", "config.toml"):
        p = run_dir / name
        if p.exists():
            return p
    raise FileNotFoundError(f"No config file found in {run_dir}")


def _load_config_from_run_dir(run_dir: Path) -> ConfigOptimization:
    run_dir = Path(run_dir).resolve()
    if not run_dir.is_dir():
        raise NotADirectoryError(f"Run directory does not exist or is not a directory: {run_dir}")
    config_path = _find_config_file(run_dir)
    config_dict = load_config(config_path)
    # Ensure paths resolve against run_dir; if data_repo_root is missing, use run_dir
    config_dict.setdefault("paths", {})
    if config_dict["paths"].get("data_repo_root") is None:
        config_dict["paths"]["data_repo_root"] = str(run_dir)
    return ConfigOptimization.from_dict(config_dict, config_path.stem, run_dir)


def _discover_result_h5_files(results_dir: Path) -> list[Path]:
    if not results_dir.exists():
        return []
    return sorted(results_dir.glob("*.h5")) + sorted(results_dir.glob("*.hdf5"))


def _variant_from_result_filename(name: str) -> str | None:
    """Infer variant from result file name, e.g. stochastic_variant_zero.h5 -> variant_zero."""
    if "_variant_" not in name:
        return None
    base = name.replace(".h5", "").replace(".hdf5", "")
    return base.split("_variant_")[-1] if "_variant_" in base else None


def run_plausibilization(  # noqa: PLR0912
    run_dir: Path | str,
    *,
    atol: float = 1e-6,
    rtol: float = 1e-6,
) -> PlausibilizationResult:
    """
    Run plausibilization on all result HDF5 files in the run directory, per scenario from config.

    Loads config from run_dir (system.variant, scenario.scenario_file), discovers all
    *.h5/*.hdf5 in results/, and runs energy balance (no-storage only) and cost consistency
    for each file and each scenario. Returns PASS only if every check passes.

    :param run_dir: Path to the run directory (contains config.json, results/, series, scenario CSVs).
    :param atol: Absolute tolerance for numeric comparisons.
    :param rtol: Relative tolerance for numeric comparisons.
    :return: PlausibilizationResult with status PASS/FAIL and list of failure details.
    """
    run_dir = Path(run_dir).resolve()
    errors: list[FailureDetail] = []
    checks: dict[str, Any] = {}

    try:
        config = _load_config_from_run_dir(run_dir)
    except Exception as e:
        logger.exception("Failed to load config from %s", run_dir)
        errors.append(
            FailureDetail(
                failure_type="cost_consistency",
                message=f"Config load failed: {e}",
            )
        )
        return PlausibilizationResult(status="FAIL", errors=errors, checks=checks)

    variants = getattr(config.system, "variant", None)
    if isinstance(variants, str):
        variants = [variants]
    if not variants:
        variants = []

    scenario_files = getattr(config.scenario, "scenario_file", [])
    results_dir = config.paths.results_dir
    result_paths = _discover_result_h5_files(results_dir)
    checks["result_files"] = [str(p.name) for p in result_paths]
    checks["variants"] = list(variants)
    checks["scenarios"] = [sf.name for sf in scenario_files]

    if not result_paths:
        errors.append(
            FailureDetail(
                failure_type="cost_consistency",
                message="No result HDF5 files found in results directory",
                result_file=None,
            )
        )
        return PlausibilizationResult(
            status="FAIL",
            errors=errors,
            checks=checks,
        )

    typical_series_path = get_typical_series_path(config)
    if config.paths.data_repo_root:
        base_dir = config.paths.data_repo_root
    elif config.paths.results_dir:
        base_dir = config.paths.results_dir.parent
    else:
        base_dir = run_dir
    carrier_types = getattr(config.scenario, "carrier_types", ["gas", "electricity", "co2"])
    step_length = 1.0
    if hasattr(config, "series") and config.series.series_file:
        sf = config.series.series_file[0]
        step_length = float(getattr(sf, "step_length", 1.0))

    for h5_path in result_paths:
        variant = _variant_from_result_filename(h5_path.name) or (variants[0] if variants else None)
        import h5py

        with h5py.File(h5_path, "r") as f:
            for scen in scenario_files:
                scen_name = scen.name
                if scen_name not in f:
                    continue
                grp = f[scen_name]
                result_file_name = h5_path.name
                traders_yearly = load_traders_yearly_from_h5(grp)
                scenario_csv_path = Path(scen.path)
                if not scenario_csv_path.is_absolute():
                    scenario_csv_path = base_dir / scenario_csv_path
                if scenario_csv_path.exists():
                    unit_price_by_carrier = load_scenario_unit_price_by_year(scenario_csv_path, carrier_types)
                    cost_errors = check_cost_consistency(
                        traders_yearly,
                        unit_price_by_carrier,
                        result_file=result_file_name,
                        scenario=scen_name,
                        atol=atol,
                        rtol=rtol,
                    )
                    errors.extend(cost_errors)
                if variant and variant in NO_STORAGE_VARIANTS and typical_series_path:
                    energy_errors = check_energy_balance_no_storage(
                        typical_series_path,
                        grp,
                        variant,
                        result_file=result_file_name,
                        scenario=scen_name,
                        atol=atol,
                        rtol=rtol,
                        step_length=step_length,
                    )
                    errors.extend(energy_errors)

    status = "FAIL" if errors else "PASS"
    return PlausibilizationResult(status=status, errors=errors, checks=checks)
