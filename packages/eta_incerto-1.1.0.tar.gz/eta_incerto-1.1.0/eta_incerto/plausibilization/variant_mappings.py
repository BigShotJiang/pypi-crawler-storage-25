"""
Variant-specific mappings for energy balance: which demand series and which dispatch vars per carrier.

For each variant, we define:
- demand_series: dict[carrier_key, list[series_name]]  (series names in typical_series.h5)
- supply_var_patterns: dict[carrier_key, list[str]]  (var name substrings or full names to sum)
"""

from __future__ import annotations

# Carrier keys used in energy balance (heat = hnht+hnlt, cooling = cn, electricity)
CARRIER_HEAT = "heat"
CARRIER_COOLING = "cooling"
CARRIER_ELECTRICITY = "electricity"

# variant_zero: chp1, chp2, condensing_boiler (cb), cu (compression chiller)
# Heat: chp1/chp2 p_heat_out, p_waste_heat_out; cb p_heat_out
# Cooling: cu p_cool_out (stored as negative in model)
# Electricity: gas_supplier (gas), electricity_supplier (amount), chp1/chp2 p_el_out; demand/feed_in are sinks
VARIANT_ZERO_DEMAND_SERIES = {
    CARRIER_HEAT: ["hnht_consumer", "hnlt_consumer"],
    CARRIER_COOLING: ["cn_consumer"],
    CARRIER_ELECTRICITY: ["electricity_consumer"],
}

# Dispatch var names (unit_name__var_suffix as in bundle.vars / unit_dispatch)
VARIANT_ZERO_SUPPLY_VARS = {
    CARRIER_HEAT: [
        "chp1__p_heat_out",
        "chp1__p_waste_heat_out",
        "chp2__p_heat_out",
        "chp2__p_waste_heat_out",
        "condensing_boiler__p_heat_out",
    ],
    CARRIER_COOLING: [
        "cu__p_cool_out",  # negative in model = cooling out
    ],
    CARRIER_ELECTRICITY: [
        "electricity_supplier__amount",
        "chp1__p_el_out",
        "chp2__p_el_out",
        # electricity_consumer is demand (sink); electricity_feed_in is negative supply
    ],
}

VARIANT_MAPPINGS: dict[str, dict] = {
    "variant_zero": {
        "demand_series": VARIANT_ZERO_DEMAND_SERIES,
        "supply_vars": VARIANT_ZERO_SUPPLY_VARS,
    },
}


def get_demand_series_for_variant(variant: str) -> dict[str, list[str]]:
    """Return demand series names per carrier for the variant, or empty dict if unknown."""
    m = VARIANT_MAPPINGS.get(variant, {})
    return m.get("demand_series", {})


def get_supply_vars_for_variant(variant: str) -> dict[str, list[str]]:
    """Return list of dispatch var names to sum per carrier for the variant, or empty dict if unknown."""
    m = VARIANT_MAPPINGS.get(variant, {})
    return m.get("supply_vars", {})
