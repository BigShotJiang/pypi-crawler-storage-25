"""Result and failure types for plausibilization checks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

FailureType = Literal["energy_balance", "cost_consistency"]


@dataclass
class FailureDetail:
    """Single plausibilization failure with context and deviations."""

    failure_type: FailureType
    message: str
    result_file: str | None = None
    scenario: str | None = None
    carrier: str | None = None
    trader: str | None = None
    year: int | None = None
    timesteps: Any = None  # e.g. (year, period, time) or list of such
    expected: float | None = None
    actual: float | None = None
    abs_deviation: float | None = None
    rel_deviation: float | None = None

    def format_message(self) -> str:
        parts = [f"[{self.failure_type}] {self.message}"]
        if self.result_file:
            parts.append(f"result_file={self.result_file}")
        if self.scenario:
            parts.append(f"scenario={self.scenario}")
        if self.carrier is not None:
            parts.append(f"carrier={self.carrier}")
        if self.trader is not None:
            parts.append(f"trader={self.trader}")
        if self.year is not None:
            parts.append(f"year={self.year}")
        if self.timesteps is not None:
            parts.append(f"timesteps={self.timesteps}")
        if self.expected is not None:
            parts.append(f"expected={self.expected}")
        if self.actual is not None:
            parts.append(f"actual={self.actual}")
        if self.abs_deviation is not None:
            parts.append(f"abs_deviation={self.abs_deviation}")
        if self.rel_deviation is not None:
            parts.append(f"rel_deviation={self.rel_deviation}")
        return " ".join(parts)


@dataclass
class PlausibilizationResult:
    """Aggregate result of plausibilization over all result files and scenarios."""

    status: Literal["PASS", "FAIL"]
    errors: list[FailureDetail] = field(default_factory=list)
    checks: dict[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return self.status == "PASS"

    def format_errors(self) -> str:
        if not self.errors:
            return ""
        return "\n".join(e.format_message() for e in self.errors)
