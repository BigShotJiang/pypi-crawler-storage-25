"""CLI entry point: python -m eta_incerto.plausibilization --run-dir <path> [--atol] [--rtol]."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from eta_incerto.plausibilization import run_plausibilization


def main() -> int:
    parser = argparse.ArgumentParser(description="Plausibilize optimization results (no-storage systems).")
    parser.add_argument(
        "--run-dir",
        type=Path,
        required=True,
        help="Run directory with config.json, results/, and scenario CSVs.",
    )
    parser.add_argument("--atol", type=float, default=1e-6, help="Absolute tolerance for numeric checks.")
    parser.add_argument("--rtol", type=float, default=1e-6, help="Relative tolerance for numeric checks.")
    args = parser.parse_args()
    result = run_plausibilization(args.run_dir, atol=args.atol, rtol=args.rtol)
    if result.format_errors():
        sys.stderr.write(result.format_errors() + "\n")
    sys.stdout.write(result.status + "\n")
    return 0 if result.passed else 1


if __name__ == "__main__":
    sys.exit(main())
