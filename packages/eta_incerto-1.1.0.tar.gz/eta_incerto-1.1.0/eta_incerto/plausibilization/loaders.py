"""Load typical_series, unit_dispatch, scenario CSV from run directory (avoids shadowing stdlib io)."""

from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import xarray as xr

from eta_incerto.config.config import ConfigOptimization


def load_typical_series_h5(typical_series_path: Path) -> dict[str, pd.DataFrame]:
    """
    Load typical_series.h5 written by TypicalData.data_to_periods().

    Each key is a series name (e.g. electricity_consumer, hnht_consumer); value is a
    DataFrame with MultiIndex (period, step) and one column (the inner key, e.g. P_in).
    Returns dict mapping series_name -> DataFrame (index = (period, step), one column).
    """
    out: dict[str, pd.DataFrame] = {}
    with pd.HDFStore(typical_series_path, mode="r") as store:
        for key in store:
            name = key.lstrip("/")
            frame = store[key]
            out[name] = frame
    return out


def load_typical_series_demand(
    typical_series_path: Path,
    demand_series_names: list[str],
) -> dict[str, xr.DataArray]:
    """
    Load demand arrays from typical_series.h5 for the given series names.

    Returns dict series_name -> DataArray with dims (period, step), values = demand (use abs for consumption).
    """
    raw = load_typical_series_h5(typical_series_path)
    result: dict[str, xr.DataArray] = {}
    for name in demand_series_names:
        if name not in raw:
            continue
        frame = raw[name]
        if frame.index.names != ["period", "step"]:
            frame = frame.copy()
            frame.index.names = ["period", "step"]
        # Single column (e.g. P_in); take absolute value for demand magnitude
        demand_series = frame.iloc[:, 0].abs()
        unstacked = demand_series.unstack()  # noqa: PD010
        periods = unstacked.index.tolist()
        steps = unstacked.columns.tolist()
        result[name] = xr.DataArray(
            unstacked.values,
            dims=["period", "step"],
            coords={"period": periods, "step": steps},
        )
    return result


def _parse_dispatch_keys(keys_ds: np.ndarray) -> list[tuple]:
    parsed = []
    for k in keys_ds:
        s = k if isinstance(k, str) else k.decode("utf-8")
        try:
            t = ast.literal_eval(s)
            parsed.append(t)
        except (ValueError, SyntaxError):
            continue
    return parsed


def load_unit_dispatch_from_h5(  # noqa: PLR0912
    grp,
    unit_name: str,
    var_suffix: str,
    dim_names: tuple[str, ...] = ("year", "period", "time"),
) -> xr.DataArray | None:
    """
    Reconstruct a single variable from unit_dispatch in result HDF5.

    grp: scenario group (e.g. f["S1"]) so that grp["unit_dispatch"] exists.
    unit_name: e.g. "chp1"
    var_suffix: part after unit_name__ in var name, e.g. "amount" or "P_heat_out"
    dim_names: dimension names for the reconstructed array.

    Returns DataArray with coords from parsed keys, or None if not found.
    """
    ud = grp.get("unit_dispatch")
    if ud is None:
        return None
    units = ud.get("units")
    if units is None:
        return None
    ugrp = units.get(unit_name)
    if ugrp is None:
        return None
    # short_component may have / replaced by _; try var_suffix and var_suffix with dim suffix
    comp_name = var_suffix.replace("/", "_")
    comp_grp = ugrp.get(comp_name)
    if comp_grp is None:
        for k in ugrp:
            if k.startswith(comp_name):
                comp_grp = ugrp[k]
                break
    if comp_grp is None:
        return None
    keys_ds = comp_grp["keys"]
    values_ds = comp_grp["values"]
    keys_arr = np.asarray(keys_ds)
    values_arr = np.asarray(values_ds)
    parsed = _parse_dispatch_keys(keys_arr)
    if not parsed:
        return None
    ndim = len(parsed[0]) if parsed else 0
    if ndim != len(dim_names):
        dim_names = tuple(f"dim_{i}" for i in range(ndim))
    unique_coords: list[list[Any]] = [[] for _ in range(ndim)]
    for t in parsed:
        for i, v in enumerate(t):
            if v not in unique_coords[i]:
                unique_coords[i].append(v)
    for i in range(ndim):
        unique_coords[i].sort()
    shape = tuple(len(u) for u in unique_coords)
    arr = np.full(shape, np.nan)
    coord_to_idx = [{c: j for j, c in enumerate(unique_coords[i])} for i in range(ndim)]
    for t, val in zip(parsed, values_arr.ravel(), strict=False):
        idx = tuple(coord_to_idx[i].get(t[i]) for i in range(ndim))
        if all(i is not None for i in idx):
            arr[idx] = val
    coords = {dim_names[i]: unique_coords[i] for i in range(ndim)}
    return xr.DataArray(arr, dims=list(dim_names), coords=coords)


def _walk_unit_dispatch(grp, prefix: str = "") -> dict[str, tuple[np.ndarray, np.ndarray]]:
    out: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    ud = grp.get("unit_dispatch")
    if ud is None:
        return out
    units = ud.get("units")
    if units is None:
        return out
    for unit_name in units:
        ugrp = units[unit_name]
        for comp_name in ugrp:
            comp_grp = ugrp[comp_name]
            if "keys" not in comp_grp or "values" not in comp_grp:
                continue
            full_name = f"{unit_name}__{comp_name}"
            keys_arr = np.asarray(comp_grp["keys"])
            vals_arr = np.asarray(comp_grp["values"])
            out[full_name] = (keys_arr, vals_arr)
    return out


def load_unit_dispatch_flat(
    grp,
    dim_names: tuple[str, ...] = ("year", "period", "time"),
) -> dict[str, xr.DataArray]:
    """
    Load all unit_dispatch vars from scenario group, reconstructing DataArrays from keys/values.
    """
    raw = _walk_unit_dispatch(grp)
    result: dict[str, xr.DataArray] = {}
    for var_name, (keys_arr, values_arr) in raw.items():
        parsed = _parse_dispatch_keys(keys_arr)
        if not parsed:
            continue
        ndim = len(parsed[0])
        dnames = dim_names if ndim == len(dim_names) else tuple(f"dim_{i}" for i in range(ndim))
        unique_coords = [[] for _ in range(ndim)]
        for t in parsed:
            for i, v in enumerate(t):
                if v not in unique_coords[i]:
                    unique_coords[i].append(v)
        for i in range(ndim):
            unique_coords[i].sort()
        shape = tuple(len(u) for u in unique_coords)
        arr = np.full(shape, np.nan)
        coord_to_idx = [{c: j for j, c in enumerate(unique_coords[i])} for i in range(ndim)]
        for t, val in zip(parsed, values_arr.ravel(), strict=False):
            idx = tuple(coord_to_idx[i].get(t[i]) for i in range(ndim))
            if all(i is not None for i in idx):
                arr[idx] = val
        coords = {dnames[i]: unique_coords[i] for i in range(ndim)}
        result[var_name] = xr.DataArray(arr, dims=list(dnames), coords=coords)
    return result


def load_scenario_unit_price_by_year(path: Path, carrier_types: list[str]) -> dict[str, dict[int, float]]:
    """
    Load scenario CSV; return carrier -> {year: unit_price}.
    Expects two-row header: (carrier_type, year), (gas, unit_price), (gas, emissions_per_unit), ...
    Rows = years 1, 2, ...
    """
    scenario_table = pd.read_csv(path, header=[0, 1])
    first_col = scenario_table.columns[0]
    if first_col == ("carrier_type", "year") or scenario_table.columns[0][0] == "carrier_type":
        scenario_table = scenario_table.set_index(scenario_table.columns[0])
    out: dict[str, dict[int, float]] = {c: {} for c in carrier_types}
    for col in scenario_table.columns:
        if not isinstance(col, tuple) or len(col) != 2:
            continue
        carrier, metric = col[0], col[1]
        if metric != "unit_price" or carrier not in carrier_types:
            continue
        for year in scenario_table.index:
            try:
                out[carrier][int(year)] = float(scenario_table.loc[year, col])
            except (KeyError, TypeError, ValueError):
                pass
    return out


def load_traders_yearly_from_h5(grp) -> dict[str, dict[str, dict[int, float]]]:
    """
    Read technical/traders_yearly from a scenario group (JSON serialized).
    Returns dict trader_name -> {Quantity_kWh_per_year: {year: float}, Costs_per_year: {year: float}, ...}.
    """
    tech = grp.get("technical")
    if tech is None:
        return {}
    if "traders_yearly" not in tech:
        return {}
    dset = tech["traders_yearly"]
    raw = dset[()]
    if hasattr(raw, "decode"):
        raw = raw.decode("utf-8")
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")
    return json.loads(raw)


def get_typical_series_path(config: ConfigOptimization) -> Path | None:
    """Return path to typical_series.h5 from config, or None if not present."""
    series_dir = getattr(config.paths, "series_dir", None)
    if series_dir is None:
        return None
    series_file = getattr(config.series, "series_file", [])
    if not series_file:
        return None
    sf = series_file[0]
    file_name = getattr(sf, "file_name", "series")
    path = (Path(series_dir) / file_name / "typical_series.h5").resolve()
    return path if path.exists() else None
