from __future__ import annotations

import json
import os
import time
from logging import getLogger
from pathlib import Path
from typing import Any

import h5py
import numpy as np
from chaospy.distributions.baseclass import Distribution
from eta_components.milp_component_library.exceptions import InfeasibleProblemError
from joblib import Parallel, delayed
from pydantic import BaseModel, ConfigDict, Field
from pymoo.optimize import minimize

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.envs.antifragile import AntifragileProblem, AntifragileRuntime
from eta_incerto.envs.model import Model
from eta_incerto.surrogate import (
    QuadratureUPRCache,
    feasible_samples_chaospy_layout,
    fit_pce_regression_with_coefficients,
    generate_polynomial_expansion,
    leave_one_out_pce_rmse,
    normalize_distribution_sample_to_rows,
    pce_first_total_sobol,
    pce_mean_nominal,
    pce_variance_nominal,
    predict_pce,
    tag_group_schema_version,
    training_sample_count,
)
from eta_incerto.surrogate.independence import (
    independence_corr_status,
    max_abs_correlation_off_diagonal,
    pearson_correlation_matrix,
)
from eta_incerto.uncertainty.marginal_export import (
    marginal_record_from_chaospy,
    marginal_record_from_variable_spec,
)
from eta_incerto.util.h5_config import save_config_to_h5
from eta_incerto.util.numba_stats import skew_moment, upr_from_y_weights
from eta_incerto.util.sampling_feasibility import (
    FeasibilityConstraint,
    RejectionSamplerWithStats,
    XiSampler,
)

log = getLogger(__name__)


class AntifragileEvaluator(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: ConfigOptimization = Field(..., description="Optimization config from central config.json")
    h5_file_name: str
    model_builder: Model = Field(..., description="Model to use for evaluation")
    distribution_data: Distribution = Field(..., description="Distribution of input parameters")
    variable_names: str | list[str]
    objective_names: str | list[str]
    variant_name: str

    normalize: bool = False
    obj_min: np.ndarray | None = None
    obj_max: np.ndarray | None = None

    problem: AntifragileProblem | None = None

    _xi_sampler: RejectionSamplerWithStats | None = None
    _xi_key: str = "xi"
    _phase_time_totals: dict[str, float] | None = None
    _phase_counts: dict[str, int] | None = None
    _objective_history: list[np.ndarray] | None = None
    _effective_omega_history: list[float] | None = None
    _pce_loo_initial_rmses: list[float] | None = None
    _pce_loo_objective_eval_indices: list[int] | None = None

    def model_post_init(self, __context: Any, /) -> None:
        pdef = self.config.pymoo.for_variant(self.variant_name)
        self.normalize = bool(pdef.normalize)
        self.obj_min = np.asarray(pdef.obj_min, dtype=float) if getattr(pdef, "obj_min", None) is not None else None
        self.obj_max = np.asarray(pdef.obj_max, dtype=float) if getattr(pdef, "obj_max", None) is not None else None

        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        dt_min = float(getattr(eval_cfg, "feasibility_dt_min", 1e-6))
        batch_size = int(getattr(eval_cfg, "feasibility_batch_size", 256))
        max_rounds = int(getattr(eval_cfg, "feasibility_max_rounds", 200))

        def _draw_fn(n: int, rng: np.random.Generator) -> dict[str, np.ndarray]:
            n = int(n)
            # deterministic seed taken from your Generator
            seed = int(rng.integers(0, 2**32 - 1, dtype=np.uint32))
            rule = self.config.evaluate.for_variant(self.variant_name).pce_rule

            s = self.distribution_data.sample(size=n, rule=rule, seed=seed)

            s = np.asarray(s, dtype=float)
            s = normalize_distribution_sample_to_rows(s, n)
            return {self._xi_key: s}

        base = XiSampler(draw_fn=_draw_fn)
        constraint = FeasibilityConstraint(self.model_builder, dt_min=dt_min, xi_key=self._xi_key)

        self._xi_sampler = RejectionSamplerWithStats(
            base=base,
            constraint=constraint,
            max_rounds=max_rounds,
            batch_size=batch_size,
        )
        self._phase_time_totals = {
            "sampling_s": 0.0,
            "simulation_s": 0.0,
            "fit_s": 0.0,
            "stats_s": 0.0,
            "pce_loo_s": 0.0,
        }
        self._phase_counts = {"objective_evals": 0}
        self._objective_history = []
        self._effective_omega_history = []
        self._pce_loo_initial_rmses = []
        self._pce_loo_objective_eval_indices = []
        self._quadrature_upr_cache = QuadratureUPRCache()

        # Problem is built in evaluate_systems() with inline PCE evaluation.

    def _add_phase_time(self, key: str, elapsed_s: float) -> None:
        if self._phase_time_totals is None:
            self._phase_time_totals = {}
        self._phase_time_totals[key] = float(self._phase_time_totals.get(key, 0.0) + float(elapsed_s))

    def _inc_counter(self, key: str) -> None:
        if self._phase_counts is None:
            self._phase_counts = {}
        self._phase_counts[key] = int(self._phase_counts.get(key, 0) + 1)

    def _append_pce_loo_initial(self, rmse: float) -> None:
        if self._pce_loo_initial_rmses is None:
            self._pce_loo_initial_rmses = []
        if self._pce_loo_objective_eval_indices is None:
            self._pce_loo_objective_eval_indices = []
        idx = int(self._phase_counts.get("objective_evals", 0)) if self._phase_counts else 0
        self._pce_loo_initial_rmses.append(float(rmse))
        self._pce_loo_objective_eval_indices.append(idx)
        self._inc_counter("pce_loo_calls")

    @staticmethod
    def _safe_get_private(obj: Any, attr_name: str, default: Any = None) -> Any:
        """Read private attrs safely for lightweight test stubs built via object.__new__."""
        try:
            return getattr(obj, attr_name)
        except AttributeError:
            return default

    def get_phase_timing_summary(self) -> dict[str, float | int]:
        totals = dict(self._phase_time_totals or {})
        counts = dict(self._phase_counts or {})
        objective_evals = int(counts.get("objective_evals", 0))
        out: dict[str, float | int] = {**totals, **counts}
        if objective_evals > 0:
            for key in ("sampling_s", "simulation_s", "fit_s", "stats_s"):
                out[f"avg_{key}"] = float(totals.get(key, 0.0) / objective_evals)
        n_loo = int(counts.get("pce_loo_calls", 0))
        if n_loo > 0:
            out["avg_pce_loo_s"] = float(totals.get("pce_loo_s", 0.0) / n_loo)
        return out

    @staticmethod
    def _resolve_parallel_workers(
        eval_cfg: Any,
        *,
        requested_n_jobs: int | None = None,
        n_tasks: int | None = None,
    ) -> int:
        cpu = max(1, int(os.cpu_count() or 1))
        requested = getattr(eval_cfg, "n_workers", None)
        if requested is None:
            requested = int(getattr(eval_cfg, "n_jobs", 1) if requested_n_jobs is None else requested_n_jobs)
        requested = int(requested)
        if requested < 0:
            requested = cpu
        if requested == 0:
            requested = 1

        strategy = str(getattr(eval_cfg, "parallel_strategy", "safe")).lower()
        max_workers = getattr(eval_cfg, "max_parallel_workers", None)
        if max_workers is not None:
            cap = max(1, int(max_workers))
        elif strategy == "safe":
            cap = max(1, min(4, cpu // 2 if cpu > 2 else 1))
        else:
            cap = cpu

        workers = max(1, min(requested, cap))
        if n_tasks is not None:
            workers = max(1, min(workers, int(n_tasks)))
        return workers

    # ----------------------------
    # Feasibility metadata (persist to HDF5)
    # ----------------------------
    def _feasibility_metadata(self) -> dict[str, Any]:
        if self._xi_sampler is None:
            return {}

        n_drawn = int(getattr(self._xi_sampler, "n_drawn", 0))
        n_rejected = int(getattr(self._xi_sampler, "n_rejected", 0))
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        return {
            "n_drawn": n_drawn,
            "n_rejected": n_rejected,
            "rejection_rate": float(n_rejected / max(n_drawn, 1)),
            "dt_min": float(getattr(eval_cfg, "feasibility_dt_min", 1e-6)),
            "batch_size": int(getattr(eval_cfg, "feasibility_batch_size", 256)),
            "max_rounds": int(getattr(eval_cfg, "feasibility_max_rounds", 200)),
        }

    def _objective_name_list(self) -> list[str]:
        if isinstance(self.objective_names, str):
            return [self.objective_names]
        return list(self.objective_names)

    @staticmethod
    def _non_dominated_count(fvals: np.ndarray) -> int:
        arr = np.asarray(fvals, dtype=float)
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        n = int(arr.shape[0])
        if n == 0:
            return 0
        is_nd = np.ones((n,), dtype=bool)
        for i in range(n):
            if not is_nd[i]:
                continue
            for j in range(n):
                if i == j:
                    continue
                if np.all(arr[j] <= arr[i]) and np.any(arr[j] < arr[i]):
                    is_nd[i] = False
                    break
        return int(np.sum(is_nd))

    @staticmethod
    def _unique_rows_count(values: np.ndarray) -> int:
        arr = np.asarray(values, dtype=float)
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        if arr.shape[0] == 0:
            return 0
        return int(np.unique(arr, axis=0).shape[0])

    @staticmethod
    def _non_dominated_indices(fvals: np.ndarray) -> np.ndarray:
        arr = np.asarray(fvals, dtype=float)
        if arr.ndim == 1:
            arr = arr.reshape(-1, 1)
        n = int(arr.shape[0])
        if n == 0:
            return np.array([], dtype=int)
        is_nd = np.ones((n,), dtype=bool)
        for i in range(n):
            if not is_nd[i]:
                continue
            for j in range(n):
                if i == j:
                    continue
                if np.all(arr[j] <= arr[i]) and np.any(arr[j] < arr[i]):
                    is_nd[i] = False
                    break
        return np.flatnonzero(is_nd).astype(int)

    def _validate_search_budget(self) -> None:
        pdef = self.config.pymoo.for_variant(self.variant_name)
        n_obj = len(list(getattr(pdef, "objective_names", self._objective_name_list())))
        pop_size = int(self.config.algorithm.pop_size)
        if pop_size < n_obj:
            raise ValueError(
                f"Invalid antifragile setup for {self.variant_name}: pop_size={pop_size} < "
                f"n_objectives={n_obj}. Increase algorithm.pop_size to at least {n_obj}."
            )

        term = self.config.termination
        method = str(term.method).lower()
        value = int(term.value)
        if method == "n_eval":
            if value < pop_size:
                raise ValueError(
                    f"Invalid antifragile termination for {self.variant_name}: n_eval={value} < pop_size={pop_size}. "
                    "Increase termination.value."
                )
            if value < 2 * pop_size:
                log.warning(
                    "Antifragile run has low search depth for %s: n_eval=%s, pop_size=%s "
                    "(<2 generations). Pareto front may degenerate.",
                    self.variant_name,
                    value,
                    pop_size,
                )
        elif method == "n_gen" and value < 2:
            log.warning(
                "Antifragile run has n_gen=%s for %s (<2 generations). Pareto front may degenerate.",
                value,
                self.variant_name,
            )

    @staticmethod
    def _resolve_effective_omega(
        y: np.ndarray,
        *,
        mode: str,
        stat_omega: float,
        omega_quantile: float,
        omega_shift: float,
    ) -> float:
        mode_l = str(mode or "fixed").lower()
        if mode_l == "quantile":
            return float(np.quantile(np.asarray(y, dtype=float), float(omega_quantile)))
        if mode_l == "median_anchor":
            return float(np.median(np.asarray(y, dtype=float)) + float(omega_shift))
        return float(stat_omega)

    def _objective_diagnostics(self) -> dict[str, Any]:
        rows = np.asarray(self._objective_history or [], dtype=float)
        if rows.size == 0:
            return {}
        if rows.ndim == 1:
            rows = rows.reshape(1, -1)
        out: dict[str, Any] = {"n_objective_evals": int(rows.shape[0])}
        names = self._objective_name_list()
        for idx in range(rows.shape[1]):
            key = names[idx] if idx < len(names) else f"obj_{idx}"
            col = rows[:, idx]
            out[f"{key}__min"] = float(np.min(col))
            out[f"{key}__max"] = float(np.max(col))
            out[f"{key}__std"] = float(np.std(col))
        omegas = np.asarray(self._effective_omega_history or [], dtype=float)
        if omegas.size > 0:
            out["omega_effective_min"] = float(np.min(omegas))
            out["omega_effective_max"] = float(np.max(omegas))
            out["omega_effective_mean"] = float(np.mean(omegas))
        return out

    # ----------------------------
    # Core eval
    # ----------------------------
    def _simulate(self, x: np.ndarray, xi: np.ndarray) -> float:
        try:
            return float(self.model_builder.build_simulate_model(x, xi))
        except InfeasibleProblemError:
            # großer Wert = "schlecht" (weil du median etc. minimierst/transformierst)
            return float(self.config.pymoo.penalty)

    def _simulate_many(self, x: np.ndarray, xi_batch: np.ndarray, batch_size: int | None = None) -> np.ndarray:
        xi_batch = np.asarray(xi_batch, dtype=float)
        if xi_batch.ndim != 2:
            raise ValueError(f"Expected xi_batch with 2 dims, got shape {xi_batch.shape}.")

        n_rows = xi_batch.shape[0]
        if not batch_size or batch_size <= 0 or batch_size >= n_rows:
            return self._simulate_many_once(x, xi_batch)

        y = np.empty((n_rows,), dtype=float)
        for start in range(0, n_rows, batch_size):
            end = min(start + batch_size, n_rows)
            chunk = xi_batch[start:end]
            y_chunk = self._simulate_many_once(x, chunk)
            if y_chunk.shape[0] != chunk.shape[0]:
                raise ValueError(
                    f"Vectorized evaluation returned unexpected shape: {y_chunk.shape} for inputs {chunk.shape}."
                )
            y[start:end] = y_chunk
        return y

    def _simulate_many_once(self, x: np.ndarray, xi_batch: np.ndarray) -> np.ndarray:
        try:
            y = self.model_builder.build_simulate_model(x, xi_batch)
            y = np.asarray(y, dtype=float)
            if y.ndim == 0:
                y = np.full((xi_batch.shape[0],), float(y))
            return y
        except InfeasibleProblemError:
            return np.full((xi_batch.shape[0],), float(self.config.pymoo.penalty))

    def _draw_feasible_samples(self, n_samples: int) -> np.ndarray:
        """
        Returns samples shaped (n_dim, n_samples) for chaospy.fit_regression.
        """
        if self._xi_sampler is None:
            raise RuntimeError("Feasibility sampler not initialized.")

        rng = np.random.default_rng(self.config.pymoo.seed)
        return feasible_samples_chaospy_layout(self._xi_sampler, rng, int(n_samples), key=self._xi_key)

    def build_pce_surrogate(
        self,
        x: np.ndarray,
        distribution_data: Distribution,
        pce_rule: int,
        pce_order: int,
        n_jobs: int,
        backend: str,
        vectorized: bool,
        vectorized_batch_size: int | None,
        *,
        pymoo_n_gen: int | None = None,
        return_expansion_coeffs: bool = False,
    ):
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        overrides = {}
        if getattr(eval_cfg, "solver_mipgap_override", None) is not None:
            overrides["mipgap"] = float(eval_cfg.solver_mipgap_override)
        if getattr(eval_cfg, "solver_timelimit_override", None) is not None:
            overrides["timelimit"] = float(eval_cfg.solver_timelimit_override)
        self.model_builder._solver_options_override = overrides if overrides else None
        try:
            return self._build_pce_surrogate_impl(
                x=x,
                distribution_data=distribution_data,
                pce_rule=pce_rule,
                pce_order=pce_order,
                n_jobs=n_jobs,
                backend=backend,
                vectorized=vectorized,
                vectorized_batch_size=vectorized_batch_size,
                pymoo_n_gen=pymoo_n_gen,
                return_expansion_coeffs=return_expansion_coeffs,
            )
        finally:
            self.model_builder._solver_options_override = None

    def _build_pce_surrogate_impl(
        self,
        x: np.ndarray,
        distribution_data: Distribution,
        pce_rule: int,
        pce_order: int,
        n_jobs: int,
        backend: str,
        vectorized: bool,
        vectorized_batch_size: int | None,
        *,
        pymoo_n_gen: int | None = None,
        return_expansion_coeffs: bool = False,
    ):
        poly_exp = generate_polynomial_expansion(pce_order, distribution_data)
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        factor = int(getattr(eval_cfg, "pce_sample_factor", 4))
        n_samples = training_sample_count(poly_exp, factor)
        effective_n_jobs = self._resolve_parallel_workers(eval_cfg, requested_n_jobs=n_jobs, n_tasks=n_samples)

        # IMPORTANT: draw feasible samples (conditional distribution)
        t_sampling = time.perf_counter()
        samples = self._draw_feasible_samples(n_samples)
        self._add_phase_time("sampling_s", time.perf_counter() - t_sampling)
        y_vals = None
        if vectorized:
            xi_batch = samples.T
            n_rows = xi_batch.shape[0]
            chunk_size = (
                vectorized_batch_size if vectorized_batch_size and 0 < vectorized_batch_size < n_rows else n_rows
            )
            n_chunks = max(1, (n_rows + chunk_size - 1) // chunk_size)
            allow_parallel_chunks = bool(getattr(eval_cfg, "vectorized_parallel_chunks", False))
            use_parallel_chunks = allow_parallel_chunks and n_chunks > 1 and effective_n_jobs != 1
            t_sim = time.perf_counter()
            try:
                if use_parallel_chunks:
                    chunks = [xi_batch[start : start + chunk_size] for start in range(0, n_rows, chunk_size)]
                    chunk_jobs = max(1, min(effective_n_jobs, len(chunks)))
                    chunk_results = Parallel(n_jobs=chunk_jobs, backend=backend)(
                        delayed(self._simulate_many_once)(x, chunk) for chunk in chunks
                    )
                    y_vals = np.concatenate(chunk_results)
                else:
                    y_vals = self._simulate_many(x, xi_batch, batch_size=vectorized_batch_size)
            except Exception as exc:
                log.warning("Vectorized evaluation failed; falling back to scalar loop.", exc_info=exc)
                y_vals = None
            finally:
                self._add_phase_time("simulation_s", time.perf_counter() - t_sim)

        if y_vals is None:
            strategy = str(getattr(eval_cfg, "parallel_strategy", "safe")).lower()
            scalar_jobs = 1 if strategy == "sequential_fallback" else effective_n_jobs
            t_sim = time.perf_counter()
            if scalar_jobs == 1:
                y_vals = [self._simulate(x, samples[:, i]) for i in range(samples.shape[1])]
            else:
                y_vals = Parallel(n_jobs=scalar_jobs, backend=backend)(
                    delayed(self._simulate)(x, samples[:, i]) for i in range(samples.shape[1])
                )
            self._add_phase_time("simulation_s", time.perf_counter() - t_sim)

        y_arr = np.asarray(y_vals, dtype=float).ravel()
        t_fit = time.perf_counter()
        model, coeffs = fit_pce_regression_with_coefficients(poly_exp, samples, y_vals)
        self._add_phase_time("fit_s", time.perf_counter() - t_fit)

        loo_enabled = bool(getattr(eval_cfg, "pce_loo_initial_generation_enabled", False))
        loo_target_gen = int(getattr(eval_cfg, "pce_loo_initial_generation_n_gen", 1))
        if loo_enabled and pymoo_n_gen is not None and int(pymoo_n_gen) == loo_target_gen and y_arr.shape[0] >= 2:
            t_loo = time.perf_counter()
            loo_rmse = leave_one_out_pce_rmse(poly_exp, samples, y_arr)
            self._add_phase_time("pce_loo_s", time.perf_counter() - t_loo)
            self._append_pce_loo_initial(loo_rmse)
            log.info("PCE leave-one-out RMSE (pymoo n_gen=%s): %.6g", pymoo_n_gen, loo_rmse)

        if return_expansion_coeffs:
            return model, poly_exp, coeffs
        return model

    def upr_from_distribution(
        self,
        pce_model,
        distribution_data: Distribution,
        omega: float,
        quad_order: int,
        quad_rule: str,
    ) -> float:
        return self._quadrature_upr_cache.upr_from_pce(
            pce_model,
            distribution_data,
            omega,
            quad_order,
            quad_rule,
        )

    def _evaluate_config_for_variant(self):
        try:
            return self.config.evaluate.for_variant(self.variant_name)
        except Exception:
            return None

    def evaluate_statistics(
        self,
        pce_model,
        distribution_data: Distribution,
        stat_n_mc: int,
        stat_omega: float,
        omega_mode: str,
        omega_quantile: float,
        omega_anchor_shift: float,
        stat_rule: str,
        quad_order: int,
        quad_rule: str,
    ) -> tuple[np.ndarray, float]:
        eval_cfg = self._evaluate_config_for_variant()
        mode = getattr(eval_cfg, "objective_stat_mode", "mc_median_skew_upr") if eval_cfg else "mc_median_skew_upr"

        if mode == "mc_median_skew_upr":
            samples = self._draw_feasible_samples(stat_n_mc)
            y = np.asarray(predict_pce(pce_model, samples), dtype=float).ravel()
            med = float(np.median(y))
            skewness = float(skew_moment(y))
            effective_omega = self._resolve_effective_omega(
                y,
                mode=omega_mode,
                stat_omega=stat_omega,
                omega_quantile=omega_quantile,
                omega_shift=omega_anchor_shift,
            )
            n_samples = int(max(1, y.shape[0]))
            weights = np.full((n_samples,), 1.0 / n_samples, dtype=float)
            upr = float(upr_from_y_weights(y, weights, float(effective_omega)))
            return np.asarray([med, -skewness, -upr], dtype=float), float(effective_omega)

        if mode == "pce_mean_var_upr":
            moment_ref = getattr(eval_cfg, "moment_reference", "nominal") if eval_cfg else "nominal"
            if moment_ref == "nominal":
                mean = float(pce_mean_nominal(pce_model, distribution_data))
                variance = float(pce_variance_nominal(pce_model, distribution_data))
                x_cal = distribution_data.sample(int(stat_n_mc), rule=str(stat_rule))
                y_cal = np.asarray(predict_pce(pce_model, x_cal), dtype=float).ravel()
                effective_omega = self._resolve_effective_omega(
                    y_cal,
                    mode=omega_mode,
                    stat_omega=stat_omega,
                    omega_quantile=omega_quantile,
                    omega_shift=omega_anchor_shift,
                )
                upr = float(
                    self.upr_from_distribution(
                        pce_model,
                        distribution_data,
                        float(effective_omega),
                        quad_order,
                        quad_rule,
                    )
                )
                return np.asarray([mean, variance, upr], dtype=float), float(effective_omega)

            samples = self._draw_feasible_samples(stat_n_mc)
            y = np.asarray(predict_pce(pce_model, samples), dtype=float).ravel()
            mean = float(np.mean(y))
            variance = float(np.var(y))
            effective_omega = self._resolve_effective_omega(
                y,
                mode=omega_mode,
                stat_omega=stat_omega,
                omega_quantile=omega_quantile,
                omega_shift=omega_anchor_shift,
            )
            n_samples = int(max(1, y.shape[0]))
            weights = np.full((n_samples,), 1.0 / n_samples, dtype=float)
            upr = float(upr_from_y_weights(y, weights, float(effective_omega)))
            return np.asarray([mean, variance, upr], dtype=float), float(effective_omega)

        raise ValueError(f"Unknown objective_stat_mode {mode!r}")

    def _evaluate_objectives(self, x: np.ndarray, *, pymoo_n_gen: int | None = None) -> np.ndarray:
        eval_cfg = self.config.evaluate.for_variant(self.variant_name)
        self._inc_counter("objective_evals")

        pce_model = self.build_pce_surrogate(
            x=x,
            distribution_data=self.distribution_data,
            pce_rule=eval_cfg.pce_rule,
            pce_order=eval_cfg.pce_order,
            n_jobs=eval_cfg.n_jobs,
            backend=eval_cfg.backend,
            vectorized=bool(getattr(eval_cfg, "vectorized", False)),
            vectorized_batch_size=getattr(eval_cfg, "vectorized_batch_size", None),
            pymoo_n_gen=pymoo_n_gen,
        )

        t_stats = time.perf_counter()
        stats, effective_omega = self.evaluate_statistics(
            pce_model=pce_model,
            distribution_data=self.distribution_data,
            stat_n_mc=eval_cfg.stat_n_mc,
            stat_omega=eval_cfg.stat_omega,
            omega_mode=getattr(eval_cfg, "omega_mode", "fixed"),
            omega_quantile=float(getattr(eval_cfg, "omega_quantile", 0.5)),
            omega_anchor_shift=float(getattr(eval_cfg, "omega_anchor_shift", 0.0)),
            stat_rule=eval_cfg.stat_rule,
            quad_order=eval_cfg.quad_order,
            quad_rule=eval_cfg.quad_rule,
        )
        self._add_phase_time("stats_s", time.perf_counter() - t_stats)
        if self._objective_history is None:
            self._objective_history = []
        self._objective_history.append(np.asarray(stats, dtype=float).copy())
        if self._effective_omega_history is None:
            self._effective_omega_history = []
        self._effective_omega_history.append(float(effective_omega))

        if self.normalize and self.obj_min is not None and self.obj_max is not None:
            denom = self.obj_max - self.obj_min

            # If denom is a plain numpy array, use masking (no np.where => no numpoly dispatch)
            if isinstance(denom, np.ndarray):
                denom = denom.copy()
                denom[np.abs(denom) < 1e-12] = 1.0
            else:
                # denom might be scalar, list, numpoly polynomial, etc.
                # Convert to array if safe; otherwise just guard scalar case.
                try:
                    denom_arr = np.asarray(denom, dtype=float)
                    denom_arr[np.abs(denom_arr) < 1e-12] = 1.0
                    denom = denom_arr
                except Exception:
                    # last resort: scalar-ish
                    denom = 1.0 if abs(float(denom)) < 1e-12 else denom

            return (stats - self.obj_min) / denom

        return stats

    # ----------------------------
    # Optimization + persistence (inline PCE evaluation in NSGA-II loop)
    # ----------------------------
    def evaluate_systems(self):
        """Run NSGA-II with online PCE evaluation: each design point via _evaluate_objectives (PCE + Gurobi)."""
        self._validate_search_budget()
        rt = AntifragileRuntime(config=self.config, eval_objectives=self._evaluate_objectives)
        self.problem = AntifragileProblem(rt, self.variant_name)

        algorithm_cfg = self.config.algorithm
        termination = self.config.termination.termination_instance
        kwargs = {
            "pop_size": algorithm_cfg.pop_size,
            "sampling": algorithm_cfg.sampling_class(),
            "selection": algorithm_cfg.selection_class(),
            "crossover": algorithm_cfg.crossover_class(),
            "mutation": algorithm_cfg.mutation_class(),
        }
        try:
            algorithm = algorithm_cfg.algorithm_class(
                **kwargs,
                eliminate_duplicates=True,
            )
        except TypeError as exc:
            if "eliminate_duplicates" not in str(exc):
                raise
            log.debug("Algorithm does not support eliminate_duplicates; using class defaults.")
            algorithm = algorithm_cfg.algorithm_class(**kwargs)

        log.info("Starting NSGA-II with inline PCE evaluation (Gurobi in loop).")
        res = minimize(
            problem=self.problem,
            algorithm=algorithm,
            termination=termination,
            seed=self.config.pymoo.seed,
            save_history=bool(getattr(self.config.pymoo, "save_history", True)),
            verbose=self.config.pymoo.verbose,
        )
        x_vals = res.X
        f_vals = res.F
        if x_vals is None or f_vals is None:
            opt = getattr(res, "opt", None)
            if opt is not None:
                try:
                    x_vals = opt.get("X")
                    f_vals = opt.get("F")
                except Exception:
                    x_vals, f_vals = None, None
        if x_vals is None or f_vals is None:
            raise RuntimeError(
                f"Antifragile optimization for {self.variant_name} returned no feasible solutions "
                "(res.X/res.F are None). Check solver feasibility and constraints."
            )

        x_arr = np.asarray(x_vals, dtype=float)
        f_arr = np.asarray(f_vals, dtype=float)
        if x_arr.ndim == 1:
            x_arr = x_arr.reshape(1, -1)
        if f_arr.ndim == 1:
            f_arr = f_arr.reshape(1, -1)
        nd_idx = self._non_dominated_indices(f_arr)
        x_pareto = x_arr[nd_idx] if nd_idx.size > 0 else x_arr
        f_pareto = f_arr[nd_idx] if nd_idx.size > 0 else f_arr
        n_total = int(x_arr.shape[0])
        n_unique = self._unique_rows_count(x_arr)
        n_front = int(f_pareto.shape[0])
        log.info(
            "Antifragile diagnostics %s: points=%s unique=%s non_dominated=%s",
            self.variant_name,
            n_total,
            n_unique,
            n_front,
        )

        self._save_results(
            x_pareto,
            f_pareto,
            self.h5_file_name,
            population_size=n_total,
            population_unique=n_unique,
            population_front=n_front,
        )
        return res

    def _get_config_dict(self) -> dict:
        """Return config as a plain dict for HDF5 serialization."""
        if hasattr(self.config, "to_dict"):
            return self.config.to_dict()
        if hasattr(self.config, "model_dump"):
            return self.config.model_dump()
        return dict(self.config.__dict__)

    def _independence_diagnostics_for_h5(self) -> dict[str, Any] | None:
        ev = self._evaluate_config_for_variant()
        if ev is None or not bool(getattr(ev, "independence_diagnostics_enabled", False)):
            return None
        n_req = getattr(ev, "independence_n_samples", None)
        if n_req is None:
            n_req = max(256, int(ev.stat_n_mc) * 2)
        n = int(n_req)
        thr = float(getattr(ev, "independence_max_abs_corr_threshold", 0.25))
        space = str(getattr(ev, "independence_sample_space", "feasible"))
        rule = ev.pce_rule

        if space == "feasible":
            xi = self._draw_feasible_samples(n)
        elif space == "nominal":
            seed_obj = getattr(ev, "independence_rng_seed", 42)
            seed_int = int(np.random.default_rng().integers(0, 2**31 - 1)) if seed_obj is None else int(seed_obj)
            raw = self.distribution_data.sample(size=n, rule=rule, seed=seed_int)
            s = np.asarray(raw, dtype=float)
            rows = normalize_distribution_sample_to_rows(s, n)
            xi = np.asarray(rows.T, dtype=float)
        else:
            raise ValueError(f"Unknown independence_sample_space {space!r}")

        corr = pearson_correlation_matrix(xi)
        mx = max_abs_correlation_off_diagonal(corr)
        status = independence_corr_status(mx, thr)

        vnames = [self.variable_names] if isinstance(self.variable_names, str) else list(self.variable_names)
        if len(vnames) != xi.shape[0]:
            log.warning(
                "Independence diagnostics: %d variable_names vs xi dim %d; using generic labels.",
                len(vnames),
                xi.shape[0],
            )
            vnames = [f"xi_{i}" for i in range(xi.shape[0])]

        return {
            "corr_pearson": corr,
            "max_abs_off_diagonal": mx,
            "threshold": thr,
            "status": status,
            "n_samples": n,
            "sample_space": space,
            "variable_names": vnames,
        }

    def _uncertainty_stochastic_dimension(self) -> int:
        try:
            return len(self.distribution_data)
        except Exception:
            return 0

    def _uncertainty_variable_names_for_h5(self) -> list[str]:
        n = self._uncertainty_stochastic_dimension()
        if n <= 0:
            return []
        raw = getattr(self.distribution_data, "variable_names", None)
        if raw is None:
            return [f"xi_{i}" for i in range(n)]
        names = [raw] if isinstance(raw, str) else list(raw)
        if len(names) != n:
            log.warning(
                "Sobol diagnostics: %d distribution variable_names vs stochastic dim %d; using generic labels.",
                len(names),
                n,
            )
            return [f"xi_{i}" for i in range(n)]
        return names

    def _sobol_diagnostics_for_h5(self, pareto_x: np.ndarray) -> dict[str, Any] | None:
        ev = self._evaluate_config_for_variant()
        if ev is None or not bool(getattr(ev, "sobol_diagnostics_enabled", False)):
            return None
        n_xi = self._uncertainty_stochastic_dimension()
        if n_xi <= 0:
            log.warning("Sobol diagnostics skipped: could not infer stochastic dimension from distribution_data.")
            return None

        px = np.asarray(pareto_x, dtype=float)
        if px.ndim == 1:
            px = px.reshape(1, -1)
        cap = int(getattr(ev, "sobol_max_pareto_points", 5))
        px = px[:cap]
        n_save = int(px.shape[0])
        if n_save == 0:
            return None

        vnames = self._uncertainty_variable_names_for_h5()
        s1_rows: list[np.ndarray] = []
        st_rows: list[np.ndarray] = []
        rows_saved: list[int] = []

        for row_idx in range(n_save):
            x_row = np.asarray(px[row_idx]).ravel()
            _model, poly_exp, coeffs = self.build_pce_surrogate(
                x=x_row,
                distribution_data=self.distribution_data,
                pce_rule=ev.pce_rule,
                pce_order=ev.pce_order,
                n_jobs=ev.n_jobs,
                backend=ev.backend,
                vectorized=bool(getattr(ev, "vectorized", False)),
                vectorized_batch_size=getattr(ev, "vectorized_batch_size", None),
                return_expansion_coeffs=True,
            )
            s1, st = pce_first_total_sobol(poly_exp, coeffs, n_dim=n_xi)
            s1_rows.append(s1)
            st_rows.append(st)
            rows_saved.append(row_idx)

        return {
            "S1": np.stack(s1_rows, axis=0),
            "ST": np.stack(st_rows, axis=0),
            "pareto_row": np.asarray(rows_saved, dtype=np.int32),
            "variable_names": vnames,
            "method": "pce_coefficient_sobol",
            "reference_measure": "nominal_joint_independence",
            "target": "pce_scalar_training_objective",
            "pce_order": int(ev.pce_order),
        }

    def _marginals_diagnostics_for_h5(self) -> dict[str, Any] | None:
        ev = self._evaluate_config_for_variant()
        if ev is None or not bool(getattr(ev, "marginal_diagnostics_enabled", False)):
            return None
        n_grid = int(getattr(ev, "marginal_plot_grid_points", 256))
        n_hist_raw = getattr(ev, "marginal_hist_n_samples", None)
        hist_bins = int(getattr(ev, "marginal_hist_bins", 40))
        xi_full: np.ndarray | None = None
        if n_hist_raw is not None and int(n_hist_raw) > 0:
            try:
                xi_full = self._draw_feasible_samples(int(n_hist_raw))
            except Exception:
                log.warning(
                    "Marginal diagnostics: feasible sampling failed; skipping histogram overlay.",
                    exc_info=True,
                )
                xi_full = None
        hist_n = int(n_hist_raw) if n_hist_raw is not None and int(n_hist_raw) > 0 and xi_full is not None else None

        records: list[dict[str, Any]] = []
        dd = self.distribution_data
        try:
            if hasattr(dd, "_to_generic"):
                gen = dd._to_generic()
                for idx, n in enumerate(gen.variable_names()):
                    vs = gen.variables[n]
                    row = xi_full[idx, :] if xi_full is not None and idx < xi_full.shape[0] else None
                    records.append(
                        marginal_record_from_variable_spec(
                            str(vs.name or n),
                            str(vs.mode),
                            vs,
                            n_grid=n_grid,
                            n_hist_samples=hist_n,
                            hist_bins=hist_bins,
                            xi_row=row,
                        )
                    )
            elif hasattr(dd, "_build_dist") and callable(getattr(dd, "variable_names", None)):
                names = list(dd.variable_names())
                for idx, n in enumerate(names):
                    raw = getattr(dd, n, None)
                    if raw is None:
                        continue
                    mode = str(getattr(dd, f"mode_{n}", "absolute"))
                    cpd = dd._build_dist(raw, n)
                    dtype = str(raw.get("type", "unknown")).lower()
                    params = dict(raw.get("params") or {})
                    pj = json.dumps({k: (float(v) if isinstance(v, int | float) else v) for k, v in params.items()})
                    row = xi_full[idx, :] if xi_full is not None and idx < xi_full.shape[0] else None
                    records.append(
                        marginal_record_from_chaospy(
                            str(n),
                            mode,
                            cpd,
                            distribution_type=dtype,
                            parameterization="direct_params",
                            params_json=pj,
                            n_grid=n_grid,
                            n_hist_samples=hist_n,
                            hist_bins=hist_bins,
                            xi_row=row,
                        )
                    )
            else:
                # Already a Chaospy joint (e.g. config.uncertainty -> build_uncertainty_joint_distribution)
                # has no build_joint(); variant file-based models expose build_joint().
                build_joint = getattr(dd, "build_joint", None)
                joint = build_joint() if callable(build_joint) else dd
                d = len(joint)
                for i in range(d):
                    row = xi_full[i, :] if xi_full is not None and i < xi_full.shape[0] else None
                    records.append(
                        marginal_record_from_chaospy(
                            f"xi_{i}",
                            "unknown",
                            joint[i],
                            distribution_type="joint_marginal",
                            parameterization="joint_marginal_slice",
                            params_json="{}",
                            n_grid=n_grid,
                            n_hist_samples=hist_n,
                            hist_bins=hist_bins,
                            xi_row=row,
                        )
                    )
        except Exception:
            log.warning("Marginal diagnostics skipped.", exc_info=True)
            return None
        if not records:
            return None
        return {"records": records}

    def _save_results(  # noqa: PLR0912, PLR0915
        self,
        x: np.ndarray,
        fvals: np.ndarray,
        h5_file_name: str,
        *,
        population_size: int | None = None,
        population_unique: int | None = None,
        population_front: int | None = None,
    ) -> None:
        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        hdf_path = out_dir / h5_file_name
        if hdf_path.exists():
            hdf_path.unlink()

        var_names = [self.variable_names] if isinstance(self.variable_names, str) else list(self.variable_names)
        obj_names = [self.objective_names] if isinstance(self.objective_names, str) else list(self.objective_names)

        if x.ndim == 1:
            x = x.reshape(1, -1)
        if fvals.ndim == 1:
            fvals = fvals.reshape(1, -1)

        if len(var_names) != x.shape[1]:
            raise ValueError(f"Expected {x.shape[1]} variable names, got {len(var_names)}")
        if len(obj_names) != fvals.shape[1]:
            raise ValueError(f"Expected {fvals.shape[1]} objective names, got {len(obj_names)}")

        with h5py.File(hdf_path, "w") as f:
            meta_grp = f.require_group("meta")
            objective_transform = np.ones((len(obj_names),), dtype=float)
            for idx, obj_name in enumerate(obj_names):
                if str(obj_name).strip().startswith("-"):
                    objective_transform[idx] = -1.0
            meta_grp.create_dataset("objective_transform", data=objective_transform)
            meta_grp.attrs["variant"] = self.variant_name
            try:
                ev = self.config.evaluate.for_variant(self.variant_name)
                meta_grp.attrs["objective_stat_mode"] = getattr(ev, "objective_stat_mode", "mc_median_skew_upr")
                meta_grp.attrs["moment_reference"] = getattr(ev, "moment_reference", "nominal")
            except Exception:
                pass
            tag_group_schema_version(meta_grp)

            # persist rejection sampler stats (RejectionSamplerWithStats)
            feas = self._feasibility_metadata()
            if feas:
                g_feas = f.require_group("feasibility")
                for k, v in feas.items():
                    g_feas.create_dataset(str(k), data=v)
                tag_group_schema_version(g_feas)

            g = f.require_group("pareto")
            g.create_dataset("X", data=x)
            g.create_dataset("F", data=fvals)
            g.create_dataset("variable_names", data=np.asarray(var_names, dtype="S"))
            g.create_dataset("objective_names", data=np.asarray(obj_names, dtype="S"))
            tag_group_schema_version(g)

            g_diag = f.require_group("diagnostics")
            g_diag.create_dataset("pareto_n_points", data=int(x.shape[0]))
            g_diag.create_dataset("pareto_n_unique_points", data=self._unique_rows_count(x))
            g_diag.create_dataset("pareto_front_size", data=self._non_dominated_count(fvals))
            if population_size is not None:
                g_diag.create_dataset("population_n_points", data=int(population_size))
            if population_unique is not None:
                g_diag.create_dataset("population_n_unique_points", data=int(population_unique))
            if population_front is not None:
                g_diag.create_dataset("population_front_size", data=int(population_front))
            for key, val in self._objective_diagnostics().items():
                g_diag.create_dataset(str(key), data=val)
            tag_group_schema_version(g_diag)

            ind = self._independence_diagnostics_for_h5()
            if ind is not None:
                ig = f.require_group("independence")
                tag_group_schema_version(ig)
                ig.create_dataset("corr_pearson", data=ind["corr_pearson"])
                ig.attrs["status"] = ind["status"]
                ig.attrs["max_abs_off_diagonal"] = float(ind["max_abs_off_diagonal"])
                ig.attrs["threshold"] = float(ind["threshold"])
                ig.attrs["n_samples"] = int(ind["n_samples"])
                ig.attrs["sample_space"] = ind["sample_space"]
                ig.create_dataset("variable_names", data=np.asarray(ind["variable_names"], dtype="S"))

            loo_rmses = list(self._safe_get_private(self, "_pce_loo_initial_rmses", []) or [])
            loo_idx = list(self._safe_get_private(self, "_pce_loo_objective_eval_indices", []) or [])
            if loo_rmses:
                ev_loo = self._evaluate_config_for_variant()
                target_gen = int(getattr(ev_loo, "pce_loo_initial_generation_n_gen", 1)) if ev_loo is not None else 1
                plg = f.require_group("pce_loo_initial")
                tag_group_schema_version(plg)
                plg.create_dataset("loo_rmse", data=np.asarray(loo_rmses, dtype=float))
                plg.create_dataset("objective_eval_index", data=np.asarray(loo_idx, dtype=np.int32))
                plg.attrs["pymoo_n_gen_target"] = int(target_gen)
                plg.attrs["n_points"] = len(loo_rmses)

            sbl = self._sobol_diagnostics_for_h5(x)
            if sbl is not None:
                sg = f.require_group("sobol")
                tag_group_schema_version(sg)
                sg.create_dataset("S1", data=sbl["S1"])
                sg.create_dataset("ST", data=sbl["ST"])
                sg.create_dataset("pareto_row", data=sbl["pareto_row"])
                sg.create_dataset("variable_names", data=np.asarray(sbl["variable_names"], dtype="S"))
                sg.attrs["method"] = sbl["method"]
                sg.attrs["reference_measure"] = sbl["reference_measure"]
                sg.attrs["target"] = sbl["target"]
                sg.attrs["pce_order"] = int(sbl["pce_order"])

            marg = self._marginals_diagnostics_for_h5()
            if marg is not None:
                mg = f.require_group("marginals")
                tag_group_schema_version(mg)
                mlist = marg["records"]
                mg.attrs["n_marginals"] = len(mlist)
                str_dt = h5py.string_dtype(encoding="utf-8")
                for i, rec in enumerate(mlist):
                    sub = mg.require_group(str(i))
                    sub.attrs["variable_name"] = rec["variable_name"]
                    sub.attrs["mode"] = rec["mode"]
                    sub.attrs["distribution_type"] = rec["distribution_type"]
                    sub.attrs["parameterization"] = rec["parameterization"]
                    sub.create_dataset("params_json", data=rec["params_json"], dtype=str_dt)
                    sub.create_dataset("grid_x", data=rec["grid_x"])
                    sub.create_dataset("pdf", data=rec["pdf"])
                    sub.create_dataset("cdf", data=rec["cdf"])
                    if "hist_edges" in rec:
                        sub.create_dataset("hist_edges", data=rec["hist_edges"])
                        sub.create_dataset("hist_density", data=rec["hist_density"])
                        sub.attrs["hist_sample_space"] = str(rec["hist_sample_space"])

            config_dict = self._get_config_dict()
            cfg_grp = f.require_group("config")
            save_config_to_h5(cfg_grp, config_dict)
            tag_group_schema_version(cfg_grp)

        log.info("Antifragile optimization stored: X %s, F %s -> %s", x.shape, fvals.shape, hdf_path)
