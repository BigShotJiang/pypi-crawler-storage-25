"""
Surrogate model for design x -> objectives F (used after offline DOE).
Uses scipy RBF interpolation; prediction clamps x to bounds.
"""

from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy.interpolate import RBFInterpolator


def fit_surrogate(
    x_design: np.ndarray,
    f_objectives: np.ndarray,
    kind: str = "rbf",
) -> Callable[[np.ndarray], np.ndarray]:
    """
    Fit a surrogate that maps design points x to objective vectors.

    x_design: (n_samples, n_var) design points from offline DOE.
    f_objectives: (n_samples, n_obj) objective values (e.g. med, -skewness, -upr).
    kind: surrogate type; only "rbf" is implemented.

    Returns a callable f such that f(x) returns shape (n_obj,) for x of shape (n_var,).
    """
    x_arr = np.asarray(x_design, dtype=float)
    f_arr = np.asarray(f_objectives, dtype=float)
    if x_arr.ndim != 2 or f_arr.ndim != 2:
        raise ValueError("x_design and f_objectives must be 2-dimensional.")
    if x_arr.shape[0] != f_arr.shape[0]:
        raise ValueError(
            f"x_design and f_objectives must have same number of rows, got {x_arr.shape[0]} and {f_arr.shape[0]}."
        )

    if kind.lower() != "rbf":
        raise ValueError(f"Unsupported surrogate_kind: {kind!r}. Use 'rbf'.")

    n_samples, n_dim = x_arr.shape[0], x_arr.shape[1]
    # RBFInterpolator(..., kernel="thin_plate_spline") with default degree=1 requires
    # at least (n_dim + 1) points to solve the polynomial part.
    min_points = n_dim + 1
    if n_samples < min_points:
        raise ValueError(
            f"RBF thin_plate_spline with {n_dim} design variable(s) requires at least "
            f"{min_points} data points, got {n_samples}. "
            "Increase antifragile.offline_n_design_points (or --n-design-points when profiling) to at least "
            f"{min_points}."
        )

    rbf = RBFInterpolator(x_arr, f_arr, kernel="thin_plate_spline")
    n_obj = f_arr.shape[1]

    def _predict(x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        if x.ndim == 1:
            x = x.reshape(1, -1)
        out = rbf(x)
        return out.reshape(-1, n_obj)

    return _predict


def predict_surrogate(
    surrogate: Callable[[np.ndarray], np.ndarray],
    x: np.ndarray,
    xl: np.ndarray,
    xu: np.ndarray,
) -> np.ndarray:
    """
    Evaluate the surrogate at x, with x clamped to [xl, xu].

    x: (n_var,) or (1, n_var). xl, xu: (n_var,) bounds.
    Returns (n_obj,) array.
    """
    x = np.asarray(x, dtype=float).ravel()
    xl = np.asarray(xl, dtype=float).ravel()
    xu = np.asarray(xu, dtype=float).ravel()
    x_clamped = np.clip(x, xl, xu)
    out = surrogate(x_clamped.reshape(1, -1))
    return out[0]
