from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np
from numpy import asarray
from pymoo.core.problem import ElementwiseProblem

from eta_incerto.config.config import ConfigOptimization


class EvalObjectivesFn(Protocol):
    def __call__(self, x: np.ndarray, *, pymoo_n_gen: int | None = None) -> np.ndarray: ...


@dataclass(frozen=True)
class AntifragileRuntime:
    config: ConfigOptimization
    eval_objectives: EvalObjectivesFn


class AntifragileProblem(ElementwiseProblem):
    def __init__(self, rt: AntifragileRuntime, variant_name: str, parallelization=None):
        self.rt = rt
        cfg = rt.config
        pdef = cfg.pymoo.for_variant(variant_name)

        super().__init__(
            n_var=len(pdef.variable_names),
            n_obj=len(pdef.objective_names),
            n_ieq_constr=int(getattr(pdef, "n_ieq_constraints", 0) or 0),
            n_eq_constr=int(getattr(pdef, "n_eq_constraints", 0) or 0),
            xl=asarray(pdef.x_lower_bound, dtype=float),
            xu=asarray(pdef.x_upper_bound, dtype=float),
            elementwise=True,
            parallelization=parallelization,
            requires_kwargs=True,
        )

    def _evaluate(self, x, out, *args, **kwargs):
        alg = kwargs.get("algorithm")
        pymoo_n_gen = int(alg.n_gen) if alg is not None and getattr(alg, "n_gen", None) is not None else None
        out["F"] = self.rt.eval_objectives(asarray(x, dtype=float), pymoo_n_gen=pymoo_n_gen)
