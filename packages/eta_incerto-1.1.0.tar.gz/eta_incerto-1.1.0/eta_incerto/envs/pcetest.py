from __future__ import annotations

from logging import getLogger
from pathlib import Path

import h5py
from chaospy.distributions.baseclass import Distribution
from joblib import Parallel, delayed
from numpy import (
    arange,
    array,
    asarray,
    linspace,
    ndarray,
    zeros,
)
from pydantic import BaseModel, ConfigDict, Field

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.envs.model import Model
from eta_incerto.surrogate import (
    fit_pce_regression,
    generate_polynomial_expansion,
    kfold_pce_rmse,
    leave_one_out_pce_rmse,
    predict_pce,
    root_mean_squared_error,
    tag_group_schema_version,
)
from eta_incerto.util.h5_config import save_config_to_h5

log = getLogger(__name__)


class PceOrderTest(BaseModel):
    """Evaluate for a variant model the pce surrogate model qualtiy with RMSE."""

    model_config = ConfigDict(arbitrary_types_allowed=True)
    config: ConfigOptimization = Field(..., description="Optimization config from central config.json")
    distribution_data: Distribution = Field(..., description="Distribution of input parameters")
    model_builder: Model = Field(..., description="Model to use for evaluation")
    h5_file_name: str
    variant_name: str | None = Field(
        default=None,
        description="Variant name used to resolve the evaluate config (defaults to first system variant).",
    )

    def _resolve_eval_config(self):
        if self.variant_name:
            return self.config.evaluate.for_variant(self.variant_name)

        variants = getattr(self.config.system, "variant", None)
        if isinstance(variants, list) and variants:
            return self.config.evaluate.for_variant(variants[0])
        if isinstance(variants, str) and variants:
            return self.config.evaluate.for_variant(variants)

        eval_root = getattr(self.config.evaluate, "root", None)
        if isinstance(eval_root, dict) and eval_root:
            return self.config.evaluate.for_variant(next(iter(eval_root.keys())))

        raise ValueError("Unable to resolve evaluate config: no variant available.")

    def _variant_key(self) -> str:
        if self.variant_name:
            return self.variant_name
        variants = getattr(self.config.system, "variant", None)
        if isinstance(variants, list) and variants:
            return str(variants[0])
        if isinstance(variants, str) and variants:
            return variants
        eval_root = getattr(self.config.evaluate, "root", None)
        if isinstance(eval_root, dict) and eval_root:
            return str(next(iter(eval_root.keys())))
        raise ValueError("Unable to resolve variant for pymoo bounds.")

    def _pymoo_design_bounds(self) -> tuple[ndarray, ndarray, list[str]]:
        v = self._variant_key()
        pdef = self.config.pymoo.for_variant(v)
        names = list(pdef.variable_names)
        lb = asarray(pdef.x_lower_bound, dtype=float).ravel()
        ub = asarray(pdef.x_upper_bound, dtype=float).ravel()
        if lb.size != ub.size:
            raise ValueError(f"pymoo x_lower_bound / x_upper_bound length mismatch for {v}.")
        if len(names) != int(lb.size):
            raise ValueError(f"pymoo variable_names length {len(names)} != bounds length {lb.size} for {v}.")
        return lb, ub, names

    def _reference_design_vector(self) -> ndarray:
        lb, ub, _ = self._pymoo_design_bounds()
        ref = getattr(self.config.pcetest, "reference_design", None)
        if ref is not None:
            x = asarray(ref, dtype=float).ravel()
            if x.size != lb.size:
                raise ValueError(f"pcetest.reference_design length {x.size} must match pymoo dimension {lb.size}.")
            return x
        return (lb + ub) / 2.0

    def design_vector(self):
        """Builds a design vector with minimum, maximum, and step (numpy arange semantics on [min, max))."""
        lo = int(self.config.pcetest.design_var_min)
        hi = int(self.config.pcetest.design_var_max)
        step = int(self.config.pcetest.design_var_step)
        if step <= 0:
            raise ValueError("pcetest.design_var_step must be positive.")
        if lo == hi:
            return array([lo])
        return arange(lo, hi, step)

    def _pcetest_n_orders(self) -> int:
        lo = int(self.config.pcetest.min_order)
        hi = int(self.config.pcetest.max_order)
        return hi - lo + 1

    def rmse_matrix(self):
        """Builds matrix for design."""
        design_x_range = self.design_vector()
        return zeros((len(design_x_range), self._pcetest_n_orders()))

    def model(self, x, xi):
        return self.model_builder.build_simulate_model(x, xi)  # returns LCOE

    def rmse_vs_order(
        self,
        design_x,
        *,
        x_val_cache: ndarray | None = None,
        x_train_cache: dict[int, ndarray] | None = None,
    ):
        n_val = self.config.pcetest.n_val
        min_order = int(self.config.pcetest.min_order)
        max_order = int(self.config.pcetest.max_order)
        sampler = self.config.pcetest.sampler
        eval_cfg = self._resolve_eval_config()
        n_jobs = eval_cfg.n_jobs
        backend = eval_cfg.backend
        diag_mode = self.config.pcetest.pce_diagnostics_mode

        orders, rmses = [], []
        diag_rmses: list[float] | None = None if diag_mode == "none" else []

        # validation inputs (optionally reused across the full sweep for smoother curves)
        x_val = x_val_cache if x_val_cache is not None else self.distribution_data.sample(n_val, rule=sampler)
        n_val_eff = int(x_val.shape[1])

        # true model on validation set
        y_val = Parallel(n_jobs=n_jobs, backend=backend)(
            delayed(self.model)(design_x, x_val[:, i]) for i in range(n_val_eff)
        )
        y_val = array(y_val)

        for order in range(min_order, max_order + 1):
            pol_basis = generate_polynomial_expansion(order, self.distribution_data)
            if x_train_cache is not None and order in x_train_cache:
                x_train = x_train_cache[order]
                n_train = int(x_train.shape[1])
            else:
                n_train = 2 * len(pol_basis)
                x_train = self.distribution_data.sample(n_train, rule=sampler)

            # keep same parallel config as above for consistency
            y_train = Parallel(n_jobs=n_jobs, backend=backend)(
                delayed(self.model)(design_x, x_train[:, i]) for i in range(n_train)
            )
            y_train = array(y_train)

            pce = fit_pce_regression(pol_basis, x_train, y_train)
            y_pred = predict_pce(pce, x_val)

            rmse = root_mean_squared_error(y_val, y_pred)
            orders.append(order)
            rmses.append(rmse)

            if diag_rmses is not None:
                if diag_mode == "kfold":
                    k = int(self.config.pcetest.pce_diagnostics_cv_folds)
                    k_eff = min(k, n_train)
                    if k_eff < 2:
                        diag_rmses.append(float("nan"))
                    else:
                        mean_rmse, _ = kfold_pce_rmse(
                            pol_basis,
                            x_train,
                            y_train,
                            k_eff,
                            random_state=self.config.pcetest.pce_diagnostics_seed,
                        )
                        diag_rmses.append(mean_rmse)
                elif diag_mode == "loo":
                    diag_rmses.append(leave_one_out_pce_rmse(pol_basis, x_train, y_train))

        return rmses, orders, diag_rmses

    def evaluate_rmse_for_design_x(
        self,
        x: ndarray,
        *,
        x_val_cache: ndarray | None = None,
        x_train_cache: dict[int, ndarray] | None = None,
    ) -> tuple[ndarray, ndarray | None]:
        """Full decision vector x (length n_dim); returns (rmses_per_order, diag_per_order or None)."""
        xv = asarray(x, dtype=float).ravel()
        rmses, _orders, diag = self.rmse_vs_order(xv, x_val_cache=x_val_cache, x_train_cache=x_train_cache)
        if diag is None:
            return array(rmses), None
        return array(rmses), array(diag)

    def evaluate_rmse_for_var(self, var):
        """Legacy 1D sweep: scalar var as single-element design vector."""
        design_x = array([var], dtype=float)
        return self.evaluate_rmse_for_design_x(design_x)

    def save_rmse_results(self, design_x_range, rmse_matrix, diagnostics_matrix: ndarray | None = None) -> None:
        """
        Save RMSE results vs nominal power into a single HDF5 file:
        /rmse/design_var, /rmse/matrix, /rmse/orders, /rmse/order_labels, /config/
        """
        h5_file_name = self.h5_file_name

        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        hdf_path = out_dir / h5_file_name
        if hdf_path.exists():
            hdf_path.unlink()

        with h5py.File(hdf_path, "w") as f:
            f.create_dataset("rmse/design_var", data=design_x_range)
            f.create_dataset("rmse/matrix", data=rmse_matrix)

            min_o = int(self.config.pcetest.min_order)
            orders = arange(min_o, min_o + int(rmse_matrix.shape[1]))
            f.create_dataset("rmse/orders", data=orders)

            order_labels = array([f"Order {o}" for o in orders], dtype="S")
            f.create_dataset("rmse/order_labels", data=order_labels)
            tag_group_schema_version(f["rmse"])

            try:
                config_dict = self.config.to_dict()
            except AttributeError:
                config_dict = self.config.__dict__

            cfg_group = f.create_group("config")
            save_config_to_h5(cfg_group, config_dict)
            tag_group_schema_version(cfg_group)

            if diagnostics_matrix is not None:
                dgrp = f.create_group("pce_diagnostics")
                tag_group_schema_version(dgrp)
                mode = self.config.pcetest.pce_diagnostics_mode
                dgrp.attrs["mode"] = mode
                if mode == "kfold":
                    dgrp.attrs["cv_folds"] = int(self.config.pcetest.pce_diagnostics_cv_folds)
                seed = self.config.pcetest.pce_diagnostics_seed
                if seed is not None:
                    dgrp.attrs["seed"] = int(seed)
                dgrp.create_dataset("rmse", data=diagnostics_matrix)

        log.info("RMSE results stored: matrix shape %s -> %s", rmse_matrix.shape, hdf_path)

    def save_multi_axis_results(self, hdf_path: Path) -> None:
        """Write by_axis/{k}/sweep_values, rmse, optional pce_diagnostics/rmse for each pymoo variable."""
        lb, ub, names = self._pymoo_design_bounds()
        n_dim = int(lb.size)
        n_pt = int(self.config.pcetest.n_sweep_points)
        x_ref = self._reference_design_vector()
        min_order = int(self.config.pcetest.min_order)
        max_order = int(self.config.pcetest.max_order)
        n_orders = max_order - min_order + 1
        diag_mode = self.config.pcetest.pce_diagnostics_mode
        sampler = self.config.pcetest.sampler
        n_val = int(self.config.pcetest.n_val)

        # Reuse one validation sample set and one training sample set per order
        # across all sweep points to reduce Monte-Carlo jitter in RMSE-vs-design curves.
        x_val_shared = self.distribution_data.sample(n_val, rule=sampler)
        x_train_shared: dict[int, ndarray] = {}
        for order in range(min_order, max_order + 1):
            pol_basis = generate_polynomial_expansion(order, self.distribution_data)
            n_train = 2 * len(pol_basis)
            x_train_shared[order] = self.distribution_data.sample(n_train, rule=sampler)

        if hdf_path.exists():
            hdf_path.unlink()

        with h5py.File(hdf_path, "w") as f:
            bx = f.create_group("by_axis")
            tag_group_schema_version(bx)
            ord_ds = arange(min_order, max_order + 1)
            bx.create_dataset("orders", data=ord_ds)

            for k in range(n_dim):
                g = bx.create_group(str(k))
                tag_group_schema_version(g)
                g.attrs["variable_name"] = names[k]
                grid = linspace(float(lb[k]), float(ub[k]), n_pt)
                g.create_dataset("sweep_values", data=grid)

                rmse_m = zeros((n_pt, n_orders))
                diag_m: ndarray | None = None if diag_mode == "none" else zeros((n_pt, n_orders))

                for i, val in enumerate(grid):
                    x = x_ref.copy()
                    x[k] = float(val)
                    rmses, diag = self.evaluate_rmse_for_design_x(
                        x,
                        x_val_cache=x_val_shared,
                        x_train_cache=x_train_shared,
                    )
                    rmse_m[i, :] = rmses
                    if diag is not None and diag_m is not None:
                        diag_m[i, :] = diag

                g.create_dataset("rmse", data=rmse_m)
                if diag_m is not None:
                    dgrp = g.create_group("pce_diagnostics")
                    tag_group_schema_version(dgrp)
                    dgrp.attrs["mode"] = diag_mode
                    if diag_mode == "kfold":
                        dgrp.attrs["cv_folds"] = int(self.config.pcetest.pce_diagnostics_cv_folds)
                    seed = self.config.pcetest.pce_diagnostics_seed
                    if seed is not None:
                        dgrp.attrs["seed"] = int(seed)
                    dgrp.create_dataset("rmse", data=diag_m)

            try:
                config_dict = self.config.to_dict()
            except AttributeError:
                config_dict = self.config.__dict__
            cfg_grp = f.create_group("config")
            save_config_to_h5(cfg_grp, config_dict)
            tag_group_schema_version(cfg_grp)

        log.info("Multi-axis PCE order test stored under by_axis/ (%d vars) -> %s", n_dim, hdf_path)

    def evaluate_rmse(self):
        """
        Compute RMSE vs order and persist. Legacy: one scalar design grid in rmse/.
        Multi-axis: one sweep per pymoo variable in by_axis/.
        """
        if bool(getattr(self.config.pcetest, "multi_axis_sweep", False)):
            out_dir = Path(self.config.paths.results_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            hdf_path = out_dir / self.h5_file_name
            self.save_multi_axis_results(hdf_path)
            return

        rmse_matrix = self.rmse_matrix()
        design_x_range = self.design_vector()
        diagnostics_matrix: ndarray | None = None

        for i, var in enumerate(design_x_range):
            rmses, diag = self.evaluate_rmse_for_var(var)
            rmse_matrix[i, :] = rmses
            if diag is not None:
                if diagnostics_matrix is None:
                    diagnostics_matrix = zeros(rmse_matrix.shape)
                diagnostics_matrix[i, :] = diag

        self.save_rmse_results(design_x_range, rmse_matrix, diagnostics_matrix)
