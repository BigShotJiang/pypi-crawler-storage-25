"""Scenario objective aggregators: regret, robust, stochastic (expected cost).

These wrap a base objective (NPV or TAC from eta-components) and add variables/constraints
so the backend objective is min (capex + w) for regret/robust or capex + weighted scenario
cost for stochastic. The LP objective row then lists explicit decision variables (capex terms)
plus the aggregation variable w.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import xarray as xr
from eta_components.milp_component_library.objectives import sum_all_dims

if TYPE_CHECKING:
    from eta_components.milp_component_library.systems import BasicSystem


class _BaseAggregator:
    """Base for scenario aggregators; conforms to objective-like contract for system.set_objective."""

    base_objective: Any = None  # Subclasses set this; used for .weights delegation

    def __init__(self, name: str, system: BasicSystem):
        self.name = name
        self.system = system
        self._is_constructed = False
        self._active = True
        self.data: dict[str, Any] = {}

    def _sense_backend(self) -> str:
        sense = str(self.data.get("sense", "minimize")).lower()
        return "min" if sense in {"min", "minimize"} else "max"

    @property
    def weights(self):
        """Delegate to base objective weights (for aggregate_over_all_indices etc.)."""
        if self.base_objective is not None and hasattr(self.base_objective, "weights"):
            return self.base_objective.weights
        raise AttributeError(f"{type(self).__name__} has no base_objective.weights")


class RegretAggregator(_BaseAggregator):
    """Min-max regret: minimize w s.t. w >= (obj_per_scenario - ideal_per_scenario) for all scenarios.

    Objective set to sum_all_dims(capex_expr) + w so the LP lists explicit decision variables.
    """

    def __init__(
        self,
        name: str,
        system: BasicSystem,
        base_objective: Any,
        ideal_per_scenario: xr.DataArray | list[float] | None = None,
        data: dict[str, Any] | None = None,
    ):
        super().__init__(name, system)
        self.base_objective = base_objective
        self.ideal_per_scenario = ideal_per_scenario
        self.data = data or {}

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        operational, capex_expr = self.base_objective.get_operational_and_capex_parts()
        time_dims = [d for d in ("year", "period", "time") if hasattr(operational, "dims") and d in operational.dims]
        if not time_dims or not hasattr(operational, "sum") or "scenario" not in getattr(operational, "dims", ()):
            total = self.base_objective._expression()
            self.system.set_backend_objective(total, sense=self._sense_backend())
            self._is_constructed = True
            return
        per_scenario = operational.sum(dim=time_dims)
        scenarios = list(self.system.index.coords["scenario"].values)
        obj_per_scenario = self.system.add_variable(
            "__obj_per_scenario",
            dims=("scenario",),
            coords={"scenario": scenarios},
            lower=None,
            upper=None,
        )
        self.system.add_constraints("__obj_per_scenario_def", obj_per_scenario == per_scenario)
        ideal_raw = self.ideal_per_scenario
        if ideal_raw is None:
            raise ValueError("RegretAggregator requires ideal_per_scenario")
        if not hasattr(ideal_raw, "dims") or "scenario" not in getattr(ideal_raw, "dims", ()):
            iterable = (
                list(ideal_raw)
                if hasattr(ideal_raw, "__iter__") and not isinstance(ideal_raw, str)
                else [float(ideal_raw)]
            )
            ideal_per_scenario = xr.DataArray(
                iterable,
                coords={"scenario": scenarios},
                dims=("scenario",),
            )
        else:
            ideal_per_scenario = ideal_raw
        regret_per_scenario = obj_per_scenario - ideal_per_scenario
        w = self.system.add_variable(
            "__regret_w",
            dims=(),
            coords={},
            lower=None,
            upper=None,
        )
        self.system.add_constraints("__regret_w_ge", w >= regret_per_scenario)
        total = sum_all_dims(capex_expr) + w
        self.system.set_backend_objective(total, sense=self._sense_backend())
        self._is_constructed = True


class RobustAggregator(_BaseAggregator):
    """Min-max (robust): minimize w s.t. w >= obj_per_scenario for all scenarios.

    Objective set to sum_all_dims(capex_expr) + w so the LP lists explicit decision variables.
    """

    def __init__(self, name: str, system: BasicSystem, base_objective: Any, data: dict[str, Any] | None = None):
        super().__init__(name, system)
        self.base_objective = base_objective
        self.data = data or {}

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        operational, capex_expr = self.base_objective.get_operational_and_capex_parts()
        time_dims = [d for d in ("year", "period", "time") if hasattr(operational, "dims") and d in operational.dims]
        if not time_dims or not hasattr(operational, "sum") or "scenario" not in getattr(operational, "dims", ()):
            total = self.base_objective._expression()
            self.system.set_backend_objective(total, sense=self._sense_backend())
            self._is_constructed = True
            return
        per_scenario = operational.sum(dim=time_dims)
        scenarios = list(self.system.index.coords["scenario"].values)
        obj_per_scenario = self.system.add_variable(
            "__obj_per_scenario",
            dims=("scenario",),
            coords={"scenario": scenarios},
            lower=None,
            upper=None,
        )
        self.system.add_constraints("__obj_per_scenario_def", obj_per_scenario == per_scenario)
        w = self.system.add_variable(
            "__robust_w",
            dims=(),
            coords={},
            lower=None,
            upper=None,
        )
        self.system.add_constraints("__robust_w_ge", w >= obj_per_scenario)
        total = sum_all_dims(capex_expr) + w
        self.system.set_backend_objective(total, sense=self._sense_backend())
        self._is_constructed = True


class StochasticAggregator(_BaseAggregator):
    """Expected cost: capex + sum_s (scenario_weights[s] * obj_per_scenario[s]).

    Objective set so the LP lists explicit decision variables (capex) plus weighted scenario terms.
    """

    def __init__(
        self,
        name: str,
        system: BasicSystem,
        base_objective: Any,
        scenario_weights: xr.DataArray,
        data: dict[str, Any] | None = None,
    ):
        super().__init__(name, system)
        self.base_objective = base_objective
        self.scenario_weights = scenario_weights
        self.data = data or {}

    def construct_objective(self) -> None:
        if not self._active:
            self.system.set_backend_objective(0, sense=self._sense_backend())
            self._is_constructed = True
            return
        operational, capex_expr = self.base_objective.get_operational_and_capex_parts()
        time_dims = [d for d in ("year", "period", "time") if hasattr(operational, "dims") and d in operational.dims]
        if not time_dims or not hasattr(operational, "sum") or "scenario" not in getattr(operational, "dims", ()):
            total = self.base_objective._expression()
            self.system.set_backend_objective(total, sense=self._sense_backend())
            self._is_constructed = True
            return
        per_scenario = operational.sum(dim=time_dims)
        scenarios = list(self.system.index.coords["scenario"].values)
        obj_per_scenario = self.system.add_variable(
            "__obj_per_scenario",
            dims=("scenario",),
            coords={"scenario": scenarios},
            lower=None,
            upper=None,
        )
        self.system.add_constraints("__obj_per_scenario_def", obj_per_scenario == per_scenario)
        sw = self.scenario_weights
        if hasattr(sw, "dims") and "scenario" in getattr(sw, "dims", ()):
            total = sum_all_dims(capex_expr) + (sw * obj_per_scenario).sum()
        else:
            total = sum_all_dims(capex_expr) + obj_per_scenario.sum()
        self.system.set_backend_objective(total, sense=self._sense_backend())
        self._is_constructed = True
