from __future__ import annotations

import logging
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import numpy as np
from pymoo.core.problem import Problem
from pymoo.optimize import minimize

from eta_incerto.envs.deterministic_evaluation import DeterministicEvaluator
from eta_incerto.envs.scenario import ScenarioCollection
from eta_incerto.envs.utils import numeric_value
from eta_incerto.envs.warmstart_sampling import WarmStartSampling

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class EvalMeta:
    ok: bool
    msg: str


class _EtaDeterministicProblem(Problem):
    """pymoo Problem wrapper delegating to PymooEvaluator."""

    def __init__(self, evaluator: Any, xl: np.ndarray, xu: np.ndarray):
        self._ev = evaluator
        super().__init__(
            n_var=len(evaluator.variable_names),
            n_obj=len(evaluator.objective_names),
            n_ieq_constr=0,
            xl=xl,
            xu=xu,
            elementwise_evaluation=False,
        )

    def _evaluate(self, variable: np.ndarray, out: dict, *args, **kwargs) -> None:
        objective = np.zeros((variable.shape[0], self.n_obj), dtype=float)

        for i in range(variable.shape[0]):
            f, meta = self._ev.evaluate_candidate(variable[i])
            objective[i, :] = f
            if not meta.ok:
                logger.debug("Penalized candidate %d: %s", i, meta.msg)

        out["F"] = objective


class PymooEvaluator:
    """
    pymoo-driven optimization for eta-components Pyomo MILP formulations.
    """

    def __init__(
        self,
        config: Any,
        scenarios: ScenarioCollection,
        h5_file_name: str,
        variable_names: Sequence[str],
        objective_names: Sequence[str],
        x_lower_bound: Sequence[float] | None = None,
        x_upper_bound: Sequence[float] | None = None,
    ):
        self.config = config
        self.scenarios = scenarios
        self.h5_file_name = h5_file_name
        self.variable_names = list(variable_names)
        self.objective_names = list(objective_names)

        if len(self.objective_names) != 1:
            raise ValueError(
                "Phase-1 PymooEvaluator supports a single objective. "
                "Implement Phase-2 multi-objective attachment if needed."
            )

        self.det = DeterministicEvaluator(config=self.config, scenarios=self.scenarios, h5_file_name=self.h5_file_name)

        # penalty: prefer pymoo config if present
        self.penalty = float(getattr(getattr(self.config, "pymoo", None), "penalty", None) or 1e12)

        self.xl, self.xu = self._get_bounds(x_lower_bound, x_upper_bound)

    # ----------------------------
    # Warmstart helpers
    # ----------------------------

    def _unfix_design_vector(self) -> None:
        """Ensure design variables are free before computing a warm-start from a solve."""
        for scen in self.scenarios:
            sys = scen.system
            inv_units = dict(self.det._iter_investments(sys))

            for key in self.variable_names:
                unit_name, field = self._split_var_key(key)
                unit = inv_units[unit_name]

                # unfix buy decision
                if field in ("y", "bought", "is_bought"):
                    if hasattr(unit, "is_bought") and hasattr(unit.is_bought, "unfix"):
                        unit.is_bought.unfix()
                    elif hasattr(unit, "model") and hasattr(unit.model, "y") and hasattr(unit.model.y, "unfix"):
                        unit.model.y.unfix()
                    continue

                # unfix nominal sizing
                _, nom_var = self.det._get_design_nominal(unit)
                if hasattr(nom_var, "is_indexed") and nom_var.is_indexed():
                    for idx in nom_var:
                        if hasattr(nom_var[idx], "unfix"):
                            nom_var[idx].unfix()
                elif hasattr(nom_var, "unfix"):
                    nom_var.unfix()

    def _extract_design_vector(self) -> np.ndarray:
        """
        Build x in the exact order of self.variable_names from the *first* scenario's solved model.
        """
        scen0 = next(iter(self.scenarios))
        sys = scen0.system
        inv_units = dict(self.det._iter_investments(sys))

        x = np.zeros(len(self.variable_names), dtype=float)

        for i, key in enumerate(self.variable_names):
            unit_name, field = self._split_var_key(key)
            unit = inv_units[unit_name]

            if field in ("y", "bought", "is_bought"):
                if hasattr(unit, "is_bought"):
                    x[i] = float(numeric_value(unit.is_bought))
                elif hasattr(unit, "model") and hasattr(unit.model, "y"):
                    x[i] = float(numeric_value(unit.model.y))
                else:
                    raise AttributeError(f"Unit '{unit_name}' has no buy decision for '{key}'")
                # IMPORTANT: keep it binary
                x[i] = 1.0 if x[i] >= 0.5 else 0.0
                continue

            _, nom_var = self.det._get_design_nominal(unit)
            if hasattr(nom_var, "is_indexed") and nom_var.is_indexed():
                # take a representative entry (or average). Usually nominal is scalar anyway.
                first_idx = next(iter(nom_var))
                x[i] = float(numeric_value(nom_var[first_idx]))
            else:
                x[i] = float(numeric_value(nom_var))

        # finally clip into bounds
        return np.clip(x, self.xl, self.xu)

    def _compute_warmstart(self) -> np.ndarray | None:
        """
        Try to compute one feasible seed x by solving the invest model once without fixed design vars.
        Returns x or None if it fails.
        """
        try:
            self._unfix_design_vector()

            # build objective and solve once
            self.det._attach_objectives(self.scenarios)
            _ = self.det._build_and_solve_framework(self.scenarios)

            return self._extract_design_vector()
        except Exception:
            logger.exception("Warm-start computation failed.")
            return None

    def _get_bounds(
        self,
        x_lower_bound: Sequence[float] | None,
        x_upper_bound: Sequence[float] | None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Prefer explicit bounds passed in."""
        if x_lower_bound is not None and x_upper_bound is not None:
            xl = np.asarray(list(x_lower_bound), dtype=float)
            xu = np.asarray(list(x_upper_bound), dtype=float)
            if xl.size != len(self.variable_names) or xu.size != len(self.variable_names):
                raise ValueError(
                    f"x_lower_bound/x_upper_bound must match variable_names length: "
                    f"{xl.size} / {xu.size} != {len(self.variable_names)}"
                )
            if np.any(xl > xu):
                raise ValueError("Some x_lower_bound > x_upper_bound")
            return xl, xu

        raise ValueError("x_lower_bound/x_upper_bound must be provided for pymoo evaluation.")

    # ----------------------------
    # Public API
    # ----------------------------
    def evaluate_systems(self):
        """Run pymoo optimization and persist results (Pareto + a final deterministic HDF dump for best)."""

        problem = _EtaDeterministicProblem(self, xl=self.xl, xu=self.xu)

        algorithm = self._make_algorithm()
        termination = self._make_termination()

        pymoo_cfg = getattr(self.config, "pymoo", None)
        res = minimize(
            problem,
            algorithm,
            termination,
            seed=int(getattr(pymoo_cfg, "seed", 1) or 1),
            save_history=bool(getattr(pymoo_cfg, "save_history", True) or True),
            verbose=bool(getattr(pymoo_cfg, "verbose", True) or True),
        )

        # persist pareto set + front
        self._save_pymoo_result(res)

        # Optional: also run a "full" deterministic export using your existing HDF structure for ONE selected solution.
        # This gives the same rich dump as deterministic evaluation (unit dispatch etc.).
        try:
            if getattr(res, "variable", None) is not None and len(res.variable) > 0:
                x_best = np.asarray(res.variable[0], dtype=float)  # for multi-objective choose a knee point etc.
                self._apply_design_vector_to_all_scenarios(x_best)
                # this will attach objectives, solve, collect KPIs, and write the "classic" HDF layout
                self.det.evaluate_systems()
        except Exception:
            logger.exception("Could not run full deterministic export for best solution. Keeping pymoo_result.h5 only.")

        return res

    def evaluate_candidate(self, x: np.ndarray) -> tuple[np.ndarray, EvalMeta]:
        """
        Evaluate a single candidate x:
          - fix investment decisions in *each scenario system*
          - attach objective (once)
          - solve via DeterministicFramework
          - return objective value aggregated over scenarios (mean)
        """
        try:
            x = np.asarray(x, dtype=float)

            # apply design to all scenarios first
            self._apply_design_vector_to_all_scenarios(x)

            # attach objectives + solve (this builds/solves via DeterministicFramework)
            self.det._attach_objectives(self.scenarios)
            self.det._build_and_solve_framework(self.scenarios)

            for scen in self.scenarios:
                system = scen.system
                # Linopy: use last_results.solve_info; Pyomo: use system.results.solver
                term = None
                status = None
                last_results = getattr(system, "last_results", None)
                if last_results is not None and hasattr(last_results, "solve_info"):
                    term = getattr(last_results.solve_info, "termination_condition", None)
                    status = getattr(last_results.solve_info, "status", None)
                if term is None or status is None:
                    results = getattr(system, "results", None)
                    solver = getattr(results, "solver", None) if results else None
                    if term is None and solver is not None:
                        term = getattr(solver, "termination_condition", None)
                term_infeasible = term is not None and "infeasible" in str(term).lower()
                status_infeasible = status is not None and "infeasible" in str(status).lower()
                if term_infeasible or status_infeasible:
                    return np.full((1,), self.penalty, float), EvalMeta(False, "Solver infeasible")

            # extract scalar objective per scenario (Linopy: use last_results.solve_info, not system.objective)
            vals = []
            for scen in self.scenarios:
                system = scen.system
                last_results = getattr(system, "last_results", None)
                if (
                    last_results is not None
                    and hasattr(last_results, "solve_info")
                    and getattr(last_results.solve_info, "objective_value", None) is not None
                ):
                    vals.append(float(last_results.solve_info.objective_value))
                else:
                    vals.append(float(numeric_value(system.objective)))

            # aggregate across scenarios (simple mean for deterministic invest scenarios)
            f = np.asarray([float(np.mean(vals))], dtype=float)

            # guard against nan/inf
            if not np.isfinite(f).all():
                return np.full((1,), self.penalty, dtype=float), EvalMeta(False, "Non-finite objective")
            return f, EvalMeta(True, "ok")

        except Exception as e:
            logger.debug("Candidate evaluation failed: %r", e, exc_info=True)
            return np.full((1,), self.penalty, dtype=float), EvalMeta(False, f"Exception: {e!r}")

    # ----------------------------
    # Fixing investment decisions
    # ----------------------------
    def _apply_design_vector_to_all_scenarios(self, x: np.ndarray) -> None:
        """
        Fix investment variables for each scenario based on variable_names.

        Supported variable naming conventions:
          - "<unit_name>"                    -> sets the unit's nominal design variable (E_nom or p_out_nom)
          - "<unit_name>.E_nom"              -> same, explicit
          - "<unit_name>.p_out_nom"          -> same, explicit
          - "<unit_name>.y" or "<unit_name>.bought" -> fixes buy decision (if present)
        """
        mapping = {name: float(val) for name, val in zip(self.variable_names, x, strict=False)}

        for scen in self.scenarios:
            sys = scen.system

            # iterate investment units using DeterministicEvaluator helper
            inv_units = dict(self.det._iter_investments(sys))
            for key, val in mapping.items():
                unit_name, field = self._split_var_key(key)

                if unit_name not in inv_units:
                    raise KeyError(
                        f"Unknown investment unit '{unit_name}' in variable '{key}'. Known: {list(inv_units)}"
                    )

                unit = inv_units[unit_name]

                # buy decision (binary by design, I make sure it is set to binary here)
                if field in ("y", "bought", "is_bought"):
                    y_val = 1.0 if float(val) >= 0.5 else 0.0
                    if hasattr(unit, "is_bought"):
                        unit.is_bought.fix(y_val)
                    elif hasattr(unit, "model") and hasattr(unit.model, "y"):
                        unit.model.y.fix(y_val)
                    else:
                        raise AttributeError(f"Unit '{unit_name}' has no buy decision (is_bought/model.y).")
                    continue

                # nominal sizing (default)
                _, nom_var = self.det._get_design_nominal(unit)
                # if field is explicit, we try to use it, else we use detected nominal variable
                if field not in ("", "E_nom", "e_nom", "p_out_nom", "P_out_nom", "E_nominal", "e_nominal"):
                    raise ValueError(f"Unsupported design field '{field}' in variable '{key}'.")

                # Fix all entries if indexed (Pyomo Var), else fix scalar
                if hasattr(nom_var, "is_indexed") and nom_var.is_indexed():
                    for idx in nom_var:
                        nom_var[idx].fix(val)
                else:
                    nom_var.fix(val) if hasattr(nom_var, "fix") else None

    @staticmethod
    def _split_var_key(key: str) -> tuple[str, str]:
        if "." in key:
            a, b = key.split(".", 1)
            return a, b
        return key, ""

    # ----------------------------
    # Bounds / algorithm / termination
    # ----------------------------
    def _make_algorithm(self):
        # Use pre-built algorithm if your config already provides it
        algo = getattr(getattr(self.config, "algorithm", None), "instance", None)
        if algo is not None:
            return algo

        # Default NSGA2
        from pymoo.algorithms.moo.nsga2 import NSGA2
        from pymoo.operators.crossover.sbx import SBX
        from pymoo.operators.mutation.pm import PM
        from pymoo.operators.sampling.lhs import LHS

        alg_cfg = getattr(self.config, "algorithm", None)
        pop_size = int(getattr(alg_cfg, "pop_size", 80) or 80)

        base_sampling = LHS()

        warm = self._compute_warmstart()
        sampling = WarmStartSampling(warm, base_sampling) if warm is not None else base_sampling

        return NSGA2(
            pop_size=pop_size,
            sampling=sampling,
            crossover=SBX(
                prob=float(getattr(alg_cfg, "crossover_prob", 0.9) or 0.9),
                eta=float(getattr(alg_cfg, "crossover_eta", 15) or 15),
            ),
            mutation=PM(eta=float(getattr(alg_cfg, "mutation_eta", 20) or 20)),
            eliminate_duplicates=True,
        )

    def _make_termination(self):
        tcfg = getattr(self.config, "termination", None)
        if tcfg is None:
            raise ValueError("Missing config section: 'termination'")
        termination_instance = getattr(tcfg, "termination_instance", None)
        if termination_instance is None:
            raise ValueError("Config 'termination' must provide a prebuilt termination_instance.")
        return termination_instance

    # ----------------------------
    # Save pymoo results (Pareto)
    # ----------------------------
    def _save_pymoo_result(self, res: Any) -> None:
        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        hdf_path = out_dir / (Path(self.h5_file_name).stem + "_pymoo_result.h5")
        if hdf_path.exists():
            hdf_path.unlink()

        variable = np.asarray(getattr(res, "variable", np.empty((0, len(self.variable_names)))), dtype=float)
        objective = np.asarray(getattr(res, "F", np.empty((0, len(self.objective_names)))), dtype=float)

        with h5py.File(hdf_path, "w") as f:
            f.create_dataset("variable", data=variable)
            f.create_dataset("F", data=objective)
            f.create_dataset("variable_names", data=np.asarray(self.variable_names, dtype="S"))
            f.create_dataset("objective_names", data=np.asarray(self.objective_names, dtype="S"))

        logger.info("Saved pymoo Pareto result to %s", hdf_path)
