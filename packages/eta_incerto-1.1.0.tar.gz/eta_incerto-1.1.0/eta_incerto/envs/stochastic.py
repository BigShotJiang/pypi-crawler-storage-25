from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import Field

from eta_incerto.envs.base import UncertaintyFramework
from eta_incerto.envs.scenario import Scenario, ScenarioCollection
from eta_incerto.envs.utils import unique_lp_path
from eta_incerto.util.progress import SolverProgressMonitor


class StochasticScenario(Scenario):
    probability: float = Field(ge=0.0)


class StochasticScenarioCollection(ScenarioCollection):
    _scenario_type = StochasticScenario

    def set_scenario(self, scenario: StochasticScenario):
        super().set_scenario(scenario)

    def get_scenario(self, name: str) -> StochasticScenario:
        return super().get_scenario(name)


class StochasticEnv(UncertaintyFramework):
    """Linopy-only: solve each scenario, populate first-stage from highest-probability scenario."""

    def __init__(self, scenarios: StochasticScenarioCollection):
        super().__init__(scenarios)
        self._global_model: Any = None

    def build_model(self) -> None:
        self._global_model = None
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            scenario.system.join_models()
            if scenario.system.objective is not None and hasattr(scenario.system.objective, "construct_objective"):
                scenario.system.objective.construct_objective()

    def submodel(self, name: str):
        raise NotImplementedError("Linopy path has no global model; use scenario.results_bundle instead.")

    def objective_value(self) -> float:
        total = 0.0
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            bundle = getattr(scenario, "results_bundle", None)
            if (
                bundle is not None
                and hasattr(bundle, "solve_info")
                and getattr(bundle.solve_info, "objective_value", None) is not None
            ):
                total += float(scenario.probability) * float(bundle.solve_info.objective_value)
        return total

    def solve(
        self,
        solver_name: str = "highs",
        tee: bool = False,
        options: dict | None = None,
        model_export: bool | str = False,
        model_export_dir: Path | None = None,
        explicit_coordinate_names: bool = True,
    ) -> Any:
        if options is None:
            options = {}
        if model_export_dir is not None:
            model_export_dir = Path(model_export_dir)
            model_export_dir.mkdir(parents=True, exist_ok=True)
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            monitor = SolverProgressMonitor(
                f"Solving scenario {scenario_name} ({solver_name})",
                solver_name,
                options=options,
                tee=tee,
            )
            solver_options = monitor.prepare_options()
            monitor.start()
            try:
                if model_export_dir is not None and model_export is True:
                    model_export_arg = model_export_dir / f"{scenario_name}.lp"
                elif isinstance(model_export, str | Path):
                    model_export_arg = model_export
                else:
                    model_export_arg = None if not model_export else True
                res = scenario.system.solve(
                    solver=solver_name,
                    tee=tee,
                    options=dict(solver_options),
                    model_export=model_export_arg,
                    explicit_coordinate_names=explicit_coordinate_names,
                )
            finally:
                monitor.stop()
            scenario.results_bundle = res
        self._populate_first_stage_from_bundle()
        return getattr(self._scenarios.get_scenario(next(iter(self._scenarios.names()))), "results_bundle", None)

    def _get_best_scenario_name_for_bundle(self) -> str:
        """Name of scenario with highest probability that has a results_bundle."""
        best_name = None
        best_prob = -1.0
        for name in self._scenarios.names():
            sc = self._scenarios.get_scenario(name)
            p = getattr(sc, "probability", 1.0)
            if p >= best_prob and getattr(sc, "results_bundle", None) is not None:
                best_prob = p
                best_name = name
        return best_name or next(iter(self._scenarios.names()))

    @staticmethod
    def _first_stage_key_from_varname(vname: str) -> str | None:
        """Parse first-stage key from variable name, or None if not a first-stage var."""
        vname_lower = vname.lower()
        if "p_out_nom" not in vname_lower and "p_heat_out_nom" not in vname_lower and "e_nom" not in vname_lower:
            return None
        if "__" in vname:
            parts = vname.split("__")
            uname = parts[0]
            suffix = parts[1] if len(parts) > 1 else ""
        elif "_p_out_nom" in vname_lower or "_p_heat_out_nom" in vname_lower:
            for sep in ("_p_heat_out_nom", "_p_out_nom"):
                if sep in vname_lower:
                    idx = vname_lower.index(sep)
                    uname = vname[:idx]
                    suffix = "p_out_nom"
                    break
            else:
                return None
        elif "_e_nom" in vname_lower:
            idx = vname_lower.index("_e_nom")
            uname = vname[:idx]
            suffix = "e_nom"
        else:
            return None
        if "p_out_nom" in suffix.lower() or "p_heat_out_nom" in vname_lower:
            return f"{uname}.p_out_nom"
        if "e_nom" in suffix.lower():
            return f"{uname}.{suffix}"
        return None

    def _fill_first_stage_from_items(self, items: list, scenario: StochasticScenario) -> None:
        """Populate _first_stage_variables from (vname, da) items using key parsing."""
        for vname, da in items:
            key = self._first_stage_key_from_varname(vname)
            if key is None:
                continue
            try:
                if hasattr(da, "sum"):
                    val = float(da.sum().values)
                else:
                    flat = da.values.flatten()
                    val = float(flat[0]) if flat.size else 0.0
            except Exception:
                val = 0.0
            self._first_stage_variables[key] = val

    def _fill_first_stage_units_fallback(self, scenario: StochasticScenario, items: list) -> None:
        """Fallback: fill first-stage from items by matching unit names."""
        for unit in getattr(scenario.system, "units", []):
            uname = getattr(unit, "name", "")
            if not uname:
                continue
            for vname, da in list(items):
                if uname not in vname or ("p_out_nom" not in vname.lower() and "p_heat_out_nom" not in vname.lower()):
                    continue
                try:
                    val = float(da.sum().values) if hasattr(da, "sum") else float(da.values.flatten()[0])
                except Exception:
                    val = 0.0
                self._first_stage_variables[f"{uname}.p_out_nom"] = val
                break

    def _populate_first_stage_from_bundle(self) -> None:
        """Fill _first_stage_variables from the highest-probability scenario's results_bundle (Linopy path)."""
        best_name = self._get_best_scenario_name_for_bundle()
        scenario = self._scenarios.get_scenario(best_name)
        bundle = getattr(scenario, "results_bundle", None) or getattr(scenario.system, "last_results", None)
        if bundle is None or not hasattr(bundle, "vars"):
            return
        vars_ds = bundle.vars
        try:
            items = list(
                vars_ds.items() if hasattr(vars_ds, "items") else getattr(vars_ds, "data_vars", vars_ds).items()
            )
        except Exception:
            return
        self._fill_first_stage_from_items(items, scenario)
        if self._first_stage_variables:
            return
        self._fill_first_stage_units_fallback(scenario, items)

    def clear(self) -> None:
        self._scenarios.clear()
        self._global_model = None


class StochasticFramework(UncertaintyFramework):
    """Linopy path: solve each scenario independently, aggregate weighted objective.
    When use_two_stage: holds a single system, one build and one solve.
    """

    def __init__(self, scenarios: StochasticScenarioCollection):
        super().__init__(scenarios)
        self._system: Any = None  # When set, two-stage path: one system, one solve
        self._results_bundle: Any = None  # Single bundle when two-stage

    def set_system(self, system: Any) -> None:
        """Set the single system for two-stage path (one build, one solve)."""
        self._system = system

    def build_model(self) -> None:
        if self._system is not None:
            self._system.join_models()
            if self._system.objective is not None and hasattr(self._system.objective, "construct_objective"):
                self._system.objective.construct_objective()
            return
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            scenario.system.join_models()
            if scenario.system.objective is not None and hasattr(scenario.system.objective, "construct_objective"):
                scenario.system.objective.construct_objective()

    def solve(
        self,
        solver_name: str = "highs",
        tee: bool = False,
        options: dict | None = None,
        model_export: bool | str = False,
        model_export_dir: Path | None = None,
        explicit_coordinate_names: bool = True,
    ):
        if options is None:
            options = {}
        if model_export_dir is not None:
            model_export_dir = Path(model_export_dir)
            model_export_dir.mkdir(parents=True, exist_ok=True)
        if self._system is not None:
            monitor = SolverProgressMonitor(
                f"Solving two-stage system ({solver_name})",
                solver_name,
                options=options,
                tee=tee,
            )
            solver_options = monitor.prepare_options()
            monitor.start()
            try:
                if model_export_dir is not None and model_export is True:
                    model_export_arg = unique_lp_path(model_export_dir, "two_stage.lp")
                elif isinstance(model_export, str | Path):
                    model_export_arg = model_export
                else:
                    model_export_arg = None if not model_export else True
                res = self._system.solve(
                    solver=solver_name,
                    tee=tee,
                    options=dict(solver_options),
                    model_export=model_export_arg,
                    explicit_coordinate_names=explicit_coordinate_names,
                )
            finally:
                monitor.stop()
            self._results_bundle = res
            return
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            monitor = SolverProgressMonitor(
                f"Solving scenario {scenario_name} ({solver_name})",
                solver_name,
                options=options,
                tee=tee,
            )
            solver_options = monitor.prepare_options()
            monitor.start()
            try:
                if model_export_dir is not None and model_export is True:
                    model_export_arg = unique_lp_path(model_export_dir, f"{scenario_name}.lp")
                elif isinstance(model_export, str | Path):
                    model_export_arg = model_export
                else:
                    model_export_arg = None if not model_export else True
                res = scenario.system.solve(
                    solver=solver_name,
                    tee=tee,
                    options=dict(solver_options),
                    model_export=model_export_arg,
                    explicit_coordinate_names=explicit_coordinate_names,
                )
            finally:
                monitor.stop()
            scenario.results_bundle = res

    def objective_value(self) -> float:
        if self._results_bundle is not None and hasattr(self._results_bundle, "solve_info"):
            obj = self._results_bundle.solve_info.objective_value
            if obj is not None:
                return float(obj)
        total = 0.0
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            bundle = getattr(scenario, "results_bundle", None)
            if bundle is not None and hasattr(bundle, "solve_info"):
                obj = bundle.solve_info.objective_value
                if obj is not None:
                    total += float(scenario.probability) * float(obj)
        return total

    def submodel(self, name: str):
        raise NotImplementedError("Linopy path has no global model; use scenario.results_bundle instead.")

    def graph_representation(self) -> dict:
        """Return nodes/edges for topology; when two-stage use single system."""
        if self._system is not None and hasattr(self._system, "graph_representation"):
            return self._system.graph_representation()
        return super().graph_representation()

    def clear(self) -> None:
        self._scenarios.clear()
        self._system = None
        self._results_bundle = None
