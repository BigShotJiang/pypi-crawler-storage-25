from __future__ import annotations

import logging
from collections.abc import Iterator
from json import dumps, load
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import xarray as xr
from eta_components.milp_component_library.backends.protocol import ResultsBundle
from eta_components.milp_component_library.custom_types import BasicSystem
from eta_components.milp_component_library.objectives import Emissions, NetPresentValue, TotalAnnualizedCost
from numpy import array
from pydantic import BaseModel, ConfigDict, Field

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.envs.deterministic import DeterministicFramework
from eta_incerto.envs.scenario import ScenarioCollection
from eta_incerto.envs.utils import (
    aggregate_for_years,
    check_plausibility_trader_cost,
    iter_investment_units,
    numeric_value,
    trader_scalar_or_year_da,
)
from eta_incerto.util.h5_config import save_config_to_h5

logger = logging.getLogger(__name__)


class DeterministicEvaluator(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: ConfigOptimization = Field(..., description="Optimization config from central config.json")
    scenarios: ScenarioCollection = Field(..., description="Scenarios to evaluate deterministically")
    h5_file_name: str

    # -----------------------
    # Linopy: dump from ResultsBundle.vars
    # -----------------------

    def _dump_unit_from_bundle(self, dump_root: h5py.Group, unit_name: str, vars_ds: xr.Dataset) -> None:
        """Dump variables in vars_ds with prefix unit_name + '__' as keys+values (old Pyomo layout).

        Writes units/<unit_name>/<short_component>/keys and .../values so dispatch plotter can read.
        dump_root is either unit_dispatch (then we create units/<unit_name>) or the units group
        (then we create <unit_name>).
        """
        prefix = f"{unit_name}__"
        parent = dump_root.get("units", dump_root)
        ugrp = parent.require_group(unit_name)
        for vname, da in vars_ds.data_vars.items():
            if not vname.startswith(prefix):
                continue
            short_component = vname[len(prefix) :].replace("/", "_")
            if not short_component:
                short_component = "value"
            if short_component in ugrp:
                short_component = f"{short_component}_{'_'.join(da.dims)}"
            comp_grp = ugrp.require_group(short_component)
            if "keys" in comp_grp:
                del comp_grp["keys"]
            if "values" in comp_grp:
                del comp_grp["values"]
            if da.ndim == 0:
                keys_arr = array(["()"], dtype=object)
                vals_arr = array([float(da.values)], dtype=float)
            else:
                dims = da.dims
                keys_list = []
                for idx in range(da.size):
                    multi_idx = np.unravel_index(idx, da.shape)
                    t = tuple(da.coords[d].values[multi_idx[i]].item() for i, d in enumerate(dims))
                    keys_list.append(repr(t))
                keys_arr = array(keys_list, dtype=object)
                vals_arr = array(da.values.ravel(), dtype=float)
            dt_str = h5py.string_dtype(encoding="utf-8")
            comp_grp.create_dataset("keys", data=keys_arr, dtype=dt_str)
            comp_grp.create_dataset("values", data=vals_arr)

    # -----------------------
    # eta-components helpers
    # -----------------------

    def _iter_traders(self, system: BasicSystem) -> Iterator[tuple[str, Any]]:
        for unit in system.units:
            if all(hasattr(unit, attr) for attr in ("amount", "time_step_cost", "emissions")):
                yield unit.name, unit

    def _iter_investments(self, system: BasicSystem) -> Iterator[tuple[str, Any]]:
        yield from iter_investment_units(system)

    def _total_investment_cost_from_bundle(self, system: BasicSystem, bundle: ResultsBundle) -> float:
        total = 0.0
        for inv_name, _ in self._iter_investments(system):
            for vname, da in bundle.vars.data_vars.items():
                if not vname.startswith(f"{inv_name}__"):
                    continue
                if "onetime_cost" in vname or "investment_cost" in vname:
                    total += float(da.sum().values)
                    break
        return total

    def _get_design_param_key(self, unit: Any) -> str:
        """Return the data key used to set design size (for update_data / support). Linopy-friendly."""
        if hasattr(unit, "vars") and isinstance(unit.vars, dict):
            if "e_nom" in unit.vars:
                return "E_nom_support"
            if "p_out_nom" in unit.vars or "P_out_nom" in unit.vars:
                return "P_out_nom_support"
        if hasattr(unit, "data") and isinstance(unit.data, dict):
            for k in ("E_nom_support", "P_out_nom_support", "e_nom", "p_out_nom"):
                if k in unit.data:
                    return "E_nom_support" if "E_nom" in k or "e_nom" in k else "P_out_nom_support"
        return "E_nom_support"

    @staticmethod
    def _get_first_attr(obj: Any, names: tuple[str, ...]) -> tuple[str | None, Any | None]:
        for n in names:
            if hasattr(obj, n):
                try:
                    return n, getattr(obj, n)
                except Exception:
                    continue
        return None, None

    def _read_investment_unit_from_bundle(self, inv_unit: Any, bundle: ResultsBundle) -> dict[str, float | str]:
        inv_name = getattr(inv_unit, "name", "?")
        prefix = f"{inv_name}__"
        out: dict[str, float | str] = {
            "bought": 0.0,
            "design_var_name": "",
            "E_nom": 0.0,
            "investment_cost": 0.0,
        }
        vars_ds = getattr(bundle, "vars", None)
        if vars_ds is None:
            return out
        data_vars = getattr(vars_ds, "data_vars", None) or getattr(vars_ds, "variables", None)
        if data_vars is None or not hasattr(data_vars, "items"):
            return out

        def _first_year_or_sum(da):  # Standard: report single investment (first year only)
            if not da.size:
                return 0.0
            if "year" in getattr(da, "dims", ()):
                return float(da.isel(year=0).sum().values)
            return float(da.sum().values)

        for vname, da in data_vars.items():
            if not vname.startswith(prefix):
                continue
            val = _first_year_or_sum(da)
            if "y" in vname or "is_bought" in vname:
                # Report bought as 0 or 1 (semantic: unit bought or not); avoid e.g. 10 when batch has 10 scenarios
                out["bought"] = float((da > 0).any()) if da.size else 0.0
            elif (
                "e_nom" in vname.lower()
                or "p_out_nom" in vname
                or ("p_heat_out_nom" in vname and "_nom_on" not in vname)
                or ("p_cool_out_nom" in vname and "_nom_on" not in vname)
                or vname.endswith("__area")
            ):
                out["E_nom"] = val
                out["design_var_name"] = vname.split("__")[-1]
            elif "onetime_cost" in vname or "investment_cost" in vname:
                out["investment_cost"] = val
            elif "E_nom_min" in vname:
                out["E_nom_min"] = _first_year_or_sum(da)
            elif "E_nom_max" in vname or "p_out_nom_max" in vname:
                out["E_nom_max"] = _first_year_or_sum(da)
        return out

    def _read_investment_unit(self, inv_unit: Any, bundle: ResultsBundle | None = None) -> dict[str, float | str]:
        """Read investment metrics from a bundle or from the unit's solved state."""
        if bundle is not None and hasattr(bundle, "vars"):
            raw = self._read_investment_unit_from_bundle(inv_unit, bundle)
            out: dict[str, float | str] = {
                "bought": raw["bought"],
                "investment_cost": raw["investment_cost"],
                "E_nom": raw["E_nom"],
            }
            out["p_out_nom"] = raw.get("E_nom", 0.0)
            if "E_nom_min" in raw:
                out["E_nom_min"] = raw["E_nom_min"]
            if "E_nom_max" in raw:
                out["E_nom_max"] = raw["E_nom_max"]
            return out

        # Read from unit attributes (solved model / unit state)
        def _val(primary_getter: Any, fallback_getter: Any) -> float:
            try:
                return float(numeric_value(primary_getter()))
            except Exception:
                return float(numeric_value(fallback_getter()))

        def _fallback_y() -> float:
            return float(getattr(inv_unit.model, "y", 0)) if hasattr(inv_unit, "model") else 0.0

        def _fallback_p_nom() -> float:
            return float(getattr(inv_unit.model, "p_out_nom", 0)) if hasattr(inv_unit, "model") else 0.0

        def _fallback_e_nom() -> float:
            if hasattr(inv_unit, "model") and hasattr(inv_unit.model, "e_nom"):
                return float(numeric_value(inv_unit.model.e_nom))
            if hasattr(inv_unit, "E_nom"):
                return float(numeric_value(inv_unit.E_nom))
            return p_nom_val

        def _fallback_cost() -> float:
            return float(getattr(inv_unit.model, "investment_cost", 0)) if hasattr(inv_unit, "model") else 0.0

        y_val = _val(lambda: getattr(inv_unit, "is_bought", 0), _fallback_y)
        p_nom_val = _val(lambda: getattr(inv_unit, "_p_out_nom", 0), _fallback_p_nom)
        e_nom_val = _val(lambda: getattr(inv_unit, "_e_nom", 0), _fallback_e_nom)
        invest_cost_val = _val(lambda: getattr(inv_unit, "onetime_cost", 0), _fallback_cost)

        # Linopy dimensioning units may only expose nominal via unit.vars
        if (p_nom_val == 0.0 or e_nom_val == 0.0) and hasattr(inv_unit, "vars") and isinstance(inv_unit.vars, dict):
            for key in ("p_heat_out_nom", "p_out_nom", "e_nom"):
                if key in inv_unit.vars:
                    try:
                        var_val = inv_unit.vars[key]
                        v = numeric_value(var_val.sum() if hasattr(var_val, "sum") else var_val)
                        if v > 0:
                            p_nom_val = v if p_nom_val == 0.0 else p_nom_val
                            e_nom_val = v if e_nom_val == 0.0 else e_nom_val
                            break
                    except Exception:
                        pass

        result: dict[str, float | str] = {
            "bought": y_val,
            "p_out_nom": p_nom_val,
            "E_nom": e_nom_val,
            "investment_cost": invest_cost_val,
        }
        if hasattr(inv_unit, "model") and hasattr(inv_unit.model, "p_out_nom_min"):
            result["p_out_nom_min"] = float(numeric_value(inv_unit.model.p_out_nom_min))
        if hasattr(inv_unit, "model") and hasattr(inv_unit.model, "p_out_nom_max"):
            result["p_out_nom_max"] = float(numeric_value(inv_unit.model.p_out_nom_max))
        return result

    def _collect_investment_metrics_from_bundle(
        self, system: BasicSystem, bundle: ResultsBundle
    ) -> dict[str, dict[str, float | str]]:
        invest_metrics: dict[str, dict[str, float | str]] = {}
        for inv_name, inv_unit in self._iter_investments(system):
            invest_metrics[inv_name] = self._read_investment_unit_from_bundle(inv_unit, bundle)
        return invest_metrics

    # -----------------------
    # objective attachment + solve
    # -----------------------

    def _load_weights(self, series_file_name: str, system: BasicSystem) -> dict[int, float]:
        weights_path = self.config.paths.series_dir / series_file_name / "weights.json"
        if not weights_path.exists():
            raise FileNotFoundError(f"No weights.json found for series {series_file_name}")
        with weights_path.open() as f:
            raw = load(f)
        raw = {int(k): float(v) for k, v in raw.items()}
        n_time_steps = len(system.index.coords["time"])
        step_length = float(getattr(system, "step_length", 1.0))
        scale = 8760.0 / (n_time_steps * step_length)
        weights = {}
        for y in system.years_set:
            for p, w in raw.items():
                weights[(y, p)] = w * scale
        return weights

    def _attach_objectives(self, scenarios: ScenarioCollection) -> None:
        objective_kind = self.config.pyomo.objective_kind
        for scen in scenarios:
            system: BasicSystem = scen.system
            weights = self._load_weights(scen.series_file_name, system)
            npv_obj = NetPresentValue(
                "npv_objective",
                {
                    "weights": weights,
                    "interest": self.config.pyomo.interest,
                    "emission_cost": self.config.pyomo.emission_cost,
                },
                system,
            )
            tac_obj = TotalAnnualizedCost(
                "tac_objective",
                {
                    "weights": weights,
                    "interest": self.config.pyomo.interest,
                    "emission_cost": self.config.pyomo.emission_cost,
                    "n_years": self.config.pyomo.horizon.n_years,
                },
                system,
            )
            emissions_obj = Emissions(
                "emissions_objective",
                {"weights": weights},
                system,
            )
            if objective_kind == "npv":
                system.set_objective(npv_obj)
            elif objective_kind == "tac":
                system.set_objective(tac_obj)
            elif objective_kind == "emissions":
                system.set_objective(emissions_obj)
            else:
                raise ValueError(f"Unknown objective_kind: {objective_kind}")

    def _build_and_solve_framework(
        self, scenarios: ScenarioCollection, options_override: dict | None = None
    ) -> DeterministicFramework:
        fw = DeterministicFramework(scenarios=scenarios)
        fw.build_model()
        opts = {
            **self.config.pyomo.solver_settings.options,
            **(options_override or {}),
        }
        if getattr(self.config.pyomo.solver_settings, "use_solver_api", False):
            opts["use_solver_api"] = True
        solver_name = self.config.pyomo.solver_settings.solver
        model_export = self.config.pyomo.solver_settings.model_export
        model_export_dir = None
        if model_export is True:
            model_export_dir = Path(self.config.paths.results_dir) / "lp" / Path(self.h5_file_name).stem
        fw.solve(
            solver_name=solver_name,
            tee=self.config.pyomo.solver_settings.tee,
            options=opts,
            model_export=model_export,
            model_export_dir=model_export_dir,
        )
        return fw

    # -----------------------
    # results collection (ResultsBundle only)
    # -----------------------

    def _collect_results(self, scenarios: ScenarioCollection, fw: DeterministicFramework) -> dict[str, dict[Any, Any]]:
        results: dict[str, dict[Any, Any]] = {}

        for scen in scenarios:
            system: BasicSystem = scen.system
            bundle = getattr(scen, "results_bundle", None)
            if bundle is None or not isinstance(bundle, ResultsBundle):
                raise RuntimeError(
                    f"Scenario {scen.name} has no results_bundle (Linopy ResultsBundle). "
                    "Ensure DeterministicFramework.solve() ran and stored results."
                )

            dt_hours = float(getattr(system, "step_length", 1.0))
            energy_to_kwh = 1.0 / 1000
            vars_ds = bundle.vars

            trader_vals_yearly: dict[str, dict[str, dict[int, float]]] = {}
            for trader_name, trader in self._iter_traders(system):
                amount_var = f"{trader_name}__amount"
                if amount_var not in vars_ds:
                    continue
                amount_da = vars_ds[amount_var]
                qty_w_avg_period_by_year = aggregate_for_years(amount_da, system)
                qty_wh = {int(y): float(v) * dt_hours for y, v in qty_w_avg_period_by_year.items()}
                qty_kwh_by_year = {y: v * energy_to_kwh for y, v in qty_wh.items()}

                unit_price = trader_scalar_or_year_da(trader.data.get("unit_price"), amount_da, 0.0)
                cost_da = amount_da * unit_price
                costs_avg = aggregate_for_years(cost_da, system)
                costs_by_year = {int(y): float(v) for y, v in costs_avg.items()}

                epu = trader_scalar_or_year_da(trader.data.get("emissions_per_unit"), amount_da, 0.0)
                emissions_da = amount_da * epu
                emissions_avg = aggregate_for_years(emissions_da, system)
                emissions_by_year = {int(y): float(v) for y, v in emissions_avg.items()}

                check_plausibility_trader_cost(
                    amount_da,
                    unit_price,
                    system,
                    costs_by_year,
                    trader_name,
                )

                trader_vals_yearly[trader_name] = {
                    "Quantity_kWh_per_year": qty_kwh_by_year,
                    "Costs_per_year": costs_by_year,
                    "Emissions_per_year": emissions_by_year,
                }

            obj_val = bundle.solve_info.objective_value
            if obj_val is None:
                obj_val = 0.0
            obj_val = float(obj_val)

            opex_by_year: dict[int, float] = {}
            if "opex_by_year" in getattr(bundle, "derived", xr.Dataset()).data_vars:
                opex_da = bundle.derived["opex_by_year"]
                for y in system.years_set:
                    opex_by_year[int(y)] = float(opex_da.sel(year=y).values)
            else:
                for y in system.years_set:
                    opex_by_year[int(y)] = 0.0

            capex_total = self._total_investment_cost_from_bundle(system, bundle)
            invest_metrics = self._collect_investment_metrics_from_bundle(system, bundle)

            metrics: dict[tuple[str, str], Any] = {}
            for inv_name, im in invest_metrics.items():
                metrics[("technical", f"{inv_name}_E_nom")] = float(im["E_nom"])
                metrics[("technical", f"{inv_name}_design_var_name")] = str(im.get("design_var_name", ""))
                metrics[("economical", f"{inv_name}_capex")] = float(im["investment_cost"])
                metrics[("technical", f"{inv_name}_bought")] = float(im["bought"])
                if "E_nom_min" in im:
                    metrics[("technical", f"{inv_name}_E_nom_min")] = float(im["E_nom_min"])
                if "E_nom_max" in im:
                    metrics[("technical", f"{inv_name}_E_nom_max")] = float(im["E_nom_max"])

            metrics[("economical", "capex_total")] = capex_total
            metrics[("economical", "npv_yearly")] = obj_val
            metrics[("economical", "opex_yearly")] = opex_by_year
            metrics[("technical", "traders_yearly")] = trader_vals_yearly

            results[scen.name] = metrics
            logger.info("Scenario %s solved: %s = %.6g", scen.name, self.config.pyomo.objective_kind.upper(), obj_val)

        return results

    # -----------------------
    # save results
    # -----------------------

    def _save_results(
        self,
        results: dict[str, dict[Any, Any]],
        h5_file_name: str,
        fw: DeterministicFramework,
        scenarios: ScenarioCollection,
    ) -> None:
        out_dir = Path(self.config.paths.results_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        hdf_path = out_dir / h5_file_name
        if hdf_path.exists():
            hdf_path.unlink()

        def _to_hdf5_value(v: Any) -> Any:
            if isinstance(v, dict | list | tuple):
                return dumps(v).encode("utf-8")
            if isinstance(v, str):
                return v.encode("utf-8")
            if v is None:
                return b""
            return v

        with h5py.File(hdf_path, "w") as f:
            for scen_name, metrics in results.items():
                grp = f.create_group(scen_name)
                for (category, name), v in metrics.items():
                    cat_grp = grp.require_group(category)
                    if name in cat_grp:
                        del cat_grp[name]
                    v2 = _to_hdf5_value(v)
                    try:
                        cat_grp.create_dataset(name, data=v2)
                    except TypeError:
                        cat_grp.create_dataset(name, data=str(v2))

            for scen in scenarios:
                scen_grp = f.require_group(scen.name)
                dump_root = scen_grp.require_group("unit_dispatch")
                bundle = getattr(scen, "results_bundle", None)
                if isinstance(bundle, ResultsBundle):
                    for unit in scen.system.units:
                        self._dump_unit_from_bundle(dump_root, unit.name, bundle.vars)

            config_dict = getattr(self.config, "to_dict", lambda: self.config.__dict__)()
            save_config_to_h5(f.create_group("config"), config_dict)

        logger.info("Evaluation results for %d scenarios written to: %s", len(results), hdf_path)

    # -----------------------
    # Public API
    # -----------------------

    def evaluate_systems(self, scenarios: ScenarioCollection | None = None) -> dict[str, dict[Any, Any]]:
        scenarios = self.scenarios if scenarios is None else scenarios
        self._attach_objectives(scenarios)
        fw = self._build_and_solve_framework(scenarios)
        results = self._collect_results(scenarios, fw)
        self._save_results(results, self.h5_file_name, fw, scenarios)
        return results
