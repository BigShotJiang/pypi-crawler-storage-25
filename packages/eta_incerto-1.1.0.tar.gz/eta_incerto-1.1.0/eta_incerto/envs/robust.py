from __future__ import annotations

from pathlib import Path
from typing import Any

from eta_incerto.envs.base import ScenarioCollection, UncertaintyFramework
from eta_incerto.envs.utils import unique_lp_path


class RobustFramework(UncertaintyFramework):
    """Robust (min-max) framework: minimize the worst-case scenario objective.
    When use_two_stage: holds a single system, one build and one solve (RobustAggregator objective).
    """

    def __init__(self, scenarios: ScenarioCollection):
        super().__init__(scenarios=scenarios)
        self._global_model: Any = None
        self._system: Any = None
        self._results_bundle: Any = None

    def set_system(self, system: Any) -> None:
        """Set the single system for two-stage path."""
        self._system = system

    def build_model(self) -> None:
        self._global_model = None
        if self._system is not None:
            self._system.join_models()
            if self._system.objective is not None and hasattr(self._system.objective, "construct_objective"):
                self._system.objective.construct_objective()
            return
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            if hasattr(scenario.system, "join_models"):
                scenario.system.join_models()
            if scenario.system.objective is not None and hasattr(scenario.system.objective, "construct_objective"):
                scenario.system.objective.construct_objective()

    def objective_value(self) -> float:
        if self._results_bundle is not None and hasattr(self._results_bundle, "solve_info"):
            obj = getattr(self._results_bundle.solve_info, "objective_value", None)
            if obj is not None:
                return float(obj)
        return getattr(self, "_worst_objective_value", 0.0)

    @staticmethod
    def _model_export_arg(
        model_export: bool | str | Path,
        model_export_dir: Path | None,
        lp_basename: str | None = None,
    ) -> Path | str | bool | None:
        """Resolve model_export into the value to pass to system.solve(model_export=...)."""
        if model_export_dir is not None and model_export is True:
            name = lp_basename if lp_basename is not None else "two_stage.lp"
            return unique_lp_path(model_export_dir, name)
        if isinstance(model_export, str | Path):
            return model_export
        return None if not model_export else True

    @staticmethod
    def _solve_with_monitor(
        system: Any,
        label: str,
        solver_name: str,
        tee: bool,
        options: dict,
        model_export_arg: Path | str | bool | None,
        explicit_coordinate_names: bool = True,
    ) -> Any:
        """Run system.solve with a progress monitor; return the results bundle."""
        from eta_incerto.util.progress import SolverProgressMonitor

        monitor = SolverProgressMonitor(label, solver_name, options=options, tee=tee)
        solver_options = monitor.prepare_options()
        monitor.start()
        try:
            return system.solve(
                solver=solver_name,
                tee=tee,
                options=dict(solver_options),
                model_export=model_export_arg,
                explicit_coordinate_names=explicit_coordinate_names,
            )
        finally:
            monitor.stop()

    def solve(
        self,
        solver_name: str = "highs",
        tee: bool = False,
        options: dict | None = None,
        model_export: bool | str = False,
        model_export_dir: Path | None = None,
        explicit_coordinate_names: bool = True,
    ) -> Any:
        if options is None:
            options = {}
        if model_export_dir is not None:
            model_export_dir = Path(model_export_dir)
            model_export_dir.mkdir(parents=True, exist_ok=True)
        if self._system is not None:
            model_export_arg = self._model_export_arg(model_export, model_export_dir, None)
            res = self._solve_with_monitor(
                self._system,
                f"Solving two-stage robust system ({solver_name})",
                solver_name,
                tee,
                options,
                model_export_arg,
                explicit_coordinate_names,
            )
            self._results_bundle = res
            return res
        worst_val = None
        worst_name = None
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            model_export_arg = self._model_export_arg(model_export, model_export_dir, f"{scenario_name}.lp")
            res = self._solve_with_monitor(
                scenario.system,
                f"Solving scenario {scenario_name} ({solver_name})",
                solver_name,
                tee,
                options,
                model_export_arg,
                explicit_coordinate_names,
            )
            scenario.results_bundle = res
            bundle = getattr(scenario, "results_bundle", None)
            obj_val = None
            if bundle is not None and hasattr(bundle, "solve_info") and hasattr(bundle.solve_info, "objective_value"):
                obj_val = bundle.solve_info.objective_value
            if obj_val is not None and (worst_val is None or float(obj_val) > (worst_val or 0)):
                worst_val = float(obj_val)
                worst_name = scenario_name
        self._worst_objective_value = worst_val if worst_val is not None else 0.0
        if worst_name is not None:
            self._populate_first_stage_from_scenario(worst_name)
        return getattr(self._scenarios.get_scenario(next(iter(self._scenarios.names()))), "results_bundle", None)

    def graph_representation(self) -> dict:
        """Return nodes and edges; when two-stage use single system."""
        if self._system is not None and hasattr(self._system, "graph_representation"):
            return self._system.graph_representation()
        rep = super().graph_representation()
        edges = rep.get("edges", [])
        if edges and isinstance(edges[0], dict):
            out_edges = []
            for e in edges:
                s, t = e["source"], e["target"]
                out_edges.append((s, t))
                out_edges.append((t, s))
            rep["edges"] = out_edges
        return rep

    def plot_topology(self) -> None:
        """No-op for tests that call it."""
        pass
