from __future__ import annotations

from pathlib import Path
from typing import Any

from eta_incerto.envs.base import ScenarioCollection
from eta_incerto.util.progress import SolverProgressMonitor


class DeterministicFramework:
    """Linopy-only: per-scenario solve; no global model."""

    def __init__(self, scenarios: ScenarioCollection):
        self._scenarios = scenarios
        self._global_model: Any = None

    def build_model(self) -> None:
        """Join models and construct objectives per scenario."""
        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)
            scenario.system.join_models()
            if scenario.system.objective is not None and hasattr(scenario.system.objective, "construct_objective"):
                scenario.system.objective.construct_objective()

    def solve(
        self,
        solver_name: str,
        tee: bool = False,
        options: dict | None = None,
        model_export: bool | str = False,
        model_export_dir: Path | None = None,
    ):
        """
        Solve each scenario with scenario.system.solve(). Stores ResultsBundle on scenario.results_bundle.

        - solver_name: e.g. "highs", "cplex", "gurobi"
        - model_export: if True, export LP from each system; if str/path, export to that path per scenario
        - model_export_dir: when model_export is True, write one .lp per scenario here (e.g. dir/S1.lp)
        """
        if options is None:
            options = {}

        if model_export_dir is not None:
            model_export_dir = Path(model_export_dir)
            model_export_dir.mkdir(parents=True, exist_ok=True)

        results_by_scenario = {}

        for scenario_name in self._scenarios.names():
            scenario = self._scenarios.get_scenario(scenario_name)

            monitor = SolverProgressMonitor(
                f"Solving scenario {scenario_name} ({solver_name})",
                solver_name,
                options=options,
                tee=tee,
            )
            solver_options = monitor.prepare_options()
            monitor.start()
            try:
                if model_export_dir is not None and model_export is True:
                    model_export_arg = model_export_dir / f"{scenario_name}.lp"
                elif isinstance(model_export, str | Path):
                    model_export_arg = model_export
                else:
                    model_export_arg = None if not model_export else True
                res = scenario.system.solve(
                    solver=solver_name,
                    tee=tee,
                    options=dict(solver_options),
                    model_export=model_export_arg,
                )
            finally:
                monitor.stop()

            scenario.results_bundle = res
            results_by_scenario[scenario_name] = res

        return results_by_scenario
