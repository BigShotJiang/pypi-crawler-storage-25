from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from eta_incerto.analysis.monte_carlo.datastructures import Design, Stage


@dataclass(frozen=True, slots=True)
class SurrogateEvaluator:
    """Optional surrogate / PCE-backed evaluator for Monte Carlo analysis.

    This class defines the integration point for fast approximation-based
    evaluation in the Monte Carlo pipeline. It implements the same evaluator
    contract as the direct EtaIncerto-based evaluator:

        (design, sampled_inputs, stage) -> KPI mapping

    Intended integration pattern:
    - load a trained surrogate model (e.g. PCE, regression, emulator)
    - map sampled_inputs into the surrogate input space
    - predict KPIs
    - return a dict with the same KPI names as the direct evaluator
      (e.g. "capex", "tac", "total_emissions")

    Current behavior:
    - if no surrogate model is provided, a NotImplementedError is raised
    - if a surrogate model object is provided, it must expose either:
        * predict(design=..., sampled_inputs=..., stage=...)
      or
        * __call__(design=..., sampled_inputs=..., stage=...)
      and return a KPI mapping

    This keeps the Monte Carlo pipeline backend-pluggable while allowing
    future acceleration via surrogate / PCE models without changing the
    orchestration layer.
    """

    model: Any | None = None

    def __call__(
        self,
        design: Design,
        sampled_inputs: Mapping[str, Any],
        stage: Stage,
    ) -> Mapping[str, float]:
        """Evaluate one sampled world using a surrogate / PCE backend."""
        if self.model is None:
            raise NotImplementedError(
                "SurrogateEvaluator was selected, but no surrogate model was provided. "
                "Provide a trained surrogate/PCE model or use monte_carlo.backend='direct'."
            )

        prediction = self._predict(
            design=design,
            sampled_inputs=sampled_inputs,
            stage=stage,
        )
        return self._normalize_prediction(prediction)

    def _predict(
        self,
        *,
        design: Design,
        sampled_inputs: Mapping[str, Any],
        stage: Stage,
    ) -> Any:
        """Call the wrapped surrogate model using a small, stable adapter layer."""
        if hasattr(self.model, "predict"):
            return self.model.predict(
                design=design,
                sampled_inputs=sampled_inputs,
                stage=stage,
            )

        if callable(self.model):
            return self.model(
                design=design,
                sampled_inputs=sampled_inputs,
                stage=stage,
            )

        raise TypeError(
            "Unsupported surrogate model interface. Expected an object with 'predict(...)' or a callable model."
        )

    def _normalize_prediction(self, prediction: Any) -> dict[str, float]:
        """Validate and normalize surrogate output to KPI -> float."""
        if not isinstance(prediction, Mapping):
            raise TypeError("Surrogate model must return a mapping of KPI names to numeric values.")

        out: dict[str, float] = {}
        for key, value in prediction.items():
            try:
                out[str(key)] = float(value)
            except (TypeError, ValueError) as exc:
                raise TypeError(f"Surrogate prediction for KPI '{key}' is not numeric: {value!r}") from exc

        if not out:
            raise ValueError("Surrogate model returned an empty KPI mapping.")

        return out
