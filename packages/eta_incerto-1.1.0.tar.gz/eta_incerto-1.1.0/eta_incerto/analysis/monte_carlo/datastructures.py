from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class SourceType(str, Enum):
    """Supported sources for loading designs and uncertainty models."""

    JSON = "json"
    H5 = "h5"


class PerturbationKind(str, Enum):
    """How baseline uncertainty is perturbed across stages."""

    SIGMA_SCALE = "sigma_scale"
    BOUNDS_WIDEN = "bounds_widen"
    DIST_OVERRIDE = "dist_override"
    STRESS_FACTOR = "stress_factor"


class UncertaintyMode(str, Enum):
    """Whether perturbation affects sampling randomness or epistemic assumptions."""

    ALEATORY = "aleatory"
    EPISTEMIC = "epistemic"


class SampleStatus(str, Enum):
    """Status codes for sampling/evaluation outcomes."""

    OK = "ok"
    INFEASIBLE = "infeasible"
    FAILED = "failed"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


class FeasibilityPolicy(str, Enum):
    """How infeasible/failed evaluations contribute to the MC dataset."""

    SKIP = "skip"
    PENALIZE = "penalize"
    REPAIR = "repair"


class SeedMode(str, Enum):
    """Seed policy (matches the plan: fixed/random/multi)."""

    FIXED = "fixed"
    RANDOM = "random"
    MULTI = "multi"


class ObjectiveDirection(str, Enum):
    """Interpretation direction for KPIs and objectives."""

    MIN = "min"
    MAX = "max"


@dataclass(frozen=True, slots=True)
class DesignRef:
    """Reference to one or more optimized designs stored in an external artifact."""

    source_path: str
    source_type: SourceType
    selector: str | None = None
    design_id: str | None = None
    tags: Sequence[str] = field(default_factory=tuple)
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Design:
    """Normalized design used for evaluation and Monte Carlo validation.

    For RODMO result H5 files, a design is primarily an identified solution variant
    plus compact context metadata, not necessarily a fully reconstructed vector of
    optimization variables.
    """

    design_id: str
    params: Mapping[str, Any]

    frozen_decisions: Mapping[str, Any] = field(default_factory=dict)
    feasibility_policy: FeasibilityPolicy = FeasibilityPolicy.SKIP

    source_file: str = ""
    run_id: str | None = None
    variant_name: str = ""
    scenario_groups: Sequence[str] = field(default_factory=tuple)

    topology_summary: Mapping[str, Any] = field(default_factory=dict)
    config_summary: Mapping[str, Any] = field(default_factory=dict)

    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class BaselineUncertaintyRef:
    """Reference to a baseline uncertainty model that can be loaded by the engine."""

    source_path: str
    source_type: SourceType
    selector: str | None = None
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class DistributionSpec:
    """Minimal distribution specification."""

    dist_type: str
    params: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class UncertaintyVariable:
    """One uncertain variable with its distribution."""

    name: str
    distribution: DistributionSpec
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CorrelationSpec:
    """Optional coupling/correlation specification across uncertain variables."""

    kind: str
    params: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class UncertaintyModel:
    """Uncertainty model used for sampling and/or scenario variation."""

    variables: Sequence[UncertaintyVariable]
    correlation: CorrelationSpec | None = None
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class PerturbationSpec:
    """Specifies how baseline uncertainty is systematically perturbed across stages."""

    kind: PerturbationKind
    mode: UncertaintyMode
    targets: Sequence[str] = field(default_factory=tuple)
    levels: Sequence[float] = field(default_factory=tuple)
    knobs: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Stage:
    """Concrete validation stage with a derived uncertainty model."""

    stage_id: str
    level: float
    settings: Mapping[str, Any]
    uncertainty_model: UncertaintyModel
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class MonteCarloSpec:
    """Settings for Monte Carlo sampling and repeated evaluation."""

    n_samples: int
    seed_mode: SeedMode = SeedMode.FIXED
    seed: int | None = 0
    n_runs: int = 1
    seeds: Sequence[int] = field(default_factory=tuple)
    use_crn: bool = True
    params: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class KpiSpec:
    """KPI definition and interpretation metadata."""

    name: str
    direction: ObjectiveDirection | None = None
    thresholds: Mapping[str, float] = field(default_factory=dict)
    risk_metrics: Sequence[str] = field(default_factory=tuple)
    quantiles: Sequence[float] = (0.05, 0.5, 0.95)


@dataclass(frozen=True, slots=True)
class KpiSamples:
    """Raw KPI samples for one (design_id, stage_id, run_id)."""

    design_id: str
    stage_id: str
    run_id: int
    samples_by_kpi: Mapping[str, Sequence[float]]


@dataclass(frozen=True, slots=True)
class RunMeta:
    """Run metadata for reproducibility and debugging."""

    design_id: str
    stage_id: str
    run_id: int
    seed_used: int | None
    status: SampleStatus
    runtime_s: float | None = None
    n_total: int | None = None
    n_ok: int | None = None
    n_failed: int | None = None
    error_type: str | None = None
    error_message: str | None = None
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class KpiStats:
    """Statistics for a single KPI at a single (design, stage, run)."""

    n_total: int
    n_ok: int
    n_failed: int
    failure_rate: float

    mean: float | None = None
    median: float | None = None
    std: float | None = None
    var: float | None = None
    iqr: float | None = None
    skewness: float | None = None

    quantiles: Mapping[str, float] = field(default_factory=dict)
    risk_metrics: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class KpiSummary:
    """Summary per (design, stage, run) across KPIs."""

    design_id: str
    stage_id: str
    run_id: int
    level: float
    stats_by_kpi: Mapping[str, KpiStats]
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ComparisonSummary:
    """Comparison between multiple designs for one stage and one KPI."""

    stage_id: str
    level: float
    kpi_name: str
    design_ids: Sequence[str]

    delta_median: Mapping[str, float] = field(default_factory=dict)
    delta_tail: Mapping[str, float] = field(default_factory=dict)
    paired_diff: Mapping[str, float] = field(default_factory=dict)

    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EvaluationPlan:
    """Fully specified plan derived from config: designs x stages x MC spec x KPI specs."""

    design_refs: Sequence[DesignRef]
    baseline_uncertainty_ref: BaselineUncertaintyRef
    perturbation: PerturbationSpec
    mc: MonteCarloSpec
    kpis: Sequence[KpiSpec]
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EvaluationStore:
    """Container for intermediate and final artifacts produced by execution."""

    plan: EvaluationPlan | None = None
    designs: Sequence[Design] = field(default_factory=tuple)
    stages: Sequence[Stage] = field(default_factory=tuple)

    raw_runs: Sequence[tuple[KpiSamples, RunMeta]] = field(default_factory=tuple)
    summaries: Sequence[KpiSummary] = field(default_factory=tuple)
    comparisons: Sequence[ComparisonSummary] = field(default_factory=tuple)

    artefacts: Mapping[str, Any] = field(default_factory=dict)
    meta: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EvaluationResultBundle:
    """Final result object passed to plotting/reporting."""

    designs: Sequence[Design]
    stages: Sequence[Stage]
    mc: MonteCarloSpec
    kpis: Sequence[KpiSpec]
    summaries: Sequence[KpiSummary]
    comparisons: Sequence[ComparisonSummary] = field(default_factory=tuple)
    seed_mode: SeedMode | None = None
    seeds_used: Sequence[int] = field(default_factory=tuple)
    n_runs: int = 1
    meta: Mapping[str, Any] = field(default_factory=dict)


def quantile_key(q: float) -> str:
    """Convert quantile 0.05 -> 'p05', 0.5 -> 'p50', 0.95 -> 'p95'."""
    if not (0.0 <= q <= 1.0):
        raise ValueError(f"Quantile must be within [0, 1], got {q}.")
    return f"p{int(round(q * 100)):02d}"


def make_stage_id(kind: PerturbationKind, level: float, targets: Sequence[str]) -> str:
    """Create a deterministic stage ID (stable formatting, canonical target ordering)."""
    lvl = f"{level:.6g}"
    tgt = ",".join(sorted(targets)) if targets else "ALL"
    return f"{kind.value}:{lvl}:{tgt}"
