from __future__ import annotations

import time
import traceback
from collections.abc import Callable, Mapping, Sequence
from concurrent.futures import ProcessPoolExecutor
from dataclasses import replace
from typing import Any, Protocol

import numpy as np

from eta_incerto.analysis.monte_carlo.datastructures import (
    Design,
    EvaluationPlan,
    FeasibilityPolicy,
    KpiSamples,
    KpiSpec,
    RunMeta,
    SampleStatus,
    Stage,
    UncertaintyModel,
)
from eta_incerto.analysis.monte_carlo.seeds import num_runs, resolve_run_seed, sample_seed


class UncertaintySampler(Protocol):
    """Protocol for sampling a concrete 'world' from an UncertaintyModel."""

    def __call__(self, model: UncertaintyModel, rng: np.random.Generator) -> Mapping[str, Any]: ...


class ModelEvaluator(Protocol):
    """Protocol for evaluating a design under sampled inputs and returning KPI values."""

    def __call__(
        self,
        design: Design,
        sampled_inputs: Mapping[str, Any],
        stage: Stage,
    ) -> Mapping[str, float]: ...


PenaltyProvider = Callable[[KpiSpec], float]


def run_all_monte_carlo(
    *,
    plan: EvaluationPlan,
    designs: Sequence[Design],
    stages: Sequence[Stage],
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    penalty_provider: PenaltyProvider | None = None,
) -> list[tuple[KpiSamples, RunMeta]]:
    """Run MC for all (design x stage x run_id) combinations.

    This is the stage-centered orchestration described in the planning document.

    Parallel execution is optional and controlled via:
        plan.mc.params["parallel"] -> bool
        plan.mc.params["n_workers"] -> int
    """
    jobs = _build_mc_jobs(
        designs=designs,
        stages=stages,
        kpis=plan.kpis,
        mc=plan.mc,
    )

    if _parallel_enabled(plan.mc.params):
        return _run_all_monte_carlo_parallel(
            jobs=jobs,
            sampler=sampler,
            evaluator=evaluator,
            penalty_provider=penalty_provider,
            n_workers=_parallel_workers(plan.mc.params),
        )

    return _run_all_monte_carlo_sequential(
        jobs=jobs,
        sampler=sampler,
        evaluator=evaluator,
        penalty_provider=penalty_provider,
    )


def _run_all_monte_carlo_sequential(
    *,
    jobs: Sequence[dict[str, Any]],
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    penalty_provider: PenaltyProvider | None,
) -> list[tuple[KpiSamples, RunMeta]]:
    results: list[tuple[KpiSamples, RunMeta]] = []

    for job in jobs:
        samples, meta = run_monte_carlo(
            design=job["design"],
            stage=job["stage"],
            mc=job["mc"],
            kpis=job["kpis"],
            sampler=sampler,
            evaluator=evaluator,
            run_id=job["run_id"],
            penalty_provider=penalty_provider,
        )
        results.append((samples, meta))

    return results


def _run_all_monte_carlo_parallel(
    *,
    jobs: Sequence[dict[str, Any]],
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    penalty_provider: PenaltyProvider | None,
    n_workers: int,
) -> list[tuple[KpiSamples, RunMeta]]:
    with ProcessPoolExecutor(max_workers=n_workers) as executor:
        futures = [
            executor.submit(
                run_monte_carlo,
                design=job["design"],
                stage=job["stage"],
                mc=job["mc"],
                kpis=job["kpis"],
                sampler=sampler,
                evaluator=evaluator,
                run_id=job["run_id"],
                penalty_provider=penalty_provider,
            )
            for job in jobs
        ]
        return [future.result() for future in futures]


def _build_mc_jobs(
    *,
    designs: Sequence[Design],
    stages: Sequence[Stage],
    kpis: Sequence[KpiSpec],
    mc: Any,
) -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []

    for stage in stages:
        for run_id in range(num_runs(mc)):
            for design in designs:
                jobs.append(
                    {
                        "design": design,
                        "stage": stage,
                        "mc": mc,
                        "kpis": tuple(kpis),
                        "run_id": run_id,
                    }
                )

    return jobs


def _parallel_enabled(params: Mapping[str, Any] | None) -> bool:
    if not isinstance(params, Mapping):
        return False
    return bool(params.get("parallel", False))


def _parallel_workers(params: Mapping[str, Any] | None) -> int:
    if not isinstance(params, Mapping):
        return 1

    raw = params.get("n_workers", 1)
    try:
        workers = int(raw)
    except (TypeError, ValueError):
        workers = 1

    return max(workers, 1)


def run_monte_carlo(
    *,
    design: Design,
    stage: Stage,
    mc: Any,
    kpis: Sequence[KpiSpec],
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    run_id: int,
    penalty_provider: PenaltyProvider | None = None,
) -> tuple[KpiSamples, RunMeta]:
    """Run MC for one (design, stage, run_id) and return raw KPI samples + run meta.

    The per-sample RNG is derived using seeds.sample_seed(). This enables CRN
    and reproducibility while keeping the sampling logic deterministic.
    """
    start = time.perf_counter()
    run_seed = resolve_run_seed(mc, run_id)

    kpi_names = [k.name for k in kpis]
    samples_by_kpi: dict[str, list[float]] = {name: [] for name in kpi_names}

    n_ok = 0
    n_failed = 0

    first_error_type: str | None = None
    first_error_message: str | None = None
    first_failed_sample_idx: int | None = None
    first_error_traceback: str | None = None

    if penalty_provider is None:
        penalty_provider = _default_penalty_provider

    for sample_idx in range(mc.n_samples):
        s = sample_seed(
            mc=mc,
            stage_id=stage.stage_id,
            design_id=design.design_id,
            run_id=run_id,
            sample_idx=sample_idx,
        )

        rng = np.random.default_rng(s)
        try:
            sampled_inputs = sampler(stage.uncertainty_model, rng)
            kpi_values = evaluator(design, sampled_inputs, stage)

            _collect_kpis(samples_by_kpi, kpi_values, kpi_names)
            n_ok += 1

        except Exception as exc:
            if first_error_type is None:
                first_error_type = type(exc).__name__
                first_error_message = str(exc)
                first_failed_sample_idx = sample_idx
                first_error_traceback = traceback.format_exc()

            decision = _handle_run_error(
                exc,
                policy=design.feasibility_policy,
                kpis=kpis,
                penalty_provider=penalty_provider,
                samples_by_kpi=samples_by_kpi,
                kpi_names=kpi_names,
            )
            if decision == SampleStatus.SKIPPED:
                n_failed += 1
                continue

            n_failed += 1

    runtime_s = time.perf_counter() - start
    status = SampleStatus.OK if n_ok > 0 else SampleStatus.FAILED

    samples = KpiSamples(
        design_id=design.design_id,
        stage_id=stage.stage_id,
        run_id=run_id,
        samples_by_kpi={k: tuple(v) for k, v in samples_by_kpi.items()},
    )

    meta_payload: dict[str, Any] = {
        "use_crn": bool(mc.use_crn),
        "seed_mode": mc.seed_mode.value,
        "stage_level": stage.level,
        "parallel": _parallel_enabled(getattr(mc, "params", {})),
        "n_workers": _parallel_workers(getattr(mc, "params", {})),
    }
    if first_failed_sample_idx is not None:
        meta_payload["first_failed_sample_idx"] = first_failed_sample_idx
    if first_error_traceback is not None:
        meta_payload["first_error_traceback"] = first_error_traceback

    meta = RunMeta(
        design_id=design.design_id,
        stage_id=stage.stage_id,
        run_id=run_id,
        seed_used=run_seed,
        status=status,
        runtime_s=runtime_s,
        n_total=int(mc.n_samples),
        n_ok=n_ok,
        n_failed=n_failed,
        error_type=first_error_type,
        error_message=first_error_message,
        meta=meta_payload,
    )

    return samples, meta


def _collect_kpis(
    samples_by_kpi: dict[str, list[float]],
    kpi_values: Mapping[str, float],
    expected_names: Sequence[str],
) -> None:
    """Append KPI values in stable order, raising if a KPI is missing."""
    for name in expected_names:
        if name not in kpi_values:
            raise KeyError(f"Evaluator did not return KPI '{name}'. Returned: {sorted(kpi_values.keys())}.")
        samples_by_kpi[name].append(float(kpi_values[name]))


def _handle_run_error(
    exc: Exception,
    *,
    policy: FeasibilityPolicy,
    kpis: Sequence[KpiSpec],
    penalty_provider: PenaltyProvider,
    samples_by_kpi: dict[str, list[float]],
    kpi_names: Sequence[str],
) -> SampleStatus:
    """Handle a per-sample evaluation error according to the feasibility policy."""
    if policy == FeasibilityPolicy.SKIP:
        return SampleStatus.SKIPPED

    if policy == FeasibilityPolicy.PENALIZE:
        penalty_values = {k.name: float(penalty_provider(k)) for k in kpis}
        _collect_kpis(samples_by_kpi, penalty_values, kpi_names)
        return SampleStatus.FAILED

    if policy == FeasibilityPolicy.REPAIR:
        penalty_values = {k.name: float(penalty_provider(k)) for k in kpis}
        _collect_kpis(samples_by_kpi, penalty_values, kpi_names)
        return SampleStatus.FAILED

    raise ValueError(f"Unsupported feasibility policy: {policy!s}.") from exc


def _default_penalty_provider(_: KpiSpec) -> float:
    """Default penalty value for failed samples."""
    return float("nan")


def ensure_design_feasibility_policy(design: Design, policy: FeasibilityPolicy) -> Design:
    """Utility to apply/override feasibility policy if your design loader stores it in meta."""
    return replace(design, feasibility_policy=policy)
