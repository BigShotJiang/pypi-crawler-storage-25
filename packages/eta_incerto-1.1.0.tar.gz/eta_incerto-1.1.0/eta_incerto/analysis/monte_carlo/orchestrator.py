from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict
from typing import Any, Protocol

from eta_incerto.analysis.monte_carlo.config_validation import (
    validate_statistical_evaluation_config,
)
from eta_incerto.analysis.monte_carlo.datastructures import (
    Design,
    DesignRef,
    EvaluationPlan,
    EvaluationResultBundle,
    EvaluationStore,
    Stage,
    UncertaintyModel,
)
from eta_incerto.analysis.monte_carlo.plan import build_evaluation_plan
from eta_incerto.analysis.monte_carlo.postprocess import postprocess_and_report
from eta_incerto.analysis.monte_carlo.stages import build_stages
from eta_incerto.analysis.monte_carlo.store import execute_plan
from eta_incerto.config.config import ConfigOptimization


class DesignLoader(Protocol):
    """Load and normalize optimized designs referenced by DesignRef."""

    def __call__(self, design_refs: Sequence[DesignRef], config: ConfigOptimization) -> Sequence[Design]: ...


class UncertaintySampler(Protocol):
    """Sample a concrete 'world' from an uncertainty model using an RNG."""

    def __call__(self, model: UncertaintyModel, rng: Any) -> Mapping[str, Any]: ...


class ModelEvaluator(Protocol):
    """Evaluate a design for one sampled world and return KPI values."""

    def __call__(self, design: Design, sampled_inputs: Mapping[str, Any], stage: Stage) -> Mapping[str, float]: ...


PenaltyProvider = Callable[[Any], float]


def run_statistical_evaluation(
    *,
    config: ConfigOptimization,
    design_loader: DesignLoader,
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    penalty_provider: PenaltyProvider | None = None,
) -> EvaluationResultBundle:
    """Run the full statistical evaluation pipeline."""
    mc_cfg = _require_monte_carlo_config(config)
    validate_statistical_evaluation_config(mc_cfg)

    plan = build_evaluation_plan(config)
    if not _is_enabled(plan):
        return _report_disabled(config, plan)

    designs = tuple(design_loader(plan.design_refs, config))
    if not designs:
        raise ValueError("Design loader returned no designs. Check monte_carlo.designs in config.")

    _baseline, stages = build_stages(
        plan.baseline_uncertainty_ref,
        plan.perturbation,
        root_path=str(config.root_path),
    )

    store = execute_plan(
        plan=plan,
        designs=designs,
        stages=stages,
        sampler=sampler,
        evaluator=evaluator,
        penalty_provider=penalty_provider,
    )

    return report_store(store=store, config=config)


def report_store(*, store: EvaluationStore, config: ConfigOptimization) -> EvaluationResultBundle:
    """Create plots/exports and return the final bundle."""
    mc_meta = _store_meta_for_reporting(store, config=config)
    reporting_cfg = _require_reporting_config(config)

    return postprocess_and_report(
        designs=store.designs,
        stages=store.stages,
        raw_runs=store.raw_runs,
        summaries=store.summaries,
        comparisons=store.comparisons,
        reporting=reporting_cfg,
        mc_meta=mc_meta,
    )


def _require_monte_carlo_config(config: ConfigOptimization) -> Any:
    mc_cfg = getattr(config, "monte_carlo", None)
    if mc_cfg is None:
        raise ValueError(
            "Monte Carlo configuration is missing on ConfigOptimization. "
            "Attach it as `config.monte_carlo` before calling the Monte Carlo pipeline."
        )
    return mc_cfg


def _require_reporting_config(config: ConfigOptimization) -> Any:
    mc_cfg = _require_monte_carlo_config(config)
    reporting = getattr(mc_cfg, "reporting", None)
    if reporting is None:
        raise ValueError("Monte Carlo reporting configuration is missing. Attach it as `config.monte_carlo.reporting`.")
    return reporting


def _is_enabled(plan: EvaluationPlan) -> bool:
    return bool(plan.meta.get("enabled"))


def _report_disabled(config: ConfigOptimization, plan: EvaluationPlan) -> EvaluationResultBundle:
    reporting_cfg = _require_reporting_config(config)
    return postprocess_and_report(
        designs=(),
        stages=(),
        raw_runs=(),
        summaries=(),
        comparisons=(),
        reporting=reporting_cfg,
        mc_meta={
            "enabled": False,
            "config_name": config.config_name,
            "mc": asdict(plan.mc),
            "kpis": tuple(asdict(k) for k in plan.kpis),
            "seed_mode": plan.mc.seed_mode.value,
            "seeds_used": (),
            "n_runs": 1,
        },
    )


def _store_meta_for_reporting(store: EvaluationStore, *, config: ConfigOptimization) -> dict[str, Any]:
    meta = dict(store.meta)

    run_dir = getattr(config, "root_path", None)
    results_dir = None

    paths_cfg = getattr(config, "paths", None)
    if paths_cfg is not None:
        results_dir = getattr(paths_cfg, "results_dir", None)

    meta.update(
        {
            "enabled": True,
            "config_name": config.config_name,
            "design_ids": [d.design_id for d in store.designs],
            "stage_ids": [s.stage_id for s in store.stages],
            "config_name_from_plan": store.plan.meta.get("config_name") if store.plan else None,
            "run_dir": str(run_dir) if run_dir is not None else None,
            "results_dir": str(results_dir) if results_dir is not None else None,
        }
    )
    return meta
