from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

import h5py

from eta_incerto.analysis.monte_carlo.datastructures import (
    BaselineUncertaintyRef,
    DistributionSpec,
    PerturbationSpec,
    Stage,
    UncertaintyModel,
    UncertaintyVariable,
    make_stage_id,
)
from eta_incerto.util.io_utils import load_config

SUPPORTED_PERTURBATION_KINDS = {
    "sigma_scale",
    "bounds_widen",
    "dist_override",
    "stress_factor",
}


def build_stages(
    baseline_ref: BaselineUncertaintyRef,
    perturbation: PerturbationSpec,
    *,
    root_path: str | None = None,
) -> tuple[UncertaintyModel, list[Stage]]:
    """Build baseline uncertainty model and perturbation stages."""
    baseline_model = load_baseline_uncertainty(baseline_ref, root_path=root_path)

    stage_settings = expand_stage_plan(perturbation)
    stages: list[Stage] = []
    for settings in stage_settings:
        stage_id = make_stage_id(perturbation.kind, settings["level"], perturbation.targets)
        stage_model = apply_perturbation(
            baseline_model=baseline_model,
            perturbation=perturbation,
            settings=settings,
        )
        stages.append(
            Stage(
                stage_id=stage_id,
                level=settings["level"],
                settings=settings,
                uncertainty_model=stage_model,
                meta={
                    "baseline_source": str(baseline_ref.source_path),
                    "kind": perturbation.kind.value,
                    "mode": perturbation.mode.value,
                },
            )
        )

    validate_stages(stages)
    return baseline_model, stages


def load_baseline_uncertainty(
    baseline_ref: BaselineUncertaintyRef,
    *,
    root_path: str | None = None,
) -> UncertaintyModel:
    """Resolve BaselineUncertaintyRef into an UncertaintyModel.

    Supported sources:
    - JSON
    - H5 (RODMO result H5, using __expected__/carriers as uncertainty source)
    """
    path = baseline_ref.source_path
    if root_path is not None:
        path = str((Path(root_path) / path).resolve())

    if baseline_ref.source_type.value == "h5":
        raw = _load_baseline_uncertainty_from_h5(path, selector=baseline_ref.selector)
    else:
        raw = load_config(path)

    variables_raw = raw.get("variables", [])
    if not isinstance(variables_raw, list) or not variables_raw:
        raise ValueError("Baseline uncertainty must contain a non-empty 'variables' list.")

    variables: list[UncertaintyVariable] = []
    for v in variables_raw:
        if not isinstance(v, dict):
            raise TypeError("Each entry in 'variables' must be a dict.")

        name = v.get("name")
        dist = v.get("distribution", {})
        if not isinstance(dist, dict):
            raise TypeError("Variable 'distribution' must be a dict.")

        dist_type = dist.get("dist_type")
        params = dist.get("params", {})
        if not isinstance(params, dict):
            raise TypeError("Distribution 'params' must be a dict.")

        variables.append(
            UncertaintyVariable(
                name=str(name),
                distribution=DistributionSpec(dist_type=str(dist_type), params=params),
                meta=v.get("meta", {}) if isinstance(v.get("meta", {}), dict) else {},
            )
        )

    correlation_raw = raw.get("correlation")
    correlation = None
    if isinstance(correlation_raw, dict):
        from eta_incerto.analysis.monte_carlo.datastructures import CorrelationSpec

        correlation = CorrelationSpec(
            kind=str(correlation_raw.get("kind", "")),
            params=correlation_raw.get("params", {}) if isinstance(correlation_raw.get("params", {}), dict) else {},
        )

    meta = raw.get("meta", {}) if isinstance(raw.get("meta", {}), dict) else {}
    meta = {
        **meta,
        "baseline_ref_meta": dict(baseline_ref.meta),
        "selector": baseline_ref.selector,
    }

    model = UncertaintyModel(
        variables=tuple(variables),
        correlation=correlation,
        meta=meta,
    )
    validate_uncertainty_model(model)
    return model


def expand_stage_plan(perturbation: PerturbationSpec) -> list[dict[str, Any]]:
    """Expand PerturbationSpec into concrete stage settings."""
    if not perturbation.levels:
        raise ValueError("PerturbationSpec.levels must not be empty.")

    settings_list: list[dict[str, Any]] = []
    for lvl in perturbation.levels:
        settings_list.append(
            {
                "level": float(lvl),
                "kind": perturbation.kind.value,
                "mode": perturbation.mode.value,
                "targets": list(perturbation.targets),
                "knobs": dict(perturbation.knobs),
            }
        )

    return settings_list


def apply_perturbation(
    *,
    baseline_model: UncertaintyModel,
    perturbation: PerturbationSpec,
    settings: dict[str, Any],
) -> UncertaintyModel:
    """Derive a perturbed uncertainty model from the baseline model."""
    kind = perturbation.kind.value
    if kind not in SUPPORTED_PERTURBATION_KINDS:
        supported_list = ", ".join(sorted(SUPPORTED_PERTURBATION_KINDS))
        msg = (
            f"Perturbation kind '{kind}' is not implemented in the Monte Carlo "
            f"perturbation engine. Supported kinds are: {supported_list}."
        )
        raise NotImplementedError(msg)

    level = float(settings["level"])
    targets = set(perturbation.targets)

    def _is_target(var_name: str) -> bool:
        return not targets or var_name in targets

    new_vars: list[UncertaintyVariable] = []
    for var in baseline_model.variables:
        if not _is_target(var.name):
            new_vars.append(var)
            continue

        new_dist = _perturb_distribution(
            var.distribution,
            kind=kind,
            level=level,
            knobs=perturbation.knobs,
        )
        new_vars.append(replace(var, distribution=new_dist))

    new_meta = dict(baseline_model.meta)
    new_meta.update(
        {
            "perturbation_kind": kind,
            "perturbation_mode": perturbation.mode.value,
            "perturbation_level": level,
            "perturbation_targets": sorted(targets) if targets else ["ALL"],
            "perturbation_knobs": dict(perturbation.knobs),
        }
    )

    model = UncertaintyModel(
        variables=tuple(new_vars),
        correlation=baseline_model.correlation,
        meta=new_meta,
    )
    validate_uncertainty_model(model)
    return model


def _perturb_distribution(
    dist: DistributionSpec,
    *,
    kind: str,
    level: float,
    knobs: dict[str, Any],
) -> DistributionSpec:
    """Perturb a distribution spec in a conservative, schema-agnostic manner."""
    params = dict(dist.params)

    if kind == "sigma_scale":
        for key in ("sigma", "std", "scale"):
            if key in params and isinstance(params[key], int | float):
                params[key] = float(params[key]) * level

    elif kind == "bounds_widen":
        for low_key, high_key in (("min", "max"), ("low", "high")):
            if low_key in params and high_key in params:
                lo = params[low_key]
                hi = params[high_key]
                if isinstance(lo, int | float) and isinstance(hi, int | float):
                    center = 0.5 * (float(lo) + float(hi))
                    half_range = 0.5 * (float(hi) - float(lo)) * level
                    params[low_key] = center - half_range
                    params[high_key] = center + half_range

    elif kind == "stress_factor":
        for key in ("mu", "mean", "loc"):
            if key in params and isinstance(params[key], int | float):
                params[key] = float(params[key]) * level

    elif kind == "dist_override":
        new_type = knobs.get("dist_type")
        if isinstance(new_type, str) and new_type:
            return DistributionSpec(dist_type=new_type, params=params)

    return DistributionSpec(dist_type=dist.dist_type, params=params)


def validate_uncertainty_model(model: UncertaintyModel) -> None:
    """Basic validation for an uncertainty model."""
    if not model.variables:
        raise ValueError("UncertaintyModel.variables must not be empty.")

    seen = set()
    for v in model.variables:
        if not v.name:
            raise ValueError("Uncertainty variable names must be non-empty.")
        if v.name in seen:
            raise ValueError(f"Duplicate uncertainty variable name '{v.name}'.")
        seen.add(v.name)
        if not v.distribution.dist_type:
            raise ValueError(f"Variable '{v.name}' must have a non-empty dist_type.")


def validate_stages(stages: list[Stage]) -> None:
    """Validate stage list consistency and determinism constraints."""
    if not stages:
        raise ValueError("Stages must not be empty.")

    ids = [s.stage_id for s in stages]
    if len(ids) != len(set(ids)):
        raise ValueError("Stage IDs must be unique.")


def _load_baseline_uncertainty_from_h5(path: str, selector: str | None = None) -> dict[str, Any]:
    """Build a baseline uncertainty payload from a RODMO result H5.

    Current MVP:
    - reads __expected__/carriers
    - extracts electricity/gas
    - maps absolute carrier series to MC scale-space variables around mean=1.0
    """
    h5_path = Path(path)
    if not h5_path.exists():
        raise FileNotFoundError(f"Baseline uncertainty H5 does not exist: {h5_path}")

    with h5py.File(h5_path, "r") as f:
        root = _resolve_h5_root(f, selector=selector, h5_path=h5_path)
        variables = _extract_h5_uncertainty_variables(root)

    if not variables:
        raise ValueError(f"No supported carrier uncertainty variables found in H5 baseline '{h5_path}'.")

    return {
        "variables": variables,
        "meta": {
            "source": "h5",
            "source_path": str(h5_path),
            "selector": selector,
            "description": "Baseline uncertainty derived from RODMO result H5 (__expected__/carriers).",
        },
    }


def _resolve_h5_root(
    file_handle: h5py.File,
    *,
    selector: str | None,
    h5_path: Path,
) -> h5py.Group | h5py.File:
    if not selector:
        return file_handle

    if selector not in file_handle:
        raise KeyError(f"Selector '{selector}' not found in baseline uncertainty H5: {h5_path}")

    node = file_handle[selector]
    if not isinstance(node, h5py.Group):
        raise TypeError(f"Selector '{selector}' must point to an H5 group.")

    return node


def _extract_h5_uncertainty_variables(root: h5py.Group | h5py.File) -> list[dict[str, Any]]:
    carriers_group = _resolve_h5_carriers_group(root)

    variables: list[dict[str, Any]] = []
    for carrier_name in ("electricity", "gas"):
        if carrier_name not in carriers_group:
            continue

        carrier_group = carriers_group[carrier_name]
        if not isinstance(carrier_group, h5py.Group):
            continue

        variables.extend(_extract_h5_carrier_fields(carrier_name, carrier_group))

    return variables


def _resolve_h5_carriers_group(root: h5py.Group | h5py.File) -> h5py.Group:
    carriers_path = "__expected__/carriers"
    if carriers_path not in root:
        raise ValueError(f"H5 baseline uncertainty does not contain '{carriers_path}'.")

    carriers_group = root[carriers_path]
    if not isinstance(carriers_group, h5py.Group):
        raise TypeError(f"'{carriers_path}' must be an H5 group.")

    return carriers_group


def _extract_h5_carrier_fields(
    carrier_name: str,
    carrier_group: h5py.Group,
) -> list[dict[str, Any]]:
    variables: list[dict[str, Any]] = []

    for field_name in ("unit_price", "emissions_per_unit"):
        if field_name not in carrier_group:
            continue

        field_group = carrier_group[field_name]
        if not isinstance(field_group, h5py.Group):
            continue

        variables.append(
            _extract_h5_carrier_variable(
                carrier_name=carrier_name,
                field_name=field_name,
                field_group=field_group,
            )
        )

    return variables


def _extract_h5_carrier_variable(
    *,
    carrier_name: str,
    field_name: str,
    field_group: h5py.Group,
) -> dict[str, Any]:
    if "year" not in field_group or "value" not in field_group:
        raise ValueError(f"H5 carrier field '{carrier_name}/{field_name}' must contain datasets 'year' and 'value'.")

    years = _to_python_list(field_group["year"][()])
    values = _to_python_list(field_group["value"][()])

    if len(years) != len(values):
        raise ValueError(f"H5 carrier field '{carrier_name}/{field_name}' has mismatched year/value lengths.")

    target = _target_key_for_carrier_field(carrier_name, field_name)
    dist_type, params = _series_group_to_distribution_params(field_name)

    return {
        "name": f"{carrier_name}_{field_name}",
        "distribution": {
            "dist_type": dist_type,
            "params": params,
        },
        "meta": {
            "target": target,
            "carrier_name": carrier_name,
            "field_name": field_name,
            "source": "h5::__expected__/carriers",
            "baseline_years": years,
            "baseline_values": values,
        },
    }


def _series_group_to_distribution_params(field_name: str) -> tuple[str, dict[str, Any]]:
    """Map H5 carrier series to MC scale distributions.

    The evaluator consumes multiplicative scale factors, not absolute prices/emissions.
    """
    if field_name == "unit_price":
        return "normal", {"mean": 1.0, "std": 0.05}
    if field_name == "emissions_per_unit":
        return "normal", {"mean": 1.0, "std": 0.03}
    return "normal", {"mean": 1.0, "std": 0.05}


def _target_key_for_carrier_field(carrier_name: str, field_name: str) -> str:
    return f"carriers.{carrier_name}.{field_name}.scale"


def _to_python_list(values: Any) -> list[Any]:
    try:
        import numpy as np
    except ImportError:
        np = None  # type: ignore[assignment]

    out = values
    if np is not None and hasattr(np, "ndarray") and isinstance(out, np.ndarray):
        out = out.tolist()

    if not isinstance(out, list):
        out = [out]

    normalized: list[Any] = []
    for raw_item in out:
        normalized_item = raw_item
        if np is not None and isinstance(normalized_item, np.generic):
            normalized_item = normalized_item.item()
        if isinstance(normalized_item, bytes):
            normalized_item = normalized_item.decode("utf-8")
        normalized.append(normalized_item)

    return normalized
