from __future__ import annotations

import hashlib
from dataclasses import dataclass

from eta_incerto.analysis.monte_carlo.datastructures import MonteCarloSpec, SeedMode


@dataclass(frozen=True, slots=True)
class SeedBundle:
    """Resolved seed information for a specific MC run."""

    seed_used: int | None
    base_seed: int | None
    seed_mode: SeedMode
    use_crn: bool


def resolve_run_seed(mc: MonteCarloSpec, run_id: int) -> int | None:
    """Resolve the base seed for a given run.

    Rules (matches the planning document):
    - fixed: seed_used = mc.seed
    - random: seed_used = None (system randomness)
    - multi: seed_used = mc.seeds[run_id] if provided else deterministic from mc.seed + run_id
    """
    if mc.seed_mode == SeedMode.RANDOM:
        return None

    if mc.seed_mode == SeedMode.FIXED:
        if mc.seed is None:
            raise ValueError("mc.seed must not be None for seed_mode='fixed'.")
        if run_id != 0:
            raise ValueError("run_id must be 0 for seed_mode='fixed'.")
        return int(mc.seed)

    if mc.seed_mode == SeedMode.MULTI:
        if mc.seeds:
            if run_id < 0 or run_id >= len(mc.seeds):
                raise ValueError("run_id out of range for explicit mc.seeds.")
            return int(mc.seeds[run_id])

        # If no explicit seeds are provided, derive deterministically.
        # mc.seed acts as the base seed; if None, fall back to 0.
        base = int(mc.seed or 0)
        return derive_seed(base_seed=base, parts=("multi", run_id))

    raise ValueError(f"Unsupported seed mode: {mc.seed_mode!s}")


def seed_bundle(mc: MonteCarloSpec, run_id: int) -> SeedBundle:
    """Build a SeedBundle for (mc, run_id)."""
    seed_used = resolve_run_seed(mc, run_id)
    base_seed = None if seed_used is None else int(seed_used)
    return SeedBundle(
        seed_used=seed_used,
        base_seed=base_seed,
        seed_mode=mc.seed_mode,
        use_crn=bool(mc.use_crn),
    )


def derive_seed(*, base_seed: int, parts: tuple[object, ...]) -> int:
    """Derive a deterministic 32-bit seed from a base seed and arbitrary parts.

    We use a stable hash (sha256) to avoid Python's randomized hashing.
    """
    payload = "|".join([str(base_seed), *[str(p) for p in parts]]).encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    # Use first 4 bytes as unsigned 32-bit integer
    return int.from_bytes(digest[:4], byteorder="big", signed=False)


def sample_seed(
    *,
    mc: MonteCarloSpec,
    stage_id: str,
    design_id: str,
    run_id: int,
    sample_idx: int,
) -> int | None:
    """Return the deterministic per-sample seed (or None for random mode).

    CRN logic (document requirement):
    - If mc.use_crn is True: do NOT include design_id in the seed derivation.
      => same random world for all designs at same (stage_id, run_id, sample_idx)
    - If mc.use_crn is False: include design_id
      => designs get independent random worlds

    For seed_mode='random', returns None (caller should use default RNG entropy).
    """
    base = resolve_run_seed(mc, run_id)
    if base is None:
        return None

    if mc.use_crn:
        parts: tuple[object, ...] = ("crn", stage_id, run_id, sample_idx)
    else:
        parts = ("independent", stage_id, design_id, run_id, sample_idx)

    return derive_seed(base_seed=base, parts=parts)


def num_runs(mc: MonteCarloSpec) -> int:
    """Return the number of runs implied by the seed mode."""
    if mc.seed_mode == SeedMode.MULTI:
        return int(mc.n_runs)
    return 1
