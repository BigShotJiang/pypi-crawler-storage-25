from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict
from typing import Any, Protocol

from eta_incerto.analysis.monte_carlo.comparison import compare_designs
from eta_incerto.analysis.monte_carlo.datastructures import (
    ComparisonSummary,
    Design,
    EvaluationPlan,
    EvaluationStore,
    KpiSamples,
    KpiSummary,
    RunMeta,
    Stage,
    UncertaintyModel,
)
from eta_incerto.analysis.monte_carlo.metrics import compute_all_metrics
from eta_incerto.analysis.monte_carlo.runner import run_all_monte_carlo
from eta_incerto.analysis.monte_carlo.seeds import num_runs, resolve_run_seed


class UncertaintySampler(Protocol):
    """Sample a concrete 'world' from an uncertainty model using an RNG."""

    def __call__(self, model: UncertaintyModel, rng: Any) -> Mapping[str, Any]: ...


class ModelEvaluator(Protocol):
    """Evaluate a design for one sampled world and return KPI values."""

    def __call__(self, design: Design, sampled_inputs: Mapping[str, Any], stage: Stage) -> Mapping[str, float]: ...


PenaltyProvider = Callable[[Any], float]


def execute_plan(
    *,
    plan: EvaluationPlan,
    designs: Sequence[Design],
    stages: Sequence[Stage],
    sampler: UncertaintySampler,
    evaluator: ModelEvaluator,
    penalty_provider: PenaltyProvider | None = None,
) -> EvaluationStore:
    """Execute a fully built EvaluationPlan and return an EvaluationStore.

    This corresponds to the planning document's "store = execute(plan)" step:
    - run all Monte Carlo evaluations (design x stage x run_id)
    - compute all metrics
    - compute comparisons
    - keep everything in a single store container
    """
    raw_runs: list[tuple[KpiSamples, RunMeta]] = run_all_monte_carlo(
        plan=plan,
        designs=designs,
        stages=stages,
        sampler=sampler,
        evaluator=evaluator,
        penalty_provider=penalty_provider,
    )

    stage_levels = {s.stage_id: float(s.level) for s in stages}
    summaries: list[KpiSummary] = compute_all_metrics(
        raw_runs=raw_runs,
        kpi_specs=plan.kpis,
        stage_levels=stage_levels,
    )

    comparisons: list[ComparisonSummary] = []
    baseline_design_id = designs[0].design_id if designs else None
    for kpi in plan.kpis:
        comparisons.extend(
            compare_designs(
                summaries=summaries,
                kpi_name=kpi.name,
                baseline_design_id=baseline_design_id,
                tail_key="p05",
                use_crn=bool(plan.mc.use_crn),
                raw_runs=raw_runs,
            )
        )

    seeds_used = tuple(resolve_run_seed(plan.mc, run_id) for run_id in range(num_runs(plan.mc)))
    mc_params = getattr(plan.mc, "params", {}) or {}

    return EvaluationStore(
        plan=plan,
        designs=tuple(designs),
        stages=tuple(stages),
        raw_runs=tuple(raw_runs),
        summaries=tuple(summaries),
        comparisons=tuple(comparisons),
        artefacts={},
        meta={
            "seed_mode": plan.mc.seed_mode.value,
            "seeds_used": seeds_used,
            "n_runs": int(num_runs(plan.mc)),
            "n_samples": int(plan.mc.n_samples),
            "use_crn": bool(plan.mc.use_crn),
            "parallel": bool(mc_params.get("parallel", False)),
            "n_workers": int(mc_params.get("n_workers", 1)) if str(mc_params.get("n_workers", 1)).isdigit() else 1,
            "hpc_note": (
                "Parallel execution is optional and intended for independent "
                "(design, stage, run_id) tasks. When using Gurobi-backed direct evaluation, "
                "worker counts should respect available solver licenses and cluster policy."
            ),
            "mc": asdict(plan.mc),
            "kpis": tuple(asdict(k) for k in plan.kpis),
        },
    )
