from __future__ import annotations

from collections.abc import Mapping, Sequence

import numpy as np

from eta_incerto.analysis.monte_carlo.datastructures import (
    KpiSamples,
    KpiSpec,
    KpiStats,
    KpiSummary,
    ObjectiveDirection,
    RunMeta,
)


def compute_all_metrics(
    *,
    raw_runs: Sequence[tuple[KpiSamples, RunMeta]],
    kpi_specs: Sequence[KpiSpec],
    stage_levels: Mapping[str, float] | None = None,
) -> list[KpiSummary]:
    """Compute KPI summaries for a list of MC runs.

    Each entry in raw_runs is one (KpiSamples, RunMeta) pair for a specific
    (design_id, stage_id, run_id). This function returns one KpiSummary per run.

    stage_levels can be used to attach a stable 'level' to summaries. If not
    provided, the function will attempt to read it from RunMeta.meta['stage_level'].
    """
    spec_by_name = {k.name: k for k in kpi_specs}

    summaries: list[KpiSummary] = []
    for samples, meta in raw_runs:
        level = _resolve_stage_level(samples.stage_id, meta, stage_levels)

        stats_by_kpi: dict[str, KpiStats] = {}
        for kpi_name, values in samples.samples_by_kpi.items():
            if kpi_name not in spec_by_name:
                raise KeyError(f"Unknown KPI '{kpi_name}' in samples. Known KPIs: {sorted(spec_by_name.keys())}.")
            spec = spec_by_name[kpi_name]
            stats_by_kpi[kpi_name] = compute_kpi_metrics(
                values=values,
                spec=spec,
                n_total=meta.n_total,
                n_ok=meta.n_ok,
                n_failed=meta.n_failed,
            )

        summaries.append(
            KpiSummary(
                design_id=samples.design_id,
                stage_id=samples.stage_id,
                run_id=samples.run_id,
                level=level,
                stats_by_kpi=stats_by_kpi,
                meta={
                    "seed_used": meta.seed_used,
                    "status": meta.status.value,
                    "runtime_s": meta.runtime_s,
                    "use_crn": meta.meta.get("use_crn"),
                    "seed_mode": meta.meta.get("seed_mode"),
                },
            )
        )

    return summaries


def compute_kpi_metrics(
    *,
    values: Sequence[float],
    spec: KpiSpec,
    n_total: int | None,
    n_ok: int | None,
    n_failed: int | None,
) -> KpiStats:
    """Compute statistics and risk metrics for a single KPI sample vector."""
    arr = _to_float_array(values)

    # Basic counts: prefer RunMeta counts (covers skip-policy), otherwise infer from array length.
    total = int(n_total) if n_total is not None else int(arr.size)
    ok = int(n_ok) if n_ok is not None else int(arr.size)
    failed = int(n_failed) if n_failed is not None else max(total - ok, 0)
    failure_rate = float(failed / total) if total > 0 else 1.0

    # Filter invalid values for moment/quantile calculations (NaN penalties, infs).
    finite = arr[np.isfinite(arr)]

    quantiles = _compute_quantiles(finite, spec.quantiles)
    mean = _safe_mean(finite)
    median = _safe_median(finite)
    var = _safe_var(finite)
    std = _safe_std(finite)
    iqr = _safe_iqr(finite)
    skewness = _safe_skewness(finite)

    risk = _compute_risk_metrics(
        finite=finite,
        spec=spec,
    )

    return KpiStats(
        n_total=total,
        n_ok=ok,
        n_failed=failed,
        failure_rate=failure_rate,
        mean=mean,
        median=median,
        std=std,
        var=var,
        iqr=iqr,
        skewness=skewness,
        quantiles=quantiles,
        risk_metrics=risk,
    )


def _compute_quantiles(values: np.ndarray, qs: Sequence[float]) -> dict[str, float]:
    if values.size == 0:
        return {}
    out: dict[str, float] = {}
    for q in qs:
        key = _quantile_key(q)
        out[key] = float(np.quantile(values, q))
    return out


def _compute_risk_metrics(*, finite: np.ndarray, spec: KpiSpec) -> dict[str, float]:
    """Compute optional risk metrics declared in spec.risk_metrics plus threshold violations."""
    risk: dict[str, float] = {}

    if finite.size == 0:
        return risk

    # Threshold violation probabilities
    for name, thr in spec.thresholds.items():
        risk[f"p_violation_{name}"] = _p_violation(finite, thr, spec.direction)

    # Metric strings (kept flexible)
    for metric_name in spec.risk_metrics:
        metric = metric_name.strip().lower()

        # CVaR parsing: "cvar" or "cvar_05" or "cvar_0.05"
        if metric.startswith("cvar"):
            alpha = _parse_alpha(metric, default=0.05)
            risk[f"cvar_{_alpha_key(alpha)}"] = _cvar(finite, alpha, spec.direction)

        # Upside capture parsing: "upside" or "upside_05" etc.
        if metric.startswith("upside"):
            alpha = _parse_alpha(metric, default=0.05)
            risk[f"upside_{_alpha_key(alpha)}"] = _upside_capture(finite, alpha, spec.direction)

    return risk


def _p_violation(values: np.ndarray, threshold: float, direction: ObjectiveDirection | None) -> float:
    """Probability of violating a threshold based on KPI direction.

    Convention:
    - direction=MIN: violation if value > threshold (too large)
    - direction=MAX: violation if value < threshold (too small)
    - direction=None: defaults to value > threshold
    """
    thr = float(threshold)
    if direction == ObjectiveDirection.MAX:
        return float(np.mean(values < thr))
    return float(np.mean(values > thr))


def _cvar(values: np.ndarray, alpha: float, direction: ObjectiveDirection | None) -> float:
    """Compute conditional value at risk (expected shortfall) for the downside tail.

    Convention:
    - direction=MIN: downside = high values -> upper tail (1 - alpha)
    - direction=MAX: downside = low values -> lower tail (alpha)
    - direction=None: treated as MIN (conservative)
    """
    a = float(alpha)
    a = min(max(a, 0.0), 1.0)

    if values.size == 0:
        return float("nan")

    if direction == ObjectiveDirection.MAX:
        q = float(np.quantile(values, a))
        tail = values[values <= q]
    else:
        q = float(np.quantile(values, 1.0 - a))
        tail = values[values >= q]

    if tail.size == 0:
        return float("nan")
    return float(np.mean(tail))


def _upside_capture(values: np.ndarray, alpha: float, direction: ObjectiveDirection | None) -> float:
    """Compute a simple upside-tail mean.

    Convention:
    - direction=MIN: upside = low values -> lower tail (alpha)
    - direction=MAX: upside = high values -> upper tail (1 - alpha)
    - direction=None: treated as MIN
    """
    a = float(alpha)
    a = min(max(a, 0.0), 1.0)

    if values.size == 0:
        return float("nan")

    if direction == ObjectiveDirection.MAX:
        q = float(np.quantile(values, 1.0 - a))
        tail = values[values >= q]
    else:
        q = float(np.quantile(values, a))
        tail = values[values <= q]

    if tail.size == 0:
        return float("nan")
    return float(np.mean(tail))


def _safe_mean(values: np.ndarray) -> float | None:
    return None if values.size == 0 else float(np.mean(values))


def _safe_median(values: np.ndarray) -> float | None:
    return None if values.size == 0 else float(np.median(values))


def _safe_var(values: np.ndarray) -> float | None:
    return None if values.size == 0 else float(np.var(values))


def _safe_std(values: np.ndarray) -> float | None:
    return None if values.size == 0 else float(np.std(values))


def _safe_iqr(values: np.ndarray) -> float | None:
    if values.size == 0:
        return None
    q75 = float(np.quantile(values, 0.75))
    q25 = float(np.quantile(values, 0.25))
    return q75 - q25


def _safe_skewness(values: np.ndarray) -> float | None:
    """Compute population skewness via standardized 3rd central moment."""
    if values.size == 0:
        return None
    mu = float(np.mean(values))
    sigma = float(np.std(values))
    if sigma == 0.0:
        return 0.0
    m3 = float(np.mean((values - mu) ** 3))
    return m3 / (sigma**3)


def _to_float_array(values: Sequence[float]) -> np.ndarray:
    return np.asarray(list(values), dtype=float)


def _quantile_key(q: float) -> str:
    if not (0.0 <= q <= 1.0):
        raise ValueError(f"Quantile must be within [0, 1], got {q}.")
    return f"p{int(round(q * 100)):02d}"


def _alpha_key(alpha: float) -> str:
    return f"{int(round(alpha * 100)):02d}"


def _parse_alpha(metric: str, *, default: float) -> float:
    """Parse alpha from metric strings like 'cvar_05' or 'cvar_0.05'."""
    parts = metric.split("_", maxsplit=1)
    if len(parts) == 1:
        return float(default)

    raw = parts[1].strip()
    if raw.startswith("0."):
        try:
            return float(raw)
        except ValueError as exc:
            raise ValueError(f"Invalid alpha in metric '{metric}'.") from exc

    # Interpret "05" as 0.05
    try:
        n = int(raw)
    except ValueError as exc:
        raise ValueError(f"Invalid alpha in metric '{metric}'.") from exc
    return float(n) / 100.0


def _resolve_stage_level(
    stage_id: str,
    meta: RunMeta,
    stage_levels: Mapping[str, float] | None,
) -> float:
    if stage_levels is not None:
        if stage_id not in stage_levels:
            raise KeyError(f"Missing stage level for stage_id '{stage_id}'.")
        return float(stage_levels[stage_id])

    # Fallback: runner stored it in meta
    lvl = meta.meta.get("stage_level")
    if lvl is None:
        # Keep it deterministic: if level is not available, use NaN to expose miswiring early.
        return float("nan")
    return float(lvl)
