from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt

from eta_incerto.analysis.monte_carlo.datastructures import (
    ComparisonSummary,
    Design,
    EvaluationResultBundle,
    KpiSamples,
    KpiSummary,
    Stage,
)
from eta_incerto.config.config_monte_carlo import ConfigMonteCarloReporting


def postprocess_and_report(
    *,
    designs: Sequence[Design],
    stages: Sequence[Stage],
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    summaries: Sequence[KpiSummary],
    comparisons: Sequence[ComparisonSummary],
    reporting: ConfigMonteCarloReporting,
    mc_meta: Mapping[str, Any] | None = None,
) -> EvaluationResultBundle:
    """Create exports and plots and return an EvaluationResultBundle.

    This corresponds to the "Post-Process, Plots & Results" block in the document.
    """
    output_dir = _resolve_output_dir(reporting.output_dir, mc_meta=mc_meta)
    output_dir.mkdir(parents=True, exist_ok=True)

    stage_levels = {s.stage_id: float(s.level) for s in stages}

    artefacts: dict[str, Any] = {}
    if reporting.export_raw:
        artefacts.update(export_raw_runs(raw_runs=raw_runs, output_dir=output_dir, formats=reporting.formats))

    if reporting.export_summary:
        artefacts.update(
            export_summaries(
                summaries=summaries,
                comparisons=comparisons,
                output_dir=output_dir,
                formats=reporting.formats,
            )
        )

    plots = reporting.plots or []
    if plots:
        artefacts.update(
            generate_plots(
                designs=designs,
                stages=stages,
                summaries=summaries,
                raw_runs=raw_runs,
                output_dir=output_dir,
                plots=plots,
            )
        )

    return EvaluationResultBundle(
        designs=tuple(designs),
        stages=tuple(stages),
        mc=mc_meta["mc"] if isinstance(mc_meta, dict) and "mc" in mc_meta else None,  # optional
        kpis=mc_meta["kpis"] if isinstance(mc_meta, dict) and "kpis" in mc_meta else (),
        summaries=tuple(summaries),
        comparisons=tuple(comparisons),
        seed_mode=mc_meta.get("seed_mode") if isinstance(mc_meta, dict) else None,
        seeds_used=tuple(mc_meta.get("seeds_used", ())) if isinstance(mc_meta, dict) else (),
        n_runs=int(mc_meta.get("n_runs", 1)) if isinstance(mc_meta, dict) else 1,
        meta={
            "output_dir": str(output_dir),
            "stage_levels": stage_levels,
            "artefacts": artefacts,
            **(dict(mc_meta) if isinstance(mc_meta, dict) else {}),
        },
    )


def export_raw_runs(
    *,
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    output_dir: Path,
    formats: Sequence[str],
) -> dict[str, str]:
    """Export raw KPI samples per (design, stage, run)."""
    artefacts: dict[str, str] = {}

    raw_records: list[dict[str, Any]] = []
    for samples, meta in raw_runs:
        rec = {
            "design_id": samples.design_id,
            "stage_id": samples.stage_id,
            "run_id": samples.run_id,
            "samples_by_kpi": {k: list(v) for k, v in samples.samples_by_kpi.items()},
            "run_meta": _safe_meta_to_dict(meta),
        }
        raw_records.append(rec)

    if "json" in formats:
        path = output_dir / "raw_runs.json"
        _write_json(path, raw_records)
        artefacts["raw_runs_json"] = str(path)

    if "csv" in formats:
        # CSV for raw runs is large; export a flattened "long" table.
        path = output_dir / "raw_runs_long.csv"
        _write_raw_runs_long_csv(path, raw_runs)
        artefacts["raw_runs_csv"] = str(path)

    if "parquet" in formats:
        path = output_dir / "raw_runs_long.parquet"
        _write_raw_runs_long_parquet(path, raw_runs)
        artefacts["raw_runs_parquet"] = str(path)

    return artefacts


def export_summaries(
    *,
    summaries: Sequence[KpiSummary],
    comparisons: Sequence[ComparisonSummary],
    output_dir: Path,
    formats: Sequence[str],
) -> dict[str, str]:
    """Export computed summaries and comparisons."""
    artefacts: dict[str, str] = {}

    summary_records = [_summary_to_record(s) for s in summaries]
    comparison_records = [_comparison_to_record(c) for c in comparisons]

    if "json" in formats:
        p1 = output_dir / "kpi_summaries.json"
        p2 = output_dir / "comparisons.json"
        _write_json(p1, summary_records)
        _write_json(p2, comparison_records)
        artefacts["summaries_json"] = str(p1)
        artefacts["comparisons_json"] = str(p2)

    if "csv" in formats:
        p1 = output_dir / "kpi_summaries.csv"
        p2 = output_dir / "comparisons.csv"
        _write_records_csv(p1, summary_records)
        _write_records_csv(p2, comparison_records)
        artefacts["summaries_csv"] = str(p1)
        artefacts["comparisons_csv"] = str(p2)

    if "parquet" in formats:
        p1 = output_dir / "kpi_summaries.parquet"
        p2 = output_dir / "comparisons.parquet"
        _write_records_parquet(p1, summary_records)
        _write_records_parquet(p2, comparison_records)
        artefacts["summaries_parquet"] = str(p1)
        artefacts["comparisons_parquet"] = str(p2)

    return artefacts


def generate_plots(
    *,
    designs: Sequence[Design],
    stages: Sequence[Stage],
    summaries: Sequence[KpiSummary],
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    output_dir: Path,
    plots: Sequence[str],
) -> dict[str, str]:
    """Generate standardized plots described in the planning document."""
    artefacts: dict[str, str] = {}

    grouped = group_summaries(summaries)

    kpi_names = sorted(grouped.keys())
    stage_order = [s.stage_id for s in sorted(stages, key=lambda x: x.level)]
    design_ids = [d.design_id for d in designs]

    for kpi in kpi_names:
        data = grouped[kpi]

        if "stage_profile" in plots:
            path = output_dir / f"{kpi}_stage_profile.png"
            plot_stage_profile(path, kpi, data, stage_order, design_ids)
            artefacts[f"{kpi}_stage_profile"] = str(path)

        if "tail_metrics" in plots:
            path = output_dir / f"{kpi}_tail_metrics.png"
            plot_tail_metrics(path, kpi, data, stage_order, design_ids)
            artefacts[f"{kpi}_tail_metrics"] = str(path)

        if "skewness" in plots:
            path = output_dir / f"{kpi}_skewness.png"
            plot_skewness(path, kpi, data, stage_order, design_ids)
            artefacts[f"{kpi}_skewness"] = str(path)

        if "violation_prob" in plots:
            path = output_dir / f"{kpi}_violation_prob.png"
            ok = plot_violation_prob(path, kpi, data, stage_order, design_ids)
            if ok:
                artefacts[f"{kpi}_violation_prob"] = str(path)
            # Do not create empty plot files.
            elif path.exists():
                path.unlink()

        if "distribution" in plots:
            artefacts.update(
                _generate_stage_raw_plots(
                    output_dir=output_dir,
                    kpi_name=kpi,
                    raw_runs=raw_runs,
                    stage_order=stage_order,
                    design_ids=design_ids,
                    plot_kind="distribution",
                    plot_fn=plot_distribution,
                )
            )

        if "ecdf" in plots:
            artefacts.update(
                _generate_stage_raw_plots(
                    output_dir=output_dir,
                    kpi_name=kpi,
                    raw_runs=raw_runs,
                    stage_order=stage_order,
                    design_ids=design_ids,
                    plot_kind="ecdf",
                    plot_fn=plot_ecdf,
                )
            )

    return artefacts


def _generate_stage_raw_plots(
    *,
    output_dir: Path,
    kpi_name: str,
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    stage_order: Sequence[str],
    design_ids: Sequence[str],
    plot_kind: str,
    plot_fn: Any,
) -> dict[str, str]:
    """Generate raw-sample plots for baseline and last stage."""
    artefacts: dict[str, str] = {}

    baseline_stage = stage_order[0] if stage_order else None
    last_stage = stage_order[-1] if stage_order else None
    if not baseline_stage or not last_stage:
        return artefacts

    for stage_id in {baseline_stage, last_stage}:
        path = output_dir / f"{kpi_name}_{plot_kind}_{stage_id}.png"
        ok = plot_fn(path, kpi_name, raw_runs, stage_id, design_ids)
        if ok:
            artefacts[f"{kpi_name}_{plot_kind}_{stage_id}"] = str(path)
        elif path.exists():
            path.unlink()

    return artefacts


def group_summaries(
    summaries: Sequence[KpiSummary],
) -> dict[str, dict[str, dict[str, list[dict[str, Any]]]]]:
    """Group summaries into KPI -> stage_id -> design_id -> list[run_stats].

    Each run_stats dict contains commonly used fields:
    mean, median, std, skewness, quantiles, risk_metrics
    """
    grouped: dict[str, dict[str, dict[str, list[dict[str, Any]]]]] = {}

    for s in summaries:
        for kpi_name, stats in s.stats_by_kpi.items():
            grouped.setdefault(kpi_name, {}).setdefault(s.stage_id, {}).setdefault(s.design_id, [])
            grouped[kpi_name][s.stage_id][s.design_id].append(
                {
                    "run_id": s.run_id,
                    "level": s.level,
                    "mean": stats.mean,
                    "median": stats.median,
                    "std": stats.std,
                    "skewness": stats.skewness,
                    "quantiles": dict(stats.quantiles),
                    "risk_metrics": dict(stats.risk_metrics),
                    "failure_rate": stats.failure_rate,
                }
            )

    return grouped


def plot_stage_profile(
    path: Path,
    kpi_name: str,
    data: dict[str, dict[str, list[dict[str, Any]]]],
    stage_order: Sequence[str],
    design_ids: Sequence[str],
) -> None:
    """Plot median and mean vs stage for each design."""
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    x = list(range(len(stage_order)))
    ax.set_title(f"{kpi_name}: stage profile")
    ax.set_xlabel("Stage")
    ax.set_ylabel(kpi_name)
    ax.set_xticks(x)
    ax.set_xticklabels([_short_stage(s) for s in stage_order], rotation=45, ha="right")

    for did in design_ids:
        med = []
        mean = []
        for sid in stage_order:
            runs = data.get(sid, {}).get(did, [])
            med.append(_mean_of(runs, "median"))
            mean.append(_mean_of(runs, "mean"))
        ax.plot(x, med, marker="o", label=f"{did} median")
        ax.plot(x, mean, marker="x", linestyle="--", label=f"{did} mean")

    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_tail_metrics(
    path: Path,
    kpi_name: str,
    data: dict[str, dict[str, list[dict[str, Any]]]],
    stage_order: Sequence[str],
    design_ids: Sequence[str],
    low_key: str = "p05",
    high_key: str = "p95",
) -> None:
    """Plot low/high quantiles vs stage for each design."""
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    x = list(range(len(stage_order)))
    ax.set_title(f"{kpi_name}: tail metrics")
    ax.set_xlabel("Stage")
    ax.set_ylabel(kpi_name)
    ax.set_xticks(x)
    ax.set_xticklabels([_short_stage(s) for s in stage_order], rotation=45, ha="right")

    for did in design_ids:
        low = []
        high = []
        for sid in stage_order:
            runs = data.get(sid, {}).get(did, [])
            low.append(_mean_quantile(runs, low_key))
            high.append(_mean_quantile(runs, high_key))
        ax.plot(x, low, marker="o", label=f"{did} {low_key}")
        ax.plot(x, high, marker="x", linestyle="--", label=f"{did} {high_key}")

    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_skewness(
    path: Path,
    kpi_name: str,
    data: dict[str, dict[str, list[dict[str, Any]]]],
    stage_order: Sequence[str],
    design_ids: Sequence[str],
) -> None:
    """Plot skewness vs stage for each design."""
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    x = list(range(len(stage_order)))
    ax.set_title(f"{kpi_name}: skewness")
    ax.set_xlabel("Stage")
    ax.set_ylabel("Skewness")
    ax.set_xticks(x)
    ax.set_xticklabels([_short_stage(s) for s in stage_order], rotation=45, ha="right")
    for did in design_ids:
        sk = []
        for sid in stage_order:
            runs = data.get(sid, {}).get(did, [])
            sk.append(_mean_of(runs, "skewness"))
        ax.plot(x, sk, marker="o", label=did)

    ax.axhline(0.0, linestyle="--")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_violation_prob(
    path: Path,
    kpi_name: str,
    data: dict[str, dict[str, list[dict[str, Any]]]],
    stage_order: Sequence[str],
    design_ids: Sequence[str],
) -> bool:
    """Plot threshold violation probabilities if available.

    Returns False if no violation metrics were found (to skip empty plots).
    """
    # Find any risk_metrics keys that look like p_violation_*
    metric_keys: set[str] = set()
    for _sid, sid_data in data.items():
        for _did, runs in sid_data.items():
            for run in runs:
                for key in run.get("risk_metrics", {}):
                    if key.startswith("p_violation_"):
                        metric_keys.add(key)
    if not metric_keys:
        return False

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    x = list(range(len(stage_order)))
    ax.set_title(f"{kpi_name}: violation probability")
    ax.set_xlabel("Stage")
    ax.set_ylabel("P(violation)")
    ax.set_xticks(x)
    ax.set_xticklabels([_short_stage(s) for s in stage_order], rotation=45, ha="right")

    for did in design_ids:
        for mkey in sorted(metric_keys):
            y = []
            for sid in stage_order:
                runs = data.get(sid, {}).get(did, [])
                y.append(_mean_risk_metric(runs, mkey))
            ax.plot(x, y, marker="o", label=f"{did} {mkey}")

    ax.set_ylim(0.0, 1.0)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return True


def plot_distribution(
    path: Path,
    kpi_name: str,
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    stage_id: str,
    design_ids: Sequence[str],
    bins: int = 50,
) -> bool:
    """Plot histogram distributions for a KPI at a single stage (raw samples required)."""
    # Collect sample arrays per design for the given stage
    per_design: dict[str, list[float]] = {}
    for samples, _meta in raw_runs:
        if samples.stage_id != stage_id:
            continue
        if kpi_name not in samples.samples_by_kpi:
            continue
        per_design.setdefault(samples.design_id, [])
        per_design[samples.design_id].extend([float(x) for x in samples.samples_by_kpi[kpi_name]])

    if not per_design:
        return False

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ax.set_title(f"{kpi_name}: distribution (stage {_short_stage(stage_id)})")
    ax.set_xlabel(kpi_name)
    ax.set_ylabel("Count")

    for did in design_ids:
        vals = per_design.get(did)
        if not vals:
            continue
        ax.hist(vals, bins=bins, alpha=0.5, label=did)

    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return True


def plot_ecdf(
    path: Path,
    kpi_name: str,
    raw_runs: Sequence[tuple[KpiSamples, Any]],
    stage_id: str,
    design_ids: Sequence[str],
) -> bool:
    """Plot ECDF curves for a KPI at a single stage (raw samples required)."""
    per_design: dict[str, list[float]] = {}

    # Collect samples
    for samples, _meta in raw_runs:
        if samples.stage_id != stage_id:
            continue
        if kpi_name not in samples.samples_by_kpi:
            continue

        per_design.setdefault(samples.design_id, [])
        per_design[samples.design_id].extend(float(x) for x in samples.samples_by_kpi[kpi_name])

    if not per_design:
        return False

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)

    ax.set_title(f"{kpi_name}: ECDF (stage {_short_stage(stage_id)})")
    ax.set_xlabel(kpi_name)
    ax.set_ylabel("ECDF")

    plotted_any = False

    for did in design_ids:
        vals = per_design.get(did)
        if not vals:
            continue

        x = sorted(vals)
        n = len(x)
        if n == 0:
            continue

        y = [(i + 1) / n for i in range(n)]
        ax.step(x, y, where="post", label=did)

        plotted_any = True

    if not plotted_any:
        plt.close(fig)
        return False

    ax.set_ylim(0.0, 1.0)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)

    return True


def _resolve_output_dir(output_dir: Path | None, mc_meta: Mapping[str, Any] | None = None) -> Path:
    """
    Resolve Monte Carlo output directory.

    Relative output paths from config should be written into the active run
    directory, not relative to the current working directory of the code repo.
    """
    run_dir, results_dir = _extract_mc_dirs(mc_meta)

    if output_dir is None:
        return _default_output_dir(run_dir, results_dir)

    return _resolve_relative_output_dir(Path(output_dir), run_dir, results_dir)


def _extract_mc_dirs(mc_meta: Mapping[str, Any] | None) -> tuple[Path | None, Path | None]:
    run_dir: Path | None = None
    results_dir: Path | None = None

    if isinstance(mc_meta, Mapping):
        run_dir_raw = mc_meta.get("run_dir")
        results_dir_raw = mc_meta.get("results_dir")

        if run_dir_raw:
            run_dir = Path(run_dir_raw)

        if results_dir_raw:
            results_dir = Path(results_dir_raw)

    return run_dir, results_dir


def _default_output_dir(run_dir: Path | None, results_dir: Path | None) -> Path:
    if run_dir is not None:
        return run_dir / "results" / "analysis" / "monte_carlo"
    if results_dir is not None:
        return results_dir / "analysis" / "monte_carlo"
    return Path("results") / "analysis" / "monte_carlo"


def _resolve_relative_output_dir(
    output_dir: Path,
    run_dir: Path | None,
    results_dir: Path | None,
) -> Path:
    if output_dir.is_absolute():
        return output_dir

    if run_dir is not None:
        return run_dir / output_dir

    if results_dir is None:
        return output_dir

    if output_dir.parts and output_dir.parts[0] == "results":
        return results_dir.parent / output_dir

    return results_dir / output_dir


def _write_json(path: Path, obj: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, ensure_ascii=False)


def _write_records_csv(path: Path, records: Sequence[Mapping[str, Any]]) -> None:
    # Minimal CSV writer without pandas.
    if not records:
        path.write_text("", encoding="utf-8")
        return

    keys = sorted({k for r in records for k in r})
    lines = [",".join(keys)]
    for r in records:
        row = []
        for k in keys:
            v = r.get(k, "")
            if isinstance(v, dict | list):
                v = json.dumps(v, ensure_ascii=False)
            row.append(_csv_escape(str(v)))
        lines.append(",".join(row))
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_records_parquet(path: Path, records: Sequence[Mapping[str, Any]]) -> None:
    try:
        import pandas as pd
    except ImportError as exc:
        raise ImportError("Parquet export requires pandas (+ pyarrow/fastparquet).") from exc

    records_df = pd.DataFrame(list(records))
    records_df.to_parquet(path, index=False)


def _write_raw_runs_long_csv(path: Path, raw_runs: Sequence[tuple[KpiSamples, Any]]) -> None:
    records = _raw_runs_long_records(raw_runs)
    _write_records_csv(path, records)


def _write_raw_runs_long_parquet(path: Path, raw_runs: Sequence[tuple[KpiSamples, Any]]) -> None:
    records = _raw_runs_long_records(raw_runs)
    _write_records_parquet(path, records)


def _raw_runs_long_records(raw_runs: Sequence[tuple[KpiSamples, Any]]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for samples, meta in raw_runs:
        meta_dict = _safe_meta_to_dict(meta)
        for kpi, vals in samples.samples_by_kpi.items():
            for idx, v in enumerate(vals):
                records.append(
                    {
                        "design_id": samples.design_id,
                        "stage_id": samples.stage_id,
                        "run_id": samples.run_id,
                        "kpi": kpi,
                        "sample_idx": idx,
                        "value": float(v),
                        "seed_used": meta_dict.get("seed_used"),
                        "status": meta_dict.get("status"),
                    }
                )
    return records


def _summary_to_record(s: KpiSummary) -> dict[str, Any]:
    rec: dict[str, Any] = {
        "design_id": s.design_id,
        "stage_id": s.stage_id,
        "run_id": s.run_id,
        "level": s.level,
    }
    for kpi, stats in s.stats_by_kpi.items():
        prefix = f"{kpi}__"
        rec[prefix + "mean"] = stats.mean
        rec[prefix + "median"] = stats.median
        rec[prefix + "std"] = stats.std
        rec[prefix + "var"] = stats.var
        rec[prefix + "iqr"] = stats.iqr
        rec[prefix + "skewness"] = stats.skewness
        rec[prefix + "failure_rate"] = stats.failure_rate
        for qk, qv in stats.quantiles.items():
            rec[prefix + qk] = qv
        for rk, rv in stats.risk_metrics.items():
            rec[prefix + rk] = rv
    return rec


def _comparison_to_record(c: ComparisonSummary) -> dict[str, Any]:
    return {
        "stage_id": c.stage_id,
        "level": c.level,
        "kpi_name": c.kpi_name,
        "design_ids": list(c.design_ids),
        "delta_median": dict(c.delta_median),
        "delta_tail": dict(c.delta_tail),
        "paired_diff": dict(c.paired_diff),
        "meta": dict(c.meta),
    }


def _safe_meta_to_dict(meta: Any) -> dict[str, Any]:
    if meta is None:
        return {}
    if hasattr(meta, "__dict__"):
        return dict(meta.__dict__)
    try:
        return asdict(meta)
    except Exception:
        return {"meta": str(meta)}


def _mean_of(runs: Sequence[Mapping[str, Any]], key: str) -> float | None:
    vals = [r.get(key) for r in runs if r.get(key) is not None]
    if not vals:
        return None
    return float(sum(vals) / len(vals))


def _mean_quantile(runs: Sequence[Mapping[str, Any]], qkey: str) -> float | None:
    vals = []
    for r in runs:
        q = r.get("quantiles", {})
        if isinstance(q, dict) and qkey in q and q[qkey] is not None:
            vals.append(float(q[qkey]))
    if not vals:
        return None
    return float(sum(vals) / len(vals))


def _mean_risk_metric(runs: Sequence[Mapping[str, Any]], mkey: str) -> float | None:
    vals = []
    for r in runs:
        rm = r.get("risk_metrics", {})
        if isinstance(rm, dict) and mkey in rm and rm[mkey] is not None:
            vals.append(float(rm[mkey]))
    if not vals:
        return None
    return float(sum(vals) / len(vals))


def _csv_escape(s: str) -> str:
    if any(ch in s for ch in [",", '"', "\n"]):
        s = s.replace('"', '""')
        return f'"{s}"'
    return s


def _short_stage(stage_id: str) -> str:
    # Keep file labels readable.
    return stage_id.split(":")[1] if ":" in stage_id else stage_id
