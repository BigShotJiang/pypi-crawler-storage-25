from __future__ import annotations

from pathlib import Path

from eta_incerto.analysis.monte_carlo.design_loader import load_designs
from eta_incerto.analysis.monte_carlo.evaluator_adapter import (
    MonteCarloEtaIncertoAdapter,
)
from eta_incerto.analysis.monte_carlo.orchestrator import (
    EvaluationResultBundle,
    run_statistical_evaluation,
)
from eta_incerto.analysis.monte_carlo.reference_sampler import ReferenceSampler
from eta_incerto.analysis.monte_carlo.surrogate_evaluator import SurrogateEvaluator
from eta_incerto.config.config import ConfigOptimization
from eta_incerto.config.config_monte_carlo import ConfigStatisticalEvaluation


def design_loader_adapter(
    design_refs,
    config: ConfigOptimization,
):
    """Load designs relative to the resolved run directory."""
    root_path = Path(config.root_path) if config.root_path else None
    return load_designs(design_refs, root_path=root_path)


def run_monte_carlo_from_run_dir(
    *,
    run_dir: Path,
    config_name: str = "config",
    mc_config: ConfigStatisticalEvaluation | None = None,
) -> EvaluationResultBundle:
    """Run Monte Carlo evaluation for a concrete RODMO run directory."""
    config_path = run_dir / f"{config_name}.json"
    config = ConfigOptimization.from_file(config_path, run_dir)

    if mc_config is not None:
        object.__setattr__(config, "monte_carlo", mc_config)

    if getattr(config, "monte_carlo", None) is None:
        raise ValueError(
            f"No Monte Carlo config found in '{config_path}'. Provide one explicitly or add it to the run config."
        )

    backend = getattr(config.monte_carlo.monte_carlo, "backend", "direct")

    if backend == "direct":
        evaluator = MonteCarloEtaIncertoAdapter(config_name=config_name)
    elif backend == "surrogate":
        evaluator = SurrogateEvaluator()
    else:
        raise ValueError(f"Unknown Monte Carlo evaluator backend: {backend!r}")

    sampler = ReferenceSampler()

    return run_statistical_evaluation(
        config=config,
        design_loader=design_loader_adapter,
        sampler=sampler,
        evaluator=evaluator,
    )
