from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass
from logging import getLogger
from pathlib import Path
from typing import TYPE_CHECKING, Any

from eta_incerto.analysis.monte_carlo.datastructures import Design, Stage
from eta_incerto.analysis.monte_carlo.investment_fixing import (
    fix_design_investments,
)
from eta_incerto.envs.utils import _lookup_scalar_by_year

if TYPE_CHECKING:
    from eta_incerto.core import EtaIncerto

logger = getLogger(__name__)


@dataclass(frozen=True, slots=True)
class MonteCarloEtaIncertoAdapter:
    """Adapter that reuses eta-incerto's existing run/config loading for MC evaluation."""

    config_name: str = "config"
    relpath_config: str = "."

    def __call__(
        self,
        design: Design,
        sampled_inputs: Mapping[str, Any],
        stage: Stage,
    ) -> Mapping[str, float]:
        logger.info(
            "[MC] adapter start: design=%s variant=%s stage=%s sample_keys=%s",
            design.design_id,
            design.variant_name,
            stage.stage_id,
            sorted(str(key) for key in sampled_inputs),
        )

        run_dir = self._resolve_run_dir(design)
        logger.debug("[MC] resolved run dir: %s", run_dir)

        try:
            logger.debug("[MC] constructing EtaIncerto")
            from eta_incerto.core import EtaIncerto as _EtaIncerto

            experiment = _EtaIncerto(
                run_dir,
                self.config_name,
                relpath_config=self.relpath_config,
            )
            logger.debug("[MC] EtaIncerto constructed successfully")

            variant_name = design.variant_name
            logger.debug("[MC] resolved variant: %s", variant_name)

            logger.debug("[MC] applying design context")
            self._apply_design_context(experiment, design)

            logger.debug("[MC] building invest scenarios")
            invest_scenarios = self._build_invest_scenarios(experiment, variant_name)

            logger.debug("[MC] applying sampled inputs to built scenarios")
            self._apply_sampled_inputs_to_scenarios(invest_scenarios, sampled_inputs, stage)

            logger.debug("[MC] applying frozen decisions")
            self._apply_frozen_decisions(invest_scenarios, design, stage)

            logger.debug("[MC] entering evaluation")
            result = self._evaluate_once(experiment, design, stage, invest_scenarios)

            try:
                extracted = self._extract_kpis(
                    result=result,
                    experiment=experiment,
                    design=design,
                    stage=stage,
                    invest_scenarios=invest_scenarios,
                    sampled_inputs=sampled_inputs,
                )
                logger.info(
                    "[MC] KPI extraction succeeded from direct result: design=%s stage=%s keys=%s",
                    design.design_id,
                    stage.stage_id,
                    sorted(extracted.keys()),
                )
                return extracted

            except ValueError:
                logger.warning(
                    "[MC] falling back to deterministic results file for KPI extraction: design=%s stage=%s",
                    design.design_id,
                    stage.stage_id,
                )
                extracted = self._extract_kpis_from_results_file(run_dir, design)

                logger.info(
                    "[MC] KPI extraction from results file succeeded: design=%s stage=%s keys=%s",
                    design.design_id,
                    stage.stage_id,
                    sorted(extracted.keys()),
                )

                return extracted

        except Exception as exc:
            logger.exception(
                "[MC] adapter failure: design=%s variant=%s stage=%s error=%s",
                design.design_id,
                design.variant_name,
                stage.stage_id,
                exc,
            )
            raise RuntimeError(
                f"Monte Carlo evaluator adapter failed for design='{design.design_id}', stage='{stage.stage_id}': {exc}"
            ) from exc

    def _resolve_run_dir(self, design: Design) -> Path:
        source = Path(design.source_file).resolve()
        parts = source.parts

        if "runs" in parts:
            idx = parts.index("runs")
            if idx + 1 < len(parts):
                return Path(*parts[: idx + 2])

        if design.run_id:
            current = source.parent
            while current != current.parent:
                if current.name == design.run_id:
                    return current
                current = current.parent

        return source.parent

    def _apply_design_context(self, experiment: EtaIncerto, design: Design) -> None:
        if not hasattr(experiment, "config"):
            return

        try:
            experiment.config._mc_design_id = design.design_id
            experiment.config._mc_variant_name = design.variant_name
        except Exception:
            logger.debug(
                "[MC] could not attach design context markers to experiment config.",
                exc_info=True,
            )

    def _apply_sampled_inputs_to_scenarios(
        self,
        invest_scenarios: Any,
        sampled_inputs: Mapping[str, Any],
        stage: Stage,
    ) -> None:
        scenarios = self._coerce_scenarios_iterable(invest_scenarios)
        if not scenarios:
            logger.warning(
                "[MC] no invest scenarios available for sampled input application: stage=%s",
                stage.stage_id,
            )
            return

        total_applied = 0
        total_skipped = 0

        for scenario in scenarios:
            scenario_name = getattr(scenario, "name", "<unknown>")
            energy_scenario = getattr(scenario, "energy_scenario", None)

            if energy_scenario is None:
                logger.warning(
                    "[MC] scenario '%s' has no energy_scenario; skipping sampled input application.",
                    scenario_name,
                )
                continue

            supplier_data = self._resolve_supplier_data(energy_scenario)
            if supplier_data is None:
                logger.warning(
                    "[MC] scenario '%s' has no accessible supplier/carrier data; skipping sampled input application.",
                    scenario_name,
                )
                continue

            applied_count = 0
            skipped_keys: list[str] = []

            for key, value in sampled_inputs.items():
                parsed = self._parse_sampled_input_key(key)

                try:
                    factor = float(value)
                except (TypeError, ValueError) as exc:
                    raise ValueError(
                        f"Sampled input '{key}' has non-numeric value {value!r}; expected a numeric scale factor."
                    ) from exc

                applied = self._scale_supplier_field(
                    supplier_data=supplier_data,
                    carrier_name=parsed["carrier_name"],
                    field_name=parsed["field_name"],
                    factor=factor,
                )

                if applied:
                    applied_count += 1
                    total_applied += 1
                else:
                    skipped_keys.append(str(key))
                    total_skipped += 1

            if skipped_keys:
                logger.warning(
                    (
                        "[MC] sampled inputs partially applied to "
                        "scenario=%s stage=%s applied=%s skipped=%s skipped_keys=%s"
                    ),
                    scenario_name,
                    stage.stage_id,
                    applied_count,
                    len(skipped_keys),
                    skipped_keys,
                )
            else:
                logger.info(
                    "[MC] applied sampled inputs to scenario=%s stage=%s count=%s",
                    scenario_name,
                    stage.stage_id,
                    applied_count,
                )

        if total_applied == 0 and sampled_inputs:
            raise ValueError(
                "None of the sampled inputs could be applied to any built scenario. "
                "Check MC baseline targets and scenario carrier naming."
            )

        logger.info(
            "[MC] sampled input application summary: stage=%s applied=%s skipped=%s",
            stage.stage_id,
            total_applied,
            total_skipped,
        )

    def _resolve_supplier_data(self, energy_scenario: Any) -> Any | None:
        """Resolve supplier/carrier data from a built scenario.energy_scenario object."""
        if energy_scenario is None:
            return None

        if isinstance(energy_scenario, Mapping):
            if "supplier_data" in energy_scenario:
                return energy_scenario["supplier_data"]
            return energy_scenario

        supplier_data = getattr(energy_scenario, "supplier_data", None)
        if supplier_data is not None:
            return supplier_data

        return energy_scenario

    def _parse_sampled_input_key(self, key: Any) -> dict[str, str]:
        """Validate and parse supported sampled input keys.

        Supported key patterns:
        - carriers.<carrier_name>.unit_price.scale
        - carriers.<carrier_name>.emissions_per_unit.scale
        """
        if not isinstance(key, str):
            raise ValueError(
                f"Unsupported sampled input key {key!r}. Expected a string key of the form "
                "'carriers.<carrier_name>.<field_name>.scale'."
            )

        parts = key.split(".")
        if len(parts) != 4:
            raise ValueError(
                f"Unsupported sampled input key '{key}'. Expected exactly 4 segments in the form "
                "'carriers.<carrier_name>.<field_name>.scale'."
            )

        prefix, carrier_name, field_name, operation = parts

        if prefix != "carriers":
            raise ValueError(f"Unsupported sampled input key '{key}'. Supported prefix is 'carriers'.")

        if operation != "scale":
            raise ValueError(f"Unsupported sampled input key '{key}'. Supported operation is 'scale'.")

        if field_name not in {"unit_price", "emissions_per_unit"}:
            raise ValueError(
                f"Unsupported sampled input key '{key}'. Supported fields are 'unit_price' and 'emissions_per_unit'."
            )

        if not carrier_name:
            raise ValueError(f"Unsupported sampled input key '{key}'. Carrier name must not be empty.")

        return {
            "carrier_name": carrier_name,
            "field_name": field_name,
        }

    def _scale_supplier_field(
        self,
        *,
        supplier_data: Any,
        carrier_name: str,
        field_name: str,
        factor: float,
    ) -> bool:
        success = False
        carrier_obj = self._get_supplier_carrier(supplier_data, carrier_name)

        if carrier_obj is None:
            logger.debug(
                "[MC] could not resolve carrier '%s' in supplier data of type %s",
                carrier_name,
                type(supplier_data).__name__,
            )
        else:
            current = getattr(carrier_obj, field_name, None)
            if current is None and isinstance(carrier_obj, Mapping):
                current = carrier_obj.get(field_name)

            if current is None:
                logger.debug(
                    "[MC] carrier '%s' resolved to object type %s but field '%s' is missing",
                    carrier_name,
                    type(carrier_obj).__name__,
                    field_name,
                )
            else:
                scaled = self._scale_supplier_value(current, factor)
                if scaled is None:
                    logger.debug(
                        "[MC] carrier '%s' field '%s' could not be scaled for value type %s",
                        carrier_name,
                        field_name,
                        type(current).__name__,
                    )
                else:
                    success = self._write_scaled_supplier_field(carrier_obj, field_name, scaled)

        return success

    def _write_scaled_supplier_field(
        self,
        carrier_obj: Any,
        field_name: str,
        scaled: Any,
    ) -> bool:
        try:
            if hasattr(carrier_obj, field_name):
                setattr(carrier_obj, field_name, scaled)
                return True

            if isinstance(carrier_obj, dict):
                carrier_obj[field_name] = scaled
                return True
        except Exception:
            logger.debug("[MC] failed writing scaled supplier field", exc_info=True)

        return False

    def _scale_supplier_value(
        self,
        value: Any,
        factor: float,
    ) -> Any | None:
        """Scale supplier values that may be scalar or indexed mappings."""
        if isinstance(value, int | float):
            return float(value) * factor

        if isinstance(value, Mapping):
            scaled: dict[Any, float] = {}
            for key, item in value.items():
                if not isinstance(item, int | float):
                    return None
                scaled[key] = float(item) * factor
            return scaled

        return None

    def _build_invest_scenarios(
        self,
        experiment: EtaIncerto,
        variant_name: str,
    ) -> Any:
        _, _, invest_scenarios, _ = experiment.load_system_series_scenario(variant_name)
        return invest_scenarios

    def _apply_frozen_decisions(
        self,
        invest_scenarios: Any,
        design: Design,
        stage: Stage,
    ) -> None:
        if not design.frozen_decisions:
            logger.warning(
                "[MC] no frozen decisions available for design=%s stage=%s.",
                design.design_id,
                stage.stage_id,
            )
            return

        scenarios = self._coerce_scenarios_iterable(invest_scenarios)
        if not scenarios:
            logger.warning(
                "[MC] no invest scenarios available for decision fixing: design=%s stage=%s",
                design.design_id,
                stage.stage_id,
            )
            return

        aggregate = {
            "scenarios_seen": 0,
            "scenarios_fixed": 0,
            "units_seen": 0,
            "units_fixed": 0,
            "y_fixed": 0,
            "p_out_nom_fixed": 0,
            "E_nom_fixed": 0,
        }

        for scenario in scenarios:
            aggregate["scenarios_seen"] += 1
            scenario_name = getattr(scenario, "name", "<unknown>")
            expected_system = self._resolve_expected_system(scenario)

            if expected_system is None:
                logger.warning(
                    "[MC] could not resolve expected system for scenario='%s', design=%s, stage=%s.",
                    scenario_name,
                    design.design_id,
                    stage.stage_id,
                )
                continue

            summary = fix_design_investments(
                expected_system=expected_system,
                frozen_decisions=design.frozen_decisions,
            )

            if not isinstance(summary, Mapping):
                raise TypeError(
                    f"fix_design_investments returned non-mapping for scenario='{scenario_name}': "
                    f"{type(summary).__name__}"
                )

            aggregate["scenarios_fixed"] += 1
            aggregate["units_seen"] += summary.get("units_seen", 0)
            aggregate["units_fixed"] += summary.get("units_fixed", 0)
            aggregate["y_fixed"] += summary.get("y_fixed", 0)
            aggregate["p_out_nom_fixed"] += summary.get("p_out_nom_fixed", 0)
            aggregate["E_nom_fixed"] += summary.get("E_nom_fixed", 0)

            logger.info(
                "[MC] applied frozen decisions: design=%s stage=%s scenario=%s "
                "units_seen=%s units_fixed=%s y_fixed=%s p_out_nom_fixed=%s "
                "E_nom_fixed=%s",
                design.design_id,
                stage.stage_id,
                scenario_name,
                summary.get("units_seen", 0),
                summary.get("units_fixed", 0),
                summary.get("y_fixed", 0),
                summary.get("p_out_nom_fixed", 0),
                summary.get("E_nom_fixed", 0),
            )

        logger.info(
            "[MC] frozen decision fixing aggregate: design=%s stage=%s "
            "scenarios_seen=%s scenarios_fixed=%s units_seen=%s units_fixed=%s "
            "y_fixed=%s p_out_nom_fixed=%s E_nom_fixed=%s",
            design.design_id,
            stage.stage_id,
            aggregate["scenarios_seen"],
            aggregate["scenarios_fixed"],
            aggregate["units_seen"],
            aggregate["units_fixed"],
            aggregate["y_fixed"],
            aggregate["p_out_nom_fixed"],
            aggregate["E_nom_fixed"],
        )

    def _coerce_scenarios_iterable(self, invest_scenarios: Any) -> list[Any]:
        if invest_scenarios is None:
            return []

        if isinstance(invest_scenarios, Mapping):
            return list(invest_scenarios.values())

        try:
            return list(invest_scenarios)
        except TypeError:
            return [invest_scenarios]

    def _resolve_expected_system(self, scenario: Any) -> Any | None:
        candidates = (
            "expected_system",
            "_expected_system",
            "system",
            "_system",
        )

        for attr_name in candidates:
            system = getattr(scenario, attr_name, None)
            if system is not None:
                return system

        model = getattr(scenario, "model", None)
        if model is not None:
            system = getattr(model, "system", None)
            if system is not None:
                return system

        if isinstance(scenario, Mapping):
            for key in ("expected_system", "system"):
                system = scenario.get(key)
                if system is not None:
                    return system

        return None

    def _evaluate_once(
        self,
        experiment: EtaIncerto,
        design: Design,
        stage: Stage,
        invest_scenarios: Any,
    ) -> Any:
        del stage

        logger.info(
            "[MC] starting evaluation: design=%s variant=%s",
            design.design_id,
            design.variant_name,
        )

        if hasattr(experiment, "evaluate_operation_with_invest"):
            return experiment.evaluate_operation_with_invest(invest_scenarios)

        raise NotImplementedError("Could not find a supported evaluate entry point on EtaIncerto.")

    def _extract_kpis(
        self,
        result: Any,
        experiment: EtaIncerto,
        design: Design,
        stage: Stage,
        invest_scenarios: Any,
        sampled_inputs: Mapping[str, Any],
    ) -> Mapping[str, float]:
        direct = self._extract_from_mapping(result, design)
        if direct:
            out = dict(direct)
            emissions = self._extract_total_emissions_from_result(
                result=result,
                invest_scenarios=invest_scenarios,
            )
            if emissions is not None:
                out["total_emissions"] = emissions
            return self._finalize_kpis(out, design)

        scenarios = self._extract_from_scenarios(
            result=result,
            experiment=experiment,
            design=design,
            stage=stage,
            invest_scenarios=invest_scenarios,
            sampled_inputs=sampled_inputs,
        )
        if scenarios:
            return scenarios

        tuple_case = self._extract_from_tuple(result, design)
        if tuple_case:
            out = dict(tuple_case)
            emissions = self._extract_total_emissions_from_result(
                result=result,
                invest_scenarios=invest_scenarios,
            )
            if emissions is not None:
                out["total_emissions"] = emissions
            return self._finalize_kpis(out, design)

        ref = self._extract_from_reference(design)
        if ref:
            return ref

        raise ValueError(f"No KPI mapping could be extracted for design '{design.design_id}'.")

    def _extract_from_mapping(
        self,
        result: Any,
        design: Design,
    ) -> Mapping[str, float] | None:
        if not isinstance(result, Mapping):
            return None

        normalized = self._normalize_kpi_mapping(result)

        if not normalized:
            return None

        return self._project_expected_kpis(normalized, design)

    def _extract_from_tuple(
        self,
        result: Any,
        design: Design,
    ) -> Mapping[str, float] | None:
        if not isinstance(result, tuple) or not result:
            return None

        first = result[0]
        if not isinstance(first, Mapping):
            return None

        normalized = self._normalize_kpi_mapping(first)
        if not normalized:
            return None

        return self._project_expected_kpis(normalized, design)

    def _extract_from_reference(self, design: Design) -> Mapping[str, float] | None:
        ref = design.meta.get("reference_kpis")
        if not isinstance(ref, Mapping):
            return None

        normalized = self._normalize_kpi_mapping(ref)
        if not normalized:
            return None

        logger.warning("[MC] using reference_kpis fallback")

        projected = self._project_expected_kpis(normalized, design)
        self._warn_if_expected_emissions_missing(projected, design)
        return projected

    def _extract_from_scenarios(
        self,
        result: Any,
        experiment: EtaIncerto,
        design: Design,
        stage: Stage,
        invest_scenarios: Any,
        sampled_inputs: Mapping[str, Any],
    ) -> Mapping[str, float] | None:
        del stage

        if not isinstance(result, Mapping):
            return None

        capex_vals: list[float] = []

        for metrics in result.values():
            if not isinstance(metrics, Mapping):
                continue
            capex = self._get_metric(metrics, "economical", "capex_total")
            self._append_numeric(capex_vals, capex)

        out: dict[str, float] = {}

        if capex_vals:
            out["capex"] = sum(capex_vals) / len(capex_vals)

        reconstructed_tac = self._extract_tac_from_result(
            result=result,
            experiment=experiment,
            design=design,
            invest_scenarios=invest_scenarios,
            sampled_inputs=sampled_inputs,
        )
        if reconstructed_tac is not None:
            out["tac"] = reconstructed_tac

        emissions = self._extract_total_emissions_from_result(
            result=result,
            invest_scenarios=invest_scenarios,
        )
        if emissions is not None:
            out["total_emissions"] = emissions

        if not out:
            return None

        return self._finalize_kpis(out, design)

    def _extract_tac_from_result(
        self,
        result: Any,
        experiment: EtaIncerto,
        design: Design,
        invest_scenarios: Any,
        sampled_inputs: Mapping[str, Any],
    ) -> float | None:
        if not isinstance(result, Mapping):
            return None

        reference_tac = self._reference_kpi_value(design, "tac")
        if reference_tac is None:
            logger.debug("[MC] reference TAC missing; cannot reconstruct baseline+delta TAC.")
            return None

        supplier_by_scenario = self._build_supplier_data_index(invest_scenarios)
        fallback_supplier = next(iter(supplier_by_scenario.values()), None)

        interest = self._read_interest(experiment)
        emission_cost = self._read_emission_cost(experiment)
        n_years = self._read_n_years(experiment)
        apvf = self._apvf(interest=interest, n_years=n_years)
        scale_lookup = self._build_sampled_input_scale_lookup(sampled_inputs)

        scenario_deltas: list[float] = []

        for scenario_name, metrics in result.items():
            if not isinstance(metrics, Mapping):
                continue

            traders = self._get_metric(metrics, "technical", "traders_yearly")
            supplier_data = supplier_by_scenario.get(str(scenario_name), fallback_supplier)

            perturbed_opex_by_year = self._sum_costs_from_quantities_by_year(
                traders,
                supplier_data,
                scale_lookup=scale_lookup,
                use_baseline=False,
            )
            baseline_opex_by_year = self._sum_costs_from_quantities_by_year(
                traders,
                supplier_data,
                scale_lookup=scale_lookup,
                use_baseline=True,
            )

            perturbed_emissions_by_year = self._sum_emissions_from_quantities_by_year(
                traders,
                supplier_data,
                scale_lookup=scale_lookup,
                use_baseline=False,
            )
            baseline_emissions_by_year = self._sum_emissions_from_quantities_by_year(
                traders,
                supplier_data,
                scale_lookup=scale_lookup,
                use_baseline=True,
            )

            if (
                perturbed_opex_by_year is None
                and baseline_opex_by_year is None
                and perturbed_emissions_by_year is None
                and baseline_emissions_by_year is None
            ):
                logger.debug(
                    "[MC] could not reconstruct TAC delta contribution: scenario=%s",
                    scenario_name,
                )
                continue

            perturbed_npv_opex = self._discount_year_map(perturbed_opex_by_year or {}, interest=interest)
            baseline_npv_opex = self._discount_year_map(baseline_opex_by_year or {}, interest=interest)

            perturbed_npv_emission_cost = self._discount_emission_costs(
                perturbed_emissions_by_year or {},
                interest=interest,
                emission_cost=emission_cost,
            )
            baseline_npv_emission_cost = self._discount_emission_costs(
                baseline_emissions_by_year or {},
                interest=interest,
                emission_cost=emission_cost,
            )

            delta_tac = (
                (perturbed_npv_opex - baseline_npv_opex) + (perturbed_npv_emission_cost - baseline_npv_emission_cost)
            ) / apvf

            logger.debug(
                (
                    "[MC] reconstructed TAC delta: scenario=%s "
                    "perturbed_npv_opex=%s baseline_npv_opex=%s "
                    "perturbed_npv_emission_cost=%s baseline_npv_emission_cost=%s "
                    "apvf=%s delta_tac=%s"
                ),
                scenario_name,
                perturbed_npv_opex,
                baseline_npv_opex,
                perturbed_npv_emission_cost,
                baseline_npv_emission_cost,
                apvf,
                delta_tac,
            )

            scenario_deltas.append(delta_tac)

        if not scenario_deltas:
            return None

        return reference_tac + (sum(scenario_deltas) / len(scenario_deltas))

    def _reference_kpi_value(
        self,
        design: Design,
        kpi_name: str,
    ) -> float | None:
        ref = design.meta.get("reference_kpis", {})
        if not isinstance(ref, Mapping):
            return None

        value = ref.get(kpi_name)
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _build_sampled_input_scale_lookup(
        self,
        sampled_inputs: Mapping[str, Any],
    ) -> dict[tuple[str, str], float]:
        lookup: dict[tuple[str, str], float] = {}

        for key, raw_value in sampled_inputs.items():
            try:
                parsed = self._parse_sampled_input_key(key)
                factor = float(raw_value)
            except (TypeError, ValueError):
                continue

            carrier_name = self._canonical_carrier_name(parsed["carrier_name"])
            lookup[(carrier_name, parsed["field_name"])] = factor

        return lookup

    def _read_interest(self, experiment: EtaIncerto) -> float:
        try:
            raw = getattr(experiment.config.pyomo, "interest", 0.0)
        except Exception:
            raw = 0.0

        if isinstance(raw, Mapping):
            vals = list(raw.values())
            return float(vals[0]) if vals else 0.0

        return self._coerce_float(raw, default=0.0)

    def _read_emission_cost(self, experiment: EtaIncerto) -> float:
        try:
            raw = getattr(experiment.config.pyomo, "emission_cost", 0.0)
        except Exception:
            raw = 0.0

        if isinstance(raw, Mapping):
            vals = list(raw.values())
            return float(vals[0]) if vals else 0.0

        return self._coerce_float(raw, default=0.0)

    def _read_n_years(self, experiment: EtaIncerto) -> int:
        try:
            raw = getattr(experiment.config.pyomo.horizon, "n_years", 1)
        except Exception:
            raw = 1

        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = 1

        return max(value, 1)

    def _read_n_years_from_scenarios(self, invest_scenarios: Any) -> int:
        for scenario in self._coerce_scenarios_iterable(invest_scenarios):
            system = self._resolve_expected_system(scenario)
            if system is None:
                continue

            years_set = getattr(system, "years_set", None)
            if years_set:
                try:
                    return max(len(list(years_set)), 1)
                except Exception:
                    continue

        return 1

    def _apvf(self, *, interest: float, n_years: int) -> float:
        if interest <= 0.0:
            return float(max(n_years, 1))

        th = max(int(n_years), 1)
        return ((1.0 + interest) ** th - 1.0) / (interest * (1.0 + interest) ** th)

    def _discount_year_map(
        self,
        yearly_values: Mapping[int, float],
        *,
        interest: float,
    ) -> float:
        if not yearly_values:
            return 0.0

        years = sorted(int(year) for year in yearly_values)
        y0 = min(years)

        total = 0.0
        for year in years:
            exponent = int(year) - int(y0) + 1
            discount = 1.0 / ((1.0 + interest) ** exponent) if interest > 0.0 else 1.0
            total += float(yearly_values[year]) * discount
        return total

    def _discount_emission_costs(
        self,
        yearly_emissions: Mapping[int, float],
        *,
        interest: float,
        emission_cost: float,
    ) -> float:
        if not yearly_emissions or emission_cost == 0.0:
            return 0.0

        yearly_costs = {int(year): float(value) * emission_cost for year, value in yearly_emissions.items()}
        return self._discount_year_map(yearly_costs, interest=interest)

    def _annualize_year_map(
        self,
        yearly_values: Mapping[int, float],
        *,
        n_years: int,
    ) -> float:
        if not yearly_values:
            return 0.0

        horizon = max(int(n_years), 1)
        return sum(float(v) for v in yearly_values.values()) / horizon

    def _sum_costs_from_quantities_by_year(
        self,
        traders: Any,
        supplier_data: Any,
        *,
        scale_lookup: Mapping[tuple[str, str], float] | None = None,
        use_baseline: bool = False,
    ) -> dict[int, float] | None:
        if not isinstance(traders, Mapping):
            return None

        totals: dict[int, float] = {}
        found = False

        for trader_name, trader in traders.items():
            if not isinstance(trader, Mapping):
                continue

            qty_map = trader.get("Quantity_kWh_per_year")
            if not isinstance(qty_map, Mapping):
                continue

            carrier_obj = self._get_supplier_carrier(supplier_data, str(trader_name))
            if carrier_obj is None:
                logger.debug("[MC] no supplier carrier found for trader '%s'", trader_name)
                continue

            unit_price = getattr(carrier_obj, "unit_price", None)
            if unit_price is None and isinstance(carrier_obj, Mapping):
                unit_price = carrier_obj.get("unit_price")

            if unit_price is None:
                logger.debug("[MC] no unit_price found for trader '%s'", trader_name)
                continue

            factor = self._carrier_field_scale_factor(
                trader_name=str(trader_name),
                field_name="unit_price",
                scale_lookup=scale_lookup,
            )

            for year_key, qty in qty_map.items():
                try:
                    year = int(year_key)
                    qty_val = float(qty)
                except Exception:
                    logger.debug("[MC] quantity conversion failed for trader '%s'", trader_name, exc_info=True)
                    continue

                price = self._resolve_cost_factor(unit_price, year)
                if price is None:
                    logger.debug(
                        "[MC] could not resolve unit price for trader='%s' year='%s'",
                        trader_name,
                        year,
                    )
                    continue

                if use_baseline and factor != 0.0:
                    price = price / factor

                totals[year] = totals.get(year, 0.0) + qty_val * price
                found = True

        return totals if found else None

    def _append_numeric(self, target: list[float], value: Any) -> None:
        if value is None:
            return

        try:
            target.append(float(value))
        except Exception:
            logger.debug("[MC] numeric conversion failed", exc_info=True)

    def _extract_total_emissions_from_result(
        self,
        result: Any,
        invest_scenarios: Any,
    ) -> float | None:
        if not isinstance(result, Mapping):
            return None

        supplier_by_scenario = self._build_supplier_data_index(invest_scenarios)
        scenario_totals: list[float] = []

        fallback_supplier = next(iter(supplier_by_scenario.values()), None)
        n_years = self._read_n_years_from_scenarios(invest_scenarios)

        for scenario_name, metrics in result.items():
            if not isinstance(metrics, Mapping):
                continue

            traders = self._get_metric(metrics, "technical", "traders_yearly")
            logger.debug("[MC] scenario metrics keys=%s", sorted(str(k) for k in metrics))
            logger.debug(
                "[MC] traders_yearly type=%s preview=%s",
                type(traders).__name__,
                str(traders)[:1000],
            )

            supplier_data = supplier_by_scenario.get(str(scenario_name), fallback_supplier)

            yearly = self._sum_emissions_from_quantities_by_year(
                traders,
                supplier_data,
                scale_lookup=None,
                use_baseline=False,
            )
            if not yearly:
                continue

            total_annualized = self._annualize_year_map(yearly, n_years=n_years)

            logger.debug(
                "[MC] reconstructed scenario emissions: scenario=%s yearly=%s annualized_total=%s supplier_found=%s",
                scenario_name,
                yearly,
                total_annualized,
                supplier_data is not None,
            )

            scenario_totals.append(total_annualized)

        if not scenario_totals:
            return None

        return sum(scenario_totals) / len(scenario_totals)

    def _build_supplier_data_index(self, invest_scenarios: Any) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for scenario in self._coerce_scenarios_iterable(invest_scenarios):
            scenario_name = getattr(scenario, "name", None)
            energy_scenario = getattr(scenario, "energy_scenario", None)
            supplier_data = self._resolve_supplier_data(energy_scenario)
            if scenario_name is not None and supplier_data is not None:
                out[str(scenario_name)] = supplier_data
        return out

    def _warn_if_expected_emissions_missing(
        self,
        projected: Mapping[str, float],
        design: Design,
    ) -> None:
        ref = design.meta.get("reference_kpis")
        if isinstance(ref, Mapping) and "total_emissions" in ref and "total_emissions" not in projected:
            logger.warning(
                "[MC] total_emissions is expected (reference_kpis) but missing after extraction; "
                "Monte Carlo will raise KeyError unless KPI list is adjusted. "
                "Check technical/traders_yearly and scenario supplier_data emission factors "
                "(including year key types: int vs str).",
            )

    def _finalize_kpis(self, out: Mapping[str, float], design: Design) -> dict[str, float]:
        projected = self._project_expected_kpis(out, design)
        self._warn_if_expected_emissions_missing(projected, design)
        return projected

    @staticmethod
    def _get_metric(metrics: Mapping[Any, Any], category: str, name: str) -> Any:
        """Read metrics written as tuple keys or legacy string paths."""
        tuple_key = (category, name)
        if tuple_key in metrics:
            return metrics[tuple_key]
        str_key = f"{category}/{name}"
        if str_key in metrics:
            return metrics[str_key]
        return None

    def _sum_emissions_from_quantities(
        self,
        traders: Any,
        supplier_data: Any,
    ) -> float | None:
        yearly = self._sum_emissions_from_quantities_by_year(traders, supplier_data)
        if not yearly:
            return None
        return sum(yearly.values())

    def _sum_emissions_from_quantities_by_year(
        self,
        traders: Any,
        supplier_data: Any,
        *,
        scale_lookup: Mapping[tuple[str, str], float] | None = None,
        use_baseline: bool = False,
    ) -> dict[int, float] | None:
        if not isinstance(traders, Mapping):
            return None

        if not use_baseline:
            precomputed = self._sum_emissions_from_precomputed_traders_by_year(traders)
            if precomputed is not None:
                return precomputed

        totals: dict[int, float] = {}
        found = False

        for trader_name, trader in traders.items():
            yearly = self._extract_trader_emissions_by_year(
                trader_name=str(trader_name),
                trader=trader,
                supplier_data=supplier_data,
                scale_lookup=scale_lookup,
                use_baseline=use_baseline,
            )
            if not yearly:
                continue

            for year, value in yearly.items():
                totals[year] = totals.get(year, 0.0) + value
            found = True

        return totals if found else None

    def _extract_trader_emissions_by_year(
        self,
        *,
        trader_name: str,
        trader: Any,
        supplier_data: Any,
        scale_lookup: Mapping[tuple[str, str], float] | None,
        use_baseline: bool,
    ) -> dict[int, float] | None:
        if not isinstance(trader, Mapping):
            return None

        qty_map = trader.get("Quantity_kWh_per_year")
        if not isinstance(qty_map, Mapping):
            return None

        carrier_obj = self._get_supplier_carrier(supplier_data, trader_name)
        if carrier_obj is None:
            logger.debug("[MC] no supplier carrier found for trader '%s'", trader_name)
            return None

        emissions_per_unit = self._resolve_emissions_source(
            carrier_obj=carrier_obj,
            field_name="emissions_per_unit",
            trader_name=trader_name,
        )
        if emissions_per_unit is None:
            return None

        factor_scale = self._carrier_field_scale_factor(
            trader_name=trader_name,
            field_name="emissions_per_unit",
            scale_lookup=scale_lookup,
        )

        totals: dict[int, float] = {}
        found = False

        for year_key, qty in qty_map.items():
            try:
                year = int(year_key)
                qty_val = float(qty)
            except Exception:
                logger.debug("[MC] quantity conversion failed for trader '%s'", trader_name, exc_info=True)
                continue

            factor = self._resolve_emissions_factor(emissions_per_unit, year)
            if factor is None:
                continue

            if use_baseline and factor_scale != 0.0:
                factor = factor / factor_scale

            totals[year] = totals.get(year, 0.0) + qty_val * factor
            found = True

        return totals if found else None

    def _resolve_emissions_source(
        self,
        *,
        carrier_obj: Any,
        field_name: str,
        trader_name: str,
    ) -> Any | None:
        value = getattr(carrier_obj, field_name, None)
        if value is None and isinstance(carrier_obj, Mapping):
            value = carrier_obj.get(field_name)

        if value is None:
            logger.debug("[MC] no %s found for trader '%s'", field_name, trader_name)

        return value

    def _sum_emissions_from_precomputed_traders(self, traders: Mapping[Any, Any]) -> float | None:
        yearly = self._sum_emissions_from_precomputed_traders_by_year(traders)
        if not yearly:
            return None
        return sum(yearly.values())

    def _sum_emissions_from_precomputed_traders_by_year(
        self,
        traders: Mapping[Any, Any],
    ) -> dict[int, float] | None:
        totals: dict[int, float] = {}
        found = False
        found_non_zero = False

        for trader in traders.values():
            if not isinstance(trader, Mapping):
                continue

            per_year = trader.get("Emissions_per_year")
            if not isinstance(per_year, Mapping):
                continue

            for year_key, raw in per_year.items():
                try:
                    year = int(year_key)
                    value = float(raw)
                except (TypeError, ValueError):
                    logger.debug("[MC] skip non-numeric Emissions_per_year entry", exc_info=True)
                    continue

                totals[year] = totals.get(year, 0.0) + value
                found = True
                if value != 0.0:
                    found_non_zero = True

        if not found:
            return None

        if not found_non_zero:
            logger.debug("[MC] precomputed Emissions_per_year found but all values are zero; forcing reconstruction")
            return None

        return totals

    def _get_supplier_carrier(
        self,
        supplier_data: Any,
        trader_name: str,
    ) -> Any | None:
        if supplier_data is None:
            return None

        exact = self._get_supplier_carrier_exact(supplier_data, trader_name)
        if exact is not None:
            return exact

        normalized_target = self._normalize_name(trader_name)
        alias_hits = self._carrier_aliases(trader_name)

        if isinstance(supplier_data, Mapping):
            return self._get_supplier_carrier_from_mapping(
                supplier_data=supplier_data,
                normalized_target=normalized_target,
                alias_hits=alias_hits,
            )

        return self._get_supplier_carrier_from_attributes(
            supplier_data=supplier_data,
            normalized_target=normalized_target,
        )

    def _get_supplier_carrier_from_mapping(
        self,
        *,
        supplier_data: Mapping[Any, Any],
        normalized_target: str,
        alias_hits: set[str],
    ) -> Any | None:
        for key, value in supplier_data.items():
            if self._normalize_name(key) == normalized_target:
                return value

        for key, value in supplier_data.items():
            key_norm = self._normalize_name(key)
            if normalized_target in key_norm or key_norm in normalized_target:
                return value

            type_name = self._normalize_name(getattr(value, "type", ""))
            if type_name and (
                normalized_target == type_name or normalized_target in type_name or type_name in normalized_target
            ):
                return value

        for key, value in supplier_data.items():
            key_norm = self._normalize_name(key)
            type_name = self._normalize_name(getattr(value, "type", ""))
            if key_norm in alias_hits or type_name in alias_hits:
                return value

        return None

    def _get_supplier_carrier_from_attributes(
        self,
        *,
        supplier_data: Any,
        normalized_target: str,
    ) -> Any | None:
        for attr_name in dir(supplier_data):
            if attr_name.startswith("_"):
                continue

            try:
                value = getattr(supplier_data, attr_name)
            except Exception:
                continue

            attr_norm = self._normalize_name(attr_name)
            if attr_norm == normalized_target or normalized_target in attr_norm or attr_norm in normalized_target:
                return value

            type_name = self._normalize_name(getattr(value, "type", ""))
            if type_name and (
                type_name == normalized_target or normalized_target in type_name or type_name in normalized_target
            ):
                return value

        return None

    def _get_supplier_carrier_exact(
        self,
        supplier_data: Any,
        trader_name: str,
    ) -> Any | None:
        if isinstance(supplier_data, Mapping):
            return supplier_data.get(trader_name)

        return getattr(supplier_data, trader_name, None)

    def _normalize_name(self, name: Any) -> str:
        text = str(name).strip().lower()
        for ch in (" ", "-", "_", "/", "\\", "."):
            text = text.replace(ch, "")
        return text

    def _carrier_aliases(self, name: str) -> set[str]:
        normalized = self._normalize_name(name)

        alias_map: dict[str, set[str]] = {
            "electricity": {"electricity", "power", "el", "gridelectricity", "electric", "electricitysupplier"},
            "gas": {"gas", "naturalgas", "ng", "gassupplier"},
        }

        aliases = {normalized}
        for canonical, values in alias_map.items():
            if normalized == canonical or normalized in values:
                aliases.update(values)
                aliases.add(canonical)

        return aliases

    def _canonical_carrier_name(self, name: str) -> str:
        aliases = self._carrier_aliases(name)
        if "electricity" in aliases:
            return "electricity"
        if "gas" in aliases:
            return "gas"
        return self._normalize_name(name)

    def _carrier_field_scale_factor(
        self,
        *,
        trader_name: str,
        field_name: str,
        scale_lookup: Mapping[tuple[str, str], float] | None,
    ) -> float:
        if not scale_lookup:
            return 1.0

        carrier_name = self._canonical_carrier_name(trader_name)
        factor = scale_lookup.get((carrier_name, field_name), 1.0)

        try:
            return float(factor)
        except (TypeError, ValueError):
            return 1.0

    def _resolve_cost_factor(
        self,
        unit_price: Any,
        year_key: Any,
    ) -> float | None:
        try:
            year_int = int(year_key)
        except Exception:
            year_int = None

        if isinstance(unit_price, int | float):
            return float(unit_price)

        if isinstance(unit_price, Mapping):
            probed = _lookup_scalar_by_year(unit_price, year_key, default=float("nan"))
            if not math.isnan(probed):
                return probed

            tuple_matches: list[float] = []
            if year_int is not None:
                for key, value in unit_price.items():
                    if isinstance(key, tuple) and key and key[0] == year_int:
                        try:
                            tuple_matches.append(float(value))
                        except Exception:
                            logger.debug("[MC] tuple-key unit price conversion failed", exc_info=True)

            if tuple_matches:
                return sum(tuple_matches) / len(tuple_matches)

        return None

    def _resolve_emissions_factor(
        self,
        emissions_per_unit: Any,
        year_key: Any,
    ) -> float | None:
        try:
            year_int = int(year_key)
        except Exception:
            year_int = None

        if isinstance(emissions_per_unit, int | float):
            return float(emissions_per_unit)

        if isinstance(emissions_per_unit, Mapping):
            probed = _lookup_scalar_by_year(emissions_per_unit, year_key, default=float("nan"))
            if not math.isnan(probed):
                return probed

            tuple_matches: list[float] = []
            if year_int is not None:
                for key, value in emissions_per_unit.items():
                    if isinstance(key, tuple) and key and key[0] == year_int:
                        try:
                            tuple_matches.append(float(value))
                        except Exception:
                            logger.debug("[MC] tuple-key emissions factor conversion failed", exc_info=True)

            if tuple_matches:
                return sum(tuple_matches) / len(tuple_matches)

        return None

    def _extract_kpis_from_results_file(
        self,
        run_dir: Path,
        design: Design,
    ) -> Mapping[str, float]:
        results_path = run_dir / "results" / "determ_w_invest.h5"
        if not results_path.exists():
            raise ValueError(f"No KPI mapping could be extracted and results file does not exist at '{results_path}'.")

        try:
            import h5py
        except ModuleNotFoundError as exc:
            raise RuntimeError("Reading deterministic evaluation results requires 'h5py'.") from exc

        expected_kpis = design.meta.get("reference_kpis", {})
        if not isinstance(expected_kpis, Mapping) or not expected_kpis:
            raise ValueError(f"No KPI mapping could be extracted for design '{design.design_id}'.")

        with h5py.File(results_path, "r") as handle:
            flat_values = self._collect_numeric_hdf5_values(handle)

        projected = self._project_expected_kpis(flat_values, design)
        if projected:
            self._warn_if_expected_emissions_missing(projected, design)
            return projected

        raise ValueError(f"No KPI mapping could be extracted for design '{design.design_id}'.")

    def _collect_numeric_hdf5_values(
        self,
        group: Any,
        prefix: str = "",
    ) -> dict[str, float]:
        out: dict[str, float] = {}

        for key, value in group.items():
            path = f"{prefix}/{key}" if prefix else key

            if hasattr(value, "keys"):
                out.update(self._collect_numeric_hdf5_values(value, path))
                continue

            try:
                raw = value[()]
            except Exception:
                continue

            scalar = self._coerce_scalar(raw)
            if scalar is not None:
                out[path] = scalar

        return out

    def _coerce_scalar(self, value: Any) -> float | None:
        try:
            if hasattr(value, "shape") and getattr(value, "shape", ()) == ():
                value = value.item()
        except Exception:
            pass

        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _coerce_float(self, value: Any, *, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return float(default)

    def _project_expected_kpis(
        self,
        mapping: Mapping[str, float],
        design: Design,
    ) -> dict[str, float]:
        expected = design.meta.get("reference_kpis", {})
        if not isinstance(expected, Mapping) or not expected:
            return dict(mapping)

        out: dict[str, float] = {}

        for expected_name in expected:
            matched_value = self._match_expected_kpi(str(expected_name), mapping)
            if matched_value is not None:
                out[str(expected_name)] = matched_value

        return out

    def _match_expected_kpi(
        self,
        expected_name: str,
        mapping: Mapping[str, float],
    ) -> float | None:
        if expected_name in mapping:
            return mapping[expected_name]

        aliases = self._build_kpi_aliases(expected_name)
        lowered = {key.lower(): value for key, value in mapping.items()}

        for alias in aliases:
            if alias in mapping:
                return mapping[alias]

            alias_lower = alias.lower()
            if alias_lower in lowered:
                return lowered[alias_lower]

        for key, value in mapping.items():
            key_lower = key.lower()
            if any(alias.lower() in key_lower for alias in aliases):
                return value

        return None

    def _build_kpi_aliases(self, expected_name: str) -> tuple[str, ...]:
        alias_map = {
            "capex": (
                "capex",
                "capex_total",
            ),
            "tac": (
                "tac",
                "npv_yearly",
            ),
            "total_emissions": (
                "total_emissions",
                "emissions_total",
                "total_co2",
                "co2_total",
            ),
        }

        aliases = alias_map.get(expected_name, ())
        return (expected_name, *aliases)

    def _normalize_kpi_mapping(
        self,
        mapping: Mapping[str, Any],
    ) -> dict[str, float]:
        out: dict[str, float] = {}

        for key, value in mapping.items():
            try:
                out[str(key)] = float(value)
            except (TypeError, ValueError):
                continue

        return out
