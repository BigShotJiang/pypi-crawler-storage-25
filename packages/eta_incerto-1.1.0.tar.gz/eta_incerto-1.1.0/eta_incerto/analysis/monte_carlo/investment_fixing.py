from __future__ import annotations

from collections.abc import Mapping
from logging import getLogger
from typing import Any

logger = getLogger(__name__)


def fix_design_investments(
    *,
    expected_system: Any,
    frozen_decisions: Mapping[str, Any],
) -> dict[str, int]:
    """Apply frozen investment decisions to an expected system.

    This function is intentionally defensive because the exact attribute layout
    of units and their model containers can differ between variants and
    components.

    Parameters
    ----------
    expected_system:
        The system object that contains the units for one invest scenario.
    frozen_decisions:
        Frozen decision mapping from the MC design object. Expected shape:

        {
            "investment": {
                "<unit_name>": {
                    "bought": 1.0,
                    "p_out_nom": 123.0,
                    "E_nom": 456.0,
                }
            }
        }

    Returns
    -------
    dict[str, int]
        Summary counters for debugging and logging.
    """
    summary = _make_summary()

    investment_block = frozen_decisions.get("investment", {})
    if not isinstance(investment_block, Mapping):
        logger.warning(
            "MC investment fixing: frozen_decisions['investment'] is not a mapping.",
        )
        return summary

    for unit_name, unit_payload in investment_block.items():
        _process_unit_investment(
            expected_system=expected_system,
            unit_name=str(unit_name),
            unit_payload=unit_payload,
            summary=summary,
        )

    _log_summary(summary)
    return summary


def _make_summary() -> dict[str, int]:
    """Create the summary counter structure."""
    return {
        "units_seen": 0,
        "units_fixed": 0,
        "y_fixed": 0,
        "p_out_nom_fixed": 0,
        "E_nom_fixed": 0,
    }


def _process_unit_investment(
    *,
    expected_system: Any,
    unit_name: str,
    unit_payload: Any,
    summary: dict[str, int],
) -> None:
    """Process investment fixing for a single unit."""
    summary["units_seen"] += 1

    if not isinstance(unit_payload, Mapping):
        logger.warning(
            "MC investment fixing: payload for unit '%s' is not a mapping.",
            unit_name,
        )
        return

    unit = _try_get_unit(expected_system, unit_name)
    if unit is None:
        logger.warning(
            "MC investment fixing: unit '%s' not found in expected system.",
            unit_name,
        )
        _log_unit_lookup_debug(expected_system, unit_name)
        return

    logger.info(
        "MC investment fixing inspect: found unit '%s' of type '%s'.",
        unit_name,
        type(unit).__name__,
    )
    _log_unit_structure(unit, unit_name)

    unit_changed = False
    unit_changed |= _apply_bought_fix(unit, unit_name, unit_payload, summary)
    unit_changed |= _apply_capacity_fix(
        unit=unit,
        unit_name=unit_name,
        unit_payload=unit_payload,
        payload_key="p_out_nom",
        summary_key="p_out_nom_fixed",
        summary=summary,
    )
    unit_changed |= _apply_capacity_fix(
        unit=unit,
        unit_name=unit_name,
        unit_payload=unit_payload,
        payload_key="E_nom",
        summary_key="E_nom_fixed",
        summary=summary,
    )

    if unit_changed:
        summary["units_fixed"] += 1


def _apply_bought_fix(
    unit: Any,
    unit_name: str,
    unit_payload: Mapping[str, Any],
    summary: dict[str, int],
) -> bool:
    """Apply the bought/y fix for one unit if present."""
    bought_value = unit_payload.get("bought")
    if bought_value is None:
        return False

    fixed = _try_fix_bought(unit, float(bought_value))
    if fixed:
        summary["y_fixed"] += 1
        return True

    logger.warning(
        "MC investment fixing: could not fix y/is_bought for unit '%s'.",
        unit_name,
    )
    return False


def _apply_capacity_fix(
    *,
    unit: Any,
    unit_name: str,
    unit_payload: Mapping[str, Any],
    payload_key: str,
    summary_key: str,
    summary: dict[str, int],
) -> bool:
    """Apply one capacity-like fix if present in the payload."""
    raw_value = unit_payload.get(payload_key)
    if raw_value is None:
        return False

    fixed = _try_fix_capacity(unit, payload_key, float(raw_value))
    if fixed:
        summary[summary_key] += 1
        return True

    logger.warning(
        "MC investment fixing: could not fix %s for unit '%s'.",
        payload_key,
        unit_name,
    )
    return False


def _log_summary(summary: Mapping[str, int]) -> None:
    """Log the final fixing summary."""
    logger.info(
        "MC investment fixing summary: units_seen=%s units_fixed=%s y_fixed=%s p_out_nom_fixed=%s E_nom_fixed=%s",
        summary["units_seen"],
        summary["units_fixed"],
        summary["y_fixed"],
        summary["p_out_nom_fixed"],
        summary["E_nom_fixed"],
    )


def _try_get_unit(expected_system: Any, unit_name: str) -> Any | None:
    """Resolve a unit object from the expected system."""
    get_unit = getattr(expected_system, "get_unit", None)
    if callable(get_unit):
        try:
            unit = get_unit(unit_name)
        except Exception:
            unit = None
        if unit is not None:
            return unit

    units = getattr(expected_system, "units", None)
    if isinstance(units, Mapping):
        unit = units.get(unit_name)
        if unit is not None:
            return unit

    if isinstance(expected_system, Mapping):
        units_map = expected_system.get("units")
        if isinstance(units_map, Mapping):
            unit = units_map.get(unit_name)
            if unit is not None:
                return unit

    for attr_name in ("components", "nodes", "_units"):
        container = getattr(expected_system, attr_name, None)
        if isinstance(container, Mapping):
            unit = container.get(unit_name)
            if unit is not None:
                return unit

    return None


def _try_fix_bought(unit: Any, value: float) -> bool:
    """Try to fix the investment binary or purchase indicator."""
    candidates = (
        ("unit", "is_bought"),
        ("unit", "_is_bought"),
        ("unit", "y"),
        ("unit", "_y"),
        ("model", "is_bought"),
        ("model", "_is_bought"),
        ("model", "y"),
        ("model", "_y"),
    )

    for scope, attr_name in candidates:
        target = unit if scope == "unit" else getattr(unit, "model", None)
        if target is None:
            continue

        variable = getattr(target, attr_name, None)
        if variable is None:
            logger.info(
                "MC investment fixing inspect: candidate %s.%s is None.",
                scope,
                attr_name,
            )
            continue

        logger.info(
            "MC investment fixing inspect: candidate %s.%s type=%s repr=%s",
            scope,
            attr_name,
            type(variable).__name__,
            variable,
        )

        if _try_fix_variable(variable, value, f"{scope}.{attr_name}"):
            logger.info(
                "MC investment fixing: fixed bought variable via %s.%s.",
                scope,
                attr_name,
            )
            return True

    return False


def _try_fix_capacity(unit: Any, logical_name: str, value: float) -> bool:
    """Try to fix a capacity-like variable on the unit or its model."""
    candidate_map = {
        "p_out_nom": (
            ("unit", "p_out_nom"),
            ("unit", "_p_out_nom"),
            ("unit", "P_out_nom"),
            ("unit", "_P_out_nom"),
            ("unit", "p_heat_out_nom"),
            ("unit", "_p_heat_out_nom"),
            ("unit", "P_heat_out_nom"),
            ("unit", "_P_heat_out_nom"),
            ("model", "p_out_nom"),
            ("model", "_p_out_nom"),
            ("model", "P_out_nom"),
            ("model", "_P_out_nom"),
            ("model", "p_heat_out_nom"),
            ("model", "_p_heat_out_nom"),
            ("model", "P_heat_out_nom"),
            ("model", "_P_heat_out_nom"),
        ),
        "E_nom": (
            ("unit", "E_nom"),
            ("unit", "_E_nom"),
            ("unit", "e_nom"),
            ("unit", "_e_nom"),
            ("model", "E_nom"),
            ("model", "_E_nom"),
            ("model", "e_nom"),
            ("model", "_e_nom"),
        ),
    }

    for scope, attr_name in candidate_map.get(logical_name, ()):
        target = unit if scope == "unit" else getattr(unit, "model", None)
        if target is None:
            continue

        variable = getattr(target, attr_name, None)
        if variable is None:
            logger.info(
                "MC investment fixing inspect: candidate %s.%s is None.",
                scope,
                attr_name,
            )
            continue

        logger.info(
            "MC investment fixing inspect: candidate %s.%s type=%s repr=%s",
            scope,
            attr_name,
            type(variable).__name__,
            variable,
        )

        if _try_fix_variable(variable, value, f"{scope}.{attr_name}"):
            logger.info(
                "MC investment fixing: fixed %s via %s.%s.",
                logical_name,
                scope,
                attr_name,
            )
            return True

    return False


def _try_fix_variable(variable: Any, value: float, label: str) -> bool:
    """Try a sequence of common fix/set patterns on a variable-like object."""
    if variable is None:
        return False

    fix = getattr(variable, "fix", None)
    if callable(fix):
        try:
            fix(value)
            logger.info("MC investment fixing: fixed %s via fix(%s).", label, value)
            return True
        except Exception:
            pass

    set_value = getattr(variable, "set_value", None)
    if callable(set_value):
        try:
            set_value(value)
            fixed_attr = getattr(variable, "fixed", None)
            if fixed_attr is not None:
                try:
                    variable.fixed = True
                except Exception:
                    pass
            logger.info(
                "MC investment fixing: fixed %s via set_value(%s).",
                label,
                value,
            )
            return True
        except Exception:
            pass

    lower = getattr(variable, "lower", None)
    upper = getattr(variable, "upper", None)
    if lower is not None and upper is not None:
        lower_ok = _try_set_bound_container(lower, value)
        upper_ok = _try_set_bound_container(upper, value)
        if lower_ok and upper_ok:
            logger.info(
                "MC investment fixing: fixed %s via lower/upper bounds = %s.",
                label,
                value,
            )
            return True

    try:
        variable.value = value
        logger.info("MC investment fixing: fixed %s via .value = %s.", label, value)
        return True
    except Exception:
        pass

    return False


def _try_set_bound_container(bound_obj: Any, value: float) -> bool:
    """Set all entries of a linopy/xarray-like bound container to one value."""
    data = getattr(bound_obj, "data", None)

    if data is not None:
        try:
            data[...] = value
            return True
        except Exception:
            pass

    values = getattr(bound_obj, "values", None)
    if values is not None:
        try:
            values[...] = value
            return True
        except Exception:
            pass

    loc = getattr(bound_obj, "loc", None)
    coords = getattr(bound_obj, "coords", None)
    if loc is not None and coords is not None:
        try:
            coord_indexers = {name: coords[name].values for name in getattr(coords, "keys", lambda: [])()}
            loc[coord_indexers] = value
            return True
        except Exception:
            pass

    try:
        bound_obj[...] = value
        return True
    except Exception:
        pass

    return False


def _log_unit_lookup_debug(expected_system: Any, requested_unit_name: str) -> None:
    """Log basic system structure when unit lookup fails."""
    system_attrs = _safe_dir(expected_system)
    logger.info(
        "MC investment fixing inspect: expected_system type='%s' requested_unit='%s'.",
        type(expected_system).__name__,
        requested_unit_name,
    )
    logger.info(
        "MC investment fixing inspect: expected_system attrs sample=%s",
        system_attrs[:80],
    )

    units = getattr(expected_system, "units", None)
    if isinstance(units, Mapping):
        logger.info(
            "MC investment fixing inspect: available expected_system.units keys=%s",
            sorted(str(key) for key in units),
        )

    for attr_name in ("components", "nodes", "_units"):
        container = getattr(expected_system, attr_name, None)
        if isinstance(container, Mapping):
            logger.info(
                "MC investment fixing inspect: available %s keys=%s",
                attr_name,
                sorted(str(key) for key in container),
            )


def _log_unit_structure(unit: Any, unit_name: str) -> None:
    """Log unit/model structure for one resolved unit."""
    unit_attrs = _safe_dir(unit)
    logger.info(
        "MC investment fixing inspect: unit '%s' attrs sample=%s",
        unit_name,
        unit_attrs[:120],
    )

    model = getattr(unit, "model", None)
    if model is None:
        logger.info(
            "MC investment fixing inspect: unit '%s' has no 'model' attribute.",
            unit_name,
        )
        return

    model_attrs = _safe_dir(model)
    logger.info(
        "MC investment fixing inspect: unit '%s' model type='%s' attrs sample=%s",
        unit_name,
        type(model).__name__,
        model_attrs[:120],
    )


def _safe_dir(obj: Any) -> list[str]:
    """Return a robust, sorted dir() listing for debug logging."""
    try:
        return sorted(str(name) for name in dir(obj))
    except Exception:
        return []
