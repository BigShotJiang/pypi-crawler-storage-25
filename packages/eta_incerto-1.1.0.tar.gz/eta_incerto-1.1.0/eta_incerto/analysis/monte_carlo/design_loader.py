from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import replace
from logging import getLogger
from pathlib import Path
from typing import Any

import h5py

from eta_incerto.analysis.monte_carlo.datastructures import (
    Design,
    DesignRef,
    FeasibilityPolicy,
)
from eta_incerto.util.io_utils import load_config

log = getLogger(__name__)


RODMO_RESERVED_GROUPS = {
    "__expected__",
    "config",
    "meta",
    "scenarios",
    "topology",
}

KPI_PATHS = {
    "capex": "__expected__/objective/capex",
    "tac": "__expected__/objective/tac",
    "electricity_feed_in_cost": "__expected__/costs/electricity_feed_in_eur",
    "electricity_supplier_cost": "__expected__/costs/electricity_supplier_eur",
    "gas_supplier_cost": "__expected__/costs/gas_supplier_eur",
    "electricity_feed_in_emissions": "__expected__/emissions/electricity_feed_in_t",
    "electricity_supplier_emissions": "__expected__/emissions/electricity_supplier_t",
    "gas_supplier_emissions": "__expected__/emissions/gas_supplier_t",
    "total_emissions": "__expected__/emissions/total_t",
    "electricity_feed_in_energy": "__expected__/energy/electricity_feed_in_wh",
    "electricity_supplier_energy": "__expected__/energy/electricity_supplier_wh",
    "gas_supplier_energy": "__expected__/energy/gas_supplier_wh",
    "scenario_probability_sum": "__expected__/scenario/probability_sum",
}


def load_designs(
    design_refs: Sequence[DesignRef],
    *,
    root_path: Path | None = None,
) -> tuple[Design, ...]:
    """Load, normalize and validate designs referenced by DesignRef."""
    designs: list[Design] = []
    for ref in design_refs:
        resolved = resolve_source(ref, root_path=root_path)
        raw = read_design(ref, resolved)
        design = normalize_design(raw, ref)
        validate_design(design)
        designs.append(design)
    return tuple(designs)


def resolve_source(ref: DesignRef, *, root_path: Path | None = None) -> Path:
    """Resolve the design artifact path."""
    src = Path(ref.source_path)
    if src.is_absolute():
        return src

    if root_path is None:
        return src.resolve()

    return (root_path / src).resolve()


def read_design(ref: DesignRef, resolved_path: Path) -> dict[str, Any]:
    """Read an optimization result into a raw dict structure."""
    if not resolved_path.exists():
        raise FileNotFoundError(f"Design source does not exist: {resolved_path}")

    if ref.source_type.value == "json":
        return _read_json(resolved_path, selector=ref.selector)

    if ref.source_type.value == "h5":
        return _read_h5(resolved_path, selector=ref.selector)

    raise ValueError(f"Unsupported design source_type: {ref.source_type!s}")


def normalize_design(raw: Mapping[str, Any], ref: DesignRef) -> Design:
    """Normalize a raw solution into the uniform Design contract."""
    design_id = ref.design_id or _infer_design_id(raw, ref)
    feasibility_policy = _infer_feasibility_policy(ref)

    if bool(raw.get("__normalized_design__")):
        source_file = str(raw.get("source_file", ref.source_path))
        run_id = raw.get("run_id")
        variant_name = str(raw.get("variant_name", ""))

        scenario_groups_raw = raw.get("scenario_groups", ())
        scenario_groups = (
            tuple(str(x) for x in scenario_groups_raw) if isinstance(scenario_groups_raw, list | tuple) else ()
        )

        topology_summary = raw.get("topology_summary", {})
        config_summary = raw.get("config_summary", {})
        metadata = raw.get("metadata", {})
        reference_kpis = raw.get("reference_kpis", {})
        loader_summary = raw.get("loader_summary", {})

        meta = dict(ref.meta)
        meta.update(
            {
                "source_path": str(ref.source_path),
                "selector": ref.selector,
                "tags": list(ref.tags),
                "source_file": source_file,
                "run_id": run_id,
                "variant_name": variant_name,
                "scenario_groups": list(scenario_groups),
                "reference_kpis": reference_kpis,
                "loader_summary": loader_summary,
                "raw_keys": sorted(raw.keys()),
            }
        )

        if isinstance(metadata, dict):
            meta.update(metadata)

        params = raw.get("params", {})
        if not isinstance(params, dict):
            params = {}

        frozen = raw.get("frozen_decisions", {})
        if not isinstance(frozen, dict):
            frozen = {}

        return Design(
            design_id=str(design_id),
            params=params,
            frozen_decisions=frozen,
            feasibility_policy=feasibility_policy,
            source_file=source_file,
            run_id=str(run_id) if run_id is not None else None,
            variant_name=variant_name,
            scenario_groups=scenario_groups,
            topology_summary=dict(topology_summary) if isinstance(topology_summary, dict) else {},
            config_summary=dict(config_summary) if isinstance(config_summary, dict) else {},
            meta=meta,
        )

    params = _infer_params(raw)
    frozen = _infer_frozen_decisions(raw)

    meta = dict(ref.meta)
    meta.update(
        {
            "source_path": str(ref.source_path),
            "selector": ref.selector,
            "tags": list(ref.tags),
            "raw_keys": sorted(raw.keys()),
        }
    )
    meta["raw"] = _compact_raw(raw)

    return Design(
        design_id=str(design_id),
        params=params,
        frozen_decisions=frozen,
        feasibility_policy=feasibility_policy,
        source_file=str(ref.source_path),
        run_id=None,
        variant_name="",
        scenario_groups=(),
        topology_summary={},
        config_summary={},
        meta=meta,
    )


def validate_design(design: Design) -> None:
    """Validate that a Design is minimally complete and consistent."""
    if not design.design_id:
        raise ValueError("Design.design_id must be non-empty.")

    if not isinstance(design.params, dict):
        raise TypeError("Design.params must be a dict.")

    if not isinstance(design.frozen_decisions, dict):
        raise TypeError("Design.frozen_decisions must be a dict.")

    if not isinstance(design.feasibility_policy, FeasibilityPolicy):
        raise TypeError("Design.feasibility_policy must be a FeasibilityPolicy enum.")

    if not design.source_file:
        raise ValueError(f"Design '{design.design_id}' must have a non-empty source_file.")

    if design.variant_name and not isinstance(design.variant_name, str):
        raise TypeError("Design.variant_name must be a string.")

    if not isinstance(design.scenario_groups, list | tuple):
        raise TypeError("Design.scenario_groups must be a sequence of strings.")


def _read_json(path: Path, *, selector: str | None) -> dict[str, Any]:
    """Read JSON-like config/solution payload."""
    raw = load_config(path)

    if selector:
        selected = _select_from_mapping(raw, selector)
        if not isinstance(selected, dict):
            return {"selected": selected, "root": raw}
        return selected

    if not isinstance(raw, dict):
        raise TypeError(f"Expected dict-like JSON config at {path}, got {type(raw)}.")
    return raw


def _read_h5(path: Path, *, selector: str | None) -> dict[str, Any]:
    """Read H5-based optimization results."""
    with h5py.File(path, "r") as f:
        if selector is None and _is_rodmo_result_h5(f):
            return _read_rodmo_result_h5(f, path)

        node = f
        if selector:
            node = f[selector]

        if isinstance(node, h5py.Dataset):
            return {"selected_dataset": _h5_value(node), "selector": selector}

        if isinstance(node, h5py.Group):
            return _h5_group_to_dict(node)

        raise TypeError(f"Unsupported H5 node type for selector {selector!r}: {type(node)}")


def _is_rodmo_result_h5(f: h5py.File) -> bool:
    """Heuristic detection for RODMO result files."""
    keys = set(f.keys())
    has_core_groups = {"__expected__", "config", "meta"}.issubset(keys)
    has_variant_group = any(key not in RODMO_RESERVED_GROUPS and isinstance(f[key], h5py.Group) for key in f)
    return has_core_groups and has_variant_group


def _read_rodmo_result_h5(f: h5py.File, path: Path) -> dict[str, Any]:
    """Extract a compact, design-oriented payload from a RODMO result H5."""
    scenario_groups = _detect_scenario_groups(f)
    variant_name = _derive_variant_name(scenario_groups, path)
    run_id = _extract_run_id(path)

    reference_kpis = _extract_reference_kpis(f)
    investment_source, investment_records = _extract_investment_records(f, scenario_groups)

    frozen_decisions = {
        "investment": investment_records,
    }

    params: dict[str, Any] = {
        "variant_name": variant_name,
        "source_kind": "rodmo_result_h5",
        "reference_kpis": reference_kpis,
    }

    if investment_records:
        params["has_investment_decisions"] = True
        params["investment_units"] = sorted(investment_records.keys())
        params["n_investment_units"] = len(investment_records)
    else:
        params["has_investment_decisions"] = False
        params["investment_units"] = []
        params["n_investment_units"] = 0

    return {
        "__normalized_design__": True,
        "source_file": str(path),
        "run_id": run_id,
        "variant_name": variant_name,
        "scenario_groups": scenario_groups,
        "params": params,
        "frozen_decisions": frozen_decisions,
        "topology_summary": _extract_topology_summary(f),
        "config_summary": _extract_config_summary(f),
        "metadata": _extract_metadata(f),
        "reference_kpis": reference_kpis,
        "loader_summary": {
            "investment_source": investment_source,
            "n_investment_units": len(investment_records),
            "investment_units": sorted(investment_records.keys()),
        },
    }


def _detect_scenario_groups(f: h5py.File) -> list[str]:
    return sorted(key for key in f if key not in RODMO_RESERVED_GROUPS and isinstance(f[key], h5py.Group))


def _derive_variant_name(scenario_groups: Sequence[str], source_file: Path) -> str:
    """Derive the eta-incerto variant name from H5 scenario group names.

    Example:
    - variant_one_demand_ambient_series_S1 -> variant_one
    - variant_two_demand_ambient_series_S2 -> variant_two
    """
    if not scenario_groups:
        return source_file.stem

    prefixes: list[str] = []
    for name in scenario_groups:
        if "_S" in name:
            prefixes.append(name.split("_S", 1)[0])
        else:
            prefixes.append(name)

    first = prefixes[0]
    if not all(p == first for p in prefixes):
        return source_file.stem

    parts = first.split("_")

    # Typical eta-incerto conventional naming:
    # variant_one_demand_ambient_series -> variant_one
    if len(parts) >= 2 and parts[0] == "variant":
        return "_".join(parts[:2])

    # Fallback: if it already looks like a plain variant name, keep it
    return first


def _extract_run_id(path: Path) -> str | None:
    parts = path.parts
    if "runs" in parts:
        idx = parts.index("runs")
        if idx + 1 < len(parts):
            return parts[idx + 1]
    return None


def _extract_topology_summary(f: h5py.File) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    if "topology" not in f:
        return summary

    topo = f["topology"]
    summary["top_level_keys"] = sorted(topo.keys())

    if "nodes" in topo and isinstance(topo["nodes"], h5py.Dataset):
        nodes = _to_jsonable(topo["nodes"][()])
        summary["n_nodes"] = len(nodes) if isinstance(nodes, list) else None

    if "edges" in topo and isinstance(topo["edges"], h5py.Dataset):
        edges = _to_jsonable(topo["edges"][()])
        summary["n_edges"] = len(edges) if isinstance(edges, list) else None

    return summary


def _extract_config_summary(f: h5py.File) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    if "config" not in f:
        return summary

    config = f["config"]
    summary["top_level_keys"] = sorted(config.keys())

    for key, item in config.items():
        if isinstance(item, h5py.Dataset):
            value = _to_jsonable(item[()])
            if isinstance(value, int | float | str | bool) or value is None:
                summary[key] = value

    return summary


def _extract_metadata(f: h5py.File) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    if "meta" not in f:
        return summary

    meta = f["meta"]
    for key, item in meta.items():
        if isinstance(item, h5py.Dataset):
            summary[key] = _to_jsonable(item[()])
    return summary


def _extract_reference_kpis(f: h5py.File) -> dict[str, float]:
    result: dict[str, float] = {}
    for kpi_name, h5_path in KPI_PATHS.items():
        value = _read_path(f, h5_path)
        if isinstance(value, int | float):
            result[kpi_name] = float(value)
    return result


def _extract_investment_records(
    f: h5py.File,
    scenario_groups: Sequence[str],
) -> tuple[str | None, dict[str, dict[str, Any]]]:
    """Extract investment decisions from RODMO H5 results.

    Preferred source is '__expected__/investment'. If that does not exist,
    fall back to the first scenario group that contains an 'investment' block.
    """
    candidate_paths = ["__expected__/investment"]
    candidate_paths.extend(f"{group}/investment" for group in scenario_groups)

    for candidate in candidate_paths:
        if candidate in f and isinstance(f[candidate], h5py.Group):
            records = _group_investment_datasets(f[candidate])
            if records:
                return candidate, records

    return None, {}


def _group_investment_datasets(group: h5py.Group) -> dict[str, dict[str, Any]]:
    """Group flat investment datasets by unit prefix.

    Example:
    hp_hnht_cn_bought
    hp_hnht_cn_investment_cost
    hp_hnht_cn_p_out_nom

    ->
    {
        "hp_hnht_cn": {
            "bought": 1.0,
            "investment_cost": ...,
            "p_out_nom": ...,
        }
    }
    """
    suffixes = (
        "investment_cost",
        "p_out_nom",
        "E_nom",
        "bought",
    )

    grouped: dict[str, dict[str, Any]] = {}
    passthrough: dict[str, Any] = {}

    for key, item in group.items():
        if not isinstance(item, h5py.Dataset):
            continue

        value = _to_jsonable(item[()])
        matched = False

        for suffix in suffixes:
            token = f"_{suffix}"
            if key.endswith(token):
                unit_name = key[: -len(token)]
                if not unit_name:
                    break
                grouped.setdefault(unit_name, {})[suffix] = value
                matched = True
                break

        if not matched:
            passthrough[key] = value

    if passthrough:
        grouped["__ungrouped__"] = passthrough

    return grouped


def _read_path(f: h5py.File, path: str) -> Any | None:
    if path not in f:
        return None

    obj = f[path]
    if isinstance(obj, h5py.Dataset):
        return _to_jsonable(obj[()])
    return None


def _h5_group_to_dict(group: h5py.Group) -> dict[str, Any]:
    out: dict[str, Any] = {}

    if group.attrs:
        out["__attrs__"] = {k: _to_jsonable(v) for k, v in group.attrs.items()}

    for key, item in group.items():
        if isinstance(item, h5py.Dataset):
            out[key] = _h5_value(item)
        elif isinstance(item, h5py.Group):
            out[key] = _h5_group_to_dict(item)
        else:
            out[key] = str(item)
    return out


def _h5_value(ds: h5py.Dataset) -> Any:
    v = ds[()]
    return _to_jsonable(v)


def _to_jsonable(v: Any) -> Any:
    """Convert common H5/numpy types to JSON-serializable python types."""
    out: Any = v

    try:
        import numpy as np
    except ImportError:
        np = None  # type: ignore[assignment]

    if np is not None:
        if isinstance(out, np.generic):
            out = out.item()
        elif isinstance(out, np.ndarray):
            out = out.tolist()

    if isinstance(out, bytes | bytearray):
        try:
            out = out.decode("utf-8")
        except Exception:
            out = out.hex()

    if isinstance(out, int | float | str | bool) or out is None:
        pass
    elif isinstance(out, dict):
        out = {str(k): _to_jsonable(val) for k, val in out.items()}
    elif isinstance(out, list | tuple):
        out = [_to_jsonable(x) for x in out]
    else:
        out = str(out)

    return out


def _select_from_mapping(root: Any, selector: str) -> Any:
    """Select nested data by a simple slash-separated selector."""
    if not selector:
        return root

    if not isinstance(root, dict):
        raise TypeError("Selector can only be applied to dict-like objects.")

    parts = [p for p in selector.split("/") if p]
    cur: Any = root
    for p in parts:
        if not isinstance(cur, dict) or p not in cur:
            raise KeyError(f"Selector '{selector}' not found at segment '{p}'.")
        cur = cur[p]
    return cur


def _infer_design_id(raw: Mapping[str, Any], ref: DesignRef) -> str:
    for key in ("design_id", "id", "name"):
        if key in raw and isinstance(raw[key], str) and raw[key].strip():
            return raw[key].strip()

    src = Path(ref.source_path)
    base = src.stem
    if ref.selector:
        base = f"{base}:{ref.selector.strip('/')}"

    if bool(raw.get("__normalized_design__")) and isinstance(raw.get("run_id"), str):
        variant_name = raw.get("variant_name")
        if isinstance(variant_name, str) and variant_name.strip():
            return f"{raw['run_id']}__{variant_name}"

    return base


def _infer_feasibility_policy(ref: DesignRef) -> FeasibilityPolicy:
    policy = ref.meta.get("feasibility_policy")
    if isinstance(policy, str):
        return FeasibilityPolicy(policy)
    return FeasibilityPolicy.SKIP


def _infer_params(raw: Mapping[str, Any]) -> dict[str, float]:
    """Try to infer optimized parameters from common payload patterns."""
    for key in ("params", "decision_vars", "variables"):
        if key in raw and isinstance(raw[key], dict):
            return _coerce_float_dict(raw[key])

    if "x" in raw and isinstance(raw["x"], list | tuple):
        names = raw.get("x_names")
        x = raw["x"]
        if isinstance(names, list | tuple) and len(names) == len(x):
            return {str(n): float(v) for n, v in zip(names, x, strict=True) if _is_number(v)}
        return {f"x{i}": float(v) for i, v in enumerate(x) if _is_number(v)}

    for container_key in ("best", "result", "solution", "optimum", "optimization"):
        sub = raw.get(container_key)
        if isinstance(sub, dict):
            nested = _infer_params(sub)
            if nested:
                return nested

    return {}


def _infer_frozen_decisions(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Try to infer fixed structural/invest decisions."""
    for key in ("frozen_decisions", "investments", "structure", "discrete", "binary"):
        if key in raw and isinstance(raw[key], dict):
            return dict(raw[key])

    for container_key in ("best", "result", "solution", "optimum"):
        sub = raw.get(container_key)
        if isinstance(sub, dict):
            nested = _infer_frozen_decisions(sub)
            if nested:
                return nested

    return {}


def _coerce_float_dict(d: Mapping[str, Any]) -> dict[str, float]:
    out: dict[str, float] = {}
    for k, v in d.items():
        if _is_number(v):
            out[str(k)] = float(v)
    return out


def _is_number(v: Any) -> bool:
    return isinstance(v, int | float) and not isinstance(v, bool)


def _compact_raw(raw: Mapping[str, Any], *, max_bytes: int = 50_000) -> dict[str, Any]:
    """Keep raw payload but avoid exploding bundle sizes."""
    try:
        s = json.dumps(raw, ensure_ascii=False)
    except TypeError:
        return {k: str(type(v)) for k, v in raw.items()}

    if len(s.encode("utf-8")) <= max_bytes:
        return dict(raw)

    compact: dict[str, Any] = {}
    for k, v in raw.items():
        if isinstance(v, int | float | str | bool) or v is None:
            compact[k] = v
        else:
            compact[k] = f"<{type(v).__name__}>"
    compact["__truncated__"] = True
    return compact


def override_feasibility_policy(design: Design, policy: FeasibilityPolicy) -> Design:
    """Convenience helper to override a design's feasibility policy."""
    return replace(design, feasibility_policy=policy)
