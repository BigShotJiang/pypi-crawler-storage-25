from __future__ import annotations

from collections.abc import Mapping, Sequence

import numpy as np

from eta_incerto.analysis.monte_carlo.datastructures import (
    ComparisonSummary,
    KpiSamples,
    KpiSummary,
)


def compare_designs(
    *,
    summaries: Sequence[KpiSummary],
    kpi_name: str,
    baseline_design_id: str | None = None,
    tail_key: str = "p05",
    use_crn: bool = True,
    raw_runs: Sequence[tuple[KpiSamples, object]] | None = None,
) -> list[ComparisonSummary]:
    """Compare designs stage-wise for one KPI.

    Parameters
    ----------
    summaries:
        List of KpiSummary objects (one per design/stage/run).
    kpi_name:
        KPI to compare.
    baseline_design_id:
        Design used as baseline for deltas. If None, the first design found per stage is used.
    tail_key:
        Quantile key used as "tail metric" delta (default p05).
        This is meaningful especially for MIN-direction KPIs.
    use_crn:
        If True, compute paired diffs if raw samples are available.
    raw_runs:
        Optional raw runs as (KpiSamples, RunMeta) pairs to compute paired diffs.
        We only use KpiSamples; RunMeta is ignored and typed as object to avoid import cycles.

    Returns
    -------
    List[ComparisonSummary] with one entry per stage (aggregated across runs).
    """
    by_stage = _group_summaries_by_stage(summaries, kpi_name)

    paired_by_stage = None
    if use_crn and raw_runs is not None:
        paired_by_stage = _paired_diffs_by_stage(raw_runs, kpi_name)

    results: list[ComparisonSummary] = []
    for stage_id, stage_summaries in sorted(by_stage.items(), key=lambda x: x[0]):
        # Aggregate per design within this stage (across runs).
        agg = _aggregate_stage(stage_summaries, kpi_name)

        # Determine baseline for this stage.
        baseline_id = baseline_design_id or _pick_first_design_id(agg)
        if baseline_id not in agg:
            raise KeyError(
                f"Baseline design '{baseline_id}' not present in stage '{stage_id}'. Available: {sorted(agg.keys())}."
            )

        baseline = agg[baseline_id]
        level = baseline["level"]

        # Determine available designs
        design_ids = sorted(agg.keys())

        delta_median: dict[str, float] = {}
        delta_tail: dict[str, float] = {}
        paired_diff: dict[str, float] = {}

        base_median = baseline["median"]
        base_tail = baseline["tail"].get(tail_key)

        for did in design_ids:
            med = agg[did]["median"]
            tail = agg[did]["tail"].get(tail_key)

            if base_median is not None and med is not None:
                delta_median[did] = float(med - base_median)

            if base_tail is not None and tail is not None:
                delta_tail[did] = float(tail - base_tail)

            if paired_by_stage is not None:
                # paired_by_stage: stage_id -> design_id -> mean(paired diffs vs baseline)
                stage_map = paired_by_stage.get(stage_id, {})
                if did in stage_map and baseline_id in stage_map:
                    # paired diffs are defined vs baseline: base is 0.0
                    paired_diff[did] = float(stage_map[did])
                elif did in stage_map and did == baseline_id:
                    paired_diff[did] = 0.0

        results.append(
            ComparisonSummary(
                stage_id=stage_id,
                level=float(level),
                kpi_name=kpi_name,
                design_ids=tuple(design_ids),
                delta_median=delta_median,
                delta_tail=delta_tail,
                paired_diff=paired_diff,
                meta={
                    "baseline_design_id": baseline_id,
                    "tail_key": tail_key,
                    "use_crn": bool(use_crn),
                    "paired_available": paired_by_stage is not None,
                },
            )
        )

    return results


def _group_summaries_by_stage(
    summaries: Sequence[KpiSummary],
    kpi_name: str,
) -> dict[str, list[KpiSummary]]:
    by_stage: dict[str, list[KpiSummary]] = {}
    for s in summaries:
        if kpi_name not in s.stats_by_kpi:
            continue
        by_stage.setdefault(s.stage_id, []).append(s)
    if not by_stage:
        raise ValueError(f"No summaries found for KPI '{kpi_name}'.")
    return by_stage


def _aggregate_stage(stage_summaries: Sequence[KpiSummary], kpi_name: str) -> dict[str, dict[str, object]]:
    """Aggregate multiple runs for a stage into per-design representative values.

    Current aggregation:
    - median: mean of run medians (robust and simple)
    - tail: mean of run quantiles per tail_key
    - level: taken from the first summary (assumed stable across runs)
    """
    agg: dict[str, dict[str, object]] = {}
    for s in stage_summaries:
        did = s.design_id
        stats = s.stats_by_kpi[kpi_name]
        bucket = agg.setdefault(
            did,
            {"level": s.level, "medians": [], "tails": []},
        )
        if stats.median is not None:
            bucket["medians"].append(float(stats.median))
        bucket["tails"].append({k: float(v) for k, v in stats.quantiles.items()})

    out: dict[str, dict[str, object]] = {}
    for did, bucket in agg.items():
        medians = np.asarray(bucket["medians"], dtype=float)
        tails_list = bucket["tails"]
        out[did] = {
            "level": float(bucket["level"]),
            "median": float(np.mean(medians)) if medians.size > 0 else None,
            "tail": _mean_tail_quantiles(tails_list),
        }
    return out


def _mean_tail_quantiles(tails_list: Sequence[Mapping[str, float]]) -> dict[str, float]:
    keys = sorted({k for d in tails_list for k in d})
    out: dict[str, float] = {}
    for k in keys:
        vals = [float(d[k]) for d in tails_list if k in d]
        if vals:
            out[k] = float(np.mean(np.asarray(vals, dtype=float)))
    return out


def _pick_first_design_id(agg: Mapping[str, object]) -> str:
    return sorted(agg.keys())[0]


def _paired_diffs_by_stage(
    raw_runs: Sequence[tuple[KpiSamples, object]],
    kpi_name: str,
) -> dict[str, dict[str, float]]:
    """Compute paired mean differences vs baseline per stage if CRN is used.

    Output format:
        stage_id -> design_id -> mean(samplewise_diff_vs_baseline)

    Notes:
    - This requires that samples are aligned across designs (CRN).
    - We compute diffs against the first design encountered within each stage/run group.
      The higher-level compare_designs() will re-anchor against baseline_design_id if needed.
    """
    # Group by (stage_id, run_id)
    grouped: dict[tuple[str, int], dict[str, np.ndarray]] = {}
    for samples, _meta in raw_runs:
        if kpi_name not in samples.samples_by_kpi:
            continue
        key = (samples.stage_id, samples.run_id)
        grouped.setdefault(key, {})
        grouped[key][samples.design_id] = np.asarray(samples.samples_by_kpi[kpi_name], dtype=float)

    # For each stage, compute per-run diffs, then average across runs.
    by_stage: dict[str, dict[str, list[float]]] = {}
    for (stage_id, _run_id), per_design in grouped.items():
        if len(per_design) < 2:
            continue
        design_ids = sorted(per_design.keys())
        baseline_id = design_ids[0]
        base = per_design[baseline_id]

        for did in design_ids:
            arr = per_design[did]
            # Align to min length defensively (should be equal under CRN unless skips occurred).
            n = min(base.size, arr.size)
            if n == 0:
                continue
            diff = arr[:n] - base[:n]
            # Filter non-finite diffs to avoid NaN penalties dominating.
            diff = diff[np.isfinite(diff)]
            if diff.size == 0:
                continue
            by_stage.setdefault(stage_id, {}).setdefault(did, []).append(float(np.mean(diff)))

    # Average across runs
    out: dict[str, dict[str, float]] = {}
    for stage_id, per_design in by_stage.items():
        out[stage_id] = {}
        for did, diffs in per_design.items():
            out[stage_id][did] = float(np.mean(np.asarray(diffs, dtype=float)))

    return out
