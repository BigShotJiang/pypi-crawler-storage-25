from __future__ import annotations

from typing import Any

from eta_incerto.analysis.monte_carlo.datastructures import UncertaintyModel


def distribution_aware_sampler(model: UncertaintyModel, rng: Any) -> dict[str, float]:
    """Sample Monte Carlo inputs from an UncertaintyModel.

    MVP behavior:
    - one sampled scalar per uncertainty variable
    - sampled input key is variable.meta["target"] if present, otherwise variable.name
    - supported distributions: normal, gaussian, uniform
    - optional bounds via (min, max) or (low, high) are applied by clipping

    Unsupported distribution types raise NotImplementedError explicitly.
    """
    sampled_inputs: dict[str, float] = {}

    for variable in model.variables:
        value = _sample_distribution(
            dist_type=variable.distribution.dist_type,
            params=variable.distribution.params,
            rng=rng,
        )
        value = _apply_bounds(value, variable.distribution.params)
        target_key = _resolve_target_key(variable)
        sampled_inputs[target_key] = float(value)

    return sampled_inputs


def _resolve_target_key(variable: Any) -> str:
    """Resolve the evaluator-facing sampled input key for a variable."""
    meta = getattr(variable, "meta", {})
    if isinstance(meta, dict):
        target = meta.get("target")
        if isinstance(target, str) and target.strip():
            return target.strip()

    return str(variable.name)


def _sample_distribution(*, dist_type: str, params: dict[str, Any], rng: Any) -> float:
    """Sample a scalar from a supported distribution."""
    normalized = dist_type.strip().lower()

    if normalized in {"normal", "gaussian"}:
        mean = params.get("mean", params.get("mu"))
        std = params.get("std", params.get("sigma"))
        if not isinstance(mean, int | float) or not isinstance(std, int | float):
            raise ValueError("Normal distribution requires numeric 'mean'/'mu' and 'std'/'sigma' parameters.")
        return float(rng.normal(float(mean), float(std)))

    if normalized == "uniform":
        low = params.get("low", params.get("min"))
        high = params.get("high", params.get("max"))
        if not isinstance(low, int | float) or not isinstance(high, int | float):
            raise ValueError("Uniform distribution requires numeric 'low'/'min' and 'high'/'max' parameters.")
        return float(rng.uniform(float(low), float(high)))

    raise NotImplementedError(
        f"Unsupported uncertainty distribution type '{dist_type}'. "
        "Currently supported types are: normal, gaussian, uniform."
    )


def _apply_bounds(value: float, params: dict[str, Any]) -> float:
    """Clip a sampled value to optional bounds declared in params."""
    lower = params.get("min", params.get("low"))
    upper = params.get("max", params.get("high"))

    clipped = float(value)
    if isinstance(lower, int | float):
        clipped = max(clipped, float(lower))
    if isinstance(upper, int | float):
        clipped = min(clipped, float(upper))

    return clipped
