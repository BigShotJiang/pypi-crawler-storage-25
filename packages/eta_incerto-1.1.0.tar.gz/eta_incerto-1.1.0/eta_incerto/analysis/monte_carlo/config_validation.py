from __future__ import annotations

from eta_incerto.config.config_monte_carlo import ConfigStatisticalEvaluation

SUPPORTED_PERTURBATION_KINDS = {
    "sigma_scale",
    "bounds_widen",
    "dist_override",
    "stress_factor",
}

SUPPORTED_MC_BACKENDS = {
    "direct",
    "surrogate",
}


def validate_statistical_evaluation_config(cfg: ConfigStatisticalEvaluation) -> None:
    """Validate cross-field constraints for statistical evaluation config."""
    if not cfg.enabled:
        return

    _validate_required_fields(cfg)
    _validate_perturbation(cfg)
    _validate_seed_config(cfg)
    _validate_backend_config(cfg)
    _validate_parallel_config(cfg)
    _validate_kpi_quantiles(cfg)


def _validate_required_fields(cfg: ConfigStatisticalEvaluation) -> None:
    if not cfg.designs:
        raise ValueError("analysis.monte_carlo.designs must not be empty when enabled is true.")
    if cfg.baseline_uncertainty is None:
        raise ValueError("analysis.monte_carlo.baseline_uncertainty must be set when enabled is true.")
    if cfg.perturbation is None:
        raise ValueError("analysis.monte_carlo.perturbation must be set when enabled is true.")
    if not cfg.kpis:
        raise ValueError("analysis.monte_carlo.kpis must not be empty when enabled is true.")


def _validate_perturbation(cfg: ConfigStatisticalEvaluation) -> None:
    perturbation = cfg.perturbation
    if perturbation is None:
        return

    if not perturbation.levels:
        raise ValueError("analysis.monte_carlo.perturbation.levels must not be empty.")

    kind = perturbation.kind
    if kind not in SUPPORTED_PERTURBATION_KINDS:
        supported_list = ", ".join(sorted(SUPPORTED_PERTURBATION_KINDS))
        raise ValueError(
            "analysis.monte_carlo.perturbation.kind "
            f"'{kind}' is currently declared in the config schema but not implemented "
            f"in the Monte Carlo perturbation engine. Supported kinds are: {supported_list}."
        )


def _validate_seed_config(cfg: ConfigStatisticalEvaluation) -> None:
    mc = cfg.monte_carlo

    if mc.seed_mode == "fixed":
        _validate_seed_mode_fixed(cfg)
        return

    if mc.seed_mode == "random":
        _validate_seed_mode_random(cfg)
        return

    if mc.seed_mode == "multi":
        _validate_seed_mode_multi(cfg)
        return

    raise ValueError(f"Unsupported monte_carlo.seed_mode: {mc.seed_mode!r}")


def _validate_seed_mode_fixed(cfg: ConfigStatisticalEvaluation) -> None:
    mc = cfg.monte_carlo

    if mc.seed is None:
        raise ValueError("monte_carlo.seed must be set when seed_mode='fixed'.")
    if mc.n_runs != 1:
        raise ValueError("monte_carlo.n_runs must be 1 when seed_mode='fixed'.")
    if mc.seeds:
        raise ValueError("monte_carlo.seeds must be empty when seed_mode='fixed'.")


def _validate_seed_mode_random(cfg: ConfigStatisticalEvaluation) -> None:
    mc = cfg.monte_carlo

    if mc.seed is not None:
        raise ValueError("monte_carlo.seed must be None when seed_mode='random'.")


def _validate_seed_mode_multi(cfg: ConfigStatisticalEvaluation) -> None:
    mc = cfg.monte_carlo

    if mc.n_runs < 1:
        raise ValueError("monte_carlo.n_runs must be >= 1 when seed_mode='multi'.")
    if mc.seeds and len(mc.seeds) != mc.n_runs:
        raise ValueError("If monte_carlo.seeds is provided, it must have length n_runs.")


def _validate_backend_config(cfg: ConfigStatisticalEvaluation) -> None:
    backend = cfg.monte_carlo.backend
    if backend not in SUPPORTED_MC_BACKENDS:
        supported_list = ", ".join(sorted(SUPPORTED_MC_BACKENDS))
        raise ValueError(
            f"analysis.monte_carlo.monte_carlo.backend '{backend}' is not supported. "
            f"Supported backends are: {supported_list}."
        )


def _validate_parallel_config(cfg: ConfigStatisticalEvaluation) -> None:
    mc = cfg.monte_carlo
    params = mc.params if isinstance(mc.params, dict) else {}

    parallel = bool(params.get("parallel", False))
    n_workers_raw = params.get("n_workers", 1)

    try:
        n_workers = int(n_workers_raw)
    except (TypeError, ValueError) as exc:
        raise ValueError("monte_carlo.params.n_workers must be an integer.") from exc

    if n_workers < 1:
        raise ValueError("monte_carlo.params.n_workers must be >= 1.")

    if not parallel and n_workers != 1:
        raise ValueError("monte_carlo.params.n_workers must be 1 when monte_carlo.params.parallel is false.")


def _validate_kpi_quantiles(cfg: ConfigStatisticalEvaluation) -> None:
    for kpi in cfg.kpis:
        for q in kpi.quantiles:
            if not (0.0 <= q <= 1.0):
                raise ValueError(f"KPI '{kpi.name}' has invalid quantile {q}. Must be within [0, 1].")
