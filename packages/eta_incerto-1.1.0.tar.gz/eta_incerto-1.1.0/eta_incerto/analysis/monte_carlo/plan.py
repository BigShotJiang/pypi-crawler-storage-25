from __future__ import annotations

from typing import Any

from eta_incerto.analysis.monte_carlo.config_validation import (
    validate_statistical_evaluation_config,
)
from eta_incerto.analysis.monte_carlo.datastructures import (
    BaselineUncertaintyRef,
    DesignRef,
    EvaluationPlan,
    MonteCarloSpec,
    ObjectiveDirection,
    PerturbationKind,
    PerturbationSpec,
    SeedMode,
    SourceType,
    UncertaintyMode,
)
from eta_incerto.config.config import ConfigOptimization
from eta_incerto.config.config_monte_carlo import (
    ConfigBaselineUncertaintyRef,
    ConfigDesignRef,
    ConfigKpi,
    ConfigMonteCarlo,
    ConfigPerturbation,
)


def build_evaluation_plan(config: ConfigOptimization) -> EvaluationPlan:
    """Build an EvaluationPlan from the optimization config.

    This is intentionally pure:
    - no file I/O
    - no path resolution
    - no sampling
    """
    mc_cfg = _require_monte_carlo_config(config)
    validate_statistical_evaluation_config(mc_cfg)

    if not mc_cfg.enabled:
        return EvaluationPlan(
            design_refs=(),
            baseline_uncertainty_ref=BaselineUncertaintyRef(
                source_path="",
                source_type=SourceType.JSON,
                selector=None,
                meta={"disabled": True},
            ),
            perturbation=PerturbationSpec(
                kind=PerturbationKind.SIGMA_SCALE,
                mode=UncertaintyMode.ALEATORY,
                targets=(),
                levels=(),
                knobs={"disabled": True},
            ),
            mc=MonteCarloSpec(n_samples=1, seed_mode=SeedMode.FIXED, seed=0),
            kpis=(),
            meta={
                "enabled": False,
                "config_name": config.config_name,
            },
        )

    design_refs = tuple(_build_design_refs(mc_cfg.designs))
    baseline_ref = _build_baseline_uncertainty_ref(mc_cfg.baseline_uncertainty)
    perturbation = _build_perturbation_spec(mc_cfg.perturbation)
    mc_spec = _build_monte_carlo_spec(mc_cfg.monte_carlo)
    kpis = tuple(_build_kpi_specs(mc_cfg.kpis))

    return EvaluationPlan(
        design_refs=design_refs,
        baseline_uncertainty_ref=baseline_ref,
        perturbation=perturbation,
        mc=mc_spec,
        kpis=kpis,
        meta={
            "enabled": True,
            "config_name": config.config_name,
        },
    )


def _require_monte_carlo_config(config: ConfigOptimization) -> Any:
    """Return the MC config attached to the optimization config.

    For now this is expected as a top-level attribute `config.monte_carlo`.
    This keeps Monte Carlo independent from `config.analysis`.
    """
    mc_cfg = getattr(config, "monte_carlo", None)
    if mc_cfg is None:
        raise ValueError(
            "Monte Carlo configuration is missing on ConfigOptimization. "
            "Attach it as `config.monte_carlo` before calling the Monte Carlo pipeline."
        )
    return mc_cfg


def _build_design_refs(designs: list[ConfigDesignRef]) -> list[DesignRef]:
    """Convert config design references to normalized DesignRef objects."""
    refs: list[DesignRef] = []
    for d in designs:
        refs.append(
            DesignRef(
                source_path=str(d.source_path),
                source_type=_to_source_type(d.source_type),
                selector=d.selector,
                design_id=d.design_id,
                tags=tuple(d.tags),
                meta={
                    **dict(d.meta),
                    "feasibility_policy": d.feasibility_policy,
                },
            )
        )
    return refs


def _build_baseline_uncertainty_ref(
    baseline: ConfigBaselineUncertaintyRef | None,
) -> BaselineUncertaintyRef:
    if baseline is None:
        raise ValueError("baseline_uncertainty must not be None when statistical evaluation is enabled.")

    return BaselineUncertaintyRef(
        source_path=str(baseline.source_path),
        source_type=_to_source_type(baseline.source_type),
        selector=baseline.selector,
        meta=dict(baseline.meta),
    )


def _build_perturbation_spec(perturbation: ConfigPerturbation | None) -> PerturbationSpec:
    if perturbation is None:
        raise ValueError("perturbation must not be None when statistical evaluation is enabled.")

    return PerturbationSpec(
        kind=_to_perturbation_kind(perturbation.kind),
        mode=_to_uncertainty_mode(perturbation.mode),
        targets=tuple(perturbation.targets),
        levels=tuple(perturbation.levels),
        knobs=dict(perturbation.knobs),
    )


def _build_monte_carlo_spec(mc: ConfigMonteCarlo) -> MonteCarloSpec:
    return MonteCarloSpec(
        n_samples=mc.n_samples,
        seed_mode=_to_seed_mode(mc.seed_mode),
        seed=mc.seed,
        n_runs=mc.n_runs,
        seeds=tuple(mc.seeds),
        use_crn=mc.use_crn,
        params=dict(mc.params),
    )


def _build_kpi_specs(kpis: list[ConfigKpi]) -> list[Any]:
    from eta_incerto.analysis.monte_carlo.datastructures import KpiSpec

    specs: list[KpiSpec] = []
    for k in kpis:
        specs.append(
            KpiSpec(
                name=k.name,
                direction=_to_objective_direction(k.direction),
                thresholds=dict(k.thresholds),
                risk_metrics=tuple(k.risk_metrics),
                quantiles=tuple(k.quantiles),
            )
        )
    return specs


def _to_source_type(value: str) -> SourceType:
    return SourceType(value)


def _to_uncertainty_mode(value: str) -> UncertaintyMode:
    return UncertaintyMode(value)


def _to_seed_mode(value: str) -> SeedMode:
    return SeedMode(value)


def _to_objective_direction(value: str | None) -> ObjectiveDirection | None:
    if value is None:
        return None
    return ObjectiveDirection(value)


def _to_perturbation_kind(value: str) -> PerturbationKind:
    return PerturbationKind(value)
