from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from eta_incerto.analysis.monte_carlo.datastructures import (
    DistributionSpec,
    UncertaintyModel,
    UncertaintyVariable,
)


@dataclass(frozen=True, slots=True)
class ReferenceSampler:
    """Canonical sampler for Monte Carlo uncertainty models.

    The sampler draws one scalar value per uncertainty variable and returns a
    mapping that is directly consumable by the evaluator, i.e. typically
    target keys such as ``carriers.electricity.unit_price.scale``.

    Supported distributions:
    - normal
    - lognormal
    - uniform
    - triangular
    - fixed / deterministic / delta

    Notes
    -----
    - Sampling order is deterministic (sorted by output key, then variable name)
      so equal seeds produce equal samples.
    - Correlation specs are currently not applied; variables are sampled
      independently.
    """

    def __call__(
        self,
        model: UncertaintyModel,
        rng: np.random.Generator,
    ) -> dict[str, float]:
        return self.sample(model=model, rng=rng)

    def sample(
        self,
        *,
        model: UncertaintyModel,
        rng: np.random.Generator,
    ) -> dict[str, float]:
        sampled: dict[str, float] = {}

        for variable in self._ordered_variables(model):
            out_key = self._output_key(variable)
            sampled[out_key] = self._sample_variable(variable, rng)

        return sampled

    def _ordered_variables(self, model: UncertaintyModel) -> list[UncertaintyVariable]:
        return sorted(
            model.variables,
            key=lambda var: (self._output_key(var), var.name),
        )

    def _output_key(self, variable: UncertaintyVariable) -> str:
        target = variable.meta.get("target")
        if isinstance(target, str) and target:
            return target
        return variable.name

    def _sample_variable(
        self,
        variable: UncertaintyVariable,
        rng: np.random.Generator,
    ) -> float:
        dist = variable.distribution
        dist_type = str(dist.dist_type).strip().lower()

        if dist_type == "normal":
            return self._sample_normal(variable, dist, rng)

        if dist_type == "lognormal":
            return self._sample_lognormal(variable, dist, rng)

        if dist_type == "uniform":
            return self._sample_uniform(variable, dist, rng)

        if dist_type == "triangular":
            return self._sample_triangular(variable, dist, rng)

        if dist_type in {"fixed", "deterministic", "delta"}:
            return self._sample_fixed(variable, dist)

        raise NotImplementedError(
            f"Unsupported distribution '{dist.dist_type}' for uncertainty variable '{variable.name}'."
        )

    def _sample_normal(
        self,
        variable: UncertaintyVariable,
        dist: DistributionSpec,
        rng: np.random.Generator,
    ) -> float:
        mean = self._get_required_numeric_param(dist, variable, ("mean", "mu", "loc"))
        std = self._get_required_numeric_param(dist, variable, ("std", "sigma", "scale"))

        if std < 0.0:
            raise ValueError(
                f"Normal distribution for variable '{variable.name}' requires non-negative std, got {std}."
            )

        return float(rng.normal(loc=mean, scale=std))

    def _sample_lognormal(
        self,
        variable: UncertaintyVariable,
        dist: DistributionSpec,
        rng: np.random.Generator,
    ) -> float:
        mean = self._get_required_numeric_param(dist, variable, ("mean", "mu"))
        sigma = self._get_required_numeric_param(dist, variable, ("sigma", "std", "scale"))

        if sigma < 0.0:
            raise ValueError(
                f"Lognormal distribution for variable '{variable.name}' requires non-negative sigma, got {sigma}."
            )

        return float(rng.lognormal(mean=mean, sigma=sigma))

    def _sample_uniform(
        self,
        variable: UncertaintyVariable,
        dist: DistributionSpec,
        rng: np.random.Generator,
    ) -> float:
        low, high = self._get_bounds(dist, variable)

        if high < low:
            raise ValueError(
                f"Uniform distribution for variable '{variable.name}' requires high >= low, got {low}, {high}."
            )

        return float(rng.uniform(low, high))

    def _sample_triangular(
        self,
        variable: UncertaintyVariable,
        dist: DistributionSpec,
        rng: np.random.Generator,
    ) -> float:
        low, high = self._get_bounds(dist, variable)
        mode = self._get_required_numeric_param(dist, variable, ("mode", "c", "peak"))

        if high < low:
            raise ValueError(
                f"Triangular distribution for variable '{variable.name}' requires high >= low, got {low}, {high}."
            )
        if not (low <= mode <= high):
            raise ValueError(
                f"Triangular distribution for variable '{variable.name}' requires low <= mode <= high, "
                f"got low={low}, mode={mode}, high={high}."
            )

        return float(rng.triangular(left=low, mode=mode, right=high))

    def _sample_fixed(
        self,
        variable: UncertaintyVariable,
        dist: DistributionSpec,
    ) -> float:
        return self._get_required_numeric_param(dist, variable, ("value", "mean", "mu", "loc"))

    def _get_bounds(
        self,
        dist: DistributionSpec,
        variable: UncertaintyVariable,
    ) -> tuple[float, float]:
        params = dist.params

        if "low" in params or "high" in params:
            low = self._get_required_numeric_param(dist, variable, ("low",))
            high = self._get_required_numeric_param(dist, variable, ("high",))
            return low, high

        if "min" in params or "max" in params:
            low = self._get_required_numeric_param(dist, variable, ("min",))
            high = self._get_required_numeric_param(dist, variable, ("max",))
            return low, high

        raise ValueError(
            f"Distribution '{dist.dist_type}' for variable '{variable.name}' requires bounds "
            "('low'/'high' or 'min'/'max')."
        )

    def _get_required_numeric_param(
        self,
        dist: DistributionSpec,
        variable: UncertaintyVariable,
        names: tuple[str, ...],
    ) -> float:
        for name in names:
            if name not in dist.params:
                continue

            raw = dist.params[name]
            try:
                value = float(raw)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Distribution parameter '{name}' for variable '{variable.name}' must be numeric, got {raw!r}."
                ) from exc

            if math.isnan(value) or math.isinf(value):
                raise ValueError(
                    f"Distribution parameter '{name}' for variable '{variable.name}' must be finite, got {value}."
                )

            return value

        expected = ", ".join(names)
        raise ValueError(
            f"Distribution '{dist.dist_type}' for variable '{variable.name}' is missing required parameter(s): "
            f"{expected}."
        )
