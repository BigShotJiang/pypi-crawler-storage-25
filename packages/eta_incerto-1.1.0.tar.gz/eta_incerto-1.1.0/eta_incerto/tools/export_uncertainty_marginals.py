"""Plot input (marginal) uncertainty PDF/CDF curves from ``config.json`` ``uncertainty`` only.

No antifragile HDF5 or optimization run is required: the same Chaospy path as
:func:`eta_incerto.uncertainty.pipeline.build_uncertainty_joint_distribution` is used.

Example::

  poetry run eta-incerto-export-uncertainty-marginals --config path/to/config.json -o marginals.pdf

  poetry run eta-incerto-export-uncertainty-marginals --run-dir path/to/run
  # -> path/to/run/plots/marginals_from_config.pdf

  poetry run eta-incerto-export-uncertainty-marginals --run-dir path/to/run -o path/to/run/plots/custom.pdf
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pydantic import ValidationError

from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig
from eta_incerto.plotting.config_uncertainty_marginals import figure_from_parameter_configs


def _load_uncertainty_list(cfg: dict[str, Any], variant: str) -> list[dict[str, Any]]:
    raw = cfg.get("uncertainty")
    if raw is None:
        raise ValueError("config has no 'uncertainty' section")
    if isinstance(raw, dict):
        if variant not in raw:
            raise ValueError(f"uncertainty has no key {variant!r} (available: {sorted(raw)!r})")
        entries = raw[variant]
    else:
        entries = raw
    if not isinstance(entries, list) or not entries:
        raise ValueError("uncertainty entries must be a non-empty list")
    return entries


def plot_uncertainty_marginals_from_config(
    cfg: dict[str, Any],
    *,
    variant: str,
    n_grid: int,
) -> matplotlib.figure.Figure:
    entries = _load_uncertainty_list(cfg, variant)
    configs = [ParameterUncertaintyConfig.model_validate(e) for e in entries]
    return figure_from_parameter_configs(configs, n_grid=n_grid, style=None)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Plot marginal PDF/CDF from config uncertainty (no HDF5 required).",
    )
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--config",
        type=Path,
        help="Path to config.json",
    )
    src.add_argument(
        "--run-dir",
        type=Path,
        help="Run directory containing config.json",
    )
    parser.add_argument(
        "--variant",
        default="variant_one",
        help="Variant key when uncertainty is a dict (default: variant_one)",
    )
    parser.add_argument(
        "--n-grid",
        type=int,
        default=256,
        help="Inverse-CDF grid resolution (default: 256)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help=(
            "Output PDF path. With --run-dir only, default is <run_dir>/plots/marginals_from_config.pdf; "
            "with --config only, default is ./uncertainty_marginals.pdf in the current working directory."
        ),
    )
    args = parser.parse_args()

    if args.config is not None:
        cfg_path = args.config.resolve()
        run_root: Path | None = None
    else:
        run_root = args.run_dir.resolve()
        cfg_path = (run_root / "config.json").resolve()

    if not cfg_path.is_file():
        sys.stderr.write(f"config not found: {cfg_path}\n")
        return 1

    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))

    try:
        fig = plot_uncertainty_marginals_from_config(
            cfg,
            variant=args.variant,
            n_grid=max(8, int(args.n_grid)),
        )
    except (ValueError, ValidationError) as exc:
        sys.stderr.write(f"{type(exc).__name__}: {exc}\n")
        return 1

    if args.output is not None:
        out = args.output.resolve()
    elif run_root is not None:
        out = (run_root / "plots" / "marginals_from_config.pdf").resolve()
    else:
        out = (Path.cwd() / "uncertainty_marginals.pdf").resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    sys.stdout.write(f"{out}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
