"""
Compute an Irreducible Infeasible Subsystem (IIS) from an exported .lp file and write it to .ilp.

Use this to debug infeasible optimization problems: the .ilp file contains a minimal set of
constraints and variable bounds that are still infeasible.

Usage:
  python -m eta_incerto.tools.compute_iis <lp_file> [-o output.ilp] [--no-optimize]
  eta-incerto-iis <lp_file> [-o output.ilp] [--no-optimize]

Example (after a run that exported two_stage.lp):
  python -m eta_incerto.tools.compute_iis path/to/two_stage.lp -o two_stage.ilp
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def _infeasible_status(status: int) -> bool:
    """True if model status indicates infeasibility (or infeasible-or-unbounded)."""
    return status in (GRB.INF_OR_UNBD, GRB.INFEASIBLE)


def compute_iis(
    lp_path: Path,
    ilp_path: Path,
    *,
    run_optimize: bool = True,
) -> None:
    """
    Load model from lp_path, optionally confirm infeasibility via optimize(), compute IIS, write to ilp_path.

    Raises:
        FileNotFoundError: if lp_path does not exist.
        ValueError: if run_optimize is True and the model is not infeasible.
        gurobipy.GurobiError: on solver/license or IIS errors.
    """
    lp_path = lp_path.resolve()
    if not lp_path.is_file():
        raise FileNotFoundError(f"LP file not found: {lp_path}")

    model = gp.read(str(lp_path))
    try:
        if run_optimize:
            model.optimize()
            status = model.Status
            if not _infeasible_status(status):
                raise ValueError(
                    f"Model is not infeasible (status={status}). "
                    "IIS can only be computed for infeasible models. Use --no-optimize to skip this check.",
                )

        model.computeIIS()
        model.write(str(ilp_path))

        # Optional summary: IIS size
        n_iis_constr = sum(1 for c in model.getConstrs() if c.IISConstr) if hasattr(model, "getConstrs") else None
        if n_iis_constr is not None:
            n_iis_lb = sum(1 for v in model.getVars() if v.IISLB)
            n_iis_ub = sum(1 for v in model.getVars() if v.IISUB)
            minimal = getattr(model, "IISMinimal", None)
            minimal_note = " (minimal)" if minimal == 1 else " (not minimal)" if minimal == 0 else ""
            sys.stdout.write(
                f"IIS: {n_iis_constr} constraints, {n_iis_lb} lower bounds, {n_iis_ub} upper bounds{minimal_note}\n"
            )
        sys.stdout.write(f"Wrote: {ilp_path}\n")
    finally:
        model.dispose()


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Compute an Irreducible Infeasible Subsystem (IIS) from an .lp file and write it to .ilp for debugging."
        ),
    )
    parser.add_argument(
        "lp_file",
        type=Path,
        help="Path to the .lp file (e.g. exported two_stage.lp from a failed run)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Path for the .ilp file (default: same directory as lp_file, same stem with .ilp extension)",
    )
    parser.add_argument(
        "--no-optimize",
        action="store_true",
        help="Skip calling optimize() before computeIIS(); use when the model is already known to be infeasible",
    )
    args = parser.parse_args()

    lp_path = args.lp_file.resolve()
    if not lp_path.exists():
        sys.stderr.write(f"Error: LP file not found: {lp_path}\n")
        sys.exit(1)
    if not lp_path.is_file():
        sys.stderr.write(f"Error: Not a file: {lp_path}\n")
        sys.exit(1)

    ilp_path = lp_path.with_suffix(".ilp") if args.output is None else args.output.resolve()

    try:
        compute_iis(lp_path, ilp_path, run_optimize=not args.no_optimize)
    except (FileNotFoundError, ValueError) as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)
    except gp.GurobiError as e:
        sys.stderr.write(f"Gurobi error: {e}\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
