"""
Unified runtime analysis orchestrator for ETA-Incerto optimization approaches.

Runs conventional and antifragile optimization plus all profiling tools (debug minimal,
line profile, pyinstrument, job resource profile) from a single CLI call. Config files
are read from the run folder using a fixed naming convention—see the config table below.

Config naming convention (all configs live inside the run folder):

| Step              | Config base name       | Purpose                                        |
| ----------------- | ---------------------- | ---------------------------------------------- |
| Conventional      | config                 | Stochastic / regret / robust optimization       |
| Antifragile debug | config_debug_minimal   | Smoke / minimal antifragile run                |
| Line profile      | config_line_profile    | Line-by-line profiling                         |
| Pyinstrument      | config_pyinstrument    | Call-stack profiling                           |
| Job profile       | config_job_profile     | Resource / HPC sizing                          |

Extensions .json, .toml, .yaml are resolved automatically. If a step's config is
missing, that step is skipped and recorded in the manifest.

Usage (from eta-incerto root):
  eta-incerto-runtime-analysis runs/2026-03-06_1344_8f8584
  eta-incerto-runtime-analysis --run-dir path/to/run
  set RUN_DIR=runs\\2026-03-06_1344_8f8584 && eta-incerto-runtime-analysis
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from eta_incerto.util.data_paths import get_run_dir_from_env

log = logging.getLogger(__name__)

# Step id -> config base name (no extension). Order defines execution order.
STEP_CONFIG_BASE_NAMES: dict[str, str] = {
    "conventional": "config",
    "antifragile_debug": "config_debug_minimal",
    "line_profile": "config_line_profile",
    "pyinstrument": "config_pyinstrument",
    "job_profile": "config_job_profile",
}

CONFIG_EXTENSIONS = (".json", ".toml", ".yaml", ".yml")


def _find_config_in_run_dir(run_dir: Path, base_name: str) -> Path | None:
    """Resolve config file in run_dir by base name; try .json, .toml, .yaml, .yml."""
    run_dir = run_dir.resolve()
    if not run_dir.is_dir():
        return None
    # bare name (no ext)
    candidate = run_dir / base_name
    if candidate.exists() and candidate.is_file():
        return candidate
    for ext in CONFIG_EXTENSIONS:
        p = run_dir / f"{base_name}{ext}"
        if p.exists():
            return p
    return None


def _resolve_run_dir(args: argparse.Namespace) -> Path:
    """Run directory: --run-dir, positional, or RUN_DIR / DATA_REPO_PATH+RUN_ID."""
    if getattr(args, "run_dir_opt", None):
        return Path(args.run_dir_opt).expanduser().resolve()
    if getattr(args, "run_dir", None):
        return Path(args.run_dir).expanduser().resolve()
    run_dir = get_run_dir_from_env()
    if run_dir is not None:
        return run_dir
    raise RuntimeError(
        "Run directory is required. Pass the run folder as the first argument, "
        "e.g. eta-incerto-runtime-analysis runs/2026-03-06_1344_8f8584, "
        "or set --run-dir, or set RUN_DIR (or DATA_REPO_PATH and RUN_ID)."
    )


def _get_eta_incerto_root() -> Path:
    """Root of eta-incerto (project root)."""
    return Path(__file__).resolve().parents[2]


@dataclass
class StepResult:
    """Result of one pipeline step."""

    step_id: str
    config_base: str
    config_path: Path | None
    skipped: bool
    skip_reason: str | None = None
    return_code: int | None = None
    elapsed_seconds: float | None = None
    command: list[str] | None = None
    artifact_paths: list[str] = field(default_factory=list)
    error_message: str | None = None


def _run_step(
    step_id: str,
    config_base: str,
    config_path: Path | None,
    run_dir: Path,
    env: dict[str, str],
    dry_run: bool,
) -> StepResult:
    """Run a single step via subprocess. Returns result; does not raise."""
    if config_path is None:
        return StepResult(
            step_id=step_id,
            config_base=config_base,
            config_path=None,
            skipped=True,
            skip_reason="config not found",
        )
    root = _get_eta_incerto_root()
    run_dir_str = str(run_dir.resolve())
    env_run = {**os.environ, **env, "RUN_DIR": run_dir_str}
    artifact_paths: list[str] = []

    if step_id == "conventional":
        cmd = [
            sys.executable,
            "-m",
            "examples.conventional.main",
            "--run-dir",
            run_dir_str,
            "--config",
            config_base,
        ]
        cwd = root
    elif step_id == "antifragile_debug":
        cmd = [
            sys.executable,
            "-m",
            "examples.antifragile.main",
            "--run-dir",
            run_dir_str,
            "--config",
            config_base,
        ]
        cwd = root
    elif step_id == "line_profile":
        # Profile tools use --config path; they take parent of config as root. Run with cwd=run_dir.
        config_arg = config_path.name
        cmd = [
            sys.executable,
            "-m",
            "eta_incerto.tools.line_profile",
            "--config",
            config_arg,
        ]
        cwd = run_dir
    elif step_id == "pyinstrument":
        config_arg = config_path.name
        cmd = [
            sys.executable,
            "-m",
            "eta_incerto.tools.pyinstrument_profile",
            "--config",
            config_arg,
        ]
        cwd = run_dir
    elif step_id == "job_profile":
        config_arg = config_path.name
        cmd = [
            sys.executable,
            "-m",
            "eta_incerto.tools.job_resource_profile",
            "--config",
            config_arg,
        ]
        cwd = run_dir
    else:
        return StepResult(
            step_id=step_id,
            config_base=config_base,
            config_path=config_path,
            skipped=True,
            skip_reason="unknown step",
        )

    if dry_run:
        log.info("[dry-run] %s: %s", step_id, " ".join(cmd))
        return StepResult(
            step_id=step_id,
            config_base=config_base,
            config_path=config_path,
            skipped=False,
            command=cmd,
        )

    t0 = time.perf_counter()
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            env=env_run,
            capture_output=True,
            text=True,
            timeout=None,
            check=False,
        )
        elapsed = time.perf_counter() - t0
        err_msg = result.stderr.strip()[:500] if result.returncode != 0 and result.stderr else None
        return StepResult(
            step_id=step_id,
            config_base=config_base,
            config_path=config_path,
            skipped=False,
            return_code=result.returncode,
            elapsed_seconds=round(elapsed, 2),
            command=cmd,
            artifact_paths=artifact_paths,
            error_message=err_msg,
        )
    except Exception as e:
        elapsed = time.perf_counter() - t0
        return StepResult(
            step_id=step_id,
            config_base=config_base,
            config_path=config_path,
            skipped=False,
            return_code=-1,
            elapsed_seconds=round(elapsed, 2),
            command=cmd,
            error_message=str(e),
        )


def _step_result_to_dict(r: StepResult) -> dict:
    d: dict = {
        "step_id": r.step_id,
        "config_base": r.config_base,
        "skipped": r.skipped,
    }
    if r.config_path is not None:
        d["config_path"] = str(r.config_path)
    if r.skip_reason is not None:
        d["skip_reason"] = r.skip_reason
    if r.return_code is not None:
        d["return_code"] = r.return_code
    if r.elapsed_seconds is not None:
        d["elapsed_seconds"] = r.elapsed_seconds
    if r.command is not None:
        d["command"] = r.command
    if r.artifact_paths:
        d["artifact_paths"] = r.artifact_paths
    if r.error_message is not None:
        d["error_message"] = r.error_message
    return d


def _write_manifest(run_dir: Path, results: list[StepResult], started_at: datetime) -> Path:
    """Write results/analysis/runtime_analysis_manifest.json and return its path."""
    analysis_dir = run_dir / "results" / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = analysis_dir / "runtime_analysis_manifest.json"
    manifest = {
        "run_dir": str(run_dir.resolve()),
        "started_at": started_at.isoformat(),
        "steps": [_step_result_to_dict(r) for r in results],
        "config_naming_convention": {
            "description": (
                "Config files live in the run folder. Base names (extensions .json/.toml/.yaml resolved automatically)."
            ),
            "steps": STEP_CONFIG_BASE_NAMES,
        },
    }
    with manifest_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    return manifest_path


def _write_summary(run_dir: Path, results: list[StepResult], manifest_path: Path) -> Path:
    """Write results/analysis/runtime_analysis_summary.txt."""
    analysis_dir = run_dir / "results" / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    summary_path = analysis_dir / "runtime_analysis_summary.txt"
    lines = [
        "Runtime analysis summary",
        "=======================",
        f"Run dir: {run_dir.resolve()}",
        f"Manifest: {manifest_path}",
        "",
    ]
    for r in results:
        if r.skipped:
            lines.append(f"  {r.step_id}: skipped ({r.skip_reason})")
        else:
            rc = r.return_code if r.return_code is not None else "?"
            elapsed = r.elapsed_seconds if r.elapsed_seconds is not None else "?"
            lines.append(f"  {r.step_id}: return_code={rc}, elapsed_s={elapsed}")
            if r.error_message:
                lines.append(f"    error: {r.error_message[:200]}")
    with summary_path.open("w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return summary_path


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run full runtime analysis (conventional + antifragile + all profilers) from a run folder.",
        epilog="Config files are read from the run folder by name. See module docstring for the naming convention.",
    )
    parser.add_argument(
        "run_dir",
        nargs="?",
        default=None,
        help="Path to run directory (data label). Optional if RUN_DIR or DATA_REPO_PATH+RUN_ID is set.",
    )
    parser.add_argument(
        "--run-dir",
        dest="run_dir_opt",
        default=None,
        help="Path to run directory (overrides positional).",
    )
    parser.add_argument(
        "--skip",
        action="append",
        default=[],
        metavar="STEP",
        help=(
            "Skip step(s). STEP: conventional, antifragile_debug, line_profile, pyinstrument, job_profile. Repeatable."
        ),
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Do not stop on first step failure.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print commands only, do not execute.",
    )
    return parser.parse_args()


def main() -> int:
    """Entry point for eta-incerto-runtime-analysis."""
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _parse_args()
    run_dir = _resolve_run_dir(args)
    if not run_dir.is_dir():
        log.error("Run directory does not exist or is not a directory: %s", run_dir)
        return 1

    skip_set = set(args.skip or [])
    continue_on_error = getattr(args, "continue_on_error", False)
    dry_run = getattr(args, "dry_run", False)

    started_at = datetime.now(tz=UTC)
    results: list[StepResult] = []
    first_failure_code: int | None = None

    for step_id, config_base in STEP_CONFIG_BASE_NAMES.items():
        if step_id in skip_set:
            results.append(
                StepResult(
                    step_id=step_id,
                    config_base=config_base,
                    config_path=None,
                    skipped=True,
                    skip_reason="--skip",
                )
            )
            log.info("Skipping step (--skip): %s", step_id)
            continue

        config_path = _find_config_in_run_dir(run_dir, config_base)
        if config_path is None:
            results.append(
                StepResult(
                    step_id=step_id,
                    config_base=config_base,
                    config_path=None,
                    skipped=True,
                    skip_reason="config not found",
                )
            )
            log.info("Skipping step (config not found): %s (base %s)", step_id, config_base)
            continue

        log.info("Running step: %s (config %s)", step_id, config_path.name)
        env = {"RUN_DIR": str(run_dir.resolve())}
        result = _run_step(step_id, config_base, config_path, run_dir, env, dry_run)
        results.append(result)

        if not result.skipped and result.return_code is not None and result.return_code != 0:
            if first_failure_code is None:
                first_failure_code = result.return_code
            log.warning("Step %s failed with return code %s", step_id, result.return_code)
            if result.error_message:
                log.warning("Error: %s", result.error_message[:300])
            if not continue_on_error:
                log.error("Stopping (use --continue-on-error to run remaining steps).")
                break

    manifest_path = _write_manifest(run_dir, results, started_at)
    summary_path = _write_summary(run_dir, results, manifest_path)
    log.info("Manifest: %s", manifest_path)
    log.info("Summary: %s", summary_path)

    if first_failure_code is not None:
        return first_failure_code
    return 0


if __name__ == "__main__":
    sys.exit(main())
