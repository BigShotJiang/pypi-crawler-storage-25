"""Universal optimization entrypoint for local, VM, and HPC runs.

This module is intended to be called directly, including from batch schedulers
(e.g., Slurm), via:

    python -m eta_incerto.tools.run_optimization --config ... --root-path ...

Typical usage:
    python -m eta_incerto.tools.run_optimization \
      --config config \
      --root-path /path/to/run_root \
      --results-dir /path/to/results \
      --mode stochastic \
      --force-python-workers \
      --force-solver-threads

Core CLI contract:
- --config (required):
  Config file path or basename. If basename is provided (e.g. "config"),
  supported extensions are resolved automatically (.json/.toml/.yaml/.yml).
- --root-path (required):
  Run root directory containing config-relative resources and variant folders.
- --results-dir (optional):
  Highest-priority output override. If provided, it is exported as ETA_RESULTS_DIR
  (effective precedence for results_dir: config < env < CLI).
- --mode (optional):
  Explicit execution mode. Defaults to "conventional".
- --force-python-workers (optional):
  Trigger strict internal policy. If this flag or --force-solver-threads is provided,
  internal Python workers are forced to 1.
- --force-solver-threads (optional):
  Trigger strict internal policy. If this flag or --force-python-workers is provided, solver threads
  are forced to 1 via pyomo.solver_settings.options["threads"] and numeric runtime
  env vars (OMP/MKL/OPENBLAS/NUMEXPR/VECLIB/NUMBA/BLIS/GOTO/TBB).

Variant handling:
- Source of truth is config.system.variant.
- For each configured variant, modules are auto-imported by mode family:
  - conventional|stochastic|robust|regret -> examples.conventional.variants.<variant>.system
  - deterministic -> examples.deterministic_operation.variants.<variant>.system
  - antifragile|pymoo -> examples.antifragile.variants.<variant>.system
- Entry-point validates:
  - variant layout under --root-path (required: <variant>/static_data)
  - successful registry presence via get_system(<variant>)

Exit-code behavior (scheduler-friendly):
- 0: successful completion
- 130: interrupted (KeyboardInterrupt)
- 1: failure
"""

from __future__ import annotations

import argparse
import importlib
import logging
import os
import sys
from collections.abc import Callable, Iterable
from pathlib import Path

from eta_incerto.core import EtaIncerto
from eta_incerto.registry import get_system

log = logging.getLogger(__name__)

# Config extensions supported by the resolver when --config is passed without suffix.
_EXTS = (".json", ".toml", ".yaml", ".yml")


def _parse_args() -> argparse.Namespace:
    """Define and parse CLI arguments for the run entrypoint.

    Notes:
    - --config and --root-path are required.
    - --results-dir overrides output location with highest priority via ETA_RESULTS_DIR.
    - --mode is explicit and defaults to "conventional".
    - If any --force-* argument is provided, strict internal policy is enabled and
      internal Python workers and solver threads are both forced to 1.
    - If both --force-* arguments are omitted, config-defined parallel settings are preserved.
    """
    parser = argparse.ArgumentParser(description="Run ETA Incerto optimization from a single module entrypoint.")
    parser.add_argument(
        "--config",
        required=True,
        help="Config path (absolute or relative to --root-path).",
    )
    parser.add_argument(
        "--root-path",
        required=True,
        help="Base path used to resolve relative paths in config.",
    )
    parser.add_argument(
        "--results-dir",
        default=None,
        help="Override paths.results_dir (highest priority).",
    )
    parser.add_argument(
        "--mode",
        choices=["conventional", "antifragile", "stochastic", "robust", "regret", "pymoo", "deterministic"],
        default="conventional",
        help="Execution mode (default: conventional).",
    )
    parser.add_argument(
        "--force-python-workers",
        action="store_true",
        help="Enable strict internal policy (internal workers forced to 1).",
    )
    parser.add_argument(
        "--force-solver-threads",
        action="store_true",
        help="Enable strict internal policy (solver threads forced to 1).",
    )
    return parser.parse_args()


def _resolve_config_path(config_arg: str, root_path: Path) -> Path:
    """Resolve --config to an existing file path.

    Behavior:
    - Absolute config paths are used directly.
    - Relative config paths are interpreted relative to --root-path.
    - If --config has no extension, try supported extensions in _EXTS.
    """
    raw = Path(config_arg).expanduser()
    candidate = raw if raw.is_absolute() else (root_path / raw)

    if candidate.exists():
        return candidate.resolve()

    if candidate.suffix:
        raise FileNotFoundError(f"Config file not found: {candidate}")

    for ext in _EXTS:
        with_ext = candidate.with_suffix(ext)
        if with_ext.exists():
            return with_ext.resolve()

    raise FileNotFoundError(f"Config file not found: {candidate}")


def _force_parallel_policy(exp: EtaIncerto, args: argparse.Namespace) -> None:
    """
    Conditional anti-oversubscription policy:
    - If any --force-* argument is provided, force internal workers/threads to 1.
    - If both --force-* are omitted, keep config-defined parallel settings.
    """
    force_requested = bool(args.force_python_workers or args.force_solver_threads)
    if not force_requested:
        return

    py_workers = 1
    solver_threads = 1

    # Align numeric runtimes with the same solver thread limit.
    for env_name in (
        "OMP_NUM_THREADS",
        "OMP_THREAD_LIMIT",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "BLIS_NUM_THREADS",
        "GOTO_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMBA_NUM_THREADS",
        "TBB_NUM_THREADS",
    ):
        os.environ[env_name] = str(solver_threads)

    # Solver threads
    settings = exp.config.pyomo.solver_settings
    if getattr(settings, "options", None) is None or not isinstance(settings.options, dict):
        settings.options = {}
    settings.options["threads"] = solver_threads

    # Python workers in evaluate.* (all variants)
    eval_root = getattr(exp.config.evaluate, "root", {})
    for _variant, eval_cfg in eval_root.items():
        eval_cfg.n_workers = py_workers
        eval_cfg.n_jobs = py_workers
        eval_cfg.backend = "loky"


def _run_conventional(exp: EtaIncerto) -> None:
    """Run conventional pipeline: stochastic + regret + robust."""
    exp.stochastic_optimization()
    exp.regret_optimization()
    exp.robust_optimization()


def _collect_variants(exp: EtaIncerto, mode: str) -> list[str]:
    variants = list(exp.config.system.variant or [])
    if not variants:
        raise ValueError(
            f"Mode '{mode}': no variants configured. "
            "Fix: set config.system.variant to a non-empty list (e.g. ['variant_one'])."
        )
    return variants


def _variant_family_for_mode(mode: str) -> str:
    if mode in {"conventional", "stochastic", "robust", "regret"}:
        return "examples.conventional"
    if mode == "deterministic":
        return "examples.deterministic_operation"
    if mode in {"antifragile", "pymoo"}:
        return "examples.antifragile"
    raise ValueError(
        f"Mode '{mode}': unsupported variant family resolution. "
        "Fix: use one of [conventional, antifragile, stochastic, robust, regret, pymoo, deterministic]."
    )


def _required_variant_subdirs_for_mode(mode: str) -> tuple[str, ...]:
    if mode in {"conventional", "antifragile", "stochastic", "robust", "regret", "pymoo", "deterministic"}:
        return ("static_data",)

    raise ValueError(
        f"Mode '{mode}': unsupported variant layout validation mode. "
        "Fix: use one of [conventional, antifragile, stochastic, robust, regret, pymoo, deterministic]."
    )


def _validate_variants(variants: list[str], root_path: Path, mode: str) -> None:
    # 1) Run layout (filesystem)
    required_subdirs = _required_variant_subdirs_for_mode(mode)
    missing_layout: list[str] = []
    for variant in variants:
        variant_root = root_path / variant
        if not variant_root.is_dir():
            missing_layout.append(f"{variant} (missing directory: {variant_root})")
            continue
        for subdir in required_subdirs:
            p = variant_root / subdir
            if not p.is_dir():
                missing_layout.append(f"{variant} (missing directory: {p})")

    if missing_layout:
        raise ValueError(
            f"Mode '{mode}': invalid run variant layout. Missing entries: {missing_layout}. "
            "Fix: ensure each variant folder exists under --root-path with required subdirectories."
        )

    # 2) Registry check (post-import)
    missing_registered: list[str] = []
    for variant in variants:
        try:
            get_system(variant)
        except ValueError:
            missing_registered.append(variant)

    if missing_registered:
        raise ValueError(
            f"Mode '{mode}': variant module imported but system not registered for {missing_registered}. "
            "Fix: verify each module defines @register_system('<variant>', ...) and executes at import time."
        )


def _auto_import_variant_modules(variants: Iterable[str], mode: str) -> None:
    family = _variant_family_for_mode(mode)
    failed: list[str] = []

    for variant in variants:
        module_name = f"{family}.variants.{variant}.system"
        try:
            importlib.import_module(module_name)
            log.info("Imported variant module: %s", module_name)
        except Exception:
            failed.append(module_name)

    if failed:
        raise ValueError(
            f"Mode '{mode}': failed to import variant module(s): {failed}. "
            "Fix: ensure these modules exist and are importable."
        )


def _prepare_variants(exp: EtaIncerto, root_path: Path, mode: str) -> list[str]:
    """Prepare configured variants for execution.

    Sequence:
    1) Read configured variants from config.system.variant
    2) Auto-import mode-family variant modules
    3) Validate run layout and registry availability

    :return: Effective variant names to execute.
    """
    variants = _collect_variants(exp, mode)
    _auto_import_variant_modules(variants, mode)
    _validate_variants(variants, root_path, mode)
    return variants


def _validate_series_scenario(exp: EtaIncerto, mode: str) -> None:
    if not exp.config.series.series_file:
        raise ValueError(
            f"Mode '{mode}': missing series definitions. Fix: add at least one entry under config.series.series_file."
        )
    if not exp.config.scenario.scenario_file:
        raise ValueError(
            f"Mode '{mode}': missing scenario definitions. "
            "Fix: add at least one entry under config.scenario.scenario_file."
        )


def _validate_pymoo_defs(exp: EtaIncerto, variants: list[str], mode: str) -> None:
    missing_pymoo: list[str] = []
    for variant in variants:
        try:
            exp.config.pymoo.for_variant(variant)
        except KeyError:
            missing_pymoo.append(variant)

    if missing_pymoo:
        raise ValueError(
            f"Mode '{mode}': missing pymoo problem definitions for variant(s) {missing_pymoo}. "
            "Fix: add entries under config.pymoo.problems.<variant> for each listed variant."
        )


def _validate_common_scenario_mode_prerequisites(exp: EtaIncerto, mode: str) -> None:
    _validate_series_scenario(exp, mode)


def _validate_pymoo_mode_prerequisites(exp: EtaIncerto, variants: list[str]) -> None:
    _validate_pymoo_defs(exp, variants, "pymoo")


def _validate_antifragile_prerequisites(exp: EtaIncerto, variants: list[str]) -> None:
    mode = "antifragile"
    _validate_pymoo_defs(exp, variants, mode)

    invest_variants: list[str] = []
    missing_evaluate: list[str] = []
    for variant in variants:
        pdef = exp.config.pymoo.for_variant(variant)
        if getattr(pdef, "mode", "invest") == "dispatch":
            continue
        invest_variants.append(variant)
        try:
            exp.config.evaluate.for_variant(variant)
        except KeyError:
            missing_evaluate.append(variant)

    if not invest_variants:
        raise ValueError(
            "Mode 'antifragile': no invest variants available. "
            "Fix: set config.pymoo.problems.<variant>.mode='invest' for at least one variant."
        )
    if missing_evaluate:
        raise ValueError(
            f"Mode 'antifragile': missing evaluate settings for invest variant(s) {missing_evaluate}. "
            "Fix: add config.evaluate.<variant> for each invest variant."
        )


def _validate_mode_prerequisites(exp: EtaIncerto, mode: str, variants: list[str]) -> None:
    """Run mode-specific preflight checks before heavy computation.

    - Scenario-based modes validate series/scenario definitions.
    - Pymoo/antifragile modes validate pymoo problem definitions.
    - Antifragile additionally validates invest/evaluate compatibility.
    """
    validators: dict[str, Callable[[EtaIncerto, list[str]], None]] = {
        "conventional": lambda e, _v: _validate_common_scenario_mode_prerequisites(e, "conventional"),
        "stochastic": lambda e, _v: _validate_common_scenario_mode_prerequisites(e, "stochastic"),
        "robust": lambda e, _v: _validate_common_scenario_mode_prerequisites(e, "robust"),
        "regret": lambda e, _v: _validate_common_scenario_mode_prerequisites(e, "regret"),
        "deterministic": lambda e, _v: _validate_common_scenario_mode_prerequisites(e, "deterministic"),
        "pymoo": _validate_pymoo_mode_prerequisites,
        "antifragile": _validate_antifragile_prerequisites,
    }
    validator = validators.get(mode)
    if validator is None:
        raise ValueError(f"Mode '{mode}': unsupported validation mode.")
    validator(exp, variants)


def _run_mode(exp: EtaIncerto, mode: str) -> int:
    """Dispatch execution to the selected EtaIncerto method and normalize exit code.

    Return normalization:
    - None -> 0
    - bool -> 0 (True) / 1 (False)
    - int -> as-is
    - other -> TypeError
    """
    mapping: dict[str, Callable[[], object]] = {
        "conventional": lambda: _run_conventional(exp),
        "antifragile": exp.antifragile_optimization,
        "stochastic": exp.stochastic_optimization,
        "robust": exp.robust_optimization,
        "regret": exp.regret_optimization,
        "pymoo": exp.pymoo_pyomo_optimization,
        "deterministic": exp.evaluate_deterministic,
    }

    runner = mapping.get(mode)
    if runner is None:
        raise ValueError(f"Unsupported mode: {mode}")

    result = runner()
    if result is None:
        return 0
    if isinstance(result, bool):
        return 0 if result else 1
    if isinstance(result, int):
        return result
    raise TypeError(f"Mode '{mode}' returned unsupported type: {type(result).__name__}")


def _log_run_context(
    *,
    root_path: Path,
    config_path: Path,
    relpath_config: str,
    mode: str,
    variants: list[str],
) -> None:
    active_overrides: dict[str, str] = {}
    if os.getenv("ETA_RESULTS_DIR"):
        active_overrides["ETA_RESULTS_DIR"] = os.environ["ETA_RESULTS_DIR"]
    if os.getenv("ETA_DATA_REPO_ROOT"):
        active_overrides["ETA_DATA_REPO_ROOT"] = os.environ["ETA_DATA_REPO_ROOT"]

    log.info("Run root: %s", root_path)
    log.info("Config effective: file=%s relpath_config=%s", config_path.name, relpath_config)
    log.info("Mode effective: %s", mode)
    log.info("Variants effective (%d): %s", len(variants), variants)
    log.info("Active overrides: %s", active_overrides or "none")


def main() -> int:
    """Entrypoint body used by `python -m`.

    Steps:
    1) Parse args
    2) Validate/resolve root and config paths
    3) Apply optional results-dir override (ETA_RESULTS_DIR)
    4) Build EtaIncerto instance
    5) Prepare variants (collect, auto-import, layout/registry checks)
    6) Log effective run context
    7) Validate mode-specific prerequisites
    8) Execute selected mode and return normalized exit code
    """
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _parse_args()

    root_path = Path(args.root_path).expanduser().resolve()
    if not root_path.exists():
        raise FileNotFoundError(
            f"--root-path does not exist: {root_path}. Fix: provide an existing run root directory."
        )
    if not root_path.is_dir():
        raise NotADirectoryError(
            f"--root-path is not a directory: {root_path}. Fix: provide a directory path containing the run structure."
        )
    config_path = _resolve_config_path(args.config, root_path)

    # CLI override takes highest priority for output location.
    # This is the key hook for scratch-first batch jobs.
    if args.results_dir:
        results_dir = Path(args.results_dir).expanduser()
        if not results_dir.is_absolute():
            results_dir = root_path / results_dir
        os.environ["ETA_RESULTS_DIR"] = str(results_dir.resolve())
        log.info("Using results dir override: %s", os.environ["ETA_RESULTS_DIR"])

    # Keep config resolution relative to root path; reject config paths outside root.
    try:
        rel_cfg_dir = config_path.parent.relative_to(root_path)
    except ValueError as exc:
        raise ValueError(f"--config must be inside --root-path. config={config_path}, root={root_path}") from exc

    relpath_config = str(rel_cfg_dir) if str(rel_cfg_dir) else "."
    exp = EtaIncerto(root_path, config_path.name, relpath_config=relpath_config)
    _force_parallel_policy(exp, args)
    mode = args.mode
    variants = _prepare_variants(exp, root_path, mode)
    _log_run_context(
        root_path=root_path,
        config_path=config_path,
        relpath_config=relpath_config,
        mode=mode,
        variants=variants,
    )
    _validate_mode_prerequisites(exp, mode, variants)
    return _run_mode(exp, mode)


if __name__ == "__main__":
    # Exit-code contract for schedulers:
    # - normal return from main() -> propagated status
    # - Ctrl+C -> 130 (standard interrupt code)
    # - schema/key issues -> 1 with clearer config message
    # - all other failures -> 1 with traceback
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except KeyError as exc:
        log.error("Config not compatible with current schema: %s", exc)
        sys.exit(1)
    except Exception:
        log.exception("Optimization run failed.")
        sys.exit(1)
