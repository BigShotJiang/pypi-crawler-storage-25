from __future__ import annotations

import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
from collections.abc import Iterable
from datetime import UTC, datetime
from logging import getLogger
from pathlib import Path

import h5py
import numpy as np

from eta_incerto.util.io_utils import load_config

log = getLogger(__name__)


class ResultsRepoError(RuntimeError):
    pass


def _run(
    cmd: list[str],
    *,
    cwd: Path | None = None,
    capture_output: bool = False,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            check=check,
            text=True,
            capture_output=capture_output,
        )
    except subprocess.CalledProcessError as exc:
        stdout = exc.stdout.strip() if exc.stdout else ""
        stderr = exc.stderr.strip() if exc.stderr else ""
        msg = f"Command failed: {' '.join(cmd)}"
        if stdout:
            msg += f"\nstdout: {stdout}"
        if stderr:
            msg += f"\nstderr: {stderr}"
        raise ResultsRepoError(msg) from exc


def _get_git_output(args: list[str], repo: Path) -> str:
    result = _run(["git", *args], cwd=repo, capture_output=True)
    return result.stdout.strip()


def _ensure_results_repo(repo_path: Path, repo_url: str | None, *, dry_run: bool) -> None:
    if repo_path.exists():
        if not (repo_path / ".git").exists():
            raise ResultsRepoError(f"Results repo path exists but is not a git repo: {repo_path}")
        return
    if not repo_url:
        raise ResultsRepoError("Results repo path does not exist and no --results-repo-url was provided.")
    if dry_run:
        log.info("[dry-run] Would clone results repo from %s to %s", repo_url, repo_path)
        return
    _run(["git", "clone", repo_url, str(repo_path)])
    _run(["git", "lfs", "install"], cwd=repo_path)


def _ensure_lfs(repo_path: Path, *, dry_run: bool) -> None:
    if dry_run:
        log.info("[dry-run] Would run git lfs install in %s", repo_path)
        return
    _run(["git", "lfs", "install"], cwd=repo_path)


def _resolve_results_dir(config_path: Path) -> Path:
    config = load_config(config_path)
    paths = config.get("paths", {})
    root_path = config_path.resolve().parent
    data_repo_root = paths.get("data_repo_root")
    if data_repo_root is not None:
        repo_root = Path(data_repo_root)
        base_path = repo_root if repo_root.is_absolute() else root_path / repo_root
    else:
        base_path = root_path
    results_dir = paths.get("results_dir", "results")
    results_dir = Path(results_dir)
    if not results_dir.is_absolute():
        results_dir = base_path / results_dir
    results_dir.mkdir(parents=True, exist_ok=True)
    return results_dir


def _resolve_data_repo_root(config_path: Path) -> Path | None:
    config = load_config(config_path)
    data_repo_root = config.get("paths", {}).get("data_repo_root")
    if not data_repo_root:
        return None
    root_path = config_path.resolve().parent
    repo_root = Path(data_repo_root)
    return repo_root if repo_root.is_absolute() else root_path / repo_root


def _decode_names(arr: Iterable) -> list[str]:
    out: list[str] = []
    for item in np.asarray(arr):
        if isinstance(item, bytes | np.bytes_):
            out.append(item.decode("utf-8", errors="replace"))
        else:
            out.append(str(item))
    return out


def _export_pareto_csv(h5_path: Path, dest_path: Path) -> None:
    with h5py.File(h5_path, "r") as handle:
        if "pareto/X" not in handle or "pareto/F" not in handle:
            raise ResultsRepoError(f"Pareto data not found in {h5_path}.")
        pareto_x = np.asarray(handle["pareto/X"], dtype=float)
        pareto_f = np.asarray(handle["pareto/F"], dtype=float)
        var_names = _decode_names(handle["pareto/variable_names"][:])
        obj_names = _decode_names(handle["pareto/objective_names"][:])

    if pareto_x.shape[0] != pareto_f.shape[0]:
        raise ResultsRepoError("Pareto X/F row count mismatch.")

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    header = var_names + obj_names
    rows = np.hstack([pareto_x, pareto_f])
    with dest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        for row in rows:
            writer.writerow([f"{val:.10g}" for val in row])


def _parse_run_id(output: str) -> str | None:
    match = re.search(r"Added run ([^ ]+) to", output)
    if match:
        return match.group(1).strip()
    return None


def _find_analysis_files(config_path: Path) -> list[str]:
    """Return list of analysis file paths (relative to data repo root) that exist for this run."""
    data_repo_root = _resolve_data_repo_root(config_path)
    if not data_repo_root or not data_repo_root.exists():
        return []
    run_dir = config_path.resolve().parent
    run_id = run_dir.name
    analysis_dir = run_dir / "results" / "analysis"
    if not analysis_dir.is_dir():
        return []
    out: list[str] = []
    for solve_type in ("conventional", "antifragile"):
        p = analysis_dir / f"analysis_{run_id}_{solve_type}.json"
        if p.exists():
            try:
                rel = p.relative_to(data_repo_root)
                out.append(rel.as_posix())
            except ValueError:
                pass
    return out


def _write_run_link(
    results_dir: Path,
    run_id: str,
    *,
    code_repo_url: str,
    code_commit_sha: str,
    results_repo_url: str,
    results_repo_commit_sha: str,
    data_repo_meta: dict[str, str | list[str] | None] | None = None,
) -> Path:
    """Write run_link.json. data_repo_meta: optional keys include data_repo_url, analysis_files, etc."""
    timestamp = datetime.now(UTC).isoformat(timespec="seconds")
    payload = {
        "run_id": run_id,
        "timestamp": timestamp,
        "code_repo_url": code_repo_url,
        "code_commit_sha": code_commit_sha,
        "results_repo_url": results_repo_url,
        "results_repo_commit_sha": results_repo_commit_sha,
    }
    if data_repo_meta:
        for key in ("data_repo_url", "data_repo_commit_sha", "input_metadata_path", "input_path_prefix"):
            val = data_repo_meta.get(key)
            if val:
                payload[key] = val
        if data_repo_meta.get("analysis_files"):
            payload["analysis_files"] = data_repo_meta["analysis_files"]
    link_dir = results_dir / run_id
    link_dir.mkdir(parents=True, exist_ok=True)
    link_path = link_dir / "run_link.json"
    link_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return link_path


def _common_prefix(parts_list: list[tuple[str, ...]]) -> Path | None:
    if not parts_list:
        return None
    prefix = list(parts_list[0])
    for parts in parts_list[1:]:
        while prefix and prefix != list(parts[: len(prefix)]):
            prefix.pop()
    return Path(*prefix) if prefix else None


def _get_data_repo_metadata(config_path: Path) -> dict[str, str]:
    data_repo_root = _resolve_data_repo_root(config_path)
    if not data_repo_root:
        return {}
    if not data_repo_root.exists():
        log.warning("Data repo root does not exist: %s", data_repo_root)
        return {}

    try:
        repo_root = Path(_get_git_output(["rev-parse", "--show-toplevel"], data_repo_root))
        data_repo_url = _get_git_output(["config", "--get", "remote.origin.url"], repo_root)
        data_repo_commit_sha = _get_git_output(["rev-parse", "HEAD"], repo_root)
    except ResultsRepoError as exc:
        log.warning("Failed to read data repo git metadata: %s", exc)
        return {}

    config = load_config(config_path)
    scenario_files = config.get("scenario", {}).get("scenario_file", [])
    series_files = config.get("series", {}).get("series_file", [])
    rel_parts: list[tuple[str, ...]] = []

    def _add_rel(path_value: str | None) -> None:
        if not path_value:
            return
        path = Path(path_value)
        absolute = path if path.is_absolute() else data_repo_root / path
        try:
            rel = absolute.relative_to(data_repo_root)
        except ValueError:
            return
        rel_parts.append(rel.parts)

    for entry in scenario_files:
        _add_rel(entry.get("path"))
    for entry in series_files:
        _add_rel(entry.get("raw_data_path"))

    prefix = _common_prefix(rel_parts)
    input_path_prefix = prefix.as_posix() if prefix else ""
    input_metadata_path = f"{input_path_prefix}/metadata.json" if input_path_prefix else ""
    metadata_full = data_repo_root / input_metadata_path if input_metadata_path else None

    if metadata_full and not metadata_full.exists():
        log.warning("Input metadata not found at %s", metadata_full)
        input_metadata_path = ""

    result = {
        "data_repo_url": data_repo_url,
        "data_repo_commit_sha": data_repo_commit_sha,
    }
    if input_metadata_path:
        result["input_metadata_path"] = input_metadata_path
    if input_path_prefix:
        result["input_path_prefix"] = input_path_prefix
    return result


def _resolve_run_from_index(index_path: Path, run_id: str) -> Path:
    if not index_path.exists():
        raise ResultsRepoError(f"index.csv not found at {index_path}")
    with index_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if (row.get("run_id") or "").strip() == run_id:
                run_path = (row.get("path") or "").strip()
                if not run_path:
                    raise ResultsRepoError(f"Run {run_id} found, but path column is empty.")
                return Path(run_path)
    raise ResultsRepoError(f"run_id {run_id} not found in {index_path}")


def _latest_run_from_index(index_path: Path) -> str:
    if not index_path.exists():
        raise ResultsRepoError(f"index.csv not found at {index_path}")
    last_run = None
    with index_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            run_id = (row.get("run_id") or "").strip()
            if run_id:
                last_run = run_id
    if not last_run:
        raise ResultsRepoError("No runs found in index.csv.")
    return last_run


def _resolve_pareto_path(
    artifact_path: Path,
    config_path: Path,
    *,
    dry_run: bool,
) -> Path | None:
    """Resolve and optionally export pareto CSV; return path or None."""
    try:
        results_dir = _resolve_results_dir(config_path)
        pareto_path = results_dir / f"{artifact_path.stem}_pareto.csv"
        if dry_run:
            log.info("[dry-run] Would export pareto CSV to %s", pareto_path)
        else:
            _export_pareto_csv(artifact_path, pareto_path)
        return pareto_path
    except ResultsRepoError as exc:
        log.warning("Skipping pareto export: %s", exc)
        return None


def _commit_and_push_if_changes(results_repo_path: Path, run_id: str) -> None:
    """Stage all, commit and push only if there are changes."""
    _run(["git", "add", "-A"], cwd=results_repo_path)
    status = _get_git_output(["status", "--porcelain"], results_repo_path)
    if status:
        _run(["git", "commit", "-m", f"Add run {run_id}"], cwd=results_repo_path)
        _run(["git", "push"], cwd=results_repo_path)
    else:
        log.info("No changes to commit in results repo.")


def publish(args: argparse.Namespace) -> int:
    code_repo = Path(__file__).resolve().parents[2]
    results_repo_url = args.results_repo_url or os.environ.get("RESULTS_REPO_URL")
    results_repo_path = Path(args.results_repo_path or os.environ.get("RESULTS_REPO_PATH", ""))
    if not str(results_repo_path):
        raise ResultsRepoError("Missing --results-repo-path and RESULTS_REPO_PATH.")

    artifact_path = Path(args.artifact)
    config_path = Path(args.config)

    if not artifact_path.exists():
        raise ResultsRepoError(f"Artifact not found: {artifact_path}")
    if not config_path.exists():
        raise ResultsRepoError(f"Config not found: {config_path}")

    _ensure_results_repo(results_repo_path, results_repo_url, dry_run=args.dry_run)
    _ensure_lfs(results_repo_path, dry_run=args.dry_run)

    code_repo_url = _get_git_output(["config", "--get", "remote.origin.url"], code_repo)
    code_commit_sha = _get_git_output(["rev-parse", "HEAD"], code_repo)

    pareto_path = (
        Path(args.pareto) if args.pareto else _resolve_pareto_path(artifact_path, config_path, dry_run=args.dry_run)
    )

    cmd = [
        sys.executable,
        "scripts/add_run.py",
        "--artifact",
        str(artifact_path),
        "--config",
        str(config_path),
        "--code-repo-url",
        code_repo_url,
        "--code-commit-sha",
        code_commit_sha,
        "--objectives-summary",
        args.objectives_summary,
    ]
    if args.run_id:
        cmd.extend(["--run-id", args.run_id])
    if pareto_path:
        cmd.extend(["--pareto", str(pareto_path)])

    if args.dry_run:
        log.info("[dry-run] Would run: %s (cwd=%s)", " ".join(cmd), results_repo_path)
        return 0

    result = _run(cmd, cwd=results_repo_path, capture_output=True)
    run_id = args.run_id or _parse_run_id(result.stdout) or "unknown"

    _commit_and_push_if_changes(results_repo_path, run_id)

    results_repo_commit_sha = _get_git_output(["rev-parse", "HEAD"], results_repo_path)

    results_dir = _resolve_results_dir(config_path)
    data_repo_meta = dict(_get_data_repo_metadata(config_path))
    analysis_files = _find_analysis_files(config_path)
    if analysis_files:
        data_repo_meta["analysis_files"] = analysis_files
    link_path = _write_run_link(
        results_dir,
        run_id,
        code_repo_url=code_repo_url,
        code_commit_sha=code_commit_sha,
        results_repo_url=results_repo_url or "",
        results_repo_commit_sha=results_repo_commit_sha,
        data_repo_meta=data_repo_meta or None,
    )

    log.info("Published run %s at %s.", run_id, results_repo_commit_sha)
    log.info("Run link metadata: %s", link_path)
    return 0


def _checkout_ref(results_repo_path: Path, ref: str | None, *, dry_run: bool) -> None:
    if not ref:
        return
    if dry_run:
        log.info("[dry-run] Would checkout %s", ref)
        return
    _run(["git", "checkout", ref], cwd=results_repo_path)


def _lfs_pull(results_repo_path: Path, *, dry_run: bool) -> None:
    if dry_run:
        log.info("[dry-run] Would run git lfs pull in %s", results_repo_path)
        return
    _run(["git", "lfs", "pull"], cwd=results_repo_path)


def _copy_run_files(
    run_path: Path,
    dest: Path,
    patterns: list[str] | None,
    *,
    dry_run: bool,
) -> None:
    if patterns:
        matches: list[Path] = []
        for pattern in patterns:
            matches.extend(run_path.glob(pattern))
        if not matches:
            raise ResultsRepoError("No files matched the provided patterns.")
        if dry_run:
            log.info("[dry-run] Would copy %s files to %s", len(matches), dest)
            return
        for match in matches:
            rel = match.relative_to(run_path)
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(match, target)
        return

    if dry_run:
        log.info("[dry-run] Would copy %s to %s", run_path, dest)
        return
    shutil.copytree(run_path, dest, dirs_exist_ok=True)


def pull(args: argparse.Namespace) -> int:
    code_repo = Path(__file__).resolve().parents[2]
    results_repo_url = args.results_repo_url or os.environ.get("RESULTS_REPO_URL")
    results_repo_path = Path(args.results_repo_path or os.environ.get("RESULTS_REPO_PATH", ""))
    if not str(results_repo_path):
        raise ResultsRepoError("Missing --results-repo-path and RESULTS_REPO_PATH.")

    _ensure_results_repo(results_repo_path, results_repo_url, dry_run=args.dry_run)
    _ensure_lfs(results_repo_path, dry_run=args.dry_run)

    _checkout_ref(results_repo_path, args.results_repo_ref, dry_run=args.dry_run)

    run_id = args.run_id
    if not run_id:
        run_id = _latest_run_from_index(results_repo_path / "index.csv")

    run_path_rel = _resolve_run_from_index(results_repo_path / "index.csv", run_id)
    run_path = results_repo_path / run_path_rel
    if not run_path.exists():
        raise ResultsRepoError(f"Run folder not found: {run_path}")

    _lfs_pull(results_repo_path, dry_run=args.dry_run)

    dest = Path(args.dest) if args.dest else (code_repo / "outputs" / "pulled" / run_id)
    patterns = [p for p in (args.files or []) if p]
    if args.files and not patterns:
        raise ResultsRepoError("No valid --files patterns provided.")
    _copy_run_files(run_path, dest, patterns if patterns else None, dry_run=args.dry_run)

    results_repo_commit_sha = _get_git_output(["rev-parse", "HEAD"], results_repo_path)
    log.info("Pulled run %s to %s", run_id, dest)
    log.info("Results repo commit: %s", results_repo_commit_sha)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Publish/pull optimization run artifacts via results repo.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    publish_parser = subparsers.add_parser("publish", help="Publish run artifacts to results repo.")
    publish_parser.add_argument("--results-repo-url", default=None)
    publish_parser.add_argument("--results-repo-path", default=None)
    publish_parser.add_argument("--artifact", required=True)
    publish_parser.add_argument("--pareto", default=None)
    publish_parser.add_argument("--config", required=True)
    publish_parser.add_argument("--objectives-summary", required=True)
    publish_parser.add_argument("--run-id", default=None)
    publish_parser.add_argument("--dry-run", action="store_true")

    pull_parser = subparsers.add_parser("pull", help="Pull run artifacts from results repo.")
    pull_parser.add_argument("--results-repo-url", default=None)
    pull_parser.add_argument("--results-repo-path", default=None)
    pull_parser.add_argument("--run-id", default=None)
    pull_parser.add_argument("--results-repo-ref", default=None)
    pull_parser.add_argument("--dest", default=None)
    pull_parser.add_argument("--files", nargs="*", default=None)
    pull_parser.add_argument("--dry-run", action="store_true")

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        if args.command == "publish":
            return publish(args)
        if args.command == "pull":
            return pull(args)
    except ResultsRepoError as exc:
        log.error("Results repo error: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
