"""
CLI: PCE order test (RMSE vs polynomial order, optional LOO/k-fold diagnostics).

Loads config and variant data from a run directory (same layout as antifragile),
attaches one reference investment scenario to the model builder, then runs
``EtaIncerto.evaluate_pce_order`` → ``PceOrderTest.evaluate_rmse()`` writing
``results/pce_order_test.h5`` (see ``config.pcetest``).

Requires a registration module that registers the variant's system (e.g.
``examples.antifragile.variants.variant_one.system``). When running from a
source checkout, the repository root is prepended to ``sys.path`` so ``examples.*``
imports resolve.
"""

from __future__ import annotations

import argparse
import importlib
import logging
import sys
from pathlib import Path

from eta_incerto.core import EtaIncerto
from eta_incerto.util.data_paths import get_run_dir_from_env

log = logging.getLogger(__name__)


def _ensure_repo_root_on_path() -> None:
    """Allow ``import examples....`` when running via ``python -m`` / poetry script."""
    here = Path(__file__).resolve()
    # eta-incerto/eta_incerto/tools/run_pce_order_test.py -> parents[2] = repo root
    repo_root = here.parents[2]
    examples = repo_root / "examples"
    if examples.is_dir():
        root_s = str(repo_root)
        if root_s not in sys.path:
            sys.path.insert(0, root_s)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run PCE order test from a run directory (writes results/pce_order_test.h5).",
    )
    p.add_argument(
        "--run-dir",
        default=None,
        help="Path to run directory (config.json and variant_* inputs). "
        "If omitted, uses RUN_DIR or DATA_REPO_PATH+RUN_ID (see eta_incerto.util.data_paths).",
    )
    p.add_argument(
        "--config",
        default="config",
        help="Config name without extension inside the run dir (default: config).",
    )
    p.add_argument(
        "--registration-module",
        default="examples.antifragile.variants.variant_one.system",
        help="Import path that registers the variant system (default: variant_one antifragile example).",
    )
    p.add_argument(
        "--variant",
        default=None,
        help="System variant name (default: first entry in config.system.variant).",
    )
    return p


def _resolve_run_dir(args: argparse.Namespace) -> Path:
    if getattr(args, "run_dir", None):
        return Path(args.run_dir).expanduser().resolve()
    run_dir = get_run_dir_from_env()
    if run_dir is not None:
        return run_dir
    raise SystemExit(
        "Run directory is required. Pass --run-dir, or set RUN_DIR to the run folder, or DATA_REPO_PATH and RUN_ID."
    )


def run_pce_order_test_cli(args: argparse.Namespace) -> Path:
    """Execute the PCE order test; returns path to the written H5 (under results_dir)."""
    importlib.import_module(args.registration_module)
    run_dir = _resolve_run_dir(args)
    experiment = EtaIncerto(run_dir, args.config, relpath_config=".")

    variants = experiment.config.system.variant
    variant = variants if isinstance(variants, str) else variants[0] if variants else None
    if args.variant is not None:
        variant = args.variant
    if not variant:
        raise SystemExit("No variant in config.system.variant and none passed via --variant.")

    model_builder, _demand_series, distribution_data = experiment.load_model_series_algorithm_termination(variant)
    try:
        ref = experiment._load_single_invest_ref_scenario(variant)
    except RuntimeError as exc:
        log.warning(
            "Skipping reference scenario attachment for PCE order test: %s. "
            "Proceeding with distribution-driven runtime inputs.",
            exc,
        )
    else:
        if hasattr(model_builder, "attach_inputs_from_scenario"):
            model_builder.attach_inputs_from_scenario(ref)
        else:
            model_builder.series_data = ref.series
            model_builder.scenario_data = ref.energy_scenario
            model_builder.series_file_name = getattr(ref, "series_file_name", "")

    experiment.evaluate_pce_order(model_builder, distribution_data)

    results_dir = Path(experiment.config.paths.results_dir)
    if not results_dir.is_absolute():
        results_dir = run_dir / results_dir
    return results_dir / "pce_order_test.h5"


def main(argv: list[str] | None = None) -> int:
    _ensure_repo_root_on_path()
    parser = _build_parser()
    args = parser.parse_args(argv)
    run_pce_order_test_cli(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
