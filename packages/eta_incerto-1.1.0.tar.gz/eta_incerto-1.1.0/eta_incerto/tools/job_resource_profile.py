"""
Job resource profiler for production/HPC sizing.

Runs antifragile optimization (or a single objective evaluation) and reports:
- Compute time in core-hours
- Expected maximum duration of production job runs (elapsed hours)
- Number of software codes (variants)
- Job categorization: max simultaneous jobs, max memory per core (GB),
  typical/max cores per job

Output is written as JSON and a human-readable summary for use in SLURM or
similar scheduler configuration.
"""

from __future__ import annotations

import argparse
import importlib
import json
import logging
import os
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from pymoo.termination import get_termination

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.core import EtaIncerto
from eta_incerto.envs.antifragile_evaluation import AntifragileEvaluator

log = logging.getLogger(__name__)

# Optional: sample process memory during run (requires psutil)
try:
    import psutil
except ImportError:
    psutil = None  # type: ignore[assignment]


@dataclass
class JobCategoryMetrics:
    """Per-job-category (variant) resource metrics."""

    variant: str
    max_simultaneous_jobs: int
    max_memory_per_core_gb: float | None
    typical_cores_per_job: int
    max_cores_per_job: int


@dataclass
class ResourceProfileResult:
    """Aggregate resource profile from a profiling run."""

    core_hours: float
    max_job_duration_hours: float
    n_software_codes: int
    job_categories: list[JobCategoryMetrics] = field(default_factory=list)
    elapsed_wall_seconds: float = 0.0
    effective_cores_used: float = 1.0
    peak_memory_rss_gb: float | None = None
    core_hours_per_evaluation: float | None = None
    profiling_run_config: dict | None = None
    extrapolated_core_hours: float | None = None
    extrapolated_max_job_duration_hours: float | None = None
    extrapolation_production_n_eval: int | None = None
    extrapolation_production_cores: float | None = None
    extrapolation_cost_ratio: float | None = None

    def to_dict(self) -> dict:
        out = {
            "core_hours": self.core_hours,
            "max_job_duration_hours": self.max_job_duration_hours,
            "n_software_codes": self.n_software_codes,
            "elapsed_wall_seconds": self.elapsed_wall_seconds,
            "effective_cores_used": self.effective_cores_used,
            "peak_memory_rss_gb": self.peak_memory_rss_gb,
            "job_categories": [
                {
                    "variant": c.variant,
                    "max_simultaneous_jobs": c.max_simultaneous_jobs,
                    "max_memory_per_core_gb": c.max_memory_per_core_gb,
                    "typical_cores_per_job": c.typical_cores_per_job,
                    "max_cores_per_job": c.max_cores_per_job,
                }
                for c in self.job_categories
            ],
        }
        if self.core_hours_per_evaluation is not None:
            out["core_hours_per_evaluation"] = self.core_hours_per_evaluation
        if self.profiling_run_config is not None:
            out["profiling_run_config"] = self.profiling_run_config
        if self.extrapolated_core_hours is not None:
            out["extrapolated_core_hours"] = self.extrapolated_core_hours
        if self.extrapolated_max_job_duration_hours is not None:
            out["extrapolated_max_job_duration_hours"] = self.extrapolated_max_job_duration_hours
        if self.extrapolation_production_n_eval is not None:
            out["extrapolation_production_n_eval"] = self.extrapolation_production_n_eval
        if self.extrapolation_production_cores is not None:
            out["extrapolation_production_cores"] = self.extrapolation_production_cores
        if self.extrapolation_cost_ratio is not None:
            out["extrapolation_cost_ratio"] = self.extrapolation_cost_ratio
        return out


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Profile job resources (core-hours, duration, memory, job categories) for production sizing."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to config file (json/toml/yaml).",
    )
    parser.add_argument(
        "--variant",
        action="append",
        default=None,
        help="Variant name to profile. Repeat for multiple variants. Default: all invest variants.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Directory for JSON and summary output (default: <results_dir>/job_profiles).",
    )
    parser.add_argument(
        "--variant-module",
        action="append",
        default=None,
        help="Python module to import to register systems (repeatable).",
    )
    parser.add_argument(
        "--single-eval",
        action="store_true",
        help="Profile a single objective evaluation (no optimization loop).",
    )
    parser.add_argument(
        "--min-runtime",
        action="store_true",
        help="Override config for minimal runtime (small samples, n_eval=1) for quick profiling.",
    )
    parser.add_argument(
        "--no-memory-sampling",
        action="store_true",
        help="Disable memory sampling even if psutil is available.",
    )
    parser.add_argument(
        "--extrapolate",
        action="store_true",
        help="Minimal local probe (single eval, single process, strongest overrides) for extrapolation to production.",
    )
    parser.add_argument(
        "--production-config",
        default=None,
        help="Path to production config (supercomputer run) for extrapolation. Same format as --config.",
    )
    parser.add_argument(
        "--production-n-eval",
        type=int,
        default=None,
        help="Production number of evaluations (overrides production-config termination if set).",
    )
    parser.add_argument(
        "--production-cores",
        type=int,
        default=None,
        help="Production cores (overrides production-config n_jobs/n_workers if set).",
    )
    parser.add_argument(
        "--production-pce-order",
        type=int,
        default=None,
        help="Production PCE order for cost-ratio scaling (overrides production-config if set).",
    )
    parser.add_argument(
        "--production-pce-sample-factor",
        type=int,
        default=None,
        help="Production PCE sample factor for cost-ratio scaling (overrides production-config if set).",
    )
    return parser.parse_args()


def _resolve_config_path(config_arg: str) -> Path:
    raw = Path(config_arg).expanduser()
    if raw.exists():
        return raw
    if raw.suffix:
        raise FileNotFoundError(f"Config file not found: {raw}")
    for ext in (".json", ".toml", ".yaml", ".yml"):
        candidate = raw.with_suffix(ext)
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Config file not found: {raw}")


def _import_variant_modules(modules: list[str]) -> None:
    for mod in modules:
        try:
            importlib.import_module(mod)
            log.info("Imported variant module: %s", mod)
        except Exception as exc:
            log.warning("Failed importing variant module %s: %s", mod, exc)


def _maybe_import_example_variants(config_path: Path, variants: list[str]) -> None:
    if config_path.parent.name != "antifragile":
        return
    modules: list[str] = []
    for variant in variants:
        modules.append(f"examples.antifragile.variants.{variant}.system")
    _import_variant_modules(modules)


def _attach_inputs_from_scenario(model_builder, scenario) -> None:
    if hasattr(model_builder, "attach_inputs_from_scenario"):
        model_builder.attach_inputs_from_scenario(scenario)
        return
    model_builder.series_data = scenario.series
    model_builder.scenario_data = scenario.energy_scenario
    model_builder.series_file_name = getattr(scenario, "series_file_name", "")


def _apply_fast_solver_for_profiling(config, variant: str) -> None:
    """Apply relaxed solver and PCE settings so profiling runs finish in reasonable time."""
    eval_cfg = config.evaluate.for_variant(variant)
    mipgap = 0.10
    timelimit = 120
    pce_sample_factor = 2
    eval_cfg.solver_mipgap_override = mipgap
    eval_cfg.solver_timelimit_override = timelimit
    if hasattr(eval_cfg, "pce_sample_factor"):
        eval_cfg.pce_sample_factor = pce_sample_factor


def _apply_min_runtime(config, variant: str) -> None:
    eval_cfg = config.evaluate.for_variant(variant)
    overrides = {
        "pce_order": 1,
        "quad_order": 1,
        "stat_n_mc": 10,
        "feasibility_batch_size": 32,
        "feasibility_max_rounds": 5,
    }
    for key, value in overrides.items():
        if hasattr(eval_cfg, key):
            setattr(eval_cfg, key, value)
    algo_cfg = config.algorithm
    if hasattr(algo_cfg, "pop_size") and algo_cfg.pop_size > 4:
        algo_cfg.pop_size = 4
    config.termination.termination_instance = get_termination("n_eval", 1)


def _apply_probe_overrides(config, variant: str) -> None:
    """Strongest minimal overrides for extrapolation probe: single process, minimal PCE/quad, 30s solver."""
    eval_cfg = config.evaluate.for_variant(variant)
    eval_cfg.n_jobs = 1
    eval_cfg.n_workers = 1
    eval_cfg.solver_mipgap_override = 0.10
    eval_cfg.solver_timelimit_override = 30
    overrides = {
        "pce_order": 1,
        "pce_sample_factor": 1,
        "quad_order": 1,
        "stat_n_mc": 5,
        "feasibility_batch_size": 16,
        "feasibility_max_rounds": 2,
    }
    for key, value in overrides.items():
        if hasattr(eval_cfg, key):
            setattr(eval_cfg, key, value)
    algo_cfg = config.algorithm
    if hasattr(algo_cfg, "pop_size") and algo_cfg.pop_size > 2:
        algo_cfg.pop_size = 2
    config.termination.termination_instance = get_termination("n_eval", 1)


def _build_evaluator(experiment: EtaIncerto, variant: str) -> AntifragileEvaluator:
    pdef = experiment.config.pymoo.for_variant(variant)
    if getattr(pdef, "mode", "invest") == "dispatch":
        raise RuntimeError(f"Variant '{variant}' is dispatch-only; no antifragile design variables to profile.")
    model_builder, demand_series, distribution_data = experiment.load_model_series_algorithm_termination(variant)
    _, _, invest_scenarios, _ = experiment.load_system_series_scenario(variant)
    invest_scenarios = list(invest_scenarios or [])
    if not invest_scenarios:
        raise RuntimeError(f"Antifragile optimization requires invest_scenarios for '{variant}', but none were loaded.")
    _attach_inputs_from_scenario(model_builder, invest_scenarios[0])
    return AntifragileEvaluator(
        config=experiment.config,
        variant_name=variant,
        model_builder=model_builder,
        demand_series=demand_series,
        distribution_data=distribution_data,
        h5_file_name=f"antifragile_{variant}.h5",
        variable_names=pdef.variable_names,
        objective_names=pdef.objective_names,
    )


class _MemorySampler:
    """Background thread that samples current process RSS (and children if psutil)."""

    def __init__(self, interval: float = 2.0, include_children: bool = True) -> None:
        self.interval = interval
        self.include_children = include_children
        self._samples: list[float] = []
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def _sample(self) -> float:
        if not psutil:
            return 0.0
        proc = psutil.Process()
        rss = proc.memory_info().rss
        if self.include_children:
            for child in proc.children(recursive=True):
                try:
                    rss += child.memory_info().rss
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        return rss / (1024**3)  # GB

    def _run(self) -> None:
        while not self._stop.wait(timeout=self.interval):
            self._samples.append(self._sample())

    def start(self) -> None:
        if psutil and self._thread is None:
            self._samples.append(self._sample())
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()

    def stop(self) -> list[float]:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval * 2)
            self._thread = None
        return list(self._samples)


def _job_category_metrics(experiment: EtaIncerto, variant: str) -> JobCategoryMetrics:
    eval_cfg = experiment.config.evaluate.for_variant(variant)
    n_jobs = eval_cfg.n_jobs
    if n_jobs <= 0:
        n_jobs = max(1, (os.cpu_count() or 1) + n_jobs)
    n_workers = getattr(eval_cfg, "n_workers", None) or n_jobs
    if n_workers <= 0:
        n_workers = max(1, (os.cpu_count() or 1) + n_workers)
    max_simultaneous = max(n_jobs, n_workers)
    typical_cores = min(n_jobs, n_workers) if n_jobs > 0 and n_workers > 0 else 1
    max_cores = max(n_jobs, n_workers)
    return JobCategoryMetrics(
        variant=variant,
        max_simultaneous_jobs=max_simultaneous,
        max_memory_per_core_gb=None,  # filled from sampler if available
        typical_cores_per_job=typical_cores,
        max_cores_per_job=max_cores,
    )


def _run_single_eval(
    experiment: EtaIncerto,
    variant: str,
    sample_memory: bool,
) -> ResourceProfileResult:
    evaluator = _build_evaluator(experiment, variant)
    eval_cfg = experiment.config.evaluate.for_variant(variant)
    n_jobs = eval_cfg.n_jobs
    if n_jobs <= 0:
        n_jobs = max(1, (os.cpu_count() or 1) + n_jobs)
    n_workers = getattr(eval_cfg, "n_workers", None) or n_jobs
    if n_workers <= 0:
        n_workers = max(1, (os.cpu_count() or 1) + n_workers)
    effective_cores = max(1, min(n_jobs, n_workers))

    sampler = _MemorySampler() if (sample_memory and psutil) else None
    if sampler:
        sampler.start()

    t0 = time.perf_counter()
    pdef = experiment.config.pymoo.for_variant(variant)
    xl = np.asarray(pdef.x_lower_bound, dtype=float)
    xu = np.asarray(pdef.x_upper_bound, dtype=float)
    x = (xl + xu) / 2.0
    evaluator._evaluate_objectives(x)
    elapsed = time.perf_counter() - t0

    peak_memory_gb: float | None = None
    if sampler:
        samples = sampler.stop()
        if samples:
            peak_memory_gb = max(samples)
            peak_memory_gb = round(peak_memory_gb, 4)

    core_hours = (elapsed / 3600.0) * effective_cores
    categories = [_job_category_metrics(experiment, variant)]
    if categories[0].max_memory_per_core_gb is None and peak_memory_gb is not None:
        categories[0].max_memory_per_core_gb = round(peak_memory_gb / effective_cores, 4)

    return ResourceProfileResult(
        core_hours=round(core_hours, 6),
        max_job_duration_hours=round(elapsed / 3600.0, 6),
        n_software_codes=1,
        job_categories=categories,
        elapsed_wall_seconds=round(elapsed, 2),
        effective_cores_used=effective_cores,
        peak_memory_rss_gb=peak_memory_gb,
    )


def _run_full_optimization(
    experiment: EtaIncerto,
    variant: str,
    sample_memory: bool,
) -> ResourceProfileResult:
    evaluator = _build_evaluator(experiment, variant)
    eval_cfg = experiment.config.evaluate.for_variant(variant)
    n_jobs = eval_cfg.n_jobs
    if n_jobs <= 0:
        n_jobs = max(1, (os.cpu_count() or 1) + n_jobs)
    n_workers = getattr(eval_cfg, "n_workers", None) or n_jobs
    if n_workers <= 0:
        n_workers = max(1, (os.cpu_count() or 1) + n_workers)
    effective_cores = max(1, min(n_jobs, n_workers))

    sampler = _MemorySampler() if (sample_memory and psutil) else None
    if sampler:
        sampler.start()

    t0 = time.perf_counter()
    evaluator.evaluate_systems()
    elapsed = time.perf_counter() - t0

    peak_memory_gb = None
    if sampler:
        samples = sampler.stop()
        if samples:
            peak_memory_gb = round(max(samples), 4)

    core_hours = (elapsed / 3600.0) * effective_cores
    categories = [_job_category_metrics(experiment, variant)]
    if categories[0].max_memory_per_core_gb is None and peak_memory_gb is not None:
        categories[0].max_memory_per_core_gb = round(peak_memory_gb / effective_cores, 4)

    return ResourceProfileResult(
        core_hours=round(core_hours, 6),
        max_job_duration_hours=round(elapsed / 3600.0, 6),
        n_software_codes=1,
        job_categories=categories,
        elapsed_wall_seconds=round(elapsed, 2),
        effective_cores_used=effective_cores,
        peak_memory_rss_gb=peak_memory_gb,
    )


def _build_profiling_run_config(experiment: EtaIncerto, variant: str) -> dict:
    """Snapshot of config actually used for the profiling run (after overrides)."""
    eval_cfg = experiment.config.evaluate.for_variant(variant)
    term = experiment.config.termination
    algo = experiment.config.algorithm
    n_eval = 1
    if getattr(term, "method", None) == "n_eval" and getattr(term, "value", None) is not None:
        n_eval = int(term.value)
    elif getattr(term, "method", None) == "n_gen" and getattr(term, "value", None) is not None:
        pop = int(getattr(algo, "pop_size", 4))
        n_eval = int(term.value) * pop
    cfg = {
        "n_eval": n_eval,
        "pop_size": int(getattr(algo, "pop_size", 4)),
        "pce_order": int(getattr(eval_cfg, "pce_order", 1)),
        "pce_sample_factor": int(getattr(eval_cfg, "pce_sample_factor", 1)),
        "quad_order": int(getattr(eval_cfg, "quad_order", 1)),
        "stat_n_mc": int(getattr(eval_cfg, "stat_n_mc", 5)),
        "n_jobs": int(eval_cfg.n_jobs),
        "n_workers": int(eval_cfg.n_workers or eval_cfg.n_jobs),
    }
    if getattr(eval_cfg, "solver_timelimit_override", None) is not None:
        cfg["solver_timelimit_override"] = eval_cfg.solver_timelimit_override
    if getattr(eval_cfg, "solver_mipgap_override", None) is not None:
        cfg["solver_mipgap_override"] = eval_cfg.solver_mipgap_override
    return cfg


def _production_n_eval_and_cores(prod_config: ConfigOptimization, variant: str) -> tuple[int, float]:
    """From production config compute n_eval and effective cores for given variant."""
    term = prod_config.termination
    algo = prod_config.algorithm
    pop = int(getattr(algo, "pop_size", 4))
    if getattr(term, "method", None) == "n_eval" and getattr(term, "value", None) is not None:
        n_eval = int(term.value)
    elif getattr(term, "method", None) == "n_gen" and getattr(term, "value", None) is not None:
        n_eval = int(term.value) * pop
    else:
        n_eval = 1
    eval_cfg = prod_config.evaluate.for_variant(variant)
    n_jobs = eval_cfg.n_jobs
    if n_jobs <= 0:
        n_jobs = max(1, (os.cpu_count() or 1) + n_jobs)
    n_workers = getattr(eval_cfg, "n_workers", None) or n_jobs
    if n_workers <= 0:
        n_workers = max(1, (os.cpu_count() or 1) + n_workers)
    cores = max(1.0, min(n_jobs, n_workers))
    return n_eval, cores


def _compute_cost_ratio(
    probe_pce_order: int,
    probe_pce_sample_factor: int,
    prod_pce_order: int,
    prod_pce_sample_factor: int,
    k: int = 2,
) -> float:
    """Cost per evaluation ratio: (prod * (order+1)^k) / (probe * (order+1)^k)."""
    probe_factor = probe_pce_sample_factor * ((probe_pce_order + 1) ** k)
    prod_factor = prod_pce_sample_factor * ((prod_pce_order + 1) ** k)
    if probe_factor <= 0:
        return 1.0
    return prod_factor / probe_factor


def _enrich_aggregate(
    aggregate: ResourceProfileResult,
    experiment: EtaIncerto,
    invest_variants: list[str],
    single_eval: bool,
    args: argparse.Namespace,
) -> None:
    """Set core_hours_per_evaluation, profiling_run_config, and extrapolation fields on aggregate."""
    want_extrapolation = bool(args.production_config or getattr(args, "production_n_eval", None) is not None)
    if single_eval:
        aggregate.core_hours_per_evaluation = aggregate.core_hours
        if invest_variants:
            aggregate.profiling_run_config = _build_profiling_run_config(experiment, invest_variants[0])
    elif want_extrapolation and invest_variants:
        aggregate.core_hours_per_evaluation = aggregate.core_hours
        aggregate.profiling_run_config = _build_profiling_run_config(experiment, invest_variants[0])

    production_config: ConfigOptimization | None = None
    if args.production_config:
        prod_path = _resolve_config_path(args.production_config)
        prod_root = prod_path.parent
        try:
            production_config = ConfigOptimization.from_file(prod_path, prod_root)
        except Exception as exc:
            log.warning("Could not load production config %s: %s. Skipping extrapolation.", prod_path, exc)

    prod_n_eval = getattr(args, "production_n_eval", None)
    prod_cores = getattr(args, "production_cores", None)
    prod_pce_order = getattr(args, "production_pce_order", None)
    prod_pce_sample_factor = getattr(args, "production_pce_sample_factor", None)

    if production_config and invest_variants:
        v0 = invest_variants[0]
        try:
            n_ev, cores = _production_n_eval_and_cores(production_config, v0)
            if prod_n_eval is not None:
                n_ev = prod_n_eval
            if prod_cores is not None:
                cores = float(prod_cores)
            eval_cfg = production_config.evaluate.for_variant(v0)
            if prod_pce_order is None:
                prod_pce_order = int(getattr(eval_cfg, "pce_order", 2))
            if prod_pce_sample_factor is None:
                prod_pce_sample_factor = int(getattr(eval_cfg, "pce_sample_factor", 4))
            _do_extrapolation(
                aggregate,
                n_ev,
                cores,
                prod_pce_order,
                prod_pce_sample_factor,
            )
        except KeyError as exc:
            log.warning("Production config missing variant for extrapolation: %s. Skipping.", exc)
    elif prod_n_eval is not None and aggregate.core_hours_per_evaluation is not None:
        cores = float(prod_cores) if prod_cores is not None else 1.0
        po = prod_pce_order if prod_pce_order is not None else 2
        pf = prod_pce_sample_factor if prod_pce_sample_factor is not None else 4
        probe_cfg = aggregate.profiling_run_config or {}
        probe_po = int(probe_cfg.get("pce_order", 1))
        probe_pf = int(probe_cfg.get("pce_sample_factor", 1))
        _do_extrapolation(aggregate, prod_n_eval, cores, po, pf, probe_po, probe_pf)


def _do_extrapolation(
    aggregate: ResourceProfileResult,
    production_n_eval: int,
    production_cores: float,
    prod_pce_order: int,
    prod_pce_sample_factor: int,
    probe_pce_order: int | None = None,
    probe_pce_sample_factor: int | None = None,
) -> None:
    """Compute and set extrapolated core-hours and duration on aggregate."""
    if aggregate.core_hours_per_evaluation is None:
        return
    cfg = aggregate.profiling_run_config or {}
    if probe_pce_order is None:
        probe_pce_order = int(cfg.get("pce_order", 1))
    if probe_pce_sample_factor is None:
        probe_pce_sample_factor = int(cfg.get("pce_sample_factor", 1))
    cost_ratio = _compute_cost_ratio(
        probe_pce_order,
        probe_pce_sample_factor,
        prod_pce_order,
        prod_pce_sample_factor,
    )
    n_eval_this_run = max(1, cfg.get("n_eval", 1))
    extrapolated_core_hours = aggregate.core_hours_per_evaluation * (production_n_eval / n_eval_this_run) * cost_ratio
    aggregate.extrapolated_core_hours = round(extrapolated_core_hours, 6)
    aggregate.extrapolated_max_job_duration_hours = round(extrapolated_core_hours / max(1.0, production_cores), 6)
    aggregate.extrapolation_production_n_eval = production_n_eval
    aggregate.extrapolation_production_cores = production_cores
    aggregate.extrapolation_cost_ratio = round(cost_ratio, 6)


def _aggregate_results(results: list[ResourceProfileResult]) -> ResourceProfileResult:
    """Combine multiple variant results into one profile (e.g. for multi-variant run)."""
    if not results:
        return ResourceProfileResult(
            core_hours=0.0,
            max_job_duration_hours=0.0,
            n_software_codes=0,
        )
    if len(results) == 1:
        return results[0]
    total_core_hours = sum(r.core_hours for r in results)
    max_duration = max(r.max_job_duration_hours for r in results)
    all_categories: list[JobCategoryMetrics] = []
    for r in results:
        all_categories.extend(r.job_categories)
    peak_gb = None
    for r in results:
        if r.peak_memory_rss_gb is not None:
            peak_gb = r.peak_memory_rss_gb if peak_gb is None else max(peak_gb, r.peak_memory_rss_gb)
    return ResourceProfileResult(
        core_hours=round(total_core_hours, 6),
        max_job_duration_hours=round(max_duration, 6),
        n_software_codes=len(all_categories),
        job_categories=all_categories,
        elapsed_wall_seconds=round(sum(r.elapsed_wall_seconds for r in results), 2),
        effective_cores_used=max((r.effective_cores_used for r in results), default=1.0),
        peak_memory_rss_gb=round(peak_gb, 4) if peak_gb is not None else None,
    )


def _write_output(aggregate: ResourceProfileResult, output_dir: Path, single_eval: bool) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    suffix = "single_eval" if single_eval else "full"
    base = f"job_resource_profile_{suffix}_{timestamp}"

    json_path = output_dir / f"{base}.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(aggregate.to_dict(), f, indent=2)

    txt_path = output_dir / f"{base}.txt"
    lines = [
        "Job resource profile (production sizing)",
        "========================================",
        "",
        f"Compute time (core-hours):     {aggregate.core_hours}",
        f"Max job duration (hours):     {aggregate.max_job_duration_hours}",
        f"Number of software codes:     {aggregate.n_software_codes}",
        f"Elapsed wall time (s):       {aggregate.elapsed_wall_seconds}",
        f"Effective cores used:         {aggregate.effective_cores_used}",
        (
            f"Peak memory RSS (GB):         {aggregate.peak_memory_rss_gb}"
            if aggregate.peak_memory_rss_gb is not None
            else "Peak memory RSS (GB):         N/A"
        ),
        "",
        "Job categorization (per variant):",
    ]
    for c in aggregate.job_categories:
        mem = f"{c.max_memory_per_core_gb} GB" if c.max_memory_per_core_gb is not None else "N/A"
        lines.append(
            f"  {c.variant}: max_simultaneous_jobs={c.max_simultaneous_jobs}, "
            f"max_memory_per_core={mem}, typical_cores={c.typical_cores_per_job}, max_cores={c.max_cores_per_job}"
        )
    if aggregate.core_hours_per_evaluation is not None:
        lines.extend(
            [
                "",
                "Probe run (per-evaluation metrics):",
                f"  Core-hours per evaluation:   {aggregate.core_hours_per_evaluation}",
            ]
        )
    if aggregate.profiling_run_config:
        lines.append("  Profiling run config:")
        for k, v in aggregate.profiling_run_config.items():
            lines.append(f"    {k}: {v}")
    if aggregate.extrapolated_core_hours is not None and aggregate.extrapolated_max_job_duration_hours is not None:
        lines.extend(
            [
                "",
                "Extrapolation to production:",
                f"  Extrapolated core-hours:     {aggregate.extrapolated_core_hours}",
                f"  Extrapolated max duration (h): {aggregate.extrapolated_max_job_duration_hours}",
                f"  Production n_eval:           {aggregate.extrapolation_production_n_eval}",
                f"  Production cores:            {aggregate.extrapolation_production_cores}",
                f"  Cost ratio (PCE scaling):   {aggregate.extrapolation_cost_ratio}",
                "  (Duration = extrapolated_core_hours / production_cores.)",
            ]
        )
    with txt_path.open("w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    log.info("Job resource profile JSON: %s", json_path)
    log.info("Job resource profile summary: %s", txt_path)


def _collect_invest_variants(experiment: EtaIncerto, variants: list[str]) -> list[str]:
    """Filter to invest-only variants; skip dispatch-only."""
    invest_variants = []
    for v in variants:
        pdef = experiment.config.pymoo.for_variant(v)
        if getattr(pdef, "mode", "invest") == "dispatch":
            log.warning("Skipping dispatch-only variant '%s'.", v)
            continue
        invest_variants.append(v)
    return invest_variants


def _run_profiling_loop(
    experiment: EtaIncerto,
    invest_variants: list[str],
    args: argparse.Namespace,
    sample_memory: bool,
) -> list[ResourceProfileResult]:
    """Apply config overrides and run single-eval or full optimization per variant."""
    results: list[ResourceProfileResult] = []
    for variant in invest_variants:
        if args.extrapolate:
            _apply_probe_overrides(experiment.config, variant)
        else:
            _apply_fast_solver_for_profiling(experiment.config, variant)
            if args.min_runtime:
                _apply_min_runtime(experiment.config, variant)
        if args.single_eval:
            results.append(_run_single_eval(experiment, variant, sample_memory))
        else:
            results.append(_run_full_optimization(experiment, variant, sample_memory))
    return results


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _parse_args()

    config_path = _resolve_config_path(args.config)
    root_path = config_path.parent
    experiment = EtaIncerto(root_path, config_path.name, relpath_config=".")

    output_dir = (
        Path(args.output_dir) if args.output_dir else Path(experiment.config.paths.results_dir) / "job_profiles"
    )

    variants = args.variant or list(experiment.config.system.variant)
    if args.variant_module:
        _import_variant_modules(args.variant_module)
    else:
        _maybe_import_example_variants(config_path, variants)

    invest_variants = _collect_invest_variants(experiment, variants)
    if not invest_variants:
        log.error("No invest variants to profile.")
        sys.exit(1)

    sample_memory = not args.no_memory_sampling
    if sample_memory and not psutil:
        log.warning("psutil not installed; memory metrics will be N/A. Install with: pip install psutil")

    if args.extrapolate:
        args.single_eval = True

    results = _run_profiling_loop(experiment, invest_variants, args, sample_memory)
    aggregate = _aggregate_results(results)
    _enrich_aggregate(aggregate, experiment, invest_variants, args.single_eval, args)
    _write_output(aggregate, output_dir, args.single_eval)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log.exception("Job resource profiling failed.")
        sys.exit(1)
