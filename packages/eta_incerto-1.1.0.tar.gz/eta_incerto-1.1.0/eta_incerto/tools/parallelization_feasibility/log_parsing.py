from __future__ import annotations

import re
from pathlib import Path

_SOLVE_S_PATTERN = re.compile(r"solve_s=(?P<value>\d+(?:\.\d+)?)")
_NODES_PATTERN = re.compile(r"Explored\s+(?P<nodes>\d+)\s+nodes")
_GAP_PATTERN = re.compile(r"gap\s+(?P<gap>\d+(?:\.\d+)?)%")

_SOLVER_THREADS_SET_PATTERN = re.compile(r"Set parameter Threads to value (?P<threads>\d+)")
_SOLVER_THREADS_USED_PATTERN = re.compile(r"Thread count was (?P<threads>\d+)")
_SOLVER_THREADS_UP_TO_PATTERN = re.compile(r"using up to (?P<threads>\d+) threads")


def _read_text(log_path: Path) -> str:
    if not log_path.exists():
        return ""
    return log_path.read_text(encoding="utf-8", errors="ignore")


def parse_solve_times_from_log(log_path: Path) -> list[float]:
    text = _read_text(log_path)
    values: list[float] = []

    for match in _SOLVE_S_PATTERN.finditer(text):
        try:
            values.append(float(match.group("value")))
        except (TypeError, ValueError):
            continue

    return values


def parse_nodes_from_log(log_path: Path) -> list[int]:
    text = _read_text(log_path)
    values: list[int] = []

    for match in _NODES_PATTERN.finditer(text):
        try:
            values.append(int(match.group("nodes")))
        except (TypeError, ValueError):
            continue

    return values


def parse_gap_percent_from_log(log_path: Path) -> list[float]:
    text = _read_text(log_path)
    values: list[float] = []

    for match in _GAP_PATTERN.finditer(text):
        try:
            values.append(float(match.group("gap")))
        except (TypeError, ValueError):
            continue

    return values


def parse_solver_threads_from_log(log_path: Path) -> list[int]:
    text = _read_text(log_path)
    values: list[int] = []

    for pattern in (
        _SOLVER_THREADS_USED_PATTERN,
        _SOLVER_THREADS_SET_PATTERN,
        _SOLVER_THREADS_UP_TO_PATTERN,
    ):
        for match in pattern.finditer(text):
            try:
                values.append(int(match.group("threads")))
            except (TypeError, ValueError):
                continue

    return values
