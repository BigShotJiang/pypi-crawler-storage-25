from __future__ import annotations

import threading
import time

import psutil

from eta_incerto.tools.parallelization_feasibility.datastructures import ResourceSample


class ResourceMonitor:
    def __init__(
        self,
        root_pid: int,
        sample_interval_s: float = 0.5,
    ) -> None:
        self.root_pid = root_pid
        self.sample_interval_s = sample_interval_s
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._samples: list[ResourceSample] = []

    def start(self) -> None:
        if self._thread is not None:
            return

        try:
            psutil.cpu_percent(interval=None)
        except Exception:
            pass

        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> list[ResourceSample]:
        self._stop_event.set()

        if self._thread is not None:
            self._thread.join(timeout=max(1.0, self.sample_interval_s * 4))
            self._thread = None

        return list(self._samples)

    def _run(self) -> None:
        while not self._stop_event.is_set():
            self._samples.append(self._sample_once())
            self._stop_event.wait(self.sample_interval_s)

    def _sample_once(self) -> ResourceSample:
        timestamp = time.time()
        cpu_percent = self._safe_cpu_percent()

        processes = self._collect_process_tree()
        memory_rss_mb = 0.0
        active_threads_total = 0
        max_threads_per_process = 0

        for process in processes:
            try:
                memory_rss_mb += process.memory_info().rss / (1024 * 1024)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

            try:
                thread_count = process.num_threads()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                thread_count = 0

            active_threads_total += thread_count
            max_threads_per_process = max(max_threads_per_process, thread_count)

        return ResourceSample(
            timestamp=timestamp,
            cpu_percent=cpu_percent,
            memory_rss_mb=memory_rss_mb,
            active_processes=len(processes),
            active_threads_total=active_threads_total,
            max_threads_per_process=max_threads_per_process,
        )

    def _collect_process_tree(self) -> list[psutil.Process]:
        try:
            root = psutil.Process(self.root_pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return []

        processes: list[psutil.Process] = []
        seen: set[int] = set()

        candidates = [root]
        try:
            candidates.extend(root.children(recursive=True))
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

        for process in candidates:
            try:
                pid = process.pid
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

            if pid in seen:
                continue

            seen.add(pid)
            processes.append(process)

        return processes

    @staticmethod
    def _safe_cpu_percent() -> float:
        try:
            return float(psutil.cpu_percent(interval=None))
        except Exception:
            return 0.0
