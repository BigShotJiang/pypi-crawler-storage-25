from __future__ import annotations

from eta_incerto.tools.parallelization_feasibility.datastructures import BenchmarkCase


def make_benchmark_case(
    *,
    processes: int,
    threads_per_process: int,
    repetition: int = 1,
    label: str | None = None,
) -> BenchmarkCase:
    if processes < 1:
        raise ValueError("processes must be >= 1.")
    if threads_per_process < 1:
        raise ValueError("threads_per_process must be >= 1.")
    if repetition < 1:
        raise ValueError("repetition must be >= 1.")

    resolved_label = label
    if resolved_label is None:
        if processes == 1:
            resolved_label = (
                "sequential_baseline"
                if threads_per_process == 1
                else f"sequential_p{processes:02d}_t{threads_per_process:02d}"
            )
        else:
            resolved_label = f"parallel_p{processes:02d}_t{threads_per_process:02d}"

    return BenchmarkCase(
        processes=processes,
        threads_per_process=threads_per_process,
        repetition=repetition,
        label=resolved_label,
    )


def build_benchmark_cases(
    *,
    process_values: list[int],
    thread_values: list[int],
    repetition_values: list[int] | None = None,
    include_sequential: bool = True,
    include_parallel: bool = True,
    max_total_threads: int | None = None,
) -> list[BenchmarkCase]:
    """
    Build a benchmark matrix from arbitrary process/thread/repetition values.

    Parameters
    ----------
    process_values:
        Candidate Python process counts.
    thread_values:
        Candidate solver thread counts per process.
    repetition_values:
        Candidate repetition indices. Defaults to [1].
    include_sequential:
        Whether to include cases with processes == 1.
    include_parallel:
        Whether to include cases with processes > 1.
    max_total_threads:
        Optional upper bound for processes * threads_per_process.
        Useful to avoid oversubscription on local machines or to match HPC limits.
    """
    if repetition_values is None:
        repetition_values = [1]

    cases: list[BenchmarkCase] = []
    seen: set[tuple[int, int, int]] = set()

    for processes in process_values:
        for threads_per_process in thread_values:
            for repetition in repetition_values:
                if processes < 1 or threads_per_process < 1 or repetition < 1:
                    continue

                if processes == 1 and not include_sequential:
                    continue

                if processes > 1 and not include_parallel:
                    continue

                total_threads = processes * threads_per_process
                if max_total_threads is not None and total_threads > max_total_threads:
                    continue

                key = (processes, threads_per_process, repetition)
                if key in seen:
                    continue
                seen.add(key)

                cases.append(
                    make_benchmark_case(
                        processes=processes,
                        threads_per_process=threads_per_process,
                        repetition=repetition,
                    )
                )

    cases.sort(
        key=lambda case: (
            case.processes,
            case.threads_per_process,
            case.repetition,
        )
    )
    return cases


def get_sequential_baseline_case(repetition: int = 1) -> BenchmarkCase:
    return make_benchmark_case(
        processes=1,
        threads_per_process=1,
        repetition=repetition,
        label="sequential_baseline",
    )


def get_default_local_cases(repetition: int = 1) -> list[BenchmarkCase]:
    """
    Small default matrix for local feasibility checks.
    """
    return build_benchmark_cases(
        process_values=[1, 2, 4],
        thread_values=[1, 2, 4],
        repetition_values=[repetition],
        include_sequential=True,
        include_parallel=True,
        max_total_threads=8,
    )


def get_default_hpc_cases(
    *,
    max_processes: int = 8,
    max_threads_per_process: int = 8,
    repetition: int = 1,
    max_total_threads: int | None = None,
) -> list[BenchmarkCase]:
    """
    Broader default matrix for HPC-oriented scaling studies.
    """
    return build_benchmark_cases(
        process_values=list(range(1, max_processes + 1)),
        thread_values=list(range(1, max_threads_per_process + 1)),
        repetition_values=[repetition],
        include_sequential=True,
        include_parallel=True,
        max_total_threads=max_total_threads,
    )
