from __future__ import annotations

import logging
import multiprocessing as mp
import os
import queue
import socket
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

import examples.conventional.variants.variant_one.system
import examples.conventional.variants.variant_two.system
import examples.conventional.variants.variant_zero.system  # noqa: F401
from eta_incerto.core import EtaIncerto
from eta_incerto.envs.regret_evaluation import RegretEvaluator
from eta_incerto.envs.robust_evaluation import RobustEvaluator
from eta_incerto.envs.stochastic_evaluation import StochasticEvaluator
from eta_incerto.tools.parallelization_feasibility.datastructures import (
    BenchmarkCase,
    BenchmarkRunResult,
    ModuleRunResult,
)
from eta_incerto.tools.parallelization_feasibility.log_parsing import (
    parse_gap_percent_from_log,
    parse_nodes_from_log,
    parse_solve_times_from_log,
    parse_solver_threads_from_log,
)

VALID_MODULES = ("stochastic", "regret", "robust")


def _set_thread_environment(threads_per_process: int) -> None:
    value = str(threads_per_process)
    for env_name in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
    ):
        os.environ[env_name] = value


def _execution_base_dir(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> Path:
    return (
        run_dir
        / "parallelization_feasibility"
        / "execution"
        / (
            f"p{benchmark_case.processes:02d}"
            f"_t{benchmark_case.threads_per_process:02d}"
            f"_r{benchmark_case.repetition:02d}"
        )
        / module_name
    )


def _log_file_path(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> Path:
    return _execution_base_dir(run_dir, benchmark_case, module_name) / "execution.log"


def _configure_experiment_for_benchmark(
    experiment: EtaIncerto,
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> None:
    solver_settings = experiment.config.pyomo.solver_settings
    options = getattr(solver_settings, "options", None)

    if options is None:
        solver_settings.options = {}
        options = solver_settings.options

    if isinstance(options, dict):
        options["threads"] = benchmark_case.threads_per_process

    execution_results_dir = (
        _execution_base_dir(
            run_dir=run_dir,
            benchmark_case=benchmark_case,
            module_name=module_name,
        )
        / "results"
    )
    experiment.config.paths.results_dir = str(execution_results_dir)


def _extract_stats_from_framework(fw: Any) -> dict[str, Any]:
    bundle = getattr(fw, "_results_bundle", None)
    if bundle is None:
        return {}

    solve_info = getattr(bundle, "solve_info", None)
    if solve_info is None:
        return {}

    stats: dict[str, Any] = {}

    if getattr(solve_info, "objective_value", None) is not None:
        try:
            stats["objective_value"] = float(solve_info.objective_value)
        except (TypeError, ValueError):
            pass

    if getattr(solve_info, "status", None) is not None:
        stats["status"] = str(solve_info.status)

    if getattr(solve_info, "runtime_s", None) is not None:
        try:
            stats["runtime_s"] = float(solve_info.runtime_s)
        except (TypeError, ValueError):
            pass

    if getattr(solve_info, "solver", None) is not None:
        stats["solver"] = str(solve_info.solver)

    if getattr(solve_info, "termination_condition", None) is not None:
        stats["termination_condition"] = str(solve_info.termination_condition)

    effective_options = getattr(solve_info, "effective_options", None)
    if effective_options is not None:
        stats["effective_options"] = effective_options

    return stats


@contextmanager
def _capture_logs_to_file(log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)

    root_logger.addHandler(file_handler)
    try:
        yield
    finally:
        root_logger.removeHandler(file_handler)
        file_handler.close()


def _summarize_solve_times(solve_times_s: list[float]) -> tuple[int, float | None, float | None, float | None]:
    if not solve_times_s:
        return 0, None, None, None

    solve_count = len(solve_times_s)
    solve_time_mean_s = sum(solve_times_s) / solve_count
    solve_time_max_s = max(solve_times_s)
    solve_time_min_s = min(solve_times_s)
    return solve_count, solve_time_mean_s, solve_time_max_s, solve_time_min_s


def _run_stochastic_module(
    experiment: EtaIncerto,
) -> dict[str, Any]:
    last_stats: dict[str, Any] = {}

    for variant in experiment.config.system.variant:
        h5_file_name = f"stochastic_{variant}.h5"
        _, stochastic_invest_scenarios = experiment.load_stochastic_system_series_scenario(variant)
        evaluator = StochasticEvaluator(
            config=experiment.config,
            scenarios=stochastic_invest_scenarios,
            h5_file_name=h5_file_name,
            variant_name=variant,
        )
        _, fw = evaluator.evaluate_systems()
        last_stats = _extract_stats_from_framework(fw)

    return last_stats


def _run_regret_module(
    experiment: EtaIncerto,
) -> dict[str, Any]:
    last_stats: dict[str, Any] = {}

    for variant in experiment.config.system.variant:
        h5_file_name = f"regret_{variant}.h5"
        _, stochastic_invest_scenarios = experiment.load_stochastic_system_series_scenario(variant)
        evaluator = RegretEvaluator(
            config=experiment.config,
            scenarios=stochastic_invest_scenarios,
            h5_file_name=h5_file_name,
            variant_name=variant,
        )
        _, fw = evaluator.evaluate_systems()
        last_stats = _extract_stats_from_framework(fw)

    return last_stats


def _run_robust_module(
    experiment: EtaIncerto,
) -> dict[str, Any]:
    last_stats: dict[str, Any] = {}

    for variant in experiment.config.system.variant:
        h5_file_name = f"robust_{variant}.h5"
        _, stochastic_invest_scenarios = experiment.load_stochastic_system_series_scenario(variant)
        evaluator = RobustEvaluator(
            config=experiment.config,
            scenarios=stochastic_invest_scenarios,
            h5_file_name=h5_file_name,
            variant_name=variant,
        )
        _, fw = evaluator.evaluate_systems()
        last_stats = _extract_stats_from_framework(fw)

    return last_stats


def _run_experiment_module(
    experiment: EtaIncerto,
    module_name: str,
) -> dict[str, Any]:
    if module_name == "stochastic":
        return _run_stochastic_module(experiment)
    if module_name == "regret":
        return _run_regret_module(experiment)
    if module_name == "robust":
        return _run_robust_module(experiment)

    raise ValueError(f"Unsupported module_name '{module_name}'. Expected one of: {', '.join(VALID_MODULES)}.")


def _run_single_module_in_current_process(
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
) -> ModuleRunResult:
    _set_thread_environment(benchmark_case.threads_per_process)

    started = time.perf_counter()
    log_path = _log_file_path(run_dir, benchmark_case, module_name)

    try:
        with _capture_logs_to_file(log_path):
            experiment = EtaIncerto(run_dir, config_name, relpath_config=".")
            _configure_experiment_for_benchmark(
                experiment=experiment,
                run_dir=run_dir,
                benchmark_case=benchmark_case,
                module_name=module_name,
            )

            stats = _run_experiment_module(experiment, module_name)

        wall_time_s = time.perf_counter() - started
        stats = stats or {}

        solver_runtime_s = None
        if stats.get("runtime_s") is not None:
            solver_runtime_s = float(stats["runtime_s"])

        objective_value = None
        if stats.get("objective_value") is not None:
            objective_value = float(stats["objective_value"])

        status = None
        if stats.get("status") is not None:
            status = str(stats["status"])

        termination_condition = None
        if stats.get("termination_condition") is not None:
            termination_condition = str(stats["termination_condition"])

        solver_name = None
        if stats.get("solver") is not None:
            solver_name = str(stats["solver"])

        effective_options = None
        if isinstance(stats.get("effective_options"), dict):
            effective_options = stats["effective_options"]

        solve_times_s = parse_solve_times_from_log(log_path)
        nodes_all = parse_nodes_from_log(log_path)
        best_gap_percent_all = parse_gap_percent_from_log(log_path)
        solver_threads_all = parse_solver_threads_from_log(log_path)

        solve_count, solve_time_mean_s, solve_time_max_s, solve_time_min_s = _summarize_solve_times(solve_times_s)

        solver_threads_max = max(solver_threads_all) if solver_threads_all else None

        solver_threads_configured = None
        if isinstance(effective_options, dict):
            normalized = effective_options.get("normalized")
            if isinstance(normalized, dict) and normalized.get("threads") is not None:
                try:
                    solver_threads_configured = int(normalized["threads"])
                except (TypeError, ValueError):
                    solver_threads_configured = None

        if status is None:
            status = "ok"

        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=solver_runtime_s,
            status=status,
            termination_condition=termination_condition,
            solver_name=solver_name,
            objective_value=objective_value,
            solve_count=solve_count,
            solve_times_s=solve_times_s,
            solve_time_mean_s=solve_time_mean_s,
            solve_time_max_s=solve_time_max_s,
            solve_time_min_s=solve_time_min_s,
            nodes_all=nodes_all,
            best_gap_percent_all=best_gap_percent_all,
            solver_threads_all=solver_threads_all,
            solver_threads_max=solver_threads_max,
            solver_threads_configured=solver_threads_configured,
            log_path=str(log_path),
            solver_stats_raw=stats,
            effective_options=effective_options,
            timed_out=False,
            timeout_s=None,
            error_message=None,
        )

    except Exception as exc:
        wall_time_s = time.perf_counter() - started
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="error",
            termination_condition=None,
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(log_path),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=False,
            timeout_s=None,
            error_message=f"{type(exc).__name__}: {exc}",
        )


def _module_runner_entrypoint(
    result_queue: mp.Queue,
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
) -> None:
    result = _run_single_module_in_current_process(
        run_dir=run_dir,
        config_name=config_name,
        module_name=module_name,
        benchmark_case=benchmark_case,
    )
    result_queue.put(result)


def run_single_module_benchmark(
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
    timeout_s: float | None = None,
) -> ModuleRunResult:
    if timeout_s is None:
        return _run_single_module_in_current_process(
            run_dir=run_dir,
            config_name=config_name,
            module_name=module_name,
            benchmark_case=benchmark_case,
        )

    ctx = mp.get_context("spawn")
    result_queue: mp.Queue = ctx.Queue()
    process = ctx.Process(
        target=_module_runner_entrypoint,
        args=(result_queue, run_dir, config_name, module_name, benchmark_case),
    )

    started = time.perf_counter()
    process.start()
    process.join(timeout=timeout_s)

    if process.is_alive():
        process.terminate()
        process.join()

        wall_time_s = time.perf_counter() - started
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="timeout",
            termination_condition="timeout",
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(_log_file_path(run_dir, benchmark_case, module_name)),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=True,
            timeout_s=timeout_s,
            error_message=f"Module run exceeded timeout of {timeout_s} s.",
        )

    wall_time_s = time.perf_counter() - started

    try:
        result = result_queue.get_nowait()
    except queue.Empty:
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="error",
            termination_condition=None,
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(_log_file_path(run_dir, benchmark_case, module_name)),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=False,
            timeout_s=timeout_s,
            error_message="Module process finished without returning a result.",
        )

    result.wall_time_s = wall_time_s
    result.timeout_s = timeout_s
    return result


def create_benchmark_run_result(
    benchmark_case: BenchmarkCase,
    config_name: str,
    run_dir: Path,
    module_results: list[ModuleRunResult],
    resource_samples,
    started_at: datetime,
    finished_at: datetime,
) -> BenchmarkRunResult:
    total_wall_time_s = (finished_at - started_at).total_seconds()

    return BenchmarkRunResult(
        benchmark_case=benchmark_case,
        config_name=config_name,
        run_dir=run_dir,
        module_results=module_results,
        resource_samples=list(resource_samples),
        started_at=started_at,
        finished_at=finished_at,
        hostname=socket.gethostname(),
        total_wall_time_s=total_wall_time_s,
    )
