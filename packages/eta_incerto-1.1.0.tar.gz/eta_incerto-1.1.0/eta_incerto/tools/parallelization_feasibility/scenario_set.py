from __future__ import annotations

import json
from pathlib import Path

from eta_incerto.tools.parallelization_feasibility.datastructures import ScenarioCase
from eta_incerto.tools.parallelization_feasibility.paths import get_pf_root

SCENARIO_SET_FILENAME = "scenario_set.json"


def get_scenario_set_path(run_dir: Path) -> Path:
    return get_pf_root(run_dir) / SCENARIO_SET_FILENAME


def load_scenario_set(run_dir: Path) -> list[ScenarioCase]:
    """
    Load the scenario set definition from
    <run_dir>/parallelization_feasibility/scenario_set.json.

    Expected JSON structure:
    [
      {
        "scenario_id": "scenario_01",
        "source_path": "relative/or/absolute/path/to/file.csv",
        "description": "optional text"
      }
    ]
    """
    scenario_set_path = get_scenario_set_path(run_dir)

    if not scenario_set_path.exists():
        raise FileNotFoundError(
            f"Scenario set file not found: {scenario_set_path}. "
            "Create parallelization_feasibility/scenario_set.json first."
        )

    with scenario_set_path.open("r", encoding="utf-8") as file:
        payload = json.load(file)

    if not isinstance(payload, list):
        raise ValueError(f"Scenario set must be a JSON list, got {type(payload).__name__}.")

    scenarios: list[ScenarioCase] = []
    seen_ids: set[str] = set()

    for index, entry in enumerate(payload):
        if not isinstance(entry, dict):
            raise ValueError(f"Scenario entry at index {index} must be a JSON object, got {type(entry).__name__}.")

        scenario_id = entry.get("scenario_id")
        source_path_raw = entry.get("source_path")
        description = entry.get("description")

        if not scenario_id or not isinstance(scenario_id, str):
            raise ValueError(f"Scenario entry at index {index} is missing a valid 'scenario_id'.")

        if scenario_id in seen_ids:
            raise ValueError(f"Duplicate scenario_id detected: {scenario_id}")
        seen_ids.add(scenario_id)

        if not source_path_raw or not isinstance(source_path_raw, str):
            raise ValueError(f"Scenario '{scenario_id}' is missing a valid 'source_path'.")

        source_path = Path(source_path_raw)
        if not source_path.is_absolute():
            source_path = run_dir / source_path

        if not source_path.exists():
            raise FileNotFoundError(f"Scenario '{scenario_id}' references missing file: {source_path}")

        if description is not None and not isinstance(description, str):
            raise ValueError(f"Scenario '{scenario_id}' has non-string 'description'.")

        scenarios.append(
            ScenarioCase(
                scenario_id=scenario_id,
                source_path=source_path.resolve(),
                description=description,
            )
        )

    if not scenarios:
        raise ValueError(f"No scenarios found in {scenario_set_path}.")

    return scenarios


def write_example_scenario_set(run_dir: Path, overwrite: bool = False) -> Path:
    """
    Write a minimal example scenario set file if none exists yet.
    """
    scenario_set_path = get_scenario_set_path(run_dir)

    if scenario_set_path.exists() and not overwrite:
        raise FileExistsError(f"Scenario set already exists: {scenario_set_path}. Use overwrite=True to replace it.")

    example_payload = [
        {
            "scenario_id": "scenario_01",
            "source_path": "scenarios/scenario_01.csv",
            "description": "Example scenario placeholder.",
        }
    ]

    scenario_set_path.parent.mkdir(parents=True, exist_ok=True)
    with scenario_set_path.open("w", encoding="utf-8") as file:
        json.dump(example_payload, file, indent=2)

    return scenario_set_path
