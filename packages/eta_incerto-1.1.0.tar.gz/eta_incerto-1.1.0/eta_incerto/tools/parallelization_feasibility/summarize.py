from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from eta_incerto.tools.parallelization_feasibility.paths import (
    get_raw_dir,
    get_summaries_dir,
)


def _load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as file:
        return json.load(file)


def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _safe_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _module_result_by_name(payload: dict[str, Any], module_name: str) -> dict[str, Any] | None:
    for module_result in payload.get("module_results", []):
        if module_result.get("module_name") == module_name:
            return module_result
    return None


def _all_module_names(payloads: list[dict[str, Any]]) -> list[str]:
    names: set[str] = set()
    for payload in payloads:
        for module_result in payload.get("module_results", []):
            module_name = module_result.get("module_name")
            if isinstance(module_name, str):
                names.add(module_name)
    return sorted(names)


def _overall_status(payload: dict[str, Any]) -> str:
    statuses = []
    for module_result in payload.get("module_results", []):
        status = module_result.get("status")
        if status is not None:
            statuses.append(str(status))

    if not statuses:
        return "unknown"

    if all(status == "ok" for status in statuses):
        return "ok"

    return "error"


def _baseline_total_wall_time(rows: list[dict[str, Any]]) -> float | None:
    baseline_candidates = [
        row
        for row in rows
        if row["processes"] == 1
        and row["threads_per_process"] == 1
        and row["repetition"] == 1
        and row["total_wall_time_s"] is not None
        and row["overall_status"] == "ok"
        and row["is_comparable_full_run"]
    ]
    if not baseline_candidates:
        return None
    return baseline_candidates[0]["total_wall_time_s"]


def _mean(values: list[float]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


def _resource_summary(payload: dict[str, Any]) -> dict[str, float | int | None]:
    resource_samples = payload.get("resource_samples", [])

    cpu_values: list[float] = []
    memory_values: list[float] = []
    active_processes_values: list[int] = []
    active_threads_values: list[int] = []
    max_threads_per_process_values: list[int] = []

    for sample in resource_samples:
        cpu = _safe_float(sample.get("cpu_percent"))
        memory = _safe_float(sample.get("memory_rss_mb"))
        active_processes = _safe_int(sample.get("active_processes"))
        active_threads_total = _safe_int(sample.get("active_threads_total"))
        max_threads_per_process = _safe_int(sample.get("max_threads_per_process"))

        if cpu is not None:
            cpu_values.append(cpu)
        if memory is not None:
            memory_values.append(memory)
        if active_processes is not None:
            active_processes_values.append(active_processes)
        if active_threads_total is not None:
            active_threads_values.append(active_threads_total)
        if max_threads_per_process is not None:
            max_threads_per_process_values.append(max_threads_per_process)

    return {
        "resource_sample_count": len(resource_samples),
        "avg_cpu_percent": _mean(cpu_values),
        "max_cpu_percent": max(cpu_values) if cpu_values else None,
        "avg_memory_rss_mb": _mean(memory_values),
        "max_memory_rss_mb": max(memory_values) if memory_values else None,
        "max_active_processes": max(active_processes_values) if active_processes_values else None,
        "max_active_threads_total": max(active_threads_values) if active_threads_values else None,
        "max_threads_per_process": max(max_threads_per_process_values) if max_threads_per_process_values else None,
    }


def _has_full_module_coverage(payload: dict[str, Any], module_names: list[str]) -> bool:
    if not module_names:
        return False

    for module_name in module_names:
        module_result = _module_result_by_name(payload, module_name)
        if module_result is None:
            return False
        if module_result.get("status") is None:
            return False

    return True


def _build_summary_rows(payloads: list[dict[str, Any]]) -> list[dict[str, Any]]:
    module_names = _all_module_names(payloads)
    rows: list[dict[str, Any]] = []

    for payload in payloads:
        benchmark_case = payload.get("benchmark_case", {})
        resource_summary = _resource_summary(payload)
        is_comparable_full_run = (
            _has_full_module_coverage(payload, module_names) and _safe_int(benchmark_case.get("repetition")) == 1
        )

        row: dict[str, Any] = {
            "file_name": payload.get("_file_name"),
            "processes": _safe_int(benchmark_case.get("processes")),
            "threads_per_process": _safe_int(benchmark_case.get("threads_per_process")),
            "repetition": _safe_int(benchmark_case.get("repetition")),
            "label": benchmark_case.get("label"),
            "total_wall_time_s": _safe_float(payload.get("total_wall_time_s")),
            "overall_status": _overall_status(payload),
            "is_comparable_full_run": is_comparable_full_run,
            **resource_summary,
        }

        for module_name in module_names:
            module_result = _module_result_by_name(payload, module_name)
            prefix = module_name.lower()

            row[f"{prefix}_status"] = None if module_result is None else module_result.get("status")
            row[f"{prefix}_wall_time_s"] = (
                None if module_result is None else _safe_float(module_result.get("wall_time_s"))
            )
            row[f"{prefix}_solver_runtime_s"] = (
                None if module_result is None else _safe_float(module_result.get("solver_runtime_s"))
            )
            row[f"{prefix}_objective_value"] = (
                None if module_result is None else _safe_float(module_result.get("objective_value"))
            )
            row[f"{prefix}_termination_condition"] = (
                None if module_result is None else module_result.get("termination_condition")
            )
            row[f"{prefix}_solver_name"] = None if module_result is None else module_result.get("solver_name")
            row[f"{prefix}_solve_count"] = (
                None if module_result is None else _safe_int(module_result.get("solve_count"))
            )
            row[f"{prefix}_solve_time_mean_s"] = (
                None if module_result is None else _safe_float(module_result.get("solve_time_mean_s"))
            )
            row[f"{prefix}_solve_time_max_s"] = (
                None if module_result is None else _safe_float(module_result.get("solve_time_max_s"))
            )
            row[f"{prefix}_solve_time_min_s"] = (
                None if module_result is None else _safe_float(module_result.get("solve_time_min_s"))
            )
            row[f"{prefix}_solver_threads_max"] = (
                None if module_result is None else _safe_int(module_result.get("solver_threads_max"))
            )
            row[f"{prefix}_solver_threads_configured"] = (
                None if module_result is None else _safe_int(module_result.get("solver_threads_configured"))
            )

        rows.append(row)

    baseline = _baseline_total_wall_time(rows)

    for row in rows:
        total_wall_time_s = row["total_wall_time_s"]
        if baseline is None or total_wall_time_s is None or total_wall_time_s <= 0:
            row["speedup_vs_1x1"] = None
        else:
            row["speedup_vs_1x1"] = baseline / total_wall_time_s

    rows.sort(
        key=lambda row: (
            not row["is_comparable_full_run"],
            row["total_wall_time_s"] is None,
            row["total_wall_time_s"] if row["total_wall_time_s"] is not None else float("inf"),
        )
    )
    return rows


def _write_summary_json(summary_dir: Path, rows: list[dict[str, Any]]) -> Path:
    output_path = summary_dir / "benchmark_summary.json"
    with output_path.open("w", encoding="utf-8") as file:
        json.dump(rows, file, indent=2)
    return output_path


def _write_summary_csv(summary_dir: Path, rows: list[dict[str, Any]]) -> Path:
    output_path = summary_dir / "benchmark_summary.csv"
    if not rows:
        with output_path.open("w", encoding="utf-8", newline="") as file:
            file.write("")
        return output_path

    fieldnames = list(rows[0].keys())
    with output_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return output_path


def _format_float(value: Any, digits: int = 2) -> str:
    if value is None:
        return "-"
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return str(value)


def _best_row(rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    valid_rows = [
        row
        for row in rows
        if row.get("overall_status") == "ok"
        and row.get("total_wall_time_s") is not None
        and row.get("is_comparable_full_run")
    ]
    if not valid_rows:
        return None
    return min(valid_rows, key=lambda row: row["total_wall_time_s"])


def _write_summary_md(summary_dir: Path, rows: list[dict[str, Any]]) -> Path:
    output_path = summary_dir / "benchmark_summary.md"

    lines: list[str] = []
    lines.append("# Parallelization feasibility benchmark summary")
    lines.append("")

    best = _best_row(rows)
    if best is not None:
        lines.append("## Best comparable full-run configuration")
        lines.append("")
        lines.append(f"- Processes: {best['processes']}")
        lines.append(f"- Threads per process: {best['threads_per_process']}")
        lines.append(f"- Repetition: {best['repetition']}")
        lines.append(f"- Total wall time [s]: {_format_float(best['total_wall_time_s'])}")
        lines.append(f"- Speedup vs 1x1: {_format_float(best['speedup_vs_1x1'])}")
        lines.append(f"- Max active processes: {_format_float(best['max_active_processes'], 0)}")
        lines.append(f"- Max active threads total: {_format_float(best['max_active_threads_total'], 0)}")
        lines.append(f"- Max threads per process: {_format_float(best['max_threads_per_process'], 0)}")
        lines.append(f"- Avg CPU percent: {_format_float(best['avg_cpu_percent'])}")
        lines.append(f"- Max memory RSS [MB]: {_format_float(best['max_memory_rss_mb'])}")
        lines.append("")

    lines.append("## Comparable full runs")
    lines.append("")
    lines.append(
        "| File | P | T | Rep | Total [s] | Speedup vs 1x1 | Max proc | "
        "Max threads | Max threads/proc | Avg CPU [%] | Max RAM [MB] | Status |"
    )
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")

    for row in rows:
        if not row["is_comparable_full_run"]:
            continue

        lines.append(
            "| "
            f"{row['file_name']} | "
            f"{row['processes']} | "
            f"{row['threads_per_process']} | "
            f"{row['repetition']} | "
            f"{_format_float(row['total_wall_time_s'])} | "
            f"{_format_float(row['speedup_vs_1x1'])} | "
            f"{_format_float(row['max_active_processes'], 0)} | "
            f"{_format_float(row['max_active_threads_total'], 0)} | "
            f"{_format_float(row['max_threads_per_process'], 0)} | "
            f"{_format_float(row['avg_cpu_percent'])} | "
            f"{_format_float(row['max_memory_rss_mb'])} | "
            f"{row['overall_status']} |"
        )

    lines.append("")
    lines.append("## Additional runs (non-comparable or partial)")
    lines.append("")
    lines.append("| File | P | T | Rep | Total [s] | Comparable full run | Status |")
    lines.append("|---|---:|---:|---:|---:|---|---|")

    for row in rows:
        if row["is_comparable_full_run"]:
            continue

        lines.append(
            "| "
            f"{row['file_name']} | "
            f"{row['processes']} | "
            f"{row['threads_per_process']} | "
            f"{row['repetition']} | "
            f"{_format_float(row['total_wall_time_s'])} | "
            f"{row['is_comparable_full_run']} | "
            f"{row['overall_status']} |"
        )

    lines.append("")
    lines.append("## Module details")
    lines.append("")

    module_prefixes = sorted(
        {
            key.removesuffix("_wall_time_s")
            for row in rows
            for key in row
            if key.endswith("_wall_time_s") and key not in {"total_wall_time_s"}
        }
    )

    for module_prefix in module_prefixes:
        lines.append(f"### {module_prefix}")
        lines.append("")
        lines.append(
            "| File | Wall [s] | Solver runtime [s] | Solve count | "
            "Solve mean [s] | Solve max [s] | Solve min [s] | "
            "Solver threads cfg | Solver threads max | Objective | Status |"
        )
        lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")

        for row in rows:
            lines.append(
                "| "
                f"{row['file_name']} | "
                f"{_format_float(row.get(f'{module_prefix}_wall_time_s'))} | "
                f"{_format_float(row.get(f'{module_prefix}_solver_runtime_s'))} | "
                f"{_format_float(row.get(f'{module_prefix}_solve_count'), 0)} | "
                f"{_format_float(row.get(f'{module_prefix}_solve_time_mean_s'))} | "
                f"{_format_float(row.get(f'{module_prefix}_solve_time_max_s'))} | "
                f"{_format_float(row.get(f'{module_prefix}_solve_time_min_s'))} | "
                f"{_format_float(row.get(f'{module_prefix}_solver_threads_configured'), 0)} | "
                f"{_format_float(row.get(f'{module_prefix}_solver_threads_max'), 0)} | "
                f"{_format_float(row.get(f'{module_prefix}_objective_value'))} | "
                f"{row.get(f'{module_prefix}_status') or '-'} |"
            )

        lines.append("")

    with output_path.open("w", encoding="utf-8") as file:
        file.write("\n".join(lines))

    return output_path


def summarize_benchmark_results(run_dir: Path) -> dict[str, Path]:
    raw_dir = get_raw_dir(run_dir)
    summary_dir = get_summaries_dir(run_dir)
    summary_dir.mkdir(parents=True, exist_ok=True)

    payloads: list[dict[str, Any]] = []
    for path in sorted(raw_dir.glob("benchmark_*.json")):
        payload = _load_json(path)
        payload["_file_name"] = path.name
        payloads.append(payload)

    rows = _build_summary_rows(payloads)

    json_path = _write_summary_json(summary_dir, rows)
    csv_path = _write_summary_csv(summary_dir, rows)
    md_path = _write_summary_md(summary_dir, rows)

    return {
        "json": json_path,
        "csv": csv_path,
        "md": md_path,
    }
