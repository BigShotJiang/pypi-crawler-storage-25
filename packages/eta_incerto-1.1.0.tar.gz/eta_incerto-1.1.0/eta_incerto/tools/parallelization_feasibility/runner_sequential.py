from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path

from eta_incerto.tools.parallelization_feasibility.collect import (
    save_benchmark_run_result,
)
from eta_incerto.tools.parallelization_feasibility.datastructures import (
    BenchmarkCase,
    ModuleRunResult,
)
from eta_incerto.tools.parallelization_feasibility.monitor import ResourceMonitor
from eta_incerto.tools.parallelization_feasibility.paths import ensure_pf_structure
from eta_incerto.tools.parallelization_feasibility.runner_common import (
    create_benchmark_run_result,
    run_single_module_benchmark,
)


def run_sequential_benchmark(
    run_dir: Path,
    config_name: str,
    modules: list[str],
    repetition: int = 1,
    threads_per_process: int = 1,
    timeout_s: float | None = None,
) -> tuple:
    ensure_pf_structure(run_dir)

    benchmark_case = BenchmarkCase(
        processes=1,
        threads_per_process=threads_per_process,
        repetition=repetition,
        label="sequential_baseline",
    )

    started_at = datetime.now(UTC)
    monitor = ResourceMonitor(root_pid=os.getpid())
    monitor.start()

    module_results: list[ModuleRunResult] = []

    for module_name in modules:
        result = run_single_module_benchmark(
            run_dir=run_dir,
            config_name=config_name,
            module_name=module_name,
            benchmark_case=benchmark_case,
            timeout_s=timeout_s,
        )
        module_results.append(result)

    resource_samples = monitor.stop()
    finished_at = datetime.now(UTC)

    benchmark_run_result = create_benchmark_run_result(
        benchmark_case=benchmark_case,
        config_name=config_name,
        run_dir=run_dir,
        module_results=module_results,
        resource_samples=resource_samples,
        started_at=started_at,
        finished_at=finished_at,
    )

    output_path = save_benchmark_run_result(run_dir, benchmark_run_result)
    return benchmark_run_result, output_path
