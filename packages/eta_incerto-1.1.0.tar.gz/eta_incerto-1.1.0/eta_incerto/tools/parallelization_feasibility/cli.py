from __future__ import annotations

import argparse
from pathlib import Path

from eta_incerto.tools.parallelization_feasibility.benchmark_matrix import (
    build_benchmark_cases,
)
from eta_incerto.tools.parallelization_feasibility.paths import ensure_pf_structure
from eta_incerto.tools.parallelization_feasibility.runner_common import VALID_MODULES
from eta_incerto.tools.parallelization_feasibility.runner_parallel import (
    run_parallel_benchmark,
)
from eta_incerto.tools.parallelization_feasibility.runner_sequential import (
    run_sequential_benchmark,
)
from eta_incerto.tools.parallelization_feasibility.summarize import (
    summarize_benchmark_results,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the eta-incerto parallelization feasibility analysis for a given run directory."
    )

    parser.add_argument(
        "--run-dir",
        type=Path,
        required=True,
        help="Path to the rodmo run directory.",
    )

    parser.add_argument(
        "--config",
        default="config",
        help="Config file name (without extension) inside run dir.",
    )

    parser.add_argument(
        "--mode",
        choices=["sequential", "parallel", "summarize"],
        default="sequential",
        help="Execution mode for the feasibility analysis.",
    )

    parser.add_argument(
        "--modules",
        nargs="+",
        default=["stochastic", "regret"],
        help=f"Conventional optimization modules to benchmark. Supported values: {', '.join(VALID_MODULES)}.",
    )

    parser.add_argument(
        "--processes",
        nargs="+",
        type=int,
        default=[1],
        help="One or more Python process counts. Sequential mode only uses cases with processes == 1.",
    )

    parser.add_argument(
        "--threads-per-process",
        nargs="+",
        type=int,
        default=[1],
        help="One or more solver thread counts per process.",
    )

    parser.add_argument(
        "--repetition",
        type=int,
        default=1,
        help="Repetition index for the benchmark case.",
    )

    parser.add_argument(
        "--timeout-s",
        type=float,
        default=None,
        help="Optional timeout in seconds per module run.",
    )

    parser.add_argument(
        "--max-total-threads",
        type=int,
        default=None,
        help="Optional upper bound for processes * threads_per_process when building a matrix.",
    )

    return parser


def _validate_modules(parser: argparse.ArgumentParser, modules: list[str]) -> None:
    invalid = [module for module in modules if module not in VALID_MODULES]
    if invalid:
        parser.error(f"Unsupported module(s): {', '.join(invalid)}. Expected only: {', '.join(VALID_MODULES)}.")


def _build_cases_from_args(
    parser: argparse.ArgumentParser,
    mode: str,
    process_values: list[int],
    thread_values: list[int],
    repetition: int,
    max_total_threads: int | None,
):
    if repetition < 1:
        parser.error("--repetition must be >= 1.")

    if any(value < 1 for value in process_values):
        parser.error("All --processes values must be >= 1.")

    if any(value < 1 for value in thread_values):
        parser.error("All --threads-per-process values must be >= 1.")

    if max_total_threads is not None and max_total_threads < 1:
        parser.error("--max-total-threads must be >= 1 when provided.")

    if mode == "sequential":
        return build_benchmark_cases(
            process_values=process_values,
            thread_values=thread_values,
            repetition_values=[repetition],
            include_sequential=True,
            include_parallel=False,
            max_total_threads=max_total_threads,
        )

    if mode == "parallel":
        return build_benchmark_cases(
            process_values=process_values,
            thread_values=thread_values,
            repetition_values=[repetition],
            include_sequential=False,
            include_parallel=True,
            max_total_threads=max_total_threads,
        )

    return []


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    run_dir = args.run_dir.expanduser().resolve()
    ensure_pf_structure(run_dir)

    if args.timeout_s is not None and args.timeout_s <= 0:
        parser.error("--timeout-s must be > 0 when provided.")

    modules = list(dict.fromkeys(args.modules))
    _validate_modules(parser, modules)

    if args.mode == "summarize":
        outputs = summarize_benchmark_results(run_dir)
        parser.exit(
            status=0,
            message=(
                "Benchmark summary completed.\n"
                f"Run directory: {run_dir}\n"
                f"JSON summary: {outputs['json']}\n"
                f"CSV summary: {outputs['csv']}\n"
                f"Markdown summary: {outputs['md']}\n"
            ),
        )

    cases = _build_cases_from_args(
        parser=parser,
        mode=args.mode,
        process_values=args.processes,
        thread_values=args.threads_per_process,
        repetition=args.repetition,
        max_total_threads=args.max_total_threads,
    )

    if not cases:
        parser.error(
            "No benchmark cases were generated for the selected mode. "
            "Check --processes, --threads-per-process, and --max-total-threads."
        )

    output_lines: list[str] = []

    for case in cases:
        if args.mode == "sequential":
            result, output_path = run_sequential_benchmark(
                run_dir=run_dir,
                config_name=args.config,
                modules=modules,
                repetition=case.repetition,
                threads_per_process=case.threads_per_process,
                timeout_s=args.timeout_s,
            )
            output_lines.append(
                f"[sequential] p={case.processes} t={case.threads_per_process} "
                f"total_wall_time_s={result.total_wall_time_s} file={output_path}"
            )
        else:
            result, output_path = run_parallel_benchmark(
                run_dir=run_dir,
                config_name=args.config,
                modules=modules,
                processes=case.processes,
                threads_per_process=case.threads_per_process,
                repetition=case.repetition,
                timeout_s=args.timeout_s,
            )
            output_lines.append(
                f"[parallel] p={case.processes} t={case.threads_per_process} "
                f"total_wall_time_s={result.total_wall_time_s} file={output_path}"
            )

    parser.exit(
        status=0,
        message=(
            f"{args.mode.capitalize()} benchmark batch completed.\n"
            f"Run directory: {run_dir}\n"
            f"Modules executed: {', '.join(modules)}\n"
            f"Cases executed: {len(cases)}\n" + "\n".join(output_lines) + "\n"
        ),
    )


if __name__ == "__main__":
    main()
