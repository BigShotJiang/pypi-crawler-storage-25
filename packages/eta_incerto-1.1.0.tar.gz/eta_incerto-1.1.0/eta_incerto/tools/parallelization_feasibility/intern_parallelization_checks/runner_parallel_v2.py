from __future__ import annotations

import multiprocessing as mp
import os
from datetime import UTC, datetime
from pathlib import Path

from eta_incerto.tools.parallelization_feasibility.collect import (
    save_benchmark_run_result,
)
from eta_incerto.tools.parallelization_feasibility.datastructures import (
    BenchmarkCase,
    ModuleRunResult,
)
from eta_incerto.tools.parallelization_feasibility.intern_parallelization_checks.runner_common_v2 import (
    create_benchmark_run_result,
    run_single_module_benchmark,
)
from eta_incerto.tools.parallelization_feasibility.monitor import ResourceMonitor
from eta_incerto.tools.parallelization_feasibility.paths import ensure_pf_structure


def _parallel_worker(
    payload: tuple[Path, str, str, BenchmarkCase, float | None],
) -> ModuleRunResult:
    run_dir, config_name, module_name, benchmark_case, timeout_s = payload
    return run_single_module_benchmark(
        run_dir=run_dir,
        config_name=config_name,
        module_name=module_name,
        benchmark_case=benchmark_case,
        timeout_s=timeout_s,
    )


def run_benchmark(
    run_dir: Path,
    config_name: str,
    modules: list[str],
    benchmark_case: BenchmarkCase,
    timeout_s: float | None = None,
) -> tuple:
    ensure_pf_structure(run_dir)

    started_at = datetime.now(UTC)
    monitor = ResourceMonitor(root_pid=os.getpid())
    monitor.start()

    payloads = [(run_dir, config_name, module_name, benchmark_case, timeout_s) for module_name in modules]

    if not payloads:
        raise ValueError("No modules provided for parallel benchmark.")

    if benchmark_case.processes == 1:
        module_results = [_parallel_worker(payload) for payload in payloads]
    else:
        with mp.get_context("spawn").Pool(processes=benchmark_case.processes) as pool:
            module_results = pool.map(_parallel_worker, payloads)

    resource_samples = monitor.stop()
    finished_at = datetime.now(UTC)

    benchmark_run_result = create_benchmark_run_result(
        benchmark_case=benchmark_case,
        config_name=config_name,
        run_dir=run_dir,
        module_results=module_results,
        resource_samples=resource_samples,
        started_at=started_at,
        finished_at=finished_at,
    )

    output_path = save_benchmark_run_result(run_dir, benchmark_run_result)
    return benchmark_run_result, output_path
