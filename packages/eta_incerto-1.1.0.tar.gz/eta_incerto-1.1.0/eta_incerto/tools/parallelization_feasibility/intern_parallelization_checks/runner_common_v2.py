from __future__ import annotations

import multiprocessing as mp
import os
import queue
import socket
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from eta_incerto.tools.parallelization_feasibility.datastructures import (
    BenchmarkCase,
    BenchmarkRunResult,
    ModuleRunResult,
)
from eta_incerto.tools.parallelization_feasibility.log_parsing import (
    parse_gap_percent_from_log,
    parse_nodes_from_log,
    parse_solve_times_from_log,
    parse_solver_threads_from_log,
)

VALID_MODULES = ("stochastic", "regret", "robust")


def _set_thread_environment(threads_per_process: int) -> None:
    value = str(threads_per_process)
    for env_name in (
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "NUMBA_NUM_THREADS",
    ):
        os.environ[env_name] = value


def _execution_base_dir(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> Path:
    return (
        run_dir
        / "parallelization_feasibility"
        / "execution"
        / (
            f"p{benchmark_case.processes:02d}"
            f"_t{benchmark_case.threads_per_process:02d}"
            f"_r{benchmark_case.repetition:02d}"
        )
        / module_name
    )


def _log_file_path(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> Path:
    return _execution_base_dir(run_dir, benchmark_case, module_name) / "execution.log"


def _results_dir_path(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
    module_name: str,
) -> Path:
    return _execution_base_dir(run_dir, benchmark_case, module_name) / "results"


def _mode_for_module(module_name: str) -> str:
    if module_name not in VALID_MODULES:
        raise ValueError(f"Unsupported module_name '{module_name}'. Expected one of: {', '.join(VALID_MODULES)}.")
    return module_name


def _build_run_optimization_cmd(
    *,
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
    results_dir: Path,
) -> list[str]:
    mode = _mode_for_module(module_name)
    return [
        sys.executable,
        "-m",
        "eta_incerto.tools.run_optimization",
        "--config",
        config_name,
        "--root-path",
        str(run_dir),
        "--results-dir",
        str(results_dir),
        "--mode",
        mode,
        "--force-python-workers",
        "--force-solver-threads",
    ]


def _summarize_solve_times(solve_times_s: list[float]) -> tuple[int, float | None, float | None, float | None]:
    if not solve_times_s:
        return 0, None, None, None

    solve_count = len(solve_times_s)
    solve_time_mean_s = sum(solve_times_s) / solve_count
    solve_time_max_s = max(solve_times_s)
    solve_time_min_s = min(solve_times_s)
    return solve_count, solve_time_mean_s, solve_time_max_s, solve_time_min_s


def _tail_text(path: Path, max_bytes: int = 8192) -> str:
    if not path.exists():
        return ""
    with path.open("rb") as f:
        f.seek(0, 2)
        size = f.tell()
        read_size = min(size, max_bytes)
        f.seek(-read_size, 2)
        return f.read().decode(errors="ignore")


def _run_single_module_in_current_process(
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
) -> ModuleRunResult:
    # Internal solver/runtime threading is intentionally fixed to 1 in v2 external-only mode.
    _set_thread_environment(1)

    started = time.perf_counter()
    log_path = _log_file_path(run_dir, benchmark_case, module_name)
    results_dir = _results_dir_path(run_dir, benchmark_case, module_name)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    cmd = _build_run_optimization_cmd(
        run_dir=run_dir,
        config_name=config_name,
        module_name=module_name,
        benchmark_case=benchmark_case,
        results_dir=results_dir,
    )

    try:
        with log_path.open("w", encoding="utf-8") as f:
            f.write(f"[runner_common_v2] cmd: {' '.join(cmd)}\n")
            f.flush()
            completed = subprocess.run(
                cmd,
                stdout=f,
                stderr=subprocess.STDOUT,
                check=False,
            )

        wall_time_s = time.perf_counter() - started
        solve_times_s = parse_solve_times_from_log(log_path)
        nodes_all = parse_nodes_from_log(log_path)
        best_gap_percent_all = parse_gap_percent_from_log(log_path)
        solver_threads_all = parse_solver_threads_from_log(log_path)
        solve_count, solve_time_mean_s, solve_time_max_s, solve_time_min_s = _summarize_solve_times(solve_times_s)
        solver_threads_max = max(solver_threads_all) if solver_threads_all else None

        status = "ok" if completed.returncode == 0 else "error"
        error_message = None
        if completed.returncode != 0:
            tail = _tail_text(log_path)
            error_message = f"run_optimization exited with code {completed.returncode}." + (
                f" Log tail:\n{tail}" if tail else ""
            )

        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=solve_time_mean_s,
            status=status,
            termination_condition=None if completed.returncode == 0 else f"exit_code_{completed.returncode}",
            solver_name=None,
            objective_value=None,
            solve_count=solve_count,
            solve_times_s=solve_times_s,
            solve_time_mean_s=solve_time_mean_s,
            solve_time_max_s=solve_time_max_s,
            solve_time_min_s=solve_time_min_s,
            nodes_all=nodes_all,
            best_gap_percent_all=best_gap_percent_all,
            solver_threads_all=solver_threads_all,
            solver_threads_max=solver_threads_max,
            solver_threads_configured=1,
            log_path=str(log_path),
            solver_stats_raw=None,
            effective_options={"normalized": {"threads": 1}},
            timed_out=False,
            timeout_s=None,
            error_message=error_message,
        )

    except Exception as exc:
        wall_time_s = time.perf_counter() - started
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="error",
            termination_condition=None,
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(log_path),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=False,
            timeout_s=None,
            error_message=f"{type(exc).__name__}: {exc}",
        )


def _module_runner_entrypoint(
    result_queue: mp.Queue,
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
) -> None:
    result = _run_single_module_in_current_process(
        run_dir=run_dir,
        config_name=config_name,
        module_name=module_name,
        benchmark_case=benchmark_case,
    )
    result_queue.put(result)


def run_single_module_benchmark(
    run_dir: Path,
    config_name: str,
    module_name: str,
    benchmark_case: BenchmarkCase,
    timeout_s: float | None = None,
) -> ModuleRunResult:
    if timeout_s is None:
        return _run_single_module_in_current_process(
            run_dir=run_dir,
            config_name=config_name,
            module_name=module_name,
            benchmark_case=benchmark_case,
        )

    ctx = mp.get_context("spawn")
    result_queue: mp.Queue = ctx.Queue()
    process = ctx.Process(
        target=_module_runner_entrypoint,
        args=(result_queue, run_dir, config_name, module_name, benchmark_case),
    )

    started = time.perf_counter()
    process.start()
    process.join(timeout=timeout_s)

    if process.is_alive():
        process.terminate()
        process.join()

        wall_time_s = time.perf_counter() - started
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="timeout",
            termination_condition="timeout",
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(_log_file_path(run_dir, benchmark_case, module_name)),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=True,
            timeout_s=timeout_s,
            error_message=f"Module run exceeded timeout of {timeout_s} s.",
        )

    wall_time_s = time.perf_counter() - started

    try:
        result = result_queue.get_nowait()
    except queue.Empty:
        return ModuleRunResult(
            module_name=module_name,
            wall_time_s=wall_time_s,
            solver_runtime_s=None,
            status="error",
            termination_condition=None,
            solver_name=None,
            objective_value=None,
            solve_count=0,
            solve_times_s=[],
            solve_time_mean_s=None,
            solve_time_max_s=None,
            solve_time_min_s=None,
            nodes_all=[],
            best_gap_percent_all=[],
            solver_threads_all=[],
            solver_threads_max=None,
            solver_threads_configured=None,
            log_path=str(_log_file_path(run_dir, benchmark_case, module_name)),
            solver_stats_raw=None,
            effective_options=None,
            timed_out=False,
            timeout_s=timeout_s,
            error_message="Module process finished without returning a result.",
        )

    result.wall_time_s = wall_time_s
    result.timeout_s = timeout_s
    return result


def create_benchmark_run_result(
    benchmark_case: BenchmarkCase,
    config_name: str,
    run_dir: Path,
    module_results: list[ModuleRunResult],
    resource_samples,
    started_at: datetime,
    finished_at: datetime,
) -> BenchmarkRunResult:
    total_wall_time_s = (finished_at - started_at).total_seconds()

    return BenchmarkRunResult(
        benchmark_case=benchmark_case,
        config_name=config_name,
        run_dir=run_dir,
        module_results=module_results,
        resource_samples=list(resource_samples),
        started_at=started_at,
        finished_at=finished_at,
        hostname=socket.gethostname(),
        total_wall_time_s=total_wall_time_s,
    )
