from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from eta_incerto.tools.parallelization_feasibility.datastructures import (
    BenchmarkCase,
    BenchmarkRunResult,
)
from eta_incerto.tools.parallelization_feasibility.paths import get_raw_dir


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def serialize_benchmark_run_result(result: BenchmarkRunResult) -> dict[str, Any]:
    """
    Convert a BenchmarkRunResult dataclass into a JSON-serializable dictionary.
    """
    payload = asdict(result)

    if result.started_at is not None:
        payload["started_at"] = result.started_at.isoformat()

    if result.finished_at is not None:
        payload["finished_at"] = result.finished_at.isoformat()

    payload["run_dir"] = str(result.run_dir)

    return payload


def build_benchmark_result_filename(benchmark_case: BenchmarkCase) -> str:
    """
    Build a stable raw result filename from the benchmark configuration.
    """
    return (
        f"benchmark_p{benchmark_case.processes:02d}"
        f"_t{benchmark_case.threads_per_process:02d}"
        f"_r{benchmark_case.repetition:02d}.json"
    )


def get_benchmark_result_path(
    run_dir: Path,
    benchmark_case: BenchmarkCase,
) -> Path:
    """
    Return the output path for a raw benchmark result file.
    """
    return get_raw_dir(run_dir) / build_benchmark_result_filename(benchmark_case)


def save_benchmark_run_result(
    run_dir: Path,
    result: BenchmarkRunResult,
) -> Path:
    """
    Persist a benchmark run result as JSON in the raw results directory.
    """
    output_path = get_benchmark_result_path(
        run_dir=run_dir,
        benchmark_case=result.benchmark_case,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)

    payload = serialize_benchmark_run_result(result)

    with output_path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, default=_json_default)

    return output_path
