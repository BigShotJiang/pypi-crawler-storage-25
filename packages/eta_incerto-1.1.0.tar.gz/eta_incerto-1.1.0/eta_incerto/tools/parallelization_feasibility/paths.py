from pathlib import Path

PF_DIR_NAME = "parallelization_feasibility"


def get_pf_root(run_dir: Path) -> Path:
    return run_dir / PF_DIR_NAME


def get_raw_dir(run_dir: Path) -> Path:
    return get_pf_root(run_dir) / "raw"


def get_logs_dir(run_dir: Path) -> Path:
    return get_pf_root(run_dir) / "logs"


def get_monitor_dir(run_dir: Path) -> Path:
    return get_pf_root(run_dir) / "monitor"


def get_summaries_dir(run_dir: Path) -> Path:
    return get_pf_root(run_dir) / "summaries"


def ensure_pf_structure(run_dir: Path) -> None:
    """
    Create all required directories for the parallelization feasibility analysis.
    """
    for path in [
        get_pf_root(run_dir),
        get_raw_dir(run_dir),
        get_logs_dir(run_dir),
        get_monitor_dir(run_dir),
        get_summaries_dir(run_dir),
    ]:
        path.mkdir(parents=True, exist_ok=True)
