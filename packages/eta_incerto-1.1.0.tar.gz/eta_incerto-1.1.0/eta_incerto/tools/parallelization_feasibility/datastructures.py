from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class BenchmarkCase:
    processes: int
    threads_per_process: int
    repetition: int = 1
    label: str | None = None


@dataclass
class ModuleCase:
    module_name: str


@dataclass
class ModuleRunResult:
    module_name: str
    wall_time_s: float

    solver_runtime_s: float | None = None
    status: str | None = None
    termination_condition: str | None = None
    solver_name: str | None = None
    objective_value: float | None = None

    solve_count: int = 0
    solve_times_s: list[float] = field(default_factory=list)
    solve_time_mean_s: float | None = None
    solve_time_max_s: float | None = None
    solve_time_min_s: float | None = None

    nodes_all: list[int] = field(default_factory=list)
    best_gap_percent_all: list[float] = field(default_factory=list)

    solver_threads_all: list[int] = field(default_factory=list)
    solver_threads_max: int | None = None
    solver_threads_configured: int | None = None

    log_path: str | None = None
    solver_stats_raw: dict[str, Any] | None = None
    effective_options: dict[str, Any] | None = None

    timed_out: bool = False
    timeout_s: float | None = None
    error_message: str | None = None


@dataclass
class ResourceSample:
    timestamp: float
    cpu_percent: float
    memory_rss_mb: float
    active_processes: int
    active_threads_total: int
    max_threads_per_process: int


@dataclass
class BenchmarkRunResult:
    benchmark_case: BenchmarkCase
    config_name: str
    run_dir: Path

    module_results: list[ModuleRunResult] = field(default_factory=list)
    resource_samples: list[ResourceSample] = field(default_factory=list)

    started_at: datetime | None = None
    finished_at: datetime | None = None

    hostname: str | None = None
    total_wall_time_s: float | None = None
