Parallelization Feasibility Analysis
===================================

Goal
----

This module provides a structured framework to analyze the feasibility of parallel execution in eta-incerto.

The primary objective is to answer the following questions:

- Can eta-incerto be executed in parallel in a stable way?
- How do Python processes and solver threads behave in practice?
- Does parallelization provide a real runtime improvement compared to sequential execution?
- Which combination of processes and solver threads is optimal?
- Where do issues occur (e.g. oversubscription, memory pressure, solver instability)?

This analysis is a prerequisite for running large-scale sensitivity / stress-test studies on HPC systems.


Concept
-------

The analysis is based on running a fixed set of scenarios under different parallelization configurations:

- Number of Python processes
- Number of solver threads per process

Each configuration is executed and evaluated with respect to:

- Wall-time (total runtime)
- Runtime per scenario / solve
- Solver metrics (time, nodes, mip gap, status)
- System metrics (CPU usage, RAM usage, active processes, threads)
- Stability (errors, timeouts, reproducibility)


Run Directory Integration
------------------------

The analysis operates on an existing run directory (run_dir), consistent with the eta-incerto ↔ data-repo contract.

Inputs are loaded from the run directory:
- config.json
- variants/
- distribution_data/
- scenario definitions

All outputs are written back to the same run directory under:

::

    <run_dir>/parallelization_feasibility/


Structure
---------

::

    parallelization_feasibility/
        benchmark_matrix.json
        scenario_set.json
        raw/
        logs/
        monitor/
        summaries/

- raw/: per benchmark run results
- logs/: execution logs
- monitor/: sampled system metrics
- summaries/: aggregated results and recommendations


Execution Modes
---------------

- Sequential baseline (1 process × 1 thread)
- Single-process multi-thread
- Multi-process single-thread
- Multi-process multi-thread

Parallel execution is process-based. Solver threads must be explicitly controlled to avoid oversubscription.


Implementation Notes
--------------------

- Each benchmark run is independent and writes its own result file.
- Results are stored in a structured and reproducible format.
- Monitoring is performed during execution to capture real resource usage.
- The implementation is designed to be HPC-compatible (batch / array execution).


Next Steps
----------

1. Define scenario set
2. Implement sequential runner
3. Implement parallel runner
4. Add monitoring
5. Evaluate and summarize results
