from __future__ import annotations

import argparse
import importlib
import logging
import sys
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from line_profiler import LineProfiler
from pymoo.termination import get_termination

from eta_incerto.core import EtaIncerto
from eta_incerto.envs.antifragile_evaluation import AntifragileEvaluator

log = logging.getLogger(__name__)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Line-profile antifragile optimization.")
    parser.add_argument(
        "--config",
        required=True,
        help="Path to config file (json/toml/yaml).",
    )
    parser.add_argument(
        "--variant",
        action="append",
        default=None,
        help="Variant name to profile. Repeat to profile multiple variants.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory for .lprof and .txt files (defaults to <results_dir>/profiles).",
    )
    parser.add_argument(
        "--variant-module",
        action="append",
        default=None,
        help="Python module to import to register systems (repeatable).",
    )
    parser.add_argument(
        "--single-eval",
        action="store_true",
        help="Profile a single objective evaluation (no optimization loop).",
    )
    parser.add_argument(
        "--min-runtime",
        action="store_true",
        help="Override config values for minimal runtime (small samples and termination).",
    )
    return parser.parse_args()


def _resolve_config_path(config_arg: str) -> Path:
    raw = Path(config_arg).expanduser()
    if raw.exists():
        return raw

    if raw.suffix:
        raise FileNotFoundError(f"Config file not found: {raw}")

    for ext in (".json", ".toml", ".yaml", ".yml"):
        candidate = raw.with_suffix(ext)
        if candidate.exists():
            return candidate

    raise FileNotFoundError(f"Config file not found: {raw}")


def _import_variant_modules(modules: list[str]) -> None:
    for mod in modules:
        try:
            importlib.import_module(mod)
            log.info("Imported variant module: %s", mod)
        except Exception as exc:
            log.warning("Failed importing variant module %s: %s", mod, exc)


def _maybe_import_example_variants(config_path: Path, variants: list[str]) -> None:
    if config_path.parent.name != "antifragile":
        return

    modules: list[str] = []
    for variant in variants:
        modules.append(f"examples.antifragile.variants.{variant}.system")

    _import_variant_modules(modules)


def _attach_inputs_from_scenario(model_builder, scenario) -> None:
    if hasattr(model_builder, "attach_inputs_from_scenario"):
        model_builder.attach_inputs_from_scenario(scenario)
        return

    model_builder.series_data = scenario.series
    model_builder.scenario_data = scenario.energy_scenario
    model_builder.series_file_name = getattr(scenario, "series_file_name", "")


def _configure_single_process(config, variant: str) -> None:
    eval_cfg = config.evaluate.for_variant(variant)
    if getattr(eval_cfg, "n_workers", None) not in (None, 1):
        log.info("Overriding evaluate.n_workers=%s -> 1 for profiling.", eval_cfg.n_workers)
    if getattr(eval_cfg, "n_jobs", None) not in (None, 1):
        log.info("Overriding evaluate.n_jobs=%s -> 1 for profiling.", eval_cfg.n_jobs)
    eval_cfg.n_workers = 1
    eval_cfg.n_jobs = 1


def _apply_fast_solver_for_profiling(config, variant: str) -> None:
    """Apply relaxed solver and PCE settings so line-profiling runs finish faster."""
    eval_cfg = config.evaluate.for_variant(variant)
    mipgap = 0.10
    timelimit = 120
    pce_sample_factor = 2
    if getattr(eval_cfg, "solver_mipgap_override", None) != mipgap:
        log.info("Overriding evaluate.solver_mipgap_override -> %s for fast profiling.", mipgap)
    if getattr(eval_cfg, "solver_timelimit_override", None) != timelimit:
        log.info("Overriding evaluate.solver_timelimit_override -> %s s for fast profiling.", timelimit)
    if getattr(eval_cfg, "pce_sample_factor", 4) != pce_sample_factor:
        log.info("Overriding evaluate.pce_sample_factor -> %s for fast profiling.", pce_sample_factor)
    eval_cfg.solver_mipgap_override = mipgap
    eval_cfg.solver_timelimit_override = timelimit
    if hasattr(eval_cfg, "pce_sample_factor"):
        eval_cfg.pce_sample_factor = pce_sample_factor


def _apply_min_runtime(config, variant: str) -> None:
    eval_cfg = config.evaluate.for_variant(variant)
    overrides = {
        "pce_order": 1,
        "quad_order": 1,
        "stat_n_mc": 10,
        "feasibility_batch_size": 32,
        "feasibility_max_rounds": 5,
    }
    for key, value in overrides.items():
        if hasattr(eval_cfg, key):
            log.info("Overriding evaluate.%s=%s -> %s for minimal runtime.", key, getattr(eval_cfg, key), value)
            setattr(eval_cfg, key, value)

    algo_cfg = config.algorithm
    if hasattr(algo_cfg, "pop_size") and algo_cfg.pop_size > 4:
        log.info("Overriding algorithm.pop_size=%s -> 4 for minimal runtime.", algo_cfg.pop_size)
        algo_cfg.pop_size = 4

    config.termination.termination_instance = get_termination("n_eval", 1)
    log.info("Overriding termination to n_eval=1 for minimal runtime.")


def _add_eta_components_to_profiler(profiler: LineProfiler) -> None:
    """Register eta-components build/solve functions so the profile shows build vs solve breakdown."""
    try:
        from eta_components.milp_component_library.backends.linopy_backend import LinopyBackend
        from eta_components.milp_component_library.systems import _BaseSystem

        profiler.add_function(_BaseSystem.solve)
        profiler.add_function(LinopyBackend.solve)
        log.debug("Added eta-components solve path to line profiler.")
    except ImportError as exc:
        log.warning(
            "eta_components not available; profile will not include build/solve breakdown. %s",
            exc,
        )


def _build_evaluator(experiment: EtaIncerto, variant: str) -> AntifragileEvaluator:
    pdef = experiment.config.pymoo.for_variant(variant)
    if getattr(pdef, "mode", "invest") == "dispatch":
        raise RuntimeError(f"Variant '{variant}' is dispatch-only; no antifragile design variables to profile.")

    model_builder, demand_series, distribution_data = experiment.load_model_series_algorithm_termination(variant)

    _, _, invest_scenarios, _ = experiment.load_system_series_scenario(variant)
    invest_scenarios = list(invest_scenarios or [])
    if not invest_scenarios:
        raise RuntimeError(f"Antifragile optimization requires invest_scenarios for '{variant}', but none were loaded.")

    _attach_inputs_from_scenario(model_builder, invest_scenarios[0])

    return AntifragileEvaluator(
        config=experiment.config,
        variant_name=variant,
        model_builder=model_builder,
        demand_series=demand_series,
        distribution_data=distribution_data,
        h5_file_name=f"antifragile_{variant}.h5",
        variable_names=pdef.variable_names,
        objective_names=pdef.objective_names,
    )


def _profile_variant(experiment: EtaIncerto, variant: str, output_dir: Path) -> None:
    _configure_single_process(experiment.config, variant)
    evaluator = _build_evaluator(experiment, variant)

    profiler = LineProfiler()
    profiler.add_function(evaluator._evaluate_objectives)
    profiler.add_function(evaluator.build_pce_surrogate)
    profiler.add_function(evaluator.evaluate_statistics)
    profiler.add_function(evaluator._simulate)
    profiler.add_function(evaluator._simulate_many)
    profiler.add_function(evaluator._simulate_many_once)
    profiler.add_function(evaluator._draw_feasible_samples)
    if evaluator.problem is not None:
        profiler.add_function(evaluator.problem._evaluate)
    _add_eta_components_to_profiler(profiler)

    if experiment.config is None:
        raise RuntimeError("Experiment config not available.")

    log.info("Profiling antifragile optimization for variant '%s'.", variant)
    profiler.runcall(evaluator.evaluate_systems)

    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    base = f"line_profile_{variant}_{timestamp}"
    lprof_path = output_dir / f"{base}.lprof"
    txt_path = output_dir / f"{base}.txt"

    profiler.dump_stats(str(lprof_path))
    with txt_path.open("w", encoding="utf-8") as handle:
        profiler.print_stats(stream=handle)

    log.info("Line profiler output: %s", lprof_path)
    log.info("Line profiler report: %s", txt_path)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _parse_args()

    config_path = _resolve_config_path(args.config)
    root_path = config_path.parent
    experiment = EtaIncerto(root_path, config_path.name, relpath_config=".")

    output_dir = Path(args.output_dir) if args.output_dir else Path(experiment.config.paths.results_dir) / "profiles"

    variants = args.variant or list(experiment.config.system.variant)
    if args.variant_module:
        _import_variant_modules(args.variant_module)
    else:
        _maybe_import_example_variants(config_path, variants)
    for variant in variants:
        _apply_fast_solver_for_profiling(experiment.config, variant)
        if args.min_runtime:
            _apply_min_runtime(experiment.config, variant)
        if args.single_eval:
            _configure_single_process(experiment.config, variant)
            evaluator = _build_evaluator(experiment, variant)
            profiler = LineProfiler()
            profiler.add_function(evaluator._evaluate_objectives)
            profiler.add_function(evaluator.build_pce_surrogate)
            profiler.add_function(evaluator.evaluate_statistics)
            profiler.add_function(evaluator._simulate)
            profiler.add_function(evaluator._simulate_many)
            profiler.add_function(evaluator._simulate_many_once)
            profiler.add_function(evaluator._draw_feasible_samples)
            if evaluator.problem is not None:
                profiler.add_function(evaluator.problem._evaluate)
            _add_eta_components_to_profiler(profiler)

            pdef = experiment.config.pymoo.for_variant(variant)
            xl = np.asarray(pdef.x_lower_bound, dtype=float)
            xu = np.asarray(pdef.x_upper_bound, dtype=float)
            x = (xl + xu) / 2.0

            log.info("Profiling single objective evaluation for variant '%s'.", variant)
            profiler.runcall(evaluator._evaluate_objectives, x)

            output_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
            base = f"line_profile_single_eval_{variant}_{timestamp}"
            lprof_path = output_dir / f"{base}.lprof"
            txt_path = output_dir / f"{base}.txt"

            profiler.dump_stats(str(lprof_path))
            with txt_path.open("w", encoding="utf-8") as handle:
                profiler.print_stats(stream=handle)

            log.info("Line profiler output: %s", lprof_path)
            log.info("Line profiler report: %s", txt_path)
            continue

        _profile_variant(experiment, variant, output_dir)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log.exception("Profiling failed.")
        sys.exit(1)
