"""Run antifragile optimization under pyinstrument (call-stack profiler) with config-driven CLI."""

from __future__ import annotations

import argparse
import importlib
import logging
import os
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

from pyinstrument import Profiler

from eta_incerto.core import EtaIncerto

log = logging.getLogger(__name__)


def _resolve_config_path(config_arg: str) -> Path:
    raw = Path(config_arg).expanduser()
    if raw.exists():
        return raw

    if raw.suffix:
        raise FileNotFoundError(f"Config file not found: {raw}")

    for ext in (".json", ".toml", ".yaml", ".yml"):
        candidate = raw.with_suffix(ext)
        if candidate.exists():
            return candidate

    raise FileNotFoundError(f"Config file not found: {raw}")


def _import_variant_modules(modules: list[str]) -> None:
    for mod in modules:
        try:
            importlib.import_module(mod)
            log.info("Imported variant module: %s", mod)
        except Exception as exc:
            log.warning("Failed importing variant module %s: %s", mod, exc)


def _maybe_import_example_variants(config_path: Path, variants: list[str]) -> None:
    if config_path.parent.name != "antifragile":
        return

    modules: list[str] = []
    for variant in variants:
        modules.append(f"examples.antifragile.variants.{variant}.system")

    _import_variant_modules(modules)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run antifragile optimization under pyinstrument (call-stack profiler)."
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to config file (json/toml/yaml).",
    )
    parser.add_argument(
        "--html-report",
        default=None,
        help="Path for HTML report (default: <results_dir>/profiles/pyinstrument_<timestamp>.html).",
    )
    parser.add_argument("--publish-results", action="store_true", help="Publish results to LFS repo.")
    parser.add_argument("--objectives-summary", default=None, help="Summary for results repo metadata.")
    parser.add_argument("--results-repo-url", default=None)
    parser.add_argument("--results-repo-path", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--variant-module",
        action="append",
        default=None,
        help="Python module to import to register systems (repeatable).",
    )
    return parser.parse_args()


def _should_publish(args: argparse.Namespace) -> bool:
    return bool(args.publish_results or os.environ.get("PUBLISH_RESULTS") == "1")


def _progress_start(phase: str) -> float:
    log.info("Starting %s...", phase)
    return time.perf_counter()


def _progress_done(phase: str, started_at: float) -> None:
    elapsed = time.perf_counter() - started_at
    log.info("Finished %s in %.1fs.", phase, elapsed)


def _publish_artifacts(
    root_path: Path,
    config_path: Path,
    artifacts: list[Path],
    args: argparse.Namespace,
) -> None:
    if not _should_publish(args):
        return
    if not args.objectives_summary:
        raise ValueError("--objectives-summary is required when publishing results.")

    for artifact in artifacts:
        if not artifact.exists():
            log.warning("Artifact not found, skipping publish: %s", artifact)
            continue
        cmd = [
            sys.executable,
            "-m",
            "eta_incerto.tools.results_repo",
            "publish",
            "--artifact",
            str(artifact),
            "--config",
            str(config_path),
            "--objectives-summary",
            args.objectives_summary,
        ]
        if args.results_repo_url:
            cmd.extend(["--results-repo-url", args.results_repo_url])
        if args.results_repo_path:
            cmd.extend(["--results-repo-path", args.results_repo_path])
        if args.dry_run:
            cmd.append("--dry-run")
        subprocess.run(cmd, check=True)


def _run_antifragile_and_maybe_publish(
    root_path: Path,
    config_name: str,
    config_path: Path,
    args: argparse.Namespace,
) -> None:
    started_at = _progress_start("antifragile optimization")
    experiment = EtaIncerto(root_path, config_name, relpath_config=".")
    experiment.antifragile_optimization()
    _progress_done("antifragile optimization", started_at)

    results_dir = Path(experiment.config.paths.results_dir)
    artifacts = [results_dir / f"antifragile_{variant}.h5" for variant in experiment.config.system.variant]
    if _should_publish(args):
        started_at = _progress_start("publishing artifacts")
        _publish_artifacts(root_path, config_path, artifacts, args)
        _progress_done("publishing artifacts", started_at)
    else:
        _publish_artifacts(root_path, config_path, artifacts, args)


def _optional_stop_profiling_type() -> type[BaseException] | None:
    try:
        from examples.antifragile.variants.variant_one.system import StopProfiling

        return StopProfiling
    except ImportError:
        return None


def _optional_infeasible_error_type() -> type[BaseException] | None:
    try:
        from eta_components.milp_component_library.exceptions import InfeasibleProblemError

        return InfeasibleProblemError
    except ImportError:
        return None


def _handle_profiler_exception(
    exc: BaseException,
    stop_profiling_exc: type[BaseException] | None,
    infeasible_error_cls: type[BaseException] | None,
) -> int:
    if stop_profiling_exc is not None and type(exc) is stop_profiling_exc:
        log.info("Stopped after first solve (profiling).")
        return 0
    if infeasible_error_cls is not None and isinstance(exc, infeasible_error_cls):
        log.error("InfeasibleProblemError: %s", exc)
        return 2
    log.exception("Unexpected error: %s", exc)
    return 1


def _write_profiler_output(profiler: Profiler, html_path: Path) -> None:
    try:
        sys.stdout.write(profiler.output_text(unicode=True, color=True) + "\n")
    except KeyboardInterrupt:
        log.warning("Interrupted while rendering profiler output.")
    except Exception as e:
        log.warning("Could not render profiler output: %s", e)

    try:
        html_path.parent.mkdir(parents=True, exist_ok=True)
        html_path.write_text(profiler.output_html(), encoding="utf-8")
        log.info("HTML report written to: %s", html_path)
    except KeyboardInterrupt:
        log.warning("Interrupted while writing HTML report.")
    except Exception as rep_err:
        log.warning("Could not write HTML report: %s", rep_err)


def _run_under_profiler(
    root_path: Path,
    config_name: str,
    config_path: Path,
    args: argparse.Namespace,
    html_path: Path,
    stop_profiling_exc: type[BaseException] | None,
    infeasible_error_cls: type[BaseException] | None,
) -> int:
    def run_profiled() -> None:
        _run_antifragile_and_maybe_publish(root_path, config_name, config_path, args)

    log.info("=== pyinstrument run ===")
    log.info("Config: %s", config_path)
    log.info("HTML report: %s", html_path)

    profiler = Profiler()
    profiler.start()
    exit_code = 0

    try:
        run_profiled()
        log.info("Run returned normally.")
    except KeyboardInterrupt:
        exit_code = 130
        log.warning("KeyboardInterrupt")
    except Exception as exc:
        exit_code = _handle_profiler_exception(exc, stop_profiling_exc, infeasible_error_cls)
    finally:
        try:
            profiler.stop()
        except Exception:
            pass
        _write_profiler_output(profiler, html_path)

    return exit_code


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
    args = _parse_args()

    config_path = _resolve_config_path(args.config)
    root_path = config_path.parent
    config_name = config_path.name

    # Load config to get variant list, then import variant modules before running.
    experiment = EtaIncerto(root_path, config_name, relpath_config=".")
    variants = list(experiment.config.system.variant)
    if args.variant_module:
        _import_variant_modules(args.variant_module)
    else:
        _maybe_import_example_variants(config_path, variants)

    # Resolve HTML report path
    if args.html_report:
        html_path = Path(args.html_report).expanduser()
    else:
        profiles_dir = Path(experiment.config.paths.results_dir) / "profiles"
        timestamp = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
        html_path = profiles_dir / f"pyinstrument_{timestamp}.html"

    stop_profiling_exc: type[BaseException] | None = _optional_stop_profiling_type()
    infeasible_error_cls: type[BaseException] | None = _optional_infeasible_error_type()

    exit_code = _run_under_profiler(
        root_path=root_path,
        config_name=config_name,
        config_path=config_path,
        args=args,
        html_path=html_path,
        stop_profiling_exc=stop_profiling_exc,
        infeasible_error_cls=infeasible_error_cls,
    )
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
