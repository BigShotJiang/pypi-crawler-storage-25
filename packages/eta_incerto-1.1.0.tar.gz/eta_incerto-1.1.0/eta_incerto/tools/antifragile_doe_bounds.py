from __future__ import annotations

import argparse
import json
from pathlib import Path

import h5py
import numpy as np
from scipy.stats import qmc

import examples.antifragile.variants.heat_pump.system
import examples.antifragile.variants.variant_one.system
import examples.antifragile.variants.variant_two.system
import examples.antifragile.variants.variant_zero.system  # noqa: F401
from eta_incerto.core import EtaIncerto
from eta_incerto.envs.antifragile_evaluation import AntifragileEvaluator


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run variant_one DOE objective sampling and derive normalization bounds.")
    p.add_argument("--run-dir", required=True, help="Run directory containing config.json and inputs.")
    p.add_argument("--config", default="config", help="Config basename inside run directory.")
    p.add_argument("--variant", default="variant_one", help="Variant to sample (default: variant_one).")
    p.add_argument("--n-samples", type=int, default=16, help="Number of LHS design samples.")
    p.add_argument("--q-low", type=float, default=0.05, help="Lower quantile for bounds.")
    p.add_argument("--q-high", type=float, default=0.95, help="Upper quantile for bounds.")
    p.add_argument(
        "--h5-name",
        default="antifragile_variant_one_doe_norm.h5",
        help="DOE artifact filename written in results dir.",
    )
    p.add_argument(
        "--bounds-json",
        default="variant_one_obj_bounds.json",
        help="Bounds JSON filename written in results dir.",
    )
    return p.parse_args()


def _lhs_samples(lb: np.ndarray, ub: np.ndarray, n_samples: int, seed: int) -> np.ndarray:
    sampler = qmc.LatinHypercube(d=lb.shape[0], seed=seed)
    u = sampler.random(n=n_samples)
    return qmc.scale(u, lb, ub)


def main() -> int:  # noqa: PLR0915
    args = _parse_args()
    run_dir = Path(args.run_dir).resolve()
    experiment = EtaIncerto(run_dir, args.config, relpath_config=".")
    variant = str(args.variant)

    pdef = experiment.config.pymoo.for_variant(variant)
    if getattr(pdef, "mode", "invest") == "dispatch":
        raise RuntimeError(f"{variant} is dispatch-only; DOE objective sampling requires invest mode.")

    model_builder, demand_series, distribution_data = experiment.load_model_series_algorithm_termination(variant)
    ref = experiment._load_single_invest_ref_scenario(variant)
    if hasattr(model_builder, "attach_inputs_from_scenario"):
        model_builder.attach_inputs_from_scenario(ref)
    else:
        model_builder.series_data = ref.series
        model_builder.scenario_data = ref.energy_scenario
        model_builder.series_file_name = getattr(ref, "series_file_name", "")

    evaluator = AntifragileEvaluator(
        config=experiment.config,
        variant_name=variant,
        model_builder=model_builder,
        demand_series=demand_series,
        distribution_data=distribution_data,
        h5_file_name=f"__tmp_{variant}.h5",
        variable_names=pdef.variable_names,
        objective_names=pdef.objective_names,
    )
    # Ensure raw objective space for bound extraction.
    evaluator.normalize = False
    evaluator.obj_min = None
    evaluator.obj_max = None

    lb = np.asarray(pdef.x_lower_bound, dtype=float).ravel()
    ub = np.asarray(pdef.x_upper_bound, dtype=float).ravel()
    x = _lhs_samples(lb, ub, int(args.n_samples), int(experiment.config.pymoo.seed))
    f = np.vstack([evaluator._evaluate_objectives(row) for row in x])

    q_low = float(args.q_low)
    q_high = float(args.q_high)
    if not (0.0 <= q_low < q_high <= 1.0):
        raise ValueError("Require 0 <= q_low < q_high <= 1.")
    obj_min = np.quantile(f, q_low, axis=0)
    obj_max = np.quantile(f, q_high, axis=0)
    span = obj_max - obj_min
    tiny = np.abs(span) < 1e-9
    if np.any(tiny):
        obj_min[tiny] = np.min(f[:, tiny], axis=0)
        obj_max[tiny] = np.max(f[:, tiny], axis=0)

    results_dir = Path(experiment.config.paths.results_dir)
    if not results_dir.is_absolute():
        results_dir = run_dir / results_dir
    results_dir.mkdir(parents=True, exist_ok=True)

    h5_path = results_dir / args.h5_name
    if h5_path.exists():
        h5_path.unlink()
    with h5py.File(h5_path, "w") as hf:
        g = hf.require_group("doe_norm")
        g.create_dataset("X", data=x)
        g.create_dataset("F", data=f)
        g.create_dataset("x_lower", data=lb)
        g.create_dataset("x_upper", data=ub)
        g.create_dataset("obj_min", data=obj_min)
        g.create_dataset("obj_max", data=obj_max)
        g.attrs["variant"] = variant
        g.attrs["q_low"] = q_low
        g.attrs["q_high"] = q_high
        g.create_dataset("variable_names", data=np.asarray(list(pdef.variable_names), dtype="S"))
        g.create_dataset("objective_names", data=np.asarray(list(pdef.objective_names), dtype="S"))

    bounds = {
        "variant": variant,
        "q_low": q_low,
        "q_high": q_high,
        "n_samples": int(args.n_samples),
        "objective_names": list(pdef.objective_names),
        "obj_min": [float(v) for v in obj_min],
        "obj_max": [float(v) for v in obj_max],
    }
    bounds_path = results_dir / args.bounds_json
    bounds_path.write_text(json.dumps(bounds, indent=2), encoding="utf-8")

    print(f"DOE artifact: {h5_path}")  # noqa: T201
    print(f"Bounds JSON: {bounds_path}")  # noqa: T201
    print(f"obj_min={bounds['obj_min']}")  # noqa: T201
    print(f"obj_max={bounds['obj_max']}")  # noqa: T201
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
