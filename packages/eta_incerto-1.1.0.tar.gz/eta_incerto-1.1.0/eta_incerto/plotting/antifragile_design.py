# eta_incerto/plotting/antifragile_design.py
"""
Design-variable scatter visualization for antifragile optimization.

Produces objective-vs-objective scatter panels (same metric pairs as Pareto plots),
with points colored by a design variable so axes and colorbar never duplicate a
design dimension on both x and color.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.pareto import (
    _DEFAULT_OBJECTIVE_PAIRS,
    _canonical_obj_name,
    objective_pair_plot_mask,
)
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint: 455pt x 650pt (same as ParetoPlotter)
_MAX_W_IN = 455.0 / 72.0
_MAX_H_IN = 650.0 / 72.0


@dataclass(frozen=True, slots=True)
class DesignScatterDefaults:
    """Default styling for design-variable scatter plots."""

    w_scale: float = 1.0
    h_scale: float = 1.0
    alpha: float = 0.7
    s: float = 16.0
    cmap: str = "viridis"
    x_label_rotation: float = 25.0


class DesignScatterPlotter(PlotterBase):
    """
    Design-variable scatter plotter for antifragile Pareto datasets.

    Reads:
      config.plots.design_scatter = ["file.h5", ...] (optional)
      Falls back to config.plots.pareto if design_scatter is None/empty.

    Expected HDF5 layout (antifragile format):
      pareto/X           - design variables (n_solutions, n_vars)
      pareto/F           - objectives (n_solutions, n_obj)
      pareto/variable_names
      pareto/objective_names

    Produces:
      One figure per objective pair (x, y), matching pareto_options.pairs or the same
      default antifragile pairs as ParetoPlotter (median/skewness/upr, etc.).
      Color is always a design variable: optional config color_by if it names a design
      column; otherwise the first design variable.
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        # Prefer design_scatter, fall back to pareto
        cfg_ds = getattr(ctx.config.plots, "design_scatter", None)
        cfg_pareto = getattr(ctx.config.plots, "pareto", None)
        cfg = cfg_ds if cfg_ds else cfg_pareto

        if cfg is None:
            raise AttributeError("Missing config: config.plots.design_scatter or config.plots.pareto")

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]
        if not items:
            raise ValueError("config.plots.design_scatter / pareto is empty")

        self.h5_paths = [results_dir / it for it in items]
        self._cfg = cfg
        self._cache: dict[Path, tuple[pd.DataFrame, pd.DataFrame, list[str], list[str]]] = {}

    # -------------------------
    # helpers
    # -------------------------

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, nrows: int = 1, ncols: int = 1, payload: dict[str, Any]):
        """Prefer PlotterBase.make_figure; fallback when ctx has no layout."""
        pid = compute_plot_id(payload)

        try:
            fig, axes = super().make_figure(nrows=nrows, ncols=ncols, plot_id_payload=payload, squeeze=False)
            self._clamp_figsize(fig)
            return fig, axes
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w * ncols, _MAX_W_IN)
            fig_h = min(base_h * nrows, _MAX_H_IN)
            fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(fig_w, fig_h), squeeze=False)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, axes

    @staticmethod
    def _decode_names(arr: Any) -> list[str]:
        out: list[str] = []
        for n in np.asarray(arr):
            if isinstance(n, bytes | np.bytes_):
                out.append(n.decode("utf-8", errors="replace"))
            else:
                out.append(str(n))
        return out

    @staticmethod
    def _first_existing(h5f: h5py.File, candidates: Sequence[str]) -> str | None:
        for p in candidates:
            if p in h5f:
                return p
        return None

    def _resolve_objective_pairs(self, f_df: pd.DataFrame, obj_names: list[str]) -> list[tuple[str, str]]:
        """Same pair resolution as ParetoPlotter (config pairs or antifragile defaults)."""
        opts = getattr(self.ctx.config.plots, "pareto_options", None)
        canonical_to_column: dict[str, str] = {}
        for col in f_df.columns:
            canonical_to_column.setdefault(_canonical_obj_name(col), col)

        def _resolve_col(label: str) -> str | None:
            if label in f_df.columns:
                return label
            return canonical_to_column.get(_canonical_obj_name(label))

        pairs_cfg = getattr(opts, "pairs", None) if opts else None
        if pairs_cfg and isinstance(pairs_cfg, list | tuple):
            pairs: list[tuple[str, str]] = []
            for p in pairs_cfg:
                if isinstance(p, list | tuple) and len(p) >= 2:
                    x_raw, y_raw = str(p[0]), str(p[1])
                    x_col = _resolve_col(x_raw)
                    y_col = _resolve_col(y_raw)
                    if x_col and y_col:
                        pairs.append((x_col, y_col))
            if pairs:
                return pairs
        available: list[tuple[str, str]] = []
        for x_raw, y_raw in _DEFAULT_OBJECTIVE_PAIRS:
            x_col = _resolve_col(x_raw)
            y_col = _resolve_col(y_raw)
            if x_col and y_col:
                available.append((x_col, y_col))
        if available:
            return available
        if len(obj_names) >= 2:
            return [(obj_names[0], obj_names[1])]
        return []

    @staticmethod
    def _pick_design_color_column(
        var_names: Sequence[str],
        combined: pd.DataFrame,
        config_color_by: str,
    ) -> str | None:
        """Color only by a design column; optional config_color_by must name a design variable."""
        var_set = set(var_names)
        if config_color_by and config_color_by in combined.columns and config_color_by in var_set:
            return config_color_by
        if var_names:
            v0 = str(var_names[0])
            return v0 if v0 in combined.columns else None
        return None

    def _load_h5(self, h5_path: Path) -> tuple[pd.DataFrame, pd.DataFrame, list[str], list[str]]:
        """Load X, F, variable_names, objective_names from antifragile H5."""
        if h5_path in self._cache:
            return self._cache[h5_path]

        with h5py.File(h5_path, "r") as f:
            x_path = self._first_existing(f, ["pareto/X", "X"])
            f_path = self._first_existing(f, ["pareto/F", "pareto/f", "F", "f"])
            if not x_path:
                raise KeyError(f"Could not find design variables (pareto/X) in {h5_path}")
            if not f_path:
                raise KeyError(f"Could not find objectives (pareto/F) in {h5_path}")

            x_data = np.asarray(f[x_path], dtype=float)
            f_data = np.asarray(f[f_path], dtype=float)
            if x_data.ndim == 1:
                x_data = x_data.reshape(-1, 1)
            if f_data.ndim == 1:
                f_data = f_data.reshape(-1, 1)

            var_names_path = self._first_existing(f, ["pareto/variable_names", "variable_names"])
            obj_names_path = self._first_existing(
                f,
                [
                    "problem/objective_names",
                    "objective_names",
                    "pareto/objective_names",
                ],
            )

            var_names = (
                self._decode_names(f[var_names_path][:])
                if var_names_path
                else [f"x_{i}" for i in range(x_data.shape[1])]
            )
            obj_names = (
                self._decode_names(f[obj_names_path][:])
                if obj_names_path
                else [f"obj_{i}" for i in range(f_data.shape[1])]
            )

        if len(var_names) != x_data.shape[1]:
            var_names = [f"x_{i}" for i in range(x_data.shape[1])]
        if len(obj_names) != f_data.shape[1]:
            obj_names = [f"obj_{i}" for i in range(f_data.shape[1])]

        x_df = pd.DataFrame(x_data, columns=var_names)
        f_df = pd.DataFrame(f_data, columns=obj_names)
        result = (x_df, f_df, var_names, obj_names)
        self._cache[h5_path] = result
        return result

    def _rc_context(self) -> dict[str, Any]:
        extra_rc = dict(getattr(self._cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    def _plotid_payload(
        self,
        *,
        h5_path: Path,
        w_scale: float,
        h_scale: float,
        color_by: str,
        design_var: str,
    ) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "design_scatter",
            "h5_path": str(h5_path),
            "w_scale": float(w_scale),
            "h_scale": float(h_scale),
            "color_by": str(color_by),
            "design_var": str(design_var),
        }

    def _force_scientific_ticks(self, ax) -> None:
        """
        Force scientific tick notation for both axes to keep consistency with
        high-magnitude antifragile values.
        """
        sci_limits = getattr(self.ctx.style, "sci_limits", (-3, 3))
        for axis in (ax.xaxis, ax.yaxis):
            fmt = mticker.ScalarFormatter(useMathText=True)
            fmt.set_scientific(True)
            # keep style limits but still prefer scientific notation in this view
            fmt.set_powerlimits(sci_limits)
            axis.set_major_formatter(fmt)

    # -------------------------
    # public API
    # -------------------------

    def make_figure(self) -> Figure:
        figs = self.make_figures()
        return figs[0]

    def make_figures(self) -> list[Figure]:  # noqa: PLR0915
        defaults = DesignScatterDefaults()
        cfg = self._cfg
        w_scale = float(getattr(cfg, "w_scale", defaults.w_scale))
        h_scale = float(getattr(cfg, "h_scale", defaults.h_scale))
        alpha = float(getattr(cfg, "alpha", defaults.alpha))
        s = float(getattr(cfg, "s", defaults.s))
        cmap = str(getattr(cfg, "cmap", defaults.cmap))
        tick_style = getattr(cfg, "tick_style", None) or "sci"
        x_label_rotation = float(getattr(cfg, "x_label_rotation", defaults.x_label_rotation))

        # Color must be a design variable; optional config color_by names that column.
        config_color_by = str(getattr(cfg, "color_by", "")).strip()

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            try:
                x_df, f_df, var_names, obj_names = self._load_h5(h5_path)
            except (KeyError, OSError) as e:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "design_scatter",
                    "h5_path": str(h5_path),
                }
                fig, axes = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload)
                ax = axes.flat[0]
                ax.text(0.5, 0.5, f"Could not load: {e}", ha="center", va="center")
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Design scatter ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            combined = pd.concat([x_df, f_df], axis=1)

            n_vars = len(var_names)
            n_obj = len(obj_names)
            if n_vars == 0 or n_obj == 0:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "design_scatter",
                    "h5_path": str(h5_path),
                }
                fig, axes = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload)
                ax = axes.flat[0]
                ax.text(
                    0.5,
                    0.5,
                    "Need design vars and objectives",
                    ha="center",
                    va="center",
                )
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Design scatter ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            pairs = self._resolve_objective_pairs(f_df, obj_names)
            if not pairs:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "design_scatter",
                    "h5_path": str(h5_path),
                }
                fig, axes = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload)
                ax = axes.flat[0]
                ax.text(
                    0.5,
                    0.5,
                    "Need at least two objectives for objectiveâ€“objective scatter",
                    ha="center",
                    va="center",
                )
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Design scatter ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            color_col = self._pick_design_color_column(var_names, combined, config_color_by)
            if not color_col:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "design_scatter",
                    "h5_path": str(h5_path),
                }
                fig, axes = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload)
                ax = axes.flat[0]
                ax.text(
                    0.5,
                    0.5,
                    "Could not resolve a design variable for color",
                    ha="center",
                    va="center",
                )
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Design scatter ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            c_values = combined[color_col].to_numpy()
            sci_limits = getattr(self.ctx.style, "sci_limits", (-3, 3))
            po = getattr(self.ctx.config.plots, "pareto_options", None)
            max_abs_f = getattr(po, "max_abs_f", None) if po else None
            if max_abs_f is not None:
                max_abs_f = float(max_abs_f)

            for x_name, y_name in pairs:
                payload = self._plotid_payload(
                    h5_path=h5_path,
                    w_scale=w_scale,
                    h_scale=h_scale,
                    color_by=color_col,
                    design_var=f"{x_name}__{y_name}",
                )
                fig, axes = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload)

                try:
                    w, h = fig.get_size_inches()
                    fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
                except Exception:
                    pass
                self._clamp_figsize(fig)

                with plt.rc_context(self._rc_context()):
                    ax = axes[0, 0]
                    xv = combined[x_name].to_numpy()
                    yv = combined[y_name].to_numpy()
                    pm, _, _ = objective_pair_plot_mask(xv, yv, max_abs_f=max_abs_f)
                    sc = ax.scatter(
                        xv[pm],
                        yv[pm],
                        c=c_values[pm],
                        s=s,
                        alpha=alpha,
                        cmap=cmap,
                    )
                    self.ctx.style.apply_axis_format(
                        ax,
                        title=f"{x_name} vs {y_name}",
                        xlabel=x_name,
                        ylabel=y_name,
                        grid=False,
                        tick_style=tick_style,
                    )
                    ylab = ax.get_ylabel()
                    if ylab:
                        ax.set_ylabel(ylab, rotation=90)
                    self._force_scientific_ticks(ax)
                    ax.tick_params(axis="x", labelrotation=x_label_rotation)
                    for tick in ax.get_xticklabels():
                        tick.set_ha("right")

                    cbar = fig.colorbar(sc, ax=ax, shrink=0.85)
                    fmt = mticker.ScalarFormatter(useMathText=True)
                    fmt.set_scientific(True)
                    fmt.set_powerlimits(sci_limits)
                    cbar.formatter = fmt
                    cbar.update_ticks()
                    cbar.set_label(color_col)

                    fig.suptitle(
                        f"{h5_path.stem} | {x_name} vs {y_name} (color: {color_col})",
                        fontsize=9,
                    )
                fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)

        return figs


if __name__ == "__main__":
    pass
