# eta_incerto/plotting/scenario.py
from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path
from typing import Any

import h5py
import matplotlib.axes
import matplotlib.pyplot as plt
import numpy as np

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext

# Notes on context compatibility
# ------------------------------
# Some code paths provide a PlotContext without a `.layout` attribute, while
# PlotterBase expects `ctx.layout` and, in particular, a `ctx.layout.figsize(...)`
# method. To keep plotters interoperable across context variants (including
# frozen dataclass contexts), this module constructs a small proxy context that
# supplies a minimal layout implementation when needed. The original context is
# never mutated.

SHORT_SCENARIO_LABELS: dict[str, str] = {
    "variant_one_eta_S1_invest": "S1",
    "variant_one_eta_S2_invest": "S2",
    "variant_one_eta_S3_invest": "S3",
    "variant_two_eta_S1_invest": "S1",
    "variant_two_eta_S2_invest": "S2",
    "variant_two_eta_S3_invest": "S3",
}


class ScenarioPlotter(PlotterBase):
    """Scenario plotter using centralized PlotStyle (incl. fonts) from style.py.

    Expected HDF5 layout:
      scenarios/<scenario>/carriers/<carrier>/<metric>/year
      scenarios/<scenario>/carriers/<carrier>/<metric>/value
      scenarios/<scenario>/probability

    Styling contract:
      - Typography (font family/sizes, mathtext, etc.) MUST come from ctx.style.rcparams
        which is defined centrally in eta_incerto/plotting/style.py.
      - Axis label formatting (units, rotation, pads, tick format, grid/spines) should use
        PlotStyle helpers where possible.
      - This plotter only specifies plot-local layout choices (e.g., legend placement).
    """

    def __init__(
        self,
        ctx: PlotContext,
        *,
        # Optional explicit inputs for environments without ctx.config
        h5_path: str | Path | None = None,
        h5_paths: Iterable[str | Path] | None = None,
    ) -> None:
        # ------------------------------------------------------------------
        # Build an "effective" context compatible with PlotterBase.
        # ------------------------------------------------------------------
        style = getattr(ctx, "style", None)
        if style is None:
            raise AttributeError("ScenarioPlotter requires a context with `.style`.")

        layout = getattr(ctx, "layout", None)
        if layout is None:

            class _FallbackLayout:
                """Minimal layout provider for PlotterBase.

                The base width/height represent a single subplot. The resulting
                figure size scales linearly with (ncols, nrows) and optional
                scale factors.
                """

                def __init__(self, base_w_in: float, base_h_in: float) -> None:
                    self.base_w_in = float(base_w_in)
                    self.base_h_in = float(base_h_in)

                def figsize(
                    self,
                    *,
                    nrows: int,
                    ncols: int,
                    w_scale: float = 1.0,
                    h_scale: float = 1.0,
                ) -> tuple[float, float]:
                    nrows_i = max(1, int(nrows))
                    ncols_i = max(1, int(ncols))
                    w = self.base_w_in * ncols_i * float(w_scale)
                    h = self.base_h_in * nrows_i * float(h_scale)
                    return float(w), float(h)

            layout = _FallbackLayout(base_w_in=float(style.fig_w_in), base_h_in=float(style.fig_h_in))

        config = getattr(ctx, "config", None)
        preset_name = getattr(ctx, "preset_name", None)

        class _CtxProxy:
            """Context adapter exposing the attributes required by PlotterBase.

            We forward style/layout/config/preset_name as PlotterBase expects those
            attributes on ctx, while ensuring we never mutate the caller's context.
            """

            def __init__(self, style, layout, config, preset_name) -> None:
                self.style = style
                self.layout = layout
                self.config = config
                self.preset_name = preset_name

        effective_ctx = _CtxProxy(style=style, layout=layout, config=config, preset_name=preset_name)

        # Initialize PlotterBase using the proxy context (do not mutate caller context).
        super().__init__(effective_ctx)  # type: ignore[arg-type]

        # Keep a reference for config-driven file discovery (may be None).
        self._config = config

        # ------------------------------------------------------------------
        # Resolve input HDF5 file paths.
        # ------------------------------------------------------------------
        explicit_paths = (h5_path is not None) or (h5_paths is not None)

        if explicit_paths:
            if h5_paths is not None:
                self.h5_paths = [Path(p) for p in h5_paths]
            else:
                self.h5_paths = [Path(h5_path)]  # type: ignore[list-item]
        else:
            if self._config is None:
                raise AttributeError(
                    "ScenarioPlotter requires ctx.config (config-driven mode) or explicit h5_path/h5_paths."
                )
            results_dir = Path(self._config.paths.results_dir)
            files = list(self._config.plots.scenario)
            self.h5_paths = [results_dir / fn for fn in files]

        if not self.h5_paths:
            raise ValueError("No scenario result files configured/provided.")

    # ------------------------------------------------------------------
    # HDF5 accessors
    # ------------------------------------------------------------------

    def _scenario_names(self, f: h5py.File) -> list[str]:
        return sorted(f["scenarios"].keys())

    def _carriers(self, f: h5py.File, scenario: str) -> list[str]:
        return sorted(f[f"scenarios/{scenario}/carriers"].keys())

    def _metrics_for_carrier(self, f: h5py.File, scenario: str, carrier: str) -> list[str]:
        """Return metrics that have year and value for this carrier (from H5 only)."""
        base = f"scenarios/{scenario}/carriers/{carrier}"
        if base not in f:
            return []
        carr_grp = f[base]
        if not isinstance(carr_grp, h5py.Group):
            return []
        out = []
        for key in carr_grp:
            sub = carr_grp[key]
            if not isinstance(sub, h5py.Group):
                continue
            if "year" in sub and "value" in sub:
                out.append(key)
        return sorted(out)

    def _probability(self, f: h5py.File, scenario: str) -> float:
        return float(np.array(f[f"scenarios/{scenario}/probability"])[()])

    def _series(self, f: h5py.File, scenario: str, carrier: str, metric: str) -> tuple[np.ndarray, np.ndarray]:
        base = f"scenarios/{scenario}/carriers/{carrier}/{metric}"
        years = np.array(f[f"{base}/year"])
        values = np.array(f[f"{base}/value"], dtype=float)
        return years, values

    @staticmethod
    def _metric_display_name(metric: str) -> str:
        """Human-readable label for metric in figure titles."""
        if metric == "unit_price":
            return "cost"
        if metric == "emissions_per_unit":
            return "CO2 intensity"
        return metric

    def _unit_from_h5(self, f: h5py.File, scenario: str, carrier: str, metric: str) -> str | None:
        """Read unit from H5 when available (dataset or group attributes)."""
        base = f"scenarios/{scenario}/carriers/{carrier}/{metric}"
        for path in (f"{base}/value", base, f"scenarios/{scenario}/carriers/{carrier}"):
            if path not in f:
                continue
            obj = f[path]
            for attr in ("unit", "units"):
                if hasattr(obj, "attrs") and attr in obj.attrs:
                    val = obj.attrs[attr]
                    if isinstance(val, str | bytes):
                        return val.decode() if isinstance(val, bytes) else val
        return None

    # ------------------------------------------------------------------
    # Styling helpers (centralized fonts live in ctx.style.rcparams)
    # ------------------------------------------------------------------

    def _style_rcparams(self) -> dict[str, Any]:
        """Return matplotlib rcParams from the active PlotStyle.

        This is the central mechanism by which font family/sizes (and other
        typography settings) are applied. We intentionally do NOT set font
        properties locally in this plotter.
        """
        style = getattr(self.ctx, "style", None)
        if style is None:
            return {}
        rc = getattr(style, "rcparams", None)
        return dict(rc) if isinstance(rc, dict) else {}

    def _get_linestyles(self) -> list[str]:
        """Return configured linestyles or a stable default sequence."""
        try:
            linestyles = list(self.linestyles)  # type: ignore[arg-type]
        except Exception:
            linestyles = []
        return linestyles or ["-", "--", ":", "-."]

    def _format_label(self, scen: str, *, show_prob: bool, f: h5py.File) -> str:
        """Map a scenario name to a display label, optionally including probability."""
        label = SHORT_SCENARIO_LABELS.get(scen, scen)
        if show_prob:
            p = self._probability(f, scen)
            return f"{label} (p={p:.3f})"
        return label

    def _series_kwargs(self, series_index: int) -> dict[str, Any]:
        """Resolve per-series styling from ctx.style where available.

        We delegate color/marker decisions to the centralized PlotStyle. Linestyle
        remains controlled in this plotter to encode scenario identity consistently.
        """
        style = getattr(self.ctx, "style", None)
        if style is not None:
            fn = getattr(style, "series_style", None)
            if callable(fn):
                kw = dict(fn(series_index))
                # Keep linestyle encoding local and consistent across plotters.
                kw.pop("linestyle", None)
                return kw
        # Fallback: keep the plot readable in the absence of a style definition.
        return {"color": "black"}

    def _legend_defaults_for_target(self) -> tuple[int, str | int, bool]:
        """Return (ncol, fontsize, frameon) defaults consistent with PlotStyle target."""
        style = getattr(self.ctx, "style", None)
        tgt = str(getattr(style, "target", "paper")).lower() if style is not None else "paper"
        if tgt == "slides":
            return 2, "medium", True
        return 1, "small", False

    def _place_global_legend_target(self, axes_list: list[matplotlib.axes.Axes]) -> None:
        """Place a single legend inside the first subplot (bottom-left).

        The legend is anchored inside the axes to match the reference layout and to
        avoid interfering with external figure layout policies.

        NOTE: We do not override font properties here; legend typography is driven
        by matplotlib rcParams coming from PlotStyle.rcparams (centralized).
        """
        if not axes_list:
            return

        ax0 = axes_list[0]
        handles, labels = ax0.get_legend_handles_labels()
        if not handles:
            return

        # Remove per-axes legends to avoid duplicates.
        for ax in axes_list:
            leg = ax.get_legend()
            if leg is not None:
                leg.remove()

        ncol, fontsize, frameon = self._legend_defaults_for_target()

        # Always draw a legend frame so the semi-transparent background
        # is visible, regardless of style defaults.
        leg = ax0.legend(
            handles,
            labels,
            loc="lower left",
            # Anchor at the lower-left of the axes coordinate system.
            bbox_to_anchor=(0.0, 0.0),
            ncol=int(ncol),
            frameon=True,
            borderaxespad=0.3,
            columnspacing=0.8,
            handlelength=2.0,
            handletextpad=0.4,
            fontsize=fontsize,
        )
        if leg is not None:
            frame = leg.get_frame()
            frame.set_facecolor("white")
            # Semi-transparent white background; increase alpha if you
            # want a more opaque panel (e.g. 0.4 or 0.6).
            frame.set_alpha(0.8)

    # ------------------------------------------------------------------
    # Plotting
    # ------------------------------------------------------------------

    def _resolve_y_unit(self, f: h5py.File, scenario: str, carrier: str, metric: str) -> str:
        """Unit from H5 when available; fallback by metric/carrier until pipeline writes units."""
        y_unit = self._unit_from_h5(f, scenario, carrier, metric)
        if y_unit is not None:
            return y_unit
        if metric == "unit_price":
            return "EUR/kg" if str(carrier).lower() == "co2" else "EUR/Wh"
        return "kgCO_2/Wh"  # emissions_per_unit (CO2 intensity)

    def _format_carrier_axis(
        self,
        ax: matplotlib.axes.Axes,
        carrier: str,
        xlab: str,
        y_unit: str,
        *,
        grid: bool,
    ) -> None:
        """Apply axis format and spines for one carrier subplot."""
        style = getattr(self.ctx, "style", None)
        if style is not None:
            style.apply_axis_format(
                ax,
                xlabel=xlab,
                ylabel=str(carrier),
                y_unit=y_unit,
                grid=grid,
                tick_style="sci",
            )
        ylabel = ax.get_ylabel()
        if ylabel:
            ax.set_ylabel(ylabel, rotation=90)
        for spine in ("top", "right", "bottom", "left"):
            ax.spines[spine].set_visible(True)

    def plot_into(
        self,
        axes: Iterable[matplotlib.axes.Axes],
        *,
        file_index: int = 0,
        metric: str = "unit_price",
        carriers: list[str] | None = None,
        title: str | None = "Scenarios",
        legend: bool = True,
        legend_ncol: int = 3,  # kept for API compatibility (not used for global legend)
        show_probability_in_legend: bool = False,
        xlabel: str = "year",
        grid: bool = True,
    ) -> list[matplotlib.axes.Axes]:
        """Plot a single HDF5 file into provided axes.

        This method assumes the caller already created the figure/axes. Fonts and
        sizes are applied via rc_context at figure-creation time (see make_figures),
        and axis-level formatting is delegated to PlotStyle helpers.
        """
        style = getattr(self.ctx, "style", None)
        if style is None:
            raise AttributeError("ScenarioPlotter requires ctx.style.")

        axes_list = [axes] if isinstance(axes, matplotlib.axes.Axes) else list(axes)
        h5_path = self.h5_paths[file_index]

        for ax in axes_list:
            ax.cla()

        linestyles = self._get_linestyles()
        scale = 1.0

        with h5py.File(h5_path, "r") as f:
            scen_names = self._scenario_names(f)
            if not scen_names:
                if title and axes_list:
                    axes_list[0].figure.suptitle(title)
                return axes_list

            carrs = carriers or self._carriers(f, scen_names[0])
            n = min(len(carrs), len(axes_list))
            carrs = carrs[:n]
            axes_list = axes_list[:n]

            for i, (carrier, ax) in enumerate(zip(carrs, axes_list, strict=False)):
                y_unit = self._resolve_y_unit(f, scen_names[0], carrier, metric)
                for j, scen in enumerate(scen_names):
                    years, values = self._series(f, scen, carrier, metric)
                    ax.plot(
                        years,
                        values * scale,
                        label=self._format_label(scen, show_prob=show_probability_in_legend, f=f),
                        linestyle=linestyles[j % len(linestyles)],
                        **self._series_kwargs(j),
                    )

                is_last = i == n - 1
                xlab = xlabel if is_last else ""
                if not is_last:
                    ax.tick_params(labelbottom=False)
                self._format_carrier_axis(ax, carrier, xlab, y_unit, grid=grid)

            if legend and axes_list:
                self._place_global_legend_target(axes_list)

        if title and axes_list:
            fig = axes_list[0].figure
            default_fs = plt.rcParams.get("axes.titlesize", plt.rcParams.get("font.size", 10))
            # rcParams can be a named size ('large', 'small', etc.); pass through
            fontsize = 0.9 * default_fs if isinstance(default_fs, int | float) else default_fs
            fig.suptitle(title, y=0.93, fontsize=fontsize)

        return axes_list

    def make_figures(
        self,
        *,
        metric: str = "unit_price",
        carriers: list[str] | None = None,
        title_prefix: str = "Scenarios",
        legend: bool = True,
        legend_ncol: int = 3,
        show_probability_in_legend: bool = True,
        xlabel: str = "year",
        grid: bool = True,
    ) -> list[plt.Figure]:
        """Create one figure per configured scenario result file.

        IMPORTANT: We wrap figure creation + plotting in plt.rc_context(style.rcparams).
        This is the single, centralized hook that applies the font family/sizes from
        style.py to everything (axes, labels, titles, legends, mathtext, ...).
        """
        rcparams = self._style_rcparams()

        figs: list[plt.Figure] = []
        with plt.rc_context(rcparams or None):
            for i, p in enumerate(self.h5_paths):
                # Carriers from H5 only (only source for plotting).
                with h5py.File(self.h5_paths[i], "r") as f:
                    scen_names = self._scenario_names(f)
                    if not scen_names:
                        fig, ax = super().make_figure(nrows=1, ncols=1, squeeze=True)
                        self.plot_into(
                            ax,
                            file_index=i,
                            metric=metric,
                            carriers=carriers,
                            title=f"{title_prefix}: {p.stem}",
                            legend=legend,
                            legend_ncol=legend_ncol,
                            show_probability_in_legend=show_probability_in_legend,
                            xlabel=xlabel,
                            grid=grid,
                        )
                        figs.append(fig)
                        continue
                    carriers_in_h5 = self._carriers(f, scen_names[0])
                    # Collect (carrier, metric) pairs from H5: cost + CO2 intensity per carrier.
                    carrier_metrics: list[tuple[str, str]] = []
                    for carr in carriers_in_h5:
                        for m in self._metrics_for_carrier(f, scen_names[0], carr):
                            carrier_metrics.append((carr, m))

                for carrier, m in carrier_metrics:
                    fig, ax = super().make_figure(nrows=1, ncols=1, squeeze=True)
                    display = self._metric_display_name(m)
                    self.plot_into(
                        ax,
                        file_index=i,
                        metric=m,
                        carriers=[carrier],
                        title=f"{title_prefix}: {carrier} - {display}",
                        legend=legend,
                        legend_ncol=legend_ncol,
                        show_probability_in_legend=show_probability_in_legend,
                        xlabel=xlabel,
                        grid=grid,
                    )
                    figs.append(fig)

        return figs


if __name__ == "__main__":
    pass
