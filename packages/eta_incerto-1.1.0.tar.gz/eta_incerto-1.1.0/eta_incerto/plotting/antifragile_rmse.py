# eta_incerto/plotting/antifragile_rmse.py
"""
PCE RMSE plotter for antifragile / surrogate model quality evaluation.

Renders RMSE vs PCE order when rmse/ group exists in H5. When
pce_diagnostics/rmse is present (LOO or k-fold from pcetest), optionally
adds a second figure: diagnostic error vs design variable, one line per
polynomial order (thesis Figure 9 style). Multi-axis pcetest layout (by_axis/{k}/...) produces, per pymoo variable:
diagnostic or validation RMSE vs PCE order (one line per sweep point), and
when diagnostics exist and pce_plot_diagnostic_vs_design is True, a second
figure: LOO/CV vs that variable's sweep (one line per order), matching the
legacy Figure 9 style. Gracefully skips when no supported RMSE data is present.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint: 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0
_MAX_H_IN = 650.0 / 72.0

_SKIP_MSG_NO_RMSE = "No RMSE data (rmse/matrix) in H5. Skipping PCE RMSE plot."
_SKIP_MSG_NO_CONFIG = "config.plots.pce_rmse not configured."


@dataclass(frozen=True, slots=True)
class RmsePlotDefaults:
    """Default styling for PCE RMSE plots."""

    w_scale: float = 1.0
    h_scale: float = 1.0
    alpha: float = 0.8
    tick_style: str = "sci"


def _has_rmse_data(h5_path: Path) -> bool:
    """Check if H5 file contains RMSE data (rmse/matrix)."""
    try:
        with h5py.File(h5_path, "r") as f:
            return "rmse" in f and "rmse/matrix" in f
    except (OSError, KeyError):
        return False


def _has_multi_axis_pcetest(h5_path: Path) -> bool:
    """pcetest multi_axis_sweep layout: by_axis/<k>/rmse."""
    try:
        with h5py.File(h5_path, "r") as f:
            if "by_axis" not in f or "orders" not in f["by_axis"]:
                return False
            bx = f["by_axis"]
            for key in bx:
                if key == "orders":
                    continue
                sub = bx[key]
                if isinstance(sub, h5py.Group) and "rmse" in sub:
                    return True
            return False
    except (OSError, KeyError):
        return False


def _decode_order_labels(arr: Any) -> list[str]:
    out: list[str] = []
    for n in np.asarray(arr):
        if isinstance(n, bytes | np.bytes_):
            out.append(n.decode("utf-8", errors="replace"))
        else:
            out.append(str(n))
    return out


class AntifragileRmsePlotter(PlotterBase):
    """
    PCE RMSE plotter for surrogate model quality.

    Reads:
      config.plots.pce_rmse = "file.h5" or ["file.h5", ...] (optional)

    Expected HDF5 layout (pcetest format):
      rmse/design_var  - design variable values (1D)
      rmse/matrix      - RMSE matrix (n_design_points, n_orders)
      rmse/orders      - PCE order indices (1..max_order)
      rmse/order_labels - optional labels

    Produces:
      Line plot: RMSE vs PCE order. One line per design point, or mean.
      Returns empty list when no RMSE data exists (graceful skip).
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        cfg = getattr(ctx.config.plots, "pce_rmse", None)

        if cfg is None:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]
        if not items:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        self.h5_paths = [results_dir / it for it in items]
        self._skip_reason = None
        self._cfg = cfg

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        pid = compute_plot_id(payload)
        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            self._clamp_figsize(fig)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)
            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, ax

    def _load_rmse(self, h5_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str]]:
        """Load design_var, matrix, orders, order_labels from rmse/ group."""
        with h5py.File(h5_path, "r") as f:
            g = f["rmse"]
            design_var = np.asarray(g["design_var"], dtype=float).flatten()
            matrix = np.asarray(g["matrix"], dtype=float)
            if matrix.ndim == 1:
                matrix = matrix.reshape(-1, 1)
            orders = np.asarray(g["orders"], dtype=float).flatten()
            if "order_labels" in g:
                order_labels = _decode_order_labels(g["order_labels"][:])
            else:
                order_labels = [f"Order {int(o)}" for o in orders]
        return design_var, matrix, orders, order_labels

    def _try_load_diagnostic_matrix(self, h5_path: Path) -> tuple[np.ndarray, str] | None:
        """Return (diagnostics_matrix, mode_str) from pce_diagnostics/rmse, or None."""
        try:
            with h5py.File(h5_path, "r") as f:
                if "pce_diagnostics" not in f or "rmse" not in f["pce_diagnostics"]:
                    return None
                dgrp = f["pce_diagnostics"]
                raw_mode = dgrp.attrs.get("mode", b"")
                mode_str = raw_mode.decode("utf-8", errors="replace") if isinstance(raw_mode, bytes) else str(raw_mode)
                mat = np.asarray(dgrp["rmse"][:], dtype=float)
                if mat.ndim == 1:
                    mat = mat.reshape(-1, 1)
                if mat.size == 0:
                    return None
                return mat, mode_str
        except (OSError, KeyError):
            return None

    @staticmethod
    def _diagnostic_ylabel(mode_str: str) -> str:
        m = mode_str.lower()
        if m == "loo":
            return "Leave-One-Out error"
        if m == "kfold":
            return "K-fold CV RMSE"
        return "PCE diagnostic RMSE"

    def _make_diagnostic_vs_design_figure(  # noqa: PLR0913
        self,
        h5_path: Path,
        design_var: np.ndarray,
        diag: np.ndarray,
        orders: np.ndarray,
        *,
        w_scale: float,
        h_scale: float,
        alpha: float,
        tick_style: str,
        mode_str: str,
        variable_name: str | None = None,
        axis_key: str | None = None,
    ) -> Figure:
        """LOO/CV RMSE vs design variable; one line per PCE order (Figure 9 style)."""
        payload: dict[str, Any] = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "antifragile_pce_diagnostic_vs_design",
            "h5_path": str(h5_path),
            "mode": mode_str,
        }
        if variable_name is not None:
            payload["variable_name"] = variable_name
        if axis_key is not None:
            payload["axis"] = axis_key
        fig, ax = self._make_figure_with_fallback(payload=payload)
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
        except Exception:
            pass
        self._clamp_figsize(fig)

        order_idx = np.argsort(design_var)
        x = design_var[order_idx]
        y = diag[order_idx, :]
        n_ord = min(y.shape[1], len(orders))

        plots_cfg = self.ctx.config.plots
        xlabel = getattr(plots_cfg, "pce_design_var_xlabel", None) or (
            variable_name if variable_name else "Design variable"
        )
        plot_title = f"{h5_path.stem} | PCE vs design"
        if variable_name:
            plot_title = f"{h5_path.stem} | {variable_name} | diagnostic vs design"

        with plt.rc_context(self._rc_context()):
            prop_cycle = plt.rcParams.get("axes.prop_cycle", None)
            colors = prop_cycle.by_key().get("color", []) if prop_cycle is not None else []
            for j in range(n_ord):
                p = int(orders[j]) if j < len(orders) else j + 1
                c = colors[j % len(colors)] if colors else None
                lab = f"$p = {p}$"
                ax.plot(x, y[:, j], "o-", alpha=alpha, color=c, markersize=5, label=lab)

            self.ctx.style.apply_axis_format(
                ax,
                title=plot_title,
                xlabel=xlabel,
                ylabel=self._diagnostic_ylabel(mode_str),
                grid=True,
                tick_style=tick_style,
            )
            ax.legend(fontsize=8, loc="best")

        fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
        self._clamp_figsize(fig)
        return fig

    def _rc_context(self) -> dict[str, Any]:
        if self._cfg is None:
            return dict(getattr(self.ctx.style, "rcparams", {}) or {})
        extra_rc = dict(getattr(self._cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    def _make_multi_axis_figures(
        self,
        h5_path: Path,
        *,
        w_scale: float,
        h_scale: float,
        alpha: float,
        tick_style: str,
    ) -> list[Figure]:
        """One figure per pymoo variable: LOO/CV or validation RMSE vs order, one line per sweep point."""
        figs: list[Figure] = []
        plots_cfg = self.ctx.config.plots
        max_leg = int(getattr(plots_cfg, "pce_multi_axis_max_legend_lines", 12))

        with h5py.File(h5_path, "r") as f:
            bx = f["by_axis"]
            orders = np.asarray(bx["orders"][:], dtype=float).flatten()
            axis_keys = sorted((k for k in bx if k != "orders"), key=int)

            for ak in axis_keys:
                g = bx[ak]
                sweep = np.asarray(g["sweep_values"][:], dtype=float).flatten()
                vname = g.attrs.get("variable_name", ak)
                if isinstance(vname, bytes):
                    vname = vname.decode("utf-8", errors="replace")
                vname = str(vname)

                use_diag = "pce_diagnostics" in g and "rmse" in g["pce_diagnostics"]
                if use_diag:
                    dgrp = g["pce_diagnostics"]
                    raw_mode = dgrp.attrs.get("mode", b"")
                    mode_str = (
                        raw_mode.decode("utf-8", errors="replace") if isinstance(raw_mode, bytes) else str(raw_mode)
                    )
                    data = np.asarray(dgrp["rmse"][:], dtype=float)
                    ylabel = self._diagnostic_ylabel(mode_str)
                else:
                    data = np.asarray(g["rmse"][:], dtype=float)
                    mode_str = "validation"
                    ylabel = "RMSE (validation)"

                if data.ndim == 1:
                    data = data.reshape(-1, 1)
                if data.size == 0 or orders.size == 0:
                    continue

                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "antifragile_pce_multi_axis_vs_order",
                    "h5_path": str(h5_path),
                    "axis": ak,
                    "variable_name": vname,
                }
                fig, ax = self._make_figure_with_fallback(payload=payload)
                try:
                    ww, hh = fig.get_size_inches()
                    fig.set_size_inches(ww * w_scale, hh * h_scale, forward=True)
                except Exception:
                    pass
                self._clamp_figsize(fig)

                n_sweep = data.shape[0]
                prop_cycle = plt.rcParams.get("axes.prop_cycle", None)
                colors = prop_cycle.by_key().get("color", []) if prop_cycle is not None else []

                with plt.rc_context(self._rc_context()):
                    for i in range(n_sweep):
                        lab = f"{sweep[i]:.4g}" if i < max_leg else None
                        c = colors[i % len(colors)] if colors else None
                        ax.plot(orders, data[i, :], "o-", alpha=alpha, color=c, markersize=4, label=lab)
                    if n_sweep <= max_leg and n_sweep > 1:
                        ax.legend(title=vname, fontsize=7, loc="best")

                    plot_title = f"{h5_path.stem} | {vname}"
                    if n_sweep > max_leg:
                        plot_title = f"{plot_title}\n(legend: first {max_leg} sweep values)"

                    self.ctx.style.apply_axis_format(
                        ax,
                        title=plot_title,
                        xlabel="PCE order",
                        ylabel=ylabel,
                        grid=True,
                        tick_style=tick_style,
                    )
                    ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))

                fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)

                plot_diag_vs_design = bool(getattr(plots_cfg, "pce_plot_diagnostic_vs_design", True))
                if plot_diag_vs_design and use_diag:
                    fig_d = self._make_diagnostic_vs_design_figure(
                        h5_path,
                        sweep,
                        data,
                        orders,
                        w_scale=w_scale,
                        h_scale=h_scale,
                        alpha=alpha,
                        tick_style=tick_style,
                        mode_str=mode_str,
                        variable_name=vname,
                        axis_key=str(ak),
                    )
                    figs.append(fig_d)

        return figs

    def make_figures(self) -> list[Figure]:  # noqa: PLR0912
        """
        Produce PCE RMSE figures. Returns empty list when no RMSE data.
        """
        if self._skip_reason is not None:
            return []

        defaults = RmsePlotDefaults()
        cfg = self._cfg
        w_scale = float(getattr(cfg, "w_scale", defaults.w_scale)) if cfg else defaults.w_scale
        h_scale = float(getattr(cfg, "h_scale", defaults.h_scale)) if cfg else defaults.h_scale
        alpha = float(getattr(cfg, "alpha", defaults.alpha)) if cfg else defaults.alpha
        tick_style = str(getattr(cfg, "tick_style", defaults.tick_style)) if cfg else defaults.tick_style
        plot_mean_only = bool(getattr(cfg, "plot_mean_only", False)) if cfg else False

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            if not h5_path.exists():
                continue
            if _has_multi_axis_pcetest(h5_path):
                figs.extend(
                    self._make_multi_axis_figures(
                        h5_path,
                        w_scale=w_scale,
                        h_scale=h_scale,
                        alpha=alpha,
                        tick_style=tick_style,
                    )
                )
                continue
            if not _has_rmse_data(h5_path):
                continue

            try:
                design_var, matrix, orders, order_labels = self._load_rmse(h5_path)
            except (KeyError, OSError):
                continue

            if matrix.size == 0 or orders.size == 0:
                continue

            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "antifragile_rmse",
                "h5_path": str(h5_path),
            }
            fig, ax = self._make_figure_with_fallback(payload=payload)

            try:
                w, h = fig.get_size_inches()
                fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
            except Exception:
                pass
            self._clamp_figsize(fig)

            with plt.rc_context(self._rc_context()):
                if plot_mean_only or matrix.shape[0] == 1:
                    rmse_mean = np.mean(matrix, axis=0)
                    ax.plot(orders, rmse_mean, "o-", alpha=alpha, c="0.35", markersize=6)
                else:
                    for i in range(matrix.shape[0]):
                        label = f"x={design_var[i]:.1f}" if i < 10 else None
                        ax.plot(
                            orders,
                            matrix[i, :],
                            "o-",
                            alpha=alpha,
                            c="0.35",
                            markersize=4,
                            label=label,
                        )
                    if matrix.shape[0] <= 10:
                        ax.legend(fontsize=7)

                self.ctx.style.apply_axis_format(
                    ax,
                    title=f"{h5_path.stem} | PCE RMSE",
                    xlabel="PCE order",
                    ylabel="RMSE",
                    grid=True,
                    tick_style=tick_style,
                )
                ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))

            fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
            self._clamp_figsize(fig)
            figs.append(fig)

            plot_diag = bool(getattr(self.ctx.config.plots, "pce_plot_diagnostic_vs_design", True))
            if plot_diag:
                loaded = self._try_load_diagnostic_matrix(h5_path)
                if loaded is not None:
                    diag_mat, mode_s = loaded
                    if (
                        diag_mat.shape[0] == design_var.shape[0]
                        and diag_mat.shape[1] == matrix.shape[1]
                        and design_var.size > 0
                    ):
                        fig2 = self._make_diagnostic_vs_design_figure(
                            h5_path,
                            design_var,
                            diag_mat,
                            orders,
                            w_scale=w_scale,
                            h_scale=h_scale,
                            alpha=alpha,
                            tick_style=tick_style,
                            mode_str=mode_s,
                        )
                        figs.append(fig2)

        return figs

    def make_figure(self) -> Figure | None:
        figs = self.make_figures()
        return figs[0] if figs else None


if __name__ == "__main__":
    pass
