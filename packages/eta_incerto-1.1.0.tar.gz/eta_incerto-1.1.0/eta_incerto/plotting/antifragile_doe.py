# eta_incerto/plotting/antifragile_doe.py
"""
DOE (Design of Experiments) evaluation plotter for antifragile optimization.

Renders design-variable vs objective scatter when pareto/X and pareto/F exist
in the H5 file. Gracefully skips with a clear message when DOE data is absent.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint: 455pt x 650pt (same as ParetoPlotter)
_MAX_W_IN = 455.0 / 72.0
_MAX_H_IN = 650.0 / 72.0

_SKIP_MSG_NO_DOE = "No DOE data (pareto/X) in H5. Skipping DOE plot."
_SKIP_MSG_NO_CONFIG = "config.plots.design_doe (or design_scatter/pareto) not configured."


@dataclass(frozen=True, slots=True)
class DoePlotDefaults:
    """Default styling for DOE evaluation plots."""

    w_scale: float = 1.0
    h_scale: float = 1.0
    alpha: float = 0.7
    s: float = 18.0
    x_label_rotation: float = 25.0


def _first_existing(h5f: h5py.File, candidates: Sequence[str]) -> str | None:
    for p in candidates:
        if p in h5f:
            return p
    return None


def _decode_names(arr: Any) -> list[str]:
    out: list[str] = []
    for n in np.asarray(arr):
        if isinstance(n, bytes | np.bytes_):
            out.append(n.decode("utf-8", errors="replace"))
        else:
            out.append(str(n))
    return out


def _has_doe_data(h5_path: Path) -> bool:
    """Check if H5 file contains DOE data (pareto/X)."""
    try:
        with h5py.File(h5_path, "r") as f:
            return _first_existing(f, ["pareto/X", "X"]) is not None
    except (OSError, KeyError):
        return False


class AntifragileDoePlotter(PlotterBase):
    """
    DOE evaluation plotter for antifragile Pareto datasets.

    Reads:
      config.plots.design_doe = ["file.h5", ...] (optional)
      Falls back to config.plots.design_scatter, then config.plots.pareto.

    Expected HDF5 layout (antifragile format):
      pareto/X           - design variables (n_solutions, n_vars)
      pareto/F           - objectives (n_solutions, n_obj)
      pareto/variable_names, pareto/objective_names

    Produces:
      Compact scatter: first design var vs first objective per file.
      Returns empty list when no DOE data exists (graceful skip).
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        cfg_doe = getattr(ctx.config.plots, "design_doe", None)
        cfg_ds = getattr(ctx.config.plots, "design_scatter", None)
        cfg_pareto = getattr(ctx.config.plots, "pareto", None)
        cfg = cfg_doe or cfg_ds or cfg_pareto

        if cfg is None:
            self.h5_paths: list[Path] = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]
        if not items:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        self.h5_paths = [results_dir / it for it in items]
        self._skip_reason = None
        self._cfg = cfg
        self._cache: dict[Path, tuple[pd.DataFrame, pd.DataFrame, list[str], list[str]]] = {}

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        pid = compute_plot_id(payload)
        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            self._clamp_figsize(fig)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)
            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, ax

    def _load_h5(self, h5_path: Path) -> tuple[pd.DataFrame, pd.DataFrame, list[str], list[str]]:
        if h5_path in self._cache:
            return self._cache[h5_path]

        with h5py.File(h5_path, "r") as f:
            x_path = _first_existing(f, ["pareto/X", "X"])
            f_path = _first_existing(f, ["pareto/F", "pareto/f", "F", "f"])
            if not x_path:
                raise KeyError(f"Could not find design variables (pareto/X) in {h5_path}")
            if not f_path:
                raise KeyError(f"Could not find objectives (pareto/F) in {h5_path}")

            x_data = np.asarray(f[x_path], dtype=float)
            f_data = np.asarray(f[f_path], dtype=float)
            if x_data.ndim == 1:
                x_data = x_data.reshape(-1, 1)
            if f_data.ndim == 1:
                f_data = f_data.reshape(-1, 1)

            var_names_path = _first_existing(f, ["pareto/variable_names", "variable_names"])
            obj_names_path = _first_existing(
                f,
                ["problem/objective_names", "objective_names", "pareto/objective_names"],
            )

            var_names = (
                _decode_names(f[var_names_path][:]) if var_names_path else [f"x_{i}" for i in range(x_data.shape[1])]
            )
            obj_names = (
                _decode_names(f[obj_names_path][:]) if obj_names_path else [f"obj_{i}" for i in range(f_data.shape[1])]
            )

        if len(var_names) != x_data.shape[1]:
            var_names = [f"x_{i}" for i in range(x_data.shape[1])]
        if len(obj_names) != f_data.shape[1]:
            obj_names = [f"obj_{i}" for i in range(f_data.shape[1])]

        x_df = pd.DataFrame(x_data, columns=var_names)
        f_df = pd.DataFrame(f_data, columns=obj_names)
        result = (x_df, f_df, var_names, obj_names)
        self._cache[h5_path] = result
        return result

    def _rc_context(self) -> dict[str, Any]:
        if self._cfg is None:
            return dict(getattr(self.ctx.style, "rcparams", {}) or {})
        extra_rc = dict(getattr(self._cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    def make_figures(self) -> list[Figure]:  # noqa: PLR0912
        """
        Produce DOE evaluation figures. Returns empty list when no DOE data.
        """
        if self._skip_reason is not None:
            return []

        defaults = DoePlotDefaults()
        cfg = self._cfg
        w_scale = float(getattr(cfg, "w_scale", defaults.w_scale)) if cfg else defaults.w_scale
        h_scale = float(getattr(cfg, "h_scale", defaults.h_scale)) if cfg else defaults.h_scale
        alpha = float(getattr(cfg, "alpha", defaults.alpha)) if cfg else defaults.alpha
        s = float(getattr(cfg, "s", defaults.s)) if cfg else defaults.s
        if cfg:
            x_label_rotation = float(getattr(cfg, "x_label_rotation", defaults.x_label_rotation))
        else:
            x_label_rotation = defaults.x_label_rotation

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            if not h5_path.exists():
                continue
            if not _has_doe_data(h5_path):
                continue

            try:
                x_df, f_df, var_names, obj_names = self._load_h5(h5_path)
            except (KeyError, OSError):
                continue

            if not var_names or not obj_names:
                continue

            x_col = var_names[0]
            y_col = obj_names[0]

            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "antifragile_doe",
                "h5_path": str(h5_path),
                "x": x_col,
                "y": y_col,
            }
            fig, ax = self._make_figure_with_fallback(payload=payload)

            try:
                w, h = fig.get_size_inches()
                fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
            except Exception:
                pass
            self._clamp_figsize(fig)

            po = getattr(self.ctx.config.plots, "pareto_options", None)
            max_abs_f = getattr(po, "max_abs_f", None) if po else None
            if max_abs_f is not None:
                max_abs_f = float(max_abs_f)
            x_arr = x_df[x_col].to_numpy(dtype=float)
            y_arr = f_df[y_col].to_numpy(dtype=float)
            finite = np.isfinite(x_arr) & np.isfinite(y_arr)
            plot_m = finite
            if max_abs_f is not None:
                plot_m = finite & (np.abs(y_arr) <= max_abs_f)

            with plt.rc_context(self._rc_context()):
                ax.scatter(x_arr[plot_m], y_arr[plot_m], s=s, alpha=alpha, c="0.35")
                self.ctx.style.apply_axis_format(
                    ax,
                    title=f"{h5_path.stem} | DOE",
                    xlabel=x_col,
                    ylabel=y_col,
                    grid=False,
                    tick_style="sci",
                )
                ylab = ax.get_ylabel()
                if ylab:
                    ax.set_ylabel(ylab, rotation=90)
                sci_limits = getattr(self.ctx.style, "sci_limits", (-3, 3))
                for axis in (ax.xaxis, ax.yaxis):
                    fmt = mticker.ScalarFormatter(useMathText=True)
                    fmt.set_scientific(True)
                    fmt.set_powerlimits(sci_limits)
                    axis.set_major_formatter(fmt)
                ax.tick_params(axis="x", labelrotation=x_label_rotation)
                for tick in ax.get_xticklabels():
                    tick.set_ha("right")

            fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
            self._clamp_figsize(fig)
            figs.append(fig)

        return figs

    def make_figure(self) -> Figure | None:
        figs = self.make_figures()
        return figs[0] if figs else None


if __name__ == "__main__":
    pass
