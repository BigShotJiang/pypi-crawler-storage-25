# eta_incerto/plotting/config_uncertainty_marginals.py
"""Marginal PDF/CDF from ``config.uncertainty`` (no HDF5).

Included in ``antifragile_summary`` so input distributions appear even when
``marginals/`` was not written to the antifragile H5.
"""

from __future__ import annotations

from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure
from matplotlib.ticker import ScalarFormatter

from eta_incerto.config.config import ConfigOptimization
from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig
from eta_incerto.plotting.base import MAX_H_IN, MAX_W_IN, PlotterBase
from eta_incerto.plotting.context import PlotContext
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure
from eta_incerto.plotting.style import DEFAULT_PRESETS
from eta_incerto.uncertainty.pipeline import iter_marginal_curves_from_parameter_configs


def uncertainty_blocks_for_plot(
    config: ConfigOptimization,
) -> list[tuple[str, list[ParameterUncertaintyConfig]]]:
    """
    Return ``(label, parameter_configs)`` for each figure to emit.

    - Global list: one block, labeled with the sole pymoo variant name if there
      is exactly one problem, else ``\"uncertainty\"``.
    - Dict: one block per non-empty list, pymoo problem order first, then any
      remaining keys.
    """
    unc = config.uncertainty
    if isinstance(unc, list):
        if not unc:
            return []
        vkeys = list(config.pymoo.problems.keys())
        label = vkeys[0] if len(vkeys) == 1 else "uncertainty"
        return [(label, unc)]

    if not unc:
        return []

    pymoo_variants = list(config.pymoo.problems.keys())
    out: list[tuple[str, list[ParameterUncertaintyConfig]]] = []
    seen: set[str] = set()
    for v in pymoo_variants:
        block = unc.get(v)
        if block:
            out.append((v, block))
            seen.add(v)
    for k in sorted(unc.keys()):
        if k in seen:
            continue
        block = unc[k]
        if block:
            out.append((k, block))
    return out


def marginal_grid_n(config: ConfigOptimization, variant_label: str) -> int:
    """Inverse-CDF grid size; align with ``evaluate.<variant>.marginal_plot_grid_points`` when possible."""
    key = variant_label
    if key not in config.evaluate.root:
        key = next(iter(config.pymoo.problems.keys()))
    return max(8, int(config.evaluate.for_variant(key).marginal_plot_grid_points))


def _apply_academic_numbering(ax: Any) -> None:
    """
    Use publication-friendly scientific axis numbering (math-text exponents).
    """
    fmt = ScalarFormatter(useMathText=True)
    fmt.set_scientific(True)
    fmt.set_powerlimits((-2, 3))
    fmt.set_useOffset(False)
    ax.xaxis.set_major_formatter(fmt)
    ax.yaxis.set_major_formatter(fmt)


def figure_from_parameter_configs(
    configs: list[ParameterUncertaintyConfig],
    *,
    n_grid: int,
    style: Any | None = None,
) -> Figure:
    """
    Standalone figure (e.g. CLI). Not tagged with PlotID; caller saves/closes.

    ``style``: optional :class:`PlotStyle` with ``rcparams`` for ``plt.rc_context``.
    If ``style`` is None, paper preset typography (serif stack, sizes) is used so output
    matches figures produced via :class:`ConfigUncertaintyMarginalsPlotter`.
    """
    rows = list(iter_marginal_curves_from_parameter_configs(configs, n_grid=n_grid))
    n = len(rows)
    if style is not None:
        rc = dict(getattr(style, "rcparams", {}) or {})
    else:
        rc = dict(DEFAULT_PRESETS["paper_rgb"].rcparams)
    with plt.rc_context(rc):
        fig, axes = plt.subplots(nrows=n, ncols=2, figsize=(8.0, max(2.0, 1.6 * n)), squeeze=False)
        for row, (name, units, gx, pdf, cdf) in enumerate(rows):
            ulabel = f" ({units})" if units else ""
            ax_p = axes[row, 0]
            ax_c = axes[row, 1]
            ax_p.plot(gx, pdf, color="0.2", lw=1.2)
            ax_p.set_ylabel("density")
            ax_p.set_title(f"{name}{ulabel} | PDF")
            ax_p.grid(True, alpha=0.3)
            _apply_academic_numbering(ax_p)

            ax_c.plot(gx, cdf, color="0.2", lw=1.2)
            ax_c.set_ylabel("CDF")
            ax_c.set_title(f"{name}{ulabel} | CDF")
            ax_c.grid(True, alpha=0.3)
            _apply_academic_numbering(ax_c)
            if row == n - 1:
                ax_p.set_xlabel(r"$\xi$")
                ax_c.set_xlabel(r"$\xi$")
        fig.tight_layout()
    return fig


class ConfigUncertaintyMarginalsPlotter(PlotterBase):
    """PDF/CDF panels from ``config.uncertainty`` (same math as the joint builder)."""

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), MAX_W_IN), min(float(h), MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any], nrows: int, ncols: int):
        pid = compute_plot_id(payload)
        try:
            fig, axes = super().make_figure(
                nrows=nrows,
                ncols=ncols,
                plot_id_payload=payload,
                squeeze=False,
            )
            self._clamp_figsize(fig)
            return fig, axes
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 2.0)) * max(1, nrows)
            fig_w = min(base_w * ncols, MAX_W_IN)
            fig_h = min(base_h, MAX_H_IN)
            fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(fig_w, fig_h), squeeze=False)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, axes

    def make_figures(self) -> list[Figure]:
        cfg = self.ctx.config
        blocks = uncertainty_blocks_for_plot(cfg)
        if not blocks:
            return []

        rcparams = dict(getattr(self.ctx.style, "rcparams", {}) or {})
        figs: list[Figure] = []
        for label, param_cfgs in blocks:
            n = len(param_cfgs)
            if n == 0:
                continue
            n_grid = marginal_grid_n(cfg, label)
            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "config_uncertainty_marginals",
                "variant": label,
                "n_marginals": n,
            }
            with plt.rc_context(rcparams):
                fig, axes = self._make_figure_with_fallback(payload=payload, nrows=n, ncols=2)
                for row, (name, units, gx, pdf, cdf) in enumerate(
                    iter_marginal_curves_from_parameter_configs(param_cfgs, n_grid=n_grid)
                ):
                    ulabel = f" ({units})" if units else ""
                    ax_p = axes[row, 0]
                    ax_c = axes[row, 1]
                    ax_p.plot(np.asarray(gx, dtype=float), np.asarray(pdf, dtype=float), color="0.2", lw=1.2)
                    ax_p.set_ylabel("density")
                    ax_p.set_title(f"{name}{ulabel} | PDF")
                    ax_p.grid(True, alpha=0.3)
                    _apply_academic_numbering(ax_p)

                    ax_c.plot(np.asarray(gx, dtype=float), np.asarray(cdf, dtype=float), color="0.2", lw=1.2)
                    ax_c.set_ylabel("CDF")
                    ax_c.set_title(f"{name}{ulabel} | CDF")
                    ax_c.grid(True, alpha=0.3)
                    _apply_academic_numbering(ax_c)
                    if row == n - 1:
                        ax_p.set_xlabel(r"$\xi$")
                        ax_c.set_xlabel(r"$\xi$")

                fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
            self._clamp_figsize(fig)
            figs.append(fig)

        return figs
