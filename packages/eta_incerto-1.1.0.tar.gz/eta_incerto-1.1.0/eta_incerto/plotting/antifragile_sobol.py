# eta_incerto/plotting/antifragile_sobol.py
"""Sobol' index bar plot for antifragile HDF5 outputs (reads sobol/ group only)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

_MAX_W_IN = 455.0 / 72.0
_MAX_H_IN = 650.0 / 72.0

_SKIP_MSG_NO_SOBOL = "No Sobol data (sobol/S1) in H5. Skipping Sobol plot."
_SKIP_MSG_NO_CONFIG = "config.plots.sobol not configured."


@dataclass(frozen=True, slots=True)
class SobolPlotDefaults:
    w_scale: float = 1.0
    h_scale: float = 1.0
    bar_height: float = 0.35


def _has_sobol_data(h5_path: Path) -> bool:
    try:
        with h5py.File(h5_path, "r") as f:
            return "sobol" in f and "S1" in f["sobol"] and "ST" in f["sobol"]
    except OSError:
        return False


def _decode_str_list(arr: Any) -> list[str]:
    out: list[str] = []
    for item in np.asarray(arr).ravel():
        if isinstance(item, bytes | np.bytes_):
            out.append(item.decode("utf-8", errors="replace"))
        else:
            out.append(str(item))
    return out


class AntifragileSobolPlotter(PlotterBase):
    """
    Reads:
      sobol/S1, sobol/ST — shape (n_pareto_saved, n_xi)
      sobol/pareto_row — optional row indices
      sobol/variable_names — bytes or unicode

    Config:
      config.plots.sobol — H5 file(s) under results_dir
      config.plots.sobol_pareto_row — which row of S1/ST to plot (default 0)
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        cfg = getattr(ctx.config.plots, "sobol", None)

        if cfg is None:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]
        if not items:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        self.h5_paths = [results_dir / it for it in items]
        self._skip_reason = None
        self._cfg = cfg

    def _pareto_row(self) -> int:
        return int(getattr(self.ctx.config.plots, "sobol_pareto_row", 0))

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        pid = compute_plot_id(payload)
        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            self._clamp_figsize(fig)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 4.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)
            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, ax

    def _load_sobol_row(self, h5_path: Path, row: int) -> tuple[np.ndarray, np.ndarray, list[str]]:
        with h5py.File(h5_path, "r") as f:
            g = f["sobol"]
            s1m = np.asarray(g["S1"], dtype=float)
            stm = np.asarray(g["ST"], dtype=float)
            if s1m.ndim == 1:
                s1m = s1m.reshape(1, -1)
            if stm.ndim == 1:
                stm = stm.reshape(1, -1)
            n_r = int(s1m.shape[0])
            if row < 0 or row >= n_r:
                raise IndexError(f"sobol_pareto_row={row} out of range for S1 with {n_r} rows")
            names = _decode_str_list(g["variable_names"][:]) if "variable_names" in g else []
            d = int(s1m.shape[1])
            if len(names) != d:
                names = [f"xi_{i}" for i in range(d)]
            return s1m[row], stm[row], names

    def make_figures(self) -> list[Figure]:
        if self._skip_reason is not None:
            return []

        defaults = SobolPlotDefaults()
        row = self._pareto_row()
        w_scale = float(getattr(self._cfg, "w_scale", defaults.w_scale)) if self._cfg else defaults.w_scale
        h_scale = float(getattr(self._cfg, "h_scale", defaults.h_scale)) if self._cfg else defaults.h_scale

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            if not h5_path.exists():
                continue
            if not _has_sobol_data(h5_path):
                continue

            try:
                s1, st, names = self._load_sobol_row(h5_path, row)
            except (KeyError, OSError, IndexError):
                continue

            if s1.size == 0:
                continue

            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "antifragile_sobol",
                "h5_path": str(h5_path),
                "pareto_row": row,
            }
            fig, ax = self._make_figure_with_fallback(payload=payload)

            try:
                w, h = fig.get_size_inches()
                fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
            except Exception:
                pass
            self._clamp_figsize(fig)

            d = len(names)
            y = np.arange(d)
            bh = defaults.bar_height
            with plt.rc_context(dict(getattr(self.ctx.style, "rcparams", {}) or {})):
                ax.barh(y - bh / 2, s1, bh, label=r"$S_1$", alpha=0.85)
                ax.barh(y + bh / 2, st, bh, label=r"$S_T$", alpha=0.85)
                ax.set_yticks(y, labels=names)
                ax.set_xlim(0.0, min(1.05, float(max(np.max(s1), np.max(st), 0.05) * 1.15)))
                self.ctx.style.apply_axis_format(
                    ax,
                    title=f"{h5_path.stem} | Sobol' (Pareto row {row})",
                    xlabel="Index",
                    ylabel="Uncertain input",
                    grid=True,
                    tick_style="plain",
                )
                ax.legend(loc="lower right", fontsize=8)

            fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
            self._clamp_figsize(fig)
            figs.append(fig)

        return figs

    def make_figure(self) -> Figure | None:
        figs = self.make_figures()
        return figs[0] if figs else None


if __name__ == "__main__":
    pass
