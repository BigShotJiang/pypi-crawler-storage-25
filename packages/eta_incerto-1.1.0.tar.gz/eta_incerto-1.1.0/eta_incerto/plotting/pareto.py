# eta_incerto/plotting/pareto.py
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# Benchmark constraint: 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0  # 6.319444...
_MAX_H_IN = 650.0 / 72.0  # 9.027777...

# Default antifragile objective pairs: (median, skewness), (median, upr), (skewness, upr)
# Column names in H5 match objective_names; values may be transformed (e.g. -skewness, -upr).
_DEFAULT_OBJECTIVE_PAIRS: list[tuple[str, str]] = [
    ("median", "skewness"),
    ("median", "upr"),
    ("skewness", "upr"),
]


def _pareto_front_indices_2d(f_vals: np.ndarray) -> np.ndarray:
    """
    Return indices of Pareto-optimal (non-dominated) points for 2D minimization.

    Point i dominates j iff F[i,0] <= F[j,0] and F[i,1] <= F[j,1], with strict
    inequality in at least one dimension. Non-dominated points form the Pareto front.
    """
    f_vals = np.asarray(f_vals, dtype=float)
    if f_vals.ndim == 1:
        f_vals = f_vals.reshape(-1, 1)
    if f_vals.shape[1] < 2:
        return np.arange(f_vals.shape[0])
    n = f_vals.shape[0]
    front: list[int] = []
    for i in range(n):
        dominated = False
        for j in range(n):
            if i == j:
                continue
            # j dominates i if j is <= i in both objectives and < in at least one
            if (
                f_vals[j, 0] <= f_vals[i, 0]
                and f_vals[j, 1] <= f_vals[i, 1]
                and (f_vals[j, 0] < f_vals[i, 0] or f_vals[j, 1] < f_vals[i, 1])
            ):
                dominated = True
                break
        if not dominated:
            front.append(i)
    return np.array(front, dtype=int)


def _canonical_obj_name(name: str) -> str:
    """Canonical objective key for pair matching (ignore leading sign, case-insensitive)."""
    key = str(name).strip().lower()
    if key.startswith("-"):
        key = key[1:]
    return key


def objective_pair_plot_mask(
    xv: np.ndarray,
    yv: np.ndarray,
    *,
    max_abs_f: float | None,
) -> tuple[np.ndarray, int, int]:
    """
    Row mask for plotting two objectives: finite values, optionally |x|,|y| <= max_abs_f.

    Returns (plot_mask, n_non_finite, n_abs_excluded).
    """
    xv = np.asarray(xv, dtype=float)
    yv = np.asarray(yv, dtype=float)
    n = int(xv.shape[0])
    finite = np.isfinite(xv) & np.isfinite(yv)
    n_non_finite = n - int(finite.sum())
    plot_m = finite
    n_abs_excluded = 0
    if max_abs_f is not None:
        ma = float(max_abs_f)
        within = (np.abs(xv) <= ma) & (np.abs(yv) <= ma)
        n_abs_excluded = int(np.sum(finite & ~within))
        plot_m = finite & within
    return plot_m, n_non_finite, n_abs_excluded


@dataclass(frozen=True, slots=True)
class ParetoFigureDefaults:
    w_scale: float = 1.0
    h_scale: float = 1.0
    alpha: float = 0.75
    s: float = 18.0
    x_label_rotation: float = 25.0


class ParetoPlotter(PlotterBase):
    """
    Pareto plotter.

    Reads:
      config.plots.pareto = ["file_a.h5", "file_b.h5", ...] or "file.h5"

    Expected HDF5 layout (best-effort):
      - tries common paths:
          /pareto/F
          /problem/objective_names
        fallback:
          /F, /objective_names

    Benchmark contract:
      - figure size must not exceed 455pt x 650pt
      - must work even if ctx has no .layout (legacy PlotContext)
      - does NOT save
      - returns matplotlib Figure(s)
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)
        cfg = getattr(ctx.config.plots, "pareto", None)
        if cfg is None:
            raise AttributeError("Missing config entry: config.plots.pareto")

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]

        if not items:
            raise ValueError("config.plots.pareto is empty")

        self.h5_paths = [results_dir / it for it in items]
        self._cfg = cfg
        self._cache: dict[Path, tuple[pd.DataFrame, list[str]]] = {}

    # -------------------------
    # helpers
    # -------------------------

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any]):
        """
        Prefer PlotterBase.make_figure (new ctx.layout world). If ctx has no layout -> fallback.
        Always tags PlotID and clamps to benchmark.
        """
        pid = compute_plot_id(payload)

        try:
            fig, ax = super().make_figure(nrows=1, ncols=1, plot_id_payload=payload, squeeze=True)
            self._clamp_figsize(fig)
            return fig, ax
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 3.0))
            fig_w = min(base_w, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)

            fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(fig_w, fig_h), squeeze=True)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, ax

    @staticmethod
    def _decode_names(arr: Any) -> list[str]:
        out: list[str] = []
        for n in np.asarray(arr):
            if isinstance(n, bytes | np.bytes_):
                out.append(n.decode("utf-8", errors="replace"))
            else:
                out.append(str(n))
        return out

    @staticmethod
    def _first_existing(h5f: h5py.File, candidates: Sequence[str]) -> str | None:
        for p in candidates:
            if p in h5f:
                return p
        return None

    def _load_h5(self, h5_path: Path) -> tuple[pd.DataFrame, list[str]]:
        if h5_path in self._cache:
            return self._cache[h5_path]

        with h5py.File(h5_path, "r") as f:
            f_path = self._first_existing(f, ["pareto/F", "pareto/f", "F", "f"])
            if not f_path:
                raise KeyError(f"Could not find Pareto objective array in {h5_path} (tried pareto/F, F).")

            f_values = np.asarray(f[f_path], dtype=float)
            if f_values.ndim == 1:
                f_values = f_values.reshape(-1, 1)

            names_path = self._first_existing(
                f,
                [
                    "problem/objective_names",
                    "objective_names",
                    "pareto/objective_names",
                ],
            )

            obj_names = (
                self._decode_names(f[names_path][:]) if names_path else [f"obj_{i}" for i in range(f_values.shape[1])]
            )

        if len(obj_names) != f_values.shape[1]:
            obj_names = [f"obj_{i}" for i in range(f_values.shape[1])]

        pareto_df = pd.DataFrame(f_values, columns=obj_names)
        self._cache[h5_path] = (pareto_df, obj_names)
        return pareto_df, obj_names

    def _rc_context(self) -> dict[str, Any]:
        extra_rc = dict(getattr(self._cfg, "rcparams", {}) or {})
        return {**self.ctx.style.rcparams, **extra_rc}

    def _resolve_pairs(self, pareto_df: pd.DataFrame, obj_names: list[str], h5_path: Path) -> list[tuple[str, str]]:
        """
        Resolve objective pairs for matrix plots.
        Prefer config.plots.pareto_options.pairs; fallback to default antifragile pairs.
        Only include pairs where both columns exist.
        """
        del h5_path  # currently unused, retained for API stability
        opts = getattr(self.ctx.config.plots, "pareto_options", None)
        # Build lookup by canonical objective name so "skewness" maps to "-skewness" if needed.
        canonical_to_column: dict[str, str] = {}
        for col in pareto_df.columns:
            canonical_to_column.setdefault(_canonical_obj_name(col), col)

        def _resolve_col(label: str) -> str | None:
            if label in pareto_df.columns:
                return label
            return canonical_to_column.get(_canonical_obj_name(label))

        pairs_cfg = getattr(opts, "pairs", None) if opts else None
        if pairs_cfg and isinstance(pairs_cfg, list | tuple):
            pairs: list[tuple[str, str]] = []
            for p in pairs_cfg:
                if isinstance(p, list | tuple) and len(p) >= 2:
                    x_raw, y_raw = str(p[0]), str(p[1])
                    x_col = _resolve_col(x_raw)
                    y_col = _resolve_col(y_raw)
                    if x_col and y_col:
                        pairs.append((x_col, y_col))
            if pairs:
                return pairs
        # Default: antifragile pairs with robust fallback
        available: list[tuple[str, str]] = []
        for x_raw, y_raw in _DEFAULT_OBJECTIVE_PAIRS:
            x_col = _resolve_col(x_raw)
            y_col = _resolve_col(y_raw)
            if x_col and y_col:
                available.append((x_col, y_col))
        if available:
            return available
        # Fallback: first two objectives
        if len(obj_names) >= 2:
            return [(obj_names[0], obj_names[1])]
        return []

    def _diagnostics_text(
        self,
        *,
        n_points: int,
        n_unique: int,
        front_size: int,
        n_non_finite: int,
        collapsed: bool,
        n_abs_excluded: int = 0,
    ) -> str:
        """Format diagnostic annotation with degeneracy indicators."""
        dup_ratio = 0.0 if n_points <= 0 else max(0.0, 1.0 - float(n_unique) / float(n_points))
        parts = [
            f"n={n_points}",
            f"unique={n_unique}",
            f"front={front_size}",
            f"dup={dup_ratio:.0%}",
        ]
        if n_non_finite > 0:
            parts.append(f"non_finite={n_non_finite}")
        if n_abs_excluded > 0:
            parts.append(f"abs_excl={n_abs_excluded}")
        if collapsed:
            parts.append("collapsed")
        return " | ".join(parts)

    # -------------------------
    # plotid
    # -------------------------
    def _plotid_payload(self, *, h5_path: Path, x: str, y: str, w_scale: float, h_scale: float) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "pareto",
            "h5_path": str(h5_path),
            "x": str(x),
            "y": str(y),
            "w_scale": float(w_scale),
            "h_scale": float(h_scale),
        }

    def _draw_single_2d(
        self,
        ax,
        pareto_df: pd.DataFrame,
        x_name: str,
        y_name: str,
        *,
        h5_path: Path,
        alpha: float,
        s: float,
        show_front: bool,
        show_diagnostics: bool,
        max_abs_f: float | None = None,
    ) -> None:
        """Draw scatter, optional front overlay, and diagnostics on ax."""
        xv = pareto_df[x_name].to_numpy()
        yv = pareto_df[y_name].to_numpy()
        plot_mask, n_non_finite, n_abs_excluded = objective_pair_plot_mask(xv, yv, max_abs_f=max_abs_f)
        xv_plot = xv[plot_mask]
        yv_plot = yv[plot_mask]
        n_points = int(xv_plot.shape[0])
        n_unique = int(np.unique(np.column_stack([xv_plot, yv_plot]), axis=0).shape[0]) if xv_plot.size else 0
        x_span = float(np.nanmax(xv_plot) - np.nanmin(xv_plot)) if xv_plot.size else 0.0
        y_span = float(np.nanmax(yv_plot) - np.nanmin(yv_plot)) if yv_plot.size else 0.0
        collapsed = bool(n_unique <= 1 or (abs(x_span) <= 1e-12 and abs(y_span) <= 1e-12))

        # All points (background)
        ax.scatter(xv_plot, yv_plot, s=s, alpha=alpha, c="0.35", zorder=1, label="all")

        front_size = 0
        if show_front and xv_plot.shape[0] > 0:
            f2 = np.column_stack([xv_plot, yv_plot])
            idx = _pareto_front_indices_2d(f2)
            front_size = len(idx)
            if front_size > 0:
                ax.scatter(
                    xv_plot[idx],
                    yv_plot[idx],
                    s=s * 1.2,
                    alpha=1.0,
                    c="C0",
                    edgecolors="black",
                    linewidths=0.5,
                    zorder=2,
                    label="front",
                )
                # Sort by x for line overlay
                order = np.argsort(xv_plot[idx])
                ax.plot(
                    xv_plot[idx][order],
                    yv_plot[idx][order],
                    "-",
                    color="C0",
                    alpha=0.6,
                    linewidth=1.5,
                    zorder=1.5,
                )

        self.ctx.style.apply_axis_format(
            ax,
            title=f"{h5_path.stem} | pareto",
            xlabel=x_name,
            ylabel=y_name,
            grid=False,
            tick_style="sci",
        )
        ylab = ax.get_ylabel()
        if ylab:
            ax.set_ylabel(ylab, rotation=90)
        # Enforce scientific notation regardless of data span for consistency.
        sci_limits = getattr(self.ctx.style, "sci_limits", (-3, 3))
        for axis in (ax.xaxis, ax.yaxis):
            fmt = mticker.ScalarFormatter(useMathText=True)
            fmt.set_scientific(True)
            fmt.set_powerlimits(sci_limits)
            axis.set_major_formatter(fmt)

        if show_diagnostics:
            diag = self._diagnostics_text(
                n_points=n_points,
                n_unique=n_unique,
                front_size=front_size,
                n_non_finite=n_non_finite,
                collapsed=collapsed,
                n_abs_excluded=n_abs_excluded,
            )
            ax.text(
                0.02,
                0.98,
                diag,
                transform=ax.transAxes,
                fontsize=6,
                va="top",
                ha="left",
            )

    # -------------------------
    # public API
    # -------------------------

    def make_figure(self) -> Figure:
        figs = self.make_figures()
        return figs[0]

    def make_figures(self) -> list[Figure]:
        defaults = ParetoFigureDefaults()

        cfg = self._cfg
        w_scale = float(getattr(cfg, "w_scale", defaults.w_scale))
        h_scale = float(getattr(cfg, "h_scale", defaults.h_scale))
        alpha = float(getattr(cfg, "alpha", defaults.alpha))
        s = float(getattr(cfg, "s", defaults.s))
        x_label_rotation = float(getattr(cfg, "x_label_rotation", defaults.x_label_rotation))
        opts = getattr(self.ctx.config.plots, "pareto_options", None)
        show_front = bool(getattr(opts, "show_front", True) if opts else True)
        show_diagnostics = bool(getattr(opts, "show_diagnostics", True) if opts else True)
        matrix_mode = bool(getattr(opts, "matrix_mode", True) if opts else True)
        max_abs_f = getattr(opts, "max_abs_f", None) if opts else None
        if max_abs_f is not None:
            max_abs_f = float(max_abs_f)

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            pareto_df, obj_names = self._load_h5(h5_path)

            if len(obj_names) < 2:
                payload = {
                    "plotter": self.__class__.__qualname__,
                    "plot_type": "pareto",
                    "h5_path": str(h5_path),
                }
                fig, ax = self._make_figure_with_fallback(payload=payload)
                ax.text(0.5, 0.5, "Pareto plot needs >= 2 objectives", ha="center", va="center")
                ax.set_axis_off()
                fig = self.finalize_figure(fig, title=f"Pareto ({h5_path.stem})", layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)
                continue

            pairs = self._resolve_pairs(pareto_df, obj_names, h5_path)
            if not pairs:
                pairs = [(obj_names[0], obj_names[1])]

            # Matrix mode: one figure per pair; else single x,y from config
            use_single = not matrix_mode
            if opts and (getattr(opts, "x", None) is not None or getattr(opts, "y", None) is not None):
                use_single = True
            if use_single:
                x_name = str(getattr(opts, "x", obj_names[0]) if opts else getattr(cfg, "x", obj_names[0]))
                y_name = str(getattr(opts, "y", obj_names[1]) if opts else getattr(cfg, "y", obj_names[1]))
                if x_name not in pareto_df.columns:
                    x_name = obj_names[0]
                if y_name not in pareto_df.columns:
                    y_name = obj_names[1]
                pairs = [(x_name, y_name)]

            for x_name, y_name in pairs:
                payload = self._plotid_payload(
                    h5_path=h5_path,
                    x=x_name,
                    y=y_name,
                    w_scale=w_scale,
                    h_scale=h_scale,
                )

                fig, ax = self._make_figure_with_fallback(payload=payload)

                try:
                    w, h = fig.get_size_inches()
                    fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
                except Exception:
                    pass
                self._clamp_figsize(fig)

                with plt.rc_context(self._rc_context()):
                    self._draw_single_2d(
                        ax,
                        pareto_df,
                        x_name,
                        y_name,
                        h5_path=h5_path,
                        alpha=alpha,
                        s=s,
                        show_front=show_front,
                        show_diagnostics=show_diagnostics,
                        max_abs_f=max_abs_f,
                    )
                    ax.tick_params(axis="x", labelrotation=x_label_rotation)
                    for tick in ax.get_xticklabels():
                        tick.set_ha("right")

                fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
                self._clamp_figsize(fig)
                figs.append(fig)

        return figs


if __name__ == "__main__":
    pass
