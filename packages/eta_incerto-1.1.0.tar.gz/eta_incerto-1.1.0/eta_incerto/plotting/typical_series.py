# eta_incerto/plotting/typical_series.py
from __future__ import annotations

import json
import logging
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotterBase
from eta_incerto.plotting.context import PlotContext
from eta_incerto.plotting.plot_id import compute_plot_id

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TypicalSeriesConfig:
    # IO
    h5_path: Path
    weights_path: Path

    # behavior
    kind: str = "periods"  # "weights" | "periods" | "overlay"
    kinds: list[str] | None = None
    where: str = "post"
    legend_mode: str = "first"  # "none" | "first" | "each"

    # layout
    ncols: int = 3
    w_scale: float = 1.0
    h_scale: float = 1.0
    extra_top_in: float = 0.0
    extra_bottom_in: float = 0.0
    extra_left_in: float = 0.0
    extra_right_in: float = 0.0

    # content selection
    key: list[str] | None = None
    column: str | None = None
    periods: list[int] | None = None
    title: str | None = None

    # overlay-specific
    specs: list[dict[str, Any]] | None = None
    normalize: str | None = None
    show_weighted_mean: bool = False

    # optional rcparams override from config
    rcparams: dict[str, Any] | None = None

    # optional display name mapping for columns/metrics (supports MathText)
    # e.g. {"P_in": "$P_{\\mathrm{in}}$", "T_db": "$T_{\\mathrm{db}}$"}
    display_names: dict[str, str] | None = None


class TypicalSeriesPlotter(PlotterBase):
    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        cfg_raw = getattr(ctx.config.plots, "typical_series", None)
        if cfg_raw is None:
            raise AttributeError("Missing config entry: config.plots.typical_series")

        self._cfg = self._normalize_config(ctx, cfg_raw)

        if not self._cfg.h5_path.exists():
            raise FileNotFoundError(self._cfg.h5_path)
        if not self._cfg.weights_path.exists():
            raise FileNotFoundError(self._cfg.weights_path)

        self._weights: dict[int, float] | None = None
        self._keys: list[str] | None = None

    # ------------------------- config normalization -------------------------

    @staticmethod
    def _normalize_config(ctx: PlotContext, cfg_raw: Any) -> TypicalSeriesConfig:
        series_dir = Path(ctx.config.paths.series_dir)

        file_attr = getattr(cfg_raw, "file", None)
        typical_folder = getattr(cfg_raw, "folder", None)

        h5_file = file_attr if file_attr is not None else cfg_raw
        if not isinstance(h5_file, str | Path):
            raise ValueError("config.plots.typical_series must be a filename or have a .file attribute.")
        if typical_folder is None:
            raise ValueError("config.plots.typical_series.folder is required (subfolder under series_dir).")

        h5_path = series_dir / str(typical_folder) / str(h5_file)

        weights_file = getattr(cfg_raw, "weights_file", None) or getattr(cfg_raw, "weights_path", None)
        if weights_file is None:
            raise ValueError("config.plots.typical_series.weights_file is required.")
        weights_path = series_dir / str(typical_folder) / str(weights_file)

        kind = str(getattr(cfg_raw, "kind", "periods")).lower()
        kinds_raw = getattr(cfg_raw, "kinds", None)
        kinds = [str(k).lower() for k in list(kinds_raw)] if kinds_raw else None

        key_raw = getattr(cfg_raw, "key", None)
        if isinstance(key_raw, str):
            key_list = [key_raw]
        elif key_raw is None:
            key_list = None
        else:
            key_list = [str(k) for k in list(key_raw)]

        periods_raw = getattr(cfg_raw, "periods", None)
        periods = [int(p) for p in list(periods_raw)] if periods_raw is not None else None

        specs_raw = getattr(cfg_raw, "specs", None)
        specs = list(specs_raw) if specs_raw is not None else None

        rcparams = getattr(cfg_raw, "rcparams", None)
        rcparams = dict(rcparams) if rcparams is not None else None

        display_names = getattr(cfg_raw, "display_names", None)
        display_names = dict(display_names) if display_names is not None else None

        return TypicalSeriesConfig(
            h5_path=h5_path,
            weights_path=weights_path,
            kind=kind,
            kinds=kinds,
            where=str(getattr(cfg_raw, "where", "post")),
            legend_mode=str(getattr(cfg_raw, "legend_mode", "first")).lower(),
            ncols=int(getattr(cfg_raw, "ncols", 3)),
            w_scale=float(getattr(cfg_raw, "w_scale", 1.0)),
            h_scale=float(getattr(cfg_raw, "h_scale", 1.0)),
            extra_top_in=float(getattr(cfg_raw, "extra_top_in", 0.0)),
            extra_bottom_in=float(getattr(cfg_raw, "extra_bottom_in", 0.0)),
            extra_left_in=float(getattr(cfg_raw, "extra_left_in", 0.0)),
            extra_right_in=float(getattr(cfg_raw, "extra_right_in", 0.0)),
            key=key_list,
            column=getattr(cfg_raw, "column", None),
            periods=periods,
            title=getattr(cfg_raw, "title", None),
            specs=specs,
            normalize=getattr(cfg_raw, "normalize", None),
            show_weighted_mean=bool(getattr(cfg_raw, "show_weighted_mean", False)),
            rcparams=rcparams,
            display_names=display_names,
        )

    # ------------------------- cached IO -------------------------

    @property
    def weights(self) -> dict[int, float]:
        if self._weights is None:
            self._weights = self._load_weights(self._cfg.weights_path)
        return self._weights

    @property
    def keys(self) -> list[str]:
        if self._keys is None:
            self._keys = self._list_hdf_keys()
        return self._keys

    @staticmethod
    def _load_weights(path: Path) -> dict[int, float]:
        raw = json.loads(path.read_text(encoding="utf-8"))
        weights = {int(k): float(v) for k, v in raw.items()}
        s = float(sum(weights.values()))
        if abs(s - 1.0) > 1e-6:
            raise ValueError(f"weights must sum to 1.0, got {s}")
        return weights

    def _list_hdf_keys(self) -> list[str]:
        with pd.HDFStore(self._cfg.h5_path, mode="r") as store:
            keys = [k.lstrip("/") for k in store]
        return sorted(keys)

    def read_series(self, key: str) -> pd.DataFrame:
        if key not in self.keys:
            raise KeyError(f"{key!r} not found. Available: {self.keys}")

        with pd.HDFStore(self._cfg.h5_path, mode="r") as store:
            series_frame = store.get(key)

        if isinstance(series_frame.index, pd.MultiIndex) and series_frame.index.nlevels == 2:
            series_frame.index = series_frame.index.set_names(["period", "step"])
            return series_frame.sort_index()

        if "period" in series_frame.columns and "step" in series_frame.columns:
            return series_frame.set_index(["period", "step"]).sort_index()

        raise ValueError(f"{key!r} must have MultiIndex (period, step) or columns ['period','step'].")

    # ------------------------- helpers -------------------------

    def _rc_context(self) -> dict[str, Any]:
        return {**self.ctx.style.rcparams, **(self._cfg.rcparams or {})}

    def _display_name(self, name: str) -> str:
        m = self._cfg.display_names or {}
        return str(m.get(str(name), str(name)))

    # remove markers even if style preset adds them
    @staticmethod
    def _strip_markers(style: dict[str, Any]) -> dict[str, Any]:
        out = dict(style)
        for k in (
            "marker",
            "markersize",
            "markevery",
            "markerfacecolor",
            "markeredgecolor",
            "markeredgewidth",
            "markerfacecoloralt",
        ):
            out.pop(k, None)
        out["marker"] = None
        return out

    def _series_style_no_markers(self, idx: int) -> dict[str, Any]:
        return self._strip_markers(self.ctx.style.series_style(idx))

    def _apply_scale(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(w * self._cfg.w_scale, h * self._cfg.h_scale, forward=True)
        except Exception:
            pass

    @staticmethod
    def _apply_scientific_y(ax) -> None:
        """Format y-axis with scientific notation (useMathText, powerlimits like comparison plot)."""
        fmt = mticker.ScalarFormatter(useMathText=True)
        fmt.set_scientific(True)
        fmt.set_powerlimits((-1, 1))
        ax.yaxis.set_major_formatter(fmt)

    # Layout: tight_layout() first, then enforce margins via subplots_adjust().
    def _apply_layout(self, fig: Figure) -> None:
        try:
            w_in, h_in = fig.get_size_inches()
            w_in = float(w_in) if w_in else 1.0
            h_in = float(h_in) if h_in else 1.0

            extra_left = (self._cfg.extra_left_in / w_in) if w_in > 0 else 0.0
            extra_right = (self._cfg.extra_right_in / w_in) if w_in > 0 else 0.0
            extra_bottom = (self._cfg.extra_bottom_in / h_in) if h_in > 0 else 0.0
            extra_top = (self._cfg.extra_top_in / h_in) if h_in > 0 else 0.0

            left = min(0.35, max(0.10, 0.12 + extra_left))
            bottom = min(0.35, max(0.10, 0.12 + extra_bottom))
            right = max(0.65, min(0.99, 0.98 - extra_right))
            top = max(0.65, min(0.99, 0.90 - extra_top))

            fig.tight_layout()
            fig.subplots_adjust(left=left, bottom=bottom, right=right, top=top)
        except Exception:
            pass

    @staticmethod
    def _resolve_column(df_typical: pd.DataFrame, *, key: str, column: str | None) -> str:
        if column is None:
            if df_typical.shape[1] != 1:
                raise ValueError(f"{key!r} has multiple columns {list(df_typical.columns)}. Pass column=...")
            return str(df_typical.columns[0])
        if column not in df_typical.columns:
            raise KeyError(f"column {column!r} not in {list(df_typical.columns)} for key {key!r}")
        return column

    @staticmethod
    def _as_period_list(df_typical: pd.DataFrame, periods: Iterable[int] | None) -> list[int]:
        if periods is None:
            return sorted(df_typical.index.get_level_values("period").unique().astype(int).tolist())
        return [int(p) for p in periods]

    def weighted_mean_profile(self, df_one_col: pd.DataFrame) -> pd.Series:
        if df_one_col.shape[1] != 1:
            raise ValueError("weighted_mean_profile expects exactly one column")

        col = str(df_one_col.columns[0])
        periods = sorted(df_one_col.index.get_level_values("period").unique().astype(int).tolist())
        steps = sorted(df_one_col.index.get_level_values("step").unique().tolist())

        out = pd.Series(index=steps, dtype=float)
        out[:] = 0.0

        for p in periods:
            w = self.weights.get(int(p))
            if w is None:
                raise KeyError(f"Missing weight for period {p}")
            prof = df_one_col.xs(p, level="period")[col].reindex(steps)
            out += w * prof

        out.name = f"{col}_weighted_mean"
        out.index.name = "step"
        return out

    @staticmethod
    def _normalize_array(y: np.ndarray, mode: str | None) -> np.ndarray:
        if mode is None:
            return y
        if mode == "zscore":
            mu = float(np.mean(y))
            sigma = float(np.std(y))
            return (y - mu) / (sigma if sigma > 0 else 1.0)
        if mode == "minmax":
            ymin = float(np.min(y))
            ymax = float(np.max(y))
            denom = (ymax - ymin) if ymax > ymin else 1.0
            return (y - ymin) / denom
        raise ValueError("normalize must be None, 'zscore', or 'minmax'.")

    @staticmethod
    def _should_add_legend(*, legend_mode: str, i: int) -> bool:
        if legend_mode == "none":
            return False
        return legend_mode == "each" or (legend_mode == "first" and i == 0)

    @staticmethod
    def _disable_unused_axes(axes: np.ndarray, *, used: int, nrows: int, ncols: int) -> None:
        for j in range(used, nrows * ncols):
            r, c = divmod(j, ncols)
            axes[r][c].axis("off")

    def _attach_payload(self, fig: Figure, payload: dict[str, Any]) -> None:
        """
        export.py liest dieses Attribut und merged es in meta["payload"].
        Wichtig: nur Dateiname, nicht voller Pfad.
        """
        try:
            payload = dict(payload)
            payload.setdefault("plotter", self.__class__.__qualname__)
            payload.setdefault("plot_type", "typical_series")
            payload.setdefault(
                "inputs",
                {
                    "h5_file": Path(self._cfg.h5_path).name,
                    "weights_file": Path(self._cfg.weights_path).name,
                },
            )
            fig._eta_incerto_plot_payload = payload  # type: ignore[attr-defined]
        except Exception:
            pass

    # ------------------------- public API -------------------------

    def make_figure(self) -> Figure:
        kind = self._cfg.kind

        if kind == "weights":
            return self._plot_weights(title=str(self._cfg.title or "Typical period weights"))

        if kind == "periods":
            keys = self._cfg.key
            if not keys:
                raise ValueError("typical_series.kind='periods' requires config.plots.typical_series.key")
            if len(keys) > 1:
                logger.warning(
                    "typical_series.kind='periods' with multiple keys: make_figure() returns only the first. "
                    "Use make_figures() to get all."
                )
            return self._plot_typical_periods(
                key=str(keys[0]),
                column=self._cfg.column,
                periods=self._cfg.periods,
                show_weighted_mean=self._cfg.show_weighted_mean,
                ncols=self._cfg.ncols,
                title=self._cfg.title,
                legend_mode=self._cfg.legend_mode,
                where=self._cfg.where,
            )

        if kind == "overlay":
            if not self._cfg.specs:
                raise ValueError("typical_series.kind='overlay' requires config.plots.typical_series.specs")
            return self._plot_periods_with_multiple_parameters(
                specs=self._cfg.specs,
                periods=self._cfg.periods,
                ncols=self._cfg.ncols,
                title=self._cfg.title,
                legend_mode=self._cfg.legend_mode,
                normalize=self._cfg.normalize,
                show_weighted_mean=self._cfg.show_weighted_mean,
                where=self._cfg.where,
            )

        raise ValueError(f"Unknown typical_series.kind={kind!r} (expected: 'weights'|'periods'|'overlay').")

    def make_figures(self) -> list[Figure]:
        kinds = self._cfg.kinds or [self._cfg.kind]
        figs: list[Figure] = []

        for k in kinds:
            kind = str(k).lower()
            if kind == "periods":
                keys = self._cfg.key
                if not keys:
                    raise ValueError("typical_series.kind='periods' requires config.plots.typical_series.key")
                for key in keys:
                    figs.append(
                        self._plot_typical_periods(
                            key=str(key),
                            column=self._cfg.column,
                            periods=self._cfg.periods,
                            show_weighted_mean=self._cfg.show_weighted_mean,
                            ncols=self._cfg.ncols,
                            title=self._cfg.title,
                            legend_mode=self._cfg.legend_mode,
                            where=self._cfg.where,
                        )
                    )
            elif kind == "weights":
                figs.append(self._plot_weights(title=str(self._cfg.title or "typical period weights")))
            elif kind == "overlay":
                if not self._cfg.specs:
                    raise ValueError("typical_series.kind='overlay' requires config.plots.typical_series.specs")
                figs.append(
                    self._plot_periods_with_multiple_parameters(
                        specs=self._cfg.specs,
                        periods=self._cfg.periods,
                        ncols=self._cfg.ncols,
                        title=self._cfg.title,
                        legend_mode=self._cfg.legend_mode,
                        normalize=self._cfg.normalize,
                        show_weighted_mean=self._cfg.show_weighted_mean,
                        where=self._cfg.where,
                    )
                )
            else:
                raise ValueError(f"Unknown typical_series.kind={k!r} (expected: 'weights'|'periods'|'overlay').")

        return figs

    # ------------------------- internal plot implementations -------------------------

    def _plot_weights(self, *, title: str) -> Figure:
        periods = sorted(self.weights.keys())
        vals = [self.weights[p] for p in periods]

        payload = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "typical_series",
            "kind": "weights",
            "inputs": {
                "h5_file": self._cfg.h5_path.name,
                "weights_file": self._cfg.weights_path.name,
            },
            "periods": periods,
        }
        _ = compute_plot_id(payload)

        with plt.rc_context(self._rc_context()):
            fig, ax = plt.subplots(nrows=1, ncols=1, squeeze=True)
            self._apply_scale(fig)

            ax.bar([str(p) for p in periods], vals, **self.ctx.style.bar_style(0))
            self.ctx.style.apply_axis_format(
                ax,
                xlabel="typical period",
                ylabel="Weight",
                y_unit="fraction of year",
                grid=True,
                tick_style=None,
                title=title,
            )
            self._apply_scientific_y(ax)

            self._apply_layout(fig)
            self._attach_payload(fig, payload)
            return fig

    def _plot_typical_periods(
        self,
        key: str,
        *,
        column: str | None,
        periods: Iterable[int] | None,
        show_weighted_mean: bool,
        ncols: int,
        title: str | None,
        legend_mode: str,
        where: str,
    ) -> Figure:
        df_typical = self.read_series(key)
        col = self._resolve_column(df_typical, key=key, column=column)
        period_list = self._as_period_list(df_typical, periods)

        n = len(period_list)
        ncols = max(1, int(ncols))
        nrows = (n + ncols - 1) // ncols

        payload = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "typical_series",
            "kind": "periods",
            "inputs": {
                "h5_file": self._cfg.h5_path.name,
                "weights_file": self._cfg.weights_path.name,
            },
            "key": str(key),
            "column": str(col),
            "periods": [int(p) for p in period_list],
            "nrows": int(nrows),
            "ncols": int(ncols),
            "where": str(where),
            "show_weighted_mean": bool(show_weighted_mean),
        }
        _ = compute_plot_id(payload)

        wm = self.weighted_mean_profile(df_typical[[col]]) if show_weighted_mean else None

        with plt.rc_context(self._rc_context()):
            fig, axes = plt.subplots(nrows=nrows, ncols=ncols, squeeze=False)
            self._apply_scale(fig)
            axes = np.asarray(axes)

            # overall title once (key, unless title explicitly set)
            fig.suptitle(str(title) if title else str(key))

            for i, p in enumerate(period_list):
                r, c = divmod(i, ncols)
                ax = axes[r][c]
                prof = df_typical.xs(int(p), level="period")[col]

                ax.step(
                    prof.index,
                    prof.to_numpy(),
                    where=where,
                    linewidth=1.2,
                    label=f"period {p} (w={self.weights.get(int(p), float('nan')):.3f})",
                    **self._series_style_no_markers(0),
                )

                if wm is not None:
                    ax.step(
                        wm.index,
                        wm.to_numpy(),
                        where=where,
                        linewidth=1.2,
                        label="weighted mean",
                        **self._series_style_no_markers(1),
                    )

                if self._should_add_legend(legend_mode=legend_mode, i=i):
                    leg = ax.legend(fontsize=8)
                    if leg:
                        leg.get_frame().set_linewidth(0.0)

                self.ctx.style.apply_axis_format(
                    ax,
                    xlabel=None,
                    ylabel=self._display_name(str(col)),
                    grid=True,
                    tick_style=None,
                    title=f"period {p}",
                )
                self._apply_scientific_y(ax)

                # Also ensure matplotlib itself has no xlabel set (belt + suspenders)
                ax.set_xlabel("")

            self._disable_unused_axes(axes, used=n, nrows=nrows, ncols=ncols)

            self._apply_layout(fig)
            self._attach_payload(fig, payload)
            return fig

    def _plot_periods_with_multiple_parameters(
        self,
        specs: Sequence[dict[str, Any]],
        *,
        periods: Iterable[int] | None,
        ncols: int,
        title: str | None,
        legend_mode: str,
        normalize: str | None,
        show_weighted_mean: bool,
        where: str,
    ) -> Figure:
        series_data: list[tuple[str, str, str, pd.DataFrame]] = []
        common_periods: set[int] | None = None

        for s in specs:
            key = str(s["key"])
            df_typical = self.read_series(key)
            col = self._resolve_column(df_typical, key=key, column=s.get("column"))
            label = str(s.get("label", f"{key}:{col}"))

            pset = set(df_typical.index.get_level_values("period").unique().astype(int).tolist())
            common_periods = pset if common_periods is None else (common_periods & pset)

            series_data.append((key, col, label, df_typical[[col]]))

        if common_periods is None or len(common_periods) == 0:
            raise ValueError("No common periods found across the provided specs.")

        period_list = sorted(common_periods) if periods is None else [int(p) for p in periods]

        n = len(period_list)
        ncols = max(1, int(ncols))
        nrows = (n + ncols - 1) // ncols

        payload = {
            "plotter": self.__class__.__qualname__,
            "plot_type": "typical_series",
            "kind": "overlay",
            "inputs": {
                "h5_file": self._cfg.h5_path.name,
                "weights_file": self._cfg.weights_path.name,
            },
            "specs": [{"key": str(s.get("key")), "column": s.get("column"), "label": s.get("label")} for s in specs],
            "periods": [int(p) for p in period_list],
            "nrows": int(nrows),
            "ncols": int(ncols),
            "where": str(where),
            "normalize": normalize,
            "show_weighted_mean": bool(show_weighted_mean),
            "legend_mode": str(legend_mode),
        }
        _ = compute_plot_id(payload)

        weighted_means: dict[str, pd.Series] = {}
        if show_weighted_mean:
            for _key, _col, label, df1 in series_data:
                weighted_means[label] = self.weighted_mean_profile(df1)

        with plt.rc_context(self._rc_context()):
            fig, axes = plt.subplots(nrows=nrows, ncols=ncols, squeeze=False)
            self._apply_scale(fig)
            axes = np.asarray(axes)

            if title:
                fig.suptitle(str(title))

            for i, p in enumerate(period_list):
                r, c = divmod(i, ncols)
                ax = axes[r][c]

                for k, (_key, col, label, df1) in enumerate(series_data):
                    prof = df1.xs(int(p), level="period")[col]
                    y = self._normalize_array(prof.to_numpy(dtype=float), normalize)

                    ax.step(
                        prof.index,
                        y,
                        where=where,
                        linewidth=1.2,
                        label=label,
                        **self._series_style_no_markers(k),
                    )

                    if show_weighted_mean:
                        wm = weighted_means[label]
                        ax.step(
                            wm.index,
                            self._normalize_array(wm.to_numpy(dtype=float), normalize),
                            where=where,
                            linewidth=1.2,
                            label=f"{label} (weighted mean)",
                            **self._series_style_no_markers(k + len(series_data)),
                        )

                if self._should_add_legend(legend_mode=legend_mode, i=i):
                    leg = ax.legend(fontsize=8, ncol=2)
                    if leg:
                        leg.get_frame().set_linewidth(0.0)

                ylabel = "value" if normalize is None else f"value ({normalize})"
                self.ctx.style.apply_axis_format(
                    ax,
                    xlabel=None,  # remove "step" here too (consistent)
                    ylabel=ylabel,
                    grid=True,
                    tick_style=None,
                    title=f"period {p} (w={self.weights.get(int(p), float('nan')):.3f})",
                )
                self._apply_scientific_y(ax)
                ax.set_xlabel("")

            self._disable_unused_axes(axes, used=n, nrows=nrows, ncols=ncols)

            self._apply_layout(fig)
            self._attach_payload(fig, payload)
            return fig
