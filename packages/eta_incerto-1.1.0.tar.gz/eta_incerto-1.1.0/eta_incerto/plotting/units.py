"""Display unit conversions for plotting. SI units (Wh, EUR, W) are stored in HDF5.

Plotting reads SI and converts to display units for readability.
"""

# SI -> display (for plotting only)
Wh_to_MWh = 1e-6
EUR_to_kEUR = 1e-3
W_to_kW = 1e-3
