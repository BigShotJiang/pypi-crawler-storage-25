# eta_incerto/plotting/comparison.py
from __future__ import annotations

import logging
import math
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

import h5py
import matplotlib.axes
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

from eta_incerto.plotting.base import LayoutSpec, PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

logger = logging.getLogger(__name__)

MetricMeta = Mapping[str, Mapping[str, str]]
Expected = Mapping[str, Mapping[str, float]]

# Benchmark constraint: 455pt x 650pt
_MAX_W_IN = 455.0 / 72.0  # 6.319444...
_MAX_H_IN = 650.0 / 72.0  # 9.027777...


@dataclass(frozen=True)
class MetricDrawStyle:
    trader_label: Mapping[str, str]
    trader_color: Mapping[str, str]
    left_label: str
    right_label: str
    group_spacing: float
    bar_width: float


class ComparisonPlotter(PlotterBase):
    """
    Config-driven comparison plot.

    Reads:
      config.plots.comparison = [["name_1","name_2"], ["name_3","name_4"], ...]

    Returns:
      - stacked=True  -> ONE stacked figure with nrows=len(pairs), 3 columns
      - stacked=False -> one figure per pair (1 row, 3 columns)

    Benchmark contract:
      - figure size must not exceed 455pt x 650pt
      - must work even if ctx has no .layout (legacy PlotContext)
      - do not call fig.subplots_adjust() directly
      - use self.finalize_figure(...) for consistent layout
    """

    TRADER_NAMES_FULL: ClassVar[tuple[str, ...]] = (
        "gas_supplier",
        "electricity_supplier",
        "electricity_feed_in",
    )

    TRADER_NAME_MAP: ClassVar[dict[str, str]] = {
        "gas_supplier": "gas purchase",
        "electricity_supplier": "electricity purchase",
        "electricity_feed_in": "electricity feed-in",
    }

    TRADER_NAME_COLOR: ClassVar[dict[str, str]] = {
        # keep greyscale
        "gas_supplier": "dimgrey",
        "electricity_supplier": "lightgrey",
        "electricity_feed_in": "black",
    }

    # Suffixes to find datasets in H5; scale 1.0 (use values as stored; H5 is source of truth).
    # Units aligned with eta-components/eta-incerto: Wh, EUR, kg (SI/base units in HDF5).
    METRIC_PATHS: ClassVar[dict[str, dict[str, Any]]] = {
        "energy": {
            "suffixes": (("_wh", 1.0), ("_mwh", 1.0)),
            "h5_group": "energy",
            "ylabel": "in Wh",
        },
        "costs": {
            "suffixes": (("_eur", 1.0), ("_keur", 1.0)),
            "h5_group": "costs",
            "ylabel": "in EUR",
        },
        "emissions": {
            "suffixes": (("_t", 1.0), ("_kg", 1.0)),
            "h5_group": "emissions",
            "ylabel": "in kg",
        },
    }

    def __init__(self, ctx: Any) -> None:
        """
        Backward/forward compatible initializer.

        - Legacy PlotContext may be a frozen dataclass.
        - PlotterBase expects ctx.layout to exist in the migrated world.
        - This plotter needs ctx.config (paths + plots.comparison) and ctx.style.

        Strategy:
          * Build an "effective" new PlotContext(style+layout) for PlotterBase,
            while keeping config separately (no mutation of legacy ctx).
        """
        cfg = getattr(ctx, "config", None)
        style = getattr(ctx, "style", None)

        if cfg is None:
            raise AttributeError(
                "ComparisonPlotter requires a context with `.config` (e.g., LegacyPlotContext(config, style))."
            )
        if style is None:
            raise AttributeError(
                "ComparisonPlotter requires a context with `.style` "
                "(e.g., LegacyPlotContext(config, style) or new PlotContext(style,...))."
            )

        layout = getattr(ctx, "layout", None)
        if layout is None:
            # Use the same base width as other plots but compress the
            # vertical extent for comparison figures (slightly shorter
            # than default, but taller than half height).
            layout = LayoutSpec(
                base_w_in=float(getattr(style, "fig_w_in", 6.0)),
                base_h_in=0.65 * float(getattr(style, "fig_h_in", 3.0)),
            )

        preset_name = getattr(ctx, "preset_name", None)

        effective_ctx = PlotContext(style=style, layout=layout, preset_name=preset_name)
        super().__init__(effective_ctx)

        # keep config for file access
        self.config = cfg

        self.trader_names = self.TRADER_NAMES_FULL
        self.trader_map = self.TRADER_NAME_MAP
        self.trader_color = self.TRADER_NAME_COLOR

    # -------------------------
    # Utilities
    # -------------------------
    @staticmethod
    def _h5_display_name(p: str | Path) -> str:
        s = Path(p).stem
        return (
            s.replace("deterministic_variant_one", "deterministic_v1")
            .replace("stochastic_variant_one", "stochastic_v1")
            .replace("regret_variant_one", "regret_v1")
            .replace("robust_variant_one", "robust_v1")
            .replace("deterministic_variant_two", "deterministic_v2")
            .replace("stochastic_variant_two", "stochastic_v2")
            .replace("regret_variant_two", "regret_v2")
            .replace("robust_variant_two", "robust_v2")
        )

    @staticmethod
    def _read_scalar_dataset(h5: h5py.File, path: str) -> float:
        return float(h5[path][()])

    def _expected_h5(self, res_name: str) -> Path:
        return Path(self.config.paths.results_dir) / res_name

    def _collect_expected_values(self, h5_path: Path) -> dict[str, dict[str, float]]:
        out: dict[str, dict[str, float]] = {k: {} for k in self.METRIC_PATHS}
        with h5py.File(h5_path, "r") as f:
            base = "__expected__"
            for metric_name, meta in self.METRIC_PATHS.items():
                grp = meta["h5_group"]
                suffixes = meta.get("suffixes") or ()
                for trader in self.trader_names:
                    raw = 0.0
                    scale = 1.0
                    found = False
                    for suffix, s in suffixes:
                        ds_path = f"{base}/{grp}/{trader}{suffix}"
                        if ds_path in f:
                            try:
                                raw = self._read_scalar_dataset(f, ds_path)
                                scale = float(s)
                                found = True
                                break
                            except Exception as e:
                                logger.warning(
                                    "Unreadable dataset '%s' in '%s' for trader '%s' (metric=%s): %s. "
                                    "Treating value as 0.0.",
                                    ds_path,
                                    h5_path,
                                    trader,
                                    metric_name,
                                    e,
                                )
                                found = True
                                raw = 0.0
                                scale = 1.0
                                break

                    if not found:
                        # No matching dataset for any known suffix; log once and
                        # keep the value at 0.0 so the plot can still be drawn.
                        logger.warning(
                            "No expected-value dataset found for trader '%s' (metric=%s) in '%s' "
                            "under group '%s' with suffixes %s. Treating value as 0.0.",
                            trader,
                            metric_name,
                            h5_path,
                            grp,
                            [s for (s, _scale) in suffixes],
                        )

                    out[metric_name][trader] = float(raw) * float(scale)
        return out

    def _clamp_figsize(self, fig: plt.Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _style_rcparams(self) -> dict[str, Any] | None:
        """
        Extract matplotlib rcParams from style.
        """
        style = getattr(self.ctx, "style", None)
        if style is None:
            return None
        for attr in ("rcparams", "mpl_rcparams", "matplotlib_rcparams"):
            v = getattr(style, attr, None)
            if isinstance(v, dict) and v:
                return v
        return None

    def _make_figure_with_fallback(self, *, nrows: int, ncols: int, payload: dict[str, Any], squeeze: bool):
        """
        Prefer PlotterBase.make_figure (new ctx.layout world). If ctx has no layout -> fallback.
        Always tags PlotID and clamps to benchmark.
        """
        pid = compute_plot_id(payload)

        try:
            fig, axs = super().make_figure(
                nrows=nrows,
                ncols=ncols,
                plot_id_payload=payload,
                squeeze=squeeze,
            )
            self._clamp_figsize(fig)
            return fig, axs
        except Exception:
            # legacy fallback: base size from style, but clamp to benchmark.
            # Compress vertical size for comparison figures (shorter than
            # default, but taller than half height).
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = 0.65 * float(getattr(self.ctx.style, "fig_h_in", 3.0))

            # naive multi-panel scaling (then clamp)
            fig_w = min(base_w * max(1, ncols), _MAX_W_IN)
            fig_h = min(base_h * max(1, nrows), _MAX_H_IN)

            fig, axs = plt.subplots(nrows=nrows, ncols=ncols, figsize=(fig_w, fig_h), squeeze=squeeze)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, axs

    # -------------------------
    # Drawing
    # -------------------------
    @staticmethod
    def _format_total(v: float) -> str:
        """Format in-figure total in scientific notation (mantissa x 10^n) for all non-zero values."""
        if v == 0:
            return "0"
        av = abs(v)
        try:
            exp = int(math.floor(math.log10(av)))
        except ValueError:
            return f"{v:.2e}"
        mant = v / (10**exp)
        # Mathtext so the in-figure number shows as mantissa x 10^n
        return f"${mant:.2f} \\times 10^{{{exp}}}$"

    @staticmethod
    def _draw_single_metric(
        ax: plt.Axes,
        *,
        metric_name: str,
        metric_meta: MetricMeta,
        trader_names: tuple[str, ...],
        expected_left: Expected,
        expected_right: Expected,
        style: MetricDrawStyle,
    ) -> None:
        """
        NOTE: Avoid hardcoded font sizes so preset rcParams control the look.
        """
        ax.cla()

        x = np.array([0.0, style.group_spacing], dtype=float)

        prev_pos = np.zeros_like(x)
        prev_neg = np.zeros_like(x)

        for trader in trader_names:
            vals = np.array(
                [expected_left[metric_name][trader], expected_right[metric_name][trader]],
                dtype=float,
            )
            bottom = np.where(vals < 0, prev_neg, prev_pos)

            ax.bar(
                x,
                vals,
                width=style.bar_width,
                bottom=bottom,
                color=style.trader_color[trader],
                edgecolor="black",
                linewidth=0.6,
                label=style.trader_label[trader],
            )

            prev_pos = np.where(vals >= 0, prev_pos + vals, prev_pos)
            prev_neg = np.where(vals < 0, prev_neg + vals, prev_neg)

        totals = prev_pos + prev_neg
        # Slightly smaller value labels and tighter offset to reduce
        # visual clutter and overlap with the bars.
        for xx, yy in zip(x, totals, strict=True):
            off = 0.02 * (abs(yy) + 1e-9)
            txt = ax.text(
                xx,
                yy + (off if yy >= 0 else -off),
                ComparisonPlotter._format_total(yy),
                ha="center",
                va="bottom" if yy >= 0 else "top",
                fontsize=8,
                fontweight="bold",
            )
            txt.set_path_effects([pe.withStroke(linewidth=3, foreground="white")])

        ax.set_xticks(x, [style.left_label, style.right_label])

        # Place group labels at the bottom (not on top) and keep the
        # padding small so labels sit closer to the bars.
        ax.xaxis.tick_bottom()
        ax.tick_params(
            axis="x",
            labelbottom=True,
            labeltop=False,
            bottom=True,
            top=False,
            pad=2,
        )

        ax.set_ylabel(metric_meta[metric_name]["ylabel"])
        ax.grid(axis="y", alpha=0.35)
        ax.set_axisbelow(True)

        # Scientific notation for all y-axis tick labels (energy, costs, emissions).
        fmt = mticker.ScalarFormatter(useMathText=True)
        fmt.set_scientific(True)
        # Use scientific for exponent outside (-1, 1), i.e. |v| >= 10 or |v| < 0.1
        fmt.set_powerlimits((-1, 1))
        ax.yaxis.set_major_formatter(fmt)

        pad = 0.35 * style.group_spacing
        ax.set_xlim(x.min() - pad, x.max() + pad)

    @staticmethod
    def _draw_single_metric_combined(
        ax: plt.Axes,
        *,
        metric_name: str,
        metric_meta: MetricMeta,
        trader_names: tuple[str, ...],
        all_expected: list[Expected],
        labels: list[str],
        trader_color: Mapping[str, str],
        trader_label: Mapping[str, str],
        group_spacing: float = 1.35,
        bar_width: float = 0.55,
    ) -> None:
        """Draw one metric subplot with N stacked bars (N = len(all_expected))."""
        ax.cla()
        n = len(all_expected)
        if n == 0:
            ax.set_ylabel(metric_meta.get(metric_name, {}).get("ylabel", ""))
            return
        x = np.arange(n, dtype=float) * group_spacing
        prev_pos = np.zeros(n)
        prev_neg = np.zeros(n)
        for trader in trader_names:
            vals = np.array(
                [all_expected[i][metric_name].get(trader, 0.0) for i in range(n)],
                dtype=float,
            )
            bottom = np.where(vals < 0, prev_neg, prev_pos)
            ax.bar(
                x,
                vals,
                width=bar_width,
                bottom=bottom,
                color=trader_color.get(trader, "grey"),
                edgecolor="black",
                linewidth=0.6,
                label=trader_label.get(trader, trader),
            )
            prev_pos = np.where(vals >= 0, prev_pos + vals, prev_pos)
            prev_neg = np.where(vals < 0, prev_neg + vals, prev_neg)
        totals = prev_pos + prev_neg
        for xx, yy in zip(x, totals, strict=True):
            off = 0.02 * (abs(yy) + 1e-9)
            txt = ax.text(
                xx,
                yy + (off if yy >= 0 else -off),
                ComparisonPlotter._format_total(yy),
                ha="center",
                va="bottom" if yy >= 0 else "top",
                fontsize=8,
                fontweight="bold",
            )
            txt.set_path_effects([pe.withStroke(linewidth=3, foreground="white")])
        ax.set_xticks(x, labels, rotation=45, ha="right")
        ax.xaxis.tick_bottom()
        ax.tick_params(
            axis="x",
            labelbottom=True,
            labeltop=False,
            bottom=True,
            top=False,
            pad=2,
        )
        ax.set_ylabel(metric_meta[metric_name]["ylabel"])
        ax.grid(axis="y", alpha=0.35)
        ax.set_axisbelow(True)
        fmt = mticker.ScalarFormatter(useMathText=True)
        fmt.set_scientific(True)
        fmt.set_powerlimits((-1, 1))
        ax.yaxis.set_major_formatter(fmt)
        pad = 0.35 * group_spacing
        ax.set_xlim(x.min() - pad, x.max() + pad)

    def plot_into(
        self,
        axes: list[matplotlib.axes.Axes],
        *,
        opt_one: str,
        opt_two: str,
        title: str | None = None,
        left_label: str = "wo",
        right_label: str = "wi",
    ) -> list[matplotlib.axes.Axes]:
        if len(axes) != 3:
            raise ValueError("ComparisonPlotter.plot_into expects exactly 3 axes (energy, costs, emissions).")

        expected_left = self._collect_expected_values(self._expected_h5(opt_one))
        expected_right = self._collect_expected_values(self._expected_h5(opt_two))

        metric_order = list(self.METRIC_PATHS.keys())  # ["energy","costs","emissions"]

        if title:
            # Use default font sizes (rcParams) rather than forcing
            axes[0].set_title(title)

        style = MetricDrawStyle(
            trader_label=self.trader_map,
            trader_color=self.trader_color,
            left_label=left_label,
            right_label=right_label,
            group_spacing=1.35,
            bar_width=0.70,
        )

        for i, metric_name in enumerate(metric_order):
            self._draw_single_metric(
                axes[i],
                metric_name=metric_name,
                metric_meta=self.METRIC_PATHS,
                trader_names=self.trader_names,
                expected_left=expected_left,
                expected_right=expected_right,
                style=style,
            )

        return axes

    # -------------------------
    # PlotID payloads (stable)
    # -------------------------
    def _plotid_payload_single(self, *, pair_index: int, opt_one: str, opt_two: str) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "comparison",
            "kind": "single",
            "pair_index": int(pair_index),
            "opt_one": str(opt_one),
            "opt_two": str(opt_two),
            "traders": list(self.trader_names),
            "metrics": list(self.METRIC_PATHS.keys()),
        }

    def _plotid_payload_stacked(self, *, pairs: list[list[str]] | list[tuple[str, str]]) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "comparison",
            "kind": "stacked",
            "pairs": [(str(a), str(b)) for a, b in pairs],
            "traders": list(self.trader_names),
            "metrics": list(self.METRIC_PATHS.keys()),
        }

    def _plotid_payload_combined(self, *, pairs: list[list[str]] | list[tuple[str, str]]) -> dict[str, Any]:
        return {
            "plotter": self.__class__.__qualname__,
            "plot_type": "comparison",
            "kind": "combined",
            "pairs": [(str(a), str(b)) for a, b in pairs],
            "traders": list(self.trader_names),
            "metrics": list(self.METRIC_PATHS.keys()),
        }

    # -------------------------
    # Figure builders
    # -------------------------
    def _add_bottom_legend(self, fig: plt.Figure, first_ax: plt.Axes) -> None:
        handles, labels = first_ax.get_legend_handles_labels()

        seen: set[str] = set()
        uniq: list[tuple[object, str]] = []
        for handle, label in zip(handles, labels, strict=False):
            if label and label not in seen:
                uniq.append((handle, label))
                seen.add(label)

        if not uniq:
            return

        handles_u, labels_u = zip(*uniq, strict=False)

        # Respect rcParams font.size; don't hardcode "small"
        fontsize = plt.rcParams.get("legend.fontsize", plt.rcParams.get("font.size", None))

        fig.legend(
            handles_u,
            labels_u,
            loc="lower center",
            # Move legend even closer to the plots to further reduce
            # the gap between the lowest bars and the legend.
            bbox_to_anchor=(0.5, 0.09),
            ncol=min(3, len(labels_u)) if labels_u else 1,
            frameon=True,
            fancybox=True,
            framealpha=1.0,
            fontsize=fontsize,
        )

    def make_figure(self, *, pair_index: int = 0) -> plt.Figure:
        pairs = getattr(self.config.plots, "comparison", None)
        if not pairs:
            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "comparison",
                "kind": "empty",
            }
            fig, ax = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload, squeeze=True)
            ax.text(0.5, 0.5, "No config.plots.comparison configured", ha="center", va="center")
            ax.set_axis_off()
            fig = self.finalize_figure(fig, layout_policy="constrained")
            self._clamp_figsize(fig)
            return fig

        pair_index = max(0, min(int(pair_index), len(pairs) - 1))
        opt_one, opt_two = pairs[pair_index]

        payload = self._plotid_payload_single(pair_index=pair_index, opt_one=opt_one, opt_two=opt_two)

        fig, axs = self._make_figure_with_fallback(nrows=1, ncols=3, payload=payload, squeeze=False)
        axes = list(np.asarray(axs).reshape(-1)[:3])

        name_one = self._h5_display_name(opt_one)
        name_two = self._h5_display_name(opt_two)

        rcparams = self._style_rcparams()
        with plt.rc_context(rcparams if isinstance(rcparams, dict) else None):
            self.plot_into(
                axes,
                opt_one=opt_one,
                opt_two=opt_two,
                title=f"{name_one} vs. {name_two}",
                left_label=name_one,
                right_label=name_two,
            )

            self._add_bottom_legend(fig, axes[0])

            fig = self.finalize_figure(
                fig,
                layout_policy="tight",
                tight_rect=(0.06, 0.18, 0.98, 0.92),
            )

            # Add a bit more horizontal spacing between the three metric
            # subplots so bars and annotations do not visually overlap
            # between columns.
            fig.subplots_adjust(wspace=0.45)

        self._clamp_figsize(fig)
        return fig

    def make_figures(self, *, stacked: bool) -> list[plt.Figure]:
        """
        stacked=True  -> ONE stacked figure with all pairs
        stacked=False -> one figure per pair
        """
        pairs = getattr(self.config.plots, "comparison", None) or []
        if stacked:
            # Match the colleague layout:
            #  - stacked=True  -> one figure per pair (3 metric subplots per row)
            #  - stacked=False -> one stacked figure with all pairs
            return [self.make_figure(pair_index=i) for i in range(len(pairs))]
        return [self.make_stacked_figure()]

    def make_stacked_figures_per_metric(self) -> list[plt.Figure]:
        """
        Create one stacked figure PER metric (energy, costs, emissions).

        Each figure has:
          - rows = comparison pairs
          - columns = 1 metric

        This allows each metric to use the full horizontal width, improving
        readability and avoiding horizontal crowding across three columns.
        """
        pairs = getattr(self.config.plots, "comparison", None)
        if not pairs:
            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "comparison",
                "kind": "empty_stacked_per_metric",
            }
            fig, ax = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload, squeeze=True)
            ax.text(0.5, 0.5, "No config.plots.comparison configured", ha="center", va="center")
            ax.set_axis_off()
            fig = self.finalize_figure(fig, layout_policy="constrained")
            self._clamp_figsize(fig)
            return [fig]

        nrows = len(pairs)
        metric_names = list(self.METRIC_PATHS.keys())
        figs: list[plt.Figure] = []

        for metric_name in metric_names:
            payload = self._plotid_payload_stacked(pairs=pairs)
            payload["metric"] = metric_name

            fig, axs = self._make_figure_with_fallback(nrows=nrows, ncols=1, payload=payload, squeeze=False)
            axs_arr = np.asarray(axs).reshape(-1)

            rcparams = self._style_rcparams()
            with plt.rc_context(rcparams if isinstance(rcparams, dict) else None):
                for r, (opt_one, opt_two) in enumerate(pairs):
                    ax = axs_arr[r]

                    name_one = self._h5_display_name(opt_one)
                    name_two = self._h5_display_name(opt_two)

                    expected_left = self._collect_expected_values(self._expected_h5(opt_one))
                    expected_right = self._collect_expected_values(self._expected_h5(opt_two))

                    style = MetricDrawStyle(
                        trader_label=self.trader_map,
                        trader_color=self.trader_color,
                        left_label=name_one,
                        right_label=name_two,
                        group_spacing=1.35,
                        bar_width=0.70,
                    )

                    self._draw_single_metric(
                        ax,
                        metric_name=metric_name,
                        metric_meta=self.METRIC_PATHS,
                        trader_names=self.trader_names,
                        expected_left=expected_left,
                        expected_right=expected_right,
                        style=style,
                    )

                    # Title each row with the pair name to keep context.
                    ax.set_title(f"{name_one} vs. {name_two}", fontsize=plt.rcParams.get("axes.titlesize", 10))

                # Figure-level legend at the bottom (once per metric figure).
                self._add_bottom_legend(fig, axs_arr[0])

                fig = self.finalize_figure(
                    fig,
                    layout_policy="tight",
                    tight_rect=(0.08, 0.16, 0.98, 0.94),
                )

            self._clamp_figsize(fig)
            figs.append(fig)

        return figs

    def make_stacked_figure(self) -> plt.Figure:
        pairs = getattr(self.config.plots, "comparison", None)
        if not pairs:
            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "comparison",
                "kind": "empty_stacked",
            }
            fig, ax = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload, squeeze=True)
            ax.text(0.5, 0.5, "No config.plots.comparison configured", ha="center", va="center")
            ax.set_axis_off()
            fig = self.finalize_figure(fig, layout_policy="constrained")
            self._clamp_figsize(fig)
            return fig

        nrows = len(pairs)
        payload = self._plotid_payload_stacked(pairs=pairs)

        fig, axs = self._make_figure_with_fallback(nrows=nrows, ncols=3, payload=payload, squeeze=False)
        axs_arr = np.asarray(axs)

        rcparams = self._style_rcparams()
        with plt.rc_context(rcparams if isinstance(rcparams, dict) else None):
            for r, (opt_one, opt_two) in enumerate(pairs):
                row_axes = list(axs_arr[r, :])

                name_one = self._h5_display_name(opt_one)
                name_two = self._h5_display_name(opt_two)

                self.plot_into(
                    row_axes,
                    opt_one=opt_one,
                    opt_two=opt_two,
                    title=f"{name_one} vs. {name_two}",
                    left_label=name_one,
                    right_label=name_two,
                )

            self._add_bottom_legend(fig, axs_arr[0, 0])

            fig = self.finalize_figure(
                fig,
                layout_policy="tight",
                tight_rect=(0.06, 0.14, 0.98, 0.94),
            )

            # For the stacked layout, increase horizontal spacing between
            # metric columns to avoid overlap of bars/labels across columns.
            fig.subplots_adjust(wspace=0.45)

        self._clamp_figsize(fig)
        return fig

    def make_combined_figure(self) -> plt.Figure:
        """
        One figure with 9 panels: 3 rows (one per approach) x 3 columns (energy, costs, emissions).
        Each row is the same as a single comparison figure (v1 vs v2, two bars per metric).
        One shared legend at the bottom.
        """
        pairs = getattr(self.config.plots, "comparison", None)
        if not pairs:
            payload = {
                "plotter": self.__class__.__qualname__,
                "plot_type": "comparison",
                "kind": "empty_combined",
            }
            fig, ax = self._make_figure_with_fallback(nrows=1, ncols=1, payload=payload, squeeze=True)
            ax.text(0.5, 0.5, "No config.plots.comparison configured", ha="center", va="center")
            ax.set_axis_off()
            fig = self.finalize_figure(fig, layout_policy="constrained")
            self._clamp_figsize(fig)
            return fig

        nrows = len(pairs)
        payload = self._plotid_payload_combined(pairs=pairs)
        fig, axs = self._make_figure_with_fallback(nrows=nrows, ncols=3, payload=payload, squeeze=False)
        axs_arr = np.asarray(axs)

        rcparams = self._style_rcparams()
        with plt.rc_context(rcparams if isinstance(rcparams, dict) else None):
            for r, (opt_one, opt_two) in enumerate(pairs):
                row_axes = list(axs_arr[r, :])
                name_one = self._h5_display_name(opt_one)
                name_two = self._h5_display_name(opt_two)
                self.plot_into(
                    row_axes,
                    opt_one=opt_one,
                    opt_two=opt_two,
                    title=f"{name_one} vs. {name_two}",
                    left_label=name_one,
                    right_label=name_two,
                )
            self._add_bottom_legend(fig, axs_arr[0, 0])
            fig = self.finalize_figure(
                fig,
                layout_policy="tight",
                tight_rect=(0.06, 0.12, 0.98, 0.94),
            )
            fig.subplots_adjust(wspace=0.45)

        self._clamp_figsize(fig)
        return fig
