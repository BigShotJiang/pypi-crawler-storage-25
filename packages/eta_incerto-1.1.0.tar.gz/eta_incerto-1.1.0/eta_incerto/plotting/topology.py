# eta_incerto/plotting/topology.py
from __future__ import annotations

import math
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

import h5py
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from networkx import DiGraph, Graph, draw_networkx_edges, draw_networkx_nodes, nx_agraph

from eta_incerto.plotting.base import PlotContext, PlotterBase

Edge = tuple[str, str]


@dataclass(frozen=True, slots=True)
class TopologyPlotOptions:
    use_graphviz: bool = True
    graphviz_prog: str = "dot"
    grid_dx: float = 2.0
    grid_dy: float = 2.0
    sort_nodes: bool = True

    node_size: float = 500.0
    node_color: str = "0.85"
    node_edge_color: str = "0.4"
    node_edge_width: float = 1.0

    edge_color: str = "0.4"
    edge_width: float = 1.5
    edge_alpha: float = 0.25

    label_dx: float = 0.0
    label_dy: float = 0.3
    # If you want fully style-driven labels, leave this None
    label_font_size: float | None = None
    label_font_color: str = "black"

    # --- long-label handling ---
    label_wrap_width: int = 14  # wrap labels into multiple lines (0 disables)
    label_max_chars: int | None = 60  # truncate very long labels (None disables)

    # --- label overlap control ---
    label_mode: str = "all"  # "all" or "top_n"
    label_top_frac: float = 0.4  # only used if label_mode == "top_n"
    label_max_count: int | None = None  # hard cap (optional)
    label_min_font_size: float = 6.0
    label_shrink_ref: float = 12.0  # heuristic ref count for shrinking

    # --- optional collision avoidance ---
    label_adjust: bool = True  # use adjustText if installed
    label_adjust_arrows: bool = False
    label_adjust_expand: float = 1.10

    # --- optional label bbox (no hard-coded styling) ---
    label_bbox: dict[str, Any] | None = None

    arrowsize: float = 15.0
    ylim_pad_frac: float = 0.20


class TopologyPlotter(PlotterBase):
    """
    Plot a system topology from an HDF5 file.

    CONTRACT (new architecture):
    - receives PlotContext only
    - does NOT read config
    - does NOT save
    - returns a matplotlib Figure
    """

    DEFAULT_PROG: ClassVar[str] = "dot"

    def __init__(
        self,
        ctx: PlotContext,
        *,
        h5_path: Path,
        title: str | None = None,
        options: TopologyPlotOptions | None = None,
    ) -> None:
        super().__init__(ctx)

        opts = options or TopologyPlotOptions()

        self.h5_path = Path(h5_path)
        self.title = title

        self.use_graphviz = bool(opts.use_graphviz)
        self.graphviz_prog = str(opts.graphviz_prog)
        self.grid_dx = float(opts.grid_dx)
        self.grid_dy = float(opts.grid_dy)
        self.sort_nodes = bool(opts.sort_nodes)

        self.node_size = float(opts.node_size)
        self.node_color = str(opts.node_color)
        self.node_edge_color = str(opts.node_edge_color)
        self.node_edge_width = float(opts.node_edge_width)

        self.edge_color = str(opts.edge_color)
        self.edge_width = float(opts.edge_width)
        self.edge_alpha = float(opts.edge_alpha)

        self.label_dx = float(opts.label_dx)
        self.label_dy = float(opts.label_dy)
        self.label_font_size = opts.label_font_size
        self.label_font_color = str(opts.label_font_color)

        self.label_wrap_width = int(opts.label_wrap_width)
        self.label_max_chars = opts.label_max_chars if opts.label_max_chars is None else int(opts.label_max_chars)

        self.label_mode = str(opts.label_mode)
        self.label_top_frac = float(opts.label_top_frac)
        self.label_max_count = opts.label_max_count if opts.label_max_count is None else int(opts.label_max_count)
        self.label_min_font_size = float(opts.label_min_font_size)
        self.label_shrink_ref = float(opts.label_shrink_ref)

        self.label_adjust = bool(opts.label_adjust)
        self.label_adjust_arrows = bool(opts.label_adjust_arrows)
        self.label_adjust_expand = float(opts.label_adjust_expand)

        self.label_bbox = opts.label_bbox

        self.arrowsize = float(opts.arrowsize)
        self.ylim_pad_frac = float(opts.ylim_pad_frac)

        self._graph_cache: dict[str, list] | None = None

    # ------------------------------------------------------------------
    # data loading
    # ------------------------------------------------------------------

    @staticmethod
    def _to_str(x: Any) -> str:
        return x.decode("utf-8", errors="replace") if isinstance(x, bytes | bytearray) else str(x)

    def _load_topology(self) -> dict[str, list]:
        with h5py.File(self.h5_path, "r") as f:
            if "topology" not in f:
                raise KeyError(f"Missing group '/topology' in {self.h5_path}")
            topo = f["topology"]
            if "nodes" not in topo or "edges" not in topo:
                raise KeyError(f"Missing '/topology/nodes' or '/topology/edges' in {self.h5_path}")

            nodes_raw = topo["nodes"][()]
            edges_raw = topo["edges"][()]

        nodes = [self._to_str(n) for n in nodes_raw]

        edges: list[Edge] = []
        if getattr(edges_raw, "shape", None) is not None:
            for u, v in edges_raw:
                edges.append((self._to_str(u), self._to_str(v)))

        return {"nodes": nodes, "edges": edges}

    @property
    def graph_representation(self) -> dict[str, list]:
        if self._graph_cache is None:
            self._graph_cache = self._load_topology()
        return self._graph_cache

    def build_graph(self) -> DiGraph:
        rep = self.graph_representation
        g = DiGraph()
        g.add_nodes_from(rep["nodes"])
        g.add_edges_from(rep["edges"])
        return g

    # ------------------------------------------------------------------
    # layout
    # ------------------------------------------------------------------

    @staticmethod
    def _grid_layout(
        graph: Graph,
        *,
        dx: float,
        dy: float,
        sort_nodes: bool,
    ) -> dict[str, tuple[float, float]]:
        nodes = list(graph.nodes())
        if sort_nodes:
            nodes = sorted(nodes, key=str)

        n = len(nodes)
        if n == 0:
            return {}

        cols = math.ceil(math.sqrt(n))
        return {node: (dx * (i % cols), -dy * (i // cols)) for i, node in enumerate(nodes)}

    def _layout(self, graph: DiGraph) -> dict[str, tuple[float, float]]:
        if self.use_graphviz:
            try:
                return nx_agraph.graphviz_layout(graph, prog=self.graphviz_prog)
            except Exception:
                pass
        return self._grid_layout(
            graph,
            dx=self.grid_dx,
            dy=self.grid_dy,
            sort_nodes=self.sort_nodes,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _select_labels(
        self, graph: DiGraph, label_pos: dict[str, tuple[float, float]]
    ) -> dict[str, tuple[float, float]]:
        if not label_pos:
            return {}

        labels_to_draw = label_pos

        if self.label_mode == "top_n":
            deg = dict(graph.degree())
            n_keep = max(1, int(round(self.label_top_frac * len(deg))))
            keep_nodes = set(sorted(deg, key=deg.get, reverse=True)[:n_keep])
            labels_to_draw = {n: p for n, p in label_pos.items() if n in keep_nodes}

        if self.label_max_count is not None and len(labels_to_draw) > self.label_max_count:
            deg = dict(graph.degree())
            keep_nodes = sorted(labels_to_draw.keys(), key=lambda n: deg.get(n, 0), reverse=True)[
                : self.label_max_count
            ]
            keep_set = set(keep_nodes)
            labels_to_draw = {n: p for n, p in labels_to_draw.items() if n in keep_set}

        return labels_to_draw

    def _auto_font_size(self, n_labels: int) -> float:
        # Base font size: prefer explicit label_font_size, else Matplotlib rcParams font.size
        base = (
            float(self.label_font_size)
            if self.label_font_size is not None
            else float(plt.rcParams.get("font.size", 10.0))
        )
        if n_labels <= 0:
            return base
        scale = min(1.0, math.sqrt(self.label_shrink_ref / float(n_labels)))
        return max(self.label_min_font_size, base * scale)

    def _format_label(self, s: str) -> str:
        s = str(s).strip()

        # optional truncate
        if self.label_max_chars is not None and len(s) > self.label_max_chars:
            s = s[: self.label_max_chars - 1] + "…"

        # optional wrap
        if self.label_wrap_width and self.label_wrap_width > 0:
            lines = textwrap.wrap(s, width=int(self.label_wrap_width))
            return "\n".join(lines) if lines else s

        return s

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def plot(self) -> Figure:
        """
        Create and return the topology figure.
        """
        # IMPORTANT: ensure figure/axes are created under style rcparams
        with plt.rc_context(self.ctx.style.rcparams):
            fig, ax = self.make_figure(nrows=1, ncols=1)

            graph = self.build_graph()
            pos = self._layout(graph)

            ax.set_axis_off()

            label_pos = {n: (x + self.label_dx, y + self.label_dy) for n, (x, y) in pos.items()} if pos else {}
            labels_to_draw = self._select_labels(graph, label_pos)
            font_size = self._auto_font_size(len(labels_to_draw))

            draw_networkx_edges(
                graph,
                pos,
                ax=ax,
                arrows=True,
                arrowsize=self.arrowsize,
                edge_color=self.edge_color,
                alpha=self.edge_alpha,
                width=self.edge_width,
            )

            draw_networkx_nodes(
                graph,
                pos,
                ax=ax,
                node_size=self.node_size,
                node_color=self.node_color,
                edgecolors=self.node_edge_color,
                linewidths=self.node_edge_width,
            )

            # draw labels as Text objects (needed for collision avoidance)
            texts = []
            for n, (x, y) in labels_to_draw.items():
                label = self._format_label(str(n))
                t = ax.text(
                    x,
                    y,
                    label,
                    fontsize=font_size,
                    color=self.label_font_color,
                    ha="center",
                    va="bottom",
                    bbox=self.label_bbox,
                )
                texts.append(t)

            # optional collision avoidance (best effort)
            if self.label_adjust and texts:
                try:
                    from adjustText import adjust_text  # type: ignore

                    arrowprops = None
                    if self.label_adjust_arrows:
                        arrowprops = {"arrowstyle": "-", "lw": 0.3, "alpha": 0.5}

                    adjust_text(
                        texts,
                        ax=ax,
                        expand_text=(self.label_adjust_expand, self.label_adjust_expand),
                        expand_points=(self.label_adjust_expand, self.label_adjust_expand),
                        arrowprops=arrowprops,
                    )
                except Exception:
                    # if adjustText isn't installed (or fails), keep original positions
                    pass

            # avoid clipped labels
            if pos:
                ys = [p[1] for p in pos.values()]
                lys = [p[1] for p in label_pos.values()]
                ymin = min(ys + lys)
                ymax = max(ys + lys)
                span = (ymax - ymin) or 1.0
                pad = self.ylim_pad_frac * span
                ax.set_ylim(ymin - pad, ymax + pad)

            ax.set_aspect("auto")

            # IMPORTANT: apply title via style helper (keeps font + size consistent)
            if self.title:
                self.ctx.style.apply_axis_format(
                    ax,
                    title=self.title,
                    xlabel=None,
                    ylabel=None,
                    grid=False,
                    tick_style="plain",
                )

            return fig
