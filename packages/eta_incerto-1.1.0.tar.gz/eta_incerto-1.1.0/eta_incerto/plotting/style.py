# eta_incerto/plotting/style.py
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import matplotlib.ticker as mticker


@dataclass(frozen=True)
class PlotStyle:
    # required
    fig_w_in: float
    fig_h_in: float
    dpi: int
    rcparams: dict[str, Any]
    linestyles: tuple[Any, ...]
    markers: tuple[str, ...]
    # optional
    mode: str = "rgb"  # "rgb" | "bw"
    target: str = "paper"  # "paper" | "slides" | "draft"
    palette: tuple[str, ...] = ()
    export_formats: tuple[str, ...] = ("pdf", "png")

    grid: bool = False
    grid_axis: str = "both"
    grid_alpha: float = 0.25

    hide_spines: tuple[str, ...] = ("top", "right")
    show_spines: tuple[str, ...] = ("bottom", "left")

    ylabel_rotation: float = 0.0
    ylabel_labelpad: float = 5.0
    ylabel_ha: str = "right"
    ylabel_va: str = "bottom"

    tick_style: str = "plain"  # "plain" | "sci" | "auto"
    sci_limits: tuple[int, int] = (-3, 3)

    unit_separator: str = " in "

    @staticmethod
    def from_legacy_config(config) -> PlotStyle:
        style = getattr(config, "plot_style", None)
        if style is None:
            # Last-resort default: keep plotting usable even without config.
            return DEFAULT_PRESETS["paper_rgb"]

        return PlotStyle(
            fig_w_in=float(style.fig_w_in),
            fig_h_in=float(style.fig_h_in),
            dpi=int(style.dpi),
            rcparams=dict(getattr(style, "rcparams", None) or {}),
            linestyles=tuple(getattr(style, "linestyles", None) or ()),
            markers=tuple(getattr(style, "markers", None) or ()),
            mode=str(getattr(style, "mode", "rgb")).lower(),
            target=str(getattr(style, "target", "paper")).lower(),
            palette=tuple(getattr(style, "palette", None) or ()),
            export_formats=tuple(getattr(style, "export_formats", None) or ("pdf", "png")),
        )

    # ---------------- helpers ----------------

    def is_bw(self) -> bool:
        return self.mode.lower() == "bw"

    def format_unit(self, unit: str | None) -> str | None:
        if unit is None:
            return None
        u = str(unit).strip()
        return u if u else None

    def label_with_unit(self, label: str, unit: str | None) -> str:
        u = self.format_unit(unit)
        if not u:
            return str(label)
        return f"{label}{self.unit_separator}{u}"

    def set_xlabel(self, ax, label: str, *, unit: str | None = None) -> None:
        ax.set_xlabel(self.label_with_unit(str(label), unit))

    def set_ylabel(self, ax, label: str, *, unit: str | None = None) -> None:
        ax.set_ylabel(
            self.label_with_unit(str(label), unit),
            rotation=self.ylabel_rotation,
            labelpad=self.ylabel_labelpad,
            ha=self.ylabel_ha,
            va=self.ylabel_va,
        )

    def apply_spines(self, ax) -> None:
        for s in ("top", "right", "bottom", "left"):
            if s in self.hide_spines:
                ax.spines[s].set_visible(False)
            elif s in self.show_spines:
                ax.spines[s].set_visible(True)

    def apply_grid(self, ax, *, enabled: bool | None = None) -> None:
        on = self.grid if enabled is None else bool(enabled)
        if not on:
            ax.grid(False)
            return
        ax.grid(True, axis=self.grid_axis, alpha=self.grid_alpha)

    def apply_tick_format(self, ax, *, axis: str = "both", style: str | None = None) -> None:
        use = (style or self.tick_style).lower()
        if use == "auto":
            return

        def _apply_one(a):
            if use == "plain":
                a.set_major_formatter(mticker.ScalarFormatter(useMathText=False))
                try:
                    a.get_major_formatter().set_scientific(False)
                except Exception:
                    pass
            elif use == "sci":
                fmt = mticker.ScalarFormatter(useMathText=True)
                fmt.set_scientific(True)
                fmt.set_powerlimits(self.sci_limits)
                a.set_major_formatter(fmt)
            else:
                raise ValueError(f"Unknown tick style: {use!r}")

        if axis in ("x", "both"):
            _apply_one(ax.xaxis)
        if axis in ("y", "both"):
            _apply_one(ax.yaxis)

    def apply_axis_format(
        self,
        ax,
        *,
        xlabel: str | None = None,
        ylabel: str | None = None,
        x_unit: str | None = None,
        y_unit: str | None = None,
        grid: bool | None = None,
        tick_style: str | None = None,
        title: str | None = None,
    ) -> None:
        self.apply_spines(ax)
        self.apply_grid(ax, enabled=grid)
        self.apply_tick_format(ax, axis="both", style=tick_style)

        if xlabel is not None:
            self.set_xlabel(ax, xlabel, unit=x_unit)
        if ylabel is not None:
            self.set_ylabel(ax, ylabel, unit=y_unit)
        if title:
            ax.set_title(str(title))

    def apply_legend(
        self,
        ax,
        *,
        ncol: int | None = None,
        loc: str | None = None,
        frameon: bool | None = None,
        fontsize: str | int | None = None,
        max_items: int | None = None,
    ) -> None:
        handles, labels = ax.get_legend_handles_labels()
        if not handles:
            return

        if max_items is not None and len(handles) > max_items:
            handles = handles[:max_items]
            labels = labels[:max_items]

        tgt = self.target.lower()
        if tgt == "slides":
            loc = loc or "best"
            ncol = ncol if ncol is not None else 2
            fontsize = fontsize or "medium"
            frameon = frameon if frameon is not None else True
        else:
            loc = loc or "best"
            ncol = ncol if ncol is not None else 1
            fontsize = fontsize or "small"
            frameon = frameon if frameon is not None else False

        leg = ax.legend(handles, labels, loc=loc, ncol=int(ncol), frameon=bool(frameon), fontsize=fontsize)
        if leg and not bool(frameon):
            leg.get_frame().set_linewidth(0.0)

    def color(self, i: int) -> str | None:
        if self.is_bw():
            return "black"
        if self.palette:
            return self.palette[i % len(self.palette)]
        return None

    def line_style(self, i: int) -> Any:
        if not self.linestyles:
            fallback = ("-", "--", ":", "-.")
            return fallback[i % len(fallback)] if self.is_bw() else "-"
        if self.is_bw():
            return self.linestyles[i % len(self.linestyles)]
        return self.linestyles[0]

    def series_style(self, i: int) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"linestyle": self.line_style(i)}
        c = self.color(i)
        if c is not None:
            kwargs["color"] = c
        if self.markers:
            kwargs["marker"] = self.markers[i % len(self.markers)]
        return kwargs

    def bar_style(self, i: int = 0) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        if self.is_bw():
            kwargs["edgecolor"] = "black"
            kwargs["linewidth"] = 1.0
            kwargs["color"] = "white"
        return kwargs


# Central typography defaults.
# Palatino Linotype is available on many Windows setups; we provide fallbacks to keep
# plots readable on systems without the font installed.
_FONT_RCPARAMS: dict[str, Any] = {
    "font.family": "serif",
    "font.serif": ["Palatino Linotype", "Palatino", "Book Antiqua", "DejaVu Serif"],
    # Optional: keep mathtext consistent with the serif family.
    # If you do not use mathtext, these keys are harmless.
    "mathtext.fontset": "custom",
    "mathtext.rm": "Palatino Linotype",
    "mathtext.it": "Palatino Linotype:italic",
    "mathtext.bf": "Palatino Linotype:bold",
}


DEFAULT_PRESETS: dict[str, PlotStyle] = {
    "paper_rgb": PlotStyle(
        fig_w_in=6.0,
        fig_h_in=3.5,
        dpi=300,
        mode="rgb",
        target="paper",
        rcparams={
            **_FONT_RCPARAMS,
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "legend.fontsize": 7,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "axes.linewidth": 0.8,
            "lines.linewidth": 1.2,
            "savefig.bbox": "tight",
        },
        linestyles=("-",),
        markers=(),
        palette=("tab:blue", "tab:orange", "tab:green", "tab:red"),
        export_formats=("pdf", "png"),
        grid=False,
        tick_style="plain",
        unit_separator=" in ",
    ),
    "paper_bw": PlotStyle(
        fig_w_in=6.0,
        fig_h_in=3.5,
        dpi=300,
        mode="bw",
        target="paper",
        rcparams={
            **_FONT_RCPARAMS,
            "font.size": 8,
            "axes.titlesize": 9,
            "axes.labelsize": 8,
            "legend.fontsize": 7,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "axes.linewidth": 0.8,
            "lines.linewidth": 1.2,
            "savefig.bbox": "tight",
        },
        linestyles=("-", "--", ":", "-."),
        markers=(),
        palette=(),
        export_formats=("pdf", "png"),
        grid=False,
        tick_style="plain",
        unit_separator=" in ",
    ),
    "slides_rgb": PlotStyle(
        fig_w_in=8.0,
        fig_h_in=4.5,
        dpi=160,
        mode="rgb",
        target="slides",
        rcparams={
            **_FONT_RCPARAMS,
            "font.size": 14,
            "axes.titlesize": 16,
            "axes.labelsize": 14,
            "legend.fontsize": 12,
            "xtick.labelsize": 12,
            "ytick.labelsize": 12,
            "axes.linewidth": 1.2,
            "lines.linewidth": 2.0,
            "savefig.bbox": "tight",
        },
        linestyles=("-",),
        markers=(),
        palette=("tab:blue", "tab:orange", "tab:green", "tab:red"),
        export_formats=("png",),
        grid=True,
        grid_axis="y",
        grid_alpha=0.18,
        tick_style="plain",
        unit_separator=" in ",
    ),
}


def _getattr_or_key(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, Mapping):
        return obj.get(name, default)
    return getattr(obj, name, default)


def resolve_style(config, *, preset: str | None = None) -> PlotStyle:
    """
    New master path:
      config.plotting.preset + config.plotting.presets

    Legacy fallback:
      config.plot_style
    """
    plotting = _getattr_or_key(config, "plotting", None)

    # --- New-style ---
    if plotting is not None:
        preset_name = str(preset or _getattr_or_key(plotting, "preset", "paper_rgb") or "paper_rgb")

        # user presets map
        user_presets = _getattr_or_key(plotting, "presets", {}) or {}
        if isinstance(user_presets, Mapping) and preset_name in user_presets:
            p = user_presets[preset_name]
            base = DEFAULT_PRESETS.get(preset_name, DEFAULT_PRESETS["paper_rgb"])

            base_rc = dict(base.rcparams)
            base_rc.update(dict(_getattr_or_key(p, "rcparams", {}) or {}))

            style = PlotStyle(
                fig_w_in=float(_getattr_or_key(p, "fig_w_in", base.fig_w_in)),
                fig_h_in=float(_getattr_or_key(p, "fig_h_in", base.fig_h_in)),
                dpi=int(_getattr_or_key(p, "dpi", base.dpi)),
                mode=str(_getattr_or_key(p, "mode", base.mode)).lower(),
                target=str(_getattr_or_key(p, "target", base.target)).lower(),
                rcparams=base_rc,
                linestyles=tuple(_getattr_or_key(p, "linestyles", base.linestyles) or base.linestyles),
                markers=tuple(_getattr_or_key(p, "markers", base.markers) or base.markers),
                palette=tuple(_getattr_or_key(p, "palette", base.palette) or base.palette),
                export_formats=tuple(_getattr_or_key(p, "export_formats", base.export_formats) or base.export_formats),
                grid=bool(_getattr_or_key(p, "grid", base.grid)),
                grid_axis=str(_getattr_or_key(p, "grid_axis", base.grid_axis)),
                grid_alpha=float(_getattr_or_key(p, "grid_alpha", base.grid_alpha)),
                hide_spines=tuple(_getattr_or_key(p, "hide_spines", base.hide_spines) or base.hide_spines),
                show_spines=tuple(_getattr_or_key(p, "show_spines", base.show_spines) or base.show_spines),
                ylabel_rotation=float(_getattr_or_key(p, "ylabel_rotation", base.ylabel_rotation)),
                ylabel_labelpad=float(_getattr_or_key(p, "ylabel_labelpad", base.ylabel_labelpad)),
                ylabel_ha=str(_getattr_or_key(p, "ylabel_ha", base.ylabel_ha)),
                ylabel_va=str(_getattr_or_key(p, "ylabel_va", base.ylabel_va)),
                tick_style=str(_getattr_or_key(p, "tick_style", base.tick_style)).lower(),
                sci_limits=tuple(_getattr_or_key(p, "sci_limits", base.sci_limits) or base.sci_limits),
                unit_separator=str(_getattr_or_key(p, "unit_separator", base.unit_separator)),
            )
        else:
            style = DEFAULT_PRESETS.get(preset_name, DEFAULT_PRESETS["paper_rgb"])

        # global overrides on plotting.*
        override_rc = dict(_getattr_or_key(plotting, "rcparams", {}) or {})
        if override_rc:
            rc = dict(style.rcparams)
            rc.update(override_rc)
        else:
            rc = style.rcparams

        fig_w_in = float(_getattr_or_key(plotting, "fig_w_in", style.fig_w_in) or style.fig_w_in)
        fig_h_in = float(_getattr_or_key(plotting, "fig_h_in", style.fig_h_in) or style.fig_h_in)
        dpi = int(_getattr_or_key(plotting, "dpi", style.dpi) or style.dpi)

        linestyles_override = _getattr_or_key(plotting, "linestyles", None)
        markers_override = _getattr_or_key(plotting, "markers", None)
        palette_override = _getattr_or_key(plotting, "palette", None)
        export_formats_override = _getattr_or_key(plotting, "export_formats", None)

        mode_override = _getattr_or_key(plotting, "mode", None)
        target_override = _getattr_or_key(plotting, "target", None)

        grid_override = _getattr_or_key(plotting, "grid", None)
        grid_axis_override = _getattr_or_key(plotting, "grid_axis", None)
        grid_alpha_override = _getattr_or_key(plotting, "grid_alpha", None)
        tick_style_override = _getattr_or_key(plotting, "tick_style", None)

        return PlotStyle(
            fig_w_in=fig_w_in,
            fig_h_in=fig_h_in,
            dpi=dpi,
            mode=str(mode_override).lower() if mode_override is not None else style.mode,
            target=str(target_override).lower() if target_override is not None else style.target,
            rcparams=rc,
            linestyles=tuple(linestyles_override) if linestyles_override is not None else style.linestyles,
            markers=tuple(markers_override) if markers_override is not None else style.markers,
            palette=tuple(palette_override) if palette_override is not None else style.palette,
            export_formats=(
                tuple(export_formats_override) if export_formats_override is not None else style.export_formats
            ),
            grid=bool(grid_override) if grid_override is not None else style.grid,
            grid_axis=str(grid_axis_override) if grid_axis_override is not None else style.grid_axis,
            grid_alpha=float(grid_alpha_override) if grid_alpha_override is not None else style.grid_alpha,
            hide_spines=style.hide_spines,
            show_spines=style.show_spines,
            ylabel_rotation=style.ylabel_rotation,
            ylabel_labelpad=style.ylabel_labelpad,
            ylabel_ha=style.ylabel_ha,
            ylabel_va=style.ylabel_va,
            tick_style=str(tick_style_override).lower() if tick_style_override is not None else style.tick_style,
            sci_limits=style.sci_limits,
            unit_separator=style.unit_separator,
        )

    # --- Legacy fallback ---
    return PlotStyle.from_legacy_config(config)


def get_selected_preset_name(config) -> str:
    plotting = getattr(config, "plotting", None)
    if plotting is None:
        return "paper_rgb"
    return str(getattr(plotting, "preset", "paper_rgb") or "paper_rgb")
