# eta_incerto/plotting/base.py
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import matplotlib.pyplot as plt

from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

# ---------------------------------------------------------------------
# Hard page-size cap used by the benchmark (455pt x 650pt)
# ---------------------------------------------------------------------
MAX_W_PT = 455.0
MAX_H_PT = 650.0
MAX_W_IN = MAX_W_PT / 72.0  # 6.319444...
MAX_H_IN = MAX_H_PT / 72.0  # 9.027777...


@dataclass(frozen=True)
class LayoutSpec:
    """
    Minimal layout policy:
    - base subplot size (inches)
    - optional caps
    - hard cap (455pt x 650pt) to satisfy benchmark
    """

    base_w_in: float
    base_h_in: float
    max_w_in: float | None = None
    max_h_in: float | None = None

    def figsize(self, nrows: int = 1, ncols: int = 1) -> tuple[float, float]:
        w = self.base_w_in * max(1, ncols)
        h = self.base_h_in * max(1, nrows)

        if self.max_w_in is not None:
            w = min(w, self.max_w_in)
        if self.max_h_in is not None:
            h = min(h, self.max_h_in)

        w = min(float(w), MAX_W_IN)
        h = min(float(h), MAX_H_IN)

        return float(w), float(h)


@dataclass(frozen=True)
class PlotContext:
    """
    New/migrated plotters receive THIS context:
      - style: PlotStyle
      - layout: LayoutSpec
      - preset_name: e.g. "paper_rgb"
    """

    style: Any
    layout: LayoutSpec
    preset_name: str


class PlotterBase:
    """
    Base class all migrated plotters should inherit.
    Plotters must NOT save figures or mutate global rcParams.
    """

    # canonical attribute for attaching payload to figures (for exporters/reports)
    _PLOT_PAYLOAD_ATTR = "_eta_incerto_plot_payload"

    def __init__(self, ctx: PlotContext):
        self.ctx = ctx

    def make_figure(
        self,
        *,
        nrows: int = 1,
        ncols: int = 1,
        squeeze: bool = True,
        plot_id: str | None = None,
        plot_id_payload: Mapping[str, Any] | None = None,
        tag_location: str = "east",
        draw_id_on_plot: bool = False,
    ):
        """
        Create and tag a figure.

        - plot_id: if provided, use it directly
        - plot_id_payload: if provided and plot_id is None, compute stable PlotID from payload
        """
        figsize = self.ctx.layout.figsize(nrows=nrows, ncols=ncols)
        fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=figsize, squeeze=squeeze)

        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), MAX_W_IN), min(float(h), MAX_H_IN), forward=True)
        except Exception:
            pass

        pid = plot_id
        if pid is None and plot_id_payload is not None:
            pid = compute_plot_id(plot_id_payload)

        # attach payload for meta export (so exporters can recover inputs even if report payload is minimal)
        if plot_id_payload is not None:
            try:
                setattr(fig, self._PLOT_PAYLOAD_ATTR, dict(plot_id_payload))
            except Exception:
                pass

        if pid is not None:
            tag_matplotlib_figure(fig, pid, location=tag_location, draw=draw_id_on_plot)

        return fig, axes

    def style_axis(
        self,
        ax,
        *,
        xlabel: str | None = None,
        ylabel: str | None = None,
        x_unit: str | None = None,
        y_unit: str | None = None,
        grid: bool | None = None,
        tick_style: str | None = None,
        title: str | None = None,
        legend: bool = True,
    ) -> None:
        s = self.ctx.style
        s.apply_axis_format(
            ax,
            xlabel=xlabel,
            ylabel=ylabel,
            x_unit=x_unit,
            y_unit=y_unit,
            grid=grid,
            tick_style=tick_style,
            title=title,
        )
        if legend:
            s.apply_legend(ax)

    def finalize_figure(
        self,
        fig,
        *,
        title: str | None = None,
        layout_policy: str = "constrained",
        tight_rect: tuple[float, float, float, float] | None = None,
    ):
        finalize = getattr(self, "finalize", None)
        if callable(finalize):
            try:
                return finalize(fig, title=title, layout_policy=layout_policy, tight_rect=tight_rect)
            except TypeError:
                return finalize(fig, title=title, layout_policy=layout_policy)

        if title:
            fig.suptitle(title)

        if layout_policy == "tight":
            if tight_rect is not None:
                fig.tight_layout(rect=tight_rect)
            else:
                fig.tight_layout()
        elif layout_policy in ("constrained", "none"):
            pass

        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), MAX_W_IN), min(float(h), MAX_H_IN), forward=True)
        except Exception:
            pass

        return fig
