# eta_incerto/plotting/plot_id.py
from __future__ import annotations

import base64
import dataclasses
import hashlib
import json
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# Optional dependency: plotid
try:
    from plotid.tagplot import tagplot
except Exception:  # pragma: no cover - optional dependency
    tagplot = None


# ---------- Canonicalization / normalization ----------


def _canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _is_empty(v: Any) -> bool:
    """Treat these as 'absent' to improve PlotID stability."""
    return v is None or (isinstance(v, str) and v.strip().lower() in {"", "none", "null", "n/a"})


def _normalize(obj: Any) -> Any:
    """
    Normalize payload before hashing to keep PlotIDs stable:
    - drop empty-ish values (None, "", "none", "null", "n/a")
    - normalize dict keys to strings
    - recursively normalize nested structures
    - sort common lists-of-dicts by stable keys when possible
    - convert Path to str
    - convert numpy scalars to python scalars (if numpy is present)
    """
    # dict: normalize recursively + drop empties
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            nv = _normalize(v)
            if _is_empty(nv):
                continue
            out[str(k)] = nv
        return out

    # list/tuple: normalize recursively + drop empties + optional sorting
    if isinstance(obj, list | tuple):
        items: list[Any] = []
        for v in obj:
            nv = _normalize(v)
            if _is_empty(nv):
                continue
            items.append(nv)

        # If it's a list of dicts, sort by common stable keys (best-effort)
        if items and all(isinstance(x, dict) for x in items):
            # extend keys here as your schema evolves
            stable_keys = (
                "Figure_Number",
                "Subfigure_Number",
                "SubfigureNumber",
                "Line_Number",
                "Name",
                "Description",
            )
            for key in stable_keys:
                if all(key in x for x in items):
                    items.sort(key=lambda d: str(d.get(key)))
                    break

        return items

    # Path -> str
    if isinstance(obj, Path):
        return str(obj)

    # numpy scalar -> python scalar (optional)
    try:
        import numpy as np  # type: ignore

        if isinstance(obj, np.generic):
            return obj.item()
    except Exception:
        pass

    return obj


# ---------- PlotID generation ----------


def compute_plot_id(payload: Mapping[str, Any], prefix: str = "PLOT-") -> str:
    """
    Compute a stable PlotID from a JSON-serializable payload.

    Notes:
    - The payload is normalized to reduce accidental instability
      (e.g., missing optional fields, "none" placeholders, list ordering).
    - If you include raw numeric arrays in the payload, PlotIDs will change
      whenever sampling changes. Prefer referencing data via file + identifier.
    """
    payload_n = _normalize(dict(payload))
    raw = _canonical_json(payload_n).encode("utf-8")
    digest = hashlib.sha256(raw).digest()
    short = base64.b32encode(digest).decode("ascii").rstrip("=")[:14]
    return f"{prefix}{short}"


# ---------- Registry ----------


@dataclasses.dataclass(frozen=True)
class PlotIDRecord:
    plot_id: str
    payload: dict[str, Any]
    created_at: str
    plotter: str
    outputs: list[str]


class PlotIDRegistry:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: PlotIDRecord) -> None:
        line = json.dumps(dataclasses.asdict(record), ensure_ascii=False)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(line + "\n")


# ---------- Plot tagging ----------

# Canonical place to store PlotID on matplotlib figures
_PLOT_ID_ATTR = "_eta_incerto_plot_id"


def tag_matplotlib_figure(
    fig,
    plot_id: str,
    *,
    location: str = "east",
    draw: bool = False,
    id_on_plot: bool | None = None,
) -> None:
    """
    Tag a matplotlib figure with plot_id.

    Guarantees:
    - PlotID is ALWAYS stored on the figure object (routing/export contract)
    - Visual painting is OPTIONAL (draw=True) and only used for debugging

    Notes:
    - We keep the legacy arg id_on_plot for compatibility with plotid.tagplot.
    - If draw is False, we force id_on_plot=False when calling tagplot.
    """
    # store PlotID on the figure (infrastructure contract)
    try:
        setattr(fig, _PLOT_ID_ATTR, str(plot_id))
    except Exception:
        pass

    # fallback for debugging / manual inspection
    try:
        fig.set_label(str(plot_id))
    except Exception:
        pass

    # optional visual tagging
    if tagplot is None:
        return

    # If caller didn't specify id_on_plot explicitly, derive it from draw.
    if id_on_plot is None:
        id_on_plot = bool(draw)

    # If draw is False, force it off no matter what.
    if not draw:
        id_on_plot = False

    tagplot(
        figs=[fig],
        engine="matplotlib",
        figure_ids=[plot_id],
        location=location,
        id_on_plot=bool(id_on_plot),
    )


def get_plot_id_from_figure(fig) -> str | None:
    """
    Retrieve PlotID previously stored via tag_matplotlib_figure().
    Returns None if the figure was not created via PlotterBase.make_figure().
    """
    v = getattr(fig, _PLOT_ID_ATTR, None)
    if isinstance(v, str) and v:
        return v

    # Fallback to using the figure label.
    try:
        lab = fig.get_label()
        if isinstance(lab, str) and lab:
            return lab
    except Exception:
        pass

    return None


# ---------- Utilities ----------


def now_utc_iso() -> str:
    return datetime.now(UTC).isoformat()


def get_plot_dir(base_dir: str | Path, plot_id: str, preset_name: str) -> Path:
    """
    Return the directory for a (plot_id, preset).

    Folder layout:
    <base_dir>/
        <plot_id>/
            <preset_name>/
    """
    base = Path(base_dir)
    out = base / str(plot_id) / str(preset_name)
    out.mkdir(parents=True, exist_ok=True)
    return out
