# eta_incerto/plotting/antifragile_marginals.py
"""Marginal PDF/CDF panels from antifragile HDF5 (reads marginals/ only)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure

from eta_incerto.plotting.base import PlotContext, PlotterBase
from eta_incerto.plotting.plot_id import compute_plot_id, tag_matplotlib_figure

_MAX_W_IN = 455.0 / 72.0
_MAX_H_IN = 650.0 / 72.0

_SKIP_MSG_NO_MARGINALS = "No marginal curve data (marginals/) in H5. Skipping marginal plot."
_SKIP_MSG_NO_CONFIG = "config.plots.marginals not configured."


@dataclass(frozen=True, slots=True)
class MarginalsPlotDefaults:
    w_scale: float = 1.0
    h_scale: float = 1.0


def _has_marginals_data(h5_path: Path) -> bool:
    try:
        with h5py.File(h5_path, "r") as f:
            return "marginals" in f and int(f["marginals"].attrs.get("n_marginals", 0)) > 0
    except OSError:
        return False


def _decode_utf8_scalar(val: Any) -> str:
    if isinstance(val, bytes):
        return val.decode("utf-8", errors="replace")
    if isinstance(val, np.ndarray) and val.shape == ():
        return _decode_utf8_scalar(val.item())
    return str(val)


def _marginal_subgroup_ids(handle: h5py.File) -> list[str]:
    g = handle["marginals"]
    n = int(g.attrs.get("n_marginals", 0))
    return [str(i) for i in range(n) if str(i) in g]


class AntifragileMarginalsPlotter(PlotterBase):
    """
    Reads ``marginals/<i>/{grid_x,pdf,cdf}`` plus optional histogram datasets.
    """

    def __init__(self, ctx: PlotContext) -> None:
        super().__init__(ctx)

        results_dir = Path(ctx.config.paths.results_dir)

        cfg = getattr(ctx.config.plots, "marginals", None)

        if cfg is None:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        items = [str(cfg)] if isinstance(cfg, str | Path) else [str(x) for x in list(cfg)]
        if not items:
            self.h5_paths = []
            self._skip_reason = _SKIP_MSG_NO_CONFIG
            self._cfg = None
            return

        self.h5_paths = [results_dir / it for it in items]
        self._skip_reason = None
        self._cfg = cfg

    def _clamp_figsize(self, fig: Figure) -> None:
        try:
            w, h = fig.get_size_inches()
            fig.set_size_inches(min(float(w), _MAX_W_IN), min(float(h), _MAX_H_IN), forward=True)
        except Exception:
            pass

    def _make_figure_with_fallback(self, *, payload: dict[str, Any], nrows: int, ncols: int):
        pid = compute_plot_id(payload)
        try:
            fig, axes = super().make_figure(
                nrows=nrows,
                ncols=ncols,
                plot_id_payload=payload,
                squeeze=False,
            )
            self._clamp_figsize(fig)
            return fig, axes
        except Exception:
            base_w = float(getattr(self.ctx.style, "fig_w_in", 6.0))
            base_h = float(getattr(self.ctx.style, "fig_h_in", 2.0)) * max(1, nrows)
            fig_w = min(base_w * ncols, _MAX_W_IN)
            fig_h = min(base_h, _MAX_H_IN)
            fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(fig_w, fig_h), squeeze=False)
            tag_matplotlib_figure(fig, pid, location="east", draw=False)
            self._clamp_figsize(fig)
            return fig, axes

    def make_figures(self) -> list[Figure]:
        if self._skip_reason is not None:
            return []

        defaults = MarginalsPlotDefaults()
        w_scale = float(getattr(self._cfg, "w_scale", defaults.w_scale)) if self._cfg else defaults.w_scale
        h_scale = float(getattr(self._cfg, "h_scale", defaults.h_scale)) if self._cfg else defaults.h_scale

        figs: list[Figure] = []

        for h5_path in self.h5_paths:
            if not h5_path.exists():
                continue
            if not _has_marginals_data(h5_path):
                continue

            try:
                with h5py.File(h5_path, "r") as handle:
                    ids = _marginal_subgroup_ids(handle)
                    if not ids:
                        continue
                    n = len(ids)
                    payload = {
                        "plotter": self.__class__.__qualname__,
                        "plot_type": "antifragile_marginals",
                        "h5_path": str(h5_path),
                        "n_marginals": n,
                    }
                    fig, axes = self._make_figure_with_fallback(payload=payload, nrows=n, ncols=2)
                    try:
                        w, h = fig.get_size_inches()
                        fig.set_size_inches(w * w_scale, h * h_scale, forward=True)
                    except Exception:
                        pass
                    self._clamp_figsize(fig)

                    with plt.rc_context(dict(getattr(self.ctx.style, "rcparams", {}) or {})):
                        for row, mid in enumerate(ids):
                            sub = handle["marginals"][mid]
                            name = _decode_utf8_scalar(sub.attrs["variable_name"])
                            gx = np.asarray(sub["grid_x"], dtype=float).ravel()
                            pdf = np.asarray(sub["pdf"], dtype=float).ravel()
                            cdf = np.asarray(sub["cdf"], dtype=float).ravel()
                            ax_p = axes[row, 0]
                            ax_c = axes[row, 1]
                            ax_p.plot(gx, pdf, color="0.2", lw=1.2, label="pdf (nominal marginal)")
                            if "hist_edges" in sub and "hist_density" in sub:
                                ed = np.asarray(sub["hist_edges"], dtype=float)
                                dens = np.asarray(sub["hist_density"], dtype=float)
                                xc = 0.5 * (ed[:-1] + ed[1:])
                                ax_p.step(
                                    xc,
                                    dens,
                                    where="mid",
                                    color="C0",
                                    alpha=0.7,
                                    lw=1.0,
                                    label="feasible sample density",
                                )
                            ax_p.set_ylabel("density")
                            ax_p.set_title(f"{name} | PDF")
                            ax_p.legend(fontsize=6, loc="upper right")
                            ax_p.grid(True, alpha=0.3)

                            ax_c.plot(gx, cdf, color="0.2", lw=1.2)
                            ax_c.set_ylabel("CDF")
                            ax_c.set_title(f"{name} | CDF")
                            ax_c.grid(True, alpha=0.3)
                            if row == n - 1:
                                ax_p.set_xlabel(r"$\xi$")
                                ax_c.set_xlabel(r"$\xi$")

                    fig.suptitle(f"{h5_path.stem} | Uncertain inputs (H5 marginals/)", fontsize=10, y=1.02)
                    fig = self.finalize_figure(fig, title=None, layout_policy="constrained")
                    self._clamp_figsize(fig)
                    figs.append(fig)
            except (KeyError, OSError, ValueError):
                continue

        return figs

    def make_figure(self) -> Figure | None:
        figs = self.make_figures()
        return figs[0] if figs else None


if __name__ == "__main__":
    pass
