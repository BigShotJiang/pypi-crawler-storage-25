from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from logging import getLogger
from typing import Any

import numpy as np

log = getLogger(__name__)

Xi = dict[str, np.ndarray]


@dataclass(frozen=True)
class FeasibilityResult:
    ok: bool
    n_violations: int
    min_margin: float  # min(hot - cold - dt_min)


class XiSampler:
    """Draws batches of xi samples via a provided callable."""

    def __init__(self, draw_fn: Callable[[int, np.random.Generator], Xi]):
        self._draw_fn = draw_fn

    def draw(self, n: int, rng: np.random.Generator) -> Xi:
        n = int(n)
        if n <= 0:
            raise ValueError("n must be >= 1")

        out = self._draw_fn(n, rng)

        # Normalize: each value should be (n, dim...)
        norm: Xi = {}
        for k, v in out.items():
            arr = np.asarray(v, dtype=float)
            if arr.shape[0] != n:
                raise ValueError(f"XiSampler.draw: key={k!r} returned first dimension {arr.shape[0]} != n={n}")
            norm[k] = arr
        return norm

    def draw_one(self, rng: np.random.Generator) -> Xi:
        batch = self.draw(1, rng)
        return {k: np.asarray(v)[0] for k, v in batch.items()}


class XiConstraint:
    """Checks whether a single xi sample is feasible."""

    def check(self, xi: Xi) -> FeasibilityResult:
        raise NotImplementedError

    # Optional fast path: vectorized feasibility
    # Should accept a batched Xi dict (each value shaped (n, ...))
    # and return a boolean mask of shape (n,), True = feasible.
    def mask(self, batch: Xi) -> np.ndarray:  # pragma: no cover
        raise NotImplementedError


class RejectionSampler(XiSampler):
    """
    Samples xi from a base sampler and rejects infeasible draws.
    Statistically: samples from prior conditioned on feasibility.
    """

    def __init__(
        self,
        base: XiSampler,
        constraint: XiConstraint,
        *,
        max_rounds: int = 200,
        batch_size: int = 256,
    ):
        self._base = base
        self._constraint = constraint
        self._max_rounds = int(max_rounds)
        self._batch_size = int(batch_size)

    def _mask_feasible(self, batch: Xi) -> np.ndarray:
        """
        Returns a feasibility mask for a batch.

        Priority:
          1) constraint.mask(batch) if implemented
          2) per-sample constraint.check(...)
        """
        first = np.asarray(next(iter(batch.values())))
        n = int(first.shape[0])

        # Try vectorized mask API if implemented
        try:
            mask = self._constraint.mask(batch)
        except NotImplementedError:
            mask = None

        if mask is not None:
            mask = np.asarray(mask, dtype=bool).reshape(-1)
            if mask.shape[0] != n:
                raise ValueError(f"XiConstraint.mask returned wrong length {mask.shape[0]} (expected {n})")
            return mask

        # Fallback: per-sample check
        out = np.empty(n, dtype=bool)
        for i in range(n):
            xi_i = {k: np.asarray(v)[i] for k, v in batch.items()}
            out[i] = bool(self._constraint.check(xi_i).ok)
        return out

    def draw_many(
        self,
        rng: np.random.Generator,
        n: int,
        *,
        key: str | None,
        oversample_factor: float = 1.0,
    ) -> Xi | np.ndarray:
        """
        Draw n feasible xi samples using batched rejection sampling.

        If key is provided, returns an array shaped (n, dim...) for that key.
        Otherwise returns Xi dict where each value is stacked to shape (n, dim...).

        oversample_factor > 1.0 can reduce the number of rounds when acceptance is low.
        """
        n = int(n)
        if n <= 0:
            raise ValueError("n must be >= 1")
        oversample_factor = float(oversample_factor)
        if oversample_factor <= 0:
            raise ValueError("oversample_factor must be > 0")

        accepted: dict[str, list[np.ndarray]] = {}
        remaining = n

        for _round in range(self._max_rounds):
            if remaining <= 0:
                break

            draw_n = max(self._batch_size, int(np.ceil(remaining * oversample_factor)))
            batch = self._base.draw(draw_n, rng)

            mask = self._mask_feasible(batch)
            idx = np.nonzero(mask)[0]
            if idx.size == 0:
                continue

            take = min(int(idx.size), remaining)
            idx = idx[:take]

            for k, v in batch.items():
                accepted.setdefault(k, []).append(np.asarray(v)[idx])

            remaining -= take

        if remaining > 0:
            raise RuntimeError(
                "RejectionSampler: could not draw feasible xi. "
                "Distributions likely produce infeasible samples too often."
            )

        out: Xi = {k: np.concatenate(chunks, axis=0) for k, chunks in accepted.items()}

        if key is not None:
            if key not in out:
                raise KeyError(f"Requested key={key!r} not present. Available keys: {list(out.keys())}")
            return out[key]
        return out

    def draw_one(self, rng: np.random.Generator) -> Xi:
        batch = self.draw_many(rng, 1)
        assert isinstance(batch, dict)
        return {k: np.asarray(v)[0] for k, v in batch.items()}


class RejectionSamplerWithStats(RejectionSampler):
    """Same as RejectionSampler but tracks drawn/rejected counters."""

    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.n_drawn = 0
        self.n_rejected = 0

    def draw_many(
        self,
        rng: np.random.Generator,
        n: int,
        *,
        key: str | None,
        oversample_factor: float = 1.0,
    ) -> Xi | np.ndarray:
        n = int(n)
        if n <= 0:
            raise ValueError("n must be >= 1")
        oversample_factor = float(oversample_factor)
        if oversample_factor <= 0:
            raise ValueError("oversample_factor must be > 0")

        accepted: dict[str, list[np.ndarray]] = {}
        remaining = n

        for _round in range(self._max_rounds):
            if remaining <= 0:
                break

            draw_n = max(self._batch_size, int(np.ceil(remaining * oversample_factor)))
            batch = self._base.draw(draw_n, rng)

            mask = self._mask_feasible(batch)

            # Stats: count all checked in this batch
            self.n_drawn += int(mask.shape[0])
            n_ok = int(np.count_nonzero(mask))
            self.n_rejected += int(mask.shape[0] - n_ok)

            if n_ok == 0:
                continue

            idx = np.nonzero(mask)[0]
            take = min(int(idx.size), remaining)
            idx = idx[:take]

            for k, v in batch.items():
                accepted.setdefault(k, []).append(np.asarray(v)[idx])

            remaining -= take

        if remaining > 0:
            log.error(
                "Feasibility sampling failed: max_rounds=%s batch_size=%s drawn=%s rejected=%s reject_rate=%.3f",
                self._max_rounds,
                self._batch_size,
                self.n_drawn,
                self.n_rejected,
                (self.n_rejected / max(self.n_drawn, 1)),
            )
            raise RuntimeError("Could not draw feasible xi")

        out: Xi = {k: np.concatenate(chunks, axis=0) for k, chunks in accepted.items()}

        if key is not None:
            if key not in out:
                raise KeyError(f"Requested key={key!r} not present. Available keys: {list(out.keys())}")
            return out[key]
        return out

    def draw_one(self, rng: np.random.Generator) -> Xi:
        batch = self.draw_many(rng, 1)
        assert isinstance(batch, dict)
        return {k: np.asarray(v)[0] for k, v in batch.items()}


class FeasibilityConstraint(XiConstraint):
    """
    Checks feasibility using the model builder's mapping.

    Expects xi dict: {"xi": (n_dim,)}.
    """

    def __init__(self, model_builder: Any, dt_min: float, xi_key: str = "xi"):
        self.model_builder = model_builder
        self.dt_min = float(dt_min)
        self.xi_key = str(xi_key)

        if not hasattr(model_builder, "feasibility_margin"):
            raise AttributeError(
                "Model builder must implement feasibility_margin(xi, dt_min) to use FeasibilityConstraint."
            )

    def check(self, xi: dict[str, np.ndarray]) -> FeasibilityResult:
        vec = np.asarray(xi[self.xi_key], dtype=float).ravel()
        m = float(self.model_builder.feasibility_margin(vec, self.dt_min))
        ok = m > 0.0
        return FeasibilityResult(ok=ok, n_violations=(0 if ok else 1), min_margin=m)

    def mask(self, batch: Xi) -> np.ndarray:
        """
        Optional batched feasibility.
        Uses model_builder.feasibility_margin_batch(X, dt_min) if available,
        otherwise falls back to per-row feasibility_margin.
        """
        X = np.asarray(batch[self.xi_key], dtype=float)  # noqa:N806
        if X.ndim == 1:
            X = X.reshape(1, -1)  # noqa:N806
        n = X.shape[0]

        if hasattr(self.model_builder, "feasibility_margin_batch"):
            m = self.model_builder.feasibility_margin_batch(X, self.dt_min)
            m = np.asarray(m, dtype=float).reshape(-1)
            if m.shape[0] != n:
                raise ValueError(f"feasibility_margin_batch returned wrong length {m.shape[0]} (expected {n})")
            return m > 0.0

        out = np.empty(n, dtype=bool)
        for i in range(n):
            out[i] = float(self.model_builder.feasibility_margin(X[i, :], self.dt_min)) > 0.0
        return out
