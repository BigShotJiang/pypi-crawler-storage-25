"""
Load variant data (static, investment, distribution) from a run directory when available.

When config.paths.data_repo_root is set and the run contains variant_<name>/static_data,
investment_data, or distribution_data, load from those paths. Otherwise fall back to
each loader's load_default() (e.g. from the example package).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def load_variant_data(
    config: Any,
    variant_name: str,
    static_data_cls: type,
    investment_data_cls: type,
    distribution_data_cls: type | None,
) -> tuple[Any, Any, Any | None]:
    """
    Load static_data, investment_data, and optionally distribution_data for a variant.

    When config.paths.data_repo_root is set and the run directory contains
    variant_<name>/static_data, investment_data, or distribution_data, load from
    those folders. Otherwise use each class's load_default().

    Returns:
        (static_data, investment_data, distribution_data_or_none).
        distribution_data is the result of .build_joint() when distribution_data_cls
        is not None; otherwise None.
    """
    paths = getattr(config, "paths", None)
    run_root = getattr(paths, "data_repo_root", None) if paths is not None else None
    variant_root: Path | None = None
    if run_root is not None:
        run_root = Path(run_root).resolve()
        vr = run_root / variant_name
        if vr.is_dir():
            variant_root = vr

    def _load_static(cls: type, subdir: str, default_fn: str = "load_default") -> Any:
        if variant_root is None:
            return getattr(cls, default_fn)()
        folder = variant_root / subdir
        if not folder.is_dir():
            return getattr(cls, default_fn)()
        load_from_folder = getattr(cls, "load_static_component_data", None)
        if load_from_folder is not None and callable(load_from_folder):
            return load_from_folder(folder)
        return getattr(cls, default_fn)()

    def _load_investment(cls: type) -> Any:
        return _load_static(cls, "investment_data")

    def _load_distribution(cls: type) -> Any | None:
        if cls is None:
            return None
        if variant_root is None:
            return cls.load_default().build_joint()
        folder = variant_root / "distribution_data"
        if not folder.is_dir():
            return cls.load_default().build_joint()
        load_from_folder = getattr(cls, "load_distribution_data", None)
        if load_from_folder is not None and callable(load_from_folder):
            return load_from_folder(folder).build_joint()
        return cls.load_default().build_joint()

    static_data = _load_static(static_data_cls, "static_data")
    investment_data = _load_investment(investment_data_cls)
    distribution_data = _load_distribution(distribution_data_cls) if distribution_data_cls is not None else None

    return static_data, investment_data, distribution_data
