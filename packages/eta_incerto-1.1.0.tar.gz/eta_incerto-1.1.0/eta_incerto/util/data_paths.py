from __future__ import annotations

import os
from collections.abc import Iterable
from pathlib import Path

ENV_VAR_NAME = "DATA_REPO_PATH"
RUN_DIR_ENV = "RUN_DIR"
RUN_ID_ENV = "RUN_ID"


def get_run_dir_from_env() -> Path | None:
    """
    Resolve run directory from environment for run-driven examples.

    Order: RUN_DIR (path to run dir), then DATA_REPO_PATH + RUN_ID (relative path from repo root).
    Returns None if neither is set.
    """
    run_dir = os.environ.get(RUN_DIR_ENV)
    if run_dir:
        return Path(run_dir).expanduser().resolve()
    data_root = get_data_repo_root_or_none()
    run_id = os.environ.get(RUN_ID_ENV)
    if data_root is not None and run_id:
        return (data_root / run_id).resolve()
    return None


def get_data_repo_root() -> Path:
    root = os.environ.get(ENV_VAR_NAME)
    if not root:
        raise RuntimeError(
            f"Environment variable {ENV_VAR_NAME} is not set.\n\n"
            "PowerShell (current session):\n"
            "  $env:DATA_REPO_PATH = 'C:\\path\\to\\data-repo'\n\n"
            "PowerShell (permanent):\n"
            '  setx DATA_REPO_PATH "C:\\path\\to\\data-repo"'
        )
    return Path(root).expanduser().resolve()


def get_data_repo_root_or_none() -> Path | None:
    """Return DATA_REPO_PATH if set, else None. Use when data repo is optional."""
    root = os.environ.get(ENV_VAR_NAME)
    if not root:
        return None
    return Path(root).expanduser().resolve()


def resolve_data_path(rel_path: str | Path) -> Path:
    return get_data_repo_root() / Path(rel_path)


def _existing_first(paths: Iterable[Path]) -> Path | None:
    for p in paths:
        try:
            if p.exists():
                return p
        except OSError:
            # e.g. permission issues / broken symlinks
            pass
    return None


def _try_direct(root: Path, rel_path: Path) -> Path | None:
    """Return root / rel_path if it exists, else None."""
    candidate = root / rel_path
    return candidate if candidate.exists() else None


def _search_bare_name(root: Path, name: str) -> Path | None:
    """Search for filename under results/, series/, then anywhere under root."""
    hit = _existing_first(
        [root / "results" / name, root / "series" / name],
    )
    if hit:
        return hit
    return _existing_first(root.rglob(name))


def smart_resolve_path(
    local_root: Path,
    rel_path: str | Path,
    config_data_repo_root: Path | None = None,
) -> Path:
    """
    Resolve a path robustly across:
      - local_root (config dir or run dir)
      - config_data_repo_root (paths.data_repo_root from config, if set)
      - DATA_REPO_PATH (env var, if set)

    Search order:
      0) If rel_path is absolute and exists -> return it
      1) local_root / rel_path
      2) config_data_repo_root / rel_path (if provided)
      3) DATA_REPO_PATH / rel_path (if env set)
      4) If bare filename: same order under results/, series/, then rglob.
    """
    local_root = Path(local_root).expanduser().resolve()
    rel_path = Path(rel_path)
    p_local = local_root / rel_path
    result: Path | None = None

    if rel_path.is_absolute() and rel_path.exists():
        result = rel_path
    if result is None:
        result = _try_direct(local_root, rel_path)
    if result is None and config_data_repo_root is not None:
        config_root = Path(config_data_repo_root).expanduser().resolve()
        result = _try_direct(config_root, rel_path)
    if result is None:
        data_root = get_data_repo_root_or_none()
        if data_root is not None:
            result = _try_direct(data_root, rel_path)

    if result is not None:
        return result

    if rel_path.parent not in (Path(), Path()):
        return p_local

    name = rel_path.name
    result = _search_bare_name(local_root, name)
    if result is None and config_data_repo_root is not None:
        config_root = Path(config_data_repo_root).expanduser().resolve()
        result = _search_bare_name(config_root, name)
    if result is None:
        data_root = get_data_repo_root_or_none()
        if data_root is not None:
            result = _search_bare_name(data_root, name)

    return result if result is not None else p_local
