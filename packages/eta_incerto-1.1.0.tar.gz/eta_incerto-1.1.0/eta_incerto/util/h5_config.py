"""Save config dicts to HDF5 groups in an HDF5-native way (no object dtype)."""

from __future__ import annotations

import json
from typing import Any

import h5py
import numpy as np


def save_config_to_h5(group: h5py.Group, d: dict[str, Any]) -> None:
    """Recursively write a config dict into an HDF5 group.

    Handles dicts (as subgroups), lists of dicts (as subgroup with "0", "1", ...),
    lists of HDF5-serializable scalars (as datasets), object/mixed lists (as JSON string),
    and scalars. Avoids object dtype so configs with e.g. scenario_file (list of dicts) save correctly.
    """
    for k, v in d.items():
        key = str(k)
        if isinstance(v, dict):
            save_config_to_h5(group.require_group(key), v)
        elif isinstance(v, list | tuple):
            _write_list(group, key, v)
        elif isinstance(v, np.ndarray):
            _write_ndarray(group, key, v)
        else:
            _write_scalar(group, key, v)


def _write_list(group: h5py.Group, key: str, v: list[Any] | tuple[Any, ...]) -> None:
    if len(v) == 0:
        group.create_dataset(key, data=np.asarray([], dtype=float))
        return
    if all(isinstance(item, dict) for item in v):
        sub = group.require_group(key)
        for i, item in enumerate(v):
            save_config_to_h5(sub.require_group(str(i)), item)
        return
    arr = np.asarray(v)
    if arr.dtype == object:
        group.create_dataset(
            key,
            data=json.dumps(v, default=str),
            dtype=h5py.string_dtype(encoding="utf-8"),
        )
        return
    if np.issubdtype(arr.dtype, np.str_):
        # h5py has no conversion path for numpy Unicode dtype (<U11 etc.)
        group.create_dataset(
            key,
            data=np.asarray(v, dtype=object),
            dtype=h5py.special_dtype(vlen=str),
        )
        return
    group.create_dataset(key, data=arr)


def _write_ndarray(group: h5py.Group, key: str, v: np.ndarray) -> None:
    if v.dtype == object:
        group.create_dataset(
            key,
            data=json.dumps(v.tolist(), default=str),
            dtype=h5py.string_dtype(encoding="utf-8"),
        )
        return
    if np.issubdtype(v.dtype, np.str_):
        group.create_dataset(
            key,
            data=v.astype(object),
            dtype=h5py.special_dtype(vlen=str),
        )
        return
    group.create_dataset(key, data=v)


def _write_scalar(group: h5py.Group, key: str, v: Any) -> None:
    try:
        group.create_dataset(key, data=v)
    except TypeError:
        group.create_dataset(key, data=str(v), dtype=h5py.string_dtype(encoding="utf-8"))
