import numpy as np
from numba import njit, prange


@njit(cache=True, fastmath=True)
def skew_moment(y):
    n = y.shape[0]
    if n < 3:
        return 0.0
    mean = 0.0
    for i in range(n):
        mean += y[i]
    mean /= n

    m2 = 0.0
    m3 = 0.0
    for i in range(n):
        d = y[i] - mean
        m2 += d * d
        m3 += d * d * d
    m2 /= n
    m3 /= n
    if m2 <= 1e-30:
        return 0.0
    return m3 / (m2**1.5)


@njit(cache=True, fastmath=True, parallel=True)
def upr_from_y_weights(y, weights, omega):
    # parallel reduction: split sums
    n = y.shape[0]
    upside = 0.0
    downside = 0.0
    for i in prange(n):
        yi = y[i]
        wi = weights[i]
        if yi < omega:
            upside += (omega - yi) * wi
        elif yi > omega:
            d = omega - yi
            downside += (d * d) * wi
    eps = 1e-12
    return upside / max(np.sqrt(downside), eps)
