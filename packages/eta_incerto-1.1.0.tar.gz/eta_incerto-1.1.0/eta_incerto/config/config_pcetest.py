from __future__ import annotations

from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator


class ConfigPceTest(BaseModel):
    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)
    sampler: str
    n_val: int
    max_order: int
    design_var_min: int
    design_var_max: int
    design_var_step: int
    min_order: int = Field(
        default=1,
        ge=1,
        description="Lowest PCE polynomial order to evaluate\
             (inclusive). Use with max_order to run a subset (e.g. only order 3).",
    )

    # When True: sweep each pymoo decision variable along its bounds (others fixed at reference).
    multi_axis_sweep: bool = Field(
        default=False,
        description="If True, run pcetest per design dimension using full pymoo x vectors; writes by_axis/ in H5.",
    )
    reference_design: list[float] | None = Field(
        default=None,
        description=(
            "Fixed part of x when sweeping one axis; length must match pymoo variables. None = midpoint of bounds."
        ),
    )
    n_sweep_points: int = Field(
        default=11,
        ge=2,
        description="Number of linspace points per axis between x_lower_bound[k] and x_upper_bound[k].",
    )
    pce_diagnostics_mode: Literal["none", "kfold", "loo"] = Field(
        default="none",
        description="Cross-validation on the PCE training sample: none | kfold | loo (exact LOO refits).",
    )
    pce_diagnostics_cv_folds: int = Field(
        default=5,
        ge=2,
        description="K for k-fold CV (capped to n_train at runtime).",
    )
    pce_diagnostics_seed: int | None = Field(
        default=42,
        description="RNG seed for shuffling indices in k-fold CV (None = non-deterministic).",
    )

    @model_validator(mode="after")
    def _min_order_le_max_order(self) -> Self:
        if self.min_order > self.max_order:
            raise ValueError("pcetest.min_order must be <= pcetest.max_order")
        return self
