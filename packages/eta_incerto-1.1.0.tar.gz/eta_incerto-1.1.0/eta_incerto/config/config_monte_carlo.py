from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ConfigDesignRef(BaseModel):
    """Reference to an optimized design artifact (JSON/H5)."""

    model_config = ConfigDict(extra="allow")

    source_path: Path
    source_type: Literal["json", "h5"]

    selector: str | None = None
    design_id: str | None = None

    tags: list[str] = Field(default_factory=list)

    feasibility_policy: Literal["skip", "penalize", "repair"] = "skip"

    meta: dict[str, Any] = Field(default_factory=dict)


class ConfigBaselineUncertaintyRef(BaseModel):
    """Reference to the baseline uncertainty model/system."""

    model_config = ConfigDict(extra="allow")

    source_path: Path
    source_type: Literal["json", "h5"]

    selector: str | None = None

    meta: dict[str, Any] = Field(default_factory=dict)


class ConfigPerturbation(BaseModel):
    """Declarative stage-based perturbation of baseline uncertainty."""

    model_config = ConfigDict(extra="allow")

    kind: Literal[
        "sigma_scale",
        "bounds_widen",
        "dist_override",
        "stress_factor",
    ]

    mode: Literal["aleatory", "epistemic"]

    targets: list[str] = Field(default_factory=list)

    levels: list[float] = Field(
        default_factory=list,
        description="Perturbation levels applied to baseline uncertainty.",
    )

    knobs: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional parameters controlling perturbation behavior.",
    )


class ConfigMonteCarlo(BaseModel):
    """Monte Carlo sampling configuration (reproducibility, backend, and optional engine params)."""

    model_config = ConfigDict(extra="allow")

    n_samples: int = Field(
        default=100,
        ge=1,
        description="Number of samples per run.",
    )

    seed_mode: Literal["fixed", "random", "multi"] = Field(
        default="fixed",
        description="Seed strategy controlling reproducibility.",
    )

    seed: int | None = Field(
        default=0,
        ge=0,
        description="Single seed used when seed_mode='fixed'.",
    )

    n_runs: int = Field(
        default=1,
        ge=1,
        description="Number of independent runs (used in multi/random modes).",
    )

    seeds: list[int] = Field(
        default_factory=list,
        description="Explicit seed list (optional override for multi mode).",
    )

    use_crn: bool = Field(
        default=True,
        description="Use common random numbers across designs/stages.",
    )

    backend: Literal["direct", "surrogate"] = Field(
        default="direct",
        description="Evaluator backend used for Monte Carlo execution.",
    )

    params: dict[str, Any] = Field(
        default_factory=dict,
        description=("Additional engine-specific parameters. For example: {'parallel': true, 'n_workers': 2}"),
    )


class ConfigKpi(BaseModel):
    """KPI definition and interpretation metadata."""

    model_config = ConfigDict(extra="allow")

    name: str

    direction: Literal["min", "max"] | None = Field(
        default=None,
        description="Optimization direction for comparisons.",
    )

    thresholds: dict[str, float] = Field(
        default_factory=dict,
        description="Threshold values for pass/fail or risk evaluation.",
    )

    risk_metrics: list[str] = Field(
        default_factory=list,
        description="Additional risk metrics to compute.",
    )

    quantiles: list[float] = Field(
        default_factory=lambda: [0.05, 0.5, 0.95],
        description="Quantiles to evaluate.",
    )


class ConfigMonteCarloReporting(BaseModel):
    """Reporting/export options for statistical evaluation outputs."""

    model_config = ConfigDict(extra="allow")

    export_raw: bool = Field(
        default=True,
        description="Export raw Monte Carlo samples.",
    )

    export_summary: bool = Field(
        default=True,
        description="Export aggregated summary statistics.",
    )

    formats: list[Literal["json", "csv", "parquet"]] = Field(
        default_factory=lambda: ["json"],
        description="Export file formats.",
    )

    plots: list[str] = Field(
        default_factory=list,
        description="List of plot identifiers to generate.",
    )

    output_dir: Path | None = Field(
        default=None,
        description="Output directory for exports.",
    )


class ConfigStatisticalEvaluation(BaseModel):
    """Top-level config for the statistical evaluation module."""

    model_config = ConfigDict(extra="allow")

    enabled: bool = Field(
        default=False,
        description="Enable statistical evaluation module.",
    )

    designs: list[ConfigDesignRef] = Field(
        default_factory=list,
        description="Design references to evaluate.",
    )

    baseline_uncertainty: ConfigBaselineUncertaintyRef | None = Field(
        default=None,
        description="Baseline uncertainty reference.",
    )

    perturbation: ConfigPerturbation | None = Field(
        default=None,
        description="Stage-based perturbation specification.",
    )

    monte_carlo: ConfigMonteCarlo = Field(
        default_factory=ConfigMonteCarlo,
        description="Monte Carlo execution configuration.",
    )

    kpis: list[ConfigKpi] = Field(
        default_factory=list,
        description="KPIs to evaluate.",
    )

    reporting: ConfigMonteCarloReporting = Field(
        default_factory=ConfigMonteCarloReporting,
        description="Reporting/export options.",
    )
