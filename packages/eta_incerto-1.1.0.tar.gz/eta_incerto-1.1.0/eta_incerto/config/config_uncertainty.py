from __future__ import annotations

from pydantic import BaseModel, field_validator


class QuantileConfig(BaseModel):
    p: float
    x: float


class ParameterUncertaintyConfig(BaseModel):
    type: str
    params: dict[str, float] | None = None
    quantiles: list[QuantileConfig] | None = None
    name: str
    units: str | None = None
    notes: str | None = None

    @field_validator("quantiles", mode="before")
    def normalize_quantiles(cls, v):  # noqa: N805
        if v is None:
            return v

        # Accept [[p, x]] and convert to [{p, x}]
        if isinstance(v, list) and v and isinstance(v[0], list):
            return [{"p": q[0], "x": q[1]} for q in v]

        return v
