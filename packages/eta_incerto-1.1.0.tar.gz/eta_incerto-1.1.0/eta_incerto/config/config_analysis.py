"""
Analysis configuration.

This config defines optional post-processing and sensitivity analyses
(e.g. std_target analysis based on typical periods).
"""

from pydantic import BaseModel, Field


class ConfigAnalysis(BaseModel):
    """
    Configuration for the analysis module.

    Defaults are intentionally disabled so that analysis is optional and
    Monte Carlo can be used independently.
    """

    enabled: bool = Field(default=False, description="Enable or disable the analysis module.")

    mode: str = Field(default="", description="Analysis mode identifier (e.g. 'std_target').")

    factors: list[float] = Field(default_factory=list, description="Scaling factors applied in the analysis.")

    seed: int = Field(default=0, description="Random seed used for the analysis.")

    results_subdir: str = Field(default="analysis", description="Subdirectory name for analysis results.")

    make_plots: bool = Field(default=False, description="Whether plots should be generated.")

    pdf_name: str = Field(default="analysis.pdf", description="Filename of the generated analysis PDF report.")
