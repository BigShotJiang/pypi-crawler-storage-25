# config_pyomo.py (replace the file content)

from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field, model_validator

from eta_incerto.config.config_settings import ConfigSettings

if TYPE_CHECKING:
    from typing import Any


log = getLogger(__name__)


class ConfigPyomoHorizon(BaseModel):
    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    n_years: int = Field(ge=1)
    n_time_steps: int = Field(ge=1)
    n_periods: int = Field(ge=1)
    year_length: int = Field(default=1, ge=1)
    n_days_in_year: int = Field(ge=1)

    @model_validator(mode="after")
    def validate_year_length(self):
        if self.year_length > self.n_years:
            raise ValueError(f"year_length ({self.year_length}) must be <= n_years ({self.n_years}).")
        return self


class ConfigPyomo(BaseModel):
    """
    Pyomo / eta-components MILP problem configuration.

    Matches config.json structure under "pyomo": {...}.
    """

    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

    # objective definition for the solved MILP
    objective_kind: str = Field(description="e.g. 'npv', 'tac', or 'emissions'")

    # economics / global parameters
    interest: float = Field(ge=0.0)
    emission_cost: float = Field(ge=0.0)

    # model switches
    remove_plr: bool = False
    remove_storage_binary: bool = False
    use_two_stage: bool = Field(
        default=False,
        description="True: one system with n_scenarios, one solve (stochastic/robust/regret).",
    )

    # time discretization
    horizon: ConfigPyomoHorizon

    # solver settings (merged here)
    solver_settings: ConfigSettings

    # mapping from objective_kind -> KPI key (optional but handy)
    kpi_mapping: dict[str, str] = Field(default_factory=dict)

    def model_post_init(self, __context: Any, /) -> None:
        log.info("ConfigPyomo loaded: objective_kind=%s, solver=%s", self.objective_kind, self.solver_settings.solver)
