from __future__ import annotations

from logging import getLogger
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field, ValidationError, field_validator

from eta_incerto.config.config_algorithm import ConfigAlgorithm
from eta_incerto.config.config_analysis import ConfigAnalysis
from eta_incerto.config.config_evaluate import ConfigEvaluate
from eta_incerto.config.config_monte_carlo import ConfigStatisticalEvaluation
from eta_incerto.config.config_paths import ConfigPaths
from eta_incerto.config.config_pcetest import ConfigPceTest
from eta_incerto.config.config_plot_style import ConfigPlotStyleLegacy, ConfigPlotting
from eta_incerto.config.config_plots import ConfigPlots
from eta_incerto.config.config_pymoo import ConfigPymoo
from eta_incerto.config.config_pyomo import ConfigPyomo
from eta_incerto.config.config_scenario import ConfigScenario
from eta_incerto.config.config_series import ConfigSeries
from eta_incerto.config.config_system import ConfigSystem
from eta_incerto.config.config_termination import ConfigTermination
from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig
from eta_incerto.config.config_uncertainty_doe import ConfigUncertaintyDoe
from eta_incerto.util.data_paths import smart_resolve_path
from eta_incerto.util.io_utils import load_config

if TYPE_CHECKING:
    from typing import Any

log = getLogger(__name__)


def _first_variant(config: dict[str, Any]) -> str | None:
    """Try to determine the first variant name from config."""
    sys_section = config.get("system", {})
    if isinstance(sys_section, dict):
        variants = sys_section.get("variant")
        if isinstance(variants, list) and variants:
            return str(variants[0])
    return None


def _is_uncertainty_only_antifragile(config: dict[str, Any]) -> bool:
    """Detect strict uncertainty-only antifragile config for variant_one."""
    system_section = config.get("system", {})
    variants = system_section.get("variant") if isinstance(system_section, dict) else None
    if not isinstance(variants, list) or "variant_one" not in variants:
        return False
    unc = config.get("uncertainty")
    if isinstance(unc, dict):
        return isinstance(unc.get("variant_one"), list) and len(unc.get("variant_one", [])) > 0
    return isinstance(unc, list) and len(unc) > 0


def _upgrade_legacy_config_inplace(config: dict[str, Any]) -> None:
    """
    Upgrade legacy config formats to the current schema IN-MEMORY.

    This allows loading old run configs (with keys like "pyomo", "pymoo", per-variant "evaluate")
    without modifying the original config.json on disk.
    """
    # If it's already in the new format, do nothing.
    if {"settings", "system", "series", "scenario", "problem"}.issubset(config.keys()):
        return

    # ---- Legacy: "pyomo.solver_settings" -> "settings" ----
    if "settings" not in config and "pyomo" in config:
        pyomo = config.get("pyomo", {}) or {}
        solver_settings = pyomo.get("solver_settings", {}) or {}

        config["settings"] = {
            "seed": solver_settings.get("seed", 123),
            "verbose": solver_settings.get("verbose", False),
            "tee": solver_settings.get("tee", False),
            "solver": solver_settings.get("solver", "cplex"),
            "options": solver_settings.get("options", {}),
            "model_export": solver_settings.get("model_export", False),
        }

    # ---- Legacy: "pyomo" core fields / horizon -> "system" ----
    if "system" not in config or not isinstance(config.get("system"), dict):
        config["system"] = {} if "system" not in config else dict(config["system"])

    if "pyomo" in config:
        pyomo = config.get("pyomo", {}) or {}
        horizon = pyomo.get("horizon", {}) or {}

        config["system"].setdefault("objective", pyomo.get("objective_kind", "npv"))
        config["system"].setdefault("lifetime", pyomo.get("lifetime", 20))
        config["system"].setdefault("interest", pyomo.get("interest", 0.03))
        config["system"].setdefault("emission_cost", pyomo.get("emission_cost", 0.1))
        config["system"].setdefault("remove_plr", pyomo.get("remove_plr", True))
        config["system"].setdefault("remove_storage_binary", pyomo.get("remove_storage_binary", False))

        config["system"].setdefault("n_years", horizon.get("n_years", 10))
        config["system"].setdefault("n_time_steps", horizon.get("n_time_steps", 24))
        config["system"].setdefault("n_periods", horizon.get("n_periods", 6))
        config["system"].setdefault("year_length", horizon.get("year_length", 1))
        config["system"].setdefault("n_days_in_year", horizon.get("n_days_in_year", 365))

    if "evaluate" in config and isinstance(config["evaluate"], dict):
        ev = config["evaluate"]

        # If already new-style (values are dicts), keep as-is
        if ev and all(isinstance(v, dict) for v in ev.values()):
            pass
        else:
            # Flat legacy evaluate dict -> wrap into first variant (or "variant_one")
            preferred = _first_variant(config) or "variant_one"
            config["evaluate"] = {preferred: dict(ev)}

    # ---- Legacy: pymoo.problems -> problem ----
    # New ConfigProblem expects one problem definition; legacy often stores:
    # "pymoo": {"vtype": "...", "normalize": ..., "problems": {"variant_one": {...}, ...}}
    if "problem" not in config and "pymoo" in config and isinstance(config["pymoo"], dict):
        pymoo = config["pymoo"]
        problems = pymoo.get("problems", {})
        if isinstance(problems, dict) and problems:
            preferred = _first_variant(config)
            chosen_key = preferred if preferred in problems else next(iter(problems.keys()))
            chosen = problems[chosen_key] if isinstance(problems[chosen_key], dict) else {}

            variable_names = chosen.get("variable_names", []) or []
            objective_names = chosen.get("objective_names", []) or []

            config["problem"] = {
                "n_variables": len(variable_names),
                "variable_names": variable_names,
                "n_objectives": len(objective_names),
                "objective_names": objective_names,
                "normalize": bool(chosen.get("normalize", pymoo.get("normalize", False))),
                "obj_min": chosen.get("obj_min", []),
                "obj_max": chosen.get("obj_max", []),
                "n_ieq_constraints": int(chosen.get("n_ieq_constraints", 0)),
                "n_eq_constraints": int(chosen.get("n_eq_constraints", 0)),
                "x_lower_bound": chosen.get("x_lower_bound", []),
                "x_upper_bound": chosen.get("x_upper_bound", []),
                "vtype": pymoo.get("vtype", "float"),
            }

    # ---- Run-folder layout compatibility ----
    # The data repo stores H5 artifacts under run_root/results/ (results home).
    # Plotters use paths.results_dir (e.g. "results") so they look in run_root/results/.

    if "plots" in config and isinstance(config["plots"], dict):
        ts = config["plots"].get("typical_series")
        if isinstance(ts, dict) and ts.get("folder") == "eta":
            ts["folder"] = "."


def _pop_section(dikt: dict[str, Any], key: str, config_name: str) -> dict[str, Any]:
    """Pop a section dict from dikt; raise if missing or not a dict."""
    if key not in dikt:
        raise KeyError(
            f"Missing section '{key}' in configuration file {config_name}. "
            f"Available top-level keys: {sorted(dikt.keys())}"
        )
    val = dikt.pop(key)
    if not isinstance(val, dict):
        raise TypeError(f"'{key}' section must be a dictionary of solver_settings.")
    return val


def _preprocess_paths_for_external_data_repo(
    section_key: str,
    section_dict: dict[str, Any],
    root_path: Path,
    config_data_repo_root: Path | None = None,
) -> None:
    """Rewrite relevant file paths so validators that check Path(...).exists() work."""
    if section_key == "series":
        series_files = section_dict.get("series_file", [])
        if isinstance(series_files, list):
            for entry in series_files:
                if isinstance(entry, dict) and "raw_data_path" in entry:
                    rel = entry["raw_data_path"]
                    resolved = smart_resolve_path(root_path, rel, config_data_repo_root=config_data_repo_root)
                    entry["raw_data_path"] = str(resolved)
    if section_key == "scenario":
        scenario_files = section_dict.get("scenario_file", [])
        if isinstance(scenario_files, list):
            for entry in scenario_files:
                if isinstance(entry, dict) and "path" in entry:
                    rel = entry["path"]
                    resolved = smart_resolve_path(root_path, rel, config_data_repo_root=config_data_repo_root)
                    entry["path"] = str(resolved)


def _load_section(
    dikt: dict[str, Any],
    key: str,
    cls_: type,
    config_name: str,
    root_path: Path,
    *,
    extra: dict | None = None,
    config_data_repo_root: Path | None = None,
) -> Any:
    """Pop a section and load it into a Pydantic model."""
    section_dict = _pop_section(dikt, key, config_name)
    if extra:
        section_dict.update(extra)
    _preprocess_paths_for_external_data_repo(key, section_dict, root_path, config_data_repo_root)
    try:
        return cls_.model_validate(section_dict)
    except ValidationError as e:
        log.info(e.json())
        log.exception("Failed reading '%s' section from config %s.", key, config_name)
        raise


def _load_uncertainty_doe(config: dict[str, Any], config_name: str, root_path: Path) -> ConfigUncertaintyDoe:
    """Load uncertainty_doe from 'uncertainty_doe' or legacy 'doe' section."""
    if "uncertainty_doe" in config:
        return _load_section(config, "uncertainty_doe", ConfigUncertaintyDoe, config_name, root_path)
    if "doe" in config:
        doe_dict = _pop_section(config, "doe", config_name)
        doe_dict["uncertainty_doe_n_samples"] = doe_dict.pop("n_samples", doe_dict.get("uncertainty_doe_n_samples"))
        return ConfigUncertaintyDoe.model_validate(doe_dict)
    raise KeyError(
        f"Missing section 'uncertainty_doe' (or legacy 'doe') in configuration file {config_name}. "
        f"Available top-level keys: {sorted(config.keys())}"
    )


def _load_series_section(
    config: dict[str, Any],
    *,
    config_name: str,
    root_path: Path,
    data_repo_root: Path | None,
) -> ConfigSeries:
    if "series" in config:
        return _load_section(
            config,
            "series",
            ConfigSeries,
            config_name,
            root_path,
            extra={"root_path": root_path, "data_repo_root": data_repo_root},
            config_data_repo_root=data_repo_root,
        )
    return ConfigSeries.model_construct(series_file=[], data_repo_root=data_repo_root)


def _load_scenario_section(
    config: dict[str, Any],
    *,
    config_name: str,
    root_path: Path,
    data_repo_root: Path | None,
) -> ConfigScenario:
    if "scenario" in config:
        return _load_section(
            config,
            "scenario",
            ConfigScenario,
            config_name,
            root_path,
            extra={"root_path": root_path, "data_repo_root": data_repo_root},
            config_data_repo_root=data_repo_root,
        )
    return ConfigScenario.model_construct(
        carrier_types=["gas", "electricity"],
        scenario_file=[],
        data_repo_root=data_repo_root,
    )


def _load_optional_section(
    config: dict[str, Any],
    key: str,
    cls_: type,
    *,
    config_name: str,
    root_path: Path,
) -> Any | None:
    if key not in config:
        return None
    return _load_section(config, key, cls_, config_name, root_path)


def _parse_uncertainty_section(
    config: dict[str, Any],
) -> dict[str, list[ParameterUncertaintyConfig]] | list[ParameterUncertaintyConfig]:
    uncertainty: dict[str, list[ParameterUncertaintyConfig]] | list[ParameterUncertaintyConfig] = {}
    if "uncertainty" not in config:
        return uncertainty
    raw_uncertainty = config.pop("uncertainty")
    if isinstance(raw_uncertainty, list):
        return [ParameterUncertaintyConfig.model_validate(u) for u in raw_uncertainty]
    if isinstance(raw_uncertainty, dict):
        parsed: dict[str, list[ParameterUncertaintyConfig]] = {}
        for key, val in raw_uncertainty.items():
            if not isinstance(val, list):
                raise TypeError(f"'uncertainty.{key}' must be a list of parameter definitions.")
            parsed[key] = [ParameterUncertaintyConfig.model_validate(u) for u in val]
        return parsed
    raise TypeError("'uncertainty' section must be a list or a dict of lists.")


class ConfigOptimization(BaseModel):
    """Configuration for the optimization, which can be loaded from a JSON file."""

    config_name: str
    root_path: Path = Field(frozen=True)
    paths: ConfigPaths
    series: ConfigSeries
    scenario: ConfigScenario
    system: ConfigSystem
    pymoo: ConfigPymoo
    pyomo: ConfigPyomo
    termination: ConfigTermination
    algorithm: ConfigAlgorithm
    evaluate: ConfigEvaluate
    monte_carlo: ConfigStatisticalEvaluation | None = None

    # Preferred optional plotting config (new)
    plotting: ConfigPlotting | None = None

    # LEGACY (optional fallback)
    plot_style: ConfigPlotStyleLegacy | None = None

    plots: ConfigPlots
    uncertainty_doe: ConfigUncertaintyDoe
    pcetest: ConfigPceTest
    analysis: ConfigAnalysis = Field(default_factory=ConfigAnalysis)

    # Optional: expert quantiles / direct params per variant (list = global, dict = per variant)
    uncertainty: dict[str, list[ParameterUncertaintyConfig]] | list[ParameterUncertaintyConfig] = Field(
        default_factory=dict
    )

    @field_validator("root_path", mode="before")
    @classmethod
    def convert_to_path(cls, v) -> Path:
        if isinstance(v, str):
            return Path(v)
        return v

    @classmethod
    def from_file(cls, file: Path, root_path: Path) -> ConfigOptimization:
        """Load configuration from JSON/TOML/YAML file."""
        config = load_config(file)
        config_name = Path(file).stem
        return ConfigOptimization.from_dict(config, config_name, root_path)

    @classmethod
    def from_dict(cls, config: dict[str, Any], config_name: str, root_path: Path) -> ConfigOptimization:
        """Build a Config object from a dictionary of configuration options."""
        _upgrade_legacy_config_inplace(config)
        uncertainty_only_antifragile = _is_uncertainty_only_antifragile(config)
        required = {
            "settings",
            "paths",
            "system",
            "problem",
            "termination",
            "algorithm",
            "evaluate",
        }
        if not uncertainty_only_antifragile:
            required |= {"scenario", "series"}
        missing = required - config.keys()
        if missing:
            raise ValueError(f"Missing section(s) {', '.join(sorted(missing))} in configuration file {config_name}.")

        paths = _load_section(
            config,
            "paths",
            ConfigPaths,
            config_name,
            root_path,
            extra={"root_path": root_path},
        )
        series = _load_series_section(
            config,
            config_name=config_name,
            root_path=root_path,
            data_repo_root=paths.data_repo_root,
        )
        scenario = _load_scenario_section(
            config,
            config_name=config_name,
            root_path=root_path,
            data_repo_root=paths.data_repo_root,
        )
        system = _load_section(config, "system", ConfigSystem, config_name, root_path)
        pymoo = _load_section(config, "pymoo", ConfigPymoo, config_name, root_path)
        pyomo = _load_section(config, "pyomo", ConfigPyomo, config_name, root_path)
        termination = _load_section(config, "termination", ConfigTermination, config_name, root_path)
        algorithm = _load_section(config, "algorithm", ConfigAlgorithm, config_name, root_path)
        evaluate = _load_section(config, "evaluate", ConfigEvaluate, config_name, root_path)
        monte_carlo = _load_optional_section(
            config, "monte_carlo", ConfigStatisticalEvaluation, config_name=config_name, root_path=root_path
        )
        plotting = _load_optional_section(
            config, "plotting", ConfigPlotting, config_name=config_name, root_path=root_path
        )
        plot_style = _load_optional_section(
            config, "plot_style", ConfigPlotStyleLegacy, config_name=config_name, root_path=root_path
        )
        if plotting is None and plot_style is None:
            raise ValueError(
                "Missing plotting configuration. Provide either 'plotting' (new) or 'plot_style' (legacy)."
            )
        plots = _load_section(config, "plots", ConfigPlots, config_name, root_path)
        uncertainty_doe = _load_uncertainty_doe(config, config_name, root_path)
        pcetest = _load_section(config, "pcetest", ConfigPceTest, config_name, root_path)
        analysis = (
            _load_optional_section(config, "analysis", ConfigAnalysis, config_name=config_name, root_path=root_path)
            or ConfigAnalysis()
        )

        uncertainty = _parse_uncertainty_section(config)

        return cls(
            config_name=config_name,
            root_path=root_path,
            paths=paths,
            series=series,
            system=system,
            scenario=scenario,
            pymoo=pymoo,
            pyomo=pyomo,
            termination=termination,
            algorithm=algorithm,
            evaluate=evaluate,
            monte_carlo=monte_carlo,
            plotting=plotting,
            plot_style=plot_style,
            plots=plots,
            uncertainty_doe=uncertainty_doe,
            pcetest=pcetest,
            analysis=analysis,
            uncertainty=uncertainty,
        )
