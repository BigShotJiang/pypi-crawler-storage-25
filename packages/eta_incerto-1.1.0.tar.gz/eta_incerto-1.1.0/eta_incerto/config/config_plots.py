from __future__ import annotations

from logging import getLogger
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

log = getLogger(__name__)


class ConfigTypicalSeries(BaseModel):
    model_config = ConfigDict(extra="forbid")  # keep strict schema

    folder: str | None = None
    file: str
    weights_file: str
    kind: Literal["weights", "periods", "overlay"] = "periods"
    key: list[str] | None = None
    ncols: int = 3
    where: Literal["pre", "post", "mid"] = "post"
    legend_mode: Literal["none", "first", "each"] = "first"
    show_weighted_mean: bool = False

    # overlay-only: list of {"key": "<series_name>", "column": "<col>", "label": "<legend>"}; key required
    specs: list[dict[str, Any]] | None = None

    # MathText supported
    # Example values may include Matplotlib MathText for subscripts/superscripts.
    display_names: dict[str, str] = Field(default_factory=dict)


class ConfigDispatchHeatmap(BaseModel):
    model_config = ConfigDict(extra="forbid")
    cmap: str = "bwr"
    vmin: float | None = None
    vmax: float | None = None
    interpolation: str = "none"
    aspect: str = "auto"
    cbar_label: str = "kW"


class ConfigDispatch(BaseModel):
    model_config = ConfigDict(extra="allow")  # allow extra keys

    file: str
    scenario: str | None = None
    components: list[str] | None = None

    n_years: int | None = None
    n_periods: int | None = None
    n_time_steps: int | None = None

    show_day_grid: bool = True
    heatmap: ConfigDispatchHeatmap = ConfigDispatchHeatmap()


class ConfigParetoOptions(BaseModel):
    """Optional Pareto plot options (backward compatible: all optional)."""

    model_config = ConfigDict(extra="allow")

    show_front: bool = True
    show_diagnostics: bool = True
    matrix_mode: bool = True
    x: str | None = None
    y: str | None = None
    pairs: list[list[str]] | None = None
    max_abs_f: float | None = Field(
        default=None,
        description=(
            "Omit points where either plotted objective has |f| > threshold "
            "(e.g. 1e3-1e6 for normalized runs; hides penalty-scale outliers). None = no filter."
        ),
    )


class ConfigPlots(BaseModel):
    comparison: list[list[str, str]]
    invest_table: list[str]
    scenario: list[str]
    pareto: list[str]
    topology: list[str]
    dispatch: list[str] | ConfigDispatch | None = None
    typical_series: ConfigTypicalSeries | None = None
    pareto_options: ConfigParetoOptions | None = None

    # Optional: design-variable scatter (antifragile X vs F). If None, falls back to pareto.
    design_scatter: list[str] | None = None

    # Optional: DOE evaluation plot (design var vs objective). Uses design_doe, else design_scatter, else pareto.
    design_doe: list[str] | None = None

    # Optional: PCE RMSE plot (RMSE vs order). Single file or list.
    pce_rmse: str | list[str] | None = None

    # Optional: x-axis label for the diagnostic-vs-design plot (LOO/CV vs pcetest design grid).
    pce_design_var_xlabel: str | None = None

    # When True, also plot diagnostic (LOO/CV) vs design: legacy rmse/design_var, or multi_axis
    # by_axis/{k}/sweep_values (Figure 9 style).
    pce_plot_diagnostic_vs_design: bool = True

    # Max legend entries per sweep line in multi-axis LOO/RMSE vs order plots (remaining lines unlabeled).
    pce_multi_axis_max_legend_lines: int = Field(default=12, ge=1)

    # Optional: Sobol bar plot (reads sobol/ from antifragile H5 only).
    sobol: str | list[str] | None = None
    sobol_pareto_row: int = Field(default=0, ge=0, description="Which Pareto row in sobol/S1 to plot.")

    # Optional: marginal PDF/CDF panels (reads marginals/ from antifragile H5 only).
    marginals: str | list[str] | None = None
