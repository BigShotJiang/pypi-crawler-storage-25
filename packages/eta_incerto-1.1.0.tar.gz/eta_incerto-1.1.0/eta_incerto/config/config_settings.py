from __future__ import annotations

from logging import getLogger
from typing import TYPE_CHECKING, Self

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from typing import Any

log = getLogger(__name__)


class ConfigSettings(BaseModel):
    model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)
    seed: int = Field(ge=0, le=999)
    verbose: bool = Field(default=False)
    tee: bool = Field(default=True)
    solver: str = Field(default="highs", description="Linopy solver: highs, cplex, gurobi, etc.")
    options: dict[str, float] = Field(default_factory=dict)
    model_export: bool = Field(default=False)

    @classmethod
    def from_dict(cls, dikt: dict[str, Any]) -> Self:
        return cls(**dikt)
