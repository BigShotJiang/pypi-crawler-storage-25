from __future__ import annotations

from collections.abc import Iterator

import chaospy as cp
import numpy as np

from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig
from eta_incerto.uncertainty.chaospy_factory import build_chaospy_distribution
from eta_incerto.uncertainty.distribution_builder import build_distribution_spec
from eta_incerto.uncertainty.marginal_export import grid_pdf_cdf
from eta_incerto.uncertainty.parameterization import parameterize_from_quantiles
from eta_incerto.uncertainty.spec import ParameterUncertaintySpec


def _chaospy_marginal_for_parameter_config(
    param_cfg: ParameterUncertaintyConfig,
) -> tuple[str, str | None, cp.Distribution]:
    spec = ParameterUncertaintySpec.from_config(param_cfg)
    if spec.params is not None:
        params = spec.params
    else:
        result = parameterize_from_quantiles(
            distribution_type=spec.type,
            quantiles=spec.quantiles,
        )
        params = result.params
    dist_spec = build_distribution_spec(
        distribution_type=spec.type,
        params=params,
    )
    dist = build_chaospy_distribution(dist_spec)
    return spec.name, spec.units, dist


def iter_marginal_curves_from_parameter_configs(
    configs: list[ParameterUncertaintyConfig],
    *,
    n_grid: int = 256,
) -> Iterator[tuple[str, str | None, np.ndarray, np.ndarray, np.ndarray]]:
    """
    For each ``uncertainty`` config entry, yield ``(name, units, grid_x, pdf, cdf)``.

    Uses the same parameterization and Chaospy build path as
    :func:`build_uncertainty_joint_distribution` (independent marginals).
    """
    for param_cfg in configs:
        name, units, dist = _chaospy_marginal_for_parameter_config(param_cfg)
        gx, pdf, cdf = grid_pdf_cdf(dist, n_grid=n_grid)
        yield name, units, gx, pdf, cdf


def build_uncertainty_joint_distribution(
    configs: list[ParameterUncertaintyConfig],
) -> cp.Distribution:
    distributions: list[cp.Distribution] = []
    variable_names: list[str] = []

    for param_cfg in configs:
        name, _units, dist = _chaospy_marginal_for_parameter_config(param_cfg)
        distributions.append(dist)
        variable_names.append(name)

    joint = cp.J(*distributions)
    joint.variable_names = variable_names  # type: ignore[attr-defined]

    return joint
