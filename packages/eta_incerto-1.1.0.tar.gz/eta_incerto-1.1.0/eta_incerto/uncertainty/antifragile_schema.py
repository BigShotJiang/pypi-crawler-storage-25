from __future__ import annotations

from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig

MANDATORY_ANTIFRAGILE_UNCERTAINTY_VARS: tuple[str, ...] = (
    "gas_unit_price",
    "electricity_unit_price",
)

ALLOWED_ANTIFRAGILE_DISTRIBUTION_TYPES: tuple[str, ...] = (
    "normal",
    "lognormal",
    "scaled_beta",
    "truncnorm",
    "trunc_gaussian_mixture",
)


def validate_antifragile_uncertainty_schema(uncertainty_list: list[ParameterUncertaintyConfig]) -> None:
    errors: list[str] = []
    names = [u.name for u in uncertainty_list]
    allowed = set(MANDATORY_ANTIFRAGILE_UNCERTAINTY_VARS)
    seen: set[str] = set()
    duplicates: set[str] = set()
    for name in names:
        if name in seen:
            duplicates.add(name)
        seen.add(name)
    missing = sorted(allowed - set(names))
    extras = sorted(set(names) - allowed)

    if missing:
        errors.append(f"missing mandatory variables: {', '.join(missing)}")
    if extras:
        errors.append(f"unsupported variables present: {', '.join(extras)}")
    if duplicates:
        errors.append(f"duplicate variable names: {', '.join(sorted(duplicates))}")

    allowed_types = set(ALLOWED_ANTIFRAGILE_DISTRIBUTION_TYPES)
    invalid_type = sorted({u.name for u in uncertainty_list if str(u.type).lower() not in allowed_types})
    if invalid_type:
        errors.append(
            "unsupported distribution types for variables: "
            f"{', '.join(invalid_type)}. Allowed types: {', '.join(sorted(allowed_types))}"
        )

    if errors:
        raise ValueError("Invalid antifragile uncertainty schema for variant_one:\n- " + "\n- ".join(errors))
