from __future__ import annotations

import itertools
from collections.abc import Iterable

from eta_incerto.uncertainty.spec import QuantilePoint


def validate_quantiles(
    quantiles: list[QuantilePoint],
    *,
    distribution_type: str | None = None,
) -> None:
    """
    Validate a list of quantiles for mathematical consistency.

    This function performs only validation.
    It does NOT infer parameters or construct distributions.

    Params
        - quantiles:
            List of QuantilePoint objects defining (p, x) pairs.

        - distribution_type:
            Optional distribution family name.
            If provided, basic support constraints are validated
            (e.g. positivity for lognormal-like families).

    Raises
        - ValueError:
            If any validation rule is violated.
    """

    if len(quantiles) < 2:
        raise ValueError("At least two quantiles are required for quantile-based parameterization.")

    # Check probability domain
    for q in quantiles:
        if not 0.0 < q.p < 1.0:
            raise ValueError(f"Invalid quantile probability p={q.p}. Quantile probabilities must satisfy 0 < p < 1.")

    # Sort quantiles by probability
    qs = sorted(quantiles, key=lambda q: q.p)

    # Check monotonicity and duplicates
    for q_prev, q_next in itertools.pairwise(qs):
        # Same probability level
        if q_prev.p == q_next.p:
            if q_prev.x != q_next.x:
                raise ValueError(
                    f"Inconsistent quantiles: duplicate probability p={q_prev.p} "
                    f"with different values ({q_prev.x} vs {q_next.x})."
                )
        # Increasing probability must imply increasing value
        elif q_next.x <= q_prev.x:
            raise ValueError(
                "Quantile monotonicity violated: "
                f"p={q_next.p} has x={q_next.x}, "
                f"which is not strictly greater than x={q_prev.x} "
                f"at p={q_prev.p}."
            )

    # Type-specific basic support checks
    if distribution_type is not None:
        _validate_type_support(qs, distribution_type)


def _validate_type_support(
    quantiles: Iterable[QuantilePoint],
    distribution_type: str,
) -> None:
    """
    Validate basic support constraints implied by the distribution type.

    This is a coarse validation layer.
    Detailed feasibility is handled during parameterization.
    """

    distribution_type_norm = distribution_type.lower()

    # Types with strictly positive support.
    # If a new distribution type is added to the framework and its support
    # is strictly positive (x > 0), it MUST be listed here to enforce the
    # corresponding quantile validation at this stage.
    positive_support_types = {"lognormal", "gamma", "inverse_gamma", "weibull"}

    if distribution_type_norm in positive_support_types:
        for q in quantiles:
            if q.x <= 0:
                raise ValueError(
                    f"Invalid quantile value x={q.x} for distribution '{distribution_type}'. "
                    "All quantile values must be strictly positive."
                )
