from __future__ import annotations

from pydantic import BaseModel, model_validator

from eta_incerto.config.config_uncertainty import ParameterUncertaintyConfig


class QuantilePoint(BaseModel):
    """
    Internal, normalized representation of a single quantile (p, x).

    Role in the architecture:
    - This is NOT a user-facing object.
    - It represents the minimal information required by the uncertainty core.

    Guarantees at this stage:
    - Structural validity only (p and x exist and are floats).
    - No mathematical assumptions are enforced here
      (e.g. 0 < p < 1, monotonicity, support constraints).

    Mathematical validation is intentionally deferred to:
      - uncertainty/validation
      - uncertainty/parameterization
    """

    p: float  # Probability level (e.g. p = 0.5 for the median)
    x: float  # Value corresponding to that probability (quantile value)


class ParameterUncertaintySpec(BaseModel):
    """
    Normalized, framework-internal uncertainty specification for a SINGLE model parameter.

    This object is the contract between:
      - the configuration layer (flexible, user-facing)
      - the uncertainty core (strict, deterministic)

    Its main responsibility is to enforce semantic consistency before any
    mathematical processing happens.

    Core invariant enforced here:
      Exactly ONE uncertainty definition must be provided per parameter:
        - params -> direct parameterization of the distribution
        - quantiles -> indirect parameterization (parameters will be derived)

    Allowing both at the same time would introduce ambiguity and break
    reproducibility guarantees.
    """

    type: str
    params: dict[str, float] | None = None
    quantiles: list[QuantilePoint] | None = None
    name: str
    units: str | None = None
    notes: str | None = None

    # Hard consistency validation (framework-level)
    @model_validator(mode="after")
    def check_exclusive_definition(self):
        """
        Enforce the XOR rule between params and quantiles.

        Valid cases:
          - params is set, quantiles is None
          - quantiles is set, params is None

        Invalid cases:
          - both are None -> uncertainty is underspecified
          - both are set -> ambiguity between direct and indirect definitions

        This validation is performed here (and not in config) to ensure that
        all downstream components operate on an unambiguous uncertainty model.
        """
        # (quantiles is None) == (params is None) is True in two cases:
        # 1) both are None
        # 2) both are not None
        if (self.quantiles is None) == (self.params is None):
            raise ValueError("Exactly one of params or quantiles must be provided for an uncertainty specification.")
        return self

    # Factory method: config → internal spec
    @classmethod
    def from_config(cls, config: ParameterUncertaintyConfig) -> ParameterUncertaintySpec:
        """
        Create a normalized internal uncertainty specification from a
        user-facing configuration object.

        Responsibilities of this method:
        - Translate config-layer objects into strict internal representations.
        - Preserve user intent while enforcing framework invariants.
        - Perform NO mathematical validation.

        Mathematical correctness (quantile feasibility, monotonicity, etc.)
        is handled in later stages of the uncertainty pipeline.
        """

        # Normalize quantiles if provided in the config
        quantiles: list[QuantilePoint] | None = None
        if config.quantiles is not None:
            quantiles = [QuantilePoint(p=q.p, x=q.x) for q in config.quantiles]

        # Instantiate the internal spec.
        # The XOR constraint is enforced automatically by validators.
        return cls(
            type=config.type,
            name=config.name,
            params=config.params,
            quantiles=quantiles,
            units=config.units,
            notes=config.notes,
        )
