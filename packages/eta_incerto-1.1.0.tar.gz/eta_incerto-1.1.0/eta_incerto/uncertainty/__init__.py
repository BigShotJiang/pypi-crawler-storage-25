"""Uncertainty module: expert quantiles to distribution parameters for antifragile optimization."""

from __future__ import annotations

from eta_incerto.uncertainty.chaospy_factory import build_chaospy_distribution
from eta_incerto.uncertainty.distribution_builder import DistributionSpec, build_distribution_spec
from eta_incerto.uncertainty.parameterization import ParameterizationResult, parameterize_from_quantiles
from eta_incerto.uncertainty.pipeline import (
    build_uncertainty_joint_distribution,
    iter_marginal_curves_from_parameter_configs,
)
from eta_incerto.uncertainty.quantiles import validate_quantiles
from eta_incerto.uncertainty.spec import ParameterUncertaintySpec, QuantilePoint

__all__ = [
    "DistributionSpec",
    "ParameterUncertaintySpec",
    "ParameterizationResult",
    "QuantilePoint",
    "build_chaospy_distribution",
    "build_distribution_spec",
    "build_uncertainty_joint_distribution",
    "iter_marginal_curves_from_parameter_configs",
    "parameterize_from_quantiles",
    "validate_quantiles",
]
