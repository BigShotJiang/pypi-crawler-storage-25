from __future__ import annotations

import chaospy as cp

from eta_incerto.uncertainty.distribution_builder import DistributionSpec


def _build_inverse_gamma(params: dict[str, float]) -> cp.Distribution:
    base = cp.Gamma(params["shape"], 1.0 / params["scale"])
    return 1.0 / base


def _build_scaled_beta(params: dict[str, float]) -> cp.Distribution:
    return cp.Beta(
        params["alpha"],
        params["beta"],
        lower=params["lower"],
        upper=params["upper"],
    )


def _build_truncnorm(params: dict[str, float]) -> cp.Distribution:
    return cp.TruncNormal(
        lower=params["lower"],
        upper=params["upper"],
        mu=params["mu"],
        sigma=params["sigma"],
    )


def _build_trunc_gaussian_mixture(params: dict[str, float]) -> cp.Distribution:
    base = cp.GaussianMixture(
        means=[params["mu1"], params["mu2"]],
        covariances=[params["sigma1"] ** 2, params["sigma2"] ** 2],
        weights=[params["w1"], 1.0 - params["w1"]],
    )
    return cp.Trunc(base, lower=params["lower"], upper=params["upper"])


_DIST_BUILDERS: dict[str, callable] = {
    "normal": lambda p: cp.Normal(p["mu"], p["sigma"]),
    "cauchy": lambda p: cp.Cauchy(p["mu"], p["sigma"]),
    # Chaospy: mu, sigma of underlying normal
    "lognormal": lambda p: cp.LogNormal(p["mu"], p["sigma"]),
    "gamma": lambda p: cp.Gamma(p["shape"], p["scale"]),
    "weibull": lambda p: cp.Weibull(p["shape"], p["scale"]),
    "inverse_gamma": _build_inverse_gamma,
    "scaled_beta": _build_scaled_beta,
    "truncnorm": _build_truncnorm,
    "trunc_gaussian_mixture": _build_trunc_gaussian_mixture,
}


def build_chaospy_distribution(spec: DistributionSpec) -> cp.Distribution:
    """
    Build a Chaospy distribution from a backend-agnostic DistributionSpec.

    This function assumes:
        - spec has already been validated
        - parameters are mathematically consistent

    This is a thin translation layer with no business logic.
    """

    try:
        builder = _DIST_BUILDERS[spec.distribution_type]
    except KeyError as exc:
        raise ValueError(f"Unsupported distribution type '{spec.distribution_type}' for Chaospy backend.") from exc
    return builder(spec.params)
