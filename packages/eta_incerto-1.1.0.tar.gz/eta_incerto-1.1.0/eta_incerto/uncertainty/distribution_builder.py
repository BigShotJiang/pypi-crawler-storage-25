from __future__ import annotations

from pydantic import BaseModel

# ============================================================
# Public specification model
# ============================================================


class DistributionSpec(BaseModel):
    """
    Backend-agnostic specification of a probability distribution.
    """

    distribution_type: str
    params: dict[str, float]


# ============================================================
# Public builder
# ============================================================


def build_distribution_spec(
    distribution_type: str,
    params: dict[str, float],
) -> DistributionSpec:
    """
    Build a validated, backend-agnostic distribution specification.

    This function assumes parameters were obtained through a
    deterministic and validated process (e.g. quantile-based
    parameterization).

    Responsibilities:
        - normalize distribution type
        - validate parameter names and basic constraints
        - return a stable, backend-agnostic spec

    It does NOT:
        - infer parameters
        - choose distributions
        - apply bounds or truncation
    """

    distribution_type_norm = distribution_type.lower()

    _validate_params(distribution_type_norm, params)

    return DistributionSpec(
        distribution_type=distribution_type_norm,
        params=params,
    )


# ============================================================
# Internal validation
# ============================================================

_DISTRIBUTION_PARAM_SCHEMA = {
    # Location-Scale family
    "normal": {
        "required": {"mu", "sigma"},
        "positive": {"sigma"},
    },
    "cauchy": {
        "required": {"mu", "sigma"},
        "positive": {"sigma"},
    },
    # Log-Location-Scale family
    "lognormal": {
        "required": {"mu", "sigma"},
        "positive": {"sigma"},
    },
    # Shape-Scale family
    "gamma": {
        "required": {"shape", "scale"},
        "positive": {"shape", "scale"},
    },
    "weibull": {
        "required": {"shape", "scale"},
        "positive": {"shape", "scale"},
    },
    # Inverse Shape-Scale family
    "inverse_gamma": {
        "required": {"shape", "scale"},
        "positive": {"shape", "scale"},
    },
    # Bounded, skew-capable distributions
    "scaled_beta": {
        "required": {"alpha", "beta", "lower", "upper"},
        "positive": {"alpha", "beta"},
    },
    "truncnorm": {
        "required": {"mu", "sigma", "lower", "upper"},
        "positive": {"sigma"},
    },
    "trunc_gaussian_mixture": {
        "required": {"mu1", "sigma1", "mu2", "sigma2", "w1", "lower", "upper"},
        "positive": {"sigma1", "sigma2"},
    },
}


def _validate_params(distribution_type: str, params: dict[str, float]) -> None:
    """
    Validate parameter names and basic constraints per distribution type.

    This validation is intentionally shallow:
        - parameter presence
        - positivity where required

    Detailed mathematical correctness is guaranteed upstream
    by the parameterization step.
    """

    try:
        schema = _DISTRIBUTION_PARAM_SCHEMA[distribution_type]
    except KeyError as exc:
        raise ValueError(
            f"Unsupported distribution type '{distribution_type}'. "
            f"Supported types: {sorted(_DISTRIBUTION_PARAM_SCHEMA)}"
        ) from exc

    allowed = schema["required"]

    _no_extra(params, allowed, distribution_type=distribution_type)
    _require(params, allowed)
    _positive(params, schema.get("positive", set()))
    _validate_bounds_if_present(params, distribution_type=distribution_type)
    if distribution_type == "trunc_gaussian_mixture":
        _validate_mixture_weights(params)


def _no_extra(params: dict[str, float], keys: set[str], *, distribution_type: str) -> None:
    extra = params.keys() - keys
    if extra:
        raise ValueError(
            f"Unexpected parameter(s): {sorted(extra)}. Allowed parameters for '{distribution_type}': {sorted(keys)}"
        )


def _require(params: dict[str, float], keys: set[str]) -> None:
    missing = keys - params.keys()
    if missing:
        raise ValueError(f"Missing parameter(s): {sorted(missing)}. Provided: {sorted(params)}")


def _positive(params: dict[str, float], keys: set[str]) -> None:
    for k in keys:
        if params[k] <= 0:
            raise ValueError(f"Parameter '{k}' must be strictly positive (got {params[k]}).")


def _validate_bounds_if_present(params: dict[str, float], *, distribution_type: str) -> None:
    if "lower" in params and "upper" in params and not (params["lower"] < params["upper"]):
        raise ValueError(
            "Expected 'lower' < 'upper' "
            f"for distribution '{distribution_type}' (got lower={params['lower']}, upper={params['upper']})."
        )


def _validate_mixture_weights(params: dict[str, float]) -> None:
    w1 = params["w1"]
    if not 0.0 < w1 < 1.0:
        raise ValueError(f"Parameter 'w1' must satisfy 0 < w1 < 1 (got {w1}).")
