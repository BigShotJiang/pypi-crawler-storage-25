"""Serialize stochastic marginal laws to HDF5-friendly numeric curves (PDF/CDF on a grid).

Cook / quantile parameterization: use :func:`parameterize_from_quantiles` to obtain
``distribution_type`` and ``params``, then :func:`build_marginal_chaospy` and
:func:`grid_pdf_cdf` for the curves stored in HDF5.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import chaospy as cp
import numpy as np

from eta_incerto.uncertainty.chaospy_factory import build_chaospy_distribution
from eta_incerto.uncertainty.distribution_builder import build_distribution_spec
from eta_incerto.uncertainty.spec import QuantilePoint


def build_marginal_chaospy(distribution_type: str, params: dict[str, Any]) -> cp.Distribution:
    """
    Build a one-dimensional Chaospy distribution from type + parameter dict.

    Supports Cook-backed families via :mod:`eta_incerto.uncertainty.chaospy_factory`
    plus common antifragile JSON families (Uniform, Beta / scaled Beta).
    """
    t = str(distribution_type).lower().strip()
    p = params

    if t in ("normal", "cauchy", "lognormal", "gamma", "weibull", "inverse_gamma"):
        spec = build_distribution_spec(t, {k: float(v) for k, v in p.items()})
        return build_chaospy_distribution(spec)

    if t == "uniform":
        lo, hi = float(p["lower"]), float(p["upper"])
        return cp.Uniform(lo, hi)

    if t in ("beta", "scaledbeta", "scaled_beta"):
        a, b = float(p["a"]), float(p["b"])
        lower = float(p.get("lower", 0.0))
        upper = float(p.get("upper", 1.0))
        return cp.Beta(a, b, lower=lower, upper=upper)

    raise ValueError(f"Unsupported marginal distribution_type {distribution_type!r}")


def chaospy_marginal_from_cook(
    distribution_type: str,
    quantiles: list[QuantilePoint],
) -> tuple[cp.Distribution, str, dict[str, float], str]:
    """Cook quantiles -> Chaospy marginal, method label, resolved params, normalized type."""
    from eta_incerto.uncertainty.parameterization import parameterize_from_quantiles

    res = parameterize_from_quantiles(distribution_type, quantiles)
    dist = build_marginal_chaospy(res.distribution_type, res.params)
    return dist, str(res.method), dict(res.params), str(res.distribution_type)


def grid_pdf_cdf(
    dist: cp.Distribution,
    *,
    n_grid: int,
    q_lo: float = 0.001,
    q_hi: float = 0.999,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Inverse-CDF grid in (q_lo, q_hi) then PDF and CDF at grid points."""
    n_grid = max(8, int(n_grid))
    q_lo = float(min(max(q_lo, 1e-6), 0.5))
    q_hi = float(max(min(q_hi, 1.0 - 1e-6), 0.5))
    if q_hi <= q_lo:
        q_lo, q_hi = 0.001, 0.999
    q = np.linspace(q_lo, q_hi, n_grid)
    x = np.asarray(dist.inv(q), dtype=float).ravel()
    pdf = np.asarray(dist.pdf(x), dtype=float).ravel()
    cdf = np.asarray(dist.cdf(x), dtype=float).ravel()
    return x, pdf, cdf


def iter_stochastic_marginals(distribution_data: Any) -> Iterator[tuple[str, str, cp.Distribution]]:
    """
    Yield ``(variable_name, mode, marginal_dist)`` in stochastic dimension order.

    Recognizes:
      - objects with ``_to_generic()`` (e.g. variant_one distribution data),
      - objects with ``variables`` + ``variable_names()`` (GenericDistributionData-like),
      - objects with ``_build_dist`` + ``variable_names()`` (e.g. variant_two),
      - otherwise ``build_joint()`` with ``joint[i]`` marginals.
    """
    if hasattr(distribution_data, "_to_generic"):
        gen = distribution_data._to_generic()
        for n in gen.variable_names():
            vs = gen.variables[n]
            name = vs.name or n
            yield str(name), str(vs.mode), vs.distribution.build()
        return

    variables = getattr(distribution_data, "variables", None)
    vnames_fn = getattr(distribution_data, "variable_names", None)
    if variables is not None and callable(vnames_fn):
        names = list(vnames_fn())
        for n in names:
            vs = variables[n]
            name = getattr(vs, "name", None) or n
            mode = str(getattr(vs, "mode", "absolute"))
            yield str(name), mode, vs.distribution.build()
        return

    build_one = getattr(distribution_data, "_build_dist", None)
    if callable(build_one) and callable(vnames_fn):
        names = list(vnames_fn())
        for n in names:
            raw = getattr(distribution_data, n, None)
            if raw is None:
                continue
            mode = "absolute"
            mode_attr = f"mode_{n}"
            if hasattr(distribution_data, mode_attr):
                mode = str(getattr(distribution_data, mode_attr))
            yield str(n), mode, build_one(raw, n)
        return

    joint = distribution_data.build_joint()
    d = len(joint)
    for i in range(d):
        yield f"xi_{i}", "unknown", joint[i]


def _append_histogram(
    rec: dict[str, Any],
    xi_row: np.ndarray | None,
    *,
    n_hist_samples: int | None,
    hist_bins: int,
) -> None:
    if xi_row is None or not n_hist_samples or n_hist_samples <= 0:
        return
    arr = np.asarray(xi_row, dtype=float).ravel()
    counts, edges = np.histogram(arr, bins=int(hist_bins))
    width = np.diff(edges)
    density = counts.astype(float) / (max(arr.size, 1) * np.maximum(width, 1e-15))
    rec["hist_sample_space"] = "feasible"
    rec["hist_edges"] = edges.astype(float)
    rec["hist_density"] = density.astype(float)


def marginal_record_from_chaospy(
    variable_name: str,
    mode: str,
    cpd: cp.Distribution,
    *,
    distribution_type: str,
    parameterization: str,
    params_json: str,
    n_grid: int,
    n_hist_samples: int | None,
    hist_bins: int,
    xi_row: np.ndarray | None,
) -> dict[str, Any]:
    x, pdf, cdf = grid_pdf_cdf(cpd, n_grid=n_grid)
    rec: dict[str, Any] = {
        "variable_name": variable_name,
        "mode": mode,
        "distribution_type": distribution_type,
        "parameterization": parameterization,
        "params_json": params_json,
        "grid_x": x,
        "pdf": pdf,
        "cdf": cdf,
    }
    _append_histogram(rec, xi_row, n_hist_samples=n_hist_samples, hist_bins=hist_bins)
    return rec


def marginal_record_from_variable_spec(
    variable_name: str,
    mode: str,
    vs: Any,
    *,
    n_grid: int,
    n_hist_samples: int | None,
    hist_bins: int,
    xi_row: np.ndarray | None,
) -> dict[str, Any]:
    """VariableSpec-like: ``vs.distribution`` has ``type`` and ``params`` (JSON-style)."""
    dist = getattr(vs, "distribution", None)
    if dist is None:
        raise ValueError("Variable spec has no distribution")
    dtype = str(dist.type).strip()
    params = dict(dist.params or {})
    cpd = dist.build()
    params_json = json.dumps({k: float(v) if isinstance(v, int | float) else v for k, v in params.items()})
    return marginal_record_from_chaospy(
        variable_name,
        mode,
        cpd,
        distribution_type=dtype.lower(),
        parameterization="direct_params",
        params_json=params_json,
        n_grid=n_grid,
        n_hist_samples=n_hist_samples,
        hist_bins=hist_bins,
        xi_row=xi_row,
    )


def marginal_record_from_cook_quantiles(
    variable_name: str,
    mode: str,
    distribution_type: str,
    quantiles: list[QuantilePoint],
    *,
    n_grid: int,
    n_hist_samples: int | None,
    hist_bins: int,
    xi_row: np.ndarray | None,
) -> dict[str, Any]:
    """Public entry for Cook-parameterized marginals."""
    cpd, method, params, dtype_norm = chaospy_marginal_from_cook(distribution_type, quantiles)
    payload = {
        "quantiles": [{"p": q.p, "x": q.x} for q in quantiles],
        **{k: float(v) for k, v in params.items()},
    }
    return marginal_record_from_chaospy(
        variable_name,
        mode,
        cpd,
        distribution_type=dtype_norm,
        parameterization=f"cook_quantiles:{method}",
        params_json=json.dumps(payload),
        n_grid=n_grid,
        n_hist_samples=n_hist_samples,
        hist_bins=hist_bins,
        xi_row=xi_row,
    )
