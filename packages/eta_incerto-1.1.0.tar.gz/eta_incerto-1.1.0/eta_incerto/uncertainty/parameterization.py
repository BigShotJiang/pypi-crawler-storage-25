"""
Quantile-based parameterization of probability distributions:

This module implements mathematically grounded algorithms for deriving
distribution parameters from elicited quantiles. It is intended for
probabilistic modeling workflows where quantiles are more natural,
robust, and interpretable inputs than moments such as means or variances.

The implementation combines:
- exact analytic derivations where mathematically available,
- and provably well-posed numerical root-finding methods where analytic
  inversion is impossible (in this case for the shape parameter of the
  gamma distribution).


Problem setting:

Given a parametric family of distributions with two parameters,
and two elicited quantile conditions

    P(X < x₁) = p₁
    P(X < x₂) = p₂

with 0 < p₁ < p₂ < 1 and x₁ < x₂, the goal is to determine parameters
such that both constraints are satisfied.

For all families implemented here, when a solution exists it is:
- unique,
- deterministic,
- and exact for two quantiles.


Mathematical foundations:

The theoretical basis for quantile-based parameterization is primarily
drawn from:

    John D. Cook (2010),
    "Determining distribution parameters from quantiles".

This reference establishes:
- closed-form solutions for location-scale families,
- analytic derivations for the Weibull distribution,
- existence and uniqueness of the Gamma shape parameter given two
  quantiles satisfying x₂ / x₁ > 1 for p₂ > p₁ and an analytic derivation
  of the scale parameter (that works also for the inverse gamma).

However, Cook explicitly notes that the Gamma shape parameter does not
admit a closed-form expression and must be obtained numerically via
bisection method.


Numerical root finding for Gamma shape:

For the Gamma distribution, the quantile ratio equation

    log(Q(p₂; a)) - log(Q(p₁; a)) = log(x₂ / x₁)

defines a scalar, one-dimensional root-finding problem in the shape
parameter 'a'.

Key theoretical properties:
- The left-hand side is a continuous and strictly decreasing function
  of a (Cook, 2010), guaranteeing:
    • existence of a solution,
    • uniqueness of the solution,
    • suitability for bracketing methods.

The numerical solution strategy follows classical root-finding theory as
described in:

    • "Numerical Recipes: The Art of Scientific Computing", 3rd Edition,
      Chapter 9 (Root Finding and Nonlinear Sets of Equations), Sections
      9.1 (Bracketing and Bisection) and 9.2 (Van Wijngaarden-Dekker-Brent
      Method).

    • P. Sam Johnson (2020), "Root Finding Problems", Sections on
      bracketing methods (Bisection Method) and convergence guarantees.

Specifically:
- A bracketing interval [lo, hi] is constructed such that the root is
  guaranteed to lie within the interval.
- While Cook (2010) mentions bisection explicitly, any bracketing method is
  admissible. In this implementation, Brent's method is used for improved
  convergence while preserving guarantees.
- Bracketing ensures robustness and avoids dependence on initial guesses,
  in accordance with standard numerical analysis practice.


Role of SciPy:

SciPy is used strictly as a computational backend:

- `scipy.stats` provides numerically stable and well-tested implementations
  of inverse CDFs (PPF) for all supported distributions.
- `scipy.optimize.root_scalar` is used with a bracketing-based method
  (Brent), implementing the classical algorithms described in Numerical
  Recipes.

SciPy does not define the mathematical structure of the problem, it is
used only to evaluate functions and perform root finding once existence
and uniqueness are theoretically guaranteed.



Algorithmic guarantees:

• Determinism:
    Identical inputs always produce identical outputs.

• Exactness:
    For two quantiles, all supported families satisfy the constraints
    exactly (up to numerical tolerance for root finding).

• Robustness:
    Bracketing-based root finding guarantees convergence and numerical
    stability under the stated existence conditions.

• Extensibility:
    New distributions should be added by mapping them to an existing
    family whenever possible and implementing the distribution CDF and
    PPF via scipy.


Design philosophy

This module deliberately avoids generic optimization-based fitting
(e.g. least-squares or likelihood maximization). Instead, it relies on:

    - analytic derivations where mathematically available,
    - monotone, bracketed root finding where analytic inversion is impossible.

The resulting parameterizations are interpretable, reproducible,
and mathematically justified.
"""

from __future__ import annotations

import math

from pydantic import BaseModel
from scipy.optimize import root_scalar
from scipy.stats import (
    cauchy as cauchy_dist,
    gamma as gamma_dist,
    norm as norm_dist,
    weibull_min as weibull_dist,
)

from eta_incerto.uncertainty.quantiles import validate_quantiles
from eta_incerto.uncertainty.spec import QuantilePoint


class ParameterizationResult(BaseModel):
    """
    Result of a quantile-based distribution parameterization.

    This object is intended for:
    - reproducibility
    - testing
    - logging / inspection
    """

    distribution_type: str
    params: dict[str, float]
    quantiles: list[QuantilePoint]
    method: str


# ============================================================
# Public API
# ============================================================


def parameterize_from_quantiles(
    distribution_type: str,
    quantiles: list[QuantilePoint],
) -> ParameterizationResult:
    """
    Derive distribution parameters from elicited quantiles.

    The parameterization strategy is selected automatically
    based on the distribution family.
    """

    distribution_type_norm = distribution_type.lower()

    # 1. Validation (structural + support)
    validate_quantiles(
        quantiles,
        distribution_type=distribution_type_norm,
    )

    # 2. Select family-specific parameterizer
    try:
        parameterizer = _PARAMETERIZERS[distribution_type_norm]
    except KeyError as exc:
        raise ValueError(
            f"Unsupported distribution type '{distribution_type}'. Supported types: {sorted(_PARAMETERIZERS)}"
        ) from exc

    # 3. Parameterize (method chosen internally)
    params, method_used = parameterizer(
        quantiles,
        distribution_type=distribution_type_norm,
    )

    # 4. Structured result
    return ParameterizationResult(
        distribution_type=distribution_type_norm,
        params=params,
        quantiles=quantiles,
        method=method_used,  # informational
    )


# ============================================================
# Family-specific parameterizers
# ============================================================


def _parameterize_location_scale(
    quantiles: list[QuantilePoint],
    *,
    distribution_type: str,
) -> tuple[dict[str, float], str]:
    """Parameterization for location-scale distributions (normal, cauchy)."""
    qs = sorted(quantiles, key=lambda q: q.p)
    q1, q2 = qs[0], qs[-1]

    if distribution_type == "normal":
        z1 = norm_dist.ppf(q1.p)
        z2 = norm_dist.ppf(q2.p)
    elif distribution_type == "cauchy":
        z1 = cauchy_dist.ppf(q1.p)
        z2 = cauchy_dist.ppf(q2.p)
    else:
        raise ValueError(f"Unsupported location-scale distribution '{distribution_type}'.")

    if z1 == z2:
        raise ValueError("Degenerate quantiles: identical standardized values.")

    sigma = (q2.x - q1.x) / (z2 - z1)
    if sigma <= 0:
        raise ValueError(
            "Derived scale parameter is non-positive. Quantiles may be inconsistent with a location-scale family."
        )
    mu = q1.x - sigma * z1

    return {"mu": float(mu), "sigma": float(sigma)}, "analytic"


def _parameterize_log_location_scale(
    quantiles: list[QuantilePoint],
    *,
    distribution_type: str,
) -> tuple[dict[str, float], str]:
    """Parameterization for log-location-scale distributions (lognormal)."""
    if distribution_type != "lognormal":
        raise ValueError(f"Unsupported log-location-scale distribution '{distribution_type}'.")
    log_quantiles = [QuantilePoint(p=q.p, x=math.log(q.x)) for q in quantiles]
    params, _ = _parameterize_location_scale(log_quantiles, distribution_type="normal")
    return params, "analytic"


def _parameterize_shape_scale(
    quantiles: list[QuantilePoint],
    *,
    distribution_type: str,
) -> tuple[dict[str, float], str]:
    """Parameterization for shape-scale distributions (gamma, weibull)."""
    qs = sorted(quantiles, key=lambda q: q.p)
    q1, q2 = qs[0], qs[-1]

    if distribution_type == "weibull":
        shape = (math.log(-math.log(1.0 - q2.p)) - math.log(-math.log(1.0 - q1.p))) / (math.log(q2.x) - math.log(q1.x))
        if shape <= 0:
            raise ValueError("Derived Weibull shape parameter is non-positive.")
        scale = q1.x / weibull_dist.ppf(q1.p, c=shape, scale=1.0)
        return {"shape": float(shape), "scale": float(scale)}, "analytic"

    if distribution_type == "gamma":
        r = q2.x / q1.x
        if r <= 1.0:
            raise ValueError("No Gamma solution: requires x2/x1 > 1 for p2 > p1.")
        log_r = math.log(r)

        def h(a: float) -> float:
            try:
                q1a = gamma_dist.ppf(q1.p, a=a, scale=1.0)
                q2a = gamma_dist.ppf(q2.p, a=a, scale=1.0)
                if q1a <= 0 or q2a <= 0:
                    return math.inf
                return math.log(q2a) - math.log(q1a) - log_r
            except Exception:
                return math.inf

        hi = 1.0
        for _ in range(80):
            val = h(hi)
            if math.isfinite(val) and val < 0.0:
                break
            hi *= 2.0
        else:
            raise ValueError(
                "Gamma solution should exist (x2/x1 > 1) "
                "but could not find upper bracket. Likely numerical PPF instability."
            )
        lo = 1e-8
        for _ in range(80):
            val = h(lo)
            if not math.isfinite(val) or val > 0.0:
                break
            lo *= 0.5
        else:
            raise ValueError(
                "Gamma solution should exist (x2/x1 > 1) "
                "but could not find lower bracket. Likely numerical PPF instability."
            )
        sol = root_scalar(h, bracket=(lo, hi), method="brentq")
        if not sol.converged:
            raise ValueError("Gamma shape root finding did not converge.")
        shape = float(sol.root)
        scale = q1.x / gamma_dist.ppf(q1.p, a=shape, scale=1.0)
        return {"shape": float(shape), "scale": float(scale)}, "numeric"

    raise ValueError(f"Unsupported shape-scale distribution '{distribution_type}'.")


def _parameterize_inverse_shape_scale(
    quantiles: list[QuantilePoint],
    *,
    distribution_type: str,
) -> tuple[dict[str, float], str]:
    """Parameterization for inverse shape-scale distributions (inverse_gamma)."""
    if distribution_type != "inverse_gamma":
        raise ValueError(f"Unsupported inverse shape-scale distribution '{distribution_type}'.")
    inv_quantiles = sorted(
        (QuantilePoint(p=1.0 - q.p, x=1.0 / q.x) for q in quantiles),
        key=lambda q: q.p,
    )
    gamma_params, _ = _parameterize_shape_scale(inv_quantiles, distribution_type="gamma")
    alpha = gamma_params["shape"]
    theta = gamma_params["scale"]
    beta = 1.0 / theta
    if alpha <= 0 or beta <= 0:
        raise ValueError("Invalid inverse shape-scale parameters derived from quantiles.")
    return {"shape": float(alpha), "scale": float(beta)}, "numeric"


_PARAMETERIZERS = {
    "normal": _parameterize_location_scale,
    "cauchy": _parameterize_location_scale,
    "lognormal": _parameterize_log_location_scale,
    "gamma": _parameterize_shape_scale,
    "weibull": _parameterize_shape_scale,
    "inverse_gamma": _parameterize_inverse_shape_scale,
}
