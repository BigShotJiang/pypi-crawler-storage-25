import polars as pl

lf = pl.scan_parquet("../pathways.parquet")

"""
Filter
"""

# Only keep Akutordning
lf = lf.filter((pl.col("referralReason").first() == "Akutordning").over(pl.col("c:id")))

# remove cases that has events that could not map to specialties based on SOR
lf = lf.filter(~pl.col("ansSpec").is_null().any().over("c:id"))

"""
Add meta activities
"""

# Define the 1-year mark from the first event in the trace
target_time = pl.col("startTime").first().over("c:id") + pl.duration(days=365)
# Add Death activities
lf = (
    lf.with_columns(
        replicate=pl.when(pl.col("endReason") == "Afsluttet ved patientens død")
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Dødsfald"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop("replicate")
)

lf = lf.with_columns(
    pl.col("ansSpec").eq("Dødsfald").any().over("c:id").alias("c:dies")
)

# No more courses within a year
lf = lf.with_columns(
    shorter_than_1_year=(
        pl.col("startTime").last() - pl.col("startTime").first() < pl.duration(days=365)
    ).over("c:id"),
    longer_than_1_year=(
        pl.col("startTime").last() - pl.col("startTime").first()
        >= pl.duration(days=365)
    ).over("c:id"),
    is_expired=(
        pl.col("startTime") - pl.col("startTime").first().over("c:id")
        > pl.duration(days=365)
    ),
)

lf = (
    lf.with_columns(
        # Identify the last row in each trace to trigger the explosion
        replicate=pl.when(
            (pl.col("startTime") == pl.col("startTime").last()).over("c:id")
            & pl.col("shorter_than_1_year")
            & ~pl.col("c:dies")
        )
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Afsluttet"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop(["replicate"])
)

# Add the "Fortsætter" meta-activity for traces that were truncated
lf = lf.filter(~pl.col("is_expired"))
lf = (
    lf.with_columns(
        replicate=pl.when(
            ((pl.col("startTime") == pl.col("startTime").last()).over("c:id"))
            & pl.col("longer_than_1_year")
            & ~(pl.col("c:dies") & pl.col("shorter_than_1_year"))
        )
        .then(pl.lit([1, 2]))
        .otherwise(pl.lit([1]))
    )
    .explode("replicate")
    .with_columns(
        ansSpec=pl.when(pl.col("replicate") == 2)
        .then(pl.lit("Fortsætter"))
        .otherwise(pl.col("ansSpec")),
        startTime=pl.when(pl.col("replicate") == 2)
        .then(target_time)
        .otherwise(pl.col("startTime")),
        endTime=pl.when(pl.col("replicate") == 2)
        .then(target_time + pl.duration(seconds=1))
        .otherwise(pl.col("endTime")),
    )
    .drop(["replicate", "longer_than_1_year", "shorter_than_1_year", "is_expired", "target_time"])
)
