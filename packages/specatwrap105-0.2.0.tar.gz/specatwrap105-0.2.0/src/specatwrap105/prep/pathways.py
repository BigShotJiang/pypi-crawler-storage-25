import polars as pl

from .base_filter import BaseFilter


class PathwaysFilter(BaseFilter):
    CASE_ATTR = {
        k: f"c:{v}"
        for k, v in {
            "PNR": "PNR",
            "DW_EK_BORGER": "patientId",
            "DW_EK_HELBREDSFORLOEB": "id",
            "HELBREDSFORL_STARTTIDSPUNKT": "pathStartTime",
            "HELBREDSFORL_SLUTTIDSPUNKT": "pathEndTime",
        }.items()
    }

    EVENT_ATTR = {
        "DW_EK_FORLOEB": "id",
        "FORL_AFSLUT_MAADE_TEKST": "endReason",
        "FORL_HENV_AARSAG": "diagnosis",
        "FORL_HENV_MAADE_TEKST": "referralReason",
        "FORL_LABEL": "label",
        "FORL_LABEL_TEKST": "labelText",
        "FORL_ANS": "ans",
        "FORL_ANS_TEKST": "ansText",
        "FORL_ANS_INST": "ansInst",
        "FORL_ANS_SPEC": "ansSpec",
        "FORL_ANS_INST_TEKST": "ansInstText",
        "FORL_STARTTIDSPUNKT": "startTime",
        "FORL_SLUTTIDSPUNKT": "endTime",
    }

    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        sor_lf = pl.scan_csv("./sor.csv").select(
            [
                pl.col("SOR-kode").cast(pl.String).alias("SOR_ID"),
                pl.col("Enhedsnavn").cast(pl.String),
                pl.col("Hovedspeciale").cast(pl.String).alias("FORL_ANS_SPEC")
            ]
        )

        for key, name in [
            ("FORL_ANS", "FORL_ANS_TEKST"),
            ("FORL_ANS_INST", "FORL_ANS_INST_TEKST"),
        ]:
            cols_to_select = ["SOR_ID", "Enhedsnavn"]
            if key == "FORL_ANS":
                cols_to_select.append("FORL_ANS_SPEC")
            lf = lf.join(
                sor_lf.rename({"Enhedsnavn": name}),
                left_on=key,
                right_on="SOR_ID",
                how="left",
            )

        return (
            lf.select(list((self.CASE_ATTR | self.EVENT_ATTR).keys()))
            .rename(self.CASE_ATTR | self.EVENT_ATTR)
            .sort(["id", "startTime"], descending=True)
        )
