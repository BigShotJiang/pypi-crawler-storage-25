"""
noonhelpers - Common helper utilities for Python services.

Provides shared helpers for configuration loading, logging setup,
and service bootstrapping.
"""

__version__ = "99.1.0"
__author__ = "Platform Engineering"


def get_version():
    """Return the current package version."""
    return __version__


def configure_logging(level="INFO"):
    """Set up standard logging configuration."""
    import logging
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
