# noonhelpers

Common helper utilities for Python services.

## Installation

```bash
pip install noonhelpers
```

## Usage

```python
from noonhelpers import configure_logging, get_version

configure_logging()
print(get_version())
```

## License

MIT
