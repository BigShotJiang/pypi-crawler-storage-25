"""Consumer-side helper to read data files that the kh-license proxy
encrypted before shipping the wheel.

Usage in a protected package:

    from license_sdk.assets import read_asset, open_asset

    data = read_asset("templates/index.html")          # bytes
    with open_asset("config/schema.yaml") as f:        # BinaryIO
        ...

The helper:
  1. Locates the caller package's dist-info (via the LICENCE.jwt path).
  2. Reads the JWT signature, derives the AES-256-GCM key via HKDF.
  3. Reads the kh_assets_manifest.json + kh_assets.enc blob.
  4. Decrypts only the requested path (lazy, on demand).
  5. Caches decrypted bytes per-process to amortise repeated reads.

If the package was distributed without encryption (no kh_assets.enc),
both functions transparently fall back to reading the file from disk
via importlib.resources — so a producer can activate encryption later
without code changes.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import inspect
import io
import json
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO


_HKDF_SALT = b"kh-license-assets-v1"
_HKDF_INFO = b"aes-256-gcm"
_CACHE_LOCK = threading.Lock()
_BUNDLE_CACHE: dict[str, "_Bundle"] = {}


class AssetError(Exception):
    """Asset cannot be read (missing, tampered, or licence chain broken)."""


@dataclass
class _Bundle:
    manifest: dict
    blob: bytes
    key: bytes
    plaintext_cache: dict[str, bytes]


def _hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: int) -> bytes:
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    n = (length + 31) // 32
    t = b""
    okm = b""
    for i in range(1, n + 1):
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        okm += t
    return okm[:length]


def _derive_key(jwt_token: str) -> bytes:
    parts = jwt_token.split(".")
    if len(parts) != 3:
        raise AssetError("invalid LICENCE.jwt (expected 3 parts)")
    sig_b64 = parts[2].encode()
    pad = b"=" * ((4 - len(sig_b64) % 4) % 4)
    return _hkdf_sha256(base64.urlsafe_b64decode(sig_b64 + pad), _HKDF_SALT, _HKDF_INFO, 32)


def _find_caller_package() -> str:
    """Return the top-level package of the caller (one level up the stack)."""
    frame = inspect.stack()
    for info in frame[1:]:
        module_name = info.frame.f_globals.get("__name__")
        if module_name and not module_name.startswith("license_sdk."):
            return module_name.split(".", 1)[0]
    raise AssetError("could not identify caller package")


def _find_dist_info(package: str) -> Path:
    """Find <package>-<ver>.dist-info/ beside the installed package dir."""
    try:
        import importlib
        mod = importlib.import_module(package)
    except ImportError as exc:
        raise AssetError(f"package '{package}' not importable: {exc}") from exc
    pkg_path = Path(mod.__file__).resolve().parent
    parent = pkg_path.parent
    candidates = sorted(parent.glob(f"{package.replace('-', '_')}-*.dist-info"))
    if not candidates:
        candidates = sorted(parent.glob(f"{package}-*.dist-info"))
    if not candidates:
        raise AssetError(f"no dist-info found for '{package}' in {parent}")
    return candidates[-1]


def _load_bundle(package: str) -> _Bundle:
    with _CACHE_LOCK:
        cached = _BUNDLE_CACHE.get(package)
        if cached is not None:
            return cached

    dist_info = _find_dist_info(package)
    licence_jwt = dist_info / "LICENCE.jwt"
    if not licence_jwt.is_file():
        raise AssetError(f"LICENCE.jwt missing in {dist_info}")
    jwt_token = licence_jwt.read_text().strip()
    key = _derive_key(jwt_token)

    # Encrypted bundle lives at the wheel root (= package parent).
    parent = dist_info.parent
    manifest_path = parent / "kh_assets_manifest.json"
    blob_path = parent / "kh_assets.enc"
    if not manifest_path.is_file() or not blob_path.is_file():
        # Package was not distributed with encryption. Caller falls back
        # to filesystem read. Signal by raising a dedicated class.
        raise _NoEncryption(package)

    manifest = json.loads(manifest_path.read_text())
    blob = blob_path.read_bytes()

    bundle = _Bundle(manifest=manifest, blob=blob, key=key, plaintext_cache={})
    with _CACHE_LOCK:
        _BUNDLE_CACHE[package] = bundle
    return bundle


class _NoEncryption(Exception):
    def __init__(self, package: str):
        self.package = package


def _decrypt_entry(bundle: _Bundle, path: str) -> bytes:
    cached = bundle.plaintext_cache.get(path)
    if cached is not None:
        return cached
    entry = next(
        (e for e in bundle.manifest.get("entries", []) if e.get("path") == path),
        None,
    )
    if entry is None:
        raise AssetError(f"asset not found: {path}")
    offset = entry["offset"]
    length = entry["length"]
    nonce_b64 = entry["nonce"]
    pad = "=" * ((4 - len(nonce_b64) % 4) % 4)
    nonce = base64.urlsafe_b64decode((nonce_b64 + pad).encode())
    ciphertext = bundle.blob[offset : offset + length]

    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    aesgcm = AESGCM(bundle.key)
    try:
        plaintext = aesgcm.decrypt(nonce, ciphertext, path.encode())
    except Exception as exc:  # InvalidTag and friends
        raise AssetError(
            f"decryption failed for '{path}' — check that the LICENCE.jwt "
            f"matches the wheel: {exc}"
        ) from exc
    bundle.plaintext_cache[path] = plaintext
    return plaintext


def _fallback_read_file(package: str, relative_path: str) -> bytes:
    """Read an unencrypted file from the installed package directory."""
    import importlib
    mod = importlib.import_module(package)
    base = Path(mod.__file__).resolve().parent.parent  # wheel root
    target = base / relative_path
    if not target.is_file():
        # Try package-root relative path as a courtesy.
        pkg_dir = Path(mod.__file__).resolve().parent
        target = pkg_dir / relative_path
    if not target.is_file():
        raise AssetError(f"asset not found on disk: {relative_path}")
    return target.read_bytes()


def read_asset(relative_path: str, package: str | None = None) -> bytes:
    """Return the bytes of a data file distributed with a protected package.

    If the wheel was encrypted, decrypts on the fly. If it was not
    encrypted, reads from disk. In both cases the caller sees the same
    plain bytes — the producer can opt into encryption later without
    changing their code.
    """
    pkg = package or _find_caller_package()
    try:
        bundle = _load_bundle(pkg)
    except _NoEncryption:
        return _fallback_read_file(pkg, relative_path)
    return _decrypt_entry(bundle, relative_path)


def open_asset(relative_path: str, package: str | None = None) -> BinaryIO:
    """Return a BytesIO over the (possibly-decrypted) asset bytes.

    Usable in `with` blocks like a normal file object.
    """
    data = read_asset(relative_path, package=package)
    return io.BytesIO(data)
