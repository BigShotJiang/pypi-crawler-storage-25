"""`kh-license` CLI for configuring the SDK.

Commands:
  login      — interactive or --token/--server; writes config + pip.conf
  status     — shows detected token source + active licences
  logout     — removes config + restores pip.conf
  bootstrap  — non-interactive; uses LICENSE_SDK_TOKEN env var; for CI/CD
"""
from __future__ import annotations
import argparse
import getpass
import os
import sys
from pathlib import Path

import httpx

from license_sdk._config import load_runtime_config
from license_sdk._config_paths import user_config_path
from license_sdk._pipconfig import detect_pip_config_path, write_pip_config, PipConfigUnchanged


def _write_config(
    path: Path,
    token: str,
    server_url: str,
    client_id: str,
    root_pem: str,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    content = (
        f'[server]\nurl = "{server_url}"\nclient_id = "{client_id}"\n\n'
        f'[auth]\ntoken = "{token}"\n\n'
        f'[security]\nroot_public_key = """\n{root_pem.rstrip()}\n"""\n'
    )
    path.write_text(content)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _fetch_client_info(token: str, server_url: str) -> tuple[dict | None, str | None]:
    """GET /api/v1/whoami. Returns ({client_id, email, company}, None) or (None, error)."""
    try:
        resp = httpx.get(
            f"{server_url.rstrip('/')}/api/v1/whoami",
            auth=("__token__", token),
            timeout=5.0,
        )
    except Exception as exc:
        return None, f"Network error contacting {server_url}: {exc}"
    if resp.status_code != 200:
        return None, f"Authentication failed (HTTP {resp.status_code})"
    return resp.json(), None


def _fetch_root_public_key(server_url: str) -> tuple[str | None, str | None]:
    """GET /api/v1/keys/root-public-key. Returns (pem, None) or (None, error)."""
    try:
        resp = httpx.get(
            f"{server_url.rstrip('/')}/api/v1/keys/root-public-key",
            timeout=5.0,
        )
    except Exception as exc:
        return None, f"Network error fetching root key: {exc}"
    if resp.status_code != 200:
        return None, f"Server could not provide root public key (HTTP {resp.status_code})"
    pem = resp.json().get("public_key_pem")
    if not pem:
        return None, "Server response missing public_key_pem"
    return pem, None


def _login_with_password(server_url: str, email: str, password: str, totp_code: str | None = None):
    """POST /api/v1/auth/login-password. Returns (body, None) or (None, error)."""
    payload = {"email": email, "password": password}
    if totp_code:
        payload["totp_code"] = totp_code
    try:
        resp = httpx.post(
            f"{server_url.rstrip('/')}/api/v1/auth/login-password",
            json=payload,
            timeout=10.0,
        )
    except Exception as exc:
        return None, f"Network error contacting {server_url}: {exc}"
    if resp.status_code == 200:
        return resp.json(), None
    if resp.status_code == 409:
        return None, "totp_required"
    if resp.status_code == 401:
        body = resp.json() if callable(getattr(resp, "json", None)) else {}
        return None, f"Authentication failed: {body.get('detail', 'unauthorized')}"
    return None, f"Server error (HTTP {resp.status_code})"


def _cmd_recover(args) -> int:
    server = args.server or os.environ.get("LICENSE_SDK_SERVER_URL")
    if not server:
        print("ERROR: --server is required", file=sys.stderr)
        return 2
    email = args.email
    if not email:
        print("ERROR: --email is required", file=sys.stderr)
        return 2

    password = getpass.getpass(f"Password for {email}: ")
    if not password:
        print("ERROR: password required", file=sys.stderr)
        return 2

    body, err = _login_with_password(server, email, password)
    if err == "totp_required":
        code = input("2FA code: ").strip()
        if not code:
            print("ERROR: TOTP code required", file=sys.stderr)
            return 2
        body, err = _login_with_password(server, email, password, totp_code=code)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1

    token = body["token"]
    client_id = body["client_id"]

    root_pem, err = _fetch_root_public_key(server)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1

    cfg_path = user_config_path()
    _write_config(cfg_path, token, server, client_id, root_pem)
    print(f"Wrote {cfg_path} (client_id={client_id}, email={email})")
    print("Your previous API token (if any) has been invalidated.")

    if not args.skip_pip_config:
        pip_path = detect_pip_config_path()
        index_url = f"https://__token__:{token}@{server.rstrip('/').split('://')[-1]}/pypi/simple"
        try:
            write_pip_config(
                pip_path, index_url=index_url,
                confirm_overwrite=lambda old: _ask_yes_no(f"Overwrite existing index-url ({old})?"),
            )
            print(f"Wrote {pip_path}")
        except PipConfigUnchanged:
            print(f"Skipped {pip_path} (kept existing index-url)")
    return 0


def _cmd_login(args) -> int:
    token = args.token or os.environ.get("LICENSE_SDK_TOKEN")
    if not token and sys.stdin.isatty():
        token = getpass.getpass("Token: ")
    if not token:
        print("ERROR: token required (--token, stdin, or LICENSE_SDK_TOKEN)", file=sys.stderr)
        return 2

    server = args.server or os.environ.get("LICENSE_SDK_SERVER_URL")
    if not server:
        print("ERROR: --server is required on first login", file=sys.stderr)
        return 2

    info, err = _fetch_client_info(token, server)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1

    root_pem, err = _fetch_root_public_key(server)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1

    cfg_path = user_config_path()
    _write_config(cfg_path, token, server, info["client_id"], root_pem)
    print(f"Wrote {cfg_path} (client_id={info['client_id']}, email={info.get('email', '?')})")

    if not args.skip_pip_config:
        pip_path = detect_pip_config_path()
        index_url = f"https://__token__:{token}@{server.rstrip('/').split('://')[-1]}/pypi/simple"
        try:
            write_pip_config(
                pip_path, index_url=index_url,
                confirm_overwrite=lambda old: _ask_yes_no(f"Overwrite existing index-url ({old})?"),
            )
            print(f"Wrote {pip_path}")
        except PipConfigUnchanged:
            print(f"Skipped {pip_path} (kept existing index-url)")
    return 0


def _cmd_bootstrap(args) -> int:
    token = os.environ.get("LICENSE_SDK_TOKEN")
    if not token:
        print("ERROR: LICENSE_SDK_TOKEN not set", file=sys.stderr)
        return 2
    server = os.environ.get("LICENSE_SDK_SERVER_URL")
    if not server:
        print("ERROR: LICENSE_SDK_SERVER_URL not set", file=sys.stderr)
        return 2
    info, err = _fetch_client_info(token, server)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1
    root_pem, err = _fetch_root_public_key(server)
    if err:
        print(f"ERROR: {err}", file=sys.stderr)
        return 1
    cfg_path = user_config_path()
    _write_config(cfg_path, token, server, info["client_id"], root_pem)
    pip_path = detect_pip_config_path()
    index_url = f"https://__token__:{token}@{server.rstrip('/').split('://')[-1]}/pypi/simple"
    try:
        write_pip_config(
            pip_path, index_url=index_url,
            confirm_overwrite=lambda old: True,  # non-interactive
        )
    except PipConfigUnchanged:
        pass
    print("bootstrap OK")
    return 0


def _cmd_logout(args) -> int:
    cfg_path = user_config_path()
    if not cfg_path.exists():
        print("Nothing to do (config not present).")
        return 0
    if not args.yes and sys.stdin.isatty():
        if not _ask_yes_no(f"Remove {cfg_path}?"):
            return 1
    cfg_path.unlink()
    print(f"Removed {cfg_path}")
    return 0


def _cmd_status(args) -> int:
    """Diagnose the local licence setup."""
    cfg_path = user_config_path()
    overall_ok = True

    def _print(label: str, ok: bool, detail: str = "") -> None:
        nonlocal overall_ok
        marker = "OK  " if ok else "FAIL"
        print(f"[{marker}] {label}" + (f" — {detail}" if detail else ""))
        if not ok:
            overall_ok = False

    _print(f"config file ({cfg_path})", cfg_path.exists())
    if not cfg_path.exists():
        print("  Run: kh-license login --server URL --token TOKEN", file=sys.stderr)
        return 1

    cfg = load_runtime_config()
    server_url = cfg.get("server", {}).get("url")
    client_id = cfg.get("server", {}).get("client_id")
    token = cfg.get("auth", {}).get("token")
    root_pem = cfg.get("security", {}).get("root_public_key")

    _print("[server].url", bool(server_url), server_url or "missing")
    _print("[server].client_id", bool(client_id), client_id or "missing")
    _print("[auth].token", bool(token), "set" if token else "missing")
    _print(
        "[security].root_public_key",
        bool(root_pem and "BEGIN PUBLIC KEY" in root_pem),
        "set" if root_pem else "missing",
    )

    if not (server_url and token):
        return 1 if not overall_ok else 0

    info, err = _fetch_client_info(token, server_url)
    _print(
        "server /whoami",
        info is not None,
        err or (f"client_id={info.get('client_id')}" if info else "?"),
    )

    if info and client_id and info["client_id"] != client_id:
        _print(
            "client_id matches server",
            False,
            f"config has {client_id} but server says {info['client_id']}",
        )

    server_pem, err = _fetch_root_public_key(server_url)
    if server_pem is None:
        _print("server /keys/root-public-key", False, err or "")
    else:
        local_norm = (root_pem or "").strip()
        server_norm = server_pem.strip()
        match = bool(local_norm) and (local_norm in server_norm or server_norm in local_norm)
        _print(
            "root_public_key matches server",
            match,
            "mismatch — re-run 'kh-license login'" if not match else "",
        )

    hooks = [m for m in sys.meta_path if type(m).__name__ == "LicenceImportHook"]
    _print(
        "LicenceImportHook armed in sys.meta_path",
        len(hooks) >= 1,
        f"{len(hooks)} instance(s)",
    )

    try:
        from license_sdk._bootstrap import _discover_protected_packages
        discovered = _discover_protected_packages()
        _print(
            "protected packages discovered",
            True,
            f"{len(discovered)} — {sorted(discovered) or 'none'}",
        )
    except Exception as e:
        _print("protected packages discovered", False, str(e))

    return 0 if overall_ok else 1


def _probe_bootstrap(server: str, admin_key: str) -> tuple[dict | None, str | None]:
    try:
        resp = httpx.post(
            f"{server.rstrip('/')}/api/v1/admin/probe-account",
            headers={"X-Admin-Key": admin_key},
            timeout=10.0,
        )
    except Exception as exc:
        return None, f"Network error: {exc}"
    if resp.status_code != 200:
        return None, f"probe-account bootstrap failed (HTTP {resp.status_code}): {resp.text[:200]}"
    return resp.json(), None


def _probe_refresh(server: str, auth: tuple[str, str], payload: dict):
    return httpx.post(
        f"{server.rstrip('/')}/api/v1/licences/refresh",
        json=payload, auth=auth, timeout=10.0,
    )


def _probe_revoke(server: str, admin_key: str):
    return httpx.post(
        f"{server.rstrip('/')}/api/v1/admin/probe-account/revoke",
        headers={"X-Admin-Key": admin_key}, timeout=10.0,
    )


def _cmd_probe(args) -> int:
    """Exercise the full licence chain against a persistent probe account."""
    import uuid as _uuid

    server = (
        args.server
        or os.environ.get("LICENSE_SDK_SERVER_URL")
        or load_runtime_config().get("server", {}).get("url")
    )
    admin_key = args.admin_key or os.environ.get("LICENSE_SDK_ADMIN_KEY")
    if not server:
        print(
            "ERROR: --server required (or LICENSE_SDK_SERVER_URL, "
            "or configure via 'kh-license login')",
            file=sys.stderr,
        )
        return 2
    if not admin_key:
        print("ERROR: --admin-key required (or LICENSE_SDK_ADMIN_KEY)", file=sys.stderr)
        return 2

    print(f"Probing {server}\n")

    overall_ok = True

    def _scenario(title: str):
        print(f"─── {title} ───")

    def _result(ok: bool, msg: str = ""):
        nonlocal overall_ok
        overall_ok = overall_ok and ok
        print(f"  {'PASS' if ok else 'FAIL'}" + (f" — {msg}" if msg else ""))

    # ── Bootstrap ────────────────────────────────────────────────────────
    _scenario("Bootstrap: probe account is retrievable")
    acct, err = _probe_bootstrap(server, admin_key)
    if err:
        _result(False, err)
        return 1
    client_id = acct["client_id"]
    email = acct["client_email"]
    token = acct["api_token"]
    password = acct["portal_password"]
    package = acct["package"]
    version = acct["version"]
    seats = acct["seats"]
    auth = (client_id, token)
    _result(True, f"client={email} licence={acct['licence_id']} seats={seats}")

    # ── Scenario 1: whoami round-trip ───────────────────────────────────
    _scenario("1. Token authenticates as the probe client")
    try:
        r = httpx.get(f"{server.rstrip('/')}/api/v1/whoami",
                      auth=("__token__", token), timeout=5.0)
        ok = r.status_code == 200 and r.json().get("client_id") == client_id
        _result(ok, f"whoami→{r.status_code} {r.json() if r.status_code == 200 else r.text[:80]}")
    except Exception as e:
        _result(False, f"network: {e}")

    # ── Scenario 2: refresh issues a JWT ────────────────────────────────
    _scenario("2. /licences/refresh issues a JWT for the probe package")
    session_id = str(_uuid.uuid4())
    machine_a = f"probe-A-{_uuid.uuid4().hex[:8]}"
    payload_a = {
        "package": package, "version": version,
        "machine_id": machine_a, "session_id": session_id,
        "environment": "prod",
    }
    r = _probe_refresh(server, auth, payload_a)
    ok = r.status_code == 200
    body = r.json() if ok else None
    has_jwt = bool(body and (body.get("token") or body.get("jwt")))
    _result(ok and has_jwt,
            f"refresh→{r.status_code}" + (" JWT OK" if has_jwt else f" {r.text[:80]}"))

    # ── Scenario 3: seat limit is enforced ──────────────────────────────
    _scenario(f"3. Seat limit ({seats}) is enforced on additional machines")
    results = []
    for i in range(2, seats + 2):  # machines beyond the first
        machine = f"probe-{chr(65+i-1)}-{_uuid.uuid4().hex[:8]}"
        r = _probe_refresh(server, auth, {**payload_a, "machine_id": machine})
        results.append((machine, r.status_code))
    extras_ok = sum(1 for _, s in results if s == 200)
    extras_blocked = sum(1 for _, s in results if s == 403)
    # With seats=N: machine A + (N-1) more should succeed, next should 403.
    ok = extras_ok == (seats - 1) and extras_blocked >= 1
    _result(ok, f"{extras_ok} extra seats accepted, {extras_blocked} blocked (seats={seats})")

    # ── Scenario 4: revocation blocks refresh ───────────────────────────
    _scenario("4. Revoking the probe licence blocks subsequent refreshes")
    rv = _probe_revoke(server, admin_key)
    if rv.status_code != 200:
        _result(False, f"revoke endpoint returned {rv.status_code}")
    else:
        r = _probe_refresh(server, auth, payload_a)
        ok = r.status_code in (403, 404)
        _result(ok, f"refresh after revoke→{r.status_code}")

    # ── Scenario 5: re-bootstrapping restores a usable account ──────────
    _scenario("5. Re-running bootstrap reactivates the account")
    acct2, err2 = _probe_bootstrap(server, admin_key)
    if err2:
        _result(False, err2)
    else:
        auth2 = (acct2["client_id"], acct2["api_token"])
        r = _probe_refresh(server, auth2, {
            "package": acct2["package"], "version": acct2["version"],
            "machine_id": f"probe-reboot-{_uuid.uuid4().hex[:8]}",
            "session_id": str(_uuid.uuid4()),
            "environment": "prod",
        })
        ok = r.status_code == 200
        _result(ok, f"refresh after rebootstrap→{r.status_code}")

    # ── Scenario 6: recovery (login-password) rotates the token ─────────
    _scenario("6. Token recovery via email + password")
    # Use the credentials from the most recent bootstrap (scenario 5) since
    # each bootstrap rotates the password.
    recovery_email = (acct2 or acct)["client_email"]
    recovery_password = (acct2 or acct)["portal_password"]
    prev_token = (acct2 or acct)["api_token"]
    try:
        rr = httpx.post(
            f"{server.rstrip('/')}/api/v1/auth/login-password",
            json={"email": recovery_email, "password": recovery_password},
            timeout=10.0,
        )
        if rr.status_code != 200:
            _result(False, f"login-password→{rr.status_code} {rr.text[:80]}")
        else:
            new_token = rr.json()["token"]
            auth3 = (rr.json()["client_id"], new_token)
            r = _probe_refresh(server, auth3, {
                "package": (acct2 or acct)["package"],
                "version": (acct2 or acct)["version"],
                "machine_id": f"probe-recov-{_uuid.uuid4().hex[:8]}",
                "session_id": str(_uuid.uuid4()),
                "environment": "prod",
            })
            ok = r.status_code == 200 and new_token != prev_token
            _result(ok, f"new token issued + refresh→{r.status_code}")
    except Exception as e:
        _result(False, f"network: {e}")

    print()
    print("All scenarios passed." if overall_ok else "At least one scenario FAILED — see above.")
    return 0 if overall_ok else 1


_PTH_CONTENT = "import license_sdk._bootstrap; license_sdk._bootstrap.install()\n"


def _target_site_packages() -> Path:
    import sysconfig
    return Path(sysconfig.get_paths()["purelib"])


_WHEEL_INIT_PY = '''"""Auto-generated wrapper for a JVM asset.

Importing this module triggers the kh-license hook; on success the
console-script launches the JVM with the bundled JAR.
"""
__version__ = "{version}"
'''

_WHEEL_CLI_PY = '''"""Launcher — validates the licence then execs the JVM."""
from __future__ import annotations
import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    assets = Path(__file__).parent / "assets"
    jars = sorted(assets.glob("*.jar"))
    if not jars:
        print("ERROR: no JAR in assets/", file=sys.stderr)
        return 2
    java = shutil.which("java")
    if java is None:
        print("ERROR: java not found on PATH", file=sys.stderr)
        return 2
    java_opts = os.environ.get("JAVA_OPTS", "").split() if os.environ.get("JAVA_OPTS") else []
    cmd = [java, *java_opts, "-jar", str(jars[0]), *sys.argv[1:]]
    return subprocess.call(cmd)


if __name__ == "__main__":
    sys.exit(main())
'''


def _cmd_package_jar(args) -> int:
    """Package a JAR into a Python wheel wrapper ready for the kh-license proxy."""
    import base64
    import hashlib
    import io
    import zipfile
    from pathlib import Path as _Path

    jar_path = _Path(args.jar).resolve()
    if not jar_path.is_file():
        print(f"ERROR: JAR not found: {jar_path}", file=sys.stderr)
        return 2

    name = args.name
    if not name.replace("-", "").replace("_", "").isalnum():
        print(f"ERROR: invalid package name '{name}' (letters/digits/_/- only)", file=sys.stderr)
        return 2

    version = args.version
    module = name.replace("-", "_")
    entry = args.entry or f"kh-{name.replace('kh-', '')}"

    jar_bytes = jar_path.read_bytes()
    init_py = _WHEEL_INIT_PY.format(version=version).encode()
    cli_py = _WHEEL_CLI_PY.encode()

    dist_info = f"{module}-{version}.dist-info"
    metadata = (
        f"Metadata-Version: 2.1\n"
        f"Name: {name}\n"
        f"Version: {version}\n"
        f"Summary: JVM asset wrapped for the kh-license platform\n"
        f"Requires-Python: >=3.10\n"
    ).encode()
    wheel_meta = (
        f"Wheel-Version: 1.0\n"
        f"Generator: kh-license package-jar\n"
        f"Root-Is-Purelib: true\n"
        f"Tag: py3-none-any\n"
    ).encode()
    entry_points = (
        f"[console_scripts]\n"
        f"{entry} = {module}.cli:main\n"
    ).encode()

    files = [
        (f"{module}/__init__.py", init_py),
        (f"{module}/cli.py", cli_py),
        (f"{module}/assets/{jar_path.name}", jar_bytes),
        (f"{dist_info}/METADATA", metadata),
        (f"{dist_info}/WHEEL", wheel_meta),
        (f"{dist_info}/entry_points.txt", entry_points),
    ]

    record_lines = []
    for path, content in files:
        digest = base64.urlsafe_b64encode(
            hashlib.sha256(content).digest()
        ).rstrip(b"=").decode()
        record_lines.append(f"{path},sha256={digest},{len(content)}")
    record_lines.append(f"{dist_info}/RECORD,,")
    record_bytes = ("\n".join(record_lines) + "\n").encode()
    files.append((f"{dist_info}/RECORD", record_bytes))

    output_dir = _Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    wheel_name = f"{module}-{version}-py3-none-any.whl"
    wheel_path = output_dir / wheel_name

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for path, content in files:
            z.writestr(path, content)
    wheel_path.write_bytes(buf.getvalue())

    print(f"Wrote {wheel_path} ({len(buf.getvalue())} bytes)")
    print(f"Console script: {entry}")
    print(f"Next: upload {wheel_name} to your producer repository, then declare")
    print(f"  package name '{name}' in the producer portal for admin approval.")
    return 0


def _cmd_install_hook(args) -> int:
    site = _target_site_packages()
    pth = site / "_license_sdk.pth"
    if pth.exists() and pth.read_text() == _PTH_CONTENT:
        print(f"Already installed: {pth}")
        return 0
    site.mkdir(parents=True, exist_ok=True)
    pth.write_text(_PTH_CONTENT)
    print(f"Wrote {pth}")
    return 0


def _detect_token_source() -> str:
    if os.environ.get("LICENSE_SDK_TOKEN"):
        return "env (LICENSE_SDK_TOKEN)"
    from license_sdk._config_paths import user_config_path as ucp, system_config_path as scp
    if ucp().exists():
        return f"user ({ucp()})"
    if scp().exists():
        return f"system ({scp()})"
    return "none"


def _ask_yes_no(prompt: str) -> bool:
    try:
        answer = input(f"{prompt} [y/N] ").strip().lower()
    except EOFError:
        return False
    return answer in ("y", "yes")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="kh-license", description="License SDK CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_login = sub.add_parser("login", help="Configure token + pip.conf")
    p_login.add_argument("--token")
    p_login.add_argument("--server")
    p_login.add_argument("--skip-pip-config", action="store_true")
    p_login.set_defaults(func=_cmd_login)

    p_boot = sub.add_parser("bootstrap", help="Non-interactive login for CI")
    p_boot.set_defaults(func=_cmd_bootstrap)

    p_rec = sub.add_parser(
        "recover",
        help="Recover / rotate the API token using email + password (+ 2FA)",
    )
    p_rec.add_argument("--server", help="Server URL")
    p_rec.add_argument("--email", required=True)
    p_rec.add_argument("--skip-pip-config", action="store_true")
    p_rec.set_defaults(func=_cmd_recover)

    p_logout = sub.add_parser("logout", help="Remove local config")
    p_logout.add_argument("--yes", action="store_true")
    p_logout.set_defaults(func=_cmd_logout)

    p_stat = sub.add_parser("status", help="Show configuration + active licences")
    p_stat.set_defaults(func=_cmd_status)

    p_install = sub.add_parser(
        "install-hook",
        help="Install _license_sdk.pth (for editable installs that skip setuptools' data_files)",
    )
    p_install.set_defaults(func=_cmd_install_hook)

    p_pkg = sub.add_parser(
        "package-jar",
        help="Package a JAR into a Python wheel wrapper (e.g. for distributing an EDC Connector)",
    )
    p_pkg.add_argument("jar", help="Path to the .jar to wrap")
    p_pkg.add_argument("--name", required=True, help="Python package name (e.g. 'kh-edc-connector')")
    p_pkg.add_argument("--version", required=True, help="Version (e.g. '0.1.0')")
    p_pkg.add_argument("--entry", default=None, help="Console-script name (default derived from --name)")
    p_pkg.add_argument("--output-dir", default="dist", help="Where to write the wheel (default: dist/)")
    p_pkg.set_defaults(func=_cmd_package_jar)

    p_probe = sub.add_parser(
        "probe",
        help="Exercise the full licence chain against a persistent probe account (admin only)",
    )
    p_probe.add_argument("--server", help="Server URL (default: $LICENSE_SDK_SERVER_URL)")
    p_probe.add_argument("--admin-key", help="Server admin API key (default: $LICENSE_SDK_ADMIN_KEY)")
    p_probe.set_defaults(func=_cmd_probe)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
