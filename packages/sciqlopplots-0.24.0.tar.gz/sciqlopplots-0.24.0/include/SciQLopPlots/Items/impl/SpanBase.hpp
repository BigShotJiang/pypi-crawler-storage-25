/*------------------------------------------------------------------------------
-- This file is a part of the SciQLop Software
-- Copyright (C) 2024, Plasma Physics Laboratory - CNRS
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
-------------------------------------------------------------------------------*/
#pragma once

#include "SciQLopPlots/Items/SciQLopPlotItem.hpp"
#include <QColor>
#include <qcustomplot.h>

namespace impl
{

// Shared logic for impl::VerticalSpan, impl::HorizontalSpan, impl::RectangularSpan.
// Uses composition: each impl class passes its QCPAbstractSpanItem* (via upcast from this).
class SpanBase : public SciQlopItemWithToolTip
{
    QCPAbstractSpanItem* _span;

public:
    explicit SpanBase(QCPAbstractSpanItem* span);

    [[nodiscard]] QCPAbstractSpanItem* span() const noexcept { return _span; }

    void set_color(const QColor& color);
    [[nodiscard]] QColor color() const noexcept;

    void set_borders_color(const QColor& color);
    [[nodiscard]] QColor borders_color() const noexcept;

    void set_line_width(double width);
    [[nodiscard]] double line_width() const noexcept;

    void set_line_style(Qt::PenStyle style);
    [[nodiscard]] Qt::PenStyle line_style() const noexcept;

    void set_visible(bool visible);

    void set_borders_tool_tip(const QString& tool_tip);

    void replot(bool immediate = false);
};

} // namespace impl
