import pandas as pd
import numpy as np

def CovMatrix(
    df_returns: pd.DataFrame,
    use_ewma: bool = True,
    lambda_: float = None,
    ewma_value: bool = True,
    half_life: int = None
) -> dict:
    """
    Calcula matrices de riesgo usando:
    - EWMA, si use_ewma=True
    - Histórico simple, si use_ewma=False

    Retorna un diccionario con:
    - cov: matriz var-cov
    - vol: volatilidades individuales
    - corr: matriz de correlación
    - vol_corr: D * Corr
    - lambda: lambda efectivo usado
    - half_life: half-life efectivo usado o estimado
    - half_life_date: fecha donde ocurre el half-life

    Parámetros
    ----------
    df_returns : pd.DataFrame
        DataFrame de retornos
        - índice: fechas
        - columnas: activos
        - valores: retornos

    use_ewma : bool, default True
        - True: usa EWMA
        - False: usa estimación histórica simple

    lambda_ : float, opcional
        Factor de decaimiento EWMA. Se usa si:
        use_ewma=True y ewma_value=True

    ewma_value : bool, default True
        Solo aplica si use_ewma=True
        - True  -> usa lambda_ directamente
        - False -> estima lambda_ a partir de half_life

    half_life : int, opcional
        Half-life en número de períodos.
        Se usa solo si:
        use_ewma=True y ewma_value=False

    Retorna
    -------
    dict
    """

    # -----------------------------
    # Validaciones
    # -----------------------------
    if not isinstance(df_returns, pd.DataFrame):
        raise TypeError("df_returns debe ser un pandas DataFrame.")

    if df_returns.empty:
        raise ValueError("df_returns está vacío.")

    df = df_returns.select_dtypes(include=[np.number])

    if df.shape[1] == 0:
        raise ValueError("df_returns no contiene columnas numéricas.")

    cols = df.columns
    n_assets = df.shape[1]

    # =============================
    # CASO 1: EWMA
    # =============================
    if use_ewma:
        df = df.dropna(how="any")
        if df.shape[0] < 2:
            raise ValueError("Se requieren al menos 2 observaciones completas.")

        # -----------------------------
        # Determinar lambda y half-life efectivos
        # -----------------------------
        if ewma_value:
            if lambda_ is None:
                raise ValueError("Si use_ewma=True y ewma_value=True, debes ingresar lambda_.")
            if not (0 < lambda_ < 1):
                raise ValueError("lambda_ debe estar entre 0 y 1.")

            lambda_eff = float(lambda_)
            half_life_eff = float(np.log(0.5) / np.log(lambda_eff))

        else:
            if half_life is None:
                raise ValueError("Si use_ewma=True y ewma_value=False, debes ingresar half_life.")
            if not isinstance(half_life, int) or half_life <= 0:
                raise ValueError("half_life debe ser un entero positivo.")

            half_life_eff = float(half_life)
            lambda_eff = float(np.exp(np.log(0.5) / half_life_eff))

        # -----------------------------
        # Cálculo EWMA recursivo
        # -----------------------------
        returns = df.to_numpy(dtype=float)

        r0 = returns[0].reshape(-1, 1)
        sigma = r0 @ r0.T

        for t in range(1, returns.shape[0]):
            rt = returns[t].reshape(-1, 1)
            sigma = lambda_eff * sigma + (1 - lambda_eff) * (rt @ rt.T)

        # -----------------------------
        # Volatilidades EWMA
        # -----------------------------
        variances = np.diag(sigma)
        vol = np.sqrt(np.maximum(variances, 0.0))
        D = np.diag(vol)

        # -----------------------------
        # Correlación implícita EWMA
        # -----------------------------
        inv_vol = np.where(vol > 0, 1.0 / vol, 0.0)
        D_inv = np.diag(inv_vol)
        corr = D_inv @ sigma @ D_inv

        for i in range(n_assets):
            corr[i, i] = 1.0 if vol[i] > 0 else 0.0

        # -----------------------------
        # Reconstrucción
        # -----------------------------
        cov = D @ corr @ D
        vol_corr = D @ corr

        # -----------------------------
        # Half-life date
        # -----------------------------
        hl_periods = int(round(half_life_eff))
        if hl_periods < len(df):
            half_life_date = df.index[-(hl_periods + 1)]
        else:
            half_life_date = df.index[0]

    # =============================
    # CASO 2: HISTÓRICO SIMPLE
    # =============================
    else:
        # -----------------------------
        # Volatilidades históricas
        # -----------------------------
        vol_series = df.std(ddof=1)
        vol = vol_series.to_numpy(dtype=float)
        D = np.diag(vol)

        # -----------------------------
        # Correlación histórica
        # -----------------------------
        corr_df = df.corr().fillna(0)
        corr = corr_df.to_numpy(dtype=float)
        np.fill_diagonal(corr, np.where(vol > 0, 1.0, 0.0))

        # -----------------------------
        # Matriz var-cov histórica
        # -----------------------------
        cov = D @ corr @ D
        vol_corr = D @ corr

        lambda_eff = None
        half_life_eff = None
        half_life_date = None

    # -----------------------------
    # Outputs
    # -----------------------------
    cov_df = pd.DataFrame(cov, index=cols, columns=cols)
    corr_df = pd.DataFrame(corr, index=cols, columns=cols)
    vol_df = pd.DataFrame(vol, index=cols, columns=["vol"])
    vol_corr_df = pd.DataFrame(vol_corr, index=cols, columns=cols)

    return {
        "cov": cov_df,
        "vol": vol_df,
        "corr": corr_df,
        "vol_corr": vol_corr_df,
        "lambda": lambda_eff,
        "half_life": half_life_eff,
        "half_life_date": half_life_date
    }

def PortfolioRisk(weights: pd.DataFrame, cov_matrix: pd.DataFrame) -> float:
    """
    Calcula la volatilidad del portafolio: sqrt(w^T * Σ * w).

    Parámetros
    ----------
    weights : pd.DataFrame
        DataFrame de pesos del portafolio.
        - índice: nombre de los activos
        - debe tener una sola columna con los pesos

    cov_matrix : pd.DataFrame
        Matriz de varianza-covarianza.
        - índice y columnas: nombre de los activos

    Retorna
    -------
    float
        Volatilidad del portafolio.
    """
    if not isinstance(weights, pd.DataFrame):
        raise TypeError("weights debe ser un pandas DataFrame.")
    if not isinstance(cov_matrix, pd.DataFrame):
        raise TypeError("cov_matrix debe ser un pandas DataFrame.")

    if weights.shape[1] != 1:
        raise ValueError("weights debe tener exactamente una columna.")

    assets_w = set(weights.index)
    assets_cov = set(cov_matrix.index)

    missing_in_cov = assets_w - assets_cov
    missing_in_w = assets_cov - assets_w

    if missing_in_cov:
        raise ValueError(f"Activos en weights no encontrados en cov_matrix: {missing_in_cov}")
    if missing_in_w:
        raise ValueError(f"Activos en cov_matrix no encontrados en weights: {missing_in_w}")

    # Alinear por orden del índice de weights
    assets = weights.index.tolist()
    cov_aligned = cov_matrix.loc[assets, assets]

    w = weights.iloc[:, 0].to_numpy(dtype=float)
    sigma = cov_aligned.to_numpy(dtype=float)
    variance = float(w @ sigma @ w)
    
    return float(np.sqrt(max(variance, 0.0)))

