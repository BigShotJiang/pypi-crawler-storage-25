import os
import time
import tempfile
from dataclasses import dataclass
from typing import Any, Optional

import pandas as pd
import requests


@dataclass
class Config:
    """
    Configuración base para conectarse a la API.
    """
    base_url: str = os.getenv("API_RISK_GCS_URL")
    token: str = os.getenv("API_RISK_GCS_TOKEN")
    timeout: int = 120
    poll_seconds: int = 3
    max_polls: int = 120

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

    def _print(self, message: str, log: bool = False) -> None:
        if log:
            print(message)

    def _get(
        self,
        endpoint: str,
        params: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        response = requests.get(
            f"{self.base_url}/{endpoint.lstrip('/')}",
            headers=self.headers,
            params=params,
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def _post(
        self,
        endpoint: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        response = requests.post(
            f"{self.base_url}/{endpoint.lstrip('/')}",
            headers=self.headers,
            json=payload or {},
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def get_health(self) -> dict[str, Any]:
        response = requests.get(
            f"{self.base_url}/health",
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def get_export_status(
        self,
        module_name: str,
        job_id: str,
        export_id: str,
    ) -> dict[str, Any]:
        return self._get(
            endpoint=f"exports/{module_name}/{job_id}",
            params={"export_id": export_id},
        )

    def wait_until_done(
        self,
        module_name: str,
        job_id: str,
        export_id: str,
        log: bool = False,
    ) -> dict[str, Any]:
        """
        Espera hasta que un export termine.
        """
        for attempt in range(1, self.max_polls + 1):
            status_data = self.get_export_status(
                module_name=module_name,
                job_id=job_id,
                export_id=export_id,
            )

            status = status_data["status"]
            state = status_data["state"]

            self._print(
                f"[{attempt}/{self.max_polls}] module={module_name} status={status} | state={state}",
                log=log,
            )

            if status == "done":
                return status_data

            if status == "failed":
                raise RuntimeError(
                    f"Export failed. error_result={status_data.get('error_result')} "
                    f"errors={status_data.get('errors')}"
                )

            time.sleep(self.poll_seconds)

        raise TimeoutError("El export no terminó dentro del tiempo máximo configurado.")

    def _download_file_from_signed_url(
        self,
        url: str,
        destination_path: str,
    ) -> str:
        with requests.get(url, stream=True, timeout=600) as response:
            response.raise_for_status()
            with open(destination_path, "wb") as file_obj:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        file_obj.write(chunk)
        return destination_path

    def files_to_dataframe(
        self,
        files: list[dict[str, Any]],
        log: bool = False,
    ) -> pd.DataFrame:
        """
        Descarga archivos parquet desde signed URLs y los concatena en un DataFrame.
        """
        if not files:
            return pd.DataFrame()

        dataframes: list[pd.DataFrame] = []

        with tempfile.TemporaryDirectory() as tmpdir:
            for idx, file_info in enumerate(files, start=1):
                file_name = file_info["file_name"]
                signed_url = file_info["signed_url"]
                local_path = os.path.join(tmpdir, f"{idx}_{file_name}")

                self._print(f"Descargando {file_name} ...", log=log)
                self._download_file_from_signed_url(signed_url, local_path)

                self._print(f"Leyendo {file_name} ...", log=log)
                df_part = pd.read_parquet(local_path)
                dataframes.append(df_part)

        if not dataframes:
            return pd.DataFrame()

        return pd.concat(dataframes, ignore_index=True)

    def export_to_dataframe(
        self,
        module_name: str,
        endpoint_export: str,
        payload: dict[str, Any],
        log: bool = False,
    ) -> pd.DataFrame:
        """
        Flujo genérico:
        1. crea export
        2. espera a que termine
        3. descarga signed URLs
        4. concatena parquet a DataFrame
        """
        export_data = self._post(endpoint_export, payload)

        export_id = export_data["export_id"]
        job_id = export_data["job_id"]

        self._print("Export creado:", log=log)
        self._print(f"  module_name: {module_name}", log=log)
        self._print(f"  export_id:   {export_id}", log=log)
        self._print(f"  job_id:      {job_id}", log=log)
        self._print(f"  gcs_prefix:  {export_data.get('gcs_prefix')}", log=log)
        self._print("", log=log)

        final_status = self.wait_until_done(
            module_name=module_name,
            job_id=job_id,
            export_id=export_id,
            log=log,
        )

        files = final_status.get("files", [])
        self._print(f"Archivos generados: {len(files)}", log=log)

        return self.files_to_dataframe(files, log=log)


class Datamart(Config):
    """
    Cliente para endpoints de la categoría DATAMART.
    """

    # =========================
    # FM Valores Cuota
    # =========================
    def fm_valores_cuota_stats(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        moneda: str,
        categoria: Optional[str] = None,
        runs: Optional[list[str]] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "moneda": moneda,
            "bruto": bruto,
        }

        if categoria:
            params["categoria"] = categoria

        if runs:
            params["runs"] = runs

        self._print("Consultando FM_Valores_Cuota_Stats ...", log=log)
        return self._get("FM_Valores_Cuota_Stats", params=params)

    def fm_valores_cuota_export(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        moneda: str,
        categoria: Optional[str] = None,
        runs: Optional[list[str]] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "moneda": moneda,
            "categoria": categoria,
            "runs": runs or [],
            "bruto": bruto,
        }
        self._print("Creando export FM_Valores_Cuota_Export ...", log=log)
        return self._post("FM_Valores_Cuota_Export", payload)

    def fm_valores_cuota_to_dataframe(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        moneda: str,
        categoria: Optional[str] = None,
        runs: Optional[list[str]] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "moneda": moneda,
            "categoria": categoria,
            "runs": runs or [],
            "bruto": bruto,
        }
        return self.export_to_dataframe(
            module_name="fm_valores_cuota",
            endpoint_export="FM_Valores_Cuota_Export",
            payload=payload,
            log=log,
        )

    # =========================
    # Fondos Mutuos
    # =========================
    def fondos_mutuos_stats(
        self,
        ignorar_cambio_nombre: bool,
        fecha_corte: Optional[str] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "ignorar_cambio_nombre": ignorar_cambio_nombre,
            "bruto": bruto,
        }

        if fecha_corte:
            params["fecha_corte"] = fecha_corte

        self._print("Consultando Fondos_Mutuos_Stats ...", log=log)
        return self._get("Fondos_Mutuos_Stats", params=params)

    def fondos_mutuos_export(
        self,
        ignorar_cambio_nombre: bool,
        fecha_corte: Optional[str] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "ignorar_cambio_nombre": ignorar_cambio_nombre,
            "fecha_corte": fecha_corte,
            "bruto": bruto,
        }
        self._print("Creando export Fondos_Mutuos_Export ...", log=log)
        return self._post("Fondos_Mutuos_Export", payload)

    def fondos_mutuos_to_dataframe(
        self,
        ignorar_cambio_nombre: bool,
        fecha_corte: Optional[str] = None,
        bruto: bool = True,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "ignorar_cambio_nombre": ignorar_cambio_nombre,
            "fecha_corte": fecha_corte,
            "bruto": bruto,
        }
        return self.export_to_dataframe(
            module_name="fondos_mutuos",
            endpoint_export="Fondos_Mutuos_Export",
            payload=payload,
            log=log,
        )

    # =========================
    # LVA Aux Valores Cuota
    # =========================
    def lva_aux_valores_cuota_stats(
        self,
        runs: Optional[list[str]] = None,
        vigente: Optional[int] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if runs:
            params["runs"] = runs
        if vigente is not None:
            params["vigente"] = vigente
        self._print("Consultando LVA_Aux_Valores_Cuota_Stats ...", log=log)
        return self._get("LVA_Aux_Valores_Cuota_Stats", params=params)

    def lva_aux_valores_cuota_export(
        self,
        runs: Optional[list[str]] = None,
        vigente: Optional[int] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "runs": runs or [],
            "vigente": vigente,
        }
        self._print("Creando export LVA_Aux_Valores_Cuota_Export ...", log=log)
        return self._post("LVA_Aux_Valores_Cuota_Export", payload)

    def lva_aux_valores_cuota_to_dataframe(
        self,
        runs: Optional[list[str]] = None,
        vigente: Optional[int] = None,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "runs": runs or [],
            "vigente": vigente,
        }
        return self.export_to_dataframe(
            module_name="lva_aux_valores_cuota",
            endpoint_export="LVA_Aux_Valores_Cuota_Export",
            payload=payload,
            log=log,
        )


class FrameworkRiesgo(Config):
    """
    Cliente para endpoints de la categoría Framework Riesgo.
    """

    # =========================
    # Benchmarks
    # =========================
    def benchmarks_stats(
        self,
        categoria: str,
        year: str,
        log: bool = False,
    ) -> dict[str, Any]:
        self._print("Consultando Benchmarks_Stats ...", log=log)
        return self._get(f"Benchmarks_Stats/{categoria}_{year}")

    def benchmarks_export(
        self,
        categoria: str,
        year: str,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "categoria": categoria,
            "year": year,
        }
        self._print("Creando export Benchmarks_Export ...", log=log)
        return self._post("Benchmarks_Export", payload)

    def benchmarks_to_dataframe(
        self,
        categoria: str,
        year: str,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "categoria": categoria,
            "year": year,
        }
        return self.export_to_dataframe(
            module_name="benchmarks",
            endpoint_export="Benchmarks_Export",
            payload=payload,
            log=log,
        )

    # =========================
    # Métricas Expost
    # =========================
    def metricas_expost_stats(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        categoria: Optional[str] = None,
        metrica: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}

        if run:
            params["run"] = run
        if categoria:
            params["categoria"] = categoria
        if metrica:
            params["metrica"] = metrica

        self._print("Consultando Metricas_Expost_Stats ...", log=log)
        return self._get(
            f"Metricas_Expost_Stats/{start_date}_{end_date}",
            params=params if params else None,
        )

    def metricas_expost_export(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        categoria: Optional[str] = None,
        metrica: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "start_date": start_date,
            "end_date": end_date,
            "run": run,
            "categoria": categoria,
            "metrica": metrica,
        }
        self._print("Creando export Metricas_Expost_Export ...", log=log)
        return self._post("Metricas_Expost_Export", payload)

    def metricas_expost_to_dataframe(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        categoria: Optional[str] = None,
        metrica: Optional[str] = None,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "start_date": start_date,
            "end_date": end_date,
            "run": run,
            "categoria": categoria,
            "metrica": metrica,
        }
        return self.export_to_dataframe(
            module_name="metricas_expost",
            endpoint_export="Metricas_Expost_Export",
            payload=payload,
            log=log,
        )

    # =========================
    # Alertas Métricas Expost
    # =========================
    def alertas_metricas_expost_stats(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        id_metrica: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}

        if run:
            params["run"] = run
        if id_metrica:
            params["id_metrica"] = id_metrica

        self._print("Consultando Alertas_Metricas_Expost_Stats ...", log=log)
        return self._get(
            f"Alertas_Metricas_Expost_Stats/{start_date}_{end_date}",
            params=params if params else None,
        )

    def alertas_metricas_expost_export(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        id_metrica: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "start_date": start_date,
            "end_date": end_date,
            "run": run,
            "id_metrica": id_metrica,
        }
        self._print("Creando export Alertas_Metricas_Expost_Export ...", log=log)
        return self._post("Alertas_Metricas_Expost_Export", payload)

    def alertas_metricas_expost_to_dataframe(
        self,
        start_date: str,
        end_date: str,
        run: Optional[str] = None,
        id_metrica: Optional[str] = None,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "start_date": start_date,
            "end_date": end_date,
            "run": run,
            "id_metrica": id_metrica,
        }
        return self.export_to_dataframe(
            module_name="alertas_metricas_expost",
            endpoint_export="Alertas_Metricas_Expost_Export",
            payload=payload,
            log=log,
        )

    # =========================
    # SRRI
    # =========================
    def srri_stats(
        self,
        log: bool = False,
    ) -> dict[str, Any]:
        self._print("Consultando SRRI_Stats ...", log=log)
        return self._get("SRRI_Stats")

    def srri_export(
        self,
        log: bool = False,
    ) -> dict[str, Any]:
        self._print("Creando export SRRI_Export ...", log=log)
        return self._post("SRRI_Export")

    def srri_to_dataframe(
        self,
        log: bool = False,
    ) -> pd.DataFrame:
        return self.export_to_dataframe(
            module_name="srri",
            endpoint_export="SRRI_Export",
            payload={},
            log=log,
        )

    # =========================
    # Niveles Riesgo
    # =========================
    def niveles_riesgo_stats(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        administradora: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
        }
        if administradora:
            params["administradora"] = administradora
        self._print("Consultando Niveles_Riesgo_Stats ...", log=log)
        return self._get("Niveles_Riesgo_Stats", params=params)

    def niveles_riesgo_export(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        administradora: Optional[str] = None,
        log: bool = False,
    ) -> dict[str, Any]:
        payload = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "administradora": administradora,
        }
        self._print("Creando export Niveles_Riesgo_Export ...", log=log)
        return self._post("Niveles_Riesgo_Export", payload)

    def niveles_riesgo_to_dataframe(
        self,
        fecha_inicio: str,
        fecha_fin: str,
        administradora: Optional[str] = None,
        log: bool = False,
    ) -> pd.DataFrame:
        payload = {
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin,
            "administradora": administradora,
        }
        return self.export_to_dataframe(
            module_name="niveles_riesgo",
            endpoint_export="Niveles_Riesgo_Export",
            payload=payload,
            log=log,
        )