from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()
    

setup(
    name='sdk_risk_qa',
    version='0.0.0.6',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas>=2.2.3",
        "requests>=2.32.3",
        'numpy',
        'scipy',
        'PyQuantimClient'
        
    ],
    long_description=description,
    long_description_content_type="text/markdown",
            
)