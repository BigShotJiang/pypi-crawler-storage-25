# 🔱 Sovereign AG: The Invisible Rail

[![PyPI Version](https://img.shields.io/pypi/v/svtp.svg?color=black&style=flat-square)](https://pypi.org/project/svtp/)
[![Python Version](https://img.shields.io/badge/python-3.8%20%7C%203.9%20%7C%203.10%20%7C%203.11%20%7C%203.12-black?style=flat-square)](https://pypi.org/project/svtp/)
[![License](https://img.shields.io/badge/license-MIT-black?style=flat-square)](https://github.com/sovereign-ag/sdk)

> Institutional-grade non-custodial AI fleet governance, cryptographic agent provisioning, and liability routing protocol.

---

## 🚀 3-Second Quickstart

To install the SDK and launch the onboarding guide, run these two commands in your terminal:

```bash
# Install the package
pip install svtp

# Launch the interactive guide
svtp
```

---

## 🛠️ The Master Command Suite

The Sovereign AG CLI provides full cryptographically anchored control over your local and cloud-based AI agent fleets:

### 1. Identity & Setup
*   `svtp init` — Generate a high-entropy local RSA-2048 non-repudiation keypair and claim a unique DID (`did:svtp`).
*   `svtp login` — Initiate a secure OAuth2-style device-flow pairing handshake to claim and anchor your terminal hardware to your Web Dashboard account.
*   `svtp status` — Perform a comprehensive terminal diagnostic check showing DID, claims status, and active passports.

### 2. Fleet Governance
*   `svtp mint-passport` — Mint an cryptographically signed liability passport for a new autonomous agent and save it locally.
*   `svtp list` — Fetch the active infrastructure fleet status directly from the validator database ledger.
*   `svtp pulse` — Monitor real-time telemetry heartbeats and trust indexes.
*   `svtp freeze` — Issue an instant emergency global fleet pause command.

---

## 🛡️ Non-Custodial Security & Architecture

Sovereign AG is built on strict non-custodial architecture:
*   **Hardware-Anchored Identity**: Your master private keys reside safely inside your local directory (`~/.svtp_identity.json`) and never leave your machine.
*   **OAuth2 Device Authorization**: Terminal-to-dashboard pairing is performed using cryptographically isolated short-code polling over standard OIDC validation pipelines.
*   **Auditable Ledger**: Every single agent registration and telemetry pulse is notarized to the physical append-only ledger (`sovereign_ledger.ndjson`) for real-time auditability.

---

🔱 **Sovereign AG** | Institutional AI Infrastructure.