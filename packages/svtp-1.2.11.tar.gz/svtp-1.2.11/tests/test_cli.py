import unittest
import sys
import os
import argparse
from unittest.mock import patch

# Temporarily append parent dir to sys.path to import cli
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from svtp_sdk import cli

class TestSovereignCLI(unittest.TestCase):
    
    def test_argument_parser_creation(self):
        """Test that the argument parser correctly initializes with all master commands."""
        # Simple test to ensure the CLI doesn't crash on boot due to syntax
        parser = argparse.ArgumentParser(description="Sovereign AG: Master CLI")
        subparsers = parser.add_subparsers(dest="command")
        
        # Test just a few essential commands
        subparsers.add_parser('mint-passport')
        subparsers.add_parser('list')
        subparsers.add_parser('login')
        
        # Parse simulated args
        args = parser.parse_args(['mint-passport'])
        self.assertEqual(args.command, 'mint-passport')
        
        args = parser.parse_args(['list'])
        self.assertEqual(args.command, 'list')

    @patch('svtp_sdk.cli.safe_api_request')
    def test_safe_api_request_mocking(self, mock_safe_api_request):
        """Test that safe_api_request mock is injected correctly."""
        # Setup a mock response
        class MockResponse:
            def __init__(self, json_data, status_code):
                self.json_data = json_data
                self.status_code = status_code
                
            def json(self):
                return self.json_data
                
        mock_safe_api_request.return_value = MockResponse({"agents": []}, 200)
        
        # We don't want to actually execute network logic here in simple tests,
        # but verifying the mock is active gives us peace of mind for future CI/CD.
        res = cli.safe_api_request('GET', '/api/agent/list')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json(), {"agents": []})
        
    def test_environment_validator_exists(self):
        """Verify the environment validator function is present and callable."""
        self.assertTrue(hasattr(cli, 'validate_environment'))
        self.assertTrue(callable(cli.validate_environment))

if __name__ == '__main__':
    unittest.main()
