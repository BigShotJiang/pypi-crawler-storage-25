from setuptools import setup, find_packages
from setuptools.command.install import install
import sys

class PremiumPostInstall(install):
    def run(self):
        install.run(self)
        sys.stdout.write("\n" + "="*60 + "\n")
        sys.stdout.write("SOVEREIGN AG: PROTOCOL INSTALLED SUCCESSFULLY!\n")
        sys.stdout.write("="*60 + "\n")
        sys.stdout.write("Your physical terminal is ready to anchor.\n")
        sys.stdout.write("\n[NEXT STEP]\n")
        sys.stdout.write("Please type the following command to claim your identity:\n")
        sys.stdout.write(" ==>   svtp   <==\n")
        sys.stdout.write("="*60 + "\n\n")
        sys.stdout.flush()

setup(
    name="svtp",
    version="1.2.11",
    description="Sovereign AG Master CLI & Institutional SDK",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Sovereign AG",
    url="https://github.com/sovereign-ag/sdk",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "cryptography>=41.0.0",
        "pydantic>=2.0.0"
    ],
    entry_points={
        "console_scripts": [
            "svtp=svtp_sdk.cli:main",
        ],
    },
    cmdclass={
        'install': PremiumPostInstall,
    },
    python_requires='>=3.8',
)
