## v0.2.0 (2026-04-11)

### Feat

- add --version flag

## v0.1.3 (2026-04-11)

## v0.1.2 (2026-04-11)

### Refactor

- rename depwhy → whydep, dw → wd

## v0.1.1 (2026-04-11)

### Fix

- resolve clippy warnings
- remove incorrect working-directory from all workflows
