use whydep::scan::{get_import_names, line_imports};

fn names(s: &[&str]) -> Vec<String> {
    s.iter().map(|x| x.to_string()).collect()
}

// ── Basic import forms ────────────────────────────────────────────────────────

#[test]
fn import_bare() {
    assert!(line_imports("import requests", &names(&["requests"])));
}

#[test]
fn import_submodule() {
    assert!(line_imports("import fastapi.routing", &names(&["fastapi"])));
}

#[test]
fn import_alias() {
    assert!(line_imports("import numpy as np", &names(&["numpy"])));
}

#[test]
fn import_comma_first() {
    assert!(line_imports("import os, sys", &names(&["os"])));
}

#[test]
fn import_comma_second() {
    assert!(line_imports("import os, sys", &names(&["sys"])));
}

#[test]
fn from_import() {
    assert!(line_imports(
        "from fastapi import FastAPI",
        &names(&["fastapi"])
    ));
}

#[test]
fn from_submodule_import() {
    assert!(line_imports(
        "from fastapi.routing import APIRouter",
        &names(&["fastapi"])
    ));
}

#[test]
fn from_import_alias() {
    assert!(line_imports(
        "from polars import DataFrame as DF",
        &names(&["polars"])
    ));
}

// ── Dynamic import forms ──────────────────────────────────────────────────────

#[test]
fn importlib_double_quotes() {
    assert!(line_imports(
        r#"importlib.import_module("requests")"#,
        &names(&["requests"])
    ));
}

#[test]
fn importlib_single_quotes() {
    assert!(line_imports(
        "importlib.import_module('requests')",
        &names(&["requests"])
    ));
}

#[test]
fn dunder_import() {
    assert!(line_imports("__import__('os')", &names(&["os"])));
}

// ── Lines that must NOT match ─────────────────────────────────────────────────

#[test]
fn comment_not_matched() {
    assert!(!line_imports("# import requests", &names(&["requests"])));
}

#[test]
fn partial_name_not_matched() {
    assert!(!line_imports("import foobar", &names(&["foo"])));
}

#[test]
fn from_partial_not_matched() {
    assert!(!line_imports("from foobar import x", &names(&["foo"])));
}

#[test]
fn empty_line_not_matched() {
    assert!(!line_imports("", &names(&["requests"])));
}

#[test]
fn unrelated_line_not_matched() {
    assert!(!line_imports("x = 1 + 2", &names(&["requests"])));
}

// ── Edge cases ────────────────────────────────────────────────────────────────

#[test]
fn multiple_names_first_matches() {
    assert!(line_imports("import httpx", &names(&["requests", "httpx"])));
}

#[test]
fn multiple_names_second_matches() {
    assert!(line_imports(
        "import requests",
        &names(&["httpx", "requests"])
    ));
}

#[test]
fn hyphenated_pkg_underscore_import() {
    assert!(line_imports("import sklearn", &names(&["sklearn"])));
    assert!(!line_imports("import scikit-learn", &names(&["sklearn"])));
}

#[test]
fn type_checking_import() {
    assert!(line_imports(
        "from typing import TYPE_CHECKING",
        &names(&["typing"])
    ));
}

#[test]
fn try_except_import() {
    assert!(line_imports("import ujson as json", &names(&["ujson"])));
}

#[test]
fn requests_aliased() {
    // `import requests as http_client` — common alias pattern
    assert!(line_imports(
        "import requests as http_client",
        &names(&["requests"])
    ));
}

// ── get_import_names fallback (no venv) ───────────────────────────────────────

#[test]
fn import_names_fallback_simple() {
    assert_eq!(get_import_names("requests", None), vec!["requests"]);
}

#[test]
fn import_names_fallback_hyphen_gives_underscore_first() {
    let names = get_import_names("scikit-learn", None);
    assert_eq!(names[0], "scikit_learn");
}

#[test]
fn import_names_fallback_includes_both_forms() {
    let names = get_import_names("my-pkg", None);
    assert!(names.contains(&"my_pkg".to_string()));
    assert!(names.contains(&"my-pkg".to_string()));
}

#[test]
fn import_names_no_duplicates_for_simple_name() {
    // A name with no hyphens should produce exactly one entry
    let names = get_import_names("flask", None);
    assert_eq!(names, vec!["flask"]);
}
