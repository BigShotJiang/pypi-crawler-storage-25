use std::collections::HashMap;
use std::path::Path;

use whydep::lock::{
    build_reverse, normalize, parse_poetry_lock_content, parse_uv_lock_content,
    read_poetry_direct_deps,
};

// ── Helpers ──────────────────────────────────────────────────────────────────

fn make_forward(pairs: &[(&str, &[&str])]) -> HashMap<String, Vec<String>> {
    pairs
        .iter()
        .map(|(k, vs)| (k.to_string(), vs.iter().map(|s| s.to_string()).collect()))
        .collect()
}

// ── normalize ─────────────────────────────────────────────────────────────────

#[test]
fn normalize_lowercase() {
    assert_eq!(normalize("Requests"), "requests");
}

#[test]
fn normalize_underscores_to_hyphens() {
    assert_eq!(normalize("scikit_learn"), "scikit-learn");
}

#[test]
fn normalize_dots_to_hyphens() {
    assert_eq!(normalize("zope.interface"), "zope-interface");
}

#[test]
fn normalize_mixed() {
    assert_eq!(normalize("My_Package.Name"), "my-package-name");
}

#[test]
fn normalize_already_normal() {
    assert_eq!(normalize("fastapi"), "fastapi");
}

#[test]
fn normalize_hyphens_unchanged() {
    assert_eq!(normalize("scikit-learn"), "scikit-learn");
}

// ── build_reverse ─────────────────────────────────────────────────────────────

#[test]
fn build_reverse_basic() {
    let fwd = make_forward(&[("a", &["b", "c"])]);
    let rev = build_reverse(&fwd);
    assert_eq!(rev.get("b"), Some(&vec!["a".to_string()]));
    assert_eq!(rev.get("c"), Some(&vec!["a".to_string()]));
    assert!(!rev.contains_key("a"));
}

#[test]
fn build_reverse_deduplicates() {
    let fwd = make_forward(&[("x", &["z"]), ("y", &["z"])]);
    let rev = build_reverse(&fwd);
    let mut parents = rev.get("z").cloned().unwrap_or_default();
    parents.sort();
    assert_eq!(parents, vec!["x", "y"]);
}

#[test]
fn build_reverse_sorted() {
    let fwd = make_forward(&[("c", &["z"]), ("a", &["z"]), ("b", &["z"])]);
    let rev = build_reverse(&fwd);
    assert_eq!(rev.get("z").unwrap(), &vec!["a", "b", "c"]);
}

#[test]
fn build_reverse_empty_graph() {
    let fwd: HashMap<String, Vec<String>> = HashMap::new();
    assert!(build_reverse(&fwd).is_empty());
}

#[test]
fn build_reverse_leaf_package() {
    let fwd = make_forward(&[("leaf", &[])]);
    assert!(build_reverse(&fwd).is_empty());
}

// ── uv.lock parser ────────────────────────────────────────────────────────────

const UV_LOCK_SAMPLE: &str = r#"
version = 1
requires-python = ">=3.11"

[[package]]
name = "my-project"
version = "0.1.0"
source = { virtual = "." }
dependencies = [
    { name = "requests" },
    { name = "httpx" },
]

[[package]]
name = "requests"
version = "2.31.0"
source = { registry = "https://pypi.org/simple" }
dependencies = [
    { name = "certifi" },
    { name = "idna" },
]

[[package]]
name = "httpx"
version = "0.28.0"
source = { registry = "https://pypi.org/simple" }
dependencies = [
    { name = "certifi" },
]

[[package]]
name = "certifi"
version = "2024.2.2"
source = { registry = "https://pypi.org/simple" }

[[package]]
name = "idna"
version = "3.4"
source = { registry = "https://pypi.org/simple" }
"#;

#[test]
fn uv_lock_parses_forward_graph() {
    let info = parse_uv_lock_content(UV_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert!(info.forward["requests"].contains(&"certifi".to_string()));
    assert!(info.forward["requests"].contains(&"idna".to_string()));
    assert!(info.forward["httpx"].contains(&"certifi".to_string()));
}

#[test]
fn uv_lock_detects_project_deps() {
    let info = parse_uv_lock_content(UV_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert!(info.project_deps.contains("requests"));
    assert!(info.project_deps.contains("httpx"));
    assert!(!info.project_deps.contains("certifi")); // transitive, not direct
}

#[test]
fn uv_lock_display_names_preserved() {
    let info = parse_uv_lock_content(UV_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert_eq!(info.display_names["requests"], "requests");
    assert_eq!(info.display_names["my-project"], "my-project");
}

#[test]
fn uv_lock_leaf_has_no_forward_deps() {
    let info = parse_uv_lock_content(UV_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert!(info.forward.get("certifi").map_or(true, |d| d.is_empty()));
}

#[test]
fn uv_lock_reverse_graph_is_correct() {
    let info = parse_uv_lock_content(UV_LOCK_SAMPLE, Path::new(".")).unwrap();
    let rev = build_reverse(&info.forward);
    // certifi is required by both requests and httpx
    let mut certifi_parents = rev.get("certifi").cloned().unwrap_or_default();
    certifi_parents.sort();
    assert_eq!(certifi_parents, vec!["httpx", "requests"]);
}

// ── poetry.lock parser ────────────────────────────────────────────────────────

const POETRY_LOCK_SAMPLE: &str = r#"
[[package]]
name = "flask"
version = "3.0.0"
description = "A simple framework for building complex web applications."
optional = false
python-versions = ">=3.8"
files = []

[package.dependencies]
click = ">=8.1.3"
itsdangerous = ">=2.1.2"
jinja2 = ">=3.1.2"
werkzeug = ">=3.0.0"

[[package]]
name = "jinja2"
version = "3.1.2"
description = "A very fast and expressive template engine."
optional = false
python-versions = ">=3.7"
files = []

[package.dependencies]
MarkupSafe = ">=2.0"

[[package]]
name = "MarkupSafe"
version = "2.1.3"
description = "Safely add untrusted strings to HTML/XML markup."
optional = false
python-versions = ">=3.7"
files = []

[[package]]
name = "click"
version = "8.1.7"
description = "Composable command line interface toolkit"
optional = false
python-versions = ">=3.7"
files = []

[[package]]
name = "werkzeug"
version = "3.0.1"
description = "The comprehensive WSGI web application library."
optional = false
python-versions = ">=3.8"
files = []

[[package]]
name = "itsdangerous"
version = "2.1.2"
description = "Safely pass data to untrusted environments and back."
optional = false
python-versions = ">=3.7"
files = []
"#;

const POETRY_PYPROJECT: &str = r#"
[tool.poetry]
name = "test-poetry-project"
version = "0.1.0"

[tool.poetry.dependencies]
python = "^3.11"
flask = "^3.0"

[tool.poetry.group.dev.dependencies]
pytest = "^7.0"
"#;

#[test]
fn poetry_lock_parses_forward_graph() {
    let info = parse_poetry_lock_content(POETRY_LOCK_SAMPLE, Path::new(".")).unwrap();
    let flask_deps = &info.forward["flask"];
    assert!(flask_deps.contains(&"click".to_string()));
    assert!(flask_deps.contains(&"jinja2".to_string()));
    assert!(flask_deps.contains(&"werkzeug".to_string()));
    assert!(flask_deps.contains(&"itsdangerous".to_string()));
}

#[test]
fn poetry_lock_normalizes_dep_names() {
    let info = parse_poetry_lock_content(POETRY_LOCK_SAMPLE, Path::new(".")).unwrap();
    // MarkupSafe → markupsafe after normalization
    assert!(info.forward["jinja2"].contains(&"markupsafe".to_string()));
}

#[test]
fn poetry_lock_skips_python_dep() {
    let info = parse_poetry_lock_content(POETRY_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert!(!info.forward.contains_key("python"));
    for deps in info.forward.values() {
        assert!(!deps.contains(&"python".to_string()));
    }
}

#[test]
fn poetry_lock_display_names_preserved() {
    let info = parse_poetry_lock_content(POETRY_LOCK_SAMPLE, Path::new(".")).unwrap();
    assert_eq!(info.display_names["markupsafe"], "MarkupSafe");
}

#[test]
fn poetry_lock_reverse_graph_correct() {
    let info = parse_poetry_lock_content(POETRY_LOCK_SAMPLE, Path::new(".")).unwrap();
    let rev = build_reverse(&info.forward);
    assert!(rev["jinja2"].contains(&"flask".to_string()));
    assert!(rev["markupsafe"].contains(&"jinja2".to_string()));
}

#[test]
fn poetry_direct_deps_main_and_dev_groups() {
    let dir = std::env::temp_dir().join("whydep_test_poetry_deps");
    let _ = std::fs::create_dir_all(&dir);
    std::fs::write(dir.join("pyproject.toml"), POETRY_PYPROJECT).unwrap();
    let deps = read_poetry_direct_deps(&dir);
    assert!(deps.contains("flask"));
    assert!(deps.contains("pytest")); // dev group
    assert!(!deps.contains("python")); // filtered out
    let _ = std::fs::remove_dir_all(&dir);
}
