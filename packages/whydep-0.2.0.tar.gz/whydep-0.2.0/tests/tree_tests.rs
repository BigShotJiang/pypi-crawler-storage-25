use std::collections::{HashMap, HashSet};
use std::path::PathBuf;

use whydep::tree::{TreeCtx, show_usage};

fn make_ctx<'a>(
    py_files: &'a [PathBuf],
    project_dir: &'a std::path::Path,
    reverse: &'a HashMap<String, Vec<String>>,
    display_names: &'a HashMap<String, String>,
    project_deps: &'a HashSet<String>,
) -> TreeCtx<'a> {
    TreeCtx {
        reverse,
        display_names,
        project_deps,
        py_files,
        site_packages: None,
        project_dir,
    }
}

fn write_py(dir: &std::path::Path, name: &str, content: &str) -> PathBuf {
    let path = dir.join(name);
    std::fs::write(&path, content).unwrap();
    path
}

// ── show_usage return value ───────────────────────────────────────────────────

#[test]
fn show_usage_returns_true_when_imported() {
    let dir = std::env::temp_dir().join("whydep_tree_test_imported");
    std::fs::create_dir_all(&dir).unwrap();
    let f = write_py(&dir, "app.py", "import requests\n");

    let reverse = HashMap::new();
    let display_names = HashMap::new();
    let project_deps = HashSet::new();
    let files = [f];
    let ctx = make_ctx(&files, &dir, &reverse, &display_names, &project_deps);
    assert!(show_usage("requests", "", &ctx));
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn show_usage_returns_false_when_not_imported() {
    let dir = std::env::temp_dir().join("whydep_tree_test_not_imported");
    std::fs::create_dir_all(&dir).unwrap();
    let f = write_py(&dir, "app.py", "import os\n");

    let reverse = HashMap::new();
    let display_names = HashMap::new();
    let project_deps = HashSet::new();
    let files = [f];
    let ctx = make_ctx(&files, &dir, &reverse, &display_names, &project_deps);
    assert!(!show_usage("requests", "", &ctx));
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn show_usage_returns_false_for_empty_py_files() {
    let dir = std::env::temp_dir().join("whydep_tree_test_empty");
    std::fs::create_dir_all(&dir).unwrap();

    let reverse = HashMap::new();
    let display_names = HashMap::new();
    let project_deps = HashSet::new();
    let ctx = make_ctx(&[], &dir, &reverse, &display_names, &project_deps);
    assert!(!show_usage("flask", "", &ctx));
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn show_usage_returns_true_for_from_import() {
    let dir = std::env::temp_dir().join("whydep_tree_test_from_import");
    std::fs::create_dir_all(&dir).unwrap();
    let f = write_py(&dir, "views.py", "from flask import Flask\n");

    let reverse = HashMap::new();
    let display_names = HashMap::new();
    let project_deps = HashSet::new();
    let files = [f];
    let ctx = make_ctx(&files, &dir, &reverse, &display_names, &project_deps);
    assert!(show_usage("flask", "", &ctx));
    let _ = std::fs::remove_dir_all(&dir);
}
