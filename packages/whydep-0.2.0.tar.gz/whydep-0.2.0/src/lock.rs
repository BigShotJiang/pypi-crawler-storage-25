use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::{Path, PathBuf};

// ── Public types ─────────────────────────────────────────────────────────────

pub struct LockInfo {
    pub forward: HashMap<String, Vec<String>>,
    pub display_names: HashMap<String, String>,
    /// Normalized names of packages directly required by the project root
    pub project_deps: HashSet<String>,
    /// Directory containing the lock file (the project root)
    pub project_dir: PathBuf,
}

/// Which lock file format was detected.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum LockKind {
    Uv,
    Poetry,
}

impl LockKind {
    pub fn file_name(self) -> &'static str {
        match self {
            LockKind::Uv => "uv.lock",
            LockKind::Poetry => "poetry.lock",
        }
    }
}

// ── Normalization ─────────────────────────────────────────────────────────────

/// Normalize a package name: lowercase, underscores/dots → hyphen.
pub fn normalize(name: &str) -> String {
    name.to_lowercase().replace(['_', '.'], "-")
}

// ── Lock-file discovery ───────────────────────────────────────────────────────

/// Search for a supported lock file starting at `dir`, walking up to 3 parent
/// levels.  `uv.lock` is preferred over `poetry.lock` when both exist.
pub fn find_lock_file(dir: &Path) -> Option<(PathBuf, LockKind)> {
    let mut current = dir.to_path_buf();
    for _ in 0..4 {
        if current.join("uv.lock").exists() {
            return Some((current.join("uv.lock"), LockKind::Uv));
        }
        if current.join("poetry.lock").exists() {
            return Some((current.join("poetry.lock"), LockKind::Poetry));
        }
        if !current.pop() {
            break;
        }
    }
    None
}

// ── Dispatcher ────────────────────────────────────────────────────────────────

pub fn parse_lock_file(path: &Path, kind: LockKind) -> Result<LockInfo, String> {
    match kind {
        LockKind::Uv => parse_uv_lock(path),
        LockKind::Poetry => parse_poetry_lock(path),
    }
}

// ── uv.lock parser ────────────────────────────────────────────────────────────

/// Parse a `uv.lock` file.
///
/// Each `[[package]]` entry uses:
/// ```toml
/// dependencies = [{ name = "foo" }, { name = "bar" }]
/// ```
/// The project's own package is identified by `source = { virtual = "." }`.
pub fn parse_uv_lock(lock_path: &Path) -> Result<LockInfo, String> {
    let content = fs::read_to_string(lock_path).map_err(|e| e.to_string())?;
    parse_uv_lock_content(&content, lock_path.parent().unwrap_or(Path::new(".")))
}

pub fn parse_uv_lock_content(content: &str, project_dir: &Path) -> Result<LockInfo, String> {
    let doc: toml::Value = toml::from_str(content).map_err(|e| e.to_string())?;

    let packages = doc
        .get("package")
        .and_then(|v| v.as_array())
        .ok_or("No [[package]] entries found in uv.lock")?;

    let mut forward: HashMap<String, Vec<String>> = HashMap::new();
    let mut display_names: HashMap<String, String> = HashMap::new();
    let mut project_deps: HashSet<String> = HashSet::new();

    for pkg in packages {
        let name = match pkg.get("name").and_then(|v| v.as_str()) {
            Some(n) => n,
            None => continue,
        };
        let key = normalize(name);
        display_names
            .entry(key.clone())
            .or_insert_with(|| name.to_string());

        let deps: Vec<String> = pkg
            .get("dependencies")
            .and_then(|v| v.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|d| d.get("name").and_then(|n| n.as_str()))
                    .map(normalize)
                    .collect()
            })
            .unwrap_or_default();

        if pkg.get("source").and_then(|s| s.get("virtual")).is_some() {
            project_deps.extend(deps.iter().cloned());
        }

        forward.entry(key).or_default().extend(deps);
    }

    Ok(LockInfo {
        forward,
        display_names,
        project_deps,
        project_dir: project_dir.to_path_buf(),
    })
}

// ── poetry.lock parser ────────────────────────────────────────────────────────

/// Parse a `poetry.lock` file.
///
/// Each `[[package]]` entry uses a *table* for dependencies:
/// ```toml
/// [package.dependencies]
/// certifi = ">=2017.4.17"
/// charset-normalizer = ">=2,<4"
/// ```
/// Values may also be inline tables `{version = "...", optional = true}` or
/// arrays of such tables for platform-conditional specs — in all cases we only
/// need the *key* (the dependency name).
///
/// Direct project deps are read from `pyproject.toml` because the project
/// itself does not appear in `poetry.lock`.
pub fn parse_poetry_lock(lock_path: &Path) -> Result<LockInfo, String> {
    let content = fs::read_to_string(lock_path).map_err(|e| e.to_string())?;
    let project_dir = lock_path.parent().unwrap_or(Path::new("."));
    parse_poetry_lock_content(&content, project_dir)
}

pub fn parse_poetry_lock_content(content: &str, project_dir: &Path) -> Result<LockInfo, String> {
    let doc: toml::Value = toml::from_str(content).map_err(|e| e.to_string())?;

    let packages = doc
        .get("package")
        .and_then(|v| v.as_array())
        .ok_or("No [[package]] entries found in poetry.lock")?;

    let mut forward: HashMap<String, Vec<String>> = HashMap::new();
    let mut display_names: HashMap<String, String> = HashMap::new();

    for pkg in packages {
        let name = match pkg.get("name").and_then(|v| v.as_str()) {
            Some(n) => n,
            None => continue,
        };
        let key = normalize(name);
        display_names
            .entry(key.clone())
            .or_insert_with(|| name.to_string());

        // [package.dependencies] is a table: dep_name → version_spec
        // The version spec may be a string, an inline table, or an array of
        // inline tables (for conditional/platform deps) — we only need the key.
        let deps: Vec<String> = pkg
            .get("dependencies")
            .and_then(|v| v.as_table())
            .map(|table| {
                table
                    .keys()
                    .filter(|k| k.to_lowercase() != "python")
                    .map(|k| normalize(k))
                    .collect()
            })
            .unwrap_or_default();

        forward.entry(key).or_default().extend(deps);
    }

    let project_deps = read_poetry_direct_deps(project_dir);

    Ok(LockInfo {
        forward,
        display_names,
        project_deps,
        project_dir: project_dir.to_path_buf(),
    })
}

/// Read direct project dependencies from `[tool.poetry.dependencies]`,
/// `[tool.poetry.dev-dependencies]` (old format), and
/// `[tool.poetry.group.*.dependencies]` (new group format).
pub fn read_poetry_direct_deps(project_dir: &Path) -> HashSet<String> {
    let pyproject = project_dir.join("pyproject.toml");
    let Ok(content) = fs::read_to_string(&pyproject) else {
        return HashSet::new();
    };
    let Ok(doc) = toml::from_str::<toml::Value>(&content) else {
        return HashSet::new();
    };

    let mut deps = HashSet::new();

    let Some(poetry) = doc.get("tool").and_then(|t| t.get("poetry")) else {
        return deps;
    };

    // [tool.poetry.dependencies]
    collect_table_keys(poetry.get("dependencies"), &mut deps);

    // [tool.poetry.dev-dependencies]  (Poetry <1.2 format)
    collect_table_keys(poetry.get("dev-dependencies"), &mut deps);

    // [tool.poetry.group.NAME.dependencies]  (Poetry >=1.2 format)
    if let Some(groups) = poetry.get("group").and_then(|v| v.as_table()) {
        for group_val in groups.values() {
            collect_table_keys(group_val.get("dependencies"), &mut deps);
        }
    }

    deps
}

/// Insert the keys of a TOML table into `set`, normalizing each key.
/// Skips the special `python` key that poetry uses for the interpreter version.
fn collect_table_keys(val: Option<&toml::Value>, set: &mut HashSet<String>) {
    if let Some(table) = val.and_then(|v| v.as_table()) {
        for key in table.keys() {
            if key.to_lowercase() != "python" {
                set.insert(normalize(key));
            }
        }
    }
}

// ── Reverse graph ─────────────────────────────────────────────────────────────

/// Invert the forward dependency graph: dep → sorted list of packages that
/// require it.  Results are deduplicated for deterministic output.
pub fn build_reverse(forward: &HashMap<String, Vec<String>>) -> HashMap<String, Vec<String>> {
    let mut reverse: HashMap<String, HashSet<String>> = HashMap::new();
    for (pkg, deps) in forward {
        for dep in deps {
            reverse.entry(dep.clone()).or_default().insert(pkg.clone());
        }
    }
    reverse
        .into_iter()
        .map(|(k, v)| {
            let mut parents: Vec<String> = v.into_iter().collect();
            parents.sort();
            (k, parents)
        })
        .collect()
}
