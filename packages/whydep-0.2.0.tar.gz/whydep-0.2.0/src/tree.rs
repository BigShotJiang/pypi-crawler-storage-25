use std::collections::{HashMap, HashSet};
use std::io::IsTerminal;
use std::path::{Path, PathBuf};

use crate::scan::{find_usages, get_import_names};

/// All context needed to print the reverse-dependency tree.
pub struct TreeCtx<'a> {
    pub reverse: &'a HashMap<String, Vec<String>>,
    pub display_names: &'a HashMap<String, String>,
    /// Normalized names of packages that the project directly depends on
    pub project_deps: &'a HashSet<String>,
    pub py_files: &'a [PathBuf],
    pub site_packages: Option<&'a PathBuf>,
    pub project_dir: &'a Path,
}

/// Build a `file://` URI from an absolute path (handles Windows backslashes).
fn file_uri(path: &Path) -> String {
    let s = path.to_string_lossy().replace('\\', "/");
    if s.starts_with('/') {
        format!("file://{s}")
    } else {
        format!("file:///{s}")
    }
}

/// Wrap `text` in an OSC 8 hyperlink if stdout is a TTY, otherwise return plain text.
fn hyperlink(uri: &str, text: &str) -> String {
    if std::io::stdout().is_terminal() {
        format!("\x1b]8;;{uri}\x1b\\{text}\x1b]8;;\x1b\\")
    } else {
        text.to_string()
    }
}

/// Print import-usage lines for `pkg` prefixed with `prefix`.
/// Returns `true` if any usages were found.
pub fn show_usage(pkg: &str, prefix: &str, ctx: &TreeCtx) -> bool {
    let sp = ctx.site_packages.map(|p| p.as_path());
    let import_names = get_import_names(pkg, sp);
    let hits = find_usages(&import_names, ctx.py_files);

    if hits.is_empty() {
        println!(
            "{}· (not directly imported — may be aliased or dynamically imported)",
            prefix
        );
        return false;
    }

    for hit in &hits {
        let rel = hit.file.strip_prefix(ctx.project_dir).unwrap_or(&hit.file);
        let link_text = format!("{}:{}", rel.display(), hit.line_num);
        let linked = hyperlink(&file_uri(&hit.file), &link_text);
        println!("{}· {}: {}", prefix, linked, hit.line);
    }
    true
}

/// Recursively print the reverse-dependency tree for `pkg`.
///
/// - `visited`    — prevents infinite loops and duplicate subtrees
/// - `usage_shown` — ensures usage lines are printed at most once per package
/// - `is_root`    — suppresses the "(project root)" label for the query target
pub fn print_tree(
    pkg: &str,
    ctx: &TreeCtx,
    visited: &mut HashSet<String>,
    usage_shown: &mut HashSet<String>,
    prefix: &str,
    is_root: bool,
) {
    let parents = match ctx.reverse.get(pkg) {
        Some(p) if !p.is_empty() => p.clone(),
        _ => {
            if !is_root {
                println!("{}└── (project root)", prefix);
            }
            return;
        }
    };

    let count = parents.len();
    for (i, parent) in parents.iter().enumerate() {
        let is_last = i + 1 == count;
        let branch = if is_last { "└── " } else { "├── " };
        let display = ctx
            .display_names
            .get(parent)
            .map(|s| s.as_str())
            .unwrap_or(parent);

        println!("{}{}{}", prefix, branch, display);

        let child_prefix = format!("{}{}", prefix, if is_last { "    " } else { "│   " });

        if visited.contains(parent) {
            println!("{}└── (already shown above)", child_prefix);
            continue;
        }
        visited.insert(parent.clone());

        // Show file usage for direct project deps (only the first time)
        if ctx.project_deps.contains(parent) && !usage_shown.contains(parent) {
            usage_shown.insert(parent.clone());
            let _ = show_usage(parent, &child_prefix, ctx);
        }

        print_tree(parent, ctx, visited, usage_shown, &child_prefix, false);
    }
}
