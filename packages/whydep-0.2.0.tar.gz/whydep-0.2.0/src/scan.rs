use std::fs;
use std::path::{Path, PathBuf};

// ── Import names ─────────────────────────────────────────────────────────────

/// Resolve the importable module name(s) for a normalized package name.
///
/// Reads `top_level.txt` from the dist-info directory so that packages whose
/// import name differs from their PyPI name (e.g. `pillow` → `PIL`,
/// `scikit-learn` → `sklearn`) are handled automatically.
///
/// Falls back to the underscore form (and the original) if no dist-info is
/// found or `top_level.txt` is absent.
pub fn get_import_names(pkg_norm: &str, site_packages: Option<&Path>) -> Vec<String> {
    if let Some(sp) = site_packages {
        // dist-info dirs normalise dashes to underscores in the name portion
        let pkg_under = pkg_norm.replace('-', "_");
        if let Ok(entries) = fs::read_dir(sp) {
            for entry in entries.flatten() {
                let dir_name = entry.file_name().to_string_lossy().to_string();
                if !dir_name.ends_with(".dist-info") {
                    continue;
                }
                // Stem: "requests-2.31.0" or "scikit_learn-1.4.0"
                let stem = dir_name.trim_end_matches(".dist-info");
                if let Some(dash) = stem.rfind('-') {
                    let dist_pkg = stem[..dash].to_lowercase();
                    if dist_pkg == pkg_norm || dist_pkg == pkg_under {
                        let top = entry.path().join("top_level.txt");
                        if let Ok(content) = fs::read_to_string(top) {
                            let names: Vec<String> = content
                                .lines()
                                .map(|l| l.trim().to_string())
                                .filter(|l| !l.is_empty())
                                .collect();
                            if !names.is_empty() {
                                return names;
                            }
                        }
                    }
                }
            }
        }
    }
    // Fallback: underscore form (primary) + hyphen form
    let under = pkg_norm.replace('-', "_");
    if under != pkg_norm {
        vec![under, pkg_norm.to_string()]
    } else {
        vec![pkg_norm.to_string()]
    }
}

// ── Src-dir config ───────────────────────────────────────────────────────────

/// Read `[tool.whydep] src` from the project's `pyproject.toml`.
///
/// Returns a list of directories to scan, resolved relative to `project_dir`.
/// Falls back to `project_dir` itself when the setting is absent or the file
/// cannot be read.
///
/// `src` may be a single string or an array of strings:
/// ```toml
/// [tool.whydep]
/// src = "src"
/// # or
/// src = ["src", "tests"]
/// ```
pub fn read_src_dirs(project_dir: &Path) -> Vec<PathBuf> {
    let pyproject = project_dir.join("pyproject.toml");
    if let Ok(content) = fs::read_to_string(&pyproject)
        && let Ok(doc) = toml::from_str::<toml::Value>(&content)
        && let Some(src) = doc
            .get("tool")
            .and_then(|t| t.get("whydep"))
            .and_then(|p| p.get("src"))
    {
        let raw: Vec<&str> = match src {
            toml::Value::String(s) => vec![s.as_str()],
            toml::Value::Array(arr) => arr.iter().filter_map(|v| v.as_str()).collect(),
            _ => vec![],
        };
        let dirs: Vec<PathBuf> = raw
            .iter()
            .map(|s| project_dir.join(s))
            .filter(|p| p.exists())
            .collect();
        if !dirs.is_empty() {
            return dirs;
        }
    }
    vec![project_dir.to_path_buf()]
}

// ── File discovery ───────────────────────────────────────────────────────────

const SKIP_DIRS: &[&str] = &[
    ".venv",
    "venv",
    "env",
    ".env",
    "__pycache__",
    ".git",
    "node_modules",
    "target",
    "dist",
    "build",
    ".tox",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".hypothesis",
];

/// Recursively collect all `.py` files under `dir`, skipping generated /
/// environment directories.
pub fn find_py_files(dir: &Path) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let Ok(entries) = fs::read_dir(dir) else {
        return out;
    };
    for entry in entries.flatten() {
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if path.is_dir() {
            if SKIP_DIRS.contains(&name.as_str()) || name.ends_with(".egg-info") {
                continue;
            }
            out.extend(find_py_files(&path));
        } else if name.ends_with(".py") {
            out.push(path);
        }
    }
    out
}

// ── Venv discovery ───────────────────────────────────────────────────────────

/// Find the `site-packages` directory inside a project's virtual environment.
/// Checks `.venv`, `venv`, and `env` in `project_dir` and handles both Windows
/// (`Lib/site-packages`) and Unix (`lib/pythonX.Y/site-packages`) layouts.
pub fn find_venv_site_packages(project_dir: &Path) -> Option<PathBuf> {
    for venv_name in &[".venv", "venv", "env"] {
        let venv = project_dir.join(venv_name);
        if !venv.exists() {
            continue;
        }
        // Windows
        let win = venv.join("Lib").join("site-packages");
        if win.exists() {
            return Some(win);
        }
        // Unix
        if let Ok(entries) = fs::read_dir(venv.join("lib")) {
            for entry in entries.flatten() {
                if entry.file_name().to_string_lossy().starts_with("python") {
                    let sp = entry.path().join("site-packages");
                    if sp.exists() {
                        return Some(sp);
                    }
                }
            }
        }
    }
    None
}

// ── Import detection ─────────────────────────────────────────────────────────

/// A single import statement found in a source file.
pub struct ImportHit {
    pub file: PathBuf,
    pub line_num: usize,
    pub line: String,
}

/// Returns `true` if `trimmed` is an import statement that references any name
/// in `names`.
///
/// Recognised forms:
/// - `import foo`
/// - `import foo.bar`
/// - `import foo as alias`
/// - `import foo, bar`
/// - `from foo import …`
/// - `from foo.sub import …`
/// - `importlib.import_module("foo")`
/// - `__import__("foo")`
/// - `lazy_loader` patterns (best-effort string match)
///
/// Does **not** match:
/// - Lines starting with `#`
/// - Partial names (`import foobar` does not match `foo`)
pub fn line_imports(trimmed: &str, names: &[String]) -> bool {
    if trimmed.starts_with('#') || trimmed.is_empty() {
        return false;
    }
    for name in names {
        // `import foo` / `import foo.sub` / `import foo as x` / `import a, foo, b`
        // Split on commas so secondary names in multi-import lines are caught.
        if let Some(rest) = trimmed.strip_prefix("import ") {
            for segment in rest.split(',') {
                // Each segment may be "foo", "foo.bar", "foo as alias", " foo", …
                let seg_name = segment.trim().split([' ', '\t', '.']).next().unwrap_or("");
                if seg_name == name.as_str() {
                    return true;
                }
            }
        }

        // `from foo import …` / `from foo.sub import …`
        let from_prefix = format!("from {}", name);
        if trimmed.starts_with(&from_prefix) {
            let rest = &trimmed[from_prefix.len()..];
            if matches!(rest.chars().next(), Some(' ') | Some('\t') | Some('.')) {
                return true;
            }
        }

        // Dynamic: importlib.import_module("foo") / __import__("foo") / lazy_loader
        let in_dq = format!("\"{}\"", name);
        let in_sq = format!("'{}'", name);
        if (trimmed.contains("import_module(")
            || trimmed.contains("__import__(")
            || trimmed.contains("lazy_loader"))
            && (trimmed.contains(&in_dq) || trimmed.contains(&in_sq))
        {
            return true;
        }
    }
    false
}

/// Scan `py_files` and return every line that imports one of `import_names`.
pub fn find_usages(import_names: &[String], py_files: &[PathBuf]) -> Vec<ImportHit> {
    let mut hits = Vec::new();
    for file in py_files {
        let Ok(content) = fs::read_to_string(file) else {
            continue;
        };
        for (i, line) in content.lines().enumerate() {
            if line_imports(line.trim(), import_names) {
                hits.push(ImportHit {
                    file: file.clone(),
                    line_num: i + 1,
                    line: line.trim().to_string(),
                });
            }
        }
    }
    hits
}
