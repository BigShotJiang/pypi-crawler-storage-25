"""Regression tests for the finite-field dihedral FFT."""

from __future__ import annotations

import pytest

from fft_dihedral import (
    DEFAULT_MODULUS,
    cyclic_transform_naive,
    dihedral_dft_fft,
    dihedral_dft_naive,
    dihedral_inverse_fft,
    dihedral_multiply_fft,
    dihedral_multiply_naive,
    flatten_transform,
    inverse_ntt,
    multiply_fourier_transforms,
    ntt,
    random_dihedral_function,
    root_of_unity,
)


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64])
def test_ntt_matches_naive_cyclic_transform(n: int) -> None:
    omega = root_of_unity(n)
    values = [(17 * k * k + 5 * k + 11) % DEFAULT_MODULUS for k in range(n)]

    assert ntt(values, omega, DEFAULT_MODULUS) == cyclic_transform_naive(
        values, omega, DEFAULT_MODULUS
    )


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64])
def test_inverse_ntt_round_trip(n: int) -> None:
    omega = root_of_unity(n)
    values = [(31 * k + 7) % DEFAULT_MODULUS for k in range(n)]

    transformed = ntt(values, omega, DEFAULT_MODULUS)
    assert inverse_ntt(transformed, omega, DEFAULT_MODULUS) == values


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64, 128])
def test_dihedral_inverse_fft_round_trip(n: int) -> None:
    omega = root_of_unity(n)
    for seed in range(5):
        rotations, reflections = random_dihedral_function(
            n,
            DEFAULT_MODULUS,
            seed=30_000 * n + seed,
        )
        transform = dihedral_dft_fft(rotations, reflections, DEFAULT_MODULUS, omega)

        assert dihedral_inverse_fft(transform, omega) == (rotations, reflections)


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64, 128])
def test_dihedral_fft_matches_naive_dft_for_random_inputs(n: int) -> None:
    omega = root_of_unity(n)
    for seed in range(5):
        rotations, reflections = random_dihedral_function(
            n,
            DEFAULT_MODULUS,
            seed=10_000 * n + seed,
        )

        naive = flatten_transform(
            dihedral_dft_naive(rotations, reflections, DEFAULT_MODULUS, omega)
        )
        fast = flatten_transform(
            dihedral_dft_fft(rotations, reflections, DEFAULT_MODULUS, omega)
        )

        assert fast == naive


@pytest.mark.parametrize("n", [4, 8, 16, 32])
def test_dihedral_fft_matches_naive_dft_for_structured_inputs(n: int) -> None:
    omega = root_of_unity(n)
    rotations = [0] * n
    reflections = [0] * n
    rotations[0] = 1
    reflections[1] = 1

    assert flatten_transform(
        dihedral_dft_fft(rotations, reflections, DEFAULT_MODULUS, omega)
    ) == flatten_transform(
        dihedral_dft_naive(rotations, reflections, DEFAULT_MODULUS, omega)
    )


def test_naive_multiplication_uses_dihedral_group_law() -> None:
    n = 8
    modulus = 97
    zero = [0] * n
    r = [0] * n
    r[1] = 1
    s = [0] * n
    s[0] = 1

    _, r_times_s_reflections = dihedral_multiply_naive(r, zero, zero, s, modulus)
    _, s_times_r_reflections = dihedral_multiply_naive(zero, s, r, zero, modulus)

    expected_r_times_s = [0] * n
    expected_r_times_s[n - 1] = 1
    expected_s_times_r = [0] * n
    expected_s_times_r[1] = 1

    assert r_times_s_reflections == expected_r_times_s
    assert s_times_r_reflections == expected_s_times_r


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64])
def test_multiplying_fourier_transforms_matches_transform_of_product(n: int) -> None:
    omega = root_of_unity(n)
    lhs_rotations, lhs_reflections = random_dihedral_function(
        n,
        DEFAULT_MODULUS,
        seed=40_000 * n,
    )
    rhs_rotations, rhs_reflections = random_dihedral_function(
        n,
        DEFAULT_MODULUS,
        seed=50_000 * n,
    )
    product_rotations, product_reflections = dihedral_multiply_naive(
        lhs_rotations,
        lhs_reflections,
        rhs_rotations,
        rhs_reflections,
        DEFAULT_MODULUS,
    )

    lhs_transform = dihedral_dft_fft(
        lhs_rotations,
        lhs_reflections,
        DEFAULT_MODULUS,
        omega,
    )
    rhs_transform = dihedral_dft_fft(
        rhs_rotations,
        rhs_reflections,
        DEFAULT_MODULUS,
        omega,
    )
    product_transform = dihedral_dft_fft(
        product_rotations,
        product_reflections,
        DEFAULT_MODULUS,
        omega,
    )

    assert flatten_transform(
        multiply_fourier_transforms(lhs_transform, rhs_transform)
    ) == flatten_transform(product_transform)


@pytest.mark.parametrize("n", [4, 8, 16, 32, 64])
def test_dihedral_multiply_fft_matches_naive_group_algebra_product(n: int) -> None:
    omega = root_of_unity(n)
    for seed in range(3):
        lhs_rotations, lhs_reflections = random_dihedral_function(
            n,
            DEFAULT_MODULUS,
            seed=60_000 * n + seed,
        )
        rhs_rotations, rhs_reflections = random_dihedral_function(
            n,
            DEFAULT_MODULUS,
            seed=70_000 * n + seed,
        )

        assert dihedral_multiply_fft(
            lhs_rotations,
            lhs_reflections,
            rhs_rotations,
            rhs_reflections,
            DEFAULT_MODULUS,
            omega,
        ) == dihedral_multiply_naive(
            lhs_rotations,
            lhs_reflections,
            rhs_rotations,
            rhs_reflections,
            DEFAULT_MODULUS,
        )


@pytest.mark.parametrize("n", [4, 8, 16, 32])
def test_dihedral_multiply_fft_respects_identity(n: int) -> None:
    omega = root_of_unity(n)
    rotations, reflections = random_dihedral_function(
        n,
        DEFAULT_MODULUS,
        seed=80_000 * n,
    )
    identity_rotations = [0] * n
    identity_rotations[0] = 1
    identity_reflections = [0] * n

    assert dihedral_multiply_fft(
        rotations,
        reflections,
        identity_rotations,
        identity_reflections,
        DEFAULT_MODULUS,
        omega,
    ) == (rotations, reflections)
    assert dihedral_multiply_fft(
        identity_rotations,
        identity_reflections,
        rotations,
        reflections,
        DEFAULT_MODULUS,
        omega,
    ) == (rotations, reflections)


@pytest.mark.parametrize("modulus,n", [(17, 8), (97, 16), (257, 64)])
def test_dihedral_fft_accepts_other_compatible_primes(modulus: int, n: int) -> None:
    omega = root_of_unity(n, modulus)
    rotations, reflections = random_dihedral_function(n, modulus, seed=modulus + n)

    assert ntt(rotations, omega, modulus) == cyclic_transform_naive(
        rotations, omega, modulus
    )
    assert flatten_transform(
        dihedral_dft_fft(rotations, reflections, modulus, omega)
    ) == flatten_transform(dihedral_dft_naive(rotations, reflections, modulus, omega))
    assert dihedral_inverse_fft(
        dihedral_dft_fft(rotations, reflections, modulus, omega),
        omega,
    ) == (rotations, reflections)


def test_two_dimensional_coefficients_are_assembled_from_ntts() -> None:
    n = 64
    modulus = 257
    omega = root_of_unity(n, modulus)
    inv_omega = pow(omega, -1, modulus)
    inv_group_order = pow(2 * n, -1, modulus)
    rotations, reflections = random_dihedral_function(n, modulus, seed=20_000)

    positive_rotations = ntt(rotations, omega, modulus)
    negative_rotations = ntt(rotations, inv_omega, modulus)
    positive_reflections = ntt(reflections, omega, modulus)
    negative_reflections = ntt(reflections, inv_omega, modulus)
    transform = dihedral_dft_fft(rotations, reflections, modulus, omega)

    for j, matrix in transform.two_dimensional:
        assert matrix == (
            (
                positive_rotations[j] * inv_group_order % modulus,
                negative_reflections[j] * inv_group_order % modulus,
            ),
            (
                positive_reflections[j] * inv_group_order % modulus,
                negative_rotations[j] * inv_group_order % modulus,
            ),
        )


def test_non_prime_modulus_is_rejected() -> None:
    with pytest.raises(ValueError, match="modulus must be prime"):
        root_of_unity(8, 17 * 17)
