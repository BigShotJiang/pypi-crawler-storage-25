"""Benchmark plotting for ``fft-dihedral``."""

from __future__ import annotations

import argparse
import math
import os
from pathlib import Path

from .core import DEFAULT_MODULUS, benchmark, print_benchmark


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Benchmark and plot finite-field dihedral DFT timings."
    )
    parser.add_argument("--min-exp", type=int, default=4, help="smallest n=2^exp")
    parser.add_argument("--max-exp", type=int, default=13, help="largest n=2^exp")
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument(
        "--naive-limit",
        type=int,
        default=1024,
        help="also time the naive DFT for n up to this value",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--modulus", type=int, default=DEFAULT_MODULUS)
    parser.add_argument("--primitive-root", type=int, default=None)
    parser.add_argument("--output", default="dihedral_fft_timing.png")
    parser.add_argument("--svg-output", default="dihedral_fft_timing.svg")
    parser.add_argument("--scaling-output", default="dihedral_fft_scaling.png")
    parser.add_argument("--scaling-svg-output", default="dihedral_fft_scaling.svg")
    return parser.parse_args()


def loglog_slope(xs: list[float], ys: list[float]) -> float:
    import numpy as np

    log_xs = np.log(xs)
    log_ys = np.log(ys)
    slope, _ = np.polyfit(log_xs, log_ys, 1)
    return float(slope)


def main() -> None:
    os.environ.setdefault(
        "MPLCONFIGDIR",
        str(Path.cwd() / ".mplconfig"),
    )
    os.environ.setdefault(
        "XDG_CACHE_HOME",
        str(Path.cwd() / ".cache"),
    )

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    args = parse_args()
    rows = benchmark(
        range(args.min_exp, args.max_exp + 1),
        modulus=args.modulus,
        primitive_root=args.primitive_root,
        repetitions=args.repetitions,
        naive_limit=args.naive_limit,
        seed=args.seed,
    )
    print_benchmark(rows)

    group_orders = [row["group_order"] for row in rows]
    fft_seconds = [row["fft_seconds"] for row in rows]

    naive_rows = [row for row in rows if row["naive_seconds"] is not None]
    naive_group_orders = [row["group_order"] for row in naive_rows]
    naive_seconds = [row["naive_seconds"] for row in naive_rows]
    fft_slope = loglog_slope(group_orders, fft_seconds)
    naive_slope = loglog_slope(naive_group_orders, naive_seconds)

    plt.style.use("seaborn-v0_8-whitegrid")
    fig, ax = plt.subplots(figsize=(10, 6), constrained_layout=True)
    ax.loglog(
        group_orders,
        fft_seconds,
        marker="o",
        linewidth=2.5,
        label="Fast dihedral DFT: four radix-2 NTTs",
    )
    ax.loglog(
        naive_group_orders,
        naive_seconds,
        marker="o",
        linewidth=2.5,
        label="Naive dihedral DFT",
    )

    ax.set_title("Dihedral DFT over GF(p): naive versus fast")
    ax.set_xlabel(r"group order $|D_{2n}| = 2n$")
    ax.set_ylabel("median runtime (seconds)")
    ax.legend(
        title=(f"log-log fit slopes: fast {fft_slope:.2f}, naive {naive_slope:.2f}")
    )

    output = Path(args.output)
    svg_output = Path(args.svg_output)
    fig.savefig(output, dpi=180)
    fig.savefig(svg_output)
    print(f"\nWrote {output}")
    print(f"Wrote {svg_output}")

    fft_scaled = [
        seconds / (order * math.log2(order))
        for order, seconds in zip(group_orders, fft_seconds, strict=True)
    ]
    naive_scaled = [
        seconds / (order * order)
        for order, seconds in zip(naive_group_orders, naive_seconds, strict=True)
    ]
    speedups = [row["speedup"] for row in naive_rows if row["speedup"] is not None]

    scaling_fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    raw_ax, fft_ax, naive_ax, speedup_ax = axes.ravel()

    raw_ax.loglog(group_orders, fft_seconds, marker="o", label="fast")
    raw_ax.loglog(naive_group_orders, naive_seconds, marker="o", label="naive")
    raw_ax.set_title("Raw timings")
    raw_ax.set_xlabel(r"$N = |D_{2n}|$")
    raw_ax.set_ylabel("seconds")
    raw_ax.legend()

    fft_ax.semilogx(group_orders, fft_scaled, marker="o")
    fft_ax.set_title(r"FFT normalized by $N \log_2 N$")
    fft_ax.set_xlabel(r"$N = |D_{2n}|$")
    fft_ax.set_ylabel(r"seconds / $(N \log_2 N)$")

    naive_ax.semilogx(naive_group_orders, naive_scaled, marker="o", color="C1")
    naive_ax.set_title(r"Naive normalized by $N^2$")
    naive_ax.set_xlabel(r"$N = |D_{2n}|$")
    naive_ax.set_ylabel(r"seconds / $N^2$")

    speedup_ax.semilogx(naive_group_orders, speedups, marker="o", color="C2")
    speedup_ax.set_title("Measured speedup where both were timed")
    speedup_ax.set_xlabel(r"$N = |D_{2n}|$")
    speedup_ax.set_ylabel("naive / fast")

    scaling_output = Path(args.scaling_output)
    scaling_svg_output = Path(args.scaling_svg_output)
    scaling_fig.savefig(scaling_output, dpi=180)
    scaling_fig.savefig(scaling_svg_output)
    print(f"Wrote {scaling_output}")
    print(f"Wrote {scaling_svg_output}")
    print(f"\nLog-log fit slope, fast:  {fft_slope:.3f}")
    print(f"Log-log fit slope, naive: {naive_slope:.3f}")


if __name__ == "__main__":
    main()
