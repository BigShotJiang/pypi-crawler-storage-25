"""Command-line interface for ``fft-dihedral``."""

from __future__ import annotations

import argparse

from .core import (
    DEFAULT_MODULUS,
    assert_transforms_match,
    benchmark,
    benchmark_multiplication,
    print_benchmark,
    print_multiplication_benchmark,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Finite-field FFT for the dihedral group D_{2n}."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    verify = subparsers.add_parser("verify", help="compare naive and FFT outputs")
    verify.add_argument("--n", type=int, default=16, help="rotation order")
    verify.add_argument("--seed", type=int, default=0)
    verify.add_argument("--modulus", type=int, default=DEFAULT_MODULUS)
    verify.add_argument("--omega", type=int, default=None)
    verify.add_argument("--primitive-root", type=int, default=None)

    bench = subparsers.add_parser(
        "bench",
        help="time the FFT over several powers of two",
    )
    bench.add_argument("--min-exp", type=int, default=4, help="smallest n=2^exp")
    bench.add_argument("--max-exp", type=int, default=15, help="largest n=2^exp")
    bench.add_argument("--repetitions", type=int, default=5)
    bench.add_argument("--seed", type=int, default=0)
    bench.add_argument(
        "--naive-limit",
        type=int,
        default=512,
        help="also time the naive DFT for n up to this value",
    )
    bench.add_argument("--modulus", type=int, default=DEFAULT_MODULUS)
    bench.add_argument("--primitive-root", type=int, default=None)

    bench_mul = subparsers.add_parser(
        "bench-mul",
        help="time group-algebra multiplication over several powers of two",
    )
    bench_mul.add_argument("--min-exp", type=int, default=4, help="smallest n=2^exp")
    bench_mul.add_argument("--max-exp", type=int, default=12, help="largest n=2^exp")
    bench_mul.add_argument("--repetitions", type=int, default=5)
    bench_mul.add_argument("--seed", type=int, default=0)
    bench_mul.add_argument(
        "--naive-limit",
        type=int,
        default=512,
        help="also time the naive product for n up to this value",
    )
    bench_mul.add_argument("--modulus", type=int, default=DEFAULT_MODULUS)
    bench_mul.add_argument("--primitive-root", type=int, default=None)

    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "verify":
        assert_transforms_match(
            args.n,
            modulus=args.modulus,
            seed=args.seed,
            omega=args.omega,
            primitive_root=args.primitive_root,
        )
        print(
            f"OK: DFT, inverse FFT, and multiplication agree for "
            f"D_{2 * args.n} with n={args.n} modulo {args.modulus}."
        )
        return

    benchmark_fn = (
        benchmark_multiplication if args.command == "bench-mul" else benchmark
    )
    print_fn = (
        print_multiplication_benchmark
        if args.command == "bench-mul"
        else print_benchmark
    )
    rows = benchmark_fn(
        range(args.min_exp, args.max_exp + 1),
        modulus=args.modulus,
        primitive_root=args.primitive_root,
        repetitions=args.repetitions,
        seed=args.seed,
        naive_limit=args.naive_limit,
    )
    print_fn(rows)


if __name__ == "__main__":
    main()
