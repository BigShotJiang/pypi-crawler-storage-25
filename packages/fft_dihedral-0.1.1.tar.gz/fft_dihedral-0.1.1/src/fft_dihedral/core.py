"""Finite-field FFT for the dihedral group.

We use the presentation

    D_{2n} = <r, s | r^n = s^2 = e, s r s^{-1} = r^{-1}>.

The input function ``f: D_{2n} -> GF(p)`` is stored as two length-``n`` lists:

    rotations[k]   = f(r^k)
    reflections[k] = f(s r^k)

The normalized finite-group DFT convention is

    fhat(rho) = (1 / |D_{2n}|) sum_g f(g) rho(g).

For the two-dimensional irreducible representations, the expensive part is
exactly four cyclic transforms of length ``n``. This module uses a radix-2 NTT
for those cyclic transforms, so the fast path requires ``n`` to be a power of
two and ``n | p - 1``.

The inverse transform rebuilds the two cyclic spectra for the rotation and
reflection coefficients, then applies two inverse NTTs. Group-algebra
multiplication is implemented by transforming both inputs, multiplying each
Fourier block, scaling by ``|D_{2n}|`` because the transform is normalized, and
applying the inverse transform.
"""

from __future__ import annotations

import math
import random
import statistics
import time
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from functools import cache, partial

from sympy import factorint, isprime
from sympy import primitive_root as sympy_primitive_root

# 2013265921 = 15 * 2^27 + 1, with primitive root 31. This is a standard NTT
# prime, and it lets us benchmark n = 2^m for all m <= 27 inside GF(p).
DEFAULT_MODULUS = 2_013_265_921
DEFAULT_PRIMITIVE_ROOT = 31


Matrix2 = tuple[tuple[int, int], tuple[int, int]]


@dataclass(frozen=True)
class DihedralDFT:
    """Fourier data for a function on ``D_{2n}``.

    The one-dimensional coefficients are scalar values. The two-dimensional
    coefficients are ``(j, matrix)`` pairs corresponding to the irrep ``rho_j``.
    """

    n: int
    modulus: int
    one_dimensional: tuple[tuple[str, int], ...]
    two_dimensional: tuple[tuple[int, Matrix2], ...]


def is_power_of_two(n: int) -> bool:
    """Return whether ``n`` is a positive power of two."""

    return n > 0 and (n & (n - 1)) == 0


@cache
def prime_factors(n: int) -> tuple[int, ...]:
    """Return the distinct prime factors of ``n``."""

    return tuple(int(prime) for prime in factorint(n))


def mod_inv(a: int, modulus: int) -> int:
    """Return the multiplicative inverse of ``a`` modulo ``modulus``."""

    return pow(a % modulus, -1, modulus)


def is_primitive_root(candidate: int, modulus: int) -> bool:
    """Test whether ``candidate`` generates ``GF(modulus)^*``."""

    if not isprime(modulus):
        raise ValueError("modulus must be prime")
    if candidate % modulus == 0:
        return False
    return all(
        pow(candidate, (modulus - 1) // q, modulus) != 1
        for q in prime_factors(modulus - 1)
    )


@cache
def find_primitive_root(modulus: int) -> int:
    """Find a primitive root modulo a prime."""

    if not isprime(modulus):
        raise ValueError("modulus must be prime")
    root = sympy_primitive_root(modulus)
    if root is None:
        raise ValueError(f"no primitive root found modulo {modulus}")
    return int(root)


def root_of_unity(
    n: int,
    modulus: int = DEFAULT_MODULUS,
    *,
    primitive_root: int | None = None,
) -> int:
    """Return a primitive ``n``th root of unity in ``GF(modulus)``.

    The modulus must be prime and ``n`` must divide ``modulus - 1``.
    """

    if n <= 0:
        raise ValueError("n must be positive")
    if not isprime(modulus):
        raise ValueError("modulus must be prime")
    if (modulus - 1) % n != 0:
        raise ValueError(f"n={n} does not divide modulus - 1={modulus - 1}")

    if primitive_root is None:
        generator = (
            DEFAULT_PRIMITIVE_ROOT
            if modulus == DEFAULT_MODULUS
            else find_primitive_root(modulus)
        )
    else:
        generator = primitive_root
    if not is_primitive_root(generator, modulus):
        raise ValueError(f"{generator} is not a primitive root modulo {modulus}")

    omega = pow(generator, (modulus - 1) // n, modulus)
    _validate_exact_root_order(omega, n, modulus)
    return omega


def primitive_nth_root(
    n: int,
    modulus: int = DEFAULT_MODULUS,
    primitive_root: int | None = DEFAULT_PRIMITIVE_ROOT,
) -> int:
    """Backward-compatible alias for :func:`root_of_unity`."""

    return root_of_unity(n, modulus, primitive_root=primitive_root)


def _validate_exact_root_order(root: int, n: int, modulus: int) -> None:
    if pow(root, n, modulus) != 1:
        raise ValueError("root must be an n-th root of unity")
    for q in prime_factors(n):
        if pow(root, n // q, modulus) == 1:
            raise ValueError("root must be a primitive n-th root of unity")


def _normalize(values: Sequence[int], modulus: int) -> list[int]:
    return [x % modulus for x in values]


def _validate_dihedral_input(
    rotations: Sequence[int],
    reflections: Sequence[int],
    modulus: int,
    omega: int,
) -> int:
    n = len(rotations)
    if n != len(reflections):
        raise ValueError("rotations and reflections must have the same length")
    if n < 3:
        raise ValueError("use n >= 3 for the nonabelian dihedral groups")
    if not isprime(modulus):
        raise ValueError("modulus must be prime")
    if math.gcd(2 * n, modulus) != 1:
        raise ValueError("the group order 2n must be invertible in the field")
    _validate_exact_root_order(omega, n, modulus)
    return n


def _bit_reverse_in_place(values: list[int]) -> None:
    n = len(values)
    j = 0
    for i in range(1, n):
        bit = n >> 1
        while j & bit:
            j ^= bit
            bit >>= 1
        j ^= bit
        if i < j:
            values[i], values[j] = values[j], values[i]


def ntt(values: Sequence[int], root: int, modulus: int) -> list[int]:
    """Return the unnormalized radix-2 NTT of ``values``.

    The ``j``th output is ``sum_k values[k] * root^(j*k)``.
    """

    n = len(values)
    if not is_power_of_two(n):
        raise ValueError("radix-2 NTT requires a power-of-two length")
    _validate_exact_root_order(root, n, modulus)

    transformed = _normalize(values, modulus)
    _bit_reverse_in_place(transformed)

    length = 2
    while length <= n:
        half = length // 2
        step_root = pow(root, n // length, modulus)
        for start in range(0, n, length):
            twiddle = 1
            for offset in range(start, start + half):
                even = transformed[offset]
                odd = transformed[offset + half] * twiddle % modulus
                transformed[offset] = (even + odd) % modulus
                transformed[offset + half] = (even - odd) % modulus
                twiddle = twiddle * step_root % modulus
        length *= 2

    return transformed


def inverse_ntt(values: Sequence[int], root: int, modulus: int) -> list[int]:
    """Return the inverse of :func:`ntt` for the same root and modulus."""

    n = len(values)
    inv_n = mod_inv(n, modulus)
    inv_root = mod_inv(root, modulus)
    return [x * inv_n % modulus for x in ntt(values, inv_root, modulus)]


def cyclic_transform_naive(values: Sequence[int], root: int, modulus: int) -> list[int]:
    """Return the direct cyclic DFT with the same convention as :func:`ntt`."""

    n = len(values)
    values_mod = _normalize(values, modulus)
    result = []
    for j in range(n):
        twiddle = pow(root, j, modulus)
        power = 1
        total = 0
        for value in values_mod:
            total = (total + value * power) % modulus
            power = power * twiddle % modulus
        result.append(total)
    return result


def _one_dimensional_coefficients(
    rotations: Sequence[int],
    reflections: Sequence[int],
    modulus: int,
) -> tuple[tuple[str, int], ...]:
    n = len(rotations)
    inv_group_order = mod_inv(2 * n, modulus)

    rotation_sum = sum(rotations) % modulus
    reflection_sum = sum(reflections) % modulus

    coefficients = [
        ("trivial", (rotation_sum + reflection_sum) * inv_group_order % modulus),
        (
            "reflection_sign",
            (rotation_sum - reflection_sum) * inv_group_order % modulus,
        ),
    ]

    if n % 2 == 0:
        alternating_rotation_sum = (
            sum(value if k % 2 == 0 else -value for k, value in enumerate(rotations))
            % modulus
        )
        alternating_reflection_sum = (
            sum(value if k % 2 == 0 else -value for k, value in enumerate(reflections))
            % modulus
        )
        coefficients.extend(
            [
                (
                    "rotation_sign",
                    (alternating_rotation_sum + alternating_reflection_sum)
                    * inv_group_order
                    % modulus,
                ),
                (
                    "total_sign",
                    (alternating_rotation_sum - alternating_reflection_sum)
                    * inv_group_order
                    % modulus,
                ),
            ]
        )

    return tuple(coefficients)


def _two_dimensional_range(n: int) -> range:
    if n % 2 == 0:
        return range(1, n // 2)
    return range(1, (n - 1) // 2 + 1)


_ODD_ONE_DIMENSIONAL_REPS = ("trivial", "reflection_sign")
_EVEN_ONE_DIMENSIONAL_REPS = (
    "trivial",
    "reflection_sign",
    "rotation_sign",
    "total_sign",
)


def _expected_one_dimensional_reps(n: int) -> tuple[str, ...]:
    if n % 2 == 0:
        return _EVEN_ONE_DIMENSIONAL_REPS
    return _ODD_ONE_DIMENSIONAL_REPS


def _one_dimensional_value(transform: DihedralDFT, label: str) -> int:
    matches = [
        value % transform.modulus
        for coefficient_label, value in transform.one_dimensional
        if coefficient_label == label
    ]
    if len(matches) != 1:
        raise ValueError("invalid Fourier data")
    return matches[0]


def _two_dimensional_matrices_by_index(
    transform: DihedralDFT,
) -> list[Matrix2 | None]:
    matrices: list[Matrix2 | None] = [None] * transform.n
    valid_indices = set(_two_dimensional_range(transform.n))

    for j, matrix in transform.two_dimensional:
        if j not in valid_indices or matrices[j] is not None:
            raise ValueError("invalid Fourier data")
        matrices[j] = matrix

    if sum(matrix is not None for matrix in matrices) != len(valid_indices):
        raise ValueError("invalid Fourier data")
    return matrices


def _validate_fourier_shape(transform: DihedralDFT) -> None:
    if transform.n < 3:
        raise ValueError("use n >= 3 for the nonabelian dihedral groups")
    if not isprime(transform.modulus):
        raise ValueError("modulus must be prime")
    if math.gcd(2 * transform.n, transform.modulus) != 1:
        raise ValueError("the group order 2n must be invertible in the field")
    if len(transform.one_dimensional) != len(
        _expected_one_dimensional_reps(transform.n)
    ):
        raise ValueError("invalid Fourier data")
    for label in _expected_one_dimensional_reps(transform.n):
        _one_dimensional_value(transform, label)
    _two_dimensional_matrices_by_index(transform)


def _assemble_transform(
    rotations: Sequence[int],
    reflections: Sequence[int],
    positive_rotations: Sequence[int],
    negative_rotations: Sequence[int],
    positive_reflections: Sequence[int],
    negative_reflections: Sequence[int],
    modulus: int,
) -> DihedralDFT:
    n = len(rotations)
    inv_group_order = mod_inv(2 * n, modulus)

    two_dimensional = []
    for j in _two_dimensional_range(n):
        matrix = (
            (
                positive_rotations[j] * inv_group_order % modulus,
                negative_reflections[j] * inv_group_order % modulus,
            ),
            (
                positive_reflections[j] * inv_group_order % modulus,
                negative_rotations[j] * inv_group_order % modulus,
            ),
        )
        two_dimensional.append((j, matrix))

    return DihedralDFT(
        n=n,
        modulus=modulus,
        one_dimensional=_one_dimensional_coefficients(rotations, reflections, modulus),
        two_dimensional=tuple(two_dimensional),
    )


def dihedral_dft_naive(
    rotations: Sequence[int],
    reflections: Sequence[int],
    modulus: int,
    omega: int,
) -> DihedralDFT:
    """Compute the normalized dihedral DFT directly from the formulas."""

    _validate_dihedral_input(rotations, reflections, modulus, omega)
    rotations_mod = _normalize(rotations, modulus)
    reflections_mod = _normalize(reflections, modulus)
    inv_omega = mod_inv(omega, modulus)

    positive_rotations = cyclic_transform_naive(rotations_mod, omega, modulus)
    negative_rotations = cyclic_transform_naive(rotations_mod, inv_omega, modulus)
    positive_reflections = cyclic_transform_naive(reflections_mod, omega, modulus)
    negative_reflections = cyclic_transform_naive(reflections_mod, inv_omega, modulus)

    return _assemble_transform(
        rotations_mod,
        reflections_mod,
        positive_rotations,
        negative_rotations,
        positive_reflections,
        negative_reflections,
        modulus,
    )


def dihedral_dft_fft(
    rotations: Sequence[int],
    reflections: Sequence[int],
    modulus: int,
    omega: int,
) -> DihedralDFT:
    """Compute the normalized dihedral DFT using four radix-2 NTTs."""

    n = _validate_dihedral_input(rotations, reflections, modulus, omega)
    if not is_power_of_two(n):
        raise ValueError("the FFT path currently requires n to be a power of two")

    rotations_mod = _normalize(rotations, modulus)
    reflections_mod = _normalize(reflections, modulus)
    inv_omega = mod_inv(omega, modulus)

    positive_rotations = ntt(rotations_mod, omega, modulus)
    negative_rotations = ntt(rotations_mod, inv_omega, modulus)
    positive_reflections = ntt(reflections_mod, omega, modulus)
    negative_reflections = ntt(reflections_mod, inv_omega, modulus)

    return _assemble_transform(
        rotations_mod,
        reflections_mod,
        positive_rotations,
        negative_rotations,
        positive_reflections,
        negative_reflections,
        modulus,
    )


def dihedral_inverse_fft(
    transform: DihedralDFT,
    omega: int,
) -> tuple[list[int], list[int]]:
    """Invert a normalized fast dihedral DFT.

    The returned pair uses the original coefficient convention:

    ``rotations[k] = f(r^k)`` and ``reflections[k] = f(s r^k)``.
    """

    _validate_fourier_shape(transform)
    n = transform.n
    modulus = transform.modulus
    if not is_power_of_two(n):
        raise ValueError("the FFT path currently requires n to be a power of two")
    _validate_exact_root_order(omega, n, modulus)

    group_order = 2 * n
    rotation_frequencies = [0] * n
    reflection_frequencies = [0] * n

    trivial = _one_dimensional_value(transform, "trivial")
    reflection_sign = _one_dimensional_value(transform, "reflection_sign")
    rotation_frequencies[0] = n * (trivial + reflection_sign) % modulus
    reflection_frequencies[0] = n * (trivial - reflection_sign) % modulus

    if n % 2 == 0:
        rotation_sign = _one_dimensional_value(transform, "rotation_sign")
        total_sign = _one_dimensional_value(transform, "total_sign")
        rotation_frequencies[n // 2] = n * (rotation_sign + total_sign) % modulus
        reflection_frequencies[n // 2] = n * (rotation_sign - total_sign) % modulus

    matrices = _two_dimensional_matrices_by_index(transform)
    for j in _two_dimensional_range(n):
        matrix = matrices[j]
        if matrix is None:
            raise ValueError("invalid Fourier data")
        mirror = n - j

        rotation_frequencies[j] = matrix[0][0] * group_order % modulus
        reflection_frequencies[j] = matrix[1][0] * group_order % modulus
        rotation_frequencies[mirror] = matrix[1][1] * group_order % modulus
        reflection_frequencies[mirror] = matrix[0][1] * group_order % modulus

    return (
        inverse_ntt(rotation_frequencies, omega, modulus),
        inverse_ntt(reflection_frequencies, omega, modulus),
    )


def _matrix_multiply_scaled(
    lhs: Matrix2,
    rhs: Matrix2,
    scale: int,
    modulus: int,
) -> Matrix2:
    def entry(a: int, b: int, c: int, d: int) -> int:
        return scale * (a * b + c * d) % modulus

    return (
        (
            entry(lhs[0][0], rhs[0][0], lhs[0][1], rhs[1][0]),
            entry(lhs[0][0], rhs[0][1], lhs[0][1], rhs[1][1]),
        ),
        (
            entry(lhs[1][0], rhs[0][0], lhs[1][1], rhs[1][0]),
            entry(lhs[1][0], rhs[0][1], lhs[1][1], rhs[1][1]),
        ),
    )


def multiply_fourier_transforms(
    lhs: DihedralDFT,
    rhs: DihedralDFT,
) -> DihedralDFT:
    """Multiply two normalized dihedral Fourier transforms.

    Since this package uses ``1 / |D_{2n}|`` normalization, group-algebra
    multiplication satisfies ``(fg)^hat(rho) = |D_{2n}| fhat(rho) ghat(rho)``.
    """

    _validate_fourier_shape(lhs)
    _validate_fourier_shape(rhs)
    if lhs.n != rhs.n:
        raise ValueError("transforms must have the same rotation order")
    if lhs.modulus != rhs.modulus:
        raise ValueError("transforms must use the same modulus")

    n = lhs.n
    modulus = lhs.modulus
    group_order = 2 * n

    one_dimensional = []
    for label in _expected_one_dimensional_reps(n):
        one_dimensional.append(
            (
                label,
                group_order
                * _one_dimensional_value(lhs, label)
                * _one_dimensional_value(rhs, label)
                % modulus,
            )
        )

    lhs_matrices = _two_dimensional_matrices_by_index(lhs)
    rhs_matrices = _two_dimensional_matrices_by_index(rhs)
    two_dimensional = []
    for j in _two_dimensional_range(n):
        lhs_matrix = lhs_matrices[j]
        rhs_matrix = rhs_matrices[j]
        if lhs_matrix is None or rhs_matrix is None:
            raise ValueError("invalid Fourier data")
        two_dimensional.append(
            (j, _matrix_multiply_scaled(lhs_matrix, rhs_matrix, group_order, modulus))
        )

    return DihedralDFT(
        n=n,
        modulus=modulus,
        one_dimensional=tuple(one_dimensional),
        two_dimensional=tuple(two_dimensional),
    )


def _validate_group_algebra_inputs(
    lhs_rotations: Sequence[int],
    lhs_reflections: Sequence[int],
    rhs_rotations: Sequence[int],
    rhs_reflections: Sequence[int],
    modulus: int,
) -> int:
    n = len(lhs_rotations)
    if (
        n != len(lhs_reflections)
        or n != len(rhs_rotations)
        or n != len(rhs_reflections)
    ):
        raise ValueError("all coefficient arrays must have the same length")
    if n < 3:
        raise ValueError("use n >= 3 for the nonabelian dihedral groups")
    if not isprime(modulus):
        raise ValueError("modulus must be prime")
    return n


def dihedral_multiply_naive(
    lhs_rotations: Sequence[int],
    lhs_reflections: Sequence[int],
    rhs_rotations: Sequence[int],
    rhs_reflections: Sequence[int],
    modulus: int,
) -> tuple[list[int], list[int]]:
    """Multiply two group-algebra elements directly in quadratic time."""

    n = _validate_group_algebra_inputs(
        lhs_rotations,
        lhs_reflections,
        rhs_rotations,
        rhs_reflections,
        modulus,
    )
    lhs_rotations_mod = _normalize(lhs_rotations, modulus)
    lhs_reflections_mod = _normalize(lhs_reflections, modulus)
    rhs_rotations_mod = _normalize(rhs_rotations, modulus)
    rhs_reflections_mod = _normalize(rhs_reflections, modulus)
    rotations = [0] * n
    reflections = [0] * n

    for i in range(n):
        for j in range(n):
            sum_index = (i + j) % n
            difference_index = (j - i) % n

            rotations[sum_index] += lhs_rotations_mod[i] * rhs_rotations_mod[j]
            rotations[difference_index] += (
                lhs_reflections_mod[i] * rhs_reflections_mod[j]
            )
            reflections[difference_index] += (
                lhs_rotations_mod[i] * rhs_reflections_mod[j]
            )
            reflections[sum_index] += lhs_reflections_mod[i] * rhs_rotations_mod[j]

            rotations[sum_index] %= modulus
            rotations[difference_index] %= modulus
            reflections[difference_index] %= modulus
            reflections[sum_index] %= modulus

    return rotations, reflections


def dihedral_multiply_fft(
    lhs_rotations: Sequence[int],
    lhs_reflections: Sequence[int],
    rhs_rotations: Sequence[int],
    rhs_reflections: Sequence[int],
    modulus: int,
    omega: int,
) -> tuple[list[int], list[int]]:
    """Multiply two group-algebra elements using the dihedral FFT."""

    _validate_group_algebra_inputs(
        lhs_rotations,
        lhs_reflections,
        rhs_rotations,
        rhs_reflections,
        modulus,
    )
    lhs = dihedral_dft_fft(lhs_rotations, lhs_reflections, modulus, omega)
    rhs = dihedral_dft_fft(rhs_rotations, rhs_reflections, modulus, omega)
    return dihedral_inverse_fft(multiply_fourier_transforms(lhs, rhs), omega)


def flatten_transform(transform: DihedralDFT) -> list[int]:
    """Flatten Fourier data to a vector of length ``2n``."""

    flattened = [value for _, value in transform.one_dimensional]
    for _, matrix in transform.two_dimensional:
        flattened.extend([matrix[0][0], matrix[0][1], matrix[1][0], matrix[1][1]])
    return flattened


def random_dihedral_function(
    n: int,
    modulus: int = DEFAULT_MODULUS,
    seed: int | None = None,
) -> tuple[list[int], list[int]]:
    """Generate deterministic pseudo-random values on ``D_{2n}``."""

    rng = random.Random(seed)
    return (
        [rng.randrange(modulus) for _ in range(n)],
        [rng.randrange(modulus) for _ in range(n)],
    )


def assert_transforms_match(
    n: int,
    modulus: int = DEFAULT_MODULUS,
    seed: int = 0,
    *,
    omega: int | None = None,
    primitive_root: int | None = None,
) -> None:
    """Assert that the FFT, inverse FFT, and multiplication agree with references."""

    omega = (
        root_of_unity(n, modulus, primitive_root=primitive_root)
        if omega is None
        else omega
    )
    rotations, reflections = random_dihedral_function(n, modulus, seed)

    naive = flatten_transform(
        dihedral_dft_naive(rotations, reflections, modulus, omega)
    )
    fast = flatten_transform(dihedral_dft_fft(rotations, reflections, modulus, omega))

    if naive != fast:
        for index, (left, right) in enumerate(zip(naive, fast, strict=False)):
            if left != right:
                raise AssertionError(
                    f"first mismatch at flattened index {index}: {left} != {right}"
                )
        raise AssertionError("transform lengths differ")

    transform = dihedral_dft_fft(rotations, reflections, modulus, omega)
    if dihedral_inverse_fft(transform, omega) != (rotations, reflections):
        raise AssertionError("inverse FFT failed to recover the original input")

    rhs_rotations, rhs_reflections = random_dihedral_function(
        n,
        modulus,
        seed=seed + 1_000_000,
    )
    fast_product = dihedral_multiply_fft(
        rotations,
        reflections,
        rhs_rotations,
        rhs_reflections,
        modulus,
        omega,
    )
    naive_product = dihedral_multiply_naive(
        rotations,
        reflections,
        rhs_rotations,
        rhs_reflections,
        modulus,
    )
    if fast_product != naive_product:
        raise AssertionError("FFT multiplication does not match the naive product")


def median_seconds(repetitions: int, callback: Callable[[], object]) -> float:
    """Return the median runtime in seconds for ``callback``."""

    samples = []
    for _ in range(repetitions):
        start = time.perf_counter()
        callback()
        samples.append(time.perf_counter() - start)
    return statistics.median(samples)


def benchmark(
    exponents: Iterable[int],
    modulus: int = DEFAULT_MODULUS,
    *,
    primitive_root: int | None = None,
    repetitions: int = 5,
    seed: int = 0,
    naive_limit: int = 512,
) -> list[dict[str, float | int | None]]:
    """Benchmark FFT and, for small sizes, the direct DFT."""

    rows = []
    for exponent in exponents:
        n = 2**exponent
        omega = root_of_unity(n, modulus, primitive_root=primitive_root)
        rotations, reflections = random_dihedral_function(n, modulus, seed + n)

        fast_time = median_seconds(
            repetitions,
            lambda rotations=rotations, reflections=reflections, omega=omega: (
                dihedral_dft_fft(rotations, reflections, modulus, omega)
            ),
        )

        if n <= naive_limit:
            naive_time = median_seconds(
                max(1, min(repetitions, 3)),
                lambda rotations=rotations, reflections=reflections, omega=omega: (
                    dihedral_dft_naive(rotations, reflections, modulus, omega)
                ),
            )
            speedup = naive_time / fast_time
        else:
            naive_time = None
            speedup = None

        group_order = 2 * n
        scale = group_order * math.log2(group_order)
        rows.append(
            {
                "n": n,
                "group_order": group_order,
                "fft_seconds": fast_time,
                "fft_ns_per_group_log": fast_time * 1e9 / scale,
                "naive_seconds": naive_time,
                "speedup": speedup,
            }
        )

    return rows


def benchmark_multiplication(
    exponents: Iterable[int],
    modulus: int = DEFAULT_MODULUS,
    *,
    primitive_root: int | None = None,
    repetitions: int = 5,
    seed: int = 0,
    naive_limit: int = 512,
) -> list[dict[str, float | int | None]]:
    """Benchmark FFT multiplication and, for small sizes, direct multiplication."""

    rows = []
    for exponent in exponents:
        n = 2**exponent
        omega = root_of_unity(n, modulus, primitive_root=primitive_root)
        lhs_rotations, lhs_reflections = random_dihedral_function(n, modulus, seed + n)
        rhs_rotations, rhs_reflections = random_dihedral_function(
            n,
            modulus,
            seed + 1_000_000 + n,
        )

        fast_time = median_seconds(
            repetitions,
            partial(
                dihedral_multiply_fft,
                lhs_rotations,
                lhs_reflections,
                rhs_rotations,
                rhs_reflections,
                modulus,
                omega,
            ),
        )

        if n <= naive_limit:
            naive_time = median_seconds(
                max(1, min(repetitions, 3)),
                partial(
                    dihedral_multiply_naive,
                    lhs_rotations,
                    lhs_reflections,
                    rhs_rotations,
                    rhs_reflections,
                    modulus,
                ),
            )
            speedup = naive_time / fast_time
        else:
            naive_time = None
            speedup = None

        group_order = 2 * n
        scale = group_order * math.log2(group_order)
        rows.append(
            {
                "n": n,
                "group_order": group_order,
                "fft_seconds": fast_time,
                "fft_ns_per_group_log": fast_time * 1e9 / scale,
                "naive_seconds": naive_time,
                "speedup": speedup,
            }
        )

    return rows


def format_seconds(value: float | None) -> str:
    """Format seconds in a compact human-readable unit."""

    if value is None:
        return "-"
    if value < 1e-3:
        return f"{value * 1e6:.2f} us"
    if value < 1:
        return f"{value * 1e3:.2f} ms"
    return f"{value:.2f} s"


def print_benchmark(rows: Sequence[dict[str, float | int | None]]) -> None:
    """Print benchmark rows as a fixed-width table."""

    headers = (
        "n",
        "|D_{2n}|",
        "FFT median",
        "ns/(2n log2(2n))",
        "naive median",
        "speedup",
    )
    print(
        f"{headers[0]:>8} "
        f"{headers[1]:>10} "
        f"{headers[2]:>12} "
        f"{headers[3]:>20} "
        f"{headers[4]:>14} "
        f"{headers[5]:>10}"
    )
    for row in rows:
        naive = format_seconds(row["naive_seconds"])
        speedup = "-" if row["speedup"] is None else f"{row['speedup']:.1f}x"
        print(
            f"{row['n']:8d} "
            f"{row['group_order']:10d} "
            f"{format_seconds(row['fft_seconds']):>12} "
            f"{row['fft_ns_per_group_log']:20.2f} "
            f"{naive:>14} "
            f"{speedup:>10}"
        )


def print_multiplication_benchmark(
    rows: Sequence[dict[str, float | int | None]],
) -> None:
    """Print multiplication benchmark rows as a fixed-width table."""

    headers = (
        "n",
        "|D_{2n}|",
        "FFT multiply",
        "ns/(2n log2(2n))",
        "naive product",
        "speedup",
    )
    print(
        f"{headers[0]:>8} "
        f"{headers[1]:>10} "
        f"{headers[2]:>14} "
        f"{headers[3]:>20} "
        f"{headers[4]:>14} "
        f"{headers[5]:>10}"
    )
    for row in rows:
        naive = format_seconds(row["naive_seconds"])
        speedup = "-" if row["speedup"] is None else f"{row['speedup']:.1f}x"
        print(
            f"{row['n']:8d} "
            f"{row['group_order']:10d} "
            f"{format_seconds(row['fft_seconds']):>14} "
            f"{row['fft_ns_per_group_log']:20.2f} "
            f"{naive:>14} "
            f"{speedup:>10}"
        )
