"""Exception hierarchy for the TonWise SDK."""

from typing import Optional


class TonWiseError(Exception):
    """Base exception for all TonWise SDK errors."""


class AuthError(TonWiseError):
    """Raised when API key authentication fails (HTTP 401)."""


class RateLimitError(TonWiseError):
    """Raised when API rate limit is exceeded (HTTP 429).

    The ``retry_after`` attribute holds the number of seconds the caller
    should wait before retrying, parsed from the ``Retry-After`` header.
    """

    def __init__(self, message: str, retry_after: int = 60) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class APIError(TonWiseError):
    """Raised on non-auth, non-rate-limit 4xx/5xx responses.

    Carries ``status_code`` and a truncated ``body`` for debugging.
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        body: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
