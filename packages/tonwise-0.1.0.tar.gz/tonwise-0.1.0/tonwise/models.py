"""Pydantic v2 response models for the TonWise API."""

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class ScanResult(BaseModel):
    """Result of GET /api/v1/shield."""

    model_config = ConfigDict(extra="ignore")

    contract: str
    is_safe: bool
    dump_probability: int = Field(ge=0, le=100)
    reason: str
    sybil_clusters: int = 0
    stake_concentration: Optional[float] = None
    total_sybils: Optional[int] = None


class BadgeResult(BaseModel):
    """Result of GET /api/badge."""

    model_config = ConfigDict(extra="ignore")

    score: int = Field(ge=0, le=100)
    label: str  # 'SAFE' | 'WARNING' | 'DANGER' | 'UNKNOWN'
    color: str  # 'green' | 'yellow' | 'red' | 'gray'
