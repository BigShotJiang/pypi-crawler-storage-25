"""Asynchronous client for the TonWise Security API."""

from typing import Any, Dict, List, Optional

import aiohttp

from ._version import __version__
from .exceptions import APIError, AuthError, RateLimitError
from .models import ScanResult


class AsyncTonWiseClient:
    """Async client for the TonWise Security API.

    Designed for AI agents, trading bots, and FastAPI/aiohttp services.

    Example:
        >>> import asyncio
        >>> from tonwise import AsyncTonWiseClient
        >>>
        >>> async def main():
        ...     async with AsyncTonWiseClient(api_key="tg_live_xxx") as client:
        ...         result = await client.scan("EQA1234...")
        ...         print(result.is_safe)
        >>>
        >>> asyncio.run(main())
    """

    BASE_URL = "https://tonguard.app"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.BASE_URL).rstrip("/")
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: Optional[aiohttp.ClientSession] = None

    # ─────────────────────────── lifecycle ─────────────────────────

    async def __aenter__(self) -> "AsyncTonWiseClient":
        self._session = aiohttp.ClientSession(
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": f"tonwise-python/{__version__}",
                "Accept": "application/json",
            },
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()

    def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            raise RuntimeError(
                "AsyncTonWiseClient is not initialized. "
                "Use 'async with AsyncTonWiseClient(...)' or call __aenter__() manually."
            )
        return self._session

    # ─────────────────────────── helpers ───────────────────────────

    async def _handle_response(self, resp: aiohttp.ClientResponse) -> Dict[str, Any]:
        if resp.status == 401:
            raise AuthError("Invalid API key")
        if resp.status == 429:
            raise RateLimitError(
                "Rate limit exceeded",
                retry_after=int(resp.headers.get("Retry-After", 60)),
            )
        if resp.status >= 400:
            body = await resp.text()
            raise APIError(
                f"API request failed: HTTP {resp.status}",
                status_code=resp.status,
                body=body[:500],
            )
        return await resp.json()

    # ─────────────────────────── public API ────────────────────────

    async def scan(self, contract: str) -> ScanResult:
        """Scan a TON contract for security risks. See :class:`ScanResult`."""
        session = self._ensure_session()
        url = f"{self.base_url}/api/v1/shield"
        async with session.get(url, params={"contract": contract}) as resp:
            data = await self._handle_response(resp)
            return ScanResult(**data)

    async def register_webhook(
        self,
        url: str,
        events: List[str],
        secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Register a webhook subscription."""
        session = self._ensure_session()
        endpoint = f"{self.base_url}/api/v1/webhook/register"
        payload: Dict[str, Any] = {"url": url, "events": events}
        if secret is not None:
            payload["secret"] = secret
        async with session.post(endpoint, json=payload) as resp:
            return await self._handle_response(resp)

    async def list_webhooks(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """List webhooks attached to the current API key."""
        session = self._ensure_session()
        endpoint = f"{self.base_url}/api/v1/webhook/list"
        params = {"active_only": "true" if active_only else "false"}
        async with session.get(endpoint, params=params) as resp:
            data = await self._handle_response(resp)
            return data.get("webhooks", [])

    async def delete_webhook(self, webhook_id: int) -> bool:
        """Soft-delete a webhook by ID. Returns True if deleted, False if 404."""
        session = self._ensure_session()
        endpoint = f"{self.base_url}/api/v1/webhook/{webhook_id}"
        async with session.delete(endpoint) as resp:
            if resp.status == 404:
                return False
            await self._handle_response(resp)
            return True
