# Changelog

Generated from `docs/releases/*.md` by `pr-bot release changelog`.

# pr-bot 0.3.0

Second minor bump. Three new top-level capabilities — stacked PRs, a
terminal dashboard, and a Claude Code plugin — plus a deeper `doctor`,
explicit stability commitments, and the bug fixes from the docs/cleanup
sweep that came after 0.2.0.

## Stacked PRs (`pr-bot stack ...`)

For changes too large for one PR but logically a unit. Build a chain of
dependent PR branches and land them in order.

```
pr-bot stack new auth-tokens auth-middleware auth-routes
# → feat/auth-tokens (off main)
#    └─ feat/auth-middleware (off feat/auth-tokens)
#        └─ feat/auth-routes (off feat/auth-middleware)
pr-bot stack push        # opens 3 PRs, cross-linked via <!-- pr-bot:stack -->
pr-bot stack sync        # rebase the chain onto origin/main
pr-bot stack land --all  # squash-merge bottom-up; sync between merges
```

State lives in `.git/pr-bot/stack.json` (per-clone, never committed). Six
subcommands total: `new`, `push`, `sync`, `land`, `status`, `abandon`.
Conflict mid-chain leaves the rebase in progress with explicit resolution
steps; re-run `stack sync` to finish. Design doc:
[`docs/design-pr-stack.md`](../design-pr-stack.md).

## Terminal dashboard (`pr-bot ui`)

A Textual UI showing branches, the active stack, release lines, the
selected PR's body, and its CI checks — all on one screen. Hotkeys map
to the existing CLI:

| key | action |
| --- | ------ |
| ↑/↓ | move selection |
| s | `pr-bot pr sync` on the selected branch |
| r | `pr-bot pr ready` |
| m | `pr-bot pr merge` |
| c | `pr-bot pr cleanup` |
| o | open PR URL in browser |
| g | refresh |
| q | quit |

User guide: [`docs/ui.md`](../ui.md). Design + implementation order:
[`docs/design-tui.md`](../design-tui.md).

## Claude Code plugin

Slash commands now ship as a Claude Code plugin instead of requiring a
clone-and-symlink dance:

```bash
# inside Claude Code:
/plugin marketplace add andrewrothstein/pr-bot
/plugin install pr-bot@pr-bot
```

Manifest at `.claude-plugin/plugin.json`; the 28 command files moved from
`.claude/commands/` to `commands/` at repo root (with `.claude/commands`
now a symlink so this repo's own session keeps working).

## `pr-bot doctor` deepened

Doctor used to run two checks; it now runs eight, grouped by what they
need:

- **Always:** main is linear, branch names match the model, tags are
  X.Y.Z.
- **Repo-shape:** pyproject.toml version is X.Y.Z, `.pr-bot.toml`
  present, CI workflow present, every `commands/*.md` invokes the CLI
  via `uvx`.
- **Needs gh + remote:** `gh auth status`, declared policy matches
  GitHub branch protection.

Output is grouped: `ok:` lines first, then `warnings:`, then
`problems:`. Exit codes unchanged (0 / 1 / 2).

## `pr open` is stack-aware

Silent footgun before this release: running `/pr-open` on a non-bottom
branch in an active stack opened the PR against `main` (wrong target).
Now it auto-routes to the parent in the stack and prints a one-line
explanation. New `--base` flag overrides.

## Stability commitment

[`docs/stability.md`](../stability.md) spells out exactly which surfaces
1.x will not break: CLI subcommands + long flags, slash command names,
branch/tag shapes, `.pr-bot.toml` schema, `.git/pr-bot/stack.json`
fields, the importable Python API (`pr_bot.{names, git, gh, policy,
stack, changelog, release_notes, pyproject}`), exit codes. TUI layout
and `commands/*.md` body content are explicitly experimental.

## Other improvements

- **`release tag` mismatch error** now suggests `pr-bot release prepare`
  instead of `sed`.
- **Branch-protection policy doc** — `docs/policy.md` explains v1's
  classic-protection scope and the workaround for multiple release
  lines. Rulesets backend filed as a P3 follow-up.
- **Release-day checklist** — `docs/release-checklist.md` lists the
  manual smoke-test steps to run against the live `gh` API before
  tagging.

## Tests

148 → 159 passing. New coverage: `pr open` stack-aware base routing,
doctor's seven new checks, `stack sync` conflict-resume flow.

## What's next

1.0 ships after `pr-bot-mgu` — two weeks of dogfooding pr-bot in a
non-self repo. The five P3 follow-ups (TUI stack hotkeys, `release
backport`, `pr-bot init`, Windows audit, `release diff`, rulesets
backend) are explicitly *not* 1.0 blockers.

# pr-bot 0.2.0

First minor bump. Three meaty additions; cumulative test count 93 → 108.

## What's new

- **`pr-bot release notes-draft X.Y.Z`** (`/release-notes-draft`).
  Queries gh for PRs merged to the release branch (or main) since the
  previous tag in the same line, groups by conventional-commit prefix
  into *What's new* / *Fixes* / *Infrastructure* / *Other*, and writes
  `docs/releases/X.Y.Z.md`. `release prepare` invokes it automatically
  when the file doesn't exist.
- **`toolbar repo template <name>`** (`/toolbar-repo-template`).
  Bootstraps a brand-new Python project with the entire pr-bot model
  pre-wired: pyproject + ruff + ratchet-pinned CI workflow + CLAUDE.md
  + AGENTS.md + LICENSE + an initial commit on `main` + a cut
  `release/0.1` + `gh repo create --private --push`. The "use it
  everywhere" promise made literal.
- **`pr-bot policy apply` / `policy check`** (`/policy-apply`,
  `/policy-check`). Reads `.pr-bot.toml` and either applies the
  branch-protection rules (linear history, no force push, required
  status checks, etc.) to GitHub via the protection API, or diffs
  remote-vs-declared. Same default policy ships in the repo template.

## Why a minor bump

These three features add new surface area (subcommands, slash twins,
new module). 0.1.x has been patch fixes only — bumping minor reflects
the shape change.

## Infrastructure / tests

- 10 unit tests for `release_notes` (classify + render).
- 5 unit tests for the template renderer (substitution + .tmpl strip).
- 14 unit tests for `policy` (load + payload + diff).
- ratchet exclude for `src/toolbar/templates/` (placeholders aren't
  valid Python/TOML), pytest `testpaths = ["tests"]`.
- hatch `force-include` for the templates directory so dotfiles ship
  in the wheel.

# pr-bot 0.1.5

Three additions, all dogfooded by this very release.

## What's new

- **`pr-bot pr cleanup`** (`/pr-cleanup`). Finishes the merge dance for
  PRs landed via GitHub's UI: refuses if the PR is still OPEN, otherwise
  fetches, switches to main, fast-forwards, and deletes the local PR
  branch. Idempotent.
- **Generated `CHANGELOG.md`.** Concatenated from `docs/releases/*.md`
  by `pr-bot release changelog` (sorted by version desc).
  `pr-bot release prepare` regenerates it as part of the bump commit, so
  it never drifts. New `/release-changelog` slash command.
- **Test coverage for `pr_bot.commands.{pr,release,hotfix}`.** 25 new
  integration tests against a real git in `tmp_path` with a fake `gh`
  shim on `PATH`. Covers golden paths and the error guards we've shipped
  (uncommitted-rejection, existing-branch, version-mismatch, missing-
  release, etc.).

## Test count

58 → 83 passing.

# pr-bot 0.1.4

Release-flow ergonomics. Two new things, both about how you ship a
release rather than what's in one.

## What's new

- **`pr-bot release tag X.Y.Z --notes-file <path>`.** Reads release
  notes from a file rather than requiring `--notes "$(cat ...)"`.
  Mutually exclusive with `--notes`. Passes through to gh's native
  `--notes-file`.
- **`pr-bot release prepare X.Y.Z`.** New subcommand. Bumps
  `pyproject.toml`'s `[project].version` on the matching `release/X.Y`
  branch, commits `chore: bump to X.Y.Z`, and pushes. Pair with
  `pr-bot release tag X.Y.Z` (which still refuses to tag if
  pyproject doesn't match — the safety check from 0.1.2).
- **New slash command:** `/release-prepare`.

## Day-to-day release flow now

```
pr-bot release cut X.Y                    # if the line doesn't exist
pr-bot release prepare X.Y.Z              # bumps + commits + pushes
pr-bot release tag X.Y.Z --notes-file docs/releases/X.Y.Z.md
```

Three commands, no `sed`, no `$(cat ...)`.

# pr-bot 0.1.3

Third drift patch. The `0.1.2` wheel on PyPI has correct metadata but
`pr-bot --version` inside it prints `0.1.0`, because
`src/pr_bot/__init__.py` hardcoded `__version__`.

## Fix

- **`__version__` now comes from `importlib.metadata`.** Reads the
  installed distribution's version — the one source of truth is
  `pyproject.toml`. Falls back to `"0.0.0+unknown"` if the package
  isn't installed (e.g. running directly from source without
  `uv sync`).
- **`toolbar` re-uses `pr_bot.__version__`.** Same package, same
  version.

## Filed for later

- `pin GitHub Actions to SHAs via ratchet` — all workflows still use
  floating version tags; swap in SHAs for supply-chain safety.

# pr-bot 0.1.2

Re-sync release. `0.1.1` shipped a git tag and a GitHub release but the
PyPI upload was labeled `0.1.0` — the wheel's version comes from
`pyproject.toml`, which wasn't bumped. Fixed for real this time.

## Fixes

- **`pr-bot release tag X.Y.Z` requires `pyproject.toml` version
  match.** Refuses to tag when `[project].version` in `pyproject.toml`
  doesn't equal `X.Y.Z`, with step-by-step bump instructions in the
  error message. `--skip-version-check` escape hatch available but
  noisy. Closes `pr-bot-fvc`.
- **pyproject version bumped to 0.1.2** to match the tag (the fix that
  `pr-bot-fvc` will enforce going forward).

## Infra

- `pr_bot.pyproject` module with `find_pyproject()` (walks up from cwd)
  and `read_version()`. 6 new unit tests.

## Test count

49 → 55 passing.

# pr-bot 0.1.1

Patch release on `release/0.1`. Six PRs landed since `0.1.0`, all through
the full pr-bot flow — first real dogfood cycle.

## Fixes

- **`pr merge` handles diverged local main.** When local `main` has
  commits not on `origin/main` (which the GitHub squash merge has
  superseded), `pr merge` now surfaces the stray commits and prints
  explicit reconcile options (`git rebase` vs `git reset --hard`) rather
  than dying on `git pull --ff-only`. (#3)
- **`toolbar repo create --push` wires `gh auth setup-git` first.**
  Checks `credential.https://<host>.helper`; if gh's helper isn't
  registered, runs `gh auth setup-git` before `gh repo create --push`
  to avoid the "Repository not found" first-push failure. (#4)
- **`pr sync` leaves rebase state intact on conflict.** Previously
  `SystemExit`'d with git's raw stderr, leaving the user stuck. Now
  detects `.git/rebase-merge` / `rebase-apply`, prints step-by-step
  resolution (resolve → `git rebase --continue` → re-run `/pr-sync`),
  and preserves the rebase state for the user. (#5)
- **`list_branches("*")` now returns multi-level branch names.** `git
  for-each-ref`'s fnmatch doesn't cross `/`; `refs/heads/*` missed
  `feat/a`. Treated `*` and `None` as "everything" via prefix match.
  Same fix applied to `list_remote_branches`. (#6)

## Infrastructure

- **GitHub Actions CI.** `pytest -q` + `ruff check src tests` on every
  PR and push to `main` / `release/**`. `uv sync --frozen` against a
  committed `uv.lock` for deterministic installs. (#2)
- **PyPI publish workflow.** Tag-triggered (`X.Y.Z`), builds with `uv`,
  uploads via `pypa/gh-action-pypi-publish` using OIDC — no secrets.
  Scoped to a `pypi` environment. One-time pypi.org Trusted Publisher
  registration still needed before first publish; see
  `docs/publishing.md`. (#7)

## Tests

- **Integration tests for `pr_bot.git`.** 24 new tests against a real
  git repo in `tmp_path` covering branch ops, tags, working-tree state,
  `ahead_behind`, `is_ancestor`, `rebase_try`, and `rebase_in_progress`.
  Total: 25 → 49 passing. (#6)

# pr-bot 0.1.0: one shape for every repo's PR lifecycle

Every repo I touch follows the same rules.

- `main` is linear. Fast-forward only. Squash merges only.
- Work branches: `feat/<slug>`, `fix/<slug>`, `hotfix/<slug>`.
- Release branches: `release/X.Y`, long-lived, receive only hotfixes.
- Tags: `X.Y.Z`, annotated, on the matching release branch.

These rules are load-bearing. Linear main means `git bisect` actually works. Squash merges keep one commit per PR, so `git log main` reads like a changelog. Release lines keep "what's next" and "what shipped" separately inspectable. Hotfixes land on the right release, then forward-port to main as a normal fix PR.

The rules don't enforce themselves. I used to have a scratchpad of git commands. Over time it became a page of notes, then a handful of shell aliases. Now it's `pr-bot` — a CLI plus a set of Claude Code slash commands, both thin.

## What it does

Three command groups, one per lifecycle stage.

```
pr-bot pr start feat add-login   # fetch main, FF, branch off
pr-bot pr open --draft           # push + gh pr create
pr-bot pr sync                   # rebase on main, force-push with lease
pr-bot pr ready                  # undraft
pr-bot pr merge                  # squash-merge, delete branch, FF main
```

```
pr-bot release cut 1.4           # release/1.4 off main
pr-bot release tag 1.4.0         # annotated tag + gh release
pr-bot release list              # what's shipped on which line
```

```
pr-bot hotfix start fix-x --on 1.4
pr-bot hotfix open --on 1.4      # PR into release/1.4
pr-bot hotfix forward-port <sha> # carry to main as fix/<slug>
```

Plus `pr-bot doctor`, which checks main is linear, branches and tags match the model, and the remote is wired.

Each subcommand has a slash-command twin: `/pr-start`, `/pr-merge`, `/release-cut`. They all resolve to the same CLI via `uvx`:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr start $ARGUMENTS
```

No install. Each invocation runs in a cached, isolated env with deps pinned by `pyproject.toml`. Point `PR_BOT_SOURCE` at a local clone during development, or a git tag for reproducibility.

## Why an agent likes this

An agent given raw git can do anything, including the wrong thing — merge main into a branch, push to main, tag outside the `X.Y.Z` convention. An agent given `/pr-start feat add-login` can only do what `pr-bot pr start` does. The constraints *are* the interface.

`AGENTS.md` spells the rules out: no merge commits on main, no direct pushes to `release/*`, no branch names outside the model. `pr-bot doctor` is the check. The slash commands keep the agent on rails.

## A sibling: `toolbar`

`pr-bot` operates *inside* a repo. `toolbar` operates *around* it:

```
toolbar repo info                 # what would I create?
toolbar repo create --push        # gh repo create --private, push main
```

Defaults come from `GH_MIRROR` (default `https://github.com`) and `GH_ORG` (default `andrewrothstein`). This very repo was bootstrapped with `toolbar repo create --push`.

## What's there and what isn't

This is 0.1. The CLIs work, the slash commands work, the parsers are unit-tested, the bootstrap is real.

What's not there yet:

- CI (no GitHub Actions)
- PyPI publish — for now, pin `PR_BOT_SOURCE` to a git ref
- Integration tests against a real git + gh
- Conflict-handling polish in `pr sync`
- A dogfood cycle through the full flow

1.0 is probably two weeks of use away. I'll tag `0.1.0` on `release/0.1` and iterate.

## Source

`github.com/andrewrothstein/pr-bot` — private today. I want to eat my own dog food for a bit before opening it up.
