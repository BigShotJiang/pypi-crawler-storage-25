---
description: Create a private GitHub repo for this workspace (respects GH_MIRROR / GH_ORG).
argument-hint: [--name <n>] [--org <o>] [--mirror <url>] [--public] [--push] [--description "..."]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" toolbar repo create $ARGUMENTS
```

Defaults: repo name = current directory name, org = `${GH_ORG:-andrewrothstein}`, mirror = `${GH_MIRROR:-https://github.com}`, visibility = **private**. Pass `--push` to also push the current branch.

If the user hasn't confirmed they want this created, use `/toolbar-repo-info` first to show the resolved target.
