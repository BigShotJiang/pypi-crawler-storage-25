---
description: Squash-merge the bottom of the stack and pop it from the state.
argument-hint: [--all]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack land $ARGUMENTS
```

By default lands one branch (the bottom). `--all` repeats: merge → sync remaining → merge → … until the stack is empty. Marks draft PRs ready before merging. Pops each landed branch from `.git/pr-bot/stack.json`; clears the file when the stack is empty.
