---
description: Mark the current PR as ready for review (undraft).
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr ready
```
