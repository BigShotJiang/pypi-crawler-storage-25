---
description: Rebase the entire stack onto origin/main; force-push each branch.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack sync
```

Walks the stack bottom-to-top, rebasing each branch onto its parent's freshly-rebased head. Stops on the first conflict with explicit resolution steps and leaves the rebase state intact — re-run `/stack-sync` after `git rebase --continue` to finish the chain.
