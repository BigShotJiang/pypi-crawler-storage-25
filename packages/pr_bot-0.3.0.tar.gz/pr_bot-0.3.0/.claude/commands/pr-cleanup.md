---
description: Finish the merge dance for a PR that was merged via the GitHub UI.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr cleanup
```

Use this when someone clicked GitHub's *Merge* button instead of running `/pr-merge`. It fetches, switches to main, fast-forwards, and deletes the local PR branch. Refuses if the PR is still open.
