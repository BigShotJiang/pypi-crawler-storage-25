---
description: Show the current stack — branches, PRs, draft state.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack status
```
