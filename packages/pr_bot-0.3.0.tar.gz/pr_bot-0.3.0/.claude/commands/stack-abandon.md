---
description: Delete the stack state file (branches and PRs are left intact).
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack abandon
```

After this, `pr-bot stack` commands won't see the stack anymore. The branches and any open PRs are still present — clean them up via `git branch -D` and `gh pr close` if desired.
