---
description: Show ahead/behind vs main and the state of any open PR.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr status
```
