---
description: Push the pr-bot policy (from .pr-bot.toml) to GitHub branch protection.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot policy apply
```

Reads `.pr-bot.toml`, calls `gh api PUT /repos/.../branches/.../protection` for each `protected_branches` entry. Idempotent. Requires repo admin.
