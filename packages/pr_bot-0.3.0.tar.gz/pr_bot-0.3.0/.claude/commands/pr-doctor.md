---
description: Validate the repo against the pr-bot branching model.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot doctor
```

Report any warnings or problems to the user. Do not attempt to auto-fix — surface and discuss first.
