---
description: Bootstrap a new project with the full pr-bot model wired up.
argument-hint: <name> [--at <path>] [--description "..."] [--public] [--no-push] [--no-release]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" toolbar repo template $ARGUMENTS
```

Creates a directory with a Python project skeleton (pyproject + ruff + pytest + CI workflow + CLAUDE.md/AGENTS.md), runs `git init`, makes the initial commit, cuts `release/0.1`, and (by default) creates the GitHub repo via `gh repo create --private --push`.

If `$ARGUMENTS` is empty, ask the user for the project `<name>`. Defaults: org `${GH_ORG:-andrewrothstein}`, mirror `${GH_MIRROR:-https://github.com}`, private visibility.
