---
description: Auto-draft docs/releases/X.Y.Z.md from PRs merged since the previous tag.
argument-hint: <X.Y.Z> [--edit] [--print] [--since <ref>] [--base <branch>] [--force]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot release notes-draft $ARGUMENTS
```

`release prepare X.Y.Z` calls this automatically when `docs/releases/X.Y.Z.md` doesn't exist. Use this command to regenerate or to draft ahead of `prepare`. Always review the output — it groups by conventional-commit prefix and may miss nuance.
