---
description: Start a hotfix branch off release/X.Y.
argument-hint: <slug> --on <X.Y>
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot hotfix start $ARGUMENTS
```

Preconditions: `--on X.Y` is required; `release/X.Y` must exist. If the user omits the slug or target series, ask — do not invent either.
