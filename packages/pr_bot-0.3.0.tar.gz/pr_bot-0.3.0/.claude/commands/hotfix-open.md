---
description: Push current hotfix branch and open a PR into release/X.Y.
argument-hint: --on <X.Y> [--title "..."] [--body "..."] [--draft]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot hotfix open $ARGUMENTS
```

Preconditions: current branch is `hotfix/<slug>`; `--on X.Y` is required.
