---
description: Forward-port a hotfix commit from a release branch to main via a fix/ PR branch.
argument-hint: <sha> [--slug <slug>]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot hotfix forward-port $ARGUMENTS
```

This creates a new `fix/<slug>` off main and cherry-picks the given commit. After it succeeds, suggest `/pr-open` then `/pr-merge` to land the forward-port on main.
