---
description: Cut a new release/X.Y branch off main.
argument-hint: <X.Y> [--from <ref>] [--no-push]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot release cut $ARGUMENTS
```

If `$ARGUMENTS` is empty, ask the user for the `X.Y` series. Never guess.
