---
description: Show the GitHub target repo that toolbar would create (no side effects).
argument-hint: [--name <n>] [--org <o>] [--mirror <url>]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" toolbar repo info $ARGUMENTS
```
