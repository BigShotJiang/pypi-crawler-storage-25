---
description: Diff GitHub's actual branch protection against the declared policy.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot policy check
```

Exit 0 = match, 1 = drift. Prints per-branch diff to stdout. Use to confirm the GitHub side hasn't been edited by hand.
