---
description: Rebase current PR branch onto origin/main and force-push with lease.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr sync
```

If the rebase hits a conflict, `pr-bot pr sync` will exit with step-by-step resolution guidance and leave the rebase state intact. Do not auto-resolve conflicts — let the user fix them, then re-run `/pr-sync`.
