---
description: Push current PR branch and open a PR against main.
argument-hint: [--draft] [--title "..."] [--body "..."] [--web]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr open $ARGUMENTS
```

Preconditions: current branch is `feat/<slug>` or `fix/<slug>`. If the user doesn't specify `--title`/`--body`, `pr-bot` will auto-fill from commit messages.
