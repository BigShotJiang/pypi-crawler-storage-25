---
description: Bump pyproject.toml to X.Y.Z and commit on the matching release/X.Y branch.
argument-hint: <X.Y.Z> [--no-push]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot release prepare $ARGUMENTS
```

Pairs with `/release-tag` — run `prepare` first to bump the version, then `tag` to cut the release. If `$ARGUMENTS` is empty or doesn't look like semver, ask the user.
