---
description: Push every branch in the stack and ensure each has a linked PR.
argument-hint: [--no-drafts]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack push $ARGUMENTS
```

Pushes each branch (force-push-with-lease if already on origin), opens any missing PRs against the right parent, and rewrites each PR body's `<!-- pr-bot:stack -->` block so all PRs cross-link to each other. By default, all but the bottom-most are opened as drafts. Idempotent — safe to re-run after every commit.
