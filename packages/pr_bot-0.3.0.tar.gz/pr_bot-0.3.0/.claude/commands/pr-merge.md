---
description: Squash-merge the current PR into main and clean up the branch.
argument-hint: [--auto]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr merge $ARGUMENTS
```

This squash-merges, deletes the remote branch, fast-forwards local main, and prunes the local branch. With `--auto`, queues an auto-merge and returns.
