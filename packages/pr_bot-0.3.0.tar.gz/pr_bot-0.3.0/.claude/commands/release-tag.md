---
description: Tag X.Y.Z on the matching release/X.Y branch and create a GitHub release.
argument-hint: <X.Y.Z> [--notes-file <path> | --notes "..."] [--no-gh-release] [--no-push]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot release tag $ARGUMENTS
```

If `$ARGUMENTS` is empty or doesn't look like semver, ask the user for the `X.Y.Z` tag. You may suggest `pr-bot release next-patch` to compute the next patch.

Prefer `--notes-file docs/releases/X.Y.Z.md` over `--notes "$(cat ...)"`. Run `/release-prepare X.Y.Z` first to bump pyproject.toml.
