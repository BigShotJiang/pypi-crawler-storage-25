---
description: Start a new PR branch off main (feat/fix + slug).
argument-hint: <feat|fix> <slug>
---

Parse `$ARGUMENTS` as `<type> <slug>` where type is `feat` or `fix` and slug is kebab-case.

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot pr start $ARGUMENTS
```

If the argument form doesn't match `<type> <slug>`, ask the user for both. Do not invent a slug from their prompt without confirming.
