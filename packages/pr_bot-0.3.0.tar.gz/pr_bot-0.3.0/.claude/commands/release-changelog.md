---
description: Regenerate CHANGELOG.md from docs/releases/*.md.
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot release changelog
```

`pr-bot release prepare X.Y.Z` calls this automatically — only run it directly when you've edited release notes outside of a normal `prepare` flow.
