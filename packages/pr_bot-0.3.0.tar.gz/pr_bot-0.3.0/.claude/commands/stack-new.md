---
description: Create a stack of dependent PR branches (each based on the previous).
argument-hint: <slug-1> <slug-2> [slug-3 ...]
---

Run:

```bash
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot stack new $ARGUMENTS
```

Each arg is `feat:slug`, `fix:slug`, or just `slug` (defaults to feat). The first becomes the bottom of the stack (off main); each subsequent branches off the previous. State lives in `.git/pr-bot/stack.json` (per-clone). Leaves you on the bottom branch.

If `$ARGUMENTS` has fewer than 2 branches, ask the user — a one-branch "stack" is just a regular PR.
