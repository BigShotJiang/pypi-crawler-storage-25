"""Integration tests for pr_bot.commands.doctor."""

from __future__ import annotations

import subprocess

from pr_bot.commands import doctor as doctor_cmd


def _g(repo, *args):
    return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()


def test_doctor_minimal_repo_ok(repo, capsys):
    rc = doctor_cmd.check()
    out = capsys.readouterr().out
    assert rc == 0
    # On a fresh repo (no remote, no pyproject) we get warnings, not problems.
    assert "main branch: main" in out
    assert "ok." in out


def test_doctor_flags_merge_commit(repo, capsys):
    # Build a merge commit on main to trigger the "expected linear" check.
    _g(repo, "checkout", "-b", "tmp")
    _g(repo, "commit", "--allow-empty", "-q", "-m", "tmp commit")
    _g(repo, "checkout", "main")
    _g(repo, "merge", "--no-ff", "-q", "-m", "merge tmp", "tmp")
    rc = doctor_cmd.check()
    out = capsys.readouterr().out
    assert rc == 1
    assert "merge commit" in out


def test_doctor_flags_invalid_branch_name(repo, capsys):
    _g(repo, "checkout", "-b", "wip/random")
    _g(repo, "checkout", "main")
    doctor_cmd.check()
    out = capsys.readouterr().out
    assert "wip/random" in out
    assert "does not match" in out


def test_doctor_flags_invalid_tag(repo, capsys):
    _g(repo, "tag", "v1.0")  # not X.Y.Z
    doctor_cmd.check()
    out = capsys.readouterr().out
    assert "v1.0" in out
    assert "X.Y.Z semver" in out


def test_doctor_pyproject_check(tmp_path, monkeypatch):
    """pyproject version check works against an existing pyproject.toml."""
    repo_dir = tmp_path / "repo"
    repo_dir.mkdir()
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=repo_dir, check=True)
    subprocess.run(["git", "config", "user.email", "t@e.com"], cwd=repo_dir, check=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=repo_dir, check=True)
    subprocess.run(["git", "commit", "--allow-empty", "-q", "-m", "i"], cwd=repo_dir, check=True)
    (repo_dir / "pyproject.toml").write_text('[project]\nname="x"\nversion="0.1.0"\n')
    monkeypatch.chdir(repo_dir)
    rc = doctor_cmd.check()
    assert rc == 0
