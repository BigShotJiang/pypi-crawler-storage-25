"""Integration tests for pr_bot.commands.hotfix."""

from __future__ import annotations

import subprocess

import pytest

from pr_bot.commands import hotfix as hf_cmd
from pr_bot.commands import release as rel_cmd


def _git(repo, *args):
    return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()


def _current_branch(repo):
    return _git(repo, "rev-parse", "--abbrev-ref", "HEAD")


class TestStart:
    def test_creates_hotfix_branch_off_release(self, repo):
        rel_cmd.cut("1.4", from_ref=None, push=False)
        _git(repo, "checkout", "main")
        hf_cmd.start("npe-on-logout", on="1.4")
        assert _current_branch(repo) == "hotfix/npe-on-logout"
        # branched from release/1.4 (HEAD's parent should match release/1.4's HEAD)
        rel_head = _git(repo, "rev-parse", "release/1.4")
        assert rel_head == _git(repo, "rev-parse", "HEAD")

    def test_rejects_missing_release(self, repo):
        with pytest.raises(SystemExit, match="release/9.9 does not exist"):
            hf_cmd.start("x", on="9.9")

    def test_invalid_series_rejected(self, repo):
        with pytest.raises(SystemExit, match="X.Y"):
            hf_cmd.start("x", on="bogus")


class TestForwardPort:
    def test_cherry_picks_onto_main(self, repo):
        # Set up: release branch with a fix commit, then forward-port to main.
        rel_cmd.cut("1.4", from_ref=None, push=False)
        f = repo / "fix.txt"
        f.write_text("fixed\n")
        _git(repo, "add", "fix.txt")
        _git(repo, "commit", "-q", "-m", "hotfix: fix the thing")
        sha = _git(repo, "rev-parse", "HEAD")
        _git(repo, "checkout", "main")
        hf_cmd.forward_port(ref=sha, slug="forward-fix")
        assert _current_branch(repo) == "fix/forward-fix"
        # cherry-pick brought the file with it
        assert (repo / "fix.txt").read_text() == "fixed\n"

    def test_default_slug_derives_from_sha(self, repo):
        rel_cmd.cut("1.4", from_ref=None, push=False)
        f = repo / "fix.txt"
        f.write_text("y")
        _git(repo, "add", "fix.txt")
        _git(repo, "commit", "-q", "-m", "hotfix")
        sha = _git(repo, "rev-parse", "HEAD")
        _git(repo, "checkout", "main")
        hf_cmd.forward_port(ref=sha, slug=None)
        assert _current_branch(repo).startswith("fix/forward-port-")
