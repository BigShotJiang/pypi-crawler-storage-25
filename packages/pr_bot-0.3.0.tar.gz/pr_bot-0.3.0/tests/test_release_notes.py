from __future__ import annotations

from pr_bot.names import Version
from pr_bot.release_notes import Item, classify, render


class TestClassify:
    def test_feat(self):
        assert classify("feat: add login button") == ("feat", "add login button")

    def test_fix_with_scope(self):
        assert classify("fix(parser): handle empty input") == ("fix", "handle empty input")

    def test_breaking_change_marker(self):
        assert classify("feat!: drop python 3.13") == ("feat", "drop python 3.13")

    def test_chore_goes_to_infra(self):
        assert classify("chore: bump deps") == ("infra", "bump deps")

    def test_test_prefix_goes_to_infra(self):
        assert classify("test: add coverage") == ("infra", "add coverage")

    def test_unknown_goes_to_other(self):
        assert classify("Random title with no prefix") == ("other", "Random title with no prefix")


class TestRender:
    def test_groups_buckets_in_order(self):
        v = Version(0, 2, 0)
        items = [
            Item(1, "add login", "feat"),
            Item(2, "off-by-one", "fix"),
            Item(3, "bump uv", "infra"),
            Item(4, "ad-hoc", "other"),
        ]
        out = render(v, items)
        assert "# pr-bot 0.2.0" in out
        # Order: What's new → Fixes → Infrastructure → Other
        i_new = out.index("## What's new")
        i_fix = out.index("## Fixes")
        i_inf = out.index("## Infrastructure")
        i_other = out.index("## Other")
        assert i_new < i_fix < i_inf < i_other

    def test_empty_renders_placeholder(self):
        v = Version(0, 1, 0)
        out = render(v, [])
        assert "# pr-bot 0.1.0" in out
        assert "No merged PRs found" in out

    def test_pr_numbers_appear(self):
        v = Version(1, 0, 0)
        out = render(v, [Item(42, "shiny new thing", "feat")])
        assert "(#42)" in out
        assert "shiny new thing" in out

    def test_only_fix_section_present(self):
        v = Version(1, 2, 3)
        out = render(v, [Item(7, "patch the leak", "fix")])
        assert "## Fixes" in out
        assert "## What's new" not in out
        assert "## Infrastructure" not in out
