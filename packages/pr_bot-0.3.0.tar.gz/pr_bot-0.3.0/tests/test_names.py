import pytest

from pr_bot.names import (
    PrBranch,
    ReleaseLine,
    Version,
    normalize_slug,
    parse_pr_branch,
    parse_release_branch,
    parse_version,
    pr_branch,
    require_pr_branch,
    require_release_branch,
)


class TestSlugNormalization:
    def test_strips_and_lowercases(self):
        assert normalize_slug("  Add Login Button  ") == "add-login-button"

    def test_collapses_non_alnum(self):
        assert normalize_slug("fix: NPE on @logout!") == "fix-npe-on-logout"

    def test_trims_leading_trailing_hyphens(self):
        assert normalize_slug("---foo---") == "foo"


class TestPrBranch:
    def test_valid_feat(self):
        pb = pr_branch("feat", "add-login")
        assert pb == PrBranch("feat", "add-login")
        assert str(pb) == "feat/add-login"

    def test_valid_fix(self):
        assert str(pr_branch("fix", "off-by-one")) == "fix/off-by-one"

    def test_valid_hotfix(self):
        assert str(pr_branch("hotfix", "npe-logout")) == "hotfix/npe-logout"

    def test_invalid_type(self):
        with pytest.raises(SystemExit):
            pr_branch("wip", "x")

    def test_normalizes_slug(self):
        assert str(pr_branch("feat", "Add Login")) == "feat/add-login"

    def test_parse_roundtrip(self):
        assert parse_pr_branch("feat/add-login") == PrBranch("feat", "add-login")
        assert parse_pr_branch("fix/x") == PrBranch("fix", "x")
        assert parse_pr_branch("hotfix/a-b-c") == PrBranch("hotfix", "a-b-c")

    def test_parse_rejects_nonmatching(self):
        assert parse_pr_branch("main") is None
        assert parse_pr_branch("release/1.4") is None
        assert parse_pr_branch("feat/") is None
        assert parse_pr_branch("feat/UPPER") is None
        assert parse_pr_branch("wip/foo") is None

    def test_require_pr_branch_raises(self):
        with pytest.raises(SystemExit):
            require_pr_branch("main")


class TestReleaseBranch:
    def test_parse(self):
        assert parse_release_branch("release/1.4") == ReleaseLine(1, 4)
        assert parse_release_branch("release/10.20") == ReleaseLine(10, 20)

    def test_parse_rejects(self):
        assert parse_release_branch("release/1") is None
        assert parse_release_branch("release/1.4.0") is None
        assert parse_release_branch("release/v1.4") is None
        assert parse_release_branch("main") is None

    def test_branch_property(self):
        assert ReleaseLine(1, 4).branch == "release/1.4"

    def test_tag_from_line(self):
        assert ReleaseLine(1, 4).tag(2) == "1.4.2"

    def test_require_release_branch_raises(self):
        with pytest.raises(SystemExit):
            require_release_branch("feat/x")


class TestVersion:
    def test_parse(self):
        assert parse_version("1.4.0") == Version(1, 4, 0)
        assert parse_version("10.20.30") == Version(10, 20, 30)

    def test_parse_rejects(self):
        assert parse_version("v1.4.0") is None
        assert parse_version("1.4") is None
        assert parse_version("1.4.0-rc1") is None

    def test_release_line(self):
        assert Version(1, 4, 2).release_line == ReleaseLine(1, 4)

    def test_str(self):
        assert str(Version(1, 4, 2)) == "1.4.2"
