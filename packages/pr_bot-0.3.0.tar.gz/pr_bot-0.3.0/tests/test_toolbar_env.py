import pytest

from toolbar.env import DEFAULT_MIRROR, DEFAULT_ORG, resolve


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    for k in ("GH_MIRROR", "GH_ORG", "GH_HOST"):
        monkeypatch.delenv(k, raising=False)


def test_defaults():
    t = resolve(name="pr-bot")
    assert t.name == "pr-bot"
    assert t.org == DEFAULT_ORG
    assert t.mirror == DEFAULT_MIRROR
    assert t.host == "github.com"
    assert t.slug == f"{DEFAULT_ORG}/pr-bot"
    assert t.browser_url == f"{DEFAULT_MIRROR}/{DEFAULT_ORG}/pr-bot"


def test_env_overrides(monkeypatch):
    monkeypatch.setenv("GH_MIRROR", "https://gh.corp.example/")
    monkeypatch.setenv("GH_ORG", "widgets-inc")
    t = resolve(name="secret-sauce")
    assert t.mirror == "https://gh.corp.example/"
    assert t.host == "gh.corp.example"
    assert t.org == "widgets-inc"
    assert t.slug == "widgets-inc/secret-sauce"


def test_flag_overrides_env(monkeypatch):
    monkeypatch.setenv("GH_MIRROR", "https://wrong.example")
    monkeypatch.setenv("GH_ORG", "wrong-org")
    t = resolve(name="x", org="right-org", mirror="https://right.example")
    assert t.org == "right-org"
    assert t.mirror == "https://right.example"
    assert t.host == "right.example"


def test_gh_host_wins_over_mirror_host(monkeypatch):
    monkeypatch.setenv("GH_MIRROR", "https://from-mirror.example")
    monkeypatch.setenv("GH_HOST", "from-gh-host.example")
    t = resolve(name="x")
    assert t.host == "from-gh-host.example"
    assert t.mirror == "https://from-mirror.example"


def test_mirror_without_scheme():
    t = resolve(name="x", mirror="gh.corp.example")
    assert t.host == "gh.corp.example"
