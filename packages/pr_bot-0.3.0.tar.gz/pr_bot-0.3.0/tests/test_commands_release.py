"""Integration tests for pr_bot.commands.release."""

from __future__ import annotations

import subprocess

import pytest

from pr_bot.commands import release as rel_cmd


def _git(repo, *args):
    return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()


def _current_branch(repo):
    return _git(repo, "rev-parse", "--abbrev-ref", "HEAD")


def _write_pyproject(repo, version: str):
    (repo / "pyproject.toml").write_text(
        f'[project]\nname = "x"\nversion = "{version}"\n'
    )
    _git(repo, "add", "pyproject.toml")
    _git(repo, "commit", "-q", "-m", "add pyproject")


class TestCut:
    def test_creates_release_branch(self, repo):
        rel_cmd.cut("1.4", from_ref=None, push=False)
        assert _current_branch(repo) == "release/1.4"

    def test_invalid_series_rejected(self, repo):
        with pytest.raises(SystemExit, match="X.Y"):
            rel_cmd.cut("1", from_ref=None, push=False)

    def test_idempotent_rejected(self, repo):
        rel_cmd.cut("1.4", from_ref=None, push=False)
        _git(repo, "checkout", "main")
        with pytest.raises(SystemExit, match="already exists"):
            rel_cmd.cut("1.4", from_ref=None, push=False)


class TestPrepare:
    def test_bumps_pyproject_and_commits(self, repo):
        _write_pyproject(repo, "0.1.0")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        rel_cmd.prepare("0.1.1", push=False)
        text = (repo / "pyproject.toml").read_text()
        assert 'version = "0.1.1"' in text
        # commit landed
        msg = _git(repo, "log", "-1", "--format=%s")
        assert msg == "chore: bump to 0.1.1"
        # CHANGELOG.md was generated and staged in the same commit
        changelog = (repo / "CHANGELOG.md").read_text()
        assert changelog.startswith("# Changelog")

    def test_idempotent_when_already_at_version(self, repo, capsys):
        _write_pyproject(repo, "0.1.1")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        rel_cmd.prepare("0.1.1", push=False)
        out = capsys.readouterr().out
        assert "already at 0.1.1" in out


class TestTag:
    def test_refuses_on_pyproject_mismatch(self, repo):
        _write_pyproject(repo, "0.1.0")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        with pytest.raises(SystemExit, match="pyproject.toml"):
            rel_cmd.tag("0.1.1", ref=None, notes=None, notes_file=None,
                        gh_release=False, push=False, skip_version_check=False)

    def test_mismatch_message_suggests_release_prepare(self, repo):
        _write_pyproject(repo, "0.1.0")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        with pytest.raises(SystemExit) as excinfo:
            rel_cmd.tag("0.1.1", ref=None, notes=None, notes_file=None,
                        gh_release=False, push=False, skip_version_check=False)
        msg = str(excinfo.value)
        assert "pr-bot release prepare 0.1.1" in msg
        assert "sed -i" not in msg

    def test_succeeds_when_matched(self, repo):
        _write_pyproject(repo, "0.1.1")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        rel_cmd.tag("0.1.1", ref=None, notes=None, notes_file=None,
                    gh_release=False, push=False, skip_version_check=False)
        tags = _git(repo, "tag", "--list").splitlines()
        assert "0.1.1" in tags

    def test_skip_version_check_bypasses(self, repo, capsys):
        _write_pyproject(repo, "0.1.0")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        rel_cmd.tag("0.1.1", ref=None, notes=None, notes_file=None,
                    gh_release=False, push=False, skip_version_check=True)
        out = capsys.readouterr().out
        assert "WARNING" in out


class TestNextPatch:
    def test_zero_when_no_tags(self, repo, capsys):
        rel_cmd.cut("0.1", from_ref=None, push=False)
        capsys.readouterr()  # discard cut output
        rel_cmd.next_patch(series=None)
        assert capsys.readouterr().out.strip() == "0.1.0"

    def test_increments_highest(self, repo, capsys):
        _write_pyproject(repo, "0.1.5")
        rel_cmd.cut("0.1", from_ref=None, push=False)
        for v in ("0.1.0", "0.1.1", "0.1.5", "0.1.3"):
            _git(repo, "tag", v)
        capsys.readouterr()  # discard cut output
        rel_cmd.next_patch(series=None)
        assert capsys.readouterr().out.strip() == "0.1.6"
