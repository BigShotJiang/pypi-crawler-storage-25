from __future__ import annotations

from pr_bot.policy import Policy, default_policy, diff, load, to_payload


class TestLoad:
    def test_full(self, tmp_path):
        p = tmp_path / ".pr-bot.toml"
        p.write_text(
            """
[policy]
linear_history = true
allow_force_push = false
required_status_checks = ["test", "lint"]
required_approving_review_count = 1
protected_branches = ["main", "release/1.0"]
""".lstrip()
        )
        pol = load(p)
        assert pol.linear_history is True
        assert pol.allow_force_push is False
        assert pol.required_status_checks == ("test", "lint")
        assert pol.required_approving_review_count == 1
        assert pol.protected_branches == ("main", "release/1.0")

    def test_partial_uses_defaults(self, tmp_path):
        p = tmp_path / ".pr-bot.toml"
        p.write_text("[policy]\nlinear_history = false\n")
        pol = load(p)
        assert pol.linear_history is False
        assert pol.required_status_checks == ("test",)  # default
        assert pol.required_approving_review_count == 0  # default


class TestPayload:
    def test_required_fields_present(self):
        body = to_payload(default_policy())
        for k in (
            "required_status_checks",
            "enforce_admins",
            "required_pull_request_reviews",
            "restrictions",
            "required_linear_history",
            "allow_force_pushes",
            "allow_deletions",
        ):
            assert k in body

    def test_status_checks_listed(self):
        body = to_payload(Policy(required_status_checks=("test", "lint")))
        assert body["required_status_checks"] == {"strict": False, "contexts": ["test", "lint"]}

    def test_no_status_checks_yields_null(self):
        body = to_payload(Policy(required_status_checks=()))
        assert body["required_status_checks"] is None

    def test_review_count_passes_through(self):
        body = to_payload(Policy(required_approving_review_count=2))
        assert body["required_pull_request_reviews"]["required_approving_review_count"] == 2

    def test_linear_history_flag(self):
        assert to_payload(Policy(linear_history=True))["required_linear_history"] is True
        assert to_payload(Policy(linear_history=False))["required_linear_history"] is False


class TestDiff:
    def test_match_yields_empty(self):
        actual = {
            "required_linear_history": {"enabled": True},
            "allow_force_pushes": {"enabled": False},
            "allow_deletions": {"enabled": False},
            "enforce_admins": {"enabled": False},
            "required_status_checks": {"contexts": ["test"]},
            "required_pull_request_reviews": {"required_approving_review_count": 0},
        }
        assert diff(default_policy(), actual) == []

    def test_linear_history_drift(self):
        actual = {
            "required_linear_history": {"enabled": False},
            "allow_force_pushes": {"enabled": False},
            "allow_deletions": {"enabled": False},
            "enforce_admins": {"enabled": False},
            "required_status_checks": {"contexts": ["test"]},
            "required_pull_request_reviews": {"required_approving_review_count": 0},
        }
        diffs = diff(default_policy(), actual)
        assert any("linear_history" in d for d in diffs)

    def test_status_checks_drift(self):
        actual = {
            "required_linear_history": {"enabled": True},
            "allow_force_pushes": {"enabled": False},
            "allow_deletions": {"enabled": False},
            "enforce_admins": {"enabled": False},
            "required_status_checks": {"contexts": ["other"]},
            "required_pull_request_reviews": {"required_approving_review_count": 0},
        }
        diffs = diff(default_policy(), actual)
        assert any("required_status_checks" in d for d in diffs)
