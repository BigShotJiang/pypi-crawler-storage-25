from __future__ import annotations

from pr_bot.stack import (
    Stack,
    base_for,
    clear,
    load,
    name_from_slugs,
    parent_of,
    parse_stack_arg,
    save,
)


class TestParseStackArg:
    def test_default_feat(self):
        assert parse_stack_arg("foo") == ("feat", "foo")

    def test_explicit_type(self):
        assert parse_stack_arg("fix:bar") == ("fix", "bar")

    def test_hotfix(self):
        assert parse_stack_arg("hotfix:patch-1") == ("hotfix", "patch-1")


class TestStack:
    def test_position_of(self):
        s = Stack(name="x", branches=("feat/a", "feat/b", "feat/c"))
        assert s.position_of("feat/a") == 0
        assert s.position_of("feat/b") == 1
        assert s.position_of("missing") is None

    def test_parent_of(self):
        s = Stack(name="x", branches=("feat/a", "feat/b", "feat/c"))
        assert parent_of(s, "feat/a") is None
        assert parent_of(s, "feat/b") == "feat/a"
        assert parent_of(s, "feat/c") == "feat/b"

    def test_base_for(self):
        s = Stack(name="x", branches=("feat/a", "feat/b"))
        assert base_for(s, "feat/a", "main") == "main"
        assert base_for(s, "feat/b", "main") == "feat/a"


class TestPersistence:
    def test_save_then_load_roundtrip(self, tmp_path):
        gitdir = tmp_path / ".git"
        gitdir.mkdir()
        s = Stack(name="auth", branches=("feat/x", "feat/y"))
        path = save(s, gitdir=gitdir)
        assert path.is_file()
        loaded = load(gitdir=gitdir)
        assert loaded is not None
        assert loaded.name == "auth"
        assert loaded.branches == ("feat/x", "feat/y")

    def test_load_missing_returns_none(self, tmp_path):
        gitdir = tmp_path / ".git"
        gitdir.mkdir()
        assert load(gitdir=gitdir) is None

    def test_clear_removes(self, tmp_path):
        gitdir = tmp_path / ".git"
        gitdir.mkdir()
        save(Stack(name="x", branches=("feat/a", "feat/b")), gitdir=gitdir)
        assert clear(gitdir=gitdir) is True
        assert clear(gitdir=gitdir) is False  # idempotent


class TestNameFromSlugs:
    def test_uses_first_slug(self):
        assert name_from_slugs(["alpha", "beta"]) == "alpha"

    def test_empty_falls_back(self):
        assert name_from_slugs([]) == "unnamed"
