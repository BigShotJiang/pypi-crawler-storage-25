from __future__ import annotations

from pathlib import Path

from pr_bot.changelog import collect_release_files, render


def _write(p: Path, content: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)


def test_collect_sorts_versions_desc(tmp_path):
    rd = tmp_path / "releases"
    _write(rd / "0.1.0.md", "x")
    _write(rd / "0.1.10.md", "x")
    _write(rd / "0.1.2.md", "x")
    _write(rd / "1.0.0.md", "x")
    _write(rd / "notes.md", "x")  # not a version, ignored
    out = [p.stem for _, p in collect_release_files(rd)]
    assert out == ["1.0.0", "0.1.10", "0.1.2", "0.1.0"]


def test_render_includes_header_and_versions(tmp_path):
    rd = tmp_path / "releases"
    _write(rd / "0.1.0.md", "# 0.1.0\n\nfirst")
    _write(rd / "0.1.1.md", "# 0.1.1\n\nsecond")
    s = render(rd)
    assert s.startswith("# Changelog")
    assert "first" in s
    assert "second" in s
    # newer version appears earlier
    assert s.index("# 0.1.1") < s.index("# 0.1.0")


def test_render_empty_dir(tmp_path):
    rd = tmp_path / "releases"
    rd.mkdir()
    s = render(rd)
    assert s.startswith("# Changelog")
    assert s.strip() != ""
