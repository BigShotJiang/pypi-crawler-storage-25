from __future__ import annotations

from pathlib import Path

from pr_bot.pyproject import find_pyproject, read_version


def _write_pyproject(path: Path, version: str) -> None:
    path.write_text(
        f"""
[project]
name = "x"
version = "{version}"
""".lstrip()
    )


class TestFindPyproject:
    def test_in_same_dir(self, tmp_path):
        p = tmp_path / "pyproject.toml"
        _write_pyproject(p, "1.2.3")
        assert find_pyproject(tmp_path) == p

    def test_walks_up(self, tmp_path):
        p = tmp_path / "pyproject.toml"
        _write_pyproject(p, "1.2.3")
        child = tmp_path / "a" / "b" / "c"
        child.mkdir(parents=True)
        assert find_pyproject(child) == p

    def test_missing(self, tmp_path):
        child = tmp_path / "deep"
        child.mkdir()
        assert find_pyproject(child) is None


class TestReadVersion:
    def test_reads_version(self, tmp_path):
        p = tmp_path / "pyproject.toml"
        _write_pyproject(p, "0.1.1")
        assert read_version(p) == "0.1.1"

    def test_missing_returns_none(self, tmp_path):
        child = tmp_path / "deep"
        child.mkdir()
        assert read_version(find_pyproject(child)) is None

    def test_no_project_section(self, tmp_path):
        p = tmp_path / "pyproject.toml"
        p.write_text("[tool.ruff]\nline-length = 100\n")
        assert read_version(p) is None
