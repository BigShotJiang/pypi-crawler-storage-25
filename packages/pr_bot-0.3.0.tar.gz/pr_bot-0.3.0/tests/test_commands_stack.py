"""Integration tests for pr_bot.commands.stack — real git in tmp_path."""

from __future__ import annotations

import subprocess

import pytest

from pr_bot import stack
from pr_bot.commands import stack as stack_cmd


def _git(repo, *args):
    return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()


def _current(repo):
    return _git(repo, "rev-parse", "--abbrev-ref", "HEAD")


class TestStackNew:
    def test_creates_chain(self, repo):
        stack_cmd.new(["a", "b", "c"])
        # Bottom branch is the active one
        assert _current(repo) == "feat/a"
        # Each branch exists
        for br in ("feat/a", "feat/b", "feat/c"):
            r = subprocess.run(
                ["git", "rev-parse", "--verify", f"refs/heads/{br}"],
                cwd=repo,
                capture_output=True,
            )
            assert r.returncode == 0
        # Each is based on its predecessor (b's parent commit == a's HEAD; etc.)
        a_head = _git(repo, "rev-parse", "feat/a")
        b_head = _git(repo, "rev-parse", "feat/b")
        # In this fresh chain (no commits added), heads of all three equal
        # main's head since checkout -b doesn't add a commit. Verify via merge-base.
        assert _git(repo, "merge-base", "feat/a", "feat/b") == a_head
        assert _git(repo, "merge-base", "feat/b", "feat/c") == b_head
        # State file written
        s = stack.load()
        assert s is not None
        assert s.branches == ("feat/a", "feat/b", "feat/c")
        assert s.name == "a"

    def test_explicit_types(self, repo):
        stack_cmd.new(["feat:x", "fix:y"])
        s = stack.load()
        assert s is not None
        assert s.branches == ("feat/x", "fix/y")

    def test_rejects_single_branch(self, repo):
        with pytest.raises(SystemExit, match="at least 2"):
            stack_cmd.new(["only-one"])

    def test_rejects_when_stack_exists(self, repo):
        stack_cmd.new(["a", "b"])
        with pytest.raises(SystemExit, match="already exists"):
            stack_cmd.new(["c", "d"])

    def test_rejects_uncommitted_changes(self, repo):
        (repo / "x.txt").write_text("dirty")
        with pytest.raises(SystemExit, match="uncommitted"):
            stack_cmd.new(["a", "b"])

    def test_rejects_existing_branch(self, repo):
        _git(repo, "checkout", "-b", "feat/already-here")
        _git(repo, "checkout", "main")
        with pytest.raises(SystemExit, match="already exists"):
            stack_cmd.new(["already-here", "next"])


class TestStackSync:
    def test_rebases_chain_onto_main(self, repo_with_origin):
        # Build a 3-branch stack with one commit on each.
        stack_cmd.new(["a", "b", "c"])
        for br, content in [("feat/a", "A"), ("feat/b", "B"), ("feat/c", "C")]:
            _git(repo_with_origin, "checkout", br)
            (repo_with_origin / f"{content}.txt").write_text(content)
            _git(repo_with_origin, "add", f"{content}.txt")
            _git(repo_with_origin, "commit", "-q", "-m", f"add {content}")
        # Push everything once so force-with-lease works.
        for br in ("feat/a", "feat/b", "feat/c"):
            _git(repo_with_origin, "checkout", br)
            _git(repo_with_origin, "push", "-u", "origin", br)
        # Add a commit on main and push it (so origin/main is ahead of where
        # the stack was branched from).
        _git(repo_with_origin, "checkout", "main")
        (repo_with_origin / "MAIN.txt").write_text("M")
        _git(repo_with_origin, "add", "MAIN.txt")
        _git(repo_with_origin, "commit", "-q", "-m", "main edit")
        _git(repo_with_origin, "push", "origin", "main")
        # Sync the stack — every branch should now contain MAIN.txt.
        stack_cmd.sync()
        for br in ("feat/a", "feat/b", "feat/c"):
            _git(repo_with_origin, "checkout", br)
            assert (repo_with_origin / "MAIN.txt").is_file()

    def test_no_stack_rejects(self, repo_with_origin):
        with pytest.raises(SystemExit, match="no stack"):
            stack_cmd.sync()

    def test_conflict_mid_chain_leaves_state_for_user_to_resolve(self, repo_with_origin):
        """When a rebase mid-chain conflicts, sync exits with a clear hint
        and leaves the rebase in progress. After resolution + git rebase
        --continue, re-running sync should finish the rest of the chain.
        """
        from pr_bot import git as _gitmod

        repo = repo_with_origin

        # Seed main with a file that will become the conflict surface.
        f = repo / "shared.txt"
        f.write_text("base\n")
        _git(repo, "add", "shared.txt")
        _git(repo, "commit", "-q", "-m", "base shared.txt")
        _git(repo, "push", "origin", "main")

        stack_cmd.new(["a", "b", "c"])

        # feat/a: trivial commit, no conflict
        _git(repo, "checkout", "feat/a")
        (repo / "a.txt").write_text("A")
        _git(repo, "add", "a.txt")
        _git(repo, "commit", "-q", "-m", "A")

        # feat/b: edits shared.txt — will conflict with main's later edit
        _git(repo, "checkout", "feat/b")
        f.write_text("from feat/b\n")
        _git(repo, "commit", "-aq", "-m", "feat/b edits shared")

        # feat/c: trivial commit
        _git(repo, "checkout", "feat/c")
        (repo / "c.txt").write_text("C")
        _git(repo, "add", "c.txt")
        _git(repo, "commit", "-q", "-m", "C")

        # Push initial state for all three so force-with-lease works later.
        for br in ("feat/a", "feat/b", "feat/c"):
            _git(repo, "checkout", br)
            _git(repo, "push", "-u", "origin", br)

        # Now main moves forward with a conflicting edit to shared.txt.
        _git(repo, "checkout", "main")
        f.write_text("from main\n")
        _git(repo, "commit", "-aq", "-m", "main edits shared")
        _git(repo, "push", "origin", "main")

        # First sync: feat/a rebases cleanly, feat/b conflicts → SystemExit.
        with pytest.raises(SystemExit, match="conflict"):
            stack_cmd.sync()
        assert _gitmod.rebase_in_progress() is True
        # During a rebase, HEAD is detached. The head-name file in
        # .git/rebase-merge points at the branch being rebased.
        gitdir = _git(repo, "rev-parse", "--git-dir")
        from pathlib import Path

        head_name = (Path(repo) / gitdir / "rebase-merge" / "head-name").read_text().strip()
        assert head_name == "refs/heads/feat/b"

        # User resolves the conflict and continues the rebase.
        f.write_text("resolved\n")
        _git(repo, "add", "shared.txt")
        _git(repo, "rebase", "--continue")
        assert _gitmod.rebase_in_progress() is False

        # Re-run sync — finishes feat/c onto the resolved feat/b.
        stack_cmd.sync()
        _git(repo, "checkout", "feat/c")
        assert (repo / "shared.txt").read_text() == "resolved\n"
        # feat/c retained its own commit
        assert (repo / "c.txt").read_text() == "C"


class TestStackStatus:
    def test_prints_branches(self, repo, capsys):
        stack_cmd.new(["a", "b"])
        capsys.readouterr()
        stack_cmd.status()
        out = capsys.readouterr().out
        assert "stack: a" in out
        assert "feat/a" in out
        assert "feat/b" in out

    def test_no_stack_rejects(self, repo):
        with pytest.raises(SystemExit, match="no stack"):
            stack_cmd.status()


class TestStackAbandon:
    def test_clears_state(self, repo, capsys):
        stack_cmd.new(["a", "b"])
        capsys.readouterr()
        stack_cmd.abandon()
        out = capsys.readouterr().out
        assert "abandoned" in out
        # Subsequent status fails — state is gone
        with pytest.raises(SystemExit, match="no stack"):
            stack_cmd.status()

    def test_no_stack_is_noop(self, repo, capsys):
        stack_cmd.abandon()
        out = capsys.readouterr().out
        assert "no stack" in out
