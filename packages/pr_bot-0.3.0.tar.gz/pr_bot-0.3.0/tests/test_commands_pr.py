"""Integration tests for pr_bot.commands.pr.

Covers golden paths and the error guards we've shipped (uncommitted-rejection,
existing-branch, missing remote, stack-aware base routing, etc.).
"""

from __future__ import annotations

import json
import subprocess

import pytest

from pr_bot.commands import pr as pr_cmd


def _git(repo, *args):
    return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True).stdout.strip()


def _current_branch(repo):
    return _git(repo, "rev-parse", "--abbrev-ref", "HEAD")


class TestStart:
    def test_clean_creates_branch(self, repo):
        pr_cmd.start("feat", "add-login")
        assert _current_branch(repo) == "feat/add-login"

    def test_uncommitted_rejected(self, repo):
        (repo / "x.txt").write_text("dirty")
        with pytest.raises(SystemExit, match="uncommitted"):
            pr_cmd.start("feat", "x")

    def test_existing_branch_rejected(self, repo):
        pr_cmd.start("feat", "x")
        _git(repo, "checkout", "main")
        with pytest.raises(SystemExit, match="already exists"):
            pr_cmd.start("feat", "x")

    def test_invalid_slug_rejected(self, repo):
        # !!! normalizes to "" which fails the slug regex
        with pytest.raises(SystemExit, match="invalid slug"):
            pr_cmd.start("feat", "!!!")


class TestStatus:
    def test_runs_clean_no_remote(self, repo, capsys):
        pr_cmd.start("feat", "x")
        pr_cmd.status()
        out = capsys.readouterr().out
        assert "branch: feat/x" in out
        assert "no 'origin' remote" in out

    def test_runs_with_remote_no_pr(self, repo_with_origin, fake_gh, capsys):
        pr_cmd.start("feat", "x")
        # gh pr view fails (no PR yet) → exit 0 from fake gh but empty stdout
        fake_gh.set_response("")
        pr_cmd.status()
        out = capsys.readouterr().out
        assert "branch: feat/x" in out


class TestOpenBaseSelection:
    """The 'pr open' command shells out to 'gh pr create'. With the fake_gh
    shim on PATH we can observe the args it would send."""

    def test_solo_branch_targets_main(self, repo_with_origin, fake_gh):
        pr_cmd.start("feat", "x")
        pr_cmd.open_(draft=False, title="t", body="b", web=False, base=None)
        # Last gh invocation was 'pr create'
        last = fake_gh.calls[-1]
        # Find --base flag
        idx = last.index("--base")
        assert last[idx + 1] == "main"

    def test_stack_branch_targets_parent(self, repo_with_origin, fake_gh):
        from pr_bot.commands import stack as stack_cmd

        stack_cmd.new(["a", "b"])
        # Switch to top-of-stack feat/b and open it; base should be feat/a.
        _git(repo_with_origin, "checkout", "feat/b")
        pr_cmd.open_(draft=False, title="t", body="b", web=False, base=None)
        last = fake_gh.calls[-1]
        idx = last.index("--base")
        assert last[idx + 1] == "feat/a"

    def test_stack_bottom_targets_main(self, repo_with_origin, fake_gh):
        from pr_bot.commands import stack as stack_cmd

        stack_cmd.new(["a", "b"])
        # feat/a is the bottom of the stack — its base is still main.
        _git(repo_with_origin, "checkout", "feat/a")
        pr_cmd.open_(draft=False, title="t", body="b", web=False, base=None)
        last = fake_gh.calls[-1]
        idx = last.index("--base")
        assert last[idx + 1] == "main"

    def test_explicit_base_overrides_stack(self, repo_with_origin, fake_gh):
        from pr_bot.commands import stack as stack_cmd

        stack_cmd.new(["a", "b"])
        _git(repo_with_origin, "checkout", "feat/b")
        # User overrides — should target main, not feat/a.
        pr_cmd.open_(draft=False, title="t", body="b", web=False, base="main")
        last = fake_gh.calls[-1]
        idx = last.index("--base")
        assert last[idx + 1] == "main"


class TestCleanup:
    def test_refuses_open_pr(self, repo_with_origin, fake_gh):
        pr_cmd.start("feat", "x")
        fake_gh.set_response(json.dumps({"number": 42, "state": "OPEN", "isDraft": False, "title": "x"}))
        with pytest.raises(SystemExit, match="still OPEN"):
            pr_cmd.cleanup()

    def test_succeeds_on_merged_pr(self, repo_with_origin, fake_gh):
        pr_cmd.start("feat", "x")
        # PR closed → cleanup should switch to main and delete the branch
        fake_gh.set_response(json.dumps({"number": 42, "state": "MERGED", "isDraft": False, "title": "x"}))
        pr_cmd.cleanup()
        assert _current_branch(repo_with_origin) == "main"
        # feat/x should be gone locally
        r = subprocess.run(
            ["git", "rev-parse", "--verify", "refs/heads/feat/x"],
            cwd=repo_with_origin,
            capture_output=True,
        )
        assert r.returncode != 0

    def test_refuses_non_pr_branch(self, repo_with_origin, fake_gh):
        with pytest.raises(SystemExit, match="not a PR branch"):
            pr_cmd.cleanup()

    def test_uncommitted_rejected(self, repo_with_origin, fake_gh):
        pr_cmd.start("feat", "x")
        (repo_with_origin / "y.txt").write_text("dirty")
        with pytest.raises(SystemExit, match="uncommitted"):
            pr_cmd.cleanup()
