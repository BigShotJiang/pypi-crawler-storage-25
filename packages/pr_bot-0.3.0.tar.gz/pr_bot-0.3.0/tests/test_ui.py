"""Smoke tests for pr-bot ui (Textual). Step 1 only verifies the layout mounts
and basic hotkeys behave; later TUI steps will exercise live data flows."""

from __future__ import annotations

import pytest

from pr_bot.ui import PrBotApp


@pytest.mark.asyncio
async def test_app_mounts_three_panes():
    app = PrBotApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        for pid in ("branches", "detail", "checks"):
            node = app.query_one(f"#{pid}")
            assert node is not None


@pytest.mark.asyncio
async def test_help_lists_all_hotkeys():
    """The footer should advertise the new s/r/m/c/o bindings."""
    app = PrBotApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        keys = {b.key for b in app.BINDINGS}
        assert {"q", "g", "?", "s", "r", "m", "c", "o"}.issubset(keys)
        await pilot.press("q")


@pytest.mark.asyncio
async def test_quit_hotkey():
    app = PrBotApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("q")
        # If 'q' didn't quit, run_test would deadlock; reaching here is success.


@pytest.mark.asyncio
async def test_help_hotkey_emits_notification():
    app = PrBotApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("question_mark")
        await pilot.press("q")


def test_pr_summary_formats_dict():
    from pr_bot.ui import _pr_summary

    pr = {
        "number": 42,
        "state": "OPEN",
        "isDraft": False,
        "title": "fix the thing",
        "baseRefName": "main",
        "headRefName": "fix/the-thing",
        "url": "https://github.com/foo/bar/pull/42",
    }
    out = _pr_summary(pr)
    assert "#42 OPEN" in out
    assert "fix/the-thing → main" in out
    assert "https://github.com/foo/bar/pull/42" in out
    assert "(draft)" not in out


def test_render_checks_with_icons():
    from pr_bot.ui import render_checks

    out = render_checks([
        {"name": "test", "bucket": "pass", "link": "https://x/1"},
        {"name": "lint", "bucket": "fail", "link": "https://x/2"},
        {"name": "deploy", "bucket": "pending", "link": "https://x/3"},
    ])
    assert "✓" in out and "test" in out and "https://x/1" in out
    assert "✗" in out and "lint" in out
    assert "⏳" in out and "deploy" in out


def test_render_checks_empty():
    from pr_bot.ui import render_checks

    assert render_checks([]) == "(no checks)"


def test_render_stack_lists_branches():
    from pr_bot.stack import Stack
    from pr_bot.ui import render_stack

    s = Stack(name="auth", branches=("feat/a", "feat/b", "feat/c"))
    out = render_stack(s)
    assert "auth" in out
    assert "3 branches" in out
    assert "1/3 feat/a" in out
    assert "2/3 feat/b" in out
    assert "3/3 feat/c" in out


def test_render_releases_shows_latest_tag(repo):
    """Use the conftest 'repo' fixture for a real git repo with tags."""
    import subprocess

    from pr_bot.ui import render_releases

    def g(*args):
        subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True)

    g("checkout", "-b", "release/1.0")
    g("tag", "1.0.0")
    g("tag", "1.0.1")
    g("checkout", "-b", "release/1.1")
    g("tag", "1.1.0")
    g("checkout", "main")

    out = render_releases(["release/1.0", "release/1.1"])
    assert "release/1.0" in out and "v1.0.1" in out
    assert "release/1.1" in out and "v1.1.0" in out


def test_render_releases_no_tags(repo):
    import subprocess

    from pr_bot.ui import render_releases

    subprocess.run(
        ["git", "checkout", "-b", "release/2.0"],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    )
    out = render_releases(["release/2.0"])
    assert "(no tags)" in out


def test_pr_summary_marks_draft():
    from pr_bot.ui import _pr_summary

    pr = {
        "number": 7,
        "state": "OPEN",
        "isDraft": True,
        "title": "WIP",
        "baseRefName": "main",
        "headRefName": "feat/wip",
        "url": "https://example/7",
    }
    assert "(draft)" in _pr_summary(pr)


@pytest.mark.asyncio
async def test_branch_list_populates_in_real_repo(tmp_path, monkeypatch):
    """Run the app inside a tmp_path git repo with a few branches; verify
    the ListView has BranchItems matching what 'git branch' would return."""
    import subprocess

    from pr_bot.ui import BranchItem

    repo = tmp_path / "repo"
    repo.mkdir()

    def _g(*args):
        return subprocess.run(["git", *args], cwd=repo, check=True, capture_output=True, text=True)

    _g("init", "-q", "-b", "main")
    _g("config", "user.email", "t@e.com")
    _g("config", "user.name", "T")
    _g("commit", "--allow-empty", "-q", "-m", "initial")
    _g("checkout", "-b", "feat/x")
    _g("checkout", "-b", "feat/y")
    _g("checkout", "main")
    monkeypatch.chdir(repo)

    app = PrBotApp()
    async with app.run_test() as pilot:
        await pilot.pause()
        from textual.widgets import ListView

        lv = app.query_one("#branch-list", ListView)
        items = [c for c in lv.children if isinstance(c, BranchItem)]
        names = sorted(i.branch for i in items)
        assert names == sorted(["main", "feat/x", "feat/y"])
        # main should be at the top
        assert items[0].branch == "main"
        await pilot.press("q")
