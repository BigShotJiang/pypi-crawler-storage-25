"""Shared fixtures for command-module integration tests."""

from __future__ import annotations

import os
import subprocess
import textwrap
from pathlib import Path

import pytest


def _git(repo: Path, *args: str) -> str:
    r = subprocess.run(
        ["git", *args],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    )
    return r.stdout.strip()


def _init_repo(path: Path, *, initial_branch: str = "main") -> Path:
    path.mkdir(parents=True, exist_ok=True)
    _git(path, "init", "-q", "-b", initial_branch)
    _git(path, "config", "user.email", "test@example.com")
    _git(path, "config", "user.name", "Test")
    _git(path, "commit", "--allow-empty", "-q", "-m", "initial")
    return path


@pytest.fixture
def repo(tmp_path, monkeypatch):
    """Plain git repo, no remote, on main, one initial commit, cwd switched."""
    r = _init_repo(tmp_path / "repo")
    monkeypatch.chdir(r)
    return r


@pytest.fixture
def repo_with_origin(tmp_path, monkeypatch):
    """Git repo with a bare 'origin' remote, main pushed, cwd switched."""
    bare = tmp_path / "origin.git"
    subprocess.run(["git", "init", "--bare", "-q", "-b", "main", str(bare)], check=True)
    r = _init_repo(tmp_path / "repo")
    _git(r, "remote", "add", "origin", str(bare))
    _git(r, "push", "-u", "origin", "main")
    monkeypatch.chdir(r)
    return r


@pytest.fixture
def fake_gh(tmp_path, monkeypatch):
    """Put a stub `gh` on PATH that records args and emits a canned stdout.

    Set the canned output by writing fixture.set_response('<json>') before
    the action runs. Read recorded calls via fixture.calls (list of argv lists).
    """
    bin_dir = tmp_path / "fakebin"
    bin_dir.mkdir()
    calls_path = tmp_path / "gh-calls.log"
    response_path = tmp_path / "gh-response.txt"
    response_path.write_text("")

    script = textwrap.dedent(f"""\
        #!/usr/bin/env bash
        # Log args (one per line, newline-terminated record per invocation)
        printf '%s\\n' "$@" >> {calls_path}
        printf '\\n--END--\\n' >> {calls_path}
        # Emit canned stdout if any
        if [ -s {response_path} ]; then
          cat {response_path}
        fi
        exit 0
    """)
    gh = bin_dir / "gh"
    gh.write_text(script)
    gh.chmod(0o755)

    monkeypatch.setenv("PATH", f"{bin_dir}{os.pathsep}{os.environ['PATH']}")

    class _Stub:
        def set_response(self, body: str) -> None:
            response_path.write_text(body)

        @property
        def calls(self) -> list[list[str]]:
            if not calls_path.exists():
                return []
            chunks = calls_path.read_text().split("\n--END--\n")
            return [c.strip().split("\n") for c in chunks if c.strip()]

    return _Stub()
