from __future__ import annotations

from pr_bot.stack import Stack, merge_marker, render_marker


class TestRenderMarker:
    def test_three_branches(self):
        s = Stack(name="auth", branches=("feat/a", "feat/b", "feat/c"))
        prs = {"feat/a": 10, "feat/b": 11, "feat/c": 12}
        out = render_marker(s, "feat/b", prs)
        assert "<!-- pr-bot:stack -->" in out
        assert "<!-- /pr-bot:stack -->" in out
        assert "**Stack:** 2/3" in out
        assert "feat/a` #10" in out
        assert "feat/b` #11" in out
        assert "feat/c` #12" in out
        assert "← this PR" in out
        assert "← bottom" in out
        assert "← top" in out

    def test_unopened_pr_shown(self):
        s = Stack(name="x", branches=("feat/a", "feat/b"))
        out = render_marker(s, "feat/a", {"feat/a": 7, "feat/b": None})
        assert "(unopened)" in out


class TestMergeMarker:
    def test_inserts_into_empty_body(self):
        marker = "<!-- pr-bot:stack -->\nstack stuff\n<!-- /pr-bot:stack -->"
        assert merge_marker("", marker) == marker
        assert merge_marker(None, marker) == marker

    def test_prepends_when_no_existing_block(self):
        marker = "<!-- pr-bot:stack -->\nstack\n<!-- /pr-bot:stack -->"
        body = "Original PR description."
        merged = merge_marker(body, marker)
        assert merged.startswith("<!-- pr-bot:stack -->")
        assert "Original PR description." in merged

    def test_replaces_existing_block(self):
        marker = "<!-- pr-bot:stack -->\nNEW\n<!-- /pr-bot:stack -->"
        body = (
            "Intro\n\n"
            "<!-- pr-bot:stack -->\nOLD STACK\n<!-- /pr-bot:stack -->\n\n"
            "Trailing prose"
        )
        merged = merge_marker(body, marker)
        assert "OLD STACK" not in merged
        assert "NEW" in merged
        assert "Intro" in merged
        assert "Trailing prose" in merged
