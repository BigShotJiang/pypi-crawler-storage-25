"""Integration tests for pr_bot.git — real git in a tmp_path repo."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from pr_bot import git


def _git(repo: Path, *args: str) -> str:
    r = subprocess.run(
        ["git", *args],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    )
    return r.stdout.strip()


def _init_repo(path: Path, *, initial_branch: str = "main") -> Path:
    path.mkdir(parents=True, exist_ok=True)
    _git(path, "init", "-q", "-b", initial_branch)
    _git(path, "config", "user.email", "test@example.com")
    _git(path, "config", "user.name", "Test")
    _git(path, "commit", "--allow-empty", "-q", "-m", "initial")
    return path


@pytest.fixture
def repo(tmp_path, monkeypatch):
    r = _init_repo(tmp_path / "repo")
    monkeypatch.chdir(r)
    return r


@pytest.fixture
def repo_with_origin(tmp_path, monkeypatch):
    """Repo wired to a bare-repo 'origin' in the same tmp_path."""
    bare = tmp_path / "origin.git"
    subprocess.run(["git", "init", "--bare", "-q", "-b", "main", str(bare)], check=True)
    r = _init_repo(tmp_path / "repo")
    _git(r, "remote", "add", "origin", str(bare))
    _git(r, "push", "-u", "origin", "main")
    monkeypatch.chdir(r)
    return r


class TestBranchIntrospection:
    def test_current_branch_on_main(self, repo):
        assert git.current_branch() == "main"

    def test_current_branch_after_switch(self, repo):
        _git(repo, "checkout", "-b", "feat/x")
        assert git.current_branch() == "feat/x"

    def test_main_branch_prefers_main(self, repo):
        assert git.main_branch() == "main"

    def test_main_branch_falls_back_to_master(self, tmp_path, monkeypatch):
        r = _init_repo(tmp_path / "master-repo", initial_branch="master")
        monkeypatch.chdir(r)
        assert git.main_branch() == "master"

    def test_branch_exists_local(self, repo):
        assert git.branch_exists_local("main") is True
        assert git.branch_exists_local("nope") is False

    def test_list_branches(self, repo):
        _git(repo, "checkout", "-b", "feat/a")
        _git(repo, "checkout", "-b", "feat/b")
        _git(repo, "checkout", "main")
        branches = set(git.list_branches("*"))
        assert branches == {"main", "feat/a", "feat/b"}

    def test_list_branches_pattern(self, repo):
        _git(repo, "checkout", "-b", "feat/a")
        _git(repo, "checkout", "-b", "release/1.0")
        _git(repo, "checkout", "main")
        assert set(git.list_branches("feat/*")) == {"feat/a"}
        assert set(git.list_branches("release/*")) == {"release/1.0"}


class TestWorkingTree:
    def test_has_uncommitted_clean(self, repo):
        assert git.has_uncommitted() is False

    def test_has_uncommitted_with_untracked(self, repo):
        (repo / "foo.txt").write_text("hello")
        assert git.has_uncommitted() is True

    def test_has_uncommitted_with_staged(self, repo):
        (repo / "foo.txt").write_text("hello")
        _git(repo, "add", "foo.txt")
        assert git.has_uncommitted() is True


class TestRemotes:
    def test_has_remote_false_when_none(self, repo):
        assert git.has_remote() is False

    def test_has_remote_true_with_origin(self, repo_with_origin):
        assert git.has_remote() is True
        assert git.has_remote("nonesuch") is False


class TestCheckout:
    def test_checkout_switches_branches(self, repo):
        _git(repo, "checkout", "-b", "feat/x")
        git.checkout("main")
        assert git.current_branch() == "main"

    def test_checkout_new_creates_and_switches(self, repo):
        git.checkout_new("feat/y", "main")
        assert git.current_branch() == "feat/y"
        assert git.branch_exists_local("feat/y") is True


class TestTags:
    def test_tag_creates_and_exists(self, repo):
        git.tag("1.0.0", "HEAD", message="release")
        assert git.tag_exists("1.0.0") is True
        assert git.tag_exists("9.9.9") is False

    def test_list_tags_sorted_desc(self, repo):
        git.tag("1.0.0")
        git.tag("1.0.1")
        git.tag("1.1.0")
        tags = git.list_tags("1.*")
        # reverse version sort
        assert tags == ["1.1.0", "1.0.1", "1.0.0"]

    def test_list_tags_pattern(self, repo):
        git.tag("1.0.0")
        git.tag("2.0.0")
        assert git.list_tags("1.*") == ["1.0.0"]


class TestHistory:
    def test_is_ancestor_true(self, repo):
        base = _git(repo, "rev-parse", "HEAD")
        _git(repo, "commit", "--allow-empty", "-q", "-m", "second")
        assert git.is_ancestor(base, "HEAD") is True

    def test_is_ancestor_false(self, repo):
        _git(repo, "checkout", "-b", "feat/x")
        _git(repo, "commit", "--allow-empty", "-q", "-m", "on feat")
        feat = _git(repo, "rev-parse", "HEAD")
        _git(repo, "checkout", "main")
        assert git.is_ancestor(feat, "main") is False

    def test_ahead_behind(self, repo_with_origin):
        _git(repo_with_origin, "checkout", "-b", "feat/x")
        _git(repo_with_origin, "commit", "--allow-empty", "-q", "-m", "a")
        _git(repo_with_origin, "commit", "--allow-empty", "-q", "-m", "b")
        ahead, behind = git.ahead_behind("feat/x", "origin/main")
        assert (ahead, behind) == (2, 0)


class TestDeleteBranch:
    def test_delete_branch_local(self, repo):
        _git(repo, "checkout", "-b", "feat/x")
        _git(repo, "checkout", "main")
        git.delete_branch_local("feat/x", force=True)
        assert git.branch_exists_local("feat/x") is False


class TestRebase:
    def test_rebase_in_progress_false_on_clean_repo(self, repo):
        assert git.rebase_in_progress() is False

    def test_rebase_try_clean_rebase(self, repo):
        _git(repo, "checkout", "-b", "feat/x")
        _git(repo, "commit", "--allow-empty", "-q", "-m", "feat commit")
        _git(repo, "checkout", "main")
        _git(repo, "commit", "--allow-empty", "-q", "-m", "main commit")
        _git(repo, "checkout", "feat/x")
        assert git.rebase_try("main") is True
        assert git.rebase_in_progress() is False

    def test_rebase_try_conflict_leaves_rebase_in_progress(self, repo):
        f = repo / "conflict.txt"
        f.write_text("base\n")
        _git(repo, "add", "conflict.txt")
        _git(repo, "commit", "-q", "-m", "base")

        _git(repo, "checkout", "-b", "feat/x")
        f.write_text("feat\n")
        _git(repo, "commit", "-aq", "-m", "feat edit")

        _git(repo, "checkout", "main")
        f.write_text("main\n")
        _git(repo, "commit", "-aq", "-m", "main edit")

        _git(repo, "checkout", "feat/x")
        ok = git.rebase_try("main")
        assert ok is False
        assert git.rebase_in_progress() is True
        _git(repo, "rebase", "--abort")
