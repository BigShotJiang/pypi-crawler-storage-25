from __future__ import annotations

import pytest

from toolbar import template as tmpl


class TestSubstitution:
    def test_path_substitution(self):
        assert tmpl._substitute_path("__name__", {"name": "x"}) == "x"
        assert tmpl._substitute_path("a__name__b", {"name": "x"}) == "axb"
        assert tmpl._substitute_path("__missing__", {"name": "x"}) == "__missing__"

    def test_text_substitution(self):
        assert tmpl._substitute_text("hello {{name}}!", {"name": "world"}) == "hello world!"
        assert tmpl._substitute_text("{{ name }}", {"name": "x"}) == "x"
        assert tmpl._substitute_text("{{nope}}", {"name": "x"}) == "{{nope}}"


class TestRender:
    def test_python_template_renders(self, tmp_path):
        ctx = {
            "name": "my-thing",
            "name_underscore": "my_thing",
            "description": "tested project",
            "author": "Test User",
            "email": "t@example.com",
            "year": "2026",
            "dot": ".",
        }
        target = tmp_path / "out"
        tmpl.render("python", target, ctx)
        # File names: substituted + .tmpl stripped
        assert (target / "pyproject.toml").is_file()
        assert (target / ".gitignore").is_file()
        # Substituted package dir
        assert (target / "src" / "my_thing" / "__init__.py").is_file()
        # No leftover .tmpl files
        assert not list(target.rglob("*.tmpl"))
        # Content was substituted
        pyproj = (target / "pyproject.toml").read_text()
        assert 'name = "my-thing"' in pyproj
        assert "{{name}}" not in pyproj
        init = (target / "src" / "my_thing" / "__init__.py").read_text()
        assert "tested project" in init

    def test_unknown_flavor_raises(self, tmp_path):
        with pytest.raises(SystemExit, match="not found"):
            tmpl.render("nonesuch", tmp_path / "x", {})

    def test_nonempty_target_raises(self, tmp_path):
        target = tmp_path / "x"
        target.mkdir()
        (target / "existing.txt").write_text("hi")
        with pytest.raises(SystemExit, match="not empty"):
            tmpl.render("python", target, {"name": "y", "name_underscore": "y",
                                            "description": "", "author": "", "email": "",
                                            "year": "2026", "dot": "."})
