"""toolbar: workspace-admin CLI (repo bootstrap, misc ops).

Lives alongside pr-bot. Scope: things you do *around* a repo — create it,
wire up the remote, etc. — as opposed to pr-bot's scope (what you do
*inside* a repo once it exists).
"""

from pr_bot import __version__ as __version__  # noqa: F401 — single source of truth: pyproject.toml
