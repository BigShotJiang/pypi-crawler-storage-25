"""toolbar repo <subcommand> — create and wire up GitHub repos."""

from __future__ import annotations

import datetime as _dt
import os
import re
from pathlib import Path
from typing import Annotated

from cyclopts import App, Parameter

from pr_bot.sh import require, run
from toolbar import template as _template
from toolbar.env import resolve

app = App(name="repo", help="Create and wire up GitHub repos.")


def _default_name() -> str:
    return Path.cwd().name


def _ensure_gh_credential_helper(host: str) -> None:
    """If gh's git credential helper isn't wired for <host>, run 'gh auth setup-git'.

    Without this, the git push inside 'gh repo create --push' has no
    credentials and the remote 404s. Idempotent.
    """
    r = run(
        ["git", "config", "--get-all", f"credential.https://{host}.helper"],
        check=False,
    )
    if r.ok and "gh auth git-credential" in r.stdout:
        return
    print(f"toolbar: wiring gh as git credential helper for {host}...")
    _gh_with_host(host, "auth", "setup-git", capture=True, echo=False)


def _gh_with_host(host: str, *args: str, capture: bool = False, echo: bool = True):
    require("gh")
    env = dict(os.environ)
    env["GH_HOST"] = host
    cmd = ["gh", *args]
    if echo:
        import sys

        print("$", " ".join(cmd), f"  (GH_HOST={host})", file=sys.stderr)
    import subprocess

    proc = subprocess.run(cmd, env=env, capture_output=capture, text=True, check=False)
    if proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "").strip() or f"command failed: {' '.join(cmd)}"
        raise SystemExit(f"toolbar: {msg}")
    return proc


@app.command
def info(
    name: Annotated[str | None, Parameter(help="repo name (default: current dir name)")] = None,
    org: Annotated[str | None, Parameter(help="GitHub org/user (default: $GH_ORG or andrewrothstein)")] = None,
    mirror: Annotated[str | None, Parameter(help="GitHub URL (default: $GH_MIRROR or https://github.com)")] = None,
) -> None:
    """Print the resolved target repo (org/name, URL, host) without creating it."""
    t = resolve(name=name or _default_name(), org=org, mirror=mirror)
    print(f"name   : {t.name}")
    print(f"org    : {t.org}")
    print(f"mirror : {t.mirror}")
    print(f"host   : {t.host}")
    print(f"slug   : {t.slug}")
    print(f"url    : {t.browser_url}")


@app.command
def create(
    name: Annotated[str | None, Parameter(help="repo name (default: current dir name)")] = None,
    org: Annotated[str | None, Parameter(help="GitHub org/user (default: $GH_ORG or andrewrothstein)")] = None,
    mirror: Annotated[str | None, Parameter(help="GitHub URL (default: $GH_MIRROR or https://github.com)")] = None,
    public: Annotated[bool, Parameter(help="create public repo (default: private)")] = False,
    description: Annotated[str | None, Parameter(help="repo description")] = None,
    source: Annotated[str, Parameter(help="local path to wire as the repo source")] = ".",
    push: Annotated[bool, Parameter(help="also push the current branch to origin")] = False,
    remote: Annotated[str, Parameter(help="remote name to add")] = "origin",
) -> None:
    """Create a private GitHub repo and (optionally) push.

    Shells out to 'gh repo create <org>/<name> --private --source=<path> --remote=<name>'.
    Defaults honor GH_MIRROR and GH_ORG env vars.
    """
    t = resolve(name=name or _default_name(), org=org, mirror=mirror)
    visibility = "--public" if public else "--private"

    if push:
        _ensure_gh_credential_helper(t.host)

    args = [
        "repo",
        "create",
        t.slug,
        visibility,
        f"--source={source}",
        f"--remote={remote}",
    ]
    if description:
        args += ["--description", description]
    if push:
        args.append("--push")

    _gh_with_host(t.host, *args)

    print(f"toolbar: created {t.browser_url} ({'public' if public else 'private'})")
    print(f"toolbar: remote '{remote}' set on {source}")
    if not push:
        print("toolbar: nothing pushed yet. to push main:")
        print(f"        git push -u {remote} main")


def _git_user() -> tuple[str, str]:
    name = run(["git", "config", "user.name"], check=False).stdout.strip() or "Unknown"
    email = run(["git", "config", "user.email"], check=False).stdout.strip() or "unknown@example.com"
    return name, email


_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9\-]*$")


def _validate_name(name: str) -> None:
    if not _NAME_RE.match(name):
        raise SystemExit(
            f"toolbar: invalid project name {name!r} — "
            "lowercase alnum + hyphens, starting alnum"
        )


@app.command
def template(
    name: Annotated[str, Parameter(help="kebab-case project name (also the repo name)")],
    at: Annotated[str | None, Parameter(name="--at", help="target directory (default: ./<name>)")] = None,
    flavor: Annotated[str, Parameter(help="template flavor (currently: python)")] = "python",
    description: Annotated[str, Parameter(help="one-line description")] = "TODO: describe",
    public: Annotated[bool, Parameter(help="create public repo (default: private)")] = False,
    push: Annotated[bool, Parameter(help="push to GitHub via 'gh repo create' (default: yes)")] = True,
    cut_release: Annotated[
        bool,
        Parameter(name="--release/--no-release", help="cut release/0.1 (default: yes)"),
    ] = True,
    org: Annotated[str | None, Parameter(help="GitHub org/user (default: $GH_ORG or andrewrothstein)")] = None,
    mirror: Annotated[str | None, Parameter(help="GitHub URL (default: $GH_MIRROR or https://github.com)")] = None,
) -> None:
    """Bootstrap a new project with the full pr-bot model wired up.

    Creates a directory, renders a template (default: python), runs git init,
    makes the initial commit, optionally cuts release/0.1, and optionally
    pushes to GitHub via 'gh repo create' (private by default).
    """
    _validate_name(name)
    target = Path(at) if at else Path.cwd() / name
    if target.exists() and any(target.iterdir()):
        raise SystemExit(f"toolbar: target {target} is not empty")

    name_underscore = name.replace("-", "_")
    author, email = _git_user()
    ctx = {
        "name": name,
        "name_underscore": name_underscore,
        "description": description,
        "author": author,
        "email": email,
        "year": str(_dt.date.today().year),
        "dot": ".",
    }

    print(f"toolbar: rendering {flavor} template into {target}")
    _template.render(flavor, target, ctx)

    require("git")
    run(["git", "init", "-q", "-b", "main"], cwd=str(target), echo=True)
    run(["git", "add", "-A"], cwd=str(target), echo=False)
    run(
        ["git", "commit", "-q", "-m", f"initial: pr-bot scaffold for {name}"],
        cwd=str(target),
        echo=True,
    )

    if cut_release:
        run(
            ["git", "checkout", "-q", "-b", "release/0.1"],
            cwd=str(target),
            echo=True,
        )
        run(["git", "checkout", "-q", "main"], cwd=str(target), echo=True)

    if not push:
        print(f"toolbar: scaffolded {target} (no push). cd {target.name} && toolbar repo create --push to publish.")
        return

    t = resolve(name=name, org=org, mirror=mirror)
    visibility = "--public" if public else "--private"

    _ensure_gh_credential_helper(t.host)

    args = [
        "repo",
        "create",
        t.slug,
        visibility,
        f"--source={target}",
        "--remote=origin",
        "--description",
        description,
        "--push",
    ]
    _gh_with_host(t.host, *args)

    if cut_release:
        run(
            ["git", "push", "-u", "origin", "release/0.1"],
            cwd=str(target),
            echo=True,
        )

    print(f"toolbar: bootstrapped {t.browser_url} ({'public' if public else 'private'})")


@app.command
def push_main(
    remote: Annotated[str, Parameter(help="remote name (default: origin)")] = "origin",
) -> None:
    """Push local main to origin (sanity-checks clean tree + on main)."""
    require("git")
    status = run(["git", "status", "--porcelain"]).stdout.strip()
    if status:
        raise SystemExit("toolbar: working tree not clean; commit or stash first")
    branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"]).stdout.strip()
    if branch not in ("main", "master"):
        raise SystemExit(f"toolbar: expected to be on main/master, got {branch}")
    run(["git", "push", "-u", remote, branch], capture=False, echo=True)
