# {{name}}

{{description}}

## Quick start

```bash
uv sync
uv run pytest -q
```

## PR lifecycle

This repo follows the **pr-bot model**: `main` + `release/X.Y` +
`{feat,fix,hotfix}/<slug>`, linear history, squash merges, semver
(`X.Y.Z`) tags on release branches.

Use `pr-bot` to drive the lifecycle:

```bash
pr-bot pr start feat add-thing
# …edit, commit…
pr-bot pr open --draft
pr-bot pr ready
pr-bot pr merge
```

See `pr-bot --help` and `AGENTS.md` for the full picture.
