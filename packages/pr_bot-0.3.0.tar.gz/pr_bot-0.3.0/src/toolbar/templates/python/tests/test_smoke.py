import {{name_underscore}}


def test_version_is_a_string():
    assert isinstance({{name_underscore}}.__version__, str)
