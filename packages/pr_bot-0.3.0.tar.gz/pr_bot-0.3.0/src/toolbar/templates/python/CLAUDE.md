# CLAUDE.md

Project instructions for Claude Code agents working on **{{name}}**.

## Build & Test

```bash
uv sync                          # install deps + editable package
uv run pytest -q                 # run tests
uv run ruff check src tests      # lint
```

## PR Lifecycle

This repo follows the pr-bot model. Use the slash commands or the CLI:

```bash
pr-bot pr start feat <slug>      # branch off main
# …edit, commit…
pr-bot pr open --draft           # push + open PR
pr-bot pr sync                   # keep up with main
pr-bot pr ready
pr-bot pr merge                  # squash, delete branch, FF main
```

Releases:

```bash
pr-bot release cut X.Y           # if line doesn't exist
pr-bot release prepare X.Y.Z     # bump pyproject + draft notes + commit
pr-bot release tag X.Y.Z --notes-file docs/releases/X.Y.Z.md
```

## Conventions

- Linear `main`, FF-only, squash merges only.
- Branch names: `feat/<slug>`, `fix/<slug>`, `hotfix/<slug>`, `release/X.Y`.
- Tag names: `X.Y.Z` (annotated, on `release/X.Y`).
- Conventional commit prefixes for PR titles (`feat:`, `fix:`, `chore:`, …)
  so `pr-bot release notes-draft` groups them correctly.
