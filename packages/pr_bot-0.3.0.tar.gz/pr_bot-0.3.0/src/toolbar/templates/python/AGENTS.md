# AGENTS.md

Instructions for AI coding agents working on **{{name}}**.

## The model

This repo follows the **pr-bot** branching model:

- `main` is linear, FF-only, squash-merged.
- Work branches: `feat/<slug>`, `fix/<slug>`, `hotfix/<slug>`.
- Release branches: `release/X.Y`, long-lived, hotfixes only.
- Tags: `X.Y.Z`, annotated, on the matching release branch.

## Decision tree

```
add a new feature    →  pr-bot pr start feat <slug>
fix a bug on main    →  pr-bot pr start fix  <slug>
push + open PR       →  pr-bot pr open [--draft]
catch up with main   →  pr-bot pr sync
mark ready for review→  pr-bot pr ready
land the PR          →  pr-bot pr merge
cut a release line   →  pr-bot release cut X.Y
ship a version       →  pr-bot release prepare X.Y.Z
                        pr-bot release tag X.Y.Z --notes-file docs/releases/X.Y.Z.md
```

## Rules

- Never merge `main` into a PR branch — rebase via `pr-bot pr sync`.
- Never push directly to `main` or `release/*` — always via PR.
- Never invent branch names outside the pattern.
- Never invent tag names outside `X.Y.Z`.
- Run `pr-bot doctor` when in doubt.
