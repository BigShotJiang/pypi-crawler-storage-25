"""Render a template tree onto a target directory with simple {{var}} substitution.

No Jinja — just str.replace for {{var}} in file *contents* and __var__ in file *paths*.
Why two syntaxes: __var__ in paths plays nice with editor config, ruff, py-imports;
{{var}} in content is unambiguous.
"""

from __future__ import annotations

import re
import shutil
from collections.abc import Iterable
from importlib import resources
from pathlib import Path


def _substitute_path(name: str, ctx: dict[str, str]) -> str:
    def replace(m: re.Match) -> str:
        key = m.group(1)
        return ctx.get(key, m.group(0))
    return re.sub(r"__([a-z_][a-z0-9_]*)__", replace, name)


def _substitute_text(text: str, ctx: dict[str, str]) -> str:
    def replace(m: re.Match) -> str:
        key = m.group(1)
        return ctx.get(key, m.group(0))
    return re.sub(r"\{\{\s*([a-z_][a-z0-9_]*)\s*\}\}", replace, text)


def template_root(flavor: str) -> Path:
    """Return the on-disk directory of the templates for <flavor>.

    Uses importlib.resources so it works whether installed as a wheel or
    editable.
    """
    base = resources.files("toolbar").joinpath("templates", flavor)
    # importlib.resources returns a Traversable; for our purposes we need
    # a real Path. resources.as_file would copy; since we only ship file
    # contents, fall back to str-cast which works for filesystem-backed
    # packages (which is our case in both editable and wheel installs).
    return Path(str(base))


def iter_template_files(root: Path) -> Iterable[Path]:
    for p in sorted(root.rglob("*")):
        if p.is_file():
            yield p


_TMPL_SUFFIX = ".tmpl"


def render(flavor: str, target: Path, ctx: dict[str, str]) -> list[Path]:
    """Render <flavor> template into target/. Returns the list of created paths.

    File-name conventions:
    - `__var__` in any path component is replaced with ctx[var].
      (Use `__dot__gitignore` for `.gitignore` etc.)
    - A trailing `.tmpl` is stripped from the output filename. Use this
      for template files whose natural extension would be parsed/linted
      by tooling at template-development time (e.g. `pyproject.toml.tmpl`
      so `uv` doesn't try to read it as a workspace member).
    """
    src_root = template_root(flavor)
    if not src_root.is_dir():
        raise SystemExit(f"toolbar: template flavor {flavor!r} not found at {src_root}")
    if target.exists() and any(target.iterdir()):
        raise SystemExit(f"toolbar: target {target} is not empty")
    target.mkdir(parents=True, exist_ok=True)

    written: list[Path] = []
    for src in iter_template_files(src_root):
        rel = src.relative_to(src_root)
        parts = [_substitute_path(p, ctx) for p in rel.parts]
        if parts[-1].endswith(_TMPL_SUFFIX):
            parts[-1] = parts[-1][: -len(_TMPL_SUFFIX)]
        dest = target / Path(*parts)
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            text = src.read_text()
            dest.write_text(_substitute_text(text, ctx))
        except UnicodeDecodeError:
            shutil.copy2(src, dest)
        written.append(dest)
    return written
