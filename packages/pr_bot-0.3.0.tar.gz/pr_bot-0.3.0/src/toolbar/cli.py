"""toolbar: workspace-admin CLI."""

from __future__ import annotations

from cyclopts import App

from toolbar import __version__
from toolbar.commands import repo as repo_mod

app = App(
    name="toolbar",
    help="Workspace-admin helpers: create GitHub repos, wire up remotes, misc ops.",
    version=__version__,
)

app.command(repo_mod.app)


def main() -> None:
    app()
