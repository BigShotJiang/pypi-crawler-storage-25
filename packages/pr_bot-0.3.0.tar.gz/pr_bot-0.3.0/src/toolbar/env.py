"""Env-var resolution for GitHub host / org defaults.

Supported env vars (with their defaults):

    GH_MIRROR   https://github.com
    GH_ORG      andrewrothstein

Also respects the vanilla `GH_HOST` from the gh CLI if set (it wins over
GH_MIRROR's host component).
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import urlparse

DEFAULT_MIRROR = "https://github.com"
DEFAULT_ORG = "andrewrothstein"


@dataclass(frozen=True)
class GhTarget:
    mirror: str  # full URL like https://github.com or https://gh.corp.com
    host: str  # hostname only, for gh's GH_HOST
    org: str
    name: str

    @property
    def slug(self) -> str:
        return f"{self.org}/{self.name}"

    @property
    def browser_url(self) -> str:
        return f"{self.mirror.rstrip('/')}/{self.org}/{self.name}"


def _host_from_mirror(mirror: str) -> str:
    parsed = urlparse(mirror if "://" in mirror else f"https://{mirror}")
    return parsed.netloc or parsed.path


def resolve(
    *,
    name: str,
    org: str | None = None,
    mirror: str | None = None,
) -> GhTarget:
    m = mirror or os.environ.get("GH_MIRROR") or DEFAULT_MIRROR
    o = org or os.environ.get("GH_ORG") or DEFAULT_ORG
    h = os.environ.get("GH_HOST") or _host_from_mirror(m)
    return GhTarget(mirror=m, host=h, org=o, name=name)
