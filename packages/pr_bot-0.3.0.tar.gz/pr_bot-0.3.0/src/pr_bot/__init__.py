"""pr-bot: PR lifecycle helpers."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _dist_version

try:
    __version__ = _dist_version("pr-bot")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
