"""State + helpers for stacked PRs.

A stack is an ordered list of PR branches where each is based on the
previous one. State lives in `.git/pr-bot/stack.json` — per-clone, never
committed (it sits inside .git which is itself outside the work tree).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from pr_bot import git as _git
from pr_bot.names import parse_pr_branch

STATE_REL_PATH = "pr-bot/stack.json"


@dataclass(frozen=True)
class Stack:
    name: str
    branches: tuple[str, ...]
    created_at: str = field(default_factory=lambda: datetime.now(tz=UTC).isoformat())

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "branches": list(self.branches),
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> Stack:
        return cls(
            name=d["name"],
            branches=tuple(d["branches"]),
            created_at=d.get("created_at", ""),
        )

    def position_of(self, branch: str) -> int | None:
        try:
            return self.branches.index(branch)
        except ValueError:
            return None


def state_path(gitdir: Path | None = None) -> Path:
    """Return the absolute path to the stack state file.

    `gitdir` defaults to the result of `git rev-parse --git-dir`.
    """
    if gitdir is None:
        gitdir = Path(_git.git("rev-parse", "--git-dir").stdout.strip()).resolve()
    return gitdir / STATE_REL_PATH


def load(gitdir: Path | None = None) -> Stack | None:
    p = state_path(gitdir)
    if not p.is_file():
        return None
    return Stack.from_dict(json.loads(p.read_text()))


def save(stack: Stack, gitdir: Path | None = None) -> Path:
    p = state_path(gitdir)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(stack.to_dict(), indent=2) + "\n")
    return p


def clear(gitdir: Path | None = None) -> bool:
    """Delete the state file. Returns True if a file was removed."""
    p = state_path(gitdir)
    if p.is_file():
        p.unlink()
        return True
    return False


def name_from_slugs(slugs: list[str]) -> str:
    """Pick a stack 'name' for display and the state file. Uses the first slug."""
    return slugs[0] if slugs else "unnamed"


def expected_branches(types_and_slugs: list[tuple[str, str]]) -> tuple[str, ...]:
    """Validate and normalize a list of (type, slug) pairs into branch names."""
    out: list[str] = []
    for type_, slug in types_and_slugs:
        from pr_bot.names import pr_branch
        out.append(str(pr_branch(type_, slug)))
    return tuple(out)


def parse_stack_arg(arg: str, default_type: str = "feat") -> tuple[str, str]:
    """Parse 'feat:slug', 'fix:slug', or just 'slug' (default type) → (type, slug)."""
    if ":" in arg:
        t, s = arg.split(":", 1)
        return t, s
    return default_type, arg


def is_stack_branch(stack: Stack | None, branch: str) -> bool:
    if stack is None:
        return False
    return branch in stack.branches


def parent_of(stack: Stack, branch: str) -> str | None:
    """Return the branch that <branch> is based on (the previous one in the
    stack), or None if <branch> is the bottom (its parent is `main`)."""
    pos = stack.position_of(branch)
    if pos is None or pos == 0:
        return None
    return stack.branches[pos - 1]


def base_for(stack: Stack, branch: str, main_branch: str) -> str:
    """Return the base branch for <branch>: parent in stack, or main."""
    parent = parent_of(stack, branch)
    return parent if parent is not None else main_branch


_STACK_MARKER_BEGIN = "<!-- pr-bot:stack -->"
_STACK_MARKER_END = "<!-- /pr-bot:stack -->"


def render_marker(stack: Stack, current: str, pr_numbers: dict[str, int | None]) -> str:
    """Render the pr-bot:stack marker block for one PR's body.

    `current` = the branch this PR represents.
    `pr_numbers` maps branch → PR number (or None if not yet opened).
    """
    n = len(stack.branches)
    lines = [_STACK_MARKER_BEGIN, f"**Stack:** {stack.position_of(current) + 1}/{n}"]
    for i, br in enumerate(stack.branches):
        idx = i + 1
        prn = pr_numbers.get(br)
        prnref = f"#{prn}" if prn else "(unopened)"
        suffix = ""
        if br == current:
            suffix = " ← this PR"
        elif i == 0:
            suffix = " ← bottom"
        elif i == n - 1:
            suffix = " ← top"
        lines.append(f"- {idx}/{n}: `{br}` {prnref}{suffix}")
    lines.append(_STACK_MARKER_END)
    return "\n".join(lines)


def merge_marker(existing_body: str | None, marker: str) -> str:
    """Replace the existing pr-bot:stack block with `marker`, or prepend it."""
    body = existing_body or ""
    if _STACK_MARKER_BEGIN in body and _STACK_MARKER_END in body:
        before = body.split(_STACK_MARKER_BEGIN, 1)[0].rstrip()
        after = body.split(_STACK_MARKER_END, 1)[1].lstrip()
        if before or after:
            return f"{before}\n\n{marker}\n\n{after}".strip()
        return marker
    if not body.strip():
        return marker
    return f"{marker}\n\n{body.strip()}"


def validate_branch_in_stack(branch: str, stack: Stack | None) -> Stack:
    if stack is None:
        raise SystemExit("pr-bot: no stack found in .git/pr-bot/stack.json")
    if branch not in stack.branches:
        if parse_pr_branch(branch) is None:
            raise SystemExit(f"pr-bot: {branch!r} is not a PR branch")
        raise SystemExit(f"pr-bot: {branch} is not part of stack {stack.name!r}")
    return stack
