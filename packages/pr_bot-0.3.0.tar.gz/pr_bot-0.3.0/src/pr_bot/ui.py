"""pr-bot ui — Textual dashboard.

See docs/design-tui.md for the full design. Implementation ships in
slices; this module grows step by step:

- step 1 (shipped): three-pane skeleton, q/?/g hotkeys
- step 2 (shipped): live branch list, detail pane shows 'git log -1'
- step 3 (shipped): when selection is a PR branch, render gh pr view
  details (title, state, body) instead of the bare git log
- step 4 (shipped): bottom CI checks pane shows gh pr checks output
- step 5 (shipped): hotkeys wire s/r/m/c/o into the existing CLI
- step 6+7 (this slice): stack pane (active stack) and release pane
  (release branches + latest tags) above the checks pane
"""

from __future__ import annotations

import os
import subprocess
import webbrowser

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Header, Label, ListItem, ListView, Static

from pr_bot import gh as _gh
from pr_bot import git as _git
from pr_bot import stack as _stack
from pr_bot.names import parse_pr_branch, parse_release_branch, parse_version
from pr_bot.sh import run as _run


class _Pane(Static):
    """Static placeholder pane with a title bar."""

    def __init__(self, title: str, body: str = "", *, id: str | None = None) -> None:
        rendered = f"[bold]{title}[/bold]\n\n{body}" if body else f"[bold]{title}[/bold]"
        super().__init__(rendered, id=id)
        self.border_title = title


def _list_branches() -> list[str]:
    """Best-effort branch list. Returns [] when not in a git repo."""
    try:
        return _git.list_branches("*")
    except SystemExit:
        return []


class BranchItem(ListItem):
    """ListItem that holds the branch name explicitly (Label content is opaque)."""

    def __init__(self, branch: str) -> None:
        super().__init__(Label(branch))
        self.branch = branch


_CHECK_ICON = {
    "pass": "✓",
    "fail": "✗",
    "pending": "⏳",
    "skipping": "·",
    "cancel": "⊘",
}


def render_stack(stack: _stack.Stack) -> str:
    n = len(stack.branches)
    head_lines = [f"[bold]{stack.name}[/bold]  ({n} branch{'es' if n != 1 else ''})"]
    for i, br in enumerate(stack.branches):
        head_lines.append(f"  {i + 1}/{n} {br}")
    return "\n".join(head_lines)


def render_releases(branches: list[str]) -> str:
    """For each release/X.Y branch, show the highest X.Y.Z tag (or 'no tags')."""
    lines = []
    for br in branches:
        rl = parse_release_branch(br)
        if rl is None:
            continue
        tags = []
        for t in _git.list_tags(f"{rl.major}.{rl.minor}.*"):
            v = parse_version(t)
            if v is not None:
                tags.append(v)
        latest = max(tags, key=lambda v: (v.major, v.minor, v.patch)) if tags else None
        suffix = f"v{latest}" if latest else "(no tags)"
        lines.append(f"  {br:<18}  {suffix}")
    return "\n".join(lines)


def render_checks(checks: list[dict]) -> str:
    """Format gh pr checks output into the bottom-pane lines."""
    if not checks:
        return "(no checks)"
    lines = []
    for c in checks:
        bucket = c.get("bucket") or c.get("state") or "?"
        icon = _CHECK_ICON.get(bucket, "?")
        name = c.get("name") or "?"
        link = c.get("link") or ""
        lines.append(f"{icon} {bucket:<8}  {name:<28}  {link}")
    return "\n".join(lines)


def _git_log_one(branch: str) -> str:
    r = _run(["git", "log", "-1", "--format=%h %s%n%n%an <%ae>%n%cI%n%n%b", branch], check=False)
    if not r.ok:
        return f"git log failed for {branch}:\n{r.stderr.strip() or 'unknown error'}"
    return r.stdout.strip() or "(no commits)"


def _pr_summary(pr: dict) -> str:
    """Human-friendly header lines for a gh pr view JSON dict."""
    draft = " (draft)" if pr.get("isDraft") else ""
    title = pr.get("title", "(no title)")
    state = pr.get("state", "?")
    base = pr.get("baseRefName", "?")
    head = pr.get("headRefName", "?")
    url = pr.get("url", "")
    return (
        f"#{pr['number']} {state}{draft}  {title}\n"
        f"{head} → {base}\n"
        f"{url}"
    )


def _branch_detail(branch: str) -> str:
    """Render the right pane content for <branch>.

    For PR-shaped branches with an open/closed PR on GitHub, show the PR
    summary + body. Falls back to 'git log -1' for everything else (main,
    release/X.Y, branches with no PR).
    """
    if not branch:
        return "(no selection)"
    is_pr_branch = parse_pr_branch(branch) is not None
    if is_pr_branch and _git.has_remote():
        pr = _gh.pr_view(branch)
        if pr is not None:
            body = (pr.get("body") or "").strip() or "(no body)"
            return f"{_pr_summary(pr)}\n\n{body}"
    return _git_log_one(branch)


class PrBotApp(App):
    """The pr-bot dashboard."""

    CSS = """
    Screen { layout: vertical; }
    #top { height: 1fr; }
    #left-col { width: 35%; }
    #branches { border: round $primary; padding: 0; height: 1fr; }
    #branches > ListView { height: 1fr; }
    #stack-pane { border: round $primary; padding: 1; height: 8; }
    #releases { border: round $primary; padding: 1; height: 8; }
    #detail { width: 1fr; border: round $primary; padding: 1; }
    #checks { height: 8; border: round $primary; padding: 1; }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("?", "help", "Help"),
        Binding("g", "refresh", "Refresh"),
        Binding("s", "pr_sync", "pr sync"),
        Binding("r", "pr_ready", "pr ready"),
        Binding("m", "pr_merge", "pr merge"),
        Binding("c", "pr_cleanup", "pr cleanup"),
        Binding("o", "open_url", "Open PR in browser"),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Vertical():
            with Horizontal(id="top"):
                with Vertical(id="left-col"):
                    with Vertical(id="branches"):
                        yield Label("[bold]branches[/bold]")
                        yield ListView(id="branch-list")
                    yield _Pane("stack", "(no stack)", id="stack-pane")
                    yield _Pane("releases", "(no releases)", id="releases")
                yield _Pane(
                    "pr detail",
                    "(select a branch on the left)",
                    id="detail",
                )
            yield _Pane("checks", "(no PR for this branch)", id="checks")
        yield Footer()

    def on_mount(self) -> None:
        self._populate_branches()
        self._populate_stack()
        self._populate_releases()

    def _populate_branches(self) -> None:
        list_view = self.query_one("#branch-list", ListView)
        list_view.clear()
        branches = _list_branches()
        if not branches:
            list_view.append(ListItem(Label("(no git repo or no branches)")))
            self.query_one("#detail", _Pane).update(
                "[bold]pr detail[/bold]\n\n(no branches)"
            )
            return
        # Show main first, then everything else alphabetically.
        try:
            main = _git.main_branch()
        except SystemExit:
            main = None
        ordered = (
            ([main] if main and main in branches else [])
            + sorted(b for b in branches if b != main)
        )
        for br in ordered:
            list_view.append(BranchItem(br))
        if ordered:
            list_view.index = 0
            self._show_detail(ordered[0])

    def _show_detail(self, branch: str) -> None:
        detail = self.query_one("#detail", _Pane)
        detail.update(f"[bold]pr detail — {branch}[/bold]\n\n{_branch_detail(branch)}")
        self._show_checks(branch)

    def _show_checks(self, branch: str) -> None:
        checks_pane = self.query_one("#checks", _Pane)
        if not _git.has_remote() or parse_pr_branch(branch) is None:
            checks_pane.update("[bold]checks[/bold]\n\n(no PR for this branch)")
            return
        checks_pane.update("[bold]checks[/bold]\n\n" + render_checks(_gh.pr_checks(branch)))

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if isinstance(event.item, BranchItem):
            self._show_detail(event.item.branch)

    def _populate_stack(self) -> None:
        pane = self.query_one("#stack-pane", _Pane)
        s = _stack.load()
        if s is None:
            pane.update("[bold]stack[/bold]\n\n(no active stack)")
            return
        pane.update("[bold]stack[/bold]\n\n" + render_stack(s))

    def _populate_releases(self) -> None:
        pane = self.query_one("#releases", _Pane)
        try:
            local = set(_git.list_branches("release/*"))
            remote = set(_git.list_remote_branches("release/*")) if _git.has_remote() else set()
        except SystemExit:
            pane.update("[bold]releases[/bold]\n\n(no git repo)")
            return
        all_branches = sorted(local | remote)
        if not all_branches:
            pane.update("[bold]releases[/bold]\n\n(no release branches)")
            return
        pane.update("[bold]releases[/bold]\n\n" + render_releases(all_branches))

    def _selected_branch(self) -> str | None:
        list_view = self.query_one("#branch-list", ListView)
        item = list_view.highlighted_child
        if isinstance(item, BranchItem):
            return item.branch
        return None

    def _run_pr_subcommand(self, *subcmd: str) -> None:
        """Shell out to 'pr-bot pr <subcmd>' on the selected branch.

        The TUI is invoked from within a checked-out repo; we switch to the
        target branch first (so 'pr sync' / 'pr ready' / 'pr merge' / 'pr
        cleanup' all see the right HEAD), run, then refresh both panes.
        """
        br = self._selected_branch()
        if not br:
            self.notify("no branch selected", timeout=2)
            return
        if parse_pr_branch(br) is None:
            self.notify(f"{br} is not a PR branch — hotkey skipped", timeout=3)
            return
        # Switch to the branch first; abort silently if already there.
        try:
            current = _git.current_branch()
        except SystemExit:
            current = None
        if current != br:
            r = subprocess.run(["git", "checkout", br], capture_output=True, text=True)
            if r.returncode != 0:
                self.notify(f"git checkout {br} failed: {r.stderr.strip()}", timeout=5)
                return
        cmd = ["pr-bot", "pr", *subcmd]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode == 0:
            self.notify(f"{' '.join(cmd)} ok", timeout=2)
            self._populate_branches()
        else:
            err = (proc.stderr or proc.stdout or "").strip().splitlines()
            head = err[0] if err else "(no output)"
            self.notify(f"{' '.join(cmd)} failed: {head}", severity="error", timeout=6)

    def action_help(self) -> None:
        self.notify(
            "↑/↓ select · s sync · r ready · m merge · c cleanup · o open · g refresh · q quit",
            timeout=6,
        )

    def action_refresh(self) -> None:
        self._populate_branches()
        self._populate_stack()
        self._populate_releases()
        self.notify("refreshed", timeout=2)

    def action_pr_sync(self) -> None:
        self._run_pr_subcommand("sync")

    def action_pr_ready(self) -> None:
        self._run_pr_subcommand("ready")

    def action_pr_merge(self) -> None:
        self._run_pr_subcommand("merge")

    def action_pr_cleanup(self) -> None:
        self._run_pr_subcommand("cleanup")

    def action_open_url(self) -> None:
        br = self._selected_branch()
        if not br or parse_pr_branch(br) is None:
            self.notify("no PR branch selected", timeout=2)
            return
        if not _git.has_remote():
            self.notify("no 'origin' remote configured", timeout=3)
            return
        pr = _gh.pr_view(br)
        if pr is None or not pr.get("url"):
            self.notify(f"no PR URL for {br}", timeout=3)
            return
        # webbrowser.open works on most desktops; on a remote server it'll
        # silently no-op which is acceptable. Better than crashing.
        if "BROWSER" not in os.environ and not os.environ.get("DISPLAY"):
            self.notify(f"open: {pr['url']}", timeout=8)
            return
        webbrowser.open(pr["url"])
        self.notify(f"opened {pr['url']}", timeout=3)


def run() -> None:
    PrBotApp().run()
