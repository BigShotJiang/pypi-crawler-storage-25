"""Auto-draft release notes from merged PRs.

Groups PRs by conventional-commit prefix (`feat:`, `fix:`, ...) and renders
markdown that mirrors the shape of the hand-written notes in docs/releases/.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from pr_bot import gh, git
from pr_bot.names import Version, parse_version

# Conventional-commit prefix → bucket.
_PREFIX_BUCKET: dict[str, str] = {
    "feat": "feat",
    "fix": "fix",
    "chore": "infra",
    "docs": "infra",
    "test": "infra",
    "ci": "infra",
    "refactor": "infra",
    "perf": "infra",
    "build": "infra",
    "style": "infra",
}

_PREFIX_RE = re.compile(
    r"^(?P<kind>feat|fix|chore|docs|test|ci|refactor|perf|build|style)"
    r"(?:\([^)]*\))?!?:\s*(?P<rest>.+)$"
)


@dataclass(frozen=True)
class Item:
    number: int
    title: str
    bucket: str  # "feat" | "fix" | "infra" | "other"


def classify(title: str) -> tuple[str, str]:
    """Return (bucket, cleaned_title)."""
    m = _PREFIX_RE.match(title.strip())
    if not m:
        return "other", title.strip()
    return _PREFIX_BUCKET[m.group("kind")], m.group("rest").strip()


def resolve_since(v: Version) -> str | None:
    """Find the highest existing X.Y.<patch> tag with patch < v.patch.

    Returns None when there is no prior tag in the same line (the very first
    release), letting the caller list everything.
    """
    candidates: list[Version] = []
    for t in git.list_tags(f"{v.major}.{v.minor}.*"):
        parsed = parse_version(t)
        if parsed is None:
            continue
        if (parsed.major, parsed.minor, parsed.patch) < (v.major, v.minor, v.patch):
            candidates.append(parsed)
    if not candidates:
        return None
    return str(max(candidates, key=lambda c: c.patch))


def resolve_base(v: Version) -> str:
    """release/X.Y if it exists on origin, else origin's default branch."""
    rl = v.release_line
    if git.has_remote() and git.branch_exists_remote(rl.branch):
        return rl.branch
    if git.has_remote():
        return git.remote_main_branch()
    return git.main_branch()


def render(v: Version, items: list[Item]) -> str:
    sections: dict[str, list[Item]] = {"feat": [], "fix": [], "infra": [], "other": []}
    for it in items:
        sections[it.bucket].append(it)

    parts: list[str] = [
        f"# pr-bot {v}",
        "",
        "_Auto-drafted release notes — review and edit before publishing._",
    ]

    def section(title: str, bullets: list[Item], bold: bool = True) -> None:
        if not bullets:
            return
        parts.append("")
        parts.append(f"## {title}")
        parts.append("")
        for it in bullets:
            line = f"- **{it.title}** (#{it.number})" if bold else f"- {it.title} (#{it.number})"
            parts.append(line)

    section("What's new", sections["feat"])
    section("Fixes", sections["fix"])
    section("Infrastructure", sections["infra"], bold=False)
    section("Other", sections["other"], bold=False)

    if not items:
        parts.append("")
        parts.append("_No merged PRs found between the previous tag and now._")

    return "\n".join(parts).rstrip() + "\n"


def draft(v: Version, *, since: str | None = None, base: str | None = None) -> str:
    """Return the rendered release notes markdown for v."""
    base = base or resolve_base(v)
    since = since if since is not None else resolve_since(v)
    prs = gh.list_merged_prs(base=base, since=since)
    items = [Item(number=pr["number"], title=classify(pr["title"])[1],
                  bucket=classify(pr["title"])[0]) for pr in prs]
    return render(v, items)
