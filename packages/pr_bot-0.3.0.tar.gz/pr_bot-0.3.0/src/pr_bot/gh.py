"""Thin wrappers over the GitHub CLI."""

from __future__ import annotations

import json

from pr_bot.sh import Result, require, run


def _gh(*args: str, check: bool = True, capture: bool = True, echo: bool = False) -> Result:
    require("gh")
    return run(["gh", *args], check=check, capture=capture, echo=echo)


def current_pr() -> dict | None:
    """Return metadata for the PR attached to the current branch, or None."""
    r = _gh(
        "pr",
        "view",
        "--json",
        "number,state,isDraft,title,url,baseRefName,headRefName,mergeable,mergeStateStatus",
        check=False,
    )
    if not r.ok:
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def create_pr(
    *,
    base: str,
    title: str | None = None,
    body: str | None = None,
    draft: bool = False,
    fill: bool = True,
    web: bool = False,
) -> None:
    args = ["pr", "create", "--base", base]
    if draft:
        args.append("--draft")
    if web:
        args.append("--web")
    if title:
        args += ["--title", title]
    if body:
        args += ["--body", body]
    elif fill:
        args.append("--fill")
    _gh(*args, capture=False, echo=True)


def mark_ready() -> None:
    _gh("pr", "ready", capture=False, echo=True)


def merge_pr(*, squash: bool = True, delete_branch: bool = True, auto: bool = False) -> None:
    args = ["pr", "merge"]
    if squash:
        args.append("--squash")
    if delete_branch:
        args.append("--delete-branch")
    if auto:
        args.append("--auto")
    _gh(*args, capture=False, echo=True)


def pr_checks(branch: str) -> list[dict]:
    """Return the list of CI checks for the PR on <branch>, or [] on miss."""
    r = _gh("pr", "checks", branch, "--json", "name,bucket,state,link,workflow", check=False)
    if not r.ok:
        return []
    try:
        return json.loads(r.stdout) if r.stdout.strip() else []
    except json.JSONDecodeError:
        return []


def pr_view(branch: str) -> dict | None:
    """Return PR metadata for <branch>, or None if there isn't one."""
    r = _gh(
        "pr",
        "view",
        branch,
        "--json",
        "number,state,isDraft,title,body,url,baseRefName,headRefName",
        check=False,
    )
    if not r.ok:
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def pr_edit_body(branch: str, body: str) -> None:
    """Replace the PR body for the PR on <branch>."""
    _gh("pr", "edit", branch, "--body", body, capture=False, echo=True)


def repo_slug() -> str:
    """Return 'owner/repo' for the current repository as gh sees it."""
    r = _gh("repo", "view", "--json", "nameWithOwner", check=True)
    return json.loads(r.stdout)["nameWithOwner"]


def branch_protection_get(branch: str, *, slug: str | None = None) -> dict | None:
    """Return GitHub's current branch-protection config for <branch>, or None."""
    s = slug or repo_slug()
    r = _gh("api", f"/repos/{s}/branches/{branch}/protection", check=False)
    if not r.ok:
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def branch_protection_put(branch: str, payload: dict, *, slug: str | None = None) -> None:
    """PUT branch protection. Uses gh api with --input -."""
    import subprocess

    s = slug or repo_slug()
    require("gh")
    cmd = ["gh", "api", "--method", "PUT", f"/repos/{s}/branches/{branch}/protection",
           "--input", "-"]
    print("$", " ".join(cmd), file=__import__("sys").stderr)
    proc = subprocess.run(
        cmd,
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "").strip()
        raise SystemExit(f"pr-bot: {msg}")


def list_merged_prs(*, base: str, since: str | None = None) -> list[dict]:
    """List merged PRs against <base>, optionally filtered by 'merged:>=<since>'.

    `since` may be a git ref (tag or SHA — resolved to its committer ISO date)
    or any string gh accepts in --search merged:>= (e.g. an ISO date).
    """
    args = [
        "pr",
        "list",
        "--state",
        "merged",
        "--base",
        base,
        "--limit",
        "200",
        "--json",
        "number,title,mergedAt",
    ]
    if since:
        iso = _ref_to_iso(since) or since
        args += ["--search", f"merged:>={iso}"]
    r = _gh(*args, check=True, capture=True)
    try:
        return json.loads(r.stdout) if r.stdout.strip() else []
    except json.JSONDecodeError:
        return []


def _ref_to_iso(ref: str) -> str | None:
    """Resolve a git ref to its committer ISO date, or None on failure.

    Uses 'git log -1' rather than 'git show' because annotated tags' show
    output includes the tag annotation block, which would leak into the
    return value.
    """
    from pr_bot.sh import run
    r = run(["git", "log", "-1", "--format=%cI", ref], check=False)
    if r.ok and r.stdout.strip():
        return r.stdout.strip().splitlines()[-1]
    return None


def create_release(
    tag: str,
    *,
    title: str | None = None,
    notes: str | None = None,
    notes_file: str | None = None,
    draft: bool = False,
    target: str | None = None,
) -> None:
    if notes is not None and notes_file is not None:
        raise SystemExit("pr-bot: --notes and --notes-file are mutually exclusive")
    args = ["release", "create", tag]
    if title:
        args += ["--title", title]
    if notes_file is not None:
        args += ["--notes-file", notes_file]
    elif notes is not None:
        args += ["--notes", notes]
    else:
        args.append("--generate-notes")
    if draft:
        args.append("--draft")
    if target:
        args += ["--target", target]
    _gh(*args, capture=False, echo=True)
