"""Read the version field from pyproject.toml in the repo root."""

from __future__ import annotations

import tomllib
from pathlib import Path


def find_pyproject(start: Path | None = None) -> Path | None:
    """Walk up from start (cwd by default) looking for pyproject.toml."""
    cur = (start or Path.cwd()).resolve()
    while True:
        candidate = cur / "pyproject.toml"
        if candidate.is_file():
            return candidate
        if cur.parent == cur:
            return None
        cur = cur.parent


def read_version(path: Path | None) -> str | None:
    """Return the [project].version field. Returns None if path is None or the
    field is absent. Does not walk — pass find_pyproject() yourself if needed."""
    if path is None:
        return None
    with path.open("rb") as f:
        data = tomllib.load(f)
    return data.get("project", {}).get("version")
