"""Git primitives tailored to the pr-bot branching model."""

from __future__ import annotations

from pr_bot.sh import Result, run


def git(*args: str, check: bool = True, capture: bool = True, echo: bool = False) -> Result:
    return run(["git", *args], check=check, capture=capture, echo=echo)


def current_branch() -> str:
    return git("rev-parse", "--abbrev-ref", "HEAD").stdout.strip()


def main_branch() -> str:
    for name in ("main", "master"):
        r = git("rev-parse", "--verify", f"refs/heads/{name}", check=False)
        if r.ok:
            return name
    raise SystemExit("pr-bot: no main (or master) branch found")


def remote_main_branch() -> str:
    r = git("symbolic-ref", "--short", "refs/remotes/origin/HEAD", check=False)
    if r.ok:
        return r.stdout.strip().split("/", 1)[1]
    return main_branch()


def has_uncommitted() -> bool:
    return bool(git("status", "--porcelain").stdout.strip())


def has_remote(name: str = "origin") -> bool:
    return git("remote", "get-url", name, check=False).ok


def fetch(remote: str = "origin", *, prune: bool = True, tags: bool = True) -> None:
    args = ["fetch"]
    if prune:
        args.append("--prune")
    if tags:
        args.append("--tags")
    args.append(remote)
    git(*args, echo=True)


def checkout(ref: str) -> None:
    git("checkout", ref, echo=True)


def checkout_new(branch: str, start_point: str) -> None:
    git("checkout", "-b", branch, start_point, echo=True)


def branch_exists_local(branch: str) -> bool:
    return git("rev-parse", "--verify", f"refs/heads/{branch}", check=False).ok


def branch_exists_remote(branch: str, remote: str = "origin") -> bool:
    return git("rev-parse", "--verify", f"refs/remotes/{remote}/{branch}", check=False).ok


def pull_ff() -> None:
    git("pull", "--ff-only", echo=True)


def push(branch: str, *, remote: str = "origin", set_upstream: bool = True) -> None:
    args = ["push"]
    if set_upstream:
        args.append("-u")
    args += [remote, branch]
    git(*args, echo=True)


def push_force_with_lease(branch: str, *, remote: str = "origin") -> None:
    git("push", "--force-with-lease", remote, branch, echo=True)


def rebase(onto: str) -> None:
    git("rebase", onto, echo=True)


def rebase_try(onto: str) -> bool:
    """Attempt a rebase. Return True on success; on conflict, leave the rebase
    state intact and return False (does not raise)."""
    return git("rebase", onto, echo=True, check=False).ok


def rebase_in_progress() -> bool:
    gitdir = git("rev-parse", "--git-dir").stdout.strip()
    from pathlib import Path
    d = Path(gitdir)
    return (d / "rebase-merge").is_dir() or (d / "rebase-apply").is_dir()


def merge_base(a: str, b: str) -> str:
    return git("merge-base", a, b).stdout.strip()


def ahead_behind(local: str, upstream: str) -> tuple[int, int]:
    r = git("rev-list", "--left-right", "--count", f"{upstream}...{local}")
    behind, ahead = r.stdout.strip().split()
    return int(ahead), int(behind)


def delete_branch_local(branch: str, *, force: bool = False) -> None:
    flag = "-D" if force else "-d"
    git("branch", flag, branch, echo=True)


def delete_branch_remote(branch: str, remote: str = "origin") -> None:
    git("push", remote, "--delete", branch, echo=True)


def tag(name: str, ref: str = "HEAD", *, message: str | None = None) -> None:
    msg = message or name
    git("tag", "-a", name, "-m", msg, ref, echo=True)


def tag_exists(name: str) -> bool:
    return git("rev-parse", "--verify", f"refs/tags/{name}", check=False).ok


def push_tag(name: str, remote: str = "origin") -> None:
    git("push", remote, name, echo=True)


def list_tags(pattern: str = "*") -> list[str]:
    r = git("tag", "--list", pattern, "--sort=-v:refname")
    return [line for line in r.stdout.splitlines() if line]


def list_branches(pattern: str = "*") -> list[str]:
    # git for-each-ref's fnmatch doesn't cross '/', so "refs/heads/*" misses
    # feat/a. Treat "*" (and None) as "everything" via prefix match.
    ref = "refs/heads" if pattern in (None, "*") else f"refs/heads/{pattern}"
    r = git("for-each-ref", "--format=%(refname:short)", ref)
    return [line for line in r.stdout.splitlines() if line]


def list_remote_branches(pattern: str = "*", remote: str = "origin") -> list[str]:
    ref = f"refs/remotes/{remote}" if pattern in (None, "*") else f"refs/remotes/{remote}/{pattern}"
    r = git("for-each-ref", "--format=%(refname:short)", ref)
    prefix = f"{remote}/"
    out = []
    for line in r.stdout.splitlines():
        if line.startswith(prefix):
            out.append(line[len(prefix):])
    return out


def is_ancestor(ancestor: str, descendant: str) -> bool:
    return git("merge-base", "--is-ancestor", ancestor, descendant, check=False).ok


def cherry_pick(ref: str) -> None:
    git("cherry-pick", ref, echo=True)
