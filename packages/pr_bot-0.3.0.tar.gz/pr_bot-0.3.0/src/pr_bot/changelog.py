"""Concatenate docs/releases/*.md into a single CHANGELOG.md at repo root."""

from __future__ import annotations

from pathlib import Path

from pr_bot.names import parse_version
from pr_bot.pyproject import find_pyproject

HEADER = "# Changelog\n\nGenerated from `docs/releases/*.md` by `pr-bot release changelog`.\n"


def repo_root() -> Path | None:
    pp = find_pyproject()
    return pp.parent if pp is not None else None


def collect_release_files(releases_dir: Path) -> list[tuple[tuple[int, int, int], Path]]:
    """Return (version_tuple, path) pairs sorted by version desc.

    Files whose stems aren't valid X.Y.Z are skipped.
    """
    out: list[tuple[tuple[int, int, int], Path]] = []
    if not releases_dir.is_dir():
        return out
    for p in releases_dir.glob("*.md"):
        v = parse_version(p.stem)
        if v is None:
            continue
        out.append(((v.major, v.minor, v.patch), p))
    out.sort(key=lambda t: t[0], reverse=True)
    return out


def render(releases_dir: Path) -> str:
    parts = [HEADER]
    for _, p in collect_release_files(releases_dir):
        parts.append(p.read_text().rstrip())
        parts.append("")
    return "\n".join(parts).rstrip() + "\n"


def generate(out_path: Path | None = None, releases_dir: Path | None = None) -> Path:
    """Write CHANGELOG.md (default: <repo-root>/CHANGELOG.md). Returns the path."""
    root = repo_root()
    if root is None:
        raise SystemExit("pr-bot: no pyproject.toml found")
    rd = releases_dir or (root / "docs" / "releases")
    target = out_path or (root / "CHANGELOG.md")
    target.write_text(render(rd))
    return target
