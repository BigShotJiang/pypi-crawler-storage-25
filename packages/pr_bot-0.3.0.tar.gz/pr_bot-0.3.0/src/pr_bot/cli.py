"""Top-level cyclopts app wiring subcommand groups."""

from __future__ import annotations

from cyclopts import App

from pr_bot import __version__
from pr_bot.commands import doctor as doctor_mod
from pr_bot.commands import hotfix as hotfix_mod
from pr_bot.commands import policy as policy_mod
from pr_bot.commands import pr as pr_mod
from pr_bot.commands import release as release_mod
from pr_bot.commands import stack as stack_mod

app = App(
    name="pr-bot",
    help=(
        "PR lifecycle helpers for a main + release/X.Y + "
        "{feat|fix|hotfix}/<slug> branching model. Linear history, squash merges, "
        "FF-only main."
    ),
    version=__version__,
)

app.command(pr_mod.app)
app.command(release_mod.app)
app.command(hotfix_mod.app)
app.command(policy_mod.app)
app.command(stack_mod.app)


@app.command
def doctor() -> int:
    """Validate the repo against the pr-bot branching conventions."""
    return doctor_mod.check()


@app.command
def ui() -> None:
    """Launch the pr-bot terminal dashboard (Textual)."""
    from pr_bot import ui as ui_mod

    ui_mod.run()


def main() -> None:
    app()
