"""Branch, tag, and slug naming rules for the pr-bot model.

Branches:
    main
    release/X.Y
    {feat|fix|hotfix}/{slug}

Tags:
    X.Y.Z     — attached to a commit on release/X.Y
"""

from __future__ import annotations

import re
from dataclasses import dataclass

PR_BRANCH_TYPES: tuple[str, ...] = ("feat", "fix", "hotfix")

SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9\-]{0,63}$")
PR_BRANCH_RE = re.compile(r"^(feat|fix|hotfix)/([a-z0-9][a-z0-9\-]{0,63})$")
RELEASE_BRANCH_RE = re.compile(r"^release/(\d+)\.(\d+)$")
SEMVER_TAG_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")


@dataclass(frozen=True)
class PrBranch:
    type: str
    slug: str

    def __str__(self) -> str:
        return f"{self.type}/{self.slug}"


@dataclass(frozen=True)
class ReleaseLine:
    major: int
    minor: int

    @property
    def branch(self) -> str:
        return f"release/{self.major}.{self.minor}"

    @property
    def series(self) -> str:
        return f"{self.major}.{self.minor}"

    def tag(self, patch: int) -> str:
        return f"{self.major}.{self.minor}.{patch}"


@dataclass(frozen=True)
class Version:
    major: int
    minor: int
    patch: int

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}"

    @property
    def release_line(self) -> ReleaseLine:
        return ReleaseLine(self.major, self.minor)


def normalize_slug(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = s.strip("-")
    return s


def validate_slug(slug: str) -> None:
    if not SLUG_RE.match(slug):
        raise SystemExit(
            f"pr-bot: invalid slug {slug!r}; must match {SLUG_RE.pattern} "
            "(lowercase alnum + hyphens, starts alnum, ≤64 chars)"
        )


def pr_branch(type_: str, slug: str) -> PrBranch:
    if type_ not in PR_BRANCH_TYPES:
        raise SystemExit(
            f"pr-bot: invalid branch type {type_!r}; must be one of {PR_BRANCH_TYPES}"
        )
    slug = normalize_slug(slug)
    validate_slug(slug)
    return PrBranch(type_, slug)


def parse_pr_branch(name: str) -> PrBranch | None:
    m = PR_BRANCH_RE.match(name)
    if not m:
        return None
    return PrBranch(m.group(1), m.group(2))


def parse_release_branch(name: str) -> ReleaseLine | None:
    m = RELEASE_BRANCH_RE.match(name)
    if not m:
        return None
    return ReleaseLine(int(m.group(1)), int(m.group(2)))


def parse_version(tag: str) -> Version | None:
    m = SEMVER_TAG_RE.match(tag)
    if not m:
        return None
    return Version(int(m.group(1)), int(m.group(2)), int(m.group(3)))


def require_pr_branch(name: str) -> PrBranch:
    pb = parse_pr_branch(name)
    if pb is None:
        raise SystemExit(
            f"pr-bot: {name!r} is not a PR branch (expected feat|fix|hotfix/<slug>)"
        )
    return pb


def require_release_branch(name: str) -> ReleaseLine:
    rl = parse_release_branch(name)
    if rl is None:
        raise SystemExit(f"pr-bot: {name!r} is not a release branch (expected release/X.Y)")
    return rl
