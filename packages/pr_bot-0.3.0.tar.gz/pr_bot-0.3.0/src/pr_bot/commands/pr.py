"""pr-bot pr <subcommand> — PR lifecycle from branch creation to squash merge."""

from __future__ import annotations

from typing import Annotated, Literal

from cyclopts import App, Parameter

from pr_bot import gh, git
from pr_bot import stack as _stack
from pr_bot.names import parse_pr_branch, pr_branch, require_pr_branch

app = App(name="pr", help="Create, sync, and land PRs off main.")

BranchType = Literal["feat", "fix"]


@app.command
def start(
    type_: Annotated[BranchType, Parameter(help="feat or fix")],
    slug: Annotated[str, Parameter(help="kebab-case slug, e.g. 'add-login-button'")],
) -> None:
    """Create a new PR branch off an up-to-date main.

    Usage: pr-bot pr start feat add-login-button
    """
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    pb = pr_branch(type_, slug)
    main = git.main_branch()
    if git.branch_exists_local(str(pb)):
        raise SystemExit(f"pr-bot: branch {pb} already exists locally")
    if git.has_remote():
        git.fetch()
    git.checkout(main)
    if git.has_remote():
        git.pull_ff()
    git.checkout_new(str(pb), main)
    print(f"pr-bot: on {pb} (based on {main})")


@app.command(name="open")
def open_(
    draft: Annotated[bool, Parameter(help="Open as draft")] = False,
    title: Annotated[str | None, Parameter(help="PR title (else auto-fill)")] = None,
    body: Annotated[str | None, Parameter(help="PR body (else auto-fill)")] = None,
    web: Annotated[bool, Parameter(help="Open PR in browser")] = False,
    base: Annotated[str | None, Parameter(help="explicit base branch (overrides auto-detect)")] = None,
) -> None:
    """Push the current PR branch and open a pull request.

    Base auto-detection:
    - If the current branch is part of an active stack, the base is its
      parent in the stack (or main, for the bottom). Pass --base to override.
    - Otherwise, the base is origin's default branch (typically main).
    """
    br = git.current_branch()
    require_pr_branch(br)
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")

    main = git.remote_main_branch()
    stack = _stack.load()
    if base is None:
        if stack is not None and br in stack.branches:
            base = _stack.base_for(stack, br, main)
            if base != main:
                print(
                    f"pr-bot: stack {stack.name!r}: routing PR base to {base} "
                    f"(use --base {main} to override or 'pr-bot stack push' for the whole chain)"
                )
        else:
            base = main

    git.push(br)
    gh.create_pr(base=base, title=title, body=body, draft=draft, web=web)


@app.command
def sync() -> None:
    """Rebase the current PR branch onto origin/main; force-push with lease."""
    br = git.current_branch()
    require_pr_branch(br)
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    git.fetch()
    base = git.remote_main_branch()
    if not git.rebase_try(f"origin/{base}"):
        if git.rebase_in_progress():
            raise SystemExit(
                f"pr-bot: rebase onto origin/{base} hit a conflict.\n"
                f"resolve with:\n"
                f"  git status                # see conflicted files\n"
                f"  # edit the files, then:\n"
                f"  git add <file>...\n"
                f"  git rebase --continue\n"
                f"  pr-bot pr sync            # re-run to push\n"
                f"or abort with 'git rebase --abort'."
            )
        raise SystemExit(f"pr-bot: rebase onto origin/{base} failed")
    if git.branch_exists_remote(br):
        git.push_force_with_lease(br)
    else:
        git.push(br)


@app.command
def ready() -> None:
    """Mark the current PR as ready for review (undraft)."""
    require_pr_branch(git.current_branch())
    gh.mark_ready()


@app.command
def merge(
    auto: Annotated[bool, Parameter(help="Enable auto-merge when checks pass")] = False,
) -> None:
    """Squash-merge the current PR into main and delete the branch (local + remote)."""
    br = git.current_branch()
    require_pr_branch(br)
    main = git.main_branch()
    gh.merge_pr(squash=True, delete_branch=True, auto=auto)
    if auto:
        print("pr-bot: auto-merge queued; branch will delete on merge")
        return
    git.fetch()
    git.checkout(main)
    _reconcile_main_after_squash(main, br)
    if git.branch_exists_local(br):
        git.delete_branch_local(br, force=True)


@app.command
def cleanup() -> None:
    """Finish the merge dance for a PR that was merged via the GitHub UI.

    If the current branch is a PR branch whose PR is closed/merged on GitHub,
    fetch + switch to main + fast-forward (or surface a diverged-main warning),
    and delete the local PR branch.
    """
    br = git.current_branch()
    pb = parse_pr_branch(br)
    if pb is None:
        raise SystemExit(f"pr-bot: {br!r} is not a PR branch (feat|fix|hotfix/<slug>)")
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    pr = gh.current_pr()
    if pr is not None and pr.get("state") == "OPEN":
        raise SystemExit(
            f"pr-bot: PR #{pr['number']} is still OPEN. "
            f"use 'pr-bot pr merge' to land it, or 'gh pr close' first."
        )

    main = git.main_branch()
    git.fetch()
    git.checkout(main)
    _reconcile_main_after_squash(main, br)
    if git.branch_exists_local(br):
        git.delete_branch_local(br, force=True)
    print(f"pr-bot: cleaned up {br}")


def _reconcile_main_after_squash(main: str, feat_branch: str) -> None:
    """Bring local main in sync with origin/main after a squash merge.

    Fast-forwards when possible. If local main has commits not on origin/main,
    surfaces them and exits — the user decides whether to rebase or reset.
    (The squash merge is already done on GitHub, so bailing here is safe.)
    """
    remote_ref = f"origin/{main}"
    if git.is_ancestor(main, remote_ref):
        git.pull_ff()
        return
    stray = git.git("log", "--oneline", f"{remote_ref}..{main}", check=False).stdout.strip()
    raise SystemExit(
        f"pr-bot: PR squash-merged on GitHub, but local {main} has commits not on "
        f"{remote_ref}:\n{stray}\n\n"
        f"the squash merge may have superseded these. reconcile with:\n"
        f"  git rebase {remote_ref}          # keep local commits\n"
        f"  git reset --hard {remote_ref}    # discard them (destructive)\n\n"
        f"then delete the feat branch:\n"
        f"  git branch -D {feat_branch}"
    )


@app.command
def status() -> None:
    """Show where the current branch is relative to main, plus any open PR."""
    br = git.current_branch()
    pb = parse_pr_branch(br)
    print(f"branch: {br}" + ("" if pb else "  (not a pr-bot PR branch)"))

    if git.has_remote():
        git.fetch()
        base = git.remote_main_branch()
        try:
            ahead, behind = git.ahead_behind(br, f"origin/{base}")
            print(f"vs origin/{base}: ahead {ahead}, behind {behind}")
        except Exception:
            pass

        pr = gh.current_pr()
        if pr:
            print(f"pr #{pr['number']}: {pr['state']} "
                  f"{'(draft) ' if pr.get('isDraft') else ''}"
                  f"— {pr['title']}")
            print(f"  {pr['url']}")
            ms = pr.get("mergeStateStatus")
            if ms:
                print(f"  merge state: {ms}")
        else:
            print("pr: none open for this branch")
    else:
        print("pr-bot: no 'origin' remote; skipping remote checks")
