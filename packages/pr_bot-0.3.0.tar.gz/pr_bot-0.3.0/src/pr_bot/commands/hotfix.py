"""pr-bot hotfix <subcommand> — hotfixes on release branches + forward-port to main."""

from __future__ import annotations

import re
from typing import Annotated

from cyclopts import App, Parameter

from pr_bot import gh, git
from pr_bot.names import (
    ReleaseLine,
    pr_branch,
    require_pr_branch,
)

app = App(name="hotfix", help="Hotfix flow: branch off release/X.Y, merge back, forward-port to main.")


SERIES_RE = re.compile(r"^(\d+)\.(\d+)$")


def _parse_series(series: str) -> ReleaseLine:
    m = SERIES_RE.match(series)
    if not m:
        raise SystemExit(f"pr-bot: expected X.Y (e.g. 1.4), got {series!r}")
    return ReleaseLine(int(m.group(1)), int(m.group(2)))


@app.command
def start(
    slug: Annotated[str, Parameter(help="kebab-case slug, e.g. 'fix-npe-on-logout'")],
    on: Annotated[str, Parameter(name="--on", help="target release series, X.Y")],
) -> None:
    """Create a hotfix/<slug> branch off release/X.Y."""
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    rl = _parse_series(on)
    pb = pr_branch("hotfix", slug)
    if git.branch_exists_local(str(pb)):
        raise SystemExit(f"pr-bot: branch {pb} already exists locally")
    if git.has_remote():
        git.fetch()
    if not git.branch_exists_local(rl.branch):
        if git.has_remote() and git.branch_exists_remote(rl.branch):
            git.checkout(rl.branch)
        else:
            raise SystemExit(f"pr-bot: {rl.branch} does not exist")
    else:
        git.checkout(rl.branch)
    if git.has_remote():
        git.pull_ff()
    git.checkout_new(str(pb), rl.branch)
    print(f"pr-bot: on {pb} (based on {rl.branch})")


@app.command(name="open")
def open_(
    on: Annotated[str, Parameter(name="--on", help="target release series, X.Y")],
    title: Annotated[str | None, Parameter(help="PR title")] = None,
    body: Annotated[str | None, Parameter(help="PR body")] = None,
    draft: Annotated[bool, Parameter(help="open as draft")] = False,
) -> None:
    """Push the current hotfix branch and open a PR against release/X.Y."""
    br = git.current_branch()
    pb = require_pr_branch(br)
    if pb.type != "hotfix":
        raise SystemExit(f"pr-bot: current branch {br} is not a hotfix/ branch")
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")
    rl = _parse_series(on)
    git.push(br)
    gh.create_pr(base=rl.branch, title=title, body=body, draft=draft)


@app.command
def forward_port(
    ref: Annotated[str, Parameter(help="commit SHA from the release branch to cherry-pick to main")],
    slug: Annotated[str | None, Parameter(help="slug for the forward-port branch (default: derived)")] = None,
) -> None:
    """Cherry-pick a hotfix commit from a release branch to a new fix/ branch off main."""
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    main = git.main_branch()
    if git.has_remote():
        git.fetch()
    git.checkout(main)
    if git.has_remote():
        git.pull_ff()
    effective_slug = slug or f"forward-port-{ref[:7]}"
    pb = pr_branch("fix", effective_slug)
    if git.branch_exists_local(str(pb)):
        raise SystemExit(f"pr-bot: branch {pb} already exists locally")
    git.checkout_new(str(pb), main)
    git.cherry_pick(ref)
    print(f"pr-bot: cherry-picked {ref} onto {pb}")
    print("next:  pr-bot pr open   # then pr-bot pr merge")
