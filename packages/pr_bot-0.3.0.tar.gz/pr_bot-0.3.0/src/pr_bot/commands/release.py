"""pr-bot release <subcommand> — cut release branches and tag semver versions."""

from __future__ import annotations

import os
import re
import subprocess
from typing import Annotated

from cyclopts import App, Parameter

from pr_bot import changelog, gh, git, release_notes
from pr_bot.names import (
    ReleaseLine,
    Version,
    parse_release_branch,
    parse_version,
    require_release_branch,
)
from pr_bot.pyproject import find_pyproject
from pr_bot.pyproject import read_version as read_pyproject_version

app = App(name="release", help="Cut release/X.Y branches and tag X.Y.Z versions.")


SERIES_RE = re.compile(r"^(\d+)\.(\d+)$")


def _parse_series(series: str) -> ReleaseLine:
    m = SERIES_RE.match(series)
    if not m:
        raise SystemExit(f"pr-bot: expected X.Y (e.g. 1.4), got {series!r}")
    return ReleaseLine(int(m.group(1)), int(m.group(2)))


@app.command
def cut(
    series: Annotated[str, Parameter(help="X.Y, e.g. '1.4'")],
    from_ref: Annotated[str | None, Parameter(name="--from", help="commit to cut from (default: main)")] = None,
    push: Annotated[bool, Parameter(help="push the new branch to origin")] = True,
) -> None:
    """Create a new release/X.Y branch from main (or --from <ref>)."""
    rl = _parse_series(series)
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")
    main = git.main_branch()
    start = from_ref or main
    if git.has_remote():
        git.fetch()
    if git.branch_exists_local(rl.branch) or (git.has_remote() and git.branch_exists_remote(rl.branch)):
        raise SystemExit(f"pr-bot: {rl.branch} already exists")
    if from_ref is None:
        git.checkout(main)
        if git.has_remote():
            git.pull_ff()
    git.checkout_new(rl.branch, start)
    if push and git.has_remote():
        git.push(rl.branch)
    print(f"pr-bot: cut {rl.branch} from {start}")


@app.command
def tag(
    version: Annotated[str, Parameter(help="X.Y.Z, e.g. '1.4.0'")],
    ref: Annotated[str | None, Parameter(help="commit to tag (default: HEAD of release branch)")] = None,
    notes: Annotated[str | None, Parameter(help="release notes body (string)")] = None,
    notes_file: Annotated[str | None, Parameter(help="release notes from a file path")] = None,
    gh_release: Annotated[bool, Parameter(name="--gh-release", help="also create a GitHub release")] = True,
    push: Annotated[bool, Parameter(help="push the tag to origin")] = True,
    skip_version_check: Annotated[bool, Parameter(help="bypass pyproject.toml match (not recommended)")] = False,
) -> None:
    """Tag X.Y.Z on the matching release/X.Y branch.

    Refuses to tag unless pyproject.toml's [project].version matches X.Y.Z —
    prevents the drift where the git tag says 0.1.1 but the built wheel is
    labeled 0.1.0.
    """
    v = parse_version(version)
    if v is None:
        raise SystemExit(f"pr-bot: expected X.Y.Z, got {version!r}")
    rl = v.release_line

    br = git.current_branch()
    on_release = parse_release_branch(br)

    if on_release is None or on_release != rl:
        if not git.branch_exists_local(rl.branch):
            if git.has_remote() and git.branch_exists_remote(rl.branch):
                git.checkout(rl.branch)
            else:
                raise SystemExit(f"pr-bot: {rl.branch} does not exist; run 'pr-bot release cut {rl.series}' first")
        else:
            git.checkout(rl.branch)

    if git.has_remote():
        git.fetch()
        git.pull_ff()

    pyproject_version = read_pyproject_version(find_pyproject())
    if pyproject_version is not None and pyproject_version != str(v):
        if skip_version_check:
            print(
                f"pr-bot: WARNING pyproject.toml version {pyproject_version!r} != tag {v} "
                f"(--skip-version-check set)"
            )
        else:
            raise SystemExit(
                f"pr-bot: pyproject.toml [project].version is {pyproject_version!r}, but you're "
                f"tagging {v}. bump pyproject.toml on the release branch first:\n"
                f"  pr-bot release prepare {v}\n"
                f"then re-run 'pr-bot release tag {v} --notes-file docs/releases/{v}.md'.\n"
                f"(use --skip-version-check to bypass — not recommended)"
            )

    if git.tag_exists(str(v)):
        raise SystemExit(f"pr-bot: tag {v} already exists")

    git.tag(str(v), ref or "HEAD", message=f"Release {v}")
    if push and git.has_remote():
        git.push_tag(str(v))
    print(f"pr-bot: tagged {v} on {rl.branch}")

    if gh_release and git.has_remote():
        gh.create_release(
            str(v),
            title=f"v{v}",
            notes=notes,
            notes_file=notes_file,
            target=rl.branch,
        )


@app.command
def prepare(
    version: Annotated[str, Parameter(help="X.Y.Z, e.g. '1.4.0'")],
    push: Annotated[bool, Parameter(help="push the bump commit to origin")] = True,
) -> None:
    """Bump pyproject.toml to X.Y.Z and commit on the matching release/X.Y branch.

    Pair with 'pr-bot release tag X.Y.Z' which will then succeed without the
    'pyproject doesn't match' check tripping.
    """
    v = parse_version(version)
    if v is None:
        raise SystemExit(f"pr-bot: expected X.Y.Z, got {version!r}")
    rl = v.release_line

    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    br = git.current_branch()
    on_release = parse_release_branch(br)
    if on_release is None or on_release != rl:
        if not git.branch_exists_local(rl.branch):
            if git.has_remote() and git.branch_exists_remote(rl.branch):
                git.checkout(rl.branch)
            else:
                raise SystemExit(
                    f"pr-bot: {rl.branch} does not exist; run 'pr-bot release cut {rl.series}' first"
                )
        else:
            git.checkout(rl.branch)

    if git.has_remote():
        git.fetch()
        git.pull_ff()

    pp = find_pyproject()
    if pp is None:
        raise SystemExit("pr-bot: no pyproject.toml found")
    current = read_pyproject_version(pp)
    if current == str(v):
        print(f"pr-bot: pyproject.toml already at {v}; nothing to bump")
        return

    text = pp.read_text()
    new_text = re.sub(
        r'^version\s*=\s*"[^"]*"',
        f'version = "{v}"',
        text,
        count=1,
        flags=re.MULTILINE,
    )
    if new_text == text:
        raise SystemExit("pr-bot: could not find a [project] version line in pyproject.toml")
    pp.write_text(new_text)

    # Auto-draft release notes if the file doesn't exist yet.
    root = changelog.repo_root()
    notes_path = (root / "docs" / "releases" / f"{v}.md") if root else None
    notes_added = False
    if notes_path is not None and not notes_path.exists() and git.has_remote():
        try:
            body = release_notes.draft(v)
            notes_path.parent.mkdir(parents=True, exist_ok=True)
            notes_path.write_text(body)
            notes_added = True
            print(f"pr-bot: auto-drafted {notes_path} (review before tagging)")
        except SystemExit as e:
            print(f"pr-bot: skipping notes auto-draft ({e})")

    cl_path = changelog.generate()

    add_args = [str(pp), str(cl_path)]
    if notes_added and notes_path is not None:
        add_args.append(str(notes_path))
    git.git("add", *add_args, echo=True)
    git.git("commit", "-m", f"chore: bump to {v}", echo=True)
    if push and git.has_remote():
        git.push(rl.branch)
    print(f"pr-bot: bumped pyproject.toml to {v} and regenerated CHANGELOG.md on {rl.branch}")


@app.command(name="notes-draft")
def notes_draft(
    version: Annotated[str, Parameter(help="X.Y.Z, e.g. '1.4.0'")],
    edit: Annotated[bool, Parameter(help="open the file in $EDITOR after writing")] = False,
    print_: Annotated[bool, Parameter(name="--print", help="write to stdout, not the file")] = False,
    since: Annotated[str | None, Parameter(help="ref/tag/date floor (default: previous tag)")] = None,
    base: Annotated[str | None, Parameter(help="PR base branch (default: release/X.Y or main)")] = None,
    force: Annotated[bool, Parameter(help="overwrite an existing notes file")] = False,
) -> None:
    """Draft docs/releases/X.Y.Z.md from PRs merged since the previous tag."""
    v = parse_version(version)
    if v is None:
        raise SystemExit(f"pr-bot: expected X.Y.Z, got {version!r}")
    body = release_notes.draft(v, since=since, base=base)
    if print_:
        print(body, end="")
        return
    root = changelog.repo_root()
    if root is None:
        raise SystemExit("pr-bot: no pyproject.toml found")
    target = root / "docs" / "releases" / f"{v}.md"
    if target.exists() and not force:
        raise SystemExit(f"pr-bot: {target} exists; use --force to overwrite")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(body)
    print(f"pr-bot: wrote {target}")
    if edit:
        editor = os.environ.get("EDITOR", "vi")
        subprocess.run([editor, str(target)], check=False)


@app.command(name="changelog")
def changelog_cmd() -> None:
    """Regenerate CHANGELOG.md from docs/releases/*.md (sorted by version desc)."""
    out = changelog.generate()
    print(f"pr-bot: wrote {out}")


@app.command(name="list")
def list_() -> None:
    """List release branches and their highest tag."""
    if git.has_remote():
        git.fetch()
    local = {b for b in git.list_branches("release/*")}
    remote = set(git.list_remote_branches("release/*")) if git.has_remote() else set()
    branches = sorted(local | remote)
    if not branches:
        print("pr-bot: no release branches found")
        return

    for br in branches:
        rl = parse_release_branch(br)
        if rl is None:
            continue
        versions = []
        for t in git.list_tags(f"{rl.major}.{rl.minor}.*"):
            v = parse_version(t)
            if v is not None:
                versions.append(v)
        latest = max(versions, key=lambda v: (v.major, v.minor, v.patch)) if versions else None
        flags = []
        if br in local:
            flags.append("local")
        if br in remote:
            flags.append("remote")
        suffix = f"latest tag {latest}" if latest else "no tags yet"
        print(f"  {br:<20}  {suffix:<24}  ({', '.join(flags)})")


@app.command
def next_patch(
    series: Annotated[str | None, Parameter(help="X.Y (default: current release branch)")] = None,
) -> None:
    """Print the next unused patch version for release/X.Y."""
    rl = require_release_branch(git.current_branch()) if series is None else _parse_series(series)
    versions = [v for v in (parse_version(t) for t in git.list_tags(f"{rl.major}.{rl.minor}.*")) if v is not None]
    if not versions:
        nxt = Version(rl.major, rl.minor, 0)
    else:
        highest = max(versions, key=lambda v: v.patch)
        nxt = Version(rl.major, rl.minor, highest.patch + 1)
    print(nxt)
