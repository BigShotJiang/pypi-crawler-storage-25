"""pr-bot policy <subcommand> — apply/check GitHub branch protection."""

from __future__ import annotations

from cyclopts import App

from pr_bot import gh
from pr_bot import policy as pol
from pr_bot.changelog import repo_root

app = App(name="policy", help="Apply/check GitHub branch protection from .pr-bot.toml.")


def _load() -> pol.Policy:
    root = repo_root()
    if root is None:
        raise SystemExit("pr-bot: no pyproject.toml found")
    cfg = root / ".pr-bot.toml"
    if not cfg.is_file():
        print(f"pr-bot: {cfg} missing — using defaults (main, linear, no force-push, "
              "0 reviews, status check 'test')")
        return pol.default_policy()
    return pol.load(cfg)


@app.command
def apply() -> None:
    """Push the policy from .pr-bot.toml to GitHub via the branch-protection API."""
    p = _load()
    payload = pol.to_payload(p)
    slug = gh.repo_slug()
    for branch in p.protected_branches:
        print(f"pr-bot: applying policy to {slug}@{branch}")
        gh.branch_protection_put(branch, payload, slug=slug)
    print("pr-bot: applied.")


@app.command
def check() -> int:
    """Compare GitHub's actual branch protection to the declared policy.

    Exit code 0 = match (or remote unprotected and no diff to report);
    1 = mismatch (drift). Prints a human-readable diff to stdout.
    """
    p = _load()
    slug = gh.repo_slug()
    drift = 0
    for branch in p.protected_branches:
        actual = gh.branch_protection_get(branch, slug=slug)
        if actual is None:
            print(f"pr-bot: {branch} has NO branch protection on GitHub")
            drift += 1
            continue
        diffs = pol.diff(p, actual)
        if not diffs:
            print(f"pr-bot: {branch} matches policy")
        else:
            print(f"pr-bot: {branch} drift:")
            for d in diffs:
                print(f"  - {d}")
            drift += 1
    return 0 if drift == 0 else 1
