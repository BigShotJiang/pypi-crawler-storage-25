"""pr-bot doctor — sanity-check the repo against the pr-bot branching model."""

from __future__ import annotations

from pr_bot import git
from pr_bot import policy as _pol
from pr_bot.changelog import repo_root
from pr_bot.names import parse_pr_branch, parse_release_branch, parse_version
from pr_bot.names import parse_version as _pv
from pr_bot.pyproject import find_pyproject, read_version
from pr_bot.sh import run

# Each check returns (level, message) where level is 'ok' | 'warn' | 'problem'.
# A 'problem' fails the run; 'warn' is informational.


def _check_main_linear(main: str) -> tuple[str, str] | None:
    r = run(["git", "log", "--merges", "--format=%H", main], check=False)
    if not r.ok:
        return None
    n = len([line for line in r.stdout.strip().splitlines() if line])
    if n == 0:
        return ("ok", f"{main} is linear (0 merge commits)")
    return ("problem", f"{main} has {n} merge commit(s) — expected linear history (squash only)")


def _check_remote() -> tuple[str, str]:
    if git.has_remote():
        return ("ok", "remote 'origin' is configured")
    return ("warn", "no 'origin' remote configured (some checks skipped)")


def _check_gh_auth() -> tuple[str, str]:
    r = run(["gh", "auth", "status"], check=False)
    if r.ok:
        return ("ok", "gh auth: authenticated")
    return ("warn", "gh auth status reports not logged in (run 'gh auth login')")


def _check_branch_naming(main: str) -> list[tuple[str, str]]:
    out = []
    for br in git.list_branches("*"):
        if br in (main, "master"):
            continue
        if parse_release_branch(br) is not None:
            continue
        if parse_pr_branch(br) is None:
            out.append(("warn", f"branch {br!r} does not match any pr-bot pattern"))
    return out


def _check_tag_naming() -> list[tuple[str, str]]:
    out = []
    for t in git.list_tags("*"):
        if parse_version(t) is None:
            out.append(("warn", f"tag {t!r} is not X.Y.Z semver"))
    return out


def _check_pyproject_version() -> tuple[str, str] | None:
    pp = find_pyproject()
    if pp is None:
        return ("warn", "no pyproject.toml found at repo root")
    v = read_version(pp)
    if v is None:
        return ("warn", "pyproject.toml has no [project].version")
    if _pv(v) is None:
        return ("problem", f"pyproject.toml [project].version {v!r} is not X.Y.Z semver")
    return ("ok", f"pyproject.toml [project].version = {v}")


def _check_pr_bot_toml() -> tuple[str, str]:
    root = repo_root()
    if root is None:
        return ("warn", "no pyproject.toml so .pr-bot.toml location unknown")
    cfg = root / ".pr-bot.toml"
    if cfg.is_file():
        return ("ok", f"{cfg.relative_to(root)} present")
    return ("warn", ".pr-bot.toml missing — 'pr-bot policy apply' will use defaults")


def _check_ci_workflow() -> tuple[str, str]:
    root = repo_root()
    if root is None:
        return ("warn", "no pyproject.toml so CI workflow location unknown")
    ci = root / ".github" / "workflows" / "ci.yml"
    if ci.is_file():
        return ("ok", ".github/workflows/ci.yml present")
    return ("warn", ".github/workflows/ci.yml missing — no CI gate")


def _check_slash_command_set() -> list[tuple[str, str]]:
    """Verify every slash command file references a real CLI subcommand path."""
    root = repo_root()
    if root is None:
        return []
    cmd_dir = root / "commands"
    if not cmd_dir.is_dir():
        return [("warn", "commands/ directory missing — Claude Code plugin won't ship slash commands")]
    out = []
    for md in sorted(cmd_dir.glob("*.md")):
        body = md.read_text()
        if "uvx --from" not in body or "pr-bot" not in body and "toolbar" not in body:
            out.append(("warn", f"{md.name}: no pr-bot/toolbar invocation found"))
    return out


def _check_policy_match() -> tuple[str, str] | None:
    """If a .pr-bot.toml exists and origin is set, diff declared vs actual."""
    if not git.has_remote():
        return None
    root = repo_root()
    if root is None:
        return None
    cfg = root / ".pr-bot.toml"
    if not cfg.is_file():
        return None
    try:
        from pr_bot import gh as _gh

        declared = _pol.load(cfg)
        slug = _gh.repo_slug()
    except SystemExit:
        return ("warn", "policy: couldn't query gh for branch protection (skipping diff)")
    drift_lines: list[str] = []
    for branch in declared.protected_branches:
        actual = _gh.branch_protection_get(branch, slug=slug)
        if actual is None:
            drift_lines.append(f"{branch}: no protection on GitHub")
            continue
        diffs = _pol.diff(declared, actual)
        drift_lines.extend(f"{branch}: {d}" for d in diffs)
    if drift_lines:
        return ("warn", "policy drift detected — run 'pr-bot policy check' for details")
    return ("ok", f"policy matches GitHub for {len(declared.protected_branches)} branch(es)")


def check() -> int:
    """Run all checks; return 0 on success, 1 on any problem, 2 on hard error."""
    try:
        main = git.main_branch()
    except SystemExit as e:
        print(str(e))
        return 2

    results: list[tuple[str, str]] = []

    # Always-applicable
    results.append(_check_remote())
    if remote_check := _check_main_linear(main):
        results.append(remote_check)

    # Branch and tag conventions
    results.extend(_check_branch_naming(main))
    results.extend(_check_tag_naming())

    # Repo-shape checks
    if pp := _check_pyproject_version():
        results.append(pp)
    results.append(_check_pr_bot_toml())
    results.append(_check_ci_workflow())
    results.extend(_check_slash_command_set())

    # Things that need gh
    if git.has_remote():
        results.append(_check_gh_auth())
        if pol := _check_policy_match():
            results.append(pol)

    print(f"main branch: {main}\n")

    oks = [m for level, m in results if level == "ok"]
    warns = [m for level, m in results if level == "warn"]
    problems = [m for level, m in results if level == "problem"]

    if oks:
        print("ok:")
        for m in oks:
            print(f"  ✓ {m}")
    if warns:
        print()
        print("warnings:")
        for w in warns:
            print(f"  - {w}")
    if problems:
        print()
        print("problems:")
        for p in problems:
            print(f"  ✗ {p}")
        return 1

    print()
    print("ok.")
    return 0
