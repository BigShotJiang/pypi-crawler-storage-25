"""pr-bot stack <subcommand> — stacked PRs.

Implementing per docs/design-pr-stack.md, slice by slice.
"""

from __future__ import annotations

from typing import Annotated

from cyclopts import App, Parameter

from pr_bot import gh, git, stack
from pr_bot.names import pr_branch

app = App(name="stack", help="Stacked PR support — chain of dependent PR branches.")


@app.command
def new(
    branches: Annotated[
        list[str],
        Parameter(
            help=(
                "Two or more branch specs. Each is 'feat:slug', 'fix:slug', or just "
                "'slug' (defaults to feat). Example: 'pr-bot stack new auth-tokens "
                "auth-middleware auth-routes'."
            )
        ),
    ],
) -> None:
    """Create a stack of PR branches, each based on the previous.

    Branches off main:
      feat/auth-tokens   ← bottom (parent: main)
       └─ feat/auth-middleware     (parent: feat/auth-tokens)
           └─ feat/auth-routes     (parent: feat/auth-middleware)

    Leaves you on the *first* (bottom-most) branch, ready to start work.
    """
    if len(branches) < 2:
        raise SystemExit("pr-bot: stack new needs at least 2 branches")
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    parsed: list[tuple[str, str]] = [stack.parse_stack_arg(a) for a in branches]
    branch_names = [str(pr_branch(t, s)) for t, s in parsed]

    if existing := stack.load():
        raise SystemExit(
            f"pr-bot: a stack already exists ({existing.name!r}, {len(existing.branches)} branches). "
            "use 'pr-bot stack abandon' (coming soon) or remove "
            ".git/pr-bot/stack.json manually."
        )

    for name in branch_names:
        if git.branch_exists_local(name):
            raise SystemExit(f"pr-bot: branch {name} already exists locally")

    main = git.main_branch()
    if git.has_remote():
        git.fetch()
    git.checkout(main)
    if git.has_remote():
        git.pull_ff()

    parent = main
    for br in branch_names:
        git.checkout_new(br, parent)
        parent = br

    # Leave user on the bottom branch (first in the list).
    git.checkout(branch_names[0])

    s = stack.Stack(name=stack.name_from_slugs([slug for _, slug in parsed]),
                    branches=tuple(branch_names))
    state = stack.save(s)
    print(f"pr-bot: created stack {s.name!r} with {len(branch_names)} branches "
          f"({state})")
    for i, br in enumerate(branch_names):
        marker = "→" if i == 0 else " "
        print(f"  {marker} {br}")


@app.command
def land(
    all_: Annotated[bool, Parameter(name="--all", help="land every branch in order, syncing between merges")] = False,
) -> None:
    """Squash-merge the bottom branch of the stack and pop it from the state.

    With `--all`, repeats: after each merge, fetch + reset main to origin,
    rebase what's left of the stack, and merge the new bottom. Stops at the
    first PR that isn't ready (still draft) or fails its merge.
    """
    s = stack.load()
    if s is None:
        raise SystemExit("pr-bot: no stack found in this repo")
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    main = git.main_branch()

    while s.branches:
        bottom = s.branches[0]
        git.fetch()
        git.checkout(bottom)
        pr = gh.pr_view(bottom)
        if pr is None:
            raise SystemExit(f"pr-bot: {bottom} has no PR — run 'pr-bot stack push' first")
        if pr.get("isDraft"):
            print(f"pr-bot: {bottom} (#{pr['number']}) is draft; marking ready")
            gh.mark_ready()
        # Squash + delete remote branch via the existing pr.merge flow.
        gh.merge_pr(squash=True, delete_branch=True, auto=False)
        git.fetch()
        git.checkout(main)
        # Reuse the same reconciliation pr-bot pr merge uses, but inlined:
        if git.is_ancestor(main, f"origin/{main}"):
            git.pull_ff()
        else:
            print(
                f"pr-bot: local {main} diverged from origin/{main}; resetting --hard "
                f"to origin/{main} (squash already on remote)"
            )
            git.git("reset", "--hard", f"origin/{main}", echo=True)
        if git.branch_exists_local(bottom):
            git.delete_branch_local(bottom, force=True)
        # Pop the bottom from the stack.
        s = stack.Stack(name=s.name, branches=s.branches[1:], created_at=s.created_at)
        if s.branches:
            stack.save(s)
        else:
            stack.clear()
        print(f"pr-bot: landed {bottom} (#{pr['number']})")
        if not all_:
            break
        if s.branches:
            print("pr-bot: syncing remaining stack onto new main")
            sync()

    if not s.branches:
        print("pr-bot: stack fully landed; state cleared")


@app.command
def status() -> None:
    """Print the stack: each branch, its PR (if any), draft state, and CI."""
    s = stack.load()
    if s is None:
        raise SystemExit("pr-bot: no stack found in this repo")
    print(f"stack: {s.name}  ({len(s.branches)} branch{'es' if len(s.branches) != 1 else ''})")
    for i, br in enumerate(s.branches):
        prefix = "→" if br == git.current_branch() else " "
        line = f"  {prefix} {i + 1}/{len(s.branches)} {br}"
        if git.has_remote():
            pr = gh.pr_view(br)
            if pr:
                draft = " (draft)" if pr.get("isDraft") else ""
                line += f"  #{pr['number']} {pr['state']}{draft}"
            else:
                line += "  (no PR)"
        print(line)


@app.command
def abandon() -> None:
    """Delete the stack state file. Branches and PRs are left intact."""
    s = stack.load()
    if s is None:
        print("pr-bot: no stack to abandon")
        return
    stack.clear()
    print(f"pr-bot: abandoned stack {s.name!r} ({len(s.branches)} branches kept)")
    print("pr-bot: clean up branches manually with 'git branch -D' / 'pr-bot pr cleanup' if desired")


@app.command
def sync() -> None:
    """Rebase the entire stack onto origin/main; force-push each branch.

    Walks bottom-to-top: each branch is rebased onto its (possibly just-rebased)
    parent. Stops on the first conflict, leaving the user mid-rebase with a
    clear instruction; the next 'pr-bot stack sync' will resume from where
    the conflict was resolved.
    """
    s = stack.load()
    if s is None:
        raise SystemExit("pr-bot: no stack found in this repo (run 'pr-bot stack new' first)")
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    starting = git.current_branch()
    base = git.remote_main_branch()
    git.fetch()

    # For each branch in order, rebase onto its parent's CURRENT head
    # (which may differ from its original parent commit after the previous
    # branch in this loop just got rebased).
    for i, br in enumerate(s.branches):
        parent_ref = f"origin/{base}" if i == 0 else s.branches[i - 1]
        git.checkout(br)
        if not git.rebase_try(parent_ref):
            if git.rebase_in_progress():
                raise SystemExit(
                    f"pr-bot: rebase of {br} onto {parent_ref} hit a conflict.\n"
                    f"resolve, then run 'git rebase --continue', then re-run "
                    f"'pr-bot stack sync' to finish the rest of the chain.\n"
                    f"or abort with 'git rebase --abort'."
                )
            raise SystemExit(f"pr-bot: rebase of {br} onto {parent_ref} failed")
        # Force-push (with lease) the rebased branch
        if git.branch_exists_remote(br):
            git.push_force_with_lease(br)
        else:
            git.push(br)

    if starting in s.branches:
        git.checkout(starting)
    print(f"pr-bot: synced {len(s.branches)} branches in stack {s.name!r}")


@app.command
def push(
    drafts: Annotated[bool, Parameter(help="open all but the bottom as drafts (default: yes)")] = True,
) -> None:
    """Push every branch in the stack and ensure each has a linked PR.

    For each branch in order:
    - Push (or force-push-with-lease if already on origin).
    - If no PR exists, gh pr create against the parent branch (or main for
      the bottom). The bottom is opened ready; higher branches are drafted.
    - If a PR exists, update its body's pr-bot:stack marker block in place.
    """
    s = stack.load()
    if s is None:
        raise SystemExit("pr-bot: no stack found in this repo (run 'pr-bot stack new' first)")
    if not git.has_remote():
        raise SystemExit("pr-bot: no 'origin' remote configured")
    if git.has_uncommitted():
        raise SystemExit("pr-bot: uncommitted changes; commit or stash first")

    main = git.remote_main_branch()
    starting_branch = git.current_branch()
    git.fetch()

    # Phase 1: push each branch (so PRs can be created against them).
    for br in s.branches:
        git.checkout(br)
        if git.branch_exists_remote(br):
            git.push_force_with_lease(br)
        else:
            git.push(br)

    # Phase 2: ensure each has a PR; collect numbers.
    pr_numbers: dict[str, int | None] = {br: None for br in s.branches}
    for i, br in enumerate(s.branches):
        git.checkout(br)
        existing = gh.pr_view(br)
        if existing is None:
            base = stack.base_for(s, br, main)
            draft = drafts and i > 0
            # Open with a placeholder body — phase 3 rewrites bodies with full
            # cross-links once all numbers are known.
            placeholder = f"_pr-bot stack: {br}, base {base}_"
            gh.create_pr(base=base, title=br, body=placeholder, draft=draft)
            now = gh.pr_view(br)
            if now is not None:
                pr_numbers[br] = now["number"]
        else:
            pr_numbers[br] = existing["number"]

    # Phase 3: render and write the marker block on every PR.
    for br in s.branches:
        existing = gh.pr_view(br)
        if existing is None:
            continue
        marker = stack.render_marker(s, br, pr_numbers)
        body = stack.merge_marker(existing.get("body"), marker)
        gh.pr_edit_body(br, body)

    # Restore where the user was (if it was a stack branch — usually is).
    if starting_branch in s.branches:
        git.checkout(starting_branch)
    print(f"pr-bot: pushed and linked {len(s.branches)} PRs in stack {s.name!r}")
    for br, num in pr_numbers.items():
        suffix = f"#{num}" if num else "(no PR)"
        print(f"  {br:<40}  {suffix}")
