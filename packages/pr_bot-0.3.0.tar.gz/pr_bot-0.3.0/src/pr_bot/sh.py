"""Small subprocess helpers used across the CLI."""

from __future__ import annotations

import shutil
import subprocess
import sys
from dataclasses import dataclass


@dataclass
class Result:
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


def run(
    cmd: list[str],
    *,
    check: bool = True,
    capture: bool = True,
    cwd: str | None = None,
    echo: bool = False,
) -> Result:
    """Run a command. Capture output by default."""
    if echo:
        print("$", " ".join(cmd), file=sys.stderr)
    proc = subprocess.run(
        cmd,
        check=False,
        capture_output=capture,
        text=True,
        cwd=cwd,
    )
    result = Result(proc.returncode, proc.stdout or "", proc.stderr or "")
    if check and not result.ok:
        msg = result.stderr.strip() or result.stdout.strip() or f"command failed: {' '.join(cmd)}"
        raise SystemExit(f"pr-bot: {msg}")
    return result


def require(tool: str) -> None:
    if shutil.which(tool) is None:
        raise SystemExit(f"pr-bot: required tool not found on PATH: {tool}")
