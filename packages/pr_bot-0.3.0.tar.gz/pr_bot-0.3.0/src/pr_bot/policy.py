"""Branch-protection policy: load .pr-bot.toml + map to GitHub API payloads.

Scope (v1): classic per-branch protection (no rulesets, no glob patterns).
Targets *exact* branch names listed in `policy.protected_branches`. See
docs/policy.md for the limitation and workaround for multiple release
lines.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_PROTECTED_BRANCHES = ("main",)


@dataclass(frozen=True)
class Policy:
    """The pr-bot model expressed as a config object."""

    linear_history: bool = True
    allow_force_push: bool = False
    allow_deletions: bool = False
    required_status_checks: tuple[str, ...] = ("test",)
    required_approving_review_count: int = 0
    require_conversation_resolution: bool = False
    enforce_admins: bool = False
    protected_branches: tuple[str, ...] = field(default_factory=lambda: DEFAULT_PROTECTED_BRANCHES)


def default_policy() -> Policy:
    return Policy()


def load(path: Path) -> Policy:
    """Read a .pr-bot.toml file and return a Policy. Missing fields use defaults."""
    data = tomllib.loads(path.read_text())
    p = data.get("policy", {})
    return Policy(
        linear_history=p.get("linear_history", True),
        allow_force_push=p.get("allow_force_push", False),
        allow_deletions=p.get("allow_deletions", False),
        required_status_checks=tuple(p.get("required_status_checks", ["test"])),
        required_approving_review_count=p.get("required_approving_review_count", 0),
        require_conversation_resolution=p.get("require_conversation_resolution", False),
        enforce_admins=p.get("enforce_admins", False),
        protected_branches=tuple(p.get("protected_branches", DEFAULT_PROTECTED_BRANCHES)),
    )


def to_payload(p: Policy) -> dict:
    """Map a Policy to a GitHub branch-protection PUT body.

    See https://docs.github.com/en/rest/branches/branch-protection#update-branch-protection
    """
    return {
        "required_status_checks": (
            {
                "strict": False,
                "contexts": list(p.required_status_checks),
            }
            if p.required_status_checks
            else None
        ),
        "enforce_admins": p.enforce_admins,
        "required_pull_request_reviews": {
            "dismiss_stale_reviews": False,
            "require_code_owner_reviews": False,
            "required_approving_review_count": p.required_approving_review_count,
        },
        "restrictions": None,
        "required_linear_history": p.linear_history,
        "allow_force_pushes": p.allow_force_push,
        "allow_deletions": p.allow_deletions,
        "required_conversation_resolution": p.require_conversation_resolution,
    }


def diff(declared: Policy, actual: dict) -> list[str]:
    """Compare a declared policy with the dict returned by GitHub's protection GET.

    Returns a list of human-readable mismatch strings (empty list = match).
    """
    out: list[str] = []
    if (actual.get("required_linear_history") or {}).get("enabled") != declared.linear_history:
        out.append(f"linear_history: declared {declared.linear_history}")
    if (actual.get("allow_force_pushes") or {}).get("enabled") != declared.allow_force_push:
        out.append(f"allow_force_push: declared {declared.allow_force_push}")
    if (actual.get("allow_deletions") or {}).get("enabled") != declared.allow_deletions:
        out.append(f"allow_deletions: declared {declared.allow_deletions}")
    if actual.get("enforce_admins", {}).get("enabled") != declared.enforce_admins:
        out.append(f"enforce_admins: declared {declared.enforce_admins}")
    actual_checks = tuple(
        actual.get("required_status_checks", {}).get("contexts", []) or []
    )
    if set(actual_checks) != set(declared.required_status_checks):
        out.append(
            f"required_status_checks: declared {list(declared.required_status_checks)} "
            f"vs actual {list(actual_checks)}"
        )
    actual_reviews = (
        actual.get("required_pull_request_reviews", {}) or {}
    ).get("required_approving_review_count")
    if actual_reviews is None:
        # No review requirement at all on the remote
        if declared.required_approving_review_count != 0:
            out.append("required_approving_review_count: PR reviews not required on remote")
    elif actual_reviews != declared.required_approving_review_count:
        out.append(
            f"required_approving_review_count: declared {declared.required_approving_review_count} "
            f"vs actual {actual_reviews}"
        )
    return out
