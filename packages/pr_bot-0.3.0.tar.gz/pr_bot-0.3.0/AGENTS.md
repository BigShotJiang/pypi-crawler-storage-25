# AGENTS.md

Instructions for AI coding agents working **on** or **with** `pr-bot`.

## When to reach for pr-bot (in any repo)

If a repository follows the pr-bot branching model (`main` + `release/X.Y` +
`{feat,fix,hotfix}/<slug>`, linear history, squash merges), prefer `pr-bot`
subcommands (or their `/pr-*` / `/release-*` / `/hotfix-*` / `/stack-*` /
`/policy-*` slash twins) over raw `git` for these operations:

- creating PR branches (single or stacked)
- opening, syncing, marking-ready, squash-merging PRs
- cleaning up after a UI merge
- cutting release branches
- bumping pyproject + tagging semver versions
- auto-drafting release notes from merged PRs
- landing hotfixes and forward-porting them
- applying / checking GitHub branch protection rules

Raw git is fine for everything else (inspecting history, committing,
resolving conflicts, etc.).

## Rules the model enforces

An agent MUST NOT:

- merge `main` into a PR branch (rebase instead — `pr-bot pr sync`)
- create a merge commit on `main` (all landings are squash via `pr-bot pr merge`)
- push directly to `main` or `release/*` — always via a PR
- invent branch names outside `feat/`, `fix/`, `hotfix/`, or `release/X.Y`
- invent tag names outside `X.Y.Z`
- delete a release branch — they are long-lived

When in doubt, run `pr-bot doctor` — it checks the invariants.

## Decision tree

```
user wants to …             → use
──────────────────────────────────────────────────────────────────────────
add a new feature            →  pr-bot pr start feat <slug>
fix a bug on main            →  pr-bot pr start fix  <slug>
push + open PR               →  pr-bot pr open [--draft]
catch up with main           →  pr-bot pr sync
mark ready for review        →  pr-bot pr ready
land the PR                  →  pr-bot pr merge
clean up after UI merge      →  pr-bot pr cleanup
inspect status               →  pr-bot pr status

split work into stack of PRs →  pr-bot stack new <slug-1> <slug-2> [...]
push the stack               →  pr-bot stack push
rebase the chain on main     →  pr-bot stack sync
land bottom-of-stack         →  pr-bot stack land [--all]

cut a release line           →  pr-bot release cut X.Y
prep + draft notes for X.Y.Z →  pr-bot release prepare X.Y.Z
ship X.Y.Z                   →  pr-bot release tag X.Y.Z --notes-file docs/releases/X.Y.Z.md
auto-draft notes alone       →  pr-bot release notes-draft X.Y.Z

patch a released version     →  pr-bot hotfix start <slug> --on X.Y
                               pr-bot hotfix open --on X.Y
                               (merge the PR into release/X.Y)
                               pr-bot release prepare X.Y.(Z+1)
                               pr-bot release tag X.Y.(Z+1) --notes-file ...
                               pr-bot hotfix forward-port <sha>
                               pr-bot pr open && pr-bot pr merge

enforce model on GitHub      →  pr-bot policy apply
check for protection drift   →  pr-bot policy check

bootstrap a brand-new repo   →  toolbar repo template <name>

verify model invariants      →  pr-bot doctor
```

## Expected preconditions

`pr-bot` guards against common footguns but agents should still confirm:

- working tree is clean before `pr start` / `release cut` / `hotfix start` /
  `hotfix forward-port`
- the `release/X.Y` target branch exists before `release tag X.Y.Z`
- the current branch matches the expected type for the command (e.g. `pr sync`
  only works on a `feat|fix|hotfix` branch)

## Working on pr-bot itself

For the full architecture, see [`CLAUDE.md`](CLAUDE.md). Quick orientation:

- The CLI lives in `src/pr_bot/` and is wired by `src/pr_bot/cli.py`.
- Subcommand groups are Python modules in `src/pr_bot/commands/`
  (`pr`, `release`, `hotfix`, `stack`, `policy`).
- Shared primitives in `src/pr_bot/`: `sh`, `git`, `gh`, `names`,
  `pyproject`, `changelog`, `release_notes`, `policy`, `stack`, `ui`.
- Sibling CLI in `src/toolbar/` (`repo` group + `template` rendering).
- Keep error messages prefixed with `pr-bot:` or `toolbar:` so callers
  (including slash commands and other agents) can grep/regex them.
- Tests: `uv run pytest -q` (148 passing). Lint: `uv run ruff check src tests`.
- Both gate CI on every PR.

## Non-Interactive Shell Commands

**ALWAYS use non-interactive flags** with file operations to avoid hanging on
confirmation prompts.

```bash
cp -f source dest           # NOT: cp source dest
mv -f source dest           # NOT: mv source dest
rm -f file                  # NOT: rm file
rm -rf directory            # NOT: rm -r directory
```

Other commands that may prompt: `scp` (use `-o BatchMode=yes`), `ssh` (ditto),
`apt-get` (use `-y`), `brew` (set `HOMEBREW_NO_AUTO_UPDATE=1`).

<!-- BEGIN BEADS INTEGRATION v:1 profile:minimal hash:ca08a54f -->
## Beads Issue Tracker

This project uses **bd (beads)** for issue tracking. Run `bd prime` to see full workflow context and commands.

### Quick Reference

```bash
bd ready              # Find available work
bd show <id>          # View issue details
bd update <id> --claim  # Claim work
bd close <id>         # Complete work
```

### Rules

- Use `bd` for ALL task tracking — do NOT use TodoWrite, TaskCreate, or markdown TODO lists
- Run `bd prime` for detailed command reference and session close protocol
- Use `bd remember` for persistent knowledge — do NOT use MEMORY.md files

## Session Completion

**When ending a work session**, you MUST complete ALL steps below. Work is NOT complete until `git push` succeeds.

**MANDATORY WORKFLOW:**

1. **File issues for remaining work** - Create issues for anything that needs follow-up
2. **Run quality gates** (if code changed) - Tests, linters, builds
3. **Update issue status** - Close finished work, update in-progress items
4. **PUSH TO REMOTE** - This is MANDATORY:
   ```bash
   git pull --rebase
   git push
   git status  # MUST show "up to date with origin"
   ```
   (No `bd dolt push` — bd runs in pure embedded mode with no Dolt
   remote. The local `.beads/embeddeddolt/` is the source of truth.)
5. **Clean up** - Clear stashes, prune remote branches
6. **Verify** - All changes committed AND pushed
7. **Hand off** - Provide context for next session

**CRITICAL RULES:**
- Work is NOT complete until `git push` succeeds
- NEVER stop before pushing - that leaves work stranded locally
- NEVER say "ready to push when you are" - YOU must push
- If push fails, resolve and retry until it succeeds
<!-- END BEADS INTEGRATION -->
