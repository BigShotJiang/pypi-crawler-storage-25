# Project Instructions for AI Agents

This file provides instructions and context for AI coding agents working on this project.

<!-- BEGIN BEADS INTEGRATION v:1 profile:minimal hash:ca08a54f -->
## Beads Issue Tracker

This project uses **bd (beads)** for issue tracking. Run `bd prime` to see full workflow context and commands.

### Quick Reference

```bash
bd ready              # Find available work
bd show <id>          # View issue details
bd update <id> --claim  # Claim work
bd close <id>         # Complete work
```

### Rules

- Use `bd` for ALL task tracking — do NOT use TodoWrite, TaskCreate, or markdown TODO lists
- Run `bd prime` for detailed command reference and session close protocol
- Use `bd remember` for persistent knowledge — do NOT use MEMORY.md files

## Session Completion

**When ending a work session**, you MUST complete ALL steps below. Work is NOT complete until `git push` succeeds.

**MANDATORY WORKFLOW:**

1. **File issues for remaining work** - Create issues for anything that needs follow-up
2. **Run quality gates** (if code changed) - Tests, linters, builds
3. **Update issue status** - Close finished work, update in-progress items
4. **PUSH TO REMOTE** - This is MANDATORY:
   ```bash
   git pull --rebase
   git push
   git status  # MUST show "up to date with origin"
   ```
   (No `bd dolt push` — bd is configured in pure embedded mode with no
   Dolt remote. The local `.beads/embeddeddolt/` is the source of truth.)
5. **Clean up** - Clear stashes, prune remote branches
6. **Verify** - All changes committed AND pushed
7. **Hand off** - Provide context for next session

**CRITICAL RULES:**
- Work is NOT complete until `git push` succeeds
- NEVER stop before pushing - that leaves work stranded locally
- NEVER say "ready to push when you are" - YOU must push
- If push fails, resolve and retry until it succeeds
<!-- END BEADS INTEGRATION -->


## Build & Test

```bash
uv sync                          # install deps + editable package
uv run pr-bot --help             # smoke test the pr-bot CLI
uv run toolbar --help            # smoke test the toolbar CLI
uv run pytest -q                 # 148 tests as of 0.2.0
uv run ruff check src tests      # lint
```

CI (`.github/workflows/ci.yml`) runs both on every PR with action SHAs
pinned via ratchet. Run them locally before opening a PR — the CI step
just re-validates.

## Architecture Overview

Two CLIs ship from the same wheel:

- **pr-bot** (`src/pr_bot/`) — operates *inside* a repo that follows the
  `main + release/X.Y + {feat,fix,hotfix}/<slug>` model. Command groups:
  `pr`, `release`, `hotfix`, `stack`, `policy`, plus `doctor` and `ui`.
- **toolbar** (`src/toolbar/`) — operates *around* a repo: `gh repo create`,
  scaffold-from-template, wiring the remote, pushing. One group: `repo`.

Shared primitives live in `src/pr_bot/`:

| module                | purpose                                                                 |
| --------------------- | ----------------------------------------------------------------------- |
| `pr_bot.sh`           | `subprocess.run` wrapper with uniform `pr-bot:` / `toolbar:` errors     |
| `pr_bot.git`          | git wrappers — every imperative git op the CLI needs                    |
| `pr_bot.gh`           | gh CLI wrappers (PR view/create/merge/edit, release create, branch protection) |
| `pr_bot.names`        | branch/tag/slug parsers + validators (pure, heavily unit-tested)        |
| `pr_bot.pyproject`    | `pyproject.toml` discovery + version reader                             |
| `pr_bot.changelog`    | concat `docs/releases/*.md` → `CHANGELOG.md`                            |
| `pr_bot.release_notes`| group merged-PR titles by conventional-commit prefix → markdown         |
| `pr_bot.policy`       | `.pr-bot.toml` loader + GitHub-branch-protection payload mapping        |
| `pr_bot.stack`        | `.git/pr-bot/stack.json` state + cross-link marker rendering            |
| `pr_bot.ui`           | Textual dashboard (`pr-bot ui`)                                         |
| `toolbar.env`         | resolves `GH_MIRROR` / `GH_ORG` / `GH_HOST` into a target repo          |
| `toolbar.template`    | render the python flavor under `templates/python/` for `repo template`  |

Command groups are plain Python modules that register a `cyclopts.App` and
get mounted under the top-level app in `cli.py`.

Slash commands live in `commands/*.md` at the repo root (the Claude Code
plugin's command source). `.claude/commands` is a symlink to `../commands`
so this repo's own Claude Code session loads them too — one source of
truth. Each command invokes the CLI via
`uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot <group> <subcommand> $ARGUMENTS`.
The CLI is the only source of truth; changing a subcommand's behavior
never requires editing its slash command twin.

The plugin manifest is `.claude-plugin/plugin.json` (and a sibling
`marketplace.json` so the repo itself acts as a one-plugin marketplace).

## Conventions & Patterns

- **Error prefixes.** Every user-visible error raised by pr-bot starts with
  `pr-bot:`; toolbar uses `toolbar:`. Callers (including agents) can regex
  for these.
- **No subprocess escapes.** Don't call `subprocess.run` directly — use
  `pr_bot.sh.run` so errors land in a uniform shape.
- **Every destructive op is echoed.** `pr_bot.git` functions pass `echo=True`
  on any write (checkout, push, tag, rebase) so the user sees what ran.
- **Cyclopts parameters.** Use `Annotated[T, Parameter(help="...")]` for
  every subcommand argument; defaults go on the right with `= None`.
- **Validation, not transformation.** `pr_bot.names` parses and validates;
  it does not reach out to git to check if a branch exists.
- **Tests.** 148 tests as of 0.2.0. Pure-logic modules (names, policy,
  stack, changelog, release_notes, pyproject, toolbar.env, toolbar.template)
  are unit-tested. `pr_bot.git` is integration-tested against a real git
  repo in `tmp_path`. Higher-level command modules (pr, release, hotfix,
  stack, ui) use the same `tmp_path` fixture plus a fake `gh` shim on
  `PATH` (`tests/conftest.py::fake_gh`).
- **Line length 120.** Configured in `pyproject.toml`; `ruff` enforces.
- **Python 3.14 floor.** `requires-python = ">=3.14"` — we're not backporting.

## PR Lifecycle (dogfood)

This repo follows its own model. For every change except the initial scaffold:

```bash
pr-bot pr start feat <slug>      # start the branch
# ...edit, commit...
pr-bot pr open --draft           # push + open PR
pr-bot pr sync                   # keep up with main
pr-bot pr ready
pr-bot pr merge                  # squash, delete branch, FF main
```

If a change is small enough to be one commit, that's fine — `pr merge`
squashes into one commit on main regardless.
