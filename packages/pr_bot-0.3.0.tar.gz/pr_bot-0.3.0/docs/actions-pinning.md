# GitHub Actions pinning (ratchet + actionlint)

Every `uses:` reference in `.github/workflows/*.yml` is pinned to a full
40-character SHA with the human-readable version tag as a comment:

```yaml
- uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd # ratchet:actions/checkout@v6
```

## Why

Floating tags (`@v6`, `@main`) let the action's maintainer — or anyone
with write access to their repo — change what code runs in this repo's
CI without us noticing. A SHA pin freezes exactly one tree.

## Dev-only tools

Both tools are developer-side. CI doesn't install them — unpinned
workflows will just silently work on GitHub's runners; the tools catch
drift locally before a PR lands.

Install:

```bash
brew install ratchet actionlint
```

Check pins and workflow syntax before opening a PR:

```bash
ratchet lint .github/workflows/*.yml
actionlint
```

## Upgrading an action

```bash
# 1. Edit the workflow — bump the tag comment, leave the SHA as-is:
#    - uses: actions/checkout@de0fac2e... # ratchet:actions/checkout@v7
# 2. Re-pin:
ratchet update .github/workflows/*.yml
# 3. Commit, open PR, merge via the normal pr-bot flow.
```

`ratchet update` resolves every tag comment to its current SHA and
rewrites the file in place.
