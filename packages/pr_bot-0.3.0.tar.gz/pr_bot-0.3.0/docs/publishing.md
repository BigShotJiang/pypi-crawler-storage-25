# Publishing to PyPI

`pr-bot` uses a [PyPI Trusted Publisher](https://docs.pypi.org/trusted-publishers/)
for OIDC-based releases from GitHub Actions — no API tokens stored in
repo secrets.

## One-time setup (human action required)

The Trusted Publisher has to be registered on PyPI before the first
publish. This is a one-time, out-of-band step:

1. **Claim the name on PyPI.** Go to https://pypi.org/manage/account/publishing/
   and add a *pending* publisher with:

   | field               | value                       |
   | ------------------- | --------------------------- |
   | PyPI project name   | `pr-bot`                    |
   | owner               | `andrewrothstein`           |
   | repository          | `pr-bot`                    |
   | workflow filename   | `publish.yml`               |
   | environment name    | `pypi`                      |

   "Pending" is correct — the project doesn't exist on PyPI yet. It will be
   created on first successful publish.

2. **Create the `pypi` environment in the GitHub repo.**
   Repo → Settings → Environments → New environment → `pypi`. Restrict
   deployments to tag pushes matching `[0-9]+.[0-9]+.[0-9]+` (same pattern
   the workflow uses).

3. **Verify**: push a test tag on a branch (or delete a prior tag and
   re-push) to trigger `publish.yml`. The `publish` job should log
   "OIDC token issued" and upload the wheel + sdist.

## What the workflow does

`.github/workflows/publish.yml` triggers on any tag matching
`X.Y.Z` (no `v` prefix — matches the pr-bot release convention).

Two jobs:

1. **build** — `uv build` in a clean runner; uploads `dist/` as an
   artifact.
2. **publish** — downloads the artifact, uses
   `pypa/gh-action-pypi-publish` with OIDC (`id-token: write`).
   Scoped to the `pypi` environment so branch protection + environment
   reviewers can gate releases.

## Day-to-day release

```bash
pr-bot release cut X.Y             # if the line doesn't exist
pr-bot release tag X.Y.Z \
  --notes "$(cat docs/releases/X.Y.Z.md)"
# The tag push fires publish.yml. Check Actions for the run.
```

## Name conflicts

If `pr-bot` is already taken on PyPI when this repo goes public, the
fallback is `prbot` or a scoped name. Update `pyproject.toml`'s
`[project] name` and the PyPI Trusted Publisher registration's project
name. The CLI entry points (`pr-bot`, `toolbar`) do not depend on the
package name.
