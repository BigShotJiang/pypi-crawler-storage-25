# pr-bot ui

A Textual terminal dashboard for the repo you're in. Live branches, the
active stack, release lines, the selected PR's body, and its CI checks
— all on one screen, with hotkeys that map to the existing CLI.

## Launch

From inside any pr-bot-shaped repo:

```bash
pr-bot ui
# or, hermetically:
uvx --from "${PR_BOT_SOURCE:-pr-bot}" pr-bot ui
```

`q` quits. `?` shows the hotkey cheat sheet in a notification.

## Layout

```
┌─ pr-bot ─────────────────────────────────────────────────────────────┐
│ branches                  │ pr detail — feat/auth-tokens             │
│ → main                     │ #42 OPEN  fix the thing                  │
│   feat/auth-tokens         │ feat/auth-tokens → main                  │
│   feat/auth-mw             │ https://github.com/.../pull/42           │
│   release/0.2              │                                          │
│                            │ ## Summary                                │
│ stack                      │ …                                         │
│   auth (3 branches)        │                                          │
│     1/3 feat/auth-tokens   │                                          │
│     2/3 feat/auth-mw       │                                          │
│     3/3 feat/auth-routes   │                                          │
│                            │                                          │
│ releases                   │                                          │
│   release/0.1   v0.1.5     │                                          │
│   release/0.2   v0.2.0     │                                          │
├─ checks ───────────────────┴──────────────────────────────────────────┤
│ ✓ pass    test    https://github.com/.../actions/runs/123             │
└──────────────────────────────────────────────────────────────────────┘
```

Five panes:

| pane     | source                                              |
| -------- | --------------------------------------------------- |
| branches | `git for-each-ref refs/heads/`                      |
| stack    | `.git/pr-bot/stack.json` (set by `pr-bot stack new`) |
| releases | `git for-each-ref refs/heads/release/*` + `git tag` |
| detail   | `gh pr view <branch>` for PR branches; else `git log -1` |
| checks   | `gh pr checks <branch>` for the selected branch     |

## Hotkeys

| key | action                                                        |
| --- | ------------------------------------------------------------- |
| ↑/↓ | move selection in the branches pane                           |
| `s` | `pr-bot pr sync` on the selected branch                       |
| `r` | `pr-bot pr ready`                                             |
| `m` | `pr-bot pr merge`                                             |
| `c` | `pr-bot pr cleanup`                                           |
| `o` | open the PR URL in a browser (`webbrowser.open`)              |
| `g` | force refresh                                                 |
| `?` | show this cheat sheet                                         |
| `q` | quit                                                          |

Every PR-action hotkey:

1. checks the selection is a `feat/`, `fix/`, or `hotfix/` branch (else a notification, no-op);
2. `git checkout`s that branch;
3. shells out to `pr-bot pr <verb>`;
4. on success, refreshes the panes;
5. on failure, surfaces the first error line in a red notification.

## Refresh model

Pulled, not pushed: there's no live event stream from GitHub. Press `g`
(or perform a hotkey that succeeds) to refetch. Future work could add a
periodic tick — see the open questions in `docs/design-tui.md`.

## Headless / SSH boxes

`o` falls back to a notification with the URL when there's no
`$DISPLAY` and no `$BROWSER` set, instead of crashing on a missing
xdg-open. Everything else is pure terminal — works fine over SSH.

## Out of scope (for now)

- Editing PR bodies inline (drop to `gh pr edit` or your browser).
- Multi-repo dashboard.
- Composing commits / interactive rebase.

If you need richer functionality, the CLI and slash commands are still
there — the TUI is a viewing layer, not a replacement.

## Design

Full design + implementation slices: [`docs/design-tui.md`](design-tui.md).
