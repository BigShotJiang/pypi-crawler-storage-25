# Branch protection policy

`pr-bot policy apply` writes the rules in your `.pr-bot.toml` to GitHub
so the PR-bot model is enforced server-side, not just by convention.

## What's enforced

```toml
[policy]
linear_history = true
allow_force_push = false
allow_deletions = false
required_status_checks = ["test"]
required_approving_review_count = 0
require_conversation_resolution = false
enforce_admins = false
protected_branches = ["main"]
```

Each key maps directly to a field in the
[branch-protection PUT body](https://docs.github.com/en/rest/branches/branch-protection#update-branch-protection).

`pr-bot policy check` reads GitHub's actual config and diffs against
the file. `pr-bot doctor` rolls the diff into the standard health
report.

## What this uses, and the limitation

`pr-bot policy` v1 uses the **classic branch-protection REST API**
(`PUT /repos/{owner}/{repo}/branches/{branch}/protection`).

This is the older of GitHub's two branch-protection systems. The newer
one — **[rulesets](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets)** —
supports glob patterns (`release/*`), layered org+repo rules, and
phased rollouts. GitHub continues to support classic protection
indefinitely; rulesets are recommended for new setups, especially in
orgs.

What this means in practice:

- **Solo repo, single protected branch (typical pr-bot use):** classic
  is fine and `policy apply` works as documented.
- **Want to protect every `release/*` branch with one rule:** classic
  can't. You'd have to list every release branch in
  `protected_branches`. Rulesets handle this natively.
- **Rulesets-only repo (rare, but possible if your org is migrating):**
  `policy apply` still writes classic protection, which coexists with
  rulesets but is invisible in the rulesets UI. Confusing — but not
  broken.

A future version of `pr-bot policy` may grow a rulesets backend (see
the open bd issue for that). Until then, this limitation is
intentional.

## When you don't want pr-bot to manage protection

Don't run `pr-bot policy apply`. The `.pr-bot.toml` file is still used
by `pr-bot doctor` to advise; the actual server state stays whatever
your org / GitHub UI / Terraform / etc. set it to.

## Recipes

### Solo repo: protect main

```toml
[policy]
linear_history = true
allow_force_push = false
allow_deletions = false
required_status_checks = ["test"]
required_approving_review_count = 0
protected_branches = ["main"]
```

```bash
pr-bot policy apply
```

### Multiple release lines

Classic protection requires explicit branch names. List them:

```toml
[policy]
required_status_checks = ["test"]
protected_branches = ["main", "release/0.1", "release/0.2"]
```

Add new lines as you cut them. (Or wait for the rulesets backend, when
you'll be able to write `release/*`.)

### Team repo with required reviewer

```toml
[policy]
required_approving_review_count = 1
required_status_checks = ["test", "lint"]
protected_branches = ["main"]
```
