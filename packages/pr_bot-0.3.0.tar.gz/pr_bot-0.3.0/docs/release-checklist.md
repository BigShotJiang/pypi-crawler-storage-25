# Release-day checklist

The CLI is unit/integration tested against a fake `gh` shim — that
validates argv shape, not the live GitHub API surface. If gh changes
the JSON it emits or the syntax of `pr list --search merged:>=`, our
tests will stay green and a release would silently break in users'
hands.

This checklist runs the CLI's gh-touching paths against the real `gh`
before tagging.

## Before tagging X.Y.Z

Run from inside any repo where you have `gh auth status` and at least
one merged PR. The pr-bot repo itself works.

```bash
# 1. CI is green on the release branch.
gh run list --workflow=ci.yml --branch=release/X.Y --limit=1
#   → conclusion should be 'success'

# 2. release notes auto-draft works against the live gh API.
pr-bot release notes-draft X.Y.Z --print --since <prev-tag>
#   → body groups PR titles by conventional-commit prefix.
#   → if it dies on a JSON-parse error or returns empty when there
#     are real merged PRs, gh's surface changed — investigate before
#     tagging.

# 3. policy check works (if .pr-bot.toml exists).
pr-bot policy check
#   → exits 0 (match) or 1 (drift). Anything else = bug.

# 4. doctor is clean.
pr-bot doctor
#   → 0 problems. Warnings are fine; problems are blocking.

# 5. release list reflects expected state.
pr-bot release list
#   → release/X.Y shown, latest tag is the one BEFORE X.Y.Z.
```

## During the release

```bash
pr-bot release prepare X.Y.Z       # bumps pyproject + drafts notes + commits
pr-bot release tag X.Y.Z --notes-file docs/releases/X.Y.Z.md
```

The `release tag` push fires `.github/workflows/publish.yml`. Watch it:

```bash
gh run watch "$(gh run list --workflow=publish.yml --limit=1 --json databaseId --jq '.[0].databaseId')"
```

## After tagging

```bash
# 6. PyPI has the new version.
curl -sSf https://pypi.org/pypi/pr-bot/X.Y.Z/json | grep '"version"'

# 7. uvx fetches it.
uvx --no-cache --from pr-bot==X.Y.Z pr-bot --version
#   → prints X.Y.Z. (NOT the previous version — we got bitten by this
#     in 0.1.1 / 0.1.2 / 0.1.3 because pyproject's version was stale.)

# 8. GitHub release page exists.
gh release view X.Y.Z
```

## If anything looks off

Don't yank from PyPI — once a version is published it's permanent.
Cut X.Y.(Z+1) with the fix instead. Document the broken release in the
new version's notes.

## Future automation

When we ship `pr-bot release notes-draft` in CI (gated on `GH_TOKEN` so
it can run on PR branches), most of steps 2-5 can move to a
GitHub Actions check that fails the PR before merge rather than living
here as a manual checklist. Tracked at `pr-bot-v89` follow-up TBD.
