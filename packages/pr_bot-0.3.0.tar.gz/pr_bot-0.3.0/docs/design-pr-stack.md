# Design: stacked PRs

> Status: design sketch (not implemented). Tracking issue: `pr-bot-avj`.

## Problem

Large changes are easier to review when split into a chain of dependent
PRs that get reviewed and landed in order. GitHub doesn't model stacks
natively (each PR is independent); existing tools (`spr`, `git-stack`,
`gh-stack`) all impose their own conventions. pr-bot already owns the
opinion about branch shape, so the stack abstraction can ride on top.

## Mental model

A **stack** is an ordered list of PR branches:

```
main
 └─ feat/slug-1   ← PR #N+0, base: main
     └─ feat/slug-2   ← PR #N+1, base: feat/slug-1
         └─ feat/slug-3   ← PR #N+2, base: feat/slug-2
```

Each branch is rebased on its parent. Stack lands bottom-up: when
`slug-1` squash-merges, `slug-2` rebases onto the new `main`, and so on.

## State

A small state file tracks the stack so commands can locate parent /
children without inspecting every branch in the repo:

```
.git/pr-bot/stack.json
{
  "name": "auth-rework",
  "branches": ["feat/auth-tokens", "feat/auth-middleware", "feat/auth-routes"],
  "created_at": "2026-04-25T..."
}
```

Lives in `.git/`, not the working tree — per-clone, never committed.

## Commands

### `pr-bot stack new <slug-1> <slug-2> [slug-3 ...]`
- Validate slugs (reuse `pr_bot.names`).
- `pr start` semantics for the first: branch off main.
- For each subsequent: branch off the previous one.
- Write state file.
- Leave the user on the *first* branch.

### `pr-bot stack push [--draft]`
- For each branch in order:
  - Push (or force-push-with-lease if it already exists remotely).
  - `gh pr create` with the right base. PR body includes `Stack: 1/N` /
    `2/N` markers and links to neighbors.
  - All but the bottom-most are drafted by default.

### `pr-bot stack sync`
- Fetch.
- Rebase the bottom branch onto `origin/main`.
- For each subsequent branch, rebase onto the *new HEAD of the previous
  branch* (not the original parent).
- Force-push-with-lease all of them.
- Reuse the existing `pr_bot.git.rebase_try` + `rebase_in_progress` for
  conflict UX; abort early on the first conflict.

### `pr-bot stack land`
- Find the bottom branch.
- Squash-merge it via `gh pr merge` (existing `pr-bot pr merge` logic).
- After it lands: pop from the state file, sync the rest of the stack
  onto the new main, mark the next-bottom PR ready (un-draft).
- Repeat or stop after one — both modes useful (`--all` flag).

### `pr-bot stack status`
- Print the chain with each branch's PR number, draft state, ahead/behind
  vs its parent, CI status.

### `pr-bot stack abandon`
- Delete state file. Branches and remote PRs are left intact for the
  user to clean up via `pr-bot pr cleanup`.

## Open questions / tradeoffs

- **Mid-stack edits.** If the user edits a middle branch and adds a
  commit, `stack sync` rebases everything above it. That's the right
  default but worth flagging in the UX.
- **PR descriptions.** Auto-injected `Stack: i/N` block needs to be
  re-rendered on `stack push` as positions shift. Idempotent rewrite
  (find a marker, replace; otherwise append).
- **Conflicts during rebase chain.** Stop at the first conflict, surface
  exactly which branch in the chain is in-progress, leave it to the user
  (matches our `pr sync` philosophy).
- **Slash commands.** One per subcommand (`/stack-new`, `/stack-push`,
  `/stack-sync`, `/stack-land`, `/stack-status`, `/stack-abandon`).

## Implementation order

1. State file + `stack new` (smallest, gets the data structure right).
2. `stack push` (PR creation with linkage).
3. `stack sync` (the meat — rebase chain + conflict handling).
4. `stack land` (relies on `pr merge` internals already shipped).
5. `stack status` and `stack abandon` (read-only / cleanup).

Each step its own PR; ~5 PRs total.
