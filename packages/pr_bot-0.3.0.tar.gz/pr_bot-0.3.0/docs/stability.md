# pr-bot stability commitment

What we promise not to break across the **1.x** line, and what we
explicitly reserve the right to change.

> Pre-1.0 (the 0.x line), nothing in this document is binding — every
> 0.y release was free to break anything. From the 1.0.0 tag forward,
> this is the contract.

## Stable surfaces (won't change without a major version bump)

### CLI subcommands and flags

The following subcommand names, positional arguments, and flag names
are stable. Their *behavior* may evolve (e.g. faster, better defaults),
but invocations that work today keep working.

| group     | stable verbs                                                       |
| --------- | ------------------------------------------------------------------ |
| `pr`      | `start`, `open`, `sync`, `ready`, `merge`, `cleanup`, `status`     |
| `release` | `cut`, `prepare`, `tag`, `notes-draft`, `changelog`, `list`, `next-patch` |
| `hotfix`  | `start`, `open`, `forward-port`                                    |
| `stack`   | `new`, `push`, `sync`, `land`, `status`, `abandon`                 |
| `policy`  | `apply`, `check`                                                   |
|           | `doctor`, `ui`                                                     |

For `toolbar`:

| group | stable verbs                              |
| ----- | ----------------------------------------- |
| `repo`| `info`, `create`, `template`, `push-main` |

Flags marked stable retain their long names. Short flags are not part
of the contract — `-t` may be replaced.

### Slash commands

Every CLI subcommand has a slash twin. The slash command names —
`/pr-start`, `/release-prepare`, `/stack-new`, `/policy-apply`,
`/toolbar-repo-template`, etc. — are stable.

### Branch and tag conventions

- Branch shape: `feat/<slug>`, `fix/<slug>`, `hotfix/<slug>`,
  `release/X.Y`. The `<slug>` regex (`[a-z0-9][a-z0-9\-]{0,63}`) is
  stable.
- Tag shape: `X.Y.Z` (semver, no `v` prefix), annotated, on
  `release/X.Y`.

### File formats

- **`.pr-bot.toml`** — the keys under `[policy]` documented in the
  default file (linear_history, allow_force_push, allow_deletions,
  required_status_checks, required_approving_review_count,
  require_conversation_resolution, enforce_admins, protected_branches)
  are stable. New keys may be added with safe defaults.
- **`.git/pr-bot/stack.json`** — `name`, `branches`, `created_at` are
  stable. The file is local-only (per-clone, gitignored), so format
  bumps are safe with a documented migration.
- **`docs/releases/X.Y.Z.md`** — directory layout is stable. `pr-bot
  release notes-draft` produces a specific shape; consumers shouldn't
  rely on exact section headings beyond the `# pr-bot X.Y.Z` line.
- **`CHANGELOG.md`** — generated from `docs/releases/*.md`. Hand-edits
  are overwritten on `release prepare`.

### Importable Python API (`pr_bot.*`)

The following modules are public and follow semver:

- `pr_bot.names` — branch/tag/slug parsers and validators.
- `pr_bot.git` — git wrappers used by the CLI.
- `pr_bot.gh` — gh CLI wrappers.
- `pr_bot.policy` — Policy dataclass, load/to_payload/diff.
- `pr_bot.stack` — Stack dataclass, load/save/clear, render_marker.
- `pr_bot.changelog` — generate, render, collect_release_files.
- `pr_bot.release_notes` — Item, classify, render, draft.
- `pr_bot.pyproject` — find_pyproject, read_version.

Function names, argument names, and documented return types in those
modules don't change in a 1.x release without a deprecation cycle.

### Exit codes

- `0` — success
- `1` — runtime failure (bad invocation, repo state, gh error, etc.)
- `2` — programmer error / never-should-happen

These won't change.

## Explicitly experimental (no stability guarantee)

- The `pr-bot ui` Textual layout — pane sizes, hotkeys, what's shown.
  Hotkey *bindings* (s/r/m/c/o/g/q/?) are stable; everything else is
  free to evolve.
- The `commands/*.md` *bodies* — only the slash command name is part
  of the contract; the markdown body, frontmatter, and exact CLI
  invocation pattern (`uvx --from "${PR_BOT_SOURCE:-pr-bot}" ...`) are
  implementation details.
- `pr_bot.sh` — internal subprocess helper. May change shape.
- `pr_bot.commands.*` — internal modules; the CLI (above) is the
  public surface, not these.
- `toolbar.template` — the renderer. The default `python` flavor's
  *contents* are not stable (pinned action SHAs and the like update
  out from under you). The shape (`pyproject.toml`, `LICENSE`,
  `CLAUDE.md`, `AGENTS.md`, `.github/workflows/ci.yml`, etc.) is.

## Deprecation policy

When we plan to remove or rename a stable surface:

1. The replacement ships in a 1.x release alongside the old name.
2. The old name keeps working but emits a deprecation warning to
   stderr.
3. Removal happens in 2.0.

We don't promise a specific minimum window between (1) and (3) — but
nothing flagged stable here gets removed silently.
