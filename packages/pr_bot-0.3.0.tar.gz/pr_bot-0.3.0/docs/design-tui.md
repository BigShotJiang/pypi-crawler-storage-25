# Design: pr-bot ui (Textual TUI)

> Status: design sketch (not implemented). Tracking issue: `pr-bot-2uw`.

## Goal

A live terminal dashboard you leave open in a split. Branches, PRs, CI,
release lines all visible at a glance; hotkeys map to subcommands so you
rarely type `pr-bot foo` again.

Slash commands and the CLI stay — the TUI is a *human-facing layer over
them*, not a replacement. Agents continue to use the CLI directly.

## Layout

```
┌─ pr-bot — andrewrothstein/pr-bot ────────────────────────────────────┐
│ branches                       │ pr #29  feat(stack): land + status  │
│ → main                          │ MERGEABLE  base: main                │
│   feat/auth-tokens   ⏳ 2/3     │ ahead 0  behind 0                    │
│   feat/auth-mw       ⏳ 2/3     │                                       │
│   feat/auth-routes   ⏳ 2/3     │ ## Summary                            │
│ release/0.1                     │ Final slice of stacked-PR feature.    │
│ release/0.2 ← v0.2.0           │                                       │
│                                 │ ## Test plan                          │
│ stacks                          │ - [x] CI green                        │
│   auth (3 branches)             │ - [x] 132 → 136 passing               │
│                                 │                                       │
├─ checks ────────────────────────┴───────────────────────────────────┤
│ ✓ test       success    11s    https://...                            │
└──────────────────────────────────────────────────────────────────────┘
hotkeys: s sync · r ready · m merge · c cleanup · g status · q quit
```

Three regions:

1. **Left pane**: tree of *branches* and *stacks*. Highlight = current.
2. **Right pane**: detail for the selection — PR title, state, body
   (rendered Markdown).
3. **Bottom strip**: CI checks for the selected branch (status, name, URL).

## Data sources

- Branch list: `git for-each-ref refs/heads/` (we have `git.list_branches`).
- Per-branch PR detail: `gh.pr_view(<branch>)`.
- CI checks: `gh pr checks <branch> --json`.
- Stacks: `pr_bot.stack.load()`.
- Releases: `pr_bot.git.list_tags()` + `release_list` logic.

Refresh on a 5s tick by default; nudge faster after a hotkey action.

## Hotkeys

Map common actions to single keys (leader: none for now):

| key | action                                          |
|-----|-------------------------------------------------|
| `s` | `pr-bot pr sync` (current branch)               |
| `r` | `pr-bot pr ready`                               |
| `m` | `pr-bot pr merge`                               |
| `c` | `pr-bot pr cleanup`                             |
| `o` | open PR URL in browser                          |
| `g` | force refresh (no waiting on tick)              |
| `?` | help screen with all hotkeys                    |
| `q` | quit                                            |
| `S` | (capital) stack-aware actions: `stack sync` etc.|

Hotkeys shell out to the existing CLI subprocess. After completion, the
TUI re-fetches the relevant data. No reimplementation; if the CLI errors,
the error message lands in a status bar.

## Tech

- **Textual** (`textual>=0.80`). Rich already a transitive via cyclopts.
- One `App` subclass with three `Container` regions and a `Footer`.
- Async event loop; gh / git calls run in threads via `App.run_worker`.

## Implementation order (1 PR per step)

1. **Skeleton.** Non-interactive layout with stub data, just to nail the
   panes/Footer + textual setup. Add `pr-bot ui` subcommand. Run; quit
   with `q`.
2. **Branch list + selection.** Live data from `git.list_branches`. Move
   highlight up/down; right pane shows `git log -1 <branch>`.
3. **PR detail.** When the selection is a PR branch, fetch `gh pr view`
   and render the body. Cache between ticks.
4. **CI strip.** `gh pr checks` on selection.
5. **Hotkeys.** Wire `s`, `r`, `m`, `c`, `o`. Each shells out to
   `pr-bot pr <verb>` via subprocess; on success refresh the affected
   branch.
6. **Stack pane.** Surface the active stack from `pr_bot.stack.load()`.
   `S` keys: `stack-sync`, `stack-land`.
7. **Release pane.** List release branches + highest tags.

## Tradeoffs / out of scope

- **No editor integration.** Don't try to be lazygit. Editing a PR body,
  composing a message, etc. — out of scope; the user still drops to
  their shell or browser for that.
- **Polling, not webhooks.** No push from GitHub; just `gh` polling on
  a tick. Cheap, mostly.
- **No multi-repo dashboard yet.** Single repo only — the working dir is
  the repo. A multi-repo overview is interesting future work
  (would pair with a hypothetical `toolbar repos sync`).

## Open questions

- Does Textual play nicely with `gh` CLI's interactive auth prompts? If
  the user's `gh` token expires mid-session, what happens? Probably
  surfaces as a one-liner error in the footer; the user re-auths in
  another terminal.
- Where does the TUI run when invoked through `uvx`? `uvx pr-bot ui`
  inside an isolated cache should work — Textual is just a terminal app.
