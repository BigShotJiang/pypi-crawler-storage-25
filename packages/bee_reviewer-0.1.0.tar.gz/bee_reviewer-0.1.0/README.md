# Bee Reviewer 🐝

Bee Reviewer is a Python CLI tool that generates **narrated, interactive code reviews**. It uses a "Context-Aware" architecture where your AI agent (Claude, Gemini, etc.) directly generates review recipes as it works, ensuring the narration captures the full intent and design decisions of every task.

## 🌟 Features

- **Context-Aware**: Review recipes are generated *inside* the AI session, capturing planning and reasoning that raw git diffs often miss.
- **Narrated Presentation**: A cinematic web-based slideshow where your code is explained via high-quality text-to-speech.
- **Turnkey Viewer**: A self-contained web viewer with syntax highlighting, auto-play narration, and full playback controls.
- **Cross-Agent Support**: Works with Gemini CLI, Claude Code, Aider, and any other AI agent via `BEE-REVIEWER.md`.
- **Zero Token Overhead**: No secondary AI calls required for reviews.

## 🚀 Installation

Install via pip:

```bash
pip install bee-reviewer
```

## 🛠️ Getting Started

### 1. Initialize your project
Run this command in the root of your project:

```bash
bee-reviewer init
```

This will:
- Print the Bee Reviewer banner.
- Create a `.bee-review/` directory to store your reviews.
- Detect your agent (`CLAUDE.md`, `GEMINI.md`) or create a fallback `BEE-REVIEWER.md`.
- Inject instructions telling the AI to generate a `recipe.json` in `.bee-review/` after every completed task.

### 2. Work with your AI Agent
Continue working with your AI agent as usual. After every human prompt you provide, the agent will silently create a new review file in the `.bee-review/` folder.

### 3. Launch a Review
When you're ready to watch your progress:

```bash
bee-reviewer review
```

- Select a review from the chronological menu.
- A local web server starts, and your browser opens to a narrated slideshow of your changes!

## 📖 Manual Usage & Advanced Tips

### Custom Agent Launch
You can initialize and immediately launch your AI agent in one command:
```bash
bee-reviewer init --launch gemini
```

### 💡 Pro Tips for Better Reviews

- **Baseline Commits**: For the best review experience, run `git commit -m "baseline"` before starting a major task. This gives the AI a clean reference point for its narration.
- **Large File Handling**: The AI instructions include a **1,000-line limit** per file. If a file is larger, the AI is instructed to include only the most relevant 1,000 lines to keep your sessions fast and lightweight.
- **Recipe Management**: All review recipes are stored as JSON files in the `.bee-review/` directory. You can safely delete old files you no longer need, or share specific `.json` files with teammates.
- **Shell Completion**: `bee-reviewer` supports tab-completion. To enable it for your shell, run:
  ```bash
  bee-reviewer --install-completion
  ```

## 🛑 Stopping the Server
Press **Ctrl+C** in your terminal to stop the review server. This safely returns you to your shell.

## 📄 License
MIT
