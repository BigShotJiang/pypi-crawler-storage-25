import os
import json
import webbrowser
import http.server
import socketserver
import threading
import typer
import time
from pathlib import Path

# Global to store the currently selected recipe file path
SELECTED_RECIPE_PATH = None

class ViewerHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Disable caching to ensure fresh recipes are always loaded
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def translate_path(self, path):
        # Dynamically serve the selected recipe file when /recipe.json is requested
        if path == "/recipe.json":
            return str(SELECTED_RECIPE_PATH)
        
        # Serve index.html from package
        if path == "/" or path == "/index.html":
            try:
                # Resolve the path to the bundled index.html
                # We use the package directory as a base
                pkg_dir = Path(__file__).parent.parent
                viewer_html = pkg_dir / "viewer" / "index.html"
                if viewer_html.exists():
                    return str(viewer_html)
            except:
                pass
            
        return super().translate_path(path)

def run_review():
    global SELECTED_RECIPE_PATH
    
    review_dir = Path(".bee-review")
    if not review_dir.exists() or not review_dir.is_dir():
        typer.secho("Error: .bee-review directory not found. Run 'bee-reviewer init' first.", fg=typer.colors.RED)
        raise typer.Exit(1)

    # 1. Find all recipe files
    recipes = list(review_dir.glob("*.json"))
    if not recipes:
        typer.secho("Error: No recipe files found in .bee-review/. Ensure your AI agent has generated them.", fg=typer.colors.RED)
        raise typer.Exit(1)

    # Sort recipes by filename (timestamp) descending
    recipes.sort(key=lambda x: x.name, reverse=True)

    # 2. Display selection menu
    typer.echo("Select a review to play:")
    for i, recipe_path in enumerate(recipes):
        # Format name for display: 20260510_154500_auth_setup.json
        parts = recipe_path.stem.split('_')
        if len(parts) >= 2:
            ts = parts[0]
            tm = parts[1]
            summary = " ".join(parts[2:])
            display_name = f"[{ts} {tm[:2]}:{tm[2:4]}] {summary}"
        else:
            display_name = recipe_path.name
            
        typer.echo(f"{i+1}. {display_name}")

    selection = typer.prompt("Select entry number", default="1")
    try:
        idx = int(selection) - 1
        if idx < 0 or idx >= len(recipes):
            typer.secho("Invalid selection.", fg=typer.colors.RED)
            raise typer.Exit(1)
        SELECTED_RECIPE_PATH = recipes[idx]
        typer.secho(f"Serving: {SELECTED_RECIPE_PATH.name}", fg=typer.colors.YELLOW)
    except ValueError:
        typer.secho("Invalid input.", fg=typer.colors.RED)
        raise typer.Exit(1)

    # 3. Start server
    start_viewer_server()

def start_viewer_server():
    PORT = 8000
    socketserver.TCPServer.allow_reuse_address = True
    
    # Find next available port
    while True:
        try:
            httpd = socketserver.TCPServer(("", PORT), ViewerHandler)
            break
        except OSError:
            PORT += 1
            if PORT > 8010:
                typer.secho("Error: Could not find an available port.", fg=typer.colors.RED)
                return

    typer.secho(f"Server started at http://localhost:{PORT}", fg=typer.colors.CYAN)
    typer.echo("Press Ctrl+C to stop the server.")
    
    # Run server in a daemon thread so it dies when the main thread exits
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()
    
    # Open browser
    threading.Thread(target=lambda: webbrowser.open(f"http://localhost:{PORT}"), daemon=True).start()
    
    try:
        # Keep main thread alive to catch Ctrl+C
        while True:
            time.sleep(0.5)
    except KeyboardInterrupt:
        # On Windows, simply returning here allows the daemon threads 
        # to be killed by the OS, preventing the hang.
        typer.secho("\nStopping server...", fg=typer.colors.YELLOW)
        return
