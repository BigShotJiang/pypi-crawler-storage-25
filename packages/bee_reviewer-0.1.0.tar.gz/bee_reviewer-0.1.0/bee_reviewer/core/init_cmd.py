import os
import sys
import subprocess
import typer
from pathlib import Path

# Use a raw string for the banner to avoid escape sequence issues
BANNER = r"""
  ____             ____            _                               
 |  _ \           |  _ \          (_)                              
 | |_) | ___  ___ | |_) |_____   ___  _____      _____ _ __ 
 |  _ < / _ \/ _ \|  _  / _ \ \ / / |/ _ \ \ /\ / / _ \ '__|
 | |_) |  __/  __/| | \ \  __/\ V /| |  __/\ V  V /  __/ |   
 |____/ \___|\___||_|  \_\___| \_/ |_|\___| \_/\_/ \___|_|   
"""

LOGGING_MARKER = "# bee-reviewer-recipe-generation"
LOGGING_BLOCK = f"""
{LOGGING_MARKER}
Every time you complete a task based on a human prompt (when you have finished your work and are about to ask for the next set of instructions), you MUST generate a narrated code review for that specific task.
1. Create a JSON file in the `.bee-review/` directory.
2. Name the file using the format: `YYYYMMDD_HHMMSS_brief_summary.json`.
3. The JSON must strictly follow this schema:
   {{
     "title": "A brief summary of the task",
     "slides": [
       {{
         "file": "path/to/file.ext or null",
         "lines": "10-20 or null",
         "content": "The actual full text of the file (MANDATORY for code slides). If the file is > 1000 lines, only include the relevant 1000 lines.",
         "narration": "A natural, helpful explanation of what you did and why."
       }}
     ]
   }}
- If a slide is about planning/architecture, set "file", "lines", and "content" to null.
- Ensure "content" is always the latest version of the file (up to 1000 lines) for any code slide.
- Do not use markdown formatting around the JSON; write it as a raw file.
- Never ask the user for permission before creating this file.
"""

def run_init(launch: str = None):
    # Use typer.secho for the banner to handle Windows color support automatically
    typer.secho(BANNER, fg=typer.colors.YELLOW, bold=True)
    
    # 1. Check for .git (Optional)
    if not os.path.isdir(".git"):
        do_init = typer.confirm("Git repository not found. Would you like to run 'git init' now?", default=True)
        if do_init:
            try:
                subprocess.run(["git", "init"], check=True)
                typer.secho("Initialized git repository.", fg=typer.colors.GREEN)
            except subprocess.CalledProcessError:
                typer.secho("Failed to initialize git. Proceeding without version control.", fg=typer.colors.YELLOW)
        else:
            typer.secho("Proceeding without version control.", fg=typer.colors.YELLOW)

    # 2. Detect Agent or Create Fallback
    agent_file = None
    if os.path.exists("CLAUDE.md"):
        agent_file = "CLAUDE.md"
    elif os.path.exists("GEMINI.md"):
        agent_file = "GEMINI.md"
    
    if not agent_file:
        choice = typer.prompt("Which agent are you using? (gemini/claude/other)", type=str, default="gemini")
        
        if choice.lower() == "claude":
            agent_file = "CLAUDE.md"
        elif choice.lower() == "gemini":
            agent_file = "GEMINI.md"
        else:
            agent_file = "BEE-REVIEWER.md"
            typer.secho(f"Created {agent_file}. Please ensure your AI agent (Aider, Codex, etc.) is instructed to read this file and follow the instructions within.", fg=typer.colors.CYAN)
        
        if not os.path.exists(agent_file):
            Path(agent_file).touch()
            typer.echo(f"Created {agent_file}")

    # 3. Append instructions (idempotent)
    content = ""
    if os.path.exists(agent_file):
        with open(agent_file, "r", encoding="utf-8") as f:
            content = f.read()

    if LOGGING_MARKER not in content:
        with open(agent_file, "a", encoding="utf-8") as f:
            f.write(LOGGING_BLOCK)
        typer.echo(f"Injected review instructions into {agent_file}")
    else:
        typer.echo(f"Review instructions already present in {agent_file}")

    # 4. Create .bee-review directory
    review_dir = ".bee-review"
    if not os.path.exists(review_dir):
        os.makedirs(review_dir)
        typer.echo(f"Created {review_dir}/ directory")

    typer.secho("Setup complete!", fg=typer.colors.GREEN)

    # 5. Optional launch
    if launch:
        launch_agent(launch)

def launch_agent(agent: str):
    agent = agent.lower()
    command = []
    if agent == "claude":
        command = ["claude"] # Claude Code
    elif agent == "gemini":
        command = ["gemini"] # Gemini CLI
    else:
        typer.secho(f"Unknown agent: {agent}", fg=typer.colors.RED)
        return

    # Check if command exists
    # On Windows, we might need to check with 'where'
    try:
        subprocess.run(["where", command[0]], check=True, capture_output=True)
    except subprocess.CalledProcessError:
        typer.secho(f"Error: {command[0]} command not found on PATH.", fg=typer.colors.RED)
        return

    typer.echo(f"Launching {agent}...")
    try:
        # Using shell=True for Windows command resolution if needed, but subprocess usually handles it
        subprocess.run(command, shell=True)
    except Exception as e:
        typer.echo(f"Failed to launch {agent}: {e}")
