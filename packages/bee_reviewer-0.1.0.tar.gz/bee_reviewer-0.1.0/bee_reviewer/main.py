import typer
from bee_reviewer.core import init_cmd, review_cmd

app = typer.Typer(help="Bee Reviewer: A narrated code review tool.")

@app.command()
def init(
    launch: str = typer.Option(None, help="Launch the agent CLI (claude or gemini) after setup.")
):
    """
    Sets up a project to use bee-reviewer.
    """
    init_cmd.run_init(launch)

@app.command()
def review():
    """
    Generates and launches a narrated code review.
    """
    review_cmd.run_review()

if __name__ == "__main__":
    app()
