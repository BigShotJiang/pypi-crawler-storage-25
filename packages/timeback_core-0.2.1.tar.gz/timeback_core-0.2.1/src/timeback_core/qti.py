"""
QTI XML parsing utilities, re-exported from ``timeback_qti.parse``.

Example:
    ```python
    from timeback_core.qti import parse_qti_xml, extract_prompt
    ```
"""

from timeback_qti.parse import (
    ParsedQtiItem,
    QtiChoice,
    QtiInlineFeedback,
    QtiInteractionAttributes,
    QtiModalFeedback,
    QtiResponseDeclaration,
    extract_choices,
    extract_correct_response,
    extract_feedback,
    extract_interaction_attributes,
    extract_modal_feedback,
    extract_prompt,
    extract_response_declaration,
    parse_qti_xml,
)

__all__ = [
    "ParsedQtiItem",
    "QtiChoice",
    "QtiInlineFeedback",
    "QtiInteractionAttributes",
    "QtiModalFeedback",
    "QtiResponseDeclaration",
    "extract_choices",
    "extract_correct_response",
    "extract_feedback",
    "extract_interaction_attributes",
    "extract_modal_feedback",
    "extract_prompt",
    "extract_response_declaration",
    "parse_qti_xml",
]
