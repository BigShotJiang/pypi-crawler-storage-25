"""
Re-export TimebackProvider from common infrastructure.

The provider has moved to timeback_common. This module provides
backwards compatibility re-exports.
"""

from timeback_common import (
    AuthCheckResult,
    CaliperPaths,
    CasePaths,
    ClrPaths,
    EdubridgePaths,
    OneRosterPaths,
    PlatformPaths,
    PowerPathPaths,
    QtiPaths,
    ResolvedEndpoint,
    ServiceName,
    TimebackProvider,
    WebhookPaths,
)

__all__ = [
    "AuthCheckResult",
    "CaliperPaths",
    "CasePaths",
    "ClrPaths",
    "EdubridgePaths",
    "OneRosterPaths",
    "PlatformPaths",
    "PowerPathPaths",
    "QtiPaths",
    "ResolvedEndpoint",
    "ServiceName",
    "TimebackProvider",
    "WebhookPaths",
]
