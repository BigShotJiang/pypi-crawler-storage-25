"""SRBench — self-rewarding benchmark."""
__version__ = "0.1.0"
