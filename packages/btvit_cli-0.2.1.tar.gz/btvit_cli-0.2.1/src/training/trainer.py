import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.optim.lr_scheduler import (
    CosineAnnealingLR,
    StepLR,
    CosineAnnealingWarmRestarts,
    ExponentialLR,
    ReduceLROnPlateau,
    OneCycleLR,
    MultiStepLR
)
import os
import time
import shutil
from typing import Dict, List, Optional, Tuple
from tqdm import tqdm
import numpy as np
from torch.amp import GradScaler, autocast
import re
from collections import defaultdict

from ..model.vit_model import create_vit_model
from ..utils.metrics import MetricsCalculator, BinaryLoss
from ..utils.logger import get_logger
from ..utils.monitor import TensorBoardLogger
from .epoch_progress_tracker import EpochProgressTracker


class EarlyStopping:
    def __init__(self, patience: int = 10, min_delta: float = 0.001, mode: str = 'max'):
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.counter = 0
        self.best_score = None
        self.early_stop = False

    def __call__(self, score: float) -> bool:
        if self.best_score is None:
            self.best_score = score
            return False

        if self.mode == 'max':
            if score > self.best_score + self.min_delta:
                self.best_score = score
                self.counter = 0
            else:
                self.counter += 1
        else:
            if score < self.best_score - self.min_delta:
                self.best_score = score
                self.counter = 0
            else:
                self.counter += 1

        if self.counter >= self.patience:
            self.early_stop = True

        return self.early_stop


class Trainer:
    def __init__(self, config, logger=None, save_checkpoints: bool = True, fold_index: Optional[int] = None,
                 pre_model_path: Optional[str] = None, load_weights_only: bool = False,
                 strict_load: bool = False, freeze_layers: Optional[str] = None,
                 freeze_ratio: Optional[float] = None):
        self.config = config
        self.fold_index = fold_index
        self.logger = logger or get_logger("Trainer", config.experiment.log_dir)
        self.save_checkpoints = save_checkpoints

        self.device = torch.device(config.training.device)
        self.use_mixed_precision = bool(getattr(self.config.training, "mixed_precision", False) and self.device.type == "cuda")
        self.is_finetuning = bool(pre_model_path or getattr(self.config.training, "pretrained_model_path", ""))

        # 根据是否有预训练模型决定初始化方式
        if pre_model_path:
            self.logger.info(f"检测到预训练模型路径: {pre_model_path}")
            self.logger.info("将跳过随机初始化，直接加载预训练模型...")

            # 保存预训练模型到实验目录
            self._copy_pretrained_model(pre_model_path)

            # 创建空的模型框架（不初始化权重）
            self.model = create_vit_model(config).to(self.device)

            # 初始化训练组件（在加载预训练权重之前）
            self.criterion = BinaryLoss(
                loss_type="bce",
                pos_weight=self._calculate_pos_weight()
            ).to(self.device)

            self.optimizer = self._create_optimizer()
            self.scheduler = self._create_scheduler()

            # 记录调度器信息
            if self.scheduler:
                self.logger.info(f"使用学习率调度器: {self.config.training.scheduler}")
                if self.config.training.scheduler_params:
                    params_str = ", ".join([f"{k}={v}" for k, v in self.config.training.scheduler_params.items()])
                    self.logger.info(f"调度器参数: {params_str}")
            else:
                self.logger.info("未使用学习率调度器")

            self.scaler = GradScaler(enabled=self.use_mixed_precision) if getattr(self.config.training, "mixed_precision", False) else None

            # 加载预训练权重
            self.load_pretrained_weights(pre_model_path, load_weights_only, strict_load)

            # 评估预训练模型的患者级别预测准确度
            self._evaluate_pretrained_model()

            # 记录加载后的模型状态（非随机初始化）
            self._log_model_state("预训练模型加载后")
        else:
            # 原有的随机初始化流程
            self.logger.info("未提供预训练模型，将使用随机初始化...")
            self.model = create_vit_model(config).to(self.device)

            # 初始化训练组件
            self.criterion = BinaryLoss(
                loss_type="bce",
                pos_weight=self._calculate_pos_weight()
            ).to(self.device)

            self.optimizer = self._create_optimizer()
            self.scheduler = self._create_scheduler()

            # 记录调度器信息
            if self.scheduler:
                self.logger.info(f"使用学习率调度器: {self.config.training.scheduler}")
                if self.config.training.scheduler_params:
                    params_str = ", ".join([f"{k}={v}" for k, v in self.config.training.scheduler_params.items()])
                    self.logger.info(f"调度器参数: {params_str}")
            else:
                self.logger.info("未使用学习率调度器")

            self.scaler = GradScaler(enabled=self.use_mixed_precision) if getattr(self.config.training, "mixed_precision", False) else None

            # 调试输出：检查模型初始化
            self._log_model_state("随机初始化后")

            # 保存模型初始化参数
            init_save_path = os.path.join(self.config.experiment.result_dir, f"{self.config.experiment.name}_initialization.pth")
            self.model.save_initialization(init_save_path)
            self.logger.info(f"模型初始化参数已保存到: {init_save_path}")

        # 冻结指定层
        if freeze_layers or freeze_ratio is not None:
            self.apply_freezing(freeze_layers, freeze_ratio)

    def _copy_pretrained_model(self, pre_model_path: str):
        """复制预训练模型到实验目录"""
        # 获取checkpoint目录路径
        experiment_name = self.config.experiment.name
        if self.fold_index is not None:
            checkpoint_dir = os.path.join("experiments", f"{experiment_name}_fold_{self.fold_index}", "checkpoints")
        else:
            checkpoint_dir = os.path.join("experiments", experiment_name, "checkpoints")

        # 确保目录存在
        os.makedirs(checkpoint_dir, exist_ok=True)

        # 目标路径
        target_path = os.path.join(checkpoint_dir, "pre_model.pth")

        # 复制文件
        try:
            shutil.copy2(pre_model_path, target_path)
            self.logger.info(f"预训练模型已复制到: {target_path}")
        except Exception as e:
            self.logger.warning(f"复制预训练模型失败: {e}")
            self.logger.warning("将直接使用原始路径加载模型")

    def _evaluate_pretrained_model(self):
        """评估预训练模型的患者级别预测准确度"""
        from ..data.dataset import DataLoaderManager

        self.logger.info("开始评估预训练模型的患者级别预测准确度...")

        try:
            # 尝试加载保存的分割信息
            pre_split_patients = None
            split_info_path = os.path.join(self.config.experiment.result_dir,
                                         f"{self.config.experiment.name}_split_info.json")

            if os.path.exists(split_info_path):
                from ..data.enhanced_splitting import EnhancedDataSplitter
                try:
                    split_info = EnhancedDataSplitter.load_split_info(split_info_path)
                    pre_split_patients = {
                        'train': split_info['train_patients'],
                        'val': split_info['val_patients'],
                        'test': split_info['test_patients']
                    }
                    self.logger.info(f"加载已保存的分割信息: {split_info_path}")
                    self.logger.info(f"  验证集患者数: {len(pre_split_patients['val'])}")
                except Exception as e:
                    self.logger.warning(f"加载分割信息失败: {e}")

            # 创建验证数据加载器（优先使用保存的分割信息）
            data_manager = DataLoaderManager(
                data_path=self.config.data.data_path,
                label_path=self.config.data.label_path,
                batch_size=self.config.training.batch_size,
                num_workers=self.config.training.num_workers,
                pin_memory=self.config.data.pin_memory,
                pre_split_patients=pre_split_patients  # 使用保存的分割信息或None
            )
            val_loader = data_manager.get_val_dataloader()

            # 收集预测结果
            self.model.eval()
            all_predictions = []
            all_targets = []
            all_image_paths = []

            with torch.no_grad():
                sample_cursor = 0
                for batch_idx, batch in enumerate(val_loader):
                    # ViTCollator只返回两个元素：images和targets
                    images, targets = batch
                    images = images.to(self.device)
                    targets = targets.to(self.device)
                    outputs = self.model(images)
                    probs = torch.sigmoid(outputs)
                    preds = (probs > 0.5).float()

                    batch_samples, sample_cursor = self._consume_batch_samples(
                        val_loader.dataset, sample_cursor, images.size(0)
                    )
                    for i, (image_path, _) in enumerate(batch_samples):
                        all_predictions.append(preds[i].cpu().item() == 1.0)
                        all_targets.append(targets[i].cpu().item())
                        all_image_paths.append(image_path)

            # 计算患者级别准确度
            patient_metrics = self._calculate_patient_level_accuracy(
                all_predictions, all_targets, all_image_paths
            )

            # 记录日志
            self.logger.info(
                f"预装载模型的初始患者级别预测准确度: "
                f"{patient_metrics['predict_accuracy']:.4f} "
                f"({patient_metrics['patient_correct']}/{patient_metrics['patient_total']} 患者)"
            )

            # 可选：记录详细的患者预测信息
            if self.config.training.debug_logging:
                self.logger.info("患者级别预测详情:")
                for patient_id, details in patient_metrics.get('patient_details', {}).items():
                    self.logger.info(f"  {patient_id}: 预测={details['prediction']}, 真实={details['target']}, "
                                  f"准确={details['correct']}, 样本数={details['sample_count']}")

        except Exception as e:
            self.logger.error(f"评估预训练模型患者级别预测失败: {str(e)}")
            self.logger.warning("跳过患者级别预测评估")

    def _log_model_state(self, state_name: str):
        """记录模型状态信息"""
        # 调试输出：检查模型状态
        final_layer = self.model.mlp_head[-1]
        self.logger.info(f"模型输出层{state_name}检查:")
        self.logger.info(f"  权重均值: {final_layer.weight.mean().item():.6f}")
        self.logger.info(f"  权重标准差: {final_layer.weight.std().item():.6f}")
        self.logger.info(f"  偏置值: {final_layer.bias.item():.6f}")

        # 测试模型预测
        self.model.eval()
        input_h, input_w = self.config.model.input_shape
        dummy_input = torch.randn(4, 1, input_h, input_w).to(self.device)
        with torch.no_grad():
            output = self.model(dummy_input)
            probs = torch.sigmoid(output)
            preds = (probs > 0.5).float()

        self.logger.info(f"  {state_name}测试预测:")
        self.logger.info(f"    输出范围: [{output.min().item():.6f}, {output.max().item():.6f}]")
        self.logger.info(f"    概率范围: [{probs.min().item():.6f}, {probs.max().item():.6f}]")
        self.logger.info(f"    阳性预测数: {preds.sum().item()}/4")
        self.logger.info(f"    预测结果: {preds.flatten().tolist()}")

        self.early_stopping_config = self._get_early_stopping_config()
        self.model_selection_config = self._get_model_selection_config()
        self.early_stopping_enabled = bool(self.early_stopping_config.get("enabled", True))
        self.early_stopping = EarlyStopping(
            patience=self.early_stopping_config["patience"],
            min_delta=self.early_stopping_config["min_delta"],
            mode=self.early_stopping_config["mode"]
        )

        if self.model_selection_config["mode"] == "min":
            self.best_val_metric = float('inf')
        else:
            self.best_val_metric = float('-inf')
        self.best_epoch = 0

        if self.save_checkpoints:
            os.makedirs(self.config.experiment.checkpoint_dir, exist_ok=True)
        os.makedirs(self.config.experiment.result_dir, exist_ok=True)
        os.makedirs(self.config.experiment.log_dir, exist_ok=True)

        # 初始化TensorBoard记录器
        self.tensorboard_logger = TensorBoardLogger(self.config.experiment.log_dir, self.fold_index)

        self.logger.log_model_summary(self.model)
        self.logger.log_config(self.config)

        # 记录模型计算图
        self._log_model_graph()

    def _extract_patient_id(self, image_path: str) -> str:
        """从图像路径中提取患者ID"""
        # 从完整路径中提取文件名
        filename = os.path.basename(image_path)
        # 去除扩展名
        name_without_ext = os.path.splitext(filename)[0]
        # 提取患者ID（通常是第一部分，用下划线分隔）
        patient_id = name_without_ext.split('_')[0]
        return patient_id

    @staticmethod
    def _consume_batch_samples(dataset, sample_cursor: int, batch_size: int):
        """按数据集顺序提取当前批次对应的样本元数据。"""
        batch_samples = dataset.samples[sample_cursor:sample_cursor + batch_size]
        return batch_samples, sample_cursor + len(batch_samples)

    def _calculate_patient_level_accuracy(self, predictions: List[bool], targets: List[float], image_paths: List[str]) -> Dict[str, float]:
        """
        计算患者级别的预测准确度

        Args:
            predictions: 预测结果列表 (True/False)
            targets: 真实标签列表 (0.0/1.0)
            image_paths: 图像路径列表

        Returns:
            包含患者级别指标的字典
        """
        # 按患者ID分组
        patient_predictions = defaultdict(list)
        patient_targets = {}

        for pred, target, img_path in zip(predictions, targets, image_paths):
            patient_id = self._extract_patient_id(img_path)
            patient_predictions[patient_id].append(pred)
            patient_targets[patient_id] = int(target)

        # 计算患者级别的预测
        patient_level_correct = 0
        patient_level_total = 0
        patient_level_details = []

        for patient_id, preds in patient_predictions.items():
            # 患者级别预测：如果有任何阳性预测，则患者预测为阳性
            patient_prediction = 1 if any(preds) else 0
            true_label = patient_targets[patient_id]

            is_correct = patient_prediction == true_label
            if is_correct:
                patient_level_correct += 1
            patient_level_total += 1

            patient_level_details.append({
                'patient_id': patient_id,
                'prediction': patient_prediction,
                'true_label': true_label,
                'correct': is_correct,
                'positive_samples': sum(preds),
                'total_samples': len(preds)
            })

        # 计算准确率
        patient_accuracy = patient_level_correct / patient_level_total if patient_level_total > 0 else 0.0

        return {
            'predict_accuracy': patient_accuracy,
            'patient_total': patient_level_total,
            'patient_correct': patient_level_correct,
            'patient_details': patient_level_details
        }

    def _log_model_graph(self):
        """记录模型计算图到TensorBoard"""
        try:
            # 创建一个示例输入来记录模型图
            batch_size = 2
            patches_per_image = 24
            sample_input = torch.randn(batch_size, patches_per_image, 1, 16, 16).to(self.device)
            self.tensorboard_logger.log_graph(self.model, sample_input)
            self.logger.info("模型计算图已记录到TensorBoard")
        except Exception as e:
            self.logger.warning(f"记录模型计算图失败: {str(e)}")

    def _log_dataset_samples(self, data_loader: DataLoader, epoch: int):
        """记录数据集样本到TensorBoard"""
        try:
            # 获取一个批次的数据
            sample_batch = next(iter(data_loader))
            data, targets = sample_batch

            # 记录图像数据
            if isinstance(data, torch.Tensor):
                # 选择前几个样本进行可视化
                num_samples = min(4, data.shape[0])
                sample_data = data[:num_samples].to(self.device)

                # 如果数据是5D (batch, patches, channels, height, width)
                if sample_data.dim() == 5:
                    # 记录补丁图像
                    self.tensorboard_logger.log_images('Dataset/PatchSamples', sample_data, epoch, max_images=16)

                    # 记录重构后的图像网格
                    self.tensorboard_logger.log_patches_as_grid('Dataset/ReconstructedImage', sample_data, epoch)

                    # 记录输入数据分布
                    self.tensorboard_logger.log_histogram('Dataset/InputDistribution', sample_data, epoch)

                # 记录标签分布
                if isinstance(targets, torch.Tensor):
                    targets_tensor = targets[:num_samples].float().to(self.device)
                    self.tensorboard_logger.log_histogram('Dataset/LabelDistribution', targets_tensor, epoch)

                    # 记录类别统计
                    pos_count = (targets_tensor > 0.5).sum().item()
                    neg_count = (targets_tensor <= 0.5).sum().item()
                    self.tensorboard_logger.log_scalars('Dataset/ClassBalance', {
                        'positive': pos_count,
                        'negative': neg_count
                    }, epoch)

                # 记录模型统计信息
                if epoch == 0:
                    self.tensorboard_logger.log_model_stats(self.model, epoch)

                self.logger.info(f"数据集样本已记录到TensorBoard (epoch {epoch})")
        except Exception as e:
            self.logger.warning(f"记录数据集样本失败: {str(e)}")

    def _calculate_pos_weight(self) -> Optional[float]:
        try:
            from ..data.dataset import DataLoaderManager
            manager = DataLoaderManager(
                data_path=self.config.data.data_path,
                label_path=self.config.data.label_path
            )
            info = manager.get_dataset_info()
            train_info = info['train']
            neg_count = train_info['negative_samples']
            pos_count = train_info['positive_samples']

            if pos_count > 0:
                return neg_count / pos_count
            else:
                return None
        except:
            return None

    def _get_monitoring_config(self) -> dict:
        monitoring = getattr(self.config, "monitoring", None)
        return {
            "early_stopping": dict(getattr(monitoring, "early_stopping", {}) or {}),
            "model_selection": dict(getattr(monitoring, "model_selection", {}) or {}),
            "verbose": bool(getattr(monitoring, "verbose", False)),
        }

    def _get_early_stopping_config(self) -> dict:
        monitoring = self._get_monitoring_config()["early_stopping"]
        metric = monitoring.get("metric", "val_auc")
        mode = monitoring.get("mode")
        if mode not in {"min", "max"}:
            mode = "min" if metric == "val_loss" else "max"
        return {
            "enabled": bool(monitoring.get("enabled", True)),
            "metric": metric,
            "mode": mode,
            "patience": int(monitoring.get("patience", 10)),
            "min_delta": float(monitoring.get("min_delta", 0.001)),
        }

    def _get_model_selection_config(self) -> dict:
        monitoring = self._get_monitoring_config()["model_selection"]
        metric = monitoring.get("metric", "val_auc")
        mode = monitoring.get("mode", "max")
        if mode not in {"min", "max"}:
            mode = "min" if metric == "val_loss" else "max"
        return {
            "metric": metric,
            "mode": mode,
        }

    def _metric_value(self, metrics: Dict[str, float], metric_name: str) -> float:
        alias_map = {
            "val_loss": "loss",
            "val_auc": "auc",
            "val_accuracy": "accuracy",
            "val_f1": "f1",
            "predict_accuracy": "predict_accuracy",
        }
        if metric_name in metrics:
            return float(metrics[metric_name])
        fallback_key = alias_map.get(metric_name, metric_name)
        if fallback_key == "loss":
            return float(metrics.get(fallback_key, float("inf")))
        return float(metrics.get(fallback_key, 0.0))

    def _metric_display_name(self, metric_name: str) -> str:
        display_names = {
            "val_auc": "AUC",
            "val_accuracy": "Accuracy",
            "val_f1": "F1",
            "val_loss": "Loss",
            "predict_accuracy": "Predict_Accuracy",
        }
        return display_names.get(metric_name, metric_name)

    # ---- Rich test-result formatting ----

    _TEST_METRIC_ORDER = [
        "accuracy", "precision", "recall", "f1", "auc",
        "true_negative", "false_positive", "false_negative", "true_positive",
        "specificity", "sensitivity", "loss",
        "predict_accuracy", "patient_total", "patient_correct",
    ]

    def _print_test_results_rich(self, test_metrics: Dict):
        """Print test metrics as Rich tables (scalar metrics + patient details)."""
        from rich.console import Console
        from rich.table import Table

        console = Console(stderr=True)

        # -- Scalar metrics table --
        patient_details = test_metrics.get("patient_details", [])
        scalar_keys = [k for k in self._TEST_METRIC_ORDER if k in test_metrics]
        # Append any remaining scalar keys not in the predefined order
        for k in test_metrics:
            if k not in scalar_keys and k != "patient_details":
                v = test_metrics[k]
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    scalar_keys.append(k)

        metrics_table = Table(
            title="测试结果", show_header=True, header_style="bold cyan",
            title_style="bold green", expand=False,
        )
        metrics_table.add_column("指标", style="bold")
        metrics_table.add_column("值", justify="right")

        for name in scalar_keys:
            value = test_metrics[name]
            if isinstance(value, float):
                metrics_table.add_row(name, f"{value:.4f}")
            else:
                metrics_table.add_row(name, str(value))

        if patient_details:
            correct = sum(1 for p in patient_details if p.get("correct"))
            total = len(patient_details)
            metrics_table.add_row(
                "[bold]patient_details[/]",
                f"{total} patients, {correct}/{total} correct",
            )

        console.print(metrics_table)

        # -- Patient details table --
        if patient_details:
            patient_table = Table(
                title="患者预测详情", show_header=True, header_style="bold cyan",
                title_style="bold", expand=False,
            )
            patient_table.add_column("Patient ID", style="bold", max_width=22)
            patient_table.add_column("Pred", justify="center", width=4)
            patient_table.add_column("True", justify="center", width=4)
            patient_table.add_column("Result", justify="center", width=6)
            patient_table.add_column("Mean Prob", justify="right", width=9)
            patient_table.add_column("Samples", justify="right", width=7)

            for p in patient_details:
                result_text = "[green]OK[/]" if p.get("correct") else "[red]MISS[/]"
                prob = p.get("mean_probability", 0.0)
                patient_table.add_row(
                    str(p.get("patient_id", "?")),
                    str(p.get("prediction", "?")),
                    str(p.get("true_label", p.get("target", "?"))),
                    result_text,
                    f"{float(prob):.4f}",
                    str(p.get("total_samples", "")),
                )

            console.print(patient_table)

    def _format_patient_detail_line(self, patient: Dict[str, object]) -> str:
        patient_id = patient.get("patient_id", "unknown")
        prediction = patient.get("prediction", "?")
        true_label = patient.get("true_label", patient.get("target", "?"))
        line = f"    患者{patient_id}: 预测={prediction}, 真实={true_label}"

        if "positive_samples" in patient and "total_samples" in patient:
            return f"{line}, 阳性样本={patient['positive_samples']}/{patient['total_samples']}"

        if "mean_probability" in patient:
            mean_probability = float(patient["mean_probability"])
            total_samples = patient.get("total_samples")
            if total_samples is not None:
                return f"{line}, 平均概率={mean_probability:.4f}, 样本数={total_samples}"
            return f"{line}, 平均概率={mean_probability:.4f}"

        sample_count = patient.get("sample_count", patient.get("total_samples"))
        if sample_count is not None:
            return f"{line}, 样本数={sample_count}"
        return line

    def _optimizer_param_groups(self):
        learning_rate = float(getattr(self.config.training, "learning_rate", 1e-4))
        weight_decay = float(getattr(self.config.training, "weight_decay", 0.0))
        named_parameters = [(name, param) for name, param in self.model.named_parameters() if param.requires_grad]

        if not named_parameters:
            return [{"params": list(self.model.parameters()), "lr": learning_rate, "weight_decay": weight_decay}]

        if getattr(self.config.training, "use_differential_lr", False) and self.is_finetuning:
            finetune_scale = float(getattr(self.config.training, "finetune_lr_scale", 1.0))
            head_params = [param for name, param in named_parameters if name.startswith("mlp_head")]
            backbone_params = [param for name, param in named_parameters if not name.startswith("mlp_head")]
            param_groups = []
            if backbone_params:
                param_groups.append({
                    "params": backbone_params,
                    "lr": learning_rate * finetune_scale,
                    "weight_decay": weight_decay,
                })
            if head_params:
                param_groups.append({
                    "params": head_params,
                    "lr": learning_rate,
                    "weight_decay": weight_decay,
                })
            if param_groups:
                return param_groups

        return [{
            "params": [param for _, param in named_parameters],
            "lr": learning_rate,
            "weight_decay": weight_decay,
        }]

    def _create_optimizer(self):
        optimizer_params = self._optimizer_param_groups()
        if self.config.training.optimizer == "AdamW":
            return optim.AdamW(optimizer_params)
        elif self.config.training.optimizer == "Adam":
            return optim.Adam(optimizer_params)
        elif self.config.training.optimizer == "SGD":
            return optim.SGD(optimizer_params)
        else:
            raise ValueError(f"不支持的优化器: {self.config.training.optimizer}")

    def _create_scheduler(self):
        """创建学习率调度器"""
        if not self.config.training.scheduler:
            return None

        scheduler_name = self.config.training.scheduler
        scheduler_params = self.config.training.scheduler_params.copy()

        # 特殊处理需要从config中获取的参数
        if scheduler_name == "CosineAnnealingLR" and "T_max" not in scheduler_params:
            scheduler_params["T_max"] = self.config.training.epochs
        elif scheduler_name == "StepLR" and "step_size" not in scheduler_params:
            scheduler_params["step_size"] = max(1, self.config.training.epochs // 3)
        elif scheduler_name == "OneCycleLR" and "total_steps" not in scheduler_params:
            # OneCycleLR需要总步数，使用self.steps_per_epoch（如果存在）
            if hasattr(self, 'steps_per_epoch'):
                scheduler_params["total_steps"] = self.config.training.epochs * self.steps_per_epoch
            else:
                self.logger.warning("OneCycleLR需要steps_per_epoch，但当前训练器未提供此参数")

        # 创建调度器
        try:
            if scheduler_name == "CosineAnnealingLR":
                return CosineAnnealingLR(self.optimizer, **scheduler_params)
            elif scheduler_name == "CosineAnnealingWarmRestarts":
                return CosineAnnealingWarmRestarts(self.optimizer, **scheduler_params)
            elif scheduler_name == "StepLR":
                return StepLR(self.optimizer, **scheduler_params)
            elif scheduler_name == "ExponentialLR":
                return ExponentialLR(self.optimizer, **scheduler_params)
            elif scheduler_name == "ReduceLROnPlateau":
                return ReduceLROnPlateau(self.optimizer, **scheduler_params)
            elif scheduler_name == "OneCycleLR":
                return OneCycleLR(self.optimizer, **scheduler_params)
            elif scheduler_name == "MultiStepLR":
                return MultiStepLR(self.optimizer, **scheduler_params)
            else:
                self.logger.warning(f"未知的调度器类型: {scheduler_name}")
                return None
        except Exception as e:
            self.logger.error(f"创建调度器失败: {e}")
            self.logger.error(f"调度器参数: {scheduler_params}")
            return None

    def train_epoch(self, train_loader: DataLoader, epoch: int = 0, tracker=None) -> Dict[str, float]:
        self.model.train()
        metrics_calculator = MetricsCalculator()

        total_loss = 0.0
        num_batches = len(train_loader)
        accumulate_steps = max(1, int(getattr(self.config.training, "accumulate_grad_batches", 1)))
        self.optimizer.zero_grad()

        # 调试：检查第一个批次的数据
        debug_first_batch = getattr(self.config.training, 'debug_logging', False)

        for batch_idx, (data, targets) in enumerate(train_loader):
            data = data.to(self.device)
            targets = targets.to(self.device).unsqueeze(1)

            # 调试：检查第一个批次的详细信息
            if debug_first_batch and batch_idx == 0:
                self.logger.info(f"=== 第一批次调试信息 ===")
                self.logger.info(f"数据形状: {data.shape}")
                self.logger.info(f"标签形状: {targets.shape}")
                self.logger.info(f"标签范围: [{targets.min().item():.1f}, {targets.max().item():.1f}]")
                self.logger.info(f"阳性样本数: {targets.sum().item()}/{targets.size(0)}")
                self.logger.info(f"阳性比例: {targets.sum().item()/targets.size(0):.3f}")

                # 检查模型在这个批次上的初始预测
                self.model.eval()
                with torch.no_grad():
                    debug_outputs = self.model(data)
                    debug_probs = torch.sigmoid(debug_outputs)
                    debug_preds = (debug_probs > 0.5).float()

                self.logger.info(f"批次初始输出范围: [{debug_outputs.min().item():.6f}, {debug_outputs.max().item():.6f}]")
                self.logger.info(f"批次初始概率范围: [{debug_probs.min().item():.6f}, {debug_probs.max().item():.6f}]")
                self.logger.info(f"批次初始阳性预测数: {debug_preds.sum().item()}/{targets.size(0)}")
                self.model.train()

                debug_first_batch = False

            should_step = ((batch_idx + 1) % accumulate_steps == 0) or (batch_idx + 1 == num_batches)

            if self.use_mixed_precision and self.scaler:
                with autocast(self.device.type, enabled=True):
                    outputs = self.model(data)
                    loss = self.criterion(outputs, targets)

                self.scaler.scale(loss / accumulate_steps).backward()
                if should_step:
                    if self.config.training.gradient_clip_val > 0:
                        self.scaler.unscale_(self.optimizer)
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(),
                            self.config.training.gradient_clip_val
                        )

                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad()
            else:
                outputs = self.model(data)
                loss = self.criterion(outputs, targets)

                (loss / accumulate_steps).backward()

                if should_step:
                    if self.config.training.gradient_clip_val > 0:
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(),
                            self.config.training.gradient_clip_val
                        )

                    self.optimizer.step()
                    self.optimizer.zero_grad()

            total_loss += loss.item()
            metrics_calculator.update(outputs, targets)

            if tracker is not None:
                tracker.update_train_progress(batch_idx, num_batches, total_loss / (batch_idx + 1))

            # 按配置间隔记录TensorBoard参数，但不输出详细日志
            if (batch_idx + 1) % self.config.experiment.log_every_n_steps == 0:
                global_step = epoch * num_batches + batch_idx
                self.tensorboard_logger.log_scalars('Training/Step', {
                    'loss': loss.item(),
                    'avg_loss': total_loss / (batch_idx + 1)
                }, global_step)

                # 记录学习率
                current_lr = self.optimizer.param_groups[0]['lr']
                # if (batch_idx + 1) % 50 == 0:  # 每50个批次记录一次调试信息，避免日志过多
                #     print(f"[DEBUG] Step级学习率记录: batch={batch_idx+1}, lr={current_lr}")
                self.tensorboard_logger.log_learning_rate(current_lr, global_step, 'Training/LearningRate')

        avg_loss = total_loss / num_batches
        epoch_metrics = metrics_calculator.compute()
        epoch_metrics['loss'] = avg_loss

        return epoch_metrics

    def validate_epoch(self, val_loader: DataLoader, tracker=None) -> Dict[str, float]:
        self.model.eval()
        metrics_calculator = MetricsCalculator()

        total_loss = 0.0
        num_batches = len(val_loader)

        # 收集所有预测结果用于患者级别准确度计算
        all_predictions = []
        all_targets = []
        all_image_paths = []

        # 调试：检查验证数据
        debug_all_batches = getattr(self.config.training, 'debug_logging', False)

        with torch.no_grad():
            sample_cursor = 0

            for batch_idx, (data, targets) in enumerate(val_loader):
                data = data.to(self.device)
                targets = targets.to(self.device).unsqueeze(1)

                outputs = self.model(data)
                loss = self.criterion(outputs, targets)

                # 收集预测结果和图像路径
                probabilities = torch.sigmoid(outputs)
                predictions = (probabilities > 0.5).float()

                batch_samples, sample_cursor = self._consume_batch_samples(
                    val_loader.dataset, sample_cursor, data.size(0)
                )
                for i, (image_path, _) in enumerate(batch_samples):
                    all_predictions.append(predictions[i].item() == 1.0)
                    all_targets.append(targets[i].item())
                    all_image_paths.append(image_path)

                # 调试：检查所有批次信息
                if debug_all_batches:
                    self.logger.info(f"=== 验证批次 {batch_idx+1} 调试信息 ===")
                    self.logger.info(f"验证数据形状: {data.shape}")
                    self.logger.info(f"验证标签形状: {targets.shape}")
                    self.logger.info(f"验证标签范围: [{targets.min().item():.1f}, {targets.max().item():.1f}]")
                    self.logger.info(f"验证阳性样本数: {targets.sum().item()}/{targets.size(0)}")
                    self.logger.info(f"验证阳性比例: {targets.sum().item()/targets.size(0):.3f}")

                    # 检查模型在验证批次上的预测
                    probs = torch.sigmoid(outputs)
                    preds = (probs > 0.5).float()

                    self.logger.info(f"验证批次输出范围: [{outputs.min().item():.6f}, {outputs.max().item():.6f}]")
                    self.logger.info(f"验证批次概率范围: [{probs.min().item():.6f}, {probs.max().item():.6f}]")
                    self.logger.info(f"验证批次阳性预测数: {preds.sum().item()}/{targets.size(0)}")
                    self.logger.info(f"验证批次预测结果: {preds.flatten().tolist()[:10]}...")
                    self.logger.info(f"实际标签结果: {targets.flatten().tolist()[:10]}...")

                total_loss += loss.item()
                metrics_calculator.update(outputs, targets)

                if tracker is not None:
                    tracker.update_val_progress(batch_idx, num_batches, total_loss / (batch_idx + 1))

        avg_loss = total_loss / num_batches
        epoch_metrics = metrics_calculator.compute()
        epoch_metrics['loss'] = avg_loss

        # 计算患者级别的预测准确度
        if all_predictions and all_targets and all_image_paths:
            patient_metrics = self._calculate_patient_level_accuracy(
                all_predictions, all_targets, all_image_paths
            )
            # 将患者级别指标添加到epoch_metrics中
            epoch_metrics['predict_accuracy'] = patient_metrics['predict_accuracy']
            epoch_metrics['patient_total'] = patient_metrics['patient_total']
            epoch_metrics['patient_correct'] = patient_metrics['patient_correct']

            # 记录患者级别预测的详细信息
            if hasattr(self.config.training, 'debug_patient_accuracy') and self.config.training.debug_patient_accuracy:
                self.logger.info(f"患者级别预测详情:")
                for detail in patient_metrics['patient_details'][:5]:  # 只显示前5个患者的详情
                    self.logger.info(f"  患者{detail['patient_id']}: 预测={detail['prediction']}, "
                                   f"真实={detail['true_label']}, 正确={detail['correct']}, "
                                   f"阳性样本={detail['positive_samples']}/{detail['total_samples']}")
        else:
            epoch_metrics['predict_accuracy'] = 0.0
            epoch_metrics['patient_total'] = 0
            epoch_metrics['patient_correct'] = 0

        return epoch_metrics

    def save_checkpoint(self, epoch: int, val_metric: float, is_best: bool = False):
        if not self.save_checkpoints:
            return  # 不保存检查点

        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler else None,
            'val_metric': val_metric,
            'config': self.config
        }

        checkpoint_path = os.path.join(
            self.config.experiment.checkpoint_dir,
            f'checkpoint_epoch_{epoch}.pth'
        )
        torch.save(checkpoint, checkpoint_path)

        if is_best:
            best_path = os.path.join(
                self.config.experiment.checkpoint_dir,
                'best_model.pth'
            )
            torch.save(checkpoint, best_path)

        self._prune_epoch_checkpoints()

        self.logger.info(f"检查点已保存: {checkpoint_path}")

    def _prune_epoch_checkpoints(self):
        keep_count = int(getattr(self.config.experiment, "save_top_k", 0))
        if keep_count <= 0:
            return

        checkpoint_dir = self.config.experiment.checkpoint_dir
        checkpoint_files = []
        for filename in os.listdir(checkpoint_dir):
            if filename.startswith("checkpoint_epoch_") and filename.endswith(".pth"):
                try:
                    epoch = int(filename[len("checkpoint_epoch_"):-4])
                except ValueError:
                    continue
                checkpoint_files.append((epoch, os.path.join(checkpoint_dir, filename)))

        if len(checkpoint_files) <= keep_count:
            return

        checkpoint_files.sort(key=lambda item: item[0], reverse=True)
        for _, checkpoint_path in checkpoint_files[keep_count:]:
            if os.path.exists(checkpoint_path):
                os.remove(checkpoint_path)

    def load_checkpoint(self, checkpoint_path: str, weights_only: bool = False):
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        if weights_only:
            # 仅加载模型权重
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.logger.info(f"仅加载模型权重: {checkpoint_path}")
            return None, None
        else:
            # 加载完整检查点
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

            if self.scheduler and checkpoint['scheduler_state_dict']:
                self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

            epoch = checkpoint['epoch']
            val_metric = checkpoint['val_metric']

            self.logger.info(f"检查点已加载: {checkpoint_path} (epoch {epoch}, val_metric: {val_metric:.4f})")
            return epoch, val_metric

    def load_pretrained_weights(self, pre_model_path: str, load_weights_only: bool = False, strict_load: bool = False):
        """
        加载预训练权重

        Args:
            pre_model_path: 预训练模型路径
            load_weights_only: 是否仅加载权重（不加载优化器状态）
            strict_load: 是否严格加载权重（不匹配时报错）
        """
        if not os.path.exists(pre_model_path):
            self.logger.error(f"预训练模型文件不存在: {pre_model_path}")
            return

        # 记录加载前的模型参数统计
        model_dict_before = self.model.state_dict()
        stats_before = self._calculate_parameter_stats(model_dict_before)
        self.logger.info("=== 预训练权重加载前的模型统计 ===")
        self.logger.info(f"  总参数数: {stats_before['total_params']:,}")
        self.logger.info(f"  权重均值: {stats_before['weight_mean']:.6f}")
        self.logger.info(f"  权重标准差: {stats_before['weight_std']:.6f}")

        checkpoint = None
        try:
            # 使用内存优化的方式加载checkpoint
            # 处理PyTorch 2.6的weights_only默认值为True的问题
            try:
                checkpoint = torch.load(pre_model_path, map_location=self.device, weights_only=False)
            except Exception as e:
                # 如果失败，尝试使用安全加载器
                if "safe_globals" in str(e) or "WeightsUnpickler error" in str(e):
                    # 添加Config类到安全全局变量
                    torch.serialization.add_safe_globals(['src.utils.config.Config'])
                    self.logger.info("添加Config类到安全全局变量列表")
                    checkpoint = torch.load(pre_model_path, map_location=self.device, weights_only=True)
                else:
                    raise

            # 判断是完整checkpoint还是纯权重文件
            if 'model_state_dict' in checkpoint:
                # 完整checkpoint
                pretrained_dict = checkpoint['model_state_dict']
                self.logger.info(f"加载完整checkpoint: {pre_model_path}")

                # 如果是完整checkpoint且需要加载优化器状态
                if not load_weights_only:
                    if 'optimizer_state_dict' in checkpoint:
                        try:
                            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                            self.logger.info("已加载预训练优化器状态")
                        except Exception as e:
                            self.logger.warning(f"无法加载优化器状态: {str(e)}")

                    if self.scheduler and 'scheduler_state_dict' in checkpoint:
                        try:
                            self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
                            self.logger.info("已加载预训练调度器状态")
                        except Exception as e:
                            self.logger.warning(f"无法加载调度器状态: {str(e)}")
            else:
                # 纯权重文件
                pretrained_dict = checkpoint
                self.logger.info(f"加载纯权重文件: {pre_model_path}")

            # 获取当前模型的权重字典
            model_dict = self.model.state_dict()

            # 处理维度不匹配的情况
            pretrained_dict = self._handle_dimension_mismatch(pretrained_dict, model_dict)

            # 过滤不匹配的权重
            if not strict_load:
                pretrained_dict = {k: v for k, v in pretrained_dict.items()
                                 if k in model_dict and v.size() == model_dict[k].size()}

                # 报告跳过的权重
                source_keys = checkpoint['model_state_dict'].keys() if 'model_state_dict' in checkpoint else checkpoint.keys()
                skipped_keys = [k for k in source_keys if k not in pretrained_dict]
                # if skipped_keys:
                #     self.logger.warning(f"跳过以下权重: {skipped_keys}")

            # 加载权重
            if strict_load:
                # 严格加载，要求所有权重匹配
                self.model.load_state_dict(pretrained_dict, strict=True)
                self.logger.info("严格加载模式：所有权重匹配")
            else:
                # 非严格加载，更新模型字典
                model_dict.update(pretrained_dict)
                self.model.load_state_dict(model_dict)
                self.logger.info(f"成功加载 {len(pretrained_dict)}/{len(model_dict)} 个参数")

            # 记录加载后的模型参数统计
            model_dict_after = self.model.state_dict()
            stats_after = self._calculate_parameter_stats(model_dict_after)

            self.logger.info("=== 预训练权重加载后的模型统计 ===")
            self.logger.info(f"  总参数数: {stats_after['total_params']:,}")
            self.logger.info(f"  权重均值: {stats_after['weight_mean']:.6f}")
            self.logger.info(f"  权重标准差: {stats_after['weight_std']:.6f}")

            # 计算变化
            mean_change = abs(stats_after['weight_mean'] - stats_before['weight_mean'])
            std_change = abs(stats_after['weight_std'] - stats_before['weight_std'])

            self.logger.info("=== 权重变化验证 ===")
            self.logger.info(f"  权重均值变化: {mean_change:.6f}")
            self.logger.info(f"  权重标准差变化: {std_change:.6f}")

            if mean_change > 1e-6 or std_change > 1e-6:
                self.logger.info("[OK] 权重已成功更新")
            else:
                self.logger.warning("[WARNING] 权重可能未正确更新（变化很小）")

            # 验证加载效果
            self._verify_pretrained_loading()

        except Exception as e:
            self.logger.error(f"加载预训练权重失败: {str(e)}")
            if strict_load:
                raise
            else:
                self.logger.warning("继续使用随机初始化的权重")
        finally:
            # 内存优化：清理临时变量
            if checkpoint is not None:
                del checkpoint
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                self.logger.debug("已清理GPU缓存")

    def _calculate_parameter_stats(self, state_dict):
        """计算参数统计信息"""
        total_params = 0
        weight_sum = 0
        weight_sq_sum = 0
        count = 0

        for k, v in state_dict.items():
            total_params += v.numel()
            if 'weight' in k:
                weight_sum += v.sum().item()
                weight_sq_sum += (v ** 2).sum().item()
                count += v.numel()

        mean = weight_sum / count if count > 0 else 0
        std = np.sqrt((weight_sq_sum / count) - (mean ** 2)) if count > 0 else 0

        return {
            'total_params': total_params,
            'weight_mean': mean,
            'weight_std': std
        }

    def _handle_dimension_mismatch(self, pretrained_dict, model_dict):
        """处理预训练权重与当前模型维度不匹配的问题"""
        # 处理分类头（mlp_head）维度不匹配
        if 'mlp_head.1.weight' in pretrained_dict and 'mlp_head.1.weight' in model_dict:
            pre_shape = pretrained_dict['mlp_head.1.weight'].shape
            cur_shape = model_dict['mlp_head.1.weight'].shape

            if pre_shape != cur_shape:
                self.logger.warning(f"分类头维度不匹配: 预训练 {pre_shape} vs 当前 {cur_shape}")
                self.logger.warning("将跳过分类头的权重加载")
                # 移除分类头相关的权重
                pretrained_dict = {k: v for k, v in pretrained_dict.items()
                                 if not k.startswith('mlp_head')}

        # 处理位置编码维度不匹配
        if 'pos_embedding' in pretrained_dict and 'pos_embedding' in model_dict:
            pre_shape = pretrained_dict['pos_embedding'].shape
            cur_shape = model_dict['pos_embedding'].shape

            if pre_shape != cur_shape:
                self.logger.warning(f"位置编码维度不匹配: 预训练 {pre_shape} vs 当前 {cur_shape}")
                # 如果只是序列长度不同，尝试插值
                if pre_shape[1] != cur_shape[1] and pre_shape[2:] == cur_shape[2:]:
                    self.logger.info("尝试对位置编码进行插值")
                    import torch.nn.functional as F
                    pretrained_dict['pos_embedding'] = F.interpolate(
                        pretrained_dict['pos_embedding'].unsqueeze(0),
                        size=(cur_shape[1], cur_shape[2], cur_shape[3]),
                        mode='trilinear',
                        align_corners=False
                    ).squeeze(0)
                    self.logger.info("位置编码插值完成")
                else:
                    # 移除位置编码
                    pretrained_dict = {k: v for k, v in pretrained_dict.items()
                                     if k != 'pos_embedding'}
                    self.logger.warning("将跳过位置编码的加载")

        return pretrained_dict

    def _verify_pretrained_loading(self):
        """验证预训练权重加载效果"""
        self.model.eval()
        input_h, input_w = self.config.model.input_shape
        dummy_input = torch.randn(2, 1, input_h, input_w).to(self.device)

        with torch.no_grad():
            output = self.model(dummy_input)
            probs = torch.sigmoid(output)

        self.logger.info(f"预训练权重加载后测试:")
        self.logger.info(f"  输出范围: [{output.min().item():.6f}, {output.max().item():.6f}]")
        self.logger.info(f"  概率范围: [{probs.min().item():.6f}, {probs.max().item():.6f}]")

        # 检查输出层的权重变化
        final_layer = self.model.mlp_head[-1]
        self.logger.info(f"  输出层权重统计:")
        self.logger.info(f"    均值: {final_layer.weight.mean().item():.6f}")
        self.logger.info(f"    标准差: {final_layer.weight.std().item():.6f}")
        self.logger.info(f"    偏置: {final_layer.bias.item():.6f}")

    def apply_freezing(self, freeze_layers: Optional[str] = None, freeze_ratio: Optional[float] = None):
        """
        应用层级冻结

        Args:
            freeze_layers: 指定冻结的层，如 "patch_embedding,transformer:0-5"
            freeze_ratio: 按比例冻结层，0-1之间
        """
        # 先统计总参数数
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)

        self.logger.info(f"冻结前 - 总参数: {total_params:,}, 可训练参数: {trainable_params:,}")

        frozen_count = 0

        # 如果指定了freeze_layers，按层名冻结
        if freeze_layers:
            freeze_config = self._parse_freeze_config(freeze_layers)

            # 冻结patch embedding层
            if freeze_config.get('patch_embedding', False):
                for param in self.model.patch_embedding.parameters():
                    param.requires_grad = False
                    frozen_count += param.numel()
                self.logger.info("已冻结 patch_embedding 层")

            # 冻结transformer层
            transformer_layers = freeze_config.get('transformer', [])
            if transformer_layers:
                for i, layer in enumerate(self.model.transformer.layers):
                    if i in transformer_layers:
                        for param in layer.parameters():
                            param.requires_grad = False
                            frozen_count += param.numel()
                self.logger.info(f"已冻结 transformer 层: {transformer_layers}")

            # 冻结位置编码
            if freeze_config.get('pos_embedding', False):
                if hasattr(self.model, 'pos_embedding') and self.model.pos_embedding is not None:
                    self.model.pos_embedding.requires_grad = False
                    frozen_count += self.model.pos_embedding.numel()
                    self.logger.info("已冻结位置编码")

        # 如果指定了freeze_ratio，按比例冻结
        elif freeze_ratio is not None and 0 < freeze_ratio < 1:
            # 获取所有可训练的参数名称
            all_params = [(name, param) for name, param in self.model.named_parameters()
                         if param.requires_grad and not name.startswith('mlp_head')]

            # 计算需要冻结的层数
            num_layers = len(self.model.transformer.layers)
            freeze_num_layers = int(num_layers * freeze_ratio)

            # 冻结前freeze_num_layers个transformer层
            for i in range(freeze_num_layers):
                for param in self.model.transformer.layers[i].parameters():
                    param.requires_grad = False
                    frozen_count += param.numel()

            # 也冻结patch embedding
            for param in self.model.patch_embedding.parameters():
                param.requires_grad = False
                frozen_count += param.numel()

            self.logger.info(f"按比例 {freeze_ratio:.2%} 冻结了前 {freeze_num_layers} 个 transformer 层和 patch_embedding")

        # 重新计算可训练参数数
        trainable_params_after = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        freeze_ratio_actual = frozen_count / total_params * 100

        self.logger.info(f"冻结后 - 总参数: {total_params:,}, 可训练参数: {trainable_params_after:,}")
        self.logger.info(f"冻结参数: {frozen_count:,} ({freeze_ratio_actual:.2f}%)")
        self.logger.info(f"可训练参数比例: {trainable_params_after/total_params*100:.2f}%")

        # 重新创建优化器（只包含可训练参数）
        self.optimizer = self._create_optimizer()
        self.logger.info("已重新创建优化器，仅包含可训练参数")

    def _parse_freeze_config(self, config_str: str) -> dict:
        """
        解析冻结配置字符串

        Args:
            config_str: 配置字符串，如 "patch_embedding,transformer:0-5"

        Returns:
            解析后的配置字典
        """
        config = {
            'patch_embedding': False,
            'transformer': [],
            'pos_embedding': False
        }

        parts = config_str.split(',')
        for part in parts:
            part = part.strip()

            if part == 'patch_embedding':
                config['patch_embedding'] = True
            elif part == 'pos_embedding':
                config['pos_embedding'] = True
            elif part.startswith('transformer'):
                # 解析transformer:0-5或transformer:0,1,2
                if ':' in part:
                    layer_part = part.split(':')[1]
                    if '-' in layer_part:
                        # 范围
                        start, end = map(int, layer_part.split('-'))
                        config['transformer'] = list(range(start, end + 1))
                    else:
                        # 单个或多个层
                        try:
                            config['transformer'] = [int(x) for x in layer_part.split(',')]
                        except ValueError:
                            self.logger.warning(f"无法解析transformer层配置: {layer_part}")
                else:
                    # 冻结所有transformer层
                    config['transformer'] = list(range(len(self.model.transformer.layers)))

        return config

    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        self.logger.info("开始训练...")
        self.logger.info(f"训练设备: {self.device}")
        self.logger.info(f"训练批次数: {len(train_loader)}")
        self.logger.info(f"验证批次数: {len(val_loader)}")

        verbose = bool(getattr(getattr(self.config, "monitoring", None), "verbose", False))
        console_verbose = bool(getattr(getattr(self.config, "monitoring", None), "console_verbose", False))

        # Set up Rich Live display only when CLI --verbose is passed
        rich_display = None
        _replaced_handler = None
        if console_verbose:
            from rich.logging import RichHandler

            from ..utils.verbose_display import VerboseLiveDisplay, set_active_display, LiveDisplayLogHandler

            rich_display = VerboseLiveDisplay(max_log_lines=30)
            set_active_display(rich_display)

            # Replace RichHandler with LiveDisplayLogHandler so logs appear inside the panel
            live_handler = LiveDisplayLogHandler(rich_display)
            live_handler.setLevel(self.logger.level)
            for handler in list(self.logger.logger.handlers):
                if isinstance(handler, RichHandler):
                    _replaced_handler = handler
                    self.logger.logger.removeHandler(handler)
                    break
            self.logger.logger.addHandler(live_handler)
            self.logger._live_handler = live_handler

            rich_display.start(self.config.training.epochs)

        tracker = EpochProgressTracker(
            total_epochs=self.config.training.epochs,
            early_stopping_config=self.early_stopping_config if self.early_stopping_enabled else None,
            model_selection_config=self.model_selection_config,
            verbose=verbose,
            rich_display=rich_display,
        )

        # Track replaced handler for cleanup
        _saved_rich_handler = _replaced_handler

        train_history = []
        val_history = []
        validation_interval = max(1, int(round(getattr(self.config.experiment, "val_check_interval", 1.0))))
        last_val_metrics = None

        for epoch in range(self.config.training.epochs):
            self.logger.info(f"[bold]Epoch {epoch + 1}/{self.config.training.epochs}[/]")
            self.logger.info("-" * 50)

            start_time = time.time()

            # 在第一个epoch记录数据集样本
            if epoch == 0:
                self._log_dataset_samples(train_loader, epoch)

            train_metrics = self.train_epoch(train_loader, epoch, tracker=tracker)
            should_validate = ((epoch + 1) % validation_interval == 0) or (epoch + 1 == self.config.training.epochs)
            if should_validate:
                val_metrics = self.validate_epoch(val_loader, tracker=tracker)
                last_val_metrics = dict(val_metrics)
            else:
                val_metrics = dict(last_val_metrics or {})
                val_metrics["skipped"] = True

            if self.scheduler:
                # ReduceLROnPlateau需要验证指标作为输入
                if isinstance(self.scheduler, ReduceLROnPlateau):
                    if should_validate:
                        metric_value = val_metrics['loss']
                        self.scheduler.step(metric_value)
                else:
                    self.scheduler.step()

            epoch_time = time.time() - start_time

            train_history.append(train_metrics)
            val_history.append(val_metrics)

            train_parts = [f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in train_metrics.items()]
            self.logger.info(f"train: {' | '.join(train_parts)}")
            val_parts = [f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in val_metrics.items()]
            self.logger.info(f"val:   {' | '.join(val_parts)}")
            if not should_validate:
                self.logger.info(f"本轮跳过验证，val_check_interval={validation_interval}")

            # 如果有患者级别的预测准确度，单独显示
            if 'predict_accuracy' in val_metrics:
                patient_total = val_metrics.get('patient_total', 0)
                patient_correct = val_metrics.get('patient_correct', 0)
                self.logger.info(f"患者级别预测准确度: {val_metrics['predict_accuracy']:.4f} "
                               f"({patient_correct}/{patient_total} 患者)")

            self.logger.info(f"Epoch 时间: {epoch_time:.2f}s")

            # TensorBoard记录每个epoch的指标
            self.tensorboard_logger.log_scalars('Training/Epoch', train_metrics, epoch + 1)
            self.tensorboard_logger.log_scalars('Validation/Epoch', val_metrics, epoch + 1)

            # 记录每个epoch的学习率
            current_lr = self.optimizer.param_groups[0]['lr']
            self.logger.info(f"准备记录epoch {epoch + 1}学习率: {current_lr}")
            self.tensorboard_logger.log_learning_rate(current_lr, epoch + 1, 'Training/EpochLearningRate')
            self.logger.info(f"epoch {epoch + 1}学习率记录完成")

            # 记录模型参数的分布
            for name, param in self.model.named_parameters():
                if param.requires_grad and param.data is not None:
                    self.tensorboard_logger.log_histogram(f'Parameters/{name}', param.data, epoch + 1)
                    if param.grad is not None:
                        self.tensorboard_logger.log_histogram(f'Gradients/{name}', param.grad, epoch + 1)

            current_val_metric = self.best_val_metric
            is_best = False
            metric_name = self._metric_display_name(self.model_selection_config["metric"])
            if should_validate:
                selection_metric = self.model_selection_config["metric"]
                selection_mode = self.model_selection_config["mode"]
                current_val_metric = self._metric_value(val_metrics, selection_metric)
                metric_name = self._metric_display_name(selection_metric)
                if selection_mode == "min":
                    is_best = current_val_metric < self.best_val_metric
                else:
                    is_best = current_val_metric > self.best_val_metric

                if is_best:
                    self.best_val_metric = current_val_metric
                    self.best_epoch = epoch + 1
                    self.logger.info(f"[green]New best: {self.best_val_metric:.4f} ({metric_name}, Epoch {self.best_epoch})[/]")

            self.save_checkpoint(epoch + 1, current_val_metric, is_best)

            # Compute early stopping value for tracker
            early_stop_value = None
            if should_validate:
                early_stopping_metric = self.early_stopping_config["metric"]
                early_stop_value = self._metric_value(val_metrics, early_stopping_metric)

            # Update tracker at end of epoch
            current_lr = self.optimizer.param_groups[0]['lr']
            tracker.finish_epoch(
                epoch + 1, lr=current_lr,
                best_epoch=self.best_epoch, best_metric=self.best_val_metric,
                validated=should_validate,
                esp_counter=self.early_stopping.counter if self.early_stopping_enabled else None,
                esp_metric_value=early_stop_value if self.early_stopping_enabled else None,
            )

            if should_validate and self.early_stopping_enabled and early_stop_value is not None:
                if self.early_stopping(early_stop_value):
                    early_metric_name = self._metric_display_name(self.early_stopping_config["metric"])
                    dp = tracker._decimal_places
                    tracker.mark_early_stopped(
                        epoch + 1,
                        f"patience exhausted at epoch {epoch + 1}, best {early_metric_name}: "
                        f"{self.best_val_metric:.{dp}f} (Epoch {self.best_epoch})",
                    )
                    self.logger.info(f"[bold red]Early stopped[/]: patience exhausted at epoch {epoch + 1}, best {early_metric_name}: {self.best_val_metric:.4f} (Epoch {self.best_epoch})")
                    break

        self.logger.info("[bold green]Training complete[/]")

        metric_name = self._metric_display_name(self.model_selection_config["metric"])

        self.logger.info(f"[bold]Best: {self.best_val_metric:.4f} ({metric_name}, Epoch {self.best_epoch})[/]")

        # 如果监控指标是患者级别预测准确度，提供额外信息
        if self.model_selection_config["metric"] == 'predict_accuracy' and val_history:
            # 找到最佳epoch对应的验证指标
            best_epoch_idx = self.best_epoch - 1  # epoch从1开始，索引从0开始
            if 0 <= best_epoch_idx < len(val_history):
                best_val_metrics = val_history[best_epoch_idx]
                patient_total = best_val_metrics.get('patient_total', 0)
                patient_correct = best_val_metrics.get('patient_correct', 0)

                self.logger.info(f"患者级别预测详情:")
                self.logger.info(f"  最佳患者准确率: {self.best_val_metric:.4f}")
                self.logger.info(f"  正确预测患者数: {patient_correct}")
                self.logger.info(f"  总患者数: {patient_total}")
                self.logger.info(f"  错误预测患者数: {patient_total - patient_correct}")

                # 计算样本级别的准确率进行对比
                sample_accuracy = best_val_metrics.get('accuracy', 0.0)
                self.logger.info(f"  对比样本准确率: {sample_accuracy:.4f}")

                # 如果有详细的患者信息，显示一些错误预测的案例
                if 'patient_details' in best_val_metrics:
                    patient_details = best_val_metrics['patient_details']
                    incorrect_predictions = [p for p in patient_details if not p['correct']]

                    if incorrect_predictions:
                        self.logger.info(f"  错误预测患者示例 (前5个):")
                        for i, patient in enumerate(incorrect_predictions[:5]):
                            self.logger.info(self._format_patient_detail_line(patient))

        # 关闭TensorBoard记录器
        self.tensorboard_logger.close()

        tracker.close()

        # Clean up Rich Live display and restore original RichHandler
        if rich_display is not None:
            from ..utils.verbose_display import set_active_display, LiveDisplayLogHandler
            rich_display.stop()
            set_active_display(None)
            # Remove LiveDisplayLogHandler and restore RichHandler
            for handler in list(self.logger.logger.handlers):
                if isinstance(handler, LiveDisplayLogHandler):
                    self.logger.logger.removeHandler(handler)
                    break
            if _saved_rich_handler is not None:
                self.logger.logger.addHandler(_saved_rich_handler)
            self.logger._live_handler = None

        return train_history, val_history

    def evaluate(self, test_loader: DataLoader) -> Dict[str, float]:
        self.logger.info("开始测试评估...")
        self.model.eval()

        metrics_calculator = MetricsCalculator()
        total_loss = 0.0
        num_batches = len(test_loader)
        verbose = bool(getattr(getattr(self.config, "monitoring", None), "verbose", False))

        with torch.no_grad():
            progress_bar = tqdm(test_loader, desc="测试中", leave=False, disable=not verbose, dynamic_ncols=True)

            for data, targets in progress_bar:
                data = data.to(self.device)
                targets = targets.to(self.device).unsqueeze(1)

                outputs = self.model(data)
                loss = self.criterion(outputs, targets)

                total_loss += loss.item()
                metrics_calculator.update(outputs, targets)

        avg_loss = total_loss / num_batches
        test_metrics = metrics_calculator.compute()
        test_metrics['loss'] = avg_loss

        self._print_test_results_rich(test_metrics)

        confusion_matrix = metrics_calculator.get_confusion_matrix()
        if confusion_matrix is not None:
            self.logger.info("混淆矩阵:")
            self.logger.info(f"  {confusion_matrix}")

        return test_metrics
