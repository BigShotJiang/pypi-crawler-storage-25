from use_computer import Computer

# Beta: Windows sandboxes. No SSH — exec runs in-guest via PowerShell/cmd.
with Computer().create(type="windows") as win:
    win.run("Start-Process notepad")  # PowerShell by default
    win.keyboard.type("hello from use.computer")
    print(win.run("$env:COMPUTERNAME", shell="powershell").stdout)

    png = win.screenshot.take_full_screen()
    open("hello_windows.png", "wb").write(png)
    print(f"saved hello_windows.png ({len(png)} bytes)")
