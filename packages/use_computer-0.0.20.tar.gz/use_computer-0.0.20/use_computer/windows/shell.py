from __future__ import annotations

from typing import Literal

import httpx

from use_computer.models import ExecResult

ShellKind = Literal["powershell", "cmd"]


class Shell:
    """Run commands inside a Windows sandbox via the in-guest agent (no SSH)."""

    def __init__(self, http: httpx.Client, prefix: str):
        self._http = http
        self._prefix = prefix

    def run(self, command: str, shell: ShellKind = "powershell", timeout: int = 300) -> ExecResult:
        resp = self._http.post(
            f"{self._prefix}/exec",
            json={"command": command, "shell": shell},
            timeout=timeout,
        )
        resp.raise_for_status()
        return ExecResult.from_dict(resp.json())

    def powershell(self, command: str, timeout: int = 300) -> ExecResult:
        return self.run(command, "powershell", timeout)

    def cmd(self, command: str, timeout: int = 300) -> ExecResult:
        return self.run(command, "cmd", timeout)


class AsyncShell:
    """Async variant of Shell."""

    def __init__(self, http: httpx.AsyncClient, prefix: str):
        self._http = http
        self._prefix = prefix

    async def run(
        self, command: str, shell: ShellKind = "powershell", timeout: int = 300
    ) -> ExecResult:
        resp = await self._http.post(
            f"{self._prefix}/exec",
            json={"command": command, "shell": shell},
            timeout=timeout,
        )
        resp.raise_for_status()
        return ExecResult.from_dict(resp.json())

    async def powershell(self, command: str, timeout: int = 300) -> ExecResult:
        return await self.run(command, "powershell", timeout)

    async def cmd(self, command: str, timeout: int = 300) -> ExecResult:
        return await self.run(command, "cmd", timeout)
