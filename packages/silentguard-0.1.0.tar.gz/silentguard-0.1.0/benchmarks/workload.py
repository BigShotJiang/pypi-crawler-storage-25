"""Realistic workload for SilentGuard overhead benchmarks."""

from __future__ import annotations

import json
import math


def heavy_compute(x: int) -> float:
    total = 0.0
    for i in range(1, 30):
        total += math.sqrt(i * x + 1) / (i + 1)
    return total


def run_workload(calls: int = 1000) -> float:
    data = {"items": [heavy_compute(i) for i in range(1, calls + 1)]}
    encoded = json.dumps(data)
    decoded = json.loads(encoded)
    return float(sum(decoded["items"]))
