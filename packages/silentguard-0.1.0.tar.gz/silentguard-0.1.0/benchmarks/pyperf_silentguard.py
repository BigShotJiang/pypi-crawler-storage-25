"""pyperf benchmarks for SilentGuard runtime overhead."""

from __future__ import annotations

import importlib

import pyperf

from silentguard.core import GuardConfig, GuardSession


def _import_large_module() -> None:
    importlib.invalidate_caches()
    importlib.import_module("json")
    importlib.import_module("asyncio")
    importlib.import_module("http.client")
    importlib.import_module("logging")


def _calls_plain() -> None:
    from benchmarks.workload import run_workload

    run_workload(1000)


def _calls_guarded() -> None:
    from benchmarks.workload import run_workload

    session = GuardSession(GuardConfig())
    session.start()
    try:
        run_workload(1000)
    finally:
        session.stop()


def _imports_guarded() -> None:
    session = GuardSession(GuardConfig())
    session.start()
    try:
        _import_large_module()
    finally:
        session.stop()


def main() -> None:
    runner = pyperf.Runner()
    runner.bench_func("imports_plain", _import_large_module)
    runner.bench_func("imports_guarded", _imports_guarded)
    runner.bench_func("calls_plain_1000", _calls_plain)
    runner.bench_func("calls_guarded_1000", _calls_guarded)


if __name__ == "__main__":
    main()
