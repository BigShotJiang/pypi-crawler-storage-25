"""
Real pytest tests that demonstrate the --silentguard plugin.

Run with:  silentguard test -- examples/03_pytest_demo.py -v
    or:    pytest --silentguard examples/03_pytest_demo.py -v
"""

import os


def test_payment_processing():
    """Looks like a normal test, but has hidden side effects."""
    # Hidden env mutation
    os.environ["PAYMENT_MODE"] = "sandbox"
    
    # Silent exception suppression
    try:
        amount = int("not_a_number")
    except Exception:
        amount = 0  # Silently defaults to 0 — is this intended?
    
    assert amount == 0  # Test passes! But should it?


def test_config_loader():
    """Config loading that silently swallows parse errors."""
    try:
        config = {"port": int("abc")}  # This raises ValueError
    except Exception:
        config = {"port": 8080}  # Falls back silently
    
    assert config["port"] == 8080  # Passes! But the real config was never loaded.


def test_data_export():
    """Export function that secretly writes to disk."""
    data = [{"name": "Alice", "score": 95}, {"name": "Bob", "score": 87}]
    
    # Hidden file write inside a test!
    with open("test_export.csv", "w") as f:
        for row in data:
            f.write(f"{row['name']},{row['score']}\n")
    
    assert len(data) == 2
    
    # Cleanup (but what if the test fails before this?)
    os.remove("test_export.csv")
