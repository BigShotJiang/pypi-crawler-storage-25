"""
Simulated test suite that uses SilentGuard's @guard() decorator
to catch hidden side effects DURING testing.

Run with:  python examples/02_guarded_tests.py
"""

from silentguard import guard


# ── Example 1: Decorator usage ───────────────────────────────────────
# Wrap any function you're suspicious of. SilentGuard will report
# everything that happens inside.

@guard()
def test_user_creation():
    """This test looks clean but has hidden side effects."""
    import os
    
    # Simulating a function that secretly mutates environment
    os.environ["DB_HOST"] = "test-db.internal"
    
    # Simulating a function that catches errors silently
    try:
        user = create_user("bad-email")
    except Exception:
        pass  # Test passes but the bug is hidden!
    
    print("  ✓ test_user_creation passed")


def create_user(email: str) -> dict:
    """Buggy user creation that silently fails."""
    try:
        if "@" not in email:
            raise ValueError(f"Invalid email: {email}")
        return {"email": email, "created": True}
    except Exception:
        return {"email": email, "created": False}  # Silently returns failure


# ── Example 2: Context manager usage ─────────────────────────────────
# Use as a context manager when you want to inspect events programmatically.

def demo_context_manager():
    """Show how to use guard() as a context manager."""
    print("\n--- Context Manager Demo ---")
    
    with guard(detect_file_io=True, report_format="terminal") as session:
        # These side effects will be captured
        import os
        os.environ["TEMP_FLAG"] = "1"
        
        try:
            result = 1 / 0
        except Exception:
            pass  # Suppressed!
    
    # After the `with` block, you can inspect events programmatically
    print(f"\n  Events captured: {len(session.events)}")
    for ev in session.events:
        print(f"  → [{ev.confidence_label}] {ev.kind_label}: {ev.description}")


# ── Example 3: Selective detection ───────────────────────────────────
# You can disable specific detections to reduce noise.

@guard(
    detect_file_io=False,       # Don't flag file operations
    detect_network=False,       # Don't flag network calls  
    detect_env_mutation=True,   # DO flag env changes
    detect_suppressed_exceptions=True,  # DO flag swallowed exceptions
)
def test_with_selective_detection():
    """Only detect what you care about."""
    import os
    
    # This WILL be flagged (env mutation enabled)
    os.environ["API_KEY"] = "test-key-123"
    
    # This will NOT be flagged (file I/O disabled)
    # open("some_file.txt", "w").close()
    
    try:
        raise RuntimeError("Something broke")
    except Exception:
        pass  # This WILL be flagged (suppression enabled)
    
    print("  ✓ test_with_selective_detection passed")


# ── Run all demos ─────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print(" SilentGuard @guard() Decorator & Context Manager Demo")
    print("=" * 60)
    
    print("\n--- Decorator Demo (full detection) ---")
    test_user_creation()
    
    demo_context_manager()
    
    print("\n--- Selective Detection Demo ---")
    test_with_selective_detection()
    
    print("\n" + "=" * 60)
    print(" All demos complete. Check the reports above!")
    print("=" * 60)
    
    # Cleanup
    import os
    for key in ["DB_HOST", "TEMP_FLAG", "API_KEY"]:
        os.environ.pop(key, None)
