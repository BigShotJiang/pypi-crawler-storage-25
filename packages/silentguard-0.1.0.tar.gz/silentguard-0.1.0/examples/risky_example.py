"""Example file with intentional issues for SilentGuard to detect."""
import os
import socket
import subprocess


def risky_function():
    try:
        result = 1 / 0
    except:
        pass  # bare except with pass

    try:
        data = open("/etc/passwd").read()
    except Exception:
        pass  # broad except with pass

    os.system("echo hello")
    os.environ["DANGER"] = "yes"

    try:
        subprocess.run(["ls"])
    except Exception as e:
        print(f"Error: {e}")


counter = 0


def mutate_global():
    global counter
    counter += 1
