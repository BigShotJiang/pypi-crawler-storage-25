"""
Simulated API service with REAL problems that developers
accidentally ship to production every day.

Run with:  silentguard guard examples/01_api_service.py
"""

import os
import json


# ── Problem 1: Silent data corruption ────────────────────────────────
# Developer catches ALL exceptions and returns empty data instead of
# failing loudly. The caller has NO idea something went wrong.

def fetch_user_profile(user_id: int) -> dict:
    """Fetch user profile from database."""
    try:
        # Simulate a database query that fails
        if user_id > 100:
            raise ConnectionError("Database connection pool exhausted")
        return {"id": user_id, "name": "Alice", "email": "alice@example.com"}
    except Exception:
        # BUG: Silently returns empty dict — caller thinks user doesn't exist
        return {}


# ── Problem 2: Hidden environment mutation ───────────────────────────
# A utility function silently changes environment variables that
# affect other parts of the application.

def configure_logging(level: str = "INFO") -> None:
    """Configure application logging."""
    os.environ["LOG_LEVEL"] = level
    os.environ["LOG_FORMAT"] = "json"
    # These mutations persist for the entire process!


# ── Problem 3: Unexpected file I/O in a "pure" function ──────────────
# This function looks like a pure data transform but secretly
# writes to disk on every call.

def process_order(order: dict) -> dict:
    """Process an order and return the result."""
    total = order.get("quantity", 0) * order.get("price", 0)
    
    # BUG: Hidden side effect — writes to a file on every call
    with open("order_log.txt", "a") as f:
        f.write(json.dumps({"order": order, "total": total}) + "\n")
    
    return {"status": "processed", "total": total}


# ── Problem 4: Swallowed validation errors ───────────────────────────
# Input validation errors are caught and ignored, allowing bad
# data to flow through the system.

def validate_email(email: str) -> bool:
    """Validate an email address."""
    try:
        if "@" not in email:
            raise ValueError(f"Invalid email: {email}")
        if "." not in email.split("@")[1]:
            raise ValueError(f"Invalid domain in: {email}")
        return True
    except Exception:
        # BUG: Returns True even for invalid emails!
        return True


# ── Simulate the application running ─────────────────────────────────

def main():
    print("=== API Service Starting ===\n")
    
    # This silently returns {} instead of raising
    profile = fetch_user_profile(999)
    print(f"User profile: {profile}")
    
    # This mutates env vars as a side effect
    configure_logging("DEBUG")
    print(f"Log level set to: {os.environ.get('LOG_LEVEL')}")
    
    # This secretly writes to disk
    result = process_order({"item": "Widget", "quantity": 5, "price": 9.99})
    print(f"Order result: {result}")
    
    # This validates "not-an-email" as valid!
    is_valid = validate_email("not-an-email")
    print(f"Email valid: {is_valid}")
    
    print("\n=== Service ran 'successfully' — but 4 bugs are hiding ===")


if __name__ == "__main__":
    main()
