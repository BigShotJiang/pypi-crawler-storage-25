import os

try:
    {}["missing"]
except KeyError:
    pass

os.environ["SG_MIN_CONF_VERIFY"] = "1"
