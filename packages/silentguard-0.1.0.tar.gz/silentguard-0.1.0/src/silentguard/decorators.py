"""Public ``guard`` decorator / context-manager for SilentGuard.

Usage::

    from silentguard import guard

    @guard()
    def my_function():
        ...

    # Or as a context manager:
    with guard() as session:
        do_something()
        print(session.events)
"""

from __future__ import annotations

import functools
from typing import Any, Callable, TypeVar, overload

from .core import GuardConfig, GuardSession
from .reporter import create_reporter

F = TypeVar("F", bound=Callable[..., Any])


class guard:
    """Decorator and context-manager that instruments a code region.

    Parameters match ``GuardConfig`` fields – anything not supplied gets its
    default value.

    As a decorator::

        @guard(detect_file_io=False)
        def clean_function():
            ...

    As a context manager::

        with guard(report_format="markdown", output_path="report.md") as session:
            risky_work()
    """

    def __init__(self, **kwargs: Any) -> None:
        self._config = GuardConfig(**kwargs)
        self._session: GuardSession | None = None

    # ── Decorator protocol ────────────────────────────────────────────

    @overload
    def __call__(self, func: F) -> F: ...

    @overload
    def __call__(self, *args: Any, **kwargs: Any) -> Any: ...

    def __call__(self, func: Any = None, *args: Any, **kwargs: Any) -> Any:
        if func is None:
            raise TypeError("guard() must be used as @guard() with parentheses")

        if not callable(func):
            raise TypeError(
                f"guard() expected a callable, got {type(func).__name__}"
            )

        @functools.wraps(func)
        def wrapper(*a: Any, **kw: Any) -> Any:
            with self._make_context():
                return func(*a, **kw)

        return wrapper  # type: ignore[return-value]

    # ── Context-manager protocol ──────────────────────────────────────

    def __enter__(self) -> GuardSession:
        ctx = self._make_context()
        return ctx.__enter__()

    def __exit__(self, *exc_info: Any) -> bool:
        if self._session is not None:
            self._session.stop()
            self._report(self._session)
            self._session = None
        return False

    # ── Internal helpers ──────────────────────────────────────────────

    def _make_context(self) -> _GuardContext:
        return _GuardContext(self._config, self)

    def _report(self, session: GuardSession) -> None:
        """Emit a report if there are events to report."""
        if not session.events:
            return
        reporter = create_reporter(session.config.report_format)
        reporter.report(session.events, session.summary())


class _GuardContext:
    """Thin wrapper that manages session lifecycle for a ``with`` block."""

    def __init__(self, config: GuardConfig, owner: guard) -> None:
        self._config = config
        self._owner = owner
        self._session: GuardSession | None = None

    def __enter__(self) -> GuardSession:
        self._session = GuardSession(self._config)
        self._session.start()
        self._owner._session = self._session
        return self._session

    def __exit__(self, *exc_info: Any) -> bool:
        if self._session is not None:
            self._session.stop()
            self._owner._report(self._session)
            self._session = None
            self._owner._session = None
        return False
