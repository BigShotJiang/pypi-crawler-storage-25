"""Allow ``python -m silentguard`` to invoke the CLI."""

from silentguard.cli import app

if __name__ == "__main__":
    app()
