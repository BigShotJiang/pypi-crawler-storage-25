"""SilentGuard version metadata."""

__version__ = "0.1.0"
