"""SilentGuard — detect silent failures and runtime side effects.

Public API
----------
* ``guard``   – decorator / context-manager that instruments a code region.
* ``GuardSession``  – lower-level session object.
* ``GuardConfig``   – configuration dataclass.
* ``GuardEvent``    – a single detected event.
* ``EventKind``     – enumeration of event categories.
* ``Confidence``    – HIGH / MEDIUM / LOW confidence levels.
"""

from .core import GuardConfig, GuardSession
from .decorators import guard
from .utils import Confidence, EventKind, GuardEvent

__all__ = [
    "guard",
    "GuardSession",
    "GuardConfig",
    "GuardEvent",
    "EventKind",
    "Confidence",
]
