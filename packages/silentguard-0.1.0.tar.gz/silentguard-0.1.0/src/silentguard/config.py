"""Configuration loading for SilentGuard."""

from __future__ import annotations

import os
from typing import Any

import tomllib

from .utils import Confidence, GuardConfig


def discover_config_path(start_dir: str | None = None) -> str | None:
    current = os.path.abspath(start_dir or os.getcwd())
    while True:
        candidate = os.path.join(current, ".silentguardrc")
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            return None
        current = parent


def load_guard_config(config_path: str | None) -> GuardConfig:
    if not config_path:
        return GuardConfig()

    with open(config_path, "rb") as f:
        raw: dict[str, Any] = tomllib.load(f)

    cfg = GuardConfig()
    _apply_runtime_flags(cfg, raw)
    _apply_allow_flags(cfg, raw)
    _apply_filter_flags(cfg, raw)
    _apply_category_flags(cfg, raw)
    return cfg


def discover_and_load_config(start_dir: str | None = None) -> GuardConfig:
    return load_guard_config(discover_config_path(start_dir))


def merge_cli_overrides(
    base: GuardConfig,
    *,
    report_format: str | None = None,
    output_path: str | None = None,
    no_trace: bool | None = None,
    min_confidence: str | Confidence | None = None,
) -> GuardConfig:
    cfg = GuardConfig(**vars(base))
    if report_format is not None:
        cfg.report_format = report_format
    if output_path is not None:
        cfg.output_path = output_path
    if no_trace:
        cfg.detect_suppressed_exceptions = False
    if min_confidence is not None:
        cfg.min_confidence = (
            _parse_confidence(min_confidence)
            if isinstance(min_confidence, str)
            else min_confidence
        )
    return cfg


def _apply_runtime_flags(cfg: GuardConfig, raw: dict[str, Any]) -> None:
    sources = [raw, raw.get("runtime", {})]
    bool_keys = [
        "detect_suppressed_exceptions",
        "detect_file_io",
        "detect_network",
        "detect_subprocess",
        "detect_env_mutation",
        "detect_global_mutation",
        "detect_threading",
        "detect_asyncio",
    ]
    for src in sources:
        if not isinstance(src, dict):
            continue
        for key in bool_keys:
            value = src.get(key)
            if isinstance(value, bool):
                setattr(cfg, key, value)


def _apply_allow_flags(cfg: GuardConfig, raw: dict[str, Any]) -> None:
    allow = raw.get("allow", {})
    sources = [allow, raw]
    for src in sources:
        if not isinstance(src, dict):
            continue

        files = src.get("allowed_file_patterns")
        hosts = src.get("allowed_network_hosts")
        if src is allow:
            files = files or src.get("files")
            hosts = hosts or src.get("network_hosts") or src.get("hosts")

        if isinstance(files, list):
            cfg.allowed_file_patterns = [str(x) for x in files]
        if isinstance(hosts, list):
            cfg.allowed_network_hosts = [str(x) for x in hosts]


def _apply_filter_flags(cfg: GuardConfig, raw: dict[str, Any]) -> None:
    for src in (raw.get("filters", {}), raw.get("ignore", {}), raw):
        if not isinstance(src, dict):
            continue
        files = src.get("ignore_file_patterns") or src.get("files")
        funcs = src.get("ignore_function_patterns") or src.get("functions")
        min_conf = src.get("min_confidence")

        if isinstance(files, list):
            cfg.ignore_file_patterns = [str(x) for x in files]
        if isinstance(funcs, list):
            cfg.ignore_function_patterns = [str(x) for x in funcs]
        if isinstance(min_conf, str):
            cfg.min_confidence = _parse_confidence(min_conf)


def _apply_category_flags(cfg: GuardConfig, raw: dict[str, Any]) -> None:
    categories = raw.get("categories", {})
    if not isinstance(categories, dict):
        return

    disabled_events = categories.get("disabled_events") or categories.get("disabled_event_categories")
    disabled_scan = categories.get("disabled_scan") or categories.get("disabled_scan_categories")
    if isinstance(disabled_events, list):
        cfg.disabled_event_categories = [str(x) for x in disabled_events]
    if isinstance(disabled_scan, list):
        cfg.disabled_scan_categories = [str(x) for x in disabled_scan]

    events_table = categories.get("events", {})
    if isinstance(events_table, dict):
        for key, enabled in events_table.items():
            if enabled is False and key not in cfg.disabled_event_categories:
                cfg.disabled_event_categories.append(str(key))

    scan_table = categories.get("scan", {})
    if isinstance(scan_table, dict):
        for key, enabled in scan_table.items():
            if enabled is False and key not in cfg.disabled_scan_categories:
                cfg.disabled_scan_categories.append(str(key))


def _parse_confidence(value: str) -> Confidence:
    v = value.strip().lower()
    if v == "high":
        return Confidence.HIGH
    if v == "medium":
        return Confidence.MEDIUM
    return Confidence.LOW
