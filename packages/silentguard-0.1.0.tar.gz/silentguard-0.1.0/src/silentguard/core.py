"""Core session management and static source scanner for SilentGuard.

``GuardSession`` orchestrates runtime event collection by receiving
dispatched events from the hooks module and recording ``GuardEvent`` objects.

``SourceScanner`` performs AST-based static analysis to surface likely
risk areas without executing any code.
"""

from __future__ import annotations

import ast
import os
import threading
import time
from pathlib import Path
from typing import Any

from .utils import (
    Confidence,
    EventKind,
    GuardConfig,
    GuardEvent,
    ScanFinding,
    SourceLocation,
    capture_stack_summary,
    classify_exception_confidence,
    confidence_meets_threshold,
    function_matches_any,
    is_silentguard_frame,
    is_stdlib_path,
    path_matches_any,
)


# ═══════════════════════════════════════════════════════════════════════
#  GuardSession – runtime event collection
# ═══════════════════════════════════════════════════════════════════════


class GuardSession:
    """A single instrumentation session that collects guard events.

    Typical lifecycle::

        session = GuardSession(config)
        session.start()
        # ... run target code ...
        session.stop()
        print(session.events)
    """

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config: GuardConfig = config or GuardConfig()
        self._events: list[GuardEvent] = []
        self._lock = threading.Lock()
        self._active: bool = False
        self._start_time: float = 0.0
        self._end_time: float = 0.0
        # frame-id → (exc_type_name, exc_repr) for suppressed-exception detection
        self._pending_exceptions: dict[int, tuple[str, str]] = {}
        self._suppressed_events_by_frame: dict[int, GuardEvent] = {}
        self._async_frames_by_thread: dict[int, set[int]] = {}

    # ── Properties ────────────────────────────────────────────────────

    @property
    def events(self) -> list[GuardEvent]:
        """Return a snapshot of collected events (thread-safe copy)."""
        with self._lock:
            return list(self._events)

    @property
    def is_active(self) -> bool:
        return self._active

    @property
    def duration(self) -> float:
        """Elapsed wall-clock seconds for this session."""
        if self._start_time == 0.0:
            return 0.0
        end = self._end_time if self._end_time > 0.0 else time.monotonic()
        return end - self._start_time

    # ── Lifecycle ─────────────────────────────────────────────────────

    def start(self) -> None:
        """Activate the session and begin collecting events."""
        from .hooks import register_session

        self._active = True
        self._start_time = time.monotonic()
        register_session(self)

    def stop(self) -> None:
        """Deactivate the session and stop collecting events."""
        from .hooks import unregister_session

        self._active = False
        self._end_time = time.monotonic()
        unregister_session(self)

    def record_event(self, event: GuardEvent) -> None:
        """Append an event (thread-safe)."""
        if event.kind.value in self.config.disabled_event_categories:
            return
        if not confidence_meets_threshold(event.confidence, self.config.min_confidence):
            return
        if path_matches_any(event.location.file, self.config.ignore_file_patterns):
            return
        if function_matches_any(event.location.function, self.config.ignore_function_patterns):
            return
        with self._lock:
            self._events.append(event)

    # ── Audit-hook handlers ───────────────────────────────────────────

    def handle_audit_event(self, event: str, args: tuple[Any, ...]) -> None:
        """Dispatch an ``sys.addaudithook`` event to per-kind handlers."""
        if not self._active:
            return

        handlers: dict[str, Any] = {
            "open": (self.config.detect_file_io, self._on_file_open),
            "socket.connect": (self.config.detect_network, self._on_network),
            "socket.getaddrinfo": (self.config.detect_network, self._on_network),
            "subprocess.Popen": (self.config.detect_subprocess, self._on_subprocess),
            "os.system": (self.config.detect_subprocess, self._on_subprocess),
            "os.putenv": (self.config.detect_env_mutation, self._on_env_mutation),
            "os.unsetenv": (self.config.detect_env_mutation, self._on_env_mutation),
            "_thread.start_new_thread": (
                self.config.detect_threading,
                self._on_thread_spawn,
            ),
        }

        entry = handlers.get(event)
        if entry is None:
            return
        enabled, handler = entry
        if enabled:
            handler(event, args)

    # -- File I/O --

    _NOISY_SUFFIXES: frozenset[str] = frozenset(
        {".pyc", ".pyo", ".pyd", ".so", ".dll", ".dylib"}
    )

    def _on_file_open(self, event: str, args: tuple[Any, ...]) -> None:
        if len(args) < 1:
            return
        path = str(args[0]) if args[0] is not None else ""
        if not path:
            return

        # Filter noise: compiled extensions and SilentGuard internals.
        if any(path.endswith(s) for s in self._NOISY_SUFFIXES):
            return
        if is_silentguard_frame(path):
            return
        for pattern in self.config.allowed_file_patterns:
            if pattern in path:
                return

        mode = str(args[1]) if len(args) > 1 and args[1] is not None else "r"
        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return  # internal/stdlib-only activity

        self.record_event(
            GuardEvent(
                kind=EventKind.FILE_IO,
                description=f"File opened: {path!s} (mode={mode})",
                confidence=Confidence.MEDIUM if "r" in mode else Confidence.HIGH,
                timestamp=time.time(),
                location=SourceLocation(file=path),
                stack_summary=stack,
                details={"path": path, "mode": mode},
            )
        )

    # -- Network --

    def _on_network(self, event: str, args: tuple[Any, ...]) -> None:
        if event == "socket.connect":
            addr = str(args[1]) if len(args) > 1 else str(args)
            desc = f"Network connection to {addr}"
        else:
            addr = str(args[0]) if args else "<unknown>"
            desc = f"DNS lookup: {addr}"

        for host in self.config.allowed_network_hosts:
            if host in addr:
                return

        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.NETWORK_CALL,
                description=desc,
                confidence=Confidence.HIGH,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"event": event, "address": addr},
            )
        )

    # -- Subprocess --

    def _on_subprocess(self, event: str, args: tuple[Any, ...]) -> None:
        cmd = str(args[0]) if args else "<unknown>"
        label = "Subprocess executed" if event == "subprocess.Popen" else "os.system() called"
        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.SUBPROCESS_EXEC,
                description=f"{label}: {cmd}",
                confidence=Confidence.HIGH,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"command": cmd},
            )
        )

    # -- Environment variable mutation --

    def _on_env_mutation(self, event: str, args: tuple[Any, ...]) -> None:
        key = str(args[0]) if args else "<unknown>"
        if event == "os.putenv":
            value = str(args[1]) if len(args) > 1 else "<unknown>"
            desc = f"Environment variable set: {key}={value}"
        else:
            value = None
            desc = f"Environment variable unset: {key}"

        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.ENV_MUTATION,
                description=desc,
                confidence=Confidence.HIGH,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"key": key, "value": value, "action": event},
            )
        )

    # -- Thread spawning --

    def _on_thread_spawn(self, event: str, args: tuple[Any, ...]) -> None:
        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.THREAD_SPAWN,
                description="New thread started",
                confidence=Confidence.MEDIUM,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"event": event},
            )
        )

    # ── Trace-hook handlers (suppressed exceptions) ───────────────────

    def handle_exception_raised(
        self,
        frame_id: int,
        exc_type_name: str,
        exc_repr: str,
        filename: str | None,
        lineno: int | None,
        funcname: str | None,
    ) -> None:
        """Record a pending exception for later suppression analysis."""
        if not self._active or not self.config.detect_suppressed_exceptions:
            return
        if is_silentguard_frame(filename) or is_stdlib_path(filename):
            return
        self._pending_exceptions[frame_id] = (exc_type_name, exc_repr)

    def handle_frame_return(
        self,
        frame_id: int,
        filename: str | None,
        lineno: int | None,
        funcname: str | None,
    ) -> None:
        """If a pending exception exists for this frame it was caught → record."""
        pending = self._pending_exceptions.pop(frame_id, None)
        if pending is None:
            return
        exc_type_name, exc_repr = pending
        confidence = classify_exception_confidence(exc_type_name)
        if confidence is None:
            return

        event = GuardEvent(
            kind=EventKind.SUPPRESSED_EXCEPTION,
            description=f"Exception caught and suppressed: {exc_type_name}: {exc_repr}",
            confidence=confidence,
            timestamp=time.time(),
            location=SourceLocation(file=filename, line=lineno, function=funcname),
            stack_summary=[],
            details={"exception_type": exc_type_name, "exception_repr": exc_repr},
        )
        self.record_event(event)
        self._suppressed_events_by_frame[frame_id] = event

    def handle_frame_exception_propagated(self, frame_id: int) -> None:
        """Exception propagated out of the frame – not suppressed."""
        self._pending_exceptions.pop(frame_id, None)
        event = self._suppressed_events_by_frame.pop(frame_id, None)
        if event is None:
            return
        with self._lock:
            try:
                self._events.remove(event)
            except ValueError:
                pass

    def handle_frame_exception_settled(self, frame_id: int) -> None:
        """Exception outcome finalized; release correlation bookkeeping."""
        self._suppressed_events_by_frame.pop(frame_id, None)

    # ── Asyncio instrumentation handlers ───────────────────────────────

    def handle_asyncio_frame_enter(self, frame_id: int) -> None:
        if not self._active or not self.config.detect_asyncio:
            return
        tid = threading.get_ident()
        frames = self._async_frames_by_thread.setdefault(tid, set())
        frames.add(frame_id)

    def handle_asyncio_frame_exit(self, frame_id: int) -> None:
        if not self.config.detect_asyncio:
            return
        tid = threading.get_ident()
        frames = self._async_frames_by_thread.get(tid)
        if not frames:
            return
        frames.discard(frame_id)
        if not frames:
            self._async_frames_by_thread.pop(tid, None)

    def _in_async_context(self) -> bool:
        tid = threading.get_ident()
        frames = self._async_frames_by_thread.get(tid)
        return bool(frames)

    def handle_asyncio_audit_event(self, event: str, args: tuple[Any, ...]) -> None:
        if not self._active or not self.config.detect_asyncio:
            return
        if not self._in_async_context():
            return

        if event == "time.sleep":
            stack = capture_stack_summary(skip_frames=4)
            if not stack:
                return
            self.record_event(
                GuardEvent(
                    kind=EventKind.ASYNCIO_SIDE_EFFECT,
                    description="Blocking call inside async function: time.sleep",
                    confidence=Confidence.HIGH,
                    timestamp=time.time(),
                    location=SourceLocation(),
                    stack_summary=stack,
                    details={"event": event},
                )
            )
            return

        if event == "open":
            path = str(args[0]) if args else "<unknown>"
            stack = capture_stack_summary(skip_frames=4)
            if not stack:
                return
            self.record_event(
                GuardEvent(
                    kind=EventKind.ASYNCIO_SIDE_EFFECT,
                    description=f"Synchronous file I/O inside async function: open({path})",
                    confidence=Confidence.MEDIUM,
                    timestamp=time.time(),
                    location=SourceLocation(file=path),
                    stack_summary=stack,
                    details={"event": event, "path": path},
                )
            )

    def handle_asyncio_task_created(self, api_name: str, coro_repr: str) -> None:
        if not self._active or not self.config.detect_asyncio:
            return
        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.ASYNCIO_SIDE_EFFECT,
                description=f"Async task created via {api_name}",
                confidence=Confidence.MEDIUM,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"api": api_name, "coro": coro_repr[:200]},
            )
        )

    def handle_asyncio_loop_manipulation(self, operation: str) -> None:
        if not self._active or not self.config.detect_asyncio:
            return
        stack = capture_stack_summary(skip_frames=4)
        if not stack:
            return
        self.record_event(
            GuardEvent(
                kind=EventKind.ASYNCIO_SIDE_EFFECT,
                description=f"Event loop manipulation detected: {operation}",
                confidence=Confidence.MEDIUM,
                timestamp=time.time(),
                location=SourceLocation(),
                stack_summary=stack,
                details={"operation": operation},
            )
        )

    # ── Summary ───────────────────────────────────────────────────────

    def summary(self) -> dict[str, Any]:
        """Return an aggregate summary suitable for reporters."""
        events = self.events
        by_kind: dict[str, int] = {}
        by_confidence: dict[str, int] = {}
        for ev in events:
            by_kind[ev.kind.value] = by_kind.get(ev.kind.value, 0) + 1
            by_confidence[ev.confidence.value] = by_confidence.get(ev.confidence.value, 0) + 1

        return {
            "total_events": len(events),
            "by_kind": by_kind,
            "by_confidence": by_confidence,
            "duration_seconds": round(self.duration, 4),
        }


# ═══════════════════════════════════════════════════════════════════════
#  SourceScanner – AST-based static analysis
# ═══════════════════════════════════════════════════════════════════════


# Patterns considered risky in function calls.
_DANGEROUS_CALL_NAMES: frozenset[str] = frozenset(
    {
        "exec",
        "eval",
        "compile",
        "os.system",
        "os.popen",
        "subprocess.run",
        "subprocess.Popen",
        "subprocess.call",
        "subprocess.check_output",
        "subprocess.check_call",
    }
)

_NETWORK_MODULES: frozenset[str] = frozenset(
    {"socket", "urllib", "http", "requests", "httpx", "aiohttp", "urllib3"}
)


class _RiskVisitor(ast.NodeVisitor):
    """AST visitor that collects ``ScanFinding`` objects."""

    def __init__(self, filepath: str, source_lines: list[str]) -> None:
        self.filepath = filepath
        self.source_lines = source_lines
        self.findings: list[ScanFinding] = []
        self._function_stack: list[str] = []

    def _snippet(self, lineno: int) -> str:
        idx = lineno - 1
        if 0 <= idx < len(self.source_lines):
            return self.source_lines[idx].rstrip()
        return ""

    def _current_function(self) -> str | None:
        return self._function_stack[-1] if self._function_stack else None

    def _is_ignored_line(self, lineno: int) -> bool:
        snippet = self._snippet(lineno)
        return "# silentguard: ignore" in snippet

    # -- Exception handling --

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        if self._is_ignored_line(node.lineno):
            self.generic_visit(node)
            return

        lineno = node.lineno
        col = node.col_offset
        if node.type is None:
            self.findings.append(
                ScanFinding(
                    file=self.filepath,
                    line=lineno,
                    col=col,
                    category="bare_except",
                    description="Bare `except:` catches all exceptions including "
                    "KeyboardInterrupt and SystemExit.",
                    confidence=Confidence.HIGH,
                    snippet=self._snippet(lineno),
                    function=self._current_function(),
                )
            )
        elif isinstance(node.type, ast.Name) and node.type.id in (
            "Exception",
            "BaseException",
        ):
            body_is_pass = (
                len(node.body) == 1 and isinstance(node.body[0], ast.Pass)
            )
            body_is_ellipsis = (
                len(node.body) == 1
                and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and node.body[0].value.value is ...
            )
            if body_is_pass or body_is_ellipsis:
                self.findings.append(
                    ScanFinding(
                        file=self.filepath,
                        line=lineno,
                        col=col,
                        category="silent_broad_except",
                        description=f"Broad `except {node.type.id}` with no handling "
                        f"(pass/...) silently swallows errors.",
                        confidence=Confidence.HIGH,
                        snippet=self._snippet(lineno),
                        function=self._current_function(),
                    )
                )
            else:
                self.findings.append(
                    ScanFinding(
                        file=self.filepath,
                        line=lineno,
                        col=col,
                        category="broad_except",
                        description=f"Broad `except {node.type.id}` may hide unexpected errors.",
                        confidence=Confidence.MEDIUM,
                        snippet=self._snippet(lineno),
                        function=self._current_function(),
                    )
                )
        self.generic_visit(node)

    # -- Dangerous calls --

    def visit_Call(self, node: ast.Call) -> None:
        if self._is_ignored_line(node.lineno):
            self.generic_visit(node)
            return

        name = self._resolve_call_name(node.func)
        if name and name in _DANGEROUS_CALL_NAMES:
            self.findings.append(
                ScanFinding(
                    file=self.filepath,
                    line=node.lineno,
                    col=node.col_offset,
                    category="dangerous_call",
                    description=f"Call to `{name}()` may execute arbitrary code or start "
                    f"a subprocess.",
                    confidence=Confidence.HIGH,
                    snippet=self._snippet(node.lineno),
                    function=self._current_function(),
                )
            )
        self.generic_visit(node)

    # -- Global statement --

    def visit_Global(self, node: ast.Global) -> None:
        if self._is_ignored_line(node.lineno):
            self.generic_visit(node)
            return

        names = ", ".join(node.names)
        self.findings.append(
            ScanFinding(
                file=self.filepath,
                line=node.lineno,
                col=node.col_offset,
                category="global_mutation",
                description=f"`global {names}` — function mutates module-level state.",
                confidence=Confidence.MEDIUM,
                snippet=self._snippet(node.lineno),
                function=self._current_function(),
            )
        )
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._function_stack.append(node.name)
        self.generic_visit(node)
        self._function_stack.pop()

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._function_stack.append(node.name)
        self.generic_visit(node)
        self._function_stack.pop()

    # -- Imports of network / subprocess modules --

    def visit_Import(self, node: ast.Import) -> None:
        if self._is_ignored_line(node.lineno):
            self.generic_visit(node)
            return

        for alias in node.names:
            base = alias.name.split(".")[0]
            if base in _NETWORK_MODULES:
                self.findings.append(
                    ScanFinding(
                        file=self.filepath,
                        line=node.lineno,
                        col=node.col_offset,
                        category="network_import",
                        description=f"Import of networking module `{alias.name}`.",
                        confidence=Confidence.LOW,
                        snippet=self._snippet(node.lineno),
                        function=self._current_function(),
                    )
                )
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if self._is_ignored_line(node.lineno):
            self.generic_visit(node)
            return

        if node.module:
            base = node.module.split(".")[0]
            if base in _NETWORK_MODULES:
                self.findings.append(
                    ScanFinding(
                        file=self.filepath,
                        line=node.lineno,
                        col=node.col_offset,
                        category="network_import",
                        description=f"Import from networking module `{node.module}`.",
                        confidence=Confidence.LOW,
                        snippet=self._snippet(node.lineno),
                        function=self._current_function(),
                    )
                )
        self.generic_visit(node)

    # -- Helpers --

    @staticmethod
    def _resolve_call_name(node: ast.expr) -> str | None:
        """Best-effort extraction of a dotted call name from an AST node."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            value_name = _RiskVisitor._resolve_call_name(node.value)
            if value_name:
                return f"{value_name}.{node.attr}"
        return None


class SourceScanner:
    """Scan Python source files for common risk patterns via AST analysis.

    This is a best-effort heuristic scanner — it does **not** execute code
    and cannot detect dynamic patterns.
    """

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config = config or GuardConfig()

    def scan_file(self, filepath: str) -> list[ScanFinding]:
        """Scan a single Python file and return findings."""
        if path_matches_any(filepath, self.config.ignore_file_patterns):
            return []

        try:
            source = Path(filepath).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            return [
                ScanFinding(
                    file=filepath,
                    line=0,
                    col=0,
                    category="parse_error",
                    description=f"Could not read file: {exc}",
                    confidence=Confidence.LOW,
                )
            ]

        try:
            tree = ast.parse(source, filename=filepath)
        except SyntaxError as exc:
            return [
                ScanFinding(
                    file=filepath,
                    line=exc.lineno or 0,
                    col=exc.offset or 0,
                    category="syntax_error",
                    description=f"Syntax error: {exc.msg}",
                    confidence=Confidence.LOW,
                )
            ]

        lines = source.splitlines()
        visitor = _RiskVisitor(filepath, lines)
        visitor.visit(tree)
        findings = visitor.findings
        findings = [
            f
            for f in findings
            if f.category not in self.config.disabled_scan_categories
            and confidence_meets_threshold(f.confidence, self.config.min_confidence)
            and not function_matches_any(f.function, self.config.ignore_function_patterns)
        ]
        return findings

    def scan_directory(self, dirpath: str) -> list[ScanFinding]:
        """Recursively scan a directory for Python files."""
        all_findings: list[ScanFinding] = []
        root = Path(dirpath)
        for py_file in sorted(root.rglob("*.py")):
            # Skip common non-user directories.
            parts = py_file.parts
            if any(
                p in {".git", "__pycache__", ".tox", ".venv", "venv", "node_modules", ".eggs"}
                for p in parts
            ):
                continue
            all_findings.extend(self.scan_file(str(py_file)))
        return all_findings

    def scan(self, target: str) -> list[ScanFinding]:
        """Scan a file or directory."""
        p = Path(target)
        if p.is_file():
            return self.scan_file(str(p))
        if p.is_dir():
            return self.scan_directory(str(p))
        return [
            ScanFinding(
                file=target,
                line=0,
                col=0,
                category="not_found",
                description=f"Target not found: {target}",
                confidence=Confidence.HIGH,
            )
        ]
