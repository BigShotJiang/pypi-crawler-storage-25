"""pytest plugin for SilentGuard.

Registered via the ``pytest11`` entry-point in ``pyproject.toml`` so that
``pytest`` auto-discovers it when SilentGuard is installed.

Enable with ``--silentguard`` on the pytest command line, or via the
``silentguard test`` CLI wrapper.
"""

from __future__ import annotations

from typing import Any, Generator
from dataclasses import replace

import pytest

from .config import discover_and_load_config, merge_cli_overrides
from .core import GuardSession
from .reporter import create_reporter


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("silentguard", "SilentGuard runtime diagnostics")
    group.addoption(
        "--silentguard",
        action="store_true",
        default=False,
        help="Enable SilentGuard instrumentation during tests.",
    )
    group.addoption(
        "--sg-format",
        type=str,
        default="terminal",
        help="Report format: terminal | markdown | html (default: terminal).",
    )
    group.addoption(
        "--sg-output",
        type=str,
        default=None,
        help="Write the aggregate report to this file.",
    )
    group.addoption(
        "--sg-fail-on",
        type=str,
        default=None,
        help="Fail if SilentGuard detects confidence >= threshold (high|medium).",
    )
    group.addoption(
        "--sg-min-confidence",
        type=str,
        default=None,
        help="Hide events below this confidence threshold (low|medium|high).",
    )


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "silentguard: enable SilentGuard on a test")
    if config.getoption("silentguard", default=False):
        plugin = SilentGuardPlugin(config)
        config.pluginmanager.register(plugin, "silentguard-plugin")


class SilentGuardPlugin:
    """Wraps each test in a ``GuardSession`` and aggregates results."""

    def __init__(self, config: pytest.Config) -> None:
        self._config = config
        self._all_events: list[tuple[str, list[Any]]] = []  # (nodeid, events)
        base = discover_and_load_config(str(config.rootpath))
        self._guard_config = merge_cli_overrides(
            base,
            report_format=config.getoption("sg_format", "terminal"),
            output_path=config.getoption("sg_output", None),
            min_confidence=config.getoption("sg_min_confidence", None),
        )
        self._fail_on = config.getoption("sg_fail_on", None)

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_call(self, item: pytest.Item) -> Generator[None, None, None]:
        session = GuardSession(replace(self._guard_config))
        session.start()
        try:
            yield
        finally:
            session.stop()
            events = session.events
            if events:
                self._all_events.append((item.nodeid, events))

    def pytest_terminal_summary(
        self,
        terminalreporter: Any,
        exitstatus: int,
        config: pytest.Config,
    ) -> None:
        if not self._all_events:
            terminalreporter.write_line("")
            terminalreporter.write_line(
                "SilentGuard: ✓ No runtime side effects detected.", green=True
            )
            return

        fmt = self._guard_config.report_format
        output_path = self._guard_config.output_path
        reporter = create_reporter(fmt)

        # Flatten events with test-id context.
        flat_events: list[Any] = []
        for nodeid, events in self._all_events:
            for ev in events:
                ev.details["test"] = nodeid
                flat_events.append(ev)

        summary = {
            "total_events": len(flat_events),
            "by_kind": _count_by(flat_events, lambda e: e.kind.value),
            "by_confidence": _count_by(flat_events, lambda e: e.confidence.value),
            "duration_seconds": 0,
            "tests_with_events": len(self._all_events),
        }

        text = reporter.report(flat_events, summary, output_path=output_path)

        if fmt == "terminal":
            pass  # Rich already printed
        elif output_path:
            terminalreporter.write_line(f"\nSilentGuard report written to {output_path}")
        else:
            terminalreporter.write_line(text)

        if self._fail_on:
            should_fail = False
            for ev in flat_events:
                label = ev.confidence.value
                if self._fail_on == "high" and label == "high":
                    should_fail = True
                    break
                if self._fail_on == "medium" and label in {"high", "medium"}:
                    should_fail = True
                    break
            if should_fail:
                terminalreporter._session.exitstatus = 1


def _count_by(events: list[Any], key_fn: Any) -> dict[str, int]:
    counts: dict[str, int] = {}
    for ev in events:
        k = key_fn(ev)
        counts[k] = counts.get(k, 0) + 1
    return counts
