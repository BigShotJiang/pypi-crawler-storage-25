"""Shared data structures, enumerations, and helper functions for SilentGuard."""

from __future__ import annotations

import os
import sysconfig
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from fnmatch import fnmatch
from functools import lru_cache
from typing import Any


# ── Enumerations ─────────────────────────────────────────────────────


class EventKind(Enum):
    """Categories of detected runtime events."""

    SUPPRESSED_EXCEPTION = "suppressed_exception"
    FILE_IO = "file_io"
    NETWORK_CALL = "network_call"
    SUBPROCESS_EXEC = "subprocess_exec"
    ENV_MUTATION = "env_mutation"
    GLOBAL_STATE_MUTATION = "global_state_mutation"
    THREAD_SPAWN = "thread_spawn"
    ASYNCIO_SIDE_EFFECT = "asyncio_side_effect"


class Confidence(Enum):
    """Confidence level for a detected event.

    HIGH   – strong structural evidence the behaviour is problematic.
    MEDIUM – heuristic match; may be intentional but worth reviewing.
    LOW    – weak signal; common in normal code but flagged for awareness.
    """

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# ── Data classes ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class SourceLocation:
    """A location in source code."""

    file: str | None = None
    line: int | None = None
    function: str | None = None

    def __str__(self) -> str:
        parts: list[str] = []
        if self.file:
            parts.append(self.file)
        if self.line is not None:
            parts.append(f"line {self.line}")
        if self.function:
            parts.append(f"in {self.function}()")
        return ", ".join(parts) if parts else "<unknown location>"


@dataclass
class GuardEvent:
    """A single runtime event detected by SilentGuard."""

    kind: EventKind
    description: str
    confidence: Confidence
    timestamp: float
    location: SourceLocation
    stack_summary: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def kind_label(self) -> str:
        return self.kind.value.replace("_", " ").title()

    @property
    def confidence_label(self) -> str:
        return self.confidence.value.upper()


@dataclass
class ScanFinding:
    """A single finding from static source analysis."""

    file: str
    line: int
    col: int
    category: str
    description: str
    confidence: Confidence
    snippet: str = ""
    function: str | None = None


@dataclass
class GuardConfig:
    """Configuration for a guard session."""

    detect_suppressed_exceptions: bool = True
    detect_file_io: bool = True
    detect_network: bool = True
    detect_subprocess: bool = True
    detect_env_mutation: bool = True
    detect_global_mutation: bool = True
    detect_threading: bool = True
    detect_asyncio: bool = True

    # Allow-lists: substrings that suppress matching events.
    allowed_file_patterns: list[str] = field(default_factory=list)
    allowed_network_hosts: list[str] = field(default_factory=list)

    # Generic ignore/filter controls.
    ignore_file_patterns: list[str] = field(default_factory=list)
    ignore_function_patterns: list[str] = field(default_factory=list)
    disabled_event_categories: list[str] = field(default_factory=list)
    disabled_scan_categories: list[str] = field(default_factory=list)
    min_confidence: Confidence = Confidence.LOW

    # Output
    report_format: str = "terminal"
    output_path: str | None = None


# ── Exception classification ─────────────────────────────────────────

# Exceptions that are part of normal Python control flow – never flag.
CONTROL_FLOW_EXCEPTIONS: frozenset[str] = frozenset(
    {
        "StopIteration",
        "StopAsyncIteration",
        "GeneratorExit",
        "KeyboardInterrupt",
        "SystemExit",
    }
)

# Exceptions frequently caught intentionally – flag at LOW confidence.
COMMONLY_INTENTIONAL: frozenset[str] = frozenset(
    {
        "KeyError",
        "IndexError",
        "AttributeError",
        "TypeError",
        "FileNotFoundError",
        "FileExistsError",
        "ImportError",
        "ModuleNotFoundError",
        "NotImplementedError",
        "LookupError",
        "UnicodeDecodeError",
        "UnicodeEncodeError",
        "json.JSONDecodeError",
        "JSONDecodeError",
    }
)


def classify_exception_confidence(exc_type_name: str) -> Confidence | None:
    """Classify how suspicious a suppressed exception is.

    Returns ``None`` when the exception is normal control flow and should
    be silently ignored.
    """
    if exc_type_name in CONTROL_FLOW_EXCEPTIONS:
        return None
    if exc_type_name in ("Exception", "BaseException"):
        return Confidence.HIGH
    if exc_type_name in COMMONLY_INTENTIONAL:
        return Confidence.LOW
    return Confidence.MEDIUM


# ── Stack helpers ────────────────────────────────────────────────────


def is_silentguard_frame(filename: str | None) -> bool:
    """Return True if *filename* belongs to SilentGuard internals."""
    if filename is None:
        return False
    normalised = filename.replace("\\", "/")
    return "/silentguard/" in normalised


@lru_cache(maxsize=1)
def _stdlib_roots() -> tuple[str, ...]:
    roots: set[str] = set()
    for key in ("stdlib", "platstdlib"):
        root = sysconfig.get_path(key)
        if not root:
            continue
        roots.add(_normalise_path(root).rstrip("/"))
    return tuple(sorted(roots))


def is_stdlib_path(filename: str | None) -> bool:
    """Return True when *filename* belongs to the Python stdlib.

    ``site-packages`` and ``dist-packages`` are excluded so third-party
    dependencies still appear in reports when they are part of a user-driven
    call path.
    """
    if filename is None:
        return False
    if filename.startswith("<frozen "):
        return True

    normalised = _normalise_path(filename)
    if "/site-packages/" in normalised or "/dist-packages/" in normalised:
        return False

    for root in _stdlib_roots():
        if normalised == root or normalised.startswith(f"{root}/"):
            return True
    return False


def capture_stack_summary(skip_frames: int = 2, max_frames: int = 8) -> list[str]:
    """Capture a compact call-stack summary, omitting internal noise."""
    raw = traceback.extract_stack()
    relevant = raw[: -skip_frames] if skip_frames < len(raw) else raw
    relevant = [
        f for f in relevant
        if not is_silentguard_frame(f.filename) and not is_stdlib_path(f.filename)
    ]
    relevant = relevant[-max_frames:]
    return [f"  {fr.filename}:{fr.lineno} in {fr.name}" for fr in relevant]


# ── Formatting helpers ───────────────────────────────────────────────


def format_timestamp(ts: float) -> str:
    """Format an epoch timestamp for human display (UTC)."""
    dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def confidence_meets_threshold(confidence: Confidence, threshold: Confidence) -> bool:
    order = {Confidence.LOW: 1, Confidence.MEDIUM: 2, Confidence.HIGH: 3}
    return order[confidence] >= order[threshold]


def path_matches_any(path: str | None, patterns: list[str]) -> bool:
    if not path or not patterns:
        return False
    normalised = path.replace("\\", "/")
    basename = normalised.rsplit("/", 1)[-1]
    return any(fnmatch(normalised, p) or fnmatch(basename, p) for p in patterns)


def function_matches_any(funcname: str | None, patterns: list[str]) -> bool:
    if not funcname or not patterns:
        return False
    return any(fnmatch(funcname, p) for p in patterns)


def _normalise_path(path: str) -> str:
    return os.path.normcase(os.path.realpath(path)).replace("\\", "/")
