"""System hook installation and session routing for SilentGuard.

This module manages:

* A **single global** ``sys.addaudithook`` callback (cannot be removed once
  installed – this is a CPython constraint, not a SilentGuard design choice).
* A ``sys.settrace`` callback for detecting suppressed exceptions.

Both hooks are no-ops when no ``GuardSession`` is registered, keeping
overhead near-zero outside active instrumentation windows.
"""

from __future__ import annotations

import asyncio
import inspect
import sys
import threading
from typing import Any, TYPE_CHECKING

from .utils import is_silentguard_frame, is_stdlib_path

if TYPE_CHECKING:
    from types import FrameType
    from .core import GuardSession

# ═══════════════════════════════════════════════════════════════════════
#  Shared state
# ═══════════════════════════════════════════════════════════════════════

_sessions: dict[int, GuardSession] = {}
_sessions_lock = threading.Lock()

_audit_hook_installed: bool = False

# Re-entrancy guard – prevents our own hook from triggering recursive events.
_in_hook: threading.local = threading.local()

# ═══════════════════════════════════════════════════════════════════════
#  Audit hook
# ═══════════════════════════════════════════════════════════════════════


def _audit_hook(event: str, args: tuple[Any, ...]) -> None:
    """Global audit-hook dispatcher.

    Called by CPython for every auditable operation.  When no sessions are
    active the fast-path ``if not _sessions`` exits in < 50 ns.
    """
    if not _sessions:
        return
    if getattr(_in_hook, "active", False):
        return  # prevent recursion
    _in_hook.active = True
    try:
        with _sessions_lock:
            active = list(_sessions.values())
        for session in active:
            try:
                session.handle_audit_event(event, args)
                session.handle_asyncio_audit_event(event, args)
            except Exception:
                # Instrumentation must never break the target process.
                pass
    finally:
        _in_hook.active = False


def _ensure_audit_hook() -> None:
    """Install the global audit hook exactly once (idempotent)."""
    global _audit_hook_installed
    if _audit_hook_installed:
        return
    sys.addaudithook(_audit_hook)
    _audit_hook_installed = True


# ═══════════════════════════════════════════════════════════════════════
#  Trace hook (suppressed-exception detection)
# ═══════════════════════════════════════════════════════════════════════

_trace_sessions: dict[int, GuardSession] = {}
_trace_lock = threading.Lock()
_original_trace: Any = None
_trace_backend: str | None = None

_HAS_MONITORING = hasattr(sys, "monitoring")
_MONITORING_TOOL_ID = getattr(sys.monitoring, "PROFILER_ID", 2) if _HAS_MONITORING else 0
_monitoring_active: bool = False

_CO_ASYNC_FRAME_FLAGS = inspect.CO_COROUTINE | inspect.CO_ASYNC_GENERATOR

_asyncio_hooks_installed: bool = False
_original_asyncio_create_task: Any = None
_original_asyncio_ensure_future: Any = None
_original_asyncio_new_event_loop: Any = None
_original_asyncio_set_event_loop: Any = None
_original_loop_set_debug: Any = None
_original_loop_close: Any = None
_original_loop_stop: Any = None


class _TraceState:
    def __init__(self) -> None:
        self.frame_exception_types: dict[int, str] = {}
        self.waiting_children: dict[int, list[tuple[int, str, str, int, str]]] = {}


_trace_state_local = threading.local()


class _MonitoringFrame:
    def __init__(self, frame_id: int, code: Any) -> None:
        self.frame_id = frame_id
        self.code = code
        self.filename = code.co_filename
        self.funcname = code.co_name
        self.lineno = getattr(code, "co_firstlineno", 0) or 0


class _MonitoringState:
    def __init__(self) -> None:
        self.next_id = 1
        self.stack: list[_MonitoringFrame] = []
        self.by_code: dict[Any, list[_MonitoringFrame]] = {}


_monitoring_state_local = threading.local()


def _ensure_trace_state() -> _TraceState:
    state = getattr(_trace_state_local, "state", None)
    if state is None:
        state = _TraceState()
        _trace_state_local.state = state
    return state


def _ensure_monitoring_state() -> _MonitoringState:
    state = getattr(_monitoring_state_local, "state", None)
    if state is None:
        state = _MonitoringState()
        _monitoring_state_local.state = state
    return state


def _monitoring_enter(code: Any) -> _MonitoringFrame:
    state = _ensure_monitoring_state()
    frame = _MonitoringFrame(state.next_id, code)
    state.next_id += 1
    state.stack.append(frame)
    state.by_code.setdefault(code, []).append(frame)
    return frame


def _monitoring_get_current(code: Any) -> _MonitoringFrame | None:
    state = _ensure_monitoring_state()
    lst = state.by_code.get(code)
    if lst:
        return lst[-1]
    return None


def _monitoring_pop(code: Any) -> _MonitoringFrame | None:
    state = _ensure_monitoring_state()
    if not state.stack:
        return None
    frame = state.stack.pop()
    lst = state.by_code.get(frame.code)
    if lst:
        lst.pop()
        if not lst:
            state.by_code.pop(frame.code, None)
    return frame


def _monitoring_parent_id() -> int | None:
    state = _ensure_monitoring_state()
    if not state.stack:
        return None
    return state.stack[-1].frame_id


def _local_trace(frame: FrameType, event: str, arg: Any) -> Any:
    """Per-frame trace function — receives exception / return / line events.

    To reduce false positives, this hook correlates child-frame ``return``
    events with parent-frame ``exception`` events. If a child frame returns
    after raising and the parent then receives the same exception type, the
    child exception is treated as propagated (re-raised), not suppressed.
    """
    if not _trace_sessions:
        return _local_trace

    state = _ensure_trace_state()
    frame_id = id(frame)
    parent_frame = frame.f_back
    parent_frame_id = id(parent_frame) if parent_frame is not None else None
    filename = frame.f_code.co_filename
    funcname = frame.f_code.co_name
    lineno = frame.f_lineno

    if event == "exception" and arg is not None:
        exc_type, exc_value, _tb = arg
        exc_type_name = exc_type.__name__ if exc_type else "Unknown"
        exc_repr = str(exc_value)[:200] if exc_value else ""
        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_exception_raised(
                        frame_id, exc_type_name, exc_repr, filename, lineno, funcname,
                    )
                except Exception:
                    pass

        state.frame_exception_types[frame_id] = exc_type_name
        waiting = state.waiting_children.get(frame_id)
        if waiting:
            for idx in range(len(waiting) - 1, -1, -1):
                child_frame_id, child_exc_type, _, _, _ = waiting[idx]
                if child_exc_type != exc_type_name:
                    continue

                waiting.pop(idx)
                if not waiting:
                    state.waiting_children.pop(frame_id, None)

                with _trace_lock:
                    for session in _trace_sessions.values():
                        try:
                            session.handle_frame_exception_propagated(child_frame_id)
                        except Exception:
                            pass
                break
    elif event == "return":
        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_asyncio_frame_exit(frame_id)
                except Exception:
                    pass

        state.waiting_children.pop(frame_id, None)

        exc_type_name = state.frame_exception_types.pop(frame_id, None)
        if exc_type_name is not None:
            with _trace_lock:
                for session in _trace_sessions.values():
                    try:
                        session.handle_frame_return(frame_id, filename, lineno, funcname)
                    except Exception:
                        pass

            if parent_frame_id is not None:
                waiting = state.waiting_children.setdefault(parent_frame_id, [])
                waiting.append((frame_id, exc_type_name, filename, lineno, funcname))
            else:
                with _trace_lock:
                    for session in _trace_sessions.values():
                        try:
                            session.handle_frame_exception_settled(frame_id)
                        except Exception:
                            pass
            return _local_trace

        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_frame_return(frame_id, filename, lineno, funcname)
                except Exception:
                    pass

        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_frame_exception_settled(frame_id)
                except Exception:
                    pass

    return _local_trace


def _monitoring_on_start(code: Any, offset: int) -> None:
    _ = offset
    if not _trace_sessions:
        return
    if is_silentguard_frame(code.co_filename) or is_stdlib_path(code.co_filename):
        return

    frame = _monitoring_enter(code)
    if code.co_flags & _CO_ASYNC_FRAME_FLAGS:
        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_asyncio_frame_enter(frame.frame_id)
                except Exception:
                    pass


def _monitoring_on_raise(code: Any, offset: int, exc: Any) -> None:
    if not _trace_sessions:
        return
    frame = _monitoring_get_current(code)
    if frame is None:
        return

    exc_type_name = type(exc).__name__ if exc is not None else "Unknown"
    exc_repr = str(exc)[:200] if exc is not None else ""
    state = _ensure_trace_state()
    state.frame_exception_types[frame.frame_id] = exc_type_name

    with _trace_lock:
        for session in _trace_sessions.values():
            try:
                session.handle_exception_raised(
                    frame.frame_id,
                    exc_type_name,
                    exc_repr,
                    frame.filename,
                    frame.lineno,
                    frame.funcname,
                )
            except Exception:
                pass

    waiting = state.waiting_children.get(frame.frame_id)
    if waiting:
        for idx in range(len(waiting) - 1, -1, -1):
            child_frame_id, child_exc_type, _, _, _ = waiting[idx]
            if child_exc_type != exc_type_name:
                continue
            waiting.pop(idx)
            if not waiting:
                state.waiting_children.pop(frame.frame_id, None)
            with _trace_lock:
                for session in _trace_sessions.values():
                    try:
                        session.handle_frame_exception_propagated(child_frame_id)
                    except Exception:
                        pass
            break


def _monitoring_on_return(code: Any, offset: int, value: Any) -> None:
    _ = offset
    _ = value
    if not _trace_sessions:
        _monitoring_pop(code)
        return

    frame = _monitoring_pop(code)
    if frame is None:
        return

    state = _ensure_trace_state()

    with _trace_lock:
        for session in _trace_sessions.values():
            try:
                session.handle_asyncio_frame_exit(frame.frame_id)
            except Exception:
                pass

    state.waiting_children.pop(frame.frame_id, None)
    exc_type_name = state.frame_exception_types.pop(frame.frame_id, None)

    if exc_type_name is not None:
        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_frame_return(frame.frame_id, frame.filename, frame.lineno, frame.funcname)
                except Exception:
                    pass

        parent_id = _monitoring_parent_id()
        if parent_id is not None:
            waiting = state.waiting_children.setdefault(parent_id, [])
            waiting.append((frame.frame_id, exc_type_name, frame.filename, frame.lineno, frame.funcname))
        else:
            with _trace_lock:
                for session in _trace_sessions.values():
                    try:
                        session.handle_frame_exception_settled(frame.frame_id)
                    except Exception:
                        pass
        return

    with _trace_lock:
        for session in _trace_sessions.values():
            try:
                session.handle_frame_return(frame.frame_id, frame.filename, frame.lineno, frame.funcname)
            except Exception:
                pass

    with _trace_lock:
        for session in _trace_sessions.values():
            try:
                session.handle_frame_exception_settled(frame.frame_id)
            except Exception:
                pass


def _global_trace(frame: FrameType, event: str, arg: Any) -> Any:
    """Global trace function — installs ``_local_trace`` on non-internal frames."""
    if event != "call":
        return None

    filename = frame.f_code.co_filename
    # Skip SilentGuard internals and stdlib noise to reduce overhead.
    if is_silentguard_frame(filename) or is_stdlib_path(filename):
        return None

    if frame.f_code.co_flags & _CO_ASYNC_FRAME_FLAGS:
        frame_id = id(frame)
        with _trace_lock:
            for session in _trace_sessions.values():
                try:
                    session.handle_asyncio_frame_enter(frame_id)
                except Exception:
                    pass

    return _local_trace


def _for_each_trace_session(callback: Any) -> None:
    with _trace_lock:
        active = list(_trace_sessions.values())
    for session in active:
        try:
            callback(session)
        except Exception:
            pass


def _install_asyncio_hooks() -> None:
    global _asyncio_hooks_installed
    global _original_asyncio_create_task
    global _original_asyncio_ensure_future
    global _original_asyncio_new_event_loop
    global _original_asyncio_set_event_loop
    global _original_loop_set_debug
    global _original_loop_close
    global _original_loop_stop

    if _asyncio_hooks_installed:
        return

    _original_asyncio_create_task = asyncio.create_task
    _original_asyncio_ensure_future = asyncio.ensure_future
    _original_asyncio_new_event_loop = asyncio.new_event_loop
    _original_asyncio_set_event_loop = asyncio.set_event_loop
    _original_loop_set_debug = asyncio.BaseEventLoop.set_debug
    _original_loop_close = asyncio.BaseEventLoop.close
    _original_loop_stop = asyncio.BaseEventLoop.stop

    def _create_task_wrapper(coro: Any, *args: Any, **kwargs: Any) -> Any:
        coro_repr = repr(coro)
        _for_each_trace_session(
            lambda session: session.handle_asyncio_task_created("asyncio.create_task", coro_repr)
        )
        return _original_asyncio_create_task(coro, *args, **kwargs)

    def _ensure_future_wrapper(coro_or_future: Any, *args: Any, **kwargs: Any) -> Any:
        coro_repr = repr(coro_or_future)
        _for_each_trace_session(
            lambda session: session.handle_asyncio_task_created("asyncio.ensure_future", coro_repr)
        )
        return _original_asyncio_ensure_future(coro_or_future, *args, **kwargs)

    def _new_event_loop_wrapper() -> Any:
        _for_each_trace_session(
            lambda session: session.handle_asyncio_loop_manipulation("asyncio.new_event_loop")
        )
        return _original_asyncio_new_event_loop()

    def _set_event_loop_wrapper(loop: Any) -> None:
        operation = "asyncio.set_event_loop(None)" if loop is None else "asyncio.set_event_loop(loop)"
        _for_each_trace_session(
            lambda session: session.handle_asyncio_loop_manipulation(operation)
        )
        _original_asyncio_set_event_loop(loop)

    def _loop_set_debug_wrapper(self: Any, enabled: bool) -> None:
        _for_each_trace_session(
            lambda session: session.handle_asyncio_loop_manipulation(f"loop.set_debug({enabled})")
        )
        _original_loop_set_debug(self, enabled)

    def _loop_close_wrapper(self: Any) -> None:
        _for_each_trace_session(
            lambda session: session.handle_asyncio_loop_manipulation("loop.close()")
        )
        _original_loop_close(self)

    def _loop_stop_wrapper(self: Any) -> None:
        _for_each_trace_session(
            lambda session: session.handle_asyncio_loop_manipulation("loop.stop()")
        )
        _original_loop_stop(self)

    asyncio.create_task = _create_task_wrapper
    asyncio.ensure_future = _ensure_future_wrapper
    asyncio.new_event_loop = _new_event_loop_wrapper
    asyncio.set_event_loop = _set_event_loop_wrapper
    asyncio.BaseEventLoop.set_debug = _loop_set_debug_wrapper
    asyncio.BaseEventLoop.close = _loop_close_wrapper
    asyncio.BaseEventLoop.stop = _loop_stop_wrapper

    _asyncio_hooks_installed = True


def _uninstall_asyncio_hooks() -> None:
    global _asyncio_hooks_installed

    if not _asyncio_hooks_installed:
        return

    asyncio.create_task = _original_asyncio_create_task
    asyncio.ensure_future = _original_asyncio_ensure_future
    asyncio.new_event_loop = _original_asyncio_new_event_loop
    asyncio.set_event_loop = _original_asyncio_set_event_loop
    asyncio.BaseEventLoop.set_debug = _original_loop_set_debug
    asyncio.BaseEventLoop.close = _original_loop_close
    asyncio.BaseEventLoop.stop = _original_loop_stop

    _asyncio_hooks_installed = False


def _install_trace() -> None:
    """Install the global + per-frame trace functions."""
    global _original_trace
    global _trace_backend
    global _monitoring_active

    if _HAS_MONITORING and hasattr(sys.monitoring.events, "RAISE"):
        try:
            sys.monitoring.use_tool_id(_MONITORING_TOOL_ID, "silentguard")
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_START, _monitoring_on_start)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.RAISE, _monitoring_on_raise)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.RERAISE, _monitoring_on_raise)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_RETURN, _monitoring_on_return)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_UNWIND, _monitoring_on_return)
            event_set = (
                sys.monitoring.events.PY_START
                | sys.monitoring.events.RAISE
                | sys.monitoring.events.RERAISE
                | sys.monitoring.events.PY_RETURN
                | sys.monitoring.events.PY_UNWIND
            )
            sys.monitoring.set_events(_MONITORING_TOOL_ID, event_set)
            _trace_backend = "monitoring"
            _monitoring_active = True
        except Exception:
            _monitoring_active = False
            _trace_backend = None

    if _trace_backend != "monitoring":
        _original_trace = sys.gettrace()
        sys.settrace(_global_trace)
        threading.settrace(_global_trace)
        _trace_backend = "trace"

    _install_asyncio_hooks()


def _uninstall_trace() -> None:
    """Restore whatever trace function was active before we started."""
    global _original_trace
    global _trace_backend
    global _monitoring_active

    if _trace_backend == "monitoring" and _monitoring_active:
        try:
            sys.monitoring.set_events(_MONITORING_TOOL_ID, 0)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_START, None)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.RAISE, None)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.RERAISE, None)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_RETURN, None)
            sys.monitoring.register_callback(_MONITORING_TOOL_ID, sys.monitoring.events.PY_UNWIND, None)
            sys.monitoring.free_tool_id(_MONITORING_TOOL_ID)
        except Exception:
            pass
        _monitoring_active = False
        _trace_backend = None

    if _trace_backend == "trace" or _trace_backend is None:
        sys.settrace(_original_trace)
        threading.settrace(_original_trace)  # type: ignore[arg-type]
        _original_trace = None
        _trace_backend = None

    _uninstall_asyncio_hooks()


# ═══════════════════════════════════════════════════════════════════════
#  Session registration
# ═══════════════════════════════════════════════════════════════════════


def register_session(session: GuardSession) -> None:
    """Register *session* so it receives hook events."""
    sid = id(session)
    _ensure_audit_hook()
    with _sessions_lock:
        _sessions[sid] = session
    with _trace_lock:
        need_trace = not _trace_sessions
        _trace_sessions[sid] = session
    if need_trace:
        _install_trace()


def unregister_session(session: GuardSession) -> None:
    """Remove *session* from event routing."""
    sid = id(session)
    with _sessions_lock:
        _sessions.pop(sid, None)
    with _trace_lock:
        _trace_sessions.pop(sid, None)
        remove_trace = not _trace_sessions
    if remove_trace:
        _uninstall_trace()
