"""Report formatters for SilentGuard."""

from __future__ import annotations

import html as html_mod
import json
import os
from abc import ABC, abstractmethod
from typing import Any

from .utils import Confidence, GuardEvent, ScanFinding, format_timestamp


class BaseReporter(ABC):
    @abstractmethod
    def report(self, events: list[GuardEvent], summary: dict[str, Any], output_path: str | None = None) -> str:
        ...

    @abstractmethod
    def report_scan(self, findings: list[ScanFinding], output_path: str | None = None) -> str:
        ...

    def _write(self, content: str, output_path: str | None) -> None:
        if output_path:
            os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as fh:
                fh.write(content)


_CONF_STYLE: dict[Confidence, str] = {
    Confidence.HIGH: "bold red",
    Confidence.MEDIUM: "bold yellow",
    Confidence.LOW: "cyan",
}


class TerminalReporter(BaseReporter):
    def report(self, events: list[GuardEvent], summary: dict[str, Any], output_path: str | None = None) -> str:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table

        console = Console(record=True, force_terminal=True)

        total = summary.get("total_events", 0)
        duration = summary.get("duration_seconds", 0)
        high = summary.get("by_confidence", {}).get("high", 0)
        medium = summary.get("by_confidence", {}).get("medium", 0)
        low = summary.get("by_confidence", {}).get("low", 0)

        header_lines = [
            f"[bold]Events detected:[/] {total}",
            f"[bold red]HIGH[/] {high}  [bold yellow]MEDIUM[/] {medium}  [cyan]LOW[/] {low}",
            f"[dim]Duration: {duration:.3f}s[/]",
        ]
        console.print(
            Panel(
                "\n".join(header_lines),
                title="[bold magenta]⚡ SilentGuard Report[/]",
                border_style="magenta",
                expand=False,
            )
        )

        if not events:
            console.print("[green]✓ No issues detected.[/]")
            text = console.export_text()
            self._write(text, output_path)
            return text

        table = Table(show_header=True, header_style="bold", border_style="dim", title="Detected Events", expand=True)
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("Kind", min_width=18)
        table.add_column("Confidence", justify="center", width=12)
        table.add_column("Description", ratio=2)
        table.add_column("Location", ratio=1)

        for idx, ev in enumerate(events, 1):
            style = _CONF_STYLE.get(ev.confidence, "")
            table.add_row(str(idx), ev.kind_label, f"[{style}]{ev.confidence_label}[/]", ev.description, str(ev.location))

        console.print(table)

        for idx, ev in enumerate(events, 1):
            if ev.stack_summary:
                console.print(f"\n[dim]#{idx} stack trace:[/]\n" + "\n".join(f"  [dim]{line}[/]" for line in ev.stack_summary))

        text = console.export_text()
        self._write(text, output_path)
        return text

    def report_scan(self, findings: list[ScanFinding], output_path: str | None = None) -> str:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table

        console = Console(record=True, force_terminal=True)

        high = sum(1 for f in findings if f.confidence == Confidence.HIGH)
        medium = sum(1 for f in findings if f.confidence == Confidence.MEDIUM)
        low = sum(1 for f in findings if f.confidence == Confidence.LOW)

        header_lines = [
            f"[bold]Findings:[/] {len(findings)}",
            f"[bold red]HIGH[/] {high}  [bold yellow]MEDIUM[/] {medium}  [cyan]LOW[/] {low}",
        ]
        console.print(Panel("\n".join(header_lines), title="[bold magenta]🔍 SilentGuard Audit[/]", border_style="magenta", expand=False))

        if not findings:
            console.print("[green]✓ No risk patterns detected.[/]")
            text = console.export_text()
            self._write(text, output_path)
            return text

        table = Table(show_header=True, header_style="bold", expand=True)
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("File", ratio=1)
        table.add_column("Line", width=6, justify="right")
        table.add_column("Category", min_width=16)
        table.add_column("Confidence", justify="center", width=12)
        table.add_column("Description", ratio=2)

        for idx, f in enumerate(findings, 1):
            style = _CONF_STYLE.get(f.confidence, "")
            table.add_row(str(idx), f.file, str(f.line), f.category, f"[{style}]{f.confidence.value.upper()}[/]", f.description)

        console.print(table)
        text = console.export_text()
        self._write(text, output_path)
        return text


class MarkdownReporter(BaseReporter):
    def report(self, events: list[GuardEvent], summary: dict[str, Any], output_path: str | None = None) -> str:
        lines: list[str] = ["# SilentGuard Report\n"]

        total = summary.get("total_events", 0)
        duration = summary.get("duration_seconds", 0)
        by_conf = summary.get("by_confidence", {})
        lines.append("## Summary\n")
        lines.append(f"- **Total events:** {total}")
        lines.append(f"- **Duration:** {duration:.3f}s")
        lines.append(f"- **HIGH:** {by_conf.get('high', 0)} · **MEDIUM:** {by_conf.get('medium', 0)} · **LOW:** {by_conf.get('low', 0)}\n")

        if not events:
            lines.append("> ✅ No issues detected.\n")
            content = "\n".join(lines)
            self._write(content, output_path)
            return content

        lines.append("## Events\n")
        lines.append("| # | Kind | Confidence | Description | Location |")
        lines.append("|---|------|------------|-------------|----------|")
        for idx, ev in enumerate(events, 1):
            loc = str(ev.location).replace("|", "\\|")
            desc = ev.description.replace("|", "\\|")
            lines.append(f"| {idx} | {ev.kind_label} | {ev.confidence_label} | {desc} | {loc} |")

        lines.append("\n## Details\n")
        for idx, ev in enumerate(events, 1):
            lines.append(f"### Event #{idx}: {ev.kind_label}\n")
            lines.append(f"- **Confidence:** {ev.confidence_label}")
            lines.append(f"- **Time:** {format_timestamp(ev.timestamp)}")
            lines.append(f"- **Location:** {ev.location}")
            lines.append(f"- **Description:** {ev.description}")
            if ev.stack_summary:
                lines.append("\n```")
                lines.extend(ev.stack_summary)
                lines.append("```\n")
            else:
                lines.append("")

        content = "\n".join(lines)
        self._write(content, output_path)
        return content

    def report_scan(self, findings: list[ScanFinding], output_path: str | None = None) -> str:
        lines: list[str] = ["# SilentGuard Audit Report\n"]
        lines.append(f"**Findings:** {len(findings)}\n")

        if not findings:
            lines.append("> ✅ No risk patterns detected.\n")
            content = "\n".join(lines)
            self._write(content, output_path)
            return content

        lines.append("| # | File | Line | Category | Confidence | Description |")
        lines.append("|---|------|------|----------|------------|-------------|")
        for idx, f in enumerate(findings, 1):
            desc = f.description.replace("|", "\\|")
            lines.append(f"| {idx} | {f.file} | {f.line} | {f.category} | {f.confidence.value.upper()} | {desc} |")

        content = "\n".join(lines)
        self._write(content, output_path)
        return content


_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SilentGuard Report</title>
<style>
:root {
  --bg: #0f1117;
  --surface: #1a1d27;
  --border: #2d3148;
  --text: #e4e6f0;
  --text-dim: #6b7080;
  --high: #ff4d6a;
  --medium: #ffaa2a;
  --low: #4da6ff;
  --accent: #7c5cff;
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.6;
  padding: 2rem;
}
h1 { color: var(--accent); margin-bottom: .5rem; }
.summary {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.5rem;
  margin: 1rem 0 2rem;
  display: flex; gap: 2rem; flex-wrap: wrap;
}
.summary .stat { text-align: center; }
.stat .value { font-size: 2rem; font-weight: 700; }
.stat .label { font-size: .85rem; color: var(--text-dim); }
.high { color: var(--high); }
.medium { color: var(--medium); }
.low { color: var(--low); }
table {
  width: 100%;
  border-collapse: collapse;
  margin: 1.5rem 0;
  background: var(--surface);
  border-radius: 12px;
  overflow: hidden;
}
th, td {
  padding: .75rem 1rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
}
th { background: rgba(124,92,255,.15); font-weight: 600; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,.03); }
details {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  margin: .5rem 0;
  padding: .75rem 1rem;
}
summary { cursor: pointer; font-weight: 600; }
pre {
  background: #12131a;
  padding: .75rem;
  border-radius: 6px;
  overflow-x: auto;
  font-size: .85rem;
  margin-top: .5rem;
  color: var(--text-dim);
}
.badge {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 999px;
  font-size: .75rem;
  font-weight: 700;
  text-transform: uppercase;
}
.badge.high { background: rgba(255,77,106,.15); color: var(--high); }
.badge.medium { background: rgba(255,170,42,.15); color: var(--medium); }
.badge.low { background: rgba(77,166,255,.15); color: var(--low); }
footer {
  margin-top: 3rem;
  color: var(--text-dim);
  font-size: .8rem;
  text-align: center;
}
</style>
</head>
<body>
<h1>⚡ SilentGuard Report</h1>
{body}
<footer>Generated by SilentGuard · best-effort runtime diagnostics</footer>
</body>
</html>
"""


class HtmlReporter(BaseReporter):
    def report(self, events: list[GuardEvent], summary: dict[str, Any], output_path: str | None = None) -> str:
        e = html_mod.escape
        parts: list[str] = []

        by_conf = summary.get("by_confidence", {})
        parts.append('<div class="summary">')
        for label, key, cls in [("Total", "total_events", ""), ("HIGH", None, "high"), ("MEDIUM", None, "medium"), ("LOW", None, "low")]:
            val = summary.get(key, 0) if key else by_conf.get(cls, 0)
            cls_attr = f' class="{cls}"' if cls else ""
            parts.append(f'<div class="stat"><div class="value"{cls_attr}>{val}</div><div class="label">{label}</div></div>')
        duration = summary.get("duration_seconds", 0)
        parts.append(f'<div class="stat"><div class="value">{duration:.3f}s</div><div class="label">Duration</div></div>')
        parts.append("</div>")

        if events:
            parts.append("<table><tr><th>#</th><th>Kind</th><th>Confidence</th><th>Description</th><th>Location</th></tr>")
            for idx, ev in enumerate(events, 1):
                badge_cls = ev.confidence.value
                parts.append(
                    f"<tr><td>{idx}</td><td>{e(ev.kind_label)}</td>"
                    f'<td><span class="badge {badge_cls}">{ev.confidence_label}</span></td>'
                    f"<td>{e(ev.description)}</td><td>{e(str(ev.location))}</td></tr>"
                )
            parts.append("</table>")

            for idx, ev in enumerate(events, 1):
                if ev.stack_summary:
                    stack_text = "\n".join(ev.stack_summary)
                    parts.append(f"<details><summary>#{idx} stack trace</summary><pre>{e(stack_text)}</pre></details>")
        else:
            parts.append("<p>✅ No issues detected.</p>")

        content = _HTML_TEMPLATE.replace("{body}", "\n".join(parts))
        self._write(content, output_path)
        return content

    def report_scan(self, findings: list[ScanFinding], output_path: str | None = None) -> str:
        e = html_mod.escape
        parts: list[str] = [f"<p><strong>Findings:</strong> {len(findings)}</p>"]

        if findings:
            parts.append("<table><tr><th>#</th><th>File</th><th>Line</th><th>Category</th><th>Confidence</th><th>Description</th></tr>")
            for idx, f in enumerate(findings, 1):
                cls = f.confidence.value
                parts.append(
                    f"<tr><td>{idx}</td><td>{e(f.file)}</td><td>{f.line}</td>"
                    f"<td>{e(f.category)}</td><td><span class=\"badge {cls}\">{cls.upper()}</span></td>"
                    f"<td>{e(f.description)}</td></tr>"
                )
            parts.append("</table>")
        else:
            parts.append("<p>✅ No risk patterns detected.</p>")

        content = _HTML_TEMPLATE.replace("{body}", "\n".join(parts))
        self._write(content, output_path)
        return content


class SarifReporter(BaseReporter):
    def report(self, events: list[GuardEvent], summary: dict[str, Any], output_path: str | None = None) -> str:
        _ = summary
        results: list[dict[str, Any]] = []
        for ev in events:
            result: dict[str, Any] = {
                "ruleId": f"runtime/{ev.kind.value}",
                "level": _sarif_level_from_confidence(ev.confidence),
                "message": {"text": ev.description},
                "properties": {"confidence": ev.confidence.value, "kind": ev.kind.value},
            }
            if ev.location.file:
                result["locations"] = [{
                    "physicalLocation": {
                        "artifactLocation": {"uri": ev.location.file},
                        "region": {"startLine": ev.location.line or 1},
                    }
                }]
            results.append(result)
        content = json.dumps(_sarif_doc(results), indent=2)
        self._write(content, output_path)
        return content

    def report_scan(self, findings: list[ScanFinding], output_path: str | None = None) -> str:
        results: list[dict[str, Any]] = []
        for finding in findings:
            results.append(
                {
                    "ruleId": f"scan/{finding.category}",
                    "level": _sarif_level_from_confidence(finding.confidence),
                    "message": {"text": finding.description},
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {"uri": finding.file},
                            "region": {"startLine": finding.line or 1, "startColumn": finding.col or 1},
                        }
                    }],
                    "properties": {"confidence": finding.confidence.value, "category": finding.category},
                }
            )
        content = json.dumps(_sarif_doc(results), indent=2)
        self._write(content, output_path)
        return content


_REPORTERS: dict[str, type[BaseReporter]] = {
    "terminal": TerminalReporter,
    "markdown": MarkdownReporter,
    "html": HtmlReporter,
    "sarif": SarifReporter,
}


def create_reporter(name: str) -> BaseReporter:
    cls = _REPORTERS.get(name)
    if cls is None:
        valid = ", ".join(sorted(_REPORTERS))
        raise ValueError(f"Unknown report format {name!r}. Choose from: {valid}")
    return cls()


def _sarif_level_from_confidence(confidence: Confidence) -> str:
    if confidence == Confidence.HIGH:
        return "error"
    if confidence == Confidence.MEDIUM:
        return "warning"
    return "note"


def _sarif_doc(results: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{"tool": {"driver": {"name": "SilentGuard", "informationUri": "https://github.com"}}, "results": results}],
    }
