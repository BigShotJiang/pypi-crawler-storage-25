"""SilentGuard CLI.

Entry point registered as ``silentguard`` console script.

Commands
--------
* ``silentguard guard <file_or_module>``  – run under instrumentation.
* ``silentguard audit <path>``            – static AST scan.
* ``silentguard test [pytest_args]``      – run pytest with plugin.
"""

from __future__ import annotations

import os
import runpy
import sys
from typing import Any

import click

from .config import discover_and_load_config, merge_cli_overrides
from .__version__ import __version__
from .core import GuardSession, SourceScanner
from .reporter import create_reporter


# ── Shared options ────────────────────────────────────────────────────

_format_option = click.option(
    "-f",
    "--format",
    "report_format",
    type=click.Choice(["terminal", "markdown", "html", "sarif"]),
    default="terminal",
    show_default=True,
    help="Output format for the report.",
)

_output_option = click.option(
    "-o",
    "--output",
    "output_path",
    type=click.Path(),
    default=None,
    help="Write report to this file path.",
)

_fail_on_option = click.option(
    "--fail-on",
    type=click.Choice(["high", "medium"]),
    default=None,
    help="Exit with code 1 when findings/events meet or exceed this confidence.",
)

_min_confidence_option = click.option(
    "--min-confidence",
    type=click.Choice(["low", "medium", "high"]),
    default=None,
    help="Hide findings/events below this confidence threshold.",
)


# ── CLI group ─────────────────────────────────────────────────────────


@click.group()
@click.version_option(__version__, prog_name="silentguard")
def app() -> None:
    """SilentGuard – detect silent failures and runtime side effects."""


# ── guard ─────────────────────────────────────────────────────────────


@app.command()
@click.argument("target")
@_format_option
@_output_option
@_fail_on_option
@_min_confidence_option
@click.option("--no-trace", is_flag=True, help="Disable sys.settrace (lowers overhead).")
def guard(
    target: str,
    report_format: str,
    output_path: str | None,
    fail_on: str | None,
    min_confidence: str | None,
    no_trace: bool,
) -> None:
    """Run a Python file or module under SilentGuard instrumentation.

    TARGET can be a path to a .py file or a module name (dotted).
    """
    base = discover_and_load_config()
    config = merge_cli_overrides(
        base,
        report_format=report_format,
        output_path=output_path,
        no_trace=no_trace,
        min_confidence=min_confidence,
    )
    session = GuardSession(config)
    session.start()

    try:
        if os.path.isfile(target):
            # Ensure the file's directory is on sys.path so relative
            # imports inside the target work.
            target_dir = os.path.dirname(os.path.abspath(target))
            if target_dir not in sys.path:
                sys.path.insert(0, target_dir)
            runpy.run_path(target, run_name="__main__")
        else:
            runpy.run_module(target, run_name="__main__", alter_sys=True)
    except SystemExit:
        pass  # let scripts call sys.exit() normally
    except Exception as exc:
        click.secho(f"\n✗ Target raised an unhandled exception: {exc}", fg="red", err=True)
    finally:
        session.stop()

    _emit_runtime_report(session, report_format, output_path)
    _apply_fail_on_events(session.events, fail_on)


# ── audit ─────────────────────────────────────────────────────────────


@app.command()
@click.argument("target")
@_format_option
@_output_option
@_fail_on_option
@_min_confidence_option
def audit(
    target: str,
    report_format: str,
    output_path: str | None,
    fail_on: str | None,
    min_confidence: str | None,
) -> None:
    """Statically scan Python source for common risk patterns.

    TARGET can be a single .py file or a directory.
    """
    base = discover_and_load_config()
    config = merge_cli_overrides(
        base,
        report_format=report_format,
        output_path=output_path,
        min_confidence=min_confidence,
    )
    scanner = SourceScanner(config=config)
    findings = scanner.scan(target)

    reporter = create_reporter(report_format)
    text = reporter.report_scan(findings, output_path=output_path)

    if report_format == "terminal":
        pass  # already printed by Rich
    else:
        if output_path:
            click.echo(f"Report written to {output_path}")
        else:
            click.echo(text)

    _apply_fail_on_findings(findings, fail_on)


# ── test ──────────────────────────────────────────────────────────────


@app.command(
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.pass_context
@_format_option
@_output_option
@_fail_on_option
@_min_confidence_option
def test(
    ctx: click.Context,
    report_format: str,
    output_path: str | None,
    fail_on: str | None,
    min_confidence: str | None,
) -> None:
    """Run pytest with SilentGuard enabled as a plugin.

    Extra arguments are forwarded directly to pytest.
    """
    try:
        import pytest  # noqa: WPS433
    except ImportError:
        click.secho(
            "pytest is not installed. Install it with: pip install silentguard[test]",
            fg="red",
            err=True,
        )
        raise SystemExit(1)

    base = discover_and_load_config()
    cfg = merge_cli_overrides(
        base,
        report_format=report_format,
        output_path=output_path,
        min_confidence=min_confidence,
    )

    # Forward all unknown args to pytest, plus our flag.
    pytest_args = list(ctx.args) + [
        "--silentguard",
        f"--sg-format={cfg.report_format}",
    ]
    if cfg.output_path:
        pytest_args.append(f"--sg-output={cfg.output_path}")
    if fail_on:
        pytest_args.append(f"--sg-fail-on={fail_on}")
    if min_confidence:
        pytest_args.append(f"--sg-min-confidence={min_confidence}")

    raise SystemExit(pytest.main(pytest_args))


@app.command()
@click.argument("target")
@click.option("--output", "output_path", type=click.Path(), default="silentguard.sarif")
@_fail_on_option
@_min_confidence_option
def ci(
    target: str,
    output_path: str,
    fail_on: str | None,
    min_confidence: str | None,
) -> None:
    """Run audit for CI and emit SARIF."""
    base = discover_and_load_config()
    cfg = merge_cli_overrides(
        base,
        report_format="sarif",
        output_path=output_path,
        min_confidence=min_confidence,
    )
    scanner = SourceScanner(config=cfg)
    findings = scanner.scan(target)
    reporter = create_reporter("sarif")
    reporter.report_scan(findings, output_path=output_path)
    click.echo(f"Report written to {output_path}")
    _apply_fail_on_findings(findings, fail_on)


# ── Helpers ───────────────────────────────────────────────────────────


def _emit_runtime_report(
    session: GuardSession,
    report_format: str,
    output_path: str | None,
) -> None:
    """Generate and output the runtime report."""
    events = session.events
    summary = session.summary()

    reporter = create_reporter(report_format)
    text = reporter.report(events, summary, output_path=output_path)

    if report_format == "terminal":
        pass  # Rich already printed
    else:
        if output_path:
            click.echo(f"Report written to {output_path}")
        else:
            click.echo(text)


def _apply_fail_on_events(events: list[Any], fail_on: str | None) -> None:
    if not fail_on:
        return
    for event in events:
        label = event.confidence.value
        if fail_on == "high" and label == "high":
            raise SystemExit(1)
        if fail_on == "medium" and label in {"high", "medium"}:
            raise SystemExit(1)


def _apply_fail_on_findings(findings: list[Any], fail_on: str | None) -> None:
    if not fail_on:
        return
    for finding in findings:
        label = finding.confidence.value
        if fail_on == "high" and label == "high":
            raise SystemExit(1)
        if fail_on == "medium" and label in {"high", "medium"}:
            raise SystemExit(1)
