# Changelog

All notable changes to SilentGuard will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- CLI support for `--min-confidence` on `guard`, `audit`, `test`, and `ci`.
- pytest plugin support for `--sg-min-confidence`.
- `.silentguardrc` support for allow-lists (`[allow].files` / `[allow].network_hosts`).

### Changed

- Runtime guard/test instrumentation now drops stdlib and frozen-importlib-only frames to reduce noise.
- README now documents project config, confidence filtering, SARIF output, and CI workflow usage.

## [0.1.0] — 2024-XX-XX

### Added

- `@guard()` decorator and context manager for runtime instrumentation.
- Suppressed exception detection via `sys.settrace`.
- File I/O, network call, subprocess, and env-var mutation detection via `sys.addaudithook`.
- Thread-spawn detection.
- AST-based static source scanner (`silentguard audit`).
- CLI commands: `guard`, `audit`, `test`.
- pytest plugin with `--silentguard` flag.
- Three output formats: terminal (Rich), Markdown, single-file HTML.
- Confidence-level classification (HIGH / MEDIUM / LOW) for all detections.
- Allow-lists for file patterns and network hosts.
