"""End-to-end CLI tests for SilentGuard commands."""

from __future__ import annotations

import os
import textwrap
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from silentguard.cli import app


def _write_file(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(textwrap.dedent(content))


class TestCliGuardCommand:
    def test_guard_terminal_format(self, tmp_path):
        script = tmp_path / "guard_terminal.py"
        _write_file(
            str(script),
            """
            import os
            os.environ["SG_GUARD_TERM"] = "x"
            """,
        )

        runner = CliRunner()
        result = runner.invoke(app, ["guard", str(script), "--format", "terminal"])
        assert result.exit_code == 0
        assert "SilentGuard" in result.output

        os.environ.pop("SG_GUARD_TERM", None)

    def test_guard_markdown_format(self, tmp_path):
        script = tmp_path / "guard_markdown.py"
        _write_file(
            str(script),
            """
            import os
            os.environ["SG_GUARD_MD"] = "x"
            """,
        )

        runner = CliRunner()
        result = runner.invoke(app, ["guard", str(script), "--format", "markdown"])
        assert result.exit_code == 0
        assert "# SilentGuard Report" in result.output

        os.environ.pop("SG_GUARD_MD", None)

    def test_guard_html_format(self, tmp_path):
        script = tmp_path / "guard_html.py"
        _write_file(
            str(script),
            """
            import os
            os.environ["SG_GUARD_HTML"] = "x"
            """,
        )

        runner = CliRunner()
        result = runner.invoke(app, ["guard", str(script), "--format", "html"])
        assert result.exit_code == 0
        assert "<!DOCTYPE html>" in result.output

        os.environ.pop("SG_GUARD_HTML", None)

    def test_guard_nonexistent_target(self):
        runner = CliRunner()
        result = runner.invoke(app, ["guard", "this_module_should_not_exist_12345"])
        assert result.exit_code == 0
        assert "Target raised an unhandled exception" in result.output

    def test_guard_script_with_sys_exit(self, tmp_path):
        script = tmp_path / "exit_script.py"
        _write_file(
            str(script),
            """
            import sys
            sys.exit(2)
            """,
        )

        runner = CliRunner()
        result = runner.invoke(app, ["guard", str(script), "--format", "markdown"])
        assert result.exit_code == 0
        assert "# SilentGuard Report" in result.output

    def test_guard_fail_on_medium(self, tmp_path):
        script = tmp_path / "guard_fail.py"
        _write_file(
            str(script),
            """
            import os
            os.environ["SG_FAIL_ON"] = "x"
            """,
        )
        runner = CliRunner()
        result = runner.invoke(app, ["guard", str(script), "--fail-on", "medium"])
        assert result.exit_code == 1
        os.environ.pop("SG_FAIL_ON", None)

    def test_guard_min_confidence_medium_filters_low_events(self, tmp_path):
        script = tmp_path / "guard_min_conf.py"
        _write_file(
            str(script),
            """
            import os

            try:
                {}["missing"]
            except KeyError:
                pass

            os.environ["SG_MIN_CONF"] = "x"
            """,
        )

        runner = CliRunner()
        result = runner.invoke(
            app,
            ["guard", str(script), "--format", "markdown", "--min-confidence", "medium"],
        )

        assert result.exit_code == 0
        assert "Environment variable set" in result.output
        assert "KeyError" not in result.output
        assert "**LOW:** 0" in result.output

        os.environ.pop("SG_MIN_CONF", None)

    def test_guard_module_import_error(self, tmp_path):
        pkg_dir = tmp_path / "pkg_bad"
        pkg_dir.mkdir()
        _write_file(str(pkg_dir / "__init__.py"), "")
        _write_file(
            str(pkg_dir / "badmod.py"),
            """
            import definitely_missing_package_name_zzzz
            """,
        )

        runner = CliRunner()
        with runner.isolated_filesystem():
            old_cwd = os.getcwd()
            try:
                os.chdir(tmp_path)
                result = runner.invoke(app, ["guard", "pkg_bad.badmod"])
            finally:
                os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Target raised an unhandled exception" in result.output


class TestCliAuditCommand:
    def test_audit_terminal_format(self):
        runner = CliRunner()
        result = runner.invoke(app, ["audit", "examples/risky_example.py", "--format", "terminal"])
        assert result.exit_code == 0
        assert "SilentGuard Audit" in result.output

    def test_audit_markdown_format(self):
        runner = CliRunner()
        result = runner.invoke(app, ["audit", "examples/risky_example.py", "--format", "markdown"])
        assert result.exit_code == 0
        assert "# SilentGuard Audit Report" in result.output

    def test_audit_html_format(self):
        runner = CliRunner()
        result = runner.invoke(app, ["audit", "examples/risky_example.py", "--format", "html"])
        assert result.exit_code == 0
        assert "<!DOCTYPE html>" in result.output

    def test_audit_sarif_format(self):
        runner = CliRunner()
        result = runner.invoke(app, ["audit", "examples/risky_example.py", "--format", "sarif"])
        assert result.exit_code == 0
        assert '"version": "2.1.0"' in result.output

    def test_audit_uses_project_config_for_inline_filters(self, tmp_path):
        cfg = tmp_path / ".silentguardrc"
        cfg.write_text(
            """
            [categories]
            disabled_scan = ["bare_except"]
            """,
            encoding="utf-8",
        )
        src = tmp_path / "scan_me.py"
        src.write_text("try:\n    pass\nexcept:\n    pass\n", encoding="utf-8")

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(app, ["audit", str(src), "--format", "markdown"])
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Findings:** 0" in result.output

    def test_audit_nonexistent_file(self):
        runner = CliRunner()
        result = runner.invoke(app, ["audit", "does_not_exist.py", "--format", "markdown"])
        assert result.exit_code == 0
        assert "not_found" in result.output

    def test_audit_permission_error_file(self, tmp_path):
        restricted = tmp_path / "restricted.py"
        _write_file(str(restricted), "print('x')")

        original_read_text = Path.read_text

        def _deny_read(self, *args, **kwargs):
            if self == restricted:
                raise PermissionError("permission denied")
            return original_read_text(self, *args, **kwargs)

        runner = CliRunner()
        with patch("pathlib.Path.read_text", _deny_read):
            result = runner.invoke(app, ["audit", str(restricted), "--format", "markdown"])

        assert result.exit_code == 0
        assert "parse_error" in result.output

    def test_audit_fail_on_high(self):
        runner = CliRunner()
        result = runner.invoke(
            app,
            ["audit", "examples/risky_example.py", "--format", "markdown", "--fail-on", "high"],
        )
        assert result.exit_code == 1


class TestCliTestCommand:
    def test_test_terminal_format(self, tmp_path):
        test_file = tmp_path / "test_ok.py"
        _write_file(
            str(test_file),
            """
            def test_ok():
                assert True
            """,
        )

        runner = CliRunner()
        result = runner.invoke(
            app,
            ["test", "--format", "terminal", str(test_file), "-q", "-p", "no:cov"],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert "SilentGuard" in result.output

    def test_test_markdown_format(self, tmp_path):
        test_file = tmp_path / "test_md.py"
        _write_file(
            str(test_file),
            """
            import os

            def test_env_mutation():
                os.environ["SG_TEST_MD"] = "1"
                assert True
            """,
        )

        out_file = tmp_path / "sg.md"
        runner = CliRunner()
        result = runner.invoke(
            app,
            [
                "test",
                "--format",
                "markdown",
                "--output",
                str(out_file),
                str(test_file),
                "-q",
                "-p",
                "no:cov",
            ],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert out_file.exists()
        assert "SilentGuard Report" in out_file.read_text(encoding="utf-8")

        os.environ.pop("SG_TEST_MD", None)

    def test_test_html_format(self, tmp_path):
        test_file = tmp_path / "test_html.py"
        _write_file(
            str(test_file),
            """
            def test_ok_html():
                assert True
            """,
        )

        out_file = tmp_path / "sg.html"
        runner = CliRunner()
        result = runner.invoke(
            app,
            [
                "test",
                "--format",
                "html",
                "--output",
                str(out_file),
                str(test_file),
                "-q",
                "-p",
                "no:cov",
            ],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert out_file.exists()
        assert "<!DOCTYPE html>" in out_file.read_text(encoding="utf-8")

    def test_test_sarif_format(self, tmp_path):
        test_file = tmp_path / "test_sarif.py"
        _write_file(
            str(test_file),
            """
            def test_ok_sarif():
                assert True
            """,
        )

        out_file = tmp_path / "sg.sarif"
        runner = CliRunner()
        result = runner.invoke(
            app,
            [
                "test",
                "--format",
                "sarif",
                "--output",
                str(out_file),
                str(test_file),
                "-q",
                "-p",
                "no:cov",
            ],
            catch_exceptions=False,
        )
        assert result.exit_code == 0
        assert out_file.exists()
        assert '"version": "2.1.0"' in out_file.read_text(encoding="utf-8")


class TestCliCiCommand:
    def test_ci_command_outputs_sarif(self, tmp_path):
        src = tmp_path / "scan.py"
        src.write_text("try:\n    pass\nexcept:\n    pass\n", encoding="utf-8")
        out = tmp_path / "ci.sarif"

        runner = CliRunner()
        result = runner.invoke(app, ["ci", str(src), "--output", str(out)])
        assert result.exit_code == 0
        assert out.exists()
        assert '"version": "2.1.0"' in out.read_text(encoding="utf-8")

    def test_ci_fail_on_high(self, tmp_path):
        src = tmp_path / "scan.py"
        src.write_text("try:\n    pass\nexcept:\n    pass\n", encoding="utf-8")
        out = tmp_path / "ci.sarif"

        runner = CliRunner()
        result = runner.invoke(app, ["ci", str(src), "--output", str(out), "--fail-on", "high"])
        assert result.exit_code == 1
