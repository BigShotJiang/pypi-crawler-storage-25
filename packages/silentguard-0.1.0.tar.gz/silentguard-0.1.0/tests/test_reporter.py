"""Tests for SilentGuard report formatters."""

from __future__ import annotations

import os
import json
import tempfile
import time

import pytest

from silentguard.reporter import (
    HtmlReporter,
    MarkdownReporter,
    SarifReporter,
    TerminalReporter,
    create_reporter,
)
from silentguard.utils import (
    Confidence,
    EventKind,
    GuardEvent,
    ScanFinding,
    SourceLocation,
)


# ═══════════════════════════════════════════════════════════════════════
#  Fixtures
# ═══════════════════════════════════════════════════════════════════════


def _make_events() -> list[GuardEvent]:
    return [
        GuardEvent(
            kind=EventKind.SUPPRESSED_EXCEPTION,
            description="Exception caught and suppressed: RuntimeError: boom",
            confidence=Confidence.HIGH,
            timestamp=time.time(),
            location=SourceLocation(file="app.py", line=42, function="process"),
            stack_summary=["  app.py:42 in process", "  main.py:10 in run"],
            details={"exception_type": "RuntimeError"},
        ),
        GuardEvent(
            kind=EventKind.FILE_IO,
            description="File opened: /tmp/data.csv (mode=r)",
            confidence=Confidence.MEDIUM,
            timestamp=time.time(),
            location=SourceLocation(file="/tmp/data.csv"),
            stack_summary=[],
            details={"path": "/tmp/data.csv", "mode": "r"},
        ),
        GuardEvent(
            kind=EventKind.ENV_MUTATION,
            description="Environment variable set: API_KEY=secret",
            confidence=Confidence.HIGH,
            timestamp=time.time(),
            location=SourceLocation(),
            stack_summary=["  config.py:5 in load_env"],
            details={"key": "API_KEY", "value": "secret"},
        ),
    ]


def _make_summary() -> dict:
    return {
        "total_events": 3,
        "by_kind": {
            "suppressed_exception": 1,
            "file_io": 1,
            "env_mutation": 1,
        },
        "by_confidence": {"high": 2, "medium": 1},
        "duration_seconds": 0.042,
    }


def _make_findings() -> list[ScanFinding]:
    return [
        ScanFinding(
            file="bad.py",
            line=10,
            col=0,
            category="bare_except",
            description="Bare `except:` catches all exceptions.",
            confidence=Confidence.HIGH,
            snippet="except:",
        ),
        ScanFinding(
            file="risky.py",
            line=25,
            col=4,
            category="dangerous_call",
            description="Call to `os.system()` may execute arbitrary code.",
            confidence=Confidence.HIGH,
            snippet='os.system("rm -rf /")',
        ),
    ]


# ═══════════════════════════════════════════════════════════════════════
#  Factory
# ═══════════════════════════════════════════════════════════════════════


class TestFactory:
    def test_create_terminal(self):
        r = create_reporter("terminal")
        assert isinstance(r, TerminalReporter)

    def test_create_markdown(self):
        r = create_reporter("markdown")
        assert isinstance(r, MarkdownReporter)

    def test_create_html(self):
        r = create_reporter("html")
        assert isinstance(r, HtmlReporter)

    def test_create_sarif(self):
        r = create_reporter("sarif")
        assert isinstance(r, SarifReporter)

    def test_invalid_format_raises(self):
        with pytest.raises(ValueError, match="Unknown report format"):
            create_reporter("xml")


# ═══════════════════════════════════════════════════════════════════════
#  Terminal reporter
# ═══════════════════════════════════════════════════════════════════════


class TestTerminalReporter:
    def test_report_contains_events(self):
        r = TerminalReporter()
        text = r.report(_make_events(), _make_summary())
        assert "SilentGuard" in text
        assert "RuntimeError" in text

    def test_empty_report(self):
        r = TerminalReporter()
        text = r.report([], {"total_events": 0, "by_confidence": {}, "duration_seconds": 0})
        assert "No issues" in text

    def test_scan_report(self):
        r = TerminalReporter()
        text = r.report_scan(_make_findings())
        assert "bare_except" in text


# ═══════════════════════════════════════════════════════════════════════
#  Markdown reporter
# ═══════════════════════════════════════════════════════════════════════


class TestMarkdownReporter:
    def test_report_structure(self):
        r = MarkdownReporter()
        text = r.report(_make_events(), _make_summary())
        assert text.startswith("# SilentGuard Report")
        assert "## Summary" in text
        assert "## Events" in text
        assert "RuntimeError" in text
        assert "HIGH" in text

    def test_empty_report(self):
        r = MarkdownReporter()
        text = r.report([], {"total_events": 0, "by_confidence": {}, "duration_seconds": 0})
        assert "No issues" in text

    def test_scan_report(self):
        r = MarkdownReporter()
        text = r.report_scan(_make_findings())
        assert "bare_except" in text
        assert "Audit" in text

    def test_write_to_file(self):
        r = MarkdownReporter()
        with tempfile.NamedTemporaryFile(
            suffix=".md", delete=False, mode="w"
        ) as f:
            path = f.name
        try:
            r.report(_make_events(), _make_summary(), output_path=path)
            content = open(path, encoding="utf-8").read()
            assert "SilentGuard" in content
        finally:
            os.unlink(path)


# ═══════════════════════════════════════════════════════════════════════
#  HTML reporter
# ═══════════════════════════════════════════════════════════════════════


class TestHtmlReporter:
    def test_report_is_valid_html(self):
        r = HtmlReporter()
        text = r.report(_make_events(), _make_summary())
        assert "<!DOCTYPE html>" in text
        assert "<title>SilentGuard Report</title>" in text
        assert "RuntimeError" in text
        assert 'class="badge high"' in text

    def test_empty_report(self):
        r = HtmlReporter()
        text = r.report([], {"total_events": 0, "by_confidence": {}, "duration_seconds": 0})
        assert "No issues" in text

    def test_scan_report_html(self):
        r = HtmlReporter()
        text = r.report_scan(_make_findings())
        assert "bare_except" in text
        assert "<!DOCTYPE html>" in text

    def test_write_to_file(self):
        r = HtmlReporter()
        with tempfile.NamedTemporaryFile(
            suffix=".html", delete=False, mode="w"
        ) as f:
            path = f.name
        try:
            r.report(_make_events(), _make_summary(), output_path=path)
            content = open(path, encoding="utf-8").read()
            assert "<!DOCTYPE html>" in content
        finally:
            os.unlink(path)


class TestSarifReporter:
    def test_report_runtime_sarif(self):
        r = SarifReporter()
        text = r.report(_make_events(), _make_summary())
        data = json.loads(text)
        assert data["version"] == "2.1.0"
        assert data["runs"][0]["tool"]["driver"]["name"] == "SilentGuard"
        assert len(data["runs"][0]["results"]) >= 1

    def test_report_scan_sarif(self):
        r = SarifReporter()
        text = r.report_scan(_make_findings())
        data = json.loads(text)
        assert data["version"] == "2.1.0"
        assert data["runs"][0]["results"][0]["ruleId"].startswith("scan/")

    def test_write_to_file(self):
        r = SarifReporter()
        with tempfile.NamedTemporaryFile(suffix=".sarif", delete=False, mode="w") as f:
            path = f.name
        try:
            r.report_scan(_make_findings(), output_path=path)
            content = open(path, encoding="utf-8").read()
            assert "\"version\": \"2.1.0\"" in content
        finally:
            os.unlink(path)
