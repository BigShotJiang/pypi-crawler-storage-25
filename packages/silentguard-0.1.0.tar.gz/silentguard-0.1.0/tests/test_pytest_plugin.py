"""Tests for SilentGuard pytest plugin behavior."""

from __future__ import annotations


def test_plugin_outputs_no_events_message(pytester):
    pytester.makepyfile(
        test_sample="""
        def test_ok():
            assert True
        """
    )
    result = pytester.runpytest("--silentguard", "-q")
    result.assert_outcomes(passed=1)
    stdout = result.stdout.str()
    assert "SilentGuard Report" in stdout


def test_plugin_collects_events_and_writes_markdown(pytester):
    pytester.makepyfile(
        test_sample="""
        import os

        def test_mutation():
            os.environ["SG_PLUGIN_TEST"] = "1"
            assert True
        """
    )

    out = pytester.path / "plugin_report.md"
    result = pytester.runpytest("--silentguard", "--sg-format=markdown", f"--sg-output={out}", "-q")
    result.assert_outcomes(passed=1)
    assert out.exists()
    content = out.read_text(encoding="utf-8")
    assert "SilentGuard Report" in content
    assert "Environment variable set" in content


def test_plugin_writes_html_output(pytester):
    pytester.makepyfile(
        test_sample="""
        def test_ok_html():
            assert True
        """
    )

    out = pytester.path / "plugin_report.html"
    result = pytester.runpytest("--silentguard", "--sg-format=html", f"--sg-output={out}", "-q")
    result.assert_outcomes(passed=1)
    assert out.exists()
    assert "<!DOCTYPE html>" in out.read_text(encoding="utf-8")


def test_plugin_fail_on_threshold(pytester):
    pytester.makepyfile(
        test_sample="""
        import os

        def test_mutation():
            os.environ["SG_PLUGIN_FAIL"] = "1"
            assert True
        """
    )
    result = pytester.runpytest("--silentguard", "--sg-fail-on=high", "-q")
    assert result.ret != 0


def test_plugin_min_confidence_filters_low_events(pytester):
    pytester.makepyfile(
        test_sample="""
        import os

        def test_runtime_noise_filter():
            try:
                {}["missing"]
            except KeyError:
                pass

            os.environ["SG_PLUGIN_MIN_CONF"] = "1"
            assert True
        """
    )

    out = pytester.path / "plugin_report.md"
    result = pytester.runpytest(
        "--silentguard",
        "--sg-format=markdown",
        "--sg-min-confidence=medium",
        f"--sg-output={out}",
        "-q",
    )
    result.assert_outcomes(passed=1)
    content = out.read_text(encoding="utf-8")
    assert "Environment variable set" in content
    assert "KeyError" not in content
