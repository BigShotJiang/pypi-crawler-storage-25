"""Tests for sys.monitoring fast-path behavior."""

from __future__ import annotations

from silentguard import hooks


def test_monitoring_backend_selected_when_available(monkeypatch):
    if not hooks._HAS_MONITORING:
        return

    recorded = {"events": 0}

    def fake_set_events(tool_id, event_set):
        _ = tool_id
        recorded["events"] = event_set

    monkeypatch.setattr(hooks.sys.monitoring, "set_events", fake_set_events)
    monkeypatch.setattr(hooks, "_install_asyncio_hooks", lambda: None)
    monkeypatch.setattr(hooks, "_uninstall_asyncio_hooks", lambda: None)

    hooks._trace_backend = None
    hooks._monitoring_active = False
    hooks._install_trace()
    assert hooks._trace_backend in {"monitoring", "trace"}
    hooks._uninstall_trace()


def test_monitoring_callbacks_no_crash_without_sessions():
    class Code:
        co_filename = "app.py"
        co_name = "fn"
        co_firstlineno = 1
        co_flags = 0

    code = Code()
    hooks._trace_sessions.clear()
    hooks._monitoring_on_start(code, 0)
    hooks._monitoring_on_raise(code, 0, ValueError("x"))
    hooks._monitoring_on_return(code, 0, None)
