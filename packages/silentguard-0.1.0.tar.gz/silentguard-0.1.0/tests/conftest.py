"""Shared pytest configuration for test suite."""

pytest_plugins = ["pytester"]
