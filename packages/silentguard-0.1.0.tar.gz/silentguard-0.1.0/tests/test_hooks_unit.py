"""Unit tests for hooks internals to improve branch coverage."""

from __future__ import annotations

import asyncio
import types

import pytest

from silentguard import hooks


class _DummyCode:
    def __init__(self, filename: str, name: str, flags: int = 0) -> None:
        self.co_filename = filename
        self.co_name = name
        self.co_flags = flags


class _DummyFrame:
    def __init__(self, code: _DummyCode, lineno: int = 1, back=None) -> None:
        self.f_code = code
        self.f_lineno = lineno
        self.f_back = back


def _reset_hook_state() -> None:
    hooks._sessions.clear()
    hooks._trace_sessions.clear()
    hooks._audit_hook_installed = False
    hooks._asyncio_hooks_installed = False
    if hasattr(hooks._trace_state_local, "state"):
        delattr(hooks._trace_state_local, "state")


@pytest.fixture(autouse=True)
def _reset_between_tests():
    _reset_hook_state()
    yield
    _reset_hook_state()


def test_ensure_audit_hook_installs_once(monkeypatch):
    _reset_hook_state()
    calls = []

    monkeypatch.setattr(hooks.sys, "addaudithook", lambda fn: calls.append(fn))
    hooks._ensure_audit_hook()
    hooks._ensure_audit_hook()

    assert len(calls) == 1


def test_audit_hook_dispatch_and_recursion_guard():
    _reset_hook_state()
    called = []

    session = types.SimpleNamespace(
        handle_audit_event=lambda e, a: called.append(("audit", e)),
        handle_asyncio_audit_event=lambda e, a: called.append(("async", e)),
    )
    hooks._sessions[id(session)] = session

    hooks._audit_hook("open", ("x", "r"))
    assert ("audit", "open") in called
    assert ("async", "open") in called

    hooks._in_hook.active = True
    hooks._audit_hook("open", ("x", "r"))
    hooks._in_hook.active = False


def test_global_trace_filter_and_async_entry():
    _reset_hook_state()
    entered = []
    session = types.SimpleNamespace(handle_asyncio_frame_enter=lambda fid: entered.append(fid))
    hooks._trace_sessions[id(session)] = session

    internal = _DummyFrame(_DummyCode("/repo/silentguard/core.py", "fn"))
    assert hooks._global_trace(internal, "call", None) is None

    frozen_importlib = _DummyFrame(_DummyCode("<frozen importlib._bootstrap>", "fn"))
    assert hooks._global_trace(frozen_importlib, "call", None) is None

    noncall = _DummyFrame(_DummyCode("/repo/app.py", "fn"))
    assert hooks._global_trace(noncall, "line", None) is None

    async_frame = _DummyFrame(
        _DummyCode("/repo/app.py", "coro", hooks.inspect.CO_COROUTINE),
    )
    out = hooks._global_trace(async_frame, "call", None)
    assert out is hooks._local_trace
    assert entered


def test_local_trace_exception_correlation_paths():
    _reset_hook_state()
    calls = []
    session = types.SimpleNamespace(
        handle_exception_raised=lambda *a: calls.append("raised"),
        handle_frame_return=lambda *a: calls.append("return"),
        handle_frame_exception_propagated=lambda *a: calls.append("propagated"),
        handle_frame_exception_settled=lambda *a: calls.append("settled"),
        handle_asyncio_frame_exit=lambda *a: calls.append("async_exit"),
    )
    hooks._trace_sessions[id(session)] = session

    parent = _DummyFrame(_DummyCode("/repo/app.py", "parent"), lineno=10)
    child = _DummyFrame(_DummyCode("/repo/app.py", "child"), lineno=20, back=parent)

    hooks._local_trace(child, "exception", (ValueError, ValueError("x"), None))
    hooks._local_trace(child, "return", None)
    hooks._local_trace(parent, "exception", (ValueError, ValueError("x"), None))
    hooks._local_trace(parent, "return", None)

    plain = _DummyFrame(_DummyCode("/repo/app.py", "plain"), lineno=30)
    hooks._local_trace(plain, "return", None)

    assert "raised" in calls
    assert "return" in calls
    assert "propagated" in calls
    assert "settled" in calls


def test_install_and_uninstall_trace(monkeypatch):
    _reset_hook_state()
    sys_trace_calls = []
    th_trace_calls = []
    marks = []

    monkeypatch.setattr(hooks.sys, "gettrace", lambda: "orig")
    monkeypatch.setattr(hooks, "_HAS_MONITORING", False)
    monkeypatch.setattr(hooks.sys, "settrace", lambda fn: sys_trace_calls.append(fn))
    monkeypatch.setattr(hooks.threading, "settrace", lambda fn: th_trace_calls.append(fn))
    monkeypatch.setattr(hooks, "_install_asyncio_hooks", lambda: marks.append("install"))
    monkeypatch.setattr(hooks, "_uninstall_asyncio_hooks", lambda: marks.append("uninstall"))

    hooks._install_trace()
    hooks._uninstall_trace()

    assert hooks._global_trace in sys_trace_calls
    assert "orig" in sys_trace_calls
    assert hooks._global_trace in th_trace_calls
    assert "orig" in th_trace_calls
    assert marks == ["install", "uninstall"]


def test_register_unregister_session(monkeypatch):
    _reset_hook_state()
    marks = []
    session = types.SimpleNamespace()

    monkeypatch.setattr(hooks, "_ensure_audit_hook", lambda: marks.append("audit"))
    monkeypatch.setattr(hooks, "_install_trace", lambda: marks.append("install"))
    monkeypatch.setattr(hooks, "_uninstall_trace", lambda: marks.append("uninstall"))

    hooks.register_session(session)
    assert id(session) in hooks._sessions
    assert id(session) in hooks._trace_sessions

    hooks.unregister_session(session)
    assert id(session) not in hooks._sessions
    assert id(session) not in hooks._trace_sessions
    assert marks == ["audit", "install", "uninstall"]


def test_asyncio_hook_wrappers_emit_events_and_restore():
    _reset_hook_state()
    task_calls = []
    loop_calls = []
    session = types.SimpleNamespace(
        handle_asyncio_task_created=lambda api, coro: task_calls.append(api),
        handle_asyncio_loop_manipulation=lambda op: loop_calls.append(op),
    )
    hooks._trace_sessions[id(session)] = session

    hooks._install_asyncio_hooks()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.set_debug(True)

    fut = asyncio.ensure_future(asyncio.sleep(0), loop=loop)
    loop.run_until_complete(fut)

    coro = asyncio.sleep(0)
    try:
        asyncio.create_task(coro)
    except RuntimeError:
        coro.close()

    loop.stop()
    loop.close()
    asyncio.set_event_loop(None)

    hooks._uninstall_asyncio_hooks()

    assert "asyncio.ensure_future" in task_calls
    assert "asyncio.create_task" in task_calls
    assert any("new_event_loop" in op for op in loop_calls)
    assert any("set_event_loop" in op for op in loop_calls)
    assert any("set_debug" in op for op in loop_calls)
