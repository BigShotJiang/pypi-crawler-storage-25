"""Unit tests for GuardSession internals and core branches."""

from __future__ import annotations

import types

from silentguard.core import GuardConfig, GuardSession
from silentguard.utils import Confidence, EventKind, GuardEvent, SourceLocation


def test_handle_audit_event_dispatches_all_handlers(monkeypatch):
    session = GuardSession()
    session._active = True

    called = []
    monkeypatch.setattr(session, "_on_file_open", lambda e, a: called.append("open"))
    monkeypatch.setattr(session, "_on_network", lambda e, a: called.append("net"))
    monkeypatch.setattr(session, "_on_subprocess", lambda e, a: called.append("sub"))
    monkeypatch.setattr(session, "_on_env_mutation", lambda e, a: called.append("env"))
    monkeypatch.setattr(session, "_on_thread_spawn", lambda e, a: called.append("thr"))

    session.handle_audit_event("open", ("x", "r"))
    session.handle_audit_event("socket.connect", (None, "127.0.0.1"))
    session.handle_audit_event("socket.getaddrinfo", ("localhost",))
    session.handle_audit_event("subprocess.Popen", ("echo x",))
    session.handle_audit_event("os.system", ("echo y",))
    session.handle_audit_event("os.putenv", ("K", "V"))
    session.handle_audit_event("os.unsetenv", ("K",))
    session.handle_audit_event("_thread.start_new_thread", tuple())
    session.handle_audit_event("unknown.event", tuple())

    assert called.count("open") == 1
    assert called.count("net") == 2
    assert called.count("sub") == 2
    assert called.count("env") == 2
    assert called.count("thr") == 1


def test_handle_audit_event_respects_config_flags(monkeypatch):
    cfg = GuardConfig(
        detect_file_io=False,
        detect_network=False,
        detect_subprocess=False,
        detect_env_mutation=False,
        detect_threading=False,
    )
    session = GuardSession(cfg)
    session._active = True

    called = []
    monkeypatch.setattr(session, "_on_file_open", lambda e, a: called.append("open"))
    monkeypatch.setattr(session, "_on_network", lambda e, a: called.append("net"))
    monkeypatch.setattr(session, "_on_subprocess", lambda e, a: called.append("sub"))
    monkeypatch.setattr(session, "_on_env_mutation", lambda e, a: called.append("env"))
    monkeypatch.setattr(session, "_on_thread_spawn", lambda e, a: called.append("thr"))

    session.handle_audit_event("open", ("x", "r"))
    session.handle_audit_event("socket.connect", (None, "127.0.0.1"))
    session.handle_audit_event("subprocess.Popen", ("echo x",))
    session.handle_audit_event("os.putenv", ("K", "V"))
    session.handle_audit_event("_thread.start_new_thread", tuple())

    assert called == []


def test_file_open_filters_and_records(monkeypatch):
    session = GuardSession()
    session._active = True

    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: ["x"])
    monkeypatch.setattr("silentguard.core.is_silentguard_frame", lambda _: False)

    session._on_file_open("open", tuple())
    session._on_file_open("open", (None,))
    session._on_file_open("open", ("a.pyc", "r"))

    session.config.allowed_file_patterns = ["allow-me"]
    session._on_file_open("open", ("allow-me.txt", "w"))

    session.config.allowed_file_patterns = []
    session._on_file_open("open", ("file.txt", "w"))
    assert any(e.kind == EventKind.FILE_IO for e in session.events)


def test_file_open_drops_when_stack_empty(monkeypatch):
    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: [])
    monkeypatch.setattr("silentguard.core.is_silentguard_frame", lambda _: False)
    session._on_file_open("open", ("file.txt", "r"))
    assert session.events == []


def test_network_subprocess_env_thread_handlers(monkeypatch):
    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: ["stack"])

    session.config.allowed_network_hosts = ["safe.host"]
    session._on_network("socket.getaddrinfo", ("safe.host",))
    assert session.events == []

    session.config.allowed_network_hosts = []
    session._on_network("socket.connect", (None, "1.2.3.4"))
    session._on_network("socket.getaddrinfo", ("example.com",))
    session._on_subprocess("subprocess.Popen", ("echo hello",))
    session._on_subprocess("os.system", ("echo world",))
    session._on_env_mutation("os.putenv", ("A", "B"))
    session._on_env_mutation("os.unsetenv", ("A",))
    session._on_thread_spawn("_thread.start_new_thread", tuple())

    kinds = [e.kind for e in session.events]
    assert EventKind.NETWORK_CALL in kinds
    assert EventKind.SUBPROCESS_EXEC in kinds
    assert EventKind.ENV_MUTATION in kinds
    assert EventKind.THREAD_SPAWN in kinds


def test_runtime_handlers_drop_internal_or_stdlib_only_activity(monkeypatch):
    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: [])

    session._on_network("socket.connect", (None, "1.2.3.4"))
    session._on_subprocess("subprocess.Popen", ("echo hello",))
    session._on_env_mutation("os.putenv", ("A", "B"))
    session._on_thread_spawn("_thread.start_new_thread", tuple())
    session.handle_asyncio_frame_enter(10)
    session.handle_asyncio_audit_event("time.sleep", tuple())
    session.handle_asyncio_task_created("asyncio.create_task", "<coro>")
    session.handle_asyncio_loop_manipulation("loop.set_debug(True)")

    assert session.events == []


def test_exception_lifecycle_and_cleanup(monkeypatch):
    session = GuardSession()
    session._active = True

    session.handle_exception_raised(1, "RuntimeError", "boom", "app.py", 1, "fn")
    session.handle_frame_return(1, "app.py", 1, "fn")
    assert any(e.kind == EventKind.SUPPRESSED_EXCEPTION for e in session.events)

    event_count = len(session.events)
    session.handle_frame_exception_propagated(1)
    assert len(session.events) == event_count - 1

    session.handle_frame_exception_settled(1)

    # control-flow exception should be ignored
    session.handle_exception_raised(2, "StopIteration", "", "app.py", 1, "fn")
    session.handle_frame_return(2, "app.py", 1, "fn")
    assert all(e.details.get("exception_type") != "StopIteration" for e in session.events)


def test_exception_handlers_respect_flags_and_internal_frames(monkeypatch):
    session = GuardSession(GuardConfig(detect_suppressed_exceptions=False))
    session._active = True
    session.handle_exception_raised(1, "RuntimeError", "boom", "app.py", 1, "fn")
    assert session._pending_exceptions == {}

    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.is_silentguard_frame", lambda _: True)
    session.handle_exception_raised(1, "RuntimeError", "boom", "app.py", 1, "fn")
    assert session._pending_exceptions == {}

    session = GuardSession()
    session._active = True
    session.handle_exception_raised(
        1,
        "AttributeError",
        "missing",
        "<frozen importlib._bootstrap>",
        1,
        "find_spec",
    )
    assert session._pending_exceptions == {}


def test_asyncio_handlers_paths(monkeypatch):
    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: ["s"])

    # no async context -> ignored
    session.handle_asyncio_audit_event("time.sleep", tuple())
    assert session.events == []

    session.handle_asyncio_frame_enter(10)
    session.handle_asyncio_audit_event("time.sleep", tuple())
    session.handle_asyncio_audit_event("open", ("a.txt",))
    session.handle_asyncio_audit_event("other", tuple())
    session.handle_asyncio_task_created("asyncio.create_task", "<coro>")
    session.handle_asyncio_loop_manipulation("loop.set_debug(True)")
    session.handle_asyncio_frame_exit(10)

    kinds = [e.kind for e in session.events]
    assert kinds.count(EventKind.ASYNCIO_SIDE_EFFECT) >= 4

    disabled = GuardSession(GuardConfig(detect_asyncio=False))
    disabled._active = True
    disabled.handle_asyncio_frame_enter(1)
    disabled.handle_asyncio_audit_event("time.sleep", tuple())
    disabled.handle_asyncio_task_created("asyncio.create_task", "<coro>")
    disabled.handle_asyncio_loop_manipulation("x")
    disabled.handle_asyncio_frame_exit(1)
    assert disabled.events == []


def test_summary_counts_and_duration_nonzero(monkeypatch):
    session = GuardSession()
    session._active = True
    monkeypatch.setattr("silentguard.core.capture_stack_summary", lambda skip_frames=4: ["s"])
    session._on_env_mutation("os.putenv", ("A", "B"))
    out = session.summary()
    assert out["total_events"] >= 1
    assert "env_mutation" in out["by_kind"]
    assert out["duration_seconds"] >= 0


def test_record_event_filters_by_category_confidence_and_patterns():
    cfg = GuardConfig(
        disabled_event_categories=["env_mutation"],
        ignore_file_patterns=["ignored.py"],
        ignore_function_patterns=["ignored_func"],
        min_confidence=Confidence.HIGH,
    )
    session = GuardSession(cfg)

    # category disabled
    session._on_env_mutation("os.putenv", ("A", "B"))
    assert session.events == []

    # low confidence below threshold
    session.record_event(
        GuardEvent(
            kind=EventKind.SUPPRESSED_EXCEPTION,
            description="x",
            confidence=Confidence.LOW,
            timestamp=0.0,
            location=SourceLocation(file="x.py", function="f"),
        )
    )
    assert session.events == []
