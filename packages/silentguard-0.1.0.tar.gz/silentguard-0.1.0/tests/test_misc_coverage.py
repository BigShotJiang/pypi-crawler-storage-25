"""Coverage-focused tests for remaining modules and branches."""

from __future__ import annotations

import os
import runpy
import sys

import pytest
from click.testing import CliRunner

import silentguard
from silentguard.cli import app
from silentguard.decorators import guard
from silentguard.pytest_plugin import _count_by


def test_package_exports():
    assert hasattr(silentguard, "guard")
    assert hasattr(silentguard, "GuardSession")
    assert "GuardConfig" in silentguard.__all__


def test_module_entrypoint_invokes_app(monkeypatch):
    called = {"ok": False}

    def fake_app():
        called["ok"] = True

    monkeypatch.setattr("silentguard.cli.app", fake_app)
    runpy.run_module("silentguard", run_name="__main__")
    assert called["ok"]


def test_guard_decorator_type_errors():
    g = guard()
    with pytest.raises(TypeError):
        g()
    with pytest.raises(TypeError):
        g(123)


def test_guard_context_manager_exit_and_report(monkeypatch):
    reports = []

    class DummyReporter:
        def report(self, events, summary, output_path=None):
            reports.append((events, summary, output_path))
            return "ok"

    monkeypatch.setattr("silentguard.decorators.create_reporter", lambda _fmt: DummyReporter())

    @guard(report_format="markdown")
    def fn():
        os.environ["SG_DECORATOR_TEST"] = "1"

    fn()
    assert reports
    os.environ.pop("SG_DECORATOR_TEST", None)


def test_count_by_helper():
    class Obj:
        def __init__(self, kind):
            self.kind = kind

    values = [Obj("a"), Obj("a"), Obj("b")]
    out = _count_by(values, lambda x: x.kind)
    assert out == {"a": 2, "b": 1}


def test_cli_test_importerror_branch(monkeypatch):
    runner = CliRunner()
    monkeypatch.delitem(sys.modules, "pytest", raising=False)

    import builtins

    original_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "pytest":
            raise ImportError("missing")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    result = runner.invoke(app, ["test"])

    assert result.exit_code == 1
    assert "pytest is not installed" in result.output


def test_cli_guard_output_path_branch(tmp_path):
    script = tmp_path / "target.py"
    script.write_text("print('ok')\n", encoding="utf-8")
    out = tmp_path / "report.md"

    runner = CliRunner()
    result = runner.invoke(app, ["guard", str(script), "--format", "markdown", "--output", str(out)])

    assert result.exit_code == 0
    assert out.exists()
    assert "Report written to" in result.output


def test_cli_audit_output_path_branch(tmp_path):
    source = tmp_path / "audit_me.py"
    source.write_text("try:\n    pass\nexcept:\n    pass\n", encoding="utf-8")
    out = tmp_path / "audit.html"

    runner = CliRunner()
    result = runner.invoke(app, ["audit", str(source), "--format", "html", "--output", str(out)])

    assert result.exit_code == 0
    assert out.exists()
    assert "Report written to" in result.output


def test_cli_test_forwards_min_confidence(monkeypatch):
    captured = {}

    def fake_pytest_main(args):
        captured["args"] = args
        return 0

    monkeypatch.setattr("pytest.main", fake_pytest_main)

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["test", "--min-confidence", "medium", "--format", "markdown", "-q", "-p", "no:cov"],
        catch_exceptions=False,
    )

    assert result.exit_code == 0
    assert "--sg-min-confidence=medium" in captured["args"]
