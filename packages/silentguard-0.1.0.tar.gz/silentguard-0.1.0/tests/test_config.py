"""Tests for .silentguardrc config discovery/loading/merging."""

from __future__ import annotations

from silentguard.config import (
    discover_config_path,
    load_guard_config,
    merge_cli_overrides,
)
from silentguard.utils import Confidence


def test_discover_config_path_walks_up(tmp_path):
    root = tmp_path / "repo"
    nested = root / "a" / "b"
    nested.mkdir(parents=True)
    cfg = root / ".silentguardrc"
    cfg.write_text("", encoding="utf-8")

    found = discover_config_path(str(nested))
    assert found == str(cfg)


def test_load_guard_config_parses_sections(tmp_path):
    cfg_file = tmp_path / ".silentguardrc"
    cfg_file.write_text(
        """
        [runtime]
        detect_network = false

        [filters]
        ignore_file_patterns = ["vendor/*"]
        ignore_function_patterns = ["legacy_*"]
        min_confidence = "high"

        [allow]
        files = ["*.log"]
        network_hosts = ["localhost"]

        [categories]
        disabled_events = ["env_mutation"]
        disabled_scan = ["bare_except"]
        """,
        encoding="utf-8",
    )

    cfg = load_guard_config(str(cfg_file))
    assert cfg.detect_network is False
    assert cfg.allowed_file_patterns == ["*.log"]
    assert cfg.allowed_network_hosts == ["localhost"]
    assert cfg.ignore_file_patterns == ["vendor/*"]
    assert cfg.ignore_function_patterns == ["legacy_*"]
    assert cfg.min_confidence == Confidence.HIGH
    assert "env_mutation" in cfg.disabled_event_categories
    assert "bare_except" in cfg.disabled_scan_categories


def test_merge_cli_overrides_wins_over_config():
    base = load_guard_config(None)
    merged = merge_cli_overrides(
        base,
        report_format="html",
        output_path="out.html",
        no_trace=True,
        min_confidence="medium",
    )
    assert merged.report_format == "html"
    assert merged.output_path == "out.html"
    assert merged.detect_suppressed_exceptions is False
    assert merged.min_confidence == Confidence.MEDIUM
