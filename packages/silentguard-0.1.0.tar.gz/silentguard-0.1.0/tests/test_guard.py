"""Tests for SilentGuard core detection logic."""

from __future__ import annotations

import asyncio
import os
import subprocess
import tempfile
import textwrap
import time
import threading

import pytest

from silentguard.core import GuardConfig, GuardSession, SourceScanner
from silentguard.decorators import guard
from silentguard.utils import Confidence, EventKind


# ═══════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════


def _run_guarded(fn, **config_kwargs):
    """Run *fn* inside a GuardSession and return collected events."""
    config = GuardConfig(**config_kwargs)
    session = GuardSession(config)
    session.start()
    try:
        fn()
    except Exception:
        pass
    finally:
        session.stop()
    return session.events


# ═══════════════════════════════════════════════════════════════════════
#  Session lifecycle
# ═══════════════════════════════════════════════════════════════════════


class TestSessionLifecycle:
    def test_start_stop(self):
        session = GuardSession()
        assert not session.is_active
        session.start()
        assert session.is_active
        session.stop()
        assert not session.is_active

    def test_duration_positive(self):
        session = GuardSession()
        session.start()
        session.stop()
        assert session.duration >= 0

    def test_events_initially_empty(self):
        session = GuardSession()
        assert session.events == []

    def test_summary_structure(self):
        session = GuardSession()
        session.start()
        session.stop()
        s = session.summary()
        assert "total_events" in s
        assert "by_kind" in s
        assert "by_confidence" in s
        assert "duration_seconds" in s


# ═══════════════════════════════════════════════════════════════════════
#  Suppressed exception detection
# ═══════════════════════════════════════════════════════════════════════


class TestSuppressedExceptions:
    def test_broad_except_detected(self):
        def target():
            try:
                raise RuntimeError("boom")
            except Exception:
                pass  # suppressed

        events = _run_guarded(target)
        # Should detect at least the RuntimeError suppression
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]
        assert len(suppressed) >= 1
        assert any("RuntimeError" in e.description for e in suppressed)

    def test_specific_reraise_not_marked_suppressed_in_child_frame(self):
        def child_reraise():
            try:
                raise ValueError("test")
            except ValueError:
                raise  # re-raised, not suppressed

        def target_reraise():
            try:
                child_reraise()
            except ValueError:
                pass

        events = _run_guarded(target_reraise)
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]

        child_value_errors = [
            e for e in suppressed
            if e.details.get("exception_type") == "ValueError"
            and e.location.function == "child_reraise"
        ]
        assert child_value_errors == []

    def test_specific_pass_still_marked_suppressed_in_child_frame(self):
        def child_pass():
            try:
                raise ValueError("test")
            except ValueError:
                pass

        def target_pass():
            child_pass()

        events = _run_guarded(target_pass)
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]

        child_value_errors = [
            e for e in suppressed
            if e.details.get("exception_type") == "ValueError"
            and e.location.function == "child_pass"
        ]
        assert len(child_value_errors) >= 1

    def test_control_flow_exceptions_skipped(self):
        def target():
            def gen():
                yield 1
                yield 2

            for _ in gen():
                pass  # StopIteration is control flow

        events = _run_guarded(target)
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]
        stop_iter = [e for e in suppressed if "StopIteration" in e.description]
        assert len(stop_iter) == 0

    def test_detection_disabled(self):
        def target():
            try:
                raise RuntimeError("boom")
            except Exception:
                pass

        events = _run_guarded(target, detect_suppressed_exceptions=False)
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]
        assert len(suppressed) == 0


# ═══════════════════════════════════════════════════════════════════════
#  Environment variable mutation
# ═══════════════════════════════════════════════════════════════════════


class TestEnvMutation:
    def test_putenv_detected(self):
        key = "_SILENTGUARD_TEST_KEY_42"

        def target():
            os.environ[key] = "hello"

        events = _run_guarded(target)
        env_events = [e for e in events if e.kind == EventKind.ENV_MUTATION]
        assert any(key in e.description for e in env_events)

        # Cleanup
        os.environ.pop(key, None)

    def test_detection_disabled(self):
        key = "_SILENTGUARD_TEST_KEY_43"

        def target():
            os.environ[key] = "hello"

        events = _run_guarded(target, detect_env_mutation=False)
        env_events = [e for e in events if e.kind == EventKind.ENV_MUTATION]
        assert not any(key in e.description for e in env_events)

        os.environ.pop(key, None)


# ═══════════════════════════════════════════════════════════════════════
#  Decorator / context-manager
# ═══════════════════════════════════════════════════════════════════════


class TestGuardDecorator:
    def test_decorator_returns_value(self):
        @guard(detect_file_io=False, detect_network=False)
        def add(a, b):
            return a + b

        assert add(2, 3) == 5

    def test_context_manager(self):
        """Context-manager form wraps a code block in a session. Suppressed
        exceptions inside the block are recorded when the except handler and
        the raise/pass are inside a *separate* called function (trace hooks
        track per-frame events)."""

        def risky():
            try:
                raise RuntimeError("ctx test")
            except Exception:
                pass

        with guard(detect_file_io=False) as session:
            risky()

        events = session.events
        suppressed = [e for e in events if e.kind == EventKind.SUPPRESSED_EXCEPTION]
        assert len(suppressed) >= 1


# ═══════════════════════════════════════════════════════════════════════
#  Asyncio instrumentation
# ═══════════════════════════════════════════════════════════════════════


class TestAsyncioInstrumentation:
    def test_blocking_calls_inside_async_detected(self):
        path = os.path.join(tempfile.gettempdir(), "silentguard_async_blocking_test.txt")

        async def target_async():
            time.sleep(0.001)
            with open(path, "w", encoding="utf-8") as f:
                f.write("x")

        def target():
            asyncio.run(target_async())

        events = _run_guarded(target)
        asyncio_events = [e for e in events if e.kind == EventKind.ASYNCIO_SIDE_EFFECT]
        assert any("time.sleep" in e.description for e in asyncio_events)
        assert any("Synchronous file I/O" in e.description for e in asyncio_events)

        try:
            os.remove(path)
        except OSError:
            pass

    def test_task_creation_detected(self):
        async def worker():
            await asyncio.sleep(0)

        async def target_async():
            t1 = asyncio.create_task(worker())
            t2 = asyncio.ensure_future(worker())
            await t1
            await t2

        def target():
            asyncio.run(target_async())

        events = _run_guarded(target)
        asyncio_events = [e for e in events if e.kind == EventKind.ASYNCIO_SIDE_EFFECT]
        assert any("asyncio.create_task" in e.description for e in asyncio_events)
        assert any("asyncio.ensure_future" in e.description for e in asyncio_events)

    def test_event_loop_manipulation_detected(self):
        def target():
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                loop.set_debug(True)
                loop.stop()
            finally:
                loop.close()
                asyncio.set_event_loop(None)

        events = _run_guarded(target)
        asyncio_events = [e for e in events if e.kind == EventKind.ASYNCIO_SIDE_EFFECT]
        assert any("asyncio.new_event_loop" in e.description for e in asyncio_events)
        assert any("asyncio.set_event_loop" in e.description for e in asyncio_events)
        assert any("loop.set_debug(True)" in e.description for e in asyncio_events)

    def test_detection_disabled(self):
        async def worker():
            time.sleep(0.001)
            t = asyncio.create_task(asyncio.sleep(0))
            await t

        def target():
            loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(loop)
                loop.run_until_complete(worker())
            finally:
                loop.close()
                asyncio.set_event_loop(None)

        events = _run_guarded(target, detect_asyncio=False)
        asyncio_events = [e for e in events if e.kind == EventKind.ASYNCIO_SIDE_EFFECT]
        assert asyncio_events == []


# ═══════════════════════════════════════════════════════════════════════
#  Source scanner (static analysis)
# ═══════════════════════════════════════════════════════════════════════


class TestSourceScanner:
    def _scan_source(self, source: str):
        scanner = SourceScanner()
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            f.write(textwrap.dedent(source))
            f.flush()
            path = f.name
        try:
            return scanner.scan_file(path)
        finally:
            os.unlink(path)

    def test_bare_except(self):
        findings = self._scan_source("""
            try:
                pass
            except:
                pass
        """)
        assert any(f.category == "bare_except" for f in findings)

    def test_broad_except_with_pass(self):
        findings = self._scan_source("""
            try:
                pass
            except Exception:
                pass
        """)
        assert any(f.category == "silent_broad_except" for f in findings)

    def test_broad_except_with_handling(self):
        findings = self._scan_source("""
            import logging
            try:
                pass
            except Exception as e:
                logging.error(e)
        """)
        assert any(f.category == "broad_except" for f in findings)

    def test_dangerous_call(self):
        findings = self._scan_source("""
            import os
            os.system("echo hello")
        """)
        assert any(f.category == "dangerous_call" for f in findings)

    def test_global_statement(self):
        findings = self._scan_source("""
            counter = 0
            def increment():
                global counter
                counter += 1
        """)
        assert any(f.category == "global_mutation" for f in findings)

    def test_network_import(self):
        findings = self._scan_source("""
            import socket
        """)
        assert any(f.category == "network_import" for f in findings)

    def test_clean_code_no_findings(self):
        findings = self._scan_source("""
            def add(a: int, b: int) -> int:
                return a + b
        """)
        assert len(findings) == 0

    def test_syntax_error_handled(self):
        findings = self._scan_source("""
            def broken(
        """)
        assert any(f.category == "syntax_error" for f in findings)

    def test_scan_directory(self):
        scanner = SourceScanner()
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "sample.py")
            with open(path, "w") as f:
                f.write("try:\n    pass\nexcept:\n    pass\n")
            findings = scanner.scan_directory(d)
            assert any(f.category == "bare_except" for f in findings)

    def test_inline_ignore_suppresses_line(self):
        findings = self._scan_source("""
            try:
                pass
            except:  # silentguard: ignore
                pass
        """)
        assert findings == []

    def test_ignore_function_patterns(self):
        scanner = SourceScanner(GuardConfig(ignore_function_patterns=["ignore_me"]))
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            f.write(textwrap.dedent("""
                def ignore_me():
                    try:
                        pass
                    except:
                        pass
            """))
            f.flush()
            path = f.name
        try:
            findings = scanner.scan_file(path)
        finally:
            os.unlink(path)
        assert findings == []

    def test_disabled_scan_category_and_confidence_threshold(self):
        cfg = GuardConfig(disabled_scan_categories=["bare_except"])
        scanner = SourceScanner(cfg)
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            f.write("try:\n    pass\nexcept:\n    pass\n")
            f.flush()
            path = f.name
        try:
            findings = scanner.scan_file(path)
        finally:
            os.unlink(path)
        assert findings == []

    def test_min_confidence_threshold_applies_to_scan(self):
        cfg = GuardConfig(min_confidence=Confidence.HIGH)
        scanner = SourceScanner(cfg)
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        ) as f:
            f.write(textwrap.dedent("""
                def foo():
                    try:
                        x = 1 / 0
                    except RuntimeError:
                        pass
            """))
            f.flush()
            path = f.name
        try:
            findings = scanner.scan_file(path)
        finally:
            os.unlink(path)

        assert findings == []
