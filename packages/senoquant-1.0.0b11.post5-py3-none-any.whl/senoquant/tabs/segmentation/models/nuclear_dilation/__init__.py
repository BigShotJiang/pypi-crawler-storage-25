"""Nuclear dilation segmentation model."""
