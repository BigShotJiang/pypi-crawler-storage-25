"""Segmentation tab modules."""
