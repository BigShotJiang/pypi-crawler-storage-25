"""Unified topic constants for the MCFO platform.

All services MUST import and use these constants. Hardcoded topic strings are
a contract violation.

This module mirrors pkg/neonlink/topics.go. The two SDKs MUST stay in lockstep.
"""

# Waterfall topics -- main data pipeline.
# Each topic represents one stage in the sequential processing waterfall:
# goconnector -> findata -> finledger -> fininsight -> finedge
TOPIC_DATA_STAGED = "data-staged"
TOPIC_DATA_PROMOTED = "data-promoted"
TOPIC_POSTING_COMPLETED = "posting-completed"
TOPIC_INSIGHT_PUBLISHED = "insight-published"

# Connection lifecycle events from goconnector to finedge.
# Events: repair_required, new_accounts_detected, update_completed.
TOPIC_CONNECTION_LIFECYCLE = "connection-lifecycle"

# Side-channel topics -- request/response pairs outside the main waterfall.
#
# FX rate topics retained: findata publishes `fxrate-input` on first
# encounter of a currency outside the initial 20-currency seed set,
# and mcfo-fxrate replies on `fxrate-output`. gRPC handles the
# already-seeded currencies; Kafka handles new-currency discovery.
TOPIC_FINAI_INPUT = "finai-input"
TOPIC_FINAI_OUTPUT = "finai-output"

# TOPIC_GOALS_INPUT / TOPIC_GOALS_OUTPUT carry the full goals domain in/out
# channel. Producers/consumers route on `message_type` header -- DO NOT
# add a per-event-family topic. Recommendation lifecycle events
# (CREATED | APPROVED | EXECUTED | REJECTED) ride goals-output and are
# filtered by message_type by interested consumers.
TOPIC_GOALS_INPUT = "goals-input"
TOPIC_GOALS_OUTPUT = "goals-output"

TOPIC_FXRATE_INPUT = "fxrate-input"
TOPIC_FXRATE_OUTPUT = "fxrate-output"

# Advisor egress topics -- mcfo-finsor publishes notifications for downstream
# notification workers (push / email / webhook fanout).
#
# TOPIC_ADVISOR_NOTIFICATIONS carries advisor notification envelopes from
# mcfo-finsor's notify outbox worker to downstream notification consumers.
# Payload: AdvisorNotificationContext.
TOPIC_ADVISOR_NOTIFICATIONS = "advisor-notifications"

# Internal topics -- service self-loops. Each topic is owned by a single
# producer + consumer service (no cross-service traffic). Constants live here
# (not in the owning service) so the bootstrap <-> topics governance check has
# one place to enforce platform-wide.
#
# TOPIC_WEBHOOKS_INGRESS carries webhook ingress records inside mcfo-goconnector
# (CP outbox + webhook-worker -> webhook handler). Also receives config-reload
# control signals via WebhookConfigUpdateContext.
TOPIC_WEBHOOKS_INGRESS = "webhooks-ingress"

# TOPIC_BACKFILL_TRIGGER carries data sync continuation signals inside
# mcfo-goconnector (datasync-worker self-loop).
TOPIC_BACKFILL_TRIGGER = "backfill-trigger"

# Infrastructure topics.
#
# TOPIC_ERRORS_DLQ is the platform-wide system DLQ for any service that
# cannot route a record to its domain handler. Consumed by error-replay
# tooling. Long retention (90 days) per ops policy.
TOPIC_ERRORS_DLQ = "errors-dlq"

# TOPIC_NOTIFICATIONS_DLQ is the dead-letter surface for finedge's push
# notification dispatcher. Producer: mcfo-finedge dispatcher on terminal
# failure (invalid_token | retries_exhausted | permanent_4xx). Consumer:
# mcfo-finedge-ops-tool replay subcommand + monitoring pipelines.
# Postgres `notification_deliveries` remains canonical; this topic is the
# event stream powering monitoring + cross-region replay. 30 day retention
# sized for a typical replay window. Payload: NotificationDLQContext.
TOPIC_NOTIFICATIONS_DLQ = "notifications-dlq"
