"""Internal logging helper -- soft-import structlog with stdlib fallback.

The SDK MUST NOT configure structlog's processor chain, renderer, or
global settings. That is the consuming application's responsibility.
The SDK only calls structlog.get_logger() to obtain a bound logger.
"""

from __future__ import annotations

import logging

try:
    import structlog

    _HAS_STRUCTLOG = True
except ImportError:
    _HAS_STRUCTLOG = False


def get_logger(name: str):
    """Return a structlog bound logger if available, else stdlib logger.

    Both return types expose .info(), .warning(), .error(), .debug()
    with printf-style positional args, so no call-site changes are needed.
    """
    if _HAS_STRUCTLOG:
        return structlog.get_logger(name)
    return logging.getLogger(name)
