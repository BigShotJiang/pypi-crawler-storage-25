import threading
from .crypto import hash_data, sign_jws, generate_receipt_id, now_iso
from .http import HttpClient


def _strip_none(d: dict) -> dict:
    """Recursively remove keys with None values from a dict."""
    out = {}
    for k, v in d.items():
        if v is None:
            continue
        if isinstance(v, dict):
            out[k] = _strip_none(v)
        else:
            out[k] = v
    return out


class Signer:
    def __init__(self, did: str, key_id: str, private_jwk: dict, receipt_http: HttpClient):
        self.did = did
        self.key_id = key_id
        self.private_jwk = private_jwk
        self.receipt_http = receipt_http

    def record_action(
        self,
        action: str,
        capability: str,
        inputs: dict,
        outputs: dict,
        result: str = "success",
        counterparty_did: str = None,
        counterparty_key_id: str = None,
        parent_receipt_id: str = None,
        session_id: str = None,
        duration: int = None,
    ) -> dict:
        receipt_id = generate_receipt_id()
        timestamp = now_iso()

        # 1. Build receipt payload for signing (matches TS SDK structure)
        #    None values are skipped by canonicalize, matching JS undefined behavior
        receipt_for_signing = {
            "@context": "https://agent-trust.dev/ns/receipt/v1",
            "id": receipt_id,
            "type": "ActionReceipt",
            "agent": {"did": self.did, "keyId": self.key_id},
            "counterparty": (
                {"did": counterparty_did, "keyId": counterparty_key_id or ""}
                if counterparty_did
                else None
            ),
            "action": {
                "type": action,
                "description": action,
                "capability": capability,
            },
            "evidence": {
                "inputsHash": hash_data(inputs),
                "outputsHash": hash_data(outputs),
            },
            "timestamp": timestamp,
            "duration": duration,
            "result": {"status": result},
            "parentReceiptId": parent_receipt_id,
            "sessionId": session_id,
        }

        # 2. Sign: JWS payload is {receiptHash: sha256(canonicalized receipt)}
        receipt_hash = hash_data(receipt_for_signing)
        agent_signature = sign_jws(
            {"receiptHash": receipt_hash},
            self.private_jwk,
            self.key_id,
        )

        # 3. Build API request body (with raw inputs/outputs, not hashes)
        request_body = _strip_none({
            "id": receipt_id,
            "agent": {"did": self.did, "keyId": self.key_id},
            "counterparty": (
                {"did": counterparty_did, "keyId": counterparty_key_id or ""}
                if counterparty_did
                else None
            ),
            "action": {
                "type": action,
                "description": action,
                "capability": capability,
            },
            "inputs": inputs,
            "outputs": outputs,
            "timestamp": timestamp,
            "duration": duration,
            "result": {"status": result},
            "agentSignature": agent_signature,
            "parentReceiptId": parent_receipt_id,
            "sessionId": session_id,
        })

        # 4. Submit to receipt service
        submitted = self.receipt_http.request("POST", "/v1/receipts", request_body)
        return {**receipt_for_signing, "agentSignature": agent_signature, "_submitted": submitted}

    def record_action_async(self, **kwargs) -> None:
        """Fire-and-forget receipt submission via background thread."""
        thread = threading.Thread(
            target=self._submit_async, args=(kwargs,), daemon=True
        )
        thread.start()

    def _submit_async(self, kwargs: dict):
        try:
            self.record_action(**kwargs)
        except Exception as e:
            print(f"Failed to submit receipt: {e}")
