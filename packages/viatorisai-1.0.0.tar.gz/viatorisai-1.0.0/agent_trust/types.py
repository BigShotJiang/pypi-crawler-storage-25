from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RegisterOrgResult:
    org: dict
    api_key: str
    private_key_jwk: dict


@dataclass
class PassportResult:
    did: str
    private_key_jwk: dict
    key_id: str
    passport: dict


@dataclass
class ReputationResult:
    score: float
    confidence: float
    tasks_completed: int
    success_rate: float
    last_active: str


@dataclass
class ComplianceResult:
    compliant: bool
    matched_profile: Optional[str]
    gaps: list
