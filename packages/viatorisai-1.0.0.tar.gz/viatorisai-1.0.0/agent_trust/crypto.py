import base64
import hashlib
import json
import uuid
from datetime import datetime, timezone

from nacl.signing import SigningKey


def _b64url_encode(data: bytes) -> str:
    """Base64url encode without padding, matching jose library output."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    """Base64url decode, re-adding padding as needed."""
    s += "=" * (4 - len(s) % 4)
    return base64.urlsafe_b64decode(s)


def canonicalize(obj) -> str:
    """Canonical JSON matching the TypeScript SDK exactly.

    Rules:
    - Sorts object keys alphabetically
    - Skips keys where value is None (equivalent to JS undefined)
    - Recursively processes nested objects and arrays
    - Uses json.dumps for primitives (strings get quoted)
    - Booleans: "true"/"false" (JSON standard, not Python's True/False)
    """
    if obj is None:
        return "null"
    if isinstance(obj, bool):
        return "true" if obj else "false"
    if isinstance(obj, (int, float)):
        return json.dumps(obj)
    if isinstance(obj, str):
        return json.dumps(obj)
    if isinstance(obj, list):
        return "[" + ",".join(canonicalize(item) for item in obj) + "]"
    if isinstance(obj, dict):
        sorted_keys = sorted(k for k in obj.keys() if obj[k] is not None)
        entries = [json.dumps(k) + ":" + canonicalize(obj[k]) for k in sorted_keys]
        return "{" + ",".join(entries) + "}"
    return json.dumps(obj)


def hash_data(data) -> str:
    """SHA-256 hash of canonicalized data, matching TypeScript SDK."""
    canonical = data if isinstance(data, str) else canonicalize(data)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def generate_keypair() -> tuple[dict, dict]:
    """Generate Ed25519 keypair, returning (public_jwk, private_jwk)."""
    signing_key = SigningKey.generate()
    verify_key = signing_key.verify_key

    x = _b64url_encode(bytes(verify_key))
    d = _b64url_encode(bytes(signing_key)[:32])

    public_jwk = {"kty": "OKP", "crv": "Ed25519", "x": x}
    private_jwk = {"kty": "OKP", "crv": "Ed25519", "x": x, "d": d}
    return public_jwk, private_jwk


def sign_jws(payload: dict, private_jwk: dict, key_id: str) -> str:
    """Create a compact JWS (header.payload.signature) with EdDSA, matching jose library output."""
    header = {"alg": "EdDSA", "kid": key_id}
    header_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))

    full_payload = {**payload, "iat": int(datetime.now(timezone.utc).timestamp())}
    payload_b64 = _b64url_encode(json.dumps(full_payload, separators=(",", ":")).encode("utf-8"))

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")

    d_bytes = _b64url_decode(private_jwk["d"])
    signing_key = SigningKey(d_bytes)

    signed = signing_key.sign(signing_input)
    signature = signed.signature

    signature_b64 = _b64url_encode(signature)
    return f"{header_b64}.{payload_b64}.{signature_b64}"


def generate_receipt_id() -> str:
    return str(uuid.uuid4())


def now_iso() -> str:
    """UTC ISO timestamp ending in 'Z', matching JavaScript's toISOString()."""
    dt = datetime.now(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
