# packages/sdk/python/agent_trust/http.py

import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError


class HttpClient:
    def __init__(self, base_url: str, api_key: str, timeout: int):
        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout

    def request(self, method: str, path: str, body: dict = None) -> dict:
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        data = json.dumps(body).encode("utf-8") if body else None
        req = Request(url, data=data, headers=headers, method=method)

        try:
            with urlopen(req, timeout=self.timeout) as res:
                return json.loads(res.read().decode("utf-8"))
        except HTTPError as e:
            err = json.loads(e.read().decode("utf-8")) if e.fp else {}
            raise Exception(f"AgentTrust API error {e.code}: {json.dumps(err)}")
