import functools
import inspect
from urllib.parse import quote

from .http import HttpClient
from .signer import Signer
from .types import RegisterOrgResult, PassportResult, ReputationResult, ComplianceResult

DEFAULT_PASSPORT_URL = "https://api.viatoris.ai"
DEFAULT_RECEIPT_URL = "https://api-receipts.viatoris.ai"
DEFAULT_REPUTATION_URL = "https://api-reputation.viatoris.ai"
DEFAULT_COMPLIANCE_URL = "https://api-compliance.viatoris.ai"


class AgentTrust:
    def __init__(
        self,
        passport_url: str = DEFAULT_PASSPORT_URL,
        receipt_url: str = DEFAULT_RECEIPT_URL,
        reputation_url: str = DEFAULT_REPUTATION_URL,
        compliance_url: str = DEFAULT_COMPLIANCE_URL,
        org_api_key: str = "",
        timeout: int = 10,
    ):
        self.passport_http = HttpClient(passport_url, org_api_key, timeout)
        self.receipt_http = HttpClient(receipt_url, org_api_key, timeout)
        self.reputation_http = HttpClient(reputation_url, org_api_key, timeout)
        self.compliance_http = HttpClient(compliance_url, org_api_key, timeout)

    # --- Organization ---

    def register_org(self, name: str, domain: str, metadata: dict = None) -> RegisterOrgResult:
        result = self.passport_http.request("POST", "/v1/orgs", {
            "name": name,
            "domain": domain,
            "metadata": metadata or {},
        })
        return RegisterOrgResult(
            org=result.get("org", {}),
            api_key=result.get("apiKey", ""),
            private_key_jwk=result.get("privateKeyJwk", {}),
        )

    # --- Passport ---

    def create_passport(
        self,
        agent_id: str,
        controller_did: str,
        metadata: dict = None,
        service_endpoints: list = None,
    ) -> PassportResult:
        result = self.passport_http.request("POST", "/v1/passports", {
            "agentId": agent_id,
            "controllerDid": controller_did,
            "metadata": metadata or {},
            "serviceEndpoints": service_endpoints,
        })

        passport = result.get("passport", {})
        did = passport.get("id", "")
        key_id = f"{did}#key-1"

        return PassportResult(
            did=did,
            private_key_jwk=result.get("privateKeyJwk", {}),
            key_id=key_id,
            passport=passport,
        )

    def resolve_passport(self, did: str) -> dict:
        return self.passport_http.request(
            "GET", f"/v1/passports/{quote(did, safe='')}"
        )

    # --- Signer ---

    def create_signer(self, passport: PassportResult) -> Signer:
        return Signer(
            passport.did,
            passport.key_id,
            passport.private_key_jwk,
            self.receipt_http,
        )

    # --- Decorator pattern ---

    def track(self, passport: PassportResult, capability: str):
        """Decorator that records a receipt for each function call (non-blocking)."""
        signer = self.create_signer(passport)

        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                sig = inspect.signature(func)
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                inputs = dict(bound.arguments)

                result = "success"
                outputs = {}
                try:
                    outputs = func(*args, **kwargs)
                    return outputs
                except Exception as e:
                    outputs = {"error": str(e)}
                    result = "failure"
                    raise
                finally:
                    signer.record_action_async(
                        action=func.__name__,
                        capability=capability,
                        inputs=inputs,
                        outputs=outputs if isinstance(outputs, dict) else {"result": outputs},
                        result=result,
                    )

            return wrapper
        return decorator

    # --- Receipts ---

    def get_receipt(self, receipt_id: str) -> dict:
        return self.receipt_http.request(
            "GET", f"/v1/receipts/{quote(receipt_id, safe='')}"
        )

    def list_receipts(self, agent_did: str = None, session_id: str = None,
                      limit: int = None, offset: int = None) -> list:
        params = []
        if agent_did:
            params.append(f"agent={quote(agent_did, safe='')}")
        if session_id:
            params.append(f"session={quote(session_id, safe='')}")
        if limit is not None:
            params.append(f"limit={limit}")
        if offset is not None:
            params.append(f"offset={offset}")
        qs = "&".join(params)
        return self.receipt_http.request("GET", f"/v1/receipts?{qs}")

    # --- Reputation ---

    def get_reputation(self, agent_did: str, scope: str = None) -> dict:
        query = f"?scope={quote(scope, safe='')}" if scope else ""
        return self.reputation_http.request(
            "GET", f"/v1/reputation/{quote(agent_did, safe='')}{query}"
        )

    def recompute_reputation(self, agent_did: str) -> dict:
        return self.reputation_http.request(
            "POST", "/v1/reputation/recompute", {"agentDid": agent_did}
        )

    # --- Compliance ---

    def check_compliance(
        self, agent_did: str, framework: str = None, requires: dict = None
    ) -> ComplianceResult:
        result = self.compliance_http.request("POST", "/v1/compliance/evaluate", {
            "agentDid": agent_did,
            "requirements": {
                "framework": framework,
                "constraints": requires or {},
            },
        })
        return ComplianceResult(
            compliant=result.get("compliant", False),
            matched_profile=result.get("matchedProfile"),
            gaps=result.get("gaps", []),
        )

    def list_templates(self) -> list:
        return self.compliance_http.request("GET", "/v1/compliance/templates")

    def get_compliance_profiles(self, agent_did: str) -> dict:
        return self.compliance_http.request(
            "GET", f"/v1/compliance/profiles/{quote(agent_did, safe='')}"
        )

    def create_compliance_profile(self, profile: dict) -> dict:
        return self.compliance_http.request(
            "POST", "/v1/compliance/profiles", profile
        )
