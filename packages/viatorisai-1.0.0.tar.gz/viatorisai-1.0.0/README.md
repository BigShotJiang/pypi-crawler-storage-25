# Viatoris Python SDK

Trust infrastructure for AI agents — cryptographic identity, signed receipts, and audit trails.

Built on W3C DIDs and Ed25519 signatures. Works with any agent framework: LangChain, CrewAI, AutoGen, or your own.

## Install

```bash
pip install viatorisai
```

Requires Python 3.10+. Only dependency is `PyNaCl` for Ed25519 signing.

## Quick Start

Get an API key from [dashboard.viatoris.ai](https://dashboard.viatoris.ai/signup), then:

```python
from agent_trust import AgentTrust

client = AgentTrust(org_api_key="at_live_...")

# Create an agent — generates an Ed25519 key pair locally
passport = client.create_passport(
    agent_id="scout-1",
    controller_did="did:web:example.com",
    metadata={
        "name": "Scout",
        "description": "Research agent",
        "version": "1.0.0",
        "agentType": "autonomous",
        "capabilities": ["search"],
    },
)
# IMPORTANT: save passport.private_key_jwk securely — only returned once.

# Sign and submit a receipt
signer = client.create_signer(passport)
signer.record_action(
    action="web-search",
    capability="research",
    inputs={"query": "AI safety papers"},
    outputs={"results": 12},
    result="success",
)
```

## Decorator pattern

Wrap any function with `@client.track` to automatically emit a signed receipt for every call. Inputs and outputs are captured from the function signature, and submission is fire-and-forget so it never adds latency.

```python
@client.track(passport, capability="research")
def search(query: str):
    return {"results": do_search(query)}

# Each call to search(...) now produces a signed receipt in the background.
search("AI safety papers")
```

If the wrapped function raises, the receipt is recorded with `result="failure"` and the exception is re-raised.

## Fire-and-forget receipts

For inline call sites where you don't want a decorator, use `record_action_async` to submit on a background thread:

```python
signer.record_action_async(
    action="web-search",
    capability="research",
    inputs={"query": "AI safety papers"},
    outputs={"results": 12},
    result="success",
)
# Returns immediately. Errors are logged, never raised.
```

## What you get

- **Cryptographic identity** — every agent has a W3C DID and Ed25519 key pair. Private keys never leave your process.
- **Signed receipts** — every action produces a tamper-proof, timestamped record. Inputs and outputs are SHA-256 hashed before signing, so payload contents stay private.
- **Public verification** — anyone can verify an agent's identity and receipts via `https://api.viatoris.ai/v1/verify/<did>`. No API key required.
- **Reputation scoring** — Wilson score confidence intervals computed from your verified receipt history.
- **Compliance profiles** — attach HIPAA, SOC2, GDPR, or custom policy declarations to your agents.

## Documentation

Full guide at [viatoris.ai/quickstart](https://viatoris.ai/quickstart).

Questions? Email [jared@viatoris.ai](mailto:jared@viatoris.ai).

## License

MIT
