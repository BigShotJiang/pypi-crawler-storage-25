from setuptools import setup, find_packages

setup(
    name="viatorisai",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.10",
    description="Python SDK for the Agent Trust Protocol — verifiable identity, cryptographic receipts, and reputation scoring for AI agents",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="Jared",
    author_email="jared@viatoris.ai",
    url="https://viatoris.ai",
    project_urls={
        "Bug Tracker": "https://github.com/ViatorisAI/viatoris-core/issues",
        "Source": "https://github.com/ViatorisAI/viatoris-core/tree/main/packages/sdk/python",
        "Documentation": "https://viatoris.ai/quickstart",
    },
    install_requires=[
        "PyNaCl>=1.5.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Security :: Cryptography",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    license="MIT",
    keywords="ai-agent identity ed25519 w3c-did agent-trust-protocol",
)
