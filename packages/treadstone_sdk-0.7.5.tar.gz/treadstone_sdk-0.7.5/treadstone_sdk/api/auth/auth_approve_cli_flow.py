from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.auth_approve_cli_flow_response_auth_approve_cli_flow import AuthApproveCliFlowResponseAuthApproveCliFlow
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    flow_id: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/cli/flows/{flow_id}/approve".format(
            flow_id=quote(str(flow_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AuthApproveCliFlowResponseAuthApproveCliFlow.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    flow_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError]:
    """Approve Cli Flow

     Approve a pending CLI login flow using the current browser session.

    Args:
        flow_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        flow_id=flow_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    flow_id: str,
    *,
    client: AuthenticatedClient,
) -> AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError | None:
    """Approve Cli Flow

     Approve a pending CLI login flow using the current browser session.

    Args:
        flow_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError
    """

    return sync_detailed(
        flow_id=flow_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    flow_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError]:
    """Approve Cli Flow

     Approve a pending CLI login flow using the current browser session.

    Args:
        flow_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        flow_id=flow_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    flow_id: str,
    *,
    client: AuthenticatedClient,
) -> AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError | None:
    """Approve Cli Flow

     Approve a pending CLI login flow using the current browser session.

    Args:
        flow_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthApproveCliFlowResponseAuthApproveCliFlow | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            flow_id=flow_id,
            client=client,
        )
    ).parsed
