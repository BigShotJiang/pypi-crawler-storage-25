import os
from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pyhand-core",
    version="1.0.6",
    packages=find_packages(),
    python_requires=">=3.12",
    long_description=long_description,
    description="A lightweight toolkit for absolute architectural freedom in Python.",
    license="MIT",
    author="XiaoYi",
    author_email="xiao.yi.chan.tw@gmail.com",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    url="https://github.com/xiaoyi-2012/pyhand",
    readme = "README.md"
)
