# care-log-utils

A Python toolkit for care workers, rota systems, and care management software.

## Features

- Shift slot detection (Morning / Lunch / Tea / Tuck)
- Visit duration calculation
- Care rota helper utilities

## Installation

```bash
pip install care-log-utils


Usage

from care_log_utils import detect_shift_slot, visit_duration

print(detect_shift_slot("13:20"))
print(visit_duration("09:00", "10:30"))


Output

Lunch
90


Author

Austine Onwubiko