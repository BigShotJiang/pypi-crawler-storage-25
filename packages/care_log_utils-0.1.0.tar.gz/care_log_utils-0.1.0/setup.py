from setuptools import setup, find_packages

setup(
    name="care-log-utils",
    version="0.1.0",
    author="Austine Onwubiko",
    author_email="austineonwubiko@gmail.com",
    description="Utilities for care logging systems, shift detection, and rota helpers",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)