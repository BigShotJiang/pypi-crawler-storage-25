from datetime import datetime


def visit_duration(start, end):
    """
    Calculate visit duration in minutes.

    Example:
    09:00 -> 10:30 = 90
    """

    start_time = datetime.strptime(start, "%H:%M")
    end_time = datetime.strptime(end, "%H:%M")

    duration = end_time - start_time

    return int(duration.total_seconds() / 60)