from .shifts import detect_shift_slot
from .duration import visit_duration