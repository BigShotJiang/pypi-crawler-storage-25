from datetime import datetime


def detect_shift_slot(time_string):
    """
    Detect care shift slot based on time.

    Example:
    13:20 -> Lunch
    """

    time_obj = datetime.strptime(time_string, "%H:%M").time()

    if (
        datetime.strptime("07:00", "%H:%M").time()
        <= time_obj
        <= datetime.strptime("11:30", "%H:%M").time()
    ):
        return "Morning"

    elif (
        datetime.strptime("11:40", "%H:%M").time()
        <= time_obj
        <= datetime.strptime("14:30", "%H:%M").time()
    ):
        return "Lunch"

    elif (
        datetime.strptime("15:30", "%H:%M").time()
        <= time_obj
        <= datetime.strptime("18:30", "%H:%M").time()
    ):
        return "Tea"

    elif (
        datetime.strptime("19:00", "%H:%M").time()
        <= time_obj
        <= datetime.strptime("22:00", "%H:%M").time()
    ):
        return "Tuck"

    return "Out"