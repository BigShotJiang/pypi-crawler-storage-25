"""Packaged ModelPreflight config presets."""
