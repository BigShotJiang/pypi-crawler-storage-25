# This file is a part of Remoulade.
#
# Copyright (C) 2017,2018 CLEARTYPE SRL <bogdan@cleartype.io>
#
# Remoulade is free software; you can redistribute it and/or modify it
# under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at
# your option) any later version.
#
# Remoulade is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public
# License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import warnings

try:
    from .stub import StubBackend
except ImportError:
    warnings.warn(
        "StubBackend is not available.  Run `pip install remoulade[limits]` to add support for that backend.",
        ImportWarning,
        stacklevel=2,
    )


try:
    from .redis import RedisBackend
except ImportError:  # pragma: no cover
    warnings.warn(
        "RedisBackend is not available.  Run `pip install remoulade[limits,redis]` to add support for that backend.",
        ImportWarning,
        stacklevel=2,
    )


__all__ = ["RedisBackend", "StubBackend"]
