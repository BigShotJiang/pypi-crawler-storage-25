class DecoError(Exception):
    pass
