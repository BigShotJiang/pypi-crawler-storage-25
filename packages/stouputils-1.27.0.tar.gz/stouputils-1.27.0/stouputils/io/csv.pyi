import pandas as pd
import polars as pl
from .path import super_open as super_open
from typing import Any, IO, Literal, overload

def csv_dump(data: Any, file: IO[Any] | str | None = None, delimiter: str = ',', has_header: bool = True, index: bool = False, *args: Any, **kwargs: Any) -> str:
    ''' Writes data to a CSV file with customizable options and returns the CSV content as a string.

\tArgs:
\t\tdata\t\t(list[list[Any]] | list[dict[str, Any]] | pd.DataFrame | pl.DataFrame):
\t\t\t\t\t\tThe data to write, either a list of lists, list of dicts, pandas DataFrame, or Polars DataFrame
\t\tfile\t\t(IO[Any] | str): The file object or path to dump the data to
\t\tdelimiter\t(str): The delimiter to use (default: \',\')
\t\thas_header\t(bool): Whether to include headers (default: True, applies to dict and DataFrame data)
\t\tindex\t\t(bool): Whether to include the index (default: False, only applies to pandas DataFrame)
\t\t*args\t\t(Any): Additional positional arguments to pass to the underlying CSV writer or DataFrame method
\t\t**kwargs\t(Any): Additional keyword arguments to pass to the underlying CSV writer or DataFrame method
\tReturns:
\t\tstr: The CSV content as a string

\tExamples:

\t\t>>> csv_dump([["a", "b", "c"], [1, 2, 3], [4, 5, 6]])
\t\t\'a,b,c\\r\\n1,2,3\\r\\n4,5,6\\r\\n\'

\t\t>>> csv_dump([{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}])
\t\t\'name,age\\r\\nAlice,30\\r\\nBob,25\\r\\n\'
\t'''
@overload
def csv_load(file_path: str, delimiter: str = ',', has_header: bool = True, as_dict: bool = False, *, as_dataframe: Literal[True], use_polars: Literal[True], **kwargs: Any) -> pl.DataFrame: ...
@overload
def csv_load(file_path: str, delimiter: str = ',', has_header: bool = True, as_dict: bool = False, *, as_dataframe: Literal[True], use_polars: Literal[False] = False, **kwargs: Any) -> pd.DataFrame: ...
@overload
def csv_load(file_path: str, delimiter: str = ',', has_header: bool = True, *, as_dict: Literal[True], as_dataframe: bool = False, use_polars: bool = False, **kwargs: Any) -> list[dict[str, str]]: ...
@overload
def csv_load(file_path: str, delimiter: str = ',', has_header: bool = True, as_dict: bool = False, as_dataframe: bool = False, use_polars: bool = False, *args: Any, **kwargs: Any) -> list[list[str]]: ...
