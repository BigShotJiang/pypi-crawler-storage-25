from ...continuous_delivery import version_to_float as version_to_float
from ...decorators import simple_cache as simple_cache
from ...io.path import super_open as super_open
from ...print.message import info as info
from collections.abc import Callable as Callable

def check_base_dependencies() -> None:
    """ Check for each auto-docs requirement if it is installed.

\tRaises:
\t\tImportError: If any requirement from ``Cfg.AUTO_DOCS_REQUIREMENTS`` is not installed
\t"""
def download_asset(url: str, target_path: str) -> None:
    """ Download a file from a URL to a local path.

\tArgs:
\t\turl         (str): URL to download from
\t\ttarget_path (str): Local file path to save to
\t"""
@simple_cache
def get_versions_from_github(github_user: str, github_repo: str, recent_minor_versions: int = 2) -> list[str]:
    """ Get list of versions from GitHub gh-pages branch.
\tOnly shows detailed versions for the last N minor versions, and keeps only
\tthe latest patch version for older minor versions.

\tArgs:
\t\tgithub_user             (str): GitHub username
\t\tgithub_repo             (str): GitHub repository name
\t\trecent_minor_versions   (int): Number of recent minor versions to show all patches for (-1 for all).

\tReturns:
\t\tlist[str]: List of versions, with 'latest' as first element
\t"""
def generate_version_selector(github_user: str, github_repo: str, get_versions_function: Callable[[str, str, int], list[str]] = ..., recent_minor_versions: int = 2) -> str:
    """ Generate the HTML version selector string from GitHub versions.

\tArgs:
\t\tgithub_user            (str): GitHub username
\t\tgithub_repo            (str): GitHub repository name
\t\tget_versions_function  (Callable[[str, str, int], list[str]]): Function to get versions from GitHub
\t\trecent_minor_versions  (int): Number of recent minor versions to show all patches for. Defaults to 2

\tReturns:
\t\tstr: Markdown string with version links (e.g. ``**Versions**: latest, v1.0.0, ...``)
\t"""
def generate_redirect_html(filepath: str) -> None:
    """ Generate HTML content for redirect page.

\tArgs:
\t\tfilepath (str): Path to the file where the HTML content should be written
\t"""
