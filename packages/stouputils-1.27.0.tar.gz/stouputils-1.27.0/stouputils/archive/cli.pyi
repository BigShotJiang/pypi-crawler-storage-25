from ..print.message import debug as debug, error as error, info as info
from .make_archive import make_archive as make_archive
from .repair_zip_file import repair_zip_file as repair_zip_file

def archive_cli() -> None:
    ''' Main entry point for command line usage.

\tExamples:

\t.. code-block:: bash

\t\t# Repair a corrupted zip file
\t\tpython -m stouputils.archive repair /path/to/corrupted.zip /path/to/repaired.zip

\t\t# Create a zip archive
\t\tpython -m stouputils.archive make /path/to/source /path/to/destination.zip

\t\t# Create a zip archive with ignore patterns
\t\tpython -m stouputils.archive make /path/to/source /path/to/destination.zip --ignore "*.pyc,__pycache__"
\t'''
