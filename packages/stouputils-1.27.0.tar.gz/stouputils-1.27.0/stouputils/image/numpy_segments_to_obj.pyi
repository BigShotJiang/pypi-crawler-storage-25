from ..io.path import super_open as super_open
from ..print.message import debug as debug, info as info
from ..typing import is_generic_instance as is_generic_instance
from .numpy_to_obj import extract_verts_faces_from_segment as extract_verts_faces_from_segment
from numpy.typing import NDArray
from typing import Any

def add_default_colors_to_segments(segments: list[NDArray[Any]], skip_unique_color: bool = False) -> list[tuple[NDArray[Any], tuple[float, float, float, float]]]:
    """ Ensure all segments have an associated RGB color. If a segment is provided as a bare array, assign it a default color.

\tArgs:
\t\tsegments (list): List of segments, where each segment is either a 3D array or a tuple of (array, rgba_color).
\t\tskip_unique_color (bool): If True, do not assign a unique color to the first segment.
\tReturns:
\t\tlist[tuple[NDArray, tuple[float, float, float, float]]]: List of segments as (array, rgba_color) tuples, with default colors assigned where needed.
\t"""
def numpy_segments_to_obj(path: str, segments: list[tuple[NDArray[Any], tuple[float, float, float, float]]] | list[NDArray[Any]], spacing: tuple[float, float, float] = (1.0, 1.0, 1.0), threshold: float = 0.5, step_size: int = 1, pad_array: bool = True, verbose: int = 0) -> None:
    ''' Generate a \'.obj\' file from multiple segmentation arrays, each with its own color.

\tArgs:
\t\tpath      (str):  Path to the output .obj file (a .mtl file is created alongside it).
\t\tsegments  (list): List of (array, rgb_color) tuples. Each array is a 3D segmentation mask.
\t\t\tRGB values should be floats in [0.0, 1.0].
\t\tspacing   (tuple): Voxel spacing along each axis, passed to marching cubes.
\t\tthreshold (float): Iso-surface threshold for marching cubes (0.5 for binary masks).
\t\tstep_size (int):   Step size for marching cubes (higher = coarser mesh, faster).
\t\tpad_array (bool):  Pad each array with zeros to close border surfaces.
\t\tverbose   (int):   Verbosity level.
\tExamples:
\t\t.. code-block:: python
\t\t\t> numpy_segments_to_obj(
\t\t\t>     "brain_segs.obj",
\t\t\t>     segments=[
\t\t\t>         (white_matter, (1.0, 1.0, 1.0)),
\t\t\t>         (grey_matter,  (0.7, 0.5, 0.5)),
\t\t\t>         (tumor,        (1.0, 0.0, 0.0)),
\t\t\t>     ],
\t\t\t>     spacing=(0.5, 0.5, 1.0),
\t\t\t> )
\t'''
