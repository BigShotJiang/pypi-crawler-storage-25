from ..typing import CallableAny as CallableAny

def get_function_name(func: CallableAny) -> str:
    ''' Get the name of a function, returns "<unknown>" if the name cannot be retrieved. '''
def get_wrapper_name(decorator_name: str, func: CallableAny) -> str:
    ''' Get a descriptive name for a wrapper function.

\tArgs:
\t\tdecorator_name\t(str):\t\t\t\t\tName of the decorator
\t\tfunc\t\t\t(CallableAny):\t\t\tFunction being decorated
\tReturns:
\t\tstr: Combined name for the wrapper function (e.g., "stouputils.decorators.handle_error@function_name")
\t'''
def set_wrapper_name(wrapper: CallableAny, name: str) -> None:
    """ Set the wrapper function's visible name (code object name) for clearer tracebacks.

\tArgs:
\t\twrapper\t(CallableAny):\tWrapper function to update
\t\tname\t(str):\t\t\tNew name to set
\t"""
