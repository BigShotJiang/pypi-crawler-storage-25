from ..ctx.measure_time import MeasureTime as MeasureTime
from ..print.message import progress as progress
from .common import get_function_name as get_function_name, get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable, Generator
from typing import Literal, overload

@overload
def measure_time[T](func: Callable[..., Generator[T, None, None]], *, printer: Callable[..., None] = ..., message: str = '', perf_counter: bool = True, is_generator: Literal[True]) -> Callable[..., Generator[T, None, None]]: ...
@overload
def measure_time[T](func: None = None, *, printer: Callable[..., None] = ..., message: str = '', perf_counter: bool = True, is_generator: Literal[True]) -> Callable[[Callable[..., Generator[T, None, None]]], Callable[..., Generator[T, None, None]]]: ...
@overload
def measure_time[T](func: Callable[..., T], *, printer: Callable[..., None] = ..., message: str = '', perf_counter: bool = True, is_generator: Literal[False] = False) -> Callable[..., T]: ...
@overload
def measure_time[T](func: None = None, *, printer: Callable[..., None] = ..., message: str = '', perf_counter: bool = True, is_generator: Literal[False] = False) -> Callable[[Callable[..., T]], Callable[..., T]]: ...
