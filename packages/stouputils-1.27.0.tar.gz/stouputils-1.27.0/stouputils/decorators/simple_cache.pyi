from .common import get_wrapper_name as get_wrapper_name, set_wrapper_name as set_wrapper_name
from collections.abc import Callable as Callable
from typing import Any, Literal, overload

@overload
def simple_cache[T](func: Callable[..., T], *, method: Literal['str', 'pickle'] | Callable[[tuple[Any, ...], dict[str, Any]], Any] = 'str') -> Callable[..., T]: ...
@overload
def simple_cache[T](func: None = None, *, method: Literal['str', 'pickle'] | Callable[[tuple[Any, ...], dict[str, Any]], Any] = 'str') -> Callable[[Callable[..., T]], Callable[..., T]]: ...
