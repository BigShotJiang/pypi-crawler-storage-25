import polars as pl
from typing import Any

def upsert_in_dataframe(df: pl.DataFrame, new_entry: dict[str, Any], primary_keys: list[str] | dict[str, Any] | None = None) -> pl.DataFrame:
    ''' Insert or update a row in the Polars DataFrame based on primary keys.

\tArgs:
\t\tdf\t\t\t\t(pl.DataFrame):\t\tThe Polars DataFrame to update.
\t\tnew_entry\t\t(dict[str, Any]):\tThe new entry to insert or update.
\t\tprimary_keys\t(list[str] | dict[str, Any] | None):\tThe primary keys to identify the row (for updates).
\tReturns:
\t\tpl.DataFrame: The updated Polars DataFrame.
\tExamples:
\t\t>>> import polars as pl
\t\t>>> df = pl.DataFrame({"id": [1, 2], "value": ["a", "b"]})
\t\t>>> new_entry = {"id": 2, "value": "updated"}
\t\t>>> updated_df = upsert_in_dataframe(df, new_entry, primary_keys=["id"])
\t\t>>> print(updated_df)
\t\tshape: (2, 2)
\t\t┌─────┬─────────┐
\t\t│ id  ┆ value   │
\t\t│ --- ┆ ---     │
\t\t│ i64 ┆ str     │
\t\t╞═════╪═════════╡
\t\t│ 1   ┆ a       │
\t\t│ 2   ┆ updated │
\t\t└─────┴─────────┘

\t\t>>> new_entry = {"id": 3, "value": "new"}
\t\t>>> updated_df = upsert_in_dataframe(updated_df, new_entry, primary_keys=["id"])
\t\t>>> print(updated_df)
\t\tshape: (3, 2)
\t\t┌─────┬─────────┐
\t\t│ id  ┆ value   │
\t\t│ --- ┆ ---     │
\t\t│ i64 ┆ str     │
\t\t╞═════╪═════════╡
\t\t│ 1   ┆ a       │
\t\t│ 2   ┆ updated │
\t\t│ 3   ┆ new     │
\t\t└─────┴─────────┘
\t'''
