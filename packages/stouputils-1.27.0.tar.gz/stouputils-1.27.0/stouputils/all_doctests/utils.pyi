from ..ctx.measure_time import MeasureTime as MeasureTime
from ..print.message import progress as progress
from doctest import TestResults as TestResults
from types import ModuleType

def test_module_with_progress(module: ModuleType, separator: str) -> TestResults:
    """ Test a module with testmod and measure the time taken with progress printing.

\tArgs:
\t\tmodule\t\t(ModuleType):\tModule to test
\t\tseparator\t(str):\t\t\tSeparator string for alignment in output
\tReturns:
\t\tTestResults: The results of the tests
\t"""
