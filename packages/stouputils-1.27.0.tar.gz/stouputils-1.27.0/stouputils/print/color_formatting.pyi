from typing import Any, TextIO

def format_colored(*values: Any, color: str = ...) -> str:
    ''' Format text with Python 3.14 style colored formatting.

\tDynamically colors text by analyzing each word:
\t- File paths in the specified color
\t- Numbers in the specified color
\t- Function names (built-in and callable objects) in the specified color
\t- Exception names in bold with the specified color

\tArgs:
\t\tvalues\t(Any):\tValues to format (like the print function)
\t\tcolor\t(str):\tANSI color code to use for coloring (default: Cfg.MAGENTA)

\tReturns:
\t\tstr: The formatted text with ANSI color codes

\tExamples:
\t\t>>> # Test function names with parentheses
\t\t>>> result = format_colored("Call print() with 42 items")
\t\t>>> m, r, b = Cfg.MAGENTA, Cfg.RESET, Cfg.BOLD
\t\t>>> result == f"Call {m}print{r}() with {m}42{r} items"
\t\tTrue

\t\t>>> # Test function names without parentheses
\t\t>>> result = format_colored("Use len and sum functions")
\t\t>>> result == f"Use {m}len{r} and {m}sum{r} functions"
\t\tTrue

\t\t>>> # Test exceptions (bold magenta)
\t\t>>> result = format_colored("Got ValueError when parsing")
\t\t>>> result == f"Got {b}{m}ValueError{r} when parsing"
\t\tTrue

\t\t>>> # Test file paths
\t\t>>> result = format_colored("Processing ./data.csv file")
\t\t>>> result == f"Processing {m}./data.csv{r} file"
\t\tTrue
\t\t>>> result = format_colored("Processing ./data/some/sub/directory")
\t\t>>> result == f"Processing {m}./data/some/sub/directory{r}"
\t\tTrue
\t\t>>> result = format_colored("This is not a path: batches/images")
\t\t>>> result == "This is not a path: batches/images"
\t\tTrue

\t\t>>> # Test file paths with quotes
\t\t>>> result = format_colored(\'File "/path/to/script.py" line 42\')
\t\t>>> result == f\'File {m}"/path/to/script.py"{r} line {m}42{r}\'
\t\tTrue

\t\t>>> # Test numbers
\t\t>>> result = format_colored("Found 100 items and 3.14 value, 3.0e+10 is big")
\t\t>>> result == f"Found {m}100{r} items and {m}3.14{r} value, {m}3.0e+10{r} is big"
\t\tTrue

\t\t>>> # Test numbers embedded in non-numeric tokens (both must be colored the same)
\t\t>>> result = format_colored("scale=(0.5, 0.5), overlap=(0.0, 0.0)")
\t\t>>> result == f"scale=({m}0.5{r}, {m}0.5{r}), overlap=({m}0.0{r}, {m}0.0{r})"
\t\tTrue
\t\t>>> result = format_colored("took: 2.885ms")
\t\t>>> result == f"took: {m}2.885{r}ms"
\t\tTrue

\t\t>>> # Test mixed content
\t\t>>> result = format_colored("Call sum() got IndexError at line 256 in utils.py")
\t\t>>> result == f"Call {m}sum{r}() got {b}{m}IndexError{r} at line {m}256{r} in utils.py"
\t\tTrue

\t\t>>> # Test keywords always colored
\t\t>>> result = format_colored("Check class dtype type")
\t\t>>> result == f"Check {m}class{r} {m}dtype{r} {m}type{r}"
\t\tTrue

\t\t>>> # Test plain text (no coloring)
\t\t>>> result = format_colored("This is plain text")
\t\t>>> result == "This is plain text"
\t\tTrue

\t\t>>> # Affix punctuation should not be colored (assert exact coloring, punctuation uncolored)
\t\t>>> result = format_colored("<class")
\t\t>>> result == f"<{m}class{r}"
\t\tTrue
\t\t>>> result = format_colored("(dtype:")
\t\t>>> result == f"({m}dtype{r}:"
\t\tTrue
\t\t>>> result = format_colored("[1.")
\t\t>>> result == f"[{m}1{r}."
\t\tTrue

\t\t>>> # Test complex
\t\t>>> text = "<class \'numpy.ndarray\'>, <id 14036>: (dtype: float32, shape: (6,), min: 0.0, max: 1.0) [1. 0. 0. 0. 1. 0.]"
\t\t>>> result = format_colored(text)
\t\t>>> result == f"<{m}class{r} {m}\'numpy.ndarray\'{r}>, <{m}id{r} {m}14036{r}>: ({m}dtype{r}: float{m}32{r}, shape: ({m}6{r},), {m}min{r}: {m}0.0{r}, {m}max{r}: {m}1.0{r}) [{m}1{r}. {m}0{r}. {m}0{r}. {m}0{r}. {m}1{r}. {m}0{r}.]"
\t\tTrue
\t\t>>> result = format_colored("Specimen: \'C-B250021834A02HES002-NH4\': 24.29029s")
\t\t>>> result == f"Specimen: {m}\'C-B250021834A02HES002-NH4\'{r}: {m}24.29029{r}s"
\t\tTrue
\t'''
def colored(*values: Any, file: TextIO | None = None, **print_kwargs: Any) -> None:
    ''' Print with Python 3.14 style colored formatting.

\tDynamically colors text by analyzing each word:
\t- File paths in magenta
\t- Numbers in magenta
\t- Function names (built-in and callable objects) in magenta
\t- Exception names in bold magenta

\tArgs:
\t\tvalues\t\t\t(Any):\t\tValues to print (like the print function)
\t\tfile\t\t\t(TextIO):\tFile to write the message to (default: sys.stdout)
\t\tprint_kwargs\t(dict):\t\tKeyword arguments to pass to the print function

\tExamples:
\t\t>>> colored("File \'/path/to/file.py\', line 42, in function_name")  # doctest: +SKIP
\t\t>>> colored("KeyboardInterrupt")  # doctest: +SKIP
\t\t>>> colored("Processing data.csv with 100 items")  # doctest: +SKIP
\t\t>>> colored("Using print and len functions")  # doctest: +SKIP
\t'''
