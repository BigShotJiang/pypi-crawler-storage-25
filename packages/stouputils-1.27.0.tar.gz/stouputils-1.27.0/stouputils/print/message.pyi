from .color_formatting import format_colored as format_colored
from .common import PrintMemory as PrintMemory
from .utils import current_time as current_time, is_same_print as is_same_print
from typing import Any, TextIO

def info(*values: Any, color: str = ..., text: str = 'INFO ', prefix: str = '', file: TextIO | list[TextIO] | None = None, use_colored: bool = False, **print_kwargs: Any) -> None:
    ''' Print an information message looking like "[INFO HH:MM:SS] message" in green by default.

\tArgs:
\t\tvalues\t\t\t(Any):\t\t\t\t\tValues to print (like the print function)
\t\tcolor\t\t\t(str):\t\t\t\t\tColor of the message (default: GREEN)
\t\ttext\t\t\t(str):\t\t\t\t\tText of the message (default: "INFO ")
\t\tprefix\t\t\t(str):\t\t\t\t\tPrefix to add to the values
\t\tfile\t\t\t(TextIO|list[TextIO]):\tFile(s) to write the message to (default: sys.stdout)
\t\tuse_colored\t\t(bool):\t\t\t\t\tWhether to use the :py:func:`colored` function to format the message
\t\tprint_kwargs\t(dict):\t\t\t\t\tKeyword arguments to pass to the print function
\t'''
def debug(*values: Any, flush: bool = True, color: str = ..., text: str = 'DEBUG', **print_kwargs: Any) -> None:
    ''' Print a debug message looking like "[DEBUG HH:MM:SS] message" in cyan by default. '''
def alt_debug(*values: Any, flush: bool = True, color: str = ..., text: str = 'DEBUG', **print_kwargs: Any) -> None:
    ''' Print a debug message looking like "[DEBUG HH:MM:SS] message" in blue by default. '''
def suggestion(*values: Any, flush: bool = True, color: str = ..., text: str = 'SUGGESTION', **print_kwargs: Any) -> None:
    ''' Print a suggestion message looking like "[SUGGESTION HH:MM:SS] message" in cyan by default. '''
def progress(*values: Any, flush: bool = True, color: str = ..., text: str = 'PROGRESS', **print_kwargs: Any) -> None:
    ''' Print a progress message looking like "[PROGRESS HH:MM:SS] message" in magenta by default. '''
def warning(*values: Any, flush: bool = True, color: str = ..., text: str = 'WARNING', **print_kwargs: Any) -> None:
    ''' Print a warning message looking like "[WARNING HH:MM:SS] message" in yellow by default and in sys.stderr. '''
def error(*values: Any, exit: bool = False, flush: bool = True, color: str = ..., text: str = 'ERROR', **print_kwargs: Any) -> None:
    ''' Print an error message (in sys.stderr and in red by default)
\tand optionally ask the user to continue or stop the program.

\tArgs:
\t\tvalues\t\t\t(Any):\t\tValues to print (like the print function)
\t\texit\t\t\t(bool):\t\tWhether to ask the user to continue or stop the program,
\t\t\tfalse to ignore the error automatically and continue
\t\tflush\t\t\t(bool):\t\tWhether to flush the output
\t\tcolor\t\t\t(str):\t\tColor of the message (default: RED)
\t\ttext\t\t\t(str):\t\tText in the message (replaces "ERROR ")
\t\tprint_kwargs\t(dict):\t\tKeyword arguments to pass to the print function
\t'''
def infoc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def debugc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def alt_debugc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def warningc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def errorc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def progressc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
def suggestionc(*args: Any, use_colored: bool = True, **kwargs: Any) -> None: ...
