from ..io.utils import safe_close as safe_close
from _typeshed import Incomplete
from typing import Any, IO

class PipeWriter:
    """ A writer that sends data to a multiprocessing Connection. """
    conn: Any
    encoding: str
    errors: str
    def __init__(self, conn: Any, encoding: str, errors: str) -> None: ...
    def write(self, data: str) -> int: ...
    def flush(self) -> None: ...

class CaptureOutput:
    ''' Utility to capture stdout/stderr from a subprocess and relay it to the parent\'s stdout.

\tThe class creates an os.pipe(), marks fds as inheritable (for spawn method),
\tprovides methods to start a listener thread that reads from the pipe and writes
\tto the main process\'s sys.stdout/sys.stderr, and to close/join the listener.

\t>>> capturer = CaptureOutput(encoding="utf-8", errors="replace")

\t>>> pass # send capturer object to subprocess
\t>>> capturer.redirect()  # Redirects sys.stdout/sys.stderr to the pipe

\t>>> pass # in parent process:
\t>>> #capturer.parent_close_write()  # Close parent\'s write end
\t>>> capturer.start_listener()      # Start listener thread to read from pipe
\t>>> ...                            # do other work
\t>>> capturer.join_listener(timeout=0.1)       # Wait for listener to finish (on EOF)
\t'''
    encoding: str
    errors: str
    read_conn: Any
    write_conn: Any
    read_fd: Incomplete
    write_fd: Incomplete
    _thread: threading.Thread | None
    _reader_file: IO[Any] | None
    def __init__(self, encoding: str = 'utf-8', errors: str = 'replace') -> None: ...
    def __repr__(self) -> str: ...
    def __getstate__(self) -> dict[str, Any]: ...
    def redirect(self) -> None:
        """ Redirect sys.stdout and sys.stderr to the pipe's write end. """
    def parent_close_write(self) -> None:
        """ Close the parent's copy of the write end; the child's copy remains. """
    def child_close(self) -> None:
        """ Close the child's copy of the write end; the parent's copy remains. """
    def start_listener(self) -> None:
        """ Start a daemon thread that forwards data from the pipe to sys.stdout/sys.stderr. """
    def join_listener(self, timeout: float | None = None) -> None:
        """ Wait for the listener thread to finish (until EOF). """
