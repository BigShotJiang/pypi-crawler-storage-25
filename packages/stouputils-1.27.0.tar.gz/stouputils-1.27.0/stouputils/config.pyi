from typing import ClassVar

class StouputilsConfig:
    """ Global configuration class for stouputils. """
    VERBOSE_READING_ENV: bool
    RESET: str
    RED: str
    GREEN: str
    YELLOW: str
    BLUE: str
    MAGENTA: str
    CYAN: str
    LINE_UP: str
    BOLD: str
    BAR_FORMAT: str
    FORCE_RAISE_EXCEPTION: bool
    CPU_COUNT: int
    PROCESS_TITLE_PER_WORKER: bool
    CHUNK_SIZE: int
    LARGE_CHUNK_SIZE: int
    COMMIT_TYPES: ClassVar[dict[str, str]]
    AUTO_DOCS_REQUIREMENTS: tuple[str, ...]
    SEGMENTS_UNIQUE_COLOR: tuple[float, float, float, float]
    SEGMENTS_COLOR_CYCLE: tuple[tuple[float, float, float, float], ...]

def handle_config_from_env(var: str, expected_type: str) -> None: ...

type_str: str
