from .consolidate import consolidate_backups as consolidate_backups
from .create import create_delta_backup as create_delta_backup
from .limiter import limit_backups as limit_backups

def backup_cli() -> None:
    ''' Main entry point for command line usage.

\tExamples:

\t.. code-block:: bash

\t\t# Create a delta backup, excluding libraries and cache folders
\t\tpython -m stouputils.backup delta /path/to/source /path/to/backups -x "libraries/*" "cache/*"

\t\t# Consolidate backups into a single file
\t\tpython -m stouputils.backup consolidate /path/to/backups/latest.zip /path/to/consolidated.zip

\t\t# Limit the number of delta backups to 5
\t\tpython -m stouputils.backup limit 5 /path/to/backups
\t'''
