from ..io.path import clean_path as clean_path

class LockError(RuntimeError):
    """ Base lock error. """
class LockTimeoutError(TimeoutError, LockError):
    """ Raised when a lock could not be acquired within ``timeout`` seconds. """

def resolve_path(path: str) -> str:
    """ Resolve a lock file path, placing it in the system temporary directory if only a name is given.

    Examples:
        >>> import os, tempfile
        >>> p = resolve_path('foo.lock')
        >>> os.path.basename(p) == 'foo.lock'
        True
    """
def resolve_acquire_defaults(blocking_arg: bool | None, timeout_arg: float | None, check_interval_arg: float | None, default_blocking: bool, default_timeout: float | None, default_check_interval: float) -> tuple[bool, float | None, float, float | None]:
    """ Resolve acquire() parameter defaults and compute the deadline.

    Returns:
        tuple: (blocking, timeout, check_interval, deadline)
    """
