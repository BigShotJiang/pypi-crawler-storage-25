import abc
from contextlib import AbstractAsyncContextManager, AbstractContextManager

class AbstractBothContextManager[T](AbstractContextManager[T], AbstractAsyncContextManager[T], metaclass=abc.ABCMeta):
    """ Abstract base class for context managers that support both synchronous and asynchronous usage. """
