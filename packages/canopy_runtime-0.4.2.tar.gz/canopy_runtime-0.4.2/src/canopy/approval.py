from __future__ import annotations

import json
import os
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict

from .audit import HashChainAuditLog
from .errors import CanopyPermissionError


def _audit_path(path: str | Path | None = None) -> Path:
    if path is not None:
        return Path(path)
    return Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))


def _blocked_layers_text(result: Dict[str, Any]) -> str:
    layers = result.get("layers") if isinstance(result.get("layers"), dict) else {}
    parts = [f"{key}={value}" for key, value in layers.items() if value != "pass"]
    return ", ".join(parts) if parts else "(none)"


def _append_approval_event(
    result: Dict[str, Any], *, event: str, decision: str, reason: str, audit_log_path: str | Path | None = None
) -> None:
    try:
        HashChainAuditLog(_audit_path(audit_log_path)).append(
            avid=str(result.get("avid") or ""),
            action_type=str(result.get("action_type") or "approval"),
            decision=decision,
            reason=reason,
            severity=str(result.get("severity") or "low"),
            layers=result.get("layers") if isinstance(result.get("layers"), dict) else {},
            witness=result.get("witness") if isinstance(result.get("witness"), dict) else None,
            event=event,
            authorization_id=str(result.get("authorization_id") or "") or None,
            override_possible=result.get("override_possible"),
            override_key=result.get("override_key"),
        )
    except Exception:
        return


def record_approval_decision(
    result: Dict[str, Any], *, approved: bool, reason: str | None = None, audit_log_path: str | Path | None = None
) -> None:
    if approved:
        _append_approval_event(
            result,
            event="approval_granted",
            decision="APPROVED",
            reason=reason or "Human approved the action.",
            audit_log_path=audit_log_path,
        )
        return
    _append_approval_event(
        result,
        event="approval_rejected",
        decision="REJECTED",
        reason=reason or "Human rejected the action.",
        audit_log_path=audit_log_path,
    )


def approval_artifact_path(
    result: Dict[str, Any], *, audit_log_path: str | Path | None = None, create_dir: bool = False
) -> Path:
    base = _audit_path(audit_log_path)
    artifact_dir = Path(str(base) + ".approvals")
    if create_dir:
        artifact_dir.mkdir(parents=True, exist_ok=True)
    authorization_id = str(result.get("authorization_id") or "pending-approval")
    safe_name = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in authorization_id)
    return artifact_dir / f"{safe_name}.json"


def write_approval_artifact(
    result: Dict[str, Any],
    *,
    approved: bool,
    reason: str | None = None,
    audit_log_path: str | Path | None = None,
) -> Path:
    path = approval_artifact_path(result, audit_log_path=audit_log_path, create_dir=True)
    payload = {
        "artifact_type": "canopy.approval_decision",
        "authorization_id": result.get("authorization_id"),
        "avid": result.get("avid"),
        "action_type": result.get("action_type"),
        "severity": result.get("severity"),
        "decision": "APPROVED" if approved else "REJECTED",
        "reason": reason or ("Human approved the action." if approved else "Human rejected the action."),
        "layers": result.get("layers", {}),
        "override_possible": result.get("override_possible", False),
        "override_key": result.get("override_key"),
        "audit_log": str(_audit_path(audit_log_path)),
        "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def format_approval_request(result: Dict[str, Any]) -> str:
    reason = str(result.get("reason") or "")
    reason_lines = textwrap.wrap(reason, width=49) or [""]
    header = "╔══ APPROVAL REQUIRED ═══════════════════════════════╗"
    footer = "╚═════════════════════════════════════════════════════╝"

    body = [
        "║                                                     ║",
        f"║  Agent    : {str(result.get('avid') or '')[:38]:<38}║",
        f"║  Action   : {str(result.get('action_type') or 'approval')[:38]:<38}║",
        f"║  Severity : {str(result.get('severity') or '')[:38]:<38}║",
        "║                                                     ║",
    ]
    for idx, line in enumerate(reason_lines):
        label = "Reason" if idx == 0 else ""
        body.append(f"║  {label:<8}: {line[:38]:<38}║")
    body.extend(
        [
            "║                                                     ║",
            f"║  Layers   : {_blocked_layers_text(result)[:38]:<38}║",
            "║                                                     ║",
            f"║  Audit ID : {str(result.get('authorization_id') or '')[:38]:<38}║",
        ]
    )
    if result.get("override_key"):
        body.append(f"║  Override : {str(result.get('override_key'))[:38]:<38}║")
    body.extend(
        [
            "║                                                     ║",
            footer,
            "",
            "Approve this action? [y/N]: ",
        ]
    )
    return "\n".join([header, *body])


def prompt_for_approval(result: Dict[str, Any], func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    prompt = format_approval_request(result)
    approved = input(prompt).strip().lower().startswith("y")
    if approved:
        _append_approval_event(
            result,
            event="approval_granted",
            decision="APPROVED",
            reason="Human approved the action via prompt_for_approval.",
        )
        return func(*args, **kwargs)

    _append_approval_event(
        result,
        event="approval_rejected",
        decision="REJECTED",
        reason="Human rejected the action via prompt_for_approval.",
    )
    raise CanopyPermissionError({**result, "reason": "Human rejected the action"})


def format_approval_webhook(result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "type": "canopy.approval_required",
        "decision": result.get("decision"),
        "reason": result.get("reason"),
        "severity": result.get("severity"),
        "avid": result.get("avid"),
        "audit_id": result.get("authorization_id"),
        "layers": result.get("layers", {}),
        "override_key": result.get("override_key"),
        "override_possible": result.get("override_possible", False),
        "message": format_approval_request(result),
    }
