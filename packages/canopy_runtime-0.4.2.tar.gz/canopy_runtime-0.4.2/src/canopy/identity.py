from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def generate_avid(
    agent_ctx: Dict[str, Any],
    *,
    constitution_hash: Optional[str] = None,
    require_stable: bool = False,
) -> str:
    """Generate a deterministic AVID for audit correlation.

    The AVID is a SHA-256 hash of:
      - public_key          (identity anchor)
      - created_at          (stability anchor; provide explicitly for cross-session stability)
      - constitution_hash   (optional; binds identity to active constitution)
      - metadata            (remaining agent_ctx fields)
    """
    ctx = dict(agent_ctx or {})
    created_at = ctx.get("created_at")
    if not created_at:
        if require_stable:
            raise ValueError("agent_ctx must include 'created_at' for a stable AVID")
        created_at = _now_iso()
        ctx["created_at"] = created_at

    public_key = str(ctx.get("public_key", "") or "")

    exclude = {
        "public_key",
        "created_at",
        "avid",
        # Ephemeral / per-call fields that must not change identity
        "original_prompt_hash",
        "internal_reasoning",
        "agent_reputation",
        "reputation",
        "safe_paths",
        "kill_switch",
        "status",
        # Deliberately excluded so the same logical agent retains identity
        # across role/env changes; these belong in audit context, not identity.
        "env",
        "role",
    }
    payload: Dict[str, Any] = {
        "public_key": public_key,
        "created_at": created_at,
        "metadata": {k: v for k, v in ctx.items() if k not in exclude},
    }
    if constitution_hash:
        payload["constitution_hash"] = constitution_hash

    digest = hashlib.sha256(_canonical_json(payload)).hexdigest()
    return f"AVID-{digest}"


def verify_avid(agent_ctx: Dict[str, Any], claimed_avid: str, **kwargs: Any) -> bool:
    expected = generate_avid(agent_ctx, **kwargs)
    return expected == claimed_avid
