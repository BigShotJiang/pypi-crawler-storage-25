from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, List

from rich.console import Console
from rich.table import Table


def _load_entries(path: Path) -> List[dict]:
    if not path.exists():
        return []
    entries: List[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except Exception:
                continue
    return entries


def render_table(entries: List[dict], limit: int) -> None:
    console = Console()
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Timestamp", style="cyan", no_wrap=True)
    table.add_column("Decision", style="bold")
    table.add_column("Action", no_wrap=True)
    table.add_column("Reason", style="dim")
    table.add_column("Auth ID", style="dim")
    for e in entries[-limit:]:
        ts = str(e.get("timestamp", ""))
        dec = str(e.get("decision", ""))
        act = str(e.get("action_type", ""))
        reason = str(e.get("reason", ""))[:120]
        auth = str(e.get("authorization_id", ""))[:12]
        table.add_row(ts, dec, act, reason, auth)
    console.print(table)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Tail and pretty-print Canopy audit.log")
    parser.add_argument("path", nargs="?", default="audit.log", help="Path to audit log (default: audit.log)")
    parser.add_argument("--limit", "-n", type=int, default=20, help="Number of entries to show (default: 20)")
    args = parser.parse_args(argv)

    path = Path(args.path)
    entries = _load_entries(path)
    if not entries:
        print(f"No entries found in {path}")
        return
    render_table(entries, args.limit)


if __name__ == "__main__":
    main()
