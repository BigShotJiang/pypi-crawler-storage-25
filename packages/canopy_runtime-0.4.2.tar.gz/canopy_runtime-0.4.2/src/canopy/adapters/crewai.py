"""Canopy adapter for CrewAI.

CrewAI tools are typically subclasses of crewai.tools.BaseTool with `_run`
and optionally `_arun`. This module provides a mixin that wraps those methods
with Canopy authorization.

No forced dependency: crewai is only imported when the mixin is subclassed.
"""

from __future__ import annotations

import inspect
from typing import Any, Dict, Optional

from canopy.core import authorize_action
from canopy.errors import CanopyPermissionError


class CanopyCrewAITool:
    """Mixin for CrewAI BaseTool subclasses that adds Canopy governance.

    Usage (typical MRO):
        from crewai.tools import BaseTool
        from canopy.adapters.crewai import CanopyCrewAITool

        class ShellTool(CanopyCrewAITool, BaseTool):
            canopy_action_type = "execute_shell"
            canopy_agent_ctx = {"public_key": "pk", "created_at": "..."}
            def _run(self, command: str) -> str: ...

    Configuration:
        canopy_action_type: str
        canopy_agent_ctx: dict|callable returning dict
        canopy_on_require_approval: "raise" | "skip"
        canopy_policy_file / canopy_audit_log_path: optional strings
    """

    canopy_action_type: str = "unknown"
    canopy_agent_ctx: Any = None
    canopy_on_require_approval: str = "raise"
    canopy_policy_file: Optional[str] = None
    canopy_audit_log_path: Optional[str] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

        # Ensure CrewAI is installed only when subclassing for real usage.
        try:  # pragma: no cover (import check)
            import crewai  # noqa: F401
        except ImportError as e:  # pragma: no cover
            raise ImportError("crewai is required: pip install crewai") from e

        # Wrap _run/_arun defined on the subclass (not inherited wrappers).
        original_run = cls.__dict__.get("_run")
        if callable(original_run):

            def _run_wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
                self._canopy_authorize_from_call(original_run, args, kwargs)
                return original_run(self, *args, **kwargs)

            cls._run = _run_wrapped  # type: ignore[assignment]

        original_arun = cls.__dict__.get("_arun")
        if callable(original_arun):
            if inspect.iscoroutinefunction(original_arun):

                async def _arun_wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
                    self._canopy_authorize_from_call(original_arun, args, kwargs)
                    return await original_arun(self, *args, **kwargs)

                cls._arun = _arun_wrapped  # type: ignore[assignment]
            else:

                def _arun_wrapped_sync(self: Any, *args: Any, **kwargs: Any) -> Any:
                    self._canopy_authorize_from_call(original_arun, args, kwargs)
                    return original_arun(self, *args, **kwargs)

                cls._arun = _arun_wrapped_sync  # type: ignore[assignment]

    def _build_payload_from_call(self, fn: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Dict[str, Any]:
        action_type = str(self.canopy_action_type or "")
        try:
            bound = inspect.signature(fn).bind_partial(self, *args, **kwargs)
            argmap = dict(bound.arguments)
        except Exception:
            argmap = dict(kwargs)

        if action_type == "execute_shell":
            command = argmap.get("command")
            if command is None and args:
                command = args[0]
            return {"command": command} if command is not None else {"args": list(args), "kwargs": dict(kwargs)}

        if action_type == "modify_file":
            path = argmap.get("path")
            if path is None and args:
                path = args[0]
            return {"path": path} if path is not None else {"args": list(args), "kwargs": dict(kwargs)}

        if action_type == "call_external_api":
            url = argmap.get("url") or argmap.get("endpoint")
            if url is None and args:
                url = args[0]
            return {"url": url} if url is not None else {"args": list(args), "kwargs": dict(kwargs)}

        return {"args": list(args), "kwargs": dict(kwargs)}

    def _canopy_authorize_from_call(self, fn: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> None:
        payload = self._build_payload_from_call(fn, args, kwargs)
        ctx = self.canopy_agent_ctx() if callable(self.canopy_agent_ctx) else (self.canopy_agent_ctx or {})
        result = authorize_action(
            agent_ctx=dict(ctx),
            action_type=str(self.canopy_action_type or ""),
            action_payload=payload,
            policy_file=self.canopy_policy_file,
            audit_log_path=self.canopy_audit_log_path,
        )
        decision = str(result.get("decision") or "").upper()
        if decision == "DENY":
            raise CanopyPermissionError(result)
        if decision == "REQUIRE_APPROVAL":
            mode = (self.canopy_on_require_approval or "raise").lower()
            if mode == "raise":
                raise CanopyPermissionError(result)
            if mode == "skip":
                return
            raise ValueError("canopy_on_require_approval must be one of: 'raise', 'skip'")
