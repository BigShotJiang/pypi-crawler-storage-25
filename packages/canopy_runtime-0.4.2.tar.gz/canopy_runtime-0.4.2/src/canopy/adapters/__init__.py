"""Canopy framework adapters.

Adapters are optional integration helpers. They do not force-install any
third-party framework. Each adapter either:
  - imports its framework lazily inside the adapter function/class, or
  - fails with a clear ImportError if the framework is required for the call.

Available adapters:
  - canopy.adapters.langchain     — LangChain @tool and BaseTool instances
  - canopy.adapters.langgraph     — LangGraph nodes (plain callables)
  - canopy.adapters.crewai        — CrewAI BaseTool subclasses (mixin)
  - canopy.adapters.autogen       — AutoGen tool functions (decorator)
  - canopy.adapters.openai_agents — OpenAI Agents SDK function tools (decorator)
  - canopy.adapters.openclaw      — OpenClaw tool functions (decorator; best-effort)
"""

from __future__ import annotations

__all__ = [
    "langchain",
    "langgraph",
    "crewai",
    "autogen",
    "openai_agents",
    "openclaw",
]

