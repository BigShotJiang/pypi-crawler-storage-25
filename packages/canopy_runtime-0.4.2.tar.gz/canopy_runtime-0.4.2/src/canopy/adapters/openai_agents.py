"""Canopy adapter for the OpenAI Agents SDK.

This adapter is framework-agnostic: it wraps a Python function before the
SDK converts it to a tool.

Usage (decorator order matters):
    from agents import function_tool
    from canopy.adapters.openai_agents import canopy_openai_tool

    @function_tool
    @canopy_openai_tool(action_type="execute_shell", agent_ctx={...})
    def run_shell(command: str) -> str:
        ...
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from canopy.decorators import safe_tool


def canopy_openai_tool(
    *,
    action_type: str,
    agent_ctx: Any = None,
    on_require_approval: str = "raise",
    approval_callback: Optional[Callable[..., Any]] = None,
    policy_file: Optional[str] = None,
    audit_log_path: Optional[str] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that adds Canopy governance to an OpenAI Agents SDK tool function."""

    try:  # pragma: no cover
        import agents  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("OpenAI Agents SDK is required: pip install openai-agents") from e

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        return safe_tool(
            action_type=action_type,
            agent_ctx=agent_ctx,
            on_require_approval=on_require_approval,
            approval_callback=approval_callback,
            policy_file=policy_file,
            audit_log_path=audit_log_path,
        )(func)

    return decorator
