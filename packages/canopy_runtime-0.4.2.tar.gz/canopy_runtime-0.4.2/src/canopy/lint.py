from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

from .core import _parse_condition_list, _parse_minimal_yaml


def _warn(msg: str) -> str:
    return f"⚠ Warning: {msg}"


def _error(msg: str) -> str:
    return f"✗ Error: {msg}"


def _looks_like_assignment_typo(predicate: str) -> bool:
    text = predicate.strip()
    return bool(re.search(r"\b(?:agent_ctx|ctx|payload|action_type)\.[^=!\n]+=\s*[^=]", text))


def lint_policy(path: str | Path) -> Tuple[List[str], List[str], Dict[str, Any]]:
    text = Path(path).read_text(encoding="utf-8")
    warnings: List[str] = []
    errors: List[str] = []

    try:
        data = _parse_minimal_yaml(text)
    except Exception as exc:
        return [], [_error(str(exc))], {"rules": []}

    rules = data.get("rules") if isinstance(data.get("rules"), list) else []
    action_types = set()

    for index, rule in enumerate(rules, start=1):
        if not isinstance(rule, dict):
            warnings.append(_warn(f"rule #{index} is not a mapping — it may not evaluate as intended"))
            continue

        action_type = str(rule.get("action_type") or "").strip()
        if not action_type:
            warnings.append(_warn(f"rule #{index} has no 'action_type' — will never match"))
        else:
            action_types.add(action_type)

        predicates: List[str] = []
        predicates.extend(_parse_condition_list(rule.get("when_all")))
        predicates.extend(_parse_condition_list(rule.get("when_any")))
        predicates.extend(_parse_condition_list(rule.get("when_not")))
        for predicate in predicates:
            if _looks_like_assignment_typo(predicate):
                warnings.append(_warn(f"predicate {predicate!r} uses = instead of == — will never evaluate"))

        for field in ("deny_regex", "require_approval_regex"):
            raw = rule.get(field)
            patterns = [raw] if isinstance(raw, str) else raw if isinstance(raw, list) else []
            for pattern in patterns:
                rx = str(pattern)
                try:
                    re.compile(rx)
                except re.error as exc:
                    errors.append(_error(f"{field} {rx!r} is not a valid regex: {exc}"))

    summary = {"rule_count": len(rules), "action_type_count": len(action_types)}
    return warnings, errors, summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Lint a Canopy policy file for common mistakes.")
    parser.add_argument("policy_file", help="path to policy YAML")
    args = parser.parse_args(argv)

    warnings, errors, summary = lint_policy(args.policy_file)

    for line in warnings:
        print(line)
    for line in errors:
        print(line)

    if errors:
        return 1

    print(
        f"✓ Policy valid — {summary['rule_count']} rules loaded for {summary['action_type_count']} action types"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
