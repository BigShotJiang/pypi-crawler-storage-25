from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from .audit import HashChainAuditLog


def _indent_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)


def _format_layers(layers: Dict[str, Any]) -> List[str]:
    if not layers:
        return ["(none)"]
    out: List[str] = []
    for key in ("constitution", "civil_code", "firewall", "policy"):
        if key in layers:
            out.append(f"{key:13}: {layers[key]}")
    for key, value in layers.items():
        if key not in {"constitution", "civil_code", "firewall", "policy"}:
            out.append(f"{key:13}: {value}")
    return out


def _blocked_by(entry: Dict[str, Any]) -> str:
    layers = entry.get("layers") if isinstance(entry.get("layers"), dict) else {}
    labels = {
        "constitution": "Constitution",
        "civil_code": "Civil Code",
        "firewall": "Firewall",
        "policy": "Policy",
    }
    for key in ("constitution", "civil_code", "firewall", "policy"):
        value = str(layers.get(key) or "")
        if value.startswith("blocked ") or value in {"deny", "require_approval"}:
            return labels.get(key, key)
    return "N/A"


def _chain_ok_mark(entry: Dict[str, Any]) -> str:
    return "✓" if bool(entry.get("entry_hash")) and bool(entry.get("prev_hash")) else ""


def _summarize_entries(entries: List[Dict[str, Any]]) -> Tuple[Dict[str, int], Dict[str, int]]:
    decisions = {"DENY": 0, "REQUIRE_APPROVAL": 0, "ALLOW": 0}
    blocked_by = {"Constitution": 0, "Firewall": 0, "Civil Code": 0, "Policy": 0}
    for entry in entries:
        decision = str(entry.get("decision") or "").upper()
        if decision in decisions:
            decisions[decision] += 1
        blocker = _blocked_by(entry)
        if blocker in blocked_by:
            blocked_by[blocker] += 1
    return decisions, blocked_by


def _require_openpyxl() -> Any:
    try:
        import openpyxl  # type: ignore
    except ImportError as exc:  # pragma: no cover - exercised via tests through RuntimeError
        raise RuntimeError("Excel export requires: pip install canopy-runtime[excel]") from exc
    return openpyxl


def _export_csv(entries: List[Dict[str, Any]], export_path: Path) -> None:
    headers = [
        "#",
        "Timestamp",
        "Agent (AVID)",
        "Action",
        "Decision",
        "Severity",
        "Reason",
        "Blocked By",
        "Audit ID",
        "Chain",
    ]
    with export_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(headers)
        for index, entry in enumerate(entries, start=1):
            writer.writerow(
                [
                    index,
                    entry.get("timestamp", ""),
                    entry.get("avid", ""),
                    entry.get("action_type", ""),
                    entry.get("decision", ""),
                    entry.get("severity", ""),
                    entry.get("reason", ""),
                    _blocked_by(entry),
                    entry.get("authorization_id") or entry.get("entry_hash", ""),
                    _chain_ok_mark(entry),
                ]
            )


def _export_xlsx(path: Path, entries: List[Dict[str, Any]], export_path: Path) -> None:
    openpyxl = _require_openpyxl()
    from openpyxl.styles import Font, PatternFill

    workbook = openpyxl.Workbook()
    ws = workbook.active
    ws.title = "Audit Log"
    headers = ["#", "Timestamp", "Agent (AVID)", "Action", "Decision", "Severity", "Reason", "Blocked By", "Audit ID", "Chain"]
    ws.append(headers)

    header_fill = PatternFill(fill_type="solid", fgColor="1F2937")
    header_font = Font(color="FFFFFF", bold=True)
    row_fills = {
        "DENY": PatternFill(fill_type="solid", fgColor="FDE2E1"),
        "REQUIRE_APPROVAL": PatternFill(fill_type="solid", fgColor="FEF3C7"),
        "ALLOW": PatternFill(fill_type="solid", fgColor="DCFCE7"),
    }

    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = header_fill
        cell.font = header_font

    for index, entry in enumerate(entries, start=1):
        row = [
            index,
            entry.get("timestamp", ""),
            entry.get("avid", ""),
            entry.get("action_type", ""),
            entry.get("decision", ""),
            entry.get("severity", ""),
            entry.get("reason", ""),
            _blocked_by(entry),
            entry.get("authorization_id") or entry.get("entry_hash", ""),
            _chain_ok_mark(entry),
        ]
        ws.append(row)
        fill = row_fills.get(str(entry.get("decision") or "").upper())
        if fill is not None:
            for col_idx in range(1, len(headers) + 1):
                ws.cell(row=index + 1, column=col_idx).fill = fill

    ws.freeze_panes = "A2"
    for column_cells in ws.columns:
        values = [str(cell.value or "") for cell in column_cells]
        width = max(len(v) for v in values) + 2
        ws.column_dimensions[column_cells[0].column_letter].width = min(width, 60)

    summary_ws = workbook.create_sheet("Summary")
    ok = HashChainAuditLog(path).verify_integrity()
    decision_counts, blocked_counts = _summarize_entries(entries)
    generated = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    summary_lines = [
        ("Canopy Audit Report",),
        ("Generated", generated),
        ("File", str(path)),
        ("Total entries", len(entries)),
        ("Chain status", "✓ VALID" if ok else "✗ INVALID"),
        ("",),
        ("Decisions",),
        ("DENY", decision_counts["DENY"]),
        ("REQUIRE_APPROVAL", decision_counts["REQUIRE_APPROVAL"]),
        ("ALLOW", decision_counts["ALLOW"]),
        ("",),
        ("Most blocked by",),
        ("Constitution", blocked_counts["Constitution"]),
        ("Firewall", blocked_counts["Firewall"]),
        ("Civil Code", blocked_counts["Civil Code"]),
        ("Policy", blocked_counts["Policy"]),
    ]
    for row in summary_lines:
        summary_ws.append(list(row))
    summary_ws.column_dimensions["A"].width = 24
    summary_ws.column_dimensions["B"].width = 48

    workbook.save(export_path)


def _iter_report_lines(entry: Dict[str, Any]) -> Iterable[str]:
    yield f"Timestamp     : {entry.get('timestamp', '')}"
    yield f"Event         : {entry.get('event', 'authorize_action')}"
    yield f"Agent         : {entry.get('avid', '')}"
    yield f"Action        : {entry.get('action_type', '')}"
    yield f"Decision      : {entry.get('decision', '')} [{entry.get('severity', '')}]"
    yield ""
    yield "Reason"
    yield "------"
    yield str(entry.get("reason", ""))
    yield ""

    layers = entry.get("layers")
    if isinstance(layers, dict):
        yield "Layers"
        yield "------"
        for line in _format_layers(layers):
            yield line
        yield ""

    if entry.get("override_possible") is True or entry.get("override_key") is not None:
        yield "Override"
        yield "--------"
        yield f"Possible      : {entry.get('override_possible')}"
        yield f"Key           : {entry.get('override_key')}"
        yield ""

    witness = entry.get("witness")
    if isinstance(witness, dict):
        yield "Witness"
        yield "-------"
        if "violated_article" in witness:
            yield f"Article       : {witness.get('violated_article')}"
        if "violated_title" in witness:
            yield f"Title         : {witness.get('violated_title')}"
        if "constitution_hash" in witness:
            yield f"Const. Hash   : {witness.get('constitution_hash')}"
        if "civil_code_hash" in witness:
            yield f"Civil Hash    : {witness.get('civil_code_hash')}"
        if "signature" in witness:
            yield f"Signature     : {witness.get('signature')}"
        yield ""

    constitution_witness = entry.get("constitution_witness")
    if isinstance(constitution_witness, dict):
        yield "Constitution Witness"
        yield "--------------------"
        yield f"Event         : {constitution_witness.get('event')}"
        yield f"Article       : {constitution_witness.get('violated_article')}"
        yield f"Signature     : {constitution_witness.get('signature')}"
        yield ""

    if entry.get("event") == "tool_result":
        yield "Tool Result"
        yield "-----------"
        yield f"Authorization : {entry.get('authorization_id')}"
        yield f"OK            : {entry.get('ok')}"
        yield f"Result Hash   : {entry.get('result_hash')}"
        if entry.get("error"):
            yield f"Error         : {entry.get('error')}"
        yield ""

    yield "Integrity"
    yield "---------"
    yield f"Entry Hash    : {entry.get('entry_hash', '')}"
    yield f"Prev Hash     : {entry.get('prev_hash', '')}"


def _print_report(path: Path, entries: List[Dict[str, Any]], *, show_json: bool = False) -> None:
    ok = HashChainAuditLog(path).verify_integrity()
    print("Canopy Audit Report")
    print("===================")
    print(f"File          : {path.resolve()}")
    print(f"Entries       : {len(entries)}")
    print(f"Chain Status  : {'VALID' if ok else 'INVALID'}")
    print("")

    if not entries:
        print("No entries found.")
        return

    for idx, entry in enumerate(entries, start=1):
        print(f"[{idx}] {entry.get('timestamp', '')} - {entry.get('decision', '')} - {entry.get('action_type', '')}")
        print("")
        for line in _iter_report_lines(entry):
            print(line)
        if show_json:
            print("")
            print("Raw JSON")
            print("--------")
            print(_indent_json(entry))
        if idx != len(entries):
            print("")
            print("-" * 59)
            print("")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Render a human-readable Canopy audit report.")
    parser.add_argument("audit_log_path", nargs="?", default="audit.log", help="path to audit log (default: ./audit.log)")
    parser.add_argument("--last", type=int, default=1, help="number of most recent entries to show (default: 1)")
    parser.add_argument("--all", action="store_true", help="show all entries")
    parser.add_argument("--json", action="store_true", help="also print raw JSON for each reported entry")
    parser.add_argument("--export", help="export the selected entries to a spreadsheet (.xlsx or .csv)")
    args = parser.parse_args(argv)

    path = Path(args.audit_log_path)
    log = HashChainAuditLog(path)
    entries = list(log.iter_entries())
    if not args.all:
        count = max(1, int(args.last))
        entries = entries[-count:]

    if args.export:
        export_path = Path(args.export)
        try:
            if export_path.suffix.lower() == ".csv":
                _export_csv(entries, export_path)
            else:
                _export_xlsx(path, entries, export_path)
        except RuntimeError as exc:
            print(f"✗ {exc}")
            return 1
        ok = log.verify_integrity()
        decision_counts, _ = _summarize_entries(entries)
        print(f"✓ Exported {len(entries)} entries to {export_path}")
        print(f"  Chain status : {'VALID' if ok else 'INVALID'}")
        print(f"  DENY         : {decision_counts['DENY']}")
        print(f"  REQUIRE_APPROVAL : {decision_counts['REQUIRE_APPROVAL']}")
        print(f"  ALLOW        : {decision_counts['ALLOW']}")
        return 0

    _print_report(path, entries, show_json=args.json)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
