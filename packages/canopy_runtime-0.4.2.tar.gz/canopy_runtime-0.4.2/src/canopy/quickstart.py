from __future__ import annotations

import argparse
from pathlib import Path
from typing import List, Optional

from . import console, demo


def _parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run a one-command Canopy demo and open the console.")
    p.add_argument("--audit-log-path", default="/tmp/canopy_quickstart_audit.log", help="where to write the demo audit log")
    p.add_argument("--safe-path", action="append", default=["/tmp/"], help="repeatable; paths allowed for writes (default: /tmp/)")
    p.add_argument(
        "--framework",
        choices=["crewai", "langchain", "autogen", "vanilla"],
        default="crewai",
        help="just for the banner; shows how you might wire @safe_tool (default: crewai)",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = _parse_args(argv)
    audit_path = Path(args.audit_log_path)
    demo_args = ["--audit-log-path", str(audit_path)]
    for sp in args.safe_path:
        demo_args += ["--safe-path", sp]

    print(f"Running quickstart demo for framework: {args.framework}")
    demo.main(demo_args)
    print(
        "\n✅ Demo completed.\n"
        f"Audit log: {audit_path}\n"
        f"Run console: canopy-console --audit-log {audit_path}\n"
        f"Incident view: canopy-incident --trace <trace_id> {audit_path}\n"
    )
    print("Launching canopy-console with the demo audit log. Press 'q' to exit.\n")
    try:
        console.main(["--audit-log", str(audit_path)])
    except SystemExit as exc:  # console.main may call SystemExit
        return int(exc.code or 0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
