from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


DEFAULT_FIXED_PATH = "/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/opt/homebrew/bin"


def run_safely(
    command: str,
    *,
    env_whitelist: Optional[Iterable[str]] = None,
    cwd: str | Path | None = None,
    timeout: float | None = None,
) -> Dict[str, Any]:
    """Run a shell command with a clean environment and controlled working directory.

    - Does not inherit `os.environ` by default.
    - Uses a fixed PATH.
    - If env_whitelist is provided, only those variables are copied from the process env.

    Returns a dict compatible with ActionFirewall._safe_run():
        {"returncode": int, "stdout": str, "stderr": str}
    """
    if command is None or not str(command).strip():
        raise ValueError("run_safely requires a non-empty command")

    env: Dict[str, str] = {"PATH": DEFAULT_FIXED_PATH, "TERM": "dumb"}

    if env_whitelist:
        import os

        for key in env_whitelist:
            k = str(key)
            if k in os.environ:
                env[k] = os.environ[k]

    workdir = str(cwd) if cwd is not None else tempfile.gettempdir()

    proc = subprocess.run(
        ["bash", "-lc", command],
        cwd=workdir,
        env=env,
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout,
    )

    return {"returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}

