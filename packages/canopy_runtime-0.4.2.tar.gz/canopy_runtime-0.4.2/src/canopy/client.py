from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class CanopyClient:
    base_url: str = "http://127.0.0.1:8010"
    timeout_s: float = 5.0
    headers: Optional[Dict[str, str]] = None
    api_key: Optional[str] = None

    # For tests or advanced usage you can inject a TestClient/httpx-style client.
    http_client: Any = None

    def _headers(self) -> Dict[str, str]:
        headers = dict(self.headers or {})
        if self.api_key and "x-api-key" not in {k.lower(): v for k, v in headers.items()}:
            headers["x-api-key"] = self.api_key
        return headers

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        if self.http_client is not None:
            res = self.http_client.post(path, json=payload, headers=self._headers())
            res.raise_for_status()
            return res.json()

        try:
            import requests  # type: ignore
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                "Optional dependency missing: install HTTP client support with `pip install canopy-runtime[http]`"
            ) from e

        url = self.base_url.rstrip("/") + path
        res = requests.post(url, json=payload, headers=self._headers(), timeout=self.timeout_s)
        res.raise_for_status()
        return res.json()

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if self.http_client is not None:
            res = self.http_client.get(path, params=params, headers=self._headers())
            res.raise_for_status()
            return res.json()

        try:
            import requests  # type: ignore
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                "Optional dependency missing: install HTTP client support with `pip install canopy-runtime[http]`"
            ) from e

        url = self.base_url.rstrip("/") + path
        res = requests.get(url, params=params, headers=self._headers(), timeout=self.timeout_s)
        res.raise_for_status()
        return res.json()

    def authorize_action(self, agent_ctx: Dict[str, Any], action_type: str, action_payload: Any) -> Dict[str, Any]:
        return self._post(
            "/v1/authorize",
            {"agent_ctx": agent_ctx or {}, "action_type": action_type, "action_payload": action_payload},
        )

    def register_agent(self, agent_ctx: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._post("/v1/agents/register", {"agent_ctx": agent_ctx or {}, "metadata": metadata or {}})

    def list_agents(self, tenant_id: str = "default", limit: int = 100) -> Dict[str, Any]:
        return self._get("/v1/agents", {"tenant_id": tenant_id, "limit": limit})

    def list_audit_events(self, tenant_id: str = "default", avid: Optional[str] = None, limit: int = 100) -> Dict[str, Any]:
        params: Dict[str, Any] = {"tenant_id": tenant_id, "limit": limit}
        if avid:
            params["avid"] = avid
        return self._get("/v1/audit", params)

    def dashboard_summary(self, tenant_id: str = "default") -> Dict[str, Any]:
        return self._get("/v1/dashboard", {"tenant_id": tenant_id})

    def decide_approval(
        self,
        *,
        tenant_id: str,
        authorization_id: str,
        avid: str,
        decision: str,
        decided_by: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        return self._post(
            "/v1/approvals/decide",
            {
                "tenant_id": tenant_id,
                "authorization_id": authorization_id,
                "avid": avid,
                "decision": decision,
                "decided_by": decided_by,
                "reason": reason,
            },
        )
