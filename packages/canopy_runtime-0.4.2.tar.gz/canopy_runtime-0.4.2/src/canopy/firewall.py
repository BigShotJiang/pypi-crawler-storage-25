"""Canopy Firewall — configurable pattern-based action filter.

This is the second layer in the authorization pipeline, running after the
Constitution (immutable) and before policy YAML (user-defined).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass(frozen=True)
class FirewallResult:
    decision: str  # "allow" | "deny" | "require_approval"
    reason: str
    severity: str  # "low" | "medium" | "high" | "critical"


_BLOCKED_SHELL_PATTERNS: List[str] = [
    "rm -rf",
    "/etc",
    "/root",
    "/var/www",
    "/usr/bin",
    "/usr/sbin",
]

_HIGH_RISK_SHELL_PATTERNS: List[str] = [
    "sudo",
    "chmod",
    "chown",
    "dd ",
    "mkfs",
    "curl ",
    "wget ",
    "pip install",
    "npm install",
    "apt-get",
    "apt ",
]

_PROTECTED_FILE_PATHS: Tuple[str, ...] = ("/etc", "/usr/bin", "/usr/sbin", "/boot", "/root")

_SPEND_THRESHOLD = 10.0
_SPEND_ACTION_TYPES = {"spend_money", "purchase", "pay", "transfer_funds"}


def _effective_spend_threshold(agent_ctx: Dict[str, Any]) -> float | None:
    limit = agent_ctx.get("spending_limit")
    if isinstance(limit, str) and limit.strip().lower() == "unlimited":
        return None
    if limit is not None:
        try:
            return float(limit)
        except (TypeError, ValueError):
            return _SPEND_THRESHOLD
    return _SPEND_THRESHOLD


def evaluate(
    action_type: str,
    action_payload: Dict[str, Any],
    *,
    agent_ctx: Optional[Dict[str, Any]] = None,
) -> FirewallResult:
    payload = action_payload or {}
    ctx = agent_ctx or {}
    action_norm = (action_type or "").strip().lower()

    if action_norm in {"execute_shell_command", "execute_shell", "shell"}:
        cmd_lower = str(payload.get("command") or payload.get("cmd") or payload.get("shell") or "").lower().strip()

        for pattern in _BLOCKED_SHELL_PATTERNS:
            if pattern in cmd_lower:
                return FirewallResult(
                    decision="deny",
                    reason=f"Firewall: destructive pattern detected ('{pattern}')",
                    severity="critical",
                )

        if payload.get("requires_root"):
            return FirewallResult(
                decision="require_approval",
                reason="Firewall: root-level command requires explicit approval",
                severity="high",
            )

        for pattern in _HIGH_RISK_SHELL_PATTERNS:
            if pattern in cmd_lower:
                return FirewallResult(
                    decision="require_approval",
                    reason=f"Firewall: high-risk command requires approval (matched '{pattern.strip()}')",
                    severity="high",
                )

        return FirewallResult(decision="allow", reason="Shell command cleared by firewall", severity="low")

    if action_norm == "modify_file":
        path_lower = str(payload.get("path", "") or "").lower()
        for protected in _PROTECTED_FILE_PATHS:
            if path_lower.startswith(protected):
                return FirewallResult(
                    decision="deny",
                    reason=f"Firewall: protected path '{protected}' cannot be modified",
                    severity="critical",
                )

        safe_paths = ctx.get("safe_paths") or []
        if isinstance(safe_paths, list) and safe_paths:
            if any(path_lower.startswith(str(p).lower()) for p in safe_paths):
                return FirewallResult(decision="allow", reason="Firewall: path is in safe_paths", severity="low")
            return FirewallResult(
                decision="require_approval",
                reason="Firewall: path not in safe_paths — requires approval",
                severity="medium",
            )

        return FirewallResult(
            decision="require_approval",
            reason="Firewall: no safe_paths configured — file modification requires approval",
            severity="medium",
        )

    if action_norm == "call_external_api":
        domain_lower = str(payload.get("domain", "") or payload.get("url", "") or "").lower()
        if not domain_lower:
            return FirewallResult(decision="deny", reason="Firewall: external API call missing domain/url", severity="high")
        if domain_lower.endswith(".internal") or domain_lower.startswith("localhost") or domain_lower.startswith("127."):
            return FirewallResult(
                decision="deny",
                reason="Firewall: internal/loopback domains are not approved for external API calls",
                severity="high",
            )
        return FirewallResult(
            decision="require_approval",
            reason="Firewall: external API calls require approval by default",
            severity="medium",
        )

    if action_norm in _SPEND_ACTION_TYPES:
        try:
            amount = float(payload.get("amount", 0) or 0)
        except (TypeError, ValueError):
            amount = 0.0
        threshold = _effective_spend_threshold(ctx)
        if threshold is None:
            return FirewallResult(decision="allow", reason="Firewall: spending limit is unlimited in agent_ctx", severity="medium")
        if amount > threshold:
            return FirewallResult(
                decision="require_approval",
                reason=f"Firewall: spending ${amount:.2f} exceeds autonomous threshold of ${threshold:.2f}",
                severity="high",
            )
        return FirewallResult(decision="allow", reason="Firewall: spending within autonomous threshold", severity="medium")

    return FirewallResult(decision="allow", reason="Action not covered by firewall rules", severity="low")


class ActionFirewall:
    def __init__(
        self,
        agent_ctx: Optional[Dict[str, Any]] = None,
        *,
        policy_file: Optional[str] = None,
        audit_log_path: Optional[str] = None,
        env_whitelist: Optional[List[str]] = None,
        cwd: Optional[str] = None,
    ):
        self.agent_ctx = agent_ctx or {}
        self.policy_file = policy_file
        self.audit_log_path = audit_log_path
        self.env_whitelist = env_whitelist
        self.cwd = cwd

    def execute_shell(self, command: str) -> Dict[str, Any]:
        from .core import authorize_action
        from .runner import run_safely

        result = authorize_action(
            agent_ctx=dict(self.agent_ctx),
            action_type="execute_shell",
            action_payload={"command": command},
            policy_file=self.policy_file,
            audit_log_path=self.audit_log_path,
        )
        if result["decision"] != "ALLOW":
            return {
                "status": "blocked",
                "decision": result["decision"],
                "reason": result["reason"],
                "severity": result["severity"],
                "layers": result.get("layers", {}),
                "authorization_id": result.get("authorization_id"),
            }
        return {
            "status": "executed",
            "severity": result["severity"],
            "authorization_id": result.get("authorization_id"),
            **run_safely(command, env_whitelist=self.env_whitelist, cwd=self.cwd),
        }

    def _safe_run(self, command: str) -> Dict[str, Any]:
        from .runner import run_safely

        return run_safely(command, env_whitelist=self.env_whitelist, cwd=self.cwd)
