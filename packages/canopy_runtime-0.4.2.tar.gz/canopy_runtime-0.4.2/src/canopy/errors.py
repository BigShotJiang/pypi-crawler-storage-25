from __future__ import annotations

from typing import Any, Dict


class CanopyPermissionError(PermissionError):
    def __init__(self, result: Dict[str, Any]):
        self.decision = str(result.get("decision") or "")
        self.reason = str(result.get("reason") or "")
        self.avid = str(result.get("avid") or "")
        self.severity = str(result.get("severity") or "")
        self.layers = result.get("layers") if isinstance(result.get("layers"), dict) else {}
        super().__init__(self.reason)

