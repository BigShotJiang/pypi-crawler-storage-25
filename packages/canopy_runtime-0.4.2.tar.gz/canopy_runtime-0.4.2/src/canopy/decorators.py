from __future__ import annotations

import functools
import inspect
import os
import sys
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, Optional, TypeVar, Union, overload

from .audit import HashChainAuditLog
from .core import authorize_action
from .errors import CanopyPermissionError
from .approval import prompt_for_approval

T = TypeVar("T")


AgentCtxProvider = Union[Dict[str, Any], Callable[[], Dict[str, Any]], None]


def _json_safe(value: Any) -> Any:
    """Best-effort conversion to JSON-serializable structures.

    Canopy policy matching already tolerates non-JSON values via `default=str`,
    but converting common containers keeps payloads more stable and readable.
    """
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for k, v in value.items():
            out[str(k)] = _json_safe(v)
        return out
    return str(value)


def _resolve_agent_ctx(agent_ctx: AgentCtxProvider) -> Dict[str, Any]:
    if agent_ctx is None:
        return {}
    if callable(agent_ctx):
        ctx = agent_ctx()
        return dict(ctx or {})
    return dict(agent_ctx or {})


@overload
def safe_tool(
    *,
    action_type: str,
    agent_ctx: AgentCtxProvider = None,
    on_require_approval: str = "raise",
    approval_callback: None = None,
    policy_file: str | None = None,
    audit_log_path: str | None = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]: ...


@overload
def safe_tool(
    *,
    action_type: str,
    agent_ctx: AgentCtxProvider = None,
    on_require_approval: str = "callback",
    approval_callback: Callable[[Dict[str, Any], Callable[..., T], Any], T] | None = None,
    policy_file: str | None = None,
    audit_log_path: str | None = None,
) -> Callable[[Callable[..., T]], Callable[..., Optional[T]]]: ...


def safe_tool(
    *,
    action_type: str,
    agent_ctx: AgentCtxProvider = None,
    on_require_approval: str = "raise",  # "raise" | "skip" | "callback" | env via CANOPY_REQUIRE_APPROVAL_MODE
    approval_callback: Optional[Callable[..., Any]] = None,
    policy_file: str | None = None,
    audit_log_path: str | None = None,
    attest_results: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., Any]]:
    """Decorator that gates function execution with Canopy authorize_action.

    Behavior:
    - ALLOW: executes the function
    - DENY: raises PermissionError
    - REQUIRE_APPROVAL:
      - "raise": raises PermissionError (default)
      - "skip": returns None
      - "callback": calls approval_callback(result, func, *args, **kwargs) and returns its value

    `agent_ctx` can be:
    - a dict (static context)
    - a zero-arg callable returning a dict (dynamic runtime context)
    """

    if not action_type or not str(action_type).strip():
        raise ValueError("safe_tool requires a non-empty action_type")

    def decorator(func: Callable[..., T]) -> Callable[..., Any]:
        def _audit_path() -> Path:
            return Path(audit_log_path) if audit_log_path else Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))

        def _resolve_mode() -> str:
            env_mode = str(os.getenv("CANOPY_REQUIRE_APPROVAL_MODE", "")).strip().lower()
            if env_mode in {"raise", "skip", "callback", "prompt"}:
                return "callback" if env_mode == "prompt" else env_mode
            return (on_require_approval or "raise").lower()

        def _resolve_callback(mode: str) -> Optional[Callable[..., Any]]:
            if approval_callback:
                return approval_callback
            if mode == "callback":
                return prompt_for_approval
            return None

        def _should_autoprompt(mode: str) -> bool:
            # If mode is raise but we're in an interactive TTY, fall back to prompt_for_approval to reduce friction.
            env_flag = str(os.getenv("CANOPY_REQUIRE_APPROVAL_AUTOPROMPT", "")).strip().lower()
            if env_flag in {"0", "false", "no", "off"}:
                return False
            return mode == "raise" and sys.stdin.isatty()

        def _append_followup_event(
            result: Dict[str, Any],
            *,
            event: str,
            decision: str,
            reason: str,
        ) -> None:
            try:
                HashChainAuditLog(_audit_path()).append(
                    avid=str(result.get("avid") or ""),
                    action_type=action_type,
                    decision=decision,
                    reason=reason,
                    severity=str(result.get("severity") or "low"),
                    layers=result.get("layers") if isinstance(result.get("layers"), dict) else {},
                    witness=result.get("witness") if isinstance(result.get("witness"), dict) else None,
                    event=event,
                    authorization_id=str(result.get("authorization_id") or "") or None,
                    trace_id=str(result.get("trace_id") or "") or None,
                    policy_snapshot=result.get("policy_snapshot") if isinstance(result.get("policy_snapshot"), dict) else None,
                )
            except Exception:
                # Follow-up logging must never crash the tool itself.
                return

        @functools.wraps(func)
        def _build_auth_payload(*args: Any, **kwargs: Any) -> Any:
            base_payload = {
                "function": getattr(func, "__name__", "unknown"),
                "args": _json_safe(args),
                "kwargs": _json_safe(kwargs),
            }

            auth_payload: Any = base_payload
            try:
                bound = inspect.signature(func).bind_partial(*args, **kwargs)
                argmap = dict(bound.arguments)
            except Exception:
                argmap = dict(kwargs)

            if action_type == "execute_shell":
                command = argmap.get("command")
                if command is not None:
                    auth_payload = {"command": _json_safe(command)}
            elif action_type == "modify_file":
                path = argmap.get("path")
                if path is not None:
                    auth_payload = {"path": _json_safe(path)}
            elif action_type == "call_external_api":
                url = argmap.get("url")
                endpoint = argmap.get("endpoint")
                if url is not None:
                    auth_payload = {"url": _json_safe(url)}
                elif endpoint is not None:
                    auth_payload = {"endpoint": _json_safe(endpoint)}
            return auth_payload

        async def _maybe_await(value: Any) -> Any:
            if inspect.isawaitable(value):
                return await value
            return value

        def _authorize(*args: Any, **kwargs: Any) -> Dict[str, Any]:
            ctx = _resolve_agent_ctx(agent_ctx)
            result = authorize_action(
                agent_ctx=ctx,
                action_type=action_type,
                action_payload=_build_auth_payload(*args, **kwargs),
                policy_file=policy_file,
                audit_log_path=audit_log_path,
            )
            return result

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = _authorize(*args, **kwargs)
                decision = str(result.get("decision") or "").upper()

                if decision == "ALLOW":
                    authorization_id = str(result.get("authorization_id") or "")
                    try:
                        out = await func(*args, **kwargs)
                    except Exception as e:  # pragma: no cover (behavior covered by sync path)
                        if attest_results and authorization_id:
                            try:
                                HashChainAuditLog(_audit_path()).append_tool_result(
                                    authorization_id=authorization_id,
                                    avid=str(result.get("avid") or ""),
                                    action_type=action_type,
                                    ok=False,
                                    error=f"{type(e).__name__}: {e}",
                                    trace_id=str(result.get("trace_id") or "") or None,
                                )
                            except Exception:
                                pass
                        raise

                    if attest_results and authorization_id:
                        try:
                            HashChainAuditLog(_audit_path()).append_tool_result(
                                authorization_id=authorization_id,
                                avid=str(result.get("avid") or ""),
                                action_type=action_type,
                                ok=True,
                                result=out,
                                trace_id=str(result.get("trace_id") or "") or None,
                            )
                        except Exception:
                            pass
                    return out
                if decision in {"DENY", "REQUIRE_APPROVAL"}:
                    mode = _resolve_mode()
                    callback = _resolve_callback(mode)
                    autoprompt = _should_autoprompt(mode)
                    if decision == "DENY":
                        raise CanopyPermissionError(result)
                    if mode == "raise":
                        if autoprompt and callback:
                            callback_result = {**result, "action_type": action_type}
                            return await _maybe_await(callback(callback_result, func, *args, **kwargs))
                        raise CanopyPermissionError(result)
                    if mode == "skip":
                        _append_followup_event(
                            result,
                            event="approval_skipped",
                            decision="SKIP",
                            reason="Approval required but skipped by @safe_tool; tool not executed.",
                        )
                        warnings.warn(
                            "Canopy REQUIRE_APPROVAL skipped (on_require_approval='skip'); returning None. "
                            "Callers must handle None explicitly.",
                            RuntimeWarning,
                            stacklevel=2,
                        )
                        return None
                    if mode == "callback":
                        if callback is None:
                            raise ValueError("approval_callback is required when on_require_approval='callback'")
                        callback_result = {**result, "action_type": action_type}
                        return await _maybe_await(callback(callback_result, func, *args, **kwargs))
                    raise ValueError("on_require_approval must be one of: 'raise', 'skip', 'callback'")
                raise ValueError(f"Unknown Canopy decision: {decision!r}")

            return async_wrapper

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            result = _authorize(*args, **kwargs)

            decision = str(result.get("decision") or "").upper()
            mode = _resolve_mode()
            callback = _resolve_callback(mode)
            autoprompt = _should_autoprompt(mode)

            if decision == "ALLOW":
                authorization_id = str(result.get("authorization_id") or "")
                try:
                    out = func(*args, **kwargs)
                except Exception as e:
                    if attest_results and authorization_id:
                        try:
                            HashChainAuditLog(_audit_path()).append_tool_result(
                                authorization_id=authorization_id,
                                avid=str(result.get("avid") or ""),
                                action_type=action_type,
                                ok=False,
                                error=f"{type(e).__name__}: {e}",
                                trace_id=str(result.get("trace_id") or "") or None,
                            )
                        except Exception:
                            pass
                    raise

                if attest_results and authorization_id:
                    try:
                        HashChainAuditLog(_audit_path()).append_tool_result(
                            authorization_id=authorization_id,
                            avid=str(result.get("avid") or ""),
                            action_type=action_type,
                            ok=True,
                            result=out,
                            trace_id=str(result.get("trace_id") or "") or None,
                        )
                    except Exception:
                        pass
                return out

            if decision == "REQUIRE_APPROVAL":
                if mode == "raise":
                    if autoprompt and callback:
                        callback_result = {**result, "action_type": action_type}
                        return callback(callback_result, func, *args, **kwargs)
                    raise CanopyPermissionError(result)
                if mode == "skip":
                    _append_followup_event(
                        result,
                        event="approval_skipped",
                        decision="SKIP",
                        reason="Approval required but skipped by @safe_tool; tool not executed.",
                    )
                    warnings.warn(
                        "Canopy REQUIRE_APPROVAL skipped (on_require_approval='skip'); returning None. "
                        "Callers must handle None explicitly.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                    return None
                if mode == "callback":
                    if callback is None:
                        raise ValueError("approval_callback is required when on_require_approval='callback'")
                    callback_result = {**result, "action_type": action_type}
                    return callback(callback_result, func, *args, **kwargs)
                raise ValueError("on_require_approval must be one of: 'raise', 'skip', 'callback'")

            if decision == "DENY":
                raise CanopyPermissionError(result)

            raise ValueError(f"Unknown Canopy decision: {decision!r}")

        return wrapper

    return decorator
