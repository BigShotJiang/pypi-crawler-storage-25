from __future__ import annotations

import json
from pathlib import Path

from canopy.core import authorize_action


CREATED_AT = "2026-01-01T00:00:00Z"


def _last_entry(log_path: Path) -> dict:
    line = log_path.read_text(encoding="utf-8").strip().splitlines()[-1]
    return json.loads(line)


def test_civil_code_audit_has_override_key(tmp_path: Path):
    log = tmp_path / "audit.log"
    authorize_action(
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        action_type="crypto_mining",
        action_payload={},
        audit_log_path=log,
    )
    entry = _last_entry(log)
    assert entry["override_possible"] is True
    assert entry["override_key"] == "agent_ctx['mining_authorized'] = True"


def test_civil_code_audit_has_constitution_witness(tmp_path: Path):
    log = tmp_path / "audit.log"
    authorize_action(
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        action_type="crypto_mining",
        action_payload={},
        audit_log_path=log,
    )
    entry = _last_entry(log)
    assert "constitution_witness" in entry
    assert entry["constitution_witness"]["event"] == "constitution_allow"


def test_constitution_block_no_override_key(tmp_path: Path):
    log = tmp_path / "audit.log"
    authorize_action(
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        action_type="execute_shell",
        action_payload={"command": "rm -rf /"},
        audit_log_path=log,
    )
    entry = _last_entry(log)
    assert entry.get("override_possible") is False
    assert entry.get("override_key") is None
    assert "constitution_witness" not in entry

