from __future__ import annotations

from canopy.constitution import evaluate


def test_art7_kill_switch_denies():
    res = evaluate(
        avid="AVID-test",
        action_type="execute_shell",
        action_payload={"command": "echo ok"},
        agent_ctx={"kill_switch": True},
    )
    assert res.allowed is False
    assert res.violated_article == "Art.7"


def test_art1_scan_extracts_known_fields_only():
    res = evaluate(
        avid="AVID-test",
        action_type="execute_shell",
        action_payload={"command": "echo ok", "kill_yourself": "false"},
        agent_ctx={},
    )
    assert res.allowed is True


def test_art0_catastrophic_shell_denies():
    res = evaluate(
        avid="AVID-test",
        action_type="execute_shell",
        action_payload={"command": "rm -rf /"},
        agent_ctx={},
    )
    assert res.allowed is False
    assert res.violated_article == "Art.0"


def test_art0_ssrf_internal_denies():
    res = evaluate(
        avid="AVID-test",
        action_type="call_external_api",
        action_payload={"url": "http://localhost:1234/status"},
        agent_ctx={},
    )
    assert res.allowed is False
    assert res.violated_article == "Art.0"

