from __future__ import annotations

from pathlib import Path

import pytest

from canopy.decorators import safe_tool
from canopy.errors import CanopyPermissionError


CREATED_AT = "2026-03-15T00:00:00Z"


def test_safe_tool_allow(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                '    deny_if: "nope"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    @safe_tool(action_type="t", agent_ctx={"public_key": "pk", "created_at": CREATED_AT}, policy_file=str(policy))
    def f(x: int) -> int:
        return x + 1

    assert f(1) == 2


def test_safe_tool_deny_raises(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                '    deny_if: "block"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    @safe_tool(action_type="t", agent_ctx={"public_key": "pk", "created_at": CREATED_AT}, policy_file=str(policy))
    def f(s: str) -> str:
        return s

    with pytest.raises(CanopyPermissionError) as e:
        f("block")
    assert e.value.decision == "DENY"
    assert e.value.reason
    assert str(e.value.avid).startswith("AVID-")


def test_safe_tool_require_approval_raise(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                "    require_approval: true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    @safe_tool(action_type="t", agent_ctx={"public_key": "pk", "created_at": CREATED_AT}, policy_file=str(policy))
    def f() -> str:
        return "ok"

    with pytest.raises(CanopyPermissionError) as e:
        f()
    assert e.value.decision == "REQUIRE_APPROVAL"


def test_safe_tool_require_approval_skip(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                "    require_approval: true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    audit_path = tmp_path / "audit.log"

    @safe_tool(
        action_type="t",
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        policy_file=str(policy),
        audit_log_path=str(audit_path),
        on_require_approval="skip",
    )
    def f() -> str:
        return "ok"

    with pytest.warns(RuntimeWarning):
        assert f() is None

    lines = audit_path.read_text(encoding="utf-8").splitlines()
    assert len(lines) >= 2


def test_safe_tool_require_approval_callback(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                "    require_approval: true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    seen = {}

    def cb(result, func, *args, **kwargs):
        seen["decision"] = result["decision"]
        seen["avid"] = result["avid"]
        return func(*args, **kwargs)

    @safe_tool(
        action_type="t",
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        policy_file=str(policy),
        on_require_approval="callback",
        approval_callback=cb,
    )
    def f(x: int) -> int:
        return x + 10

    assert f(2) == 12
    assert seen["decision"] == "REQUIRE_APPROVAL"
    assert str(seen["avid"]).startswith("AVID-")


def test_safe_tool_attests_return_value(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                '    deny_if: "nope"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    audit_path = tmp_path / "audit.log"

    @safe_tool(
        action_type="t",
        agent_ctx={"public_key": "pk", "created_at": CREATED_AT},
        policy_file=str(policy),
        audit_log_path=str(audit_path),
    )
    def f(x: int) -> dict:
        return {"x": x, "ok": True}

    out = f(7)
    assert out["ok"] is True

    lines = audit_path.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2

    import json

    auth = json.loads(lines[0])
    att = json.loads(lines[1])
    assert auth["event"] == "authorize_action"
    assert "entry_hash" in auth
    assert att["event"] == "tool_result"
    assert att.get("authorization_id") == auth["entry_hash"]
    assert att.get("ok") is True
    assert isinstance(att.get("result_hash"), str) and att["result_hash"]


def test_canopy_permission_error_attributes(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                "    require_approval: true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    @safe_tool(action_type="t", agent_ctx={"public_key": "pk", "created_at": CREATED_AT}, policy_file=str(policy))
    def f() -> str:
        return "ok"

    with pytest.raises(CanopyPermissionError) as e:
        f()
    assert e.value.decision == "REQUIRE_APPROVAL"
    assert isinstance(e.value.layers, dict)


def test_safe_tool_dynamic_agent_ctx(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                "    when_all:",
                '      - \'agent_ctx.env == "production"\'',
                '      - \'payload contains "rm"\'',
                '    deny_if: "rm"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    state = {"env": "staging"}

    def ctx():
        return {"env": state["env"], "public_key": "pk", "created_at": CREATED_AT}

    @safe_tool(action_type="t", agent_ctx=ctx, policy_file=str(policy))
    def f(cmd: str) -> str:
        return cmd

    assert f("rm") == "rm"
    state["env"] = "production"
    with pytest.raises(CanopyPermissionError):
        f("rm")


def test_safe_tool_async_allow(tmp_path: Path):
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "\n".join(
            [
                "rules:",
                '  - action_type: "t"',
                '    deny_if: "nope"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    @safe_tool(action_type="t", agent_ctx={"public_key": "pk", "created_at": CREATED_AT}, policy_file=str(policy))
    async def f(x: int) -> int:
        return x + 1

    import asyncio

    assert asyncio.run(f(1)) == 2
