from __future__ import annotations

import types

import pytest

from canopy.errors import CanopyPermissionError


def test_langchain_adapter_deny(monkeypatch):
    # Provide a fake langchain.tools.BaseTool without installing langchain.
    class BaseTool:
        def __init__(self):
            self._run = lambda x: x  # noqa: E731
            self._arun = None

    fake_tools = types.SimpleNamespace(BaseTool=BaseTool)
    fake_langchain = types.SimpleNamespace(tools=fake_tools)

    monkeypatch.setitem(__import__("sys").modules, "langchain", fake_langchain)
    monkeypatch.setitem(__import__("sys").modules, "langchain.tools", fake_tools)

    # Force Canopy deny on any call.
    import canopy.decorators as decorators

    monkeypatch.setattr(
        decorators,
        "authorize_action",
        lambda **kwargs: {
            "decision": "DENY",
            "reason": "blocked",
            "avid": "AVID-test",
            "severity": "high",
            "layers": {},
        },
    )

    from canopy.adapters.langchain import canopy_tool

    tool_obj = BaseTool()
    guarded_tool = canopy_tool(action_type="t", agent_ctx={"created_at": "2026-01-01T00:00:00Z"})(tool_obj)

    with pytest.raises(CanopyPermissionError):
        guarded_tool._run("x")


def test_langgraph_adapter_allow(monkeypatch):
    # Provide a fake langgraph module without installing it.
    monkeypatch.setitem(__import__("sys").modules, "langgraph", types.SimpleNamespace())

    from canopy.adapters.langgraph import canopy_node
    import canopy.adapters.langgraph as lg

    monkeypatch.setattr(
        lg,
        "authorize_action",
        lambda **kwargs: {
            "decision": "ALLOW",
            "reason": "ok",
            "avid": "AVID-test",
            "severity": "low",
            "layers": {},
        },
    )

    called = {"n": 0}

    @canopy_node(action_type="t", agent_ctx={"created_at": "2026-01-01T00:00:00Z"})
    def node(state: dict) -> dict:
        called["n"] += 1
        return {**state, "ok": True}

    out = node({"x": 1})
    assert out["ok"] is True
    assert called["n"] == 1


def test_autogen_adapter_require_approval_skip(monkeypatch):
    # Provide a fake autogen module without installing it.
    monkeypatch.setitem(__import__("sys").modules, "autogen", types.SimpleNamespace())

    import canopy.decorators as decorators
    from canopy.adapters.autogen import canopy_autogen_tool

    monkeypatch.setattr(
        decorators,
        "authorize_action",
        lambda **kwargs: {
            "decision": "REQUIRE_APPROVAL",
            "reason": "needs approval",
            "avid": "AVID-test",
            "severity": "medium",
            "layers": {},
        },
    )

    called = {"n": 0}

    @canopy_autogen_tool(
        action_type="t",
        agent_ctx={"created_at": "2026-01-01T00:00:00Z"},
        on_require_approval="skip",
    )
    def tool(x: int) -> int:
        called["n"] += 1
        return x + 1

    with pytest.warns(RuntimeWarning):
        assert tool(1) is None
    assert called["n"] == 0
