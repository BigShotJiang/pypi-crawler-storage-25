from __future__ import annotations

from pathlib import Path

import pytest

from canopy.core import (
    MAX_PAYLOAD_TEXT_LEN,
    MAX_REGEX_PATTERN_LEN,
    _payload_text,
    authorize_action,
    Decision,
)


def test_payload_text_is_truncated():
    long_text = "x" * (MAX_PAYLOAD_TEXT_LEN + 500)
    rendered = _payload_text(long_text)
    assert rendered.endswith("[truncated]")
    assert len(rendered) <= MAX_PAYLOAD_TEXT_LEN + len("... [truncated]")


def test_overlong_regex_is_ignored(tmp_path: Path):
    long_regex = "a" * (MAX_REGEX_PATTERN_LEN + 10)  # intentionally exceeds regex limit
    policy = tmp_path / "policy.yaml"
    policy.write_text(
        "rules:\n"
        "  - action_type: \"execute_shell\"\n"
        f"    deny_regex: '{long_regex}'\n",
        encoding="utf-8",
    )
    decision = authorize_action(
        {"public_key": "pk", "created_at": "2026-01-01T00:00:00Z"},
        "execute_shell",
        {"command": "echo hello"},
        policy_file=policy,
    )
    # With the regex ignored, the action should remain allowed by default.
    assert decision["decision"] == Decision.ALLOW


def test_agent_ctx_requires_public_key_and_created_at():
    with pytest.raises(ValueError):
        authorize_action({}, "execute_shell", {"command": "echo hi"})
