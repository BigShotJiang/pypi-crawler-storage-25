from __future__ import annotations

from canopy.runner import run_safely


def test_run_safely_returns_shape():
    res = run_safely("echo hello", timeout=5)
    assert set(res.keys()) == {"returncode", "stdout", "stderr"}
    assert res["returncode"] == 0
    assert "hello" in res["stdout"]

