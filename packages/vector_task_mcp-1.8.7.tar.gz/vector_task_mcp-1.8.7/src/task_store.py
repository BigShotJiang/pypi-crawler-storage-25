"""
Task Store Module
==================

Provides SQLite-vec based task storage with vector embeddings for semantic task search.
Handles database initialization, task CRUD operations, and vector search.
"""

import asyncio
import logging
import sqlite3
import sqlite_vec
import json
import math
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple
from zoneinfo import ZoneInfo

from .models import Task, TaskStatus, TaskStats, Config, Priority, decimal_hours_to_hhmm, hhmm_to_minutes, minutes_to_hhmm, hhmm_add, is_decimal_hours_format
from .security import (
    SecurityError, sanitize_input, validate_task_status,
    validate_task_params, validate_task_update_params,
    validate_status_transition,
    generate_content_hash, validate_file_path, validate_parent_id,
    validate_bulk_tasks_params, validate_bulk_task_ids
)
from .embeddings import get_embedding_model, EmbeddingModel


logger = logging.getLogger(__name__)


class TaskStore:
    """Thread-safe task storage using sqlite-vec for semantic search."""

    def __init__(
        self,
        db_path: Path,
        embedding_model_name: str = None,
        timezone: str = None,
        task_folder: Optional[Path] = None,
        working_dir: Optional[Path] = None,
    ):
        """
        Initialize task store.

        Args:
            db_path: Path to SQLite database file
            embedding_model_name: Name of embedding model to use
            timezone: Timezone for timestamp storage (default: UTC)
            task_folder: Optional root for per-task folders (--task-folder
                feature). When None, folder operations are disabled.
            working_dir: Optional working directory used to compute relative
                paths in folder listings. Defaults to db_path's project root
                ({db_path}.parent.parent — i.e. above the memory/ dir).
        """
        self.db_path = Path(db_path)
        self.embedding_model_name = embedding_model_name or Config.EMBEDDING_MODEL
        self.timezone = timezone or "UTC"
        self.task_folder = Path(task_folder) if task_folder is not None else None
        self.working_dir = (
            Path(working_dir) if working_dir is not None else self.db_path.parent.parent
        )

        # Folder manager — instantiated only when feature is enabled.
        # Lazy import keeps src.task_folder optional and avoids any chance
        # of circular dependencies.
        if self.task_folder is not None:
            from .task_folder import TaskFolderManager
            self.folder_mgr: "Optional[TaskFolderManager]" = TaskFolderManager(
                task_folder_root=self.task_folder, working_dir=self.working_dir
            )
        else:
            self.folder_mgr = None

        # Lazy-loaded embedding model (async initialization)
        self._embedding_model: EmbeddingModel | None = None
        self._model_loading_task: asyncio.Task | None = None

        # Lazy-loaded database initialization (async)
        self._db_initialized: bool = False
        self._db_init_task: asyncio.Task | None = None

        # Validate database path
        validate_file_path(self.db_path)

    async def _ensure_db_initialized_async(self) -> None:
        """
        Ensure database is initialized with async lazy loading.

        Creates asyncio.Task on first call for background initialization.
        All concurrent callers await the SAME task (no duplicate initialization).
        """
        if self._db_initialized:
            return

        if self._db_init_task is None:
            self._db_init_task = asyncio.create_task(
                asyncio.to_thread(self._init_database)
            )

        await self._db_init_task
        self._db_initialized = True

    def _ensure_db_initialized_sync(self) -> None:
        """
        Ensure database is initialized with synchronous loading (fallback for non-async contexts).

        Blocks if database not yet initialized (synchronous fallback).
        """
        if not self._db_initialized:
            self._init_database()
            self._db_initialized = True

    async def get_embedding_model_async(self) -> EmbeddingModel:
        """
        Get embedding model with async lazy loading.

        Returns cached model if already loaded.
        Creates asyncio.Task on first call for background loading.
        All concurrent callers await the SAME task (no duplicate loading).

        Returns:
            EmbeddingModel instance
        """
        if self._embedding_model is not None:
            return self._embedding_model

        if self._model_loading_task is None:
            self._model_loading_task = asyncio.create_task(
                asyncio.to_thread(get_embedding_model, self.embedding_model_name)
            )

        self._embedding_model = await self._model_loading_task
        return self._embedding_model

    def _get_embedding_model_sync(self) -> EmbeddingModel:
        """
        Get embedding model with synchronous loading (fallback for non-async contexts).

        Returns cached model if already loaded.
        Blocks if model not yet loaded (synchronous fallback).

        Returns:
            EmbeddingModel instance
        """
        if self._embedding_model is None:
            self._embedding_model = get_embedding_model(self.embedding_model_name)
        return self._embedding_model

    @property
    def embedding_model(self) -> EmbeddingModel:
        """
        Property for backwards compatibility.

        Provides synchronous access to embedding model.
        Use get_embedding_model_async() for async contexts.

        Returns:
            EmbeddingModel instance
        """
        return self._get_embedding_model_sync()

    def _init_database(self) -> None:
        """Initialize sqlite-vec database with required tables."""
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to initialize task store: {e}")

        try:
            # Create tasks table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    parent_id INTEGER,
                    status TEXT NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    comment TEXT,
                    content_hash TEXT UNIQUE NOT NULL,
                    created_at TEXT NOT NULL,
                    start_at TEXT,
                    finish_at TEXT
                )
            """)

            # Migration: Add comment column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'comment' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN comment TEXT")

            # Migration: Add priority column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'priority' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'medium'")

            # Migration: Add tags column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'tags' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN tags TEXT")

            # Migration: Add estimate column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'estimate' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN estimate REAL")

            # Migration: Add order column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'order' not in columns:
                conn.execute('ALTER TABLE tasks ADD COLUMN "order" INTEGER')

            # Migration: Add time_spent column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'time_spent' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN time_spent REAL DEFAULT 0.0")

            # Migration: Add parallel column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'parallel' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN parallel INTEGER DEFAULT 0")

            # Migration: Add tag_variants column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'tag_variants' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN tag_variants TEXT")

            # Migration: Add code column if it doesn't exist
            cursor = conn.execute("PRAGMA table_info(tasks)")
            columns = [row[1] for row in cursor.fetchall()]
            if 'code' not in columns:
                conn.execute("ALTER TABLE tasks ADD COLUMN code TEXT")

            # Create vector table using vec0
            conn.execute(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS task_vectors USING vec0(
                    embedding float[{Config.EMBEDDING_DIM}]
                );
            """)

            # Create task_time_log table for time tracking
            conn.execute("""
                CREATE TABLE IF NOT EXISTS task_time_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER NOT NULL,
                    start_status TEXT NOT NULL,
                    finish_status TEXT,
                    time_spent REAL DEFAULT 0.0,
                    start_at TEXT NOT NULL,
                    finish_at TEXT,
                    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
                )
            """)

            # Create canonical_tags table for tag normalization
            conn.execute("""
                CREATE TABLE IF NOT EXISTS canonical_tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    canonical_tag TEXT NOT NULL,
                    variant_tag TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL
                )
            """)

            # Create index for canonical_tags lookups
            conn.execute("CREATE INDEX IF NOT EXISTS idx_canonical_variant ON canonical_tags(variant_tag)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_canonical_canonical ON canonical_tags(canonical_tag)")

            # Remove deprecated indexes (covered by composite indexes)
            conn.execute("DROP INDEX IF EXISTS idx_task_status")  # covered by idx_task_status_parent
            conn.execute("DROP INDEX IF EXISTS idx_task_parent")  # covered by idx_task_parent_order

            # Create indexes for performance (composite indexes cover single-column queries)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_created ON tasks(created_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_hash ON tasks(content_hash)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_priority ON tasks(status, priority, created_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_tags ON tasks(tags)")
            conn.execute('CREATE INDEX IF NOT EXISTS idx_task_parent_order ON tasks(parent_id, "order")')
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_status_parent ON tasks(status, parent_id)")
            conn.execute('CREATE INDEX IF NOT EXISTS idx_task_order ON tasks("order")')
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_start_at ON tasks(start_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_finish_at ON tasks(finish_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_estimate ON tasks(estimate)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_time_spent ON tasks(time_spent)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time_log_task_id ON task_time_log(task_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time_log_incomplete ON task_time_log(task_id) WHERE finish_at IS NULL")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time_log_start_at ON task_time_log(start_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time_log_finish_at ON task_time_log(finish_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_time_log_finish_status ON task_time_log(finish_status)")
            # Codes are NOT unique — multiple tasks may share the same code
            # to indicate "branching" of work that lives in a shared folder.
            # Drop a legacy UNIQUE definition (from earlier versions) before
            # creating the non-unique partial index.
            conn.execute("DROP INDEX IF EXISTS idx_task_code")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_task_code ON tasks(code) WHERE code IS NOT NULL")

            # Migration: backfill missing codes for ROOT tasks (parent_id IS NULL).
            # Legacy tasks created before #209 may have NULL code; the contract
            # is that every root task has a code (folder feature, project://info,
            # task_folder_files all rely on it). Subtasks are left untouched —
            # their NULL code is acceptable since they don't have folders.
            backfill_rows = conn.execute(
                "SELECT id, tags FROM tasks "
                "WHERE parent_id IS NULL AND code IS NULL"
            ).fetchall()
            for row_id, tags_json in backfill_rows:
                try:
                    tags = json.loads(tags_json) if tags_json else []
                except (json.JSONDecodeError, TypeError):
                    tags = []
                generated = self._generate_code(conn, tags)
                conn.execute(
                    "UPDATE tasks SET code = ? WHERE id = ?",
                    (generated, row_id),
                )
            if backfill_rows:
                logger.info(
                    "Backfilled %d code(s) for legacy root task(s)", len(backfill_rows)
                )

            # Update query planner statistics
            conn.execute("ANALYZE")

            conn.commit()

            # FS catch-up: opportunistically create folders for every root task
            # that has a code but no on-disk folder yet (e.g. backfilled rows
            # or rows created when --task-folder was disabled). Resilience
            # contract: FS failures NEVER affect DB state — already committed.
            if self.folder_mgr is not None:
                try:
                    rows = conn.execute(
                        "SELECT id, code, title, status FROM tasks "
                        "WHERE parent_id IS NULL AND code IS NOT NULL"
                    ).fetchall()
                    for r_id, r_code, r_title, r_status in rows:
                        try:
                            # ensure_folder_for_status is idempotent + lifecycle-
                            # aware: adopts existing folders at any position and
                            # creates new ones at the position matching status.
                            self.folder_mgr.ensure_folder_for_status(
                                r_code, r_title, r_id, r_status
                            )
                        except Exception:
                            logger.warning(
                                "FS catch-up failed for code=%r", r_code, exc_info=True
                            )
                except Exception:
                    logger.warning("FS catch-up scan failed", exc_info=True)

        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to initialize database: {e}")
        finally:
            conn.close()

    def _get_connection(self) -> sqlite3.Connection:
        """Get SQLite connection with sqlite-vec loaded."""
        conn = sqlite3.connect(str(self.db_path))
        conn.enable_load_extension(True)
        sqlite_vec.load(conn)
        # Enable WAL mode for safe concurrent access
        conn.execute("PRAGMA journal_mode=WAL")
        # Enable foreign key enforcement
        conn.execute("PRAGMA foreign_keys = ON")
        conn.enable_load_extension(False)
        return conn

    def _propagate_time_to_parents(self, conn: sqlite3.Connection, task_id: int, time_delta: float) -> None:
        """
        Recursively propagate time_delta to all parent tasks.

        Args:
            conn: Active database connection (must be within transaction)
            task_id: Current task ID
            time_delta: Time to propagate in HH.MM format
        """
        if time_delta <= 0:
            return

        # Get parent_id of current task
        cursor = conn.execute('SELECT parent_id FROM tasks WHERE id = ?', (task_id,))
        row = cursor.fetchone()
        if not row or not row[0]:  # No parent
            return

        parent_id = row[0]

        # Fetch current parent time_spent
        cursor = conn.execute(
            'SELECT time_spent FROM tasks WHERE id = ?',
            (parent_id,)
        )
        parent_row = cursor.fetchone()
        current_parent_time = parent_row[0] if parent_row and parent_row[0] else 0.0

        # Auto-convert old decimal hours format to HH.MM if needed
        if current_parent_time > 0 and is_decimal_hours_format(current_parent_time):
            current_parent_time = decimal_hours_to_hhmm(current_parent_time)

        # Calculate new time_spent using HH.MM arithmetic
        new_parent_time = hhmm_add(current_parent_time, time_delta)

        # Update parent's time_spent
        conn.execute(
            'UPDATE tasks SET time_spent = ? WHERE id = ?',
            (new_parent_time, parent_id)
        )
        # Recursively propagate to grandparent
        self._propagate_time_to_parents(conn, parent_id, time_delta)

    def _propagate_completed_to_parents(self, conn: sqlite3.Connection, task_id: int) -> None:
        """
        Recursively propagate 'completed' status to parent tasks when ALL children are finished.

        Rules:
        - Parent gets 'completed' ONLY when ALL children are in finish statuses (completed/tested/validated)
        - Recursively propagates up the parent chain with same check at each level

        Args:
            conn: Active database connection (must be within transaction)
            task_id: Current task ID whose status just changed to a finish status
        """
        # Get parent_id of current task
        cursor = conn.execute('SELECT parent_id FROM tasks WHERE id = ?', (task_id,))
        row = cursor.fetchone()
        if not row or not row[0]:  # No parent
            return

        parent_id = row[0]
        finish_statuses = TaskStatus.finish_statuses()

        # Check if ALL children of parent are in finish statuses
        placeholders = ','.join('?' * len(finish_statuses))
        cursor = conn.execute(f'''
            SELECT COUNT(*) FROM tasks
            WHERE parent_id = ? AND status NOT IN ({placeholders})
        ''', (parent_id, *finish_statuses))
        non_finished = cursor.fetchone()[0]

        if non_finished == 0:
            # All children finished → set parent to 'completed'
            conn.execute('UPDATE tasks SET status = ? WHERE id = ?', ('completed', parent_id))
            # Recursively check grandparent
            self._propagate_completed_to_parents(conn, parent_id)

    def _propagate_pending_to_parents(self, conn: sqlite3.Connection, task_id: int) -> None:
        """
        Recursively propagate 'pending' status to parent tasks when ANY child returns to pending.

        Rules:
        - Parent gets 'pending' when ANY child becomes 'pending'
        - Recursively propagates up the parent chain

        Args:
            conn: Active database connection (must be within transaction)
            task_id: Current task ID whose status just changed to 'pending'
        """
        # Get parent_id of current task
        cursor = conn.execute('SELECT parent_id FROM tasks WHERE id = ?', (task_id,))
        row = cursor.fetchone()
        if not row or not row[0]:  # No parent
            return

        parent_id = row[0]

        # Set parent to 'pending' unconditionally
        conn.execute('UPDATE tasks SET status = ? WHERE id = ?', ('pending', parent_id))
        # Recursively propagate to grandparent
        self._propagate_pending_to_parents(conn, parent_id)

    def _start_time_session(self, conn: sqlite3.Connection, task_id: int, start_status: str) -> None:
        """
        Create new time session record in task_time_log table.
        Only creates session for the specified task (no parent propagation).

        Args:
            conn: Active database connection (must be within transaction)
            task_id: Task ID to create session for
            start_status: Status at session start (typically 'in_progress')
        """
        now = datetime.now(timezone.utc).isoformat()

        try:
            conn.execute('''
                INSERT INTO task_time_log (task_id, start_status, start_at, time_spent)
                VALUES (?, ?, ?, 0.0)
            ''', (task_id, start_status, now))
        except Exception as e:
            raise RuntimeError(f"Failed to start time session for task {task_id}: {e}")

    def _finish_time_session(self, conn: sqlite3.Connection, task_id: int, time_spent: float, finish_status: str) -> None:
        """
        Complete existing time session record in task_time_log table.
        Only completes session for the specified task (no parent propagation).

        Args:
            conn: Active database connection (must be within transaction)
            task_id: Task ID to finish session for
            time_spent: Time spent in HH.MM format (e.g., 1.30 = 1 hour 30 minutes)
            finish_status: Status at session finish (e.g., completed, stopped, tested)
        """
        now = datetime.now(timezone.utc).isoformat()

        try:
            # Find incomplete session for this task
            cursor = conn.execute('''
                SELECT id FROM task_time_log
                WHERE task_id = ? AND finish_at IS NULL
                LIMIT 1
            ''', (task_id,))

            session = cursor.fetchone()

            # If no incomplete session found, return silently (no error)
            if not session:
                return

            # Update session with finish_at, time_spent, and finish_status
            conn.execute('''
                UPDATE task_time_log
                SET finish_at = ?, time_spent = ?, finish_status = ?
                WHERE id = ?
            ''', (now, time_spent, finish_status, session[0]))
        except Exception as e:
            raise RuntimeError(f"Failed to finish time session for task {task_id}: {e}")

    def _get_status_history(self, conn: sqlite3.Connection, task_id: int, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Get status transition history from task_time_log.
        Includes both completed and incomplete (open) sessions.
        Open sessions appear first with to/at/spent as null.

        Args:
            conn: Database connection
            task_id: Task ID to get history for
            limit: Maximum records to return (default 5)

        Returns:
            List of dicts with keys: from, to, at, spent
            Ordered by: open sessions first, then finish_at DESC
        """
        cursor = conn.execute(
            """
            SELECT start_status, finish_status, finish_at, time_spent
            FROM task_time_log
            WHERE task_id = ?
            ORDER BY
                CASE WHEN finish_at IS NULL THEN 0 ELSE 1 END,
                finish_at DESC
            LIMIT ?
            """,
            (task_id, limit)
        )

        history = []
        for row in cursor.fetchall():
            history.append({
                "from": row[0],
                "to": row[1],
                "at": row[2],
                "spent": row[3]
            })

        return history

    # Tag → code prefix map for auto-generation
    _CODE_PREFIX_MAP = {
        "feature": "FEAT",
        "bugfix": "FIX",
        "refactor": "REFACTOR",
        "docs": "DOCS",
        "test": "TEST",
        "hotfix": "HOTFIX",
        "chore": "CHORE",
        "research": "RESEARCH",
        "spike": "SPIKE",
    }
    _CODE_DEFAULT_PREFIX = "TASK"

    def _generate_code(self, conn: sqlite3.Connection, tags: Optional[List[str]]) -> str:
        """
        Auto-generate task code in {PREFIX}-{N} format.

        Prefix is derived from the first matching tag (feature→FEAT, bugfix→FIX, ...).
        Counter is per-prefix: SELECT MAX(numeric suffix) + 1 across existing codes
        with the same prefix. Within a single connection (e.g. bulk insert),
        previously inserted rows are visible without commit, so sequential calls
        produce monotonically increasing codes.

        Args:
            conn: Active database connection
            tags: Task tags (lowercase, validated)

        Returns:
            Generated code string (e.g. "FEAT-44")
        """
        prefix = self._CODE_DEFAULT_PREFIX
        if tags:
            for tag in tags:
                if tag in self._CODE_PREFIX_MAP:
                    prefix = self._CODE_PREFIX_MAP[tag]
                    break

        cursor = conn.execute(
            "SELECT MAX(CAST(SUBSTR(code, LENGTH(?) + 2) AS INTEGER)) "
            "FROM tasks WHERE code LIKE ? || '-%'",
            (prefix, prefix),
        )
        row = cursor.fetchone()
        max_n = row[0] if row and row[0] is not None else 0
        return f"{prefix}-{max_n + 1}"

    def create_task(
        self,
        title: str,
        content: str,
        parent_id: Optional[int] = None,
        comment: Optional[str] = None,
        priority: Optional[str] = None,
        tags: Optional[List[str]] = None,
        estimate: Optional[float] = None,
        order: Optional[int] = None,
        parallel: bool = False,
        code: Optional[str] = None,
        embedding_model: Optional[EmbeddingModel] = None
    ) -> Dict[str, Any]:
        """
        Create a new task with vector embedding.

        Args:
            title: Task title
            content: Task content
            parent_id: Optional parent task ID for subtasks
            comment: Optional comment/note for the task
            priority: Optional priority level (low, medium, high, critical)
            tags: Optional list of tags for categorization
            estimate: Optional time estimate in hours
            order: Optional order position (auto-assigned if None, shifts siblings if provided)
            parallel: Whether task can be executed in parallel with siblings (default: False)
            code: Optional task code (format: PREFIX-N, e.g. FEAT-44). Auto-generated from tags if None.
            embedding_model: Optional pre-loaded embedding model (for async callers)

        Returns:
            Dict with operation result and task data
        """
        self._ensure_db_initialized_sync()
        # Use provided model or fall back to sync loading
        model = embedding_model or self._get_embedding_model_sync()
        # Validate parameters (including comment, priority, tags, order, and code)
        (title, content, _, validated_parent_id, validated_comment, validated_priority,
         validated_tags, validated_order, validated_code) = validate_task_params(
            title, content, parent_id=parent_id, comment=comment, priority=priority,
            tags=tags, order=order, code=code
        )

        # Generate content hash from title + content (tags not included in hash)
        combined = f"{title}\n{content}\n{' '.join(validated_tags)}"
        content_hash = generate_content_hash(f"{title}\n{content}")

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to create task: {e}")

        try:
            # Check if task already exists
            existing = conn.execute(
                "SELECT id FROM tasks WHERE content_hash = ?",
                (content_hash,)
            ).fetchone()

            if existing:
                return {
                    "success": False,
                    "message": "Task already exists",
                    "task_id": existing[0]
                }

            # Generate embedding from title + content
            embedding = model.encode_single(combined)

            # Calculate or validate order
            if validated_order is None:
                # Auto-assign: get next order for this parent
                cursor = conn.execute(
                    'SELECT COALESCE(MAX("order"), 0) + 1 FROM tasks WHERE parent_id IS ?',
                    (validated_parent_id,)
                )
                order_value = cursor.fetchone()[0]
            else:
                # Shift existing siblings to make room
                conn.execute(
                    'UPDATE tasks SET "order" = "order" + 1 WHERE parent_id IS ? AND "order" >= ?',
                    (validated_parent_id, validated_order)
                )
                order_value = validated_order

            # Resolve code: use provided (already validated) or auto-generate from tags
            final_code = validated_code if validated_code is not None else self._generate_code(conn, validated_tags)

            # Store task
            now = datetime.now(ZoneInfo(self.timezone)).isoformat()
            cursor = conn.execute("""
                INSERT INTO tasks (parent_id, status, title, content, comment, priority, tags, content_hash, created_at, estimate, "order", parallel, code)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (validated_parent_id, TaskStatus.PENDING.value, title, content, validated_comment, validated_priority, json.dumps(validated_tags), content_hash, now, estimate, order_value, 1 if parallel else 0, final_code))

            task_id = cursor.lastrowid

            # Validate self-reference before committing
            validate_parent_id(task_id, validated_parent_id, conn)

            # Store vector using sqlite-vec serialization
            embedding_blob = sqlite_vec.serialize_float32(embedding)
            conn.execute(
                "INSERT INTO task_vectors (rowid, embedding) VALUES (?, ?)",
                (task_id, embedding_blob)
            )

            conn.commit()

            # FS side-effect: create per-task folder for ROOT tasks only.
            # ensure_folder_for_status adopts existing folders at any
            # lifecycle position (handles orphaned folders from a prior
            # session) — never creates a duplicate empty {code}/. Then
            # _sync_code_folder_position re-positions per the aggregate
            # rule across all root tasks sharing this code (e.g. an
            # archived folder gets pulled back to active when a new
            # pending task joins the code).
            if self.folder_mgr is not None and validated_parent_id is None:
                try:
                    self.folder_mgr.ensure_folder_for_status(
                        final_code, title, task_id, TaskStatus.PENDING.value
                    )
                    # Reopen connection because ensure_folder_for_status
                    # doesn't need DB; reuse the still-open `conn` already
                    # in scope here for the aggregate query.
                    self._sync_code_folder_position(conn, final_code)
                except Exception as e:
                    logger.warning(
                        "Folder creation failed for task %s (%r): %s",
                        task_id, final_code, e, exc_info=True,
                    )

            return {
                "success": True,
                "task_id": task_id,
                "title": title,
                "content": content,
                "comment": validated_comment,
                "priority": validated_priority,
                "tags": validated_tags,
                "status": TaskStatus.PENDING.value,
                "created_at": now,
                "order": order_value,
                "parallel": parallel,
                "code": final_code
            }

        except SecurityError as e:
            conn.rollback()
            raise e
        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to create task: {e}")
        finally:
            conn.close()

    def create_tasks_bulk(
        self,
        tasks: List[dict],
        embedding_model: Optional[EmbeddingModel] = None
    ) -> Dict[str, Any]:
        """
        Create multiple tasks in a single transaction with batch embedding generation.

        Args:
            tasks: List of task dictionaries, each containing:
                - title: Task title (required)
                - content: Task content (required)
                - parent_id: Optional parent task ID
                - comment: Optional comment/note
            embedding_model: Optional pre-loaded embedding model (for async callers)

        Returns:
            Dict with operation result:
                - success: True if all tasks created, False otherwise
                - created_task_ids: List of created task IDs
                - count: Number of tasks created
                - message: Success or error message
                - skipped: Optional list of skipped tasks (duplicates)

        Raises:
            SecurityError: If validation fails
            RuntimeError: If database operation fails
        """
        self._ensure_db_initialized_sync()
        # Use provided model or fall back to sync loading
        model = embedding_model or self._get_embedding_model_sync()
        # Validate parameters
        validated_tasks, _ = validate_bulk_tasks_params(tasks, Config.MAX_BULK_CREATE)

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to create tasks: {e}")

        try:
            now = datetime.now(ZoneInfo(self.timezone)).isoformat()
            created_task_ids = []
            skipped_tasks = []
            task_insert_data = []
            combined_texts = []
            task_metadata = []

            # First pass: validate and prepare data
            for index, validated_tuple in enumerate(validated_tasks):
                title, content, _, validated_parent_id, validated_comment, validated_priority, validated_tags, validated_order, validated_code = validated_tuple

                # Generate content hash from title + content (tags not included)
                combined = f"{title}\n{content}\n{' '.join(validated_tags)}"
                content_hash = generate_content_hash(f"{title}\n{content}")

                # Check if task already exists
                existing = conn.execute(
                    "SELECT id FROM tasks WHERE content_hash = ?",
                    (content_hash,)
                ).fetchone()

                if existing:
                    skipped_tasks.append({
                        "index": index,
                        "task_id": existing[0],
                        "title": title[:50],
                        "reason": "Task already exists"
                    })
                    continue

                # Extract estimate, order, and parallel from original task dict
                estimate = tasks[index].get("estimate") if index < len(tasks) else None
                order = tasks[index].get("order") if index < len(tasks) else None
                parallel = bool(tasks[index].get("parallel", False)) if index < len(tasks) else False

                # Store metadata for later use
                task_metadata.append({
                    "title": title,
                    "content": content,
                    "parent_id": validated_parent_id,
                    "comment": validated_comment,
                    "priority": validated_priority,
                    "tags": validated_tags,
                    "content_hash": content_hash,
                    "estimate": estimate,
                    "order": validated_order if validated_order else order,
                    "parallel": parallel,
                    "code": validated_code
                })

                combined_texts.append(combined)

            # If all tasks were skipped, return early
            if not task_metadata:
                return {
                    "success": True,
                    "created_task_ids": [],
                    "count": 0,
                    "message": f"No tasks created (all {len(skipped_tasks)} tasks already exist)",
                    "skipped": skipped_tasks
                }

            # Batch generate embeddings for all valid tasks
            embeddings = model.encode(combined_texts)

            # Second pass: insert tasks and vectors in single transaction
            for idx, metadata in enumerate(task_metadata):
                # Resolve code: use provided (already validated) or auto-generate.
                # Within the same connection, prior INSERTs are visible to SELECT
                # MAX before commit, so per-prefix counters increment correctly.
                final_code = metadata["code"] if metadata["code"] is not None else self._generate_code(conn, metadata["tags"])
                # Persist final_code for post-commit folder hooks.
                metadata["final_code"] = final_code

                # Insert task
                cursor = conn.execute("""
                    INSERT INTO tasks (parent_id, status, title, content, comment, priority, tags, content_hash, created_at, estimate, "order", parallel, code)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metadata["parent_id"],
                    TaskStatus.PENDING.value,
                    metadata["title"],
                    metadata["content"],
                    metadata["comment"],
                    metadata["priority"],
                    json.dumps(metadata["tags"]),
                    metadata["content_hash"],
                    now,
                    metadata["estimate"],
                    metadata["order"],
                    1 if metadata["parallel"] else 0,
                    final_code
                ))

                task_id = cursor.lastrowid
                created_task_ids.append(task_id)
                metadata["task_id"] = task_id  # for post-commit folder hooks

                # Validate self-reference before continuing
                validate_parent_id(task_id, metadata["parent_id"], conn)

                # Store vector using sqlite-vec serialization
                embedding_blob = sqlite_vec.serialize_float32(embeddings[idx])
                conn.execute(
                    "INSERT INTO task_vectors (rowid, embedding) VALUES (?, ?)",
                    (task_id, embedding_blob)
                )

            # Commit all operations
            conn.commit()

            # FS side-effect: create per-task folder for ROOT tasks only.
            # Resilient — TaskFolderManager catches exceptions internally;
            # defensive try/except per task guards against contract breaks
            # without aborting the rest of the bulk batch.
            if self.folder_mgr is not None:
                for metadata in task_metadata:
                    if metadata["parent_id"] is not None:
                        continue  # subtasks have no folders
                    try:
                        self.folder_mgr.ensure_folder_for_status(
                            metadata["final_code"],
                            metadata["title"],
                            metadata["task_id"],
                            TaskStatus.PENDING.value,
                        )
                    except Exception as e:
                        logger.warning(
                            "Folder creation failed for task %s (%r): %s",
                            metadata["task_id"], metadata["final_code"], e,
                            exc_info=True,
                        )

            result = {
                "success": True,
                "created_task_ids": created_task_ids,
                "count": len(created_task_ids),
                "message": f"Successfully created {len(created_task_ids)} task(s)"
            }

            if skipped_tasks:
                result["skipped"] = skipped_tasks
                result["message"] += f" ({len(skipped_tasks)} skipped as duplicates)"

            return result

        except SecurityError as e:
            conn.rollback()
            raise e
        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to create tasks in bulk: {e}")
        finally:
            conn.close()

    def update_task(
        self,
        task_id: int,
        embedding_model: Optional[EmbeddingModel] = None,
        init_folder: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Update an existing task.

        Args:
            task_id: Task ID to update
            embedding_model: Optional pre-loaded embedding model (for async callers, only used if title/content/tags change)
            init_folder: When True, (re)initialize the on-disk folder for this
                ROOT task at the lifecycle position matching its FINAL status
                (after any status update in the same call). Used to recover
                folders that were deleted via the empty-template fast-path
                or never created (e.g. --task-folder enabled after task
                creation). Idempotent: adopts existing folders at any
                position. No-op for subtasks, NULL-code tasks, or when the
                folder feature is disabled.
            **kwargs: Fields to update (title, content, status, parent_id, start_at, finish_at)

        Returns:
            Dict with updated task data
        """
        self._ensure_db_initialized_sync()
        # Validate parameters
        task_id, validated_kwargs = validate_task_update_params(task_id, **kwargs)

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to update task: {e}")

        try:
            # Validate self-reference and parent existence if parent_id is being updated
            if 'parent_id' in validated_kwargs:
                validate_parent_id(task_id, validated_kwargs['parent_id'], conn)

            # Check if task exists
            existing = conn.execute(
                "SELECT id, title, content, status, parent_id, code FROM tasks WHERE id = ?",
                (task_id,)
            ).fetchone()

            if not existing:
                return {
                    "success": False,
                    "message": f"Task {task_id} not found"
                }

            # Validate status transition (jump-to-done white-list)
            if 'status' in validated_kwargs:
                validate_status_transition(existing[3], validated_kwargs['status'])

            # Validate: cannot set finish status if has unfinished children
            if 'status' in validated_kwargs:
                new_status = validated_kwargs['status']
                finish_statuses = TaskStatus.finish_statuses()

                if new_status in finish_statuses:
                    # Check for unfinished children (not in finish_statuses and not canceled)
                    allowed_child_statuses = finish_statuses + ('canceled',)
                    placeholders = ','.join('?' * len(allowed_child_statuses))

                    unfinished_children = conn.execute(f'''
                        SELECT id, title, status FROM tasks
                        WHERE parent_id = ? AND status NOT IN ({placeholders})
                        ORDER BY "order" ASC NULLS LAST, id ASC
                        LIMIT 5
                    ''', (task_id, *allowed_child_statuses)).fetchall()

                    if unfinished_children:
                        # Count total unfinished
                        total_unfinished = conn.execute(f'''
                            SELECT COUNT(*) FROM tasks
                            WHERE parent_id = ? AND status NOT IN ({placeholders})
                        ''', (task_id, *allowed_child_statuses)).fetchone()[0]

                        children_info = [f"#{c[0]} [{c[2]}] {c[1][:50]}" for c in unfinished_children]
                        more_msg = f" (+{total_unfinished - 5} more)" if total_unfinished > 5 else ""

                        return {
                            "success": False,
                            "error": "Cannot complete task with unfinished children",
                            "message": f"Task #{task_id} has {total_unfinished} unfinished child task(s). "
                                      f"Complete or cancel them first: {', '.join(children_info)}{more_msg}"
                        }

            # Build UPDATE query dynamically
            update_fields = []
            update_values = []

            regenerate_embedding = False
            new_title = existing[1]
            new_content = existing[2]

            # Auto-set timestamps on status changes
            # Auto-calculate time_spent on status change to stopped/completed
            time_delta = 0.0  # Track time spent for parent propagation
            status_changed = False
            new_status = None
            old_status = None  # Track old status for session management
            if 'status' in validated_kwargs:
                current_status = existing[3]  # status is 4th column (index 3)
                old_status = current_status  # Save old status before change
                new_status = validated_kwargs['status']
                status_changed = True

                finish_statuses = TaskStatus.finish_statuses()

                # Auto-convert old decimal hours format to HH.MM on any update
                cursor = conn.execute(
                    'SELECT time_spent FROM tasks WHERE id = ?',
                    (task_id,)
                )
                ts_row = cursor.fetchone()
                if ts_row and ts_row[0] is not None and ts_row[0] > 0:
                    old_time_spent = ts_row[0]
                    if is_decimal_hours_format(old_time_spent):
                        converted_time_spent = decimal_hours_to_hhmm(old_time_spent)
                        update_fields.append('"time_spent" = ?')
                        update_values.append(converted_time_spent)

                # Auto-set start_at when changing to in_progress (only if not explicitly provided)
                if new_status == 'in_progress' and current_status != 'in_progress':
                    if 'start_at' not in validated_kwargs:
                        validated_kwargs['start_at'] = datetime.now(ZoneInfo(self.timezone)).isoformat()

                if new_status in finish_statuses and current_status not in finish_statuses:
                    # Finishing task (completed/tested/validated) - set finish_at timestamp (only if not explicitly provided)
                    if 'finish_at' not in validated_kwargs:
                        validated_kwargs['finish_at'] = datetime.now(ZoneInfo(self.timezone)).isoformat()
                elif new_status not in finish_statuses and current_status in finish_statuses:
                    # Un-finishing task - clear finish_at (only if not explicitly provided)
                    if 'finish_at' not in validated_kwargs:
                        validated_kwargs['finish_at'] = None

                # Calculate time_spent when changing to stopped or any finish status
                finish_and_stopped = finish_statuses + ('stopped',)
                if new_status in finish_and_stopped and current_status not in finish_and_stopped:
                    # Fetch current task's start_at and existing time_spent
                    cursor = conn.execute(
                        'SELECT start_at, time_spent FROM tasks WHERE id = ?',
                        (task_id,)
                    )
                    row = cursor.fetchone()

                    if row:
                        start_at_str = row[0]
                        current_time_spent = row[1] if row[1] is not None else 0.0

                        # Auto-convert old decimal hours format to HH.MM if needed
                        if current_time_spent > 0 and is_decimal_hours_format(current_time_spent):
                            current_time_spent = decimal_hours_to_hhmm(current_time_spent)

                        # Calculate time delta if start_at exists
                        if start_at_str:
                            start_at = datetime.fromisoformat(start_at_str)
                            now = datetime.now(ZoneInfo(self.timezone))
                            time_delta_hours = (now - start_at).total_seconds() / 3600

                            # Protect against negative time (e.g., if start_at was in future)
                            if time_delta_hours < 0:
                                time_delta_hours = 0.0

                            # Convert time_delta to HH.MM format
                            time_delta = decimal_hours_to_hhmm(time_delta_hours)

                        # Calculate new cumulative time_spent using HH.MM arithmetic
                        new_time_spent = hhmm_add(current_time_spent, time_delta)

                        # Add to update fields
                        update_fields.append('"time_spent" = ?')
                        update_values.append(new_time_spent)

            for key, value in validated_kwargs.items():
                if key == 'title':
                    update_fields.append("title = ?")
                    update_values.append(value)
                    new_title = value
                    regenerate_embedding = True
                elif key == 'content':
                    update_fields.append("content = ?")
                    update_values.append(value)
                    new_content = value
                    regenerate_embedding = True
                elif key == 'status':
                    update_fields.append("status = ?")
                    update_values.append(value)
                elif key == 'parent_id':
                    update_fields.append("parent_id = ?")
                    update_values.append(value)
                elif key == 'start_at':
                    update_fields.append("start_at = ?")
                    update_values.append(value)
                elif key == 'finish_at':
                    update_fields.append("finish_at = ?")
                    update_values.append(value)
                elif key == 'comment':
                    update_fields.append("comment = ?")
                    update_values.append(value)
                elif key == 'priority':
                    update_fields.append("priority = ?")
                    update_values.append(value)
                elif key == 'tags':
                    update_fields.append("tags = ?")
                    update_values.append(json.dumps(value))
                    regenerate_embedding = True
                elif key == 'estimate':
                    update_fields.append("estimate = ?")
                    update_values.append(value)
                elif key == 'order':
                    update_fields.append('"order" = ?')
                    update_values.append(value)
                elif key == 'parallel':
                    update_fields.append('parallel = ?')
                    update_values.append(1 if value else 0)
                elif key == 'code':
                    update_fields.append('code = ?')
                    update_values.append(value)

            # Handle order change with shift logic
            if 'order' in validated_kwargs and validated_kwargs['order'] is not None:
                new_order = validated_kwargs['order']

                # Get current task's order and parent_id
                cursor = conn.execute(
                    'SELECT "order", parent_id FROM tasks WHERE id = ?',
                    (task_id,)
                )
                current = cursor.fetchone()
                if current:
                    old_order, current_parent_id = current

                    # Determine parent_id (use new if being changed, else current)
                    target_parent_id = validated_kwargs.get('parent_id', current_parent_id)

                    if old_order != new_order or validated_kwargs.get('parent_id') is not None:
                        if validated_kwargs.get('parent_id') is not None and validated_kwargs['parent_id'] != current_parent_id:
                            # Moving to different parent - shift down old siblings, shift up new siblings
                            if old_order is not None:
                                conn.execute(
                                    'UPDATE tasks SET "order" = "order" - 1 WHERE parent_id IS ? AND "order" > ? AND id != ?',
                                    (current_parent_id, old_order, task_id)
                                )
                            conn.execute(
                                'UPDATE tasks SET "order" = "order" + 1 WHERE parent_id IS ? AND "order" >= ? AND id != ?',
                                (target_parent_id, new_order, task_id)
                            )
                        elif old_order is not None and old_order != new_order:
                            # Same parent, reordering
                            if new_order > old_order:
                                # Moving down: shift range up
                                conn.execute(
                                    'UPDATE tasks SET "order" = "order" - 1 WHERE parent_id IS ? AND "order" > ? AND "order" <= ? AND id != ?',
                                    (current_parent_id, old_order, new_order, task_id)
                                )
                            else:
                                # Moving up: shift range down
                                conn.execute(
                                    'UPDATE tasks SET "order" = "order" + 1 WHERE parent_id IS ? AND "order" >= ? AND "order" < ? AND id != ?',
                                    (current_parent_id, new_order, old_order, task_id)
                                )

            # If title, content, or tags changed, regenerate hash and embedding
            if regenerate_embedding:
                # Fetch current tags if tags not being updated
                if 'tags' not in validated_kwargs:
                    current_tags_row = conn.execute(
                        "SELECT tags FROM tasks WHERE id = ?",
                        (task_id,)
                    ).fetchone()
                    new_tags = json.loads(current_tags_row[0]) if current_tags_row[0] else []
                else:
                    new_tags = validated_kwargs['tags']

                combined = f"{new_title}\n{new_content}\n{' '.join(new_tags)}"
                new_hash = generate_content_hash(f"{new_title}\n{new_content}")
                update_fields.append("content_hash = ?")
                update_values.append(new_hash)

                # Generate new embedding (use provided model or fall back to sync loading)
                model = embedding_model or self._get_embedding_model_sync()
                embedding = model.encode_single(combined)
                embedding_blob = sqlite_vec.serialize_float32(embedding)

                # Update vector
                conn.execute(
                    "UPDATE task_vectors SET embedding = ? WHERE rowid = ?",
                    (embedding_blob, task_id)
                )

            # Execute update
            if update_fields:
                update_values.append(task_id)
                conn.execute(f"""
                    UPDATE tasks
                    SET {', '.join(update_fields)}
                    WHERE id = ?
                """, update_values)

            # Propagate time_delta to parent tasks (recursive)
            if time_delta > 0:
                self._propagate_time_to_parents(conn, task_id, time_delta)

            # Time session tracking - start/finish sessions on in_progress transitions
            if status_changed and old_status is not None:
                # Start session when entering in_progress
                if new_status == 'in_progress' and old_status != 'in_progress':
                    self._start_time_session(conn, task_id, old_status)
                # Finish session when exiting in_progress (always close, even with 0 time)
                elif old_status == 'in_progress' and new_status != 'in_progress':
                    self._finish_time_session(conn, task_id, time_delta, new_status)

            # Propagate 'completed' status to parent when ALL children are finished
            if status_changed and new_status in TaskStatus.finish_statuses():
                self._propagate_completed_to_parents(conn, task_id)

            # Propagate 'pending' status to parent when ANY child returns to pending
            if status_changed and new_status == 'pending':
                self._propagate_pending_to_parents(conn, task_id)

            conn.commit()

            # FS side-effect: folder rename/archive on root-task status transitions.
            # Predicates: feature on (folder_mgr) + ROOT (parent_id IS NULL) +
            # task has a code (legacy NULL → skip). TaskFolderManager methods are
            # already resilient (catch+return False); the wrapper here is
            # belt-and-suspenders against future contract breaks.
            #
            # Transition matrix:
            #   * → completed                 → rename_on_completed
            #   * → done                      → rename_on_done
            #   completed → in_progress (revert) → revert_on_completed
            #   any other                     → no-op
            task_parent_id = existing[4]
            task_code = existing[5]
            # Aggregate-aware folder positioning: status change of any root
            # task in a shared-code group repositions the folder to match
            # the LEAST advanced status among all roots with that code.
            # This subsumes the old per-transition rename_on_completed /
            # rename_on_done / revert_on_completed hooks — the same logic
            # applies, just driven by the aggregate query rather than the
            # individual transition.
            if (
                status_changed
                and self.folder_mgr is not None
                and task_parent_id is None
                and task_code
            ):
                self._sync_code_folder_position(conn, task_code)

            # FS side-effect: folder rename on code change (root-task only).
            # If the task previously had no code (legacy NULL), create a fresh
            # folder at the new code instead of renaming.
            new_code_value = validated_kwargs.get('code')
            code_changed = (
                'code' in validated_kwargs
                and new_code_value is not None
                and new_code_value != task_code
            )
            if (
                code_changed
                and self.folder_mgr is not None
                and task_parent_id is None
            ):
                # Resolve the FINAL status (post-update) so the new folder
                # lands at the lifecycle position matching the actual state.
                final_status = validated_kwargs.get('status', existing[3])
                try:
                    if task_code:
                        # Shared-code awareness:
                        # 1. If OTHER root tasks still carry old code → leave
                        #    old folder for them.
                        # 2. If new_code already has a folder anywhere → adopt
                        #    it instead of creating a duplicate.
                        # 3. Otherwise, safe to rename old → new.
                        others_with_old_code = conn.execute(
                            "SELECT COUNT(*) FROM tasks "
                            "WHERE parent_id IS NULL AND code = ? AND id != ?",
                            (task_code, task_id),
                        ).fetchone()[0]
                        new_code_folder_exists = (
                            self.folder_mgr._resolve_existing_folder(new_code_value)
                            is not None
                        )
                        if others_with_old_code > 0 or new_code_folder_exists:
                            # Adopt existing new-code folder, leave old folder
                            # in place (orphan handling is a user concern).
                            self.folder_mgr.ensure_folder_for_status(
                                new_code_value, existing[1], task_id, final_status
                            )
                        else:
                            renamed = self.folder_mgr.rename_code(
                                task_code, new_code_value
                            )
                            if not renamed:
                                self.folder_mgr.ensure_folder_for_status(
                                    new_code_value, existing[1], task_id,
                                    final_status,
                                )
                    else:
                        # Legacy NULL → set: no source folder to rename, create
                        # at the position matching current status.
                        self.folder_mgr.ensure_folder_for_status(
                            new_code_value, existing[1], task_id, final_status
                        )

                    # Sync BOTH codes (old still has remaining tasks, new
                    # might need repositioning to match aggregate).
                    if task_code:
                        self._sync_code_folder_position(conn, task_code)
                    self._sync_code_folder_position(conn, new_code_value)
                except Exception as e:
                    logger.warning(
                        "Folder rename_code failed for task %s (%r → %r): %s",
                        task_id, task_code, new_code_value, e, exc_info=True,
                    )

            # FS side-effect: explicit folder (re)initialisation. Triggered
            # by the `init_folder=True` flag. Resolves the FINAL code
            # (after any rename in this call) and FINAL status, then ensures
            # the folder exists at the lifecycle position matching that
            # status. Adopts orphan folders; recreates if previously deleted
            # via the empty-template fast-path. Aggregate sync afterwards
            # respects shared-code peers.
            if (
                init_folder
                and self.folder_mgr is not None
                and task_parent_id is None
            ):
                final_code = (
                    new_code_value
                    if 'code' in validated_kwargs and new_code_value is not None
                    else task_code
                )
                final_status = validated_kwargs.get('status', existing[3])
                if final_code:
                    try:
                        self.folder_mgr.ensure_folder_for_status(
                            final_code, existing[1], task_id, final_status
                        )
                        # skip_empty_delete: an explicit init must not see
                        # the folder it just (re)created get deleted by the
                        # empty-template fast-path in the same call.
                        self._sync_code_folder_position(
                            conn, final_code, skip_empty_delete=True
                        )
                    except Exception as e:
                        logger.warning(
                            "init_folder failed for task %s (%r): %s",
                            task_id, final_code, e, exc_info=True,
                        )

            # Fetch updated task
            result = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE id = ?
            """, (task_id,)).fetchone()

            task = Task.from_db_row(result)

            return {
                "success": True,
                "task": task.to_dict()
            }

        except SecurityError as e:
            conn.rollback()
            raise e
        except sqlite3.IntegrityError as e:
            conn.rollback()
            # `code` is NOT unique any more (post-1.8.2), but the table may
            # still have other constraints (content_hash UNIQUE, etc.).
            # Surface the violation as a generic database constraint error.
            return {
                "success": False,
                "error": "Database constraint violated",
                "message": str(e),
            }
        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to update task: {e}")
        finally:
            conn.close()

    def delete_task(self, task_id: int) -> bool:
        """
        Delete a task by ID.

        Args:
            task_id: Task ID to delete

        Returns:
            True if deleted, False if not found
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to delete task: {e}")

        try:
            # Get task's order and parent_id for shift logic
            cursor = conn.execute(
                'SELECT parent_id, "order" FROM tasks WHERE id = ?',
                (task_id,)
            )
            task_info = cursor.fetchone()

            if not task_info:
                return False

            # Delete from both tables
            conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            conn.execute("DELETE FROM task_vectors WHERE rowid = ?", (task_id,))

            # Shift remaining siblings down to close the gap
            parent_id, deleted_order = task_info
            if deleted_order is not None:
                conn.execute(
                    'UPDATE tasks SET "order" = "order" - 1 WHERE parent_id IS ? AND "order" > ?',
                    (parent_id, deleted_order)
                )

            conn.commit()
            return True

        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to delete task: {e}")
        finally:
            conn.close()

    def delete_tasks_bulk(self, task_ids: List[int]) -> Dict[str, Any]:
        """
        Delete multiple tasks in a single transaction.

        Args:
            task_ids: List of task IDs to delete

        Returns:
            Dict with operation result:
                - success: True if all found tasks deleted, False otherwise
                - deleted_count: Number of tasks deleted
                - deleted_task_ids: List of deleted task IDs
                - message: Success or error message
                - not_found: Optional list of task IDs not found

        Raises:
            SecurityError: If validation fails
            RuntimeError: If database operation fails
        """
        self._ensure_db_initialized_sync()
        # Validate and deduplicate task IDs
        deduplicated_task_ids = validate_bulk_task_ids(task_ids, Config.MAX_BULK_DELETE)

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to delete tasks: {e}")

        try:
            # Check which tasks exist
            placeholders = ','.join('?' * len(deduplicated_task_ids))
            existing_ids_query = f"SELECT id FROM tasks WHERE id IN ({placeholders})"
            existing_rows = conn.execute(existing_ids_query, deduplicated_task_ids).fetchall()
            existing_ids = [row[0] for row in existing_rows]

            # Determine which IDs were not found
            not_found_ids = [task_id for task_id in deduplicated_task_ids if task_id not in existing_ids]

            # If no tasks exist, return early
            if not existing_ids:
                return {
                    "success": False,
                    "deleted_count": 0,
                    "deleted_task_ids": [],
                    "message": f"No tasks found to delete (0 of {len(deduplicated_task_ids)})",
                    "not_found": not_found_ids
                }

            # Delete from both tables in single transaction
            delete_placeholders = ','.join('?' * len(existing_ids))

            conn.execute(
                f"DELETE FROM tasks WHERE id IN ({delete_placeholders})",
                existing_ids
            )

            conn.execute(
                f"DELETE FROM task_vectors WHERE rowid IN ({delete_placeholders})",
                existing_ids
            )

            conn.commit()

            result = {
                "success": True,
                "deleted_count": len(existing_ids),
                "deleted_task_ids": existing_ids,
                "message": f"Successfully deleted {len(existing_ids)} task(s)"
            }

            if not_found_ids:
                result["not_found"] = not_found_ids
                result["message"] += f" ({len(not_found_ids)} not found)"

            return result

        except SecurityError as e:
            conn.rollback()
            raise e
        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to delete tasks in bulk: {e}")
        finally:
            conn.close()

    def get_task_by_id(self, task_id: int) -> Optional[Task]:
        """
        Get a task by ID.

        Args:
            task_id: Task ID to retrieve

        Returns:
            Task object or None if not found
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get task: {e}")

        try:
            result = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE id = ?
            """, (task_id,)).fetchone()

            if result:
                task = Task.from_db_row(result)
                # Attach full status history for single task retrieval
                task.status_history = self._get_status_history(conn, task_id, limit=1000)
                return task
            return None

        except Exception as e:
            raise RuntimeError(f"Failed to get task by ID: {e}")
        finally:
            conn.close()

    # Status buckets for aggregate folder positioning.
    _ACTIVE_STATUSES = ("pending", "in_progress", "draft")
    _REVIEW_STATUSES = ("completed", "tested", "validated")
    _ARCHIVE_STATUSES = ("done",)
    _IGNORED_STATUSES = ("canceled", "stopped")

    def _aggregate_position_for_code(
        self, conn: sqlite3.Connection, code: str
    ) -> Optional[str]:
        """Compute the target folder position for ``code`` from all root tasks.

        Aggregates statuses across every ROOT task with the supplied code
        (excluding canceled/stopped) and returns the LEAST advanced bucket:

        * any pending / in_progress / draft → ``"active"``
        * else any completed / tested / validated → ``"on-review"``
        * else all done → ``"archive"``

        Returns ``None`` when no contributing root task uses the code (folder
        is orphaned and should be left where it is).
        """
        placeholders = ",".join("?" * len(self._IGNORED_STATUSES))
        rows = conn.execute(
            f"SELECT status FROM tasks "
            f"WHERE parent_id IS NULL AND code = ? "
            f"AND status NOT IN ({placeholders})",
            (code, *self._IGNORED_STATUSES),
        ).fetchall()
        if not rows:
            return None
        statuses = {row[0] for row in rows}
        if any(s in self._ACTIVE_STATUSES for s in statuses):
            return "active"
        if any(s in self._REVIEW_STATUSES for s in statuses):
            return "on-review"
        if any(s in self._ARCHIVE_STATUSES for s in statuses):
            return "archive"
        # All statuses fell into the ignored bucket — treat as orphan.
        return None

    def _sync_code_folder_position(
        self,
        conn: sqlite3.Connection,
        code: Optional[str],
        skip_empty_delete: bool = False,
    ) -> None:
        """Reposition the on-disk folder for ``code`` per the aggregate rule.

        Best-effort: never raises; logs and returns silently on any FS error.
        No-op when ``code`` is falsy, when ``folder_mgr`` is disabled, or when
        no contributing root task references the code.

        Empty-template optimisation: when the aggregate moves the folder to
        a non-active position (``on-review`` or ``archive``) AND the folder
        contains only the unmodified rendered template, delete the folder
        outright instead of renaming it. Prevents accumulating empty
        ``-on-review/`` and ``Archive/`` shells for tasks where no work
        product was added.

        ``skip_empty_delete`` suppresses that optimisation — used by the
        ``init_folder`` flow so a just-(re)created folder is not deleted on
        the very next aggregate sync that runs after creation.
        """
        if not code or self.folder_mgr is None:
            return
        try:
            target = self._aggregate_position_for_code(conn, code)
            if target is None:
                return

            if not skip_empty_delete and target in ("on-review", "archive"):
                # Try each task in the code group as a possible "owner" of
                # the rendered template; if any matches, the folder holds
                # nothing user-added.
                rows = conn.execute(
                    "SELECT id, title FROM tasks "
                    "WHERE parent_id IS NULL AND code = ? "
                    "ORDER BY id LIMIT 20",
                    (code,),
                ).fetchall()
                for owner_id, owner_title in rows:
                    if self.folder_mgr.delete_if_empty_template(
                        code, owner_title, owner_id
                    ):
                        return  # deleted; nothing more to do

            self.folder_mgr.sync_folder_position(code, target)
        except Exception as e:
            logger.warning(
                "_sync_code_folder_position failed for code=%r: %s",
                code, e, exc_info=True,
            )

    def get_root_task(self, task_id: int) -> Optional[Task]:
        """Walk parent_id chain to the ROOT task (parent_id IS NULL).

        Returns the input task if it is already a root. Returns None if the
        starting task does not exist or the chain breaks (orphan parent).
        Bounded by max-depth=64 to avoid infinite loops on corrupt cycles.
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to walk to root task: {e}")
        try:
            current_id = task_id
            for _ in range(64):
                row = conn.execute(
                    'SELECT id, parent_id, status, priority, title, content, '
                    'comment, tags, created_at, start_at, finish_at, content_hash, '
                    'estimate, "order", time_spent, parallel, tag_variants, code '
                    'FROM tasks WHERE id = ?',
                    (current_id,),
                ).fetchone()
                if row is None:
                    return None
                if row[1] is None:  # parent_id IS NULL → root
                    return Task.from_db_row(row)
                current_id = row[1]
            # Cycle / max depth reached; treat as not found.
            return None
        finally:
            conn.close()

    def get_task_by_code(self, code: str) -> Optional[Task]:
        """Look up a task by its unique ``code`` field.

        Returns None when no task has the supplied code (e.g. orphan code
        passed to a read-only API). Uses the partial UNIQUE index.
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get task by code: {e}")
        try:
            row = conn.execute(
                'SELECT id, parent_id, status, priority, title, content, '
                'comment, tags, created_at, start_at, finish_at, content_hash, '
                'estimate, "order", time_spent, parallel, tag_variants, code '
                'FROM tasks WHERE code = ?',
                (code,),
            ).fetchone()
            return Task.from_db_row(row) if row else None
        finally:
            conn.close()

    def get_subtask_ids(self, parent_id: int) -> list[int]:
        """
        Get list of subtask IDs for a parent task.

        Args:
            parent_id: Parent task ID

        Returns:
            List of subtask IDs ordered by order ASC, created_at ASC
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get subtask IDs: {e}")

        try:
            results = conn.execute("""
                SELECT id
                FROM tasks
                WHERE parent_id = ?
                ORDER BY "order" ASC NULLS LAST, created_at ASC
            """, (parent_id,)).fetchall()

            return [row[0] for row in results]

        except Exception as e:
            raise RuntimeError(f"Failed to get subtask IDs: {e}")
        finally:
            conn.close()

    def get_next_child(self, parent_id: int) -> Optional[Task]:
        """
        Get the next child task to work on for a given parent.

        Logic (same as get_next_task but scoped to children):
        1. First check: any child with status="in_progress" → return first one
        2. If none in_progress: find last completed child, return first pending child created after it
        3. If no completed: return first pending child by order/created_at

        Args:
            parent_id: Parent task ID

        Returns:
            Task object or None if no suitable child task found
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get next child task: {e}")

        try:
            # First check for in_progress child tasks
            in_progress = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE status = ? AND parent_id = ?
                ORDER BY "order" ASC NULLS LAST, created_at ASC
                LIMIT 1
            """, (TaskStatus.IN_PROGRESS.value, parent_id)).fetchone()

            if in_progress:
                return Task.from_db_row(in_progress)

            # Find last finished child task (completed/tested/validated)
            finish_statuses = TaskStatus.finish_statuses()
            placeholders = ','.join('?' * len(finish_statuses))
            last_finished = conn.execute(f"""
                SELECT created_at
                FROM tasks
                WHERE status IN ({placeholders}) AND parent_id = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (*finish_statuses, parent_id)).fetchone()

            if last_finished:
                # Get first pending child task created after last finished
                next_pending = conn.execute("""
                    SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                    FROM tasks
                    WHERE status = ? AND parent_id = ? AND created_at > ?
                    ORDER BY "order" ASC NULLS LAST, CASE priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 END, created_at ASC
                    LIMIT 1
                """, (TaskStatus.PENDING.value, parent_id, last_finished[0])).fetchone()

                if next_pending:
                    return Task.from_db_row(next_pending)

            # No completed child tasks or no pending after completed, get first pending child
            first_pending = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE status = ? AND parent_id = ?
                ORDER BY "order" ASC NULLS LAST, CASE priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 END, created_at ASC
                LIMIT 1
            """, (TaskStatus.PENDING.value, parent_id)).fetchone()

            if first_pending:
                return Task.from_db_row(first_pending)

            return None

        except Exception as e:
            raise RuntimeError(f"Failed to get next child task: {e}")
        finally:
            conn.close()

    def get_last_task(self) -> Optional[Task]:
        """
        Get the most recently created task.

        Returns:
            Task object or None if no tasks exist
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get last task: {e}")

        try:
            result = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                ORDER BY created_at DESC
                LIMIT 1
            """).fetchone()

            if result:
                return Task.from_db_row(result)
            return None

        except Exception as e:
            raise RuntimeError(f"Failed to get last task: {e}")
        finally:
            conn.close()

    def get_next_task(self) -> Optional[Task]:
        """
        Get the next task to work on.

        Logic:
        1. First check: any tasks with status="in_progress" → return first one
        2. If none in_progress: find last completed task, then return first pending task created after it
        3. If no completed: return first pending task by created_at

        Returns:
            Task object or None if no suitable task found
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get next task: {e}")

        try:
            # First check for in_progress tasks
            in_progress = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE status = ?
                ORDER BY "order" ASC NULLS LAST, created_at ASC
                LIMIT 1
            """, (TaskStatus.IN_PROGRESS.value,)).fetchone()

            if in_progress:
                return Task.from_db_row(in_progress)

            # Find last finished task (completed/tested/validated)
            finish_statuses = TaskStatus.finish_statuses()
            placeholders = ','.join('?' * len(finish_statuses))
            last_finished = conn.execute(f"""
                SELECT created_at
                FROM tasks
                WHERE status IN ({placeholders})
                ORDER BY created_at DESC
                LIMIT 1
            """, finish_statuses).fetchone()

            if last_finished:
                # Get first pending task created after last finished
                next_pending = conn.execute("""
                    SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                    FROM tasks
                    WHERE status = ? AND created_at > ?
                    ORDER BY "order" ASC NULLS LAST, CASE priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 END, created_at ASC
                    LIMIT 1
                """, (TaskStatus.PENDING.value, last_finished[0])).fetchone()

                if next_pending:
                    return Task.from_db_row(next_pending)

            # No completed tasks or no pending after completed, get first pending
            first_pending = conn.execute("""
                SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                FROM tasks
                WHERE status = ?
                ORDER BY "order" ASC NULLS LAST, CASE priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 WHEN 'low' THEN 4 END, created_at ASC
                LIMIT 1
            """, (TaskStatus.PENDING.value,)).fetchone()

            if first_pending:
                return Task.from_db_row(first_pending)

            return None

        except Exception as e:
            raise RuntimeError(f"Failed to get next task: {e}")
        finally:
            conn.close()

    def search_tasks(
        self,
        query: str = None,
        limit: int = 10,
        offset: int = 0,
        status: str = None,
        parent_id: int = None,
        tags: List[str] = None,
        ids: List[int] = None,
        code: str = None,
        embedding_model: Optional[EmbeddingModel] = None,
        use_idf_rerank: bool = True
    ) -> Tuple[List[Task], int]:
        """
        Search tasks using vector similarity or list all with filters.

        Args:
            query: Optional search query for semantic search
            limit: Maximum number of results
            offset: Number of results to skip for pagination
            status: Optional status filter
            parent_id: Optional parent_id filter
            tags: Optional list of tags to filter by (OR logic - matches if ANY tag present)
            ids: Optional list of task IDs to filter by (AND logic with other filters)
            code: Optional exact-match code filter (e.g. ``OLOM-460``). With
                shared codes (post-1.8.2), matches every task carrying that
                exact code.
            embedding_model: Optional pre-loaded embedding model (for async callers, only used if query provided)
            use_idf_rerank: If True, apply IDF-based reranking for vector search results (default: True)

        Returns:
            Tuple of (List of Task objects, total count matching filters)
        """
        self._ensure_db_initialized_sync()
        # Validate parameters
        if limit is not None:
            limit = min(max(1, limit), Config.MAX_MEMORIES_PER_SEARCH)
        else:
            limit = 10

        if offset is not None and (not isinstance(offset, int) or offset < 0):
            raise ValueError("offset must be a non-negative integer")
        if offset and offset > 10000:
            raise ValueError("offset must not exceed 10000")

        if status is not None:
            status = validate_task_status(status)

        if parent_id is not None and not isinstance(parent_id, int):
            raise ValueError("parent_id must be an integer")

        # Validate tags (optional)
        validated_tags = None
        if tags is not None:
            if not isinstance(tags, list):
                raise ValueError("tags must be a list")
            # Sanitize tags using existing sanitize_input
            validated_tags = []
            for tag in tags:
                if isinstance(tag, str) and tag.strip():
                    validated_tags.append(sanitize_input(tag.lower().strip(), 100))
            if not validated_tags:
                validated_tags = None  # Empty list = no filter

        # Validate ids (optional)
        validated_ids = None
        if ids is not None:
            if not isinstance(ids, list):
                raise ValueError("ids must be a list")
            validated_ids = []
            for task_id in ids:
                if not isinstance(task_id, int):
                    raise ValueError("All ids must be integers")
                validated_ids.append(task_id)
            if not validated_ids:
                validated_ids = None  # Empty list = no filter

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to search tasks: {e}")

        try:
            # If query provided, do vector search
            if query:
                query = sanitize_input(query)

                # Generate query embedding
                # Use provided model or fall back to sync loading (only if query provided)
                model = embedding_model or self._get_embedding_model_sync()
                query_embedding = model.encode_single(query)
                query_blob = sqlite_vec.serialize_float32(query_embedding)

                # Build search query
                base_query = """
                    SELECT
                        t.id, t.parent_id, t.status, t.priority, t.title, t.content, t.comment, t.tags, t.created_at, t.start_at, t.finish_at, t.content_hash, t.estimate, t."order", t.time_spent, t.parallel, t.tag_variants, t.code,
                        vec_distance_cosine(v.embedding, ?) as distance
                    FROM tasks t
                    JOIN task_vectors v ON t.id = v.rowid
                """

                params = [query_blob]
                where_clauses = []

                # Add filters
                if status:
                    where_clauses.append("t.status = ?")
                    params.append(status)

                if parent_id is not None:
                    where_clauses.append("t.parent_id = ?")
                    params.append(parent_id)

                # Add tags filter if provided (OR logic - match ANY tag)
                if validated_tags:
                    tag_conditions = " OR ".join(["EXISTS (SELECT 1 FROM json_each(t.tags) WHERE value = ?)" for _ in validated_tags])
                    where_clauses.append(f"({tag_conditions})")
                    for tag in validated_tags:
                        params.append(tag)

                # Add ids filter if provided
                if validated_ids:
                    placeholders = ','.join(['?'] * len(validated_ids))
                    where_clauses.append(f"t.id IN ({placeholders})")
                    params.extend(validated_ids)

                # Add code filter (exact match, AND with other filters)
                if code:
                    where_clauses.append("t.code = ?")
                    params.append(code)

                # Add WHERE clause if filters exist
                if where_clauses:
                    base_query += " WHERE " + " AND ".join(where_clauses)

                # Get total count
                count_query = """
                    SELECT COUNT(DISTINCT t.id)
                    FROM tasks t
                    JOIN task_vectors v ON t.id = v.rowid
                """
                if where_clauses:
                    count_query += " WHERE " + " AND ".join(where_clauses)

                count_params = params[1:] if len(params) > 1 else []
                total_count = conn.execute(count_query, count_params).fetchone()[0]

                # Add ORDER BY, LIMIT, and OFFSET
                base_query += " ORDER BY distance LIMIT ? OFFSET ?"
                params.append(limit)
                params.append(offset)

                results = conn.execute(base_query, params).fetchall()

            else:
                # No query, just list with filters
                base_query = """
                    SELECT id, parent_id, status, priority, title, content, comment, tags, created_at, start_at, finish_at, content_hash, estimate, "order", time_spent, parallel, tag_variants, code
                    FROM tasks
                """

                params = []
                where_clauses = []

                if status:
                    where_clauses.append("status = ?")
                    params.append(status)

                if parent_id is not None:
                    where_clauses.append("parent_id = ?")
                    params.append(parent_id)

                # Add tags filter if provided (OR logic - match ANY tag)
                if validated_tags:
                    tag_conditions = " OR ".join(["EXISTS (SELECT 1 FROM json_each(tags) WHERE value = ?)" for _ in validated_tags])
                    where_clauses.append(f"({tag_conditions})")
                    for tag in validated_tags:
                        params.append(tag)

                # Add ids filter if provided
                if validated_ids:
                    placeholders = ','.join(['?'] * len(validated_ids))
                    where_clauses.append(f"id IN ({placeholders})")
                    params.extend(validated_ids)

                # Add code filter (exact match, AND with other filters)
                if code:
                    where_clauses.append("code = ?")
                    params.append(code)

                if where_clauses:
                    base_query += " WHERE " + " AND ".join(where_clauses)

                # Get total count
                count_query = "SELECT COUNT(*) FROM tasks"
                if where_clauses:
                    count_query += " WHERE " + " AND ".join(where_clauses)

                total_count = conn.execute(count_query, params).fetchone()[0]

                # Add ORDER BY, LIMIT, and OFFSET
                base_query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
                params.append(limit)
                params.append(offset)

                results = conn.execute(base_query, params).fetchall()

            # Format results
            tasks = []

            if query and use_idf_rerank:
                from .normalization import TagNormalizer
                tag_weights = self.get_tag_weights()
                normalizer = TagNormalizer(None)
                scored_results = []
                for row in results:
                    task_row = row[:-1]
                    distance = row[-1]
                    task = Task.from_db_row(task_row)
                    tag_boost = 1.0
                    if task.tags:
                        for tag in task.tags:
                            classification = normalizer.classify_tag(tag)
                            tag_boost += classification['boost'] * 0.1
                            if tag in tag_weights:
                                tag_boost += tag_weights[tag] * 0.05
                    if task.tag_variants:
                        for variant in task.tag_variants:
                            tag_boost += 0.02
                    adjusted_score = distance / tag_boost
                    scored_results.append((adjusted_score, task))
                scored_results.sort(key=lambda x: x[0])
                tasks = [task for _, task in scored_results]
            else:
                for row in results:
                    task_row = row[:-1] if query else row
                    tasks.append(Task.from_db_row(task_row))

            return (tasks, total_count)

        except SecurityError as e:
            raise e
        except Exception as e:
            raise RuntimeError(f"Failed to search tasks: {e}")
        finally:
            conn.close()

    def get_all_tags(self) -> List[str]:
        """
        Get all unique tags across all tasks.

        Returns:
            List[str]: Sorted list of unique tags
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get tags: {e}")

        try:
            # Get all non-null tags from database
            results = conn.execute("""
                SELECT tags
                FROM tasks
                WHERE tags IS NOT NULL AND tags != '[]'
            """).fetchall()

            # Parse JSON arrays and collect unique tags
            unique_tags = set()
            for row in results:
                if row[0]:
                    try:
                        tags_list = json.loads(row[0])
                        if isinstance(tags_list, list):
                            unique_tags.update(tags_list)
                    except (json.JSONDecodeError, TypeError):
                        continue

            # Return sorted list
            return sorted(list(unique_tags))

        except Exception as e:
            raise RuntimeError(f"Failed to get unique tags: {e}")
        finally:
            conn.close()

    def get_all_tags_with_counts(self) -> Dict[str, int]:
        """
        Get all unique tags with their usage counts.

        Returns:
            Dict[str, int]: Mapping of tag -> count (number of tasks using this tag)
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get tags: {e}")

        try:
            results = conn.execute("""
                SELECT tags
                FROM tasks
                WHERE tags IS NOT NULL AND tags != '[]'
            """).fetchall()

            tag_counts: Dict[str, int] = {}
            for row in results:
                if row[0]:
                    try:
                        tags_list = json.loads(row[0])
                        if isinstance(tags_list, list):
                            for tag in tags_list:
                                if tag:
                                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
                    except (json.JSONDecodeError, TypeError):
                        continue

            return tag_counts

        except Exception as e:
            raise RuntimeError(f"Failed to get tag counts: {e}")
        finally:
            conn.close()

    def get_tag_frequencies(self) -> Dict[str, Dict[str, Any]]:
        """
        Get tag frequencies with IDF weights for search ranking.

        Returns:
            Dict[str, Dict]: Mapping of tag -> {count, frequency, idf_weight}
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get tag frequencies: {e}")

        try:
            total_tasks = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]

            if total_tasks == 0:
                return {}

            results = conn.execute("""
                SELECT tags
                FROM tasks
                WHERE tags IS NOT NULL AND tags != '[]'
            """).fetchall()

            tag_counts: Dict[str, int] = {}
            for row in results:
                if row[0]:
                    try:
                        tags_list = json.loads(row[0])
                        if isinstance(tags_list, list):
                            for tag in tags_list:
                                if tag:
                                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
                    except (json.JSONDecodeError, TypeError):
                        continue

            tag_frequencies: Dict[str, Dict[str, Any]] = {}
            for tag, count in tag_counts.items():
                frequency = count / total_tasks
                idf_weight = 1.0 / math.log(1 + count)
                tag_frequencies[tag] = {
                    "count": count,
                    "frequency": round(frequency, 4),
                    "idf_weight": round(idf_weight, 4)
                }

            return tag_frequencies

        except Exception as e:
            raise RuntimeError(f"Failed to get tag frequencies: {e}")
        finally:
            conn.close()

    def get_tag_weights(self) -> Dict[str, float]:
        """
        Get IDF weights for all tags (simplified for ranking).

        Returns:
            Dict[str, float]: Mapping of tag -> idf_weight
        """
        frequencies = self.get_tag_frequencies()
        return {tag: data["idf_weight"] for tag, data in frequencies.items()}

    # =========================================================================
    # Canonical Tag Management
    # =========================================================================

    def get_canonical_mappings(self) -> Dict[str, str]:
        """
        Get all canonical tag mappings from database.

        Returns:
            Dict[str, str]: Mapping of variant_tag -> canonical_tag
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get canonical mappings: {e}")

        try:
            results = conn.execute("""
                SELECT variant_tag, canonical_tag
                FROM canonical_tags
            """).fetchall()

            return {row[0]: row[1] for row in results}

        except Exception as e:
            raise RuntimeError(f"Failed to get canonical mappings: {e}")
        finally:
            conn.close()

    def add_canonical_mapping(self, canonical_tag: str, variant_tag: str) -> Dict[str, Any]:
        """
        Add a canonical tag mapping.

        Args:
            canonical_tag: The canonical (preferred) tag
            variant_tag: The variant tag to map to canonical

        Returns:
            Dict with success status and mapping info
        """
        canonical_tag = canonical_tag.lower().strip()
        variant_tag = variant_tag.lower().strip()

        if not canonical_tag or not variant_tag:
            return {
                "success": False,
                "error": "Tags cannot be empty"
            }

        if canonical_tag == variant_tag:
            return {
                "success": False,
                "error": "Canonical and variant tags cannot be the same"
            }

        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to add canonical mapping: {e}")

        try:
            now = datetime.now(ZoneInfo(self.timezone)).isoformat()

            existing = conn.execute("""
                SELECT canonical_tag FROM canonical_tags WHERE variant_tag = ?
            """, (variant_tag,)).fetchone()

            if existing:
                return {
                    "success": False,
                    "error": f"Variant '{variant_tag}' already mapped to '{existing[0]}'"
                }

            conn.execute("""
                INSERT INTO canonical_tags (canonical_tag, variant_tag, created_at)
                VALUES (?, ?, ?)
            """, (canonical_tag, variant_tag, now))

            conn.commit()

            return {
                "success": True,
                "canonical_tag": canonical_tag,
                "variant_tag": variant_tag,
                "message": f"Added mapping: '{variant_tag}' → '{canonical_tag}'"
            }

        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to add canonical mapping: {e}")
        finally:
            conn.close()

    def remove_canonical_mapping(self, variant_tag: str) -> Dict[str, Any]:
        """
        Remove a canonical tag mapping.

        Args:
            variant_tag: The variant tag to remove from mappings

        Returns:
            Dict with success status
        """
        variant_tag = variant_tag.lower().strip()

        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to remove canonical mapping: {e}")

        try:
            cursor = conn.execute("""
                DELETE FROM canonical_tags WHERE variant_tag = ?
            """, (variant_tag,))

            conn.commit()

            if cursor.rowcount == 0:
                return {
                    "success": False,
                    "error": f"Mapping for variant '{variant_tag}' not found"
                }

            return {
                "success": True,
                "variant_tag": variant_tag,
                "message": f"Removed mapping for '{variant_tag}'"
            }

        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to remove canonical mapping: {e}")
        finally:
            conn.close()

    def get_all_canonical_tags(self) -> List[Dict[str, Any]]:
        """
        Get all canonical tags with their variants grouped.

        Returns:
            List of dicts with canonical_tag and variants list
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get canonical tags: {e}")

        try:
            results = conn.execute("""
                SELECT canonical_tag, variant_tag, created_at
                FROM canonical_tags
                ORDER BY canonical_tag, variant_tag
            """).fetchall()

            grouped: Dict[str, Dict[str, Any]] = {}
            for row in results:
                canonical, variant, created_at = row
                if canonical not in grouped:
                    grouped[canonical] = {
                        "canonical_tag": canonical,
                        "variants": []
                    }
                grouped[canonical]["variants"].append(variant)

            return list(grouped.values())

        except Exception as e:
            raise RuntimeError(f"Failed to get canonical tags: {e}")
        finally:
            conn.close()

    def migrate_tags(self, mapping: Dict[str, str], embedding_model: Optional[EmbeddingModel] = None) -> Dict[str, Any]:
        """
        Migrate tags according to a mapping (variant -> canonical).
        
        Stores original tags in tag_variants for alias scent / reranking.

        Args:
            mapping: Dict mapping old_tag -> new_tag
            embedding_model: Optional pre-loaded embedding model (for async callers)

        Returns:
            Dict with migration results:
                - success: True if migration completed
                - tasks_updated: Number of tasks modified
                - tags_replaced: Number of individual tag replacements
                - mapping: The mapping used
        """
        if not mapping:
            return {
                "success": True,
                "tasks_updated": 0,
                "tags_replaced": 0,
                "mapping": {},
                "message": "No mapping provided, nothing to migrate"
            }

        self._ensure_db_initialized_sync()
        model = embedding_model or self._get_embedding_model_sync()

        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to migrate tags: {e}")

        try:
            results = conn.execute("""
                SELECT id, tags, tag_variants
                FROM tasks
                WHERE tags IS NOT NULL AND tags != '[]'
            """).fetchall()

            tasks_updated = 0
            tags_replaced = 0
            tasks_to_update = []

            for row in results:
                task_id = row[0]
                try:
                    tags_list = json.loads(row[1]) if row[1] else []
                except (json.JSONDecodeError, TypeError):
                    tags_list = []

                try:
                    existing_variants = json.loads(row[2]) if row[2] else []
                except (json.JSONDecodeError, TypeError):
                    existing_variants = []

                if not isinstance(tags_list, list):
                    continue

                new_tags = []
                new_variants = list(existing_variants)
                changed = False

                for tag in tags_list:
                    if tag in mapping:
                        new_tag = mapping[tag]
                        if new_tag not in new_tags:
                            new_tags.append(new_tag)
                        if tag not in new_variants:
                            new_variants.append(tag)
                        tags_replaced += 1
                        changed = True
                    elif tag not in new_tags:
                        new_tags.append(tag)

                if changed:
                    tasks_to_update.append((task_id, new_tags, new_variants))

            for task_id, new_tags, new_variants in tasks_to_update:
                cursor = conn.execute(
                    "SELECT title, content FROM tasks WHERE id = ?",
                    (task_id,)
                )
                task_row = cursor.fetchone()
                if task_row:
                    title, content = task_row
                    combined = f"{title}\n{content}\n{' '.join(new_tags)}"
                    embedding = model.encode_single(combined)
                    embedding_blob = sqlite_vec.serialize_float32(embedding)

                    conn.execute(
                        "UPDATE tasks SET tags = ?, tag_variants = ? WHERE id = ?",
                        (json.dumps(new_tags), json.dumps(new_variants), task_id)
                    )
                    conn.execute(
                        "UPDATE task_vectors SET embedding = ? WHERE rowid = ?",
                        (embedding_blob, task_id)
                    )
                    tasks_updated += 1

            conn.commit()

            return {
                "success": True,
                "tasks_updated": tasks_updated,
                "tags_replaced": tags_replaced,
                "mapping": mapping,
                "message": f"Migrated {tags_replaced} tags in {tasks_updated} tasks"
            }

        except Exception as e:
            conn.rollback()
            raise RuntimeError(f"Failed to migrate tags: {e}")
        finally:
            conn.close()

    def get_stats(
        self,
        created_after: str = None,
        created_before: str = None,
        start_after: str = None,
        start_before: str = None,
        finish_after: str = None,
        finish_before: str = None,
        status: str = None,
        priority: str = None,
        tags: List[str] = None,
        parent_id: int = None
    ) -> TaskStats:
        """
        Get task statistics with optional filters.

        Args:
            created_after: Filter tasks created after this timestamp (ISO 8601)
            created_before: Filter tasks created before this timestamp (ISO 8601)
            start_after: Filter tasks started after this timestamp (ISO 8601)
            start_before: Filter tasks started before this timestamp (ISO 8601)
            finish_after: Filter tasks finished after this timestamp (ISO 8601)
            finish_before: Filter tasks finished before this timestamp (ISO 8601)
            status: Filter by status (pending, in_progress, completed, tested, validated, stopped)
            priority: Filter by priority (low, medium, high, critical)
            tags: Filter by tags (OR logic - matches ANY tag in list)
            parent_id: Filter by parent_id (None for root tasks)

        Returns:
            TaskStats object with comprehensive statistics
        """
        self._ensure_db_initialized_sync()
        try:
            conn = self._get_connection()
        except Exception as e:
            raise RuntimeError(f"Failed to get stats: {e}")

        try:
            # Build WHERE clause dynamically
            where_clauses = []
            params = []

            # Date filters
            if created_after:
                where_clauses.append("created_at >= ?")
                params.append(created_after)
            if created_before:
                where_clauses.append("created_at <= ?")
                params.append(created_before)
            if start_after:
                where_clauses.append("start_at >= ?")
                params.append(start_after)
            if start_before:
                where_clauses.append("start_at <= ?")
                params.append(start_before)
            if finish_after:
                where_clauses.append("finish_at >= ?")
                params.append(finish_after)
            if finish_before:
                where_clauses.append("finish_at <= ?")
                params.append(finish_before)

            # Status filter
            if status:
                where_clauses.append("status = ?")
                params.append(status)

            # Priority filter
            if priority:
                where_clauses.append("priority = ?")
                params.append(priority)

            # Parent_id filter
            if parent_id is not None:
                if parent_id == 0:
                    # Filter for root tasks (parent_id IS NULL)
                    where_clauses.append("parent_id IS NULL")
                else:
                    where_clauses.append("parent_id = ?")
                    params.append(parent_id)

            # Tags filter (OR logic)
            if tags:
                tag_placeholders = ",".join(["?"] * len(tags))
                where_clauses.append(f"""
                    id IN (
                        SELECT t.id FROM tasks t, JSON_EACH(t.tags) AS tag
                        WHERE tag.value IN ({tag_placeholders})
                    )
                """)
                params.extend(tags)

            # Build final WHERE clause
            where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"

            # Total tasks
            total_tasks = conn.execute(
                f"SELECT COUNT(*) FROM tasks WHERE {where_sql}",
                params
            ).fetchone()[0]

            # Count by status
            status_counts = dict(conn.execute(
                f"""
                SELECT status, COUNT(*)
                FROM tasks
                WHERE {where_sql}
                GROUP BY status
                """,
                params
            ).fetchall())

            # Count by priority
            priority_counts = dict(conn.execute(
                f"""
                SELECT priority, COUNT(*)
                FROM tasks
                WHERE {where_sql}
                GROUP BY priority
                """,
                params
            ).fetchall())

            # Count tasks with subtasks (tasks that are parents)
            with_subtasks = conn.execute(
                f"""
                SELECT COUNT(DISTINCT parent_id)
                FROM tasks
                WHERE parent_id IS NOT NULL AND {where_sql}
                """,
                params
            ).fetchone()[0]

            # Root task count (parent_id IS NULL)
            root_task_count = conn.execute(
                f"""
                SELECT COUNT(*)
                FROM tasks
                WHERE parent_id IS NULL AND {where_sql}
                """,
                params
            ).fetchone()[0]

            # Parent task count (tasks that have children)
            parent_task_count = conn.execute(
                f"""
                SELECT COUNT(DISTINCT parent_id)
                FROM tasks
                WHERE parent_id IS NOT NULL AND {where_sql}
                """,
                params
            ).fetchone()[0]

            # Estimate metrics
            estimate_row = conn.execute(
                f"""
                SELECT
                    SUM(estimate),
                    AVG(estimate)
                FROM tasks
                WHERE estimate IS NOT NULL AND {where_sql}
                """,
                params
            ).fetchone()
            total_estimate = estimate_row[0] or 0.0
            avg_estimate = estimate_row[1] or 0.0

            # Time spent metrics - fetch all time_spent values for proper HH.MM aggregation
            time_spent_rows = conn.execute(
                f"""
                SELECT time_spent
                FROM tasks
                WHERE time_spent > 0 AND {where_sql}
                    AND id NOT IN (SELECT DISTINCT parent_id FROM tasks WHERE parent_id IS NOT NULL)
                """,
                params
            ).fetchall()

            # Convert HH.MM to minutes, sum, then convert back
            if time_spent_rows:
                time_minutes = [hhmm_to_minutes(row[0]) for row in time_spent_rows if row[0]]
                total_minutes = sum(time_minutes)
                avg_minutes = total_minutes / len(time_minutes) if time_minutes else 0
                total_time_spent = minutes_to_hhmm(total_minutes)
                avg_time_spent = minutes_to_hhmm(int(avg_minutes))
            else:
                total_time_spent = 0.0
                avg_time_spent = 0.0

            # Overdue count - fetch tasks for overdue calculation (compare in minutes for HH.MM format)
            overdue_rows = conn.execute(
                f"""
                SELECT time_spent, estimate
                FROM tasks
                WHERE time_spent > 0
                    AND estimate IS NOT NULL
                    AND estimate > 0
                    AND {where_sql}
                    AND id NOT IN (SELECT DISTINCT parent_id FROM tasks WHERE parent_id IS NOT NULL)
                """,
                params
            ).fetchall()

            # Count overdue: time_spent (HH.MM) > estimate (hours) - convert both to minutes
            overdue_count = 0
            for time_spent_val, estimate_val in overdue_rows:
                time_minutes = hhmm_to_minutes(time_spent_val)
                estimate_minutes = int(estimate_val * 60)  # estimate is in decimal hours
                if time_minutes > estimate_minutes:
                    overdue_count += 1

            # Estimate accuracy calculation
            accuracy_rows = conn.execute(
                f"""
                SELECT estimate, time_spent
                FROM tasks
                WHERE estimate IS NOT NULL
                    AND time_spent > 0
                    AND {where_sql}
                    AND id NOT IN (SELECT DISTINCT parent_id FROM tasks WHERE parent_id IS NOT NULL)
                """,
                params
            ).fetchall()

            estimate_accuracy = 0.0
            if accuracy_rows:
                deviations = []
                for estimate, time_spent in accuracy_rows:
                    time_minutes = hhmm_to_minutes(time_spent)
                    estimate_minutes = int(estimate * 60)  # estimate is in decimal hours
                    if estimate_minutes > 0:
                        deviation_pct = abs(time_minutes - estimate_minutes) / estimate_minutes * 100
                        deviations.append(deviation_pct)
                avg_deviation = sum(deviations) / len(deviations)
                estimate_accuracy = 100 - avg_deviation

            # Tag usage
            tag_usage = {}
            tags_rows = conn.execute(
                f"""
                SELECT tags
                FROM tasks
                WHERE tags IS NOT NULL
                    AND tags != '[]'
                    AND {where_sql}
                """,
                params
            ).fetchall()

            for (tags_json,) in tags_rows:
                try:
                    task_tags = json.loads(tags_json)
                    if isinstance(task_tags, list):
                        for tag in task_tags:
                            tag_usage[tag] = tag_usage.get(tag, 0) + 1
                except (json.JSONDecodeError, TypeError):
                    continue

            stats = TaskStats(
                total_tasks=total_tasks,
                by_status=status_counts,
                pending_count=status_counts.get(TaskStatus.PENDING.value, 0),
                in_progress_count=status_counts.get(TaskStatus.IN_PROGRESS.value, 0),
                completed_count=status_counts.get(TaskStatus.COMPLETED.value, 0),
                tested_count=status_counts.get(TaskStatus.TESTED.value, 0),
                validated_count=status_counts.get(TaskStatus.VALIDATED.value, 0),
                stopped_count=status_counts.get(TaskStatus.STOPPED.value, 0),
                canceled_count=status_counts.get(TaskStatus.CANCELED.value, 0),
                draft_count=status_counts.get(TaskStatus.DRAFT.value, 0),
                with_subtasks=with_subtasks,
                by_priority=priority_counts,
                root_task_count=root_task_count,
                parent_task_count=parent_task_count,
                total_estimate=total_estimate,
                total_time_spent=total_time_spent,
                avg_estimate=avg_estimate,
                avg_time_spent=avg_time_spent,
                overdue_count=overdue_count,
                estimate_accuracy=estimate_accuracy,
                tag_usage=tag_usage
            )

            return stats

        except Exception as e:
            raise RuntimeError(f"Failed to get statistics: {e}")
        finally:
            conn.close()
