"""afac — full-stack agentic framework.

Name reservation. Active development; first usable release TBD.
"""

__version__ = "0.0.0"
__all__ = ["__version__"]
