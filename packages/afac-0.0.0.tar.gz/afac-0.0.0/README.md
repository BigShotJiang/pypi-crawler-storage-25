# afac

> Full-stack agentic framework — declarative agents, MCP-native, cross-platform.

This is a name reservation. The framework is in active development; the first public release will replace this placeholder.

## what it will be

afac lets you author an agent from a single declarative blueprint — a `*.agent.md` file (or folder) — and run it end to end:

- **Runtime** — HTTP / WebSocket / MCP / SSE transports from one config
- **Plugins** — extension model for tools, infra providers, and deploy targets
- **Tracing** — OpenTelemetry, plug-in your collector
- **UI** — cross-platform Electron shell that reads the same blueprint
- **Deploy** — Dockerfile, Compose, k8s, Helm artifacts generated from the blueprint

## status

| field            | value                              |
|------------------|------------------------------------|
| version          | `0.0.0` — name reservation         |
| first release    | TBD                                |
| python           | `>=3.11`                           |
| license          | MIT                                |

## not yet installable

`pip install afac` will resolve, but the package currently exposes nothing functional. Watch this page for the first usable release.
