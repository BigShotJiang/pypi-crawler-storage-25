# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import time
from dataclasses import dataclass, field
from typing import Mapping, TypeAlias

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


@dataclass(slots=True, frozen=True)
class MetricEvent:
    """
    Class of data put into the metric event queue for processing.
    """

    metric_name: str
    value: float
    scale: str
    step: int
    labels: Mapping[str, str]
    timestamp: int = field(default_factory=time.time_ns)  # Unix epoch nanoseconds; use / 1e9 for seconds
    unordered: bool = False


@dataclass(slots=True, frozen=True)
class CompoundMetricEvent:
    """
    Metric event with a two-level (major, minor) step for compound series.
    """

    metric_name: str
    value: float
    scale: str
    environment_id: str
    episode: int | None
    major_step: int
    minor_step: int
    labels: Mapping[str, str]
    timestamp: int = field(default_factory=time.time_ns)  # Unix epoch nanoseconds; use / 1e9 for seconds
    unordered: bool = False


AnyMetricEvent: TypeAlias = MetricEvent | CompoundMetricEvent
