# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from loguru import logger

from metrana.utils import logging as metrana_logging

try:
    import av  # type: ignore[import-not-found]

    _AV_IMPORT_ERROR: ImportError | None = None
except ImportError as e:
    av = None  # type: ignore[assignment]
    _AV_IMPORT_ERROR = e

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

_PYAV_INSTALL_HINT = "PyAV is required for rendering. Install the rendering extra with: pip install metrana[rendering]"

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class Encoder:
    """
    Per-(env_id, episode) H.264 encoder backed by PyAV.

    Owns a single open output container and video stream. Frames must be uint8 numpy arrays
    of shape (H, W, 3) for RGB, (H, W, 4) for RGBA (alpha is dropped — H.264 with yuv420p
    has no alpha channel), or (H, W) / (H, W, 1) for grayscale. Four-channel frames are
    assumed to be in RGBA layout; other 4-channel layouts (BGRA, ARGB, ...) are not
    auto-detected and will produce wrong colours. Frame dimensions are locked at the first
    frame; subsequent frames must match. FPS is fixed at construction.

    Not thread-safe — intended to be owned and driven by RenderingDispatcher's single
    consumer thread.
    """

    _PIXEL_FORMAT = "yuv420p"
    _CODEC = "libx264"

    def __init__(
        self,
        output_path: Path,
        fps: int,
        env_id: str | None,
        episode: int,
        rl_step: int,
    ) -> None:
        """
        Open the output container and video stream.

        Args:
            output_path: Path to write the .mp4 file to. Parent directory will be created.
            fps: Frames per second to encode at.
            env_id: Environment identifier this encoder is for. Stored for routing.
            episode: Episode index this encoder is for. Stored for boundary detection.
            rl_step: RL step at which this encoder was opened. Recorded as the start of
                the rl_step range for this episode's video.

        Raises:
            ImportError: If PyAV is not installed.
        """

        if av is None:
            raise ImportError(_PYAV_INSTALL_HINT) from _AV_IMPORT_ERROR

        self._fps = fps
        self._env_id = env_id
        self._episode = episode
        self._rl_step_start = rl_step
        self._rl_step_end = rl_step
        self._frame_count = 0
        self._width: int | None = None
        self._height: int | None = None
        self._channels: int | None = None
        self._closed = False

        self._output_path = output_path
        self._output_path.parent.mkdir(parents=True, exist_ok=True)

        self._container: Any = av.open(str(self._output_path), mode="w")
        self._stream: Any = self._container.add_stream(self._CODEC, rate=self._fps)
        self._stream.pix_fmt = self._PIXEL_FORMAT

    @property
    def env_id(self) -> str | None:
        """Environment identifier this encoder is encoding for."""

        return self._env_id

    @property
    def episode(self) -> int:
        """Episode index this encoder is encoding for."""

        return self._episode

    @property
    def output_path(self) -> Path:
        """Filesystem path of the output .mp4."""

        return self._output_path

    @property
    def rl_step_start(self) -> int:
        """RL step at which this encoder was opened."""

        return self._rl_step_start

    @property
    def rl_step_end(self) -> int:
        """RL step of the most recently written frame."""

        return self._rl_step_end

    @property
    def frame_count(self) -> int:
        """Number of frames written to this encoder so far."""

        return self._frame_count

    def _initialise_dimensions(self, frame: np.ndarray) -> None:
        """
        Lock the frame dimensions and colour mode based on the first frame, and finish
        configuring the video stream now that we know the frame size.

        Args:
            frame: First frame to be written. Used to derive width, height, and colour mode.

        Raises:
            ValueError: If the frame's shape is not (H, W), (H, W, 1), (H, W, 3), or
                (H, W, 4), or the dtype is not uint8.
        """

        if frame.dtype != np.uint8:
            raise ValueError(f"Rendering frame must be uint8, got {frame.dtype}.")

        if frame.ndim == 2:
            channels = 1
            height, width = frame.shape
        elif frame.ndim == 3 and frame.shape[2] in (1, 3, 4):
            channels = int(frame.shape[2])
            height, width, _ = frame.shape
        else:
            raise ValueError(
                f"Rendering frame must have shape (H, W), (H, W, 1), (H, W, 3), or (H, W, 4); got {frame.shape}."
            )

        if channels == 4:
            metrana_logging.warn_once(
                "Rendering received a 4-channel frame; assuming RGBA layout and dropping the alpha channel. "
                "Other 4-channel layouts (BGRA, ARGB, ...) are not auto-detected — pre-convert to RGB or RGBA "
                "if your frames are in a different layout.",
                key="rendering_assuming_rgba",
            )

        # libx264 with yuv420p requires even dimensions.
        if width % 2 != 0 or height % 2 != 0:
            raise ValueError(f"Rendering frame dimensions must be even for H.264 with yuv420p; got {width}x{height}.")

        self._width = width
        self._height = height
        self._channels = channels
        self._stream.width = width
        self._stream.height = height

    def _validate_frame(self, frame: np.ndarray) -> None:
        """
        Validate that a subsequent frame matches the dimensions and colour mode locked
        in at the first frame.

        Args:
            frame: Frame to validate.

        Raises:
            ValueError: If the frame does not match the locked dimensions or colour mode.
        """

        if frame.dtype != np.uint8:
            raise ValueError(f"Rendering frame must be uint8, got {frame.dtype}.")

        if self._channels == 1:
            if frame.ndim == 2:
                height, width = frame.shape
            elif frame.ndim == 3 and frame.shape[2] == 1:
                height, width, _ = frame.shape
            else:
                raise ValueError(f"First frame was grayscale but subsequent frame has shape {frame.shape}.")
        elif self._channels == 3:
            if frame.ndim == 3 and frame.shape[2] == 3:
                height, width, _ = frame.shape
            else:
                raise ValueError(f"First frame was RGB but subsequent frame has shape {frame.shape}.")
        else:
            if frame.ndim == 3 and frame.shape[2] == 4:
                height, width, _ = frame.shape
            else:
                raise ValueError(f"First frame was RGBA but subsequent frame has shape {frame.shape}.")

        if width != self._width or height != self._height:
            raise ValueError(
                f"Rendering frame size changed from {self._width}x{self._height} to {width}x{height}; "
                f"frame size is locked per encoder."
            )

    def _to_av_frame(self, frame: np.ndarray) -> Any:
        """
        Convert a numpy frame into an av.VideoFrame in the layout PyAV expects for the
        configured colour mode.

        Args:
            frame: Validated uint8 numpy array.

        Returns:
            av.VideoFrame ready to be encoded.
        """

        if self._channels == 1:
            if frame.ndim == 3:
                frame = frame[:, :, 0]
            return av.VideoFrame.from_ndarray(frame, format="gray")

        if self._channels == 4:
            frame = frame[:, :, :3]

        return av.VideoFrame.from_ndarray(np.ascontiguousarray(frame), format="rgb24")

    def write_frame(self, frame: np.ndarray, rl_step: int) -> None:
        """
        Encode a single frame and write the resulting packets to the output container.

        Args:
            frame: uint8 numpy array of shape (H, W, 3) for RGB, (H, W, 4) for RGBA
                (alpha dropped), or (H, W) / (H, W, 1) for grayscale.
            rl_step: RL step at which this frame was logged. Tracked for the rl_step
                range associated with the episode video.

        Raises:
            RuntimeError: If the encoder has already been closed.
            ValueError: If the frame's shape, dtype, or dimensions are invalid.
        """

        if self._closed:
            raise RuntimeError("Encoder has been closed and cannot accept new frames.")

        if self._width is None:
            self._initialise_dimensions(frame)
        else:
            self._validate_frame(frame)

        av_frame = self._to_av_frame(frame)

        for packet in self._stream.encode(av_frame):
            self._container.mux(packet)

        self._frame_count += 1
        self._rl_step_end = rl_step

    def close(self) -> None:
        """
        Flush the encoder, write the trailer, and close the output container.

        Idempotent. Safe to call even if no frames were ever written (the resulting file
        will be removed in that case to avoid leaving a zero-length artifact).
        """

        if self._closed:
            return

        self._closed = True

        try:
            if self._width is not None:
                for packet in self._stream.encode():
                    self._container.mux(packet)
        finally:
            self._container.close()

        if self._frame_count == 0:
            try:
                self._output_path.unlink(missing_ok=True)
            except OSError as e:
                logger.warning(f"Failed to remove empty rendering file {self._output_path}: {e}")
