# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import threading
from typing import Mapping

from metrana.utils.exceptions import MetranaMetricStepError

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


class MetricStepCounter:

    def __init__(self) -> None:
        """
        Initialize the metric step counter.
        """

        self._lock = threading.Lock()

        # Tuple keys avoid the per-call f-string + sorted(labels.items()) work that
        # f-string keys would impose on every log call.
        self.steps: dict[tuple, int] = {}  # Track last step per series; missing key = never used
        self.manual_steps: set[tuple] = set()  # Track which series use manual steps
        self.auto_steps: set[tuple] = set()  # Track which series use auto steps

    def get_step(self, metric_name: str, scale: str, labels: Mapping[str, str], step: int | None = None) -> int:
        """
        Get the next step for a given metric, scale, and labels.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.
            labels: The labels of the metric.
            step: The step to use. If None, the next step will be used.

        Returns:
            The next step for the given metric, scale, and labels.

        Raises:
            MetranaMetricStepError: If a manual step is not strictly greater than
                the last step, or if manual and auto-increment steps are mixed for
                the same series.
        """

        with self._lock:
            labels_key = tuple(sorted(labels.items())) if labels else ()
            key = (metric_name, scale, labels_key)

            if step is not None:
                if key in self.auto_steps:
                    raise MetranaMetricStepError(
                        f"Metric steps can either be manually set or automatically incremented. "
                        f"Got conflicting values for metric: {metric_name}."
                    )

                # Enforce monotonicity: step must be strictly greater than last step (if any)
                if key in self.steps and step <= self.steps[key]:
                    raise MetranaMetricStepError(
                        f"Steps must be monotonically increasing. Got step: {step} for metric: {metric_name}, "
                        f"scale: {scale}, labels: {labels}. Last step was: {self.steps[key]}"
                    )

                self.manual_steps.add(key)
                self.steps[key] = step

            else:
                if key in self.manual_steps:
                    raise MetranaMetricStepError(
                        f"Metric steps can either be manually set or automatically incremented. "
                        f"Got conflicting values for metric: {metric_name}."
                    )

                self.auto_steps.add(key)
                step = self.steps.get(key, 0)  # Default to 0 for new series
                self.steps[key] = step + 1

            return step


class CompoundStepCounter:

    def __init__(self) -> None:
        """
        Initialize the compound step counter.
        """

        self._lock = threading.Lock()
        # Per series: (last_major_step, last_minor_step). Tuple keys avoid the
        # per-call f-string + sorted(labels.items()) work.
        self._state: dict[tuple, tuple[int, int]] = {}
        self._manual_minor: set[tuple] = set()
        self._auto_minor: set[tuple] = set()

    def get_step(
        self,
        metric_name: str,
        scale: str,
        environment_id: str,
        episode: int | None,
        labels: Mapping[str, str],
        major_step: int,
        minor_step: int | None = None,
    ) -> int:
        """
        Get the minor step for a compound RL data point.

        Major step is always provided by the caller (maps directly to the RL step).
        Minor step is auto-tracked per series and increments monotonically across all
        major steps, but can be overridden by the caller.

        Args:
            metric_name: The name of the metric.
            scale: The scale of the metric.
            environment_id: The environment identifier.
            episode: Optional episode index (part of series identity).
            labels: The labels of the metric.
            major_step: The RL step (required, must not decrease).
            minor_step: Override for the minor step. If None, auto-incremented.

        Returns:
            The minor step to use for this point.

        Raises:
            MetranaMetricStepError: If major_step decreases, or manual/auto minor
                steps are mixed for the same series.
        """

        with self._lock:
            labels_key = tuple(sorted(labels.items())) if labels else ()
            key = (metric_name, scale, environment_id, episode, labels_key)

            if key in self._state:
                last_major, _ = self._state[key]
                if major_step < last_major:
                    raise MetranaMetricStepError(
                        f"RL major step must not decrease. Got {major_step} after {last_major} "
                        f"for metric: {metric_name}, environment: {environment_id}."
                    )

            if minor_step is not None:
                if key in self._auto_minor:
                    raise MetranaMetricStepError(
                        f"RL minor steps can either be manually set or automatically incremented. "
                        f"Got conflicting values for metric: {metric_name}."
                    )
                self._manual_minor.add(key)
                self._state[key] = (major_step, minor_step)
                return minor_step

            if key in self._manual_minor:
                raise MetranaMetricStepError(
                    f"RL minor steps can either be manually set or automatically incremented. "
                    f"Got conflicting values for metric: {metric_name}."
                )
            self._auto_minor.add(key)

            if key in self._state:
                last_major, last_minor = self._state[key]
                next_minor = 0 if major_step > last_major else last_minor + 1
            else:
                next_minor = 0

            self._state[key] = (major_step, next_minor)
            return next_minor
