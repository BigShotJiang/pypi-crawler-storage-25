.. automodule:: qwt.text
