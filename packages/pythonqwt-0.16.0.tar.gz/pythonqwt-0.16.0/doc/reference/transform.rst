.. automodule:: qwt.transform
