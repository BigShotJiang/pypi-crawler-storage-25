.. automodule:: qwt.symbol
