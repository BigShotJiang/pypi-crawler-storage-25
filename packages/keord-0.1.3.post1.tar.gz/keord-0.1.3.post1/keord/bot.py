from __future__ import annotations

import asyncio
import contextlib
import inspect
import json
import sys
import time
from typing import Any, Awaitable, Callable, Iterable

import aiohttp

from .command import Command
from .ctx import InteractionContext, MessageContext
from .module import Embed
from .slash import SlashCommand


DISCORD_API = "https://discord.com/api/v10"
INTENTS = (1 << 0) | (1 << 9) | (1 << 15)  # guilds + guild_messages + message_content
ALLOWED_STATUSES = {"online", "idle", "dnd", "invisible"}


class Bot:
    def __init__(
        self,
        prefix: str | Iterable[str] = "!",
        *,
        status: str = "online",
        activity: str | None = None,
        afk: bool = False,
        mention_prefix: bool = True,
    ) -> None:
        self.prefixes = self._normalize_prefixes(prefix)
        self.mention_prefix = mention_prefix
        self.status = self._validate_status(status)
        self.activity = activity
        self.afk = afk

        self.commands: dict[str, Command] = {}
        self.slash_commands: dict[str, SlashCommand] = {}
        self.events: dict[str, Callable[..., Awaitable[None]]] = {}
        self.token: str | None = None
        self.application_id: str | None = None
        self.user_id: str | None = None

        self.session: aiohttp.ClientSession | None = None
        self.ws: aiohttp.ClientWebSocketResponse | None = None
        self._sequence: int | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._last_heartbeat_sent_monotonic: float | None = None
        self._last_heartbeat_ack_monotonic: float | None = None
        self._latency_ms: float | None = None
        self._ready: asyncio.Event = asyncio.Event()

    def event(self, func: Callable[..., Awaitable[None]]) -> Callable[..., Awaitable[None]]:
        self.events[func.__name__] = func
        return func

    def command(self, name: str | None = None) -> Callable[[Callable[..., Awaitable[None]]], Callable[..., Awaitable[None]]]:
        def decorator(func: Callable[..., Awaitable[None]]) -> Callable[..., Awaitable[None]]:
            cmd_name = (name or func.__name__).lower()
            self.commands[cmd_name] = Command(name=cmd_name, callback=func)
            return func

        return decorator

    def slash_command(
        self,
        name: str | None = None,
        *,
        description: str | None = None,
        options: list[dict[str, Any]] | None = None,
    ) -> Callable[[Callable[..., Awaitable[None]]], Callable[..., Awaitable[None]]]:
        def decorator(func: Callable[..., Awaitable[None]]) -> Callable[..., Awaitable[None]]:
            cmd_name = (name or func.__name__).lower()
            desc = description or (inspect.getdoc(func) or "").strip() or "No description provided."
            cmd = SlashCommand(name=cmd_name, description=desc, callback=func, options=options or [])
            self.slash_commands[cmd_name] = cmd
            return func

        return decorator

    def run(self, token: str) -> None:
        asyncio.run(self.start(token))

    async def login(self, token: str) -> None:
        """Initialize HTTP session and fetch bot/application ids.

        This does not connect to the Gateway; call :meth:`connect` or :meth:`start` after.
        """
        if self.session is not None and not self.session.closed:
            raise RuntimeError("Bot is already logged in (session is active)")

        self._ready.clear()
        self.token = token
        self.session = aiohttp.ClientSession()
        self.application_id = await self._get_application_id()
        self.user_id = await self._get_current_user_id()

    async def connect(self) -> None:
        """Connect to Discord Gateway and start receiving events."""
        if self.session is None or self.session.closed or self.token is None:
            raise RuntimeError("Bot is not logged in. Call login(token) first.")
        gateway_url = await self._get_gateway_url()
        await self._connect_gateway(gateway_url)

    async def close(self) -> None:
        """Gracefully close the Gateway and HTTP session.

        Safe to call multiple times.
        """
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._heartbeat_task
            self._heartbeat_task = None

        if self.ws is not None and not self.ws.closed:
            with contextlib.suppress(Exception):
                await self.ws.close()
        self.ws = None

        if self.session is not None and not self.session.closed:
            with contextlib.suppress(Exception):
                await self.session.close()
        self.session = None

        self._sequence = None
        self._last_heartbeat_sent_monotonic = None
        self._last_heartbeat_ack_monotonic = None
        self._latency_ms = None
        self._ready.clear()

    async def logout(self) -> None:
        """Alias for :meth:`close` (discord.py-style naming)."""
        await self.close()

    async def start(self, token: str) -> None:
        try:
            await self.login(token)
            await self.connect()
        finally:
            await self.close()

    def is_ready(self) -> bool:
        return self._ready.is_set()

    async def wait_until_ready(self) -> None:
        await self._ready.wait()

    def _normalize_prefixes(self, prefix: str | Iterable[str]) -> tuple[str, ...]:
        if isinstance(prefix, str):
            prefixes = (prefix,)
        else:
            prefixes = tuple(prefix)
        if not prefixes:
            raise ValueError("prefix must not be empty")
        return tuple(p for p in prefixes if p)

    def _validate_status(self, status: str) -> str:
        if status not in ALLOWED_STATUSES:
            raise ValueError(f"Unsupported status '{status}'. Use one of: {', '.join(sorted(ALLOWED_STATUSES))}")
        return status

    def _build_presence(self) -> dict[str, Any]:
        activities: list[dict[str, Any]] = []
        if self.activity:
            activities.append({"name": self.activity, "type": 0})

        return {
            "since": None,
            "activities": activities,
            "status": self.status,
            "afk": self.afk,
        }

    async def change_presence(self, *, status: str | None = None, activity: str | None = None, afk: bool | None = None) -> None:
        if status is not None:
            self.status = self._validate_status(status)
        if activity is not None:
            self.activity = activity
        if afk is not None:
            self.afk = afk

        if self.ws is not None:
            await self.ws.send_json({"op": 3, "d": self._build_presence()})

    async def sync_commands(self, *, guild_id: str | None = None) -> list[dict[str, Any]]:
        """Register current slash commands to Discord.

        If guild_id is provided, commands are registered for that guild (fast propagation).
        Otherwise, registers global commands (can take time to propagate).
        """
        if self.session is None or self.token is None or self.application_id is None:
            raise RuntimeError("Bot is not initialized (session/token/application_id)")

        payload = [cmd.to_application_command() for cmd in self.slash_commands.values()]
        headers = {"Authorization": f"Bot {self.token}"}
        if guild_id:
            url = f"{DISCORD_API}/applications/{self.application_id}/guilds/{guild_id}/commands"
        else:
            url = f"{DISCORD_API}/applications/{self.application_id}/commands"

        async with self.session.put(url, headers=headers, json=payload) as response:
            text = await response.text()
            if response.status >= 400:
                raise RuntimeError(f"Failed to sync commands ({response.status}): {text}")
            return json.loads(text) if text else []

    async def _get_gateway_url(self) -> str:
        assert self.session and self.token
        headers = {"Authorization": f"Bot {self.token}"}

        async with self.session.get(f"{DISCORD_API}/gateway/bot", headers=headers) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to fetch gateway ({response.status}): {text}")

            data = await response.json()
            return f"{data['url']}?v=10&encoding=json"

    async def _get_application_id(self) -> str:
        assert self.session and self.token
        headers = {"Authorization": f"Bot {self.token}"}
        async with self.session.get(f"{DISCORD_API}/oauth2/applications/@me", headers=headers) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to fetch application info ({response.status}): {text}")
            data = await response.json()
            return data["id"]

    async def _get_current_user_id(self) -> str:
        assert self.session and self.token
        headers = {"Authorization": f"Bot {self.token}"}
        async with self.session.get(f"{DISCORD_API}/users/@me", headers=headers) as response:
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Failed to fetch bot user ({response.status}): {text}")
            data = await response.json()
            return data["id"]

    async def _connect_gateway(self, gateway_url: str) -> None:
        assert self.session and self.token
        self.ws = await self.session.ws_connect(gateway_url)

        try:
            async for message in self.ws:
                if message.type != aiohttp.WSMsgType.TEXT:
                    continue

                payload = json.loads(message.data)
                op = payload.get("op")
                data = payload.get("d")
                event_name = payload.get("t")
                self._sequence = payload.get("s", self._sequence)

                if op == 10:  # Hello
                    interval = data["heartbeat_interval"] / 1000
                    self._heartbeat_task = asyncio.create_task(self._heartbeat(interval))
                    await self._identify()
                elif op == 11:  # Heartbeat ACK
                    self._last_heartbeat_ack_monotonic = time.monotonic()
                    if self._last_heartbeat_sent_monotonic is not None:
                        self._latency_ms = (self._last_heartbeat_ack_monotonic - self._last_heartbeat_sent_monotonic) * 1000.0
                elif op == 0:
                    await self._dispatch(event_name, data)
        except asyncio.CancelledError:
            # Normal on shutdown (Ctrl+C / task cancellation). Avoid noisy tracebacks.
            return

    async def _identify(self) -> None:
        assert self.ws and self.token
        payload = {
            "op": 2,
            "d": {
                "token": self.token,
                "intents": INTENTS,
                "properties": {"os": sys.platform, "browser": "keord", "device": "keord"},
                "presence": self._build_presence(),
            },
        }
        await self.ws.send_json(payload)

    async def _heartbeat(self, interval: float) -> None:
        assert self.ws
        while True:
            await asyncio.sleep(interval)
            self._last_heartbeat_sent_monotonic = time.monotonic()
            await self.ws.send_json({"op": 1, "d": self._sequence})

    def latency_ms(self, *, rounded_to: int = 100) -> int | None:
        """Gateway latency in milliseconds (rounded, no decimals).

        rounded_to=100 => 200, 300, 400... as requested.
        Returns None until at least one Heartbeat ACK is received.
        """
        if self._latency_ms is None:
            return None
        if rounded_to <= 0:
            return int(round(self._latency_ms))
        return int(round(self._latency_ms / rounded_to) * rounded_to)

    async def _dispatch(self, event_name: str | None, data: dict[str, Any] | None) -> None:
        if not event_name:
            return

        if event_name == "READY":
            self._ready.set()

        handler_name = self._to_handler_name(event_name)
        handler = self.events.get(handler_name)
        if handler:
            try:
                await self._call_handler(handler, data)
            except Exception as exc:
                print(f"[keord] Error in event handler {event_name}: {exc}")

        if event_name == "MESSAGE_CREATE" and data is not None:
            await self._handle_command(data)
        if event_name == "INTERACTION_CREATE" and data is not None:
            await self._handle_interaction(data)

    def _to_handler_name(self, event_name: str) -> str:
        if event_name == "MESSAGE_CREATE":
            return "on_message"
        if event_name == "READY":
            return "on_ready"
        return f"on_{event_name.lower()}"

    async def _call_handler(self, handler: Callable[..., Awaitable[None]], data: dict[str, Any] | None) -> None:
        params = inspect.signature(handler).parameters
        if len(params) == 0:
            await handler()
        else:
            await handler(data)

    async def _handle_command(self, message: dict[str, Any]) -> None:
        if message.get("author", {}).get("bot"):
            return

        content = message.get("content", "")
        prefix = self._match_prefix(content)
        if prefix is None:
            return

        raw = content[len(prefix) :].strip()
        if not raw:
            return

        parts = raw.split()
        name = parts[0].lower()
        args = parts[1:]
        command = self.commands.get(name)
        if not command:
            return

        ctx = MessageContext(bot=self, message=message, args=args, raw=message)
        try:
            await command.callback(ctx)
        except Exception as exc:
            print(f"[keord] Error in command '{name}': {exc}")

    def _match_prefix(self, content: str) -> str | None:
        for p in self.prefixes:
            if content.startswith(p):
                return p
        if self.mention_prefix and self.user_id:
            # Discord mentions can be <@id> or <@!id>
            for m in (f"<@{self.user_id}>", f"<@!{self.user_id}>"):
                if content.startswith(m):
                    # allow optional space after mention
                    rest = content[len(m) :]
                    if rest.startswith(" "):
                        return m + " "
                    return m
        return None

    async def _handle_interaction(self, interaction: dict[str, Any]) -> None:
        data = interaction.get("data") or {}
        name = (data.get("name") or "").lower()
        cmd = self.slash_commands.get(name)
        if not cmd:
            return

        options = data.get("options") or []
        args: list[str] = []
        for opt in options:
            if "value" in opt:
                args.append(str(opt["value"]))

        ctx = InteractionContext(
            bot=self,
            args=args,
            raw=interaction,
            interaction_id=interaction["id"],
            interaction_token=interaction["token"],
            data=data,
        )
        try:
            await cmd.callback(ctx)
        except Exception as exc:
            print(f"[keord] Error in slash command '/{name}': {exc}")
