class Colors:
    """Handy Discord-like colors (as integers)."""

    BLURPLE = 0x5865F2
    GREEN = 0x57F287
    YELLOW = 0xFEE75C
    RED = 0xED4245
    WHITE = 0xFFFFFF
    BLACK = 0x000000

