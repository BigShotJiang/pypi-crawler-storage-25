from __future__ import annotations

from typing import Any

from .module import Colors, Embed


def setup_default_commands(bot: Any, *, prefix_commands: bool = True, slash_commands: bool = True) -> None:
    """Register common starter commands: ping, avatar, help.

    - ping: gateway latency (rounded to 100ms by default)
    - avatar: show avatar url for @mention/id (or yourself)
    - help: list registered commands
    """

    if prefix_commands:

        @bot.command()
        async def ping(ctx):
            ms = None
            if hasattr(ctx.bot, "latency_ms"):
                ms = ctx.bot.latency_ms(rounded_to=100)
            await ctx.send(f"Pong! {ms}ms" if ms is not None else "Pong!")

        @bot.command()
        async def avatar(ctx):
            target = ctx.parse_user_id(ctx.args[0]) if ctx.args else (ctx.author_id or None)
            if not target:
                return await ctx.send("Укажи пользователя: `!avatar @mention`")

            user = await ctx.fetch_user(target)
            avatar_hash = user.get("avatar")
            if avatar_hash:
                url = f"https://cdn.discordapp.com/avatars/{target}/{avatar_hash}.png?size=1024"
            else:
                disc = int(user.get("discriminator") or 0)
                url = f"https://cdn.discordapp.com/embed/avatars/{disc % 5}.png"

            embed = Embed(title="Avatar", description=f"<@{target}>", color=Colors.BLURPLE).set_image(url)
            await ctx.send(embed=embed)

        @bot.command()
        async def help(ctx):
            names = sorted(getattr(ctx.bot, "commands", {}).keys())
            if not names:
                return await ctx.send("Команд нет.")
            await ctx.send("Команды: " + ", ".join(f"`{ctx.bot.prefixes[0]}{n}`" for n in names))

    if slash_commands:

        @bot.slash_command(description="Пинг (latency)")
        async def ping(ctx):
            ms = None
            if hasattr(ctx.bot, "latency_ms"):
                ms = ctx.bot.latency_ms(rounded_to=100)
            await ctx.respond(f"Pong! {ms}ms" if ms is not None else "Pong!")

        @bot.slash_command(description="Показать аватар пользователя")
        async def avatar(ctx):
            # For slash: best effort: first arg or option "user" if user-type options are used later.
            token = ctx.args[0] if ctx.args else None
            target = ctx.parse_user_id(token) if hasattr(ctx, "parse_user_id") else None
            target = target or ctx.author_id
            if not target:
                return await ctx.respond("Не удалось определить пользователя.", ephemeral=True)

            # Use webhook followup with direct URL (we don't have fetch_user here by default)
            await ctx.respond(f"Аватар: <@{target}>", ephemeral=False)

