# keord

`keord` — минималистичный Python-фреймворк (MVP) для создания Discord-ботов **без** `discord.py`/`disnake`.
Он работает напрямую с Discord HTTP API и Gateway, чтобы вы могли понять “как оно устроено”.

## Содержание

- [Установка](#установка)
- [Быстрый старт (prefix-команды)](#быстрый-старт-prefix-команды)
- [Slash-команды (application commands)](#slash-команды-application-commands)
- [Контексты (ctx)](#контексты-ctx)
- [Префиксы](#префиксы)
- [Жизненный цикл бота](#жизненный-цикл-бота)
- [Частая ошибка ImportError](#частая-ошибка-importerror)
- [Важные заметки](#важные-заметки)

## Установка

```bash
pip install keord
```

Если хотите конкретную версию:

```bash
pip install "keord==0.1.3.post1"
```

## Быстрый старт (prefix-команды)

Создайте файл `main.py` (важно: **не** `keord.py`):

```python
from keord import Bot, Colors, Embed

bot = Bot(prefix="!", status="dnd", activity="keord 0.1.3.post1")

@bot.event
async def on_ready():
    print("Bot is ready")

@bot.event
async def on_message(message):
    print(message.get("content"))

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

@bot.command()
async def info(ctx):
    embed = (
        Embed(title="Keord", description="Минимальный фреймворк", color=Colors.BLURPLE)
        .add_field(name="Версия", value="0.1.3.post1", inline=True)
        .set_footer(text="keord")
    )
    await ctx.send(embed=embed)

bot.run("TOKEN")
```

## Slash-команды (application commands)

Slash-команды объявляются через `@bot.slash_command()`, а затем их нужно синхронизировать с Discord один раз (глобально или для конкретного сервера).

```python
from keord import Bot

bot = Bot(prefix=("!",), activity="keord 0.1.3.post1")

@bot.slash_command(description="Проверка работоспособности")
async def ping(ctx):
    await ctx.respond("Pong!")

@bot.event
async def on_ready():
    print("Bot is ready")
    # Быстро (для разработки): только для гильдии
    # await bot.sync_commands(guild_id="YOUR_GUILD_ID")
    # Долго (глобально):
    await bot.sync_commands()

bot.run("TOKEN")
```

## Контексты (ctx)

### Message ctx (prefix-команды)

- **`ctx.send(...)`**: отправка сообщения в тот же канал (supports `content`, `embed/embeds`, `components`).
- **`ctx.fetch_user(user_id)`**: получить пользователя по id (HTTP).

### Slash ctx (interaction)

- **`ctx.respond(...)`**: ответ на interaction (первый ответ).
- **`ctx.defer(ephemeral=...)`**: “думаем…” (ACK).
- **`ctx.edit_original(...)`**: редактирование исходного ответа.
- **`ctx.followup(...)`**: follow-up сообщение.
- **`ctx.options`**: простая мапа `имя_опции -> значение` (если вы используете options).

## Префиксы

Поддерживается:

- один префикс: `Bot(prefix="!")`
- несколько префиксов: `Bot(prefix=("!", "."))`
- префикс-упоминание: `@BotName ping` (включено по умолчанию)

Команды вы пишете сами: `!help`, `/help`, `!avatar`, `@mention ...` — это просто разные обработчики.

## Жизненный цикл бота

Самый простой путь:

- **`bot.run("TOKEN")`**: синхронный entrypoint (внутри делает `asyncio.run(bot.start(...))`).
- **`await bot.start("TOKEN")`**: логин + подключение к gateway, и гарантированное закрытие ресурсов при выходе.

Если хотите более “ручной” контроль:

- **`await bot.login("TOKEN")`**: создаёт HTTP-сессию и получает `application_id/user_id`.
- **`await bot.connect()`**: подключается к gateway и начинает получать события.
- **`await bot.wait_until_ready()`** / **`bot.is_ready()`**: ожидание/проверка `READY`.
- **`await bot.close()`**: корректное завершение (останавливает heartbeat, закрывает WS и `aiohttp`-сессию), **идемпотентно**.
- **`await bot.logout()`**: алиас на `close()`.

Пример “ручного” запуска:

```python
import asyncio
from keord import Bot

bot = Bot(prefix="!")

@bot.event
async def on_ready():
    print("READY")

async def main():
    await bot.login("TOKEN")
    await bot.connect()

asyncio.run(main())
```

## Частая ошибка ImportError

Если видите:

`ImportError: cannot import name 'Bot' from partially initialized module 'keord'`

значит ваш пользовательский файл назван `keord.py` и перекрывает пакет.
Переименуйте его, например, в `main.py`, удалите `__pycache__` и запустите снова.

## Важные заметки

- Для работы команд включите `MESSAGE CONTENT INTENT` в Discord Developer Portal.
- Для slash-команд нужен scopes `applications.commands`, а также разрешения бота на сервере.
