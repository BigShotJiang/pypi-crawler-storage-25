from pathlib import Path

from aiva_agent.prompts import (
    ANNOTATE_SECTION,
    CLASSIFY_SECTION,
    LITERATURE_SECTION,
    RANK_GENES_SECTION,
    TRIALS_SECTION,
    VCF_SECTION_BASE,
    VCF_SECTION_MULTI_TEMPLATE,
    VCF_SECTION_SINGLE,
    WEB_SECTION,
    get_main_system_prompt,
)


def test_core_sections_always_included():
    p = get_main_system_prompt(["vcf"])
    assert "AIVA" in p
    assert "DIRECTNESS AND ANTI-SYCOPHANCY" in p
    assert "SOURCE CITATION RULES" in p
    assert "RESPONSE FORMATTING" in p


def test_only_enabled_tool_sections_appear():
    p = get_main_system_prompt(["literature"])
    assert LITERATURE_SECTION in p
    assert ANNOTATE_SECTION not in p
    assert TRIALS_SECTION not in p
    assert RANK_GENES_SECTION not in p
    assert CLASSIFY_SECTION not in p
    assert VCF_SECTION_BASE not in p


def test_unknown_tool_names_silently_skipped():
    p = get_main_system_prompt(["bogus"])
    for section in (
        VCF_SECTION_BASE,
        ANNOTATE_SECTION,
        LITERATURE_SECTION,
        TRIALS_SECTION,
        RANK_GENES_SECTION,
        CLASSIFY_SECTION,
    ):
        assert section not in p


def test_classify_section_includes_argument_template():
    p = get_main_system_prompt(["classify"])
    assert "variant_data" in p
    assert "classification_type" in p
    assert "phenotype_terms" in p
    assert "additional_context" in p
    assert "GRCh37" in p and "GRCh38" in p


def test_full_prompt_assembles_all_sections():
    enabled = ["vcf", "annotate", "literature", "trials", "rank_genes", "web", "classify"]
    p = get_main_system_prompt(enabled)
    for section in (
        VCF_SECTION_BASE,
        ANNOTATE_SECTION,
        LITERATURE_SECTION,
        TRIALS_SECTION,
        RANK_GENES_SECTION,
        WEB_SECTION,
        CLASSIFY_SECTION,
    ):
        assert section in p


def test_web_section_documents_action_parameter():
    p = get_main_system_prompt(["web"])
    assert "action='search'" in p or "action=\"search\"" in p
    assert "action='scrape'" in p or "action=\"scrape\"" in p


def test_section_ordering_preserves_enabled_order():
    p = get_main_system_prompt(["literature", "vcf", "annotate"])
    assert p.index(LITERATURE_SECTION) < p.index(VCF_SECTION_BASE) < p.index(ANNOTATE_SECTION)


def test_vcf_section_single_view_default():
    p = get_main_system_prompt(["vcf"])
    assert VCF_SECTION_BASE in p
    assert VCF_SECTION_SINGLE in p
    # The multi-mode template body should NOT appear when only one (or zero) views are registered.
    assert "MULTI-VCF MODE" not in p


def test_vcf_section_multi_view_when_multiple_specs():
    specs = [
        ("proband", Path("p.vcf.gz")),
        ("father", Path("f.vcf.gz")),
        ("mother", Path("m.vcf.gz")),
    ]
    p = get_main_system_prompt(["vcf"], vcf_specs=specs)
    assert VCF_SECTION_BASE in p
    assert "MULTI-VCF MODE" in p
    assert "`proband`" in p
    assert "`father`" in p
    assert "`mother`" in p
    # Single-view-only line should not appear when multi-view template kicks in.
    assert VCF_SECTION_SINGLE not in p


def test_vcf_section_documents_format_column_convention():
    p = get_main_system_prompt(["vcf"])
    assert "FORMAT_<FIELD>_<SAMPLE>" in p
    # Old (incorrect) "structs" wording must not regress.
    assert "FORMAT structs" not in p


def test_bash_section_appears_when_enabled():
    p = get_main_system_prompt(["bash"])
    assert "SHELL ACCESS" in p
    assert "run_bash" in p


def test_bash_section_bakes_in_workdir(tmp_path):
    p = get_main_system_prompt(["bash"], workdir=tmp_path)
    assert str(tmp_path) in p


def test_bash_section_falls_back_to_cwd_without_workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    p = get_main_system_prompt(["bash"])
    assert str(tmp_path) in p


def test_bash_section_absent_when_disabled():
    p = get_main_system_prompt(["literature"])
    assert "SHELL ACCESS" not in p
    assert "run_bash" not in p


def test_bash_section_warns_against_env_dump():
    p = get_main_system_prompt(["bash"])
    assert "LLM_API_KEY" in p
    assert "printenv" in p
    assert "private" in p.lower()


def test_bash_section_directs_failed_tools_to_alternative_apis():
    p = get_main_system_prompt(["bash"])
    assert "structured tool" in p.lower()
    assert "different" in p.lower()
    assert "upstream" in p.lower()


def test_bash_section_lists_additional_biomedical_apis():
    p = get_main_system_prompt(["bash"])
    bash_section = p[p.index("SHELL ACCESS"):]
    for name in ("Open Targets", "Ensembl REST", "UniProt", "DisGeNET", "GTEx", "OMIM", "HPO"):
        assert name in bash_section, f"missing API name in bash section: {name}"
