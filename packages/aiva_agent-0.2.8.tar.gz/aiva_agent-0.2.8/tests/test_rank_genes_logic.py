from aiva_agent.tools.rank_genes import RankGenesWorker

normalize = RankGenesWorker._normalize
penalize = RankGenesWorker._apply_exclusion_penalties


def test_normalize_adds_hp_prefix_when_missing():
    assert normalize(["0001250"]) == ["HP:0001250"]


def test_normalize_uppercases_and_keeps_existing_prefix():
    assert normalize(["hp:0001250"]) == ["HP:0001250"]


def test_normalize_strips_whitespace():
    assert normalize(["  HP:0001250  ", " 0001263 "]) == ["HP:0001250", "HP:0001263"]


def test_apply_exclusion_returns_unchanged_when_no_excluded():
    pos = [{"Gene": "TP53", "Score": 0.9, "Status": "Predicted", "Rank": 1}]
    out, removed = penalize(pos, [], 0.5)
    assert out == pos
    assert removed == []


def test_apply_exclusion_removes_seedgene_for_excluded_phenotype():
    pos = [
        {"Gene": "ARG1", "Score": 1.0, "Status": "SeedGene", "Rank": 1},
        {"Gene": "TP53", "Score": 0.5, "Status": "Predicted", "Rank": 2},
    ]
    excl = [{"Gene": "ARG1", "Score": 0.9, "Status": "SeedGene"}]
    out, removed = penalize(pos, excl, 0.5)
    assert removed == ["ARG1"]
    assert [g["Gene"] for g in out] == ["TP53"]
    assert out[0]["Rank"] == 1  # re-ranked


def test_apply_exclusion_penalizes_predicted_genes_proportionally():
    # original score 1.0, excluded score 0.5, strength 0.5 -> 1.0 * (1 - 0.25) = 0.75
    pos = [{"Gene": "X", "Score": 1.0, "Status": "Predicted", "Rank": 1}]
    excl = [{"Gene": "X", "Score": 0.5, "Status": "Predicted"}]
    out, removed = penalize(pos, excl, 0.5)
    assert removed == []
    assert out[0]["Score"] == 0.75
    assert out[0]["Rank"] == 1


def test_apply_exclusion_re_ranks_after_penalty():
    pos = [
        {"Gene": "A", "Score": 1.0, "Status": "Predicted", "Rank": 1},
        {"Gene": "B", "Score": 0.8, "Status": "Predicted", "Rank": 2},
    ]
    # Heavily penalize A so B leapfrogs.
    excl = [{"Gene": "A", "Score": 1.0, "Status": "Predicted"}]
    out, _ = penalize(pos, excl, 1.0)
    assert [g["Gene"] for g in out] == ["B", "A"]
    assert [g["Rank"] for g in out] == [1, 2]


def test_apply_exclusion_handles_lowercase_keys():
    # Some upstream response variants use lowercase keys.
    pos = [{"gene": "X", "score": 0.9, "status": "Predicted", "rank": 1}]
    excl = [{"gene": "X", "score": 0.5, "status": "Predicted"}]
    out, _ = penalize(pos, excl, 0.5)
    # 0.9 * (1 - 0.5*0.5) = 0.675
    assert abs(out[0]["score"] - 0.675) < 1e-9
