"""Tests for the --output / --force CLI flags. We invoke main() with the agent
runner monkey-patched so no real query() is made."""

from pathlib import Path

import pytest

from aiva_agent import cli


@pytest.fixture
def fake_agent(monkeypatch):
    """Replace run_once with a deterministic fake."""

    async def fake_run_once(prompt, **kwargs):
        return f"FAKE ANSWER for: {prompt}"

    monkeypatch.setattr(cli, "run_once", fake_run_once)


@pytest.fixture
def captured_kwargs(monkeypatch):
    """Replace run_once with a fake that captures the kwargs it was called with."""
    captured: dict = {}

    async def fake_run_once(prompt, **kwargs):
        captured["prompt"] = prompt
        captured.update(kwargs)
        return "ok"

    monkeypatch.setattr(cli, "run_once", fake_run_once)
    return captured


def test_output_writes_to_file(fake_agent, tmp_path: Path, capsys, monkeypatch):
    out = tmp_path / "answer.md"
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hello", "-o", str(out)],
    )
    assert cli.main() == 0
    assert out.read_text() == "FAKE ANSWER for: hello"

    captured = capsys.readouterr()
    # stdout must be empty when --output is used
    assert captured.out == ""
    # confirmation goes to stderr
    assert "Wrote" in captured.err and str(out) in captured.err


def test_output_creates_parent_directories(fake_agent, tmp_path: Path, monkeypatch):
    out = tmp_path / "nested" / "deep" / "answer.md"
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hi", "--output", str(out)],
    )
    assert cli.main() == 0
    assert out.exists()
    assert out.read_text() == "FAKE ANSWER for: hi"


def test_output_refuses_to_clobber_without_force(fake_agent, tmp_path: Path, capsys, monkeypatch):
    out = tmp_path / "existing.md"
    out.write_text("original contents")
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hi", "-o", str(out)],
    )
    assert cli.main() == 2
    assert out.read_text() == "original contents"  # unchanged
    captured = capsys.readouterr()
    assert "already exists" in captured.err
    assert "--force" in captured.err


def test_output_with_force_overwrites(fake_agent, tmp_path: Path, monkeypatch):
    out = tmp_path / "existing.md"
    out.write_text("original contents")
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hi", "-o", str(out), "--force"],
    )
    assert cli.main() == 0
    assert out.read_text() == "FAKE ANSWER for: hi"


def test_no_output_flag_prints_to_stdout(fake_agent, capsys, monkeypatch):
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "stdout test"],
    )
    assert cli.main() == 0
    captured = capsys.readouterr()
    assert "FAKE ANSWER for: stdout test" in captured.out


def test_vcf_auto_disable_emits_warning_when_no_path(fake_agent, capsys, monkeypatch):
    monkeypatch.delenv("AIVA_VCF", raising=False)
    monkeypatch.delenv("AIVA_DISABLE", raising=False)
    monkeypatch.setattr("sys.argv", ["aiva_agent", "--prompt", "hello"])
    assert cli.main() == 0
    captured = capsys.readouterr()
    assert "vcf tool disabled" in captured.err
    assert "AIVA_VCF" in captured.err


def test_explicit_disable_vcf_does_not_warn(fake_agent, capsys, monkeypatch):
    monkeypatch.delenv("AIVA_VCF", raising=False)
    monkeypatch.delenv("AIVA_DISABLE", raising=False)
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hello"],
    )
    assert cli.main() == 0
    captured = capsys.readouterr()
    assert "vcf tool disabled" not in captured.err


def test_disable_vcf_with_explicit_path_passes_no_specs(captured_kwargs, monkeypatch):
    """`--vcf path --disable vcf` should NOT spin up the vcf tool — we pass
    vcf_specs=None to run_once even though --vcf was given."""
    monkeypatch.delenv("AIVA_VCF", raising=False)
    monkeypatch.delenv("AIVA_DISABLE", raising=False)
    monkeypatch.setattr(
        "sys.argv",
        [
            "aiva_agent",
            "--vcf",
            "data/test.vcf.gz",
            "--disable",
            "vcf",
            "--prompt",
            "hi",
        ],
    )
    assert cli.main() == 0
    assert captured_kwargs["vcf_specs"] is None
    assert "vcf" in captured_kwargs["disabled_tools"]


def test_force_falls_back_to_aiva_force_env(fake_agent, tmp_path, monkeypatch):
    out = tmp_path / "existing.md"
    out.write_text("original")
    monkeypatch.setenv("AIVA_FORCE", "1")
    monkeypatch.delenv("AIVA_VCF", raising=False)
    monkeypatch.setattr(
        "sys.argv",
        ["aiva_agent", "--disable", "vcf", "--prompt", "hi", "-o", str(out)],
    )
    # AIVA_FORCE=1 should let the existing file be overwritten without --force.
    assert cli.main() == 0
    assert out.read_text() == "FAKE ANSWER for: hi"


def test_max_turns_env_resolves(monkeypatch):
    from aiva_agent.agent import _resolve_max_turns, DEFAULT_MAX_TURNS

    monkeypatch.delenv("AIVA_MAX_TURNS", raising=False)
    assert _resolve_max_turns() == DEFAULT_MAX_TURNS

    monkeypatch.setenv("AIVA_MAX_TURNS", "40")
    assert _resolve_max_turns() == 40

    # Garbage / non-positive falls back to default rather than crashing.
    monkeypatch.setenv("AIVA_MAX_TURNS", "not-a-number")
    assert _resolve_max_turns() == DEFAULT_MAX_TURNS
    monkeypatch.setenv("AIVA_MAX_TURNS", "0")
    assert _resolve_max_turns() == DEFAULT_MAX_TURNS
    monkeypatch.setenv("AIVA_MAX_TURNS", "-5")
    assert _resolve_max_turns() == DEFAULT_MAX_TURNS


def test_resolve_stream_precedence(monkeypatch, tmp_path):
    """--output forces off > --stream forces on > AIVA_STREAM env > TTY auto."""
    from aiva_agent.cli import _resolve_stream

    monkeypatch.delenv("AIVA_STREAM", raising=False)
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)

    # 1. TTY default -> on
    assert _resolve_stream(False, None) is True

    # 2. --output forces off even with --stream
    out = tmp_path / "answer.md"
    assert _resolve_stream(True, out) is False

    # 3. --stream flag forces on
    assert _resolve_stream(True, None) is True

    # 4. AIVA_STREAM=0 forces off
    monkeypatch.setenv("AIVA_STREAM", "0")
    assert _resolve_stream(False, None) is False

    # 5. AIVA_STREAM=1 forces on (even on a non-TTY)
    monkeypatch.setattr("sys.stdout.isatty", lambda: False)
    monkeypatch.setenv("AIVA_STREAM", "1")
    assert _resolve_stream(False, None) is True

    # 6. Flag wins over AIVA_STREAM=0
    monkeypatch.setenv("AIVA_STREAM", "0")
    assert _resolve_stream(True, None) is True

    # 7. Non-TTY default -> off
    monkeypatch.delenv("AIVA_STREAM", raising=False)
    monkeypatch.setattr("sys.stdout.isatty", lambda: False)
    assert _resolve_stream(False, None) is False

    # 8. Whitespace / case insensitive env
    monkeypatch.setattr("sys.stdout.isatty", lambda: False)
    monkeypatch.setenv("AIVA_STREAM", "  TRUE  ")
    assert _resolve_stream(False, None) is True
    monkeypatch.setenv("AIVA_STREAM", "Off")
    assert _resolve_stream(False, None) is False


def test_make_stream_renderer_text_deltas(monkeypatch, capsys):
    """Raw text deltas should land on stdout and trigger a trailing newline on finalize."""
    from aiva_agent.cli import _make_stream_renderer
    from agents.stream_events import RawResponsesStreamEvent
    from openai.types.responses import ResponseTextDeltaEvent

    monkeypatch.delenv("AIVA_STREAM_TOOL_OUTPUT", raising=False)
    handler, finalize = _make_stream_renderer()

    def make_delta(text: str) -> RawResponsesStreamEvent:
        # ResponseTextDeltaEvent has many required fields; we build a lightweight
        # stand-in with only the attributes the renderer actually checks.
        delta = ResponseTextDeltaEvent.model_construct(delta=text)
        return RawResponsesStreamEvent(data=delta)

    handler(make_delta("hello "))
    handler(make_delta("world"))
    handler(make_delta(""))  # empty deltas are skipped
    finalize()

    captured = capsys.readouterr()
    assert captured.out == "hello world\n"
    assert captured.err == ""


def test_make_stream_renderer_tool_markers(monkeypatch, capsys):
    """tool_call_item -> [tool] name…  ;  tool_call_output_item -> [tool] done."""
    from aiva_agent.cli import _make_stream_renderer
    from agents.stream_events import RunItemStreamEvent

    monkeypatch.delenv("AIVA_STREAM_TOOL_OUTPUT", raising=False)
    handler, _finalize = _make_stream_renderer()

    class FakeCallItem:
        type = "tool_call_item"
        tool_name = "vcf_query"

    class FakeOutputItem:
        type = "tool_call_output_item"
        output = "(does not matter — dump is off)"

    handler(RunItemStreamEvent(name="tool_called", item=FakeCallItem()))
    handler(RunItemStreamEvent(name="tool_output", item=FakeOutputItem()))

    captured = capsys.readouterr()
    assert "[tool] vcf_query…" in captured.err
    assert "[tool] done" in captured.err
    # Output content must NOT leak when AIVA_STREAM_TOOL_OUTPUT is unset.
    assert "does not matter" not in captured.err
    assert captured.out == ""


def test_make_stream_renderer_tool_output_dump(monkeypatch, capsys):
    """AIVA_STREAM_TOOL_OUTPUT=1 should dump the output, truncated by MAX."""
    from aiva_agent.cli import _make_stream_renderer
    from agents.stream_events import RunItemStreamEvent

    monkeypatch.setenv("AIVA_STREAM_TOOL_OUTPUT", "1")
    monkeypatch.setenv("AIVA_STREAM_TOOL_OUTPUT_MAX", "10")
    handler, _finalize = _make_stream_renderer()

    class FakeOutputItem:
        type = "tool_call_output_item"
        output = "abcdefghijKLMNOPQRSTUVWXYZ"  # 26 chars; cap=10

    handler(RunItemStreamEvent(name="tool_output", item=FakeOutputItem()))
    captured = capsys.readouterr()
    assert "[tool] done" in captured.err
    assert "abcdefghij…[+16 more chars]" in captured.err


def test_make_stream_renderer_empty_tool_output_no_blank_line(monkeypatch, capsys):
    """Empty tool output should not emit a spurious blank line after [tool] done."""
    from aiva_agent.cli import _make_stream_renderer
    from agents.stream_events import RunItemStreamEvent

    monkeypatch.setenv("AIVA_STREAM_TOOL_OUTPUT", "1")
    monkeypatch.delenv("AIVA_STREAM_TOOL_OUTPUT_MAX", raising=False)
    handler, _finalize = _make_stream_renderer()

    class FakeOutputItem:
        type = "tool_call_output_item"
        output = ""

    handler(RunItemStreamEvent(name="tool_output", item=FakeOutputItem()))
    captured = capsys.readouterr()
    # Exactly one newline (from the [tool] done print). No extra blank line.
    assert captured.err == "[tool] done\n"
