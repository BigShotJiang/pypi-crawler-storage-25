from aiva_agent.agent import (
    ALL_TOOLS,
    _resolve_disabled,
    build_tools_and_cleanup,
)


def test_resolve_disabled_defaults_to_all_when_none():
    assert _resolve_disabled(None) == list(ALL_TOOLS)
    assert _resolve_disabled([]) == list(ALL_TOOLS)


def test_resolve_disabled_drops_named_tools_preserving_order():
    assert _resolve_disabled(["vcf", "web"]) == [
        t for t in ALL_TOOLS if t not in {"vcf", "web"}
    ]


def test_resolve_disabled_ignores_unknown_names():
    assert _resolve_disabled(["bogus", "also_nope"]) == list(ALL_TOOLS)


def test_resolve_disabled_dedupes_input():
    assert _resolve_disabled(["vcf", "vcf", "web"]) == [
        t for t in ALL_TOOLS if t not in {"vcf", "web"}
    ]


def test_resolve_disabled_strips_whitespace():
    assert _resolve_disabled(["  vcf ", " web "]) == [
        t for t in ALL_TOOLS if t not in {"vcf", "web"}
    ]


def test_all_tools_contains_expected_set():
    # `bash` and `manage_todos` are custom @function_tool ports of the
    # Claude-Agent-SDK built-ins (Bash, TodoWrite). The OpenAI Agents SDK
    # ShellTool is wired only into the Responses-API adapter, which we don't use.
    assert set(ALL_TOOLS) == {
        "vcf",
        "annotate",
        "literature",
        "trials",
        "rank_genes",
        "web",
        "classify",
        "bash",
        "manage_todos",
    }


def test_build_tools_web_only():
    tools, cleanups = build_tools_and_cleanup(
        enabled=["web"], vcf_specs=None, model="gpt-5", base_url=None, api_key="test-key"
    )
    assert [t.name for t in tools] == ["web_search"]
    assert cleanups == []


def test_build_tools_literature_only_returns_one_tool():
    tools, cleanups = build_tools_and_cleanup(
        enabled=["literature"], vcf_specs=None, model="gpt-5", base_url=None, api_key=None
    )
    assert [t.name for t in tools] == ["search_biomedical_literature"]
    assert len(cleanups) == 1


def test_build_tools_classify_includes_subagent_dependencies_in_palette():
    tools, _ = build_tools_and_cleanup(
        enabled=["classify"], vcf_specs=None, model="gpt-5", base_url=None, api_key="test-key"
    )
    # Parent agent should expose ONLY classify_variant — annotate/literature/trials live
    # inside the sub-agent, not at the top level.
    assert [t.name for t in tools] == ["classify_variant"]


def test_build_tools_classify_plus_annotate_exposes_both_at_parent():
    tools, _ = build_tools_and_cleanup(
        enabled=["classify", "annotate"], vcf_specs=None, model="gpt-5", base_url=None, api_key="test-key"
    )
    names = sorted(t.name for t in tools)
    assert names == ["annotate_variant", "classify_variant"]


def test_build_tools_vcf_with_single_spec(tmp_path):
    from pathlib import Path

    # vcf tool will fail to actually open the file, but the early ValueError
    # guard should NOT fire when specs is non-empty. Use a small probe: pass a
    # path that doesn't need to exist on the duckhts side because we never
    # actually call build_vcf_tools — instead we mock it.
    import aiva_agent.agent as agent_mod

    captured = {}

    def fake_build_vcf_tools(specs):
        captured["specs"] = specs
        return ([], lambda: None)

    original = agent_mod.build_vcf_tools
    agent_mod.build_vcf_tools = fake_build_vcf_tools
    try:
        tools, cleanups = build_tools_and_cleanup(
            enabled=["vcf"],
            vcf_specs=[("vcf", Path("data/test.vcf.gz"))],
            model="gpt-5",
            base_url=None,
            api_key=None,
        )
    finally:
        agent_mod.build_vcf_tools = original

    assert captured["specs"] == [("vcf", Path("data/test.vcf.gz"))]
    assert len(cleanups) == 1


def test_build_tools_vcf_with_multi_spec(tmp_path):
    from pathlib import Path

    import aiva_agent.agent as agent_mod

    captured = {}

    def fake_build_vcf_tools(specs):
        captured["specs"] = specs
        return ([], lambda: None)

    original = agent_mod.build_vcf_tools
    agent_mod.build_vcf_tools = fake_build_vcf_tools
    try:
        build_tools_and_cleanup(
            enabled=["vcf"],
            vcf_specs=[
                ("proband", Path("p.vcf.gz")),
                ("father", Path("f.vcf.gz")),
                ("mother", Path("m.vcf.gz")),
            ],
            model="gpt-5",
            base_url=None,
            api_key=None,
        )
    finally:
        agent_mod.build_vcf_tools = original

    assert [a for a, _ in captured["specs"]] == ["proband", "father", "mother"]


def test_build_tools_vcf_requires_specs():
    import pytest

    with pytest.raises(ValueError, match="--vcf is required"):
        build_tools_and_cleanup(
            enabled=["vcf"], vcf_specs=None, model="gpt-5", base_url=None, api_key=None
        )
    with pytest.raises(ValueError, match="--vcf is required"):
        build_tools_and_cleanup(
            enabled=["vcf"], vcf_specs=[], model="gpt-5", base_url=None, api_key=None
        )


def test_build_tools_bash_only(tmp_path):
    tools, cleanups = build_tools_and_cleanup(
        enabled=["bash"],
        vcf_specs=None,
        model="gpt-5",
        base_url=None,
        api_key=None,
        workdir=tmp_path,
    )
    assert [t.name for t in tools] == ["run_bash"]
    assert len(cleanups) == 1


def test_build_tools_bash_defaults_to_cwd_when_no_workdir():
    tools, _ = build_tools_and_cleanup(
        enabled=["bash"],
        vcf_specs=None,
        model="gpt-5",
        base_url=None,
        api_key=None,
    )
    # No workdir passed — should default to Path.cwd() without raising.
    assert [t.name for t in tools] == ["run_bash"]


def test_build_tools_manage_todos_only():
    tools, cleanups = build_tools_and_cleanup(
        enabled=["manage_todos"],
        vcf_specs=None,
        model="gpt-5",
        base_url=None,
        api_key=None,
    )
    assert [t.name for t in tools] == ["manage_todos"]
    assert len(cleanups) == 1
