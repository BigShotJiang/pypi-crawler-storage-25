"""Sync entry point for notebooks and scripts.

Example:
    import os
    os.environ["LLM_API_KEY"] = "sk-..."
    os.environ["AIVA_VCF"] = "data/sample.vcf.gz"

    from aiva_agent import aiva_agent
    aiva_agent("list pathogenic variants")
    aiva_agent("what about VUS?")  # shares a session with the call above

Cells in the same kernel share an auto-generated session ID. Set
AIVA_SESSION_ID (env) or pass session_id= to use a stable one.
"""

from __future__ import annotations

import asyncio
import os
import threading
import uuid
from pathlib import Path

from dotenv import load_dotenv

from .agent import DEFAULT_MODEL, run_once

_loop: asyncio.AbstractEventLoop | None = None
_loop_thread: threading.Thread | None = None
_loop_lock = threading.Lock()
_kernel_session_id: str | None = None
_dotenv_loaded = False


def _ensure_loop() -> asyncio.AbstractEventLoop:
    global _loop, _loop_thread
    with _loop_lock:
        if _loop is None or _loop.is_closed():
            ready = threading.Event()
            loop = asyncio.new_event_loop()

            def _run() -> None:
                loop.call_soon(ready.set)
                loop.run_forever()

            _loop = loop
            _loop_thread = threading.Thread(
                target=_run, name="aiva-agent-loop", daemon=True
            )
            _loop_thread.start()
            ready.wait()
        return _loop


def _ensure_dotenv() -> None:
    global _dotenv_loaded
    if not _dotenv_loaded:
        load_dotenv(override=False)
        _dotenv_loaded = True


def _resolve_session_id(explicit: str | None) -> str:
    global _kernel_session_id
    if explicit:
        return explicit
    env = os.environ.get("AIVA_SESSION_ID", "").strip()
    if env:
        return env
    with _loop_lock:
        if _kernel_session_id is None:
            _kernel_session_id = f"aiva-{uuid.uuid4().hex[:12]}"
        return _kernel_session_id


def _resolve_vcf(raw: str) -> list[tuple[str, Path]]:
    from .cli import _parse_vcf_specs

    return _parse_vcf_specs(raw) if raw else []


def _resolve_disabled(disable: list[str] | str | None) -> list[str]:
    if disable is None:
        raw = os.environ.get("AIVA_DISABLE", "")
        return [p.strip() for p in raw.split(",") if p.strip()]
    if isinstance(disable, str):
        return [p.strip() for p in disable.split(",") if p.strip()]
    return list(disable)


def aiva_agent(
    prompt: str,
    *,
    vcf: str | None = None,
    disable: list[str] | str | None = None,
    model: str | None = None,
    base_url: str | None = None,
    api_key: str | None = None,
    session_id: str | None = None,
    workdir: str | Path | None = None,
) -> str:
    """Run the aiva agent synchronously. Returns the final answer string.

    All keyword args fall back to env vars (LLM_MODEL, LLM_BASE_URL,
    LLM_API_KEY, AIVA_VCF, AIVA_DISABLE, AIVA_SESSION_ID, AIVA_WORKDIR). When
    no session_id is supplied, calls within the same Python process share one
    auto-generated ID so notebook cells maintain conversation history by
    default. When no workdir is given, the bash tool runs in the kernel's
    current working directory.
    """
    _ensure_dotenv()

    resolved_model = model or os.environ.get("LLM_MODEL") or DEFAULT_MODEL
    resolved_base_url = base_url or os.environ.get("LLM_BASE_URL")
    resolved_api_key = api_key or os.environ.get("LLM_API_KEY")

    vcf_raw = vcf if vcf is not None else os.environ.get("AIVA_VCF", "")
    vcf_specs = _resolve_vcf(vcf_raw) or None

    disabled_tools = _resolve_disabled(disable)
    if vcf_specs is None and "vcf" not in disabled_tools:
        disabled_tools.append("vcf")

    if workdir is not None:
        resolved_workdir: Path | None = Path(workdir)
    else:
        env_wd = os.environ.get("AIVA_WORKDIR", "").strip()
        resolved_workdir = Path(env_wd) if env_wd else None

    sid = _resolve_session_id(session_id)

    loop = _ensure_loop()
    future = asyncio.run_coroutine_threadsafe(
        run_once(
            prompt,
            vcf_specs=vcf_specs,
            disabled_tools=disabled_tools,
            model=resolved_model,
            base_url=resolved_base_url,
            api_key=resolved_api_key,
            session_id=sid,
            workdir=resolved_workdir,
        ),
        loop,
    )
    return future.result()


def reset_session() -> str:
    """Forget the kernel's auto-generated session ID. Returns the new ID."""
    global _kernel_session_id
    new_id = f"aiva-{uuid.uuid4().hex[:12]}"
    with _loop_lock:
        _kernel_session_id = new_id
    return new_id
