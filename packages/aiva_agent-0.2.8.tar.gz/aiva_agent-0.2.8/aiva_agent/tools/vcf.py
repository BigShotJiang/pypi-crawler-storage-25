import re
from pathlib import Path
from typing import Callable

import duckdb
from agents import function_tool

ROW_LIMIT = 200
_ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Standard VCF columns surfaced by duckhts read_bcf, in display order.
STANDARD_COLS = ("CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER")


def _safe_path(p: Path) -> str:
    return str(p).replace("'", "''")


_DUCKHTS_ERROR_HINT = (
    "Failed to load the duckhts DuckDB extension on this host (likely glibc "
    "too old). Try the published container image: "
    "docker.io/mhspl/aiva-agent:latest\n"
    "Underlying error: {err}"
)


def _open_connection(specs: list[tuple[str, Path]]) -> duckdb.DuckDBPyConnection:
    if not specs:
        raise ValueError("at least one (alias, path) spec is required")
    con = duckdb.connect(":memory:")
    try:
        con.execute("INSTALL duckhts FROM community;")
        con.execute("LOAD duckhts;")
    except Exception as e:
        if "GLIBC_" in str(e):
            raise RuntimeError(_DUCKHTS_ERROR_HINT.format(err=e)) from e
        raise
    for alias, path in specs:
        if not _ALIAS_RE.match(alias):
            raise ValueError(f"invalid view alias: {alias!r}")
        con.execute(
            f"CREATE VIEW {alias} AS SELECT * FROM read_bcf('{_safe_path(path)}')"
        )
    return con


def _format_field_ids(con: duckdb.DuckDBPyConnection, path: Path) -> list[str]:
    """Return the FORMAT field IDs declared in the BCF/VCF header."""
    rows = con.execute(
        f"SELECT id FROM read_hts_header('{_safe_path(path)}') WHERE record_type='FORMAT' ORDER BY idx"
    ).fetchall()
    return [r[0] for r in rows]


def _summarize_view(
    con: duckdb.DuckDBPyConnection, alias: str, path: Path
) -> str:
    """Compact, agent-friendly schema summary for one registered view.

    Splits FORMAT_<FIELD>_<SAMPLE> column names by looking up the canonical
    FORMAT field IDs from the BCF header, so sample IDs containing
    underscores are handled correctly.
    """
    cols = con.execute(f"DESCRIBE {alias}").fetchall()
    standard: list[str] = []
    info: list[str] = []
    format_cols: list[tuple[str, str]] = []
    for name, dtype, *_ in cols:
        if name in STANDARD_COLS:
            standard.append(f"{name} {dtype}")
        elif name.startswith("INFO_"):
            info.append(f"{name} {dtype}")
        elif name.startswith("FORMAT_"):
            format_cols.append((name, dtype))

    field_ids = _format_field_ids(con, path)
    samples: list[str] = []
    seen_samples: set[str] = set()
    field_types: dict[str, str] = {}
    unparsed: list[str] = []
    for name, dtype in format_cols:
        body = name[len("FORMAT_"):]
        matched = False
        for fid in field_ids:
            prefix = fid + "_"
            if body.startswith(prefix):
                sample = body[len(prefix):]
                if sample and sample not in seen_samples:
                    seen_samples.add(sample)
                    samples.append(sample)
                field_types.setdefault(fid, dtype)
                matched = True
                break
        if not matched:
            unparsed.append(name)

    lines = [f"view: {alias}  (path: {path})"]
    lines.append(
        "  standard:  " + ", ".join(standard) if standard else "  standard:  (none)"
    )
    if info:
        lines.append("  INFO:      " + ", ".join(info))
    if samples:
        lines.append(f"  samples ({len(samples)}): " + ", ".join(samples))
    if field_types:
        ordered = [f"{fid} {field_types[fid]}" for fid in field_ids if fid in field_types]
        lines.append(
            "  FORMAT/<sample> (column = FORMAT_<FIELD>_<SAMPLE>): "
            + ", ".join(ordered)
        )
    if unparsed:
        lines.append(f"  unparsed FORMAT columns: {', '.join(unparsed)}")
    return "\n".join(lines)


def _format_rows(cols: list[str], rows: list[tuple]) -> str:
    if not rows:
        return "(0 rows)"
    header = "\t".join(cols)
    body = "\n".join("\t".join(repr(c) if not isinstance(c, str) else c for c in r) for r in rows)
    return f"{header}\n{body}\n({len(rows)} rows)"


def build_vcf_tools(
    vcf_specs: list[tuple[str, Path]],
) -> tuple[list, Callable[[], None]]:
    """Build the duckdb-backed VCF tool palette.

    Each (alias, path) spec is registered as a named DuckDB view. A single
    bare-path invocation should pass `[("vcf", path)]` to keep the legacy
    view name. Returns (tools_list, cleanup_fn). Caller must invoke
    cleanup_fn when the agent run is done so the duckdb connection is closed.
    """
    if not vcf_specs:
        raise ValueError("vcf_specs is required (got empty list)")
    con = _open_connection(vcf_specs)
    specs = list(vcf_specs)

    @function_tool
    async def query_vcf(sql: str) -> str:
        """Run a read-only SQL query against the user's VCF view(s). Each VCF
        is exposed as a DuckDB view named by the user's alias (or `vcf` for a
        single-path invocation). Per-sample FORMAT data is flattened into
        columns named `FORMAT_<FIELD>_<SAMPLE>`. Returns up to 200 rows as TSV.

        Args:
            sql: A SELECT statement. The result is wrapped in `SELECT * FROM (...) LIMIT 200`.
        """
        try:
            res = con.execute(f"SELECT * FROM ({sql}) LIMIT {ROW_LIMIT}")
            rows = res.fetchall()
            cols = [d[0] for d in res.description]
            return _format_rows(cols, rows)
        except Exception as e:
            return f"SQL error: {e}"

    @function_tool
    async def vcf_schema() -> str:
        """Return a compact summary of every registered VCF view: standard
        columns, INFO fields, sample IDs, and per-sample FORMAT field names.
        Call this once at the top of a session before composing queries."""
        blocks = [_summarize_view(con, alias, path) for alias, path in specs]
        return "\n\n".join(blocks)

    def cleanup() -> None:
        try:
            con.close()
        except Exception:
            pass

    return [query_vcf, vcf_schema], cleanup
