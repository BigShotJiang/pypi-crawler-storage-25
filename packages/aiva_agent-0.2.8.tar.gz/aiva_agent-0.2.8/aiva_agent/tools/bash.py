"""Claude-Code-style bash tool: run shell commands in a configured workdir.

The OpenAI Agents SDK ships a ShellTool, but it is wired only into the
Responses-API model adapter. aiva-agent uses OpenAIChatCompletionsModel for
multi-provider support, so we expose shell access via a regular @function_tool
that wraps asyncio.create_subprocess_shell.
"""

from __future__ import annotations

import asyncio
import os
import signal
from pathlib import Path
from typing import Any, Callable

from agents import function_tool

DEFAULT_TIMEOUT_SECONDS = 60
MAX_OUTPUT_CHARS = 8000
# Hard byte cap per stream. Bounds Python memory regardless of how much the
# subprocess writes; once exceeded, the rest is drained and discarded so the
# writer doesn't block on pipe backpressure forever.
MAX_STREAM_BYTES = 256_000


def _truncate_middle(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    keep = max(0, limit // 2 - 64)
    head = text[:keep]
    tail = text[-keep:]
    elided = len(text) - len(head) - len(tail)
    return f"{head}\n...[truncated {elided} chars]...\n{tail}"


async def _read_capped(stream: asyncio.StreamReader, cap: int) -> bytes:
    """Read up to `cap` bytes from `stream`, then drain and discard the rest
    so the writer doesn't block on pipe backpressure.
    """
    buf = bytearray()
    while len(buf) < cap:
        chunk = await stream.read(min(8192, cap - len(buf)))
        if not chunk:
            return bytes(buf)
        buf.extend(chunk)
    while await stream.read(8192):
        pass
    return bytes(buf)


def _kill_group(proc: asyncio.subprocess.Process) -> None:
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass


async def _execute(cwd: str, command: str, timeout_seconds: int) -> str:
    if timeout_seconds <= 0:
        timeout_seconds = DEFAULT_TIMEOUT_SECONDS

    # start_new_session puts the shell in its own process group so SIGKILL
    # cascades to children (python/duckdb invocations the agent spawns).
    proc = await asyncio.create_subprocess_shell(
        command,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=os.environ.copy(),
        start_new_session=True,
    )

    assert proc.stdout is not None and proc.stderr is not None
    timed_out = False
    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            asyncio.gather(
                _read_capped(proc.stdout, MAX_STREAM_BYTES),
                _read_capped(proc.stderr, MAX_STREAM_BYTES),
            ),
            timeout=timeout_seconds,
        )
        await proc.wait()
    except asyncio.TimeoutError:
        # On timeout, _read_capped tasks were cancelled mid-read and the
        # StreamReader buffers are in an indeterminate state. Don't try to
        # recover partial bytes via communicate() — that races on the same
        # readers. Kill the process group, reap the exit, and report empty.
        timed_out = True
        stdout_bytes, stderr_bytes = b"", b""
        _kill_group(proc)
        try:
            await asyncio.wait_for(proc.wait(), timeout=5)
        except (asyncio.TimeoutError, Exception):
            pass

    stdout = stdout_bytes.decode("utf-8", errors="replace")
    stderr = stderr_bytes.decode("utf-8", errors="replace")

    parts: list[str] = []
    if timed_out:
        parts.append(f"timeout after {timeout_seconds}s (process group killed)")
    if stdout:
        parts.append(f"stdout:\n{stdout.rstrip()}")
    if stderr:
        parts.append(f"stderr:\n{stderr.rstrip()}")
    parts.append(f"exit_code: {proc.returncode}")

    return _truncate_middle("\n\n".join(parts), MAX_OUTPUT_CHARS)


def build_bash_tool(workdir: Path) -> tuple[Any, Callable[[], None]]:
    """Build a shell-command tool scoped to `workdir`.

    Returns (tool, cleanup_fn) for shape consistency with other build_* helpers.
    Cleanup is a no-op (no persistent process), but the tuple keeps
    build_tools_and_cleanup symmetric.
    """
    cwd = str(workdir.resolve())

    @function_tool
    async def run_bash(command: str, timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS) -> str:
        """Run a shell command in the agent's working directory and return its
        output. Use this for ad-hoc data work: list files, peek at CSVs, query
        them with `duckdb -c`, run `python -c "..."` scripts, etc.

        Args:
            command: The shell command to execute. Runs via /bin/sh -c.
            timeout_seconds: Wall-clock timeout. Defaults to 60s. Bump to 180+
                for slow operations like `pip install`.

        Returns:
            A formatted block with stdout, stderr (if non-empty), and the
            exit code. Combined output is capped at ~8000 chars.
        """
        return await _execute(cwd, command, timeout_seconds)

    def cleanup() -> None:
        return None

    return run_bash, cleanup
