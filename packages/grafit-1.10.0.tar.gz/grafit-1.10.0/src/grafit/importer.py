import hashlib
import logging
import re
from collections import defaultdict
from datetime import datetime, time
from pathlib import Path

import fitparse

from grafit.db import Database
from grafit.models import ImportResult, BatchImportResult

logger = logging.getLogger(__name__)


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


_DATE_RE = re.compile(r"\b(19|20)(\d{2})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b")


def _generate_file_id(fit_path):
    dir_name = fit_path.parent.name
    stem = fit_path.stem
    m = _DATE_RE.search(stem)
    if m:
        date_str = m.group(1) + m.group(2) + m.group(3) + m.group(4)
        return f"{dir_name}_{stem}_{date_str}"
    return f"{dir_name}_{stem}"


def _convert_value(val):
    if val is None:
        return None
    if isinstance(val, datetime):
        return int(val.timestamp())
    if isinstance(val, time):
        return val.hour * 3600 + val.minute * 60 + val.second
    if isinstance(val, bool):
        return int(val)
    if isinstance(val, (int, float, str)):
        return val
    if isinstance(val, bytes):
        return val
    if isinstance(val, tuple):
        return ",".join(str(v) for v in val)
    return str(val)


def import_file(db, fit_path, force=False, seen_unknown_types=None):
    if seen_unknown_types is None:
        seen_unknown_types = set()
    fit_path = Path(fit_path)
    if not fit_path.exists():
        return ImportResult(
            file_path=str(fit_path), file_hash="", status="error",
            error_message=f"File not found: {fit_path}",
        )

    fhash = file_hash(fit_path)

    if not force and db.is_imported(fhash):
        return ImportResult(
            file_path=str(fit_path), file_hash=fhash, status="skipped",
        )

    if force:
        db.purge_file(fhash)

    try:
        fit = fitparse.FitFile(str(fit_path))
        messages = list(fit.get_messages())
    except (fitparse.FitParseError, fitparse.FitEOFError, fitparse.FitCRCError,
            fitparse.FitHeaderError) as e:
        result = ImportResult(
            file_path=str(fit_path), file_hash=fhash, status="error",
            error_message=str(e),
        )
        db.log_import(
            fhash, str(fit_path), "", fit_path.parent.name,
            fit_path.stat().st_size, 0, "error", str(e),
        )
        db.conn.commit()
        return result

    file_id = _generate_file_id(fit_path)
    batches = defaultdict(list)
    overflow_rows = []
    tables_affected = set()
    msg_count = 0

    for message in messages:
        msg_name = message.name
        known_cols = db.table_columns(msg_name)
        if not known_cols:
            if msg_name not in seen_unknown_types:
                seen_unknown_types.add(msg_name)
                logger.warning(
                    "Unknown message type %r (first seen in %s) — skipping. "
                    "Re-import with --force after upgrading fitparse to ingest.",
                    msg_name, fit_path.name,
                )
            continue

        row = {"file_hash": fhash}
        msg_count += 1

        msg_timestamp = None
        for field_data in message.fields:
            if field_data.name and field_data.name.lower() == "timestamp":
                msg_timestamp = _convert_value(field_data.value)
                break

        for field_data in message.fields:
            name = field_data.name.lower() if field_data.name else None
            if name is None:
                continue

            val = _convert_value(field_data.value)
            if val is None:
                continue

            if name in known_cols:
                row[name] = val
            else:
                overflow_rows.append({
                    "file_hash": fhash,
                    "message_type": msg_name,
                    "timestamp": msg_timestamp,
                    "field_name": name,
                    "field_value": str(val) if not isinstance(val, str) else val,
                    "field_units": field_data.units,
                    "field_type": field_data.field_type,
                })

        batches[msg_name].append(row)
        tables_affected.add(msg_name)

    try:
        with db.transaction():
            for table_name, rows in batches.items():
                _normalize_batch(rows)
                db.insert_rows(table_name, rows)

            if overflow_rows:
                db.insert_rows("_field_overflow", overflow_rows)

            db.log_import(
                fhash, str(fit_path), file_id, fit_path.parent.name,
                fit_path.stat().st_size, msg_count,
            )
    except Exception as e:
        logger.error("Failed to import %s: %s", fit_path.name, e)
        try:
            db.log_import(
                fhash, str(fit_path), file_id, fit_path.parent.name,
                fit_path.stat().st_size, 0, "error", str(e),
            )
            db.conn.commit()
        except Exception:
            pass
        return ImportResult(
            file_path=str(fit_path), file_hash=fhash, file_id=file_id,
            status="error", error_message=str(e),
        )

    return ImportResult(
        file_path=str(fit_path), file_hash=fhash, file_id=file_id,
        status="success", message_count=msg_count,
        tables_affected=sorted(tables_affected),
    )


def _normalize_batch(rows):
    all_keys = set()
    for row in rows:
        all_keys.update(row.keys())
    for row in rows:
        for key in all_keys:
            row.setdefault(key, None)


def import_directory(db, path, force=False, recursive=True):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")

    if path.is_file():
        result = import_file(db, path, force)
        batch = BatchImportResult()
        batch.add(result)
        return batch

    pattern = "**/*.[fF][iI][tT]" if recursive else "*.[fF][iI][tT]"
    fit_files = sorted(path.glob(pattern), key=lambda p: p.name)

    batch = BatchImportResult()
    seen_unknown_types = set()
    for fp in fit_files:
        if fp.suffix.lower() == ".fit":
            result = import_file(db, fp, force, seen_unknown_types=seen_unknown_types)
            batch.add(result)
            if result.status == "success":
                logger.info("Imported %s (%d messages)", fp.name, result.message_count)
            elif result.failed:
                logger.warning("Failed %s: %s", fp.name, result.error_message)

    return batch
