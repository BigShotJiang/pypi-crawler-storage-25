import sqlite3
from contextlib import contextmanager
from pathlib import Path

from grafit.schema import generate_full_schema

PRAGMAS = [
    "PRAGMA journal_mode = WAL",
    "PRAGMA cache_size = -65536",
    "PRAGMA synchronous = NORMAL",
    "PRAGMA foreign_keys = ON",
    "PRAGMA temp_store = MEMORY",
]


class Database:
    def __init__(self, path):
        self.path = str(path)
        self._conn = None
        self._column_cache = {}

    def connect(self):
        self._conn = sqlite3.connect(self.path)
        self._conn.row_factory = sqlite3.Row
        for pragma in PRAGMAS:
            self._conn.execute(pragma)
        return self

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None
        self._column_cache.clear()

    def __enter__(self):
        return self.connect()

    def __exit__(self, *exc):
        self.close()

    @property
    def conn(self):
        if self._conn is None:
            raise RuntimeError("Database not connected")
        return self._conn

    def init_schema(self):
        schema_sql = generate_full_schema()
        self.conn.executescript(schema_sql)
        self.conn.execute(
            "INSERT OR IGNORE INTO _schema_meta (key, value) VALUES (?, ?)",
            ("schema_version", "1.0.0"),
        )
        self.conn.commit()

    @contextmanager
    def transaction(self):
        try:
            yield self.conn
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def table_columns(self, table_name):
        if table_name not in self._column_cache:
            try:
                cursor = self.conn.execute(f"PRAGMA table_info(\"{table_name}\")")
                self._column_cache[table_name] = {row["name"] for row in cursor.fetchall()}
            except sqlite3.OperationalError:
                self._column_cache[table_name] = set()
        return self._column_cache[table_name]

    def insert_rows(self, table_name, rows):
        if not rows:
            return
        columns = sorted(rows[0].keys())
        placeholders = ", ".join("?" for _ in columns)
        col_names = ", ".join(f'"{c}"' for c in columns)
        sql = f'INSERT INTO "{table_name}" ({col_names}) VALUES ({placeholders})'
        values = [tuple(row.get(c) for c in columns) for row in rows]
        self.conn.executemany(sql, values)

    def is_imported(self, file_hash):
        cursor = self.conn.execute(
            "SELECT 1 FROM _import_log WHERE file_hash = ? AND status = 'success'",
            (file_hash,),
        )
        return cursor.fetchone() is not None

    def log_import(self, file_hash, file_path, file_id, file_dir, file_size, message_count,
                   status="success", error_message=None):
        self.conn.execute(
            """INSERT OR REPLACE INTO _import_log
            (file_hash, file_path, file_id, file_dir, file_size, message_count, status, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (file_hash, file_path, file_id, file_dir, file_size, message_count, status, error_message),
        )

    def purge_file(self, file_hash):
        tables = self._get_all_data_tables()
        count = 0
        with self.transaction():
            for table in tables:
                cols = self.table_columns(table)
                if "file_hash" in cols:
                    cursor = self.conn.execute(f'DELETE FROM "{table}" WHERE file_hash = ?', (file_hash,))
                    count += cursor.rowcount
            self.conn.execute("DELETE FROM _import_log WHERE file_hash = ?", (file_hash,))
            self.conn.execute("DELETE FROM _field_overflow WHERE file_hash = ?", (file_hash,))
        return count

    def get_stats(self):
        tables = self._get_all_data_tables()
        stats = {}
        for table in sorted(tables):
            try:
                cursor = self.conn.execute(f'SELECT COUNT(*) as cnt FROM "{table}"')
                row = cursor.fetchone()
                cnt = row["cnt"] if row else 0
                if cnt > 0:
                    stats[table] = cnt
            except sqlite3.OperationalError:
                continue
        return stats

    def _get_all_data_tables(self):
        cursor = self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
            " AND name NOT LIKE '\\_%%' ESCAPE '\\'"
            " AND name != 'sqlite_sequence'",
        )
        return [row["name"] for row in cursor.fetchall()]
