"""NetworkClient — client interface for multi-agent sessions.

Spec: client.qnt

User-facing entry point for multi-agent coordination. Takes per-agent
(AgentDef, sources) pairs, validates the configuration, and drives
turns through NetworkRunner.

    client = NetworkClient(
        agents={
            "parent": (parent_def, {"llm": claude, "tools": deleg_source}),
            "child": (child_def, {"llm": gpt, "tools": search_source}),
        },
        entry_point="parent",
        delegation_routes=[("parent", "child")],
    )
    async for event in client.send_message("hello"):
        print(event)
"""

from __future__ import annotations

from collections.abc import AsyncIterator

from gamelan.network_runner import (
    AgentDef,
    AgentRegistration,
    ClientConfigError,
    NetworkRunner,
    SessionEvent,
    validate_client_config,
)
from gamelan.source import Source


class NetworkClient:
    """Client interface for multi-agent sessions.

    Validates config per client.qnt, then wraps a NetworkRunner.
    Sources are per-agent — no shared source registry.
    """

    def __init__(
        self,
        agents: dict[str, tuple[AgentDef, dict[str, Source]]],
        *,
        delegation_routes: list[tuple[str, str]] | None = None,
        handoff_routes: list[tuple[str, str]] | None = None,
        entry_point: str,
    ):
        # Build registrations
        registrations = {
            name: AgentRegistration(agent_def=agent_def, sources=sources)
            for name, (agent_def, sources) in agents.items()
        }

        # Validate per client.qnt client_config_valid
        validate_client_config(
            registrations,
            delegation_routes or [],
            handoff_routes or [],
            entry_point,
        )

        self._runner = NetworkRunner(
            registrations,
            delegation_routes=delegation_routes,
            handoff_routes=handoff_routes,
            entry_point=entry_point,
        )

    # ── Primary API ──────────────────────────────────────

    async def send_message(self, text: str) -> AsyncIterator[SessionEvent]:
        """Send a user message. Yields events as the turn progresses."""
        async for event in self._runner.run_turn("UserMessage", {"text": text}):
            yield event

    # ── State queries ────────────────────────────────────

    @property
    def active_agent(self) -> str:
        return self._runner.active_agent

    @property
    def delegation_graph(self) -> list[dict]:
        return self._runner.network.delegation_graph()

    def delegated_agents(self) -> list[str]:
        return [d["dst"] for d in self.delegation_graph]

    def has_runner(self, agent: str) -> bool:
        return self._runner.has_runner(agent)
