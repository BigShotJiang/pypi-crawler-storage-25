"""Delegation sources — tool shape adapters bridging agent fold and network fold.

Source implementations that convert agent-level tool calls into delegation
operations. Each source adapts tool call shapes (names, arguments, schemas)
and optionally executes the delegation via a DelegationAwaiter.

Two delegation models:
- SyncDelegationSource — one tool per child. Tool call → delegate → ToolResult.
- AsyncDelegationSource — spawn/wait tools. spawn → delegate, wait → collect results.

Without an awaiter, dispatch returns raw DelegationRequest/WaitDelegation
events (pure adapter mode). With an awaiter, dispatch drives the delegation
to completion and returns ToolResult.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from typing import Callable, Awaitable

from gamelan.source import Source


# ════════════════════════════════════════════════════════════════
# DelegationAwaiter
# ════════════════════════════════════════════════════════════════


DelegateFn = Callable[[str, str, str], Awaitable[str | None]]
"""(parent_id, child_name, message) → result text or None."""


@dataclass
class DelegationAwaiter:
    """Drives delegation and returns the child's result.

    Wraps a delegate function provided by the SessionManager. When
    delegate() is called, fires spawn_delegation (non-blocking) and
    awaits the result.

    Default timeout: 300 seconds (5 minutes).
    """

    delegate_fn: DelegateFn
    parent_id: str
    timeout: float = 300.0

    async def delegate(self, child: str, message: str) -> str | None:
        """Execute a delegation and return the result."""
        return await asyncio.wait_for(
            self.delegate_fn(self.parent_id, child, message),
            timeout=self.timeout,
        )


def _make_tool_result(tool_call_id: str, result: str | None) -> tuple[str, dict]:
    """Format a delegation result as a ToolResult event."""
    text = result or "(no output)"
    return ("ToolResult", {
        "key": f"ToolRequest:{tool_call_id}",
        "tool_call_id": tool_call_id,
        "content": [{"content_type": "text", "text": text}],
    })


# ════════════════════════════════════════════════════════════════
# SyncDelegationSource
# ════════════════════════════════════════════════════════════════


class SyncDelegationSource:
    """Synchronous delegation: one tool per child agent.

    Each registered child name becomes a tool. On dispatch, either
    drives delegation via awaiter (returning ToolResult) or returns
    raw DelegationRequest (pure adapter mode).
    """

    def __init__(self):
        self._children: list[str] = []
        self._awaiter: DelegationAwaiter | None = None

    def with_network(self, awaiter: DelegationAwaiter) -> "SyncDelegationSource":
        """Wire to network for delegation execution."""
        self._awaiter = awaiter
        return self

    def with_child(self, name: str) -> "SyncDelegationSource":
        """Register a child agent name as a delegation tool."""
        self._children.append(name)
        return self

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        tool_name = request_data.get("name", "")
        if tool_name not in self._children:
            raise LookupError(f"unknown tool: {tool_name}")

        tool_call_id = request_data.get("id", "")
        args_str = request_data.get("arguments", "{}")
        try:
            args = json.loads(args_str)
        except (json.JSONDecodeError, TypeError):
            args = {}
        message = args.get("message", "")

        if self._awaiter:
            result = await self._awaiter.delegate(tool_name, message)
            return _make_tool_result(tool_call_id, result)

        # Pure adapter mode
        return ("DelegationRequest", {"child": tool_name, "message": message})

    def interface(self) -> list[dict]:
        return [{"request_type": "ToolRequest", "result_type": "ToolResult"}]

    async def discover(self) -> list[dict]:
        """Tool schemas for LLM."""
        return [
            {
                "name": name,
                "description": f"Delegate a task to the {name} agent",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "message": {"type": "string", "description": "Task for the agent"}
                    },
                    "required": ["message"],
                },
            }
            for name in self._children
        ]


# ════════════════════════════════════════════════════════════════
# AsyncDelegationSource
# ════════════════════════════════════════════════════════════════


class AsyncDelegationSource:
    """Async (two-phase) delegation: spawn_agent + wait_agent tools.

    spawn_agent fires off delegation in the background (returns immediately).
    wait_agent joins in-flight tasks and collects results.
    Multiple spawns fan out concurrently.
    """

    def __init__(self):
        self._children: list[str] = []
        self._awaiter: DelegationAwaiter | None = None
        self._in_flight: dict[str, asyncio.Task] = {}

    def with_network(self, awaiter: DelegationAwaiter) -> "AsyncDelegationSource":
        """Wire to network for delegation execution."""
        self._awaiter = awaiter
        return self

    def with_child(self, name: str) -> "AsyncDelegationSource":
        """Register a child agent name."""
        self._children.append(name)
        return self

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        tool_name = request_data.get("name", "")
        tool_call_id = request_data.get("id", "")
        args_str = request_data.get("arguments", "{}")
        try:
            args = json.loads(args_str)
        except (json.JSONDecodeError, TypeError):
            args = {}

        if tool_name == "spawn_agent":
            return await self._handle_spawn(tool_call_id, args)
        elif tool_name == "wait_agent":
            return await self._handle_wait(tool_call_id, args)
        else:
            raise LookupError(f"unknown tool: {tool_name}")

    async def _handle_spawn(self, tool_call_id: str, args: dict) -> tuple[str, dict]:
        definition = args.get("definition", "")
        if definition not in self._children:
            raise LookupError(f"spawn_agent: unknown definition '{definition}'")

        message = args.get("message", "")
        nickname = args.get("nickname", definition)

        if self._awaiter:
            awaiter = self._awaiter
            task = asyncio.create_task(awaiter.delegate(definition, message))
            self._in_flight[nickname] = task
            return _make_tool_result(
                tool_call_id,
                f"Spawned agent '{nickname}'. Use wait_agent to collect results.",
            )

        # Pure adapter mode
        return ("DelegationRequest", {
            "child": definition,
            "message": message,
            "nickname": nickname,
        })

    async def _handle_wait(self, tool_call_id: str, args: dict) -> tuple[str, dict]:
        handles: list[str] = args.get("handles", [])

        if self._awaiter is not None:
            targets = handles if handles else list(self._in_flight.keys())
            results = []

            for name in targets:
                task = self._in_flight.pop(name, None)
                if task is not None:
                    try:
                        result = await task
                        results.append(f"[{name}]: {result or '(no output)'}")
                    except Exception as e:
                        results.append(f"[{name}]: error: {e}")

            text = "\n\n".join(results) if results else "No matching handles found."
            return _make_tool_result(tool_call_id, text)

        # Pure adapter mode
        return ("WaitDelegation", {"handles": handles})

    def interface(self) -> list[dict]:
        return [{"request_type": "ToolRequest", "result_type": "ToolResult"}]

    async def discover(self) -> list[dict]:
        """Tool schemas for LLM."""
        return [
            {
                "name": "spawn_agent",
                "description": (
                    f"Spawn an agent in the background. Available types: "
                    f"{', '.join(self._children)}. Returns a handle ID."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "definition": {
                            "type": "string",
                            "enum": self._children,
                            "description": "Agent type to spawn",
                        },
                        "message": {"type": "string", "description": "Task for the agent"},
                        "nickname": {
                            "type": "string",
                            "description": "Optional short name for this agent instance",
                        },
                    },
                    "required": ["definition", "message"],
                },
            },
            {
                "name": "wait_agent",
                "description": "Wait for spawned agents to complete and return their results.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "handles": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Handle IDs to wait for. If omitted, waits for all.",
                        }
                    },
                },
            },
        ]
