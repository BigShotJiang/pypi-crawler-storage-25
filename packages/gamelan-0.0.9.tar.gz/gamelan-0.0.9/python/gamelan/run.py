"""Turn driver — the host walk pattern as a Python async generator.

Two core calls per event: check_inbound → fold_event. The host walks
the resulting requests using its native async model (generators here).

    driver = turn_driver(runner, router, "LlmResponse", event_data)
    step = await driver.__anext__()
    while not isinstance(step, Complete):
        match step:
            case DispatchReady(...):
                step = await driver.asend((result_tag, result_data))
            case CheckNeeded(...):
                step = await driver.asend(verdict)

`run_turn` is a convenience wrapper that drives the generator with callbacks.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, AsyncGenerator, Awaitable, Callable, Protocol, Union, runtime_checkable

from gamelan.check import (
    Approve,
    CheckVerdict,
    OutboundCheckEntry,
    Reject,
    Transform,
)
from gamelan.router import Router
from gamelan.runner import RunnerEvent, SessionRunner


# ════════════════════════════════════════════════════════════════
# TurnHook — lifecycle instrumentation protocol
# ════════════════════════════════════════════════════════════════


@runtime_checkable
class TurnHook(Protocol):
    """Lifecycle hooks for turn instrumentation."""

    def on_turn_start(self, event_tag: str, event_data: dict) -> Any: ...
    def on_turn_end(self, events: list[RunnerEvent], error: Exception | None, ctx: Any) -> None: ...
    def on_dispatch_start(self, request_type: str, source_id: str, request_data: dict, turn_ctx: Any) -> Any: ...
    def on_dispatch_end(self, request_type: str, result: tuple[str, dict] | None, error: bool, ctx: Any) -> None: ...
    def on_check_start(self, event_tag: str, source_id: str, event_data: dict, turn_ctx: Any) -> Any: ...
    def on_check_end(self, event_tag: str, verdict: CheckVerdict, ctx: Any) -> None: ...


# ════════════════════════════════════════════════════════════════
# TurnStep — yielded by the turn driver
# ════════════════════════════════════════════════════════════════


@dataclass
class TurnStep:
    """Base class for turn steps."""
    pass


@dataclass
class DispatchReady(TurnStep):
    """A dispatch is ready for the host to execute."""
    request_type: str
    source_id: str
    request_data: dict


@dataclass
class CheckNeeded(TurnStep):
    """A check is needed before dispatch (or before fold for inbound)."""
    event_tag: str
    source_id: str
    event_data: dict
    is_inbound: bool = False


@dataclass
class Complete(TurnStep):
    """Turn reached quiescence."""
    events: list[RunnerEvent]


# ════════════════════════════════════════════════════════════════
# Observation events
# ════════════════════════════════════════════════════════════════


@dataclass
class TurnEvent:
    pass

@dataclass
class Dispatched(TurnEvent):
    request_type: str
    result_tag: str

@dataclass
class DispatchFailed(TurnEvent):
    request_type: str

@dataclass
class CheckResolved(TurnEvent):
    event_tag: str
    verdict: CheckVerdict


# ════════════════════════════════════════════════════════════════
# turn_driver — the host walk pattern as async generator
# ════════════════════════════════════════════════════════════════


async def turn_driver(
    runner: SessionRunner,
    resolve_source: Callable[[str], str | None],
    event_tag: str,
    event_data: dict,
    *,
    hooks: list[TurnHook] | None = None,
) -> AsyncGenerator[TurnStep, Union[tuple[str, dict], CheckVerdict, None]]:
    """Walk one turn using the two-operation fold API.

    For each event in the queue:
    1. check_inbound → if needed, yield CheckNeeded for verdict
    2. fold_event → get classified requests
    3. For each request: if CheckThenDispatch, yield CheckNeeded first
    4. Yield DispatchReady → host dispatches → result enqueued

    The host sends results back via asend().
    """
    _hooks = hooks or []
    turn_ctxs = [h.on_turn_start(event_tag, event_data) for h in _hooks]

    event_queue: deque[tuple[str, dict]] = deque([(event_tag, event_data)])
    all_events: list[RunnerEvent] = []
    error: Exception | None = None

    try:
        while event_queue:
            tag, data = event_queue.popleft()

            # 1. Inbound check (before fold)
            inbound = runner.check_inbound(tag, data)
            if inbound:
                check_ctxs = [
                    h.on_check_start(inbound.event_tag, inbound.check_source, data, tc)
                    for h, tc in zip(_hooks, turn_ctxs)
                ]

                verdict = yield CheckNeeded(
                    event_tag=inbound.event_tag,
                    source_id=inbound.check_source,
                    event_data=data,
                    is_inbound=True,
                )

                for h, cc in zip(_hooks, check_ctxs):
                    h.on_check_end(inbound.event_tag, verdict, cc)

                # Inbound verdicts: InboundApprove or InboundTransform only (no reject).
                # Legacy CheckVerdict is also accepted for backward compat.
                from gamelan.check import InboundTransform, InboundApprove
                if isinstance(verdict, InboundTransform) and verdict.data:
                    new_data = dict(verdict.data)
                    tag = new_data.pop("event_tag", tag)
                    data = new_data
                elif isinstance(verdict, Reject):
                    # Legacy path: should not happen with InboundVerdict.
                    # If it does, treat as approve per spec (no inbound reject).
                    pass
                elif isinstance(verdict, Transform) and verdict.data:
                    # Legacy CheckVerdict Transform — map to inbound transform
                    new_data = dict(verdict.data)
                    tag = new_data.pop("event_tag", tag)
                    data = new_data

            # 2. Emit event entering fold
            all_events.append(RunnerEvent(
                type="event",
                event_tag=tag,
                event_data=data,
            ))

            # 3. Fold
            result = runner.fold_event(tag, data)

            # 4. Walk requests
            for req in result.requests:
                request_data = req.request
                request_type = req.request_type

                # Outbound check if needed
                if req.needs_check:
                    check_ctxs = [
                        h.on_check_start(request_type, req.check_source, request_data, tc)
                        for h, tc in zip(_hooks, turn_ctxs)
                    ]

                    verdict = yield CheckNeeded(
                        event_tag=request_type,
                        source_id=req.check_source,
                        event_data=request_data,
                    )

                    for h, cc in zip(_hooks, check_ctxs):
                        h.on_check_end(request_type, verdict, cc)

                    if isinstance(verdict, Reject):
                        runner.cancel_request(request_type)
                        continue
                    if isinstance(verdict, Transform) and verdict.data:
                        request_data = verdict.data

                    all_events.append(RunnerEvent(
                        type="check_triggered",
                        event_tag=request_type,
                        source_id=req.check_source,
                    ))

                # Dispatch
                source_id = resolve_source(request_type) or ""

                dispatch_ctxs = [
                    h.on_dispatch_start(request_type, source_id, request_data, tc)
                    for h, tc in zip(_hooks, turn_ctxs)
                ]

                response = yield DispatchReady(
                    request_type=request_type,
                    source_id=source_id,
                    request_data=request_data,
                )

                if response is None:
                    for h, dc in zip(_hooks, dispatch_ctxs):
                        h.on_dispatch_end(request_type, None, True, dc)
                    # Synthesize error result event
                    error_tag = f"{request_type}Result"
                    event_queue.append((error_tag, {"status": "error", "error": "dispatch failed"}))
                elif isinstance(response, list):
                    # Multiple results from a single dispatch — enqueue all
                    for h, dc in zip(_hooks, dispatch_ctxs):
                        h.on_dispatch_end(request_type, response[0] if response else None, False, dc)
                    for item in response:
                        if isinstance(item, tuple) and len(item) == 2:
                            event_queue.append(item)
                        elif isinstance(item, dict) and "result_tag" in item:
                            event_queue.append((item["result_tag"], item.get("result_data", {})))
                    all_events.append(RunnerEvent(
                        type="dispatched",
                        request_type=request_type,
                        source_id=source_id,
                    ))
                elif isinstance(response, tuple) and len(response) == 2:
                    for h, dc in zip(_hooks, dispatch_ctxs):
                        h.on_dispatch_end(request_type, response, False, dc)
                    event_queue.append(response)

                    all_events.append(RunnerEvent(
                        type="dispatched",
                        request_type=request_type,
                        source_id=source_id,
                    ))
                else:
                    for h, dc in zip(_hooks, dispatch_ctxs):
                        h.on_dispatch_end(request_type, None, True, dc)
                    raise TypeError(
                        f"DispatchReady expects (result_tag, result_data) tuple or list of tuples, got {type(response).__name__}"
                    )

    except Exception as exc:
        error = exc
        raise
    finally:
        for h, tc in zip(_hooks, turn_ctxs):
            h.on_turn_end(all_events, error, tc)

    # Turn complete
    if runner.is_idle:
        all_events.append(RunnerEvent(type="turn_complete"))

    yield Complete(events=all_events)


# ════════════════════════════════════════════════════════════════
# Default callbacks
# ════════════════════════════════════════════════════════════════


async def _noop(event: TurnEvent) -> None:
    pass


def _make_default_check(
    outbound_checks: list[OutboundCheckEntry],
) -> Callable[[str, dict], Awaitable[CheckVerdict]]:
    async def default_check(event_tag: str, event_data: dict) -> CheckVerdict:
        entry = next(
            (c for c in outbound_checks if c.request_type == event_tag),
            None,
        )
        if entry:
            return await entry.check.check(event_tag, event_data)
        return Approve()

    return default_check


def _make_default_dispatch(
    router: Router,
    tool_schemas: list[dict],
) -> Callable[[str, dict], Awaitable[tuple[str, dict]]]:
    async def default_dispatch(
        request_type: str, request_data: dict
    ) -> tuple[str, dict]:
        conn = router.resolve(request_type)
        if conn is None:
            raise LookupError(f"no source for {request_type}")

        source_data = dict(request_data)
        if request_type == "LlmRequest" and tool_schemas:
            source_data["tools"] = tool_schemas

        return await conn.source.dispatch(request_type, source_data)

    return default_dispatch


# ════════════════════════════════════════════════════════════════
# run_turn — convenience wrapper
# ════════════════════════════════════════════════════════════════


async def run_turn(
    runner: SessionRunner,
    router: Router,
    outbound_checks: list[OutboundCheckEntry],
    event_tag: str,
    event_data: dict,
    *,
    dispatch: Callable[[str, dict], Awaitable[tuple[str, dict]]] | None = None,
    check: Callable[[str, dict], Awaitable[CheckVerdict]] | None = None,
    observe: Callable[[TurnEvent], Awaitable[None]] | None = None,
    hooks: list[TurnHook] | None = None,
) -> list[RunnerEvent]:
    """Drive one turn to completion."""
    tool_schemas = await discover_tools(router)
    do_dispatch = dispatch or _make_default_dispatch(router, tool_schemas)
    do_check = check or _make_default_check(outbound_checks)
    do_observe = observe or _noop

    resolve_source = router.source_resolver()

    driver = turn_driver(runner, resolve_source, event_tag, event_data, hooks=hooks)
    step = await driver.__anext__()

    while not isinstance(step, Complete):
        if isinstance(step, CheckNeeded):
            verdict = await do_check(step.event_tag, step.event_data)
            await do_observe(CheckResolved(step.event_tag, verdict))
            step = await driver.asend(verdict)

        elif isinstance(step, DispatchReady):
            try:
                result_tag, result_data = await do_dispatch(
                    step.request_type, step.request_data
                )
                await do_observe(Dispatched(step.request_type, result_tag))
                step = await driver.asend((result_tag, result_data))
            except Exception as exc:
                await do_observe(DispatchFailed(step.request_type))
                # Synthesize error result
                error_tag = f"{step.request_type}Result"
                step = await driver.asend((error_tag, {"status": "error", "error": str(exc)}))

        else:
            break

    if isinstance(step, Complete):
        return step.events
    return []


# ════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════


async def discover_tools(router: Router) -> list[dict]:
    """Collect tool schemas from all sources that support discovery."""
    schemas: list[dict] = []
    for conn in router.connections:
        if hasattr(conn.source, "discover"):
            try:
                tools = await conn.source.discover()
                schemas.extend(tools)
            except Exception:
                pass
    return schemas
