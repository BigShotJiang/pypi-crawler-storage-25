"""LLM providers — optional Source implementations for different APIs.

Install extras to use:
    pip install gamelan[anthropic]   # AnthropicSource
    pip install gamelan[openai]      # OpenAISource
    pip install gamelan[litellm]     # LiteLLMSource
    pip install gamelan[all]         # everything
"""
