"""OpenAISource — wraps the OpenAI Python SDK.

Implements Source protocol: dispatches LlmRequest, returns LlmResponse.
Handles text responses, tool calls, and tool schemas.

Requires: pip install gamelan[openai]
"""

from __future__ import annotations

import json
from typing import Any


LLM_PAIR = {"request_type": "LlmRequest", "result_type": "LlmResponse"}


class OpenAISource:
    """OpenAI Chat Completions API source."""

    def __init__(
        self,
        model: str = "gpt-4o",
        max_tokens: int = 4096,
        api_key: str | None = None,
        **client_kwargs,
    ):
        try:
            from openai import AsyncOpenAI
        except ImportError:
            raise ImportError(
                "openai package required. Install with: pip install gamelan[openai]"
            )

        self._model = model
        self._max_tokens = max_tokens
        self._client = AsyncOpenAI(api_key=api_key, **client_kwargs)

    def interface(self) -> list[dict]:
        return [LLM_PAIR]

    async def dispatch(
        self, request_tag: str, request_data: dict
    ) -> tuple[str, dict]:
        context = request_data.get("context", [])
        tools_raw = request_data.get("tools", [])

        messages = _build_messages(context)
        tools = _build_tools(tools_raw)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools

        response = await self._client.chat.completions.create(**kwargs)

        return _parse_response(response)


# ── Parse: OpenAI → canonical ────────────────────────────────


def _parse_response(response) -> tuple[str, dict]:
    """Convert OpenAI response to gamelan LlmResponse.

    Normalizes to canonical parts format (kind). Tool calls extracted separately.
    """
    choice = response.choices[0]
    msg = choice.message
    parts = []
    tool_calls = []

    # Text content → canonical part
    if msg.content:
        parts.append({"kind": "text", "text": msg.content})

    # Tool calls → normalized field (not in parts)
    if msg.tool_calls:
        for tc in msg.tool_calls:
            tool_calls.append({
                "id": tc.id,
                "name": tc.function.name,
                "arguments": tc.function.arguments,
            })

    usage = response.usage
    finish = choice.finish_reason or "stop"
    stop_reason = {
        "stop": "end_turn",
        "tool_calls": "tool_use",
        "length": "max_tokens",
        "content_filter": "content_filtered",
    }.get(finish, finish)

    return ("LlmResponse", {
        "role": "assistant",
        "parts": parts,
        "tool_calls": tool_calls,
        "input_tokens": usage.prompt_tokens if usage else 0,
        "output_tokens": usage.completion_tokens if usage else 0,
        "stop_reason": stop_reason,
    })


# ── Build: canonical → OpenAI ────────────────────────────────


def _build_messages(context: list[dict]) -> list[dict]:
    """Convert gamelan context to OpenAI messages format.

    Normalizes canonical parts (kind) to OpenAI message format.
    Re-injects tool_calls as native OpenAI tool_calls for assistant messages.
    """
    messages = []

    for msg in context:
        role = msg.get("role", "")
        parts = msg.get("parts", [])

        if role == "system":
            text = _extract_text(parts)
            if text:
                messages.append({"role": "system", "content": text})
            continue

        if role == "tool":
            tool_call_id = msg.get("tool_call_id", "")
            content_items = msg.get("content", [])
            content_text = ""
            if isinstance(content_items, list) and content_items:
                text_parts = [
                    c.get("text", "") for c in content_items if isinstance(c, dict)
                ]
                content_text = "\n".join(text_parts)
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": content_text,
            })
            continue

        if role == "user":
            text = _extract_text(parts)
            if text:
                messages.append({"role": "user", "content": text})
            continue

        if role == "assistant":
            msg_dict: dict[str, Any] = {"role": "assistant"}
            text = _extract_text(parts)
            if text:
                msg_dict["content"] = text
            # Re-inject tool_calls in OpenAI native format
            tc_list = msg.get("tool_calls") or []
            if tc_list:
                msg_dict["tool_calls"] = [
                    {
                        "id": tc.get("id", ""),
                        "type": "function",
                        "function": {
                            "name": tc.get("name", ""),
                            "arguments": tc.get("arguments", "{}"),
                        },
                    }
                    for tc in tc_list
                ]
            messages.append(msg_dict)

    return messages


def _build_tools(tools_raw: list[dict]) -> list[dict]:
    """Convert gamelan tool schemas to OpenAI format."""
    tools = []
    for tool in tools_raw:
        parameters = tool.get("parameters") or tool.get("input_schema", {})
        tools.append({
            "type": "function",
            "function": {
                "name": tool.get("name", ""),
                "description": tool.get("description", ""),
                "parameters": parameters,
            },
        })
    return tools


# ── Helpers ───────────────────────────────────────────────────


def _extract_text(parts) -> str:
    """Extract text from canonical parts list."""
    if isinstance(parts, str):
        return parts
    if isinstance(parts, dict):
        # Legacy: whole message dict stored as parts
        return parts.get("content", "")
    if isinstance(parts, list):
        texts = []
        for part in parts:
            if isinstance(part, dict):
                kind = part.get("kind") or part.get("type", "")
                if kind == "text":
                    texts.append(part.get("text", ""))
        return "\n".join(texts) if texts else ""
    return ""
