"""AnthropicSource — wraps the Anthropic Python SDK.

Implements Source protocol: dispatches LlmRequest, returns LlmResponse.
Handles text responses, tool calls, and tool schemas.

Requires: pip install gamelan[anthropic]
"""

from __future__ import annotations

import json
from typing import Any


LLM_PAIR = {"request_type": "LlmRequest", "result_type": "LlmResponse"}


class AnthropicSource:
    """Anthropic Messages API source."""

    def __init__(
        self,
        model: str = "claude-sonnet-4-20250514",
        max_tokens: int = 4096,
        api_key: str | None = None,
        **client_kwargs,
    ):
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. Install with: pip install gamelan[anthropic]"
            )

        self._model = model
        self._max_tokens = max_tokens
        self._client = anthropic.AsyncAnthropic(api_key=api_key, **client_kwargs)

    def interface(self) -> list[dict]:
        return [LLM_PAIR]

    async def dispatch(
        self, request_tag: str, request_data: dict
    ) -> tuple[str, dict]:
        context = request_data.get("context", [])
        tools_raw = request_data.get("tools", [])

        system, messages = _build_messages(context)
        tools = _build_tools(tools_raw)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": self._max_tokens,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = {"type": "auto"}

        response = await self._client.messages.create(**kwargs)

        return _parse_response(response)


# ── Parse: Anthropic → canonical ─────────────────────────────


def _parse_response(response) -> tuple[str, dict]:
    """Convert Anthropic response to gamelan LlmResponse.

    Normalizes native content blocks to canonical format (kind).
    Tool calls extracted to separate field — not duplicated in parts.
    """
    parts = []
    tool_calls = []

    for block in response.content:
        if block.type == "text":
            parts.append({"kind": "text", "text": block.text})
        elif block.type == "tool_use":
            tool_calls.append({
                "id": block.id,
                "name": block.name,
                "arguments": json.dumps(block.input),
            })
        else:
            # Future block types — preserve as-is with kind
            data = block.model_dump()
            data["kind"] = data.pop("type", block.type)
            parts.append(data)

    return ("LlmResponse", {
        "role": "assistant",
        "parts": parts,
        "tool_calls": tool_calls,
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
        "stop_reason": response.stop_reason or "end_turn",
    })


# ── Build: canonical → Anthropic ─────────────────────────────


def _build_messages(context: list[dict]) -> tuple[str, list[dict]]:
    """Convert gamelan context to Anthropic messages format.

    Normalizes canonical parts (kind) to Anthropic content blocks (type).
    Re-injects tool_calls as tool_use content blocks for assistant messages.
    """
    system = ""
    messages = []

    for msg in context:
        role = msg.get("role", "")
        parts = msg.get("parts", [])

        if role == "system":
            for part in _ensure_list(parts):
                if _part_kind(part) == "text":
                    system = part.get("text", "")
            continue

        if role == "tool":
            tool_call_id = msg.get("tool_call_id", "")
            content_items = msg.get("content", [])
            content_text = ""
            if isinstance(content_items, list) and content_items:
                text_parts = [
                    c.get("text", "") for c in content_items if isinstance(c, dict)
                ]
                content_text = "\n".join(text_parts)
            messages.append({
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_call_id,
                    "content": content_text,
                }],
            })
            continue

        if role in ("user", "assistant"):
            content = _to_anthropic_content(parts)
            # Re-inject tool_calls as tool_use blocks for assistant messages
            if role == "assistant":
                for tc in msg.get("tool_calls") or []:
                    args = tc.get("arguments", "{}")
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except (json.JSONDecodeError, TypeError):
                            args = {}
                    content.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": tc.get("name", ""),
                        "input": args,
                    })
            if content:
                messages.append({"role": role, "content": content})

    return system, messages


def _to_anthropic_content(parts) -> list[dict]:
    """Convert canonical parts to Anthropic content blocks."""
    parts = _ensure_list(parts)
    content = []
    for part in parts:
        kind = _part_kind(part)
        if kind == "text":
            content.append({"type": "text", "text": part.get("text", "")})
        else:
            # Unknown kind — pass through, swap kind→type
            block = dict(part)
            if "kind" in block:
                block["type"] = block.pop("kind")
            content.append(block)
    return content


def _build_tools(tools_raw: list[dict]) -> list[dict]:
    """Convert gamelan tool schemas to Anthropic format."""
    tools = []
    for tool in tools_raw:
        schema = tool.get("input_schema") or tool.get("parameters", {})
        if not schema or schema == {"type": "object"}:
            continue
        tools.append({
            "name": tool.get("name", ""),
            "description": tool.get("description", ""),
            "input_schema": schema,
        })
    return tools


# ── Helpers ───────────────────────────────────────────────────


def _ensure_list(parts) -> list:
    """Ensure parts is a list (handles legacy dict format)."""
    if isinstance(parts, list):
        return parts
    if isinstance(parts, dict):
        return [parts]
    return []


def _part_kind(part: dict) -> str:
    """Get the kind of a part, handling both canonical and legacy formats."""
    return part.get("kind") or part.get("type", "")
