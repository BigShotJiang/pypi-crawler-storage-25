"""McpSource — connects to MCP servers for tool execution and discovery.

Each McpSource connects to one MCP server via stdio child process.
It implements Source for ToolRequest → ToolResult and provides
tool discovery via discover().

Requires: pip install gamelan[mcp]
"""

from __future__ import annotations

import json
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from typing import Any


TOOL_PAIR = {"request_type": "ToolRequest", "result_type": "ToolResult"}


@dataclass
class McpServerConfig:
    """Configuration for an MCP server connection."""

    name: str
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] | None = None


class McpSource:
    """MCP server connection as a Source.

    Connects to one MCP server via stdio, discovers its tools,
    and dispatches ToolRequest events to it. Lazy-connects on first use.
    """

    def __init__(self, config: McpServerConfig):
        try:
            import mcp  # noqa: F401
        except ImportError:
            raise ImportError(
                "mcp package required. Install with: pip install gamelan[mcp]"
            )

        self._config = config
        self._exit_stack: AsyncExitStack | None = None
        self._session = None
        self._tools: list = []

    def interface(self) -> list[dict]:
        return [TOOL_PAIR]

    async def _ensure_connected(self):
        """Lazy-connect to the MCP server on first use."""
        if self._session is not None:
            return

        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        server_params = StdioServerParameters(
            command=self._config.command,
            args=self._config.args,
            env=self._config.env,
        )

        self._exit_stack = AsyncExitStack()
        transport = await self._exit_stack.enter_async_context(
            stdio_client(server_params)
        )
        read_stream, write_stream = transport

        self._session = await self._exit_stack.enter_async_context(
            ClientSession(read_stream, write_stream)
        )
        await self._session.initialize()

        # Discover tools at connection time
        response = await self._session.list_tools()
        self._tools = response.tools

    async def discover(self) -> list[dict]:
        """Return tool schemas for LLM context."""
        await self._ensure_connected()

        prefix = f"mcp__{self._config.name}__"
        schemas = []
        for tool in self._tools:
            schema: dict[str, Any] = {
                "name": f"{prefix}{tool.name}",
            }
            if tool.description:
                schema["description"] = tool.description
            if tool.inputSchema:
                schema["parameters"] = dict(tool.inputSchema)
            schemas.append(schema)
        return schemas

    async def dispatch(
        self, request_tag: str, request_data: dict
    ) -> tuple[str, dict]:
        """Dispatch a ToolRequest to the MCP server, return ToolResult."""
        await self._ensure_connected()

        # Extract tool name and arguments
        tool_name = request_data.get("name", "")
        if not tool_name:
            raise RuntimeError("missing tool name in ToolRequest")

        # Strip MCP prefix if present
        prefix = f"mcp__{self._config.name}__"
        raw_name = tool_name.removeprefix(prefix)

        # Parse arguments (may be string or dict)
        arguments = request_data.get("arguments", {})
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except (json.JSONDecodeError, TypeError):
                arguments = {}

        tool_call_id = request_data.get("tool_call_id", "")

        # Call the tool
        result = await self._session.call_tool(raw_name, arguments=arguments)

        # Convert to gamelan ToolResult
        text_parts = []
        for content_block in result.content:
            if hasattr(content_block, "text"):
                text_parts.append(content_block.text)

        text = "\n".join(text_parts)
        is_error = getattr(result, "isError", False) or False

        return ("ToolResult", {
            "key": f"ToolRequest:{tool_call_id}",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": [{"content_type": "text", "text": text}],
            "is_error": is_error,
        })

    async def close(self):
        """Disconnect from the MCP server."""
        if self._exit_stack:
            await self._exit_stack.aclose()
            self._exit_stack = None
            self._session = None
            self._tools = []
