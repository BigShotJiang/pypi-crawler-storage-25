"""Model-based testing: replay network ITF traces against Python NetworkSession.

Replays network.qnt traces via NetworkSession.fold_event — the same API
that NetworkRunner and SessionManager use. All actions go through fold.

Same traces as rust/gamelan-core/tests/network_mbt.rs.
"""

import json
from pathlib import Path

import pytest

from gamelan._core import NetworkSession

FIXTURE_ROOT = Path(__file__).resolve().parent.parent.parent.parent / "rust"
NETWORK_TRACES = FIXTURE_ROOT / "gamelan-core" / "tests" / "fixtures" / "network_traces"


# ════════════════════════════════════════════════════════════════
# ITF parsing
# ════════════════════════════════════════════════════════════════


def parse_bigint(v) -> int:
    if isinstance(v, dict) and "#bigint" in v:
        return int(v["#bigint"])
    return int(v)


def parse_status(v) -> str:
    return {
        "SIdle": "idle", "SProcessing": "processing",
        "SWaitingDelegate": "waiting_delegate", "SDone": "done",
    }[v["tag"]]


def parse_string_set(v) -> list[str]:
    if isinstance(v, dict) and "#set" in v:
        return sorted(v["#set"])
    return sorted(v) if isinstance(v, list) else []


def parse_agent(v) -> dict:
    return {
        "status": parse_status(v["status"]),
        "step_count": parse_bigint(v["step_count"]),
        "waiting_on": parse_string_set(v["waiting_on"]),
        "event_count": parse_bigint(v["event_count"]),
    }


def parse_agents(v) -> dict[str, dict]:
    return {entry[0]: parse_agent(entry[1]) for entry in v["#map"]}


def parse_edge_set(v) -> set[tuple[str, str]]:
    return {(item["src"], item["dst"]) for item in v["#set"]}


def parse_routes(v) -> list[dict]:
    routes = []
    for item in v["#set"]:
        kind = item["kind"]["tag"]
        routes.append({
            "src": item["src"], "dst": item["dst"], "kind": kind,
        })
    return routes


def parse_state(state: dict) -> dict:
    return {
        "agents": parse_agents(state["agents"]),
        "routes": parse_routes(state["routes"]),
        "delegation_graph": parse_edge_set(state["delegation_graph"]),
        "active_agent": state["active_agent"],
    }


# ════════════════════════════════════════════════════════════════
# Action inference — all through fold_event
# ════════════════════════════════════════════════════════════════


def infer_and_apply(network: NetworkSession, prev: dict, next_: dict):
    prev_agents = prev["agents"]
    next_agents = next_["agents"]
    prev_deleg = prev["delegation_graph"]
    next_deleg = next_["delegation_graph"]

    # Handoff: active_agent changed
    if next_["active_agent"] != prev["active_agent"]:
        dst = next_["active_agent"]
        for src_id, prev_s in prev_agents.items():
            next_s = next_agents.get(src_id)
            if (next_s and prev_s["status"] == "done" and next_s["status"] == "idle"
                    and any(r["src"] == src_id and r["dst"] == dst and r["kind"] == "HandoffRoute"
                            for r in prev["routes"])):
                network.fold_event("HandoffRequested", {"src": src_id, "dst": dst})
                return

    # Removed delegation edges — DelegationComplete or DelegationFailed
    for src, dst in prev_deleg - next_deleg:
        if dst not in next_agents:
            network.fold_event("DelegationFailed", {"parent": src, "child": dst})
        elif next_agents[dst]["status"] == "idle":
            prev_dst = prev_agents.get(dst, {})
            if prev_dst.get("status") == "done":
                network.fold_event("DelegationComplete", {"parent": src, "child": dst})

    # Removed agents not covered above
    for id_ in prev_agents:
        if id_ not in next_agents and network.agent_status(id_) is not None:
            network.fold_event("AgentFailed", {"agent": id_})

    # New delegation edges — DelegationRequested
    new_delegations = next_deleg - prev_deleg
    delegation_explained = set()
    for src, dst in new_delegations:
        network.fold_event("DelegationRequested", {"parent": src, "child": dst})
        delegation_explained.add(src)
        delegation_explained.add(dst)

    # Status transitions (not explained by delegation)
    for id_, next_s in next_agents.items():
        if id_ in delegation_explained:
            continue
        prev_s = prev_agents.get(id_)
        if not prev_s:
            continue

        if prev_s["status"] == "idle" and next_s["status"] == "processing":
            if id_ == prev["active_agent"] and next_["active_agent"] == prev["active_agent"]:
                network.fold_event("UserMessage", {})
            else:
                network.fold_event("StartAgent", {"agent": id_})

        if prev_s["status"] == "processing" and next_s["status"] == "done":
            network.fold_event("AgentDone", {"agent": id_})

        if (prev_s["status"] == "done" and next_s["status"] == "idle"
                and next_["active_agent"] == prev["active_agent"]
                and not any(d[1] == id_ for d in prev_deleg)):
            network.reset_agent(id_)


# ════════════════════════════════════════════════════════════════
# State comparison
# ════════════════════════════════════════════════════════════════


def compare_states(step: int, network: NetworkSession, expected: dict) -> list[str]:
    errors = []

    # Active agent
    if network.active_agent != expected["active_agent"]:
        errors.append(
            f"step {step}: active_agent: actual={network.active_agent}, "
            f"expected={expected['active_agent']}"
        )

    # Agent statuses
    for id_, exp in expected["agents"].items():
        actual = network.agent_status(id_)
        if actual is None:
            errors.append(f"step {step}: missing agent {id_}")
            continue
        if actual != exp["status"]:
            errors.append(
                f"step {step}: {id_}.status: actual={actual}, expected={exp['status']}"
            )

    # Delegation graph
    actual_graph = {(d["src"], d["dst"]) for d in network.delegation_graph()}
    if actual_graph != expected["delegation_graph"]:
        errors.append(
            f"step {step}: delegation_graph: actual={actual_graph}, "
            f"expected={expected['delegation_graph']}"
        )

    return errors


# ════════════════════════════════════════════════════════════════
# Trace replay
# ════════════════════════════════════════════════════════════════


def replay_network_trace(path: Path):
    content = json.loads(path.read_text())
    states = content["states"]
    if len(states) < 2:
        return

    state0 = parse_state(states[0])

    delegation_routes = [
        (r["src"], r["dst"]) for r in state0["routes"] if r["kind"] == "Delegation"
    ]
    handoff_routes = [
        (r["src"], r["dst"]) for r in state0["routes"] if r["kind"] == "HandoffRoute"
    ]

    network = NetworkSession(
        agents=list(state0["agents"].keys()),
        delegation_routes=delegation_routes,
        handoff_routes=handoff_routes,
        entry_point=state0["active_agent"],
    )

    all_errors: list[str] = []
    all_errors.extend(compare_states(0, network, state0))

    for i in range(1, len(states)):
        prev = parse_state(states[i - 1])
        next_ = parse_state(states[i])
        infer_and_apply(network, prev, next_)
        all_errors.extend(compare_states(i, network, next_))

    assert not all_errors, (
        f"Trace {path.name} had {len(all_errors)} mismatches:\n"
        + "\n".join(all_errors)
    )


# ════════════════════════════════════════════════════════════════
# Tests
# ════════════════════════════════════════════════════════════════


def collect_traces(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob("*.itf.json"))


network_traces = collect_traces(NETWORK_TRACES)


@pytest.mark.parametrize(
    "trace_path",
    network_traces,
    ids=[p.stem for p in network_traces],
)
def test_network_trace(trace_path: Path):
    replay_network_trace(trace_path)
