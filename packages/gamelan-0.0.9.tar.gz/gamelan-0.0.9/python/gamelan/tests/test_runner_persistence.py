"""Test SessionRunner persistence: resume, resume_from_snapshot."""

from gamelan import SessionRunner, SessionConfig, stdlib
from tests.conftest import work_config


def simple_config() -> SessionConfig:
    return work_config()


class TestResume:
    def test_resume_reconstructs_state(self):
        """Resume from event log produces same kernel state as live."""
        tds = stdlib()
        config = simple_config()

        # Live: process events
        live = SessionRunner(tds, config)
        live.fold_event("Input", {})
        live.fold_event("WorkResult", {})
        live.fold_event("Input", {})

        # Resume from the same event log
        event_log = [
            ("Input", {}),
            ("WorkResult", {}),
            ("Input", {}),
        ]
        resumed = SessionRunner.resume(tds, config, event_log)

        # Kernel state should match
        assert resumed.get_state() == live.get_state()
        assert resumed.events_processed == live.events_processed

    def test_resume_event_log_populated(self):
        """Resumed runner has event log from the replayed events."""
        tds = stdlib()
        config = simple_config()
        event_log = [("Input", {}), ("WorkResult", {})]
        resumed = SessionRunner.resume(tds, config, event_log)
        assert resumed.event_log == ["Input", "WorkResult"]


class TestResumeFromSnapshot:
    def test_snapshot_resume_matches_full_replay(self):
        """Resume from snapshot + remaining events matches full replay."""
        tds = stdlib()
        config = simple_config()

        # Live: process some events, take snapshot, process more
        live = SessionRunner(tds, config)
        live.fold_event("Input", {})
        live.fold_event("WorkResult", {})
        snapshot = live.snapshot()
        live.fold_event("Input", {})
        live.fold_event("WorkResult", {})

        # Full replay
        full_log = [
            ("Input", {}),
            ("WorkResult", {}),
            ("Input", {}),
            ("WorkResult", {}),
        ]
        full_replay = SessionRunner.resume(tds, config, full_log)

        # Snapshot + remaining events
        remaining = [("Input", {}), ("WorkResult", {})]
        snap_resumed = SessionRunner.resume_from_snapshot(
            tds, config, snapshot, remaining
        )

        # Both should produce same kernel state
        assert snap_resumed.get_state() == full_replay.get_state()
        assert snap_resumed.events_processed == full_replay.events_processed

    def test_snapshot_resume_empty_remaining(self):
        """Snapshot with no remaining events is just the snapshot state."""
        tds = stdlib()
        config = simple_config()

        live = SessionRunner(tds, config)
        live.fold_event("Input", {})
        snapshot = live.snapshot()

        resumed = SessionRunner.resume_from_snapshot(
            tds, config, snapshot, []
        )
        assert resumed.events_processed == live.events_processed


class TestNewTurnAfterComplete:
    def test_new_turn_after_idle(self):
        """After completing a turn (idle), runner can process new events."""
        tds = stdlib()
        config = simple_config()
        runner = SessionRunner(tds, config)
        runner.fold_event("Input", {})
        runner.fold_event("WorkResult", {})
        assert runner.is_idle

        # Process another event
        runner.fold_event("Input", {})
        assert runner.events_processed == 3
