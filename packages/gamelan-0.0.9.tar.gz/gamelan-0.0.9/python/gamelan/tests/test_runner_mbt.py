"""Model-based testing: validate runner turn loop invariants against ITF traces.

Replays runner_mc.qnt traces and checks spec invariants at every step.
Same invariants as the Rust runner_mbt.rs harness.

Invariants (from runner_mc.qnt):
  - mc_reject_is_terminal: EvCheckRejected is always the last event
  - mc_dispatch_after_fold: every EvDispatched has a prior EvFolded
  - mc_complete_is_terminal: EvTurnComplete ends the turn
  - mc_queue_tags_valid: queue only contains known event tags
  - reject_clears_queue: rejection empties the queue

These catch:
  - Outbound reject not terminating the turn
  - Dispatch without prior fold
  - Multiple results from dispatch (spec validates queue grows correctly)
"""

import json
from pathlib import Path

import pytest

FIXTURE_ROOT = Path(__file__).resolve().parent.parent.parent.parent / "rust"
RUNNER_TRACES = FIXTURE_ROOT / "gamelan-core" / "tests" / "fixtures" / "runner_traces"

KNOWN_TAGS = {
    "UserMessage",
    "LlmResponse",
    "ToolResult",
    "DelegationResult",
    "MemoryBlockUpdated",
    "SessionInit",
    "CheckResult",
    "TransformedResult",
}


# ════════════════════════════════════════════════════════════════
# ITF parsing
# ════════════════════════════════════════════════════════════════


def parse_runner_event(v: dict) -> dict:
    return {"tag": v["tag"], **v.get("value", {})}


def parse_runner_state(state: dict) -> dict:
    return {
        "queue": list(state["queue"]),
        "runner_events": [parse_runner_event(e) for e in state["runner_events"]],
        "turn_active": state["turn_active"],
    }


# ════════════════════════════════════════════════════════════════
# Invariant checks
# ════════════════════════════════════════════════════════════════


def check_reject_is_terminal(step: int, s: dict, errors: list[str]):
    """EvCheckRejected must be the last event in the turn."""
    for i, ev in enumerate(s["runner_events"]):
        if ev["tag"] == "EvCheckRejected":
            if i != len(s["runner_events"]) - 1:
                errors.append(
                    f"step {step}: inv_reject_is_terminal VIOLATED — "
                    f"EvCheckRejected at position {i} but {len(s['runner_events'])} events total"
                )


def check_dispatch_after_fold(step: int, s: dict, errors: list[str]):
    """Every EvDispatched must have a prior EvFolded."""
    for i, ev in enumerate(s["runner_events"]):
        if ev["tag"] == "EvDispatched":
            has_prior_fold = any(
                e["tag"] == "EvFolded" for e in s["runner_events"][:i]
            )
            if not has_prior_fold:
                errors.append(
                    f"step {step}: inv_dispatch_after_fold VIOLATED — "
                    f"EvDispatched at position {i} with no prior EvFolded"
                )


def check_complete_is_terminal(step: int, s: dict, errors: list[str]):
    """EvTurnComplete implies turn_active is false."""
    if s["runner_events"] and s["runner_events"][-1]["tag"] == "EvTurnComplete":
        if s["turn_active"]:
            errors.append(
                f"step {step}: inv_complete_is_terminal VIOLATED — "
                f"EvTurnComplete present but turn_active is True"
            )


def check_queue_tags_valid(step: int, s: dict, errors: list[str]):
    """Queue only contains known event tags."""
    for tag in s["queue"]:
        if tag not in KNOWN_TAGS:
            errors.append(
                f"step {step}: inv_queue_tags_valid VIOLATED — "
                f"unknown tag '{tag}' in queue"
            )


def check_reject_clears_queue(step: int, s: dict, errors: list[str]):
    """When turn ends with EvCheckRejected, queue must be empty."""
    if not s["turn_active"]:
        if s["runner_events"] and s["runner_events"][-1]["tag"] == "EvCheckRejected":
            if s["queue"]:
                errors.append(
                    f"step {step}: reject_clears_queue VIOLATED — "
                    f"turn ended with EvCheckRejected but queue has {len(s['queue'])} items"
                )


def check_events_monotonic(step: int, prev: dict, next_: dict, errors: list[str]):
    """runner_events is append-only (prefix preserved)."""
    if len(next_["runner_events"]) < len(prev["runner_events"]):
        errors.append(
            f"step {step}: events_monotonic VIOLATED — "
            f"runner_events shrunk from {len(prev['runner_events'])} to {len(next_['runner_events'])}"
        )
    else:
        for i in range(min(len(prev["runner_events"]), len(next_["runner_events"]))):
            if prev["runner_events"][i] != next_["runner_events"][i]:
                errors.append(
                    f"step {step}: events_monotonic VIOLATED — runner_events[{i}] changed"
                )
                break


# ════════════════════════════════════════════════════════════════
# Trace replay
# ════════════════════════════════════════════════════════════════


def replay_runner_trace(path: Path):
    content = json.loads(path.read_text())
    states = content["states"]
    errors: list[str] = []

    for i, state_json in enumerate(states):
        s = parse_runner_state(state_json)
        check_reject_is_terminal(i, s, errors)
        check_dispatch_after_fold(i, s, errors)
        check_complete_is_terminal(i, s, errors)
        check_queue_tags_valid(i, s, errors)
        check_reject_clears_queue(i, s, errors)

    for i in range(1, len(states)):
        prev = parse_runner_state(states[i - 1])
        next_ = parse_runner_state(states[i])
        check_events_monotonic(i, prev, next_, errors)

    assert not errors, (
        f"Trace {path.name} had {len(errors)} issues:\n" + "\n".join(errors)
    )


# ════════════════════════════════════════════════════════════════
# Tests
# ════════════════════════════════════════════════════════════════


def collect_traces(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob("*.itf.json"))


runner_traces = collect_traces(RUNNER_TRACES)


@pytest.mark.parametrize(
    "trace_path",
    runner_traces,
    ids=[p.stem for p in runner_traces],
)
def test_runner_trace(trace_path: Path):
    replay_runner_trace(trace_path)
