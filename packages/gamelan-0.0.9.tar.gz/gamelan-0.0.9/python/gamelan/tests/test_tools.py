"""Test ToolSource — local function tool execution."""

import pytest

from gamelan.tools import ToolSource, ToolOutput, ToolDef


# ════════════════════════════════════════════════════════════════
# Raw handler tests (no Pydantic dependency)
# ════════════════════════════════════════════════════════════════


def make_tool_source() -> ToolSource:
    tools = ToolSource()

    async def echo_handler(args: dict) -> str:
        return args.get("message", "")

    async def fail_handler(args: dict) -> ToolOutput:
        return ToolOutput.error("something went wrong")

    tools.register_raw(
        "echo", "Echo a message",
        {"type": "object", "properties": {"message": {"type": "string"}}, "required": ["message"]},
        echo_handler,
    )
    tools.register_raw(
        "fail", "Always fails",
        {"type": "object"},
        fail_handler,
    )
    return tools


class TestToolSource:
    def test_interface(self):
        tools = make_tool_source()
        pairs = tools.interface()
        assert len(pairs) == 1
        assert pairs[0]["request_type"] == "ToolRequest"
        assert pairs[0]["result_type"] == "ToolResult"

    @pytest.mark.asyncio
    async def test_discover(self):
        tools = make_tool_source()
        schemas = await tools.discover()
        assert len(schemas) == 2
        names = [s["name"] for s in schemas]
        assert "echo" in names
        assert "fail" in names

    @pytest.mark.asyncio
    async def test_dispatch_raw(self):
        tools = make_tool_source()
        tag, data = await tools.dispatch("ToolRequest", {
            "name": "echo",
            "tool_call_id": "tc1",
            "arguments": '{"message": "hello"}',
        })
        assert tag == "ToolResult"
        assert data["tool_call_id"] == "tc1"
        assert data["is_error"] is False
        assert data["content"][0]["text"] == "hello"

    @pytest.mark.asyncio
    async def test_dispatch_with_dict_args(self):
        tools = make_tool_source()
        tag, data = await tools.dispatch("ToolRequest", {
            "name": "echo",
            "tool_call_id": "tc2",
            "arguments": {"message": "world"},
        })
        assert data["content"][0]["text"] == "world"

    @pytest.mark.asyncio
    async def test_dispatch_error_tool(self):
        tools = make_tool_source()
        tag, data = await tools.dispatch("ToolRequest", {
            "name": "fail",
            "tool_call_id": "tc3",
            "arguments": "{}",
        })
        assert data["is_error"] is True
        assert data["content"][0]["text"] == "something went wrong"

    @pytest.mark.asyncio
    async def test_dispatch_unknown_tool(self):
        tools = make_tool_source()
        with pytest.raises(RuntimeError, match="unknown tool"):
            await tools.dispatch("ToolRequest", {
                "name": "nonexistent",
                "tool_call_id": "tc4",
            })

    @pytest.mark.asyncio
    async def test_dispatch_handler_exception(self):
        tools = ToolSource()

        async def boom(args: dict) -> str:
            raise ValueError("kaboom")

        tools.register_raw("boom", "Explodes", {"type": "object"}, boom)

        tag, data = await tools.dispatch("ToolRequest", {
            "name": "boom",
            "tool_call_id": "tc5",
            "arguments": "{}",
        })
        assert data["is_error"] is True
        assert "kaboom" in data["content"][0]["text"]


class TestDecorator:
    @pytest.mark.asyncio
    async def test_decorator_raw(self):
        tools = ToolSource()

        @tools.tool("greet", "Greet someone")
        async def greet(args: dict) -> str:
            return f"Hello, {args.get('name', 'world')}!"

        tag, data = await tools.dispatch("ToolRequest", {
            "name": "greet",
            "tool_call_id": "tc1",
            "arguments": '{"name": "Alice"}',
        })
        assert data["content"][0]["text"] == "Hello, Alice!"


class TestToolOutput:
    def test_text(self):
        o = ToolOutput.text("hello")
        assert o.content == "hello"
        assert o.is_error is False

    def test_error(self):
        o = ToolOutput.error("bad")
        assert o.content == "bad"
        assert o.is_error is True
