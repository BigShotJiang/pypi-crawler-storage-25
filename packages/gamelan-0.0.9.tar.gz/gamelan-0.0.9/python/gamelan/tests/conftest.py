"""Shared test fixtures for gamelan Python tests."""

import json

from gamelan import (
    Connection,
    Router,
    SessionConfig,
    SessionRunner,
    stdlib,
)
from gamelan.source import Source


# ════════════════════════════════════════════════════════════════
# Mock sources
# ════════════════════════════════════════════════════════════════


class MockSource:
    """Returns fixed result events in order. Captures dispatch calls."""

    def __init__(self, pairs: list[dict], responses: list[tuple[str, dict]]):
        self._pairs = pairs
        self._responses = list(responses)
        self.dispatch_calls: list[tuple[str, dict]] = []

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        self.dispatch_calls.append((request_tag, request_data))
        if not self._responses:
            raise RuntimeError("no more responses")
        return self._responses.pop(0)

    def interface(self) -> list[dict]:
        return self._pairs


class FailingSource:
    """Always raises on dispatch."""

    def __init__(self, pairs: list[dict]):
        self._pairs = pairs

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        raise RuntimeError("boom")

    def interface(self) -> list[dict]:
        return self._pairs


# ════════════════════════════════════════════════════════════════
# Topology helpers
# ════════════════════════════════════════════════════════════════

LLM_PAIR = {"request_type": "LlmRequest", "result_type": "LlmResponse"}
TOOL_PAIR = {"request_type": "ToolRequest", "result_type": "ToolResult"}
WORK_PAIR = {"request_type": "WorkRequest", "result_type": "WorkResult"}


def work_topology_json() -> str:
    """Simple WorkRequest/WorkResult topology."""
    return json.dumps([{
        "request_type": "WorkRequest",
        "result_type": "WorkResult",
        "has_check": False,
        "check_source": None,
    }])


def agent_topology_json() -> str:
    """LlmRequest/LlmResponse + ToolRequest/ToolResult topology."""
    return json.dumps([
        {
            "request_type": "LlmRequest",
            "result_type": "LlmResponse",
            "has_check": False,
            "check_source": None,
        },
        {
            "request_type": "ToolRequest",
            "result_type": "ToolResult",
            "has_check": False,
            "check_source": None,
        },
    ])


def checked_work_topology_json() -> str:
    """WorkRequest/WorkResult with check."""
    return json.dumps([{
        "request_type": "WorkRequest",
        "result_type": "WorkResult",
        "has_check": True,
        "check_source": "approval",
    }])


def work_config() -> SessionConfig:
    return SessionConfig(work_topology_json())


def agent_config() -> SessionConfig:
    return SessionConfig(agent_topology_json())


def llm_only_config() -> SessionConfig:
    """LLM-only topology — no tools. For tests that only provide an LLM source."""
    return SessionConfig(json.dumps([{
        "request_type": "LlmRequest",
        "result_type": "LlmResponse",
        "has_check": False,
        "check_source": None,
    }]))


def llm_only_resolver(req_type: str) -> str | None:
    return "llm" if req_type == "LlmRequest" else None


def checked_work_config() -> SessionConfig:
    return SessionConfig(checked_work_topology_json())


def work_resolver(req_type: str) -> str | None:
    return {"WorkRequest": "worker"}.get(req_type)


def agent_resolver(req_type: str) -> str | None:
    return {"LlmRequest": "llm", "ToolRequest": "tools"}.get(req_type)


# ════════════════════════════════════════════════════════════════
# Mock LLM responses
# ════════════════════════════════════════════════════════════════


def text_response(text: str) -> tuple[str, dict]:
    """Build a text-only LlmResponse."""
    return ("LlmResponse", {
        "role": "assistant",
        "parts": [{"kind": "text", "text": text}],
        "input_tokens": 10,
        "output_tokens": 5,
    })


def tool_call_response(tool_name: str, arguments: str, call_id: str = "tc1") -> tuple[str, dict]:
    """Build a tool-call LlmResponse."""
    return ("LlmResponse", {
        "role": "assistant",
        "parts": [],
        "tool_calls": [{"id": call_id, "name": tool_name, "arguments": arguments}],
        "input_tokens": 10,
        "output_tokens": 5,
    })
