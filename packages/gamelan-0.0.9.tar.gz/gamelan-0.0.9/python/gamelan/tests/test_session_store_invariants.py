"""Property-based invariant tests for the session store.

Exercises the REAL MemoryLog, checking invariants from session_store.qnt
after every operation.

Python port of rust/gamelan/tests/session_store_invariants.rs.
"""

from dataclasses import dataclass, field
from enum import Enum, auto

from hypothesis import given, settings
from hypothesis.strategies import integers, lists, sampled_from, tuples

from gamelan import MemoryLog


# ════════════════════════════════════════════════════════════════
# Test harness wrapping real persistence code
# ════════════════════════════════════════════════════════════════


@dataclass
class SessionInfo:
    id: str
    created_at: int
    updated_at: int
    event_count: int
    title: str | None = None


class RealStore:
    """Wraps real MemoryLog instances with metadata tracking."""

    def __init__(self):
        self.logs: dict[str, MemoryLog] = {}
        self.info: dict[str, SessionInfo] = {}
        self.snapshots: dict[str, tuple[int, int]] = {}  # id -> (position, state_hash)

    def create_session(self, id: str, timestamp: int) -> bool:
        if id in self.logs:
            return False
        self.logs[id] = MemoryLog()
        self.info[id] = SessionInfo(
            id=id, created_at=timestamp, updated_at=timestamp, event_count=0
        )
        return True

    def delete_session(self, id: str) -> bool:
        if id not in self.logs:
            return False
        del self.logs[id]
        del self.info[id]
        self.snapshots.pop(id, None)
        return True

    def append_event(self, id: str, tag: str, timestamp: int) -> bool:
        if id not in self.logs:
            return False
        # Use the REAL MemoryLog.append
        self.logs[id].append((tag, {}))
        self.info[id].event_count += 1
        self.info[id].updated_at = timestamp
        return True

    def save_snapshot(self, id: str, position: int) -> bool:
        if id not in self.info:
            return False
        if position > self.info[id].event_count:
            return False
        # Use REAL MemoryLog.load to get events, compute hash
        events = self.logs[id].load()
        prefix_tags = [tag for tag, _ in events[:position]]
        state_hash = replay_state(prefix_tags)
        self.snapshots[id] = (position, state_hash)
        return True

    def update_title(self, id: str, title: str) -> bool:
        if id not in self.info:
            return False
        self.info[id].title = title
        return True


def tag_value(tag: str) -> int:
    """Abstract state hash — matches session_store.qnt::tag_value."""
    return {
        "Input": 1,
        "LlmRequest": 2,
        "LlmResponse": 3,
        "ToolRequest": 5,
        "ToolResult": 7,
    }.get(tag, 11)


def replay_state(tags: list[str]) -> int:
    return sum(tag_value(t) for t in tags)


# ════════════════════════════════════════════════════════════════
# Invariant checks — exercises REAL MemoryLog methods
# ════════════════════════════════════════════════════════════════


def check_event_count_consistent(s: RealStore):
    for id, info in s.info.items():
        log = s.logs[id]
        assert info.event_count == len(log), (
            f"session {id}: info.event_count ({info.event_count}) != len(log) ({len(log)})"
        )


def check_sessions_have_logs(s: RealStore):
    for id in s.info:
        assert id in s.logs, f"session {id} has no log"


def check_logs_have_sessions(s: RealStore):
    for id in s.logs:
        assert id in s.info, f"log {id} has no session"


def check_snapshot_within_log(s: RealStore):
    for id, (position, _) in s.snapshots.items():
        assert id in s.info, f"snapshot for {id} but no session"
        assert position <= s.info[id].event_count, (
            f"snapshot for {id}: position ({position}) > event_count ({s.info[id].event_count})"
        )


def check_snapshot_matches_replay(s: RealStore):
    for id, (position, state_hash) in s.snapshots.items():
        # Use REAL MemoryLog.load()
        events = s.logs[id].load()
        prefix_tags = [tag for tag, _ in events[:position]]
        expected = replay_state(prefix_tags)
        assert state_hash == expected, (
            f"snapshot for {id}: hash ({state_hash}) != replay ({expected})"
        )


def check_resume_equals_replay(s: RealStore):
    for id, (position, state_hash) in s.snapshots.items():
        # Use REAL MemoryLog.load() and load_after()
        all_events = s.logs[id].load()
        remaining = s.logs[id].load_after(position)

        all_tags = [tag for tag, _ in all_events]
        remaining_tags = [tag for tag, _ in remaining]

        from_scratch = replay_state(all_tags)
        from_snapshot = state_hash + replay_state(remaining_tags)

        assert from_snapshot == from_scratch, (
            f"session {id}: resume ({from_snapshot}) != replay ({from_scratch})"
        )


def check_all_invariants(s: RealStore):
    check_event_count_consistent(s)
    check_sessions_have_logs(s)
    check_logs_have_sessions(s)
    check_snapshot_within_log(s)
    check_snapshot_matches_replay(s)
    check_resume_equals_replay(s)


# ════════════════════════════════════════════════════════════════
# Action generation
# ════════════════════════════════════════════════════════════════


SESSION_IDS = sampled_from(["s1", "s2", "s3"])
EVENT_TAGS = sampled_from(["Input", "LlmRequest", "LlmResponse", "ToolRequest", "ToolResult"])
TIMESTAMPS = sampled_from([1000, 2000, 3000])
TITLES = sampled_from(["Session A", "Session B"])
POSITIONS = integers(min_value=0, max_value=10)


@dataclass(frozen=True)
class CreateSession:
    id: str
    timestamp: int

@dataclass(frozen=True)
class DeleteSession:
    id: str

@dataclass(frozen=True)
class AppendEvent:
    id: str
    tag: str
    timestamp: int

@dataclass(frozen=True)
class SaveSnapshot:
    id: str
    position: int

@dataclass(frozen=True)
class UpdateTitle:
    id: str
    title: str


StoreAction = CreateSession | DeleteSession | AppendEvent | SaveSnapshot | UpdateTitle


def store_actions():
    return sampled_from([
        "create", "delete", "append", "snapshot", "title"
    ]).flatmap(lambda kind: {
        "create": tuples(SESSION_IDS, TIMESTAMPS).map(lambda t: CreateSession(t[0], t[1])),
        "delete": SESSION_IDS.map(DeleteSession),
        "append": tuples(SESSION_IDS, EVENT_TAGS, TIMESTAMPS).map(
            lambda t: AppendEvent(t[0], t[1], t[2])
        ),
        "snapshot": tuples(SESSION_IDS, POSITIONS).map(lambda t: SaveSnapshot(t[0], t[1])),
        "title": tuples(SESSION_IDS, TITLES).map(lambda t: UpdateTitle(t[0], t[1])),
    }[kind])


def apply_action(s: RealStore, action: StoreAction):
    if isinstance(action, CreateSession):
        s.create_session(action.id, action.timestamp)
    elif isinstance(action, DeleteSession):
        s.delete_session(action.id)
    elif isinstance(action, AppendEvent):
        s.append_event(action.id, action.tag, action.timestamp)
    elif isinstance(action, SaveSnapshot):
        s.save_snapshot(action.id, action.position)
    elif isinstance(action, UpdateTitle):
        s.update_title(action.id, action.title)


# ════════════════════════════════════════════════════════════════
# Property tests — 10,000 random CRUD sequences on REAL MemoryLog
# ════════════════════════════════════════════════════════════════


@settings(max_examples=10000)
@given(actions=lists(store_actions(), min_size=1, max_size=30))
def test_store_invariants_hold(actions):
    s = RealStore()
    check_all_invariants(s)

    for action in actions:
        apply_action(s, action)
        check_all_invariants(s)


@settings(max_examples=10000)
@given(
    tags=lists(EVENT_TAGS, min_size=1, max_size=20),
    split_at=integers(min_value=0, max_value=20),
)
def test_resume_equals_replay_real_log(tags, split_at):
    """resume(snapshot_at(N), events[N..]) == replay(events[0..])"""
    log = MemoryLog()
    for tag in tags:
        log.append((tag, {}))

    split = min(split_at, len(tags))

    # Full replay via REAL load()
    all_events = log.load()
    all_tags = [tag for tag, _ in all_events]
    full = replay_state(all_tags)

    # Resume via REAL load_after()
    prefix_tags = all_tags[:split]
    remaining = log.load_after(split)
    remaining_tags = [tag for tag, _ in remaining]

    prefix_hash = replay_state(prefix_tags)
    resumed = prefix_hash + replay_state(remaining_tags)

    assert resumed == full, f"resume != replay at split {split}"


@settings(max_examples=10000)
@given(tags=lists(EVENT_TAGS, min_size=0, max_size=30))
def test_memory_log_len_consistent(tags):
    log = MemoryLog()
    for i, tag in enumerate(tags):
        assert len(log) == i
        log.append((tag, {}))
    assert len(log) == len(tags)
