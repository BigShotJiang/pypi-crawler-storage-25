"""Test run_turn — the callback-based turn driver.

run_turn is the core runtime loop. It takes three optional callbacks:
  dispatch — how to send requests to sources (default: route via Router)
  check    — how to verify requests before dispatch (default: auto-approve)
  observe  — called on each step for persistence/logging (default: noop)

These tests exercise all three callbacks directly, not through
AgentSession or SessionManager wrappers.
"""

import pytest

from gamelan import (
    Approve,
    CheckResolved,
    Connection,
    Dispatched,
    DispatchFailed,
    Reject,
    Router,
    SessionRunner,
    run_turn,
    stdlib,
)
from gamelan.check import AutoApprove, OutboundCheckEntry
from gamelan.run import TurnEvent
from tests.conftest import (
    MockSource,
    FailingSource,
    LLM_PAIR,
    text_response,
    agent_config,
    agent_resolver,
)


USER_EVENT = {
    "role": "user",
    "parts": [{"kind": "text", "text": "Hi"}],
    "input_tokens": 0,
    "output_tokens": 0,
}


def make_agent(responses: list[tuple[str, dict]]):
    """Create a runner + router for a standard agent with mock LLM."""
    tds = stdlib()
    source = MockSource([LLM_PAIR], responses)
    router = Router([Connection("llm", source)])
    config = agent_config()
    runner = SessionRunner(tds, config)
    return runner, router


# Note: agent_resolver is still imported for use outside SessionRunner


# ════════════════════════════════════════════════════════════════
# Default callbacks (backwards compatible)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_run_turn_basic():
    """User message → LLM dispatch → text response → done."""
    runner, router = make_agent([text_response("Hello!")])

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
    )

    dispatched = [e for e in events if e.type == "dispatched"]
    completed = [e for e in events if e.type == "turn_complete"]
    assert len(dispatched) > 0
    assert len(completed) > 0
    assert runner.is_idle


@pytest.mark.asyncio
async def test_run_turn_source_error():
    """Source failure → dispatch_failed called, session continues."""
    tds = stdlib()
    source = FailingSource([LLM_PAIR])
    router = Router([Connection("llm", source)])
    config = agent_config()
    runner = SessionRunner(tds, config)

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
    )

    assert runner.events_processed >= 1


# ════════════════════════════════════════════════════════════════
# Custom dispatch callback
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_custom_dispatch_intercepts():
    """A custom dispatch callback can intercept and replace source calls."""
    tds = stdlib()
    # Router has a real source but we'll bypass it
    real_source = MockSource([LLM_PAIR], [text_response("from source")])
    router = Router([Connection("llm", real_source)])
    config = agent_config()
    runner = SessionRunner(tds, config)

    async def my_dispatch(request_type: str, request_data: dict):
        """Intercept LlmRequest and return a synthetic response."""
        assert request_type == "LlmRequest"
        return text_response("from callback")

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        dispatch=my_dispatch,
    )

    assert runner.is_idle
    # The response should be from our callback, not the source
    messages = runner.get_state().get("messages", [])
    assistant_texts = [
        p["text"]
        for m in messages if m.get("role") == "assistant"
        for p in m.get("parts", []) if p.get("kind") == "text"
    ]
    assert "from callback" in assistant_texts
    assert "from source" not in assistant_texts


@pytest.mark.asyncio
async def test_custom_dispatch_error_handling():
    """A custom dispatch that raises gets handled as dispatch_failed."""
    tds = stdlib()
    source = MockSource([LLM_PAIR], [])
    router = Router([Connection("llm", source)])
    config = agent_config()
    runner = SessionRunner(tds, config)

    async def failing_dispatch(request_type: str, request_data: dict):
        raise RuntimeError("custom dispatch failed")

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        dispatch=failing_dispatch,
    )

    # Should not raise — error injected into kernel
    assert runner.events_processed >= 2  # Input + error


# ════════════════════════════════════════════════════════════════
# Custom check callback
# ════════════════════════════════════════════════════════════════


def _checked_agent_config():
    """Agent config with LlmRequest requiring a check."""
    import json
    return __import__("gamelan").SessionConfig(json.dumps([
        {
            "request_type": "LlmRequest",
            "result_type": "LlmResponse",
            "has_check": True,
            "check_source": "approval",
        },
        {
            "request_type": "ToolRequest",
            "result_type": "ToolResult",
            "has_check": False,
            "check_source": None,
        },
    ]))


@pytest.mark.asyncio
async def test_custom_check_approve():
    """A custom check callback can approve requests."""
    tds = stdlib()
    source = MockSource([LLM_PAIR], [text_response("approved response")])
    router = Router([Connection("llm", source)])
    config = _checked_agent_config()
    runner = SessionRunner(tds, config)

    approvals = []

    async def my_check(event_tag: str, event_data: dict):
        approvals.append(event_tag)
        return Approve()

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        check=my_check,
    )

    assert runner.is_idle
    assert "LlmRequest" in approvals


@pytest.mark.asyncio
async def test_custom_check_reject():
    """A custom check callback can reject requests — no dispatch happens."""
    tds = stdlib()
    source = MockSource([LLM_PAIR], [text_response("should not see")])
    router = Router([Connection("llm", source)])
    config = _checked_agent_config()
    runner = SessionRunner(tds, config)

    async def reject_all(event_tag: str, event_data: dict):
        return Reject(reason="nope")

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        check=reject_all,
    )

    # No dispatch should have happened (check was rejected)
    dispatched = [e for e in events if e.type == "dispatched"]
    assert len(dispatched) == 0


# ════════════════════════════════════════════════════════════════
# Observe callback
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_observe_sees_dispatches():
    """The observe callback is called for each dispatch step."""
    runner, router = make_agent([text_response("Hello!")])

    observed: list[TurnEvent] = []

    async def my_observe(event: TurnEvent):
        observed.append(event)

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        observe=my_observe,
    )

    assert runner.is_idle
    assert any(isinstance(e, Dispatched) for e in observed)
    dispatched = [e for e in observed if isinstance(e, Dispatched)]
    assert dispatched[0].request_type == "LlmRequest"


@pytest.mark.asyncio
async def test_observe_sees_failures():
    """The observe callback sees dispatch failures."""
    tds = stdlib()
    source = FailingSource([LLM_PAIR])
    router = Router([Connection("llm", source)])
    config = agent_config()
    runner = SessionRunner(tds, config)

    observed: list[TurnEvent] = []

    async def my_observe(event: TurnEvent):
        observed.append(event)

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        observe=my_observe,
    )

    assert any(isinstance(e, DispatchFailed) for e in observed)


@pytest.mark.asyncio
async def test_observe_sees_check_verdicts():
    """The observe callback sees check verdicts."""
    tds = stdlib()
    source = MockSource([LLM_PAIR], [text_response("checked response")])
    router = Router([Connection("llm", source)])
    config = _checked_agent_config()
    runner = SessionRunner(tds, config)

    observed: list[TurnEvent] = []

    async def my_observe(event: TurnEvent):
        observed.append(event)

    async def approve_all(event_tag: str, event_data: dict):
        return Approve()

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        check=approve_all,
        observe=my_observe,
    )

    check_events = [e for e in observed if isinstance(e, CheckResolved)]
    assert len(check_events) > 0
    assert check_events[0].event_tag == "LlmRequest"
    assert isinstance(check_events[0].verdict, Approve)
