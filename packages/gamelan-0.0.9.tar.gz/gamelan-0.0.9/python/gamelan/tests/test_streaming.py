"""Test streaming channel and events."""

import pytest

from gamelan.streaming import (
    StreamSender,
    StreamReceiver,
    TextDelta,
    ThinkingDelta,
    ToolCallStart,
    ToolCallDelta,
    StreamDone,
    stream_channel,
)


@pytest.mark.asyncio
async def test_stream_channel_sends_and_receives():
    tx, rx = stream_channel()

    tx.send(TextDelta(text="Hello"))
    tx.send(ToolCallStart(id="tc1", name="read"))
    tx.done()

    e1 = await rx.recv()
    assert isinstance(e1, TextDelta)
    assert e1.text == "Hello"

    e2 = await rx.recv()
    assert isinstance(e2, ToolCallStart)
    assert e2.name == "read"

    e3 = await rx.recv()
    assert isinstance(e3, StreamDone)

    e4 = await rx.recv()
    assert e4 is None


@pytest.mark.asyncio
async def test_multiple_receivers():
    tx = StreamSender()
    rx1 = tx.subscribe()
    rx2 = tx.subscribe()

    tx.send(TextDelta(text="hi"))
    tx.done()

    e1 = await rx1.recv()
    e2 = await rx2.recv()
    assert isinstance(e1, TextDelta)
    assert isinstance(e2, TextDelta)


@pytest.mark.asyncio
async def test_async_iterator():
    tx, rx = stream_channel()

    tx.send(TextDelta(text="a"))
    tx.send(TextDelta(text="b"))
    tx.done()

    texts = []
    async for event in rx:
        if isinstance(event, TextDelta):
            texts.append(event.text)
    assert texts == ["a", "b"]


@pytest.mark.asyncio
async def test_all_event_types():
    tx, rx = stream_channel()

    tx.send(TextDelta(text="hello"))
    tx.send(ThinkingDelta(text="hmm"))
    tx.send(ToolCallStart(id="tc1", name="read"))
    tx.send(ToolCallDelta(id="tc1", json_delta='{"path":'))
    tx.done()

    events = []
    async for event in rx:
        events.append(event)

    assert len(events) == 5  # 4 deltas + Done
    assert isinstance(events[0], TextDelta)
    assert isinstance(events[1], ThinkingDelta)
    assert isinstance(events[2], ToolCallStart)
    assert isinstance(events[3], ToolCallDelta)
    assert isinstance(events[4], StreamDone)
