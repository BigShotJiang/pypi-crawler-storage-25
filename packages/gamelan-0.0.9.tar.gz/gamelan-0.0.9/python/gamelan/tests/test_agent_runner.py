"""Tests for AgentRunner — async turn loop wrapping SessionRunner + Executor."""

import asyncio
import json
import pytest

from gamelan._core import SessionConfig, stdlib
from gamelan.agent_runner import AgentRunner
from gamelan.check import Approve
from gamelan.executor import Executor
from gamelan.runner import RunnerEvent


# ════════════════════════════════════════════════════════════════
# Mock executor
# ════════════════════════════════════════════════════════════════


class MockExecutor:
    """Auto-completes dispatches by converting Request → Result."""

    async def dispatch_one(self, request_type, request_data, source_id):
        result_tag = request_type.replace("Request", "Result").replace("request", "result")
        return [{"result_tag": result_tag, "result_data": {}}]

    async def check_outbound(self, check_source, request_type, request_data):
        return Approve()

    async def check_inbound(self, info):
        return Approve()


# ════════════════════════════════════════════════════════════════
# Tests
# ════════════════════════════════════════════════════════════════


LLM_PAIR = {"request_type": "LlmRequest", "result_type": "LlmResult", "has_check": False}


@pytest.mark.asyncio
async def test_run_turn_basic():
    tds = stdlib()
    config = SessionConfig(json.dumps([LLM_PAIR]))
    runner = AgentRunner(tds, config, lambda rt: "llm" if rt == "LlmRequest" else None)

    events = await runner.run_turn(MockExecutor(), "LlmResponse", {"role": "user", "parts": [{"kind": "text", "text": "hi"}], "input_tokens": 0, "output_tokens": 0})

    assert runner.is_idle
    assert any(e.type == "turn_complete" for e in events)


@pytest.mark.asyncio
async def test_run_turn_emits_event_type():
    tds = stdlib()
    config = SessionConfig(json.dumps([LLM_PAIR]))
    runner = AgentRunner(tds, config, lambda rt: "llm" if rt == "LlmRequest" else None)

    events = await runner.run_turn(MockExecutor(), "LlmResponse", {"role": "user", "parts": [{"kind": "text", "text": "hi"}], "input_tokens": 0, "output_tokens": 0})

    # Should have Event type (fold input)
    event_events = [e for e in events if e.type == "event"]
    assert len(event_events) > 0
    assert event_events[0].event_tag == "LlmResponse"


@pytest.mark.asyncio
async def test_stream_turn():
    tds = stdlib()
    config = SessionConfig(json.dumps([LLM_PAIR]))
    runner = AgentRunner(tds, config, lambda rt: "llm" if rt == "LlmRequest" else None)

    q: asyncio.Queue = asyncio.Queue()
    await runner.stream_turn(MockExecutor(), "LlmResponse", {"role": "user", "parts": [{"kind": "text", "text": "hi"}], "input_tokens": 0, "output_tokens": 0}, q)

    events = []
    while not q.empty():
        events.append(q.get_nowait())

    assert any(e.type == "turn_complete" for e in events)
    assert any(e.type == "event" for e in events)
