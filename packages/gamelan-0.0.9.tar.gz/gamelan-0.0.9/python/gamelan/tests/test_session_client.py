"""Tests for NetworkClient — per-agent sources, validated config."""

import json
import pytest

from gamelan._core import SessionConfig, stdlib
from gamelan.network_runner import AgentDef, SessionEvent
from gamelan.session_client import NetworkClient
from tests.conftest import MockSource, LLM_PAIR


# ════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════


def make_agent():
    """Returns (AgentDef, sources) tuple for a simple agent."""
    agent_def = AgentDef(
        transducers=stdlib(),
        config=SessionConfig(json.dumps([
            {"request_type": "LlmRequest", "result_type": "LlmResult", "has_check": False},
        ])),
        resolve_source=lambda rt: "llm" if rt == "LlmRequest" else None,
    )
    llm = MockSource([LLM_PAIR], [
        ("LlmResult", {"role": "assistant", "parts": [{"kind": "text", "text": "ok"}]}),
    ])
    return agent_def, {"llm": llm}


# ════════════════════════════════════════════════════════════════
# Tests
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_send_message_streams():
    client = NetworkClient(
        agents={"agent_a": make_agent()},
        entry_point="agent_a",
    )

    events = []
    async for event in client.send_message("hello"):
        events.append(event)

    assert len(events) > 0
    agent_events = [e for e in events if e.type == "agent"]
    assert len(agent_events) > 0
    assert all(e.agent == "agent_a" for e in agent_events)


@pytest.mark.asyncio
async def test_active_agent():
    client = NetworkClient(
        agents={"agent_a": make_agent()},
        entry_point="agent_a",
    )
    assert client.active_agent == "agent_a"


@pytest.mark.asyncio
async def test_delegation_graph_empty():
    client = NetworkClient(
        agents={"agent_a": make_agent()},
        entry_point="agent_a",
    )
    assert client.delegation_graph == []
    assert client.delegated_agents() == []


@pytest.mark.asyncio
async def test_has_runner_lazy():
    client = NetworkClient(
        agents={"agent_a": make_agent()},
        entry_point="agent_a",
    )
    assert not client.has_runner("agent_a")
    async for _ in client.send_message("hello"):
        pass
    assert client.has_runner("agent_a")


@pytest.mark.asyncio
async def test_can_collect_to_list():
    client = NetworkClient(
        agents={"agent_a": make_agent()},
        entry_point="agent_a",
    )
    events = [e async for e in client.send_message("hello")]
    assert len(events) > 0
