"""Test SessionDef load/validate via PyO3 bindings.

Matches session_def.qnt tests.
"""

import json

import pytest

from gamelan import load_session_def, validate_session_def, validate_session_def_strict


BASIC_AGENT = {
    "name": "basic_agent",
    "transducers": ["messages", "blocks", "usage", "call_llm", "execute_tool", "summary"],
    "connections": [
        {
            "source_id": "llm",
            "pairs": [{"request_type": "LlmRequest", "result_type": "LlmResponse"}],
            "checks": [],
        },
        {
            "source_id": "tools",
            "pairs": [{"request_type": "ToolRequest", "result_type": "ToolResult"}],
            "checks": [],
        },
    ],
    "config": {},
}

APPROVED_AGENT = {
    "name": "approved_agent",
    "transducers": ["messages", "blocks", "usage", "call_llm", "execute_tool", "summary"],
    "connections": [
        {
            "source_id": "llm",
            "pairs": [{"request_type": "LlmRequest", "result_type": "LlmResponse"}],
            "checks": [],
        },
        {
            "source_id": "tools",
            "pairs": [{"request_type": "ToolRequest", "result_type": "ToolResult"}],
            "checks": [{"intercept": "ToolRequest", "direction": "outbound", "check_source": "approval"}],
        },
        {
            "source_id": "approval",
            "pairs": [{"request_type": "CheckRequest", "result_type": "CheckResult"}],
            "checks": [],
        },
    ],
    "config": {},
}


class TestLoad:
    def test_load_basic_agent(self):
        result = load_session_def(json.dumps(BASIC_AGENT))
        assert "topology_json" in result
        assert "source_ids" in result
        topo = json.loads(result["topology_json"])
        assert len(topo) == 2
        assert set(result["source_ids"]) == {"llm", "tools"}
        assert len(result["transducer_names"]) == 6

    def test_load_approved_agent(self):
        result = load_session_def(json.dumps(APPROVED_AGENT))
        topo = json.loads(result["topology_json"])
        # LlmRequest (unchecked) + ToolRequest (checked) + CheckRequest (unchecked)
        assert len(topo) == 3
        checked = [t for t in topo if t["has_check"]]
        assert len(checked) == 1
        assert checked[0]["request_type"] == "ToolRequest"


class TestValidate:
    def test_valid_agents(self):
        errors = validate_session_def(json.dumps(BASIC_AGENT))
        assert errors == []
        errors = validate_session_def(json.dumps(APPROVED_AGENT))
        assert errors == []

    def test_invalid_check_source(self):
        sd = {
            "name": "bad",
            "transducers": ["messages"],
            "connections": [{
                "source_id": "tools",
                "pairs": [{"request_type": "ToolRequest", "result_type": "ToolResult"}],
                "checks": [{"intercept": "ToolRequest", "direction": "outbound", "check_source": "nonexistent"}],
            }],
            "config": {},
        }
        errors = validate_session_def(json.dumps(sd))
        assert len(errors) > 0

    def test_invalid_duplicate_source_ids(self):
        sd = {
            "name": "bad",
            "transducers": ["messages"],
            "connections": [
                {"source_id": "tools", "pairs": [{"request_type": "ToolRequest", "result_type": "ToolResult"}], "checks": []},
                {"source_id": "tools", "pairs": [{"request_type": "LlmRequest", "result_type": "LlmResponse"}], "checks": []},
            ],
            "config": {},
        }
        errors = validate_session_def(json.dumps(sd))
        assert len(errors) > 0

    def test_invalid_transducer_name(self):
        sd = {
            "name": "bad",
            "transducers": ["messages", "nonexistent"],
            "connections": [],
            "config": {},
        }
        errors = validate_session_def(json.dumps(sd))
        assert len(errors) > 0


class TestValidateStrict:
    def test_valid_passes(self):
        validate_session_def_strict(json.dumps(BASIC_AGENT))

    def test_invalid_raises(self):
        sd = {
            "name": "bad",
            "transducers": ["nonexistent"],
            "connections": [],
            "config": {},
        }
        with pytest.raises(ValueError):
            validate_session_def_strict(json.dumps(sd))
