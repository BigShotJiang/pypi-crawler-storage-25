"""Model-based testing: replay Quint ITF traces against Python models.

Replays session_loop.qnt and session_store.qnt traces, checking
invariants at every step. Same traces as the Rust MBT tests.
"""

import json
from pathlib import Path

import pytest

# Fixture directories (relative to the workspace root)
FIXTURE_ROOT = Path(__file__).resolve().parent.parent.parent.parent / "rust"
SESSION_LOOP_TRACES = FIXTURE_ROOT / "gamelan-core" / "tests" / "fixtures" / "session_loop_traces"
SESSION_STORE_TRACES = FIXTURE_ROOT / "gamelan" / "tests" / "fixtures" / "session_store_traces"


# ════════════════════════════════════════════════════════════════
# ITF parsing helpers
# ════════════════════════════════════════════════════════════════


def parse_bigint(v) -> int:
    if isinstance(v, dict) and "#bigint" in v:
        return int(v["#bigint"])
    if isinstance(v, (int, float)):
        return int(v)
    raise ValueError(f"expected bigint, got: {v}")


def parse_tag(v) -> str:
    return v["tag"]


def parse_str_list(v) -> list[str]:
    return [s for s in v]


def parse_set_of(v, parser):
    return {parser(item) for item in v["#set"]}


def parse_map_of(v, parser):
    return {entry[0]: parser(entry[1]) for entry in v["#map"]}


# ════════════════════════════════════════════════════════════════
# Session Loop MBT
# ════════════════════════════════════════════════════════════════


def parse_loop_state(state):
    in_flight = parse_set_of(state["in_flight"], lambda v: (
        v["request_type"], v["source_id"]
    ))
    in_flight_check = parse_set_of(state["in_flight_check"], lambda v: (
        v["event_tag"], v["source_id"]
    ))
    return {
        "phase": parse_tag(state["phase"]),
        "in_flight": in_flight,
        "in_flight_check": in_flight_check,
        "event_log": parse_str_list(state["event_log"]),
        "kernel_pending": parse_str_list(state["kernel_pending"]),
        "events_processed": parse_bigint(state["events_processed"]),
    }


def check_loop_invariants(step: int, s: dict, errors: list[str]):
    # in_flight_implies_pending
    pending_set = set(s["kernel_pending"])
    for req_type, source_id in s["in_flight"]:
        if req_type not in pending_set:
            errors.append(
                f"step {step}: in-flight {req_type} has no matching pending"
            )

    # events_processed matches event_log length
    if s["events_processed"] != len(s["event_log"]):
        errors.append(
            f"step {step}: events_processed ({s['events_processed']}) "
            f"!= event_log.len() ({len(s['event_log'])})"
        )


def check_loop_sequential(step: int, prev: dict, next_: dict, errors: list[str]):
    # Event log grows monotonically
    if len(next_["event_log"]) < len(prev["event_log"]):
        errors.append(
            f"step {step}: event_log shrank from {len(prev['event_log'])} "
            f"to {len(next_['event_log'])}"
        )

    # Event log prefix preserved
    for j in range(min(len(prev["event_log"]), len(next_["event_log"]))):
        if prev["event_log"][j] != next_["event_log"][j]:
            errors.append(
                f"step {step}: event_log[{j}] changed from "
                f"{prev['event_log'][j]} to {next_['event_log'][j]}"
            )


def replay_loop_trace(path: Path):
    content = json.loads(path.read_text())
    states = content["states"]
    errors: list[str] = []

    for i, state_json in enumerate(states):
        parsed = parse_loop_state(state_json)
        check_loop_invariants(i, parsed, errors)

    for i in range(1, len(states)):
        prev = parse_loop_state(states[i - 1])
        next_ = parse_loop_state(states[i])
        check_loop_sequential(i, prev, next_, errors)

    assert not errors, (
        f"Trace {path.name} had {len(errors)} issues:\n" + "\n".join(errors)
    )


# ════════════════════════════════════════════════════════════════
# Session Store MBT
# ════════════════════════════════════════════════════════════════


def parse_store_state(state):
    sessions = parse_map_of(state["sessions"], lambda v: {
        "id": v["id"],
        "created_at": parse_bigint(v["created_at"]),
        "updated_at": parse_bigint(v["updated_at"]),
        "event_count": parse_bigint(v["event_count"]),
        "title": v["title"],
    })
    logs = parse_map_of(state["logs"], parse_str_list)
    return {"sessions": sessions, "logs": logs}


def check_store_invariants(step: int, s: dict, errors: list[str]):
    # event_count_consistent
    for id_, info in s["sessions"].items():
        if id_ in s["logs"]:
            if info["event_count"] != len(s["logs"][id_]):
                errors.append(
                    f"step {step}: session {id_}: event_count ({info['event_count']}) "
                    f"!= log.len() ({len(s['logs'][id_])})"
                )

    # sessions_have_logs
    for id_ in s["sessions"]:
        if id_ not in s["logs"]:
            errors.append(f"step {step}: session {id_} has no log")

    # logs_have_sessions
    for id_ in s["logs"]:
        if id_ not in s["sessions"]:
            errors.append(f"step {step}: log {id_} has no session")


def check_store_sequential(step: int, prev: dict, next_: dict, errors: list[str]):
    for id_, prev_log in prev["logs"].items():
        if id_ in next_["logs"]:
            next_log = next_["logs"][id_]
            if len(next_log) >= len(prev_log):
                for j in range(len(prev_log)):
                    if prev_log[j] != next_log[j]:
                        errors.append(
                            f"step {step}: session {id_}: log[{j}] changed "
                            f"from {prev_log[j]} to {next_log[j]}"
                        )


def replay_store_trace(path: Path):
    content = json.loads(path.read_text())
    states = content["states"]
    errors: list[str] = []

    for i, state_json in enumerate(states):
        parsed = parse_store_state(state_json)
        check_store_invariants(i, parsed, errors)

    for i in range(1, len(states)):
        prev = parse_store_state(states[i - 1])
        next_ = parse_store_state(states[i])
        check_store_sequential(i, prev, next_, errors)

    assert not errors, (
        f"Trace {path.name} had {len(errors)} issues:\n" + "\n".join(errors)
    )


# ════════════════════════════════════════════════════════════════
# Tests — parametrize over all trace files
# ════════════════════════════════════════════════════════════════


def collect_traces(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob("*.itf.json"))


session_loop_traces = collect_traces(SESSION_LOOP_TRACES)
session_store_traces = collect_traces(SESSION_STORE_TRACES)


@pytest.mark.parametrize(
    "trace_path",
    session_loop_traces,
    ids=[p.stem for p in session_loop_traces],
)
def test_session_loop_trace(trace_path: Path):
    replay_loop_trace(trace_path)


@pytest.mark.parametrize(
    "trace_path",
    session_store_traces,
    ids=[p.stem for p in session_store_traces],
)
def test_session_store_trace(trace_path: Path):
    replay_store_trace(trace_path)
