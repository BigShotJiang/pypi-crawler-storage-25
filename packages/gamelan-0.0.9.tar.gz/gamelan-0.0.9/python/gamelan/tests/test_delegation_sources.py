"""Tests for delegation sources.

Tests:
1. Pure source unit tests (data transformation, no network)
2. Network-integrated delegation via DelegationAwaiter + NetworkRunner
3. Concurrent fan-out (proves children drive in parallel)
"""

import asyncio
import json
import time

import pytest

from gamelan import (
    Connection,
    SyncDelegationSource,
    AsyncDelegationSource,
    DelegationAwaiter,
    stdlib,
)
from gamelan._core import SessionConfig
from gamelan.network_runner import AgentDef, NetworkRunner
from gamelan.executor import Executor
from gamelan.check import Approve
from gamelan.runner import InboundCheckInfo
from tests.conftest import (
    MockSource,
    LLM_PAIR,
    text_response,
    agent_config,
    agent_resolver,
)


# ════════════════════════════════════════════════════════════════
# Slow mock for concurrency testing
# ════════════════════════════════════════════════════════════════


class SlowMockSource:
    """Mock source that sleeps before responding."""

    def __init__(self, delay: float, response: tuple[str, dict]):
        self._delay = delay
        self._response = response

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        await asyncio.sleep(self._delay)
        return self._response

    def interface(self) -> list[dict]:
        return [LLM_PAIR]


# ════════════════════════════════════════════════════════════════
# Pure source unit tests (no network, no SessionManager)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_sync_source_returns_delegation_request():
    source = SyncDelegationSource().with_child("researcher")
    tag, data = await source.dispatch("ToolRequest", {
        "name": "researcher",
        "id": "tc1",
        "arguments": json.dumps({"message": "What is Rust?"}),
    })
    assert tag == "DelegationRequest"
    assert data["child"] == "researcher"
    assert data["message"] == "What is Rust?"


@pytest.mark.asyncio
async def test_sync_source_unknown_tool_error():
    source = SyncDelegationSource().with_child("researcher")
    with pytest.raises(LookupError):
        await source.dispatch("ToolRequest", {"name": "nonexistent"})


@pytest.mark.asyncio
async def test_sync_source_discovers_tools():
    source = SyncDelegationSource().with_child("researcher").with_child("coder")
    tools = await source.discover()
    assert len(tools) == 2
    names = {t["name"] for t in tools}
    assert names == {"researcher", "coder"}


@pytest.mark.asyncio
async def test_async_source_spawn_returns_delegation_request():
    source = AsyncDelegationSource().with_child("researcher")
    tag, data = await source.dispatch("ToolRequest", {
        "name": "spawn_agent",
        "id": "tc1",
        "arguments": json.dumps({"definition": "researcher", "message": "Research it"}),
    })
    assert tag == "DelegationRequest"
    assert data["child"] == "researcher"
    assert data["message"] == "Research it"


@pytest.mark.asyncio
async def test_async_source_wait_returns_wait_delegation():
    source = AsyncDelegationSource().with_child("researcher")
    tag, data = await source.dispatch("ToolRequest", {
        "name": "wait_agent",
        "id": "tc1",
        "arguments": json.dumps({"handles": ["r1"]}),
    })
    assert tag == "WaitDelegation"
    assert data["handles"] == ["r1"]


@pytest.mark.asyncio
async def test_async_source_spawn_unknown_definition():
    source = AsyncDelegationSource().with_child("researcher")
    with pytest.raises(LookupError):
        await source.dispatch("ToolRequest", {
            "name": "spawn_agent",
            "arguments": json.dumps({"definition": "nonexistent", "message": "hi"}),
        })
