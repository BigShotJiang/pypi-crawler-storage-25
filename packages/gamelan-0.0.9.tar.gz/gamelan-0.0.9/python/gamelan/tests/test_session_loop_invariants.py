"""Property-based invariant tests for the session loop.

Drives the REAL SessionRunner (which wraps the real kernel) with random
action sequences. Checks invariants from session_loop.qnt after every step.

Python port of rust/gamelan/tests/session_loop_invariants.rs.
"""

import json
from enum import Enum, auto

from hypothesis import given, settings
from hypothesis.strategies import lists, sampled_from

from gamelan import SessionConfig, SessionRunner, stdlib


# ════════════════════════════════════════════════════════════════
# Setup — stdlib transducers emit LlmRequest and ToolRequest
# ════════════════════════════════════════════════════════════════


def make_config() -> SessionConfig:
    topology = json.dumps([
        {
            "request_type": "LlmRequest",
            "result_type": "LlmResponse",
            "has_check": False,
            "check_source": None,
        },
        {
            "request_type": "ToolRequest",
            "result_type": "ToolResult",
            "has_check": True,
            "check_source": "approval",
        },
    ])
    return SessionConfig(topology)


def make_runner() -> SessionRunner:
    return SessionRunner(stdlib(), make_config())


# ════════════════════════════════════════════════════════════════
# Invariant checks — mirrors session_loop.qnt
# ════════════════════════════════════════════════════════════════


def check_pending_consistency(r: SessionRunner):
    """Pending list should be a list of strings (request types)."""
    pending = r.pending
    assert isinstance(pending, list)
    for p in pending:
        assert isinstance(p, str)


def check_events_processed_monotonic(r: SessionRunner, prev_count: int):
    """events_processed should only increase."""
    assert r.events_processed >= prev_count


def check_all_invariants(r: SessionRunner):
    check_pending_consistency(r)


# ════════════════════════════════════════════════════════════════
# Action generation
# ════════════════════════════════════════════════════════════════


class LoopAction(Enum):
    RECEIVE_INPUT = auto()
    RECEIVE_LLM_RESPONSE = auto()
    RECEIVE_TOOL_RESULT = auto()
    CANCEL_TOOL_REQUEST = auto()


def apply_action(r: SessionRunner, action: LoopAction):
    if action == LoopAction.RECEIVE_INPUT:
        r.fold_event("Input", {})
    elif action == LoopAction.RECEIVE_LLM_RESPONSE:
        r.fold_event("LlmResponse", {})
    elif action == LoopAction.RECEIVE_TOOL_RESULT:
        r.fold_event("ToolResult", {})
    elif action == LoopAction.CANCEL_TOOL_REQUEST:
        try:
            r.cancel_request("ToolRequest")
        except Exception:
            pass  # May fail if nothing to cancel


# ════════════════════════════════════════════════════════════════
# Property tests — 10,000 random action sequences on REAL kernel
# ════════════════════════════════════════════════════════════════


@settings(max_examples=10000)
@given(actions=lists(sampled_from(LoopAction), min_size=1, max_size=40))
def test_session_loop_invariants(actions):
    runner = make_runner()
    check_all_invariants(runner)

    for action in actions:
        apply_action(runner, action)
        check_all_invariants(runner)


@settings(max_examples=10000)
@given(actions=lists(sampled_from(LoopAction), min_size=1, max_size=20))
def test_kernel_determinism(actions):
    """Same actions → same state."""
    r1 = make_runner()
    r2 = make_runner()

    for action in actions:
        apply_action(r1, action)
        apply_action(r2, action)

    s1 = r1.get_state()
    s2 = r2.get_state()
    assert s1 == s2
    assert r1.pending == r2.pending
    assert r1.events_processed == r2.events_processed
