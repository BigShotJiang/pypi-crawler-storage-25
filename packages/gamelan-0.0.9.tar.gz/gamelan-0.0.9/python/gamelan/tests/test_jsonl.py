"""Test JSONL persistence stores."""

import pytest
from pathlib import Path

from gamelan import Snapshot
from gamelan.jsonl import JsonlEventLog, JsonlSessionStore, JsonlSnapshotStore


@pytest.fixture
def tmp_dir(tmp_path):
    return tmp_path


class TestJsonlEventLog:
    def test_append_and_load(self, tmp_dir):
        path = tmp_dir / "events.jsonl"
        log = JsonlEventLog.create(path)
        assert len(log) == 0

        log.append(("Input", {}))
        log.append(("LlmResponse", {"role": "assistant"}))
        assert len(log) == 2

        events = log.load()
        assert len(events) == 2
        assert events[0][0] == "Input"
        assert events[1][0] == "LlmResponse"

    def test_persistence_across_reopen(self, tmp_dir):
        path = tmp_dir / "events.jsonl"
        log = JsonlEventLog.create(path)
        log.append(("Input", {}))
        log.append(("LlmResponse", {}))

        log2 = JsonlEventLog.open(path)
        assert len(log2) == 2
        events = log2.load()
        assert len(events) == 2

    def test_load_after(self, tmp_dir):
        path = tmp_dir / "events.jsonl"
        log = JsonlEventLog.create(path)
        log.append(("A", {}))
        log.append(("B", {}))
        log.append(("C", {}))

        after = log.load_after(1)
        assert len(after) == 2
        assert after[0][0] == "B"
        assert after[1][0] == "C"

    def test_load_with_data(self, tmp_dir):
        path = tmp_dir / "events.jsonl"
        log = JsonlEventLog.create(path)
        log.append(("Input", {"text": "hello"}))

        events = log.load()
        assert events[0][1]["text"] == "hello"


@pytest.mark.asyncio
class TestJsonlSessionStore:
    async def test_crud(self, tmp_dir):
        store = JsonlSessionStore(tmp_dir / "sessions")

        # Create
        log = await store.create("s1")
        with pytest.raises(ValueError):
            await store.create("s1")

        # Append events
        log.append(("Input", {}))
        log.append(("LlmResponse", {}))

        # List
        sessions = await store.list()
        assert len(sessions) == 1
        assert sessions[0]["id"] == "s1"

        # Load (reopens from disk)
        loaded = await store.load("s1")
        events = loaded.load()
        assert len(events) == 2

        # Delete
        await store.delete("s1")
        with pytest.raises(KeyError):
            await store.delete("s1")
        sessions = await store.list()
        assert len(sessions) == 0

    async def test_multiple_sessions(self, tmp_dir):
        store = JsonlSessionStore(tmp_dir / "sessions")

        log1 = await store.create("s1")
        log2 = await store.create("s2")

        log1.append(("A", {}))
        log1.append(("B", {}))
        log2.append(("C", {}))

        loaded1 = await store.load("s1")
        loaded2 = await store.load("s2")
        assert len(loaded1.load()) == 2
        assert len(loaded2.load()) == 1

    async def test_update_info(self, tmp_dir):
        store = JsonlSessionStore(tmp_dir / "sessions")
        await store.create("s1")

        sessions = await store.list()
        info = sessions[0]
        info["title"] = "My Session"
        info["event_count"] = 42
        await store.update_info("s1", info)

        sessions = await store.list()
        assert sessions[0]["title"] == "My Session"
        assert sessions[0]["event_count"] == 42


@pytest.mark.asyncio
class TestJsonlSnapshotStore:
    async def test_save_and_load(self, tmp_dir):
        store = JsonlSnapshotStore(tmp_dir / "sessions")

        assert await store.load("s1") is None

        snap = Snapshot.from_json('{"pending":["WorkRequest"],"vm_env":{},"event_count":5}')
        await store.save("s1", snap)

        loaded = await store.load("s1")
        assert loaded is not None
        assert loaded.event_count == 5
        assert loaded.pending == ["WorkRequest"]

    async def test_overwrite(self, tmp_dir):
        store = JsonlSnapshotStore(tmp_dir / "sessions")

        snap1 = Snapshot.from_json('{"pending":[],"vm_env":{},"event_count":5}')
        await store.save("s1", snap1)

        snap2 = Snapshot.from_json('{"pending":[],"vm_env":{},"event_count":10}')
        await store.save("s1", snap2)

        loaded = await store.load("s1")
        assert loaded.event_count == 10
