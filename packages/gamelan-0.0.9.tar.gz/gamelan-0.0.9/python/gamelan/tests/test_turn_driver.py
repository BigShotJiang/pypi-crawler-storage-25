"""Test turn_driver — the bidirectional async generator.

turn_driver is the primary API. It yields TurnStep values and receives
results back via asend(). These tests exercise the generator protocol
directly, not through run_turn callbacks.
"""

import pytest

from gamelan import (
    Approve,
    CheckNeeded,
    Complete,
    DispatchReady,
    Reject,
    SessionRunner,
    stdlib,
    turn_driver,
)
from gamelan.check import OutboundCheckEntry, AutoApprove
from tests.conftest import (
    MockSource,
    FailingSource,
    LLM_PAIR,
    TOOL_PAIR,
    text_response,
    tool_call_response,
    agent_config,
    agent_resolver,
)


def tool_result(call_id: str, name: str, content: str) -> tuple[str, dict]:
    """Build a ToolResult event."""
    return ("ToolResult", {
        "key": f"ToolRequest:{call_id}",
        "tool_call_id": call_id,
        "name": name,
        "content": [{"content_type": "text", "text": content}],
        "is_error": False,
    })


USER_EVENT = {
    "role": "user",
    "parts": [{"kind": "text", "text": "Hi"}],
    "input_tokens": 0,
    "output_tokens": 0,
}


def make_runner():
    """Create a runner with stdlib transducers and agent config."""
    return SessionRunner(stdlib(), agent_config())


# ════════════════════════════════════════════════════════════════
# Basic step protocol
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_basic_dispatch():
    """User message → DispatchReady(LlmRequest) → send result → Complete."""
    runner = make_runner()
    response = text_response("Hello!")

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()

    assert isinstance(step, DispatchReady)
    assert step.request_type == "LlmRequest"

    step = await driver.asend(response)
    assert isinstance(step, Complete)
    assert runner.is_idle


@pytest.mark.asyncio
async def test_dispatch_failure_via_none():
    """Sending None signals dispatch failure."""
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)

    step = await driver.asend(None)
    assert isinstance(step, Complete)
    # Kernel saw the error event
    assert runner.events_processed >= 2


@pytest.mark.asyncio
async def test_tool_loop():
    """LLM calls a tool, gets result, responds with text."""
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)

    # Step 1: LlmRequest dispatch
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)
    assert step.request_type == "LlmRequest"

    # LLM responds with a tool call
    step = await driver.asend(tool_call_response("read_file", '{"path":"test.txt"}', "tc1"))

    # Step 2: ToolRequest dispatch
    assert isinstance(step, DispatchReady)
    assert step.request_type == "ToolRequest"

    # Tool returns result
    step = await driver.asend(tool_result("tc1", "read_file", "file contents"))

    # Step 3: LlmRequest again (after tool result)
    assert isinstance(step, DispatchReady)
    assert step.request_type == "LlmRequest"

    # LLM responds with text
    step = await driver.asend(text_response("Based on the file, here's my answer."))

    assert isinstance(step, Complete)
    assert runner.is_idle


# ════════════════════════════════════════════════════════════════
# Check protocol
# ════════════════════════════════════════════════════════════════


def _checked_config():
    """Agent config with LlmRequest requiring a check."""
    import json
    import gamelan
    return gamelan.SessionConfig(json.dumps([
        {
            "request_type": "LlmRequest",
            "result_type": "LlmResponse",
            "has_check": True,
            "check_source": "approval",
        },
    ]))


@pytest.mark.asyncio
async def test_check_approve():
    """CheckNeeded → send Approve → DispatchReady."""
    runner = SessionRunner(stdlib(), _checked_config())

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()

    assert isinstance(step, CheckNeeded)
    assert step.event_tag == "LlmRequest"

    # Approve the check
    step = await driver.asend(Approve())

    # Now dispatch proceeds
    assert isinstance(step, DispatchReady)
    assert step.request_type == "LlmRequest"

    # Send response
    step = await driver.asend(text_response("Approved!"))
    assert isinstance(step, Complete)


@pytest.mark.asyncio
async def test_check_reject():
    """CheckNeeded → send Reject → Complete (no dispatch)."""
    runner = SessionRunner(stdlib(), _checked_config())

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()

    assert isinstance(step, CheckNeeded)

    # Reject
    step = await driver.asend(Reject(reason="denied"))

    # No dispatch — straight to complete
    assert isinstance(step, Complete)


# ════════════════════════════════════════════════════════════════
# Type safety
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_wrong_type_for_dispatch():
    """Sending a non-tuple to DispatchReady raises TypeError."""
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)

    with pytest.raises(TypeError, match="tuple"):
        await driver.asend("wrong type")


@pytest.mark.asyncio
async def test_non_verdict_for_check_treated_as_approve():
    """Sending a non-CheckVerdict to CheckNeeded falls through as approval."""
    runner = SessionRunner(stdlib(), _checked_config())

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    assert isinstance(step, CheckNeeded)

    # Non-verdict falls through to dispatch (treated as implicit approval)
    step = await driver.asend(("wrong", "type"))
    assert isinstance(step, DispatchReady)
    assert step.request_type == "LlmRequest"


# ════════════════════════════════════════════════════════════════
# Multi-turn
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_multi_turn():
    """Runner maintains state across multiple turn_driver invocations."""
    runner = make_runner()

    # Turn 1
    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)
    step = await driver.asend(text_response("Hello!"))
    assert isinstance(step, Complete)

    # Turn 2 — same runner, new driver
    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)
    step = await driver.asend(text_response("How can I help?"))
    assert isinstance(step, Complete)

    assert runner.events_processed >= 4


# ════════════════════════════════════════════════════════════════
# Complete carries events
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_complete_carries_events():
    """Complete step includes all RunnerEvents from the turn."""
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT)
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hi!"))

    assert isinstance(step, Complete)
    assert len(step.events) > 0
    types = [e.type for e in step.events]
    assert "dispatched" in types
    assert "turn_complete" in types
