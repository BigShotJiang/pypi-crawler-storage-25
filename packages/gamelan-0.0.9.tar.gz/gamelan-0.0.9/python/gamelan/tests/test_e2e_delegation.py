"""End-to-end delegation tests via NetworkClient.

Tests the full path: NetworkClient.send_message → NetworkRunner →
per-agent source dispatch → events stream back.

Sources are per-agent per client.qnt spec.
"""

import json

import pytest

from gamelan import (
    stdlib,
    NetworkClient,
    AgentDef,
    ClientConfigError,
)
from gamelan._core import SessionConfig
from gamelan.source import Source
from gamelan.runner import RunnerEvent
from tests.conftest import (
    MockSource,
    LLM_PAIR,
    TOOL_PAIR,
    text_response,
    agent_config,
    agent_resolver,
    llm_only_config,
    llm_only_resolver,
)


# ════════════════════════════════════════════════════════════════
# Tests — single agent through NetworkClient
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_single_agent_text_turn():
    """NetworkClient.send_message → single agent → text response."""
    llm = MockSource([LLM_PAIR], [text_response("Hello!")])

    client = NetworkClient(
        agents={"agent": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": llm})},
        entry_point="agent",
    )

    events = []
    async for event in client.send_message("Hi"):
        events.append(event)

    agent_events = [e for e in events if e.type == "agent"]
    assert len(agent_events) > 0
    assert client.active_agent == "agent"


@pytest.mark.asyncio
async def test_single_agent_tool_turn():
    """NetworkClient → agent → tool call → tool result → final response."""
    llm = MockSource([LLM_PAIR], [
        ("LlmResponse", {
            "role": "assistant",
            "parts": [],
            "tool_calls": [{"id": "tc1", "name": "search", "arguments": '{"q":"rust"}'}],
            "input_tokens": 10,
            "output_tokens": 5,
        }),
        text_response("Rust is a systems language."),
    ])
    tool = MockSource(
        [{"request_type": "ToolRequest", "result_type": "ToolResult"}],
        [("ToolResult", {
            "key": "ToolRequest:tc1",
            "tool_call_id": "tc1", "name": "search",
            "content": "Rust: systems language.", "is_error": False,
        })],
    )

    config = SessionConfig(json.dumps([
        {"request_type": "LlmRequest", "result_type": "LlmResponse", "has_check": False},
        {"request_type": "ToolRequest", "result_type": "ToolResult", "has_check": False},
    ]))

    client = NetworkClient(
        agents={"agent": (
            AgentDef(stdlib(), config, lambda rt: {"LlmRequest": "llm", "ToolRequest": "tools"}.get(rt)),
            {"llm": llm, "tools": tool},
        )},
        entry_point="agent",
    )

    events = []
    async for event in client.send_message("What is Rust?"):
        events.append(event)

    dispatched = [
        e.event.request_type for e in events
        if e.type == "agent" and e.event and e.event.type == "dispatched"
    ]
    assert "LlmRequest" in dispatched
    assert "ToolRequest" in dispatched


# ════════════════════════════════════════════════════════════════
# Tests — multi-agent
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_two_agents_entry_point():
    """Two agents, entry point receives the message."""
    llm = MockSource([LLM_PAIR], [text_response("I'm the parent.")])

    client = NetworkClient(
        agents={
            "parent": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": llm}),
            "child": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": MockSource([LLM_PAIR], [])}),
        },
        delegation_routes=[("parent", "child")],
        entry_point="parent",
    )

    events = []
    async for event in client.send_message("Hello"):
        events.append(event)

    assert client.active_agent == "parent"
    assert len(client.delegation_graph) == 0


# ════════════════════════════════════════════════════════════════
# Validation tests — client.qnt predicates enforced
# ════════════════════════════════════════════════════════════════


def test_missing_entry_point_rejected():
    with pytest.raises(ClientConfigError, match="entry_point"):
        NetworkClient(
            agents={"agent": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": MockSource([LLM_PAIR], [])})},
            entry_point="nonexistent",
        )


def test_self_delegation_rejected():
    with pytest.raises(ClientConfigError, match="self-delegation"):
        NetworkClient(
            agents={"agent": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": MockSource([LLM_PAIR], [])})},
            delegation_routes=[("agent", "agent")],
            entry_point="agent",
        )


def test_dangling_route_rejected():
    with pytest.raises(ClientConfigError, match="not a registered agent"):
        NetworkClient(
            agents={"parent": (AgentDef(stdlib(), llm_only_config(), llm_only_resolver), {"llm": MockSource([LLM_PAIR], [])})},
            delegation_routes=[("parent", "ghost")],
            entry_point="parent",
        )
