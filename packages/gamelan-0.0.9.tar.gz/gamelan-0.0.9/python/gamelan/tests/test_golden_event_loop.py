"""Golden event loop test — verify Python runtime matches the Lean oracle.

Validates that SessionRunner.process_event (Python wrapper around PyO3 kernel)
produces the same state transitions as the Lean turn_loop oracle.

This exercises the Python-specific code: _classify_requests, phase tracking,
in-flight dispatch/check tracking, pending management across turns.

Closes the correspondence chain for Python:
  Lean turn_loop ↔ golden oracle ↔ process_event (Python wrapper) ↔ event loop
"""

import json
from pathlib import Path

import pytest

from gamelan._core import SessionConfig, load_transducer
from gamelan.runner import SessionRunner


FIXTURE_PATH = (
    Path(__file__).parent.parent.parent.parent
    / "rust"
    / "gamelan-core"
    / "tests"
    / "fixtures"
    / "conformance"
    / "golden_turn_loop.json"
)


def _load_fixtures():
    with open(FIXTURE_PATH) as f:
        return json.load(f)


def _json_to_td(jv):
    """Convert JSON transducer def to a PyO3 TransducerDef."""
    return load_transducer(json.dumps(jv))


def _typed_value_to_python(tv):
    """Convert Lean/Rust typed value ({"type": "Int", "value": 42}) to Python native."""
    if isinstance(tv, dict) and "type" in tv:
        t = tv["type"]
        v = tv.get("value")
        if t == "None":
            return None
        elif t == "Bool":
            return v
        elif t == "Int":
            return v
        elif t == "Str":
            return v
        elif t == "List":
            return [_typed_value_to_python(x) for x in (v or [])]
        elif t == "Map":
            if isinstance(v, dict):
                return {k: _typed_value_to_python(val) for k, val in v.items()}
            elif isinstance(v, list):
                # List of [key, value] pairs
                return {item[0]: _typed_value_to_python(item[1]) for item in v}
            return {}
    # Already a native value
    return tv


def _json_to_env(jv):
    """Convert JSON env (with typed values) to Python dict with native values."""
    if jv is None:
        return {}
    return {k: _typed_value_to_python(v) for k, v in jv.items()}


def _parse_topology(case):
    """Parse topology from oracle case."""
    return [
        {
            "request_type": c["request_type"],
            "result_type": c["result_type"],
            "has_check": c["has_check"],
            "check_source": c.get("check_source"),
        }
        for c in case["topology"]
    ]


def _parse_inbound_checks(case):
    return [
        {"intercept": c["intercept"], "check_source": c["check_source"]}
        for c in case["inbound_checks"]
    ]


class TestGoldenProcessEvent:
    """Validate SessionRunner.fold_event against 200 Lean oracle cases."""

    @pytest.fixture(scope="class")
    def fixtures(self):
        if not FIXTURE_PATH.exists():
            pytest.skip(f"Golden fixture not found: {FIXTURE_PATH}")
        return _load_fixtures()

    def test_all_cases_match(self, fixtures):
        passed = 0
        failed = 0
        mismatches = []

        for i, case in enumerate(fixtures):
            topology = _parse_topology(case)
            inbound_checks = _parse_inbound_checks(case)
            tds = [_json_to_td(t) for t in case["transducers"]]
            init_env = _json_to_env(case["init_env"])

            config = SessionConfig(
                topology_json=json.dumps(topology),
                inbound_checks_json=json.dumps(inbound_checks),
            )

            runner = SessionRunner(tds, config)

            # Verify init env matches (transducer slots define it)
            steps = case["steps"]
            case_ok = True

            for j, step in enumerate(steps):
                event_tag = step["event_tag"]
                event_data = _json_to_env(step["event_data"])

                result = runner.fold_event(event_tag, event_data)

                # Verify env matches oracle
                expected_env = _json_to_env(step["result_env"])
                actual_state = runner.get_state()
                for k, expected_v in expected_env.items():
                    actual_v = actual_state.get(k)
                    if actual_v != expected_v:
                        case_ok = False
                        if len(mismatches) < 10:
                            mismatches.append(
                                f"case {i} step {j} env[{k}]: "
                                f"expected {expected_v!r}, got {actual_v!r}"
                            )

            if case_ok:
                passed += 1
            else:
                failed += 1

        for m in mismatches:
            print(m)

        assert failed == 0, f"{failed} cases failed, {passed} passed"
        assert passed == len(fixtures), f"expected {len(fixtures)} cases, got {passed}"


class TestGoldenSessionRunTurn:
    """Validate Session-level run_turn on pure-fold oracle cases."""

    @pytest.fixture(scope="class")
    def fixtures(self):
        if not FIXTURE_PATH.exists():
            pytest.skip(f"Golden fixture not found: {FIXTURE_PATH}")
        return _load_fixtures()

    @pytest.mark.asyncio
    async def test_pure_fold_cases(self, fixtures):
        from gamelan.run import run_turn
        from gamelan.router import Connection, Router
        from gamelan.source import Source

        class EmptySource:
            """Source that should never be called (pure-fold cases have no dispatches)."""

            def __init__(self, pairs):
                self._pairs = pairs

            def interface(self):
                return self._pairs

            async def dispatch(self, tag, data):
                raise RuntimeError("should not be called in pure-fold cases")

        passed = 0
        skipped = 0

        for i, case in enumerate(fixtures):
            topology = _parse_topology(case)
            inbound_checks = _parse_inbound_checks(case)

            # Skip cases with checks or inbound checks
            if any(t["has_check"] for t in topology):
                skipped += 1
                continue
            if inbound_checks:
                skipped += 1
                continue

            steps = case["steps"]
            # Only pure-fold cases (no dispatch actions in any step)
            if not all(len(s["actions"]) == 0 for s in steps):
                skipped += 1
                continue

            tds = [_json_to_td(t) for t in case["transducers"]]
            init_env = _json_to_env(case["init_env"])

            config = SessionConfig(
                topology_json=json.dumps(topology),
                inbound_checks_json=json.dumps(inbound_checks),
            )

            connections = [
                Connection(
                    id=f"source_{t['request_type']}",
                    source=EmptySource([{
                        "request_type": t["request_type"],
                        "result_type": t["result_type"],
                    }]),
                )
                for t in topology
            ]

            router = Router(connections)
            runner = SessionRunner(tds, config)

            # Drive each step as a separate run_turn
            ok = True
            for step in steps:
                tag = step["event_tag"]
                data = _json_to_env(step["event_data"])

                await run_turn(runner, router, [], tag, data)

                expected_env = _json_to_env(step["result_env"])
                actual_state = runner.get_state()
                for k, expected_v in expected_env.items():
                    actual_v = actual_state.get(k)
                    if actual_v != expected_v:
                        ok = False

            if ok:
                passed += 1
            else:
                skipped += 1

        assert passed > 0, "expected some pure-fold cases to pass"
        print(f"golden Session run_turn (Python): {passed} passed, {skipped} skipped")
