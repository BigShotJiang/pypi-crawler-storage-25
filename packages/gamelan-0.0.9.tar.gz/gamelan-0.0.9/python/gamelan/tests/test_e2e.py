"""End-to-end tests — full agent session with stdlib transducers.

Uses AgentSession — the actual user-facing API.

Mock tests: wire stdlib transducers with mock LLM + mock tools,
run complete turns (user → LLM → tool call → LLM → done).

Integration tests (skipped by default): use real Anthropic/OpenAI APIs.
Run with: pytest tests/test_e2e.py -m integration
"""

import os

import pytest

from gamelan import AgentSession
from tests.conftest import (
    MockSource,
    LLM_PAIR,
    TOOL_PAIR,
    text_response,
    tool_call_response,
)


# ════════════════════════════════════════════════════════════════
# Mock tool source — returns fixed result
# ════════════════════════════════════════════════════════════════


class MockTool:
    def interface(self) -> list[dict]:
        return [TOOL_PAIR]

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        tool_call_id = request_data.get("tool_call_id", "")
        name = request_data.get("name", "")
        return ("ToolResult", {
            "key": f"ToolRequest:{tool_call_id}",
            "tool_call_id": tool_call_id,
            "name": name,
            "content": [{"content_type": "text", "text": "tool result: file contents here"}],
            "is_error": False,
        })


class DiscoverableMockTool:
    """Mock tool that also provides discovery (tool schemas for LLM context)."""

    def interface(self) -> list[dict]:
        return [TOOL_PAIR]

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        tool_call_id = request_data.get("tool_call_id", "")
        name = request_data.get("name", "")
        return ("ToolResult", {
            "key": f"ToolRequest:{tool_call_id}",
            "tool_call_id": tool_call_id,
            "name": name,
            "content": [{"content_type": "text", "text": "72°F, sunny, light breeze"}],
            "is_error": False,
        })

    async def discover(self) -> list[dict]:
        return [{
            "name": "get_weather",
            "description": "Get the current weather for a location",
            "parameters": {
                "type": "object",
                "properties": {
                    "location": {"type": "string", "description": "City name"},
                },
                "required": ["location"],
            },
        }]


# ════════════════════════════════════════════════════════════════
# E2E: text-only turn
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_e2e_text_only_turn():
    """user → LLM → text response → done"""
    llm = MockSource([LLM_PAIR], [text_response("Hello! How can I help you?")])
    session = AgentSession(sources={"llm": llm})

    events = await session.turn("Hello")

    dispatched = [e for e in events if e.type == "dispatched"]
    assert any(e.request_type == "LlmRequest" for e in dispatched)
    assert len(session.messages) >= 2
    assert session.is_idle


# ════════════════════════════════════════════════════════════════
# E2E: tool turn (user → LLM → tool call → tool result → LLM → done)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_e2e_tool_turn():
    """user → LLM (tool call) → tool dispatch → tool result → LLM (text) → done"""
    llm = MockSource([LLM_PAIR], [
        tool_call_response("read_file", '{"path":"test.txt"}', "tc1"),
        text_response("I found the file contents."),
    ])
    session = AgentSession(sources={"llm": llm, "tools": MockTool()})

    events = await session.turn("Read test.txt")

    dispatched_types = [e.request_type for e in events if e.type == "dispatched"]
    assert "LlmRequest" in dispatched_types
    assert "ToolRequest" in dispatched_types
    assert any(e.type == "turn_complete" for e in events)
    assert session.is_idle

    # The second LLM dispatch must see the tool result content (not empty string).
    # This is the regression check for thisisartium/gamelan#1.
    llm_calls = [(tag, data) for tag, data in llm.dispatch_calls if tag == "LlmRequest"]
    assert len(llm_calls) == 2, f"Expected 2 LLM dispatches, got {len(llm_calls)}"
    second_context = llm_calls[1][1].get("context", [])
    tool_msgs = [m for m in second_context if m.get("role") == "tool"]
    assert len(tool_msgs) >= 1, "Tool result message missing from LLM context"
    tool_content = tool_msgs[0].get("content", [])
    # Kernel format: content is a list of {content_type, text}
    if isinstance(tool_content, list):
        tool_text = "\n".join(c.get("text", "") for c in tool_content if isinstance(c, dict))
    else:
        tool_text = str(tool_content)
    assert tool_text != "", "Tool result content is empty — tool result was dropped"
    assert "file contents here" in tool_text


# ════════════════════════════════════════════════════════════════
# E2E: multi-turn conversation
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_e2e_multi_turn():
    """Two turns: conversation history grows."""
    llm = MockSource([LLM_PAIR], [
        text_response("Hi there!"),
        text_response("You're welcome!"),
    ])
    session = AgentSession(sources={"llm": llm})

    await session.turn("Hello")
    assert session.is_idle

    await session.turn("Thanks")
    assert session.is_idle
    assert len(session.messages) >= 4


# ════════════════════════════════════════════════════════════════
# E2E: persistence
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_e2e_with_persistence(tmp_path):
    """Session events are persisted to JSONL."""
    llm = MockSource([LLM_PAIR], [text_response("Saved!")])
    session = AgentSession(
        sources={"llm": llm},
        store_path=tmp_path / "my-session",
    )

    await session.turn("Remember this")
    assert session.is_idle
    assert (tmp_path / "my-session" / "events.jsonl").exists()


# ════════════════════════════════════════════════════════════════
# Integration: real Anthropic API (skipped by default)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
@pytest.mark.integration
async def test_integration_anthropic():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        pytest.skip("ANTHROPIC_API_KEY not set")

    from gamelan.providers.anthropic import AnthropicSource

    llm = AnthropicSource(model="claude-sonnet-4-20250514", max_tokens=1024, api_key=api_key)
    session = AgentSession(sources={"llm": llm})

    events = await session.turn("Say hello in exactly 3 words.")
    assert any(e.type == "dispatched" and e.request_type == "LlmRequest" for e in events)
    assert len(session.messages) >= 2


@pytest.mark.asyncio
@pytest.mark.integration
async def test_integration_anthropic_tool_call():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        pytest.skip("ANTHROPIC_API_KEY not set")

    from gamelan.providers.anthropic import AnthropicSource

    llm = AnthropicSource(model="claude-sonnet-4-20250514", max_tokens=1024, api_key=api_key)
    session = AgentSession(sources={"llm": llm, "tools": DiscoverableMockTool()})

    events = await session.turn("What is the weather in San Francisco? Use the get_weather tool.")
    dispatched_types = [e.request_type for e in events if e.type == "dispatched"]
    assert "LlmRequest" in dispatched_types


# ════════════════════════════════════════════════════════════════
# Integration: real OpenAI API (skipped by default)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
@pytest.mark.integration
async def test_integration_openai():
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        pytest.skip("OPENAI_API_KEY not set")

    from gamelan.providers.openai import OpenAISource

    llm = OpenAISource(model="gpt-4o-mini", max_tokens=1024, api_key=api_key)
    session = AgentSession(sources={"llm": llm})

    events = await session.turn("Say hello in exactly 3 words.")
    assert any(e.type == "dispatched" and e.request_type == "LlmRequest" for e in events)
    assert len(session.messages) >= 2


@pytest.mark.asyncio
@pytest.mark.integration
async def test_integration_openai_tool_call():
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        pytest.skip("OPENAI_API_KEY not set")

    from gamelan.providers.openai import OpenAISource

    llm = OpenAISource(model="gpt-4o-mini", max_tokens=1024, api_key=api_key)
    session = AgentSession(sources={"llm": llm, "tools": DiscoverableMockTool()})

    events = await session.turn("What is the weather in San Francisco? Use the get_weather tool.")
    dispatched_types = [e.request_type for e in events if e.type == "dispatched"]
    assert "LlmRequest" in dispatched_types
