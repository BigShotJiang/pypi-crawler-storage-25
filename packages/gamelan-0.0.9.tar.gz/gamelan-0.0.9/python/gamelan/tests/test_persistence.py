"""Test MemoryLog, MemorySessionStore, MemorySnapshotStore.

Matches session_store.qnt invariants.
"""

import pytest

from gamelan import MemoryLog, MemorySessionStore, MemorySnapshotStore, Snapshot


class TestMemoryLog:
    def test_append_and_load(self):
        log = MemoryLog()
        assert len(log) == 0
        log.append(("Input", {}))
        log.append(("LlmResponse", {"role": "assistant"}))
        assert len(log) == 2
        events = log.load()
        assert events[0][0] == "Input"
        assert events[1][0] == "LlmResponse"

    def test_load_after(self):
        log = MemoryLog()
        log.append(("A", {}))
        log.append(("B", {}))
        log.append(("C", {}))
        after = log.load_after(1)
        assert len(after) == 2
        assert after[0][0] == "B"
        assert after[1][0] == "C"

    def test_load_after_end(self):
        log = MemoryLog()
        log.append(("A", {}))
        assert log.load_after(1) == []

    def test_load_after_beyond(self):
        log = MemoryLog()
        log.append(("A", {}))
        assert log.load_after(5) == []


@pytest.mark.asyncio
class TestMemorySessionStore:
    async def test_create_and_list(self):
        store = MemorySessionStore()
        await store.create("s1")
        sessions = await store.list()
        assert len(sessions) == 1
        assert sessions[0]["id"] == "s1"

    async def test_create_duplicate_raises(self):
        store = MemorySessionStore()
        await store.create("s1")
        with pytest.raises(ValueError):
            await store.create("s1")

    async def test_load(self):
        store = MemorySessionStore()
        await store.create("s1")
        log = await store.load("s1")
        assert len(log) == 0

    async def test_load_not_found(self):
        store = MemorySessionStore()
        with pytest.raises(KeyError):
            await store.load("s1")

    async def test_delete(self):
        store = MemorySessionStore()
        await store.create("s1")
        await store.delete("s1")
        sessions = await store.list()
        assert len(sessions) == 0

    async def test_delete_not_found(self):
        store = MemorySessionStore()
        with pytest.raises(KeyError):
            await store.delete("s1")


@pytest.mark.asyncio
class TestMemorySnapshotStore:
    async def test_save_and_load(self):
        store = MemorySnapshotStore()
        assert await store.load("s1") is None
        snap = Snapshot.from_json('{"pending":["WorkRequest"],"vm_env":{},"event_count":5}')
        await store.save("s1", snap)
        loaded = await store.load("s1")
        assert loaded is not None
        assert loaded.event_count == 5
