"""Test SessionRunner fold cycle, checks, requests.

Matches session_loop.qnt invariants and Rust runner.rs tests.
"""

import json

from gamelan import SessionConfig, SessionRunner, stdlib
from tests.conftest import (
    work_config,
    work_topology_json,
    checked_work_config,
    checked_work_topology_json,
    agent_config,
    agent_resolver,
)


def make_runner(config=None):
    """Create a runner with a simple producer transducer (stdlib)."""
    tds = stdlib()
    if config is None:
        config = work_config()
    return SessionRunner(tds, config)


class TestBasicDispatchCycle:
    def test_starts_idle(self):
        runner = make_runner()
        assert runner.is_idle

    def test_input_dispatches_request(self):
        """Stdlib call_llm emits LlmRequest on user input (agent topology)."""
        runner = make_runner(config=agent_config())
        result = runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        # Should have requests (LlmRequest)
        assert len(result.requests) > 0
        assert result.requests[0].request_type == "LlmRequest"

    def test_result_clears_pending(self):
        runner = make_runner(config=agent_config())
        runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        assert len(runner.pending) > 0

        # Feed back a text-only assistant response
        result = runner.fold_event("LlmResponse", {
            "role": "assistant",
            "parts": [{"kind": "text", "text": "Hi!"}],
            "input_tokens": 10,
            "output_tokens": 5,
        })
        # LlmRequest should be cleared from pending
        assert "LlmRequest" not in runner.pending


class TestCheckCycle:
    def test_checked_request_has_check_action(self):
        """With checked topology, requests should have CheckThenDispatch action."""
        checked_topo = json.dumps([
            {
                "request_type": "LlmRequest",
                "result_type": "LlmResponse",
                "has_check": True,
                "check_source": "approval",
            },
        ])
        config = SessionConfig(checked_topo)
        runner = make_runner(config=config)
        result = runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        checked = [r for r in result.requests if r.needs_check]
        unchecked = [r for r in result.requests if not r.needs_check]
        assert len(checked) > 0
        assert len(unchecked) == 0

    def test_cancel_request_removes_pending(self):
        checked_topo = json.dumps([{
            "request_type": "LlmRequest",
            "result_type": "LlmResponse",
            "has_check": True,
            "check_source": "approval",
        }])
        config = SessionConfig(checked_topo)
        runner = make_runner(config=config)
        runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        runner.cancel_request("LlmRequest")
        assert "LlmRequest" not in runner.pending


class TestEventLog:
    def test_logs_events(self):
        runner = make_runner(config=agent_config())
        runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        assert runner.event_log == ["LlmResponse"]


class TestIdleAfterTurn:
    def test_idle_after_no_requests(self):
        runner = make_runner(config=agent_config())
        runner.fold_event("LlmResponse", {
            "role": "user",
            "parts": [{"kind": "text", "text": "hello"}],
            "input_tokens": 0,
            "output_tokens": 0,
        })
        # Feed result
        runner.fold_event("LlmResponse", {
            "role": "assistant",
            "parts": [{"kind": "text", "text": "Hi!"}],
            "input_tokens": 10,
            "output_tokens": 5,
        })
        # After processing result with no new requests, should be idle
        assert runner.is_idle
