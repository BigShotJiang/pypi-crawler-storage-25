"""Test individual stdlib transducer behavior via the kernel."""

from gamelan import Session, SessionConfig, stdlib
from tests.conftest import agent_config, agent_topology_json


def create_session():
    tds = stdlib()
    config = agent_config()
    return Session(tds, config), tds


def user_event(text: str) -> tuple[str, dict]:
    return ("LlmResponse", {
        "role": "user",
        "parts": [{"kind": "text", "text": text}],
        "input_tokens": 0,
        "output_tokens": 0,
    })


def assistant_text(text: str) -> tuple[str, dict]:
    return ("LlmResponse", {
        "role": "assistant",
        "parts": [{"kind": "text", "text": text}],
        "input_tokens": 10,
        "output_tokens": 5,
    })


def assistant_tool_call(name: str, args: str, call_id: str = "tc1") -> tuple[str, dict]:
    return ("LlmResponse", {
        "role": "assistant",
        "parts": [],
        "tool_calls": [{"id": call_id, "name": name, "arguments": args}],
        "input_tokens": 10,
        "output_tokens": 5,
    })


class TestMessages:
    def test_user_message_projected(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        state = session.get_state()
        messages = state.get("messages", [])
        assert len(messages) == 1
        assert messages[0]["role"] == "user"

    def test_assistant_response_projected(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        tag, data = assistant_text("Hi there!")
        session.step(tag, data)
        state = session.get_state()
        messages = state.get("messages", [])
        assert len(messages) == 2
        assert messages[1]["role"] == "assistant"


class TestUsage:
    def test_tracks_tokens(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        tag, data = assistant_text("Hi!")
        session.step(tag, data)
        state = session.get_state()
        assert state.get("input_tokens", 0) > 0
        assert state.get("output_tokens", 0) > 0


class TestCallLlm:
    def test_emits_llm_request_on_user_message(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        result = session.step(tag, data)
        request_types = [
            a["request"].get("type", "")
            for a in result.actions
            if a["type"] == "Dispatch"
        ]
        assert "LlmRequest" in request_types

    def test_no_llm_request_on_text_only_response(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        tag, data = assistant_text("Hi there!")
        result = session.step(tag, data)
        request_types = [
            a["request"].get("type", "")
            for a in result.actions
            if a["type"] == "Dispatch"
        ]
        assert "LlmRequest" not in request_types


class TestExecuteTool:
    def test_emits_tool_request_on_tool_call(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        tag, data = assistant_tool_call("read_file", '{"path": "/tmp/x"}')
        result = session.step(tag, data)
        request_types = [
            a["request"].get("type", "")
            for a in result.actions
            if a["type"] == "Dispatch"
        ]
        assert "ToolRequest" in request_types

    def test_no_tool_request_on_text(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        tag, data = assistant_text("Just text")
        result = session.step(tag, data)
        request_types = [
            a["request"].get("type", "")
            for a in result.actions
            if a["type"] == "Dispatch"
        ]
        assert "ToolRequest" not in request_types


class TestSessionLifecycle:
    def test_events_processed_increments(self):
        session, tds = create_session()
        assert session.events_processed == 0
        tag, data = user_event("Hello")
        session.step(tag, data)
        assert session.events_processed == 1

    def test_pending_after_request(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        # Should have pending LlmRequest
        assert len(session.pending) > 0

    def test_snapshot_roundtrip(self):
        session, tds = create_session()
        tag, data = user_event("Hello")
        session.step(tag, data)
        snap = session.snapshot()
        assert snap.event_count == 1
        # JSON roundtrip
        json_str = snap.to_json()
        from gamelan import Snapshot
        snap2 = Snapshot.from_json(json_str)
        assert snap2.event_count == 1
