"""Test Router — topology derivation, source resolution."""

import json

from gamelan import Connection, Router
from gamelan.check import OutboundCheckEntry, AutoApprove
from tests.conftest import MockSource, LLM_PAIR, TOOL_PAIR


class TestRouter:
    def test_resolves_request_types(self):
        llm = MockSource([LLM_PAIR], [])
        tools = MockSource([TOOL_PAIR], [])
        router = Router([
            Connection("llm", llm),
            Connection("tools", tools),
        ])
        assert router.resolve("LlmRequest").id == "llm"
        assert router.resolve("ToolRequest").id == "tools"
        assert router.resolve("Unknown") is None

    def test_derives_topology(self):
        llm = MockSource([LLM_PAIR], [])
        router = Router([Connection("llm", llm)])
        topo_json = router.topology()
        topo = json.loads(topo_json)
        assert len(topo) == 1
        assert topo[0]["request_type"] == "LlmRequest"
        assert topo[0]["result_type"] == "LlmResponse"
        assert not topo[0]["has_check"]

    def test_topology_with_checks(self):
        tools = MockSource([TOOL_PAIR], [])
        router = Router([Connection("tools", tools)])
        checks = [OutboundCheckEntry(
            request_type="ToolRequest",
            source_id="approval",
            check=AutoApprove(),
        )]
        topo_json = router.topology(checks)
        topo = json.loads(topo_json)
        assert len(topo) == 1
        assert topo[0]["has_check"]
        assert topo[0]["check_source"] == "approval"

    def test_source_resolver(self):
        llm = MockSource([LLM_PAIR], [])
        tools = MockSource([TOOL_PAIR], [])
        router = Router([
            Connection("llm", llm),
            Connection("tools", tools),
        ])
        resolver = router.source_resolver()
        assert resolver("LlmRequest") == "llm"
        assert resolver("ToolRequest") == "tools"
        assert resolver("Unknown") is None
