"""Test _build_messages for LiteLLM, OpenAI, and Anthropic providers.

Verifies that tool result messages are correctly read from the kernel's
'content' format ({content_type, text}). Parts use canonical format (kind)
and providers normalize to/from their native format.
"""

import pytest

from gamelan.providers.litellm import _build_messages as _build_messages_litellm
from gamelan.providers.openai import _build_messages as _build_messages_openai
from gamelan.providers.anthropic import _build_messages as _build_messages_anthropic


# ════════════════════════════════════════════════════════════════
# Fixtures — canonical format
# ════════════════════════════════════════════════════════════════

def _kernel_tool_msg(tool_call_id="tc_1", text="result data"):
    """Tool result in kernel format (content / content_type)."""
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": [{"content_type": "text", "text": text}],
    }


def _canonical_assistant_tool_call_msg(tool_call_id="tc_1", name="echo", arguments='{"text":"hi"}'):
    """Assistant message with tool calls in canonical format."""
    return {
        "role": "assistant",
        "parts": [],
        "tool_calls": [{"id": tool_call_id, "name": name, "arguments": arguments}],
    }


def _canonical_user_msg(text="hello"):
    return {
        "role": "user",
        "parts": [{"kind": "text", "text": text}],
    }


def _canonical_system_msg(text="You are helpful."):
    return {
        "role": "system",
        "parts": [{"kind": "text", "text": text}],
    }


def _canonical_assistant_text_msg(text="Let me help."):
    return {
        "role": "assistant",
        "parts": [{"kind": "text", "text": text}],
        "tool_calls": [],
    }


# ════════════════════════════════════════════════════════════════
# LiteLLM — _build_messages (OpenAI-compatible format)
# ════════════════════════════════════════════════════════════════

class TestLiteLLMBuildMessages:
    def test_tool_result_kernel_format(self):
        context = [
            _canonical_assistant_tool_call_msg(),
            _kernel_tool_msg(text="You said: hello"),
        ]
        msgs = _build_messages_litellm(context)
        tool_msg = [m for m in msgs if m["role"] == "tool"][0]
        assert tool_msg["content"] == "You said: hello"
        assert tool_msg["tool_call_id"] == "tc_1"

    def test_tool_result_multipart_content(self):
        msg = {
            "role": "tool",
            "tool_call_id": "tc_1",
            "content": [
                {"content_type": "text", "text": "line 1"},
                {"content_type": "text", "text": "line 2"},
            ],
        }
        msgs = _build_messages_litellm([_canonical_assistant_tool_call_msg(), msg])
        tool_msg = [m for m in msgs if m["role"] == "tool"][0]
        assert tool_msg["content"] == "line 1\nline 2"

    def test_full_conversation_round_trip(self):
        context = [
            _canonical_system_msg(),
            _canonical_user_msg("Echo hello"),
            _canonical_assistant_tool_call_msg(name="echo", arguments='{"text":"hello"}'),
            _kernel_tool_msg(text="You said: hello"),
        ]
        msgs = _build_messages_litellm(context)
        assert len(msgs) == 4
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"
        assert msgs[2]["role"] == "assistant"
        assert msgs[3]["role"] == "tool"
        assert msgs[3]["content"] == "You said: hello"

    def test_assistant_tool_calls_reinjected(self):
        context = [_canonical_assistant_tool_call_msg()]
        msgs = _build_messages_litellm(context)
        assistant_msg = msgs[0]
        assert assistant_msg["role"] == "assistant"
        assert len(assistant_msg["tool_calls"]) == 1
        assert assistant_msg["tool_calls"][0]["function"]["name"] == "echo"


# ════════════════════════════════════════════════════════════════
# OpenAI — _build_messages
# ════════════════════════════════════════════════════════════════

class TestOpenAIBuildMessages:
    def test_tool_result_kernel_format(self):
        context = [
            _canonical_assistant_tool_call_msg(),
            _kernel_tool_msg(text="You said: hello"),
        ]
        msgs = _build_messages_openai(context)
        tool_msg = [m for m in msgs if m["role"] == "tool"][0]
        assert tool_msg["content"] == "You said: hello"
        assert tool_msg["tool_call_id"] == "tc_1"

    def test_tool_result_multipart_content(self):
        msg = {
            "role": "tool",
            "tool_call_id": "tc_1",
            "content": [
                {"content_type": "text", "text": "line 1"},
                {"content_type": "text", "text": "line 2"},
            ],
        }
        msgs = _build_messages_openai([_canonical_assistant_tool_call_msg(), msg])
        tool_msg = [m for m in msgs if m["role"] == "tool"][0]
        assert tool_msg["content"] == "line 1\nline 2"

    def test_assistant_tool_calls_reinjected(self):
        context = [_canonical_assistant_tool_call_msg()]
        msgs = _build_messages_openai(context)
        assistant_msg = msgs[0]
        assert assistant_msg["role"] == "assistant"
        assert len(assistant_msg["tool_calls"]) == 1
        assert assistant_msg["tool_calls"][0]["function"]["name"] == "echo"


# ════════════════════════════════════════════════════════════════
# Anthropic — _build_messages
# ════════════════════════════════════════════════════════════════

class TestAnthropicBuildMessages:
    def test_tool_result_kernel_format(self):
        context = [
            _canonical_assistant_tool_call_msg(),
            _kernel_tool_msg(text="You said: hello"),
        ]
        _, msgs = _build_messages_anthropic(context)
        tool_msg = [m for m in msgs if m["role"] == "user"
                     and isinstance(m.get("content"), list)
                     and m["content"]
                     and m["content"][0].get("type") == "tool_result"][0]
        assert tool_msg["content"][0]["content"] == "You said: hello"
        assert tool_msg["content"][0]["tool_use_id"] == "tc_1"

    def test_tool_result_multipart_content(self):
        msg = {
            "role": "tool",
            "tool_call_id": "tc_1",
            "content": [
                {"content_type": "text", "text": "line 1"},
                {"content_type": "text", "text": "line 2"},
            ],
        }
        _, msgs = _build_messages_anthropic([_canonical_assistant_tool_call_msg(), msg])
        tool_msg = [m for m in msgs if m["role"] == "user"
                     and isinstance(m.get("content"), list)
                     and m["content"]
                     and m["content"][0].get("type") == "tool_result"][0]
        assert tool_msg["content"][0]["content"] == "line 1\nline 2"

    def test_assistant_tool_calls_reinjected(self):
        """Tool calls are re-injected as Anthropic tool_use content blocks."""
        context = [_canonical_assistant_tool_call_msg(
            name="echo", arguments='{"text":"hi"}'
        )]
        _, msgs = _build_messages_anthropic(context)
        assistant_msg = [m for m in msgs if m["role"] == "assistant"][0]
        tool_use = [b for b in assistant_msg["content"] if b.get("type") == "tool_use"]
        assert len(tool_use) == 1
        assert tool_use[0]["name"] == "echo"
        assert tool_use[0]["input"] == {"text": "hi"}

    def test_canonical_parts_normalized_to_anthropic(self):
        """Canonical kind parts are converted to Anthropic type blocks."""
        context = [_canonical_user_msg("hello")]
        _, msgs = _build_messages_anthropic(context)
        user_msg = msgs[0]
        assert user_msg["content"][0]["type"] == "text"
        assert user_msg["content"][0]["text"] == "hello"
        assert "kind" not in user_msg["content"][0]

    def test_system_message_extracted(self):
        context = [_canonical_system_msg("You are helpful.")]
        system, msgs = _build_messages_anthropic(context)
        assert system == "You are helpful."
        assert len(msgs) == 0

    def test_legacy_type_parts_handled(self):
        """Parts with 'type' (legacy/native) are still handled correctly."""
        context = [{
            "role": "assistant",
            "parts": [
                {"type": "text", "text": "Let me help."},
            ],
            "tool_calls": [],
        }]
        _, msgs = _build_messages_anthropic(context)
        assistant_msg = msgs[0]
        assert assistant_msg["content"][0]["type"] == "text"
