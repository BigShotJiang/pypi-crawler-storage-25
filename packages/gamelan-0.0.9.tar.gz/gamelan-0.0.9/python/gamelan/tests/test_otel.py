"""Test OTel instrumentation via TurnHook.

Uses in-memory span exporter to verify spans are created correctly
without requiring a running collector.

Requires ``gamelan[otel]`` extra — skipped when opentelemetry is not installed.
"""

import json
import pytest

pytest.importorskip("opentelemetry", reason="requires gamelan[otel] extra")

from gamelan import (
    Approve,
    CheckNeeded,
    Complete,
    DispatchReady,
    SessionRunner,
    stdlib,
    turn_driver,
    run_turn,
)
from gamelan.otel import OTelHook
from gamelan.router import Connection, Router
from tests.conftest import (
    MockSource,
    LLM_PAIR,
    TOOL_PAIR,
    text_response,
    tool_call_response,
    agent_config,
    agent_resolver,
)

# ════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════


class _InMemoryExporter:
    """Simple in-memory span exporter for tests."""
    def __init__(self):
        self._spans = []
    def export(self, spans):
        self._spans.extend(spans)
        from opentelemetry.sdk.trace.export import SpanExportResult
        return SpanExportResult.SUCCESS
    def shutdown(self):
        pass
    def force_flush(self, timeout_millis=None):
        return True
    def get_finished_spans(self):
        return list(self._spans)


def make_hook(capture_content: bool = False) -> tuple:
    """Create OTelHook with in-memory exporter. Returns (hook, exporter)."""
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor

    exporter = _InMemoryExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    tracer = provider.get_tracer("gamelan-test")

    hook = OTelHook(
        tracer=tracer,
        agent_name="test-agent",
        capture_content=capture_content,
    )
    return hook, exporter


USER_EVENT = {
    "role": "user",
    "parts": [{"kind": "text", "text": "Hi"}],
    "input_tokens": 0,
    "output_tokens": 0,
}


def make_runner():
    return SessionRunner(stdlib(), agent_config())


def tool_result(call_id: str, name: str, content: str) -> tuple[str, dict]:
    return ("ToolResult", {
        "key": f"ToolRequest:{call_id}",
        "tool_call_id": call_id,
        "name": name,
        "content": [{"content_type": "text", "text": content}],
        "is_error": False,
    })


# ════════════════════════════════════════════════════════════════
# Tests: turn_driver with OTelHook
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_basic_spans():
    """Agent span wraps LLM span."""
    hook, exporter = make_hook()
    runner = make_runner()
    response = text_response("Hello!")

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    assert isinstance(step, DispatchReady)

    step = await driver.asend(response)
    assert isinstance(step, Complete)

    spans = exporter.get_finished_spans()
    names = [s.name for s in spans]
    assert "response" in names
    assert "test-agent" in names


@pytest.mark.asyncio
async def test_llm_span_attributes():
    """LLM span has GenAI attributes."""
    hook, exporter = make_hook()
    runner = make_runner()

    response = ("LlmResponse", {
        "role": "assistant",
        "parts": [{"kind": "text", "text": "Hi!"}],
        "input_tokens": 100,
        "output_tokens": 25,
    })

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(response)

    spans = exporter.get_finished_spans()
    llm_span = next(s for s in spans if s.name == "response")

    attrs = dict(llm_span.attributes)
    assert attrs["gen_ai.operation.name"] == "chat"
    assert attrs["gen_ai.usage.input_tokens"] == 100
    assert attrs["gen_ai.usage.output_tokens"] == 25
    assert attrs["llm.token_count.total"] == 125


@pytest.mark.asyncio
async def test_tool_span():
    """Tool dispatches get their own span."""
    hook, exporter = make_hook(capture_content=True)
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])

    # LlmRequest
    step = await driver.__anext__()
    step = await driver.asend(tool_call_response("read_file", '{"path":"test.txt"}', "tc1"))

    # ToolRequest
    assert isinstance(step, DispatchReady)
    assert step.request_type == "ToolRequest"
    step = await driver.asend(tool_result("tc1", "read_file", "file contents"))

    # Second LlmRequest
    assert isinstance(step, DispatchReady)
    step = await driver.asend(text_response("Done."))
    assert isinstance(step, Complete)

    spans = exporter.get_finished_spans()
    names = [s.name for s in spans]
    assert "read_file" in names

    tool_span = next(s for s in spans if s.name == "read_file")
    attrs = dict(tool_span.attributes)
    assert attrs["gen_ai.operation.name"] == "execute_tool"
    assert attrs["gen_ai.tool.name"] == "read_file"
    assert "path" in attrs.get("gen_ai.tool.call.arguments", "")
    assert "file contents" in attrs.get("gen_ai.tool.call.result", "")


@pytest.mark.asyncio
async def test_dispatch_failure_sets_error():
    """Failed dispatch sets error status on span."""
    hook, exporter = make_hook()
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(None)  # failure
    assert isinstance(step, Complete)

    spans = exporter.get_finished_spans()
    llm_span = next(s for s in spans if s.name == "response")

    from opentelemetry.trace import StatusCode
    assert llm_span.status.status_code == StatusCode.ERROR


@pytest.mark.asyncio
async def test_agent_span_wraps_all():
    """Agent span is parent of all dispatch spans."""
    hook, exporter = make_hook()
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hi!"))

    spans = exporter.get_finished_spans()
    agent_span = next(s for s in spans if s.name == "test-agent")
    llm_span = next(s for s in spans if s.name == "response")

    assert llm_span.parent.span_id == agent_span.context.span_id


# ════════════════════════════════════════════════════════════════
# Tests: run_turn with hooks
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_run_turn_with_hook():
    """run_turn passes hooks through to turn_driver."""
    hook, exporter = make_hook()

    source = MockSource([LLM_PAIR], [text_response("Hello!")])
    router = Router([Connection("llm", source)])
    runner = SessionRunner(stdlib(), agent_config())

    events = await run_turn(
        runner, router, [],
        "LlmResponse", USER_EVENT,
        hooks=[hook],
    )

    assert runner.is_idle
    spans = exporter.get_finished_spans()
    names = [s.name for s in spans]
    assert "test-agent" in names
    assert "response" in names


# ════════════════════════════════════════════════════════════════
# Tests: multiple hooks compose
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_multiple_hooks():
    """Multiple hooks all fire."""
    hook1, exporter1 = make_hook()
    hook2, exporter2 = make_hook()

    runner = make_runner()
    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook1, hook2])
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hi!"))

    assert len(exporter1.get_finished_spans()) > 0
    assert len(exporter2.get_finished_spans()) > 0


# ════════════════════════════════════════════════════════════════
# Tests: context conversion (parts/kind → role/content)
# ════════════════════════════════════════════════════════════════

from gamelan.otel import _convert_context, _convert_message


def test_convert_context_user_message():
    """User message: parts/kind → content string."""
    context = [{"role": "user", "parts": [{"kind": "text", "text": "Hello"}]}]
    result = _convert_context(context)
    assert result == [{"role": "user", "content": "Hello"}]


def test_convert_context_assistant_text():
    """Assistant text message converts cleanly."""
    context = [{"role": "assistant", "parts": [{"kind": "text", "text": "Hi!"}]}]
    result = _convert_context(context)
    assert result == [{"role": "assistant", "content": "Hi!"}]


def test_convert_context_assistant_tool_call():
    """Assistant tool_call parts become tool_calls list."""
    context = [{
        "role": "assistant",
        "parts": [{"kind": "tool_call", "id": "tc1", "name": "read_file", "arguments": '{"path":"x"}'}],
    }]
    result = _convert_context(context)
    assert len(result) == 1
    msg = result[0]
    assert msg["role"] == "assistant"
    assert "parts" not in msg
    assert "kind" not in msg
    assert len(msg["tool_calls"]) == 1
    assert msg["tool_calls"][0]["name"] == "read_file"


def test_convert_context_tool_result():
    """Tool result uses content/content_type, not parts/kind."""
    context = [{
        "role": "tool",
        "tool_call_id": "tc1",
        "name": "read_file",
        "content": [{"content_type": "text", "text": "file contents"}],
    }]
    result = _convert_context(context)
    assert len(result) == 1
    msg = result[0]
    assert msg["role"] == "tool"
    assert msg["content"] == "file contents"
    assert msg["tool_call_id"] == "tc1"
    assert "parts" not in msg
    assert "kind" not in msg


def test_convert_context_system_message():
    """System message with parts converts to content."""
    context = [{"role": "system", "parts": [{"kind": "text", "text": "You are helpful."}]}]
    result = _convert_context(context)
    assert result == [{"role": "system", "content": "You are helpful."}]


def test_convert_context_multi_turn():
    """Full multi-turn conversation converts without parts/kind leaking."""
    context = [
        {"role": "system", "parts": [{"kind": "text", "text": "Be helpful."}]},
        {"role": "user", "parts": [{"kind": "text", "text": "Read test.txt"}]},
        {"role": "assistant", "parts": [
            {"kind": "tool_call", "id": "tc1", "name": "read_file", "arguments": '{"path":"test.txt"}'},
        ]},
        {"role": "tool", "tool_call_id": "tc1", "name": "read_file",
         "content": [{"content_type": "text", "text": "hello world"}]},
        {"role": "assistant", "parts": [{"kind": "text", "text": "The file says hello world."}]},
    ]
    result = _convert_context(context)
    serialized = json.dumps(result)
    assert '"parts"' not in serialized
    assert '"kind"' not in serialized
    assert '"content_type"' not in serialized
    assert len(result) == 5
    # Tool result preserved
    assert result[3]["content"] == "hello world"
    assert result[3]["tool_call_id"] == "tc1"


def test_convert_message_empty_parts():
    """Empty parts list produces role-only message."""
    msg = _convert_message("user", [])
    assert msg == {"role": "user"}


# ════════════════════════════════════════════════════════════════
# Tests: span attribute content (capture_content=True)
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_input_messages_no_parts_leak():
    """gen_ai.input.messages should not contain parts/kind."""
    hook, exporter = make_hook(capture_content=True)
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hi!"))

    spans = exporter.get_finished_spans()
    llm_span = next(s for s in spans if s.name == "response")
    attrs = dict(llm_span.attributes)

    input_msgs = attrs.get("gen_ai.input.messages", "")
    assert '"parts"' not in input_msgs
    assert '"kind"' not in input_msgs
    parsed = json.loads(input_msgs)
    assert any(m.get("content") == "Hi" for m in parsed)


@pytest.mark.asyncio
async def test_output_messages_no_parts_leak():
    """gen_ai.output.messages should not contain parts/kind."""
    hook, exporter = make_hook(capture_content=True)
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hello back!"))

    spans = exporter.get_finished_spans()
    llm_span = next(s for s in spans if s.name == "response")
    attrs = dict(llm_span.attributes)

    output_msgs = attrs.get("gen_ai.output.messages", "")
    assert '"parts"' not in output_msgs
    assert '"kind"' not in output_msgs
    parsed = json.loads(output_msgs)
    assert any(m.get("content") == "Hello back!" for m in parsed)


@pytest.mark.asyncio
async def test_span_events_emitted():
    """Span events are emitted for input messages."""
    hook, exporter = make_hook(capture_content=True)
    runner = make_runner()

    driver = turn_driver(runner, agent_resolver, "LlmResponse", USER_EVENT, hooks=[hook])
    step = await driver.__anext__()
    step = await driver.asend(text_response("Hi!"))

    spans = exporter.get_finished_spans()
    llm_span = next(s for s in spans if s.name == "response")
    event_names = [e.name for e in llm_span.events]
    assert "gen_ai.user.message" in event_names
    assert "gen_ai.assistant.message" in event_names
