"""Runner conformance: test real AgentRunner + turn_driver against spec contracts.

Targeted divergences:
  1. Outbound reject: spec says turn ends. Python skips silently.
  2. Multiple dispatch results: spec says all enqueued. Python takes only first.
"""

import json
import pytest

from gamelan._core import SessionConfig, stdlib
from gamelan.agent_runner import AgentRunner
from gamelan.check import Approve, Reject
from gamelan.runner import RunnerEvent


# ════════════════════════════════════════════════════════════════
# Mock executors
# ════════════════════════════════════════════════════════════════


class RejectingExecutor:
    """Approves all dispatches but rejects outbound checks."""

    async def dispatch_one(self, request_type, request_data, source_id):
        result_tag = request_type.replace("Request", "Result")
        return [{"result_tag": result_tag, "result_data": {}}]

    async def check_outbound(self, check_source, request_type, request_data):
        return Reject(reason="policy violation")

    async def check_inbound(self, info):
        return Approve()


class MultiResultExecutor:
    """Returns multiple results from a single dispatch."""

    def __init__(self, multi_results=None):
        self._multi = multi_results or []
        self._call_idx = 0

    async def dispatch_one(self, request_type, request_data, source_id):
        if self._call_idx < len(self._multi):
            results = self._multi[self._call_idx]
            self._call_idx += 1
            return results
        result_tag = request_type.replace("Request", "Result")
        return [{"result_tag": result_tag, "result_data": {}}]

    async def check_outbound(self, check_source, request_type, request_data):
        return Approve()

    async def check_inbound(self, info):
        return Approve()


# ════════════════════════════════════════════════════════════════
# Configs
# ════════════════════════════════════════════════════════════════


LLM_PAIR = {"request_type": "LlmRequest", "result_type": "LlmResult", "has_check": False}
TOOL_PAIR_CHECKED = {
    "request_type": "ToolRequest",
    "result_type": "ToolResult",
    "has_check": True,
    "check_source": "approval",
}


# ════════════════════════════════════════════════════════════════
# Conformance test: outbound reject terminates turn
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_outbound_reject_terminates_turn():
    """Spec: check_reject → queue cleared, turn ends immediately.

    Python divergence: the turn_driver calls cancel_request and continues
    to the next request from the same fold, instead of ending the turn.
    """
    tds = stdlib()
    config = SessionConfig(json.dumps([LLM_PAIR, TOOL_PAIR_CHECKED]))
    runner = AgentRunner(tds, config, lambda rt: {
        "LlmRequest": "llm",
        "ToolRequest": "tools",
    }.get(rt))

    # Feed an LlmResponse with tool_calls so execute_tool emits ToolRequest
    # which will hit the outbound check → REJECT
    event_data = {
        "role": "assistant",
        "parts": [{"kind": "text", "text": "I'll use a tool"}],
        "tool_calls": [{"id": "tc1", "name": "search", "arguments": "{}"}],
        "input_tokens": 10,
        "output_tokens": 20,
    }

    events = await runner.run_turn(RejectingExecutor(), "LlmResponse", event_data)

    # Count events that entered the fold
    folded = [e for e in events if e.type == "event"]

    print(f"\nFolded events ({len(folded)}):")
    for e in folded:
        print(f"  {e.event_tag}: {e.event_data}")

    print(f"\nAll events ({len(events)}):")
    for e in events:
        print(f"  {e.type}: tag={e.event_tag} req={e.request_type} src={e.source_id}")

    # SPEC: after outbound reject, turn ends.
    # Only the triggering event (LlmResponse) should have been folded.
    # The ToolRequest check rejection should NOT cause the fold to continue.
    assert len(folded) <= 1, (
        f"SPEC VIOLATION: outbound reject should terminate turn immediately. "
        f"Expected <= 1 folded event (LlmResponse), got {len(folded)}. "
        f"Tags: {[e.event_tag for e in folded]}"
    )


# ════════════════════════════════════════════════════════════════
# Conformance test: multiple dispatch results all enqueued
# ════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_multiple_dispatch_results_all_processed():
    """Spec: dispatch_concurrent → all result tags enqueued and folded.

    Python divergence: AgentRunner._run_turn_inner takes only outcomes[0].
    """
    # Executor returns 2 LlmResult from one dispatch
    executor = MultiResultExecutor(multi_results=[
        [
            {"result_tag": "LlmResult", "result_data": {
                "role": "assistant",
                "parts": [{"kind": "text", "text": "response 1"}],
                "tool_calls": [],
                "input_tokens": 0,
                "output_tokens": 0,
            }},
            {"result_tag": "LlmResult", "result_data": {
                "role": "assistant",
                "parts": [{"kind": "text", "text": "response 2"}],
                "tool_calls": [],
                "input_tokens": 0,
                "output_tokens": 0,
            }},
        ],
    ])

    tds = stdlib()
    config = SessionConfig(json.dumps([LLM_PAIR]))
    runner = AgentRunner(tds, config, lambda rt: "llm" if rt == "LlmRequest" else None)

    # LlmResponse → call_llm emits LlmRequest → dispatch returns 2 results
    event_data = {
        "role": "user",
        "parts": [{"kind": "text", "text": "hello"}],
        "input_tokens": 0,
        "output_tokens": 0,
    }
    events = await runner.run_turn(executor, "LlmResponse", event_data)

    # Count LlmResult events that entered the fold
    llm_results = [e for e in events if e.type == "event" and e.event_tag == "LlmResult"]

    print(f"\nAll events ({len(events)}):")
    for e in events:
        print(f"  {e.type}: tag={e.event_tag}")

    # SPEC: both LlmResult should be enqueued and folded
    assert len(llm_results) >= 2, (
        f"SPEC VIOLATION: dispatch returned 2 results but only {len(llm_results)} "
        f"were folded. All dispatch results must be enqueued and processed. "
        f"Python AgentRunner may be taking only outcomes[0]."
    )
