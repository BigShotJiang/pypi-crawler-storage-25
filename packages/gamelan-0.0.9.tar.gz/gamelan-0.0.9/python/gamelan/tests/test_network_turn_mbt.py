"""Model-based testing: validate network turn invariants against ITF traces.

Replays network_turn_mc.qnt traces and checks invariants at every step.

Invariants (from network_turn_mc.qnt):
  - mc_agent_inputs_have_text: every agent input has non-empty text
  - mc_agent_inputs_are_user_messages: every agent input is a UserMessage
  - mc_agent_inputs_have_target: every agent input has a target agent

These catch:
  - Python text-dropping bug (empty event_data passed to agent)
  - Python wrong event tag (LlmResponse instead of UserMessage for delegation)
  - Python missing target agent in network routing
"""

import json
from pathlib import Path

import pytest

FIXTURE_ROOT = Path(__file__).resolve().parent.parent.parent.parent / "rust"
NETWORK_TURN_TRACES = FIXTURE_ROOT / "gamelan-core" / "tests" / "fixtures" / "network_turn_traces"


# ════════════════════════════════════════════════════════════════
# ITF parsing
# ════════════════════════════════════════════════════════════════


def parse_agent_input(v: dict) -> dict:
    return {
        "event_tag": v["event_tag"],
        "text": v["text"],
        "target_agent": v["target_agent"],
    }


def parse_network_turn_state(state: dict) -> dict:
    return {
        "active_agent": state["active_agent"],
        "agent_inputs": [parse_agent_input(i) for i in state["agent_inputs"]],
        "agents_completed": list(state["agents_completed"]),
        "network_active": state["network_active"],
    }


# ════════════════════════════════════════════════════════════════
# Invariant checks — direct translation from network_turn_mc.qnt
# ════════════════════════════════════════════════════════════════


def check_agent_inputs_have_text(step: int, s: dict, errors: list[str]):
    """Every agent input has non-empty text.

    This is the invariant that catches the text-dropping bug:
    Python's NetworkRunner._drive_agent passes empty {} as event_data,
    and Python's _make_user_event uses the wrong tag.
    """
    for i, inp in enumerate(s["agent_inputs"]):
        if not inp["text"]:
            errors.append(
                f"step {step}: mc_agent_inputs_have_text VIOLATED — "
                f"agent_inputs[{i}].text is empty (target: {inp['target_agent']})"
            )


def check_agent_inputs_are_user_messages(step: int, s: dict, errors: list[str]):
    """Every agent input is a UserMessage event.

    Catches: Python using 'LlmResponse' tag for delegation messages
    instead of 'UserMessage'.
    """
    for i, inp in enumerate(s["agent_inputs"]):
        if inp["event_tag"] != "UserMessage":
            errors.append(
                f"step {step}: mc_agent_inputs_are_user_messages VIOLATED — "
                f"agent_inputs[{i}].event_tag = '{inp['event_tag']}' (expected 'UserMessage')"
            )


def check_agent_inputs_have_target(step: int, s: dict, errors: list[str]):
    """Every agent input has a non-empty target agent."""
    for i, inp in enumerate(s["agent_inputs"]):
        if not inp["target_agent"]:
            errors.append(
                f"step {step}: mc_agent_inputs_have_target VIOLATED — "
                f"agent_inputs[{i}].target_agent is empty"
            )


def check_inputs_monotonic(step: int, prev: dict, next_: dict, errors: list[str]):
    """agent_inputs is append-only (inputs never removed)."""
    if len(next_["agent_inputs"]) < len(prev["agent_inputs"]):
        errors.append(
            f"step {step}: inputs_monotonic VIOLATED — "
            f"agent_inputs shrunk from {len(prev['agent_inputs'])} to {len(next_['agent_inputs'])}"
        )
    else:
        for i in range(min(len(prev["agent_inputs"]), len(next_["agent_inputs"]))):
            if prev["agent_inputs"][i] != next_["agent_inputs"][i]:
                errors.append(
                    f"step {step}: inputs_monotonic VIOLATED — agent_inputs[{i}] changed"
                )
                break


# ════════════════════════════════════════════════════════════════
# Trace replay
# ════════════════════════════════════════════════════════════════


def replay_network_turn_trace(path: Path):
    content = json.loads(path.read_text())
    states = content["states"]
    errors: list[str] = []

    for i, state_json in enumerate(states):
        s = parse_network_turn_state(state_json)
        check_agent_inputs_have_text(i, s, errors)
        check_agent_inputs_are_user_messages(i, s, errors)
        check_agent_inputs_have_target(i, s, errors)

    for i in range(1, len(states)):
        prev = parse_network_turn_state(states[i - 1])
        next_ = parse_network_turn_state(states[i])
        check_inputs_monotonic(i, prev, next_, errors)

    assert not errors, (
        f"Trace {path.name} had {len(errors)} issues:\n" + "\n".join(errors)
    )


# ════════════════════════════════════════════════════════════════
# Tests
# ════════════════════════════════════════════════════════════════


def collect_traces(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(directory.glob("*.itf.json"))


network_turn_traces = collect_traces(NETWORK_TURN_TRACES)


@pytest.mark.parametrize(
    "trace_path",
    network_turn_traces,
    ids=[p.stem for p in network_turn_traces],
)
def test_network_turn_trace(trace_path: Path):
    replay_network_turn_trace(trace_path)
