"""Test AgentSession — high-level convenience wrapper."""

import json

import pytest

from gamelan import AgentSession
from tests.conftest import (
    MockSource,
    LLM_PAIR,
    TOOL_PAIR,
    text_response,
    tool_call_response,
)


class MockTool:
    def interface(self) -> list[dict]:
        return [TOOL_PAIR]

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        tool_call_id = request_data.get("tool_call_id", "")
        return ("ToolResult", {
            "key": f"ToolRequest:{tool_call_id}",
            "tool_call_id": tool_call_id,
            "name": request_data.get("name", ""),
            "content": [{"content_type": "text", "text": "tool result"}],
            "is_error": False,
        })


@pytest.mark.asyncio
async def test_text_only_turn():
    llm = MockSource([LLM_PAIR], [text_response("Hello!")])
    session = AgentSession(sources={"llm": llm})

    events = await session.turn("Hi there")
    assert session.is_idle
    assert len(session.messages) >= 2


@pytest.mark.asyncio
async def test_tool_turn():
    llm = MockSource([LLM_PAIR], [
        tool_call_response("read_file", '{"path":"x"}', "tc1"),
        text_response("Got it."),
    ])
    tool = MockTool()
    session = AgentSession(sources={"llm": llm, "tools": tool})

    events = await session.turn("Read x")
    assert session.is_idle
    dispatched = [e.request_type for e in events if e.type == "dispatched"]
    assert "LlmRequest" in dispatched
    assert "ToolRequest" in dispatched


@pytest.mark.asyncio
async def test_multi_turn():
    llm = MockSource([LLM_PAIR], [
        text_response("Hi!"),
        text_response("You're welcome!"),
    ])
    session = AgentSession(sources={"llm": llm})

    await session.turn("Hello")
    assert session.events_processed >= 2

    await session.turn("Thanks")
    assert len(session.messages) >= 4


@pytest.mark.asyncio
async def test_with_persistence(tmp_path):
    store_path = tmp_path / "my-session"
    llm = MockSource([LLM_PAIR], [text_response("Stored!")])
    session = AgentSession(sources={"llm": llm}, store_path=store_path)

    await session.turn("Save this")
    assert session.is_idle

    # Event log file should exist
    events_file = store_path / "events.jsonl"
    assert events_file.exists()


@pytest.mark.asyncio
async def test_from_def():
    def_json = json.dumps({
        "name": "test_agent",
        "transducers": ["messages", "blocks", "usage", "call_llm"],
        "connections": [
            {
                "source_id": "llm",
                "pairs": [{"request_type": "LlmRequest", "result_type": "LlmResponse"}],
                "checks": [],
            },
        ],
        "config": {},
    })

    llm = MockSource([LLM_PAIR], [text_response("Built from def!")])
    session = AgentSession.from_def(def_json, sources={"llm": llm})

    events = await session.turn("Hello from def")
    assert session.is_idle
    assert len(session.messages) >= 2


@pytest.mark.asyncio
async def test_snapshot():
    llm = MockSource([LLM_PAIR], [text_response("Snap!")])
    session = AgentSession(sources={"llm": llm})

    await session.turn("Hello")
    snap = session.snapshot()
    assert snap.event_count >= 2


@pytest.mark.asyncio
async def test_state_access():
    llm = MockSource([LLM_PAIR], [text_response("Hi!")])
    session = AgentSession(sources={"llm": llm})

    await session.turn("Hello")
    state = session.state
    assert "messages" in state
