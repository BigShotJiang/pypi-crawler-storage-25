"""Persistence — event log, session store, snapshot store.

Three protocols covering core persistence needs. The runtime ships
built-in backends for common cases (MemoryStore). Applications can
provide custom backends (SQLite, Postgres, file-based).

Matches session_store.qnt.
"""

from __future__ import annotations

from typing import Protocol, TypedDict, runtime_checkable

from gamelan._core import Snapshot


# ════════════════════════════════════════════════════════════════
# EventLog — per-session, append-only
# ════════════════════════════════════════════════════════════════


@runtime_checkable
class EventLog(Protocol):
    """Per-session event persistence. Foundation for crash recovery and replay."""

    def append(self, event: tuple[str, dict]) -> None:
        """Append an event to the log."""
        ...

    def load(self) -> list[tuple[str, dict]]:
        """Load all events (for full replay)."""
        ...

    def load_after(self, index: int) -> list[tuple[str, dict]]:
        """Load events after a given index (for resume from snapshot)."""
        ...

    def __len__(self) -> int:
        """Number of events in the log."""
        ...


# ════════════════════════════════════════════════════════════════
# SessionStore — multi-session CRUD
# ════════════════════════════════════════════════════════════════


class SessionInfo(TypedDict, total=False):
    """Session metadata."""

    id: str
    created_at: int
    updated_at: int
    event_count: int
    title: str | None
    metadata: dict


@runtime_checkable
class SessionStore(Protocol):
    """Multi-session management. Listing, creating, loading, deleting."""

    async def list(self) -> list[SessionInfo]:
        ...

    async def create(self, id: str) -> EventLog:
        ...

    async def load(self, id: str) -> EventLog:
        ...

    async def delete(self, id: str) -> None:
        ...

    async def update_info(self, id: str, info: SessionInfo) -> None:
        ...


# ════════════════════════════════════════════════════════════════
# SnapshotStore — optional fast resume
# ════════════════════════════════════════════════════════════════


@runtime_checkable
class SnapshotStore(Protocol):
    """Snapshot persistence for fast resume. Optional."""

    async def save(self, session_id: str, snapshot: Snapshot) -> None:
        ...

    async def load(self, session_id: str) -> Snapshot | None:
        ...


# ════════════════════════════════════════════════════════════════
# MemoryLog — in-memory backend for testing
# ════════════════════════════════════════════════════════════════


class MemoryLog:
    """In-memory event log. For testing and ephemeral sessions."""

    def __init__(self):
        self._events: list[tuple[str, dict]] = []

    def append(self, event: tuple[str, dict]) -> None:
        self._events.append(event)

    def load(self) -> list[tuple[str, dict]]:
        return list(self._events)

    def load_after(self, index: int) -> list[tuple[str, dict]]:
        if index > len(self._events):
            return []
        return list(self._events[index:])

    def __len__(self) -> int:
        return len(self._events)


# ════════════════════════════════════════════════════════════════
# MemorySessionStore — in-memory backend for testing
# ════════════════════════════════════════════════════════════════


class MemorySessionStore:
    """In-memory session store. For testing."""

    def __init__(self):
        self._sessions: dict[str, SessionInfo] = {}
        self._logs: dict[str, MemoryLog] = {}

    async def list(self) -> list[SessionInfo]:
        return list(self._sessions.values())

    async def create(self, id: str) -> MemoryLog:
        if id in self._sessions:
            raise ValueError(f"session already exists: {id}")
        self._sessions[id] = SessionInfo(
            id=id, created_at=0, updated_at=0, event_count=0, title=None, metadata={}
        )
        self._logs[id] = MemoryLog()
        return self._logs[id]

    async def load(self, id: str) -> MemoryLog:
        if id not in self._sessions:
            raise KeyError(f"session not found: {id}")
        return self._logs[id]

    async def delete(self, id: str) -> None:
        if id not in self._sessions:
            raise KeyError(f"session not found: {id}")
        del self._sessions[id]
        del self._logs[id]

    async def update_info(self, id: str, info: SessionInfo) -> None:
        if id not in self._sessions:
            raise KeyError(f"session not found: {id}")
        self._sessions[id] = info


# ════════════════════════════════════════════════════════════════
# MemorySnapshotStore — in-memory backend for testing
# ════════════════════════════════════════════════════════════════


class MemorySnapshotStore:
    """In-memory snapshot store. For testing."""

    def __init__(self):
        self._snapshots: dict[str, Snapshot] = {}

    async def save(self, session_id: str, snapshot: Snapshot) -> None:
        self._snapshots[session_id] = snapshot

    async def load(self, session_id: str) -> Snapshot | None:
        return self._snapshots.get(session_id)
