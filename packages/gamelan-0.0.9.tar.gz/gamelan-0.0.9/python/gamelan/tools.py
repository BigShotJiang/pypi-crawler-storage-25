"""ToolSource — local function tools with schema discovery.

Register Python functions as tools. The LLM sees their schemas via
discover(), and ToolRequest events dispatch to the matching handler.

Two ways to register:

1. With a Pydantic model (auto-generates JSON Schema):

    class ReadFileArgs(BaseModel):
        path: str
        offset: int = 0

    tools.register("read_file", "Read a file", ReadFileArgs, read_file_handler)

2. With a manual schema dict:

    tools.register_raw("read_file", "Read a file", {"type": "object", ...}, handler)

3. With a decorator:

    @tools.tool("read_file", "Read a file")
    async def read_file(args: ReadFileArgs) -> str:
        return open(args.path).read()
"""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass
from typing import Any, Callable, Awaitable, get_type_hints


TOOL_PAIR = {"request_type": "ToolRequest", "result_type": "ToolResult"}


@dataclass
class ToolOutput:
    """Output from a tool execution."""

    content: str
    is_error: bool = False

    @staticmethod
    def text(content: str) -> ToolOutput:
        return ToolOutput(content=content)

    @staticmethod
    def error(content: str) -> ToolOutput:
        return ToolOutput(content=content, is_error=True)


@dataclass
class ToolDef:
    """Tool definition: name, description, parameter JSON Schema."""

    name: str
    description: str
    parameters: dict


class ToolSource:
    """Local tool source. Registers tools and dispatches ToolRequest -> ToolResult.

    Implements the Source protocol.
    """

    def __init__(self):
        self._tools: dict[str, tuple[ToolDef, Callable]] = {}

    def register(
        self,
        name: str,
        description: str,
        model: type,
        handler: Callable[..., Awaitable[ToolOutput | str]],
    ):
        """Register a typed tool. Schema auto-generated from a Pydantic model.

        Args:
            name: Tool name (what the LLM calls).
            description: What the tool does.
            model: A Pydantic BaseModel subclass — its schema becomes parameters.
            handler: Async function taking (model_instance) -> ToolOutput or str.
        """
        parameters = _schema_from_model(model)
        tool_def = ToolDef(name=name, description=description, parameters=parameters)
        self._tools[name] = (tool_def, _wrap_typed_handler(model, handler))

    def register_raw(
        self,
        name: str,
        description: str,
        parameters: dict,
        handler: Callable[[dict], Awaitable[ToolOutput | str]],
    ):
        """Register a tool with a manual JSON Schema.

        Args:
            name: Tool name.
            description: What the tool does.
            parameters: JSON Schema dict for the parameters.
            handler: Async function taking (args_dict) -> ToolOutput or str.
        """
        tool_def = ToolDef(name=name, description=description, parameters=parameters)
        self._tools[name] = (tool_def, _wrap_raw_handler(handler))

    def tool(
        self,
        name: str,
        description: str,
    ) -> Callable:
        """Decorator to register a tool.

        The first parameter's type annotation is used for schema generation
        (if it's a Pydantic model). Otherwise, the handler receives a raw dict.

            @tools.tool("echo", "Echo a message")
            async def echo(args: EchoArgs) -> str:
                return args.message
        """

        def decorator(fn):
            model = _infer_model(fn)
            if model is not None:
                self.register(name, description, model, fn)
            else:
                self.register_raw(name, description, {"type": "object"}, fn)
            return fn

        return decorator

    def tool_defs(self) -> list[ToolDef]:
        """Get all tool definitions."""
        return [td for td, _ in self._tools.values()]

    def interface(self) -> list[dict]:
        return [TOOL_PAIR]

    async def discover(self) -> list[dict]:
        """Return tool schemas for LLM context."""
        return [
            {
                "name": td.name,
                "description": td.description,
                "parameters": td.parameters,
            }
            for td in self.tool_defs()
        ]

    async def dispatch(
        self, request_tag: str, request_data: dict
    ) -> tuple[str, dict]:
        """Dispatch a ToolRequest to the matching handler."""
        tool_name = request_data.get("name", "")
        if not tool_name:
            raise RuntimeError("missing tool name in ToolRequest")

        entry = self._tools.get(tool_name)
        if entry is None:
            raise RuntimeError(f"unknown tool: {tool_name}")

        tool_def, handler = entry
        tool_call_id = request_data.get("tool_call_id", "")

        # Parse arguments — might be a JSON string or a dict
        arguments = request_data.get("arguments", {})
        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except (json.JSONDecodeError, TypeError):
                arguments = {}

        # Execute
        try:
            output = await handler(arguments)
        except Exception as e:
            output = ToolOutput.error(str(e))

        return ("ToolResult", {
            "key": f"ToolRequest:{tool_call_id}",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": [{"content_type": "text", "text": output.content}],
            "is_error": output.is_error,
        })


# ════════════════════════════════════════════════════════════════
# Internal helpers
# ════════════════════════════════════════════════════════════════


def _schema_from_model(model: type) -> dict:
    """Extract JSON Schema from a Pydantic model or a plain dict schema."""
    # Pydantic v2
    if hasattr(model, "model_json_schema"):
        return model.model_json_schema()
    # Pydantic v1
    if hasattr(model, "schema"):
        return model.schema()
    # Fallback: assume it's a dict
    return {"type": "object"}


def _wrap_typed_handler(
    model: type,
    handler: Callable,
) -> Callable[[dict], Awaitable[ToolOutput]]:
    """Wrap a typed handler: deserialize args into model, normalize output."""

    async def wrapped(args: dict) -> ToolOutput:
        try:
            # Pydantic v2
            if hasattr(model, "model_validate"):
                typed_args = model.model_validate(args)
            # Pydantic v1
            elif hasattr(model, "parse_obj"):
                typed_args = model.parse_obj(args)
            else:
                typed_args = args
        except Exception as e:
            return ToolOutput.error(f"invalid arguments: {e}")

        result = await handler(typed_args)
        return _normalize_output(result)

    return wrapped


def _wrap_raw_handler(
    handler: Callable[[dict], Awaitable[ToolOutput | str]],
) -> Callable[[dict], Awaitable[ToolOutput]]:
    """Wrap a raw handler: normalize output."""

    async def wrapped(args: dict) -> ToolOutput:
        result = await handler(args)
        return _normalize_output(result)

    return wrapped


def _normalize_output(result) -> ToolOutput:
    """Convert handler return to ToolOutput."""
    if isinstance(result, ToolOutput):
        return result
    if isinstance(result, str):
        return ToolOutput.text(result)
    return ToolOutput.text(str(result))


def _infer_model(fn: Callable) -> type | None:
    """Infer a Pydantic model from the first parameter's type annotation."""
    hints = get_type_hints(fn)
    params = list(inspect.signature(fn).parameters.keys())
    if not params:
        return None
    first_param_type = hints.get(params[0])
    if first_param_type is None:
        return None
    # Check if it's a Pydantic model
    if hasattr(first_param_type, "model_json_schema") or hasattr(
        first_param_type, "schema"
    ):
        return first_param_type
    return None
