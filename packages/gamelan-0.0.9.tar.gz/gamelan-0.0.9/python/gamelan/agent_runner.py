"""AgentRunner — async turn loop wrapping SessionRunner + Executor.

Same pattern as Rust AgentRunner: drives the session to quiescence
by looping fold + executor until no more requests.

    runner = AgentRunner(transducers, config, resolve_source)
    events = await runner.run_turn(executor, "UserMessage", {"text": "hello"})

The turn_driver async generator remains available for lower-level
step-by-step control. AgentRunner wraps it for the common case.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from gamelan.check import Approve, CheckVerdict, Reject, Transform
from gamelan.executor import Executor
from gamelan.run import Complete, CheckNeeded, DispatchReady, turn_driver
from gamelan.runner import RunnerEvent, SessionRunner

from gamelan._core import SessionConfig, Snapshot


# ════════════════════════════════════════════════════════════════
# Boot event types
# ════════════════════════════════════════════════════════════════


@dataclass(frozen=True)
class ContextBlock:
    """Initial context block — named content for the agent's memory."""
    name: str
    content: str


@dataclass(frozen=True)
class SessionCreated:
    """Boot event — first event on the session log.

    Carries both outer fold config (connections, checks) and
    inner fold config (initial context for transducers).
    """
    connections: list[dict] = field(default_factory=list)
    inbound_checks: list[dict] = field(default_factory=list)
    initial_context: list[ContextBlock] = field(default_factory=list)


class AgentRunner:
    """Async turn loop over SessionRunner.

    Owns a SessionRunner (the pure fold) and drives it through
    an Executor for I/O. Same layering as Rust AgentRunner.
    """

    def __init__(
        self,
        transducers: list,
        config: SessionConfig,
        resolve_source: Callable[[str], str | None],
    ):
        self.session = SessionRunner(transducers, config)
        self._resolve_source = resolve_source

    @classmethod
    def from_session_created(
        cls,
        transducers: list,
        boot: SessionCreated,
    ) -> "AgentRunner":
        """Create a runner from a SessionCreated boot event.

        Source resolution reads from the connection state (fold state)
        instead of an injected closure. This is the spec-aligned path.
        """
        from gamelan._core import derive_topology, resolve_source as _resolve

        # Build topology + inbound checks from boot connections
        topology_json = _build_topology_json(boot.connections)
        inbound_json = _build_inbound_checks_json(boot.inbound_checks)
        config = SessionConfig(topology_json, inbound_json)

        # Build source resolver from connections
        conn_map = {c["request_type"]: c["source_id"] for c in boot.connections}
        resolve = lambda req_type: conn_map.get(req_type)

        runner = cls.__new__(cls)
        runner.session = SessionRunner(transducers, config)
        runner._resolve_source = resolve
        return runner

    @classmethod
    def resume(
        cls,
        transducers: list,
        config: SessionConfig,
        event_log: list[tuple[str, dict]],
        resolve_source: Callable[[str], str | None],
    ) -> "AgentRunner":
        runner = cls.__new__(cls)
        runner.session = SessionRunner.resume(transducers, config, event_log)
        runner._resolve_source = resolve_source
        return runner

    # ── Queries ────────────────────────────────────────────

    @property
    def is_idle(self) -> bool:
        return self.session.is_idle

    @property
    def events_processed(self) -> int:
        return self.session.events_processed

    def snapshot(self) -> Snapshot:
        return self.session.snapshot()

    def get_state(self) -> dict:
        return self.session.get_state()

    # ── Turn loop ─────────────────────────────────────────

    async def run_turn(
        self,
        executor: Executor,
        event_tag: str,
        event_data: dict,
    ) -> list[RunnerEvent]:
        """Drive a turn to quiescence, collecting events."""
        events: list[RunnerEvent] = []
        await self._run_turn_inner(executor, event_tag, event_data, events.append)
        return events

    async def stream_turn(
        self,
        executor: Executor,
        event_tag: str,
        event_data: dict,
        queue: asyncio.Queue,
    ) -> None:
        """Drive a turn, streaming events to an asyncio queue."""
        await self._run_turn_inner(
            executor, event_tag, event_data, queue.put_nowait
        )

    async def _run_turn_inner(
        self,
        executor: Executor,
        event_tag: str,
        event_data: dict,
        emit: Callable[[RunnerEvent], Any],
    ) -> None:
        """Core turn loop — drives turn_driver with executor, emits via callback."""
        driver = turn_driver(
            self.session, self._resolve_source, event_tag, event_data
        )

        step = await driver.__anext__()

        while not isinstance(step, Complete):
            if isinstance(step, CheckNeeded):
                if step.is_inbound:
                    from gamelan.runner import InboundCheckInfo
                    info = InboundCheckInfo(
                        event_tag=step.event_tag,
                        check_source=step.source_id,
                        event_data=step.event_data,
                    )
                    verdict = await executor.check_inbound(info)
                else:
                    verdict = await executor.check_outbound(
                        step.source_id, step.event_tag, step.event_data
                    )
                step = await driver.asend(verdict)

            elif isinstance(step, DispatchReady):
                try:
                    outcomes = await executor.dispatch_one(
                        step.request_type, step.request_data, step.source_id
                    )
                    if outcomes:
                        if len(outcomes) == 1:
                            result = outcomes[0]
                            step = await driver.asend(
                                (result["result_tag"], result.get("result_data", {}))
                            )
                        else:
                            # Multiple results — send as list for turn_driver to enqueue all
                            step = await driver.asend(outcomes)
                    else:
                        step = await driver.asend(None)
                except Exception:
                    step = await driver.asend(None)
            else:
                break

        # Forward collected events from the driver
        if isinstance(step, Complete):
            for event in step.events:
                emit(event)


# ════════════════════════════════════════════════════════════════
# Helpers — build PyO3-compatible JSON from boot event dicts
# ════════════════════════════════════════════════════════════════

import json


def _build_topology_json(connections: list[dict]) -> str:
    """Convert connection dicts to topology JSON for SessionConfig."""
    topology = []
    for c in connections:
        topology.append({
            "request_type": c.get("request_type", ""),
            "result_type": c.get("result_type", ""),
            "has_check": c.get("has_check", False),
            "check_source": c.get("check_source"),
        })
    return json.dumps(topology)


def _build_inbound_checks_json(checks: list[dict]) -> str:
    """Convert inbound check dicts to JSON for SessionConfig."""
    if not checks:
        return ""
    result = []
    for c in checks:
        result.append({
            "intercept": c.get("result_type", ""),
            "check_source": c.get("check_source", ""),
        })
    return json.dumps(result)
