"""Executor — the async I/O boundary (internal).

The executor is constructed internally by NetworkClient/NetworkRunner
from per-agent source maps. Users don't create executors directly.

Spec: executor.qnt — three operations, verdict types.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from gamelan.check import CheckVerdict, Approve, InboundVerdict, InboundApprove
from gamelan.runner import InboundCheckInfo


@runtime_checkable
class Executor(Protocol):
    """I/O boundary for agent sessions (internal).

    Three operations matching executor.qnt:
    - dispatch_one: send request to source, get results
    - check_outbound: verify request before dispatch
    - check_inbound: verify event before fold (no reject)
    """

    async def dispatch_one(
        self,
        request_type: str,
        request_data: dict,
        source_id: str,
    ) -> list[dict]:
        ...

    async def check_outbound(
        self,
        check_source: str,
        request_type: str,
        request_data: dict,
    ) -> CheckVerdict:
        ...

    async def check_inbound(
        self,
        info: InboundCheckInfo,
    ) -> InboundVerdict:
        ...


class SourceExecutor:
    """Executor built from a source map + check entries.

    Constructed internally by NetworkRunner for each agent's turn.
    Maps source_id → Source for dispatch, check_source → Check for verdicts.
    """

    def __init__(
        self,
        sources: dict[str, object],
        outbound_checks: dict[str, object] | None = None,
        inbound_checks: dict[str, object] | None = None,
    ):
        self._sources = sources
        self._outbound_checks = outbound_checks or {}
        self._inbound_checks = inbound_checks or {}

    async def dispatch_one(
        self,
        request_type: str,
        request_data: dict,
        source_id: str,
    ) -> list[dict]:
        source = self._sources.get(source_id)
        if source is None:
            raise LookupError(f"no source for source_id '{source_id}'")
        tag, data = await source.dispatch(request_type, request_data)
        return [{"result_tag": tag, "result_data": data}]

    async def check_outbound(
        self,
        check_source: str,
        request_type: str,
        request_data: dict,
    ) -> CheckVerdict:
        check = self._outbound_checks.get(check_source)
        if check is None:
            return Approve()
        return await check.check(request_type, request_data)

    async def check_inbound(
        self,
        info: InboundCheckInfo,
    ) -> InboundVerdict:
        check = self._inbound_checks.get(info.check_source)
        if check is None:
            return InboundApprove()
        result = await check.check(info.event_tag, info.event_data)
        if isinstance(result, InboundVerdict):
            return result
        return InboundApprove()


class CallbackExecutor:
    """Adapter: wraps dispatch/check callbacks as an Executor.

    Used internally by runTurn's callback-based API.
    """

    def __init__(
        self,
        dispatch_fn=None,
        check_fn=None,
        resolve_source=None,
    ):
        self._dispatch = dispatch_fn
        self._check = check_fn
        self._resolve_source = resolve_source or (lambda _: None)

    async def dispatch_one(
        self,
        request_type: str,
        request_data: dict,
        source_id: str,
    ) -> list[dict]:
        if self._dispatch is None:
            raise LookupError(f"no dispatch handler for {request_type}")
        result_tag, result_data = await self._dispatch(request_type, request_data)
        return [{"result_tag": result_tag, "result_data": result_data}]

    async def check_outbound(
        self,
        check_source: str,
        request_type: str,
        request_data: dict,
    ) -> CheckVerdict:
        if self._check is None:
            return Approve()
        return await self._check(request_type, request_data)

    async def check_inbound(
        self,
        info: InboundCheckInfo,
    ) -> InboundVerdict:
        if self._check is None:
            return InboundApprove()
        result = await self._check(info.event_tag, info.event_data)
        if isinstance(result, InboundVerdict):
            return result
        from gamelan.check import Transform, InboundTransform
        if isinstance(result, Transform):
            return InboundTransform(data=result.data)
        return InboundApprove()
