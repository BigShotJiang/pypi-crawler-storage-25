# gamelan

Composable runtime for agent systems with a formally verified kernel.

The kernel (VM, session lifecycle, coordinator) is implemented in Rust and proved safe in Lean 4. This package provides the Python runtime: async dispatch, source/check protocols, persistence, streaming, and multi-agent coordination.

## Install

```bash
pip install gamelan

# With provider support:
pip install gamelan[anthropic]
pip install gamelan[openai]
pip install gamelan[all]
```

## Quick start

```python
from gamelan import AgentSession
from gamelan.providers.anthropic import AnthropicSource

session = AgentSession(sources={
    "llm": AnthropicSource(model="claude-sonnet-4-20250514"),
})
events = await session.turn("What is the reactor pattern?")
print(session.messages[-1])
```

## With tools

```python
from gamelan import AgentSession, ToolSource
from gamelan.providers.anthropic import AnthropicSource

tools = ToolSource()

@tools.tool("read_file", "Read a file from disk")
async def read_file(args):
    return open(args["path"]).read()

session = AgentSession(sources={
    "llm": AnthropicSource(model="claude-sonnet-4-20250514"),
    "tools": tools,
})
events = await session.turn("Read the README")
```

## Multi-agent

```python
from gamelan import NetworkClient, AgentDef, stdlib
from gamelan.providers.anthropic import AnthropicSource

claude = AnthropicSource(model="claude-sonnet-4-20250514")

parent_def = AgentDef(stdlib(), agent_config, resolver)
child_def = AgentDef(stdlib(), agent_config, resolver)

client = NetworkClient(
    agents={
        "parent": (parent_def, {"llm": claude, "tools": deleg_source}),
        "child": (child_def, {"llm": claude, "tools": search_source}),
    },
    delegation_routes=[("parent", "child")],
    entry_point="parent",
)

async for event in client.send_message("Research Rust ownership"):
    print(event)
```

Sources are per-agent. Each agent carries its own `AgentDef` (declarative config) and source map (runtime bindings). Config is validated at construction per `client.qnt`.

## Architecture

```
AgentSession (high-level convenience)
  run_turn (turn driver with callbacks)
    SessionRunner (pure fold — Rust kernel via PyO3)

NetworkClient (multi-agent)
  NetworkRunner (coordinator fold)
    AgentRunner per agent (turn loop + per-agent sources)
```

- **Kernel** (Rust via PyO3): session fold, coordinator, VM, transducers
- **Runtime** (Python): turn driver, sources, checks, delegation, streaming
- **Spec**: `executor.qnt` (I/O contract), `runner.qnt` (turn loop), `client.qnt` (multi-agent config)

## Extension model

`AgentSession` is the high-level API. Under the hood, it calls `run_turn` — the core dispatch loop with callbacks:

```python
from gamelan import run_turn

events = await run_turn(runner, router, checks, tag, data,
    dispatch=my_dispatch,   # intercept source calls
    check=my_check,         # custom approval logic
    observe=my_observe,     # persistence / logging hooks
)
```

## License

Apache-2.0
