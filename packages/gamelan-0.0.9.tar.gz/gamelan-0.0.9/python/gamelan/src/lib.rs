//! PyO3 bindings for the gamelan crate.
//!
//! Thin wrapper that exposes Rust types and functions to Python.
//! The Python session loop and API live in python/gamelan/.

use gamelan_core::agent_fold::{
    self as continuation, AgentConnectionState, AgentFold, ConnectionDef, FoldResult,
    InboundCheckConfig, InboundCheckDef, OutboundCheckConfig, RequestAction,
    SourcePair, SourceRegistration, Topology,
};
// Module alias for topology functions (avoids name clash with #[pyfunction] wrappers)
use gamelan_core::agent_fold as topo;
use gamelan_core::coordinator::{Coordinator, CoordinatorError, Route};
use gamelan_core::coordinator_fold::NetworkConnectionState;
use gamelan_core::interpreter::RoutingConfig;
use gamelan_core::session::{self, EventRecord, SessionConfig, Snapshot};
use gamelan_core::session_def::{self as sd, SessionDef};
use gamelan_core::types::{Env, TransducerDef, Value};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyBool, PyDict, PyFloat, PyInt, PyList, PyString, PyTuple};
use std::collections::BTreeMap;

// ════════════════════════════════════════════════════════════════
// Value conversion: Python ↔ Rust
// ════════════════════════════════════════════════════════════════

fn py_to_value(py: Python<'_>, obj: &Bound<'_, PyAny>) -> PyResult<Value> {
    if obj.is_none() {
        Ok(Value::None)
    } else if obj.is_instance_of::<PyBool>() {
        Ok(Value::Bool(obj.extract::<bool>()?))
    } else if obj.is_instance_of::<PyInt>() {
        Ok(Value::Int(obj.extract::<i64>()?))
    } else if obj.is_instance_of::<PyFloat>() {
        let v = obj.extract::<f64>()?;
        if v.fract() == 0.0 {
            Ok(Value::Int(v as i64))
        } else {
            Err(PyValueError::new_err("Gamelan values don't support floats"))
        }
    } else if obj.is_instance_of::<PyString>() {
        Ok(Value::Str(obj.extract::<String>()?))
    } else if obj.is_instance_of::<PyList>() {
        let list = obj.downcast::<PyList>()?;
        let items: PyResult<Vec<Value>> = list.iter().map(|item| py_to_value(py, &item)).collect();
        Ok(Value::List(items?))
    } else if obj.is_instance_of::<PyDict>() {
        let dict = obj.downcast::<PyDict>()?;
        let mut map = BTreeMap::new();
        for (k, v) in dict.iter() {
            let key: String = k.extract()?;
            map.insert(key, py_to_value(py, &v)?);
        }
        Ok(Value::Map(map))
    } else {
        Err(PyValueError::new_err(format!(
            "Cannot convert {} to Gamelan Value",
            obj.get_type().name()?
        )))
    }
}

fn value_to_py<'py>(py: Python<'py>, val: &Value) -> Bound<'py, PyAny> {
    match val {
        Value::None => py.None().into_bound(py),
        Value::Bool(b) => b.into_pyobject(py).unwrap().to_owned().into_any(),
        Value::Int(n) => n.into_pyobject(py).unwrap().into_any(),
        Value::Str(s) => s.into_pyobject(py).unwrap().into_any(),
        Value::List(items) => {
            let py_items: Vec<Bound<'py, PyAny>> =
                items.iter().map(|v| value_to_py(py, v)).collect();
            PyList::new(py, &py_items).unwrap().into_any()
        }
        Value::Map(map) => {
            let dict = PyDict::new(py);
            for (k, v) in map {
                dict.set_item(k, value_to_py(py, v)).unwrap();
            }
            dict.into_any()
        }
    }
}

fn py_dict_to_env(py: Python<'_>, dict: &Bound<'_, PyDict>) -> PyResult<Env> {
    let mut env = Env::new();
    for (k, v) in dict.iter() {
        let key: String = k.extract()?;
        env.insert(key, py_to_value(py, &v)?);
    }
    Ok(env)
}

fn env_to_py_dict<'py>(py: Python<'py>, env: &Env) -> Bound<'py, PyDict> {
    let dict = PyDict::new(py);
    for (k, v) in env {
        dict.set_item(k, value_to_py(py, v)).unwrap();
    }
    dict
}

// ════════════════════════════════════════════════════════════════
// TransducerDef
// ════════════════════════════════════════════════════════════════

#[pyfunction]
fn load_transducer(json: &str) -> PyResult<PyTransducerDef> {
    let td: TransducerDef =
        serde_json::from_str(json).map_err(|e| PyValueError::new_err(e.to_string()))?;
    Ok(PyTransducerDef { inner: td })
}

#[pyfunction]
fn stdlib() -> Vec<PyTransducerDef> {
    gamelan_core::stdlib::stdlib()
        .into_iter()
        .map(|td| PyTransducerDef { inner: td })
        .collect()
}

#[pyclass(name = "TransducerDef", frozen)]
#[derive(Clone)]
struct PyTransducerDef {
    inner: TransducerDef,
}

#[pymethods]
impl PyTransducerDef {
    #[getter]
    fn name(&self) -> &str {
        &self.inner.name
    }

    fn __repr__(&self) -> String {
        format!("TransducerDef('{}')", self.inner.name)
    }
}

// ════════════════════════════════════════════════════════════════
// SessionConfig — continuation model
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "SessionConfig", frozen)]
#[derive(Clone)]
struct PySessionConfig {
    inner: SessionConfig,
}

#[pymethods]
impl PySessionConfig {
    #[new]
    #[pyo3(signature = (topology_json, inbound_checks_json="[]"))]
    fn new(topology_json: &str, inbound_checks_json: &str) -> PyResult<Self> {
        let topology: Topology = serde_json::from_str(topology_json)
            .map_err(|e| PyValueError::new_err(format!("Invalid topology JSON: {e}")))?;
        let inbound_checks: Vec<InboundCheckDef> = serde_json::from_str(inbound_checks_json)
            .map_err(|e| PyValueError::new_err(format!("Invalid inbound checks JSON: {e}")))?;
        Ok(PySessionConfig {
            inner: SessionConfig {
                topology,
                inbound_checks,
            },
        })
    }

    /// Get the topology as JSON. Used by SessionRunner to classify events.
    #[getter]
    fn topology_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner.topology)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    /// Get the inbound checks as JSON.
    #[getter]
    fn inbound_checks_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner.inbound_checks)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }
}

// ════════════════════════════════════════════════════════════════
// StepResult — turn_step output
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "StepResult")]
struct PyStepResult {
    inner: continuation::TurnResult,
}

#[pymethods]
impl PyStepResult {
    /// Requests that passed the gate, as list of action dicts.
    /// Each dict has "type" ("Dispatch" or "CheckThenDispatch"),
    /// "request" (the value), and optionally "check_source".
    #[getter]
    fn actions<'py>(&self, py: Python<'py>) -> Bound<'py, PyList> {
        let items: Vec<Bound<'py, PyAny>> = self
            .inner
            .requests
            .iter()
            .map(|action| {
                let dict = PyDict::new(py);
                match action {
                    RequestAction::Dispatch(value) => {
                        dict.set_item("type", "Dispatch").unwrap();
                        dict.set_item("request", value_to_py(py, value)).unwrap();
                    }
                    RequestAction::CheckThenDispatch {
                        request,
                        check_source,
                    } => {
                        dict.set_item("type", "CheckThenDispatch").unwrap();
                        dict.set_item("request", value_to_py(py, request)).unwrap();
                        dict.set_item("check_source", check_source).unwrap();
                    }
                }
                dict.into_any()
            })
            .collect();
        PyList::new(py, &items).unwrap()
    }

    /// Backward compat: dispatched values (all requests, both checked and unchecked).
    #[getter]
    fn dispatched<'py>(&self, py: Python<'py>) -> Bound<'py, PyList> {
        let items: Vec<Bound<'py, PyAny>> = self
            .inner
            .requests
            .iter()
            .map(|action| {
                let value = match action {
                    RequestAction::Dispatch(v) => v,
                    RequestAction::CheckThenDispatch { request, .. } => request,
                };
                value_to_py(py, value)
            })
            .collect();
        PyList::new(py, &items).unwrap()
    }

    /// Check source IDs for requests that need approval.
    #[getter]
    fn check_requests(&self) -> Vec<String> {
        self.inner
            .requests
            .iter()
            .filter_map(|action| match action {
                RequestAction::CheckThenDispatch { check_source, .. } => {
                    Some(check_source.clone())
                }
                _ => None,
            })
            .collect()
    }

    /// Pending request types after this step.
    #[getter]
    fn pending(&self) -> Vec<String> {
        self.inner.pending.clone()
    }

    /// Inbound check source if this event was intercepted.
    #[getter]
    fn inbound_check(&self) -> Option<String> {
        self.inner.inbound_check.clone()
    }
}

// ════════════════════════════════════════════════════════════════
// Session — continuation model
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "Session")]
struct PySession {
    state: session::SessionState,
    transducers: Vec<TransducerDef>,
    config: SessionConfig,
}

#[pymethods]
impl PySession {
    #[new]
    fn new(transducers: Vec<PyTransducerDef>, config: &PySessionConfig) -> Self {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let state = session::create(&tds, &config.inner);
        PySession {
            state,
            transducers: tds,
            config: config.inner.clone(),
        }
    }

    fn step(
        &mut self,
        py: Python<'_>,
        event_tag: &str,
        event_data: &Bound<'_, PyDict>,
    ) -> PyResult<PyStepResult> {
        let data = py_dict_to_env(py, event_data)?;
        let result = self.state.process(&self.transducers, event_tag, &data);
        Ok(PyStepResult { inner: result })
    }

    fn get_state<'py>(&self, py: Python<'py>) -> Bound<'py, PyDict> {
        env_to_py_dict(py, &self.state.vm_env)
    }

    #[getter]
    fn events_processed(&self) -> usize {
        self.state.events_processed
    }

    #[getter]
    fn is_quiescent(&self) -> bool {
        self.state.is_quiescent()
    }

    #[getter]
    fn pending(&self) -> Vec<String> {
        self.state.pending.clone()
    }

    fn snapshot(&self) -> PySnapshot {
        PySnapshot {
            inner: self.state.snapshot(),
        }
    }

    #[staticmethod]
    fn replay(
        py: Python<'_>,
        transducers: Vec<PyTransducerDef>,
        config: &PySessionConfig,
        event_log: &Bound<'_, PyList>,
    ) -> PyResult<Self> {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let log = py_list_to_event_log(py, event_log)?;
        let state = session::replay(&tds, &config.inner, &log);
        Ok(PySession {
            state,
            transducers: tds,
            config: config.inner.clone(),
        })
    }

    #[staticmethod]
    fn resume(
        py: Python<'_>,
        snapshot: &PySnapshot,
        config: &PySessionConfig,
        transducers: Vec<PyTransducerDef>,
        remaining_events: &Bound<'_, PyList>,
    ) -> PyResult<Self> {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let remaining = py_list_to_event_log(py, remaining_events)?;
        let state = session::resume(snapshot.inner.clone(), &config.inner, &tds, &remaining);
        Ok(PySession {
            state,
            transducers: tds,
            config: config.inner.clone(),
        })
    }
}

fn py_list_to_event_log(py: Python<'_>, list: &Bound<'_, PyList>) -> PyResult<Vec<EventRecord>> {
    let mut log = Vec::new();
    for item in list.iter() {
        let tuple = item.downcast::<PyTuple>()?;
        let tag: String = tuple.get_item(0)?.extract()?;
        let data_dict = tuple.get_item(1)?.downcast::<PyDict>()?.clone();
        let data = py_dict_to_env(py, &data_dict)?;
        log.push((tag, data));
    }
    Ok(log)
}

// ════════════════════════════════════════════════════════════════
// Snapshot
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "Snapshot", frozen)]
#[derive(Clone)]
struct PySnapshot {
    inner: Snapshot,
}

#[pymethods]
impl PySnapshot {
    #[getter]
    fn event_count(&self) -> usize {
        self.inner.event_count
    }

    #[getter]
    fn pending(&self) -> Vec<String> {
        self.inner.pending.clone()
    }

    fn to_msgpack(&self) -> PyResult<Vec<u8>> {
        rmp_serde::to_vec(&self.inner)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_msgpack(bytes: &[u8]) -> PyResult<Self> {
        let inner: Snapshot =
            rmp_serde::from_slice(bytes).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PySnapshot { inner })
    }

    fn to_json(&self) -> PyResult<String> {
        serde_json::to_string(&self.inner).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    #[staticmethod]
    fn from_json(json: &str) -> PyResult<Self> {
        let inner: Snapshot =
            serde_json::from_str(json).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PySnapshot { inner })
    }
}

// ════════════════════════════════════════════════════════════════
// ContinuationSession — low-level fold without pending/gate
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "ContinuationSession")]
struct PyContinuationSession {
    topology: Topology,
    transducers: Vec<TransducerDef>,
    vm_env: Env,
}

#[pymethods]
impl PyContinuationSession {
    #[new]
    fn new(transducers: Vec<PyTransducerDef>, topology_json: &str) -> PyResult<Self> {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let topology: Topology = serde_json::from_str(topology_json)
            .map_err(|e| PyValueError::new_err(format!("Invalid topology JSON: {e}")))?;

        let mut vm_env = Env::new();
        for td in &tds {
            for slot in &td.slots {
                vm_env.insert(slot.name.clone(), slot.initial.clone());
            }
        }

        Ok(PyContinuationSession {
            topology,
            transducers: tds,
            vm_env,
        })
    }

    fn fold_event(
        &mut self,
        py: Python<'_>,
        event_tag: &str,
        event_data: &Bound<'_, PyDict>,
    ) -> PyResult<PyFoldResult> {
        let data = py_dict_to_env(py, event_data)?;
        let result = continuation::fold_event(
            &self.topology,
            &self.transducers,
            &self.vm_env,
            event_tag,
            &data,
        );
        self.vm_env = result.vm_env.clone();
        Ok(PyFoldResult { inner: result })
    }

    fn get_state<'py>(&self, py: Python<'py>) -> Bound<'py, PyDict> {
        env_to_py_dict(py, &self.vm_env)
    }
}

// ════════════════════════════════════════════════════════════════
// FoldResult — raw fold output (no pending/gate)
// ════════════════════════════════════════════════════════════════

#[pyclass(name = "FoldResult")]
struct PyFoldResult {
    inner: FoldResult,
}

#[pymethods]
impl PyFoldResult {
    #[getter]
    fn vm_env<'py>(&self, py: Python<'py>) -> Bound<'py, PyDict> {
        env_to_py_dict(py, &self.inner.vm_env)
    }

    #[getter]
    fn actions<'py>(&self, py: Python<'py>) -> Bound<'py, PyList> {
        let items: Vec<Bound<'py, PyAny>> = self
            .inner
            .requests
            .iter()
            .map(|action| {
                let dict = PyDict::new(py);
                match action {
                    RequestAction::Dispatch(value) => {
                        dict.set_item("type", "Dispatch").unwrap();
                        dict.set_item("request", value_to_py(py, value)).unwrap();
                    }
                    RequestAction::CheckThenDispatch {
                        request,
                        check_source,
                    } => {
                        dict.set_item("type", "CheckThenDispatch").unwrap();
                        dict.set_item("request", value_to_py(py, request)).unwrap();
                        dict.set_item("check_source", check_source).unwrap();
                    }
                }
                dict.into_any()
            })
            .collect();
        PyList::new(py, &items).unwrap()
    }
}

// ════════════════════════════════════════════════════════════════
// Loader
// ════════════════════════════════════════════════════════════════

#[pyfunction]
fn validate(transducers: Vec<PyTransducerDef>) -> PyResult<Vec<String>> {
    let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
    let errors = gamelan_core::loader::validate_session(&tds);
    Ok(errors.iter().map(|e| format!("{e:?}")).collect())
}

// ════════════════════════════════════════════════════════════════
// Coordinator — multi-session routing and lifecycle
// ════════════════════════════════════════════════════════════════

fn coordinator_err(e: CoordinatorError) -> PyErr {
    PyValueError::new_err(e.to_string())
}

fn effect_to_py<'py>(py: Python<'py>, effect: &gamelan_core::coordinator::Effect) -> Bound<'py, PyDict> {
    let dict = PyDict::new(py);
    match effect {
        gamelan_core::coordinator::Effect::CreateSession { id } => {
            dict.set_item("type", "CreateSession").unwrap();
            dict.set_item("id", id).unwrap();
        }
        gamelan_core::coordinator::Effect::ForkSession { parent, child, parent_event_count } => {
            dict.set_item("type", "ForkSession").unwrap();
            dict.set_item("parent", parent).unwrap();
            dict.set_item("child", child).unwrap();
            dict.set_item("parent_event_count", parent_event_count).unwrap();
        }
        gamelan_core::coordinator::Effect::DestroySession { id } => {
            dict.set_item("type", "DestroySession").unwrap();
            dict.set_item("id", id).unwrap();
        }
        gamelan_core::coordinator::Effect::AgentRequest { session, event_tag, request_data } => {
            dict.set_item("type", "AgentRequest").unwrap();
            dict.set_item("session", session).unwrap();
            dict.set_item("event_tag", event_tag).unwrap();
            let data = PyDict::new(py);
            for (k, v) in request_data {
                data.set_item(k, value_to_py(py, v)).unwrap();
            }
            dict.set_item("request_data", data).unwrap();
        }
        gamelan_core::coordinator::Effect::CollectAgentResult { parent, child, result_type } => {
            dict.set_item("type", "CollectAgentResult").unwrap();
            dict.set_item("parent", parent).unwrap();
            dict.set_item("child", child).unwrap();
            dict.set_item("result_type", result_type).unwrap();
        }
    }
    dict
}

#[pyclass(name = "Coordinator")]
struct PyCoordinator {
    inner: Coordinator,
}

#[pymethods]
impl PyCoordinator {
    #[new]
    fn new() -> Self {
        PyCoordinator {
            inner: Coordinator::new(),
        }
    }

    fn spawn_session<'py>(&mut self, py: Python<'py>, id: &str) -> PyResult<Bound<'py, PyDict>> {
        let effect = self.inner.spawn_session(id.to_string()).map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn fork_session<'py>(&mut self, py: Python<'py>, parent: &str, child: &str) -> PyResult<Bound<'py, PyDict>> {
        let effect = self
            .inner
            .fork_session(parent.to_string(), child.to_string())
            .map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn destroy_session<'py>(&mut self, py: Python<'py>, id: &str) -> PyResult<Bound<'py, PyDict>> {
        let effect = self.inner.destroy_session(id.to_string()).map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn add_route(
        &mut self,
        src: &str,
        dst: &str,
        request_type: &str,
        result_type: &str,
    ) -> PyResult<()> {
        self.inner
            .add_route(Route {
                src: src.to_string(),
                dst: dst.to_string(),
                request_type: request_type.to_string(),
                result_type: result_type.to_string(),
            })
            .map_err(coordinator_err)
    }

    fn start_processing(&mut self, id: &str) -> PyResult<()> {
        self.inner.start_processing(id).map_err(coordinator_err)
    }

    fn process_step(&mut self, id: &str) -> PyResult<()> {
        self.inner.process_step(id).map_err(coordinator_err)
    }

    fn delegate_to<'py>(
        &mut self,
        py: Python<'py>,
        src: &str,
        dst: &str,
        request_type: &str,
        request_data: &Bound<'_, PyDict>,
    ) -> PyResult<Bound<'py, PyDict>> {
        let data = py_dict_to_env(py, request_data)?;
        let effect = self
            .inner
            .delegate_to(src, dst, request_type, data)
            .map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn finish_session(&mut self, id: &str) -> PyResult<()> {
        self.inner.finish_session(id).map_err(coordinator_err)
    }

    fn complete_delegation<'py>(
        &mut self,
        py: Python<'py>,
        src: &str,
        dst: &str,
    ) -> PyResult<Bound<'py, PyDict>> {
        let effect = self
            .inner
            .complete_delegation(src, dst)
            .map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn reset_session(&mut self, id: &str) -> PyResult<()> {
        self.inner.reset_session(id).map_err(coordinator_err)
    }

    fn cancel_delegation(&mut self, src: &str, dst: &str) -> PyResult<()> {
        self.inner
            .cancel_delegation(src, dst)
            .map_err(coordinator_err)
    }

    fn session_failed<'py>(&mut self, py: Python<'py>, id: &str) -> PyResult<Bound<'py, PyDict>> {
        let effect = self.inner.session_failed(id).map_err(coordinator_err)?;
        Ok(effect_to_py(py, &effect))
    }

    fn session<'py>(&self, py: Python<'py>, id: &str) -> Option<Bound<'py, PyDict>> {
        self.inner.session(id).map(|s| {
            let dict = PyDict::new(py);
            let status = match s.status {
                gamelan_core::coordinator::SessionStatus::SIdle => "idle",
                gamelan_core::coordinator::SessionStatus::SProcessing => "processing",
                gamelan_core::coordinator::SessionStatus::SWaitingDelegate => "waiting_delegate",
                gamelan_core::coordinator::SessionStatus::SDone => "done",
            };
            dict.set_item("status", status).unwrap();
            dict.set_item("step_count", s.step_count).unwrap();
            let waiting_on: Vec<&str> = s.waiting_on.iter().map(|s| s.as_str()).collect();
            dict.set_item("waiting_on", waiting_on).unwrap();
            dict.set_item("event_count", s.event_count).unwrap();
            dict
        })
    }

    fn sessions<'py>(&self, py: Python<'py>) -> Bound<'py, PyDict> {
        let dict = PyDict::new(py);
        for (id, s) in self.inner.sessions() {
            let session_dict = PyDict::new(py);
            let status = match s.status {
                gamelan_core::coordinator::SessionStatus::SIdle => "idle",
                gamelan_core::coordinator::SessionStatus::SProcessing => "processing",
                gamelan_core::coordinator::SessionStatus::SWaitingDelegate => "waiting_delegate",
                gamelan_core::coordinator::SessionStatus::SDone => "done",
            };
            session_dict.set_item("status", status).unwrap();
            session_dict.set_item("step_count", s.step_count).unwrap();
            let waiting_on: Vec<&str> = s.waiting_on.iter().map(|w| w.as_str()).collect();
            session_dict.set_item("waiting_on", waiting_on).unwrap();
            session_dict.set_item("event_count", s.event_count).unwrap();
            dict.set_item(id, session_dict).unwrap();
        }
        dict
    }

    fn delegation_graph<'py>(&self, py: Python<'py>) -> Bound<'py, PyList> {
        let items: Vec<Bound<'py, PyAny>> = self
            .inner
            .delegation_graph()
            .iter()
            .map(|d| {
                let dict = PyDict::new(py);
                dict.set_item("src", &d.src).unwrap();
                dict.set_item("dst", &d.dst).unwrap();
                dict.into_any()
            })
            .collect();
        PyList::new(py, &items).unwrap()
    }

    fn can_reach(&self, start: &str, target: &str) -> bool {
        self.inner.can_reach(start, target)
    }
}

// ════════════════════════════════════════════════════════════════
// SessionDef — canonical session definition contract (JSON-in/JSON-out)
// ════════════════════════════════════════════════════════════════

/// Load a session definition from JSON. Returns dict with session_config, source_ids, etc.
#[pyfunction]
fn load_session_def<'py>(py: Python<'py>, json: &str) -> PyResult<Bound<'py, PyDict>> {
    let def: SessionDef =
        serde_json::from_str(json).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let result = sd::load(&def);

    let dict = PyDict::new(py);
    let topology_json = serde_json::to_string(&result.session_config.topology)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let inbound_checks_json = serde_json::to_string(&result.session_config.inbound_checks)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    dict.set_item("topology_json", topology_json)?;
    dict.set_item("inbound_checks_json", inbound_checks_json)?;

    let source_ids: Vec<&str> = result.source_ids.iter().map(|s| s.as_str()).collect();
    dict.set_item("source_ids", source_ids)?;
    dict.set_item("transducer_names", &result.transducer_names)?;

    let config_dict = PyDict::new(py);
    for (k, v) in &result.config {
        config_dict.set_item(k, v)?;
    }
    dict.set_item("config", config_dict)?;

    Ok(dict)
}

/// Validate a session definition from JSON. Returns list of error strings.
#[pyfunction]
fn validate_session_def(json: &str) -> PyResult<Vec<String>> {
    let def: SessionDef =
        serde_json::from_str(json).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let errors = sd::validate(&def);
    Ok(errors.iter().map(|e| e.to_string()).collect())
}

/// Validate strictly — raises ValueError on first error.
#[pyfunction]
fn validate_session_def_strict(json: &str) -> PyResult<()> {
    let def: SessionDef =
        serde_json::from_str(json).map_err(|e| PyValueError::new_err(e.to_string()))?;
    sd::validate_strict(&def).map_err(|e| PyValueError::new_err(e.to_string()))
}

// ════════════════════════════════════════════════════════════════
// Topology — derive kernel topology from source interfaces
// ════════════════════════════════════════════════════════════════

/// Derive topology JSON from source registrations and outbound checks (both JSON).
#[pyfunction]
fn derive_topology(sources_json: &str, outbound_checks_json: &str) -> PyResult<String> {
    let sources: Vec<SourceRegistrationInput> = serde_json::from_str(sources_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid sources JSON: {e}")))?;
    let checks: Vec<OutboundCheckInput> = serde_json::from_str(outbound_checks_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid checks JSON: {e}")))?;

    let registrations: Vec<SourceRegistration> = sources
        .into_iter()
        .map(|s| SourceRegistration {
            source_id: s.source_id,
            pairs: s
                .pairs
                .into_iter()
                .map(|p| SourcePair {
                    request_type: p.request_type,
                    result_type: p.result_type,
                })
                .collect(),
        })
        .collect();

    let outbound: Vec<OutboundCheckConfig> = checks
        .into_iter()
        .map(|c| OutboundCheckConfig {
            request_type: c.request_type,
            check_source: c.check_source,
        })
        .collect();

    let topology = topo::derive_topology(&registrations, &outbound);
    serde_json::to_string(&topology).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Derive inbound check defs from JSON.
#[pyfunction]
fn derive_inbound_checks(checks_json: &str) -> PyResult<String> {
    let checks: Vec<InboundCheckInput> = serde_json::from_str(checks_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid checks JSON: {e}")))?;

    let configs: Vec<InboundCheckConfig> = checks
        .into_iter()
        .map(|c| InboundCheckConfig {
            result_type: c.result_type,
            check_source: c.check_source,
        })
        .collect();

    let defs = topo::derive_inbound_checks(&configs);
    serde_json::to_string(&defs).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Resolve which source handles a request type. Returns source_id or None.
#[pyfunction]
fn resolve_source(sources_json: &str, request_type: &str) -> PyResult<Option<String>> {
    let sources: Vec<SourceRegistrationInput> = serde_json::from_str(sources_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid sources JSON: {e}")))?;

    let registrations: Vec<SourceRegistration> = sources
        .into_iter()
        .map(|s| SourceRegistration {
            source_id: s.source_id,
            pairs: s
                .pairs
                .into_iter()
                .map(|p| SourcePair {
                    request_type: p.request_type,
                    result_type: p.result_type,
                })
                .collect(),
        })
        .collect();

    Ok(topo::resolve_source(&registrations, request_type))
}

// JSON-deserializable input types for topology functions
#[derive(serde::Deserialize)]
struct SourcePairInput {
    request_type: String,
    result_type: String,
}

#[derive(serde::Deserialize)]
struct SourceRegistrationInput {
    source_id: String,
    pairs: Vec<SourcePairInput>,
}

#[derive(serde::Deserialize)]
struct OutboundCheckInput {
    request_type: String,
    check_source: String,
}

#[derive(serde::Deserialize)]
struct InboundCheckInput {
    result_type: String,
    check_source: String,
}

// ════════════════════════════════════════════════════════════════
// AgentSession — unified Session<AgentFold> wrapper
// ════════════════════════════════════════════════════════════════

use gamelan_core::agent_fold::AgentEvent;
use gamelan_core::unified_session::{self, Session, ClassifiedRequest};

#[pyclass(name = "AgentSession")]
struct PyAgentSession {
    inner: Session<AgentFold, AgentConnectionState>,
    transducers: Vec<TransducerDef>,
}

#[pymethods]
impl PyAgentSession {
    #[new]
    fn new(
        transducers: Vec<PyTransducerDef>,
        config: &PySessionConfig,
    ) -> Self {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let fold = AgentFold {
            transducers: tds.clone(),
            topology: config.inner.topology.clone(),
            inbound_checks: config.inner.inbound_checks.clone(),
        };
        let env = gamelan_core::loader::init_env(&tds);
        PyAgentSession {
            inner: gamelan_core::agent_fold::session_from_agent_fold(fold, env),
            transducers: tds,
        }
    }

    #[staticmethod]
    fn resume(
        py: Python<'_>,
        transducers: Vec<PyTransducerDef>,
        config: &PySessionConfig,
        event_log: &Bound<'_, PyList>,
    ) -> PyResult<Self> {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let log = py_list_to_event_log(py, event_log)?;
        let state = session::replay(&tds, &config.inner, &log);
        let fold = AgentFold {
            transducers: tds.clone(),
            topology: config.inner.topology.clone(),
            inbound_checks: config.inner.inbound_checks.clone(),
        };
        let event_tags: Vec<String> = log.iter().map(|(t, _)| t.clone()).collect();
        let (conn_state, routing) = gamelan_core::agent_fold::agent_conn_state_from_topology(
            &config.inner.topology, &config.inner.inbound_checks,
        );
        Ok(PyAgentSession {
            inner: Session::restore(fold, state.vm_env, conn_state, routing, state.pending, state.events_processed, event_tags),
            transducers: tds,
        })
    }

    #[staticmethod]
    fn resume_from_snapshot(
        py: Python<'_>,
        transducers: Vec<PyTransducerDef>,
        config: &PySessionConfig,
        snapshot: &PySnapshot,
        remaining_events: &Bound<'_, PyList>,
    ) -> PyResult<Self> {
        let tds: Vec<TransducerDef> = transducers.iter().map(|t| t.inner.clone()).collect();
        let remaining = py_list_to_event_log(py, remaining_events)?;
        let state = session::resume(snapshot.inner.clone(), &config.inner, &tds, &remaining);
        let fold = AgentFold {
            transducers: tds.clone(),
            topology: config.inner.topology.clone(),
            inbound_checks: config.inner.inbound_checks.clone(),
        };
        let event_tags: Vec<String> = remaining.iter().map(|(t, _)| t.clone()).collect();
        let (conn_state, routing) = gamelan_core::agent_fold::agent_conn_state_from_topology(
            &config.inner.topology, &config.inner.inbound_checks,
        );
        Ok(PyAgentSession {
            inner: Session::restore(fold, state.vm_env, conn_state, routing, state.pending, state.events_processed, event_tags),
            transducers: tds,
        })
    }

    // ── Queries ──────────────────────────────────────────

    #[getter]
    fn is_idle(&self) -> bool {
        self.inner.is_idle()
    }

    #[getter]
    fn event_log(&self) -> Vec<String> {
        self.inner.event_log().to_vec()
    }

    #[getter]
    fn events_processed(&self) -> usize {
        self.inner.events_processed()
    }

    #[getter]
    fn pending(&self) -> Vec<String> {
        self.inner.pending().to_vec()
    }

    fn snapshot(&self) -> PySnapshot {
        let pending_strings: Vec<String> = self.inner.pending().to_vec();
        PySnapshot {
            inner: Snapshot {
                pending: pending_strings,
                vm_env: self.inner.state.clone(),
                event_count: self.inner.events_processed(),
            },
        }
    }

    fn get_state<'py>(&self, py: Python<'py>) -> Bound<'py, PyDict> {
        env_to_py_dict(py, &self.inner.state)
    }

    // ── Turn operations ─────────────────────────────────

    /// Does this event need an inbound check before folding?
    /// Returns {"event_tag": str, "check_source": str} or None.
    fn check_inbound<'py>(&self, py: Python<'py>, event_tag: &str) -> PyResult<Option<Bound<'py, PyDict>>> {
        let event = AgentEvent { tag: event_tag.to_string(), data: BTreeMap::new() };
        match self.inner.check_inbound(&event) {
            Some(info) => {
                let d = PyDict::new(py);
                d.set_item("event_tag", &info.event_tag)?;
                d.set_item("check_source", &info.check_source)?;
                Ok(Some(d))
            }
            None => Ok(None),
        }
    }

    /// Fold one event: clear_pending → fold → gate → classify → add_pending.
    /// Returns {"requests": [...]} where each request is a dict with
    /// "action" = "Dispatch" or "CheckThenDispatch".
    fn fold_event<'py>(
        &mut self,
        py: Python<'py>,
        event_tag: &str,
        event_data: &Bound<'py, PyDict>,
    ) -> PyResult<Bound<'py, PyDict>> {
        let data = py_dict_to_env(py, event_data)?;
        let event = AgentEvent { tag: event_tag.to_string(), data };
        let clf = gamelan_core::agent_fold::agent_classify_result_fn(&self.inner.routing.clone());
        let result = self.inner.fold_event(&event, gamelan_core::agent_fold::agent_classify_fn, clf);
        agent_fold_result_to_py(py, result)
    }

    /// Process a boot event (SessionInit, etc). Runs fold, ignores requests.
    fn boot(
        &mut self,
        py: Python<'_>,
        event_tag: &str,
        event_data: &Bound<'_, PyDict>,
    ) -> PyResult<()> {
        let data = py_dict_to_env(py, event_data)?;
        let event = AgentEvent { tag: event_tag.to_string(), data };
        let clf = gamelan_core::agent_fold::agent_classify_result_fn(&self.inner.routing.clone());
        let _result = self.inner.fold_event(&event, gamelan_core::agent_fold::agent_classify_fn, clf);
        Ok(())
    }

    /// Cancel a request rejected by an outbound check.
    fn cancel_request(&mut self, request_type: &str) {
        self.inner.cancel_request(request_type);
    }

    /// Record that an inbound-checked event was rejected.
    fn skip_inbound(&mut self, event_tag: &str) {
        let event = AgentEvent { tag: event_tag.to_string(), data: BTreeMap::new() };
        self.inner.skip_inbound(&event);
    }
}

/// Convert unified FoldResult<Value> to Python dict.
fn agent_fold_result_to_py<'py>(py: Python<'py>, result: unified_session::FoldResult<Value>) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new(py);

    let requests = PyList::new(py,
        result.requests.iter().map(|req| {
            let d = PyDict::new(py);
            match req {
                ClassifiedRequest::Dispatch(value) => {
                    d.set_item("action", "Dispatch").unwrap();
                    let data = PyDict::new(py);
                    if let Value::Map(m) = value {
                        for (k, v) in m {
                            data.set_item(k, value_to_py(py, v)).unwrap();
                        }
                    }
                    d.set_item("request", data).unwrap();
                }
                ClassifiedRequest::CheckThenDispatch { request, check_source } => {
                    d.set_item("action", "CheckThenDispatch").unwrap();
                    d.set_item("check_source", check_source).unwrap();
                    let data = PyDict::new(py);
                    if let Value::Map(m) = request {
                        for (k, v) in m {
                            data.set_item(k, value_to_py(py, v)).unwrap();
                        }
                    }
                    d.set_item("request", data).unwrap();
                }
            }
            d
        })
    )?;
    dict.set_item("requests", requests)?;

    Ok(dict)
}

/// Stdlib helper: produce a SessionInit boot event as (tag, data_dict).
#[pyfunction]
fn session_init<'py>(py: Python<'py>, context: &Bound<'py, PyList>) -> PyResult<(String, Bound<'py, PyDict>)> {
    let ctx_value = py_to_value(py, context.as_any())?;
    let messages = match ctx_value {
        Value::List(items) => items,
        _ => return Err(PyValueError::new_err("context must be a list")),
    };
    let (tag, data) = gamelan_core::stdlib::session_init(messages);
    let py_data = PyDict::new(py);
    for (k, v) in &data {
        py_data.set_item(k, value_to_py(py, v))?;
    }
    Ok((tag, py_data))
}

// ════════════════════════════════════════════════════════════════
// NetworkSession — unified Session<CoordinatorFold> wrapper
// ════════════════════════════════════════════════════════════════

use gamelan_core::network::NetworkConfig;
use gamelan_core::coordinator_fold::{self as cf, CoordinatorFold, NetworkEvent as CfNetworkEvent, NetworkRequest as CfNetworkRequest, NetworkState};

#[pyclass(name = "NetworkSession")]
struct PyNetworkSession {
    inner: Session<CoordinatorFold, NetworkConnectionState>,
}

#[pymethods]
impl PyNetworkSession {
    #[new]
    fn new(
        agents: Vec<String>,
        delegation_routes: Vec<(String, String)>,
        handoff_routes: Vec<(String, String)>,
        entry_point: String,
    ) -> PyResult<Self> {
        let config = NetworkConfig {
            agents,
            delegation_routes,
            handoff_routes,
            entry_point,
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let inner = cf::from_config(&config)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(PyNetworkSession { inner })
    }

    #[getter]
    fn active_agent(&self) -> &str {
        &self.inner.state.active_agent
    }

    fn agent_status(&self, id: &str) -> Option<String> {
        self.inner.state.coord.session(id).map(|s| match s.status {
            gamelan_core::coordinator::SessionStatus::SIdle => "idle".to_string(),
            gamelan_core::coordinator::SessionStatus::SProcessing => "processing".to_string(),
            gamelan_core::coordinator::SessionStatus::SWaitingDelegate => "waiting_delegate".to_string(),
            gamelan_core::coordinator::SessionStatus::SDone => "done".to_string(),
        })
    }

    /// Query a session by ID. Returns dict with status etc, or None.
    fn session<'py>(&self, py: Python<'py>, id: &str) -> Option<Bound<'py, PyDict>> {
        self.inner.state.coord.session(id).map(|s| {
            let dict = PyDict::new(py);
            let status = match s.status {
                gamelan_core::coordinator::SessionStatus::SIdle => "idle",
                gamelan_core::coordinator::SessionStatus::SProcessing => "processing",
                gamelan_core::coordinator::SessionStatus::SWaitingDelegate => "waiting_delegate",
                gamelan_core::coordinator::SessionStatus::SDone => "done",
            };
            dict.set_item("status", status).unwrap();
            dict.set_item("step_count", s.step_count).unwrap();
            let waiting_on: Vec<&str> = s.waiting_on.iter().map(|s| s.as_str()).collect();
            dict.set_item("waiting_on", waiting_on).unwrap();
            dict.set_item("event_count", s.event_count).unwrap();
            dict
        })
    }

    /// Active delegation edges.
    fn delegation_graph<'py>(&self, py: Python<'py>) -> Bound<'py, PyList> {
        let items: Vec<Bound<'py, PyAny>> = self
            .inner
            .state
            .coord
            .delegation_graph()
            .iter()
            .map(|d| {
                let dict = PyDict::new(py);
                dict.set_item("src", &d.src).unwrap();
                dict.set_item("dst", &d.dst).unwrap();
                dict.into_any()
            })
            .collect();
        PyList::new(py, &items).unwrap()
    }

    /// Fold a network event. Returns {"requests": [...], "error": str|None}.
    fn fold_event<'py>(&mut self, py: Python<'py>, event_type: &str, event_data: &Bound<'_, PyDict>) -> PyResult<Bound<'py, PyDict>> {
        let event = py_to_cf_network_event(event_type, event_data)?;
        let result = self.inner.fold_event(
            &event,
            cf::network_classify_fn,
            cf::network_classify_result_fn,
        );

        cf_fold_result_to_py(py, result)
    }

    /// Fold a static delegation (between pre-registered agents).
    fn fold_static_delegation<'py>(&mut self, py: Python<'py>, src: &str, dst: &str) -> PyResult<Bound<'py, PyDict>> {
        let event = CfNetworkEvent::DelegationRequested {
            parent: src.to_string(),
            child: dst.to_string(),
        };
        let result = self.inner.fold_event(
            &event,
            cf::network_classify_fn,
            cf::network_classify_result_fn,
        );
        cf_fold_result_to_py(py, result)
    }

    /// Complete a static delegation.
    fn fold_static_delegation_complete<'py>(&mut self, py: Python<'py>, src: &str, dst: &str) -> PyResult<Bound<'py, PyDict>> {
        let event = CfNetworkEvent::DelegationComplete {
            parent: src.to_string(),
            child: dst.to_string(),
        };
        let result = self.inner.fold_event(
            &event,
            cf::network_classify_fn,
            cf::network_classify_result_fn,
        );
        cf_fold_result_to_py(py, result)
    }

    /// Reset a done agent to idle via fold.
    fn reset_agent(&mut self, id: &str) -> PyResult<()> {
        let event = CfNetworkEvent::ResetAgent { id: id.to_string() };
        let _ = self.inner.fold_event(
            &event,
            cf::network_classify_fn,
            cf::network_classify_result_fn,
        );
        Ok(())
    }
}

fn py_to_cf_network_event(event_type: &str, data: &Bound<'_, PyDict>) -> PyResult<CfNetworkEvent> {
    match event_type {
        "UserMessage" => Ok(CfNetworkEvent::UserMessage { text: String::new() }),
        "DelegationRequested" => {
            let parent: String = data.get_item("parent")?.ok_or_else(|| PyValueError::new_err("missing parent"))?.extract()?;
            let child: String = data.get_item("child")?.ok_or_else(|| PyValueError::new_err("missing child"))?.extract()?;
            Ok(CfNetworkEvent::DelegationRequested { parent, child })
        }
        "DelegationComplete" => {
            let parent: String = data.get_item("parent")?.ok_or_else(|| PyValueError::new_err("missing parent"))?.extract()?;
            let child: String = data.get_item("child")?.ok_or_else(|| PyValueError::new_err("missing child"))?.extract()?;
            Ok(CfNetworkEvent::DelegationComplete { parent, child })
        }
        "DelegationFailed" => {
            let parent: String = data.get_item("parent")?.ok_or_else(|| PyValueError::new_err("missing parent"))?.extract()?;
            let child: String = data.get_item("child")?.ok_or_else(|| PyValueError::new_err("missing child"))?.extract()?;
            Ok(CfNetworkEvent::DelegationFailed { parent, child })
        }
        "HandoffRequested" => {
            let src: String = data.get_item("src")?.ok_or_else(|| PyValueError::new_err("missing src"))?.extract()?;
            let dst: String = data.get_item("dst")?.ok_or_else(|| PyValueError::new_err("missing dst"))?.extract()?;
            Ok(CfNetworkEvent::HandoffRequested { src, dst })
        }
        "HandoffComplete" => {
            let src: String = data.get_item("src")?.ok_or_else(|| PyValueError::new_err("missing src"))?.extract()?;
            let dst: String = data.get_item("dst")?.ok_or_else(|| PyValueError::new_err("missing dst"))?.extract()?;
            Ok(CfNetworkEvent::HandoffComplete { src, dst })
        }
        "AgentDone" => {
            let agent: String = data.get_item("agent")?.ok_or_else(|| PyValueError::new_err("missing agent"))?.extract()?;
            Ok(CfNetworkEvent::AgentDone { id: agent })
        }
        "StartAgent" => {
            let agent: String = data.get_item("agent")?.ok_or_else(|| PyValueError::new_err("missing agent"))?.extract()?;
            Ok(CfNetworkEvent::StartAgent { id: agent })
        }
        "ResetAgent" => {
            let agent: String = data.get_item("agent")?.ok_or_else(|| PyValueError::new_err("missing agent"))?.extract()?;
            Ok(CfNetworkEvent::ResetAgent { id: agent })
        }
        "AgentFailed" => {
            let agent: String = data.get_item("agent")?.ok_or_else(|| PyValueError::new_err("missing agent"))?.extract()?;
            Ok(CfNetworkEvent::AgentFailed { id: agent })
        }
        "RegisterAgent" => {
            let agent: String = data.get_item("agent")?.ok_or_else(|| PyValueError::new_err("missing agent"))?.extract()?;
            Ok(CfNetworkEvent::RegisterAgent { id: agent })
        }
        _ => Err(PyValueError::new_err(format!("unknown network event type: {event_type}"))),
    }
}

fn cf_fold_result_to_py<'py>(py: Python<'py>, result: unified_session::FoldResult<CfNetworkRequest>) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new(py);
    let requests = PyList::new(py,
        result.requests.iter().map(|req| {
            let d = PyDict::new(py);
            match req {
                ClassifiedRequest::Dispatch(nr) | ClassifiedRequest::CheckThenDispatch { request: nr, .. } => {
                    match nr {
                        CfNetworkRequest::AgentRequest { agent } => {
                            d.set_item("type", "AgentRequest").unwrap();
                            d.set_item("agent", agent).unwrap();
                        }
                        CfNetworkRequest::CollectAgentResult { agent } => {
                            d.set_item("type", "CollectAgentResult").unwrap();
                            d.set_item("agent", agent).unwrap();
                        }
                    }
                }
            }
            d
        })
    )?;
    dict.set_item("requests", requests)?;
    // Coordinator fold is total — no error field
    dict.set_item("error", py.None())?;
    Ok(dict)
}

// ════════════════════════════════════════════════════════════════
// Module
// ════════════════════════════════════════════════════════════════

#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Existing
    m.add_function(wrap_pyfunction!(load_transducer, m)?)?;
    m.add_function(wrap_pyfunction!(stdlib, m)?)?;
    m.add_function(wrap_pyfunction!(validate, m)?)?;
    m.add_class::<PyTransducerDef>()?;
    m.add_class::<PySessionConfig>()?;
    m.add_class::<PyStepResult>()?;
    m.add_class::<PySession>()?;
    m.add_class::<PySnapshot>()?;
    m.add_class::<PyContinuationSession>()?;
    m.add_class::<PyFoldResult>()?;
    // Coordinator
    m.add_class::<PyCoordinator>()?;
    // SessionDef
    m.add_function(wrap_pyfunction!(load_session_def, m)?)?;
    m.add_function(wrap_pyfunction!(validate_session_def, m)?)?;
    m.add_function(wrap_pyfunction!(validate_session_def_strict, m)?)?;
    // Topology
    m.add_function(wrap_pyfunction!(derive_topology, m)?)?;
    m.add_function(wrap_pyfunction!(derive_inbound_checks, m)?)?;
    m.add_function(wrap_pyfunction!(resolve_source, m)?)?;
    // AgentSession (two-operation fold API)
    m.add_class::<PyAgentSession>()?;
    m.add_function(wrap_pyfunction!(session_init, m)?)?;
    // NetworkSession (network fold API)
    m.add_class::<PyNetworkSession>()?;
    Ok(())
}
