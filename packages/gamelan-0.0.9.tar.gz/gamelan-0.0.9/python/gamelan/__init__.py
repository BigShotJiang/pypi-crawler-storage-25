"""Gamelan — agent systems with a formally verified kernel.

The core (VM, kernel, session lifecycle) is implemented in Rust.
This package provides the Python runtime: session loop, source/check
protocols, routing, persistence, and multi-session coordination.

Quick start (high-level):

    session = AgentSession(sources={"llm": llm_source, "tools": tool_source})
    events = await session.turn("Hello!")

Quick start (callback model — the preferred extension point):

    from gamelan import SessionRunner, Router, Connection, run_turn, stdlib, SessionConfig

    router = Router([Connection("llm", llm_source)])
    config = SessionConfig(router.topology())
    runner = SessionRunner(stdlib(), config, router.source_resolver())

    # Default: dispatch via router, auto-approve checks
    events = await run_turn(runner, router, [], "LlmResponse", user_event)

    # Custom: intercept dispatches, inject checks, observe steps
    events = await run_turn(runner, router, [], "LlmResponse", user_event,
                            dispatch=my_dispatch,   # (request_type, data) → (result_tag, data)
                            check=my_check,         # (event_tag, data) → CheckVerdict
                            observe=my_observe)      # (TurnEvent) → None
"""

from gamelan._core import (
    ContinuationSession,
    FoldResult,
    Session,
    SessionConfig,
    Snapshot,
    StepResult,
    TransducerDef,
    derive_inbound_checks,
    derive_topology,
    load_session_def,
    load_transducer,
    resolve_source,
    stdlib,
    validate,
    validate_session_def,
    validate_session_def_strict,
)
from gamelan.check import (
    AlwaysReject,
    Approve,
    AutoApprove,
    Check,
    CheckVerdict,
    InboundCheckEntry,
    OutboundCheckEntry,
    Reject,
    Transform,
)
from gamelan.delegation import (
    AsyncDelegationSource,
    DelegationAwaiter,
    SyncDelegationSource,
)
from gamelan.persistence import (
    EventLog,
    MemoryLog,
    MemorySessionStore,
    MemorySnapshotStore,
    SessionInfo,
    SessionStore,
    SnapshotStore,
)
from gamelan.router import Connection, Router
from gamelan.run import (
    TurnHook,
    turn_driver,
    run_turn,
    discover_tools,
    TurnStep,
    DispatchReady,
    CheckNeeded,
    Complete,
    TurnEvent,
    Dispatched,
    DispatchFailed,
    CheckResolved,
)
from gamelan.runner import (
    FoldResult,
    InboundCheckInfo,
    RequestAction,
    RunnerEvent,
    SessionRunner,
)
from gamelan.agent_session import AgentSession
from gamelan.agent_runner import AgentRunner, ContextBlock, SessionCreated
from gamelan.network_runner import (
    AgentDef, AgentRegistration, ClientConfigError,
    NetworkRunner, SessionEvent,
)
from gamelan.session_client import NetworkClient
from gamelan.source import Source
from gamelan.streaming import (
    StreamDone,
    StreamEvent,
    StreamReceiver,
    StreamSender,
    TextDelta,
    ThinkingDelta,
    ToolCallDelta,
    ToolCallStart,
    stream_channel,
)
from gamelan.tools import ToolDef, ToolOutput, ToolSource
from gamelan.jsonl import JsonlEventLog, JsonlSessionStore, JsonlSnapshotStore

__all__ = [
    # Rust core (via PyO3)
    "TransducerDef",
    "SessionConfig",
    "StepResult",
    "Session",
    "Snapshot",
    "ContinuationSession",
    "FoldResult",
    "load_transducer",
    "stdlib",
    "validate",
    "load_session_def",
    "validate_session_def",
    "validate_session_def_strict",
    "derive_topology",
    "derive_inbound_checks",
    "resolve_source",
    # Source / Check protocols
    "Source",
    "Check",
    "CheckVerdict",
    "Approve",
    "Reject",
    "Transform",
    "AutoApprove",
    "AlwaysReject",
    "OutboundCheckEntry",
    "InboundCheckEntry",
    # Router
    "Connection",
    "Router",
    # SessionRunner
    "FoldResult",
    "InboundCheckInfo",
    "RequestAction",
    "RunnerEvent",
    "SessionRunner",
    # turn_driver (primary API)
    "TurnHook",
    "turn_driver",
    "TurnStep",
    "DispatchReady",
    "CheckNeeded",
    "Complete",
    # run_turn (convenience wrapper)
    "run_turn",
    "discover_tools",
    "TurnEvent",
    "Dispatched",
    "DispatchFailed",
    "CheckResolved",
    # Persistence
    "EventLog",
    "SessionStore",
    "SnapshotStore",
    "SessionInfo",
    "MemoryLog",
    "MemorySessionStore",
    "MemorySnapshotStore",
    # Delegation
    "DelegationAwaiter",
    "SyncDelegationSource",
    "AsyncDelegationSource",
    # Tools
    "ToolSource",
    "ToolDef",
    "ToolOutput",
    # JSONL persistence
    "JsonlEventLog",
    "JsonlSessionStore",
    "JsonlSnapshotStore",
    # Streaming
    "StreamEvent",
    "TextDelta",
    "ThinkingDelta",
    "ToolCallStart",
    "ToolCallDelta",
    "StreamDone",
    "StreamSender",
    "StreamReceiver",
    "stream_channel",
    # AgentSession
    "AgentSession",
    # AgentRunner + boot types
    "AgentRunner",
    "ContextBlock",
    "SessionCreated",
    # NetworkRunner + NetworkClient
    "AgentDef",
    "AgentRegistration",
    "ClientConfigError",
    "NetworkRunner",
    "SessionEvent",
    "NetworkClient",
    # Providers (optional — import from gamelan.providers.*)
    "providers",
]
