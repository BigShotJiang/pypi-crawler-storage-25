"""SessionRunner — thin adapter over the Rust AgentSession.

The AgentSession (gamelan-core) provides two pure operations per event:
`check_inbound` and `fold_event`. This module wraps it with Python
dataclasses for downstream compatibility.

Spec: session_loop.qnt. Implementation: gamelan_core::agent_session.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from gamelan._core import AgentSession, SessionConfig, Snapshot


# ════════════════════════════════════════════════════════════════
# Dataclasses for fold results
# ════════════════════════════════════════════════════════════════


@dataclass
class RequestAction:
    """A request from the fold — either dispatch directly or check first."""

    action: str  # "Dispatch" or "CheckThenDispatch"
    request: dict  # request data (has "type" key for request_type)
    check_source: str = ""  # only for CheckThenDispatch

    @property
    def request_type(self) -> str:
        return self.request.get("type", "")

    @property
    def needs_check(self) -> bool:
        return self.action == "CheckThenDispatch"


@dataclass
class FoldResult:
    """Result of folding one event."""

    requests: list[RequestAction] = field(default_factory=list)


@dataclass
class InboundCheckInfo:
    """Info about an inbound check needed before folding."""

    event_tag: str
    check_source: str
    event_data: dict = field(default_factory=dict)


@dataclass
class RunnerEvent:
    """Events emitted for observation (UI, logging, streaming).

    Types:
    - "event": an event entered the fold (carries event_tag + event_data)
    - "dispatched": a request was dispatched to a source
    - "check_triggered": a check was triggered
    - "turn_complete": the turn reached quiescence
    """

    type: str  # "event", "dispatched", "check_triggered", "turn_complete"
    event_tag: str = ""
    event_data: dict = field(default_factory=dict)
    request_type: str = ""
    source_id: str = ""


# ════════════════════════════════════════════════════════════════
# Conversion helpers
# ════════════════════════════════════════════════════════════════


def _to_request_action(d: dict) -> RequestAction:
    return RequestAction(
        action=d["action"],
        request=d.get("request", {}),
        check_source=d.get("check_source", ""),
    )


def _to_fold_result(d: dict) -> FoldResult:
    return FoldResult(
        requests=[_to_request_action(r) for r in d.get("requests", [])],
    )


def _to_inbound_check_info(d: dict, event_data: dict | None = None) -> InboundCheckInfo:
    return InboundCheckInfo(
        event_tag=d["event_tag"],
        check_source=d["check_source"],
        event_data=event_data or {},
    )


# ════════════════════════════════════════════════════════════════
# SessionRunner — adapter over Rust AgentSession
# ════════════════════════════════════════════════════════════════


class SessionRunner:
    """Single-session fold adapter. Delegates to Rust AgentSession.

    Two operations per event:
    - check_inbound(tag) → InboundCheckInfo | None
    - fold_event(tag, data) → FoldResult with classified requests

    The host drives the turn walk using its native async model.
    """

    def __init__(
        self,
        transducers: list,
        config: SessionConfig,
        *,
        _session: AgentSession | None = None,
    ):
        self._session = _session or AgentSession(transducers, config)

    @classmethod
    def resume(
        cls,
        transducers: list,
        config: SessionConfig,
        event_log: list[tuple[str, dict]],
    ) -> "SessionRunner":
        """Resume from a persisted event log by replaying all events."""
        session = AgentSession.resume(transducers, config, event_log)
        return cls(transducers, config, _session=session)

    @classmethod
    def resume_from_snapshot(
        cls,
        transducers: list,
        config: SessionConfig,
        snapshot: Snapshot,
        remaining_events: list[tuple[str, dict]],
    ) -> "SessionRunner":
        """Fast resume from a snapshot checkpoint plus remaining events."""
        session = AgentSession.resume_from_snapshot(
            transducers, config, snapshot, remaining_events,
        )
        return cls(transducers, config, _session=session)

    # ── Queries ────────────────────────────────────────────

    @property
    def is_idle(self) -> bool:
        return self._session.is_idle

    @property
    def event_log(self) -> list[str]:
        return self._session.event_log

    @property
    def events_processed(self) -> int:
        return self._session.events_processed

    @property
    def pending(self) -> list[str]:
        return self._session.pending

    def snapshot(self) -> Snapshot:
        return self._session.snapshot()

    def get_state(self) -> dict:
        """Access the kernel's transducer state (vm_env)."""
        return self._session.get_state()

    # ── Turn operations ──────────────────────────────────

    def check_inbound(self, event_tag: str, event_data: dict | None = None) -> InboundCheckInfo | None:
        """Does this event need an inbound check before folding?"""
        raw = self._session.check_inbound(event_tag)
        if raw is None:
            return None
        return _to_inbound_check_info(raw, event_data)

    def fold_event(self, event_tag: str, event_data: dict) -> FoldResult:
        """Fold one event: clear_pending → fold → gate → classify → add_pending."""
        raw = self._session.fold_event(event_tag, event_data)
        return _to_fold_result(raw)

    def boot(self, event_tag: str, event_data: dict) -> None:
        """Process a boot event (SessionInit, etc). Runs fold, ignores requests."""
        self._session.boot(event_tag, event_data)

    def cancel_request(self, request_type: str) -> None:
        """Cancel a request rejected by an outbound check."""
        self._session.cancel_request(request_type)

    def skip_inbound(self, event_tag: str) -> None:
        """Record that an inbound-checked event was rejected."""
        self._session.skip_inbound(event_tag)
