"""Router — maps sources to topology, resolves requests to sources.

Bridges the gap between the runtime's Source protocol and the kernel's
Topology/ConnectionDef. Derives the kernel config at boot and resolves
request types to source instances at dispatch time.

Matches session_loop.qnt derive_topology and resolve_source.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from gamelan._core import derive_topology as _derive_topology
from gamelan.check import OutboundCheckEntry
from gamelan.source import Source


@dataclass
class Connection:
    """A named source connection."""

    id: str
    source: Source


class Router:
    """Routes requests to sources. Derives kernel Topology at boot."""

    def __init__(self, connections: list[Connection]):
        self._connections = connections
        self._route_table: dict[str, int] = {}
        for idx, conn in enumerate(connections):
            for pair in conn.source.interface():
                self._route_table[pair["request_type"]] = idx

    def topology(self, checks: list[OutboundCheckEntry] | None = None) -> str:
        """Derive kernel topology JSON from source interfaces + checks.

        Returns JSON string suitable for SessionConfig(topology_json=...).
        """
        sources = []
        for conn in self._connections:
            sources.append({
                "source_id": conn.id,
                "pairs": conn.source.interface(),
            })

        check_list = []
        if checks:
            for c in checks:
                check_list.append({
                    "request_type": c.request_type,
                    "check_source": c.source_id,
                })

        return _derive_topology(json.dumps(sources), json.dumps(check_list))

    def resolve(self, request_type: str) -> Connection | None:
        """Find the connection for a request type."""
        idx = self._route_table.get(request_type)
        if idx is not None:
            return self._connections[idx]
        return None

    @property
    def connections(self) -> list[Connection]:
        return self._connections

    def source_resolver(self) -> callable:
        """Return a function that maps request_type -> source_id.

        Used by SessionRunner.
        """
        table: dict[str, str] = {}
        for conn in self._connections:
            for pair in conn.source.interface():
                table[pair["request_type"]] = conn.id
        return lambda req_type: table.get(req_type)
