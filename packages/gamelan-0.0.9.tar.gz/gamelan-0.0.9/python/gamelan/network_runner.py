"""NetworkRunner — async turn loop over the network session.

Spec: network_turn.qnt, manager.qnt, client.qnt

Drives the network to quiescence by resolving AgentRequest through
agent runners. Each agent has its own source map (per client.qnt).
The executor is built internally from the agent's sources.

    client = NetworkClient(
        agents={"agent": (agent_def, {"llm": llm_source})},
        entry_point="agent",
    )
    async for event in client.send_message("hello"):
        print(event)
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field

from gamelan._core import NetworkSession, SessionConfig
from gamelan.agent_runner import AgentRunner
from gamelan.executor import SourceExecutor
from gamelan.runner import RunnerEvent
from gamelan.source import Source


# ════════════════════════════════════════════════════════════════
# Types
# ════════════════════════════════════════════════════════════════


@dataclass
class AgentDef:
    """Declarative agent definition — serializable config.

    Spec: defs.qnt AgentDef. Does NOT include sources (runtime binding).
    """

    transducers: list
    config: SessionConfig
    resolve_source: Callable[[str], str | None]


@dataclass
class AgentRegistration:
    """Agent def + per-agent source bindings.

    Spec: client.qnt AgentRegistration.
    The source map keys are source_ids referenced by AgentDef connections.
    """

    agent_def: AgentDef
    sources: dict[str, Source]


@dataclass
class SessionEvent:
    """Events from NetworkClient — wraps agent + network events."""

    type: str  # "agent", "network", "turn_complete"
    agent: str = ""
    event: RunnerEvent | None = None
    network_event: str = ""


# ════════════════════════════════════════════════════════════════
# Validation — matches client.qnt predicates
# ════════════════════════════════════════════════════════════════


class ClientConfigError(Exception):
    """Invalid NetworkClient configuration."""
    pass


def validate_client_config(
    agents: dict[str, AgentRegistration],
    delegation_routes: list[tuple[str, str]],
    handoff_routes: list[tuple[str, str]],
    entry_point: str,
) -> None:
    """Validate per client.qnt client_config_valid. Raises on failure."""
    if not agents:
        raise ClientConfigError("at least one agent required")

    # entry_point_valid
    if entry_point not in agents:
        raise ClientConfigError(f"entry_point '{entry_point}' not in agents: {list(agents.keys())}")

    # Per-agent validation
    for agent_id, reg in agents.items():
        bound = set(reg.sources.keys())
        resolve = reg.agent_def.resolve_source

        # sources_complete: every source_id resolved from connections must be bound
        for conn in _get_connections(reg.agent_def.config):
            req_type = conn.get("request_type", "")
            sid = resolve(req_type) if resolve else None
            if sid and sid not in bound:
                raise ClientConfigError(
                    f"agent '{agent_id}': source_id '{sid}' (for {req_type}) not in bound sources {bound}"
                )

        # check_sources_bound: has_check → check_source must be bound
        for conn in _get_connections(reg.agent_def.config):
            if conn.get("has_check") and conn.get("check_source"):
                cs = conn["check_source"]
                if cs not in bound:
                    raise ClientConfigError(
                        f"agent '{agent_id}': check_source '{cs}' not in bound sources {bound}"
                    )

    agent_names = set(agents.keys())

    # delegation_routes_valid
    for src, dst in delegation_routes:
        if src not in agent_names:
            raise ClientConfigError(f"delegation route src '{src}' not a registered agent")
        if dst not in agent_names:
            raise ClientConfigError(f"delegation route dst '{dst}' not a registered agent")

    # handoff_routes_valid
    for src, dst in handoff_routes:
        if src not in agent_names:
            raise ClientConfigError(f"handoff route src '{src}' not a registered agent")
        if dst not in agent_names:
            raise ClientConfigError(f"handoff route dst '{dst}' not a registered agent")

    # no_self_routes
    for src, dst in delegation_routes:
        if src == dst:
            raise ClientConfigError(f"self-delegation not allowed: '{src}'")
    for src, dst in handoff_routes:
        if src == dst:
            raise ClientConfigError(f"self-handoff not allowed: '{src}'")


def _get_connections(config: SessionConfig) -> list[dict]:
    """Extract connection dicts from SessionConfig topology."""
    import json
    try:
        return json.loads(config.topology_json)
    except Exception:
        return []


# ════════════════════════════════════════════════════════════════
# NetworkRunner
# ════════════════════════════════════════════════════════════════


class NetworkRunner:
    """Async turn loop over the network coordinator session.

    Each agent has its own source map. The executor is built
    internally per-agent from the source map.
    """

    def __init__(
        self,
        agents: dict[str, AgentRegistration],
        *,
        delegation_routes: list[tuple[str, str]] | None = None,
        handoff_routes: list[tuple[str, str]] | None = None,
        entry_point: str,
    ):
        agent_names = list(agents.keys())
        self.network = NetworkSession(
            agents=agent_names,
            delegation_routes=delegation_routes or [],
            handoff_routes=handoff_routes or [],
            entry_point=entry_point,
        )
        self._registrations = dict(agents)
        self._agents: dict[str, AgentRunner] = {}
        self._executors: dict[str, SourceExecutor] = {}

        # Pre-build executors from source maps
        for agent_id, reg in agents.items():
            self._executors[agent_id] = SourceExecutor(reg.sources)

    @property
    def active_agent(self) -> str:
        return self.network.active_agent

    def has_runner(self, agent: str) -> bool:
        return agent in self._agents

    def ensure_runner(self, agent: str) -> AgentRunner:
        if agent not in self._agents:
            reg = self._registrations.get(agent)
            if reg is None:
                raise LookupError(f"no agent registration for {agent}")
            d = reg.agent_def
            self._agents[agent] = AgentRunner(
                d.transducers, d.config, d.resolve_source
            )
        return self._agents[agent]

    async def run_turn(
        self,
        event_type: str,
        event_data: dict,
    ) -> AsyncIterator[SessionEvent]:
        """Drive the network to quiescence, yielding events."""
        result = self.network.fold_event(event_type, event_data)
        requests = result.get("requests", [])

        if requests:
            async for event in self._walk_requests(requests, event_data):
                yield event
        elif event_type == "UserMessage":
            agent = self.active_agent
            if agent:
                async for event in self._drive_agent(agent, "UserMessage", event_data):
                    yield event

    async def _walk_requests(
        self,
        requests: list[dict],
        event_data: dict,
    ) -> AsyncIterator[SessionEvent]:
        for req in requests:
            req_type = req.get("type", "")
            agent = req.get("agent", "")
            if req_type == "AgentRequest" and agent:
                async for event in self._drive_agent(agent, "UserMessage", event_data):
                    yield event

    async def _drive_agent(
        self,
        agent: str,
        event_tag: str,
        event_data: dict,
    ) -> AsyncIterator[SessionEvent]:
        runner = self.ensure_runner(agent)
        executor = self._executors.get(agent)
        if executor is None:
            raise LookupError(f"no executor for agent {agent}")

        events = await runner.run_turn(executor, event_tag, event_data)
        for event in events:
            yield SessionEvent(type="agent", agent=agent, event=event)

        # Feed AgentDone back to network
        result = self.network.fold_event("AgentDone", {"agent": agent})
        requests = result.get("requests", [])

        if requests:
            async for event in self._walk_requests(requests, {}):
                yield event
