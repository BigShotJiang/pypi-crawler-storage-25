"""Source protocol — async I/O boundary between sessions and the outside world.

Sources dispatch requests and return results. They declare their
interface (what request/result pairs they handle) so the runtime can
derive the kernel Topology at boot.

Matches session_loop.qnt SourceRegistration and the Rust Source trait.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class Source(Protocol):
    """Async I/O boundary. Sources handle requests and return results."""

    async def dispatch(
        self, request_tag: str, request_data: dict
    ) -> tuple[str, dict]:
        """Dispatch a request, return a single result event.

        Args:
            request_tag: The request type (e.g. "LlmRequest").
            request_data: The request payload.

        Returns:
            (result_tag, result_data) — one result event.
        """
        ...

    def interface(self) -> list[dict]:
        """Declare what this source handles.

        Returns a list of {"request_type": ..., "result_type": ...} pairs.
        Used at boot to derive the kernel Topology.
        """
        ...
