# Getting Started

## Install

```bash
pip install gamelan
```

For LLM providers, install the extras you need:

```bash
pip install gamelan[anthropic]   # Anthropic Claude
pip install gamelan[openai]      # OpenAI GPT
pip install gamelan[litellm]     # LiteLLM (multi-provider)
pip install gamelan[mcp]         # MCP tool servers
pip install gamelan[all]         # Everything
```

## First agent (AgentSession)

The quickest path — `AgentSession` handles all the wiring:

```python
import asyncio
from gamelan import AgentSession
from gamelan.providers.anthropic import AnthropicSource

async def main():
    session = AgentSession(sources={
        "llm": AnthropicSource(model="claude-sonnet-4-20250514"),
    })

    events = await session.turn("Explain the reactor pattern in two sentences.")
    print(session.messages[-1])

asyncio.run(main())
```

## Under the hood: turn_driver

`AgentSession` wraps `turn_driver`, a bidirectional async generator that gives you full control over every dispatch step. This is the primary API:

```python
from gamelan import turn_driver, DispatchReady, CheckNeeded, Complete, Approve
from gamelan import SessionRunner, Router, Connection, stdlib, SessionConfig
from gamelan.providers.anthropic import AnthropicSource

# Set up
llm = AnthropicSource(model="claude-sonnet-4-20250514")
router = Router([Connection("llm", llm)])
config = SessionConfig(router.topology())
runner = SessionRunner(stdlib(), config, router.source_resolver())

# Build the user message
event_data = {
    "role": "user",
    "parts": [{"kind": "text", "text": "Explain the reactor pattern."}],
    "input_tokens": 0, "output_tokens": 0,
}

# Drive the turn
driver = turn_driver(runner, "LlmResponse", event_data)
step = await driver.__anext__()

while not isinstance(step, Complete):
    match step:
        case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
            conn = router.resolve(rt)
            result = await conn.source.dispatch(rt, rd)
            step = await driver.asend(result)
        case CheckNeeded(event_tag=tag, event_data=data):
            step = await driver.asend(Approve())

print(runner.state.get("messages"))
```

The generator yields steps; you send results back. You own the dispatch loop — retry, observability, error handling are all your concerns.

## Adding tools

Register Python functions as tools. The LLM sees their schemas and can call them:

```python
from gamelan import AgentSession, ToolSource
from gamelan.providers.anthropic import AnthropicSource

tools = ToolSource()

@tools.tool("read_file", "Read a file from disk")
async def read_file(args):
    path = args["path"]
    return open(path).read()

@tools.tool("list_files", "List files in a directory")
async def list_files(args):
    import os
    return "\n".join(os.listdir(args.get("path", ".")))

session = AgentSession(sources={
    "llm": AnthropicSource(model="claude-sonnet-4-20250514"),
    "tools": tools,
})

events = await session.turn("What files are in the current directory?")
```

With `turn_driver`, tool dispatches appear as `DispatchReady(request_type="ToolRequest", ...)`. You dispatch to the tool source the same way as the LLM.

## Typed tools (Pydantic)

For structured input validation, use a Pydantic model:

```python
from pydantic import BaseModel

class SearchArgs(BaseModel):
    query: str
    max_results: int = 10

@tools.tool("search", "Search the knowledge base")
async def search(args: SearchArgs) -> str:
    results = await kb.search(args.query, limit=args.max_results)
    return "\n".join(r.text for r in results)
```

The schema is auto-generated from the model and sent to the LLM. Arguments are validated before your handler is called.

## Multi-turn conversations

State is maintained on the `SessionRunner` across turns. With `AgentSession`:

```python
session = AgentSession(sources={"llm": llm, "tools": tools})

await session.turn("Find all Python files in src/")
await session.turn("Which ones import asyncio?")
await session.turn("Summarize what they do")
```

With `turn_driver`, create a new generator for each turn — the runner remembers:

```python
# Turn 1
driver = turn_driver(runner, "LlmResponse", user_msg_1)
# ... drive to completion

# Turn 2 — same runner
driver = turn_driver(runner, "LlmResponse", user_msg_2)
# ... drive to completion
```

## Persistence

Pass `store_path` to persist events to disk. Sessions survive process restarts:

```python
session = AgentSession(
    sources={"llm": llm, "tools": tools},
    store_path="./sessions/my-agent",
)
```

Events are stored as JSONL. See [persistence.md](persistence.md) for snapshots and crash recovery.

## Inspecting state

```python
# Via AgentSession
session.state          # All transducer slot values (dict)
session.messages       # Conversation history
session.is_idle        # True when turn is complete
session.events_processed  # Total events through the kernel
session.snapshot()     # Serializable snapshot for fast resume

# Via SessionRunner directly
runner.state           # Same slot values
runner.is_idle
runner.phase           # Idle, Processing, WaitingForResults, Done
```

## What's next

- [turn_driver](turn-driver.md) — the async generator protocol, building custom drivers
- [run_turn and callbacks](run-turn.md) — convenience wrapper over turn_driver
- [Sources](sources.md) — writing custom sources
- [Checks](checks.md) — approval flows before tool execution
- [Observability](observability.md) — OTel tracing, hooks, custom instrumentation
- [Streaming](streaming.md) — real-time output for UIs
- [Multi-session](multi-session.md) — delegation between agents
