# Sources

Sources are the I/O boundary between the kernel and the outside world. They dispatch requests and return results.

## The Source protocol

```python
class Source(Protocol):
    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        """Execute a request, return (result_tag, result_data)."""
        ...

    def interface(self) -> list[dict]:
        """Declare handled request/result pairs."""
        ...
```

`interface()` is called at boot to derive the kernel topology. `dispatch()` is called during turns when the kernel emits a matching request.

## Built-in providers

### Anthropic

```python
from gamelan.providers.anthropic import AnthropicSource

llm = AnthropicSource(
    model="claude-sonnet-4-20250514",
    max_tokens=4096,
    api_key="sk-...",       # or ANTHROPIC_API_KEY env var
)
```

Handles `LlmRequest → LlmResponse`. Supports streaming via `StreamSender`.

### OpenAI

```python
from gamelan.providers.openai import OpenAISource

llm = OpenAISource(
    model="gpt-4o",
    max_tokens=4096,
    api_key="sk-...",       # or OPENAI_API_KEY env var
)
```

### LiteLLM

```python
from gamelan.providers.litellm import LiteLLMSource

llm = LiteLLMSource(model="anthropic/claude-sonnet-4-20250514")
```

Supports any model that LiteLLM can route to.

### MCP (Model Context Protocol)

```python
from gamelan.providers.mcp import McpSource

mcp = await McpSource.connect("npx", ["-y", "@modelcontextprotocol/server-filesystem"])
```

Connects to an MCP tool server. Handles `ToolRequest → ToolResult` with auto-discovery.

## ToolSource (local functions)

For tools implemented as Python functions:

```python
from gamelan import ToolSource

tools = ToolSource()

@tools.tool("search", "Search the codebase")
async def search(args):
    return await do_search(args["query"])

# Manual registration
tools.register_raw("echo", "Echo input", {"type": "object"}, echo_handler)
```

See [getting-started.md](getting-started.md) for typed tools with Pydantic.

## Tool discovery

Sources can optionally implement `discover()` to provide tool schemas:

```python
class MySource:
    async def discover(self) -> list[dict]:
        return [{"name": "my_tool", "description": "...", "parameters": {...}}]
```

Discovered schemas are injected into `LlmRequest` payloads so the LLM knows what tools are available.

## Writing a custom source

A source that wraps an HTTP API:

```python
import httpx

class WeatherSource:
    def __init__(self, api_key: str):
        self._client = httpx.AsyncClient()
        self._api_key = api_key

    def interface(self) -> list[dict]:
        return [{"request_type": "WeatherRequest", "result_type": "WeatherResult"}]

    async def dispatch(self, request_tag: str, request_data: dict) -> tuple[str, dict]:
        resp = await self._client.get(
            "https://api.weather.example/v1/current",
            params={"q": request_data["location"]},
            headers={"Authorization": f"Bearer {self._api_key}"},
        )
        data = resp.json()
        return ("WeatherResult", {
            "location": data["name"],
            "temperature": data["main"]["temp"],
            "description": data["weather"][0]["description"],
        })
```

To use a custom source, define a matching connection in the topology. The simplest way is to add a custom transducer that emits `WeatherRequest` and handles `WeatherResult`, or use the tool source pattern where the LLM calls weather as a tool.

## Streaming sources

LLM sources can accept a `StreamSender` to emit real-time deltas:

```python
from gamelan import stream_channel

sender, receiver = stream_channel()
llm = AnthropicSource(model="claude-sonnet-4-20250514", stream=sender)

# In the UI task:
async for delta in receiver:
    print(delta.text, end="", flush=True)
```

Deltas bypass the kernel. The kernel only sees the final complete `LlmResponse` event. See [streaming.md](streaming.md).

## Sources and turn_driver

With `turn_driver`, each source dispatch appears as a `DispatchReady` step. The host resolves the source via the router and calls `dispatch()`:

```python
case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
    conn = router.resolve(rt)
    result = await conn.source.dispatch(rt, rd)
    step = await driver.asend(result)
```

See [turn-driver.md](turn-driver.md) for the full step protocol.
