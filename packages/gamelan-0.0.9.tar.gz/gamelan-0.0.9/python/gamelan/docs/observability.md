# Observability

Gamelan provides lifecycle hooks on `turn_driver` for instrumentation. OTel support ships as an optional extra — install `gamelan[otel]` and pass a hook. No code changes to your agent logic.

## TurnHook protocol

Hooks fire at key points during turn execution:

```python
class TurnHook(Protocol):
    def on_turn_start(self, event_tag: str, event_data: dict) -> Any: ...
    def on_turn_end(self, events: list[RunnerEvent], error: Exception | None, ctx: Any) -> None: ...
    def on_dispatch_start(self, request_type: str, source_id: str, request_data: dict, turn_ctx: Any) -> Any: ...
    def on_dispatch_end(self, request_type: str, result: tuple | None, error: bool, ctx: Any) -> None: ...
    def on_check_start(self, event_tag: str, source_id: str, event_data: dict, turn_ctx: Any) -> Any: ...
    def on_check_end(self, event_tag: str, verdict: CheckVerdict, ctx: Any) -> None: ...
```

Each `_start` method returns an opaque context passed back to `_end`. For OTel, that's the span. For logging, a timestamp. For metrics, a counter.

Hooks are synchronous — they don't do I/O. Multiple hooks compose via the `hooks` list.

## Quick start: OTel tracing

```bash
pip install gamelan[otel]
```

```python
from gamelan import AgentSession
from gamelan.otel import configure_tracing
from gamelan.providers.anthropic import AnthropicSource

hook = configure_tracing(service_name="my-agent")

session = AgentSession(
    sources={"llm": AnthropicSource(model="claude-sonnet-4-20250514")},
    hooks=[hook],
)

await session.turn("What is the reactor pattern?")
```

Every turn emits spans to the configured collector. No other changes needed.

## What gets traced

Three span types following GenAI semantic conventions:

```
Agent span (invoke_agent, INTERNAL)
├── LLM span (chat, CLIENT)           ← each LlmRequest dispatch
├── Tool span (execute_tool, INTERNAL) ← each ToolRequest dispatch
├── LLM span (chat, CLIENT)           ← follow-up after tool result
└── ...
```

### Agent span

Wraps the entire turn. Set on every turn.

| Attribute | Value |
|-----------|-------|
| `gen_ai.operation.name` | `invoke_agent` |
| `gen_ai.agent.name` | From `agent_name` parameter |

### LLM span

One per LLM dispatch. SpanKind: CLIENT.

| Attribute | Value |
|-----------|-------|
| `gen_ai.operation.name` | `chat` |
| `gen_ai.request.model` | Model name from request |
| `gen_ai.response.model` | Model name from response |
| `gen_ai.usage.input_tokens` | Input token count |
| `gen_ai.usage.output_tokens` | Output token count |
| `gen_ai.system` | `anthropic`, `openai`, or `unknown` |
| `gen_ai.response.id` | Response ID (if present) |
| `gen_ai.input.messages` | Input messages (if `capture_content=True`) |
| `gen_ai.output.messages` | Output messages (if `capture_content=True`) |

OpenLit-compatible token attributes are also set for Cat Cafe:
`llm.token_count.prompt`, `llm.token_count.completion`, `llm.token_count.total`.

### Tool span

One per tool dispatch. SpanKind: INTERNAL.

| Attribute | Value |
|-----------|-------|
| `gen_ai.operation.name` | `execute_tool` |
| `gen_ai.tool.name` | Tool name |
| `gen_ai.tool.call.arguments` | Tool input (if `capture_content=True`) |
| `gen_ai.tool.call.result` | Tool output (if `capture_content=True`) |

OpenInference-compatible: `input.value`, `output.value`, `input.mime_type`.

### Errors

Failed dispatches set `StatusCode.ERROR` and `error.type` on the span. The agent span gets error status if the turn fails.

## configure_tracing

```python
from gamelan.otel import configure_tracing

hook = configure_tracing(
    service_name="my-agent",           # service.name resource attribute
    endpoint="http://localhost:4318",   # OTLP collector URL
    capture_content=True,              # capture messages and tool I/O
    agent_name="my-agent",             # gen_ai.agent.name
)
```

Defaults:
- `endpoint`: `OTEL_EXPORTER_OTLP_ENDPOINT` env var, or `http://localhost:4318`
- `service_name`: `OTEL_SERVICE_NAME` env var, or `"gamelan"`
- `capture_content`: `True`

Sets up a `TracerProvider` with `BatchSpanProcessor` and `OTLPSpanExporter` (HTTP/protobuf). Registers as the global provider.

## Using hooks at every level

```python
hook = configure_tracing(service_name="my-agent")

# AgentSession — zero-effort auto-instrumentation
session = AgentSession(sources={...}, hooks=[hook])

# run_turn — callback convenience with hooks
events = await run_turn(runner, router, [], tag, data, hooks=[hook])

# turn_driver — full control with hooks
driver = turn_driver(runner, tag, data, hooks=[hook])
```

Hooks flow from `AgentSession` → `run_turn` → `turn_driver`. Set once, fires on every turn.

## Sending to Cat Cafe

Start Cat Cafe:

```bash
cd ../cat-cafe && docker compose up
```

Configure gamelan to export:

```python
hook = configure_tracing(
    service_name="my-agent",
    endpoint="http://localhost:4318",
    capture_content=True,
)
```

Or set environment variables:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
export OTEL_SERVICE_NAME=my-agent
```

Traces appear in Cat Cafe at `http://localhost:8000` with full GenAI span hierarchy, token usage, and message content.

## Writing custom hooks

Implement `TurnHook` for any instrumentation:

### Logging hook

```python
import logging
import time

log = logging.getLogger("gamelan")

class LoggingHook:
    def on_turn_start(self, event_tag, event_data):
        log.info(f"turn started: {event_tag}")
        return time.monotonic()

    def on_turn_end(self, events, error, ctx):
        elapsed = time.monotonic() - ctx
        status = "error" if error else "ok"
        log.info(f"turn ended ({status}, {elapsed:.2f}s)")

    def on_dispatch_start(self, request_type, source_id, request_data, turn_ctx):
        log.info(f"  dispatch: {request_type} → {source_id}")
        return time.monotonic()

    def on_dispatch_end(self, request_type, result, error, ctx):
        elapsed = time.monotonic() - ctx
        status = "error" if error else result[0] if result else "none"
        log.info(f"  complete: {request_type} → {status} ({elapsed:.2f}s)")

    def on_check_start(self, event_tag, source_id, event_data, turn_ctx):
        return None

    def on_check_end(self, event_tag, verdict, ctx):
        log.info(f"  check: {event_tag} → {type(verdict).__name__}")
```

### Metrics hook

```python
class MetricsHook:
    def __init__(self):
        self.dispatch_count = 0
        self.error_count = 0
        self.total_input_tokens = 0
        self.total_output_tokens = 0

    def on_turn_start(self, event_tag, event_data):
        return None

    def on_turn_end(self, events, error, ctx):
        pass

    def on_dispatch_start(self, request_type, source_id, request_data, turn_ctx):
        self.dispatch_count += 1
        return None

    def on_dispatch_end(self, request_type, result, error, ctx):
        if error:
            self.error_count += 1
        elif result and request_type == "LlmRequest":
            _, data = result
            self.total_input_tokens += data.get("input_tokens", 0)
            self.total_output_tokens += data.get("output_tokens", 0)

    def on_check_start(self, event_tag, source_id, event_data, turn_ctx):
        return None

    def on_check_end(self, event_tag, verdict, ctx):
        pass
```

### Composing hooks

```python
session = AgentSession(
    sources={"llm": llm},
    hooks=[otel_hook, logging_hook, metrics_hook],
)
```

All hooks fire for every lifecycle event. Order is preserved.
