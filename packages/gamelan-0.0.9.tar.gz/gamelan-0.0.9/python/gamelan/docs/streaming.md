# Streaming

LLM responses arrive as a stream of tokens. The kernel sees only the complete response event. Streaming deltas go directly to the UI via a separate channel.

## Architecture

```
LLM Source ──→ StreamSender ──→ StreamReceiver ──→ UI (real-time deltas)
     │
     └──→ Complete LlmResponse ──→ Kernel (event-sourced state)
```

Deltas bypass the kernel entirely. The kernel's determinism is preserved — it always processes the same complete event regardless of how it was streamed.

## Basic usage

```python
from gamelan import AgentSession, stream_channel
from gamelan.providers.anthropic import AnthropicSource

sender, receiver = stream_channel()

session = AgentSession(
    sources={"llm": AnthropicSource(model="claude-sonnet-4-20250514", stream=sender)},
)

# UI task: print tokens as they arrive
async def print_stream():
    async for delta in receiver:
        if isinstance(delta, TextDelta):
            print(delta.text, end="", flush=True)

import asyncio
ui_task = asyncio.create_task(print_stream())
await session.turn("Write a haiku about concurrency")
await ui_task
```

## Stream events

```python
from gamelan import TextDelta, ThinkingDelta, ToolCallStart, ToolCallDelta, StreamDone

# Text content (most common)
TextDelta(text="Hello")

# Thinking/reasoning (extended thinking models)
ThinkingDelta(text="Let me consider...")

# Tool call started
ToolCallStart(id="tc_1", name="search")

# Tool call arguments (incremental JSON)
ToolCallDelta(id="tc_1", json_delta='{"query":')

# Response complete
StreamDone()
```

## Multiple receivers

`StreamSender` broadcasts to all subscribers:

```python
sender = StreamSender()
ui_receiver = sender.subscribe()
log_receiver = sender.subscribe()

# Both receive all events independently
```

## Channel API

```python
from gamelan import stream_channel, StreamSender, StreamReceiver

# Convenience: create a sender + one receiver
sender, receiver = stream_channel(capacity=256)

# Manual: create sender, subscribe multiple receivers
sender = StreamSender(capacity=256)
r1 = sender.subscribe()
r2 = sender.subscribe()

# Sender (source side)
sender.send(TextDelta(text="hi"))
sender.done()  # signals completion

# Receiver (UI side)
event = await receiver.recv()        # single event, None when done
async for event in receiver:         # iterate until done
    ...
```

Capacity controls the per-receiver queue size. Events are dropped (not blocked) if a receiver falls behind.
