# Checks

Checks verify requests before dispatch. They implement approval flows — the agent proposes a tool call, the check decides whether it proceeds.

## The Check protocol

```python
class Check(Protocol):
    async def check(self, event_tag: str, event_data: dict) -> CheckVerdict:
        ...
```

Returns one of:

- `Approve()` — dispatch as-is
- `Reject(reason="...")` — drop the request
- `Transform(data={...})` — approve with modified payload

## Setting up checks

Checks are bound to connections in the topology. A connection with `has_check: true` gates dispatch through the check before sending to the source.

### With AgentSession

```python
from gamelan import AgentSession, OutboundCheckEntry

class ToolApproval:
    async def check(self, event_tag, event_data):
        tool_name = event_data.get("name", "")
        if tool_name in ["delete_file", "run_command"]:
            return Reject(reason="dangerous tool")
        return Approve()

session = AgentSession(
    sources={"llm": llm, "tools": tools},
    checks={"approval": OutboundCheckEntry(
        request_type="ToolRequest",
        source_id="approval",
        check=ToolApproval(),
    )},
)
```

### With run_turn callbacks

For more control, use the `check` callback directly. This bypasses the `OutboundCheckEntry` lookup:

```python
async def my_check(event_tag, event_data):
    if event_tag == "ToolRequest":
        approved = await ask_user(event_data)
        return Approve() if approved else Reject(reason="user denied")
    return Approve()

events = await run_turn(runner, router, [], tag, data, check=my_check)
```

See [run-turn.md](run-turn.md) for the full callback API.

## Built-in checks

```python
from gamelan import AutoApprove, AlwaysReject

# Full auto — approve everything (default behavior)
check = AutoApprove()

# Read-only — reject all tool calls
check = AlwaysReject()
```

## Inbound checks

Inbound checks verify events **before** they enter the fold (e.g. checking LLM responses for safety). They use `InboundVerdict` which has **no reject** — only approve or transform.

Why no reject? Dropping an inbound result would orphan the pending request in the kernel, causing the session to hang forever. Transform covers all cases: unsafe content → refusal message, PII → redacted, malformed → error.

```python
from gamelan.check import InboundApprove, InboundTransform

class ContentFilter:
    async def check(self, event_tag, event_data):
        if contains_pii(event_data):
            return InboundTransform(data=redact(event_data))
        return InboundApprove()
```

## How checks interact with the kernel

Checks are a runtime concern, not a kernel concern. The kernel handles the mechanics:

1. **Outbound**: A connection with `has_check: true` emits `CheckThenDispatch`. The runtime gets a verdict:
   - Approve → dispatch as-is
   - Reject → turn ends immediately (spec: `runner.qnt:108-120`)
   - Transform → dispatch with modified data

2. **Inbound**: An `inbound_check` rule matches by result type. The runtime gets a verdict:
   - Approve → event proceeds to fold
   - Transform → event proceeds with modified data
   - No reject (spec: `executor.qnt:34-48`)

The kernel's gate/hold invariants guarantee that checked requests are never dispatched without a verdict.
