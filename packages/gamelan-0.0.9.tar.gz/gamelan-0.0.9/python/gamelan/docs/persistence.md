# Persistence

The kernel is event-sourced. Every event is logged. State is a projection of the log. This enables crash recovery, replay, and debugging.

## Event logs

An `EventLog` is a per-session, append-only sequence of `(tag, data)` pairs:

```python
class EventLog(Protocol):
    def append(self, event: tuple[str, dict]) -> None: ...
    def load(self) -> list[tuple[str, dict]]: ...
    def load_after(self, index: int) -> list[tuple[str, dict]]: ...
    def __len__(self) -> int: ...
```

### JSONL backend

```python
from gamelan import JsonlEventLog

# Create new
log = JsonlEventLog.create("events.jsonl")
log.append(("Input", {"text": "hello"}))

# Reopen existing
log = JsonlEventLog.open("events.jsonl")
events = log.load()
```

### With AgentSession

```python
session = AgentSession(
    sources={"llm": llm},
    store_path="./sessions/my-agent",
)
```

Events are persisted automatically. The session can be resumed after a restart.

## Snapshots

For long sessions, replaying the full log is slow. Snapshots capture the kernel state at a point in time:

```python
# Take a snapshot
snap = session.snapshot()

# Save to disk
await session.save_snapshot(session_id="my-session")
```

Resume from snapshot + remaining events is faster than full replay.

### Snapshot store

```python
from gamelan import JsonlSnapshotStore

store = JsonlSnapshotStore("./snapshots")
await store.save("session-1", snap)
snap = await store.load("session-1")
```

## Session store

For multi-session management (listing, creating, deleting):

```python
from gamelan import JsonlSessionStore

store = JsonlSessionStore("./sessions")
log = await store.create("session-1")
sessions = await store.list()
await store.delete("session-1")
```

## Crash recovery

Because the kernel is deterministic:

1. Load the event log
2. Replay events through the kernel
3. The kernel reaches the exact same state
4. Continue from where the session left off

With snapshots, replay only the events after the snapshot.

```python
from gamelan import SessionRunner, SessionConfig, stdlib

# Full replay
log = JsonlEventLog.open("events.jsonl")
events = log.load()
runner = SessionRunner.replay(stdlib(), config, events, resolver)

# Resume from snapshot
snap = await snapshot_store.load("session-1")
remaining = log.load_after(snap.event_count)
runner = SessionRunner.resume_from_snapshot(
    stdlib(), config, snap, remaining, resolver
)
```

## In-memory backends (testing)

```python
from gamelan import MemoryLog, MemorySessionStore, MemorySnapshotStore

log = MemoryLog()
session_store = MemorySessionStore()
snapshot_store = MemorySnapshotStore()
```

## Using observe for step-level persistence

The `observe` callback in `run_turn` fires after each dispatch, not just at turn boundaries. This enables step-level persistence:

```python
async def persist_step(event):
    await step_log.append(event)

events = await run_turn(runner, router, [], tag, data, observe=persist_step)
```

See [run-turn.md](run-turn.md) for the observe callback.
