# turn_driver

`turn_driver` is the primary API for running a session turn. It's a bidirectional async generator: it yields `TurnStep` values, you send results back via `asend()`.

The host owns the dispatch loop. Retry, observability, error handling, and streaming are all your concerns — `turn_driver` just sequences the kernel's decisions.

## The step protocol

```python
from gamelan import turn_driver, DispatchReady, CheckNeeded, Complete, Approve

driver = turn_driver(runner, "LlmResponse", event_data)
step = await driver.__anext__()

while not isinstance(step, Complete):
    match step:
        case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
            conn = router.resolve(rt)
            result = await conn.source.dispatch(rt, rd)
            step = await driver.asend(result)
        case CheckNeeded(event_tag=tag, event_data=data, source_id=sid):
            verdict = await my_check(tag, data)
            step = await driver.asend(verdict)
```

Each step requires a response via `asend()` before the generator advances:

| Step | Send back | Type |
|------|----------|------|
| `DispatchReady` | `(result_tag, result_data)` | `tuple[str, dict]` |
| `DispatchReady` (failure) | `None` | `None` |
| `CheckNeeded` (outbound) | `Approve()`, `Reject(reason=...)`, or `Transform(data=...)` | `CheckVerdict` |
| `CheckNeeded` (inbound, `is_inbound=True`) | `InboundApprove()` or `InboundTransform(data=...)` | `InboundVerdict` |
| `Complete` | — | Generator finishes |

Sending the wrong type raises `TypeError`.

## TurnStep variants

```python
@dataclass
class DispatchReady(TurnStep):
    request_type: str    # e.g. "LlmRequest", "ToolRequest"
    source_id: str       # e.g. "llm", "tools"
    request_data: dict

@dataclass
class CheckNeeded(TurnStep):
    event_tag: str
    source_id: str
    event_data: dict
    is_inbound: bool = False  # True for inbound checks (no reject)

@dataclass
class Complete(TurnStep):
    events: list[RunnerEvent]  # all runner events from the turn
```

Checks are yielded before dispatches within each batch. This matches the kernel's gate/hold semantics.

## Building a custom driver

### Retry

```python
async def dispatch_with_retry(source, request_type, data, max_attempts=3):
    interval = 1.0
    for attempt in range(1, max_attempts + 1):
        try:
            return await source.dispatch(request_type, data)
        except Exception as e:
            if attempt == max_attempts:
                raise
            await asyncio.sleep(interval)
            interval = min(interval * 2, 30.0)
```

Use it in the step loop:

```python
case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
    conn = router.resolve(rt)
    try:
        result = await dispatch_with_retry(conn.source, rt, rd)
        step = await driver.asend(result)
    except Exception:
        step = await driver.asend(None)  # signal failure
```

### Observability

```python
import time, logging
log = logging.getLogger("gamelan")

case DispatchReady(request_type=rt, source_id=sid, request_data=rd):
    start = time.monotonic()
    result = await conn.source.dispatch(rt, rd)
    elapsed = time.monotonic() - start
    log.info(f"{rt} → {result[0]} ({elapsed:.2f}s via {sid})")
    step = await driver.asend(result)
```

### Step-level persistence

```python
case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
    result = await conn.source.dispatch(rt, rd)
    step = await driver.asend(result)
    # Persist after each step
    event_log.append(result)
```

### Tool schema enrichment

```python
from gamelan import discover_tools

tool_schemas = await discover_tools(router)

case DispatchReady(request_type="LlmRequest", request_data=rd, source_id=sid):
    rd = {**rd, "tools": tool_schemas}
    result = await conn.source.dispatch("LlmRequest", rd)
    step = await driver.asend(result)
```

## Dispatch failure

Send `None` to signal that a dispatch failed. The kernel injects an error event and clears pending:

```python
case DispatchReady(request_type=rt, request_data=rd, source_id=sid):
    try:
        result = await conn.source.dispatch(rt, rd)
        step = await driver.asend(result)
    except Exception:
        step = await driver.asend(None)
```

## Suspension

Async generators are inherently suspendable. You can pause mid-turn, do other work, and resume:

```python
driver = turn_driver(runner, "LlmResponse", event_data)
step = await driver.__anext__()

if isinstance(step, DispatchReady) and should_delegate(step):
    # Pause parent, run child
    child_result = await run_child_session(step)
    step = await driver.asend(child_result)

# Continue normally
while not isinstance(step, Complete):
    # ...
```

No explicit suspend/resume API needed — the generator holds its state naturally.

## Multi-turn

Create a new generator for each turn. The `SessionRunner` maintains state:

```python
for user_msg in messages:
    driver = turn_driver(runner, "LlmResponse", user_msg)
    step = await driver.__anext__()
    while not isinstance(step, Complete):
        # ... drive to completion
```

## Relationship to Rust TurnDriver

Same protocol, different idiom:

| | Rust | Python |
|---|---|---|
| Primitive | `TurnDriver` struct | Async generator |
| Yield step | `next_step() → TurnStep` | `yield DispatchReady(...)` |
| Send result | `provide_dispatch_result()` | `driver.asend(result)` |
| Signal failure | `provide_dispatch_error()` | `driver.asend(None)` |
| Suspend | `suspend() → TurnState` | Generator is already suspendable |
| Resume | `TurnDriver::resume(state)` | Just keep iterating |

Python gets suspension for free. Rust needs explicit state capture.
