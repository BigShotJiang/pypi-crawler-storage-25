# run_turn (Convenience Wrapper)

`run_turn` is a convenience wrapper over [turn_driver](turn-driver.md). It drives the generator with three optional callbacks: dispatch, check, and observe.

For full control, use `turn_driver` directly. Use `run_turn` when callbacks are sufficient — typically for simple agents or tests.

`AgentSession.turn()` calls `run_turn` with default callbacks.

## Signature

```python
async def run_turn(
    runner: SessionRunner,
    router: Router,
    outbound_checks: list[OutboundCheckEntry],
    event_tag: str,
    event_data: dict,
    *,
    dispatch: Callable[[str, dict], Awaitable[tuple[str, dict]]] | None = None,
    check: Callable[[str, dict], Awaitable[CheckVerdict]] | None = None,
    observe: Callable[[TurnEvent], Awaitable[None]] | None = None,
) -> list[RunnerEvent]
```

All three callbacks are optional. Defaults:

- **dispatch** — routes through the `Router`, enriches `LlmRequest` with discovered tool schemas
- **check** — looks up `outbound_checks` by request type, auto-approves if not found
- **observe** — no-op

## The dispatch callback

```python
async def dispatch(request_type: str, request_data: dict) -> tuple[str, dict]:
    """Execute a request and return the result event."""
```

Called for every `DispatchReady` step. Returns `(result_tag, result_data)`. Raising an exception signals dispatch failure — the error is injected into the kernel and the turn continues.

### Intercepting dispatches

```python
from gamelan import run_turn

async def my_dispatch(request_type, request_data):
    if request_type == "ToolRequest" and request_data.get("name") == "delegate":
        return ("ToolResult", {"content": [{"content_type": "text", "text": result}], ...})

    conn = router.resolve(request_type)
    source_data = dict(request_data)
    if request_type == "LlmRequest":
        source_data["tools"] = tool_schemas
    return await conn.source.dispatch(request_type, source_data)

events = await run_turn(runner, router, [], tag, data, dispatch=my_dispatch)
```

## The check callback

```python
async def check(event_tag: str, event_data: dict) -> CheckVerdict:
    """Decide whether to approve, reject, or transform a request."""
```

Called for every `CheckNeeded` step. Return `Approve()`, `Reject(reason="...")`, or `Transform(data={...})`.

```python
from gamelan import Approve, Reject

async def my_check(event_tag, event_data):
    if event_tag == "ToolRequest":
        tool_name = event_data.get("name", "")
        if tool_name in DANGEROUS_TOOLS:
            return Reject(reason=f"tool {tool_name} requires manual approval")
    return Approve()

events = await run_turn(runner, router, [], tag, data, check=my_check)
```

## The observe callback

```python
async def observe(event: TurnEvent) -> None:
    """Called after each step completes."""
```

`TurnEvent` is one of:

- `Dispatched(request_type, result_tag)` — a dispatch completed
- `DispatchFailed(request_type)` — a dispatch failed
- `CheckResolved(event_tag, verdict)` — a check returned a verdict

### Persistence

```python
async def persist(event):
    await store.append(event)
    if isinstance(event, Dispatched):
        await store.flush()

events = await run_turn(runner, router, [], tag, data, observe=persist)
```

### Logging

```python
import logging
log = logging.getLogger("gamelan")

async def log_steps(event):
    if isinstance(event, Dispatched):
        log.info(f"dispatched {event.request_type} → {event.result_tag}")
    elif isinstance(event, DispatchFailed):
        log.warning(f"dispatch failed: {event.request_type}")

events = await run_turn(runner, router, [], tag, data, observe=log_steps)
```

## How it wraps turn_driver

Internally, `run_turn` drives `turn_driver` with the callbacks:

```python
driver = turn_driver(runner, event_tag, event_data)
step = await driver.__anext__()

while not isinstance(step, Complete):
    if isinstance(step, CheckNeeded):
        verdict = await do_check(step.event_tag, step.event_data)
        await do_observe(CheckResolved(step.event_tag, verdict))
        step = await driver.asend(verdict)
    elif isinstance(step, DispatchReady):
        try:
            result = await do_dispatch(step.request_type, step.request_data)
            await do_observe(Dispatched(step.request_type, result[0]))
            step = await driver.asend(result)
        except Exception:
            await do_observe(DispatchFailed(step.request_type))
            step = await driver.asend(None)
```

## When to use turn_driver instead

Use `turn_driver` directly when you need:

- **Retry** — different strategies per source
- **Suspension** — pause mid-turn for delegation or external input
- **Step interception** — inspect or modify requests before dispatch
- **Custom error handling** — circuit breakers, degradation
- **Fine-grained observability** — metrics per step, tracing spans

`run_turn` is sufficient for simple agents and tests.
