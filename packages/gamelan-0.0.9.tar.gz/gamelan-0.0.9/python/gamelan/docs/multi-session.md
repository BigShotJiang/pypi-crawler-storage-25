# Multi-Agent and Delegation

`NetworkClient` coordinates multiple agent sessions. Each agent has its own definition (declarative config) and source map (runtime bindings). The client validates the configuration at construction and drives turns through the coordinator fold.

## Basic setup

```python
from gamelan import NetworkClient, AgentDef, stdlib
from gamelan._core import SessionConfig
from gamelan.providers.anthropic import AnthropicSource

claude = AnthropicSource(model="claude-sonnet-4-20250514")

parent_def = AgentDef(stdlib(), config, resolver)
child_def = AgentDef(stdlib(), config, resolver)

client = NetworkClient(
    agents={
        "parent": (parent_def, {"llm": claude, "tools": deleg_source}),
        "child": (child_def, {"llm": claude, "tools": search_source}),
    },
    delegation_routes=[("parent", "child")],
    entry_point="parent",
)

async for event in client.send_message("Research Rust ownership"):
    print(event)
```

## Per-agent sources

Sources are per-agent — each agent carries its own source map:

```python
client = NetworkClient(
    agents={
        "parent": (parent_def, {"llm": claude, "tools": delegation_tools}),
        "researcher": (child_def, {"llm": gpt, "tools": search_tools}),
        "writer": (child_def, {"llm": claude, "tools": file_tools}),
    },
    delegation_routes=[("parent", "researcher"), ("parent", "writer")],
    entry_point="parent",
)
```

If two agents share the same source, pass the same object to both. The framework doesn't manage sharing.

## Validation

Config is validated at construction per `client.qnt`:

- **Source completeness**: every `source_id` referenced by connections must be in the source map
- **Check source binding**: `has_check=True` requires the `check_source` to be bound
- **Route validity**: delegation/handoff routes reference registered agents
- **No self-routes**: agents can't delegate to themselves
- **Entry point**: must be a registered agent

Invalid config raises `ClientConfigError`.

## How it works

```
NetworkClient.send_message(text)
  → NetworkRunner.run_turn("UserMessage", data)
    → Coordinator fold: starts active agent
    → AgentRunner.run_turn(executor, tag, data)
      → turnDriver: fold → dispatch → fold → ...
    → AgentDone fold: may trigger delegation/handoff
    → Drive next agent if needed
  ← SessionEvent stream
```

Each agent's turn uses a `SourceExecutor` built from its source map. The executor is internal — users don't create it.

## Delegation with SyncDelegationSource

For parent-delegates-to-child patterns, wire `SyncDelegationSource` as the parent's tool source:

```python
from gamelan import SyncDelegationSource, DelegationAwaiter

deleg_source = SyncDelegationSource().with_child("researcher")
```

When the parent's LLM calls the "researcher" tool, the delegation source drives the child session and returns the result as a `ToolResult`.

## State queries

```python
client.active_agent           # Current active agent
client.delegation_graph       # Active delegation edges
client.delegated_agents()     # Children currently delegated to
client.has_runner("agent")    # Whether agent runner is live
```

## Architecture

The coordinator (from the Rust kernel via PyO3) manages session lifecycle:

- **Session states**: Idle → Processing → WaitingDelegate → Done
- **Deadlock prevention**: cycle detection in delegation graph
- **Clean transitions**: all state changes go through `fold_event`

The `NetworkRunner` drives the coordinator fold. The `NetworkClient` wraps it with a user-facing API. Neither is in the spec — they're SDK constructs that implement the spec's behavioral contracts (`runner.qnt`, `network_turn.qnt`, `manager.qnt`, `client.qnt`).
