"""AgentSession — high-level convenience for running agent sessions.

Bundles runner + router + persistence + streaming into one object.
The "just works" entry point for building agents.

    # From a session definition
    session = AgentSession.from_def(def_json, sources={"llm": llm, "tools": tools})
    events = await session.turn("Hello!")

    # From explicit components
    session = AgentSession(
        sources={"llm": llm, "tools": tools},
        checks={"approval": approval_check},
        store_path="./sessions/my-agent",
    )
    events = await session.turn("What can you do?")
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Callable

from gamelan._core import (
    SessionConfig,
    Snapshot,
    load_session_def,
    stdlib,
)
from gamelan.check import OutboundCheckEntry
from gamelan.jsonl import JsonlEventLog, JsonlSnapshotStore
from gamelan.persistence import SessionInfo
from gamelan.router import Connection, Router
from gamelan.run import TurnHook, run_turn
from gamelan.runner import RunnerEvent, SessionRunner
from gamelan.source import Source
from gamelan.streaming import StreamSender


class AgentSession:
    """High-level agent session. Wraps runner + router + persistence.

    Handles the ceremony of topology derivation, config creation,
    event logging, and snapshot management.
    """

    def __init__(
        self,
        sources: dict[str, Source],
        *,
        instructions: str | None = None,
        initial_context: list[dict] | None = None,
        transducer_names: list[str] | None = None,
        checks: dict[str, OutboundCheckEntry] | None = None,
        store_path: str | Path | None = None,
        stream: StreamSender | None = None,
        hooks: list[TurnHook] | None = None,
    ):
        """Create an agent session.

        Args:
            sources: Named sources (e.g. {"llm": AnthropicSource(...), "tools": ToolSource()}).
            instructions: System instructions for the agent. Sugar for initial_context
                with a single system message.
            initial_context: List of messages to initialize the session with (system
                instructions, few-shot examples, restored context). Processed as a
                SessionInit event — persisted in the event log, replayed on resume.
            transducer_names: Stdlib transducer names. Defaults to full stdlib.
            checks: Named outbound checks (e.g. {"approval": OutboundCheckEntry(...)}).
            store_path: Path for JSONL persistence. None = ephemeral (no disk).
            stream: Optional StreamSender for real-time deltas.
            hooks: Optional lifecycle hooks (OTel, logging, etc.). Passed to turn_driver.
        """
        # Build connections from named sources
        connections = [Connection(id=name, source=src) for name, src in sources.items()]

        # Build check entries
        outbound_checks = list((checks or {}).values())

        # Router derives topology from source interfaces
        router = Router(connections)
        topology_json = router.topology(outbound_checks)

        # Config from derived topology
        config = SessionConfig(topology_json)

        # Load transducers
        all_tds = {td.name: td for td in stdlib()}
        if transducer_names:
            tds = [all_tds[name] for name in transducer_names if name in all_tds]
        else:
            tds = list(all_tds.values())

        # Create runner
        self._runner = SessionRunner(tds, config)
        self._router = router
        self._outbound_checks = outbound_checks
        self._stream = stream
        self._hooks = hooks or []

        # Boot with initial context (SessionInit event)
        if instructions and not initial_context:
            initial_context = [
                {"role": "system", "parts": [{"kind": "text", "text": instructions}]}
            ]
        if initial_context:
            self._runner.boot("SessionInit", {"context": initial_context})

        # Persistence (optional)
        self._event_log: JsonlEventLog | None = None
        self._snapshot_store: JsonlSnapshotStore | None = None
        if store_path:
            store_path = Path(store_path)
            store_path.mkdir(parents=True, exist_ok=True)
            events_path = store_path / "events.jsonl"
            if events_path.exists():
                self._event_log = JsonlEventLog.open(events_path)
            else:
                self._event_log = JsonlEventLog.create(events_path)
            self._snapshot_store = JsonlSnapshotStore(store_path.parent)

    @classmethod
    def from_def(
        cls,
        session_def_json: str,
        sources: dict[str, Source],
        *,
        checks: dict[str, OutboundCheckEntry] | None = None,
        store_path: str | Path | None = None,
        stream: StreamSender | None = None,
        hooks: list[TurnHook] | None = None,
    ) -> AgentSession:
        """Create from a SessionDef JSON string.

        The definition specifies transducers and connections. Sources
        must be provided for each source_id in the definition.

            def_json = '''
            {
                "name": "my_agent",
                "transducers": ["messages", "blocks", "usage", "call_llm", "execute_tool"],
                "connections": [
                    {"source_id": "llm", "pairs": [{"request_type": "LlmRequest", "result_type": "LlmResponse"}], "checks": []},
                    {"source_id": "tools", "pairs": [{"request_type": "ToolRequest", "result_type": "ToolResult"}], "checks": []}
                ],
                "config": {}
            }
            '''
            session = AgentSession.from_def(def_json, sources={"llm": llm, "tools": tools})
        """
        result = load_session_def(session_def_json)
        return cls(
            sources=sources,
            transducer_names=result["transducer_names"],
            checks=checks,
            store_path=store_path,
            stream=stream,
            hooks=hooks,
        )

    async def turn(self, user_message: str) -> list[RunnerEvent]:
        """Run one conversational turn.

        Injects a user message, runs the session to completion,
        persists events, and returns runner events for observation.
        """
        tag, data = _make_user_event(user_message)
        return await self.process(tag, data)

    async def process(self, event_tag: str, event_data: dict) -> list[RunnerEvent]:
        """Process a raw event through the session.

        Lower-level than turn() — use when injecting non-user events
        (e.g. system events, restored context).
        """
        # Log the inbound event
        if self._event_log is not None:
            self._event_log.append((event_tag, event_data))

        events = await run_turn(
            self._runner,
            self._router,
            self._outbound_checks,
            event_tag,
            event_data,
            hooks=self._hooks,
        )

        # Log all result events that the kernel processed
        if self._event_log is not None:
            for tag in self._runner.event_log[-(len(events)):]:
                # Events are already logged by the runner; we persist the
                # kernel-processed events (results fed back from sources)
                pass

        return events

    def snapshot(self) -> Snapshot:
        """Take a snapshot of the current session state."""
        return self._runner.snapshot()

    async def save_snapshot(self, session_id: str = "default") -> None:
        """Save a snapshot to the snapshot store (if persistence is configured)."""
        if self._snapshot_store is None:
            raise RuntimeError("no persistence configured (set store_path)")
        snap = self.snapshot()
        await self._snapshot_store.save(session_id, snap)

    @property
    def runner(self) -> SessionRunner:
        """Access the underlying SessionRunner."""
        return self._runner

    @property
    def state(self) -> dict:
        """Get the current kernel state (all transducer slots)."""
        return self._runner.get_state()

    @property
    def messages(self) -> list:
        """Get the conversation messages from kernel state."""
        return self.state.get("messages", [])

    @property
    def is_idle(self) -> bool:
        return self._runner.is_idle

    @property
    def events_processed(self) -> int:
        return self._runner.events_processed


def _make_user_event(text: str) -> tuple[str, dict]:
    """Build a user message event."""
    return ("LlmResponse", {
        "role": "user",
        "parts": [{"kind": "text", "text": text}],
        "input_tokens": 0,
        "output_tokens": 0,
    })
