"""Check protocol — async event verification.

The kernel handles hold/release mechanics (CheckThenDispatch, InboundCheckDef).
This module provides the async verification logic.

Matches session_loop.qnt CheckVerdict and the Rust Check trait.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


# ════════════════════════════════════════════════════════════════
# CheckVerdict — discriminated union via dataclass variants
# ════════════════════════════════════════════════════════════════


class CheckVerdict:
    """Base class for check verdicts. Use Approve, Reject, or Transform."""

    pass


@dataclass(frozen=True)
class Approve(CheckVerdict):
    """Approved — dispatch the original request / accept the event."""

    pass


@dataclass(frozen=True)
class Reject(CheckVerdict):
    """Rejected — drop the request / reject the event."""

    reason: str = ""


@dataclass(frozen=True)
class Transform(CheckVerdict):
    """Transformed — dispatch a modified version."""

    data: dict = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.data is None:
            object.__setattr__(self, "data", {})


# ════════════════════════════════════════════════════════════════
# InboundVerdict — Approve or Transform only (no Reject)
# Spec (executor.qnt): rejecting an inbound result orphans the
# pending request, causing a liveness violation.
# ════════════════════════════════════════════════════════════════


class InboundVerdict:
    """Base class for inbound check verdicts. Approve or InboundTransform only."""

    pass


@dataclass(frozen=True)
class InboundApprove(InboundVerdict):
    """Approved — event proceeds to fold."""

    pass


@dataclass(frozen=True)
class InboundTransform(InboundVerdict):
    """Transformed — event proceeds with modified data."""

    data: dict = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.data is None:
            object.__setattr__(self, "data", {})


# ════════════════════════════════════════════════════════════════
# Check protocol
# ════════════════════════════════════════════════════════════════


@runtime_checkable
class Check(Protocol):
    """Async event verification."""

    async def check(self, event_tag: str, event_data: dict) -> CheckVerdict:
        ...


# ════════════════════════════════════════════════════════════════
# Built-in check implementations
# ════════════════════════════════════════════════════════════════


class AutoApprove:
    """Auto-approve everything. For full-auto mode."""

    async def check(self, event_tag: str, event_data: dict) -> CheckVerdict:
        return Approve()


class AlwaysReject:
    """Always reject. For suggest mode / read-only agents."""

    async def check(self, event_tag: str, event_data: dict) -> CheckVerdict:
        return Reject(reason="denied by policy")


# ════════════════════════════════════════════════════════════════
# Check entries — bind checks to connection boundaries
# ════════════════════════════════════════════════════════════════


@dataclass
class OutboundCheckEntry:
    """Outbound check: verify a request before dispatch."""

    request_type: str
    source_id: str
    check: Check


@dataclass
class InboundCheckEntry:
    """Inbound check: verify a result event before the fold sees it."""

    result_type: str
    source_id: str
    check: Check
