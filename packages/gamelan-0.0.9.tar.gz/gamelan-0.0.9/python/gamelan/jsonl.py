"""JsonlStore — file-per-session JSONL persistence.

Human-readable, append-only, portable. One directory per session,
one JSON object per line in the event log.

Layout:
    sessions/
    +-- index.jsonl              # session metadata, one entry per session
    +-- abc123/
    |   +-- events.jsonl         # event log, one event per line
    |   +-- snapshot.json        # most recent snapshot (optional)
    +-- ...
"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from gamelan._core import Snapshot
from gamelan.persistence import SessionInfo


# ════════════════════════════════════════════════════════════════
# JsonlEventLog — per-session event persistence
# ════════════════════════════════════════════════════════════════


class JsonlEventLog:
    """JSONL event log for one session. Append-only."""

    def __init__(self, path: Path, *, _len: int = 0):
        self._path = Path(path)
        self._len = _len

    @classmethod
    def create(cls, path: Path) -> JsonlEventLog:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
        return cls(path, _len=0)

    @classmethod
    def open(cls, path: Path) -> JsonlEventLog:
        path = Path(path)
        count = 0
        if path.exists():
            with open(path) as f:
                count = sum(1 for line in f if line.strip())
        return cls(path, _len=count)

    def append(self, event: tuple[str, dict]) -> None:
        tag, data = event
        line = json.dumps({"seq": self._len, "tag": tag, "data": data})
        with open(self._path, "a") as f:
            f.write(line + "\n")
        self._len += 1

    def load(self) -> list[tuple[str, dict]]:
        if not self._path.exists():
            return []
        events = []
        with open(self._path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                entry = json.loads(line)
                events.append((entry["tag"], entry["data"]))
        return events

    def load_after(self, index: int) -> list[tuple[str, dict]]:
        all_events = self.load()
        if index > len(all_events):
            return []
        return all_events[index:]

    def __len__(self) -> int:
        return self._len


# ════════════════════════════════════════════════════════════════
# JsonlSessionStore — multi-session CRUD
# ════════════════════════════════════════════════════════════════


class JsonlSessionStore:
    """File-per-session store. Each session gets a directory under root."""

    def __init__(self, root: str | Path):
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    def _session_dir(self, id: str) -> Path:
        return self._root / id

    def _events_path(self, id: str) -> Path:
        return self._session_dir(id) / "events.jsonl"

    def _index_path(self) -> Path:
        return self._root / "index.jsonl"

    def _load_index(self) -> list[SessionInfo]:
        path = self._index_path()
        if not path.exists():
            return []
        infos = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                infos.append(json.loads(line))
        return infos

    def _write_index(self, infos: list[SessionInfo]) -> None:
        path = self._index_path()
        with open(path, "w") as f:
            for info in infos:
                f.write(json.dumps(info) + "\n")

    async def list(self) -> list[SessionInfo]:
        return self._load_index()

    async def create(self, id: str) -> JsonlEventLog:
        infos = self._load_index()
        if any(i["id"] == id for i in infos):
            raise ValueError(f"session already exists: {id}")

        session_dir = self._session_dir(id)
        session_dir.mkdir(parents=True, exist_ok=True)

        log = JsonlEventLog.create(self._events_path(id))

        infos.append(SessionInfo(
            id=id, created_at=0, updated_at=0, event_count=0, title=None, metadata={},
        ))
        self._write_index(infos)

        return log

    async def load(self, id: str) -> JsonlEventLog:
        path = self._events_path(id)
        if not path.exists():
            raise KeyError(f"session not found: {id}")
        return JsonlEventLog.open(path)

    async def delete(self, id: str) -> None:
        session_dir = self._session_dir(id)
        if not session_dir.exists():
            raise KeyError(f"session not found: {id}")
        shutil.rmtree(session_dir)

        infos = [i for i in self._load_index() if i["id"] != id]
        self._write_index(infos)

    async def update_info(self, id: str, info: SessionInfo) -> None:
        infos = self._load_index()
        for i, existing in enumerate(infos):
            if existing["id"] == id:
                infos[i] = info
                self._write_index(infos)
                return
        raise KeyError(f"session not found: {id}")


# ════════════════════════════════════════════════════════════════
# JsonlSnapshotStore
# ════════════════════════════════════════════════════════════════


class JsonlSnapshotStore:
    """Snapshot store backed by JSON files. One snapshot.json per session."""

    def __init__(self, root: str | Path):
        self._root = Path(root)

    def _snapshot_path(self, session_id: str) -> Path:
        return self._root / session_id / "snapshot.json"

    async def save(self, session_id: str, snapshot: Snapshot) -> None:
        path = self._snapshot_path(session_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(snapshot.to_json())

    async def load(self, session_id: str) -> Snapshot | None:
        path = self._snapshot_path(session_id)
        if not path.exists():
            return None
        return Snapshot.from_json(path.read_text())
