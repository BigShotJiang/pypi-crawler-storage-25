"""OpenTelemetry instrumentation for gamelan — GenAI semantic conventions.

Provides ``OTelHook``, a ``TurnHook`` implementation that emits OTel spans
for agent turns, LLM calls, and tool executions following GenAI semantic
conventions compatible with Cat Cafe.

Requires ``gamelan[otel]`` extra::

    pip install gamelan[otel]

Usage::

    from gamelan.otel import configure_tracing

    hook = configure_tracing(service_name="my-agent")

    # With turn_driver (primary API)
    driver = turn_driver(runner, "LlmResponse", event_data, hooks=[hook])

    # With run_turn (convenience)
    events = await run_turn(runner, router, [], "LlmResponse", data, hooks=[hook])

    # With AgentSession
    session = AgentSession(sources={"llm": llm}, hooks=[hook])
"""

from __future__ import annotations

import json
import os
from typing import Any

from gamelan.check import CheckVerdict
from gamelan.runner import RunnerEvent


# ════════════════════════════════════════════════════════════════
# GenAI semantic convention attribute constants
# ════════════════════════════════════════════════════════════════

_OPERATION_NAME = "gen_ai.operation.name"
_PROVIDER_NAME = "gen_ai.provider.name"
_SYSTEM = "gen_ai.system"
_REQUEST_MODEL = "gen_ai.request.model"
_RESPONSE_MODEL = "gen_ai.response.model"
_USAGE_INPUT = "gen_ai.usage.input_tokens"
_USAGE_OUTPUT = "gen_ai.usage.output_tokens"
_AGENT_NAME = "gen_ai.agent.name"
_TOOL_NAME = "gen_ai.tool.name"
_TOOL_CALL_ARGUMENTS = "gen_ai.tool.call.arguments"
_TOOL_CALL_RESULT = "gen_ai.tool.call.result"
_TOOL_DEFINITIONS = "gen_ai.tool.definitions"
_RESPONSE_ID = "gen_ai.response.id"
_ERROR_TYPE = "error.type"
_INPUT_MESSAGES = "gen_ai.input.messages"
_OUTPUT_MESSAGES = "gen_ai.output.messages"

# OpenLit-style (read by Cat Cafe normalizer)
_TOKEN_COUNT_PROMPT = "llm.token_count.prompt"
_TOKEN_COUNT_COMPLETION = "llm.token_count.completion"
_TOKEN_COUNT_TOTAL = "llm.token_count.total"
_TOKEN_COUNT_CACHE_READ = "llm.token_count.prompt_details.cache_read"

# OpenInference compat (read by Cat Cafe)
_INPUT_VALUE = "input.value"
_OUTPUT_VALUE = "output.value"
_INPUT_MIME_TYPE = "input.mime_type"


# ════════════════════════════════════════════════════════════════
# OTelHook — TurnHook implementation
# ════════════════════════════════════════════════════════════════


class OTelHook:
    """TurnHook that emits OTel spans with GenAI semantic conventions.

    Creates three span types:
    - ``invoke_agent`` (INTERNAL) — wraps the entire turn
    - ``chat`` (CLIENT) — each LlmRequest dispatch
    - ``execute_tool`` (INTERNAL) — each ToolRequest dispatch

    Token usage, tool I/O, and message content are captured per
    Cat Cafe conventions (GenAI semconv + OpenLit + OpenInference compat).

    Args:
        tracer: An OpenTelemetry Tracer instance.
        agent_name: Name for the agent span.
        capture_content: Capture message and tool content on spans.
    """

    def __init__(
        self,
        tracer: Any,
        agent_name: str = "gamelan-agent",
        capture_content: bool = False,
    ) -> None:
        self._tracer = tracer
        self._agent_name = agent_name
        self._capture_content = capture_content

    def on_turn_start(self, event_tag: str, event_data: dict) -> Any:
        from opentelemetry import trace
        from opentelemetry.trace import SpanKind

        agent_span = self._tracer.start_span(
            name=self._agent_name,
            kind=SpanKind.INTERNAL,
        )
        agent_span.set_attribute(_OPERATION_NAME, "invoke_agent")
        agent_span.set_attribute(_AGENT_NAME, self._agent_name)
        agent_ctx = trace.set_span_in_context(agent_span)
        return (agent_span, agent_ctx)

    def on_turn_end(self, events: list[RunnerEvent], error: Exception | None, ctx: Any) -> None:
        from opentelemetry.trace import StatusCode

        agent_span, _ = ctx
        if error:
            agent_span.set_status(StatusCode.ERROR, str(error))
            agent_span.set_attribute(_ERROR_TYPE, str(error))
        else:
            agent_span.set_status(StatusCode.OK)
        agent_span.end()

    def on_dispatch_start(self, request_type: str, source_id: str, request_data: dict, turn_ctx: Any) -> Any:
        from opentelemetry.trace import SpanKind

        _, agent_ctx = turn_ctx
        is_llm = request_type == "LlmRequest"
        is_tool = request_type == "ToolRequest"

        if is_llm:
            span_name = "response"
            span_kind = SpanKind.CLIENT
        elif is_tool:
            span_name = request_data.get("name", "unknown")
            span_kind = SpanKind.INTERNAL
        else:
            span_name = request_type
            span_kind = SpanKind.INTERNAL

        span = self._tracer.start_span(
            name=span_name,
            kind=span_kind,
            context=agent_ctx,
        )

        # Provider inference
        _set_provider(span, request_data, source_id)

        if is_llm:
            span.set_attribute(_OPERATION_NAME, "chat")
            model = request_data.get("model", "")
            if model:
                span.set_attribute(_REQUEST_MODEL, model)
            if self._capture_content:
                context = request_data.get("context")
                if context:
                    converted = _convert_context(context)
                    span.set_attribute(_INPUT_MESSAGES, json.dumps(converted))
                    _emit_input_events(span, context)
        elif is_tool:
            span.set_attribute(_OPERATION_NAME, "execute_tool")
            span.set_attribute(_TOOL_NAME, request_data.get("name", ""))
            if self._capture_content:
                args = request_data.get("arguments", "")
                args_str = args if isinstance(args, str) else json.dumps(args)
                span.set_attribute(_TOOL_CALL_ARGUMENTS, args_str)
                span.set_attribute(_INPUT_VALUE, args_str)
                span.set_attribute(_INPUT_MIME_TYPE, "application/json")

        return span

    def on_dispatch_end(self, request_type: str, result: tuple[str, dict] | None, error: bool, ctx: Any) -> None:
        from opentelemetry.trace import StatusCode

        span = ctx
        if error or result is None:
            span.set_status(StatusCode.ERROR, "dispatch failed")
            span.set_attribute(_ERROR_TYPE, "dispatch_failed")
        else:
            result_tag, result_data = result
            if request_type == "LlmRequest":
                # Set provider from response model if not already set
                _set_provider(span, result_data)
                _set_llm_end_attrs(span, result_data, self._capture_content)
            elif request_type == "ToolRequest" and self._capture_content:
                content = result_data.get("content", "")
                if isinstance(content, list):
                    text_parts = [c.get("text", "") for c in content if isinstance(c, dict)]
                    content = "\n".join(text_parts)
                span.set_attribute(_TOOL_CALL_RESULT, str(content))
                span.set_attribute(_OUTPUT_VALUE, str(content))
            span.set_status(StatusCode.OK)
        span.end()

    def on_check_start(self, event_tag: str, source_id: str, event_data: dict, turn_ctx: Any) -> Any:
        return None  # No span for checks

    def on_check_end(self, event_tag: str, verdict: CheckVerdict, ctx: Any) -> None:
        pass  # No span for checks


# ════════════════════════════════════════════════════════════════
# configure_tracing — factory
# ════════════════════════════════════════════════════════════════


_DEFAULT_ENDPOINT = "http://localhost:4318"


def configure_tracing(
    service_name: str = "gamelan",
    endpoint: str | None = None,
    capture_content: bool = True,
    agent_name: str = "gamelan-agent",
) -> OTelHook:
    """Create an OTelHook with OTLP HTTP export.

    Sets up a TracerProvider with BatchSpanProcessor exporting via
    OTLP/HTTP to a collector (e.g. Cat Cafe).

    Args:
        service_name: The service.name resource attribute.
        endpoint: OTLP collector base URL. Defaults to
            OTEL_EXPORTER_OTLP_ENDPOINT or http://localhost:4318.
        capture_content: Capture message and tool content on spans.
        agent_name: Name for the agent span (gen_ai.agent.name).

    Returns:
        OTelHook to pass as a hook to turn_driver / run_turn / AgentSession.
    """
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    resolved_name = os.getenv("OTEL_SERVICE_NAME", service_name)
    resource = Resource.create({"service.name": resolved_name})

    provider = TracerProvider(resource=resource)

    resolved_endpoint = endpoint or os.getenv(
        "OTEL_EXPORTER_OTLP_ENDPOINT", _DEFAULT_ENDPOINT
    )
    traces_endpoint = resolved_endpoint.rstrip("/")
    if not traces_endpoint.endswith("/v1/traces"):
        traces_endpoint = f"{traces_endpoint}/v1/traces"

    exporter = OTLPSpanExporter(endpoint=traces_endpoint)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)

    tracer = provider.get_tracer("gamelan")
    return OTelHook(
        tracer=tracer,
        agent_name=agent_name,
        capture_content=capture_content,
    )


# ════════════════════════════════════════════════════════════════
# Internal helpers
# ════════════════════════════════════════════════════════════════


# GenAI semantic convention span event names
_EVENT_USER_MESSAGE = "gen_ai.user.message"
_EVENT_ASSISTANT_MESSAGE = "gen_ai.assistant.message"
_EVENT_SYSTEM_MESSAGE = "gen_ai.system.message"
_EVENT_TOOL_MESSAGE = "gen_ai.tool.message"

_ROLE_TO_EVENT = {
    "user": _EVENT_USER_MESSAGE,
    "assistant": _EVENT_ASSISTANT_MESSAGE,
    "system": _EVENT_SYSTEM_MESSAGE,
    "tool": _EVENT_TOOL_MESSAGE,
}


def _emit_input_events(span: Any, context: list[dict]) -> None:
    """Emit GenAI span events for each input message."""
    for msg in context:
        role = msg.get("role", "")
        event_name = _ROLE_TO_EVENT.get(role)
        if not event_name:
            continue

        attrs: dict[str, Any] = {}

        # Extract content from parts or content field
        if role == "tool":
            content_items = msg.get("content", [])
            if isinstance(content_items, list):
                text = "\n".join(
                    c.get("text", "") for c in content_items if isinstance(c, dict)
                )
                if text:
                    attrs["content"] = text
            if msg.get("tool_call_id"):
                attrs["gen_ai.tool.call.id"] = msg["tool_call_id"]
        else:
            parts = msg.get("parts", [])
            text_parts = [
                p.get("text", "") for p in parts if p.get("kind") == "text"
            ]
            if text_parts:
                attrs["content"] = "\n".join(text_parts)

        span.add_event(event_name, attributes=attrs)


def _emit_output_event(span: Any, result_data: dict) -> None:
    """Emit a GenAI span event for the assistant output message."""
    parts = result_data.get("parts", [])
    if not parts:
        return

    attrs: dict[str, Any] = {}
    text_parts = [p.get("text", "") for p in parts if p.get("kind") == "text"]
    if text_parts:
        attrs["content"] = "\n".join(text_parts)

    tool_calls = []
    for p in parts:
        if isinstance(p, dict) and p.get("kind") == "tool_call":
            tc: dict[str, Any] = {"name": p.get("name", "")}
            if p.get("arguments"):
                tc["arguments"] = p["arguments"]
            if p.get("id"):
                tc["id"] = p["id"]
            tool_calls.append(tc)
    if tool_calls:
        attrs["gen_ai.tool_calls"] = json.dumps(tool_calls)

    span.add_event(_EVENT_ASSISTANT_MESSAGE, attributes=attrs)


def _convert_context(context: list[dict]) -> list[dict]:
    """Convert gamelan context messages to Cat Cafe format.

    Gamelan format:  {"role": "user", "parts": [{"kind": "text", "text": "..."}]}
    Cat Cafe format: {"role": "user", "content": "..."}

    Tool messages stored by the kernel use 'content'/'content_type' instead
    of 'parts'/'kind', so we handle both.
    """
    return [_convert_context_message(msg) for msg in context]


def _convert_context_message(msg: dict) -> dict:
    """Convert a single context message to Cat Cafe format."""
    role = msg.get("role", "")

    # Tool result messages from the kernel (content/content_type format)
    if role == "tool":
        content_items = msg.get("content", [])
        text_parts = []
        for item in content_items:
            if isinstance(item, dict):
                text_parts.append(item.get("text", ""))
        out: dict = {"role": role, "content": "\n".join(text_parts)}
        if msg.get("tool_call_id"):
            out["tool_call_id"] = msg["tool_call_id"]
        return out

    # Standard messages with parts/kind format
    parts = msg.get("parts", [])
    return _convert_message(role, parts)


def _convert_message(role: str, parts: list[dict]) -> dict:
    """Convert a gamelan parts list to a Cat Cafe message dict."""
    text_parts = []
    tool_calls = []
    for part in parts:
        kind = part.get("kind", "")
        if kind == "text":
            text_parts.append(part.get("text", ""))
        elif kind == "tool_call":
            tc: dict = {"name": part.get("name", "")}
            if part.get("arguments"):
                tc["arguments"] = part["arguments"]
            if part.get("id"):
                tc["id"] = part["id"]
            tool_calls.append(tc)

    msg: dict = {"role": role}
    if text_parts:
        msg["content"] = "\n".join(text_parts)
    if tool_calls:
        msg["tool_calls"] = tool_calls
    return msg


def _set_provider(span: Any, request_data: dict, source_id: str = "") -> None:
    """Infer and set gen_ai.system from request data or source_id."""
    model = request_data.get("model", "")
    if isinstance(model, str) and model.startswith("claude"):
        provider = "anthropic"
    elif isinstance(model, str) and (model.startswith("gpt") or model.startswith("o1") or model.startswith("o3")):
        provider = "openai"
    else:
        # Fall back to source_id hint (e.g. "anthropic", "openai")
        provider = source_id if source_id in ("anthropic", "openai") else "unknown"
    span.set_attribute(_PROVIDER_NAME, provider)
    span.set_attribute(_SYSTEM, provider)


def _set_llm_end_attrs(span: Any, result_data: dict, capture_content: bool) -> None:
    """Set LLM response attributes on span end."""
    input_tokens = result_data.get("input_tokens", 0)
    output_tokens = result_data.get("output_tokens", 0)
    if input_tokens or output_tokens:
        span.set_attribute(_USAGE_INPUT, input_tokens)
        span.set_attribute(_USAGE_OUTPUT, output_tokens)
        span.set_attribute(_TOKEN_COUNT_PROMPT, input_tokens)
        span.set_attribute(_TOKEN_COUNT_COMPLETION, output_tokens)
        span.set_attribute(_TOKEN_COUNT_TOTAL, input_tokens + output_tokens)
        cached = result_data.get("cached_tokens")
        if cached is not None:
            span.set_attribute(_TOKEN_COUNT_CACHE_READ, cached)

    model = result_data.get("model", "")
    if model:
        span.set_attribute(_RESPONSE_MODEL, model)

    response_id = result_data.get("id", "")
    if response_id:
        span.set_attribute(_RESPONSE_ID, response_id)

    if capture_content:
        parts = result_data.get("parts", [])
        if parts:
            output = [_convert_message(
                result_data.get("role", "assistant"), parts
            )]
            span.set_attribute(_OUTPUT_MESSAGES, json.dumps(output))
            _emit_output_event(span, result_data)

        # Flattened tool calls
        for completion_idx, part in enumerate(parts):
            if isinstance(part, dict) and part.get("kind") == "tool_call":
                prefix = f"gen_ai.completion.0.tool_calls.{completion_idx}"
                if part.get("name"):
                    span.set_attribute(f"{prefix}.name", part["name"])
                if part.get("arguments"):
                    span.set_attribute(f"{prefix}.arguments", part["arguments"])
                if part.get("id"):
                    span.set_attribute(f"{prefix}.id", part["id"])
