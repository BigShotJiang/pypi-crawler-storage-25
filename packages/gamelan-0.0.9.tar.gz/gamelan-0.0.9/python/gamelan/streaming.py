"""Streaming — real-time LLM output deltas for UI.

Deltas bypass the kernel entirely. The kernel sees only the complete
LlmResponse event. The observer channel carries deltas to the UI
in real-time.

Sources that support streaming accept a StreamSender at construction
and emit deltas while building the complete response.

Uses asyncio queues for fan-out to multiple receivers.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import AsyncIterator


# ════════════════════════════════════════════════════════════════
# StreamEvent — delta types
# ════════════════════════════════════════════════════════════════


class StreamEvent:
    """Base class for streaming deltas."""
    pass


@dataclass(frozen=True)
class TextDelta(StreamEvent):
    """Text content delta."""
    text: str


@dataclass(frozen=True)
class ThinkingDelta(StreamEvent):
    """Thinking/reasoning delta."""
    text: str


@dataclass(frozen=True)
class ToolCallStart(StreamEvent):
    """Tool call started."""
    id: str
    name: str


@dataclass(frozen=True)
class ToolCallDelta(StreamEvent):
    """Tool call arguments delta (incremental JSON)."""
    id: str
    json_delta: str


@dataclass(frozen=True)
class StreamDone(StreamEvent):
    """Response complete."""
    pass


# ════════════════════════════════════════════════════════════════
# Channel — broadcast sender + multiple receivers
# ════════════════════════════════════════════════════════════════


class StreamSender:
    """Sender half — held by the source, used to emit deltas.

    Broadcasts to all subscribed receivers.
    """

    def __init__(self, capacity: int = 256):
        self._subscribers: list[asyncio.Queue[StreamEvent | None]] = []
        self._capacity = capacity

    def subscribe(self) -> StreamReceiver:
        """Create a new receiver. Call before sending events."""
        queue: asyncio.Queue[StreamEvent | None] = asyncio.Queue(maxsize=self._capacity)
        self._subscribers.append(queue)
        return StreamReceiver(queue)

    def send(self, event: StreamEvent) -> None:
        """Send an event to all subscribers. Non-blocking (drops if full)."""
        for queue in self._subscribers:
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                pass

    def done(self) -> None:
        """Signal completion to all subscribers."""
        self.send(StreamDone())
        # Send sentinel None to unblock receivers
        for queue in self._subscribers:
            try:
                queue.put_nowait(None)
            except asyncio.QueueFull:
                pass


class StreamReceiver:
    """Receiver half — held by the UI/observer.

    Async iterator over stream events.
    """

    def __init__(self, queue: asyncio.Queue[StreamEvent | None]):
        self._queue = queue

    async def recv(self) -> StreamEvent | None:
        """Receive the next event. Returns None when done."""
        item = await self._queue.get()
        if item is None:
            return None
        return item

    async def __aiter__(self) -> AsyncIterator[StreamEvent]:
        """Iterate over events until done."""
        while True:
            item = await self._queue.get()
            if item is None:
                break
            yield item


def stream_channel(capacity: int = 256) -> tuple[StreamSender, StreamReceiver]:
    """Create a stream observer channel pair."""
    sender = StreamSender(capacity)
    receiver = sender.subscribe()
    return sender, receiver
