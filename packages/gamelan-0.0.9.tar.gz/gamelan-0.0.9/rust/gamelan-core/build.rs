/// Build script: convert stdlib transducer JSON to a single MessagePack bundle.
/// The bundle is embedded in the binary via include_bytes!().
///
/// Reads from the shared stdlib/ directory (root of repo) — the canonical
/// source for transducer definitions used by all language implementations.
use std::fs;
use std::path::Path;

fn main() {
    // Use local copy for crate packaging; canonical source is ../../stdlib/transducers/
    let stdlib_dir = Path::new("stdlib");
    let out_dir = std::env::var("OUT_DIR").unwrap();
    let out_path = Path::new(&out_dir).join("stdlib.msgpack");

    let names = [
        "messages",
        "blocks",
        "usage",
        "call_llm",
        "execute_tool",
        "summary",
    ];

    let mut transducers: Vec<serde_json::Value> = Vec::new();
    for name in &names {
        let json_path = stdlib_dir.join(format!("{name}.td.json"));
        let json = fs::read_to_string(&json_path)
            .unwrap_or_else(|e| panic!("Failed to read {}: {e}", json_path.display()));
        let value: serde_json::Value = serde_json::from_str(&json)
            .unwrap_or_else(|e| panic!("Failed to parse {}: {e}", json_path.display()));
        transducers.push(value);
    }

    let msgpack = rmp_serde::to_vec(&transducers)
        .unwrap_or_else(|e| panic!("Failed to encode stdlib to MessagePack: {e}"));

    fs::write(&out_path, &msgpack)
        .unwrap_or_else(|e| panic!("Failed to write {}: {e}", out_path.display()));

    // Rerun if any stdlib file changes
    for name in &names {
        println!("cargo:rerun-if-changed=stdlib/{name}.td.json");
    }
}
