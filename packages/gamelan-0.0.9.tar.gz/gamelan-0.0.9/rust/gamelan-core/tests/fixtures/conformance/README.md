# Conformance Test Fixtures

Portable JSON test cases for verifying any Gamelan kernel implementation.

Each file contains an array of test cases. Each test case has:
- `name` — test identifier
- `input` — the data to feed to the implementation
- `expected` — the expected output to verify against

## Files

- `expand.json` — macro expansion tests (Loader.v)
- `typecheck.json` — static type checking tests (TransducerVM.v §15-16)
- `eval.json` — expression evaluation tests (TransducerVM.v §4)
- `exec.json` — transducer execution tests (TransducerVM.v §6)
- `pipeline.json` — full pipeline tests (expand → typecheck → validate → execute)

## Usage

Any implementation:
1. Load the JSON fixture
2. For each test case, run the input through the corresponding phase
3. Compare output against expected
4. All tests must pass for conformance

The Rust tests in `conformance.rs` consume these same fixtures.
