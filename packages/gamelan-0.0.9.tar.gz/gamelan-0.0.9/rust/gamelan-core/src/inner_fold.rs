//! DomainFold — the trait that every session's domain fold implements.
//!
//! The interpreter model: routing, gating, and check configuration live in
//! `RoutingConfig` (computed by the connection-state interpreter), not in
//! the fold. The fold itself is protocol-agnostic — state and requests only.
//!
//! Both `AgentFold` and `CoordinatorFold` implement `DomainFold`.

use crate::prelude::*;

// ════════════════════════════════════════════════════════════════
// String-keyed pending operations — interpreter model
// Spec: interpreter.qnt classify + agent.qnt keyed dispatch
// ════════════════════════════════════════════════════════════════

/// String-keyed pending set: opaque string keys currently in flight.
///
/// Keys are built by `classify` / `classify_result` from request type +
/// optional instance id. Type-level keys (e.g. "LlmRequest") and
/// instance-level keys (e.g. "ToolRequest:call_abc") both live here.
pub type KeyedPending = Vec<String>;

/// Is this key currently pending?
pub fn is_key_pending(pending: &KeyedPending, key: &str) -> bool {
    pending.iter().any(|k| k == key)
}

/// Gate: return only those keys that are NOT already pending.
///
/// Analogous to the existing `gate` but operates on pre-classified
/// string keys rather than on generic request values.
pub fn gate_by_key(keys: &[String], pending: &KeyedPending) -> Vec<String> {
    keys.iter()
        .filter(|k| !is_key_pending(pending, k))
        .cloned()
        .collect()
}

/// Add keys to pending, deduplicating.
pub fn add_key_pending(pending: &KeyedPending, keys: &[String]) -> KeyedPending {
    let mut result = pending.clone();
    for k in keys {
        if !is_key_pending(&result, k) {
            result.push(k.clone());
        }
    }
    result
}

/// Clear a single key from pending when its result arrives.
pub fn clear_key_pending(pending: &KeyedPending, key: &str) -> KeyedPending {
    pending
        .iter()
        .filter(|k| k.as_str() != key)
        .cloned()
        .collect()
}

// ════════════════════════════════════════════════════════════════
// DomainFold trait
// Spec: runtime-contract.md "Domain fold" section
// ════════════════════════════════════════════════════════════════

/// The domain fold of a session. Pure: `(state, event) → (state', requests)`.
///
/// Routing, gating, and check configuration live in `RoutingConfig`
/// (computed by the connection-state interpreter), not in the fold.
/// This makes the fold protocol-agnostic — it only knows about state and requests.
///
/// Both `AgentFold` and `CoordinatorFold` implement this.
pub trait DomainFold {
    /// The fold's state (Env for agent, coordinator state for network).
    type State: Clone;

    /// Events the fold processes.
    type Event;

    /// Requests the fold emits.
    type Request: Clone;

    /// Result delivered back after dispatch.
    type DispatchResult;

    /// `project : State → Event → State`
    fn project(&self, state: &Self::State, event: &Self::Event) -> Self::State;

    /// `generate : State → Event → List Request`
    fn generate(&self, state: &Self::State, event: &Self::Event) -> Vec<Self::Request>;

    /// Combined project + generate in a single pass.
    ///
    /// Default: calls project then generate(new_state). Override for folds
    /// where both happen in one computation (e.g., the VM runs once and
    /// produces both state and emits together).
    fn fold(&self, state: &Self::State, event: &Self::Event) -> (Self::State, Vec<Self::Request>) {
        let new_state = self.project(state, event);
        let requests = self.generate(&new_state, event);
        (new_state, requests)
    }

    /// String tag for event log persistence.
    fn event_tag(&self, event: &Self::Event) -> String;
}

// ════════════════════════════════════════════════════════════════
// Tests
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    /// Minimal DomainFold implementation for testing the default fold() method.
    struct CounterFold;

    #[derive(Clone)]
    struct CounterState {
        count: i32,
    }

    struct CounterEvent {
        delta: i32,
    }

    #[derive(Clone, PartialEq, Debug)]
    struct CounterRequest {
        label: String,
    }

    impl DomainFold for CounterFold {
        type State = CounterState;
        type Event = CounterEvent;
        type Request = CounterRequest;
        type DispatchResult = ();

        fn project(&self, state: &CounterState, event: &CounterEvent) -> CounterState {
            CounterState {
                count: state.count + event.delta,
            }
        }

        fn generate(&self, state: &CounterState, _event: &CounterEvent) -> Vec<CounterRequest> {
            if state.count > 5 {
                vec![CounterRequest {
                    label: "threshold_reached".into(),
                }]
            } else {
                vec![]
            }
        }

        fn event_tag(&self, event: &CounterEvent) -> String {
            format!("delta:{}", event.delta)
        }
    }

    /// Verify DomainFold default fold() calls project then generate(new_state).
    /// After delta=6 from count=0, new_state.count=6 > 5 → request emitted.
    #[test]
    fn test_domain_fold_default_fold() {
        let fold = CounterFold;
        let state = CounterState { count: 0 };
        let event = CounterEvent { delta: 6 };

        let (new_state, requests) = fold.fold(&state, &event);

        assert_eq!(new_state.count, 6);
        assert_eq!(requests.len(), 1);
        assert_eq!(requests[0].label, "threshold_reached");
    }

    /// Verify fold() does NOT emit when threshold not reached.
    #[test]
    fn test_domain_fold_no_request_below_threshold() {
        let fold = CounterFold;
        let state = CounterState { count: 0 };
        let event = CounterEvent { delta: 3 };

        let (new_state, requests) = fold.fold(&state, &event);

        assert_eq!(new_state.count, 3);
        assert!(requests.is_empty());
    }

    /// Verify event_tag is accessible.
    #[test]
    fn test_domain_fold_event_tag() {
        let fold = CounterFold;
        let event = CounterEvent { delta: 42 };
        assert_eq!(fold.event_tag(&event), "delta:42");
    }

    // ── String-keyed pending operations ───────────────

    #[test]
    fn test_is_key_pending_present() {
        let pending = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        assert!(is_key_pending(&pending, "LlmRequest"));
        assert!(is_key_pending(&pending, "ToolRequest:call_abc"));
    }

    #[test]
    fn test_is_key_pending_absent() {
        let pending = vec!["LlmRequest".into()];
        assert!(!is_key_pending(&pending, "ToolRequest"));
    }

    #[test]
    fn test_is_key_pending_empty() {
        let pending: KeyedPending = vec![];
        assert!(!is_key_pending(&pending, "LlmRequest"));
    }

    #[test]
    fn test_gate_by_key_filters_pending() {
        let pending = vec!["LlmRequest".into()];
        let keys: Vec<String> = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let result = gate_by_key(&keys, &pending);
        assert_eq!(result, vec!["ToolRequest:call_abc"]);
    }

    #[test]
    fn test_gate_by_key_all_pass() {
        let pending: KeyedPending = vec![];
        let keys: Vec<String> = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let result = gate_by_key(&keys, &pending);
        assert_eq!(result, keys);
    }

    #[test]
    fn test_gate_by_key_all_blocked() {
        let pending: KeyedPending = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let keys: Vec<String> = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let result = gate_by_key(&keys, &pending);
        assert!(result.is_empty());
    }

    #[test]
    fn test_add_key_pending_deduplicates() {
        let pending: KeyedPending = vec!["LlmRequest".into()];
        let keys: Vec<String> = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let result = add_key_pending(&pending, &keys);
        assert_eq!(result, vec!["LlmRequest", "ToolRequest:call_abc"]);
    }

    #[test]
    fn test_add_key_pending_empty_pending() {
        let pending: KeyedPending = vec![];
        let keys: Vec<String> = vec!["LlmRequest".into()];
        let result = add_key_pending(&pending, &keys);
        assert_eq!(result, vec!["LlmRequest"]);
    }

    #[test]
    fn test_add_key_pending_no_duplicate_within_keys() {
        let pending: KeyedPending = vec![];
        let keys: Vec<String> = vec!["LlmRequest".into(), "LlmRequest".into()];
        let result = add_key_pending(&pending, &keys);
        assert_eq!(result, vec!["LlmRequest"]);
    }

    #[test]
    fn test_clear_key_pending_removes_key() {
        let pending: KeyedPending = vec!["LlmRequest".into(), "ToolRequest:call_abc".into()];
        let result = clear_key_pending(&pending, "LlmRequest");
        assert_eq!(result, vec!["ToolRequest:call_abc"]);
    }

    #[test]
    fn test_clear_key_pending_key_not_present() {
        let pending: KeyedPending = vec!["LlmRequest".into()];
        let result = clear_key_pending(&pending, "ToolRequest");
        assert_eq!(result, vec!["LlmRequest"]);
    }

    #[test]
    fn test_clear_key_pending_instance_key() {
        let pending: KeyedPending = vec![
            "LlmRequest".into(),
            "ToolRequest:call_abc".into(),
            "ToolRequest:call_xyz".into(),
        ];
        // Only the exact key is cleared — other instance keys remain.
        let result = clear_key_pending(&pending, "ToolRequest:call_abc");
        assert_eq!(result, vec!["LlmRequest", "ToolRequest:call_xyz"]);
    }
}
