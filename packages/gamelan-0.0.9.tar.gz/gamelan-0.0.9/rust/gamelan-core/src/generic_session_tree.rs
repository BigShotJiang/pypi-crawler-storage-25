//! Generic session tree — the proved kernel data structure, generic over DomainFold.
//!
//! Matches the Lean `Session` inductive in `SessionMonad.lean`:
//! Five constructors: Pure, Dispatch, Yield, Check, CheckEvent.
//!
//! `build_turn_tree()` is generic over `DomainFold` and takes `RoutingConfig`
//! plus classify closures. Uses `KeyedPending` (string keys).
//! This is the interpreter-model version — routing lives in `RoutingConfig`,
//! not in the fold.

use crate::inner_fold::{self, DomainFold, KeyedPending};
use crate::interpreter::{self as interp, RoutingConfig};
use crate::prelude::*;

// ════════════════════════════════════════════════════════════════
// Session tree types
// ════════════════════════════════════════════════════════════════

/// Turn output carrying a `KeyedPending` (string keys).
#[derive(Debug, Clone)]
pub struct TurnOutput<S: Clone> {
    pub state: S,
    pub pending: KeyedPending,
}

/// Check verdict — matches Lean `CheckVerdict T`.
#[derive(Debug, Clone)]
pub enum CheckVerdict<T> {
    Approve,
    Reject,
    Transform(T),
}

#[allow(clippy::type_complexity)] // continuation closures match Lean inductive structure
/// Session free monad, generic over state/request/event.
///
/// Matches Lean:
/// ```text
/// inductive Session (Request Result Event : Type) (A : Type)
///   | Pure       : A → Session ...
///   | Dispatch   : Request → (Result → Session ...) → Session ...
///   | Yield      : (Event → Session ...) → Session ...
///   | Check      : Request → (CheckVerdict Request → Session ...) → Session ...
///   | CheckEvent : Event → (CheckVerdict Event → Session ...) → Session ...
/// ```
pub enum SessionTree<S: Clone, R: Clone, E, D> {
    /// Terminal — turn complete, return output.
    Pure(TurnOutput<S>),

    /// Send request to source, continue with result.
    Dispatch {
        request: R,
        cont: Box<dyn FnOnce(D) -> SessionTree<S, R, E, D>>,
    },

    /// Wait for next event — turn boundary.
    Yield { output: TurnOutput<S> },

    /// Outbound hold: check request before dispatch.
    Check {
        request: R,
        check_source: String,
        cont: Box<dyn FnOnce(CheckVerdict<R>) -> SessionTree<S, R, E, D>>,
    },

    /// Inbound hold: check event before fold sees it.
    CheckEvent {
        event: E,
        check_source: String,
        cont: Box<dyn FnOnce(CheckVerdict<E>) -> SessionTree<S, R, E, D>>,
    },
}

// ════════════════════════════════════════════════════════════════
// Tree construction — matches Lean turn_loop
// ════════════════════════════════════════════════════════════════

/// Build a session tree for one turn — interpreter-model version.
///
/// Same 7-step turn loop as the proved Lean `turn_loop` but driven by
/// `RoutingConfig` (external routing data) and string-keyed classify closures.
///
/// The classify closures must be `Clone + 'static` so they can be captured
/// by the `CheckEvent` continuation (which itself is `'static`).
///
/// Spec: runtime-contract.md turn_loop section with routing parameter.
///
/// Steps:
/// 0. Inbound check? → CheckEvent (hold before fold)
/// 1. clear_pending by key (classify_result_fn → key to clear)
/// 2. Fold (project + generate via DomainFold)
/// 3. Gate by keys (classify_fn(req) → key, filter pending)
/// 4. dispatch_with_checks → Check/Dispatch chain + add_pending
/// 5. Yield (turn boundary)
pub fn build_turn_tree<F, CF, CRF>(
    fold: &F,
    routing: &RoutingConfig,
    classify_fn: CF,
    classify_result_fn: CRF,
    state: &F::State,
    event: &F::Event,
    pending: &KeyedPending,
) -> SessionTree<F::State, F::Request, F::Event, F::DispatchResult>
where
    F: DomainFold + Clone + 'static,
    F::State: Clone + 'static,
    F::Request: Clone + 'static,
    F::Event: Clone + 'static,
    F::DispatchResult: 'static,
    CF: Fn(&F::Request) -> String + Clone + 'static,
    CRF: Fn(&F::Event) -> Option<String> + Clone + 'static,
{
    // Spec: turn_loop step 0 — inbound check via RoutingConfig
    let event_tag = fold.event_tag(event);
    if let Some(check_source) = interp::needs_inbound_check(routing, &event_tag) {
        let f = fold.clone();
        let r = routing.clone();
        let st = state.clone();
        let p = pending.clone();
        let ev = event.clone();
        let cf = classify_fn.clone();
        let crf = classify_result_fn.clone();

        return SessionTree::CheckEvent {
            event: event.clone(),
            check_source,
            cont: Box::new(move |verdict| match verdict {
                CheckVerdict::Approve => {
                    // Spec: approved → process inner turn with original event
                    build_inner_turn(&f, &r, cf, crf, &st, &ev, &p)
                }
                CheckVerdict::Reject => {
                    // Spec: rejected → state unchanged, pending unchanged, no fold
                    SessionTree::Pure(TurnOutput {
                        state: st,
                        pending: p,
                    })
                }
                CheckVerdict::Transform(new_event) => {
                    // Spec: transformed → process inner turn with transformed event
                    build_inner_turn(&f, &r, cf, crf, &st, &new_event, &p)
                }
            }),
        };
    }

    build_inner_turn(
        fold,
        routing,
        classify_fn,
        classify_result_fn,
        state,
        event,
        pending,
    )
}

/// Inner turn: clear_pending → fold → gate → dispatch → Yield.
///
/// Spec: runtime-contract.md turn_loop inner steps 1-5.
fn build_inner_turn<F, CF, CRF>(
    fold: &F,
    routing: &RoutingConfig,
    classify_fn: CF,
    classify_result_fn: CRF,
    state: &F::State,
    event: &F::Event,
    pending: &KeyedPending,
) -> SessionTree<F::State, F::Request, F::Event, F::DispatchResult>
where
    F: DomainFold + 'static,
    F::State: Clone + 'static,
    F::Request: Clone + 'static,
    F::Event: 'static,
    F::DispatchResult: 'static,
    CF: Fn(&F::Request) -> String + Clone + 'static,
    CRF: Fn(&F::Event) -> Option<String> + Clone + 'static,
{
    // Spec: step 1 — clear pending by key
    // classify_result_fn returns the gating key to remove (or None if not a result event).
    let pending_after_clear = match classify_result_fn(event) {
        Some(key) if !key.is_empty() => inner_fold::clear_key_pending(pending, &key),
        _ => pending.clone(),
    };

    // Spec: step 2 — fold: project + generate in one pass
    let (new_state, all_reqs) = fold.fold(state, event);

    // Spec: step 3 — gate: classify each request, filter out pending keys
    let all_keys: Vec<String> = all_reqs.iter().map(&classify_fn).collect();
    let gated_keys = inner_fold::gate_by_key(&all_keys, &pending_after_clear);

    // Keep only requests whose classified key was not gated out
    let gated_reqs: Vec<F::Request> = all_reqs
        .into_iter()
        .filter(|r| {
            let key = classify_fn(r);
            gated_keys.contains(&key)
        })
        .collect();

    // Spec: step 4 — if nothing to dispatch → Pure (quiescent)
    if gated_reqs.is_empty() {
        return SessionTree::Pure(TurnOutput {
            state: new_state,
            pending: pending_after_clear,
        });
    }

    // Spec: step 5 — add dispatched keys to pending
    let pending_after_dispatch = inner_fold::add_key_pending(&pending_after_clear, &gated_keys);

    // Classify requests for check routing — using RoutingConfig
    let classified: Vec<(F::Request, bool, Option<String>)> = gated_reqs
        .into_iter()
        .map(|r| {
            // The request_type for check routing: use classify_fn result as the type key,
            // then look up in routing.outbound_checks.
            // classify_fn returns instance-level or type-level key. For outbound check
            // lookup we need the type prefix (before ':' if instance-level).
            let key = classify_fn(&r);
            let req_type = key.split(':').next().unwrap_or(&key).to_string();
            let needs_check = interp::needs_outbound_check(routing, &req_type);
            let check_source = if needs_check {
                interp::outbound_check_source(routing, &req_type)
            } else {
                None
            };
            (r, needs_check, check_source)
        })
        .collect();

    // Spec: step 5 — Build dispatch-with-checks chain → Yield
    let output = TurnOutput {
        state: new_state,
        pending: pending_after_dispatch,
    };
    dispatch_with_checks(classified, output)
}

/// Build the Check/Dispatch chain for classified requests.
///
/// Matches Lean `dispatch_with_checks`:
/// - Checked request → Check → Approve → Dispatch → next
///   → Reject → next (key stays pending, caller cancels)
///   → Transform → Dispatch(new) → next
/// - Unchecked request → Dispatch → next
/// - Base case → Yield
///
/// Spec: runtime-contract.md dispatch_with_checks section.
fn dispatch_with_checks<S: Clone + 'static, R: Clone + 'static, E: 'static, D: 'static>(
    mut requests: Vec<(R, bool, Option<String>)>,
    output: TurnOutput<S>,
) -> SessionTree<S, R, E, D> {
    if requests.is_empty() {
        return SessionTree::Yield { output };
    }

    let (request, needs_check, check_source) = requests.remove(0);

    if needs_check {
        let cs = check_source.unwrap_or_default();
        let req_clone = request.clone();
        SessionTree::Check {
            request: request.clone(),
            check_source: cs,
            cont: Box::new(move |verdict| match verdict {
                CheckVerdict::Approve => SessionTree::Dispatch {
                    request: req_clone,
                    cont: Box::new(move |_result| dispatch_with_checks(requests, output)),
                },
                CheckVerdict::Reject => {
                    // On reject the key stays pending — caller removes via cancel_request.
                    dispatch_with_checks(requests, output)
                }
                CheckVerdict::Transform(new_req) => SessionTree::Dispatch {
                    request: new_req,
                    cont: Box::new(move |_result| dispatch_with_checks(requests, output)),
                },
            }),
        }
    } else {
        SessionTree::Dispatch {
            request,
            cont: Box::new(move |_result| dispatch_with_checks(requests, output)),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Tests for build_turn_tree
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use crate::inner_fold::DomainFold;
    use crate::interpreter::{DispatchRule, OutboundCheckRule};
    use alloc::collections::BTreeMap;

    // ── Minimal test fold ────────────────────────────────

    /// A simple counter fold: on "Tick", emits a WorkRequest and increments count.
    #[derive(Clone)]
    struct TestFold;

    #[derive(Clone, Debug, PartialEq)]
    struct TestState {
        count: i32,
    }

    #[derive(Clone, Debug, PartialEq)]
    struct TestEvent {
        tag: String,
    }

    #[derive(Clone, Debug, PartialEq)]
    struct TestRequest {
        req_type: String,
    }

    #[derive(Default)]
    struct TestResult;

    impl DomainFold for TestFold {
        type State = TestState;
        type Event = TestEvent;
        type Request = TestRequest;
        type DispatchResult = TestResult;

        fn project(&self, state: &TestState, event: &TestEvent) -> TestState {
            if event.tag == "Tick" {
                TestState {
                    count: state.count + 1,
                }
            } else {
                state.clone()
            }
        }

        fn generate(&self, _state: &TestState, event: &TestEvent) -> Vec<TestRequest> {
            if event.tag == "Tick" {
                vec![TestRequest {
                    req_type: "WorkRequest".into(),
                }]
            } else {
                vec![]
            }
        }

        fn event_tag(&self, event: &TestEvent) -> String {
            event.tag.clone()
        }
    }

    fn test_routing() -> RoutingConfig {
        RoutingConfig {
            dispatch_rules: vec![DispatchRule {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
            outbound_checks: vec![],
            inbound_checks: vec![],
        }
    }

    fn classify(req: &TestRequest) -> String {
        req.req_type.clone()
    }

    fn classify_result(event: &TestEvent) -> Option<String> {
        if event.tag == "WorkResult" {
            Some("WorkRequest".into())
        } else {
            None
        }
    }

    fn flatten_tree(
        tree: SessionTree<TestState, TestRequest, TestEvent, TestResult>,
    ) -> (TestState, KeyedPending, usize) {
        match tree {
            SessionTree::Pure(out) => (out.state, out.pending, 0),
            SessionTree::Yield { output } => (output.state, output.pending, 0),
            SessionTree::Dispatch { cont, .. } => {
                let next = cont(TestResult);
                let (s, p, c) = flatten_tree(next);
                (s, p, c + 1)
            }
            SessionTree::Check { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_tree(next)
            }
            SessionTree::CheckEvent { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_tree(next)
            }
        }
    }

    // ── Tests ─────────────────────────────────────────────

    /// Tick event: fold runs, WorkRequest dispatched, pending has "WorkRequest" key.
    #[test]
    fn tick_produces_work_request() {
        let fold = TestFold;
        let routing = test_routing();
        let state = TestState { count: 0 };
        let event = TestEvent { tag: "Tick".into() };
        let pending: KeyedPending = vec![];

        let tree = build_turn_tree(
            &fold,
            &routing,
            classify,
            classify_result,
            &state,
            &event,
            &pending,
        );
        let (new_state, new_pending, dispatch_count) = flatten_tree(tree);

        assert_eq!(new_state.count, 1);
        assert_eq!(dispatch_count, 1);
        assert_eq!(new_pending, vec!["WorkRequest"]);
    }

    /// No requests → Pure (quiescent). Non-Tick event produces no requests.
    #[test]
    fn no_requests_is_pure() {
        let fold = TestFold;
        let routing = test_routing();
        let state = TestState { count: 0 };
        let event = TestEvent {
            tag: "Other".into(),
        };
        let pending: KeyedPending = vec![];

        let tree = build_turn_tree(
            &fold,
            &routing,
            classify,
            classify_result,
            &state,
            &event,
            &pending,
        );
        assert!(matches!(tree, SessionTree::Pure(_)));
    }

    /// Gate: WorkRequest already pending → no dispatch, fold still runs.
    #[test]
    fn gate_blocks_while_pending() {
        let fold = TestFold;
        let routing = test_routing();
        let state = TestState { count: 0 };
        let event = TestEvent { tag: "Tick".into() };
        let pending: KeyedPending = vec!["WorkRequest".into()];

        let tree = build_turn_tree(
            &fold,
            &routing,
            classify,
            classify_result,
            &state,
            &event,
            &pending,
        );
        let (new_state, new_pending, dispatch_count) = flatten_tree(tree);

        // Fold ran: count incremented
        assert_eq!(new_state.count, 1);
        // Gated: no dispatch
        assert_eq!(dispatch_count, 0);
        // Pending unchanged (WorkRequest already there, didn't add again)
        assert_eq!(new_pending, vec!["WorkRequest"]);
    }

    /// WorkResult clears "WorkRequest" from pending.
    #[test]
    fn result_clears_pending() {
        let fold = TestFold;
        let routing = test_routing();
        let state = TestState { count: 1 };
        let event = TestEvent {
            tag: "WorkResult".into(),
        };
        let pending: KeyedPending = vec!["WorkRequest".into()];

        let tree = build_turn_tree(
            &fold,
            &routing,
            classify,
            classify_result,
            &state,
            &event,
            &pending,
        );
        let (_, new_pending, _) = flatten_tree(tree);

        assert!(
            new_pending.is_empty(),
            "WorkRequest should be cleared: {:?}",
            new_pending
        );
    }

    /// Outbound check: WorkRequest goes through Check node when routing has outbound check.
    #[test]
    fn outbound_check_produces_check_node() {
        let fold = TestFold;
        let routing = RoutingConfig {
            dispatch_rules: vec![DispatchRule {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
            outbound_checks: vec![OutboundCheckRule {
                request_type: "WorkRequest".into(),
                check_source: "approval".into(),
            }],
            inbound_checks: vec![],
        };
        let state = TestState { count: 0 };
        let event = TestEvent { tag: "Tick".into() };
        let pending: KeyedPending = vec![];

        let tree = build_turn_tree(
            &fold,
            &routing,
            classify,
            classify_result,
            &state,
            &event,
            &pending,
        );
        // The tree should be a Check node (not Dispatch) for the checked request.
        assert!(
            matches!(tree, SessionTree::Check { check_source, .. } if check_source == "approval")
        );
    }

    /// Verify agent fold works through build_turn_tree with classify closures.
    #[test]
    fn agent_fold_through_build_turn_tree() {
        use crate::agent_fold::{
            AgentEvent, AgentFold, agent_boot, agent_classify_fn, agent_classify_result_fn,
            agent_derive_routing,
        };
        use crate::agent_fold::{ConnectionDef, SourcePair, SourceRegistration};
        use crate::types::*;

        let fold = AgentFold {
            transducers: vec![TransducerDef {
                name: "counter".into(),
                slots: vec![SlotDef {
                    name: "n".into(),
                    initial: Value::Int(0),
                }],
                rules: vec![Rule {
                    on: "Input".into(),
                    guard: Expr::Lit {
                        value: Value::Bool(true),
                    },
                    updates: vec![Update {
                        slot: "n".into(),
                        expr: Expr::Add {
                            left: Box::new(Expr::Ref { name: "n".into() }),
                            right: Box::new(Expr::Lit {
                                value: Value::Int(1),
                            }),
                        },
                    }],
                    emits: vec![Expr::Rec {
                        fields: vec![RecField {
                            key: "type".into(),
                            val_expr: Expr::Lit {
                                value: Value::Str("WorkRequest".into()),
                            },
                        }],
                    }],
                }],
            }],
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: false,
                check_source: None,
            }],
            inbound_checks: vec![],
        };

        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let cs = agent_boot(&sources, &[]);
        let routing = agent_derive_routing(&cs);

        let state = BTreeMap::from([("n".into(), Value::Int(0))]);
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        let pending: KeyedPending = vec![];

        let tree = build_turn_tree(
            &fold,
            &routing,
            agent_classify_fn,
            agent_classify_result_fn(&routing),
            &state,
            &event,
            &pending,
        );

        fn flatten_agent(
            tree: SessionTree<
                crate::types::Env,
                crate::types::Value,
                crate::agent_fold::AgentEvent,
                crate::agent_fold::AgentDispatchResult,
            >,
        ) -> usize {
            match tree {
                SessionTree::Pure(_) | SessionTree::Yield { .. } => 0,
                SessionTree::Dispatch { cont, .. } => {
                    1 + flatten_agent(cont(crate::agent_fold::AgentDispatchResult::default()))
                }
                SessionTree::Check { cont, .. } => flatten_agent(cont(CheckVerdict::Approve)),
                SessionTree::CheckEvent { cont, .. } => {
                    flatten_agent(cont(CheckVerdict::Approve))
                }
            }
        }

        assert_eq!(
            flatten_agent(tree),
            1,
            "agent fold should dispatch exactly once"
        );
    }
}
