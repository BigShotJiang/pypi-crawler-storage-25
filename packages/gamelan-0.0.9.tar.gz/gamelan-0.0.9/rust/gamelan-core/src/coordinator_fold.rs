//! CoordinatorFold — InnerFold implementation for network sessions.
//!
//! Direct translation of `network_project` and `network_generate` from
//! `NetworkSession.lean`. The coordinator is a native transducer:
//! project + generate, pure, deterministic.
//!
//! The session tree handles gate, pending, checks — same machinery
//! as the agent fold. No special network code needed.
//!
//! Also contains the network interpreter types:
//! NetworkConnection, NetworkConnectionState, NetworkConfigEvent,
//! and the functions that derive RoutingConfig from connection state.
//! Direct translation of network.qnt network interpreter section.

use crate::coordinator::{Coordinator, Route};
use crate::inner_fold::DomainFold;
use crate::interpreter::{
    DispatchRule, InboundCheckRule, OutboundCheckRule, RoutingConfig,
};
use crate::network::{NetworkCheckDef, NetworkConfig};
use crate::prelude::*;
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Network connection types — interpreter model
// Spec: network.qnt `type NetworkConnection` + `type NetworkConnectionState`
// ════════════════════════════════════════════════════════════════

/// A network connection definition — one agent's request/result pair.
///
/// No tool_policy or available_tools (those are agent-specific).
/// `instance_key_field`: field name for instance-level gating (e.g. "agent").
///
/// Spec: network.qnt lines 9-16 `type NetworkConnection`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NetworkConnection {
    pub source_id: String,
    pub request_type: String,
    pub result_type: String,
    pub has_check: bool,
    pub check_source: String,
    pub instance_key_field: String,
}

/// Accumulated network connection state — updated by config events.
///
/// Spec: network.qnt lines 19-21 `type NetworkConnectionState`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NetworkConnectionState {
    pub connections: BTreeMap<String, NetworkConnection>,
}

impl NetworkConnectionState {
    /// Empty state — no connections.
    /// Spec: network.qnt `empty_network_connection_state`
    pub fn empty() -> Self {
        NetworkConnectionState {
            connections: BTreeMap::new(),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Network config events
// Spec: network.qnt `type NetworkConfigEvent`
// ════════════════════════════════════════════════════════════════

/// Events that update network connection state.
///
/// Spec: network.qnt lines 30-32 `type NetworkConfigEvent`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum NetworkConfigEvent {
    /// Add or replace a connection (keyed by source_id).
    ConnectionAdded(NetworkConnection),
    /// Remove a connection by source_id.
    ConnectionRemoved(String),
}

// ════════════════════════════════════════════════════════════════
// Network session boot event
// Spec: network.qnt `type NetworkSessionCreated`,
//       `pure def handle_network_session_created`
// ════════════════════════════════════════════════════════════════

/// Boot event — the first event on the network session log.
/// Carries connection topology, checks, agent set, and entry point.
///
/// Spec: network.qnt `type NetworkSessionCreated`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NetworkSessionCreated {
    pub connections: Vec<NetworkConnection>,
    pub outbound_checks: Vec<OutboundCheckRule>,
    pub inbound_checks: Vec<InboundCheckRule>,
    pub agents: Vec<String>,
    pub entry_point: String,
}

/// Process a NetworkSessionCreated event — initialize connection state
/// and routing from the boot payload.
///
/// Spec: network.qnt `pure def handle_network_session_created`
/// Lean: Interpreter.lean `network_session_boot` (proved)
pub fn handle_network_session_created(
    event: &NetworkSessionCreated,
) -> (NetworkConnectionState, RoutingConfig) {
    let cs = event.connections.iter().fold(
        NetworkConnectionState::empty(),
        |acc, conn| {
            handle_network_config_event(&acc, &NetworkConfigEvent::ConnectionAdded(conn.clone()))
        },
    );
    let mut routing = network_derive_routing(&cs);
    routing.outbound_checks = event.outbound_checks.clone();
    routing.inbound_checks = event.inbound_checks.clone();
    (cs, routing)
}

// ════════════════════════════════════════════════════════════════
// Network interpreter functions
// Spec: network.qnt lines 35-74
// ════════════════════════════════════════════════════════════════

/// Handle a network config event — update connection state.
///
/// Spec: network.qnt lines 35-47 `pure def handle_network_config_event`
pub fn handle_network_config_event(
    cs: &NetworkConnectionState,
    event: &NetworkConfigEvent,
) -> NetworkConnectionState {
    match event {
        NetworkConfigEvent::ConnectionAdded(conn) => {
            let mut new_cs = cs.clone();
            new_cs
                .connections
                .insert(conn.source_id.clone(), conn.clone());
            new_cs
        }
        NetworkConfigEvent::ConnectionRemoved(source_id) => {
            let mut new_cs = cs.clone();
            new_cs.connections.remove(source_id);
            new_cs
        }
    }
}

/// Derive `RoutingConfig` from network connection state.
///
/// Produces dispatch_rules and outbound_checks from all connections.
///
/// Spec: network.qnt lines 52-64 `pure def network_derive_routing`
pub fn network_derive_routing(cs: &NetworkConnectionState) -> RoutingConfig {
    let mut dispatch_rules = Vec::new();
    let mut outbound_checks = Vec::new();

    for conn in cs.connections.values() {
        dispatch_rules.push(DispatchRule {
            request_type: conn.request_type.clone(),
            result_type: conn.result_type.clone(),
        });
        if conn.has_check && !conn.check_source.is_empty() {
            outbound_checks.push(OutboundCheckRule {
                request_type: conn.request_type.clone(),
                check_source: conn.check_source.clone(),
            });
        }
    }

    RoutingConfig {
        dispatch_rules,
        outbound_checks,
        inbound_checks: Vec::new(),
    }
}

/// Resolve which source handles a request type.
///
/// Returns the source_id, or empty string if no source handles it.
///
/// Spec: network.qnt lines 67-74 `pure def resolve_network_source`
pub fn resolve_network_source(cs: &NetworkConnectionState, request_type: &str) -> String {
    for conn in cs.connections.values() {
        if conn.request_type == request_type {
            return conn.source_id.clone();
        }
    }
    String::new()
}

// ════════════════════════════════════════════════════════════════
// Network boot — build connection state from routes
// Spec: network.qnt lines 138-158 `pure def network_boot`
// ════════════════════════════════════════════════════════════════

/// Route kind — how two agents interact.
///
/// Spec: network.qnt `type RouteKind`
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RouteKind {
    Delegation,
    Handoff,
}

/// A network route entry for boot configuration.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NetworkRoute {
    pub src: String,
    pub dst: String,
    pub kind: RouteKind,
}

/// Build `NetworkConnectionState` from network config routes.
///
/// Each delegation route → NetworkConnection { AgentRequest → AgentResult, instance_key_field: "agent" }
/// Each handoff route → NetworkConnection { AgentRequest → AgentResult, instance_key_field: "agent" }
///
/// Spec: network.qnt lines 138-158 `pure def network_boot`
pub fn network_boot(config: &NetworkConfig) -> NetworkConnectionState {
    let mut cs = NetworkConnectionState::empty();

    // Delegation routes — spec lines 141-148
    for (src, dst) in &config.delegation_routes {
        cs = handle_network_config_event(
            &cs,
            &NetworkConfigEvent::ConnectionAdded(NetworkConnection {
                source_id: dst.clone(),
                request_type: "AgentRequest".into(),
                result_type: "AgentResult".into(),
                has_check: false,
                check_source: String::new(),
                instance_key_field: "agent".into(),
            }),
        );
        let _ = src; // src is part of topology but connection is keyed by dst
    }

    // Handoff routes — spec lines 149-157
    for (src, dst) in &config.handoff_routes {
        cs = handle_network_config_event(
            &cs,
            &NetworkConfigEvent::ConnectionAdded(NetworkConnection {
                source_id: dst.clone(),
                request_type: "AgentRequest".into(),
                result_type: "AgentResult".into(),
                has_check: false,
                check_source: String::new(),
                instance_key_field: "agent".into(),
            }),
        );
        let _ = src;
    }

    cs
}

// ════════════════════════════════════════════════════════════════
// Network state — matches Lean NetworkState
// ════════════════════════════════════════════════════════════════

/// The coordinator fold's state: coordinator + active_agent.
/// Matches Lean `NetworkState`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkState {
    pub coord: Coordinator,
    pub active_agent: String,
}

impl NetworkState {
    pub fn empty() -> Self {
        NetworkState {
            coord: Coordinator::new(),
            active_agent: String::new(),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Network events — matches Lean NetworkEvent
// ════════════════════════════════════════════════════════════════

/// Events the network fold processes.
/// Matches Lean `NetworkEvent` exactly.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum NetworkEvent {
    UserMessage { text: String },
    RegisterAgent { id: String },
    StartAgent { id: String },
    AgentDone { id: String },
    ResetAgent { id: String },
    DelegationRequested { parent: String, child: String },
    DelegationComplete { parent: String, child: String },
    DelegationFailed { parent: String, child: String },
    HandoffRequested { src: String, dst: String },
    HandoffComplete { src: String, dst: String },
    AgentFailed { id: String },
}

// ════════════════════════════════════════════════════════════════
// Network requests — matches Lean NetworkRequest
// ════════════════════════════════════════════════════════════════

/// Requests the network dispatches to agents.
/// Matches Lean `NetworkRequest` — only async dispatch operations.
/// Synchronous effects (destroy, activate, reset) are handled by
/// the host after the tree walk, not through pending/gating.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NetworkRequest {
    /// Send a message to an agent session, driving its turn.
    AgentRequest { agent: String },
    /// Collect a result from a completed agent session.
    CollectAgentResult { agent: String },
}

/// Result of dispatching a network request.
#[derive(Debug, Clone)]
pub enum NetworkDispatchResult {
    AgentRequestComplete { agent: String },
    AgentResultCollected { agent: String },
}

impl Default for NetworkDispatchResult {
    fn default() -> Self {
        NetworkDispatchResult::AgentRequestComplete {
            agent: String::new(),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// CoordinatorFold — the DomainFold implementation
// ════════════════════════════════════════════════════════════════

/// The coordinator as a transducer: project + generate.
/// Holds configuration (routes, checks). State is passed through.
#[derive(Debug, Clone)]
pub struct CoordinatorFold {
    pub inbound_checks: Vec<NetworkCheckDef>,
    pub outbound_checks: Vec<NetworkCheckDef>,
}

// ════════════════════════════════════════════════════════════════
// DomainFold impl for CoordinatorFold
// Spec: runtime-contract.md "Domain fold" section
// ════════════════════════════════════════════════════════════════

impl DomainFold for CoordinatorFold {
    type State = NetworkState;
    type Event = NetworkEvent;
    type Request = NetworkRequest;
    type DispatchResult = NetworkDispatchResult;

    /// `network_project` from NetworkSession.lean.
    /// Total: invalid events leave state unchanged.
    fn project(&self, state: &NetworkState, event: &NetworkEvent) -> NetworkState {
        let mut ns = state.clone();
        match event {
            NetworkEvent::RegisterAgent { id } => {
                let _ = ns.coord.spawn_session(id.clone());
            }
            NetworkEvent::UserMessage { .. } => {
                if let Ok(()) = ns.coord.start_processing(&ns.active_agent) {
                    // state updated in place
                }
            }
            NetworkEvent::StartAgent { id } => {
                let _ = ns.coord.start_processing(id);
            }
            NetworkEvent::AgentDone { id } => {
                let _ = ns.coord.finish_session(id);
            }
            NetworkEvent::ResetAgent { id } => {
                let _ = ns.coord.reset_session(id);
            }
            NetworkEvent::DelegationRequested { parent, child } => {
                // Spec: coordinator_project DelegationRequested.
                // Two cases:
                // 1. Ephemeral: child does not exist yet — spawn child, add route, delegate.
                //    Rolls back (destroys child) if any step fails.
                // 2. Pre-registered: child already exists with route registered at boot —
                //    delegate_to directly. delegate_to transitions:
                //    parent → SWaitingDelegate, child → SProcessing.
                // The fold is total — invalid events leave state unchanged.
                let child_exists = ns.coord.session(child).is_some();
                if child_exists {
                    // Pre-registered path: use existing child and route
                    let _ = ns
                        .coord
                        .delegate_to(parent, child, "DelegationRequest", BTreeMap::new());
                } else {
                    // Ephemeral path: spawn child, add route, delegate — with rollback
                    #[allow(clippy::if_same_then_else)] // both branches are intentional rollback
                    if ns.coord.spawn_session(child.clone()).is_ok() {
                        if ns.coord.add_route(Route {
                            src: parent.clone(),
                            dst: child.clone(),
                            request_type: "DelegationRequest".into(),
                            result_type: "DelegationResult".into(),
                        }).is_err() {
                            let _ = ns.coord.destroy_session(child.clone());
                        } else if ns.coord.delegate_to(
                            parent, child, "DelegationRequest", BTreeMap::new()
                        ).is_err() {
                            let _ = ns.coord.destroy_session(child.clone());
                        }
                    }
                }
            }
            NetworkEvent::DelegationComplete { parent, child } => {
                let _ = ns.coord.finish_session(child);
                let _ = ns.coord.complete_delegation(parent, child);
                let _ = ns.coord.destroy_session(child.clone());
            }
            NetworkEvent::DelegationFailed { parent: _, child } => {
                let _ = ns.coord.session_failed(child);
            }
            NetworkEvent::HandoffRequested { src, dst } => {
                // Handoff: src must be SDone. Reset src to SIdle, start dst, update active_agent.
                let src_done = ns
                    .coord
                    .session(src)
                    .map(|s| s.status == crate::coordinator::SessionStatus::SDone)
                    .unwrap_or(false);
                if src_done
                    && ns.coord.reset_session(src).is_ok()
                        && ns.coord.start_processing(dst).is_ok() {
                            ns.active_agent = dst.clone();
                        }
            }
            NetworkEvent::HandoffComplete { .. } => {
                // State already updated by HandoffRequested — no-op.
            }
            NetworkEvent::AgentFailed { id } => {
                let _ = ns.coord.session_failed(id);
                if ns.active_agent == *id {
                    ns.active_agent = String::new();
                }
            }
        }
        ns
    }

    /// `network_generate` from NetworkSession.lean.
    /// Only events that need outbound work produce requests.
    fn generate(&self, _state: &NetworkState, event: &NetworkEvent) -> Vec<NetworkRequest> {
        match event {
            NetworkEvent::RegisterAgent { .. } => vec![],
            NetworkEvent::DelegationRequested { child, .. } => {
                vec![NetworkRequest::AgentRequest {
                    agent: child.clone(),
                }]
            }
            NetworkEvent::DelegationComplete { .. } => {
                // Spec: coordinator_generate DelegationComplete → [].
                vec![]
            }
            NetworkEvent::HandoffRequested { dst, .. } => {
                vec![NetworkRequest::AgentRequest { agent: dst.clone() }]
            }
            NetworkEvent::HandoffComplete { .. } => vec![],
            _ => vec![],
        }
    }

    fn event_tag(&self, event: &NetworkEvent) -> String {
        match event {
            NetworkEvent::RegisterAgent { id } => format!("RegisterAgent:{id}"),
            NetworkEvent::UserMessage { .. } => "UserMessage".into(),
            NetworkEvent::StartAgent { id } => format!("StartAgent:{id}"),
            NetworkEvent::AgentDone { id } => format!("AgentDone:{id}"),
            NetworkEvent::ResetAgent { id } => format!("ResetAgent:{id}"),
            NetworkEvent::DelegationRequested { parent, child } => {
                format!("DelegationRequested:{parent}:{child}")
            }
            NetworkEvent::DelegationComplete { parent, child } => {
                format!("DelegationComplete:{parent}:{child}")
            }
            NetworkEvent::DelegationFailed { parent, child } => {
                format!("DelegationFailed:{parent}:{child}")
            }
            NetworkEvent::HandoffRequested { src, dst } => format!("HandoffRequested:{src}:{dst}"),
            NetworkEvent::HandoffComplete { src, dst } => format!("HandoffComplete:{src}:{dst}"),
            NetworkEvent::AgentFailed { id } => format!("AgentFailed:{id}"),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Network session creation
// Spec: network.qnt network session loop
// ════════════════════════════════════════════════════════════════

use crate::unified_session::Session;

/// Build the network classify closure: extract agent name as key.
///
/// Network requests carry the agent name as their instance key.
/// This gives per-agent gating: two AgentRequest requests to different
/// agents are different pending keys ("AgentRequest:worker" vs "AgentRequest:backup").
///
/// Spec: network.qnt classify — instance_key_field: "agent".
pub fn network_classify_fn(request: &NetworkRequest) -> String {
    match request {
        NetworkRequest::AgentRequest { agent } => format!("AgentRequest:{agent}"),
        NetworkRequest::CollectAgentResult { agent } => format!("CollectAgentResult:{agent}"),
    }
}

/// Build the network classify_result closure: map completion events to inject keys.
///
/// DelegationComplete clears AgentRequest:child from pending.
/// HandoffComplete (if any) clears its own inject key.
///
/// Spec: network.qnt classify_result — maps result events to pending keys.
pub fn network_classify_result_fn(event: &NetworkEvent) -> Option<String> {
    match event {
        NetworkEvent::DelegationComplete { child, .. } => Some(format!("AgentRequest:{child}")),
        NetworkEvent::HandoffComplete { dst, .. } => Some(format!("AgentRequest:{dst}")),
        _ => None,
    }
}

/// Create a `Session<CoordinatorFold, NetworkConnectionState>` from a config.
///
/// 1. network_boot → NetworkConnectionState
/// 2. network_derive_routing → RoutingConfig
/// 3. Build NetworkState (agents, routes)
/// 4. Create Session
///
/// Spec: network.qnt network session loop.
/// Called by the runtime when creating a network session.
pub fn create_network_interpreter_session(
    config: &NetworkConfig,
) -> Result<Session<CoordinatorFold, NetworkConnectionState>, crate::network::NetworkError>
{
    // Spec: network.qnt network_boot → connection state
    let conn_state = network_boot(config);
    // Spec: network.qnt network_derive_routing → RoutingConfig
    let routing = network_derive_routing(&conn_state);

    let fold = CoordinatorFold {
        inbound_checks: config.inbound_checks.clone(),
        outbound_checks: config.outbound_checks.clone(),
    };

    let mut state = NetworkState::empty();

    // Only the entry point gets a session at boot (SIdle).
    // UserMessage will transition it to SProcessing.
    // Other agents are templates — sessions are created dynamically
    // by the coordinator's ephemeral path on DelegationRequested.
    if !config.entry_point.is_empty() {
        state.coord.spawn_session(config.entry_point.clone())?;
    }

    // Handoff routes connect pre-existing agents — spawn those too.
    // (Handoff targets need sessions; delegation targets don't.)
    for (src, dst) in &config.handoff_routes {
        if state.coord.session(src).is_none() {
            state.coord.spawn_session(src.clone())?;
        }
        if state.coord.session(dst).is_none() {
            state.coord.spawn_session(dst.clone())?;
        }
        state.coord.add_route(Route {
            src: src.clone(),
            dst: dst.clone(),
            request_type: "HandoffRequest".into(),
            result_type: "HandoffResult".into(),
        })?;
    }

    // Delegation routes: only pre-add routes where both endpoints
    // already have sessions (entry point, handoff targets).
    // Other delegation routes are created on demand by the
    // DelegationRequested handler (ephemeral path: spawn → route → delegate).
    for (src, dst) in &config.delegation_routes {
        if state.coord.session(src).is_some() && state.coord.session(dst).is_some() {
            let _ = state.coord.add_route(Route {
                src: src.clone(),
                dst: dst.clone(),
                request_type: "DelegationRequest".into(),
                result_type: "DelegationResult".into(),
            });
        }
    }

    state.active_agent = config.entry_point.clone();

    Ok(Session::new(fold, state, conn_state, routing))
}

/// Build a `Session<CoordinatorFold, NetworkConnectionState>` from a `NetworkConfig`.
///
/// Alias for `create_network_interpreter_session`.
/// Provided for backward compatibility with existing call sites.
pub fn from_config(
    config: &NetworkConfig,
) -> Result<Session<CoordinatorFold, NetworkConnectionState>, crate::network::NetworkError> {
    create_network_interpreter_session(config)
}

// ════════════════════════════════════════════════════════════════
// Tests
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use crate::coordinator::SessionStatus;
    use crate::generic_session_tree::{self, CheckVerdict, SessionTree};
    use crate::inner_fold::{DomainFold, KeyedPending};

    fn setup_network() -> (CoordinatorFold, NetworkState) {
        let fold = CoordinatorFold {
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let mut state = NetworkState::empty();
        state.coord.spawn_session("a".into()).unwrap();
        state.coord.spawn_session("b".into()).unwrap();
        state
            .coord
            .add_route(Route {
                src: "a".into(),
                dst: "b".into(),
                request_type: "DelegationRequest".into(),
                result_type: "DelegationResult".into(),
            })
            .unwrap();
        state.active_agent = "a".into();
        (fold, state)
    }

    // ── DomainFold projection tests ──────────────────────

    #[test]
    fn project_user_message_starts_active() {
        let (fold, state) = setup_network();
        let new_state = DomainFold::project(
            &fold,
            &state,
            &NetworkEvent::UserMessage { text: "hi".into() },
        );
        assert_eq!(
            new_state.coord.session("a").unwrap().status,
            SessionStatus::SProcessing,
        );
    }

    #[test]
    fn project_begin_deleg_spawns_child() {
        let (fold, mut state) = setup_network();
        state.coord.start_processing("a").unwrap();
        let new_state = DomainFold::project(
            &fold,
            &state,
            &NetworkEvent::DelegationRequested {
                parent: "a".into(),
                child: "b".into(),
            },
        );
        assert_eq!(
            new_state.coord.session("a").unwrap().status,
            SessionStatus::SWaitingDelegate,
        );
        assert_eq!(
            new_state.coord.session("b").unwrap().status,
            SessionStatus::SProcessing,
        );
    }

    #[test]
    fn generate_begin_deleg_injects_child() {
        let (fold, state) = setup_network();
        let reqs = DomainFold::generate(
            &fold,
            &state,
            &NetworkEvent::DelegationRequested {
                parent: "a".into(),
                child: "worker".into(),
            },
        );
        assert_eq!(
            reqs,
            vec![NetworkRequest::AgentRequest {
                agent: "worker".into()
            }]
        );
    }

    #[test]
    fn generate_end_deleg_is_empty() {
        let (fold, state) = setup_network();
        let reqs = DomainFold::generate(
            &fold,
            &state,
            &NetworkEvent::DelegationComplete {
                parent: "a".into(),
                child: "b".into(),
            },
        );
        assert_eq!(reqs, vec![], "DelegationComplete generates no requests per spec");
    }

    #[test]
    fn project_is_total_invalid_event_no_change() {
        let (fold, state) = setup_network();
        let new_state =
            DomainFold::project(&fold, &state, &NetworkEvent::AgentDone { id: "a".into() });
        assert_eq!(
            new_state.coord.session("a").unwrap().status,
            SessionStatus::SIdle,
        );
    }

    #[test]
    fn domain_fold_event_tag() {
        let (fold, _) = setup_network();
        let event = NetworkEvent::UserMessage { text: "hi".into() };
        assert_eq!(DomainFold::event_tag(&fold, &event), "UserMessage");
    }

    // ── Generic session tree integration ────────────────

    fn make_routing() -> crate::interpreter::RoutingConfig {
        // Empty routing for network — pending uses string keys from classify_fn
        let conn_state = NetworkConnectionState::empty();
        network_derive_routing(&conn_state)
    }

    fn flatten_network_tree(
        tree: SessionTree<NetworkState, NetworkRequest, NetworkEvent, NetworkDispatchResult>,
    ) -> (NetworkState, KeyedPending, usize) {
        match tree {
            SessionTree::Pure(out) => (out.state, out.pending, 0),
            SessionTree::Yield { output } => (output.state, output.pending, 0),
            SessionTree::Dispatch { request, cont, .. } => {
                let result = match &request {
                    NetworkRequest::AgentRequest { agent } => NetworkDispatchResult::AgentRequestComplete {
                        agent: agent.clone(),
                    },
                    NetworkRequest::CollectAgentResult { agent } => {
                        NetworkDispatchResult::AgentResultCollected {
                            agent: agent.clone(),
                        }
                    }
                };
                let next = cont(result);
                let (state, pending, count) = flatten_network_tree(next);
                (state, pending, count + 1)
            }
            SessionTree::Check { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_network_tree(next)
            }
            SessionTree::CheckEvent { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_network_tree(next)
            }
        }
    }

    #[test]
    fn generic_tree_delegation_lifecycle() {
        let (fold, mut state) = setup_network();
        state.coord.start_processing("a").unwrap();
        let routing = make_routing();
        let empty_pending: KeyedPending = vec![];

        // DelegationRequested(a → b) → AgentRequest(b)
        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "b".into(),
        };
        let tree = generic_session_tree::build_turn_tree(
            &fold, &routing, network_classify_fn, network_classify_result_fn,
            &state, &event, &empty_pending,
        );
        let (new_state, pending, dispatch_count) = flatten_network_tree(tree);

        assert_eq!(dispatch_count, 1);
        assert!(pending.contains(&"AgentRequest:b".to_string()));
        assert_eq!(
            new_state.coord.session("a").unwrap().status,
            SessionStatus::SWaitingDelegate,
        );

        // DelegationComplete(a, b) → clears AgentRequest:b from pending.
        let mut state2 = new_state.clone();
        state2.coord.finish_session("b").unwrap();
        let event2 = NetworkEvent::DelegationComplete {
            parent: "a".into(),
            child: "b".into(),
        };
        let tree2 = generic_session_tree::build_turn_tree(
            &fold, &routing, network_classify_fn, network_classify_result_fn,
            &state2, &event2, &pending,
        );
        let (_final_state, final_pending, dispatch_count2) = flatten_network_tree(tree2);

        assert_eq!(dispatch_count2, 0, "DelegationComplete generates no new requests");
        assert!(
            !final_pending.contains(&"AgentRequest:b".to_string()),
            "AgentRequest:b should be cleared"
        );
    }

    #[test]
    fn generic_tree_gates_duplicate_inject() {
        let (fold, mut state) = setup_network();
        state.coord.start_processing("a").unwrap();
        let routing = make_routing();
        let empty_pending: KeyedPending = vec![];

        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "worker".into(),
        };

        let tree = generic_session_tree::build_turn_tree(
            &fold, &routing, network_classify_fn, network_classify_result_fn,
            &state, &event, &empty_pending,
        );
        let (_, pending, count) = flatten_network_tree(tree);
        assert_eq!(count, 1);

        let tree2 = generic_session_tree::build_turn_tree(
            &fold, &routing, network_classify_fn, network_classify_result_fn,
            &state, &event, &pending,
        );
        let (_, _, count2) = flatten_network_tree(tree2);
        assert_eq!(count2, 0, "duplicate inject should be gated");
    }

    #[test]
    fn generic_tree_no_requests_is_pure() {
        let (fold, state) = setup_network();
        let routing = make_routing();
        let empty_pending: KeyedPending = vec![];
        let event = NetworkEvent::AgentDone { id: "a".into() };
        let tree = generic_session_tree::build_turn_tree(
            &fold, &routing, network_classify_fn, network_classify_result_fn,
            &state, &event, &empty_pending,
        );
        assert!(matches!(tree, SessionTree::Pure(_)));
    }

    // ════════════════════════════════════════════════════════════════
    // Network interpreter tests
    // Spec: network.qnt tests
    // ════════════════════════════════════════════════════════════════

    fn agent_conn(source_id: &str, result_type: &str) -> NetworkConnection {
        NetworkConnection {
            source_id: source_id.into(),
            request_type: "AgentRequest".into(),
            result_type: result_type.into(),
            has_check: false,
            check_source: String::new(),
            instance_key_field: "agent".into(),
        }
    }

    #[test]
    fn network_add_remove_connection_test() {
        let cs0 = NetworkConnectionState::empty();
        let conn_a = agent_conn("agent_a", "AgentResult");
        let cs1 = handle_network_config_event(&cs0, &NetworkConfigEvent::ConnectionAdded(conn_a));
        assert_eq!(cs1.connections.len(), 1);
        assert!(cs1.connections.contains_key("agent_a"));

        let conn_b = agent_conn("agent_b", "AgentResult");
        let cs2 = handle_network_config_event(&cs1, &NetworkConfigEvent::ConnectionAdded(conn_b));
        assert_eq!(cs2.connections.len(), 2);

        let cs3 = handle_network_config_event(
            &cs2,
            &NetworkConfigEvent::ConnectionRemoved("agent_a".into()),
        );
        assert_eq!(cs3.connections.len(), 1);
        assert!(!cs3.connections.contains_key("agent_a"));
        assert!(cs3.connections.contains_key("agent_b"));
    }

    #[test]
    fn network_derive_routing_test() {
        let cs0 = NetworkConnectionState::empty();
        let cs1 = handle_network_config_event(
            &cs0,
            &NetworkConfigEvent::ConnectionAdded(agent_conn("agent_a", "AgentResult")),
        );
        let cs2 = handle_network_config_event(
            &cs1,
            &NetworkConfigEvent::ConnectionAdded(agent_conn("agent_b", "AgentResult")),
        );
        let rc = network_derive_routing(&cs2);
        assert_eq!(rc.dispatch_rules.len(), 2);
        assert!(rc.outbound_checks.is_empty());
        assert!(rc.inbound_checks.is_empty());
        assert!(rc.dispatch_rules.iter().all(|r| r.request_type == "AgentRequest"));
    }

    #[test]
    fn resolve_network_source_test() {
        let cs0 = NetworkConnectionState::empty();
        let cs1 = handle_network_config_event(
            &cs0,
            &NetworkConfigEvent::ConnectionAdded(agent_conn("agent_a", "AgentResult")),
        );
        let sid = resolve_network_source(&cs1, "AgentRequest");
        assert_eq!(sid, "agent_a");
        let unknown = resolve_network_source(&cs1, "UnknownType");
        assert_eq!(unknown, "");
    }

    #[test]
    fn network_boot_delegation_test() {
        let config = NetworkConfig {
            agents: vec!["a".into(), "worker".into()],
            delegation_routes: vec![("a".into(), "worker".into())],
            handoff_routes: vec![],
            entry_point: "a".into(),
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let cs = network_boot(&config);
        assert!(cs.connections.contains_key("worker"));
        let conn = cs.connections.get("worker").unwrap();
        assert_eq!(conn.request_type, "AgentRequest");
        assert_eq!(conn.result_type, "AgentResult");
        assert_eq!(conn.instance_key_field, "agent");
    }

    #[test]
    fn network_boot_handoff_test() {
        let config = NetworkConfig {
            agents: vec!["a".into(), "b".into()],
            delegation_routes: vec![],
            handoff_routes: vec![("a".into(), "b".into())],
            entry_point: "a".into(),
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let cs = network_boot(&config);
        assert!(cs.connections.contains_key("b"));
        let conn = cs.connections.get("b").unwrap();
        assert_eq!(conn.request_type, "AgentRequest");
        assert_eq!(conn.result_type, "AgentResult");
        assert_eq!(conn.instance_key_field, "agent");
    }

    #[test]
    fn network_boot_routing_test() {
        let config = NetworkConfig {
            agents: vec!["a".into(), "worker".into()],
            delegation_routes: vec![("a".into(), "worker".into())],
            handoff_routes: vec![],
            entry_point: "a".into(),
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let cs = network_boot(&config);
        let rc = network_derive_routing(&cs);
        assert_eq!(rc.dispatch_rules.len(), 1);
        assert_eq!(rc.dispatch_rules[0].request_type, "AgentRequest");
        assert_eq!(rc.dispatch_rules[0].result_type, "AgentResult");
    }

    // ── network_classify_fn / classify_result_fn tests ────

    #[test]
    fn network_classify_fn_inject_event() {
        let req = NetworkRequest::AgentRequest { agent: "worker".into() };
        assert_eq!(network_classify_fn(&req), "AgentRequest:worker");
    }

    #[test]
    fn network_classify_fn_collect_result() {
        let req = NetworkRequest::CollectAgentResult { agent: "a".into() };
        assert_eq!(network_classify_fn(&req), "CollectAgentResult:a");
    }

    #[test]
    fn network_classify_result_fn_delegation_complete() {
        let event = NetworkEvent::DelegationComplete {
            parent: "a".into(),
            child: "worker".into(),
        };
        assert_eq!(
            network_classify_result_fn(&event),
            Some("AgentRequest:worker".into())
        );
    }

    #[test]
    fn network_classify_result_fn_user_message_is_none() {
        let event = NetworkEvent::UserMessage { text: "hi".into() };
        assert_eq!(network_classify_result_fn(&event), None);
    }

    // ── Session network tests (Task 5.4) ──────────────────

    fn delegation_config() -> NetworkConfig {
        NetworkConfig {
            agents: vec!["a".into(), "worker".into()],
            delegation_routes: vec![("a".into(), "worker".into())],
            handoff_routes: vec![],
            entry_point: "a".into(),
            inbound_checks: vec![],
            outbound_checks: vec![],
        }
    }

    #[test]
    fn network_session_delegation_dispatch() {
        let config = delegation_config();
        let mut session = create_network_interpreter_session(&config).unwrap();
        // UserMessage transitions entry point from SIdle → SProcessing.
        session.fold_event(
            &NetworkEvent::UserMessage { text: "hi".into() },
            network_classify_fn,
            network_classify_result_fn,
        );

        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "worker".into(),
        };
        let result = session.fold_event(&event, network_classify_fn, network_classify_result_fn);

        assert_eq!(result.requests.len(), 1);
        assert!(matches!(
            &result.requests[0],
            crate::unified_session::ClassifiedRequest::Dispatch(NetworkRequest::AgentRequest { agent })
            if agent == "worker"
        ));
        assert!(!session.is_idle());
        assert!(session.pending().contains(&"AgentRequest:worker".into()));
    }

    #[test]
    fn network_session_clear_pending_on_delegation_complete() {
        let config = delegation_config();
        let mut session = create_network_interpreter_session(&config).unwrap();
        // UserMessage transitions entry point from SIdle → SProcessing.
        session.fold_event(
            &NetworkEvent::UserMessage { text: "hi".into() },
            network_classify_fn,
            network_classify_result_fn,
        );

        session.fold_event(
            &NetworkEvent::DelegationRequested {
                parent: "a".into(),
                child: "worker".into(),
            },
            network_classify_fn,
            network_classify_result_fn,
        );
        assert!(session.pending().contains(&"AgentRequest:worker".into()));

        session.fold_event(
            &NetworkEvent::DelegationComplete {
                parent: "a".into(),
                child: "worker".into(),
            },
            network_classify_fn,
            network_classify_result_fn,
        );
        assert!(
            !session.pending().contains(&"AgentRequest:worker".into()),
            "AgentRequest:worker should be cleared"
        );
    }

    #[test]
    fn network_session_gates_duplicate_injection() {
        let config = delegation_config();
        let mut session = create_network_interpreter_session(&config).unwrap();
        // UserMessage transitions entry point from SIdle → SProcessing.
        session.fold_event(
            &NetworkEvent::UserMessage { text: "hi".into() },
            network_classify_fn,
            network_classify_result_fn,
        );

        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "worker".into(),
        };

        let r1 = session.fold_event(&event, network_classify_fn, network_classify_result_fn);
        assert_eq!(r1.requests.len(), 1);

        let r2 = session.fold_event(&event, network_classify_fn, network_classify_result_fn);
        assert_eq!(r2.requests.len(), 0, "duplicate inject should be gated");
    }

    #[test]
    fn network_session_config_event_updates_routing() {
        let config = NetworkConfig {
            agents: vec!["a".into()],
            delegation_routes: vec![],
            handoff_routes: vec![],
            entry_point: "a".into(),
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let mut session = create_network_interpreter_session(&config).unwrap();
        assert!(session.routing.dispatch_rules.is_empty());

        let new_conn = NetworkConnection {
            source_id: "worker".into(),
            request_type: "AgentRequest".into(),
            result_type: "AgentResult".into(),
            has_check: false,
            check_source: String::new(),
            instance_key_field: "agent".into(),
        };
        session.receive_config_event(
            NetworkConfigEvent::ConnectionAdded(new_conn),
            |cs, ev| handle_network_config_event(cs, &ev),
            |cs| network_derive_routing(cs),
        );

        assert_eq!(session.routing.dispatch_rules.len(), 1);
        assert_eq!(
            session.routing.dispatch_rules[0].request_type,
            "AgentRequest"
        );
    }
}
