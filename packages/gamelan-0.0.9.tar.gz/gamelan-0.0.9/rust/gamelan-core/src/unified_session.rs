//! Session — the universal execution unit.
//!
//! One type, generic over `DomainFold` and connection state `CS`.
//! Agent sessions and network sessions are the same struct with
//! different fold + connection state implementations.
//!
//! From the model:
//! > A session is a fold over events. Events arrive in a mailbox.
//! > Pure functions process them, updating state and emitting requests.
//!
//! The session tree handles gate, pending, checks — identical for both.

use crate::generic_session_tree::{self, CheckVerdict, SessionTree};
use crate::inner_fold::{DomainFold, KeyedPending};
use crate::interpreter::{self as interp, RoutingConfig};
use crate::prelude::*;

// ════════════════════════════════════════════════════════════════
// Check info — returned by check_inbound
// ════════════════════════════════════════════════════════════════

/// Info about a check needed before folding.
#[derive(Debug, Clone)]
pub struct CheckInfo {
    /// The event tag that triggered the check.
    pub event_tag: String,
    /// The source that performs the check.
    pub check_source: String,
    /// The full event data. Populated by the runner (the session returns
    /// tag + source only; the runner adds the data it already holds).
    pub event_data: alloc::collections::BTreeMap<String, crate::types::Value>,
}

// ════════════════════════════════════════════════════════════════
// Classified request — what fold_event returns
// ════════════════════════════════════════════════════════════════

/// What to do with each request from the fold.
#[derive(Debug, Clone)]
pub enum ClassifiedRequest<R> {
    /// Dispatch directly (unchecked connection).
    Dispatch(R),
    /// Check first, then dispatch if approved.
    CheckThenDispatch { request: R, check_source: String },
}

/// Result of folding one event.
#[derive(Debug, Clone)]
pub struct FoldResult<R: Clone> {
    /// Classified requests for the host to walk.
    pub requests: Vec<ClassifiedRequest<R>>,
}

// ════════════════════════════════════════════════════════════════
// Session — the universal execution unit
//
// Uses DomainFold + RoutingConfig + KeyedPending.
// Holds connection state (CS) and routing derived from it.
//
// Spec: agent.qnt + network.qnt session loop state
// ════════════════════════════════════════════════════════════════

/// The universal execution unit. Generic over `DomainFold` and connection state `CS`.
///
/// CS is the connection state type (AgentConnectionState or NetworkConnectionState).
/// It is updated by `receive_config_event` and re-derives routing on each update.
///
/// Agent sessions and network sessions are the same type with different fold
/// and connection state implementations.
///
/// Spec: agent.qnt + network.qnt session loop state.
pub struct Session<F, CS>
where
    F: DomainFold,
    CS: Clone,
{
    /// The domain fold (config, not state). Implements project + generate.
    pub fold: F,
    /// The fold's state. Updated by fold_event.
    pub state: F::State,
    /// Connection state. Updated by receive_config_event.
    pub conn_state: CS,
    /// Routing config derived from conn_state. Rebuilt on config events.
    pub routing: RoutingConfig,
    /// String-keyed pending set: requests currently in flight.
    pending: KeyedPending,
    /// Total events processed.
    events_processed: usize,
    /// Event log (tags). Source of truth for replay.
    event_log: Vec<String>,
}

impl<F, CS> Session<F, CS>
where
    F: DomainFold + Clone + 'static,
    F::State: Clone + 'static,
    F::Request: Clone + 'static,
    F::Event: Clone + 'static,
    F::DispatchResult: Default + 'static,
    CS: Clone,
{
    /// Create a new session.
    pub fn new(fold: F, initial_state: F::State, conn_state: CS, routing: RoutingConfig) -> Self {
        Session {
            fold,
            state: initial_state,
            conn_state,
            routing,
            pending: Vec::new(),
            events_processed: 0,
            event_log: Vec::new(),
        }
    }

    /// Restore a session from a persisted snapshot.
    ///
    /// Used when resuming a session after crash recovery or migration.
    /// The `pending` and `events_processed` come from the stored `Snapshot`.
    /// The `event_log_tags` are the event tags seen so far (for log reconstruction).
    pub fn restore(
        fold: F,
        restored_state: F::State,
        conn_state: CS,
        routing: RoutingConfig,
        pending: KeyedPending,
        events_processed: usize,
        event_log_tags: Vec<String>,
    ) -> Self {
        Session {
            fold,
            state: restored_state,
            conn_state,
            routing,
            pending,
            events_processed,
            event_log: event_log_tags,
        }
    }

    // ── Queries ──────────────────────────────────────────

    /// Is the session quiescent? No pending requests.
    pub fn is_idle(&self) -> bool {
        self.pending.is_empty()
    }

    /// Total events processed.
    pub fn events_processed(&self) -> usize {
        self.events_processed
    }

    /// Event log (tags).
    pub fn event_log(&self) -> &[String] {
        &self.event_log
    }

    /// Current pending keys.
    pub fn pending(&self) -> &KeyedPending {
        &self.pending
    }

    /// Append a tag to the event log. Used by the runner for config events
    /// that don't go through fold_event.
    pub fn log_tag(&mut self, tag: String) {
        self.event_log.push(tag);
        self.events_processed += 1;
    }

    // ── Turn operations ─────────────────────────────────

    /// Does this event need an inbound check before folding?
    ///
    /// Uses RoutingConfig.inbound_checks — pure query, no state change.
    /// Call before `fold_event`.
    ///
    /// Spec: routing.inbound_checks lookup via needs_inbound_check helper.
    pub fn check_inbound(&self, event: &F::Event) -> Option<CheckInfo> {
        let tag = self.fold.event_tag(event);
        interp::needs_inbound_check(&self.routing, &tag).map(|check_source| CheckInfo {
            event_tag: tag,
            check_source,
            event_data: alloc::collections::BTreeMap::new(),
        })
    }

    /// Fold one event through the session tree.
    ///
    /// Uses `build_turn_tree` with RoutingConfig and classify closures.
    /// The classify closures are provided by the caller so this method can
    /// work with any DomainFold.
    ///
    /// Integration: called from agent_fold (create_agent_interpreter_session)
    /// and coordinator_fold (create_network_interpreter_session).
    pub fn fold_event<CF, CRF>(
        &mut self,
        event: &F::Event,
        classify_fn: CF,
        classify_result_fn: CRF,
    ) -> FoldResult<F::Request>
    where
        CF: Fn(&F::Request) -> String + Clone + 'static,
        CRF: Fn(&F::Event) -> Option<String> + Clone + 'static,
    {
        let tree = generic_session_tree::build_turn_tree(
            &self.fold,
            &self.routing,
            classify_fn,
            classify_result_fn,
            &self.state,
            event,
            &self.pending,
        );

        let (new_state, new_pending, requests) = flatten_tree::<F>(tree);

        self.state = new_state;
        self.pending = new_pending;
        self.events_processed += 1;
        self.event_log.push(self.fold.event_tag(event));

        FoldResult { requests }
    }

    /// Receive a config event — update connection state and re-derive routing.
    ///
    /// The handler closure transitions conn_state → new_conn_state.
    /// The derive closure rebuilds routing from the new conn_state.
    ///
    /// Spec: session loop receives AgentConfigEvent / NetworkConfigEvent,
    /// updates connection state, re-derives routing, emits RuntimeEffects.
    ///
    /// Should only be called when session is idle (between turns).
    pub fn receive_config_event<E, H, D>(&mut self, event: E, handler: H, derive: D)
    where
        H: FnOnce(&CS, E) -> CS,
        D: FnOnce(&CS) -> RoutingConfig,
    {
        let new_conn_state = handler(&self.conn_state, event);
        let new_routing = derive(&new_conn_state);
        self.conn_state = new_conn_state;
        self.routing = new_routing;
    }

    /// Cancel a pending request by key.
    ///
    /// Called when an outbound check rejects a request. Removes the key
    /// from pending so the gate opens again for that key.
    ///
    /// Spec: keyed pending removal.
    pub fn cancel_request(&mut self, key: &str) {
        self.pending.retain(|k| k.as_str() != key);
    }

    /// Record that an inbound-checked event was rejected (not folded).
    ///
    /// Increments events_processed and appends a rejection tag to event_log.
    pub fn skip_inbound(&mut self, event: &F::Event) {
        self.events_processed += 1;
        self.event_log
            .push(format!("{}:rejected", self.fold.event_tag(event)));
    }
}

// ════════════════════════════════════════════════════════════════
// Flatten — walk keyed tree, collect classified requests
// ════════════════════════════════════════════════════════════════

fn flatten_tree<F: DomainFold>(
    tree: SessionTree<F::State, F::Request, F::Event, F::DispatchResult>,
) -> (F::State, KeyedPending, Vec<ClassifiedRequest<F::Request>>)
where
    F::State: Clone,
    F::Request: Clone,
    F::DispatchResult: Default,
{
    let mut requests = Vec::new();
    flatten_walk::<F>(tree, &mut requests)
}

fn flatten_walk<F: DomainFold>(
    node: SessionTree<F::State, F::Request, F::Event, F::DispatchResult>,
    requests: &mut Vec<ClassifiedRequest<F::Request>>,
) -> (F::State, KeyedPending, Vec<ClassifiedRequest<F::Request>>)
where
    F::State: Clone,
    F::Request: Clone,
    F::DispatchResult: Default,
{
    match node {
        SessionTree::Pure(out) => (out.state, out.pending, requests.clone()),
        SessionTree::Yield { output } => (output.state, output.pending, requests.clone()),
        SessionTree::Dispatch { request, cont } => {
            requests.push(ClassifiedRequest::Dispatch(request));
            let next = cont(F::DispatchResult::default());
            flatten_walk::<F>(next, requests)
        }
        SessionTree::Check {
            request,
            check_source,
            cont,
        } => {
            requests.push(ClassifiedRequest::CheckThenDispatch {
                request: request.clone(),
                check_source,
            });
            let next = cont(CheckVerdict::Approve);
            skip_approved_dispatch::<F>(next, requests)
        }
        SessionTree::CheckEvent { cont, .. } => {
            let next = cont(CheckVerdict::Approve);
            flatten_walk::<F>(next, requests)
        }
    }
}

fn skip_approved_dispatch<F: DomainFold>(
    node: SessionTree<F::State, F::Request, F::Event, F::DispatchResult>,
    requests: &mut Vec<ClassifiedRequest<F::Request>>,
) -> (F::State, KeyedPending, Vec<ClassifiedRequest<F::Request>>)
where
    F::State: Clone,
    F::Request: Clone,
    F::DispatchResult: Default,
{
    match node {
        SessionTree::Dispatch { cont, .. } => {
            let next = cont(F::DispatchResult::default());
            flatten_walk::<F>(next, requests)
        }
        other => flatten_walk::<F>(other, requests),
    }
}

// ════════════════════════════════════════════════════════════════
// Tests
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent_fold::{
        AgentConnectionState, AgentEvent, AgentFold, agent_boot, agent_classify_fn,
        agent_classify_result_fn, agent_derive_routing, create_agent_interpreter_session,
    };
    use crate::agent_fold::{ConnectionDef, SourcePair, SourceRegistration};
    use crate::coordinator_fold::{
        CoordinatorFold, NetworkConnectionState, NetworkEvent, NetworkRequest, NetworkState,
        network_classify_fn, network_classify_result_fn,
    };
    use crate::coordinator::Route;
    use crate::types::*;
    use alloc::collections::BTreeMap;

    // ── Agent session helpers ────────────────────────────

    fn agent_fold_simple() -> AgentFold {
        AgentFold {
            transducers: vec![TransducerDef {
                name: "producer".into(),
                slots: vec![SlotDef {
                    name: "count".into(),
                    initial: Value::Int(0),
                }],
                rules: vec![Rule {
                    on: "Input".into(),
                    guard: Expr::Lit {
                        value: Value::Bool(true),
                    },
                    updates: vec![Update {
                        slot: "count".into(),
                        expr: Expr::Add {
                            left: Box::new(Expr::Ref {
                                name: "count".into(),
                            }),
                            right: Box::new(Expr::Lit {
                                value: Value::Int(1),
                            }),
                        },
                    }],
                    emits: vec![Expr::Rec {
                        fields: vec![RecField {
                            key: "type".into(),
                            val_expr: Expr::Lit {
                                value: Value::Str("WorkRequest".into()),
                            },
                        }],
                    }],
                }],
            }],
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: false,
                check_source: None,
            }],
            inbound_checks: vec![],
        }
    }

    fn make_agent_session() -> Session<AgentFold, AgentConnectionState> {
        let fold = agent_fold_simple();
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let conn_state = agent_boot(&sources, &[]);
        let routing = agent_derive_routing(&conn_state);
        Session::new(fold, env, conn_state, routing)
    }

    fn fold_agent(
        s: &mut Session<AgentFold, AgentConnectionState>,
        event: &AgentEvent,
    ) -> FoldResult<Value> {
        let routing = s.routing.clone();
        s.fold_event(
            event,
            agent_classify_fn,
            agent_classify_result_fn(&routing),
        )
    }

    // ── Agent session tests ─────────────────────────────

    #[test]
    fn agent_fold_produces_dispatch() {
        let mut s = make_agent_session();
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        let result = fold_agent(&mut s, &event);
        assert_eq!(result.requests.len(), 1);
        assert!(matches!(
            &result.requests[0],
            ClassifiedRequest::Dispatch(_)
        ));
        assert!(!s.is_idle());
    }

    #[test]
    fn agent_result_clears_pending() {
        let mut s = make_agent_session();
        fold_agent(&mut s, &AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        });
        assert!(!s.is_idle());
        fold_agent(&mut s, &AgentEvent {
            tag: "WorkResult".into(),
            data: BTreeMap::new(),
        });
        assert!(s.is_idle());
    }

    #[test]
    fn agent_gates_while_pending() {
        let mut s = make_agent_session();
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        let r1 = fold_agent(&mut s, &event);
        assert_eq!(r1.requests.len(), 1);
        let r2 = fold_agent(&mut s, &event);
        assert_eq!(r2.requests.len(), 0); // gated
        assert_eq!(s.state.get("count"), Some(&Value::Int(2))); // fold still ran
    }

    #[test]
    fn agent_event_log_tracks() {
        let mut s = make_agent_session();
        fold_agent(&mut s, &AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        });
        fold_agent(&mut s, &AgentEvent {
            tag: "WorkResult".into(),
            data: BTreeMap::new(),
        });
        assert_eq!(s.event_log(), &["Input", "WorkResult"]);
        assert_eq!(s.events_processed(), 2);
    }

    // ── Network session tests ───────────────────────────

    fn network_fold_and_state() -> (CoordinatorFold, NetworkState) {
        let fold = CoordinatorFold {
            inbound_checks: vec![],
            outbound_checks: vec![],
        };
        let mut state = NetworkState::empty();
        state.coord.spawn_session("a".into()).unwrap();
        state.coord.spawn_session("b".into()).unwrap();
        state
            .coord
            .add_route(Route {
                src: "a".into(),
                dst: "b".into(),
                request_type: "DelegationRequest".into(),
                result_type: "DelegationResult".into(),
            })
            .unwrap();
        state.active_agent = "a".into();
        (fold, state)
    }

    fn make_network_session() -> Session<CoordinatorFold, NetworkConnectionState> {
        let (fold, state) = network_fold_and_state();
        let conn_state = NetworkConnectionState::empty();
        let routing = crate::coordinator_fold::network_derive_routing(&conn_state);
        Session::new(fold, state, conn_state, routing)
    }

    fn fold_network(
        s: &mut Session<CoordinatorFold, NetworkConnectionState>,
        event: &NetworkEvent,
    ) -> FoldResult<NetworkRequest> {
        s.fold_event(event, network_classify_fn, network_classify_result_fn)
    }

    #[test]
    fn network_delegation_produces_inject() {
        let (fold, mut state) = network_fold_and_state();
        state.coord.start_processing("a").unwrap();
        let conn_state = NetworkConnectionState::empty();
        let routing = crate::coordinator_fold::network_derive_routing(&conn_state);
        let mut s = Session::new(fold, state, conn_state, routing);

        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "worker".into(),
        };
        let result = fold_network(&mut s, &event);
        assert_eq!(result.requests.len(), 1);
        assert!(matches!(&result.requests[0],
            ClassifiedRequest::Dispatch(NetworkRequest::AgentRequest { agent })
            if agent == "worker"
        ));
        assert!(!s.is_idle()); // AgentRequest pending
    }

    #[test]
    fn network_gates_duplicate_inject() {
        let (fold, mut state) = network_fold_and_state();
        state.coord.start_processing("a").unwrap();
        let conn_state = NetworkConnectionState::empty();
        let routing = crate::coordinator_fold::network_derive_routing(&conn_state);
        let mut s: Session<CoordinatorFold, NetworkConnectionState> =
            Session::new(fold, state, conn_state, routing);

        let event = NetworkEvent::DelegationRequested {
            parent: "a".into(),
            child: "worker".into(),
        };
        let r1 = fold_network(&mut s, &event);
        assert_eq!(r1.requests.len(), 1);
        let r2 = fold_network(&mut s, &event);
        assert_eq!(r2.requests.len(), 0); // gated
    }

    #[test]
    fn network_event_log_tracks() {
        let mut s = make_network_session();

        fold_network(&mut s, &NetworkEvent::UserMessage { text: "hi".into() });
        assert_eq!(s.events_processed(), 1);
        assert_eq!(s.event_log().len(), 1);
    }

    // ── create_agent_interpreter_session tests ─────────────────

    #[test]
    fn create_agent_session_folds_event() {
        let fold = agent_fold_simple();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut s = create_agent_interpreter_session(fold, env, &sources, &[]);
        let routing = s.routing.clone();
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        let result = s.fold_event(&event, agent_classify_fn, agent_classify_result_fn(&routing));
        assert_eq!(result.requests.len(), 1);
        assert!(!s.is_idle());
    }

    #[test]
    fn session_skip_inbound_records_rejection() {
        let mut s = make_agent_session();
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        s.skip_inbound(&event);
        assert_eq!(s.events_processed(), 1);
        assert_eq!(s.event_log(), &["Input:rejected"]);
        assert!(s.is_idle());
    }

    #[test]
    fn session_cancel_request_removes_key() {
        let mut s = make_agent_session();
        let event = AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        };
        fold_agent(&mut s, &event);
        assert!(!s.is_idle());
        s.cancel_request("WorkRequest");
        assert!(s.is_idle());
    }
}
