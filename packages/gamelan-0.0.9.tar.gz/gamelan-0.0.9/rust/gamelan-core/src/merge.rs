//! Merge operator — compose two TransducerDefs into one.
//!
//! Maps from TransducerVM.v merge_td and Composition_Merge.v.
//! Merge concatenates slots and rules. Proved properties:
//! - merge_equiv_session: merged td = sequential execution
//! - merge_assoc: merge is associative
//!
//! Slot conflicts are detected and returned as errors.
//! After merge, the result can be typechecked and validated as one unit.

use crate::prelude::*;
use crate::types::TransducerDef;

/// Errors from merging transducers.
#[derive(Debug, Clone, PartialEq)]
pub enum MergeError {
    /// Two transducers declare the same slot name.
    SlotConflict {
        slot: String,
        transducer_a: String,
        transducer_b: String,
    },
}

/// Merge two TransducerDefs into one.
/// Concatenates slots and rules. Rejects slot name conflicts.
pub fn merge(a: &TransducerDef, b: &TransducerDef) -> Result<TransducerDef, MergeError> {
    // Check slot disjointness
    for sa in &a.slots {
        for sb in &b.slots {
            if sa.name == sb.name {
                return Err(MergeError::SlotConflict {
                    slot: sa.name.clone(),
                    transducer_a: a.name.clone(),
                    transducer_b: b.name.clone(),
                });
            }
        }
    }

    let mut slots = a.slots.clone();
    slots.extend(b.slots.iter().cloned());

    let mut rules = a.rules.clone();
    rules.extend(b.rules.iter().cloned());

    Ok(TransducerDef {
        name: format!("{}+{}", a.name, b.name),
        slots,
        rules,
    })
}

/// Merge a list of TransducerDefs into one.
/// Left fold: merge(merge(merge(a, b), c), d).
pub fn merge_all(tds: &[TransducerDef]) -> Result<TransducerDef, MergeError> {
    match tds {
        [] => Ok(TransducerDef {
            name: String::new(),
            slots: vec![],
            rules: vec![],
        }),
        [first] => Ok(first.clone()),
        [first, rest @ ..] => {
            let mut acc = first.clone();
            for td in rest {
                acc = merge(&acc, td)?;
            }
            Ok(acc)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::*;

    fn simple_td(name: &str, slot: &str) -> TransducerDef {
        TransducerDef {
            name: name.into(),
            slots: vec![SlotDef {
                name: slot.into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: slot.into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref { name: slot.into() }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        }
    }

    #[test]
    fn merge_disjoint_succeeds() {
        let a = simple_td("a", "x");
        let b = simple_td("b", "y");
        let merged = merge(&a, &b).unwrap();
        assert_eq!(merged.slots.len(), 2);
        assert_eq!(merged.rules.len(), 2);
    }

    #[test]
    fn merge_conflict_rejected() {
        let a = simple_td("a", "shared");
        let b = simple_td("b", "shared");
        let result = merge(&a, &b);
        assert!(matches!(result, Err(MergeError::SlotConflict { .. })));
    }

    #[test]
    fn merge_equiv_sequential() {
        // merge_equiv_session: merged td produces same result as sequential exec
        let a = simple_td("a", "x");
        let b = simple_td("b", "y");
        let merged = merge(&a, &b).unwrap();

        let env = crate::loader::init_env(&[a.clone(), b.clone()]);
        let event_data = Env::new();

        // Sequential
        let r1 = crate::vm::exec_transducer(&a, &env, "Input", &event_data);
        let r2 = crate::vm::exec_transducer(&b, &r1.state, "Input", &event_data);

        // Merged
        let rm = crate::vm::exec_transducer(&merged, &env, "Input", &event_data);

        // State should match
        assert_eq!(rm.state.get("x"), r2.state.get("x"));
        assert_eq!(rm.state.get("y"), r2.state.get("y"));

        // Emits should match (concatenated)
        let mut sequential_emits = r1.emitted.clone();
        sequential_emits.extend(r2.emitted.iter().cloned());
        assert_eq!(rm.emitted, sequential_emits);
    }

    #[test]
    fn merge_assoc() {
        // merge_assoc: (a + b) + c = a + (b + c)
        let a = simple_td("a", "x");
        let b = simple_td("b", "y");
        let c = simple_td("c", "z");

        let ab_c = merge(&merge(&a, &b).unwrap(), &c).unwrap();
        let a_bc = merge(&a, &merge(&b, &c).unwrap()).unwrap();

        let env = crate::loader::init_env(&[a, b, c]);
        let event_data = Env::new();

        let r1 = crate::vm::exec_transducer(&ab_c, &env, "Input", &event_data);
        let r2 = crate::vm::exec_transducer(&a_bc, &env, "Input", &event_data);

        assert_eq!(r1.state, r2.state);
        assert_eq!(r1.emitted, r2.emitted);
    }

    #[test]
    fn merge_identity() {
        // Empty transducer is identity element
        let a = simple_td("a", "x");
        let empty = TransducerDef {
            name: String::new(),
            slots: vec![],
            rules: vec![],
        };

        let merged = merge(&a, &empty).unwrap();
        let env = crate::loader::init_env(&[a.clone()]);
        let event_data = Env::new();

        let r_orig = crate::vm::exec_transducer(&a, &env, "Input", &event_data);
        let r_merged = crate::vm::exec_transducer(&merged, &env, "Input", &event_data);

        assert_eq!(r_orig.state.get("x"), r_merged.state.get("x"));
        assert_eq!(r_orig.emitted, r_merged.emitted);
    }

    #[test]
    fn merge_all_stdlib() {
        let tds = crate::stdlib::stdlib();
        let merged = merge_all(&tds).unwrap();
        assert_eq!(
            merged.slots.len(),
            tds.iter().map(|td| td.slots.len()).sum::<usize>()
        );
        assert_eq!(
            merged.rules.len(),
            tds.iter().map(|td| td.rules.len()).sum::<usize>()
        );
    }

    #[test]
    fn merge_all_empty() {
        let merged = merge_all(&[]).unwrap();
        assert!(merged.slots.is_empty());
        assert!(merged.rules.is_empty());
    }
}
