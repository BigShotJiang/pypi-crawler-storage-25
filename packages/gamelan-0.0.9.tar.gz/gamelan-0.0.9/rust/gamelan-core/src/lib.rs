//! gamelan-core — formally verified kernel for agent systems.
//!
//! Pure functions over data. No I/O, no async, no runtime. Core owns the
//! model — the runtime binds it to an execution model.
//!
//! # Architecture
//!
//! One `Session<F: DomainFold, CS>` type for everything. Agent sessions and
//! network sessions are the same struct with different fold implementations.
//! Routing config is derived from connection state (CS), not embedded in the
//! fold. The session tree handles gate, pending, checks — identical for both.
//!
//! Aligned with Lean proofs (SessionMonad.lean, Coordinator.lean,
//! NetworkSession.lean). The `DomainFold` trait defines pure state + request
//! semantics (project + generate); routing lives in `RoutingConfig`.

#![no_std]
extern crate alloc;

/// Prelude for no_std: re-export alloc types that std normally provides.
mod prelude {
    pub use alloc::boxed::Box;
    pub use alloc::format;
    pub use alloc::string::{String, ToString};
    pub use alloc::vec;
    pub use alloc::vec::Vec;
}

// ── Proved kernel (Lean-backed) ───────────────────────────
pub mod kernel;

// Re-export kernel modules at crate root for backwards compatibility.
// External code uses `gamelan_core::vm`, `gamelan_core::types`, etc.
pub use kernel::coordinator;
pub use kernel::dependency;
pub use kernel::expand;
pub use kernel::interpreter;
pub use kernel::network;
pub use kernel::typecheck;
pub use kernel::types;
pub use kernel::vm;

// ── SDK-facing session machinery ──────────────────────────
pub mod loader;
pub mod merge;
#[cfg(feature = "std")]
pub mod serde;
pub mod session;
pub mod session_def;
#[cfg(feature = "std")]
pub mod stdlib;
#[cfg(feature = "std")]
mod stdlib_tests;

// ── The unified session model ──────────────────────────────
pub mod agent_fold;
pub mod coordinator_fold;
pub mod generic_session_tree;
pub mod inner_fold;
pub mod unified_session;

// ── Re-exports ─────────────────────────────────────────────

pub use agent_fold::{
    CheckVerdict, ConnectionDef, FoldResult, InboundCheckDef, Pending, RequestAction, Topology,
    TurnResult,
};
pub use coordinator::{
    CoordinatedSession, Coordinator, CoordinatorError, DelegationEdge, Effect, MAX_STEPS, Route,
    SessionStatus,
};
pub use network::{NetworkCheckDef, NetworkConfig, NetworkError};
pub use session::{EventRecord, SessionConfig, SessionState, Snapshot, create, replay, resume};
pub use session_def::{
    CheckDef, ConnectionSpec, LoadResult, SessionDef, SourcePairDef, ValidationError, load,
    validate, validate_strict,
};
pub use agent_fold::{
    InboundCheckConfig, OutboundCheckConfig, SourcePair, SourceRegistration, derive_inbound_checks,
    derive_topology, resolve_source,
};
pub use types::{Expr, Rule, SlotDef, TransducerDef, Update, Value};

// Unified session types
pub use agent_fold::{
    AgentDispatchResult, AgentEvent, AgentFold, ContextBlock, SessionCreated,
    handle_session_created,
};
pub use coordinator_fold::{
    CoordinatorFold, NetworkDispatchResult, NetworkEvent, NetworkRequest, NetworkState,
    NetworkSessionCreated, handle_network_session_created,
    from_config as network_session_from_config,
};
pub use unified_session::{CheckInfo, ClassifiedRequest, FoldResult as SessionFoldResult, Session};
