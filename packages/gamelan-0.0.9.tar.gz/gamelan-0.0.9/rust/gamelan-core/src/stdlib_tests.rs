//! Behavioral tests for stdlib transducers.
//!
//! Feed realistic event sequences (UserMessage, LlmResponse, ToolResult)
//! through the actual stdlib transducers and verify state + emits.

#[cfg(test)]
mod tests {
    extern crate alloc;
    use alloc::collections::BTreeMap;
    use alloc::string::ToString;
    use alloc::vec;
    use alloc::vec::Vec;

    use crate::loader::init_env;
    use crate::stdlib::stdlib;
    use crate::types::{Env, Value};
    use crate::vm::exec_session;

    // ── Helpers ──────────────────────────────────────────────────

    /// Build event data from key-value pairs.
    fn event_data(pairs: &[(&str, Value)]) -> Env {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }

    /// Build a text part.
    fn text_part(text: &str) -> Value {
        let mut m = BTreeMap::new();
        m.insert("kind".into(), Value::Str("text".into()));
        m.insert("text".into(), Value::Str(text.into()));
        Value::Map(m)
    }

    /// Build a tool call entry (as it appears in tool_calls array).
    fn tool_call(id: &str, name: &str, args: &str) -> Value {
        let mut m = BTreeMap::new();
        m.insert("id".into(), Value::Str(id.into()));
        m.insert("name".into(), Value::Str(name.into()));
        m.insert("arguments".into(), Value::Str(args.into()));
        Value::Map(m)
    }

    /// Feed an event through all stdlib transducers, return new state + emits.
    fn feed(tds: &[crate::types::TransducerDef], state: &Env, tag: &str, data: &Env) -> (Env, Vec<Value>) {
        let r = exec_session(tds, state, tag, data);
        (r.state, r.emitted)
    }

    /// Get the messages list from state.
    fn get_messages(state: &Env) -> &[Value] {
        state
            .get("messages")
            .and_then(|v| v.as_list())
            .unwrap_or(&[])
    }

    /// Get pending_tools count from state.
    fn get_pending_tools(state: &Env) -> i64 {
        state
            .get("pending_tools")
            .and_then(|v| v.as_int())
            .unwrap_or(0)
    }

    /// Get input_tokens from state.
    fn get_input_tokens(state: &Env) -> i64 {
        state
            .get("input_tokens")
            .and_then(|v| v.as_int())
            .unwrap_or(0)
    }

    /// Get output_tokens from state.
    fn get_output_tokens(state: &Env) -> i64 {
        state
            .get("output_tokens")
            .and_then(|v| v.as_int())
            .unwrap_or(0)
    }

    /// Check if an emitted value has a given type field.
    fn emitted_has_type(emitted: &[Value], ty: &str) -> bool {
        emitted.iter().any(|v| {
            v.as_map()
                .and_then(|m| m.get("type"))
                .and_then(|t| t.as_str())
                == Some(ty)
        })
    }

    /// Count emitted values with a given type.
    fn count_emitted_type(emitted: &[Value], ty: &str) -> usize {
        emitted
            .iter()
            .filter(|v| {
                v.as_map()
                    .and_then(|m| m.get("type"))
                    .and_then(|t| t.as_str())
                    == Some(ty)
            })
            .count()
    }

    // ── Baseline tests: current behavior ────────────────────────

    #[test]
    fn session_init_sets_context() {
        let tds = stdlib();
        let state = init_env(&tds);

        let init_context = Value::List(vec![
            Value::Map({
                let mut m = BTreeMap::new();
                m.insert("role".into(), Value::Str("system".into()));
                m.insert("parts".into(), Value::List(vec![text_part("You are helpful.")]));
                m.insert("tool_calls".into(), Value::List(vec![]));
                m
            }),
        ]);

        let data = event_data(&[("context", init_context.clone())]);
        let (state, emitted) = feed(&tds, &state, "SessionInit", &data);

        let messages = get_messages(&state);
        assert_eq!(messages.len(), 1, "SessionInit should set messages");
        assert!(emitted.is_empty(), "SessionInit should not emit");
    }

    #[test]
    fn user_message_appends_and_emits_llm_request() {
        let tds = stdlib();
        let state = init_env(&tds);

        // SessionInit with empty context
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);

        // UserMessage
        let data = event_data(&[
            ("parts", Value::List(vec![text_part("Hello")])),
        ]);
        let (state, emitted) = feed(&tds, &state, "UserMessage", &data);

        let messages = get_messages(&state);
        assert_eq!(messages.len(), 1, "UserMessage should append to messages");

        // Should have role=user
        let msg = messages[0].as_map().unwrap();
        assert_eq!(msg.get("role").unwrap().as_str().unwrap(), "user");

        // Should emit LlmRequest
        assert!(
            emitted_has_type(&emitted, "LlmRequest"),
            "UserMessage should emit LlmRequest, got: {:?}",
            emitted
        );
    }

    #[test]
    fn llm_response_text_only_appends_message() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup: SessionInit → UserMessage
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Hello")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // LlmResponse with text only (no tool calls)
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![text_part("Hi there!")])),
            ("tool_calls", Value::List(vec![])),
            ("input_tokens", Value::Int(100)),
            ("output_tokens", Value::Int(50)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);

        let messages = get_messages(&state);
        assert_eq!(messages.len(), 2, "LlmResponse should append to messages");

        let msg = messages[1].as_map().unwrap();
        assert_eq!(msg.get("role").unwrap().as_str().unwrap(), "assistant");

        // No tool calls → no ToolRequest emitted, no LlmRequest emitted
        assert!(emitted.is_empty(), "Text-only response should not emit requests");

        // Usage tracked
        assert_eq!(get_input_tokens(&state), 100);
        assert_eq!(get_output_tokens(&state), 50);
    }

    #[test]
    fn llm_response_with_tools_emits_tool_requests() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup: SessionInit → UserMessage
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Read a file")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // LlmResponse with tool calls
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![text_part("I'll read that file.")])),
            ("tool_calls", Value::List(vec![
                tool_call("tc1", "read_file", r#"{"path": "foo.rs"}"#),
            ])),
            ("input_tokens", Value::Int(200)),
            ("output_tokens", Value::Int(80)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);

        // Should append assistant message
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 2);

        // Should emit ToolRequest
        assert_eq!(
            count_emitted_type(&emitted, "ToolRequest"),
            1,
            "Should emit 1 ToolRequest, got: {:?}",
            emitted
        );

        // pending_tools should be 1
        assert_eq!(get_pending_tools(&state), 1);

        // ToolRequest should have instance-level key
        let tool_req = emitted.iter()
            .find(|v| v.as_map().and_then(|m| m.get("type")).and_then(|t| t.as_str()) == Some("ToolRequest"))
            .unwrap();
        let tool_req_map = tool_req.as_map().unwrap();
        let key_val = tool_req_map.get("key");
        assert!(key_val.is_some(), "ToolRequest should have 'key' field, got keys: {:?}", tool_req_map.keys().collect::<Vec<_>>());
        assert_eq!(key_val.unwrap().as_str(), Some("ToolRequest:tc1"), "key should be 'ToolRequest:tc1'");
    }

    #[test]
    fn llm_response_with_multiple_tools() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Do things")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // LlmResponse with 2 tool calls
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![])),
            ("tool_calls", Value::List(vec![
                tool_call("tc1", "read_file", r#"{"path": "a.rs"}"#),
                tool_call("tc2", "read_file", r#"{"path": "b.rs"}"#),
            ])),
            ("input_tokens", Value::Int(300)),
            ("output_tokens", Value::Int(100)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);

        assert_eq!(
            count_emitted_type(&emitted, "ToolRequest"),
            2,
            "Should emit 2 ToolRequests"
        );
        assert_eq!(get_pending_tools(&state), 2);
    }

    #[test]
    fn tool_result_decrements_pending() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup: SessionInit → UserMessage → LlmResponse (2 tools)
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Do things")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![])),
            ("tool_calls", Value::List(vec![
                tool_call("tc1", "read_file", r#"{}"#),
                tool_call("tc2", "write_file", r#"{}"#),
            ])),
            ("input_tokens", Value::Int(100)),
            ("output_tokens", Value::Int(50)),
        ]);
        let (state, _) = feed(&tds, &state, "LlmResponse", &data);
        assert_eq!(get_pending_tools(&state), 2);

        // First ToolResult
        let data = event_data(&[
            ("tool_call_id", Value::Str("tc1".into())),
            ("name", Value::Str("read_file".into())),
            ("content", Value::Str("file contents".into())),
            ("is_error", Value::Bool(false)),
        ]);
        let (state, emitted) = feed(&tds, &state, "ToolResult", &data);

        assert_eq!(get_pending_tools(&state), 1);
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 3, "ToolResult should append to messages");
        // First ToolResult should NOT emit LlmRequest (still pending)
        assert!(
            !emitted_has_type(&emitted, "LlmRequest"),
            "Should not emit LlmRequest with pending tools"
        );

        // Second ToolResult
        let data = event_data(&[
            ("tool_call_id", Value::Str("tc2".into())),
            ("name", Value::Str("write_file".into())),
            ("content", Value::Str("ok".into())),
            ("is_error", Value::Bool(false)),
        ]);
        let (state, emitted) = feed(&tds, &state, "ToolResult", &data);

        assert_eq!(get_pending_tools(&state), 0);
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 4);
        // Last ToolResult should emit LlmRequest
        assert!(
            emitted_has_type(&emitted, "LlmRequest"),
            "Should emit LlmRequest when all tools done, got: {:?}",
            emitted
        );
    }

    #[test]
    fn full_agent_loop() {
        let tds = stdlib();
        let state = init_env(&tds);

        // 1. SessionInit
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);

        // 2. UserMessage → emits LlmRequest
        let data = event_data(&[("parts", Value::List(vec![text_part("Hello")]))]);
        let (state, emitted) = feed(&tds, &state, "UserMessage", &data);
        assert!(emitted_has_type(&emitted, "LlmRequest"));

        // 3. LlmResponse with tool → emits ToolRequest
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![text_part("Let me check.")])),
            ("tool_calls", Value::List(vec![
                tool_call("tc1", "search", r#"{"q": "hello"}"#),
            ])),
            ("input_tokens", Value::Int(100)),
            ("output_tokens", Value::Int(30)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);
        assert_eq!(count_emitted_type(&emitted, "ToolRequest"), 1);
        assert_eq!(get_pending_tools(&state), 1);

        // 4. ToolResult → emits LlmRequest (pending_tools goes to 0)
        let data = event_data(&[
            ("tool_call_id", Value::Str("tc1".into())),
            ("name", Value::Str("search".into())),
            ("content", Value::Str("found it".into())),
            ("is_error", Value::Bool(false)),
        ]);
        let (state, emitted) = feed(&tds, &state, "ToolResult", &data);
        assert!(emitted_has_type(&emitted, "LlmRequest"));
        assert_eq!(get_pending_tools(&state), 0);

        // 5. LlmResponse (final, no tools) → no emits
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![text_part("Here's what I found.")])),
            ("tool_calls", Value::List(vec![])),
            ("input_tokens", Value::Int(200)),
            ("output_tokens", Value::Int(60)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);
        assert!(emitted.is_empty(), "Final response should not emit");

        // Verify final state
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 4); // user + assistant(tool) + tool_result + assistant(final)
        assert_eq!(get_input_tokens(&state), 200);
        assert_eq!(get_output_tokens(&state), 60);
    }

    // ── Item-level streaming tests ──────────────────────────────

    /// Helper: build opaque provider content (as a Map).
    fn provider_content(text: &str) -> Value {
        let mut m = BTreeMap::new();
        m.insert("type".into(), Value::Str("text".into()));
        m.insert("text".into(), Value::Str(text.into()));
        Value::Map(m)
    }

    #[test]
    fn llm_content_appends_to_messages() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Hello")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // LlmContent event — opaque provider content
        let data = event_data(&[
            ("content", provider_content("Let me think...")),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmContent", &data);

        let messages = get_messages(&state);
        assert_eq!(messages.len(), 2, "LlmContent should append to messages");

        let msg = messages[1].as_map().unwrap();
        assert_eq!(msg.get("role").unwrap().as_str().unwrap(), "assistant");
        // Content is opaque — just verify it's there
        assert!(msg.get("content").is_some(), "should have content field");

        // LlmContent should not emit any requests
        assert!(emitted.is_empty(), "LlmContent should not emit");
    }

    #[test]
    fn llm_tool_call_emits_tool_request() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Read a file")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // LlmToolCall event
        let data = event_data(&[
            ("id", Value::Str("tc1".into())),
            ("name", Value::Str("read_file".into())),
            ("arguments", Value::Str(r#"{"path": "foo.rs"}"#.into())),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmToolCall", &data);

        // Should append to messages
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 2, "LlmToolCall should append to messages");

        let msg = messages[1].as_map().unwrap();
        assert_eq!(msg.get("role").unwrap().as_str().unwrap(), "assistant");

        // Should emit ToolRequest
        assert_eq!(
            count_emitted_type(&emitted, "ToolRequest"),
            1,
            "LlmToolCall should emit ToolRequest"
        );

        // Should increment pending_tools
        assert_eq!(get_pending_tools(&state), 1);
    }

    #[test]
    fn llm_response_done_skips_empty() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Hello")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // Simulate streaming: LlmContent first
        let data = event_data(&[
            ("content", provider_content("Here's the answer.")),
        ]);
        let (state, _) = feed(&tds, &state, "LlmContent", &data);
        assert_eq!(get_messages(&state).len(), 2);

        // LlmResponse with empty parts/tool_calls (streaming done marker)
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![])),
            ("tool_calls", Value::List(vec![])),
            ("input_tokens", Value::Int(150)),
            ("output_tokens", Value::Int(40)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);

        // Should NOT append another message (guard: len(parts)>0 or len(tool_calls)>0)
        let messages = get_messages(&state);
        assert_eq!(messages.len(), 2, "Empty LlmResponse should not append");

        // Should not emit
        assert!(emitted.is_empty());

        // Usage should still be tracked
        assert_eq!(get_input_tokens(&state), 150);
        assert_eq!(get_output_tokens(&state), 40);
    }

    #[test]
    fn streaming_tool_call_sequence() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);
        let data = event_data(&[("parts", Value::List(vec![text_part("Do work")]))]);
        let (state, _) = feed(&tds, &state, "UserMessage", &data);

        // Stream: LlmContent (commentary)
        let data = event_data(&[
            ("content", provider_content("I'll read two files.")),
        ]);
        let (state, _) = feed(&tds, &state, "LlmContent", &data);

        // Stream: LlmToolCall #1
        let data = event_data(&[
            ("id", Value::Str("tc1".into())),
            ("name", Value::Str("read_file".into())),
            ("arguments", Value::Str(r#"{"path": "a.rs"}"#.into())),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmToolCall", &data);
        assert_eq!(count_emitted_type(&emitted, "ToolRequest"), 1);
        assert_eq!(get_pending_tools(&state), 1);

        // Stream: LlmToolCall #2
        let data = event_data(&[
            ("id", Value::Str("tc2".into())),
            ("name", Value::Str("read_file".into())),
            ("arguments", Value::Str(r#"{"path": "b.rs"}"#.into())),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmToolCall", &data);
        assert_eq!(count_emitted_type(&emitted, "ToolRequest"), 1);
        assert_eq!(get_pending_tools(&state), 2);

        // Stream: LlmResponse (done, empty)
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![])),
            ("tool_calls", Value::List(vec![])),
            ("input_tokens", Value::Int(250)),
            ("output_tokens", Value::Int(90)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);
        assert!(emitted.is_empty());
        assert_eq!(get_pending_tools(&state), 2); // still waiting

        // Messages: user + content + tc1 + tc2 = 4 entries
        assert_eq!(get_messages(&state).len(), 4);

        // ToolResult #1
        let data = event_data(&[
            ("tool_call_id", Value::Str("tc1".into())),
            ("name", Value::Str("read_file".into())),
            ("content", Value::Str("contents of a.rs".into())),
            ("is_error", Value::Bool(false)),
        ]);
        let (state, emitted) = feed(&tds, &state, "ToolResult", &data);
        assert_eq!(get_pending_tools(&state), 1);
        assert!(!emitted_has_type(&emitted, "LlmRequest"));

        // ToolResult #2 → triggers LlmRequest
        let data = event_data(&[
            ("tool_call_id", Value::Str("tc2".into())),
            ("name", Value::Str("read_file".into())),
            ("content", Value::Str("contents of b.rs".into())),
            ("is_error", Value::Bool(false)),
        ]);
        let (state, emitted) = feed(&tds, &state, "ToolResult", &data);
        assert_eq!(get_pending_tools(&state), 0);
        assert!(emitted_has_type(&emitted, "LlmRequest"));

        // Messages: user + content + tc1 + tc2 + result1 + result2 = 6
        assert_eq!(get_messages(&state).len(), 6);

        // Final LlmResponse (streaming done with content)
        let data = event_data(&[
            ("role", Value::Str("assistant".into())),
            ("parts", Value::List(vec![text_part("Here's what I found.")])),
            ("tool_calls", Value::List(vec![])),
            ("input_tokens", Value::Int(400)),
            ("output_tokens", Value::Int(120)),
        ]);
        let (state, emitted) = feed(&tds, &state, "LlmResponse", &data);
        assert!(emitted.is_empty());

        // Final state: 7 messages
        assert_eq!(get_messages(&state).len(), 7);
        assert_eq!(get_input_tokens(&state), 400);
        assert_eq!(get_output_tokens(&state), 120);
    }

    #[test]
    fn provider_specific_events_pass_through() {
        let tds = stdlib();
        let state = init_env(&tds);

        // Setup
        let data = event_data(&[("context", Value::List(vec![]))]);
        let (state, _) = feed(&tds, &state, "SessionInit", &data);

        // Provider-specific event — no transducer rule matches
        let data = event_data(&[
            ("text", Value::Str("thinking about the problem...".into())),
        ]);
        let (state, emitted) = feed(&tds, &state, "AnthropicThinking", &data);

        // Should not affect messages or emit anything
        assert_eq!(get_messages(&state).len(), 0);
        assert!(emitted.is_empty());

        // Another provider-specific event
        let data = event_data(&[
            ("summary", Value::Str("I considered three approaches.".into())),
        ]);
        let (state, emitted) = feed(&tds, &state, "OpenAIReasoning", &data);

        assert_eq!(get_messages(&state).len(), 0);
        assert!(emitted.is_empty());
    }
}
