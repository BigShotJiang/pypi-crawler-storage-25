//! Session definition — the canonical contract for session definitions.
//!
//! Defines what a session needs, not how to provide it.
//! All language runtimes validate and load from this format.
//!
//! Aligned with `session_def.qnt`.

use crate::agent_fold::{ConnectionDef as KernelConnectionDef, InboundCheckDef};
use crate::prelude::*;
use crate::session::SessionConfig;
use alloc::collections::{BTreeMap, BTreeSet};
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Types
// ════════════════════════════════════════════════════════════════

/// A request/result pair on a connection.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourcePairDef {
    pub request_type: String,
    pub result_type: String,
}

/// A check on a connection boundary.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CheckDef {
    /// Event type to check.
    pub intercept: String,
    /// "outbound" or "inbound".
    pub direction: String,
    /// Which source_id handles the check.
    pub check_source: String,
}

/// A connection to a source.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConnectionSpec {
    /// Logical name — runtime resolves to implementation.
    pub source_id: String,
    /// What events cross this boundary.
    pub pairs: Vec<SourcePairDef>,
    /// Verification policies.
    #[serde(default)]
    pub checks: Vec<CheckDef>,
}

/// Valid stdlib transducer names.
pub const STDLIB_NAMES: &[&str] = &[
    "messages",
    "blocks",
    "usage",
    "call_llm",
    "execute_tool",
    "summary",
];

/// A session definition — the canonical contract.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionDef {
    pub name: String,
    /// Stdlib transducer names, in composition order.
    pub transducers: Vec<String>,
    /// Connections to sources.
    pub connections: Vec<ConnectionSpec>,
    /// Initial config values (available to transducers via vm_env).
    #[serde(default)]
    pub config: BTreeMap<String, String>,
}

// ════════════════════════════════════════════════════════════════
// Loading — definition → kernel config
// ════════════════════════════════════════════════════════════════

/// Result of loading a session definition.
#[derive(Debug, Clone)]
pub struct LoadResult {
    /// Kernel session config (topology + inbound checks).
    pub session_config: SessionConfig,
    /// Source IDs that the runtime must provide.
    pub source_ids: BTreeSet<String>,
    /// Transducer names to load from stdlib.
    pub transducer_names: Vec<String>,
    /// Config values for vm_env.
    pub config: BTreeMap<String, String>,
}

/// Load a session definition into kernel config.
/// Pure function — same def → same result.
pub fn load(def: &SessionDef) -> LoadResult {
    let mut topology = Vec::new();
    let mut inbound_checks = Vec::new();
    let mut source_ids = BTreeSet::new();

    for conn in &def.connections {
        source_ids.insert(conn.source_id.clone());

        for pair in &conn.pairs {
            let outbound_check = conn
                .checks
                .iter()
                .find(|c| c.intercept == pair.request_type && c.direction == "outbound");

            topology.push(KernelConnectionDef {
                request_type: pair.request_type.clone(),
                result_type: pair.result_type.clone(),
                has_check: outbound_check.is_some(),
                check_source: outbound_check.map(|c| c.check_source.clone()),
            });
        }

        for check in &conn.checks {
            if check.direction == "inbound" {
                inbound_checks.push(InboundCheckDef {
                    intercept: check.intercept.clone(),
                    check_source: check.check_source.clone(),
                });
            }
        }
    }

    LoadResult {
        session_config: SessionConfig {
            topology,
            inbound_checks,
        },
        source_ids,
        transducer_names: def.transducers.clone(),
        config: def.config.clone(),
    }
}

// ════════════════════════════════════════════════════════════════
// Validation
// ════════════════════════════════════════════════════════════════

/// Validation error.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ValidationError {
    /// check_source references a source_id that doesn't exist.
    UnknownCheckSource {
        check_source: String,
        connection: String,
    },
    /// Duplicate source_id across connections.
    DuplicateSourceId(String),
    /// Duplicate request_type across connections.
    DuplicateRequestType(String),
    /// Transducer name not in stdlib.
    UnknownTransducer(String),
    /// Invalid check direction (must be "outbound" or "inbound").
    InvalidCheckDirection {
        direction: String,
        connection: String,
    },
    /// Check intercept doesn't reference a pair in the connection.
    InvalidCheckIntercept {
        intercept: String,
        connection: String,
    },
}

impl core::fmt::Display for ValidationError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::UnknownCheckSource {
                check_source,
                connection,
            } => write!(
                f,
                "check_source '{check_source}' not found (connection '{connection}')"
            ),
            Self::DuplicateSourceId(id) => write!(f, "duplicate source_id: {id}"),
            Self::DuplicateRequestType(t) => write!(f, "duplicate request_type: {t}"),
            Self::UnknownTransducer(name) => write!(f, "unknown transducer: {name}"),
            Self::InvalidCheckDirection {
                direction,
                connection,
            } => write!(
                f,
                "invalid check direction '{direction}' (connection '{connection}')"
            ),
            Self::InvalidCheckIntercept {
                intercept,
                connection,
            } => write!(
                f,
                "check intercept '{intercept}' not in connection '{connection}' pairs"
            ),
        }
    }
}

impl core::error::Error for ValidationError {}

/// Validate a session definition. Returns all errors found.
pub fn validate(def: &SessionDef) -> Vec<ValidationError> {
    let mut errors = Vec::new();

    let source_ids: BTreeSet<&str> = def
        .connections
        .iter()
        .map(|c| c.source_id.as_str())
        .collect();

    // Check for duplicate source_ids
    {
        let mut seen = BTreeSet::new();
        for conn in &def.connections {
            if !seen.insert(&conn.source_id) {
                errors.push(ValidationError::DuplicateSourceId(conn.source_id.clone()));
            }
        }
    }

    // Check for duplicate request_types
    {
        let mut seen = BTreeSet::new();
        for conn in &def.connections {
            for pair in &conn.pairs {
                if !seen.insert(&pair.request_type) {
                    errors.push(ValidationError::DuplicateRequestType(
                        pair.request_type.clone(),
                    ));
                }
            }
        }
    }

    // Validate transducer names
    for name in &def.transducers {
        if !STDLIB_NAMES.contains(&name.as_str()) {
            errors.push(ValidationError::UnknownTransducer(name.clone()));
        }
    }

    // Validate checks per connection
    for conn in &def.connections {
        let event_types: BTreeSet<&str> = conn
            .pairs
            .iter()
            .flat_map(|p| [p.request_type.as_str(), p.result_type.as_str()])
            .collect();

        for check in &conn.checks {
            // Direction
            if check.direction != "outbound" && check.direction != "inbound" {
                errors.push(ValidationError::InvalidCheckDirection {
                    direction: check.direction.clone(),
                    connection: conn.source_id.clone(),
                });
            }

            // Check source exists
            if !source_ids.contains(check.check_source.as_str()) {
                errors.push(ValidationError::UnknownCheckSource {
                    check_source: check.check_source.clone(),
                    connection: conn.source_id.clone(),
                });
            }

            // Intercept references a pair
            if !event_types.contains(check.intercept.as_str()) {
                errors.push(ValidationError::InvalidCheckIntercept {
                    intercept: check.intercept.clone(),
                    connection: conn.source_id.clone(),
                });
            }
        }
    }

    errors
}

/// Validate and return Ok if valid, Err with first error if not.
pub fn validate_strict(def: &SessionDef) -> Result<(), ValidationError> {
    let errors = validate(def);
    if let Some(err) = errors.into_iter().next() {
        Err(err)
    } else {
        Ok(())
    }
}

// ════════════════════════════════════════════════════════════════
// Tests — aligned with session_def.qnt
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn basic_agent() -> SessionDef {
        SessionDef {
            name: "basic_agent".into(),
            transducers: vec![
                "messages".into(),
                "blocks".into(),
                "usage".into(),
                "call_llm".into(),
                "execute_tool".into(),
                "summary".into(),
            ],
            connections: vec![
                ConnectionSpec {
                    source_id: "llm".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "LlmRequest".into(),
                        result_type: "LlmResponse".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        }
    }

    fn approved_agent() -> SessionDef {
        SessionDef {
            name: "approved_agent".into(),
            transducers: vec!["messages".into(), "call_llm".into(), "execute_tool".into()],
            connections: vec![
                ConnectionSpec {
                    source_id: "llm".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "LlmRequest".into(),
                        result_type: "LlmResponse".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![CheckDef {
                        intercept: "ToolRequest".into(),
                        direction: "outbound".into(),
                        check_source: "approval".into(),
                    }],
                },
                ConnectionSpec {
                    source_id: "approval".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "CheckRequest".into(),
                        result_type: "CheckResult".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        }
    }

    fn guarded_agent() -> SessionDef {
        SessionDef {
            name: "guarded_agent".into(),
            transducers: vec!["messages".into(), "call_llm".into(), "execute_tool".into()],
            connections: vec![
                ConnectionSpec {
                    source_id: "llm".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "LlmRequest".into(),
                        result_type: "LlmResponse".into(),
                    }],
                    checks: vec![CheckDef {
                        intercept: "LlmResponse".into(),
                        direction: "inbound".into(),
                        check_source: "guardrail".into(),
                    }],
                },
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "guardrail".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "CheckRequest".into(),
                        result_type: "CheckResult".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        }
    }

    fn delegating_agent() -> SessionDef {
        SessionDef {
            name: "delegating_agent".into(),
            transducers: vec!["messages".into(), "call_llm".into(), "execute_tool".into()],
            connections: vec![
                ConnectionSpec {
                    source_id: "llm".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "LlmRequest".into(),
                        result_type: "LlmResponse".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "researcher".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "DelegationRequest".into(),
                        result_type: "DelegationResult".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        }
    }

    // ── Validation ─────────────────────────────────────────

    #[test]
    fn valid_definitions() {
        assert!(validate(&basic_agent()).is_empty());
        assert!(validate(&approved_agent()).is_empty());
        assert!(validate(&guarded_agent()).is_empty());
        assert!(validate(&delegating_agent()).is_empty());
    }

    #[test]
    fn invalid_check_source() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into()],
            connections: vec![ConnectionSpec {
                source_id: "tools".into(),
                pairs: vec![SourcePairDef {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                }],
                checks: vec![CheckDef {
                    intercept: "ToolRequest".into(),
                    direction: "outbound".into(),
                    check_source: "nonexistent".into(),
                }],
            }],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::UnknownCheckSource { .. }))
        );
    }

    #[test]
    fn invalid_duplicate_source_ids() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into()],
            connections: vec![
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "tools".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "LlmRequest".into(),
                        result_type: "LlmResponse".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::DuplicateSourceId(_)))
        );
    }

    #[test]
    fn invalid_duplicate_request_types() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into()],
            connections: vec![
                ConnectionSpec {
                    source_id: "a".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
                ConnectionSpec {
                    source_id: "b".into(),
                    pairs: vec![SourcePairDef {
                        request_type: "ToolRequest".into(),
                        result_type: "ToolResult".into(),
                    }],
                    checks: vec![],
                },
            ],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::DuplicateRequestType(_)))
        );
    }

    #[test]
    fn invalid_transducer_name() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into(), "nonexistent".into()],
            connections: vec![],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::UnknownTransducer(_)))
        );
    }

    #[test]
    fn invalid_check_direction() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into()],
            connections: vec![ConnectionSpec {
                source_id: "tools".into(),
                pairs: vec![SourcePairDef {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                }],
                checks: vec![CheckDef {
                    intercept: "ToolRequest".into(),
                    direction: "sideways".into(),
                    check_source: "tools".into(),
                }],
            }],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::InvalidCheckDirection { .. }))
        );
    }

    #[test]
    fn invalid_check_intercept() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["messages".into()],
            connections: vec![ConnectionSpec {
                source_id: "tools".into(),
                pairs: vec![SourcePairDef {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                }],
                checks: vec![CheckDef {
                    intercept: "UnknownEvent".into(),
                    direction: "outbound".into(),
                    check_source: "tools".into(),
                }],
            }],
            config: BTreeMap::new(),
        };
        let errors = validate(&def);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, ValidationError::InvalidCheckIntercept { .. }))
        );
    }

    // ── Loading ────────────────────────────────────────────

    #[test]
    fn load_basic_agent() {
        let result = load(&basic_agent());
        assert_eq!(result.session_config.topology.len(), 2);
        assert!(result.session_config.inbound_checks.is_empty());
        assert_eq!(
            result.source_ids,
            BTreeSet::from(["llm".into(), "tools".into()])
        );
        assert_eq!(result.transducer_names.len(), 6);
    }

    #[test]
    fn load_approved_agent() {
        let result = load(&approved_agent());
        assert_eq!(result.session_config.topology.len(), 3);
        assert!(
            result
                .session_config
                .topology
                .iter()
                .any(|t| t.request_type == "ToolRequest" && t.has_check)
        );
        assert!(result.session_config.inbound_checks.is_empty());
    }

    #[test]
    fn load_guarded_agent() {
        let result = load(&guarded_agent());
        assert_eq!(result.session_config.topology.len(), 3);
        assert_eq!(result.session_config.inbound_checks.len(), 1);
        assert_eq!(
            result.session_config.inbound_checks[0].intercept,
            "LlmResponse"
        );
        assert_eq!(
            result.session_config.inbound_checks[0].check_source,
            "guardrail"
        );
    }

    #[test]
    fn load_delegating_agent() {
        let result = load(&delegating_agent());
        assert_eq!(result.session_config.topology.len(), 3);
        assert!(
            result
                .session_config
                .topology
                .iter()
                .any(|t| t.request_type == "DelegationRequest")
        );
        assert!(result.source_ids.contains("researcher"));
    }

    #[test]
    fn load_deterministic() {
        let r1 = load(&basic_agent());
        let r2 = load(&basic_agent());
        assert_eq!(
            r1.session_config.topology.len(),
            r2.session_config.topology.len()
        );
        assert_eq!(r1.source_ids, r2.source_ids);
        assert_eq!(r1.transducer_names, r2.transducer_names);
    }

    // ── JSON roundtrip ─────────────────────────────────────

    #[test]
    fn json_roundtrip() {
        let def = basic_agent();
        let json = serde_json::to_string_pretty(&def).unwrap();
        let def2: SessionDef = serde_json::from_str(&json).unwrap();
        assert_eq!(def, def2);
    }

    #[test]
    fn validate_strict_ok() {
        assert!(validate_strict(&basic_agent()).is_ok());
    }

    #[test]
    fn validate_strict_err() {
        let def = SessionDef {
            name: "bad".into(),
            transducers: vec!["nonexistent".into()],
            connections: vec![],
            config: BTreeMap::new(),
        };
        assert!(validate_strict(&def).is_err());
    }
}
