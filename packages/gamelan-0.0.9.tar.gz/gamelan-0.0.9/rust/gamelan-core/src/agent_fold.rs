//! AgentFold — DomainFold implementation for agent sessions (VM transducers).
//!
//! Wraps the existing VM execution (`vm::exec_session`) as project + generate.
//! The session tree handles gate, pending, and checks generically.
//!
//! Also contains the agent interpreter types:
//! AgentConnection, AgentConnectionState, AgentConfigEvent, ToolPolicy,
//! and the functions that derive RoutingConfig from connection state.
//! Direct translation of agent.qnt agent interpreter section.
//!
//! Also contains the connection/topology/continuation types formerly in
//! continuation.rs and topology.rs: ConnectionDef, Topology, Pending,
//! SourcePair, SourceRegistration, CheckVerdict, FoldResult, RequestAction,
//! TurnResult, InboundCheckDef, OutboundCheckConfig, InboundCheckConfig,
//! and the pure fold functions (fold_event, turn_step, derive_topology, etc.).

use crate::inner_fold::DomainFold;
use crate::interpreter::{
    DispatchRule, InboundCheckRule, OutboundCheckRule, RoutingConfig, RuntimeEffect,
};
use crate::prelude::*;
use crate::types::{Env, TransducerDef, Value};
use crate::vm;
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Connection topology — connection declarations (from continuation.rs)
// ════════════════════════════════════════════════════════════════

/// A connection in the topology.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectionDef {
    /// Request type this connection handles
    pub request_type: String,
    /// Result type that clears this request
    pub result_type: String,
    /// Whether this connection requires a check before dispatch
    pub has_check: bool,
    /// Check source identifier (if has_check)
    pub check_source: Option<String>,
}

/// Connection topology — input to the "compiler".
pub type Topology = Vec<ConnectionDef>;

/// Derive needs_check from topology.
pub fn build_needs_check(topology: &Topology) -> impl Fn(&str) -> bool + '_ {
    move |request_type: &str| {
        topology
            .iter()
            .any(|c| c.request_type == request_type && c.has_check)
    }
}

// ════════════════════════════════════════════════════════════════
// FoldResult + RequestAction — pure output of folding one event
// ════════════════════════════════════════════════════════════════

/// The result of folding one event — pure, no kernel state.
#[derive(Debug, Clone)]
pub struct FoldResult {
    /// Updated transducer state
    pub vm_env: Env,
    /// Requests to process (check then dispatch)
    pub requests: Vec<RequestAction>,
}

/// What to do with each request.
#[derive(Debug, Clone)]
pub enum RequestAction {
    /// Dispatch directly (unchecked connection)
    Dispatch(Value),
    /// Check first, then dispatch if approved
    CheckThenDispatch {
        request: Value,
        check_source: String,
    },
}

// ════════════════════════════════════════════════════════════════
// fold_event — the pure core
// ════════════════════════════════════════════════════════════════

/// Fold one event through transducers, classify requests by topology.
/// This is the pure core — no kernel state, no flags.
pub fn fold_event(
    topology: &Topology,
    transducers: &[TransducerDef],
    vm_env: &Env,
    event_tag: &str,
    event_data: &BTreeMap<String, Value>,
) -> FoldResult {
    // 1. Run the VM fold
    let exec_result = vm::exec_session(transducers, vm_env, event_tag, event_data);

    // 2. Classify each emitted value by topology
    let needs_check = build_needs_check(topology);
    let requests = exec_result
        .emitted
        .into_iter()
        .filter_map(|value| {
            // Extract "type" from VMap
            let request_type = match &value {
                Value::Map(m) => m
                    .get("type")
                    .and_then(|v| v.as_str())
                    .map(|s| s.to_string()),
                Value::Str(s) => Some(s.clone()),
                _ => None,
            };

            let request_type = request_type?;

            if needs_check(&request_type) {
                // Find the check source for this request type
                let check_source = topology
                    .iter()
                    .find(|c| c.request_type == request_type && c.has_check)
                    .and_then(|c| c.check_source.clone())
                    .unwrap_or_default();

                Some(RequestAction::CheckThenDispatch {
                    request: value,
                    check_source,
                })
            } else {
                Some(RequestAction::Dispatch(value))
            }
        })
        .collect();

    FoldResult {
        vm_env: exec_result.state,
        requests,
    }
}

// ════════════════════════════════════════════════════════════════
// CheckVerdict — matches Lean CheckVerdict
// ════════════════════════════════════════════════════════════════

/// Check verdict: approve, reject, or transform.
/// Maps directly to Lean `CheckVerdict`.
#[derive(Debug, Clone, PartialEq)]
pub enum CheckVerdict {
    /// Approved — dispatch the original request
    Approve,
    /// Rejected — drop the request
    Reject,
    /// Transformed — dispatch the modified request
    Transform(Value),
}

// ════════════════════════════════════════════════════════════════
// Pending — request types currently in flight
// ════════════════════════════════════════════════════════════════

/// Pending set: request types currently in flight.
/// Maps directly to Lean `Pending RequestType := List RequestType`.
pub type Pending = Vec<String>;

/// Is a request type currently pending?
/// Maps to Lean `is_pending`.
pub fn is_pending(pending: &Pending, req_type: &str) -> bool {
    pending.iter().any(|t| t == req_type)
}

/// Add dispatched request types to pending.
/// Maps to Lean `add_pending`: `pending ++ dispatched.filter(!is_pending pending)`.
/// Note: filter checks against ORIGINAL pending, not incrementally updated.
/// This matches the Lean specification exactly.
pub fn add_pending(pending: &Pending, dispatched: &[String]) -> Pending {
    let mut result = pending.clone();
    let filtered: Vec<String> = dispatched
        .iter()
        .filter(|t| !is_pending(pending, t))
        .cloned()
        .collect();
    result.extend(filtered);
    result
}

/// Clear a request type from pending when its result arrives.
/// Maps to Lean `clear_pending`: finds request type by result type in topology.
pub fn clear_pending(pending: &Pending, result_type: &str, topology: &Topology) -> Pending {
    match topology.iter().find(|c| c.result_type == result_type) {
        Some(conn) => pending
            .iter()
            .filter(|t| t.as_str() != conn.request_type)
            .cloned()
            .collect(),
        None => pending.clone(),
    }
}

/// Gate: filter out requests whose type is pending.
/// Maps to Lean `gate`. Returns only requests whose type is NOT in the pending set.
pub fn gate_requests(requests: Vec<RequestAction>, pending: &Pending) -> Vec<RequestAction> {
    requests
        .into_iter()
        .filter(|r| {
            let req_type = extract_request_type(r);
            req_type.is_none_or(|t| !is_pending(pending, &t))
        })
        .collect()
}

/// Extract the request type string from a RequestAction.
pub fn extract_request_type(action: &RequestAction) -> Option<String> {
    let value = match action {
        RequestAction::Dispatch(v) => v,
        RequestAction::CheckThenDispatch { request, .. } => request,
    };
    match value {
        Value::Map(m) => m
            .get("type")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string()),
        Value::Str(s) => Some(s.clone()),
        _ => None,
    }
}

// ════════════════════════════════════════════════════════════════
// Inbound checks — check events before fold
// ════════════════════════════════════════════════════════════════

/// Inbound check definition: intercept result events before the fold sees them.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InboundCheckDef {
    /// Result type to intercept (e.g. "LlmResponse")
    pub intercept: String,
    /// Check source identifier
    pub check_source: String,
}

/// Check if an incoming event needs an inbound check.
/// Returns the check source if the event matches an inbound check definition.
pub fn needs_inbound_check(inbound_checks: &[InboundCheckDef], event_tag: &str) -> Option<String> {
    inbound_checks
        .iter()
        .find(|c| c.intercept == event_tag)
        .map(|c| c.check_source.clone())
}

// ════════════════════════════════════════════════════════════════
// TurnStep — one iteration of the turn loop
// ════════════════════════════════════════════════════════════════

/// The result of one turn step — matches Lean turn_loop semantics.
#[derive(Debug, Clone)]
pub struct TurnResult {
    /// Updated transducer state
    pub vm_env: Env,
    /// Requests that passed the gate, classified by topology
    pub requests: Vec<RequestAction>,
    /// Updated pending set (after add_pending)
    pub pending: Pending,
    /// Inbound check needed for this event (if any)
    pub inbound_check: Option<String>,
}

/// One iteration of the turn loop.
///
/// Maps to one unfolding of Lean `turn_loop`:
/// clear_pending → fold → gate → classify → add_pending.
pub fn turn_step(
    topology: &Topology,
    inbound_checks: &[InboundCheckDef],
    transducers: &[TransducerDef],
    vm_env: &Env,
    event_tag: &str,
    event_data: &BTreeMap<String, Value>,
    pending: &Pending,
) -> TurnResult {
    // 0. Check if this event needs an inbound check
    let inbound_check = needs_inbound_check(inbound_checks, event_tag);

    // 1. Clear pending for result events
    let pending_after_clear = clear_pending(pending, event_tag, topology);

    // 2. Fold — run all transducers (product)
    let fold_result = fold_event(topology, transducers, vm_env, event_tag, event_data);

    // 3. Gate — filter by pending
    let gated = gate_requests(fold_result.requests, &pending_after_clear);

    // 4. Add dispatched types to pending
    let dispatched_types: Vec<String> = gated
        .iter()
        .filter_map(extract_request_type)
        .collect();
    let pending_after_dispatch = add_pending(&pending_after_clear, &dispatched_types);

    TurnResult {
        vm_env: fold_result.vm_env,
        requests: gated,
        pending: pending_after_dispatch,
        inbound_check,
    }
}

// ════════════════════════════════════════════════════════════════
// Source declarations (from topology.rs)
// ════════════════════════════════════════════════════════════════

/// A request/result pair declared by a source.
#[derive(Debug, Clone)]
pub struct SourcePair {
    pub request_type: String,
    pub result_type: String,
}

/// A registered source with its declared interface.
#[derive(Debug, Clone)]
pub struct SourceRegistration {
    pub source_id: String,
    pub pairs: Vec<SourcePair>,
}

/// Outbound check: verify a request before dispatch.
#[derive(Debug, Clone)]
pub struct OutboundCheckConfig {
    pub request_type: String,
    pub check_source: String,
}

/// Inbound check: verify a result before the fold sees it.
#[derive(Debug, Clone)]
pub struct InboundCheckConfig {
    pub result_type: String,
    pub check_source: String,
}

/// Derive kernel Topology from source registrations and outbound checks.
///
/// Each SourcePair becomes a ConnectionDef. If an OutboundCheckConfig
/// references a request type, the ConnectionDef gets has_check=true.
///
/// Maps to `session_loop.qnt::derive_topology`.
pub fn derive_topology(
    sources: &[SourceRegistration],
    outbound_checks: &[OutboundCheckConfig],
) -> Vec<ConnectionDef> {
    let mut topology = Vec::new();

    for source in sources {
        for pair in &source.pairs {
            let check = outbound_checks
                .iter()
                .find(|c| c.request_type == pair.request_type);

            topology.push(ConnectionDef {
                request_type: pair.request_type.clone(),
                result_type: pair.result_type.clone(),
                has_check: check.is_some(),
                check_source: check.map(|c| c.check_source.clone()),
            });
        }
    }

    topology
}

/// Derive InboundCheckDefs from inbound check configuration.
pub fn derive_inbound_checks(checks: &[InboundCheckConfig]) -> Vec<InboundCheckDef> {
    checks
        .iter()
        .map(|c| InboundCheckDef {
            intercept: c.result_type.clone(),
            check_source: c.check_source.clone(),
        })
        .collect()
}

/// Resolve which source handles a request type.
/// Returns the source_id, or None if no source handles it.
pub fn resolve_source(sources: &[SourceRegistration], request_type: &str) -> Option<String> {
    sources
        .iter()
        .find(|s| s.pairs.iter().any(|p| p.request_type == request_type))
        .map(|s| s.source_id.clone())
}

// ════════════════════════════════════════════════════════════════
// Tool policy — which tools from a source are visible to the LLM
// Spec: agent.qnt `type ToolPolicy`
// ════════════════════════════════════════════════════════════════

/// Tool visibility policy — which tools from a source are visible.
///
/// Spec: agent.qnt lines 8-11 `type ToolPolicy`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ToolPolicy {
    /// All tools are visible.
    AllowAll,
    /// Only the listed tools are visible.
    AllowList(Vec<String>),
    /// All tools except the listed ones are visible.
    DenyList(Vec<String>),
}

// ════════════════════════════════════════════════════════════════
// Agent connection types
// Spec: agent.qnt `type AgentConnection` + `type AgentConnectionState`
// ════════════════════════════════════════════════════════════════

/// An agent connection definition — one source's request/result pair.
///
/// `instance_key_field`: field name in request/result data for
/// instance-level gating. Empty string means type-level (single slot).
/// `tool_policy`: which tools from this source are visible to the LLM.
/// `available_tools`: full set of tools the source offers.
///
/// Spec: agent.qnt lines 18-27 `type AgentConnection`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentConnection {
    pub source_id: String,
    pub request_type: String,
    pub result_type: String,
    pub has_check: bool,
    pub check_source: String,
    pub instance_key_field: String,
    pub tool_policy: ToolPolicy,
    pub available_tools: Vec<String>,
}

/// Accumulated agent connection state — updated by config events.
///
/// Spec: agent.qnt lines 30-32 `type AgentConnectionState`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentConnectionState {
    pub connections: BTreeMap<String, AgentConnection>,
}

impl AgentConnectionState {
    /// Empty state — no connections.
    /// Spec: agent.qnt `empty_agent_connection_state`
    pub fn empty() -> Self {
        AgentConnectionState {
            connections: BTreeMap::new(),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Agent config events
// Spec: agent.qnt `type AgentConfigEvent`
// ════════════════════════════════════════════════════════════════

/// Events that update agent connection state.
///
/// Spec: agent.qnt lines 41-45 `type AgentConfigEvent`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AgentConfigEvent {
    /// Add or replace a connection (keyed by source_id).
    ConnectionAdded(AgentConnection),
    /// Remove a connection by source_id.
    ConnectionRemoved(String),
    /// Change the tool visibility policy for a source.
    ToolVisibilityChanged {
        source_id: String,
        policy: ToolPolicy,
    },
    /// Update the set of available tools for a source.
    ToolsAvailableChanged {
        source_id: String,
        tools: Vec<String>,
    },
}

// ════════════════════════════════════════════════════════════════
// Agent interpreter functions
// Spec: agent.qnt lines 50-160
// ════════════════════════════════════════════════════════════════

/// Handle an agent config event — update connection state.
///
/// Returns the new connection state. The caller re-derives
/// routing from the updated state.
///
/// Spec: agent.qnt lines 50-74 `pure def handle_agent_config_event`
pub fn handle_agent_config_event(
    cs: &AgentConnectionState,
    event: &AgentConfigEvent,
) -> AgentConnectionState {
    match event {
        AgentConfigEvent::ConnectionAdded(conn) => {
            let mut new_cs = cs.clone();
            new_cs
                .connections
                .insert(conn.source_id.clone(), conn.clone());
            new_cs
        }
        AgentConfigEvent::ConnectionRemoved(source_id) => {
            let mut new_cs = cs.clone();
            new_cs.connections.remove(source_id);
            new_cs
        }
        AgentConfigEvent::ToolVisibilityChanged { source_id, policy } => {
            if !cs.connections.contains_key(source_id) {
                cs.clone()
            } else {
                let mut new_cs = cs.clone();
                if let Some(conn) = new_cs.connections.get_mut(source_id) {
                    conn.tool_policy = policy.clone();
                }
                new_cs
            }
        }
        AgentConfigEvent::ToolsAvailableChanged { source_id, tools } => {
            if !cs.connections.contains_key(source_id) {
                cs.clone()
            } else {
                let mut new_cs = cs.clone();
                if let Some(conn) = new_cs.connections.get_mut(source_id) {
                    conn.available_tools = tools.clone();
                }
                new_cs
            }
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Session boot event
// Spec: agent.qnt `type ContextBlock`, `type SessionCreated`,
//       `pure def handle_session_created`
// ════════════════════════════════════════════════════════════════

/// Initial context block — named content for the agent's memory.
/// The runtime feeds these to transducers as MemoryBlockUpdated events.
///
/// Spec: agent.qnt `type ContextBlock`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ContextBlock {
    pub name: String,
    pub content: String,
}

/// Boot event — the first event on the session log.
/// Carries both outer fold config (connections, checks) and
/// inner fold config (initial context for transducers).
///
/// Spec: agent.qnt `type SessionCreated`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionCreated {
    pub connections: Vec<AgentConnection>,
    pub inbound_checks: Vec<InboundCheckRule>,
    pub initial_context: Vec<ContextBlock>,
}

/// Process a SessionCreated event — initialize connection state
/// and routing from the boot payload.
///
/// Spec: agent.qnt `pure def handle_session_created`
/// Lean: Interpreter.lean `agent_session_boot` (proved)
pub fn handle_session_created(
    event: &SessionCreated,
) -> (AgentConnectionState, RoutingConfig) {
    let cs = event.connections.iter().fold(
        AgentConnectionState::empty(),
        |acc, conn| {
            handle_agent_config_event(&acc, &AgentConfigEvent::ConnectionAdded(conn.clone()))
        },
    );
    let mut routing = agent_derive_routing(&cs);
    routing.inbound_checks = event.inbound_checks.clone();
    (cs, routing)
}

// ════════════════════════════════════════════════════════════════

/// Derive `RoutingConfig` from agent connection state.
///
/// Produces dispatch_rules and outbound_checks from all connections.
/// Inbound checks are not part of connection state (they come from
/// separate config).
///
/// Spec: agent.qnt lines 79-91 `pure def agent_derive_routing`
pub fn agent_derive_routing(cs: &AgentConnectionState) -> RoutingConfig {
    let mut dispatch_rules = Vec::new();
    let mut outbound_checks = Vec::new();

    for conn in cs.connections.values() {
        dispatch_rules.push(DispatchRule {
            request_type: conn.request_type.clone(),
            result_type: conn.result_type.clone(),
        });
        if conn.has_check && !conn.check_source.is_empty() {
            outbound_checks.push(OutboundCheckRule {
                request_type: conn.request_type.clone(),
                check_source: conn.check_source.clone(),
            });
        }
    }

    RoutingConfig {
        dispatch_rules,
        outbound_checks,
        inbound_checks: Vec::new(),
    }
}

/// Resolve which source handles a request type.
///
/// Returns the source_id, or empty string if no source handles it.
///
/// Spec: agent.qnt lines 93-101 `pure def resolve_agent_source`
pub fn resolve_agent_source(cs: &AgentConnectionState, request_type: &str) -> String {
    for conn in cs.connections.values() {
        if conn.request_type == request_type {
            return conn.source_id.clone();
        }
    }
    String::new()
}

/// Apply a tool policy to a list of available tools.
///
/// Spec: agent.qnt lines 107-112 `pure def apply_policy`
pub fn apply_policy(policy: &ToolPolicy, tools: &[String]) -> Vec<String> {
    match policy {
        ToolPolicy::AllowAll => tools.to_vec(),
        ToolPolicy::AllowList(allowed) => tools
            .iter()
            .filter(|t| allowed.contains(t))
            .cloned()
            .collect(),
        ToolPolicy::DenyList(denied) => tools
            .iter()
            .filter(|t| !denied.contains(t))
            .cloned()
            .collect(),
    }
}

/// Derive visible tools for a single connection.
///
/// Spec: agent.qnt lines 115-116 `pure def visible_tools`
pub fn visible_tools(conn: &AgentConnection) -> Vec<String> {
    apply_policy(&conn.tool_policy, &conn.available_tools)
}

/// Derive all visible tools across all connections.
///
/// Returns a map: source_id → Vec<tool_name>, omitting sources
/// with no visible tools.
///
/// Spec: agent.qnt lines 120-126 `pure def all_visible_tools`
pub fn all_visible_tools(cs: &AgentConnectionState) -> BTreeMap<String, Vec<String>> {
    let mut result = BTreeMap::new();
    for (source_id, conn) in &cs.connections {
        let tools = visible_tools(conn);
        if !tools.is_empty() {
            result.insert(source_id.clone(), tools);
        }
    }
    result
}

/// Derive runtime effects from an agent config event.
///
/// Called by the session loop after handle_agent_config_event.
/// Tells the runtime which sources to start/stop and which tool
/// schemas to update.
///
/// Spec: agent.qnt lines 133-158 `pure def derive_agent_effects`
pub fn derive_agent_effects(
    _old_cs: &AgentConnectionState,
    new_cs: &AgentConnectionState,
    event: &AgentConfigEvent,
) -> Vec<RuntimeEffect> {
    match event {
        AgentConfigEvent::ConnectionAdded(conn) => {
            let tools = visible_tools(conn);
            let mut effects = vec![RuntimeEffect::StartSource(conn.source_id.clone())];
            if !tools.is_empty() {
                effects.push(RuntimeEffect::UpdateToolSchemas {
                    source_id: conn.source_id.clone(),
                    tools,
                });
            }
            effects
        }
        AgentConfigEvent::ConnectionRemoved(source_id) => {
            vec![RuntimeEffect::StopSource(source_id.clone())]
        }
        AgentConfigEvent::ToolVisibilityChanged { source_id, .. } => {
            if let Some(conn) = new_cs.connections.get(source_id) {
                vec![RuntimeEffect::UpdateToolSchemas {
                    source_id: source_id.clone(),
                    tools: visible_tools(conn),
                }]
            } else {
                Vec::new()
            }
        }
        AgentConfigEvent::ToolsAvailableChanged { source_id, .. } => {
            if let Some(conn) = new_cs.connections.get(source_id) {
                vec![RuntimeEffect::UpdateToolSchemas {
                    source_id: source_id.clone(),
                    tools: visible_tools(conn),
                }]
            } else {
                Vec::new()
            }
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Agent boot — build connection state from source registrations
// Spec: agent.qnt lines 227-247 `pure def agent_boot`
// ════════════════════════════════════════════════════════════════

/// Build `AgentConnectionState` from source registrations and outbound checks.
///
/// Each SourcePair becomes an AgentConnection added via
/// handle_agent_config_event. Outbound checks set has_check and
/// check_source on the matching connection.
///
/// Spec: agent.qnt lines 227-247 `pure def agent_boot`
pub fn agent_boot(
    sources: &[SourceRegistration],
    outbound_checks: &[OutboundCheckConfig],
) -> AgentConnectionState {
    let mut cs = AgentConnectionState::empty();
    for source in sources {
        for pair in &source.pairs {
            let check = outbound_checks
                .iter()
                .find(|c| c.request_type == pair.request_type);
            let has_check = check.is_some();
            let check_source = check.map(|c| c.check_source.clone()).unwrap_or_default();

            // Spec: agent.qnt line 236 ConnectionAdded(...)
            cs = handle_agent_config_event(
                &cs,
                &AgentConfigEvent::ConnectionAdded(AgentConnection {
                    source_id: source.source_id.clone(),
                    request_type: pair.request_type.clone(),
                    result_type: pair.result_type.clone(),
                    has_check,
                    check_source,
                    instance_key_field: String::new(),
                    tool_policy: ToolPolicy::AllowAll,
                    available_tools: Vec::new(),
                }),
            );
        }
    }
    cs
}

/// Agent event: tag + data.
#[derive(Debug, Clone)]
pub struct AgentEvent {
    pub tag: String,
    pub data: BTreeMap<String, Value>,
}

/// Agent dispatch result: tag + data.
#[derive(Debug, Clone, Default)]
pub struct AgentDispatchResult {
    pub result_tag: String,
    pub result_data: BTreeMap<String, Value>,
}

/// The agent's inner fold: VM transducers + topology + check config.
///
/// This is the "configuration" of the fold — immutable after construction.
/// State (`Env`) is passed through the session tree, not held here.
#[derive(Debug, Clone)]
pub struct AgentFold {
    pub transducers: Vec<TransducerDef>,
    pub topology: Vec<ConnectionDef>,
    pub inbound_checks: Vec<InboundCheckDef>,
}

// ════════════════════════════════════════════════════════════════
// DomainFold impl for AgentFold
// Spec: runtime-contract.md "Domain fold" section
// ════════════════════════════════════════════════════════════════

impl DomainFold for AgentFold {
    type State = Env;
    type Event = AgentEvent;
    type Request = Value;
    type DispatchResult = AgentDispatchResult;

    fn project(&self, state: &Env, event: &AgentEvent) -> Env {
        let result = vm::exec_session(&self.transducers, state, &event.tag, &event.data);
        result.state
    }

    fn generate(&self, state: &Env, event: &AgentEvent) -> Vec<Value> {
        let result = vm::exec_session(&self.transducers, state, &event.tag, &event.data);
        result.emitted
    }

    /// Combined fold: single VM execution produces both state and emits.
    ///
    /// The VM processes all transducer rules in one pass — state updates
    /// and emits happen together. Calling project + generate separately
    /// would run the VM twice.
    fn fold(&self, state: &Env, event: &AgentEvent) -> (Env, Vec<Value>) {
        let result = vm::exec_session(&self.transducers, state, &event.tag, &event.data);
        (result.state, result.emitted)
    }

    fn event_tag(&self, event: &AgentEvent) -> String {
        event.tag.clone()
    }
}

#[cfg(test)]
fn extract_type(value: &Value) -> Option<String> {
    match value {
        Value::Map(m) => m
            .get("type")
            .and_then(|v| v.as_str())
            .map(|s| s.to_string()),
        Value::Str(s) => Some(s.clone()),
        _ => None,
    }
}

// ════════════════════════════════════════════════════════════════
// Agent session creation — interpreter model
// Task 5.3: Wire up agent InterpreterSession
// Spec: agent.qnt agent session loop
// ════════════════════════════════════════════════════════════════

use crate::interpreter::classify_result as interp_classify_result;
use crate::unified_session::Session;

/// Build the agent classify closure: extract "key" field, fall back to "type".
///
/// Spec: agent.qnt classify — uses instance_key_field if present, else request_type.
/// For Value requests the key field is "key" and the type field is "type".
pub fn agent_classify_fn(request: &Value) -> String {
    match request {
        Value::Map(m) => {
            // Instance-level key: "key" field takes precedence
            if let Some(Value::Str(k)) = m.get("key")
                && !k.is_empty() {
                    return k.clone();
                }
            // Type-level key: "type" field
            if let Some(Value::Str(t)) = m.get("type") {
                return t.clone();
            }
            // Fallback: empty string (will be kept as-is by classify)
            String::new()
        }
        Value::Str(s) => s.clone(),
        _ => String::new(),
    }
}

/// Build the agent classify_result closure: look up event tag in routing dispatch_rules.
///
/// Returns the request_type key to clear from pending, or None if this event
/// is not a result event in the routing config.
///
/// Spec: agent.qnt classify_result — reverse-lookup from result_type → request_type.
pub fn agent_classify_result_fn(
    routing: &RoutingConfig,
) -> impl Fn(&AgentEvent) -> Option<String> + Clone + 'static {
    let rules = routing.dispatch_rules.clone();
    move |event: &AgentEvent| {
        // Instance-level: if the event carries a "key" field in event.data,
        // it directly names the pending key to clear (e.g. "call_abc").
        // Type-level: reverse-lookup the request_type from dispatch_rules.
        //
        // Spec: agent.qnt classify_result — instance key takes precedence.
        let key = match event.data.get("key") {
            Some(Value::Str(k)) if !k.is_empty() => k.clone(),
            _ => String::new(),
        };
        let result = interp_classify_result(&rules, &event.tag, &key);
        if result.is_empty() {
            None
        } else {
            Some(result)
        }
    }
}

/// Create a `Session<AgentFold, AgentConnectionState>` from sources and checks.
///
/// 1. agent_boot → AgentConnectionState
/// 2. agent_derive_routing → RoutingConfig
/// 3. Build Session
///
/// Integration: this is the interpreter-model entry point for agent sessions.
/// Called by the runtime when creating an agent session with explicit source config.
pub fn create_agent_interpreter_session(
    fold: AgentFold,
    initial_state: Env,
    sources: &[SourceRegistration],
    outbound_checks: &[OutboundCheckConfig],
) -> Session<AgentFold, AgentConnectionState> {
    // Spec: agent.qnt agent_boot → connection state
    let conn_state = agent_boot(sources, outbound_checks);
    // Spec: agent.qnt agent_derive_routing → RoutingConfig
    let routing = agent_derive_routing(&conn_state);
    Session::new(fold, initial_state, conn_state, routing)
}

/// Bridge: build `AgentConnectionState` and `RoutingConfig` from legacy `ConnectionDef` topology.
///
/// Converts the old topology-based fold config to the new interpreter model.
/// Used by oracle tests and `session.rs` replay that still uses ConnectionDef.
///
/// Each `ConnectionDef` becomes an `AgentConnection` with source_id derived from
/// the request_type (e.g. "LlmRequest" → source_id "LlmRequest").
pub fn agent_conn_state_from_topology(
    topology: &[ConnectionDef],
    inbound_checks: &[InboundCheckDef],
) -> (AgentConnectionState, crate::interpreter::RoutingConfig) {
    let mut cs = AgentConnectionState::empty();
    for conn in topology {
        let new_cs = handle_agent_config_event(
            &cs,
            &AgentConfigEvent::ConnectionAdded(AgentConnection {
                // source_id: use request_type as id (legacy compat)
                source_id: conn.request_type.clone(),
                request_type: conn.request_type.clone(),
                result_type: conn.result_type.clone(),
                has_check: conn.has_check,
                check_source: conn.check_source.clone().unwrap_or_default(),
                instance_key_field: String::new(),
                tool_policy: ToolPolicy::AllowAll,
                available_tools: Vec::new(),
            }),
        );
        cs = new_cs;
    }
    let mut routing = agent_derive_routing(&cs);
    // Inbound checks come from fold config (not connection state in legacy model)
    // InboundCheckDef.intercept maps to InboundCheckRule.result_type
    for check in inbound_checks {
        routing.inbound_checks.push(crate::interpreter::InboundCheckRule {
            result_type: check.intercept.clone(),
            check_source: check.check_source.clone(),
        });
    }
    (cs, routing)
}

/// Create a `Session<AgentFold, AgentConnectionState>` from legacy topology-based fold config.
///
/// This is the bridge for code paths that have an `AgentFold` with embedded
/// `topology` and `inbound_checks` fields (e.g., oracle tests, session.rs replay).
pub fn session_from_agent_fold(
    fold: AgentFold,
    initial_state: crate::types::Env,
) -> Session<AgentFold, AgentConnectionState> {
    let (conn_state, routing) =
        agent_conn_state_from_topology(&fold.topology.clone(), &fold.inbound_checks.clone());
    Session::new(fold, initial_state, conn_state, routing)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::generic_session_tree::{self, CheckVerdict, SessionTree};
    use crate::types::*;

    fn simple_fold() -> AgentFold {
        AgentFold {
            transducers: vec![TransducerDef {
                name: "producer".into(),
                slots: vec![SlotDef {
                    name: "count".into(),
                    initial: Value::Int(0),
                }],
                rules: vec![Rule {
                    on: "Input".into(),
                    guard: Expr::Lit {
                        value: Value::Bool(true),
                    },
                    updates: vec![Update {
                        slot: "count".into(),
                        expr: Expr::Add {
                            left: Box::new(Expr::Ref {
                                name: "count".into(),
                            }),
                            right: Box::new(Expr::Lit {
                                value: Value::Int(1),
                            }),
                        },
                    }],
                    emits: vec![Expr::Rec {
                        fields: vec![RecField {
                            key: "type".into(),
                            val_expr: Expr::Lit {
                                value: Value::Str("WorkRequest".into()),
                            },
                        }],
                    }],
                }],
            }],
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: false,
                check_source: None,
            }],
            inbound_checks: vec![],
        }
    }

    fn input_event() -> AgentEvent {
        AgentEvent {
            tag: "Input".into(),
            data: BTreeMap::new(),
        }
    }

    fn result_event() -> AgentEvent {
        AgentEvent {
            tag: "WorkResult".into(),
            data: BTreeMap::new(),
        }
    }

    #[test]
    fn project_updates_state() {
        use crate::inner_fold::DomainFold;
        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let new_env = DomainFold::project(&fold, &env, &input_event());
        assert_eq!(new_env.get("count"), Some(&Value::Int(1)));
    }

    #[test]
    fn generate_emits_request() {
        use crate::inner_fold::DomainFold;
        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(1))]);
        let reqs = DomainFold::generate(&fold, &env, &input_event());
        assert_eq!(reqs.len(), 1);
        assert_eq!(extract_type(&reqs[0]), Some("WorkRequest".into()));
    }

    /// Flatten a generic session tree — extract state + pending.
    fn flatten_generic(
        tree: SessionTree<Env, Value, AgentEvent, AgentDispatchResult>,
    ) -> (Env, crate::inner_fold::KeyedPending, usize) {
        match tree {
            SessionTree::Pure(out) => (out.state, out.pending, 0),
            SessionTree::Yield { output } => (output.state, output.pending, 0),
            SessionTree::Dispatch { cont, .. } => {
                let next = cont(AgentDispatchResult::default());
                let (state, pending, count) = flatten_generic(next);
                (state, pending, count + 1)
            }
            SessionTree::Check { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_generic(next)
            }
            SessionTree::CheckEvent { cont, .. } => {
                let next = cont(CheckVerdict::Approve);
                flatten_generic(next)
            }
        }
    }

    #[test]
    fn generic_tree_pure_when_no_requests() {
        use crate::interpreter::RoutingConfig;
        let fold = AgentFold {
            transducers: vec![],
            topology: vec![],
            inbound_checks: vec![],
        };
        let env = BTreeMap::new();
        let event = input_event();
        let pending: crate::inner_fold::KeyedPending = vec![];
        let routing = RoutingConfig::empty();

        let tree = generic_session_tree::build_turn_tree(
            &fold,
            &routing,
            agent_classify_fn,
            |_: &AgentEvent| None,
            &env,
            &event,
            &pending,
        );
        assert!(matches!(tree, SessionTree::Pure(_)));
    }

    #[test]
    fn generic_tree_gates_pending() {
        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let event = input_event();
        // WorkRequest already pending — should be gated
        let pending: crate::inner_fold::KeyedPending = vec!["WorkRequest".into()];
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let cs = agent_boot(&sources, &[]);
        let routing = agent_derive_routing(&cs);
        let clf_result = agent_classify_result_fn(&routing);

        let tree = generic_session_tree::build_turn_tree(
            &fold,
            &routing,
            agent_classify_fn,
            clf_result,
            &env,
            &event,
            &pending,
        );
        // Gated → no dispatch → Pure
        assert!(matches!(tree, SessionTree::Pure(_)));
    }

    #[test]
    fn generic_tree_clears_pending_on_result() {
        use crate::inner_fold::KeyedPending;

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let event = result_event(); // WorkResult clears WorkRequest
        let pending: KeyedPending = vec!["WorkRequest".into()];
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let cs = agent_boot(&sources, &[]);
        let routing = agent_derive_routing(&cs);
        let clf_result = agent_classify_result_fn(&routing);

        let tree = generic_session_tree::build_turn_tree(
            &fold,
            &routing,
            agent_classify_fn,
            clf_result,
            &env,
            &event,
            &pending,
        );
        let (_, new_pending, _) = flatten_generic(tree);
        // WorkRequest should be cleared
        assert!(
            new_pending.is_empty(),
            "pending should be cleared: {:?}",
            new_pending
        );
    }

    // ════════════════════════════════════════════════════════════════
    // Agent interpreter tests
    // Spec: agent.qnt tests (add_connection_test, remove_connection_test, etc.)
    // ════════════════════════════════════════════════════════════════

    fn llm_conn() -> AgentConnection {
        AgentConnection {
            source_id: "llm".into(),
            request_type: "LlmRequest".into(),
            result_type: "LlmResponse".into(),
            has_check: false,
            check_source: String::new(),
            instance_key_field: String::new(),
            tool_policy: ToolPolicy::AllowAll,
            available_tools: vec![],
        }
    }

    fn tool_conn() -> AgentConnection {
        AgentConnection {
            source_id: "tools".into(),
            request_type: "ToolRequest".into(),
            result_type: "ToolResult".into(),
            has_check: false,
            check_source: String::new(),
            instance_key_field: "tool_call_id".into(),
            tool_policy: ToolPolicy::AllowAll,
            available_tools: vec!["read_file".into(), "write_file".into(), "search".into()],
        }
    }

    fn checked_tool_conn() -> AgentConnection {
        AgentConnection {
            source_id: "tools".into(),
            request_type: "ToolRequest".into(),
            result_type: "ToolResult".into(),
            has_check: true,
            check_source: "approval".into(),
            instance_key_field: "tool_call_id".into(),
            tool_policy: ToolPolicy::AllowAll,
            available_tools: vec!["read_file".into(), "write_file".into(), "search".into()],
        }
    }

    /// Spec: add_connection_test
    #[test]
    fn add_connection_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        assert_eq!(cs1.connections.len(), 1);
        assert!(cs1.connections.contains_key("llm"));

        let cs2 = handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        assert_eq!(cs2.connections.len(), 2);
        assert!(cs2.connections.contains_key("tools"));
    }

    /// Spec: remove_connection_test
    #[test]
    fn remove_connection_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let cs2 = handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let cs3 =
            handle_agent_config_event(&cs2, &AgentConfigEvent::ConnectionRemoved("llm".into()));
        assert_eq!(cs3.connections.len(), 1);
        assert!(!cs3.connections.contains_key("llm"));
        assert!(cs3.connections.contains_key("tools"));
    }

    /// Spec: agent_derive_routing_test
    #[test]
    fn agent_derive_routing_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let cs2 = handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let rc = agent_derive_routing(&cs2);
        assert_eq!(rc.dispatch_rules.len(), 2);
        assert_eq!(rc.outbound_checks.len(), 0);
        assert_eq!(rc.inbound_checks.len(), 0);
    }

    /// Spec: agent_derive_routing_with_checks_test
    #[test]
    fn agent_derive_routing_with_checks_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let cs2 = handle_agent_config_event(
            &cs1,
            &AgentConfigEvent::ConnectionAdded(checked_tool_conn()),
        );
        let rc = agent_derive_routing(&cs2);
        assert_eq!(rc.dispatch_rules.len(), 2);
        assert_eq!(rc.outbound_checks.len(), 1);
        assert_eq!(rc.outbound_checks[0].request_type, "ToolRequest");
        assert_eq!(rc.outbound_checks[0].check_source, "approval");
    }

    /// Spec: resolve_agent_source_test
    #[test]
    fn resolve_agent_source_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let cs2 = handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        assert_eq!(resolve_agent_source(&cs2, "LlmRequest"), "llm");
        assert_eq!(resolve_agent_source(&cs2, "ToolRequest"), "tools");
        assert_eq!(resolve_agent_source(&cs2, "Unknown"), "");
    }

    /// Spec: agent_dynamic_config_test
    #[test]
    fn agent_dynamic_config_test() {
        let cs0 = AgentConnectionState::empty();
        let cs0 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let rc0 = agent_derive_routing(&cs0);
        assert_eq!(rc0.dispatch_rules.len(), 1);
        assert_eq!(resolve_agent_source(&cs0, "ToolRequest"), "");

        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let rc1 = agent_derive_routing(&cs1);
        assert_eq!(rc1.dispatch_rules.len(), 2);
        assert_eq!(resolve_agent_source(&cs1, "ToolRequest"), "tools");

        let cs2 =
            handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionRemoved("tools".into()));
        let rc2 = agent_derive_routing(&cs2);
        assert_eq!(rc2.dispatch_rules.len(), 1);
        assert_eq!(resolve_agent_source(&cs2, "ToolRequest"), "");
    }

    /// Spec: tool_visibility_allow_all_test
    #[test]
    fn tool_visibility_allow_all_test() {
        let tools = visible_tools(&tool_conn());
        let mut expected = vec![
            "read_file".to_string(),
            "write_file".to_string(),
            "search".to_string(),
        ];
        let mut actual = tools.clone();
        expected.sort();
        actual.sort();
        assert_eq!(actual, expected);
    }

    /// Spec: tool_visibility_allow_list_test
    #[test]
    fn tool_visibility_allow_list_test() {
        let mut conn = tool_conn();
        conn.tool_policy = ToolPolicy::AllowList(vec!["read_file".into()]);
        let tools = visible_tools(&conn);
        assert_eq!(tools, vec!["read_file"]);
    }

    /// Spec: tool_visibility_deny_list_test
    #[test]
    fn tool_visibility_deny_list_test() {
        let mut conn = tool_conn();
        conn.tool_policy = ToolPolicy::DenyList(vec!["write_file".into()]);
        let tools = visible_tools(&conn);
        let mut actual = tools.clone();
        actual.sort();
        assert_eq!(actual, vec!["read_file", "search"]);
    }

    /// Spec: all_visible_tools_test
    #[test]
    fn all_visible_tools_test() {
        let cs0 = AgentConnectionState::empty();
        let cs1 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(llm_conn()));
        let cs2 = handle_agent_config_event(&cs1, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let all_tools = all_visible_tools(&cs2);
        // llm has no tools → not in map
        assert!(!all_tools.contains_key("llm"));
        // tools source has 3 tools
        assert!(all_tools.contains_key("tools"));
        let mut t = all_tools["tools"].clone();
        t.sort();
        assert_eq!(t, vec!["read_file", "search", "write_file"]);
    }

    /// Spec: effects_connection_added_test
    #[test]
    fn effects_connection_added_test() {
        let cs0 = AgentConnectionState::empty();
        let event = AgentConfigEvent::ConnectionAdded(tool_conn());
        let cs1 = handle_agent_config_event(&cs0, &event);
        let effects = derive_agent_effects(&cs0, &cs1, &event);
        assert_eq!(effects.len(), 2);
        assert_eq!(effects[0], RuntimeEffect::StartSource("tools".into()));
        // Second effect: UpdateToolSchemas with the 3 tools
        if let RuntimeEffect::UpdateToolSchemas { source_id, tools } = &effects[1] {
            assert_eq!(source_id, "tools");
            let mut t = tools.clone();
            t.sort();
            assert_eq!(t, vec!["read_file", "search", "write_file"]);
        } else {
            panic!("expected UpdateToolSchemas, got {:?}", effects[1]);
        }
    }

    /// Spec: effects_connection_added_no_tools_test
    #[test]
    fn effects_connection_added_no_tools_test() {
        let cs0 = AgentConnectionState::empty();
        let event = AgentConfigEvent::ConnectionAdded(llm_conn());
        let cs1 = handle_agent_config_event(&cs0, &event);
        let effects = derive_agent_effects(&cs0, &cs1, &event);
        assert_eq!(effects.len(), 1);
        assert_eq!(effects[0], RuntimeEffect::StartSource("llm".into()));
    }

    /// Spec: effects_connection_removed_test
    #[test]
    fn effects_connection_removed_test() {
        let cs0 = AgentConnectionState::empty();
        let cs0 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let event = AgentConfigEvent::ConnectionRemoved("tools".into());
        let cs1 = handle_agent_config_event(&cs0, &event);
        let effects = derive_agent_effects(&cs0, &cs1, &event);
        assert_eq!(effects.len(), 1);
        assert_eq!(effects[0], RuntimeEffect::StopSource("tools".into()));
    }

    /// Spec: tool_visibility_change_test
    #[test]
    fn tool_visibility_change_test() {
        let cs0 = AgentConnectionState::empty();
        let cs0 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let event = AgentConfigEvent::ToolVisibilityChanged {
            source_id: "tools".into(),
            policy: ToolPolicy::AllowList(vec!["read_file".into()]),
        };
        let cs1 = handle_agent_config_event(&cs0, &event);
        let tools = visible_tools(cs1.connections.get("tools").unwrap());
        assert_eq!(tools, vec!["read_file"]);
        let effects = derive_agent_effects(&cs0, &cs1, &event);
        assert_eq!(effects.len(), 1);
        if let RuntimeEffect::UpdateToolSchemas { source_id, tools } = &effects[0] {
            assert_eq!(source_id, "tools");
            assert_eq!(tools, &vec!["read_file".to_string()]);
        } else {
            panic!("expected UpdateToolSchemas, got {:?}", effects[0]);
        }
    }

    /// Spec: tools_available_change_test
    #[test]
    fn tools_available_change_test() {
        let cs0 = AgentConnectionState::empty();
        let cs0 = handle_agent_config_event(&cs0, &AgentConfigEvent::ConnectionAdded(tool_conn()));
        let event = AgentConfigEvent::ToolsAvailableChanged {
            source_id: "tools".into(),
            tools: vec![
                "read_file".into(),
                "write_file".into(),
                "search".into(),
                "execute".into(),
            ],
        };
        let cs1 = handle_agent_config_event(&cs0, &event);
        let mut tools = visible_tools(cs1.connections.get("tools").unwrap());
        tools.sort();
        assert_eq!(tools, vec!["execute", "read_file", "search", "write_file"]);
    }

    // ── agent_boot tests ──────────────────────────────

    /// Spec: agent_boot builds connection state from source registrations.
    #[test]
    fn agent_boot_builds_connections() {

        let sources = vec![
            SourceRegistration {
                source_id: "llm".into(),
                pairs: vec![SourcePair {
                    request_type: "LlmRequest".into(),
                    result_type: "LlmResponse".into(),
                }],
            },
            SourceRegistration {
                source_id: "tools".into(),
                pairs: vec![SourcePair {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                }],
            },
        ];
        let checks = vec![OutboundCheckConfig {
            request_type: "ToolRequest".into(),
            check_source: "approval".into(),
        }];
        let cs = agent_boot(&sources, &checks);
        assert_eq!(cs.connections.len(), 2);
        assert_eq!(resolve_agent_source(&cs, "LlmRequest"), "llm");
        assert_eq!(resolve_agent_source(&cs, "ToolRequest"), "tools");
        // ToolRequest should have a check
        let tool_conn = cs.connections.get("tools").unwrap();
        assert!(tool_conn.has_check);
        assert_eq!(tool_conn.check_source, "approval");
        // LlmRequest should not have a check
        let llm = cs.connections.get("llm").unwrap();
        assert!(!llm.has_check);
    }

    /// Verify routing derived from agent_boot matches sources.
    #[test]
    fn agent_boot_routing_test() {

        let sources = vec![SourceRegistration {
            source_id: "llm".into(),
            pairs: vec![SourcePair {
                request_type: "LlmRequest".into(),
                result_type: "LlmResponse".into(),
            }],
        }];
        let cs = agent_boot(&sources, &[]);
        let rc = agent_derive_routing(&cs);
        assert_eq!(rc.dispatch_rules.len(), 1);
        assert_eq!(rc.dispatch_rules[0].request_type, "LlmRequest");
        assert_eq!(rc.dispatch_rules[0].result_type, "LlmResponse");
        assert!(rc.outbound_checks.is_empty());
    }

    // ── DomainFold impl tests ──────────────────────────────

    /// Verify DomainFold event_tag delegates correctly.
    #[test]
    fn agent_domain_fold_event_tag() {
        use crate::inner_fold::DomainFold;
        let fold = simple_fold();
        let event = input_event();
        assert_eq!(DomainFold::event_tag(&fold, &event), "Input");
    }

    // ── Session agent tests (Task 5.3) ─────────
    // Integration verified: Session::fold_event called via
    // create_agent_interpreter_session in agent_fold.rs

    /// classify_fn extracts "type" field from Value request.
    #[test]
    fn agent_classify_fn_type_field() {
        let req = Value::Map(BTreeMap::from([(
            "type".into(),
            Value::Str("WorkRequest".into()),
        )]));
        let key = agent_classify_fn(&req);
        assert_eq!(key, "WorkRequest");
    }

    /// classify_fn extracts "key" field when present (instance-level gating).
    #[test]
    fn agent_classify_fn_key_field_takes_priority() {
        let req = Value::Map(BTreeMap::from([
            ("type".into(), Value::Str("ToolRequest".into())),
            ("key".into(), Value::Str("call_abc".into())),
        ]));
        let key = agent_classify_fn(&req);
        assert_eq!(key, "call_abc");
    }

    /// agent_classify_result_fn: WorkResult → clears "WorkRequest" from pending.
    #[test]
    fn agent_classify_result_fn_clears_correct_key() {

        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let cs = agent_boot(&sources, &[]);
        let routing = agent_derive_routing(&cs);
        let clf = agent_classify_result_fn(&routing);
        let result_ev = result_event();
        assert_eq!(clf(&result_ev), Some("WorkRequest".into()));
    }

    /// create_agent_interpreter_session: basic fold produces dispatch.
    #[test]
    fn agent_interpreter_session_fold_event() {

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);

        let result = session.fold_event(
            &input_event(),
            agent_classify_fn,
            agent_classify_result_fn(&session.routing.clone()),
        );

        // One WorkRequest should be dispatched
        assert_eq!(result.requests.len(), 1);
        assert!(!session.is_idle());
        assert_eq!(session.pending(), &["WorkRequest"]);
    }

    /// Gate: same key blocked while pending, different keys pass.
    #[test]
    fn agent_interpreter_session_gate_while_pending() {

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);

        let clf = agent_classify_result_fn(&session.routing.clone());

        // First event: dispatches WorkRequest
        let r1 = session.fold_event(&input_event(), agent_classify_fn, clf.clone());
        assert_eq!(r1.requests.len(), 1);

        // Second Input while WorkRequest pending: gated (no dispatch), fold still runs
        let r2 = session.fold_event(&input_event(), agent_classify_fn, clf.clone());
        assert_eq!(r2.requests.len(), 0); // gated
        // state updated even when gated
        assert_eq!(session.state.get("count"), Some(&Value::Int(2)));
    }

    /// Result event clears pending.
    #[test]
    fn agent_interpreter_session_clear_pending_on_result() {

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);

        let clf = agent_classify_result_fn(&session.routing.clone());

        session.fold_event(&input_event(), agent_classify_fn, clf.clone());
        assert!(!session.is_idle());

        session.fold_event(&result_event(), agent_classify_fn, clf);
        assert!(session.is_idle());
    }

    /// receive_config_event: adding a connection updates routing.
    #[test]
    fn agent_interpreter_session_config_event_updates_routing() {
        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let mut session = Session::new(
            fold,
            env,
            AgentConnectionState::empty(),
            RoutingConfig::empty(),
        );

        // Initially no dispatch rules
        assert!(session.routing.dispatch_rules.is_empty());

        // Receive config event: add connection
        let new_conn = AgentConnection {
            source_id: "worker".into(),
            request_type: "WorkRequest".into(),
            result_type: "WorkResult".into(),
            has_check: false,
            check_source: String::new(),
            instance_key_field: String::new(),
            tool_policy: ToolPolicy::AllowAll,
            available_tools: Vec::new(),
        };
        session.receive_config_event(
            AgentConfigEvent::ConnectionAdded(new_conn),
            |cs, ev| handle_agent_config_event(cs, &ev),
            |cs| agent_derive_routing(cs),
        );

        assert_eq!(session.routing.dispatch_rules.len(), 1);
        assert_eq!(
            session.routing.dispatch_rules[0].request_type,
            "WorkRequest"
        );
    }

    /// cancel_request removes key from pending.
    #[test]
    fn agent_interpreter_session_cancel_request() {

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);

        let clf = agent_classify_result_fn(&session.routing.clone());
        session.fold_event(&input_event(), agent_classify_fn, clf);
        assert!(!session.is_idle());

        session.cancel_request("WorkRequest");
        assert!(session.is_idle());
    }

    /// event_log tracks processed events.
    #[test]
    fn agent_interpreter_session_event_log() {

        let fold = simple_fold();
        let env = BTreeMap::from([("count".into(), Value::Int(0))]);
        let sources = vec![SourceRegistration {
            source_id: "worker".into(),
            pairs: vec![SourcePair {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
            }],
        }];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);

        let clf = agent_classify_result_fn(&session.routing.clone());
        session.fold_event(&input_event(), agent_classify_fn, clf.clone());
        session.fold_event(&result_event(), agent_classify_fn, clf);
        assert_eq!(session.event_log(), &["Input", "WorkResult"]);
        assert_eq!(session.events_processed(), 2);
    }

    /// Stdlib through Session::fold_event: ToolRequest should have instance-level key.
    #[test]
    fn stdlib_tool_request_has_instance_key_via_session() {
        use crate::loader::init_env;
        use crate::stdlib::stdlib;

        let tds = stdlib();
        let fold = AgentFold {
            transducers: tds.clone(),
            topology: vec![
                ConnectionDef {
                    request_type: "LlmRequest".into(),
                    result_type: "LlmResponse".into(),
                    has_check: false,
                    check_source: None,
                },
                ConnectionDef {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                    has_check: false,
                    check_source: None,
                },
            ],
            inbound_checks: vec![],
        };
        let env = init_env(&tds);
        let sources = vec![
            SourceRegistration {
                source_id: "llm".into(),
                pairs: vec![SourcePair {
                    request_type: "LlmRequest".into(),
                    result_type: "LlmResponse".into(),
                }],
            },
            SourceRegistration {
                source_id: "tools".into(),
                pairs: vec![SourcePair {
                    request_type: "ToolRequest".into(),
                    result_type: "ToolResult".into(),
                }],
            },
        ];
        let mut session = create_agent_interpreter_session(fold, env, &sources, &[]);
        let clf = agent_classify_result_fn(&session.routing.clone());

        // User message → LlmRequest
        let user_event = AgentEvent {
            tag: "LlmResponse".into(),
            data: BTreeMap::from([
                ("role".into(), Value::Str("user".into())),
                ("parts".into(), Value::List(vec![{
                    let mut m = BTreeMap::new();
                    m.insert("kind".into(), Value::Str("text".into()));
                    m.insert("text".into(), Value::Str("hi".into()));
                    Value::Map(m)
                }])),
                ("input_tokens".into(), Value::Int(0)),
                ("output_tokens".into(), Value::Int(0)),
            ]),
        };
        let r1 = session.fold_event(&user_event, agent_classify_fn, clf.clone());
        assert_eq!(r1.requests.len(), 1); // LlmRequest

        // LlmResponse with tool_calls → ToolRequest
        let llm_response = AgentEvent {
            tag: "LlmResponse".into(),
            data: BTreeMap::from([
                ("role".into(), Value::Str("assistant".into())),
                ("parts".into(), Value::List(vec![])),
                ("tool_calls".into(), Value::List(vec![{
                    let mut m = BTreeMap::new();
                    m.insert("id".into(), Value::Str("tc1".into()));
                    m.insert("name".into(), Value::Str("read_file".into()));
                    m.insert("arguments".into(), Value::Str("{}".into()));
                    Value::Map(m)
                }])),
                ("input_tokens".into(), Value::Int(10)),
                ("output_tokens".into(), Value::Int(5)),
            ]),
        };
        let r2 = session.fold_event(&llm_response, agent_classify_fn, clf.clone());

        // Should have ToolRequest(s) dispatched
        assert!(!r2.requests.is_empty(), "expected ToolRequest dispatch");

        // Check the dispatched request has instance-level key
        for req in &r2.requests {
            match req {
                crate::unified_session::ClassifiedRequest::Dispatch(value) => {
                    if let Value::Map(m) = value {
                        let req_type = m.get("type").and_then(|v| v.as_str());
                        if req_type == Some("ToolRequest") {
                            let key = m.get("key");
                            assert!(
                                key.is_some(),
                                "ToolRequest should have 'key' field, got keys: {:?}",
                                m.keys().collect::<Vec<_>>()
                            );
                            assert_eq!(
                                key.unwrap().as_str(),
                                Some("ToolRequest:tc1"),
                                "key should be instance-level"
                            );
                        }
                    }
                }
                _ => {}
            }
        }

        // Pending should use instance-level key
        assert!(
            session.pending().contains(&"ToolRequest:tc1".to_string()),
            "pending should have instance-level key 'ToolRequest:tc1', got: {:?}",
            session.pending()
        );
    }
}
