//! Serialization — JSON and MessagePack for TransducerDefs.
//!
//! Both formats use the same serde derives. The caller picks the format.
//! JSON for debugging/fixtures/human-readable. MessagePack for production.

extern crate std;

use crate::prelude::*;
use crate::types::TransducerDef;

#[derive(Debug)]
pub enum SerdeError {
    Json(serde_json::Error),
    MsgPack(rmp_serde::encode::Error),
    MsgPackDecode(rmp_serde::decode::Error),
}

impl std::fmt::Display for SerdeError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SerdeError::Json(e) => write!(f, "JSON error: {e}"),
            SerdeError::MsgPack(e) => write!(f, "MessagePack encode error: {e}"),
            SerdeError::MsgPackDecode(e) => write!(f, "MessagePack decode error: {e}"),
        }
    }
}

impl std::error::Error for SerdeError {}

impl From<serde_json::Error> for SerdeError {
    fn from(e: serde_json::Error) -> Self {
        SerdeError::Json(e)
    }
}

impl From<rmp_serde::encode::Error> for SerdeError {
    fn from(e: rmp_serde::encode::Error) -> Self {
        SerdeError::MsgPack(e)
    }
}

impl From<rmp_serde::decode::Error> for SerdeError {
    fn from(e: rmp_serde::decode::Error) -> Self {
        SerdeError::MsgPackDecode(e)
    }
}

// ── JSON ────────────────────────────────────────────────────

pub fn to_json(td: &TransducerDef) -> Result<String, SerdeError> {
    Ok(serde_json::to_string(td)?)
}

pub fn to_json_pretty(td: &TransducerDef) -> Result<String, SerdeError> {
    Ok(serde_json::to_string_pretty(td)?)
}

pub fn from_json(json: &str) -> Result<TransducerDef, SerdeError> {
    Ok(serde_json::from_str(json)?)
}

pub fn many_from_json(json: &str) -> Result<Vec<TransducerDef>, SerdeError> {
    Ok(serde_json::from_str(json)?)
}

// ── MessagePack ─────────────────────────────────────────────

pub fn to_msgpack(td: &TransducerDef) -> Result<Vec<u8>, SerdeError> {
    Ok(rmp_serde::to_vec(td)?)
}

pub fn from_msgpack(bytes: &[u8]) -> Result<TransducerDef, SerdeError> {
    Ok(rmp_serde::from_slice(bytes)?)
}

pub fn many_to_msgpack(tds: &[TransducerDef]) -> Result<Vec<u8>, SerdeError> {
    Ok(rmp_serde::to_vec(tds)?)
}

pub fn many_from_msgpack(bytes: &[u8]) -> Result<Vec<TransducerDef>, SerdeError> {
    Ok(rmp_serde::from_slice(bytes)?)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::*;

    fn sample_td() -> TransducerDef {
        TransducerDef {
            name: "counter".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        }
    }

    #[test]
    fn json_roundtrip() {
        let td = sample_td();
        let json = to_json(&td).unwrap();
        let td2 = from_json(&json).unwrap();
        assert_eq!(td, td2);
    }

    #[test]
    fn json_pretty_roundtrip() {
        let td = sample_td();
        let json = to_json_pretty(&td).unwrap();
        let td2 = from_json(&json).unwrap();
        assert_eq!(td, td2);
    }

    #[test]
    fn msgpack_roundtrip() {
        let td = sample_td();
        let bytes = to_msgpack(&td).unwrap();
        let td2 = from_msgpack(&bytes).unwrap();
        assert_eq!(td, td2);
    }

    #[test]
    fn msgpack_smaller_than_json() {
        let td = sample_td();
        let json = to_json(&td).unwrap();
        let bytes = to_msgpack(&td).unwrap();
        assert!(
            bytes.len() < json.len(),
            "msgpack ({}) should be smaller than json ({})",
            bytes.len(),
            json.len()
        );
    }

    #[test]
    fn many_msgpack_roundtrip() {
        let tds = vec![sample_td(), sample_td()];
        let bytes = many_to_msgpack(&tds).unwrap();
        let tds2 = many_from_msgpack(&bytes).unwrap();
        assert_eq!(tds, tds2);
    }

    #[test]
    fn fixture_json_to_msgpack_roundtrip() {
        let td: TransducerDef =
            serde_json::from_str(include_str!("../tests/fixtures/messages_td.json")).unwrap();
        let bytes = to_msgpack(&td).unwrap();
        let td2 = from_msgpack(&bytes).unwrap();
        assert_eq!(td, td2);
    }
}
