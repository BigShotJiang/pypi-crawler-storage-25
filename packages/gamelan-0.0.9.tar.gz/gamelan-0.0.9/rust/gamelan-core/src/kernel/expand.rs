//! Macro expansion — load-time substitution of macro invocations.
//!
//! Maps from Loader.v: substitute, expand, expansion properties.
//! Macros are named Expr templates with parameters. Expansion is
//! pure substitution — no conditionals, no recursion in expansion.
//!
//! Pipeline: .td.json/.td.msgpack → expand → validate → VM executes.
//! Both formats can contain Expr::Macro nodes. After expansion, only
//! the 16 VM primitives remain.

use crate::prelude::*;
use crate::types::{Expr, RecField, Rule, TransducerDef, Update, Value};
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

/// A macro definition: name, parameter names, body expression.
/// `bindings`: indices of params that are binding names (substituted
/// into String fields like item_var/acc_var in LFold, name in ELet).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MacroDef {
    pub name: String,
    pub params: Vec<String>,
    #[serde(default)]
    pub bindings: Vec<usize>,
    pub body: Expr,
}

/// Errors that can occur during macro expansion.
#[derive(Debug, Clone, PartialEq)]
pub enum ExpandError {
    /// A macro invocation references an undefined macro.
    UnknownMacro { name: String },
    /// A macro invocation has the wrong number of arguments.
    ArityMismatch {
        name: String,
        expected: usize,
        got: usize,
    },
    /// Expansion exceeded the fuel limit (cyclic macros).
    FuelExhausted { name: String },
}

/// A macro environment maps names to definitions.
pub type MacroEnv = BTreeMap<String, MacroDef>;

/// Extract a binding name from a String field.
/// If the string matches a binding parameter, extract the string
/// from the corresponding Lit(Str(...)) argument.
/// Maps to Lean `extract_binding_name`.
fn extract_binding_name(params: &[String], args: &[Expr], bindings: &[usize], s: &str) -> String {
    if let Some(idx) = params.iter().position(|p| p == s)
        && bindings.contains(&idx)
            && let Some(Expr::Lit {
                value: Value::Str(new_name),
            }) = args.get(idx)
            {
                return new_name.clone();
            }
    s.to_string()
}

/// Substitute parameter references with argument expressions.
/// Binding params are additionally substituted in String positions
/// (item_var, acc_var in LFold; name in ELet).
/// Maps to Lean `substitute`.
fn substitute(params: &[String], args: &[Expr], bindings: &[usize], expr: &Expr) -> Expr {
    match expr {
        Expr::Lit { value } => Expr::Lit {
            value: value.clone(),
        },

        Expr::Ref { name } => {
            if let Some(idx) = params.iter().position(|p| p == name) {
                if let Some(arg) = args.get(idx) {
                    arg.clone()
                } else {
                    expr.clone()
                }
            } else {
                expr.clone()
            }
        }

        Expr::Add { left, right } => Expr::Add {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::Mul { left, right } => Expr::Mul {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::Div { left, right } => Expr::Div {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::Mod { left, right } => Expr::Mod {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::Gt { left, right } => Expr::Gt {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::Eq { left, right } => Expr::Eq {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },
        Expr::LAppend { list, item } => Expr::LAppend {
            list: Box::new(substitute(params, args, bindings, list)),
            item: Box::new(substitute(params, args, bindings, item)),
        },
        Expr::MPut { map, key, value } => Expr::MPut {
            map: Box::new(substitute(params, args, bindings, map)),
            key: Box::new(substitute(params, args, bindings, key)),
            value: Box::new(substitute(params, args, bindings, value)),
        },
        Expr::MGet { map, key, type_ann } => Expr::MGet {
            map: Box::new(substitute(params, args, bindings, map)),
            key: Box::new(substitute(params, args, bindings, key)),
            type_ann: *type_ann,
        },
        Expr::MDel { map, key } => Expr::MDel {
            map: Box::new(substitute(params, args, bindings, map)),
            key: Box::new(substitute(params, args, bindings, key)),
        },
        Expr::MKeys { map } => Expr::MKeys {
            map: Box::new(substitute(params, args, bindings, map)),
        },
        Expr::Rec { fields } => Expr::Rec {
            fields: fields
                .iter()
                .map(|f| RecField {
                    key: f.key.clone(),
                    val_expr: substitute(params, args, bindings, &f.val_expr),
                })
                .collect(),
        },

        Expr::ELet { name, value, body } => Expr::ELet {
            name: extract_binding_name(params, args, bindings, name),
            value: Box::new(substitute(params, args, bindings, value)),
            body: Box::new(substitute(params, args, bindings, body)),
        },

        Expr::IfElse {
            cond,
            then_expr,
            else_expr,
        } => Expr::IfElse {
            cond: Box::new(substitute(params, args, bindings, cond)),
            then_expr: Box::new(substitute(params, args, bindings, then_expr)),
            else_expr: Box::new(substitute(params, args, bindings, else_expr)),
        },

        Expr::StrCat { left, right } => Expr::StrCat {
            left: Box::new(substitute(params, args, bindings, left)),
            right: Box::new(substitute(params, args, bindings, right)),
        },

        Expr::LFold {
            list,
            init,
            acc_var,
            item_var,
            body,
            item_type_ann,
        } => Expr::LFold {
            list: Box::new(substitute(params, args, bindings, list)),
            init: Box::new(substitute(params, args, bindings, init)),
            acc_var: extract_binding_name(params, args, bindings, acc_var),
            item_var: extract_binding_name(params, args, bindings, item_var),
            body: Box::new(substitute(params, args, bindings, body)),
            item_type_ann: *item_type_ann,
        },

        // Macro nodes inside a macro body — substitute their args too
        Expr::Macro {
            name,
            args: macro_args,
        } => Expr::Macro {
            name: name.clone(),
            args: macro_args
                .iter()
                .map(|a| substitute(params, args, bindings, a))
                .collect(),
        },
    }
}

/// Expand all macro invocations in an expression.
/// Uses a fuel parameter for termination (acyclic macros exhaust in depth = env size).
fn expand_expr(env: &MacroEnv, expr: &Expr, fuel: usize) -> Result<Expr, ExpandError> {
    if fuel == 0
        && let Expr::Macro { name, .. } = expr {
            return Err(ExpandError::FuelExhausted { name: name.clone() });
        }

    match expr {
        Expr::Macro { name, args } => {
            let mdef = env
                .get(name)
                .ok_or_else(|| ExpandError::UnknownMacro { name: name.clone() })?;

            if args.len() != mdef.params.len() {
                return Err(ExpandError::ArityMismatch {
                    name: name.clone(),
                    expected: mdef.params.len(),
                    got: args.len(),
                });
            }

            // Expand arguments first
            let expanded_args: Vec<Expr> = args
                .iter()
                .map(|a| expand_expr(env, a, fuel.saturating_sub(1)))
                .collect::<Result<_, _>>()?;

            // Substitute into body
            let substituted = substitute(&mdef.params, &expanded_args, &mdef.bindings, &mdef.body);

            // Recursively expand in case body contains macros
            expand_expr(env, &substituted, fuel.saturating_sub(1))
        }

        // Non-macro nodes: recurse into children
        Expr::Lit { .. } | Expr::Ref { .. } => Ok(expr.clone()),

        Expr::Add { left, right } => Ok(Expr::Add {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::Mul { left, right } => Ok(Expr::Mul {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::Div { left, right } => Ok(Expr::Div {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::Mod { left, right } => Ok(Expr::Mod {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::Gt { left, right } => Ok(Expr::Gt {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::Eq { left, right } => Ok(Expr::Eq {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),
        Expr::LAppend { list, item } => Ok(Expr::LAppend {
            list: Box::new(expand_expr(env, list, fuel)?),
            item: Box::new(expand_expr(env, item, fuel)?),
        }),
        Expr::MPut { map, key, value } => Ok(Expr::MPut {
            map: Box::new(expand_expr(env, map, fuel)?),
            key: Box::new(expand_expr(env, key, fuel)?),
            value: Box::new(expand_expr(env, value, fuel)?),
        }),
        Expr::MGet { map, key, type_ann } => Ok(Expr::MGet {
            map: Box::new(expand_expr(env, map, fuel)?),
            key: Box::new(expand_expr(env, key, fuel)?),
            type_ann: *type_ann,
        }),
        Expr::MDel { map, key } => Ok(Expr::MDel {
            map: Box::new(expand_expr(env, map, fuel)?),
            key: Box::new(expand_expr(env, key, fuel)?),
        }),
        Expr::MKeys { map } => Ok(Expr::MKeys {
            map: Box::new(expand_expr(env, map, fuel)?),
        }),
        Expr::Rec { fields } => Ok(Expr::Rec {
            fields: fields
                .iter()
                .map(|f| {
                    Ok(RecField {
                        key: f.key.clone(),
                        val_expr: expand_expr(env, &f.val_expr, fuel)?,
                    })
                })
                .collect::<Result<_, ExpandError>>()?,
        }),

        Expr::ELet { name, value, body } => Ok(Expr::ELet {
            name: name.clone(),
            value: Box::new(expand_expr(env, value, fuel)?),
            body: Box::new(expand_expr(env, body, fuel)?),
        }),

        Expr::IfElse {
            cond,
            then_expr,
            else_expr,
        } => Ok(Expr::IfElse {
            cond: Box::new(expand_expr(env, cond, fuel)?),
            then_expr: Box::new(expand_expr(env, then_expr, fuel)?),
            else_expr: Box::new(expand_expr(env, else_expr, fuel)?),
        }),

        Expr::StrCat { left, right } => Ok(Expr::StrCat {
            left: Box::new(expand_expr(env, left, fuel)?),
            right: Box::new(expand_expr(env, right, fuel)?),
        }),

        Expr::LFold {
            list,
            init,
            acc_var,
            item_var,
            body,
            item_type_ann,
        } => Ok(Expr::LFold {
            list: Box::new(expand_expr(env, list, fuel)?),
            init: Box::new(expand_expr(env, init, fuel)?),
            acc_var: acc_var.clone(),
            item_var: item_var.clone(),
            body: Box::new(expand_expr(env, body, fuel)?),
            item_type_ann: *item_type_ann,
        }),
    }
}

/// Expand all macros in a Rule.
fn expand_rule(env: &MacroEnv, rule: &Rule, fuel: usize) -> Result<Rule, ExpandError> {
    Ok(Rule {
        on: rule.on.clone(),
        guard: expand_expr(env, &rule.guard, fuel)?,
        updates: rule
            .updates
            .iter()
            .map(|u| {
                Ok(Update {
                    slot: u.slot.clone(),
                    expr: expand_expr(env, &u.expr, fuel)?,
                })
            })
            .collect::<Result<_, ExpandError>>()?,
        emits: rule
            .emits
            .iter()
            .map(|e| expand_expr(env, e, fuel))
            .collect::<Result<_, ExpandError>>()?,
    })
}

/// Expand all macros in a TransducerDef.
pub fn expand_transducer(env: &MacroEnv, td: &TransducerDef) -> Result<TransducerDef, ExpandError> {
    let fuel = env.len() + 1; // acyclic macros resolve in depth ≤ env size
    Ok(TransducerDef {
        name: td.name.clone(),
        slots: td.slots.clone(),
        rules: td
            .rules
            .iter()
            .map(|r| expand_rule(env, r, fuel))
            .collect::<Result<_, ExpandError>>()?,
    })
}

/// Expand all macros in a list of TransducerDefs.
pub fn expand_session(
    env: &MacroEnv,
    tds: &[TransducerDef],
) -> Result<Vec<TransducerDef>, ExpandError> {
    tds.iter().map(|td| expand_transducer(env, td)).collect()
}

/// Expand macros in a single expression.
/// Public wrapper for golden oracle tests.
pub fn expand_single_expr(env: &MacroEnv, expr: &Expr) -> Result<Expr, ExpandError> {
    let fuel = env.len() + 1;
    expand_expr(env, expr, fuel)
}

/// Build a MacroEnv from a list of MacroDefs.
pub fn macro_env(macros: Vec<MacroDef>) -> MacroEnv {
    macros.into_iter().map(|m| (m.name.clone(), m)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::Value;

    fn make_env() -> MacroEnv {
        // len(list) => LFold counting
        let len_macro = MacroDef {
            name: "len".into(),
            params: vec!["list".into()],
            bindings: vec![],
            body: Expr::LFold {
                list: Box::new(Expr::Ref {
                    name: "list".into(),
                }),
                init: Box::new(Expr::Lit {
                    value: Value::Int(0),
                }),
                acc_var: "__acc".into(),
                item_var: "__x".into(),
                body: Box::new(Expr::Add {
                    left: Box::new(Expr::Ref {
                        name: "__acc".into(),
                    }),
                    right: Box::new(Expr::Lit {
                        value: Value::Int(1),
                    }),
                }),
                item_type_ann: None,
            },
        };

        macro_env(vec![len_macro])
    }

    #[test]
    fn expand_no_macros_is_identity() {
        let env = make_env();
        let expr = Expr::Add {
            left: Box::new(Expr::Ref { name: "x".into() }),
            right: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
        };
        let result = expand_expr(&env, &expr, 10).unwrap();
        assert_eq!(result, expr);
    }

    #[test]
    fn expand_simple_macro() {
        let env = make_env();
        let expr = Expr::Macro {
            name: "len".into(),
            args: vec![Expr::Ref {
                name: "messages".into(),
            }],
        };
        let result = expand_expr(&env, &expr, 10).unwrap();

        // Should be LFold over messages
        match &result {
            Expr::LFold { list, .. } => match list.as_ref() {
                Expr::Ref { name } => assert_eq!(name, "messages"),
                other => panic!("expected Ref(messages), got {:?}", other),
            },
            other => panic!("expected LFold, got {:?}", other),
        }
    }

    #[test]
    fn expand_unknown_macro_errors() {
        let env = make_env();
        let expr = Expr::Macro {
            name: "nonexistent".into(),
            args: vec![],
        };
        let result = expand_expr(&env, &expr, 10);
        assert!(matches!(result, Err(ExpandError::UnknownMacro { .. })));
    }

    #[test]
    fn expand_arity_mismatch_errors() {
        let env = make_env();
        let expr = Expr::Macro {
            name: "len".into(),
            args: vec![], // expects 1 arg
        };
        let result = expand_expr(&env, &expr, 10);
        assert!(matches!(result, Err(ExpandError::ArityMismatch { .. })));
    }

    #[test]
    fn expand_nested_in_rule() {
        let env = make_env();
        let rule = Rule {
            on: "LlmResponse".into(),
            guard: Expr::Gt {
                left: Box::new(Expr::Macro {
                    name: "len".into(),
                    args: vec![Expr::Ref {
                        name: "messages".into(),
                    }],
                }),
                right: Box::new(Expr::Lit {
                    value: Value::Int(10),
                }),
            },
            updates: vec![],
            emits: vec![],
        };
        let result = expand_rule(&env, &rule, 10).unwrap();

        // Guard should be Gt(LFold(...), Lit(10))
        match &result.guard {
            Expr::Gt { left, .. } => assert!(matches!(left.as_ref(), Expr::LFold { .. })),
            other => panic!("expected Gt, got {:?}", other),
        }
    }

    #[test]
    fn expand_transducer_preserves_structure() {
        let env = make_env();
        let td = TransducerDef {
            name: "test".into(),
            slots: vec![crate::types::SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Macro {
                        name: "len".into(),
                        args: vec![Expr::Ref {
                            name: "items".into(),
                        }],
                    },
                }],
                emits: vec![],
            }],
        };
        let result = expand_transducer(&env, &td).unwrap();

        assert_eq!(result.name, "test");
        assert_eq!(result.slots.len(), 1);
        assert_eq!(result.rules.len(), 1);
        // The update expr should be expanded from Macro to LFold
        match &result.rules[0].updates[0].expr {
            Expr::LFold { list, .. } => match list.as_ref() {
                Expr::Ref { name } => assert_eq!(name, "items"),
                other => panic!("expected Ref(items), got {:?}", other),
            },
            other => panic!("expected LFold, got {:?}", other),
        }
    }

    #[test]
    fn macro_free_stdlib_unchanged() {
        // Existing stdlib transducers have no Macro nodes.
        // Expansion should be a no-op.
        let env = make_env();
        let tds = crate::stdlib::stdlib();
        let expanded = expand_session(&env, &tds).unwrap();
        assert_eq!(tds, expanded);
    }
}
