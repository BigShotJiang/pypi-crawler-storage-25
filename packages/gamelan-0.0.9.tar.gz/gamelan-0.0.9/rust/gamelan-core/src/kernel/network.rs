//! Network types — config and errors for the network coordination layer.
//!
//! The `Network` struct has been merged into `NetworkSession`. This module
//! retains `NetworkConfig` and `NetworkError` which are used for construction
//! and error reporting.

use crate::coordinator::CoordinatorError;
use crate::prelude::*;

// ════════════════════════════════════════════════════════════════
// Network config
// ════════════════════════════════════════════════════════════════

/// Check configuration for a network-to-agent connection.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct NetworkCheckDef {
    /// The network event type to intercept.
    pub intercept: String,
    /// The check source identifier (opaque to the fold).
    pub check_source: String,
}

/// Static configuration for a network. The "environment."
#[derive(Debug, Clone)]
pub struct NetworkConfig {
    /// Agent IDs to register.
    pub agents: Vec<String>,
    /// Delegation routes between agents.
    pub delegation_routes: Vec<(String, String)>,
    /// Handoff routes between agents.
    pub handoff_routes: Vec<(String, String)>,
    /// The agent that receives the first user message.
    pub entry_point: String,
    /// Inbound checks — intercept events before fold processes them.
    pub inbound_checks: Vec<NetworkCheckDef>,
    /// Outbound checks — intercept requests before host dispatches them.
    pub outbound_checks: Vec<NetworkCheckDef>,
}

// ════════════════════════════════════════════════════════════════
// Network errors
// ════════════════════════════════════════════════════════════════

/// Errors from network operations.
#[derive(Debug, Clone, PartialEq)]
pub enum NetworkError {
    Coordinator(CoordinatorError),
    NoActiveAgent,
    ActiveAgentNotIdle(String),
    HandoffRouteNotFound { src: String, dst: String },
    HandoffTargetNotIdle(String),
    HandoffTargetInDelegation(String),
}

impl core::fmt::Display for NetworkError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Coordinator(e) => write!(f, "coordinator: {e}"),
            Self::NoActiveAgent => write!(f, "no active agent set"),
            Self::ActiveAgentNotIdle(id) => write!(f, "active agent not idle: {id}"),
            Self::HandoffRouteNotFound { src, dst } => {
                write!(f, "no handoff route from {src} to {dst}")
            }
            Self::HandoffTargetNotIdle(id) => write!(f, "handoff target not idle: {id}"),
            Self::HandoffTargetInDelegation(id) => {
                write!(f, "handoff target is a delegation child: {id}")
            }
        }
    }
}

impl core::error::Error for NetworkError {}

impl From<CoordinatorError> for NetworkError {
    fn from(e: CoordinatorError) -> Self {
        Self::Coordinator(e)
    }
}
