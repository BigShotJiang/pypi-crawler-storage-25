//! Transducer VM — interpreter for the expression language.
//!
//! Maps from TransducerVM.v: eval, exec_rule, exec_transducer, exec_session.
//! Every operation is total: type mismatches produce Value::None, never panic.

use crate::prelude::*;
use crate::typecheck::type_of_value;
use crate::types::*;
use alloc::collections::BTreeMap;

// ════════════════════════════════════════════════════════════════
// eval — structural recursion over the Expr AST
// ════════════════════════════════════════════════════════════════

/// Evaluate an expression against an environment.
/// Total: always returns a Value. Type mismatches → Value::None.
pub fn eval(env: &Env, expr: &Expr) -> Value {
    match expr {
        // ── Atoms ──
        Expr::Lit { value } => value.clone(),
        Expr::Ref { name } => env.get(name).cloned().unwrap_or(Value::None),

        // ── Arithmetic / comparison ──
        Expr::Add { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Int(a), Value::Int(b)) => Value::Int(a.wrapping_add(b)),
            _ => Value::None,
        },
        Expr::Mul { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Int(a), Value::Int(b)) => Value::Int(a.wrapping_mul(b)),
            _ => Value::None,
        },
        Expr::Div { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Int(_), Value::Int(0)) => Value::None,
            (Value::Int(a), Value::Int(b)) => Value::Int(a / b),
            _ => Value::None,
        },
        Expr::Mod { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Int(_), Value::Int(0)) => Value::None,
            (Value::Int(a), Value::Int(b)) => Value::Int(a % b),
            _ => Value::None,
        },
        Expr::Gt { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Int(a), Value::Int(b)) => Value::Bool(a > b),
            _ => Value::None,
        },
        Expr::Eq { left, right } => Value::Bool(eval(env, left) == eval(env, right)),

        // ── List ops ──
        Expr::LAppend { list, item } => match eval(env, list) {
            Value::List(mut l) => {
                l.push(eval(env, item));
                Value::List(l)
            }
            _ => Value::None,
        },
        // ── Map ops ──
        Expr::MPut { map, key, value } => match (eval(env, map), eval(env, key)) {
            (Value::Map(mut m), Value::Str(k)) => {
                m.insert(k, eval(env, value));
                Value::Map(m)
            }
            _ => Value::None,
        },
        Expr::MGet { map, key, type_ann } => match (eval(env, map), eval(env, key)) {
            (Value::Map(m), Value::Str(k)) => {
                let result = m.get(&k).cloned().unwrap_or(Value::None);
                match type_ann {
                    Some(t) if type_of_value(&result) != Some(*t) => Value::None,
                    _ => result,
                }
            }
            _ => Value::None,
        },
        Expr::MDel { map, key } => match (eval(env, map), eval(env, key)) {
            (Value::Map(mut m), Value::Str(k)) => {
                m.remove(&k);
                Value::Map(m)
            }
            _ => Value::None,
        },
        Expr::MKeys { map } => match eval(env, map) {
            Value::Map(m) => Value::List(m.keys().map(|k| Value::Str(k.clone())).collect()),
            _ => Value::None,
        },
        // ── Records ──
        Expr::Rec { fields } => {
            let mut m = BTreeMap::new();
            for f in fields {
                m.insert(f.key.clone(), eval(env, &f.val_expr));
            }
            Value::Map(m)
        }

        // ── Binding ──
        Expr::ELet { name, value, body } => {
            let val = eval(env, value);
            let mut inner_env = env.clone();
            inner_env.insert(name.clone(), val);
            eval(&inner_env, body)
        }

        // ── Control ──
        Expr::IfElse {
            cond,
            then_expr,
            else_expr,
        } => match eval(env, cond) {
            Value::Bool(true) => eval(env, then_expr),
            Value::Bool(false) => eval(env, else_expr),
            _ => Value::None,
        },

        // ── Fold (bounded iteration) ──
        Expr::LFold {
            list,
            init,
            acc_var,
            item_var,
            body,
            item_type_ann: _,
        } => match eval(env, list) {
            Value::List(l) => {
                let mut acc = eval(env, init);
                for item in l {
                    let mut inner_env = env.clone();
                    inner_env.insert(acc_var.clone(), acc);
                    inner_env.insert(item_var.clone(), item);
                    acc = eval(&inner_env, body);
                }
                acc
            }
            _ => Value::None,
        },

        // ── String ops ──
        Expr::StrCat { left, right } => match (eval(env, left), eval(env, right)) {
            (Value::Str(a), Value::Str(b)) => Value::Str(alloc::format!("{a}{b}")),
            _ => Value::None,
        },

        // Macro nodes should be expanded before reaching eval.
        // If one slips through, it's a loader bug — return VNone.
        Expr::Macro { .. } => Value::None,
    }
}

// ════════════════════════════════════════════════════════════════
// exec — run transducers against events
// ════════════════════════════════════════════════════════════════

/// Result of executing a transducer: new state + emitted values.
#[derive(Debug, Clone)]
pub struct ExecResult {
    pub state: Env,
    pub emitted: Vec<Value>,
}

/// Evaluate an emit expression. VList flattens, VNone drops, else singleton.
fn eval_emit(env: &Env, expr: &Expr) -> Vec<Value> {
    match eval(env, expr) {
        Value::List(items) => items,
        Value::None => vec![],
        v => vec![v],
    }
}

/// Merge event data into an environment (slots + event fields).
fn bind_event(env: &Env, event_data: &Env) -> Env {
    let mut merged = env.clone();
    for (k, v) in event_data {
        merged.insert(k.clone(), v.clone());
    }
    merged
}

/// Execute one rule against an event. Accumulates into result.
fn exec_rule(result: ExecResult, event_tag: &str, event_data: &Env, rule: &Rule) -> ExecResult {
    if rule.on != event_tag {
        return result;
    }

    let env = bind_event(&result.state, event_data);

    if !eval(&env, &rule.guard).is_truthy() {
        return result;
    }

    // Apply updates
    let mut new_state = result.state;
    for upd in &rule.updates {
        let env = bind_event(&new_state, event_data);
        let val = eval(&env, &upd.expr);
        new_state.insert(upd.slot.clone(), val);
    }

    // Collect emits
    let mut new_emitted = result.emitted;
    let emit_env = bind_event(&new_state, event_data);
    for emit_expr in &rule.emits {
        new_emitted.extend(eval_emit(&emit_env, emit_expr));
    }

    ExecResult {
        state: new_state,
        emitted: new_emitted,
    }
}

/// Execute a transducer: fold all rules over the event.
pub fn exec_transducer(
    td: &TransducerDef,
    state: &Env,
    event_tag: &str,
    event_data: &Env,
) -> ExecResult {
    let init = ExecResult {
        state: state.clone(),
        emitted: vec![],
    };
    td.rules.iter().fold(init, |result, rule| {
        exec_rule(result, event_tag, event_data, rule)
    })
}

/// Execute a session: fold all transducers over the event.
/// Each transducer sees the accumulated state. Emits concatenate.
pub fn exec_session(
    transducers: &[TransducerDef],
    state: &Env,
    event_tag: &str,
    event_data: &Env,
) -> ExecResult {
    let init = ExecResult {
        state: state.clone(),
        emitted: vec![],
    };
    transducers.iter().fold(init, |result, td| {
        let r = exec_transducer(td, &result.state, event_tag, event_data);
        ExecResult {
            state: r.state,
            emitted: {
                let mut e = result.emitted;
                e.extend(r.emitted);
                e
            },
        }
    })
}

// ════════════════════════════════════════════════════════════════
// Tests
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn env_from(pairs: &[(&str, Value)]) -> Env {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }

    // ── eval tests ──

    #[test]
    fn eval_lit() {
        let env = Env::new();
        assert_eq!(
            eval(
                &env,
                &Expr::Lit {
                    value: Value::Int(42)
                }
            ),
            Value::Int(42)
        );
    }

    #[test]
    fn eval_ref_found() {
        let env = env_from(&[("x", Value::Int(10))]);
        assert_eq!(eval(&env, &Expr::Ref { name: "x".into() }), Value::Int(10));
    }

    #[test]
    fn eval_ref_missing() {
        let env = Env::new();
        assert_eq!(eval(&env, &Expr::Ref { name: "x".into() }), Value::None);
    }

    #[test]
    fn eval_add() {
        let env = Env::new();
        let expr = Expr::Add {
            left: Box::new(Expr::Lit {
                value: Value::Int(3),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(4),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::Int(7));
    }

    #[test]
    fn eval_add_type_mismatch() {
        let env = Env::new();
        let expr = Expr::Add {
            left: Box::new(Expr::Lit {
                value: Value::Str("a".into()),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::None);
    }

    #[test]
    fn eval_div_by_zero() {
        let env = Env::new();
        let expr = Expr::Div {
            left: Box::new(Expr::Lit {
                value: Value::Int(10),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(0),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::None);
    }

    #[test]
    fn eval_mod() {
        let env = Env::new();
        let expr = Expr::Mod {
            left: Box::new(Expr::Lit {
                value: Value::Int(10),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(3),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::Int(1));
    }

    #[test]
    fn eval_mod_by_zero() {
        let env = Env::new();
        let expr = Expr::Mod {
            left: Box::new(Expr::Lit {
                value: Value::Int(10),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(0),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::None);
    }

    #[test]
    fn eval_eq() {
        let env = Env::new();
        let expr = Expr::Eq {
            left: Box::new(Expr::Lit {
                value: Value::Int(5),
            }),
            right: Box::new(Expr::Lit {
                value: Value::Int(5),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::Bool(true));
    }

    #[test]
    fn eval_if_else() {
        let env = Env::new();
        let expr = Expr::IfElse {
            cond: Box::new(Expr::Lit {
                value: Value::Bool(true),
            }),
            then_expr: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
            else_expr: Box::new(Expr::Lit {
                value: Value::Int(2),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::Int(1));
    }

    #[test]
    fn eval_if_else_non_bool() {
        let env = Env::new();
        let expr = Expr::IfElse {
            cond: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
            then_expr: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
            else_expr: Box::new(Expr::Lit {
                value: Value::Int(2),
            }),
        };
        assert_eq!(eval(&env, &expr), Value::None);
    }

    #[test]
    fn eval_list_ops() {
        let env = Env::new();
        let list = Expr::Lit {
            value: Value::List(vec![Value::Int(1), Value::Int(2), Value::Int(3)]),
        };

        // LAppend
        let appended = eval(
            &env,
            &Expr::LAppend {
                list: Box::new(list.clone()),
                item: Box::new(Expr::Lit {
                    value: Value::Int(4),
                }),
            },
        );
        assert_eq!(
            appended,
            Value::List(vec![
                Value::Int(1),
                Value::Int(2),
                Value::Int(3),
                Value::Int(4)
            ])
        );
    }

    #[test]
    fn eval_map_ops() {
        let env = Env::new();
        let empty_map = Expr::Lit {
            value: Value::Map(BTreeMap::new()),
        };

        // MPut
        let with_key = eval(
            &env,
            &Expr::MPut {
                map: Box::new(empty_map.clone()),
                key: Box::new(Expr::Lit {
                    value: Value::Str("x".into()),
                }),
                value: Box::new(Expr::Lit {
                    value: Value::Int(42),
                }),
            },
        );
        let expected = Value::Map(BTreeMap::from([("x".into(), Value::Int(42))]));
        assert_eq!(with_key, expected);

        // MGet
        let got = eval(
            &env,
            &Expr::MGet {
                map: Box::new(Expr::Lit {
                    value: expected.clone(),
                }),
                key: Box::new(Expr::Lit {
                    value: Value::Str("x".into()),
                }),
                type_ann: None,
            },
        );
        assert_eq!(got, Value::Int(42));

        // MGet missing
        let missing = eval(
            &env,
            &Expr::MGet {
                map: Box::new(Expr::Lit {
                    value: expected.clone(),
                }),
                key: Box::new(Expr::Lit {
                    value: Value::Str("y".into()),
                }),
                type_ann: None,
            },
        );
        assert_eq!(missing, Value::None);
    }

    #[test]
    fn eval_lfold() {
        let env = Env::new();
        // Sum [1, 2, 3] = 6
        let expr = Expr::LFold {
            list: Box::new(Expr::Lit {
                value: Value::List(vec![Value::Int(1), Value::Int(2), Value::Int(3)]),
            }),
            init: Box::new(Expr::Lit {
                value: Value::Int(0),
            }),
            acc_var: "acc".into(),
            item_var: "item".into(),
            body: Box::new(Expr::Add {
                left: Box::new(Expr::Ref { name: "acc".into() }),
                right: Box::new(Expr::Ref {
                    name: "item".into(),
                }),
            }),
            item_type_ann: None,
        };
        assert_eq!(eval(&env, &expr), Value::Int(6));
    }

    #[test]
    fn eval_rec() {
        let env = Env::new();
        let expr = Expr::Rec {
            fields: vec![
                RecField {
                    key: "name".into(),
                    val_expr: Expr::Lit {
                        value: Value::Str("test".into()),
                    },
                },
                RecField {
                    key: "count".into(),
                    val_expr: Expr::Lit {
                        value: Value::Int(1),
                    },
                },
            ],
        };
        let expected = Value::Map(BTreeMap::from([
            ("name".into(), Value::Str("test".into())),
            ("count".into(), Value::Int(1)),
        ]));
        assert_eq!(eval(&env, &expr), expected);
    }

    // ── exec tests ──

    #[test]
    fn exec_counter_transducer() {
        let td = TransducerDef {
            name: "counter".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        };

        let state = env_from(&[("count", Value::Int(0))]);
        let event_data = Env::new();

        let r = exec_transducer(&td, &state, "Input", &event_data);
        assert_eq!(r.state.get("count"), Some(&Value::Int(1)));
        assert!(r.emitted.is_empty());

        // Second event
        let r2 = exec_transducer(&td, &r.state, "Input", &event_data);
        assert_eq!(r2.state.get("count"), Some(&Value::Int(2)));
    }

    #[test]
    fn exec_generator_transducer() {
        let td = TransducerDef {
            name: "producer".into(),
            slots: vec![],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![Expr::Rec {
                    fields: vec![RecField {
                        key: "type".into(),
                        val_expr: Expr::Lit {
                            value: Value::Str("WorkRequest".into()),
                        },
                    }],
                }],
            }],
        };

        let state = Env::new();
        let event_data = Env::new();

        let r = exec_transducer(&td, &state, "Input", &event_data);
        assert_eq!(r.emitted.len(), 1);

        // Non-matching event
        let r2 = exec_transducer(&td, &state, "Other", &event_data);
        assert!(r2.emitted.is_empty());
    }

    #[test]
    fn exec_guard_blocks() {
        let td = TransducerDef {
            name: "guarded".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Gt {
                    left: Box::new(Expr::Ref {
                        name: "count".into(),
                    }),
                    right: Box::new(Expr::Lit {
                        value: Value::Int(0),
                    }),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        };

        let state = env_from(&[("count", Value::Int(0))]);
        let event_data = Env::new();

        // Guard fails: count(0) > 0 is false
        let r = exec_transducer(&td, &state, "Input", &event_data);
        assert_eq!(r.state.get("count"), Some(&Value::Int(0)));

        // Guard passes: count(1) > 0 is true
        let state2 = env_from(&[("count", Value::Int(1))]);
        let r2 = exec_transducer(&td, &state2, "Input", &event_data);
        assert_eq!(r2.state.get("count"), Some(&Value::Int(2)));
    }

    #[test]
    fn exec_session_composes() {
        let projector = TransducerDef {
            name: "counter".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        };

        let generator = TransducerDef {
            name: "producer".into(),
            slots: vec![],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![Expr::Lit {
                    value: Value::Str("WorkRequest".into()),
                }],
            }],
        };

        let state = env_from(&[("count", Value::Int(0))]);
        let event_data = Env::new();

        let r = exec_session(&[projector, generator], &state, "Input", &event_data);
        assert_eq!(r.state.get("count"), Some(&Value::Int(1)));
        assert_eq!(r.emitted.len(), 1);
    }
}
