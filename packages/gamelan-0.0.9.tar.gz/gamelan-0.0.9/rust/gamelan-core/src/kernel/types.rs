//! Core types for the transducer VM.
//!
//! Maps 1:1 from the Rocq definitions in TransducerVM.v.
//! Value is the universal runtime type. Expr is the instruction set.
//! TransducerDef is a complete transducer as portable data.

use crate::prelude::*;
use crate::typecheck::VType;
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Value — the universal runtime type
// ════════════════════════════════════════════════════════════════

/// Every slot, expression result, and event field is a Value.
/// Type mismatches produce VNone, never panic.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", content = "value")]
pub enum Value {
    Str(String),
    Int(i64),
    Bool(bool),
    List(Vec<Value>),
    Map(BTreeMap<String, Value>),
    None,
}

impl Value {
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Value::Str(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_int(&self) -> Option<i64> {
        match self {
            Value::Int(n) => Some(*n),
            _ => None,
        }
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Value::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_list(&self) -> Option<&[Value]> {
        match self {
            Value::List(l) => Some(l),
            _ => None,
        }
    }

    pub fn as_map(&self) -> Option<&BTreeMap<String, Value>> {
        match self {
            Value::Map(m) => Some(m),
            _ => None,
        }
    }

    pub fn is_none(&self) -> bool {
        matches!(self, Value::None)
    }

    pub fn is_truthy(&self) -> bool {
        matches!(self, Value::Bool(true))
    }
}

// ════════════════════════════════════════════════════════════════
// Env — association list environment (slot values + event fields)
// ════════════════════════════════════════════════════════════════

/// The environment maps names to values.
/// Slots, event fields, and fold variables all live here.
pub type Env = BTreeMap<String, Value>;

// ════════════════════════════════════════════════════════════════
// Expr — the instruction set (recursive AST)
// ════════════════════════════════════════════════════════════════

/// 16 instruction types + control. Total by construction:
/// no loops, no general recursion, no I/O.
/// LFold provides bounded iteration over finite lists.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "op")]
pub enum Expr {
    // ── Atoms ──
    Lit {
        value: Value,
    },
    Ref {
        name: String,
    },

    // ── Arithmetic / comparison ──
    Add {
        left: Box<Expr>,
        right: Box<Expr>,
    },
    Mul {
        left: Box<Expr>,
        right: Box<Expr>,
    },
    Div {
        left: Box<Expr>,
        right: Box<Expr>,
    },
    Mod {
        left: Box<Expr>,
        right: Box<Expr>,
    },
    Gt {
        left: Box<Expr>,
        right: Box<Expr>,
    },
    Eq {
        left: Box<Expr>,
        right: Box<Expr>,
    },

    // ── List ops ──
    LAppend {
        list: Box<Expr>,
        item: Box<Expr>,
    },

    // ── Map ops ──
    MPut {
        map: Box<Expr>,
        key: Box<Expr>,
        value: Box<Expr>,
    },
    MGet {
        map: Box<Expr>,
        key: Box<Expr>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        type_ann: Option<VType>,
    },
    MDel {
        map: Box<Expr>,
        key: Box<Expr>,
    },
    MKeys {
        map: Box<Expr>,
    },

    // ── Records ──
    Rec {
        fields: Vec<RecField>,
    },

    // ── Binding ──
    ELet {
        name: String,
        value: Box<Expr>,
        body: Box<Expr>,
    },

    // ── Control ──
    IfElse {
        cond: Box<Expr>,
        then_expr: Box<Expr>,
        else_expr: Box<Expr>,
    },

    // ── Fold (bounded iteration) ──
    LFold {
        list: Box<Expr>,
        init: Box<Expr>,
        acc_var: String,
        item_var: String,
        body: Box<Expr>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        item_type_ann: Option<VType>,
    },

    // ── String ops ──
    StrCat {
        left: Box<Expr>,
        right: Box<Expr>,
    },

    // ── Macro invocation (expanded at load time) ──
    Macro {
        name: String,
        args: Vec<Expr>,
    },
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct RecField {
    pub key: String,
    pub val_expr: Expr,
}

// ════════════════════════════════════════════════════════════════
// TransducerDef — a complete transducer as portable data
// ════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SlotDef {
    pub name: String,
    pub initial: Value,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Update {
    pub slot: String,
    pub expr: Expr,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Rule {
    pub on: String,
    pub guard: Expr,
    pub updates: Vec<Update>,
    pub emits: Vec<Expr>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TransducerDef {
    pub name: String,
    pub slots: Vec<SlotDef>,
    pub rules: Vec<Rule>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn value_serde_roundtrip() {
        let v = Value::Map(BTreeMap::from([
            ("name".into(), Value::Str("messages".into())),
            ("count".into(), Value::Int(42)),
            (
                "items".into(),
                Value::List(vec![Value::Bool(true), Value::None]),
            ),
        ]));
        let json = serde_json::to_string(&v).unwrap();
        let v2: Value = serde_json::from_str(&json).unwrap();
        assert_eq!(v, v2);
    }

    #[test]
    fn transducer_def_serde_roundtrip() {
        let td = TransducerDef {
            name: "counter".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![],
            }],
        };
        let json = serde_json::to_string_pretty(&td).unwrap();
        let td2: TransducerDef = serde_json::from_str(&json).unwrap();
        assert_eq!(td, td2);
    }
}
