//! Interpreter — universal routing types and classify functions.
//!
//! Direct translation of `interpreter.qnt` (RoutingConfig, DispatchRule,
//! RuntimeEffect, classify, classify_result).
//!
//! These types are the output of the connection-state interpreters
//! (agent interpreter, network interpreter). The session tree consumes
//! `RoutingConfig` to drive gate, pending, and check decisions.

use crate::prelude::*;
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Routing config — universal output types
// Spec: interpreter.qnt lines 1-31
// ════════════════════════════════════════════════════════════════

/// A dispatch rule: request type → result type.
/// Used by `clear_pending` to map results back to requests.
///
/// Spec: interpreter.qnt `type DispatchRule`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DispatchRule {
    pub request_type: String,
    pub result_type: String,
}

/// Outbound check: request type → check source.
///
/// Spec: interpreter.qnt `type OutboundCheckRule`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OutboundCheckRule {
    pub request_type: String,
    pub check_source: String,
}

/// Inbound check: result type → check source.
///
/// Spec: interpreter.qnt `type InboundCheckRule`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct InboundCheckRule {
    pub result_type: String,
    pub check_source: String,
}

/// Everything the session tree needs for routing, checks, gating.
/// Rebuilt when connections change.
///
/// Spec: interpreter.qnt `type RoutingConfig`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RoutingConfig {
    pub dispatch_rules: Vec<DispatchRule>,
    pub outbound_checks: Vec<OutboundCheckRule>,
    pub inbound_checks: Vec<InboundCheckRule>,
}

impl RoutingConfig {
    /// Empty routing config — no connections, no checks.
    pub fn empty() -> Self {
        RoutingConfig {
            dispatch_rules: Vec::new(),
            outbound_checks: Vec::new(),
            inbound_checks: Vec::new(),
        }
    }
}

// ════════════════════════════════════════════════════════════════
// Runtime effects — instructions to the runtime
// Spec: interpreter.qnt lines 33-40
// ════════════════════════════════════════════════════════════════

/// Instructions emitted to the runtime when connection state changes.
///
/// Spec: interpreter.qnt `type RuntimeEffect`
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum RuntimeEffect {
    /// Start a source (connect, register, begin streaming).
    StartSource(String),
    /// Stop a source (disconnect, deregister).
    StopSource(String),
    /// Update the tool schemas visible from a source.
    UpdateToolSchemas {
        source_id: String,
        tools: Vec<String>,
    },
}

// ════════════════════════════════════════════════════════════════
// Classify — extract gating keys
// Spec: interpreter.qnt lines 42-83
// ════════════════════════════════════════════════════════════════

/// Extract the gating key from a request.
///
/// The key is an opaque string. Instance-level keys are
/// "type:instance_id" (e.g. "ToolRequest:call_abc"). Type-level keys
/// are just the type (e.g. "LlmRequest").
///
/// Spec: interpreter.qnt `pure def classify`
pub fn classify(request_type: &str, key: &str) -> String {
    if !key.is_empty() {
        key.to_string()
    } else {
        request_type.to_string()
    }
}

/// Extract the gating key from a result event to clear pending.
///
/// If a key is echoed (non-empty), return it directly. Otherwise
/// reverse-lookup the request type from `dispatch_rules` for the
/// given `result_type`.
///
/// Spec: interpreter.qnt `pure def classify_result`
pub fn classify_result(dispatch_rules: &[DispatchRule], result_type: &str, key: &str) -> String {
    if !key.is_empty() {
        key.to_string()
    } else {
        // Type-level: find the request type for this result type.
        // Spec: foldl("", (acc, r) => if acc != "" acc else if r.result_type == result_type r.request_type else "")
        dispatch_rules
            .iter()
            .find(|r| r.result_type == result_type)
            .map(|r| r.request_type.clone())
            .unwrap_or_default()
    }
}

// ════════════════════════════════════════════════════════════════
// Routing helpers
// ════════════════════════════════════════════════════════════════

/// Does a request of this type require an outbound check?
pub fn needs_outbound_check(routing: &RoutingConfig, request_type: &str) -> bool {
    routing
        .outbound_checks
        .iter()
        .any(|r| r.request_type == request_type)
}

/// Which check source should handle an inbound result event with this tag?
/// Returns `Some(check_source)` if the event tag matches an inbound check rule.
pub fn needs_inbound_check(routing: &RoutingConfig, event_tag: &str) -> Option<String> {
    routing
        .inbound_checks
        .iter()
        .find(|r| r.result_type == event_tag)
        .map(|r| r.check_source.clone())
}

/// Which check source handles outbound checks for a request of this type?
pub fn outbound_check_source(routing: &RoutingConfig, request_type: &str) -> Option<String> {
    routing
        .outbound_checks
        .iter()
        .find(|r| r.request_type == request_type)
        .map(|r| r.check_source.clone())
}

// ════════════════════════════════════════════════════════════════
// Tests
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn test_dispatch_rules() -> Vec<DispatchRule> {
        vec![
            DispatchRule {
                request_type: "LlmRequest".into(),
                result_type: "LlmResponse".into(),
            },
            DispatchRule {
                request_type: "ToolRequest".into(),
                result_type: "ToolResult".into(),
            },
        ]
    }

    fn test_routing() -> RoutingConfig {
        RoutingConfig {
            dispatch_rules: test_dispatch_rules(),
            outbound_checks: vec![OutboundCheckRule {
                request_type: "LlmRequest".into(),
                check_source: "policy_check".into(),
            }],
            inbound_checks: vec![InboundCheckRule {
                result_type: "LlmResponse".into(),
                check_source: "response_check".into(),
            }],
        }
    }

    // ── classify ──────────────────────────────────────

    /// Spec: classify_type_level_test — no explicit key → falls back to type
    #[test]
    fn test_classify_type_level() {
        let k = classify("LlmRequest", "");
        assert_eq!(k, "LlmRequest");
    }

    /// Spec: classify_instance_level_test — explicit key provided → returned directly
    #[test]
    fn test_classify_instance_level() {
        let k = classify("ToolRequest", "ToolRequest:call_abc");
        assert_eq!(k, "ToolRequest:call_abc");
    }

    // ── classify_result ───────────────────────────────

    /// Spec: classify_result_type_level_test — no key → type-level lookup
    #[test]
    fn test_classify_result_type_level() {
        let k = classify_result(&test_dispatch_rules(), "LlmResponse", "");
        assert_eq!(k, "LlmRequest");
    }

    /// Spec: classify_result_instance_level_test — key echoed by source → returned directly
    #[test]
    fn test_classify_result_instance_level() {
        let k = classify_result(&test_dispatch_rules(), "ToolResult", "ToolRequest:call_abc");
        assert_eq!(k, "ToolRequest:call_abc");
    }

    /// Unknown result type with no key → empty string
    #[test]
    fn test_classify_result_unknown() {
        let k = classify_result(&test_dispatch_rules(), "UnknownResult", "");
        assert_eq!(k, "");
    }

    // ── key_consistency ───────────────────────────────

    /// Spec: key_consistency_type_level_test
    #[test]
    fn test_key_consistency_type_level() {
        let rules = test_dispatch_rules();
        let req_key = classify("LlmRequest", "");
        let res_key = classify_result(&rules, "LlmResponse", "");
        assert_eq!(req_key, res_key);
    }

    /// Spec: key_consistency_instance_level_test
    #[test]
    fn test_key_consistency_instance_level() {
        let rules = test_dispatch_rules();
        let req_key = classify("ToolRequest", "ToolRequest:call_abc");
        let res_key = classify_result(&rules, "ToolResult", "ToolRequest:call_abc");
        assert_eq!(req_key, res_key);
    }

    // ── routing helpers ───────────────────────────────

    #[test]
    fn test_needs_outbound_check_present() {
        let routing = test_routing();
        assert!(needs_outbound_check(&routing, "LlmRequest"));
    }

    #[test]
    fn test_needs_outbound_check_absent() {
        let routing = test_routing();
        assert!(!needs_outbound_check(&routing, "ToolRequest"));
    }

    #[test]
    fn test_needs_inbound_check_present() {
        let routing = test_routing();
        let source = needs_inbound_check(&routing, "LlmResponse");
        assert_eq!(source, Some("response_check".into()));
    }

    #[test]
    fn test_needs_inbound_check_absent() {
        let routing = test_routing();
        let source = needs_inbound_check(&routing, "ToolResult");
        assert_eq!(source, None);
    }

    #[test]
    fn test_outbound_check_source_present() {
        let routing = test_routing();
        let source = outbound_check_source(&routing, "LlmRequest");
        assert_eq!(source, Some("policy_check".into()));
    }

    #[test]
    fn test_outbound_check_source_absent() {
        let routing = test_routing();
        let source = outbound_check_source(&routing, "ToolRequest");
        assert_eq!(source, None);
    }

    #[test]
    fn test_routing_config_empty() {
        let routing = RoutingConfig::empty();
        assert!(routing.dispatch_rules.is_empty());
        assert!(routing.outbound_checks.is_empty());
        assert!(routing.inbound_checks.is_empty());
    }
}
