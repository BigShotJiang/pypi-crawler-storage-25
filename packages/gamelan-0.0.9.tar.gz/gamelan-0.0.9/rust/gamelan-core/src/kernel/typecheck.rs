//! Static type checker for TransducerDef expressions.
//!
//! Maps from Lean Typecheck.lean: VType, tc, type soundness.
//! Checks expressions at load time — well-typed expressions don't
//! produce VNone from type mismatches at runtime.
//!
//! No TAny — MGet and LFold require explicit type annotations.
//! Strict type equality (no wildcard matching).

use crate::prelude::*;
use crate::types::{Expr, Rule, SlotDef, TransducerDef, Value};
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

/// Static types for Values.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum VType {
    TStr,
    TInt,
    TBool,
    TList,
    TMap,
}

/// Get the static type of a runtime Value.
/// VNone has no type (returns None).
pub fn type_of_value(v: &Value) -> Option<VType> {
    match v {
        Value::Str(_) => Some(VType::TStr),
        Value::Int(_) => Some(VType::TInt),
        Value::Bool(_) => Some(VType::TBool),
        Value::List(_) => Some(VType::TList),
        Value::Map(_) => Some(VType::TMap),
        Value::None => None,
    }
}

/// Typing environment: maps names to types.
pub type TyEnv = BTreeMap<String, VType>;

/// Build a typing env from slot definitions.
/// Slots with VNone initial values are excluded (no static type).
pub fn slots_to_tyenv(slots: &[SlotDef]) -> TyEnv {
    slots
        .iter()
        .filter_map(|s| type_of_value(&s.initial).map(|t| (s.name.clone(), t)))
        .collect()
}

/// Type errors from the checker.
#[derive(Debug, Clone, PartialEq)]
pub enum TypeError {
    /// An expression could not be typed.
    ExprError { context: String },
    /// A guard is not Bool.
    GuardNotBool { rule_on: String },
    /// An update expression failed type checking.
    UpdateError { rule_on: String, slot: String },
    /// An emit expression failed type checking.
    EmitError { rule_on: String },
}

/// Typecheck an expression. Returns Some(type) or None on type error.
/// Matches Lean `tc` — strict type equality, no TAny.
pub fn typecheck(tenv: &TyEnv, expr: &Expr) -> Option<VType> {
    match expr {
        Expr::Lit { value } => type_of_value(value),
        Expr::Ref { name } => tenv.get(name).copied(),

        // Arithmetic: Int × Int → Int
        Expr::Add { left, right }
        | Expr::Mul { left, right }
        | Expr::Div { left, right }
        | Expr::Mod { left, right } => {
            let lt = typecheck(tenv, left)?;
            let rt = typecheck(tenv, right)?;
            if lt == VType::TInt && rt == VType::TInt {
                Some(VType::TInt)
            } else {
                None
            }
        }

        // Comparison: Int × Int → Bool
        Expr::Gt { left, right } => {
            let lt = typecheck(tenv, left)?;
            let rt = typecheck(tenv, right)?;
            if lt == VType::TInt && rt == VType::TInt {
                Some(VType::TBool)
            } else {
                None
            }
        }

        // Eq: any × any → Bool
        Expr::Eq { left, right } => {
            typecheck(tenv, left)?;
            typecheck(tenv, right)?;
            Some(VType::TBool)
        }

        // List ops
        Expr::LAppend { list, item } => {
            let lt = typecheck(tenv, list)?;
            typecheck(tenv, item)?;
            if lt == VType::TList {
                Some(VType::TList)
            } else {
                None
            }
        }
        Expr::LFold {
            list,
            init,
            acc_var,
            item_var,
            body,
            item_type_ann,
        } => {
            let lt = typecheck(tenv, list)?;
            if lt != VType::TList {
                return None;
            }
            let init_ty = typecheck(tenv, init)?;
            let item_ty = (*item_type_ann)?; // annotation required
            let mut body_env = tenv.clone();
            body_env.insert(acc_var.clone(), init_ty);
            body_env.insert(item_var.clone(), item_ty);
            let body_ty = typecheck(&body_env, body)?;
            if body_ty == init_ty {
                Some(init_ty)
            } else {
                None
            }
        }

        // Map ops
        Expr::MPut { map, key, value } => {
            let mt = typecheck(tenv, map)?;
            let kt = typecheck(tenv, key)?;
            typecheck(tenv, value)?;
            if mt == VType::TMap && kt == VType::TStr {
                Some(VType::TMap)
            } else {
                None
            }
        }
        Expr::MGet { map, key, type_ann } => {
            let mt = typecheck(tenv, map)?;
            let kt = typecheck(tenv, key)?;
            if mt == VType::TMap && kt == VType::TStr {
                // Annotation required — no TAny fallback
                Some((*type_ann)?)
            } else {
                None
            }
        }
        Expr::MDel { map, key } => {
            let mt = typecheck(tenv, map)?;
            let kt = typecheck(tenv, key)?;
            if mt == VType::TMap && kt == VType::TStr {
                Some(VType::TMap)
            } else {
                None
            }
        }
        Expr::MKeys { map } => {
            let t = typecheck(tenv, map)?;
            if t == VType::TMap {
                Some(VType::TList)
            } else {
                None
            }
        }
        // Records → TMap
        Expr::Rec { fields } => {
            for f in fields {
                typecheck(tenv, &f.val_expr)?;
            }
            Some(VType::TMap)
        }

        // Binding
        Expr::ELet { name, value, body } => {
            let vty = typecheck(tenv, value)?;
            let mut inner = tenv.clone();
            inner.insert(name.clone(), vty);
            typecheck(&inner, body)
        }

        // Control
        Expr::IfElse {
            cond,
            then_expr,
            else_expr,
        } => {
            let ct = typecheck(tenv, cond)?;
            if ct != VType::TBool {
                return None;
            }
            let ty_t = typecheck(tenv, then_expr)?;
            let ty_f = typecheck(tenv, else_expr)?;
            if ty_t == ty_f { Some(ty_t) } else { None }
        }

        // String ops
        Expr::StrCat { left, right } => {
            let lt = typecheck(tenv, left)?;
            let rt = typecheck(tenv, right)?;
            if lt == VType::TStr && rt == VType::TStr { Some(VType::TStr) } else { None }
        }

        // Macro — should be expanded before type checking
        Expr::Macro { .. } => None,
    }
}

/// Typecheck a rule's guard (must be Bool).
pub fn typecheck_guard(tenv: &TyEnv, guard: &Expr) -> bool {
    typecheck(tenv, guard) == Some(VType::TBool)
}

/// Typecheck all expressions in a rule.
pub fn typecheck_rule(tenv: &TyEnv, rule: &Rule) -> Vec<TypeError> {
    let mut errors = Vec::new();

    if !typecheck_guard(tenv, &rule.guard) {
        errors.push(TypeError::GuardNotBool {
            rule_on: rule.on.clone(),
        });
    }

    for upd in &rule.updates {
        if typecheck(tenv, &upd.expr).is_none() {
            errors.push(TypeError::UpdateError {
                rule_on: rule.on.clone(),
                slot: upd.slot.clone(),
            });
        }
    }

    for emit in &rule.emits {
        if typecheck(tenv, emit).is_none() {
            errors.push(TypeError::EmitError {
                rule_on: rule.on.clone(),
            });
        }
    }

    errors
}

/// Typecheck a full transducer. The typing env includes the transducer's
/// own slots plus any additional context (other transducers' slots, event schemas).
pub fn typecheck_transducer(tenv: &TyEnv, td: &TransducerDef) -> Vec<TypeError> {
    let mut full_env = tenv.clone();
    for slot in &td.slots {
        if let Some(ty) = type_of_value(&slot.initial) {
            full_env.insert(slot.name.clone(), ty);
        }
    }

    let mut errors = Vec::new();
    for rule in &td.rules {
        errors.extend(typecheck_rule(&full_env, rule));
    }
    errors
}

/// Typecheck a session (all transducers together).
/// The caller provides the base typing env (event field schemas, etc.).
/// Slot types are added automatically from slot definitions.
pub fn typecheck_session(base_tenv: &TyEnv, tds: &[TransducerDef]) -> Vec<TypeError> {
    let mut tenv = base_tenv.clone();
    for td in tds {
        for slot in &td.slots {
            if let Some(ty) = type_of_value(&slot.initial) {
                tenv.insert(slot.name.clone(), ty);
            }
        }
    }

    let mut errors = Vec::new();
    for td in tds {
        errors.extend(typecheck_transducer(&tenv, td));
    }
    errors
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lit_types_correctly() {
        let env = TyEnv::new();
        assert_eq!(
            typecheck(
                &env,
                &Expr::Lit {
                    value: Value::Int(42)
                }
            ),
            Some(VType::TInt)
        );
        assert_eq!(
            typecheck(
                &env,
                &Expr::Lit {
                    value: Value::Str("hi".into())
                }
            ),
            Some(VType::TStr)
        );
    }

    #[test]
    fn add_requires_ints() {
        let mut env = TyEnv::new();
        env.insert("x".into(), VType::TInt);
        env.insert("s".into(), VType::TStr);

        // Int + Int = ok
        assert_eq!(
            typecheck(
                &env,
                &Expr::Add {
                    left: Box::new(Expr::Ref { name: "x".into() }),
                    right: Box::new(Expr::Lit {
                        value: Value::Int(1)
                    }),
                }
            ),
            Some(VType::TInt)
        );

        // Str + Int = error
        assert_eq!(
            typecheck(
                &env,
                &Expr::Add {
                    left: Box::new(Expr::Ref { name: "s".into() }),
                    right: Box::new(Expr::Lit {
                        value: Value::Int(1)
                    }),
                }
            ),
            None
        );
    }

    #[test]
    fn mget_with_annotation() {
        let mut env = TyEnv::new();
        env.insert("m".into(), VType::TMap);

        assert_eq!(
            typecheck(
                &env,
                &Expr::MGet {
                    map: Box::new(Expr::Ref { name: "m".into() }),
                    key: Box::new(Expr::Lit {
                        value: Value::Str("k".into())
                    }),
                    type_ann: Some(VType::TStr),
                }
            ),
            Some(VType::TStr)
        );
    }

    #[test]
    fn mget_without_annotation_rejected() {
        let mut env = TyEnv::new();
        env.insert("m".into(), VType::TMap);

        assert_eq!(
            typecheck(
                &env,
                &Expr::MGet {
                    map: Box::new(Expr::Ref { name: "m".into() }),
                    key: Box::new(Expr::Lit {
                        value: Value::Str("k".into())
                    }),
                    type_ann: None,
                }
            ),
            None
        );
    }

    #[test]
    fn mget_annotated_in_add() {
        let mut env = TyEnv::new();
        env.insert("m".into(), VType::TMap);

        // MGet with TInt annotation works in Add
        assert_eq!(
            typecheck(
                &env,
                &Expr::Add {
                    left: Box::new(Expr::MGet {
                        map: Box::new(Expr::Ref { name: "m".into() }),
                        key: Box::new(Expr::Lit {
                            value: Value::Str("count".into())
                        }),
                        type_ann: Some(VType::TInt),
                    }),
                    right: Box::new(Expr::Lit {
                        value: Value::Int(1)
                    }),
                }
            ),
            Some(VType::TInt)
        );
    }

    #[test]
    fn ifelse_branches_must_agree() {
        let env = TyEnv::new();

        // Both branches Int = ok
        assert_eq!(
            typecheck(
                &env,
                &Expr::IfElse {
                    cond: Box::new(Expr::Lit {
                        value: Value::Bool(true)
                    }),
                    then_expr: Box::new(Expr::Lit {
                        value: Value::Int(1)
                    }),
                    else_expr: Box::new(Expr::Lit {
                        value: Value::Int(2)
                    }),
                }
            ),
            Some(VType::TInt)
        );

        // Int vs Str = error
        assert_eq!(
            typecheck(
                &env,
                &Expr::IfElse {
                    cond: Box::new(Expr::Lit {
                        value: Value::Bool(true)
                    }),
                    then_expr: Box::new(Expr::Lit {
                        value: Value::Int(1)
                    }),
                    else_expr: Box::new(Expr::Lit {
                        value: Value::Str("no".into())
                    }),
                }
            ),
            None
        );
    }

    #[test]
    fn macro_node_fails_typecheck() {
        let env = TyEnv::new();
        assert_eq!(
            typecheck(
                &env,
                &Expr::Macro {
                    name: "len".into(),
                    args: vec![]
                }
            ),
            None
        );
    }

    #[test]
    fn unbound_ref_is_none() {
        let env = TyEnv::new();
        assert_eq!(
            typecheck(
                &env,
                &Expr::Ref {
                    name: "unknown".into()
                }
            ),
            None
        );
    }

    #[test]
    fn guard_must_be_bool() {
        let env = TyEnv::new();
        let rule = Rule {
            on: "Test".into(),
            guard: Expr::Lit {
                value: Value::Int(42), // not Bool
            },
            updates: vec![],
            emits: vec![],
        };
        let errors = typecheck_rule(&env, &rule);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, TypeError::GuardNotBool { .. }))
        );
    }
}
