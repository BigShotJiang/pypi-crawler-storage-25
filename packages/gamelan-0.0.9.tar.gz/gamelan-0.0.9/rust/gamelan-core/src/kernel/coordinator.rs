//! Multi-session coordination — routing, lifecycle, delegation,
//! cancellation, failure recovery.
//!
//! Pure state machine: `(CoordinatorState, action) → (CoordinatorState, effects)`.
//! No I/O, no async. Shared by all language hosts via FFI.
//!
//! Aligned with `coordinator.qnt` (4-state model: SIdle, SProcessing,
//! SWaitingDelegate, SDone). Key properties verified by model-checking and
//! Lean 4 proofs: deadlock freedom, graph consistency, failure safety.

use crate::prelude::*;
use alloc::collections::{BTreeMap, BTreeSet};
use serde::{Deserialize, Serialize};

// ════════════════════════════════════════════════════════════════
// Types
// ════════════════════════════════════════════════════════════════

pub type SessionId = String;

/// Maximum processing steps per session before forced completion.
pub const MAX_STEPS: usize = 10;

/// Session status as seen from the coordination layer.
/// Matches coordinator.qnt SessionStatus.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SessionStatus {
    /// Ready to accept work.
    SIdle,
    /// Internal work (LLM call, tool execution).
    SProcessing,
    /// Blocked on delegated sub-session(s).
    SWaitingDelegate,
    /// Finished — result available for collection.
    SDone,
}

/// Per-session state tracked by the coordinator.
/// Matches coordinator.qnt CoordinatedSession.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoordinatedSession {
    pub status: SessionStatus,
    /// Processing steps taken this turn (bounded by MAX_STEPS).
    pub step_count: usize,
    /// Session IDs this session is blocked on (delegation targets).
    pub waiting_on: BTreeSet<SessionId>,
    /// Events processed (for fork context).
    pub event_count: usize,
}

impl CoordinatedSession {
    fn empty() -> Self {
        Self {
            status: SessionStatus::SIdle,
            step_count: 0,
            waiting_on: BTreeSet::new(),
            event_count: 0,
        }
    }
}

/// A route: src can delegate request_type to dst.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct Route {
    pub src: SessionId,
    pub dst: SessionId,
    pub request_type: String,
    pub result_type: String,
}

/// A delegation edge (active delegation from src to dst).
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub struct DelegationEdge {
    pub src: SessionId,
    pub dst: SessionId,
}

// ════════════════════════════════════════════════════════════════
// Effects — what the host should do after a coordinator action
// ════════════════════════════════════════════════════════════════

#[derive(Debug, Clone)]
pub enum Effect {
    CreateSession {
        id: SessionId,
    },
    ForkSession {
        parent: SessionId,
        child: SessionId,
        parent_event_count: usize,
    },
    DestroySession {
        id: SessionId,
    },
    AgentRequest {
        session: SessionId,
        event_tag: String,
        request_data: BTreeMap<String, crate::types::Value>,
    },
    CollectAgentResult {
        parent: SessionId,
        child: SessionId,
        result_type: String,
    },
}

// ════════════════════════════════════════════════════════════════
// Errors
// ════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, PartialEq)]
pub enum CoordinatorError {
    SessionExists(SessionId),
    SessionNotFound(SessionId),
    NotIdle(SessionId),
    NotProcessing(SessionId),
    NotDone(SessionId),
    NotProcessingOrWaitingDelegate(SessionId),
    MaxStepsReached(SessionId),
    WaitingOnNotEmpty(SessionId),
    NoRoute { src: SessionId, dst: SessionId },
    WouldDeadlock { src: SessionId, dst: SessionId },
    HasDelegationEdge(SessionId),
    HasOutgoingEdges(SessionId),
    NoDelegationEdge { src: SessionId, dst: SessionId },
    HasIncomingDelegation(SessionId),
    SelfReference,
}

impl core::fmt::Display for CoordinatorError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::SessionExists(id) => write!(f, "session already exists: {id}"),
            Self::SessionNotFound(id) => write!(f, "session not found: {id}"),
            Self::NotIdle(id) => write!(f, "session not idle: {id}"),
            Self::NotProcessing(id) => write!(f, "session not processing: {id}"),
            Self::NotDone(id) => write!(f, "session not done: {id}"),
            Self::NotProcessingOrWaitingDelegate(id) => {
                write!(f, "session not processing or waiting delegate: {id}")
            }
            Self::MaxStepsReached(id) => write!(f, "max steps reached: {id}"),
            Self::WaitingOnNotEmpty(id) => write!(f, "session still waiting on others: {id}"),
            Self::NoRoute { src, dst } => write!(f, "no route from {src} to {dst}"),
            Self::WouldDeadlock { src, dst } => {
                write!(f, "dispatch {src}→{dst} would create deadlock")
            }
            Self::HasDelegationEdge(id) => write!(f, "session has delegation edges: {id}"),
            Self::HasOutgoingEdges(id) => write!(f, "session has outgoing edges: {id}"),
            Self::NoDelegationEdge { src, dst } => {
                write!(f, "no delegation edge from {src} to {dst}")
            }
            Self::HasIncomingDelegation(id) => {
                write!(f, "session has incoming delegation: {id}")
            }
            Self::SelfReference => write!(f, "cannot reference self"),
        }
    }
}

impl core::error::Error for CoordinatorError {}

// ════════════════════════════════════════════════════════════════
// Coordinator
// ════════════════════════════════════════════════════════════════

/// Multi-session coordinator. Pure state machine.
/// Aligned with coordinator.qnt — 4-state model with delegation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Coordinator {
    sessions: BTreeMap<SessionId, CoordinatedSession>,
    routes: BTreeSet<Route>,
    delegation_graph: BTreeSet<DelegationEdge>,
}

impl Coordinator {
    pub fn new() -> Self {
        Self {
            sessions: BTreeMap::new(),
            routes: BTreeSet::new(),
            delegation_graph: BTreeSet::new(),
        }
    }

    // ── Queries ────────────────────────────────────────────

    pub fn session(&self, id: &str) -> Option<&CoordinatedSession> {
        self.sessions.get(id)
    }

    pub fn sessions(&self) -> &BTreeMap<SessionId, CoordinatedSession> {
        &self.sessions
    }

    pub fn routes(&self) -> &BTreeSet<Route> {
        &self.routes
    }

    pub fn delegation_graph(&self) -> &BTreeSet<DelegationEdge> {
        &self.delegation_graph
    }

    fn has_route(&self, src: &str, dst: &str) -> bool {
        self.routes.iter().any(|r| r.src == src && r.dst == dst)
    }

    /// Can `start` reach `target` through waiting_on?
    /// Used for deadlock prevention.
    pub fn can_reach(&self, start: &str, target: &str) -> bool {
        let mut reachable: BTreeSet<&str> = BTreeSet::new();
        let mut frontier: Vec<&str> = match self.sessions.get(start) {
            Some(s) => s.waiting_on.iter().map(|id| id.as_str()).collect(),
            None => return false,
        };

        while let Some(node) = frontier.pop() {
            if node == target {
                return true;
            }
            if reachable.insert(node)
                && let Some(s) = self.sessions.get(node) {
                    for w in &s.waiting_on {
                        if !reachable.contains(w.as_str()) {
                            frontier.push(w);
                        }
                    }
                }
        }

        false
    }

    // ── Lifecycle ──────────────────────────────────────────

    /// Spawn a new session. Starts SIdle.
    /// Spec: spawn_session
    pub fn spawn_session(&mut self, id: SessionId) -> Result<Effect, CoordinatorError> {
        if self.sessions.contains_key(&id) {
            return Err(CoordinatorError::SessionExists(id));
        }
        self.sessions
            .insert(id.clone(), CoordinatedSession::empty());
        Ok(Effect::CreateSession { id })
    }

    /// Fork: spawn a child seeded with parent's event_count.
    /// Spec: fork_session
    pub fn fork_session(
        &mut self,
        parent: SessionId,
        child: SessionId,
    ) -> Result<Effect, CoordinatorError> {
        if parent == child {
            return Err(CoordinatorError::SelfReference);
        }
        let parent_session = self
            .sessions
            .get(&parent)
            .ok_or_else(|| CoordinatorError::SessionNotFound(parent.clone()))?;
        if self.sessions.contains_key(&child) {
            return Err(CoordinatorError::SessionExists(child));
        }
        let parent_event_count = parent_session.event_count;
        self.sessions.insert(
            child.clone(),
            CoordinatedSession {
                event_count: parent_event_count,
                ..CoordinatedSession::empty()
            },
        );
        Ok(Effect::ForkSession {
            parent,
            child,
            parent_event_count,
        })
    }

    /// Destroy a session. Must be SIdle with no graph involvement.
    /// Spec: destroy_session
    pub fn destroy_session(&mut self, id: SessionId) -> Result<Effect, CoordinatorError> {
        let session = self
            .sessions
            .get(&id)
            .ok_or_else(|| CoordinatorError::SessionNotFound(id.clone()))?;
        if session.status != SessionStatus::SIdle {
            return Err(CoordinatorError::NotIdle(id));
        }
        if self
            .delegation_graph
            .iter()
            .any(|d| d.src == id || d.dst == id)
        {
            return Err(CoordinatorError::HasDelegationEdge(id));
        }
        self.sessions.remove(&id);
        self.routes.retain(|r| r.src != id && r.dst != id);
        Ok(Effect::DestroySession { id })
    }

    // ── Routing ────────────────────────────────────────────

    /// Add a route (capability).
    /// Spec: add_route
    pub fn add_route(&mut self, route: Route) -> Result<(), CoordinatorError> {
        if !self.sessions.contains_key(&route.src) {
            return Err(CoordinatorError::SessionNotFound(route.src.clone()));
        }
        if !self.sessions.contains_key(&route.dst) {
            return Err(CoordinatorError::SessionNotFound(route.dst.clone()));
        }
        if route.src == route.dst {
            return Err(CoordinatorError::SelfReference);
        }
        self.routes.insert(route);
        Ok(())
    }

    /// Remove a route.
    pub fn remove_route(&mut self, route: &Route) {
        self.routes.remove(route);
    }

    // ── Turn lifecycle ─────────────────────────────────────

    /// Start processing (SIdle → SProcessing).
    /// Spec: start_processing
    pub fn start_processing(&mut self, id: &str) -> Result<(), CoordinatorError> {
        let session = self
            .sessions
            .get_mut(id)
            .ok_or_else(|| CoordinatorError::SessionNotFound(id.to_string()))?;
        if session.status != SessionStatus::SIdle {
            return Err(CoordinatorError::NotIdle(id.to_string()));
        }
        session.status = SessionStatus::SProcessing;
        Ok(())
    }

    /// Process one step (gated by step bound).
    /// Spec: process_step
    pub fn process_step(&mut self, id: &str) -> Result<(), CoordinatorError> {
        let session = self
            .sessions
            .get_mut(id)
            .ok_or_else(|| CoordinatorError::SessionNotFound(id.to_string()))?;
        if session.status != SessionStatus::SProcessing {
            return Err(CoordinatorError::NotProcessing(id.to_string()));
        }
        if session.step_count >= MAX_STEPS {
            return Err(CoordinatorError::MaxStepsReached(id.to_string()));
        }
        session.step_count += 1;
        session.event_count += 1;
        Ok(())
    }

    /// Finish processing (SProcessing → SDone). Requires empty waiting_on.
    /// Spec: finish_session
    pub fn finish_session(&mut self, id: &str) -> Result<(), CoordinatorError> {
        let session = self
            .sessions
            .get(id)
            .ok_or_else(|| CoordinatorError::SessionNotFound(id.to_string()))?;
        if session.status != SessionStatus::SProcessing {
            return Err(CoordinatorError::NotProcessing(id.to_string()));
        }
        if !session.waiting_on.is_empty() {
            return Err(CoordinatorError::WaitingOnNotEmpty(id.to_string()));
        }
        let session = self.sessions.get_mut(id).unwrap();
        session.status = SessionStatus::SDone;
        Ok(())
    }

    /// Reset a done session (SDone → SIdle). No incoming delegation edges.
    /// Spec: reset_session
    pub fn reset_session(&mut self, id: &str) -> Result<(), CoordinatorError> {
        let session = self
            .sessions
            .get(id)
            .ok_or_else(|| CoordinatorError::SessionNotFound(id.to_string()))?;
        if session.status != SessionStatus::SDone {
            return Err(CoordinatorError::NotDone(id.to_string()));
        }
        if !session.waiting_on.is_empty() {
            return Err(CoordinatorError::WaitingOnNotEmpty(id.to_string()));
        }
        if self.delegation_graph.iter().any(|d| d.dst == id) {
            return Err(CoordinatorError::HasIncomingDelegation(id.to_string()));
        }
        let session = self.sessions.get_mut(id).unwrap();
        session.status = SessionStatus::SIdle;
        session.step_count = 0;
        Ok(())
    }

    // ── Delegation ─────────────────────────────────────────

    /// Delegate to another session. Route required. No cycle.
    /// Source must be SProcessing or SWaitingDelegate.
    /// Spec: delegate_to
    pub fn delegate_to(
        &mut self,
        src: &str,
        dst: &str,
        request_type: &str,
        request_data: BTreeMap<String, crate::types::Value>,
    ) -> Result<Effect, CoordinatorError> {
        if src == dst {
            return Err(CoordinatorError::SelfReference);
        }
        if !self.has_route(src, dst) {
            return Err(CoordinatorError::NoRoute {
                src: src.to_string(),
                dst: dst.to_string(),
            });
        }
        let src_session = self
            .sessions
            .get(src)
            .ok_or_else(|| CoordinatorError::SessionNotFound(src.to_string()))?;
        if src_session.status != SessionStatus::SProcessing
            && src_session.status != SessionStatus::SWaitingDelegate
        {
            return Err(CoordinatorError::NotProcessingOrWaitingDelegate(
                src.to_string(),
            ));
        }
        let dst_session = self
            .sessions
            .get(dst)
            .ok_or_else(|| CoordinatorError::SessionNotFound(dst.to_string()))?;
        if dst_session.status != SessionStatus::SIdle {
            return Err(CoordinatorError::NotIdle(dst.to_string()));
        }
        if self.can_reach(dst, src) {
            return Err(CoordinatorError::WouldDeadlock {
                src: src.to_string(),
                dst: dst.to_string(),
            });
        }

        // Apply
        let src_session = self.sessions.get_mut(src).unwrap();
        src_session.status = SessionStatus::SWaitingDelegate;
        src_session.waiting_on.insert(dst.to_string());

        let dst_session = self.sessions.get_mut(dst).unwrap();
        dst_session.status = SessionStatus::SProcessing;
        dst_session.event_count += 1;

        self.delegation_graph.insert(DelegationEdge {
            src: src.to_string(),
            dst: dst.to_string(),
        });

        Ok(Effect::AgentRequest {
            session: dst.to_string(),
            event_tag: request_type.to_string(),
            request_data,
        })
    }

    /// Complete a delegation. Dst must be SDone.
    /// Spec: complete_delegation
    pub fn complete_delegation(
        &mut self,
        src: &str,
        dst: &str,
    ) -> Result<Effect, CoordinatorError> {
        let src_session = self
            .sessions
            .get(src)
            .ok_or_else(|| CoordinatorError::SessionNotFound(src.to_string()))?;
        if src_session.status != SessionStatus::SWaitingDelegate {
            return Err(CoordinatorError::NotProcessingOrWaitingDelegate(
                src.to_string(),
            ));
        }
        if !src_session.waiting_on.contains(dst) {
            return Err(CoordinatorError::NoDelegationEdge {
                src: src.to_string(),
                dst: dst.to_string(),
            });
        }
        let dst_session = self
            .sessions
            .get(dst)
            .ok_or_else(|| CoordinatorError::SessionNotFound(dst.to_string()))?;
        if dst_session.status != SessionStatus::SDone {
            return Err(CoordinatorError::NotDone(dst.to_string()));
        }

        // Find the result_type from the route
        let result_type = self
            .routes
            .iter()
            .find(|r| r.src == src && r.dst == dst)
            .map(|r| r.result_type.clone())
            .unwrap_or_default();

        // Apply
        let src_session = self.sessions.get_mut(src).unwrap();
        src_session.waiting_on.remove(dst);
        src_session.event_count += 1;
        if src_session.waiting_on.is_empty() {
            src_session.status = SessionStatus::SProcessing;
        }

        let dst_session = self.sessions.get_mut(dst).unwrap();
        dst_session.status = SessionStatus::SIdle;
        dst_session.step_count = 0;

        self.delegation_graph.remove(&DelegationEdge {
            src: src.to_string(),
            dst: dst.to_string(),
        });

        Ok(Effect::CollectAgentResult {
            parent: src.to_string(),
            child: dst.to_string(),
            result_type,
        })
    }

    // ── Cancellation ───────────────────────────────────────

    /// Cancel an active delegation. Target must be a leaf (no outgoing edges).
    /// Spec: cancel_delegation
    pub fn cancel_delegation(&mut self, src: &str, dst: &str) -> Result<(), CoordinatorError> {
        let src_session = self
            .sessions
            .get(src)
            .ok_or_else(|| CoordinatorError::SessionNotFound(src.to_string()))?;
        if src_session.status != SessionStatus::SWaitingDelegate {
            return Err(CoordinatorError::NotProcessingOrWaitingDelegate(
                src.to_string(),
            ));
        }
        if !src_session.waiting_on.contains(dst) {
            return Err(CoordinatorError::NoDelegationEdge {
                src: src.to_string(),
                dst: dst.to_string(),
            });
        }
        if !self
            .delegation_graph
            .iter()
            .any(|d| d.src == src && d.dst == dst)
        {
            return Err(CoordinatorError::NoDelegationEdge {
                src: src.to_string(),
                dst: dst.to_string(),
            });
        }
        // Target must be a leaf
        if self.delegation_graph.iter().any(|d| d.src == dst) {
            return Err(CoordinatorError::HasOutgoingEdges(dst.to_string()));
        }

        // Apply
        let src_session = self.sessions.get_mut(src).unwrap();
        src_session.waiting_on.remove(dst);
        if src_session.waiting_on.is_empty() {
            src_session.status = SessionStatus::SProcessing;
        }

        // Reset dst to empty_session (Lean spec: { empty_session with status := .SIdle })
        *self.sessions.get_mut(dst).unwrap() = CoordinatedSession::empty();

        self.delegation_graph.remove(&DelegationEdge {
            src: src.to_string(),
            dst: dst.to_string(),
        });

        Ok(())
    }

    // ── Failure ────────────────────────────────────────────

    /// Clean up after a session failure. Must be a leaf (no outgoing edges).
    /// Removes session, updates waiters, cleans up graphs and routes.
    /// Spec: session_failed
    pub fn session_failed(&mut self, id: &str) -> Result<Effect, CoordinatorError> {
        if !self.sessions.contains_key(id) {
            return Err(CoordinatorError::SessionNotFound(id.to_string()));
        }
        // Must be a leaf
        if self.delegation_graph.iter().any(|d| d.src == id) {
            return Err(CoordinatorError::HasOutgoingEdges(id.to_string()));
        }

        // Update all sessions waiting on the failed session
        let session_ids: Vec<SessionId> = self.sessions.keys().cloned().collect();
        for sid in &session_ids {
            if sid == id {
                continue;
            }
            let s = self.sessions.get(sid).unwrap();
            if s.waiting_on.contains(id) {
                let s = self.sessions.get_mut(sid).unwrap();
                s.waiting_on.remove(id);
                if s.waiting_on.is_empty() && s.status == SessionStatus::SWaitingDelegate {
                    s.status = SessionStatus::SProcessing;
                }
            }
        }

        // Remove session
        self.sessions.remove(id);
        self.routes.retain(|r| r.src != id && r.dst != id);
        self.delegation_graph.retain(|d| d.src != id && d.dst != id);

        Ok(Effect::DestroySession { id: id.to_string() })
    }
}

impl Default for Coordinator {
    fn default() -> Self {
        Self::new()
    }
}

// ════════════════════════════════════════════════════════════════
// Tests — aligned with coordinator.qnt test scenarios
// ════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    fn setup_ab(c: &mut Coordinator) {
        c.spawn_session("a".into()).unwrap();
        c.spawn_session("b".into()).unwrap();
        c.add_route(Route {
            src: "a".into(),
            dst: "b".into(),
            request_type: "DelegationRequest".into(),
            result_type: "DelegationResult".into(),
        })
        .unwrap();
    }

    fn empty_data() -> BTreeMap<String, crate::types::Value> {
        BTreeMap::new()
    }

    // ── Sequential pipeline (spec: sequential_pipeline) ──────

    #[test]
    fn sequential_pipeline() {
        let mut c = Coordinator::new();
        setup_ab(&mut c);

        c.start_processing("a").unwrap();
        c.process_step("a").unwrap();
        c.delegate_to("a", "b", "DelegationRequest", empty_data())
            .unwrap();

        assert_eq!(
            c.session("a").unwrap().status,
            SessionStatus::SWaitingDelegate
        );
        assert_eq!(c.session("b").unwrap().status, SessionStatus::SProcessing);

        c.process_step("b").unwrap();
        c.finish_session("b").unwrap();
        assert_eq!(c.session("b").unwrap().status, SessionStatus::SDone);

        c.complete_delegation("a", "b").unwrap();
        assert_eq!(c.session("a").unwrap().status, SessionStatus::SProcessing);
        assert_eq!(c.session("b").unwrap().status, SessionStatus::SIdle);

        c.finish_session("a").unwrap();
        assert_eq!(c.session("a").unwrap().status, SessionStatus::SDone);
    }

    // ── Fan-out / fan-in (spec: fan_out_fan_in) ──────────────

    #[test]
    fn fan_out_fan_in() {
        let mut c = Coordinator::new();
        c.spawn_session("s1".into()).unwrap();
        c.spawn_session("s2".into()).unwrap();
        c.spawn_session("s3".into()).unwrap();
        c.add_route(Route {
            src: "s1".into(),
            dst: "s2".into(),
            request_type: "DelegationRequest".into(),
            result_type: "DelegationResult".into(),
        })
        .unwrap();
        c.add_route(Route {
            src: "s1".into(),
            dst: "s3".into(),
            request_type: "WorkRequest".into(),
            result_type: "WorkResult".into(),
        })
        .unwrap();

        c.start_processing("s1").unwrap();
        c.delegate_to("s1", "s2", "DelegationRequest", empty_data())
            .unwrap();
        // s1 is now SWaitingDelegate, can still delegate more
        c.delegate_to("s1", "s3", "WorkRequest", empty_data())
            .unwrap();

        assert_eq!(c.session("s1").unwrap().waiting_on.len(), 2);

        c.process_step("s2").unwrap();
        c.finish_session("s2").unwrap();
        c.complete_delegation("s1", "s2").unwrap();
        // Still waiting on s3
        assert_eq!(
            c.session("s1").unwrap().status,
            SessionStatus::SWaitingDelegate
        );

        c.process_step("s3").unwrap();
        c.finish_session("s3").unwrap();
        c.complete_delegation("s1", "s3").unwrap();
        // All delegates complete
        assert_eq!(c.session("s1").unwrap().status, SessionStatus::SProcessing);
        assert!(c.session("s1").unwrap().waiting_on.is_empty());

        c.finish_session("s1").unwrap();
    }

    // ── Deadlock prevention ──────────────────────────────────

    #[test]
    fn deadlock_prevented() {
        let mut c = Coordinator::new();
        c.spawn_session("a".into()).unwrap();
        c.spawn_session("b".into()).unwrap();
        c.add_route(Route {
            src: "a".into(),
            dst: "b".into(),
            request_type: "R".into(),
            result_type: "S".into(),
        })
        .unwrap();
        c.add_route(Route {
            src: "b".into(),
            dst: "a".into(),
            request_type: "R".into(),
            result_type: "S".into(),
        })
        .unwrap();

        c.start_processing("a").unwrap();
        c.delegate_to("a", "b", "R", empty_data()).unwrap();

        // b trying to delegate back to a would create cycle
        // but a is SWaitingDelegate, not SIdle, so NotIdle fires first
        let err = c.delegate_to("b", "a", "R", empty_data()).unwrap_err();
        assert_eq!(err, CoordinatorError::NotIdle("a".into()));
    }

    // ── Cancel delegation ────────────────────────────────────

    #[test]
    fn cancel_delegation_basic() {
        let mut c = Coordinator::new();
        setup_ab(&mut c);

        c.start_processing("a").unwrap();
        c.delegate_to("a", "b", "DelegationRequest", empty_data())
            .unwrap();
        assert_eq!(c.session("a").unwrap().waiting_on.len(), 1);

        c.cancel_delegation("a", "b").unwrap();

        assert!(c.session("a").unwrap().waiting_on.is_empty());
        assert_eq!(c.session("a").unwrap().status, SessionStatus::SProcessing);
        assert_eq!(c.session("b").unwrap().status, SessionStatus::SIdle);
        assert!(c.delegation_graph().is_empty());
    }

    // ── Session failure ──────────────────────────────────────

    #[test]
    fn session_failed_basic() {
        let mut c = Coordinator::new();
        setup_ab(&mut c);

        c.start_processing("a").unwrap();
        c.delegate_to("a", "b", "DelegationRequest", empty_data())
            .unwrap();

        c.session_failed("b").unwrap();

        assert!(c.session("b").is_none());
        assert!(c.session("a").unwrap().waiting_on.is_empty());
        assert_eq!(c.session("a").unwrap().status, SessionStatus::SProcessing);
        assert!(c.delegation_graph().is_empty());
    }

    // ── Step count bounded ───────────────────────────────────

    #[test]
    fn step_count_bounded() {
        let mut c = Coordinator::new();
        c.spawn_session("a".into()).unwrap();
        c.start_processing("a").unwrap();

        for _ in 0..MAX_STEPS {
            c.process_step("a").unwrap();
        }
        let err = c.process_step("a").unwrap_err();
        assert_eq!(err, CoordinatorError::MaxStepsReached("a".into()));
    }

    // ── Destroy ──────────────────────────────────────────────

    #[test]
    fn destroy_cleans_routes() {
        let mut c = Coordinator::new();
        setup_ab(&mut c);

        c.destroy_session("b".into()).unwrap();
        assert!(c.session("b").is_none());
        assert!(c.routes().iter().all(|r| r.dst != "b"));
    }

    #[test]
    fn destroy_busy_fails() {
        let mut c = Coordinator::new();
        c.spawn_session("a".into()).unwrap();
        c.start_processing("a").unwrap();
        let err = c.destroy_session("a".into()).unwrap_err();
        assert_eq!(err, CoordinatorError::NotIdle("a".into()));
    }

    // ── Fork ─────────────────────────────────────────────────

    #[test]
    fn fork_with_context() {
        let mut c = Coordinator::new();
        c.spawn_session("parent".into()).unwrap();
        c.start_processing("parent").unwrap();
        c.process_step("parent").unwrap();
        c.finish_session("parent").unwrap();
        c.reset_session("parent").unwrap();

        c.fork_session("parent".into(), "child".into()).unwrap();
        assert_eq!(
            c.session("child").unwrap().event_count,
            c.session("parent").unwrap().event_count
        );
    }
}
