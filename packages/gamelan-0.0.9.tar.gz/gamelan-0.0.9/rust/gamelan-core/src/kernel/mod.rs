//! Proved kernel functions — backed by Lean 4 proofs.
//!
//! No I/O, no async, no runtime. These modules contain the pure functions
//! that are mechanically verified against the Lean reference implementation.

pub mod types;
pub mod vm;
pub mod dependency;
pub mod coordinator;
pub mod typecheck;
pub mod expand;
pub mod interpreter;
pub mod network;
