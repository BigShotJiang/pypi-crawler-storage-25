//! Dependency analysis — read/write slot collection for transducers.
//!
//! Aligned with Lean Dependency.lean. Collects the set of slot names
//! that a transducer reads (Ref nodes in expressions) and writes
//! (update targets). Used by the loader to compute dependency ordering.
//!
//! Key property (proved in Lean): if two transducers are independent
//! (disjoint writes, no cross-reads), they commute — execution order
//! doesn't affect the result.

use crate::prelude::*;
use crate::types::{Expr, RecField, TransducerDef};

/// Collect all Ref names from an expression.
/// Maps to Lean `refs`.
pub fn refs(expr: &Expr) -> Vec<String> {
    match expr {
        Expr::Lit { .. } => vec![],
        Expr::Ref { name } => vec![name.clone()],

        // Binary ops
        Expr::Add { left, right }
        | Expr::Mul { left, right }
        | Expr::Div { left, right }
        | Expr::Mod { left, right }
        | Expr::Gt { left, right }
        | Expr::Eq { left, right }
        | Expr::StrCat { left, right }
        | Expr::LAppend {
            list: left,
            item: right,
        }
        | Expr::MGet {
            map: left,
            key: right,
            ..
        }
        | Expr::MDel {
            map: left,
            key: right,
        } => {
            let mut r = refs(left);
            r.extend(refs(right));
            r
        }

        // Unary ops
        Expr::MKeys { map: inner } => refs(inner),

        // Ternary
        Expr::MPut { map, key, value } => {
            let mut r = refs(map);
            r.extend(refs(key));
            r.extend(refs(value));
            r
        }
        Expr::IfElse {
            cond,
            then_expr,
            else_expr,
        } => {
            let mut r = refs(cond);
            r.extend(refs(then_expr));
            r.extend(refs(else_expr));
            r
        }
        // Records
        Expr::Rec { fields } => refs_fields(fields),

        // Binding
        Expr::ELet { value, body, .. } => {
            let mut r = refs(value);
            r.extend(refs(body));
            r
        }

        // Fold
        Expr::LFold {
            list, init, body, ..
        } => {
            let mut r = refs(list);
            r.extend(refs(init));
            r.extend(refs(body));
            r
        }

        // Macro (should be expanded before dependency analysis)
        Expr::Macro { args, .. } => args.iter().flat_map(refs).collect(),
    }
}

/// Collect Ref names from record fields.
fn refs_fields(fields: &[RecField]) -> Vec<String> {
    fields.iter().flat_map(|f| refs(&f.val_expr)).collect()
}

/// All slot names read by a transducer (all Ref names in all rules).
/// Maps to Lean `read_slots`.
pub fn read_slots(td: &TransducerDef) -> Vec<String> {
    td.rules
        .iter()
        .flat_map(|r| {
            let mut names = refs(&r.guard);
            for upd in &r.updates {
                names.extend(refs(&upd.expr));
            }
            for emit in &r.emits {
                names.extend(refs(emit));
            }
            names
        })
        .collect()
}

/// All slot names written by a transducer (update targets).
/// Maps to Lean `written_slots`.
pub fn written_slots(td: &TransducerDef) -> Vec<String> {
    td.rules
        .iter()
        .flat_map(|r| r.updates.iter().map(|u| u.slot.clone()))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::*;

    #[test]
    fn refs_collects_ref_names() {
        let expr = Expr::Add {
            left: Box::new(Expr::Ref { name: "x".into() }),
            right: Box::new(Expr::Lit {
                value: Value::Int(1),
            }),
        };
        assert_eq!(refs(&expr), vec!["x"]);
    }

    #[test]
    fn refs_nested() {
        let expr = Expr::IfElse {
            cond: Box::new(Expr::Ref {
                name: "flag".into(),
            }),
            then_expr: Box::new(Expr::Ref { name: "a".into() }),
            else_expr: Box::new(Expr::Ref { name: "b".into() }),
        };
        assert_eq!(refs(&expr), vec!["flag", "a", "b"]);
    }

    #[test]
    fn read_slots_from_transducer() {
        let td = TransducerDef {
            name: "test".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Ref { name: "x".into() }),
                    },
                }],
                emits: vec![],
            }],
        };
        let reads = read_slots(&td);
        assert!(reads.contains(&"count".to_string()));
        assert!(reads.contains(&"x".to_string()));
    }

    #[test]
    fn written_slots_from_transducer() {
        let td = TransducerDef {
            name: "test".into(),
            slots: vec![
                SlotDef {
                    name: "a".into(),
                    initial: Value::Int(0),
                },
                SlotDef {
                    name: "b".into(),
                    initial: Value::Int(0),
                },
            ],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![
                    Update {
                        slot: "a".into(),
                        expr: Expr::Lit {
                            value: Value::Int(1),
                        },
                    },
                    Update {
                        slot: "b".into(),
                        expr: Expr::Ref { name: "a".into() },
                    },
                ],
                emits: vec![],
            }],
        };
        let writes = written_slots(&td);
        assert_eq!(writes, vec!["a", "b"]);
    }
}
