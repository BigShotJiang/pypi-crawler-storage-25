//! Session lifecycle — create, replay, resume, snapshot.
//!
//! A session is the runtime unit: mailbox in, fold, out to sources.
//! This module handles the pure lifecycle operations. The language
//! package handles I/O (event log persistence, source dispatch).
//!
//! Uses the continuation model (SessionMonad.lean):
//! - turn_step: clear_pending → fold → gate → classify → add_pending
//! - Pending flows through continuations (each call gets previous pending)
//! - Safety is structural (proved in Lean), not runtime-enforced
//!
//! Key property (proved as `replay_deterministic`):
//! same events → same state. This makes crash recovery correct
//! and snapshot + remaining events equivalent to full replay.

use crate::agent_fold::{self, InboundCheckDef, Pending, Topology, TurnResult};
use crate::prelude::*;
use crate::types::{Env, TransducerDef, Value};
use alloc::collections::BTreeMap;
use serde::{Deserialize, Serialize};

/// An event in the log: tag + data.
pub type EventRecord = (String, BTreeMap<String, Value>);

/// Configuration for creating a session.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionConfig {
    /// Connection topology — declares which sources exist and which need checks
    pub topology: Topology,
    /// Inbound check definitions — intercept result events before the fold
    #[serde(default)]
    pub inbound_checks: Vec<InboundCheckDef>,
}

/// A snapshot of session state at a point in time.
/// Serializable — the language package persists and loads these.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Snapshot {
    /// Pending request types at snapshot time
    pub pending: Pending,
    /// Transducer state at snapshot time
    pub vm_env: Env,
    /// Number of events processed up to this snapshot
    pub event_count: usize,
}

/// Result of a session lifecycle operation (create, replay, resume).
#[derive(Debug, Clone)]
pub struct SessionState {
    /// Connection topology
    topology: Topology,
    /// Inbound check definitions
    inbound_checks: Vec<InboundCheckDef>,
    /// Pending request types (flows through continuations)
    pub pending: Pending,
    /// Current transducer state
    pub vm_env: Env,
    /// Total events processed
    pub events_processed: usize,
}

impl SessionState {
    /// Take a snapshot of the current session state.
    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            pending: self.pending.clone(),
            vm_env: self.vm_env.clone(),
            event_count: self.events_processed,
        }
    }

    /// Process one event (live mode). Returns the turn result
    /// and updates the session state in place.
    pub fn process(
        &mut self,
        transducers: &[TransducerDef],
        event_tag: &str,
        event_data: &BTreeMap<String, Value>,
    ) -> TurnResult {
        let result = agent_fold::turn_step(
            &self.topology,
            &self.inbound_checks,
            transducers,
            &self.vm_env,
            event_tag,
            event_data,
            &self.pending,
        );
        self.pending = result.pending.clone();
        self.vm_env = result.vm_env.clone();
        self.events_processed += 1;
        result
    }

    /// Is anything pending? If not, the turn can end.
    pub fn is_quiescent(&self) -> bool {
        self.pending.is_empty()
    }
}

/// Create a new session from transducer definitions and config.
pub fn create(transducers: &[TransducerDef], config: &SessionConfig) -> SessionState {
    SessionState {
        topology: config.topology.clone(),
        inbound_checks: config.inbound_checks.clone(),
        pending: vec![],
        vm_env: crate::loader::init_env(transducers),
        events_processed: 0,
    }
}

/// Replay an event log from the beginning to reconstruct state.
///
/// Runs every event through turn_step to reconstruct pending state
/// and transducer state. Dispatched requests are discarded — this is
/// crash recovery.
///
/// Proved deterministic: same events → same state.
pub fn replay(
    transducers: &[TransducerDef],
    config: &SessionConfig,
    event_log: &[EventRecord],
) -> SessionState {
    let mut state = create(transducers, config);

    for (tag, data) in event_log {
        // Run full turn_step to reconstruct pending state correctly
        let result = agent_fold::turn_step(
            &state.topology,
            &state.inbound_checks,
            transducers,
            &state.vm_env,
            tag,
            data,
            &state.pending,
        );
        state.pending = result.pending;
        state.vm_env = result.vm_env;
        state.events_processed += 1;
    }

    state
}

/// Resume from a snapshot, replaying only the events after the
/// snapshot point.
///
/// The snapshot contract:
///   replay(events[0..]) == resume(snapshot_at(N), events[N..])
///
/// This holds because the fold is deterministic — if the snapshot
/// correctly captures state at event N, folding the remaining
/// events produces the same final state as full replay.
pub fn resume(
    snapshot: Snapshot,
    config: &SessionConfig,
    transducers: &[TransducerDef],
    remaining_events: &[EventRecord],
) -> SessionState {
    let mut state = SessionState {
        topology: config.topology.clone(),
        inbound_checks: config.inbound_checks.clone(),
        pending: snapshot.pending,
        vm_env: snapshot.vm_env,
        events_processed: snapshot.event_count,
    };

    for (tag, data) in remaining_events {
        let result = agent_fold::turn_step(
            &state.topology,
            &state.inbound_checks,
            transducers,
            &state.vm_env,
            tag,
            data,
            &state.pending,
        );
        state.pending = result.pending;
        state.vm_env = result.vm_env;
        state.events_processed += 1;
    }

    state
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent_fold::{ConnectionDef, RequestAction};
    use crate::types::*;

    fn producer_td() -> TransducerDef {
        TransducerDef {
            name: "producer".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Add {
                        left: Box::new(Expr::Ref {
                            name: "count".into(),
                        }),
                        right: Box::new(Expr::Lit {
                            value: Value::Int(1),
                        }),
                    },
                }],
                emits: vec![Expr::Rec {
                    fields: vec![RecField {
                        key: "type".into(),
                        val_expr: Expr::Lit {
                            value: Value::Str("WorkRequest".into()),
                        },
                    }],
                }],
            }],
        }
    }

    fn test_config() -> SessionConfig {
        SessionConfig {
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: false,
                check_source: None,
            }],
            inbound_checks: vec![],
        }
    }

    // ── Create ──

    #[test]
    fn create_initializes_state() {
        let tds = vec![producer_td()];
        let state = create(&tds, &test_config());
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(0)));
        assert_eq!(state.events_processed, 0);
        assert!(state.is_quiescent());
    }

    // ── Process ──

    #[test]
    fn process_dispatches_and_sets_pending() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());

        let result = state.process(&tds, "Input", &BTreeMap::new());
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(1)));
        assert_eq!(state.events_processed, 1);
        assert_eq!(result.requests.len(), 1);
        assert!(matches!(&result.requests[0], RequestAction::Dispatch(_)));
        // Pending set
        assert!(!state.is_quiescent());
        assert!(agent_fold::is_pending(&state.pending, "WorkRequest"));
    }

    #[test]
    fn process_gates_while_pending() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());

        // First input → dispatched
        let r1 = state.process(&tds, "Input", &BTreeMap::new());
        assert_eq!(r1.requests.len(), 1);

        // Second input → gated (WorkRequest is pending)
        let r2 = state.process(&tds, "Input", &BTreeMap::new());
        assert!(r2.requests.is_empty());
        // But projection still ran
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(2)));
    }

    #[test]
    fn process_clears_pending_on_result() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());

        // Input → pending
        state.process(&tds, "Input", &BTreeMap::new());
        assert!(!state.is_quiescent());

        // Result → clears pending
        state.process(&tds, "WorkResult", &BTreeMap::new());
        assert!(state.is_quiescent());
    }

    #[test]
    fn process_full_lifecycle() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());

        // 1. Input → dispatch WorkRequest
        let r1 = state.process(&tds, "Input", &BTreeMap::new());
        assert_eq!(r1.requests.len(), 1);
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(1)));

        // 2. Input while pending → gated
        let r2 = state.process(&tds, "Input", &BTreeMap::new());
        assert!(r2.requests.is_empty());
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(2)));

        // 3. WorkResult → clears pending
        state.process(&tds, "WorkResult", &BTreeMap::new());
        assert!(state.is_quiescent());

        // 4. Input again → dispatches
        let r4 = state.process(&tds, "Input", &BTreeMap::new());
        assert_eq!(r4.requests.len(), 1);
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(3)));
    }

    #[test]
    fn process_with_check() {
        let tds = vec![producer_td()];
        let config = SessionConfig {
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: true,
                check_source: Some("approval".into()),
            }],
            inbound_checks: vec![],
        };
        let mut state = create(&tds, &config);

        let result = state.process(&tds, "Input", &BTreeMap::new());
        assert_eq!(result.requests.len(), 1);
        match &result.requests[0] {
            RequestAction::CheckThenDispatch { check_source, .. } => {
                assert_eq!(check_source, "approval");
            }
            other => panic!("Expected CheckThenDispatch, got {:?}", other),
        }
    }

    #[test]
    fn process_inbound_check() {
        let tds = vec![producer_td()];
        let config = SessionConfig {
            topology: vec![ConnectionDef {
                request_type: "WorkRequest".into(),
                result_type: "WorkResult".into(),
                has_check: false,
                check_source: None,
            }],
            inbound_checks: vec![InboundCheckDef {
                intercept: "WorkResult".into(),
                check_source: "guardrail".into(),
            }],
        };
        let mut state = create(&tds, &config);

        // Input → dispatched
        state.process(&tds, "Input", &BTreeMap::new());

        // WorkResult → inbound check detected
        let result = state.process(&tds, "WorkResult", &BTreeMap::new());
        assert_eq!(result.inbound_check, Some("guardrail".into()));
    }

    // ── Replay ──

    #[test]
    fn replay_empty_log() {
        let tds = vec![producer_td()];
        let state = replay(&tds, &test_config(), &[]);
        assert_eq!(state.events_processed, 0);
        assert_eq!(state.vm_env.get("count"), Some(&Value::Int(0)));
    }

    #[test]
    fn replay_matches_live() {
        let tds = vec![producer_td()];
        let config = test_config();

        // Live: process 3 events
        let mut live = create(&tds, &config);
        live.process(&tds, "Input", &BTreeMap::new());
        live.process(&tds, "WorkResult", &BTreeMap::new());
        live.process(&tds, "Input", &BTreeMap::new());

        // Replay: same 3 events
        let log: Vec<EventRecord> = vec![
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
            ("Input".into(), BTreeMap::new()),
        ];
        let replayed = replay(&tds, &config, &log);

        assert_eq!(replayed.vm_env.get("count"), live.vm_env.get("count"));
        assert_eq!(replayed.events_processed, 3);
    }

    #[test]
    fn replay_reconstructs_pending() {
        let tds = vec![producer_td()];
        let log: Vec<EventRecord> = vec![("Input".into(), BTreeMap::new())];
        let state = replay(&tds, &test_config(), &log);
        assert!(agent_fold::is_pending(&state.pending, "WorkRequest"));
    }

    // ── Snapshot + Resume ──

    #[test]
    fn snapshot_captures_state() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());
        state.process(&tds, "Input", &BTreeMap::new());
        state.process(&tds, "WorkResult", &BTreeMap::new());

        let snap = state.snapshot();
        assert_eq!(snap.event_count, 2);
        assert_eq!(snap.vm_env.get("count"), Some(&Value::Int(1)));
        assert!(snap.pending.is_empty());
    }

    #[test]
    fn resume_from_snapshot_matches_full_replay() {
        let tds = vec![producer_td()];
        let config = test_config();

        // Full replay of 4 events
        let full_log: Vec<EventRecord> = vec![
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
        ];
        let full = replay(&tds, &config, &full_log);

        // Snapshot after 2 events, resume with remaining 2
        let partial_log: Vec<EventRecord> = vec![
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
        ];
        let partial = replay(&tds, &config, &partial_log);
        let snap = partial.snapshot();

        let remaining: Vec<EventRecord> = vec![
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
        ];
        let resumed = resume(snap, &config, &tds, &remaining);

        // Same final state
        assert_eq!(resumed.vm_env.get("count"), full.vm_env.get("count"));
        assert_eq!(resumed.events_processed, full.events_processed);
    }

    #[test]
    fn resume_from_empty_snapshot_equals_replay() {
        let tds = vec![producer_td()];
        let config = test_config();
        let state = create(&tds, &config);
        let snap = state.snapshot();

        let log: Vec<EventRecord> = vec![
            ("Input".into(), BTreeMap::new()),
            ("WorkResult".into(), BTreeMap::new()),
        ];

        let replayed = replay(&tds, &config, &log);
        let resumed = resume(snap, &config, &tds, &log);

        assert_eq!(resumed.vm_env.get("count"), replayed.vm_env.get("count"));
        assert_eq!(resumed.events_processed, replayed.events_processed);
    }

    // ── Snapshot serde ──

    #[test]
    fn snapshot_json_roundtrip() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());
        state.process(&tds, "Input", &BTreeMap::new());

        let snap = state.snapshot();
        let json = serde_json::to_string(&snap).unwrap();
        let snap2: Snapshot = serde_json::from_str(&json).unwrap();

        assert_eq!(snap.event_count, snap2.event_count);
        assert_eq!(snap.vm_env, snap2.vm_env);
        assert_eq!(snap.pending, snap2.pending);
    }

    #[test]
    fn snapshot_msgpack_roundtrip() {
        let tds = vec![producer_td()];
        let mut state = create(&tds, &test_config());
        state.process(&tds, "Input", &BTreeMap::new());

        let snap = state.snapshot();
        let bytes = rmp_serde::to_vec(&snap).unwrap();
        let snap2: Snapshot = rmp_serde::from_slice(&bytes).unwrap();

        assert_eq!(snap.event_count, snap2.event_count);
        assert_eq!(snap.vm_env, snap2.vm_env);
        assert_eq!(snap.pending, snap2.pending);
    }
}
