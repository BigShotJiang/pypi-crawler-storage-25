//! Loading contract — macro expansion + validation of transducer definitions.
//!
//! Pipeline: .td.json/.td.msgpack → expand macros → validate → VM executes.
//!
//! Maps from Loader.v (expansion) and Kernel.v (loading contract):
//! - Macro expansion: resolve Expr::Macro nodes via substitution
//! - Slot disjointness: no two transducers write the same slot
//! - Well-formedness: every rule's updates reference declared slots
//! - Connection completeness: every emittable request type has a dispatch rule

use crate::expand::{self, ExpandError, MacroEnv};
use crate::merge::{self, MergeError};
use crate::prelude::*;
use crate::types::TransducerDef;
use alloc::collections::{BTreeMap, BTreeSet};

#[derive(Debug, Clone, PartialEq)]
pub enum LoadError {
    /// Two transducers declare the same slot name
    SlotConflict {
        slot: String,
        transducer_a: String,
        transducer_b: String,
    },
    /// A rule references a slot not declared in its transducer
    UndeclaredSlot {
        transducer: String,
        rule_on: String,
        slot: String,
    },
    /// A transducer has no rules
    EmptyTransducer { transducer: String },
    /// Macro expansion failed
    MacroExpansion {
        transducer: String,
        error: ExpandError,
    },
    /// Merge failed (slot conflict)
    MergeConflict(MergeError),
}

/// Validate a single transducer definition.
pub fn validate_transducer(td: &TransducerDef) -> Vec<LoadError> {
    let mut errors = Vec::new();

    if td.rules.is_empty() {
        errors.push(LoadError::EmptyTransducer {
            transducer: td.name.clone(),
        });
    }

    let slot_names: BTreeSet<_> = td.slots.iter().map(|s| s.name.as_str()).collect();

    for rule in &td.rules {
        for upd in &rule.updates {
            if !slot_names.contains(upd.slot.as_str()) {
                errors.push(LoadError::UndeclaredSlot {
                    transducer: td.name.clone(),
                    rule_on: rule.on.clone(),
                    slot: upd.slot.clone(),
                });
            }
        }
    }

    errors
}

/// Validate a set of transducers for co-projection (loading into the same fold).
/// Checks slot disjointness across all transducers.
pub fn validate_session(transducers: &[TransducerDef]) -> Vec<LoadError> {
    let mut errors = Vec::new();

    // Validate each individually
    for td in transducers {
        errors.extend(validate_transducer(td));
    }

    // Check slot disjointness
    let mut seen_slots: BTreeSet<String> = BTreeSet::new();
    let mut slot_owners: BTreeMap<String, String> = BTreeMap::new();

    for td in transducers {
        for slot in &td.slots {
            if seen_slots.contains(&slot.name) {
                errors.push(LoadError::SlotConflict {
                    slot: slot.name.clone(),
                    transducer_a: slot_owners.get(&slot.name).unwrap().clone(),
                    transducer_b: td.name.clone(),
                });
            } else {
                seen_slots.insert(slot.name.clone());
                slot_owners.insert(slot.name.clone(), td.name.clone());
            }
        }
    }

    errors
}

/// Initialize the environment from transducer slot definitions.
/// Returns a map of slot_name → initial_value.
pub fn init_env(transducers: &[TransducerDef]) -> crate::types::Env {
    let mut env = crate::types::Env::new();
    for td in transducers {
        for slot in &td.slots {
            env.insert(slot.name.clone(), slot.initial.clone());
        }
    }
    env
}

/// Full loading pipeline: expand → merge → typecheck → validate.
/// Returns the merged, expanded TransducerDef ready for the VM,
/// plus the individual expanded TransducerDefs (for init_env).
pub fn load(
    macros: &MacroEnv,
    transducers: &[TransducerDef],
) -> Result<(TransducerDef, Vec<TransducerDef>), Vec<LoadError>> {
    // Phase 1: expand macros
    let expanded: Vec<TransducerDef> = transducers
        .iter()
        .map(|td| {
            expand::expand_transducer(macros, td).map_err(|e| LoadError::MacroExpansion {
                transducer: td.name.clone(),
                error: e,
            })
        })
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| vec![e])?;

    // Phase 2: merge (checks slot disjointness)
    let merged = merge::merge_all(&expanded).map_err(|e| vec![LoadError::MergeConflict(e)])?;

    // Phase 3: validate loading contract on merged result
    let errors = validate_transducer(&merged);
    if errors.is_empty() {
        Ok((merged, expanded))
    } else {
        Err(errors)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::*;

    #[test]
    fn valid_transducer_passes() {
        let td = TransducerDef {
            name: "counter".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "count".into(),
                    expr: Expr::Lit {
                        value: Value::Int(1),
                    },
                }],
                emits: vec![],
            }],
        };
        assert!(validate_transducer(&td).is_empty());
    }

    #[test]
    fn undeclared_slot_detected() {
        let td = TransducerDef {
            name: "bad".into(),
            slots: vec![SlotDef {
                name: "x".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![Update {
                    slot: "y".into(), // not declared
                    expr: Expr::Lit {
                        value: Value::Int(1),
                    },
                }],
                emits: vec![],
            }],
        };
        let errors = validate_transducer(&td);
        assert_eq!(errors.len(), 1);
        assert!(matches!(errors[0], LoadError::UndeclaredSlot { .. }));
    }

    #[test]
    fn empty_transducer_detected() {
        let td = TransducerDef {
            name: "empty".into(),
            slots: vec![],
            rules: vec![],
        };
        let errors = validate_transducer(&td);
        assert_eq!(errors.len(), 1);
        assert!(matches!(errors[0], LoadError::EmptyTransducer { .. }));
    }

    #[test]
    fn slot_conflict_detected() {
        let td1 = TransducerDef {
            name: "a".into(),
            slots: vec![SlotDef {
                name: "shared".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };
        let td2 = TransducerDef {
            name: "b".into(),
            slots: vec![SlotDef {
                name: "shared".into(), // conflict
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };
        let errors = validate_session(&[td1, td2]);
        assert!(
            errors
                .iter()
                .any(|e| matches!(e, LoadError::SlotConflict { .. }))
        );
    }

    #[test]
    fn disjoint_slots_pass() {
        let td1 = TransducerDef {
            name: "a".into(),
            slots: vec![SlotDef {
                name: "x".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };
        let td2 = TransducerDef {
            name: "b".into(),
            slots: vec![SlotDef {
                name: "y".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };
        let errors = validate_session(&[td1, td2]);
        assert!(errors.is_empty());
    }

    #[test]
    fn init_env_from_transducers() {
        let td1 = TransducerDef {
            name: "a".into(),
            slots: vec![SlotDef {
                name: "count".into(),
                initial: Value::Int(0),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };
        let td2 = TransducerDef {
            name: "b".into(),
            slots: vec![SlotDef {
                name: "messages".into(),
                initial: Value::List(vec![]),
            }],
            rules: vec![Rule {
                on: "Input".into(),
                guard: Expr::Lit {
                    value: Value::Bool(true),
                },
                updates: vec![],
                emits: vec![],
            }],
        };

        let env = init_env(&[td1, td2]);
        assert_eq!(env.get("count"), Some(&Value::Int(0)));
        assert_eq!(env.get("messages"), Some(&Value::List(vec![])));
    }
}
