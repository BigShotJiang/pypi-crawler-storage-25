import { useEffect } from 'preact/hooks'
import { signal } from '@preact/signals'
import { api } from '@/api'
import { useTitle } from '@/store/pageTitle'
import type { CalendarEvent } from '@/types'
import { CalendarSkeleton } from '@/components/Skeleton'
import { Button } from '@/components/Button'
import {
  CalendarEventDialog,
  openEventDialog,
  openEditEventDialog,
} from '@/components/CalendarEventDialog'
import { CalendarFilterStrip } from '@/components/CalendarFilterStrip'
import { CapacityStrip } from '@/components/CapacityStrip'
import { EventOverflowMenu } from '@/components/EventOverflowMenu'
import { LocationLink } from '@/components/LocationLink'
import { HostApprovalQueue } from '@/components/HostApprovalQueue'
import { ReminderPicker } from '@/components/ReminderPicker'
import { showToast } from '@/components/Toast'
import { currentUser } from '@/store/auth'
import { householdUsers, loadHouseholdUsers } from '@/store/householdUsers'
import { events, rsvpCounts, myRsvpStatus, activeCalendarScope } from '@/store/calendar'
import {
  advanceDate, calendarHue, dateRangeForMode, formatDayLabel,
  formatRangeHeading, groupEventsByDay, groupSharedEvents, resolveCalendarColor,
  type CalendarViewMode,
} from '@/utils/calendar'
import { t } from '@/i18n/i18n'
import { confirmDialog } from '@/components/confirm'

interface CalendarSummary {
  id: string
  name: string
  owner_username: string
  color?: string
}

/** localStorage key for "which calendars does this user want visible
 *  by default". Scoped per user_id so two members on the same browser
 *  (rare, but possible) don't trample each other. */
function visibilityKey(userId: string): string {
  return `sh-cal-visible:${userId}`
}

function loadVisibilityPrefs(userId: string): Set<string> | null {
  try {
    const raw = localStorage.getItem(visibilityKey(userId))
    if (!raw) return null
    const ids = JSON.parse(raw) as string[]
    if (!Array.isArray(ids)) return null
    return new Set(ids.filter(s => typeof s === 'string'))
  } catch {
    return null
  }
}

function saveVisibilityPrefs(userId: string, ids: Set<string>): void {
  try {
    localStorage.setItem(visibilityKey(userId), JSON.stringify(Array.from(ids)))
  } catch {
    // localStorage unavailable / full — silently degrade. The session
    // still works; defaults just re-apply on the next reload.
  }
}

const loading = signal(true)
const viewMode = signal<CalendarViewMode>('month')
/** Calendar id used as the "write target" — the calendar the +New-
 *  event dialog writes to. Always the caller's own calendar; doesn't
 *  change when they overlay another member's calendar. */
const writeCalendarId = signal<string>('')
/** Set of calendar ids currently overlaid in the view. Members can
 *  toggle each other's calendars on/off via the picker chips. */
const visibleCalendarIds = signal<Set<string>>(new Set())
const calendars = signal<CalendarSummary[]>([])
const currentDate = signal(new Date())
const selectedEvent = signal<CalendarEvent | null>(null)
const rsvpPending = signal<string | null>(null)

async function loadEvents() {
  const ids = Array.from(visibleCalendarIds.value)
  if (ids.length === 0) {
    events.value = []
    loading.value = false
    return
  }
  loading.value = true
  const { start, end } = dateRangeForMode(currentDate.value, viewMode.value)
  try {
    const responses = await Promise.all(ids.map(id =>
      api.get(`/api/calendars/${id}/events`, { start, end })
        .catch(() => [] as CalendarEvent[]) as Promise<CalendarEvent[]>,
    ))
    // Merge rows that the composer fanned out across multiple
    // calendars — same event, different rows. See
    // :func:`groupSharedEvents` for the group key and rationale.
    events.value = groupSharedEvents(responses.flat(), calendars.value)
  } catch {
    events.value = []
  }
  loading.value = false
}

function navigateDate(direction: number) {
  currentDate.value = advanceDate(currentDate.value, direction, viewMode.value)
}

/** Lazily ensure a default household calendar exists for the caller.
 *  A fresh user starts with zero personal calendars and the SPA has
 *  no "create calendar" surface — without this, the "+ New event"
 *  button would have nowhere to write. Returns the caller's calendar
 *  id, caches it in ``writeCalendarId``. */
async function ensureHouseholdCalendar(): Promise<string> {
  if (writeCalendarId.value) return writeCalendarId.value
  const cal = await api.post('/api/calendars', { name: 'Calendar' }) as
    CalendarSummary
  writeCalendarId.value = cal.id
  // Splice the freshly-created calendar into the picker list and the
  // visible set so the new event lands on screen immediately.
  if (!calendars.value.some(c => c.id === cal.id)) {
    calendars.value = [...calendars.value, cal]
  }
  const next = new Set(visibleCalendarIds.value)
  next.add(cal.id)
  visibleCalendarIds.value = next
  activeCalendarScope.value = next
  return cal.id
}

function showAllCalendars() {
  const next = new Set(calendars.value.map(c => c.id))
  visibleCalendarIds.value = next
  activeCalendarScope.value = next
  const uid = currentUser.value?.user_id
  if (uid) saveVisibilityPrefs(uid, next)
  void loadEvents()
}

function showOnlyMine() {
  const me = currentUser.value?.username
  const next = new Set(
    me
      ? calendars.value.filter(c => c.owner_username === me).map(c => c.id)
      : [],
  )
  if (next.size === 0 && calendars.value.length > 0) {
    next.add(calendars.value[0].id)
  }
  visibleCalendarIds.value = next
  activeCalendarScope.value = next
  const uid = currentUser.value?.user_id
  if (uid) saveVisibilityPrefs(uid, next)
  void loadEvents()
}

export default function CalendarPage() {
  useTitle('Calendar')
  useEffect(() => {
    // Drop any rows the WS handler accreted while we were on a
    // different surface — we'll re-fetch the right ones below.
    events.value = []
    void loadHouseholdUsers()
    api.get('/api/calendars', { scope: 'household' })
      .then(async (cals: CalendarSummary[]) => {
        calendars.value = cals
        if (cals.length === 0) {
          loading.value = false
          return
        }
        // Default visibility: the caller's own calendar(s) only.
        // Other members' calendars start hidden — the user opts in
        // by clicking their picker chip. Previously-saved preferences
        // (per-user, in localStorage) override the default so an
        // overlay choice survives reloads.
        const me = currentUser.value?.username
        const uid = currentUser.value?.user_id
        const myCals = me ? cals.filter(c => c.owner_username === me) : []
        const calIdSet = new Set(cals.map(c => c.id))
        const saved = uid ? loadVisibilityPrefs(uid) : null
        let initial: Set<string>
        if (saved) {
          // Filter out stale ids (calendars that disappeared since the
          // pref was saved). Fall back to defaults if filtering left
          // nothing.
          const kept = new Set([...saved].filter(id => calIdSet.has(id)))
          initial = kept.size > 0
            ? kept
            : new Set(myCals.length > 0 ? myCals.map(c => c.id) : [cals[0].id])
        } else {
          initial = new Set(
            myCals.length > 0 ? myCals.map(c => c.id) : [cals[0].id],
          )
        }
        // First own-calendar (alphabetical by name from the server)
        // is the write target for + New event.
        const writeTarget = myCals[0] ?? cals[0]
        writeCalendarId.value = writeTarget.id
        visibleCalendarIds.value = initial
        activeCalendarScope.value = initial
        await loadEvents()
        loading.value = false
      })
      .catch(() => { loading.value = false })
    return () => {
      // Stop accepting WS frames into the household ``events`` cache
      // once the user navigates away — without this, a per-space
      // calendar.* broadcast in the background would silently
      // re-pollute the cache between visits.
      activeCalendarScope.value = null
    }
  }, [])

  useEffect(() => {
    if (visibleCalendarIds.value.size > 0) {
      activeCalendarScope.value = visibleCalendarIds.value
      loadEvents()
    }
  }, [viewMode.value, currentDate.value])

  const handleNewEvent = async () => {
    try {
      const id = await ensureHouseholdCalendar()
      // Pass the full household-calendar list so the dialog can show
      // a "For:" selector and let the caller redirect the event onto
      // someone else's calendar (e.g. Maria can put a doctor's
      // appointment directly on Pascal's calendar).
      openEventDialog(id, calendars.value)
    } catch (e) {
      showToast(`Couldn't open new-event dialog: ${(e as Error).message}`, 'error')
    }
  }

  const handleRsvp = async (
    event: CalendarEvent,
    status: 'going' | 'maybe' | 'declined',
  ) => {
    const key = `${event.id}:${status}`
    rsvpPending.value = key
    try {
      // Phase A — RSVP lives at the event-level path (no calendar
      // segment); the server reads occurrence_at from the body for
      // recurring events.
      const body: Record<string, unknown> = { status }
      if (event.rrule) body.occurrence_at = event.start
      await api.post(`/api/calendars/events/${event.id}/rsvp`, body)
      // Optimistic local update — corrected by next WS frame.
      const isCapped = event.capacity != null
      const landing = isCapped && status === 'going' ? 'requested' : status
      myRsvpStatus.value = { ...myRsvpStatus.value, [event.id]: landing }
      showToast(t(`event.rsvp.${landing}_toast`), 'success')
    } catch (err) {
      const msg = (err as Error)?.message ?? t('event.rsvp.failed')
      showToast(msg, 'error')
    } finally {
      if (rsvpPending.value === key) rsvpPending.value = null
    }
  }

  const isEventEnded = (event: CalendarEvent): boolean => {
    const end = new Date(event.end).getTime()
    return end < Date.now()
  }

  const handleDelete = async (eventId: string) => {
    if (!await confirmDialog('Delete this event?', { destructive: true })) return
    try {
      await api.delete(`/api/calendars/events/${eventId}`)
      showToast('Event deleted', 'success')
      selectedEvent.value = null
      await loadEvents()
    } catch (err: unknown) {
      showToast(`Delete failed: ${(err as Error).message ?? err}`, 'error')
    }
  }

  const handleEdit = (evt: CalendarEvent) => {
    // Open the full event dialog in edit mode rather than the
    // single-field ``prompt()`` it used to be — every field becomes
    // editable, including attendees, the RSVP toggle, and the "For:"
    // target calendar (so an event can be moved between members'
    // calendars without delete-and-recreate).
    selectedEvent.value = null
    openEditEventDialog(
      {
        id: evt.id,
        calendar_id: evt.calendar_id,
        summary: evt.summary,
        description: evt.description,
        start: evt.start,
        end: evt.end,
        all_day: evt.all_day,
        attendees: evt.attendees,
        rsvp_enabled: evt.rsvp_enabled,
        location: evt.location,
      },
      calendars.value,
    )
  }

  if (loading.value) return <CalendarSkeleton />

  const grouped = groupEventsByDay(events.value)
  const dayKeys = Object.keys(grouped).sort((a, b) => new Date(a).getTime() - new Date(b).getTime())

  const setVisible = (next: Set<string>) => {
    visibleCalendarIds.value = next
    activeCalendarScope.value = next
    const uid = currentUser.value?.user_id
    if (uid) saveVisibilityPrefs(uid, next)
    void loadEvents()
  }

  return (
    <div class="sh-calendar">
      <CalendarFilterStrip
        calendars={calendars.value}
        visibleCalendarIds={visibleCalendarIds.value}
        onChange={setVisible}
        onShowAll={showAllCalendars}
        onShowOnlyMine={showOnlyMine}
        primaryAction={
          <Button onClick={handleNewEvent}>+ New event</Button>
        }
      />

      <div class="sh-calendar-controls">
        <div class="sh-calendar-nav">
          <Button variant="secondary"
                  aria-label={`Previous ${viewMode.value}`}
                  onClick={() => navigateDate(-1)}>&#8249;</Button>
          <span class="sh-calendar-heading">{formatRangeHeading(currentDate.value, viewMode.value)}</span>
          <Button variant="secondary"
                  aria-label={`Next ${viewMode.value}`}
                  onClick={() => navigateDate(1)}>&#8250;</Button>
          <Button variant="secondary" onClick={() => { currentDate.value = new Date() }}>Today</Button>
        </div>
        <div class="sh-calendar-views" role="tablist">
          {(['month', 'week', 'day'] as CalendarViewMode[]).map(mode => (
            <button
              key={mode}
              type="button"
              role="tab"
              aria-selected={viewMode.value === mode}
              class={viewMode.value === mode ? 'sh-tab sh-tab--active' : 'sh-tab'}
              onClick={() => { viewMode.value = mode }}
            >
              {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {events.value.length === 0 && (
        <div class="sh-empty-state">
          <div aria-hidden="true">📅</div>
          <h3>No events in this {viewMode.value}</h3>
          <p>
            Birthdays, school runs, vet visits, the trip you're planning —
            anything the household needs to keep track of.
          </p>
          <Button onClick={handleNewEvent}>
            + Create your first event
          </Button>
        </div>
      )}

      {dayKeys.map(dayKey => {
        const friendly = formatDayLabel(dayKey)
        return (
        <div key={dayKey} class="sh-calendar-day-group">
          <h3
            class={
              friendly.isToday
                ? 'sh-calendar-day-heading sh-calendar-day-heading--today'
                : 'sh-calendar-day-heading'
            }
          >
            {friendly.long}
            {friendly.relative && (
              <span class="sh-calendar-day-heading__rel">{friendly.relative}</span>
            )}
          </h3>
          {grouped[dayKey].map(e => {
            // Owner byline / chips. Single attendee → one "You" /
            // "Bob" chip (the legacy shape). Multiple attendees (the
            // composer fanned the event out across N calendars) →
            // one chip per owner, so a household dinner reads as one
            // row with "YOU · BOB" instead of two stacked rows. Only
            // surfaced when the multi-calendar overlay is on; with
            // a single calendar visible the byline is redundant.
            // Each chip carries its OWN calendar's hue so a shared
            // event reads as ``YOU (terracotta) · BOB (moss)`` rather
            // than two same-coloured pills. Without the per-chip
            // colour, all chips inherited ``--cal-hue`` from the
            // primary row (the creator's calendar) and the "shared
            // with" signal was visually flat.
            const groupedCalIds = e._grouped_calendar_ids ?? [e.calendar_id]
            const ownerChips: { name: string; color: string }[] = []
            if (visibleCalendarIds.value.size > 1) {
              const me = currentUser.value?.username
              const seen = new Set<string>()
              for (const calId of groupedCalIds) {
                const cal = calendars.value.find(c => c.id === calId)
                if (!cal) continue
                if (seen.has(cal.owner_username)) continue
                seen.add(cal.owner_username)
                const color = resolveCalendarColor(cal)
                if (cal.owner_username === me) {
                  ownerChips.push({ name: 'You', color })
                  continue
                }
                let name: string = cal.owner_username
                for (const u of householdUsers.value.values()) {
                  if (u.username === cal.owner_username) {
                    name = u.display_name || u.username
                    break
                  }
                }
                ownerChips.push({ name, color })
              }
            }
            return (
            <div key={e.id} class="sh-event"
                 style={{ '--cal-hue': (() => {
                   const cal = calendars.value.find(c => c.id === e.calendar_id)
                   return cal ? resolveCalendarColor(cal) : calendarHue(e.calendar_id)
                 })() } as Record<string, string>}
                 onClick={() => { selectedEvent.value = selectedEvent.value?.id === e.id ? null : e }}>
              <div class="sh-event-header">
                {e.cover_url && (
                  <img
                    class="sh-event-cover-thumb"
                    src={e.cover_url}
                    alt=""
                    loading="lazy"
                  />
                )}
                <strong>{e.summary}</strong>
                {ownerChips.length > 0 && (
                  <span
                    class="sh-event-owner-chips"
                    aria-label={
                      ownerChips.length === 1
                        ? `On ${ownerChips[0].name}'s calendar`
                        : `Shared with ${ownerChips.map(c => c.name).join(', ')}`
                    }
                  >
                    {ownerChips.map(chip => (
                      <span
                        key={chip.name}
                        class="sh-event-owner"
                        style={{ '--cal-hue': chip.color } as Record<string, string>}
                      >
                        {chip.name}
                      </span>
                    ))}
                  </span>
                )}
                <time>{new Date(e.start).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}</time>
                {e.all_day && <span class="sh-badge">All day</span>}
                {e.location && (
                  // Compact "where" hint on the collapsed row. The full
                  // location + maps link only renders inside the expanded
                  // detail to keep the row visually quiet.
                  <span
                    class="sh-event-row-locpin"
                    aria-label={`Location: ${e.location}`}
                    title={e.location}
                  >
                    📍
                  </span>
                )}
              </div>
              {selectedEvent.value?.id === e.id && (() => {
                // RSVP visibility: only when explicitly enabled
                // (``rsvp_enabled``) OR when there's a capacity cap
                // (the legacy Phase C signal that an event needs
                // confirmation). And even then, hide the buttons for
                // the creator viewing their own one-attendee event —
                // there's nobody to ask.
                const myUid = currentUser.value?.user_id
                const others = (e.attendees ?? []).filter(uid => uid !== myUid)
                const hasOthers = others.length > 0
                const isCapped = e.capacity != null
                const showRsvp = (e.rsvp_enabled || isCapped)
                  && hasOthers
                  && (e.attendees ?? []).includes(myUid ?? '__none__')
                return (
                <div class="sh-event-detail">
                  {e.location && (
                    <p class="sh-event-location-row">
                      <LocationLink
                        value={e.location}
                        className="sh-event-location"
                      />
                    </p>
                  )}
                  {e.description && <p>{e.description}</p>}
                  <div class="sh-event-times">
                    <span>{t('event.starts')} {new Date(e.start).toLocaleString()}</span>
                    <span>{t('event.ends')} {new Date(e.end).toLocaleString()}</span>
                  </div>

                  {showRsvp && (
                    <CapacityStrip
                      counts={rsvpCounts.value[e.id]}
                      capacity={e.capacity}
                      myStatus={
                        (myRsvpStatus.value[e.id] ?? null) as
                          | 'going' | 'maybe' | 'declined' | 'requested' | 'waitlist' | null
                      }
                    />
                  )}

                  {showRsvp && (
                    <div class="sh-event-rsvp" role="group" aria-label={t('event.rsvp.aria')}>
                      {(['going', 'maybe', 'declined'] as const).map((status) => {
                        const ended = isEventEnded(e)
                        const labelKey = isCapped && status === 'going'
                          ? 'event.rsvp.request_to_join'
                          : `event.rsvp.${status}`
                        const ariaTip = ended ? t('event.has_ended_tooltip') : ''
                        return (
                          <Button
                            key={status}
                            variant={status === 'going' ? 'primary' : 'secondary'}
                            loading={rsvpPending.value === `${e.id}:${status}`}
                            disabled={ended}
                            title={ariaTip || undefined}
                            onClick={() => handleRsvp(e, status)}
                          >
                            {t(labelKey)}
                          </Button>
                        )
                      })}
                    </div>
                  )}

                  <ReminderPicker
                    eventId={e.id}
                    occurrenceAt={e.rrule ? e.start : null}
                  />

                  {e.capacity != null && (
                    e.created_by === currentUser.value?.user_id
                      || currentUser.value?.is_admin
                  ) && (
                    <HostApprovalQueue
                      eventId={e.id}
                      spaceId={null}
                      occurrenceAt={e.rrule ? e.start : null}
                    />
                  )}

                  <div class="sh-event-admin sh-row">
                    <Button variant="secondary" onClick={() => handleEdit(e)}>
                      {t('event.edit')}
                    </Button>
                    <Button variant="danger" onClick={() => handleDelete(e.id)}>
                      {t('event.delete')}
                    </Button>
                    <EventOverflowMenu eventId={e.id} />
                  </div>
                </div>
                )
              })()}
            </div>
          )})}
        </div>
        )
      })}

      <CalendarEventDialog onCreated={(targetId) => {
        // If the user created the event on a calendar that isn't
        // currently overlaid (typically: "For: Pascal" while only
        // Maria's chip was on), auto-toggle that calendar visible so
        // the new event lands on screen instead of seemingly
        // disappearing.
        if (targetId && !visibleCalendarIds.value.has(targetId)) {
          const next = new Set(visibleCalendarIds.value)
          next.add(targetId)
          visibleCalendarIds.value = next
          activeCalendarScope.value = next
        }
        void loadEvents()
      }} />
    </div>
  )
}
