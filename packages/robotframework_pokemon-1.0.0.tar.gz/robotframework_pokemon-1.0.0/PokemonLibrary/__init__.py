"""Pokemon Robot Framework Library — RF wrapper around pytemon."""

from .library import PokemonLibrary

__version__ = "0.1.0"
__all__ = ["PokemonLibrary"]
