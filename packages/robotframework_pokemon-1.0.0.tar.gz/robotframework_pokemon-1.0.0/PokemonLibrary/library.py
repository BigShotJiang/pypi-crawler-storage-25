"""
Pokemon Robot Framework Library

This RF library wraps the pytemon Python package and exposes
keywords for launching and inspecting the interactive Pokemon terminal.
"""

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from robot.api import logger
from robot.api.deco import keyword
from robotlibcore import DynamicCore

from pytemon.data.move_data import MOVES, get_move
from pytemon.data.pokemon_data import POKEMON, get_pokemon
from pytemon.data.trainer_data import get_trainer, get_trainers_by_location
from pytemon.data.type_chart import TYPE_CHART
from pytemon.gym_system import get_badge_data, get_gym_trainers as _get_gym_trainers
from pytemon.terminal import PokemonTerminal


class PokemonLibrary(DynamicCore):
    """
    Robot Framework library for Pokemon with an interactive terminal.

    = Table of contents =

    - `Importing`
    - `Keywords`

    = Importing =

    The library can be imported directly:

    | Library | PokemonLibrary |

    = Keywords =

    The library provides keywords for interactive terminal management.
    """

    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    ROBOT_LIBRARY_VERSION = "0.1.0"

    def __init__(self):
        """Initialize the Pokemon library."""
        DynamicCore.__init__(self, [])
        self.terminal_app = None
        # project_root is the rf-pytemon directory; saves live in saves/ next to it
        self.project_root = Path(__file__).parent.parent
        self._lock_file_path = None
        self._command_file_path = None
        self._text_file_path = None
        logger.info("PokemonLibrary (rf-pytemon) initialized")

    def _find_terminal_emulator(self):
        """
        Find an available terminal emulator on the system.

        Returns:
            tuple: (command_name, command_args_template) or (None, None) if not found
        """
        terminals = [
            ("gnome-terminal", ["--maximize", "--zoom=0.8", "--", "bash", "-c", "{cmd}"]),
            ("konsole", ["--geometry", "1760x900", "-e", "bash", "-c", "{cmd}"]),
            ("xfce4-terminal", ["--geometry=220x50", "-e", 'bash -c "{cmd}"']),
            ("mate-terminal", ["--maximize", "--zoom=0.8", "--", "bash", "-c", "{cmd}"]),
            ("xterm", ["-geometry", "220x50", "-e", "bash", "-c", "{cmd}"]),
            ("x-terminal-emulator", ["-e", "bash", "-c", "{cmd}"]),
            ("terminator", ["-e", 'bash -c "{cmd}"']),
            ("tilix", ["-e", 'bash -c "{cmd}"']),
        ]

        for cmd, args in terminals:
            if shutil.which(cmd):
                return cmd, args

        return None, None

    def _launch_in_new_window(self):
        """
        Launch the terminal in a new window.

        Returns:
            bool: True if successfully launched, False otherwise
        """
        terminal_cmd, terminal_args = self._find_terminal_emulator()

        if not terminal_cmd:
            logger.warn(
                "No terminal emulator found. Available terminal emulators: "
                + "gnome-terminal, konsole, xfce4-terminal, xterm, etc.",
                html=True,
            )
            return False

        logger.info(f"Using terminal emulator: {terminal_cmd}", html=True)

        # Create a lock file that will be deleted when the game exits
        lock_file = tempfile.NamedTemporaryFile(
            mode="w", prefix="pokemon_", suffix=".lock", delete=False
        )
        lock_file_path = lock_file.name
        lock_file.write("running")
        lock_file.close()

        # Create a command file for injecting commands into the running game
        cmd_file = tempfile.NamedTemporaryFile(
            mode="w", prefix="pokemon_cmd_", suffix=".txt", delete=False
        )
        command_file_path = cmd_file.name
        cmd_file.close()

        # Create a text file for injecting styled display text into the running game
        txt_file = tempfile.NamedTemporaryFile(
            mode="w", prefix="pokemon_txt_", suffix=".txt", delete=False
        )
        text_file_path = txt_file.name
        txt_file.close()

        logger.info(f"Created lock file: {lock_file_path}", html=True)
        logger.info(f"Created command file: {command_file_path}", html=True)
        logger.info(f"Created text file: {text_file_path}", html=True)

        # Build the command to run in the new terminal
        python_bin = sys.executable
        game_cmd = (
            f"cd '{self.project_root}' && "
            f"'{python_bin}' -c '"
            f"from pytemon.terminal import launch_terminal; "
            f"launch_terminal("
            f"lock_file=\"{lock_file_path}\", "
            f"command_file=\"{command_file_path}\", "
            f"text_file=\"{text_file_path}\""
            f")'; "
            f"echo ''; echo 'Press Enter to close...'; read"
        )

        # Replace {cmd} placeholder in terminal args
        final_args = []
        if terminal_args:
            final_args = [
                arg.format(cmd=game_cmd) if "{cmd}" in arg else arg for arg in terminal_args
            ]

        try:
            # Launch the new terminal window (non-blocking)
            subprocess.Popen([terminal_cmd] + final_args)
            logger.info("✅ Pokemon Terminal launched in new window!", html=True)
            logger.info("Terminal is running in the background - test will continue", html=True)

            # Store file paths for later use
            self._lock_file_path = lock_file_path
            self._command_file_path = command_file_path
            self._text_file_path = text_file_path

            # Return immediately - don't wait for the terminal to close
            return True
        except Exception as e:
            logger.error(f"Failed to launch terminal: {e}")
            # Clean up temp files on error
            for path in (lock_file_path, command_file_path, text_file_path):
                try:
                    Path(path).unlink()
                except Exception:
                    pass
            return False

    @keyword("Start Interactive Terminal")
    def start_interactive_terminal(self, new_window: Union[bool, str] = True):
        """
        Start the interactive Pokemon terminal using Textual.

        By default, launches in a new terminal window for the best experience.
        Set new_window=False to run in the current terminal.

        Arguments:
        - ``new_window``: If True (default), opens in a new terminal window.
                         If False, runs in the current terminal.

        Examples:
        | Start Interactive Terminal |                    # Opens in new window
        | Start Interactive Terminal | new_window=${True} # Opens in new window
        | Start Interactive Terminal | new_window=${False} # Runs in current terminal
        """
        logger.info("🎮 Starting interactive terminal...", html=True)

        # Convert string "True"/"False" to boolean if needed
        if isinstance(new_window, str):
            new_window = new_window.lower() in ("true", "yes", "1")

        try:
            if new_window:
                success = self._launch_in_new_window()
                if success:
                    logger.info("Game is running in a separate terminal window", html=True)
                    return
                else:
                    logger.warn(
                        "Could not open new window, running in current terminal instead", html=True
                    )

            # Fallback: run in current terminal
            logger.info("Running terminal in current window...", html=True)
            self.terminal_app = PokemonTerminal()
            self.terminal_app.run()
            logger.info("✅ Terminal closed", html=True)
        except Exception as e:
            logger.error(f"Failed to start terminal: {e}")
            raise

    @keyword("Send Command")
    def send_command(self, command: str):
        """
        Send a command to the interactive terminal.

        Arguments:
        - ``command``: The command to send

        Example:
        | Send Command | help |
        | Send Command | status |
        """
        if not self._command_file_path:
            raise RuntimeError(
                "No command file available. "
                "Start the terminal with 'Start Interactive Terminal' first."
            )
        logger.info(f"Sending command: {command}")
        Path(self._command_file_path).write_text(command)

    @keyword("Send Text")
    def send_text(self, *lines: str):
        """
        Send styled Rich-markup text directly to the terminal output.

        Accepts one or more lines. Empty strings produce blank lines.
        Rich markup tags (e.g. ``[bold red]...[/bold red]``) are rendered.

        Arguments:
        - ``*lines``: One or more text lines to display.

        Example:
        | Send Text | [bold green]All done![/bold green] |
        | @{msg}=   | Create List | ${EMPTY} | [bold red]══════[/bold red] | Finished! | [bold red]══════[/bold red] |
        | Send Text | @{msg} |
        """
        if not self._text_file_path:
            raise RuntimeError(
                "No text file available. "
                "Start the terminal with 'Start Interactive Terminal' first."
            )
        content = "\n".join(lines)
        logger.info(f"Sending text ({len(lines)} line(s))")
        with Path(self._text_file_path).open("a", encoding="utf-8") as fh:
            fh.write(content + "\n")

    def _load_save(self, save_name: Optional[str] = None) -> dict:
        """
        Load a save file from the saves directory.

        Args:
            save_name: Optional save file name (without .json). If None, loads
                       the most recently modified save file.

        Returns:
            The parsed save data dict.

        Raises:
            FileNotFoundError: When no save files exist or the named save
                               cannot be found.
        """
        saves_dir = self.project_root / "saves"
        if not saves_dir.exists():
            raise FileNotFoundError("No saves directory found. Start a game first!")

        if save_name:
            path = saves_dir / f"{save_name}.json"
            if not path.exists():
                path = saves_dir / save_name  # exact filename fallback
            if not path.exists():
                raise FileNotFoundError(f"Save file '{save_name}' not found in {saves_dir}")
        else:
            candidates = sorted(
                saves_dir.glob("*.json"),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )
            if not candidates:
                raise FileNotFoundError("No save files found. Start a game first!")
            path = candidates[0]

        logger.info(f"Loading save: {path}", html=True)
        return json.loads(path.read_text(encoding="utf-8"))

    @keyword("Get Save Game Stats")
    def get_save_game_stats(self, save_name: Optional[str] = None) -> str:
        """
        Return a formatted summary of statistics from a save file.

        Arguments:
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | ${stats}= | Get Save Game Stats |                |
        | ${stats}= | Get Save Game Stats | save_name=mark |
        """
        data = self._load_save(save_name)

        trainer = data.get("player_name", "Unknown")
        location = data.get("location", "Unknown")
        money = data.get("money", 0)
        badges_raw = data.get("badges", 0)
        badges = len(badges_raw) if isinstance(badges_raw, list) else int(badges_raw)
        party = [p for p in data.get("pokemon", []) if isinstance(p, dict)]
        items = data.get("items", {})
        pikachu = data.get("pikachu_mode", False)
        rival = data.get("rival_pokemon", [])
        defeated = data.get("defeated_trainers", [])

        lines = [
            "=" * 46,
            f"  TRAINER CARD: {trainer}",
            "=" * 46,
            f"  Location      : {location}",
            f"  Badges        : {'*' * badges if badges else 'none'} ({badges})",
            f"  Money         : ${money:,}",
            f"  Pikachu mode  : {'ON (Easter egg unlocked!)' if pikachu else 'off'}",
            "",
            f"  POKEMON PARTY ({len(party)}/6)",
            "  " + "-" * 42,
        ]

        for i, p in enumerate(party, 1):
            hp = p.get("hp", 0)
            max_hp = max(p.get("max_hp", 1), 1)
            status = p.get("status") or "OK"
            filled = int((hp / max_hp) * 10)
            bar = "\u2588" * filled + "\u2591" * (10 - filled)
            hp_pct = int(hp / max_hp * 100)
            moves = ", ".join(m["name"] for m in p.get("moves", []))
            lines += [
                f"  {i}. {p['name']:<12} Lv.{p.get('level', '?'):<3}"
                f" [{bar}] {hp}/{max_hp} HP ({hp_pct}%) [{status}]",
                f"     Moves: {moves}",
            ]

        total_items = sum(items.values())
        lines += [
            "",
            f"  BAG ({total_items} item(s))",
            "  " + "-" * 42,
        ]
        if items:
            for item, qty in items.items():
                lines.append(f"  {item:<20} x{qty}")
        else:
            lines.append("  (empty)")

        if rival:
            lines += ["", f"  RIVAL'S TEAM  : {', '.join(rival)}"]
        if defeated:
            lines.append(f"  Trainers beaten: {len(defeated)}")

        lines.append("=" * 46)
        result = "\n".join(lines)
        logger.info(result, html=False)
        return result

    @keyword("Rate My Trainer Skills")
    def rate_my_trainer_skills(self, save_name: Optional[str] = None) -> str:
        """
        Analyse a save file and rate how well the trainer is doing.

        The score (0-100) is built from six factors:

        | Factor             | Max pts | How to improve                        |
        | Party strength     | 40      | Level up your Pokemon                 |
        | Gym progress       | 20      | Beat more Gym Leaders                 |
        | Wealth             | 15      | Win trainer battles, sell items       |
        | Preparedness       | 10      | Stock up on Potions at the Mart       |
        | Party health       | 10      | Visit the Pokemon Center regularly    |
        | Team diversity     | 5       | Catch different species               |

        Arguments:
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | ${rating}= | Rate My Trainer Skills |                |
        | ${rating}= | Rate My Trainer Skills | save_name=mark |
        """
        data = self._load_save(save_name)

        party = [p for p in data.get("pokemon", []) if isinstance(p, dict)]
        badges_raw = data.get("badges", 0)
        badges = len(badges_raw) if isinstance(badges_raw, list) else int(badges_raw)
        money = data.get("money", 0)
        items = data.get("items", {})

        # Party strength (0-40) — linear from level 0 to 50
        avg_level = sum(p.get("level", 1) for p in party) / len(party) if party else 0
        level_score = min(40, int(avg_level / 50 * 40))

        # Badge score (0-20)
        badge_score = min(20, badges * 3)

        # Wealth score (0-15) — $5 000 = full marks
        wealth_score = min(15, int(money / 5000 * 15))

        # Preparedness score (0-10) — 5 heals = full marks
        healing = ["Potion", "Super Potion", "Hyper Potion", "Max Potion", "Full Restore"]
        total_heals = sum(items.get(h, 0) for h in healing)
        prep_score = min(10, total_heals * 2)

        # Party health score (0-10) — avg HP %
        avg_hp_pct = (
            sum(p.get("hp", 0) / max(p.get("max_hp", 1), 1) for p in party) / len(party)
            if party
            else 0
        )
        health_score = int(avg_hp_pct * 10)

        # Team diversity score (0-5) — unique species
        unique_names = len({p["name"] for p in party})
        diversity_score = min(5, unique_names)

        total = (
            level_score + badge_score + wealth_score + prep_score + health_score + diversity_score
        )

        if total >= 85:
            grade, verdict = "S", "Pokemon Master material! \U0001f3c6"
        elif total >= 70:
            grade, verdict = "A", "Rising trainer — keep it up!"
        elif total >= 50:
            grade, verdict = "B", "Decent effort, but there's room to grow."
        elif total >= 30:
            grade, verdict = "C", "Could try harder. Hit the routes!"
        elif total >= 10:
            grade, verdict = "D", "Struggling... maybe talk to Professor Oak again."
        else:
            grade, verdict = "F", "Did you even start the game? \U0001f914"

        trainer = data.get("player_name", "Trainer")
        lines = [
            "=" * 46,
            f"  TRAINER SKILL RATING: {trainer}",
            "=" * 46,
            f"  Party strength   (avg Lv. {avg_level:.1f})    : {level_score:>2} / 40",
            f"  Gym progress     ({badges} badge(s))          : {badge_score:>2} / 20",
            f"  Wealth           (${money:,})             : {wealth_score:>2} / 15",
            f"  Preparedness     ({total_heals} heal item(s))      : {prep_score:>2} / 10",
            f"  Party health     ({int(avg_hp_pct * 100)}% avg HP)          : {health_score:>2} / 10",
            f"  Team diversity   ({unique_names} unique species)   : {diversity_score:>2} /  5",
            "  " + "-" * 42,
            f"  TOTAL SCORE                            : {total:>2} / 100",
            f"  GRADE                                  :  {grade}",
            "",
            f"  {verdict}",
            "=" * 46,
        ]
        result = "\n".join(lines)
        logger.info(result, html=False)
        return result

    # ──────────────────────────────────────────────────────────────
    # Save-file inspection keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Get Available Save Names")
    def get_available_save_names(self) -> List[str]:
        """
        Return a list of available save file names (without the ``.json`` extension).

        Examples:
        | @{saves}= | Get Available Save Names |
        | Log       | ${saves}                 |
        """
        saves_dir = self.project_root / "saves"
        if not saves_dir.exists():
            return []
        names = [p.stem for p in sorted(saves_dir.glob("*.json"))]
        logger.info(f"Available saves: {names}")
        return names

    @keyword("Get PC Pokemon Count")
    def get_pc_pokemon_count(self, save_name: Optional[str] = None) -> int:
        """
        Return the total number of Pokemon stored in Bill's PC boxes.

        Arguments:
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | ${count}= | Get PC Pokemon Count |                |
        | ${count}= | Get PC Pokemon Count | save_name=mark |
        """
        data = self._load_save(save_name)
        pc = data.get("pc_storage", {})
        count = sum(1 for slots in pc.values() for slot in slots if slot is not None)
        logger.info(f"Pokemon in PC: {count}")
        return count

    # ──────────────────────────────────────────────────────────────
    # Pokédex keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Get Pokedex Stats")
    def get_pokedex_stats(self, save_name: Optional[str] = None) -> Dict[str, int]:
        """
        Return Pokédex statistics from a save file as a dictionary.

        Keys: ``seen``, ``caught``, ``total``, ``seen_percent``, ``caught_percent``.

        Arguments:
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | &{dex}=   | Get Pokedex Stats |                |
        | Log       | Caught: ${dex.caught} / ${dex.total} |
        | &{dex}=   | Get Pokedex Stats | save_name=mark |
        """
        data = self._load_save(save_name)
        pokedex = data.get("pokedex", {})
        seen = pokedex.get("seen", [])
        caught = pokedex.get("caught", [])
        total = len(POKEMON)
        stats: Dict[str, int] = {
            "seen": len(seen),
            "caught": len(caught),
            "total": total,
            "seen_percent": int(len(seen) / total * 100) if total > 0 else 0,
            "caught_percent": int(len(caught) / total * 100) if total > 0 else 0,
        }
        logger.info(
            f"Pokédex — seen: {stats['seen']}/{total}, caught: {stats['caught']}/{total}"
        )
        return stats

    @keyword("Pokemon Should Be Seen")
    def pokemon_should_be_seen(self, species: str, save_name: Optional[str] = None) -> None:
        """
        Fail if the given Pokémon species has *not* been seen in the Pokédex.

        Species names are case-insensitive (e.g. ``pikachu`` or ``PIKACHU``).

        Arguments:
        - ``species``: Pokémon species name.
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | Pokemon Should Be Seen | Pikachu             |
        | Pokemon Should Be Seen | CHARMANDER | mark   |
        """
        data = self._load_save(save_name)
        seen = data.get("pokedex", {}).get("seen", [])
        if species.upper() not in [s.upper() for s in seen]:
            raise AssertionError(
                f"Expected '{species}' to be seen in the Pokédex, but it was not."
            )
        logger.info(f"✅ {species} is registered as seen in the Pokédex.")

    @keyword("Pokemon Should Be Caught")
    def pokemon_should_be_caught(self, species: str, save_name: Optional[str] = None) -> None:
        """
        Fail if the given Pokémon species has *not* been caught.

        Species names are case-insensitive.

        Arguments:
        - ``species``: Pokémon species name.
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | Pokemon Should Be Caught | Pikachu           |
        | Pokemon Should Be Caught | BULBASAUR | mark  |
        """
        data = self._load_save(save_name)
        caught = data.get("pokedex", {}).get("caught", [])
        if species.upper() not in [s.upper() for s in caught]:
            raise AssertionError(
                f"Expected '{species}' to be caught, but it is not in the Pokédex."
            )
        logger.info(f"✅ {species} is registered as caught in the Pokédex.")

    # ──────────────────────────────────────────────────────────────
    # Gym / Badge keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Trainer Has Badge")
    def trainer_has_badge(self, badge_name: str, save_name: Optional[str] = None) -> bool:
        """
        Return ``True`` if the trainer has earned the named badge, ``False`` otherwise.

        Badge names (case-insensitive examples): ``Boulder Badge``, ``Cascade Badge``,
        ``Thunder Badge``, ``Rainbow Badge``, ``Soul Badge``, ``Marsh Badge``,
        ``Volcano Badge``, ``Earth Badge``.

        Arguments:
        - ``badge_name``: Display name of the badge.
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | ${has}=  | Trainer Has Badge | Boulder Badge          |
        | ${has}=  | Trainer Has Badge | Cascade Badge | mark   |
        | Should Be True | ${has} |
        """
        data = self._load_save(save_name)
        badges: Any = data.get("badges", [])
        if not isinstance(badges, list):
            badges = []
        badge_data = get_badge_data(badge_name)
        if not badge_data:
            logger.warn(f"Unknown badge name: '{badge_name}'")
            return False
        result = badge_data["id"] in badges
        logger.info(
            f"Badge '{badge_name}': {'✅ earned' if result else '❌ not yet earned'}"
        )
        return result

    @keyword("Get Badge Count")
    def get_badge_count(self, save_name: Optional[str] = None) -> int:
        """
        Return the number of Gym badges the trainer has earned.

        Arguments:
        - ``save_name``: Name of save file to inspect (optional).

        Examples:
        | ${count}= | Get Badge Count |                |
        | ${count}= | Get Badge Count | save_name=mark |
        | Should Be Equal As Integers | ${count} | 3  |
        """
        data = self._load_save(save_name)
        badges = data.get("badges", [])
        count = len(badges) if isinstance(badges, list) else 0
        logger.info(f"Badge count: {count}")
        return count

    @keyword("Get Gym Trainers")
    def get_gym_trainers(self, location: str) -> List[str]:
        """
        Return the ordered list of gym trainer IDs for a location.

        Arguments:
        - ``location``: Location name (e.g. ``Pewter City``).

        Examples:
        | @{trainers}= | Get Gym Trainers | Pewter City     |
        | @{trainers}= | Get Gym Trainers | Cerulean City   |
        """
        trainers = _get_gym_trainers(location)
        logger.info(f"Gym trainers at '{location}': {trainers}")
        return trainers

    # ──────────────────────────────────────────────────────────────
    # Static Pokémon data lookup keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Get Pokemon Species Data")
    def get_pokemon_species_data(self, name_or_number: str) -> str:
        """
        Return a formatted summary of a Pokémon species from the static game data.

        Accepts either the species name (e.g. ``Pikachu``) or the National Dex
        number as a string (e.g. ``25``).

        Arguments:
        - ``name_or_number``: Species name or Pokédex number.

        Examples:
        | ${info}= | Get Pokemon Species Data | Pikachu |
        | ${info}= | Get Pokemon Species Data | 25      |
        | Log      | ${info}                  |
        """
        # Allow number strings
        key: Any = name_or_number
        try:
            key = int(name_or_number)
        except (ValueError, TypeError):
            pass

        species = get_pokemon(key)
        if not species:
            raise ValueError(f"No Pokémon data found for '{name_or_number}'")

        stats = species.stats
        evo = species.evolution
        if evo is None:
            evo_str = "Does not evolve"
        elif isinstance(evo, list):
            evo_str = " / ".join(
                f"{b.get('into', '?')} (with {b.get('item', '?')})" for b in evo
            )
        else:
            if hasattr(evo, "level") and evo.get("level"):
                evo_str = f"Evolves into {evo.get('into')} at Lv.{evo.get('level')}"
            else:
                evo_str = f"Evolves into {evo.get('into')} (with {evo.get('item', '?')})"

        lines = [
            "=" * 46,
            f"  #{species.number:03d}  {species.name}",
            "=" * 46,
            f"  Type(s)        : {' / '.join(species.types)}",
            f"  Catch rate     : {species.catch_rate}",
            f"  Base EXP yield : {species.base_exp}",
            "",
            "  BASE STATS",
            f"    HP      : {stats.hp}",
            f"    Attack  : {stats.attack}",
            f"    Defense : {stats.defense}",
            f"    Special : {stats.special}",
            f"    Speed   : {stats.speed}",
            f"    Total   : {stats.hp + stats.attack + stats.defense + stats.special + stats.speed}",
            "",
            f"  Evolution      : {evo_str}",
            "=" * 46,
        ]
        result = "\n".join(lines)
        logger.info(result)
        return result

    @keyword("Get Move Info")
    def get_move_info(self, move_name: str) -> str:
        """
        Return a formatted summary of a move from the static game data.

        Move names are case-insensitive (e.g. ``Thunderbolt`` or ``THUNDERBOLT``).

        Arguments:
        - ``move_name``: Name of the move.

        Examples:
        | ${info}= | Get Move Info | Thunderbolt |
        | ${info}= | Get Move Info | SURF        |
        | Log      | ${info}       |
        """
        move = get_move(move_name.upper())
        if not move:
            raise ValueError(f"No move data found for '{move_name}'")

        effect_str = (
            f"{move.effect} ({move.effect_chance}% chance)" if move.effect else "None"
        )
        lines = [
            "=" * 46,
            f"  Move: {move.name}",
            "=" * 46,
            f"  Type     : {move.type}",
            f"  Category : {move.category}",
            f"  Power    : {move.power if move.power else '—'}",
            f"  Accuracy : {move.accuracy if move.accuracy else 'Always hits'}",
            f"  PP       : {move.pp}",
            f"  Effect   : {effect_str}",
            "=" * 46,
        ]
        result = "\n".join(lines)
        logger.info(result)
        return result

    @keyword("Get Trainer Info")
    def get_trainer_info(self, trainer_id: str) -> str:
        """
        Return a formatted summary of an NPC trainer from the static game data.

        Arguments:
        - ``trainer_id``: The trainer's internal ID (e.g. ``gym_leader_brock``,
          ``elite_lance``, ``youngster_ben``).

        Examples:
        | ${info}= | Get Trainer Info | gym_leader_brock   |
        | ${info}= | Get Trainer Info | elite_lance        |
        | Log      | ${info}          |
        """
        trainer = get_trainer(trainer_id)
        if not trainer:
            raise ValueError(f"No trainer data found for ID '{trainer_id}'")

        lines = [
            "=" * 46,
            f"  {trainer.trainer_class} {trainer.name}",
            "=" * 46,
            f"  ID       : {trainer.id}",
            f"  Location : {trainer.location}",
            f"  Prize $  : {trainer.prize_money}",
            "",
            f"  POKEMON ({len(trainer.pokemon)})",
        ]
        for p in trainer.pokemon:
            lines.append(f"    - {p.get('species', p.get('name', '?'))} Lv.{p.get('level', '?')}")
        if getattr(trainer, "badge_reward", None):
            lines.append("")
            lines.append(f"  Badge reward : {trainer.badge_reward}")
        lines.append("=" * 46)
        result = "\n".join(lines)
        logger.info(result)
        return result

    @keyword("Get Trainers By Location")
    def get_trainers_by_location(self, location: str) -> List[str]:
        """
        Return a list of trainer IDs located at the given area.

        Arguments:
        - ``location``: Location name (e.g. ``Pewter City``, ``Route 3``).

        Examples:
        | @{ids}=  | Get Trainers By Location | Pewter City |
        | @{ids}=  | Get Trainers By Location | Route 3     |
        | Log      | ${ids}                   |
        """
        trainers = get_trainers_by_location(location)
        ids = [t.id for t in trainers]
        logger.info(f"Trainers at '{location}': {ids}")
        return ids

    # ──────────────────────────────────────────────────────────────
    # Evolution lookup keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Get Level Evolution")
    def get_level_evolution(self, species_name: str) -> Optional[str]:
        """
        Return the name of the species that ``species_name`` evolves into via
        levelling up, or ``None`` if it does not have a level-based evolution.

        Arguments:
        - ``species_name``: Species name (e.g. ``Charmander``).

        Examples:
        | ${into}= | Get Level Evolution | Charmander  |
        | Should Be Equal | ${into} | CHARMELEON  |
        | ${into}= | Get Level Evolution | Raichu      |
        | Should Be Equal | ${into} | ${None}     |
        """
        key = species_name.upper()
        # Find species by name
        species = next(
            (s for s in POKEMON.values() if s.name.upper() == key), None
        )
        if not species:
            raise ValueError(f"Unknown species: '{species_name}'")
        evo = species.evolution
        if evo is None or isinstance(evo, list):
            result = None
        elif hasattr(evo, "level") and evo.get("level") is not None:
            result = evo.get("into")
        else:
            result = None
        logger.info(f"{species_name} level evolution → {result}")
        return result

    @keyword("Get Stone Evolution")
    def get_stone_evolution(self, species_name: str, stone: str) -> Optional[str]:
        """
        Return the name of the species that ``species_name`` evolves into using
        ``stone``, or ``None`` if no such evolution exists.

        Arguments:
        - ``species_name``: Species name (e.g. ``Pikachu``).
        - ``stone``: Item name (e.g. ``Thunder Stone``, ``Fire Stone``).

        Examples:
        | ${into}= | Get Stone Evolution | Pikachu  | Thunder Stone |
        | Should Be Equal | ${into} | RAICHU         |
        | ${into}= | Get Stone Evolution | Eevee    | Fire Stone    |
        | Should Be Equal | ${into} | FLAREON        |
        """
        key = species_name.upper()
        species = next(
            (s for s in POKEMON.values() if s.name.upper() == key), None
        )
        if not species:
            raise ValueError(f"Unknown species: '{species_name}'")
        evo = species.evolution
        stone_upper = stone.upper()
        result: Optional[str] = None
        if isinstance(evo, list):
            for branch in evo:
                if branch.get("item", "").upper() == stone_upper:
                    result = branch.get("into")
                    break
        elif evo is not None:
            if evo.get("item", "").upper() == stone_upper:
                result = evo.get("into")
        logger.info(f"{species_name} + {stone} evolution → {result}")
        return result

    # ──────────────────────────────────────────────────────────────
    # Type effectiveness lookup
    # ──────────────────────────────────────────────────────────────

    @keyword("Get Type Effectiveness")
    def get_type_effectiveness(self, attacking_type: str, defending_type: str) -> float:
        """
        Return the damage multiplier when a move of ``attacking_type`` hits a
        Pokémon of ``defending_type``.

        Returns ``2.0`` (super effective), ``0.5`` (not very effective),
        ``0.0`` (immune), or ``1.0`` (neutral).

        Arguments:
        - ``attacking_type``: The move's type (e.g. ``Fire``).
        - ``defending_type``: The defender's type (e.g. ``Grass``).

        Examples:
        | ${mult}= | Get Type Effectiveness | Fire    | Grass   |
        | Should Be Equal As Numbers | ${mult} | 2.0    |
        | ${mult}= | Get Type Effectiveness | Normal  | Ghost   |
        | Should Be Equal As Numbers | ${mult} | 0.0    |
        """
        chart = TYPE_CHART.get(attacking_type.capitalize(), {})
        mult = chart.get(defending_type.capitalize(), 1.0)
        logger.info(
            f"Type effectiveness: {attacking_type} vs {defending_type} = {mult}x"
        )
        return mult

    # ──────────────────────────────────────────────────────────────
    # Test lifecycle keywords
    # ──────────────────────────────────────────────────────────────

    @keyword("Post Tests Finished Message")
    def post_tests_finished_message(self, suite_name: Optional[str] = None) -> None:
        """
        Log a formatted banner message indicating that the test run has finished.

        Intended to be called from a ``Suite Teardown`` or at the end of a test
        suite to provide a clear visual marker in the log output.

        Arguments:
        - ``suite_name``: Optional name of the suite to include in the message.

        Examples:
        | Post Tests Finished Message |                          |
        | Post Tests Finished Message | suite_name=Pokemon Tests |
        """
        rich_label = f" — {suite_name}" if suite_name else ""
        self.send_text(
            "",
            "[bold green]" + "=" * 46 + "[/bold green]",
            f"[bold green]  ✅  Tests Finished{rich_label}[/bold green]",
            "[bold green]" + "=" * 46 + "[/bold green]",
            "",
        )
