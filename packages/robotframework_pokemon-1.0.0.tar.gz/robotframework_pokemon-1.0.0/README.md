# robotframework-pokemon

Robot Framework keyword library for the [pytemon](https://github.com/MobyNL/pytemon) Pokemon game.

> **Disclaimer:** This is an unofficial fan project and is not affiliated with, endorsed by, or connected to Nintendo, Game Freak, or The Pokémon Company. Pokémon and all related names are trademarks of Nintendo / Creatures Inc. / GAME FREAK inc. This project is made for educational and entertainment purposes only, with love for the franchise.

## Overview

`robotframework-pokemon` exposes the pytemon game as Robot Framework keywords, allowing you to launch the interactive terminal, inspect save files, and rate trainer skills from a `.robot` test suite.

## Setup

```bash
cd robotframework-pokemon/
poetry install
```

## Run the game via Robot Framework

```bash
poetry run robot test.robot
# or
./run_robot.sh
```

## Running tests while playing Pokemon

The recommended way to run Robot Framework tests alongside the game is to use the `Start Interactive Terminal` keyword, which launches the Pokemon game in a **new terminal window** so your tests can interact with it without blocking the test runner.

This keyword should be placed in a global `__init__.robot` file as a **Suite Setup**, so the game is started once before any tests run. Pair it with `Post Tests Finished Message` as a **Suite Teardown** to get a clear visual banner in the log when your suite finishes.

### `__init__.robot`

```robot
*** Settings ***
Library    PokemonLibrary

Suite Setup       Start Interactive Terminal
Suite Teardown    Post Tests Finished Message    suite_name=Pokemon Suite
```

The `Start Interactive Terminal` keyword opens the game in a new window by default. The test suite continues immediately while the player enjoys the game, and any test keywords can interact with the running terminal throughout.

To be explicit about the new-window behaviour:

```robot
*** Settings ***
Library    PokemonLibrary

Suite Setup       Start Interactive Terminal    new_window=${True}
Suite Teardown    Post Tests Finished Message    suite_name=Pokemon Suite
```

## Available Keywords

| Keyword | Description |
|---|---|
| `Start Interactive Terminal` | Launch the Textual TUI (new window by default) |
| `Send Command` | Send a command to the running terminal |
| `Get Save Game Stats` | Return formatted save file statistics |
| `Rate My Trainer Skills` | Score and grade a trainer's save file |
| `Post Tests Finished Message` | Log a formatted banner when the suite finishes |

## Project structure

```
robotframework-pokemon/
├── PokemonLibrary/    # RF keyword library (wraps pytemon)
│   ├── __init__.py
│   └── library.py
├── atests/            # Robot Framework acceptance tests
├── test.robot         # Main RF launcher
├── run_robot.sh       # Helper script
└── pyproject.toml
```
