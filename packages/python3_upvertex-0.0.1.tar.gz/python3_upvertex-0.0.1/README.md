# python3-upvertex

Namespace reservation for UpVertex Inc. (www.upvertex.com)