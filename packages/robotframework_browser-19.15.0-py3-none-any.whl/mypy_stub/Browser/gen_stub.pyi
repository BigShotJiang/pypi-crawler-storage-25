import Browser
from _typeshed import Incomplete
from collections.abc import Generator

BR: Browser.Browser
KW_METHOD_NAMES: Incomplete
ADDED_KW: list[str]

def parse_kw_module_lines(lines: list[str]): ...
def parse_kw_stubs() -> Generator[Incomplete, Incomplete]: ...

pyi_boilerplate: str
lines: Incomplete
