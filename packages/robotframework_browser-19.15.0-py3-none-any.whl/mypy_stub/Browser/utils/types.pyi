from _typeshed import Incomplete

class Secret:
    value: Incomplete
    def __init__(self, value: str) -> None: ...
    robot_framework_browser_secret: bool
